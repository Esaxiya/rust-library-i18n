use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// A ituaiga afifi e fausia taimi uninitialized o `T`.
///
/// # Initialization invariant
///
/// O le tuʻufaʻatasia, i se tulaga lautele, manatu o se fesuiaʻiga e faʻalelei amataina e tusa ai ma manaʻoga o le ituaiga o fesuiaʻiga.Mo se faʻataʻitaʻiga, o se fesuiaʻiga o ituaiga faʻamatalaga e tatau ona faʻafetaui ma le leai.
/// o se invariant lenei e tatau *pea* ona lagolagoina, e oo lava i code saogalemu.
/// O se taunuuga, o-initializing a ma liuliuina o faasinomaga ituaiga mafua vave [undefined behavior][ub], e tusa lava pe o lena faasinomaga lava e oo atu faaaogaina e avanoa manatua:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // amioga le mafaamatalaina!️
/// // O le tulafono e tutusa ma `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // amioga le mafaamatalaina!️
/// ```
///
/// ua exploited lenei e ala i le tuufaatasia mo optimizations eseese, e pei o eliding siaki taufetuli-taimi ma optimizing faatulagaga `enum`.
///
/// E faapena foi, e matua uninitialized manatua e mafai ona maua i so o se mataupu, ae e tatau ona avea i taimi uma se `bool` `true` po `false`.O lea la, faia o se `bool` o amioga undefined uninitialized:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // amioga le mafaamatalaina!️
/// // Le tutusa tutusa ma `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // amioga le mafaamatalaina!️
/// ```
///
/// Gata i lea, e manatua uninitialized e faapitoa i ai e leai se taua faatulagaina ("fixed" o lona uiga "it won't change without being written to").O le faitauga i le pa e tasi e le faʻaaogaina i le tele o taimi e mafai ona maua ai eseʻesega.
/// O lenei mea e le mafaamatalaina amioga ia i ai uninitialized faʻamaumauga i se fesuiaiga tusa lava pe o lena fesuiaʻiga ei ai se integer ituaiga, lea a le o lea e mafai ona taofia soʻo se *faʻamau* bit mamanu:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // amioga le mafaamatalaina!️
/// // O le tulafono e tutusa ma `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // amioga le mafaamatalaina!️
/// ```
/// (Faasilasilaga e le faamautuina pea o le tulafono o loo siomia integers uninitialized, ae seia oo ina latou, e fautuaina e aloese mai ai.)
///
/// I le pito i luga o lena mea, manatua o le tele o ituaiga o loʻo iai ni faʻaopoopoga faʻaopoopo i tua atu o le naʻo le amataina i le ituaiga tulaga.
/// Mo se faataitaiga, o se '1`-initialized [`Vec<T>`] ua manatu initialized (i lalo o le faatinoga i le taimi nei; e le aofia ai se faamaoniga mautu lenei) ona o le manaoga na iloa e le na tuufaatasia e uiga i ai e faapea e tatau ona e lē soloia le faasino ai faamatalaga.
/// O le fatuina o se `Vec<T>` e le pogai *vave* amioga undefined, ae o le a mafua ai amioga undefined ma sili ona galuega saogalemu (e aofia ai le pau ai).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` auauna ina ia mafai code saogalemu e feagai ai ma faamatalaga uninitialized.
/// O se faailo i le tuufaatasia o faailoa ai e faapea o le faamatalaga iinei mafai *le* ona initialized:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Fai se faasinomaga manino uninitialized.
/// // O le tuufaatasia iloa e mafai ona aoga o faamatalaga i totonu o se `MaybeUninit<T>`, ma o lea e le o UB lenei:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Tuu i se taua aloaia.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Ia maua mai le faamatalaga initialized-o lenei ua na faatagaina *ina ua uma* lelei initializing `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// E iloa loa e le tuʻufaʻatasiga e aua neʻi faia ni masalosaloga le saʻo poʻo se faʻamaoniga i luga o lenei tulafono.
///
/// E mafai ona e mafaufau i `MaybeUninit<T>` e avea o se vaega e pei o `Option<T>` ae e aunoa ma so o se taufetuli-taimi e Siaki ai ma e aunoa ma so o se siaki saogalemu.
///
/// ## out-pointers
///
/// E mafai ona e faaaogaina `MaybeUninit<T>` e faatino "out-pointers": ae le o le toe foi o faamatalaga mai se galuega tauave, oo i ai se faasino i nisi manatua (uninitialized) e tuu le taunuuga i.
/// e mafai ona aoga lenei mea pe a e taua mo le Tagata telefoni mai e pulea le auala e manatua ua teuina le taunuuga i le e oo atu faasoasoa, ma e te manao e aloese ai mai gaoioiga le talafeagai.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` e le faʻapaʻuina mea tuai, e taua.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // O lenei ua tatou iloa ua initialized `v`!E faʻapea foi ona mautinoa o le vector e pa'ū lelei i lalo.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Initializing se elemene-i-elemene autau
///
/// `MaybeUninit<T>` mafai ona faʻaaogaina e faʻamataʻu ai le tele faʻavasega elemeni-i-elemeni:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Fai se autau uninitialized o `MaybeUninit`.
///     // O le `assume_init` e saogalemu ona o le ituaiga o loo tatou faapea ua initialized iinei o se vaega o le 'MaybeUninit`s, e le manaomia initialization.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Pau a e leai se mea `MaybeUninit`.
///     // Faapea le faaaogaina o tofiga e faasino ai mata ae le o le e le faia ai e le taua uninitialized tuai ona maligi `ptr::write`.
/////
///     // Foi pe afai ei ai se panic i lenei matasele, ua tatou maua se mama manatua, ae e leai se mataupu saogalemu manatua.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // ua initialized mea uma.
///     // Faʻaliliu le laina i le ituaiga amata.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// E mafai foi ona galulue faatasi ma initialized vaega arrays, lea e mafai ona maua i datastructures maualalo le tulaga.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Fai se autau uninitialized o `MaybeUninit`.
/// // O le `assume_init` e saogalemu ona o le ituaiga o loo tatou faapea ua initialized iinei o se vaega o le 'MaybeUninit`s, e le manaomia initialization.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Faitau le aofai o elemene tatou ua tofia i ai.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Mo aitema taʻitasi i le laina, faʻapaʻu pe a matou faʻasoaina.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Initializing se fanua-i-fanua fausia
///
/// E mafai ona e faaaogaina `MaybeUninit<T>`, ma le macro [`std::ptr::addr_of_mut`], e initialize fanua structs e fanua:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Initializing le fanua `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Initializing le `list` fanua Afai ei ai se panic iinei, lea o le `String` i le mama ma le faaleagaina fanua `name`.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // ua initialized uma o le fanua, ina ia tatou valaau `assume_init` ia maua ai se initialized Foo.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` ua mautinoa le i ai o le tele lava e tasi, ia talafeagai, ma ABI pei `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Peitai ia manatua o a ituaiga *o loo i* a `MaybeUninit<T>` e le ona o le faatulagaga lava e tasi;e le i faamaoniga aoao Rust o le fanua o se `Foo<T>` maua le faatulagaga e tasi e pei o se `Foo<U>` e tusa lava pe maua `T` ma `U` le tele lava e tasi ma ia talafeagai.
///
/// E lē gata ona e aloaia o so o se vaega itiiti o le taua mo se `MaybeUninit<T>` le mafai ona faaaoga le tuufaatasia optimizations non-zero/niche-filling, e ono iʻu ai i se telē tele:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Afai e FFI-saogalemu `T`, ona ua faapea lava o `MaybeUninit<T>`.
///
/// E ui o le `MaybeUninit` o le `#[repr(transparent)]` (o loʻo faʻailoa mai ai e mautinoa le tutusa tutusa, faʻafetaui, ma le ABI e pei o le `T`), o le mea lea e le * suia ai seisi o faʻaliga na muamua atu.
/// `Option<T>` ma e mafai ona maua pea `Option<MaybeUninit<T>>` ituaiga eseese, ma ituaiga o loo i ai se e mafai ona faataatia mai fanua o ituaiga `T` (ma lapopoa) ese pe afai `MaybeUninit<T>` le fanua.
/// `MaybeUninit` o se ituaiga faatasiga, ma `#[repr(transparent)]` i iuni o mautu (tagai [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Le aluga o taimi, o le faamaoniga tonu o `#[repr(transparent)]` i iuni mafai evolve, ma e mafai pe le mafai foi tumau `MaybeUninit` `#[repr(transparent)]`.
/// Na faapea mai, `MaybeUninit<T>` a *pea* faamaoniga ei ai le tele lava e tasi, ia talafeagai, ma ABI pei `T`;ua na o le auala `MaybeUninit` meafaigaluega mafai evolve lena faamaoniga.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang mea ina ia mafai ona afifi isi ituaiga i ai.e aoga lenei mo eletise.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Le valaʻau i le `T::clone()`, e le mafai ona tatou iloa pe ua lava le amataga mo lena mea.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Faatupu ai se `MaybeUninit<T>` fou initialized i le taua na tuuina mai.
    /// E saogalemu le valaau [`assume_init`] i le toe foi mai le taua o lenei galuega tauave.
    ///
    /// Manatua o le faapaʻuina o le a le mafai lava valaau `MaybeUninit<T>` 'code mataua a T`.
    /// O lou tiutetauave e faia e oo atu maligi mautinoa `T` pe afai ua ma initialized.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Faatupu ai se `MaybeUninit<T>` fou i se tulaga uninitialized.
    ///
    /// Manatua o le faapaʻuina o le a le mafai lava valaau `MaybeUninit<T>` 'code mataua a T`.
    /// O lou tiutetauave e faia e oo atu maligi mautinoa `T` pe afai ua ma initialized.
    ///
    /// Tagai i le [type-level documentation][MaybeUninit] mo nisi faataitaiga.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Fai se autau fou o mea `MaybeUninit<T>`, i se tulaga uninitialized.
    ///
    /// Note: i se future Rust lomiga e mafai ona avea le talafeagai lenei auala pe a syntax moni autau mafai [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// mafai ona e faaaogaina lea o le faataitaiga o loo i lalo `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Faafoi a (atonu laiti) fasi o faamatalaga na faitau moni
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // SAFETY: O le `[MaybeUninit<_>; LEN]` le faʻaaogaina e aoga.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Faatupu ai se fou `MaybeUninit<T>` i se tulaga uninitialized, faatasi ai ma le manatu ua faatumuina i bytes `0`.E faʻamoemoe ile `T` pe o lena ua maeʻa faia mo le amataga lelei.
    ///
    /// Mo se faataitaiga, ua initialized `MaybeUninit<usize>::zeroed()`, ae `MaybeUninit<&'static i32>::zeroed()` e le ona o le tatau ona soloia mau.
    ///
    /// Manatua o le faapaʻuina o le a le mafai lava valaau `MaybeUninit<T>` 'code mataua a T`.
    /// O lou tiutetauave e faia e oo atu maligi mautinoa `T` pe afai ua ma initialized.
    ///
    /// # Example
    ///
    /// Saʻo le faaaogaina o lenei galuega tauave: initializing a fausia ma o, i le mea fanua uma o le fausia e mafai ona umia le si-mamanu 0 o se taua aloaia.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Sese faaaogaina* o lenei galuega tauave: valaau `x.zeroed().assume_init()` pe a lē `0` a aoga si-mamanu mo le ituaiga:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Totonu o se paga, matou te faia se `NotZero` e leai se faʻailoga faʻailoga tonu.
    /// // o amioga undefined lenei.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // SAOGALEMU: faasino `u.as_mut_ptr()` e manatua faasoasoa.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Ua faatulagaina e le tau aogā o le `MaybeUninit<T>`.
    /// O lenei overwrites se taua muamua e aunoa ma le pau, o lea ia faaeteete ia aua le faaaogaina lenei faalua seia vagana ai e te manao e faamisi tamoe le destructor.
    ///
    /// Mo outou le faafaigofieina, e toe foi mai foi lenei o se faasinomaga mutable i le (o lenei initialized saogalemu) anotusi o `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // SAOGALEMU: E na o initialized lenei taua.
        unsafe { self.assume_init_mut() }
    }

    /// Maua se e faasino i le taua o loo i ai.
    /// O le faitauina mai lenei e faasino po o le liliu ai i se faasinomaga o amioga undefined seia vagana ai ua initialized le `MaybeUninit<T>`.
    /// Tusitusi i mea e manatua ai o le faʻasino tusi (non-transitively) faʻasino i ai e le o faʻamatalaina amioga (seʻi vagana o totonu o le `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Faʻaoga saʻo o lenei metotia:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Fatu se faasinomaga i le `MaybeUninit<T>`.e le afaina o lenei ona tatou initialized ai.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Sese* le faaaogaina o lenei auala:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Ua matou faia se faʻamatalaga i se uninitialized vector!Ole amio le faʻamatalaina lea.️
    /// ```
    ///
    /// (Faʻaaliga o tulafono o loʻo faʻasino i faʻamatalaga e leʻo faʻamaonia e leʻi maeʻa, ae a oʻo loa, e fautuaina e aloese mai ai.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` ma `ManuallyDrop` o `repr(transparent)` uma ina ia mafai ona matou lafo le faʻasino tusi.
        self as *const _ as *const T
    }

    /// Maua a faʻasino mutable i le taua o loo i ai.
    /// O le faitauina mai lenei e faasino po o le liliu ai i se faasinomaga o amioga undefined seia vagana ai ua initialized le `MaybeUninit<T>`.
    ///
    /// # Examples
    ///
    /// Faʻaoga saʻo o lenei metotia:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Fatu se faasinomaga i le `MaybeUninit<Vec<u32>>`.
    /// // E le afaina lea ona na matou faʻauʻuina.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Sese* le faaaogaina o lenei auala:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Ua matou faia se faʻamatalaga i se uninitialized vector!Ole amio le faʻamatalaina lea.️
    /// ```
    ///
    /// (Faʻaaliga o tulafono o loʻo faʻasino i faʻamatalaga e leʻo faʻamaonia e leʻi maeʻa, ae a oʻo loa, e fautuaina e aloese mai ai.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` ma `ManuallyDrop` o `repr(transparent)` uma ina ia mafai ona matou lafo le faʻasino tusi.
        self as *mut _ as *mut T
    }

    /// Otootoga le taua mai le pusa `MaybeUninit<T>`.o se auala sili lenei e mautinoa o le a maua le faapau faamatalaga faamauina, ona o le taunuuga o `T` e noatia i le taulimaina masani mataua.
    ///
    /// # Safety
    ///
    /// E oo atu i le telefoni i luga o faamaoniga e moni le `MaybeUninit<T>` i se tulaga initialized.Valaau lenei ina ua faamalieina e lei initialized atoatoa mafuaaga amioga undefined vave.
    /// O le [type-level documentation][inv] o loʻo iai isi faʻamatalaga e uiga i lenei amataga amataina.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// I le pito i luga o lena mea, manatua o le tele o ituaiga o loʻo iai ni faʻaopoopoga faʻaopoopo i tua atu o le naʻo le amataina i le ituaiga tulaga.
    /// Mo se faataitaiga, o se '1`-initialized [`Vec<T>`] ua manatu initialized (i lalo o le faatinoga i le taimi nei; e le aofia ai se faamaoniga mautu lenei) ona o le manaoga na iloa e le na tuufaatasia e uiga i ai e faapea e tatau ona e lē soloia le faasino ai faamatalaga.
    ///
    /// O le fatuina o se `Vec<T>` e le pogai *vave* amioga undefined, ae o le a mafua ai amioga undefined ma sili ona galuega saogalemu (e aofia ai le pau ai).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Faʻaoga saʻo o lenei metotia:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Sese* le faaaogaina o lenei auala:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` e leʻi amataina, ae o le laina mulimuli lea na mafua ai amioga le faʻamatalaina.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // SAFETY: o le tagata telefoni e tatau ona mautinoa o `self` ua amataina.
        // O lenei foi o lona uiga e tatau ona `self` a variant `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Faitauina le taua mai le pusa `MaybeUninit<T>`.O le taunuuga o `T` e noatia i le taulimaina masani mataua.
    ///
    /// Soo se taimi lava e mafai ai, e sili atu le faaaoga nai lo [`assume_init`], lea e taofia faia o ni kopi le aano o le `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// E oo atu i le telefoni i luga o faamaoniga e moni le `MaybeUninit<T>` i se tulaga initialized.Valaau lenei ina ua faamalieina e lei initialized atoatoa mafuaaga amioga undefined.
    /// O le [type-level documentation][inv] o loʻo iai isi faʻamatalaga e uiga i lenei amataga amataina.
    ///
    /// Lē gata i lea, o lenei lau se kopi o le tua lava lea e tasi o faamatalaga i le `MaybeUninit<T>`.
    /// A faaaoga le tele o kopi o le faamatalaga (i le valaauina taimi tele `assume_init_read`, po o le uluai valaau `assume_init_read` ma [`assume_init`]), o lou tiutetauave o le mautinoa lea e mafai ona faia ni kopi moni lava lena faamatalaga.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Faʻaoga saʻo o lenei metotia:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` o le `Copy`, o lea e mafai ai ona tatou faitau faʻatele.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Faia o ni kopi a taua `None` e le afaina, o lea e mafai ona tatou faitauina taimi tele.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Sese* le faaaogaina o lenei auala:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Tatou nei foafoaina kopi e lua o le tasi vector, e tau atu i se ⚠️ lua-saoloto pe a latou uma Mauaina maligi!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // SAFETY: o le tagata telefoni e tatau ona mautinoa o `self` ua amataina.
        // O le faitauina mai `self.as_ptr()` e saogalemu talu tatau ona initialized `self`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Mataua o le o loo taua i nofoaga.
    ///
    /// Afai e ia te oe le ona `MaybeUninit`, oe mafai ona faʻaaoga [`assume_init`] nai lo.
    ///
    /// # Safety
    ///
    /// E oo atu i le telefoni i luga o faamaoniga e moni le `MaybeUninit<T>` i se tulaga initialized.Valaau lenei ina ua faamalieina e lei initialized atoatoa mafuaaga amioga undefined.
    ///
    /// I luga o lena, e tatau ona faamalieina uma invariants faaopoopo o le ituaiga `T`, e pei ona faatinoina `Drop` le o `T` (po o ona tagata) e mafai ona faalagolago i lenei.
    /// Mo se faataitaiga, o se '1`-initialized [`Vec<T>`] ua manatu initialized (i lalo o le faatinoga i le taimi nei; e le aofia ai se faamaoniga mautu lenei) ona o le manaoga na iloa e le na tuufaatasia e uiga i ai e faapea e tatau ona e lē soloia le faasino ai faamatalaga.
    ///
    /// Pau se `Vec<T>` Peitai o le a mafua amioga undefined.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // SAOGALEMU: ua initialized le faamaoniga tatau Tagata telefoni e `self` ma
        // faamalieina invariants uma o `T`.
        // Le pau o le taua i le nofoaga o le saogalemu pe afai o le tulaga lena.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Mauaina se faʻasoa faʻasino i le taua aofaʻi.
    ///
    /// e mafai ona aoga lenei mea pe a tatou mananao e maua se `MaybeUninit` ua initialized ae te le umiaina o le `MaybeUninit` (puipuia o le faaaogaina o `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Valaau lenei ina e lei initialized atoatoa le aano mafuaaga amioga undefined: e le o aʻe i le telefoni i faamaoniga o le moni o `MaybeUninit<T>` i se tulaga initialized.
    ///
    ///
    /// # Examples
    ///
    /// ### Faʻaoga saʻo o lenei metotia:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Initialize `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // O lenei ua iloa lo tatou `MaybeUninit<_>` e initialized, e le afaina le faia o se faasinomaga faasoa atu i ai:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // ua initialized `x`: SAOGALEMU.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Sese* faʻaaogaina o lenei metotia:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Ua matou faia se faʻamatalaga i se uninitialized vector!Ole amio le faʻamatalaina lea.️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Initialize le `MaybeUninit` faaaogaina `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Faasinomaga i se uninitialized `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // SAFETY: o le tagata telefoni e tatau ona mautinoa o `self` ua amataina.
        // O lenei foi o lona uiga e tatau ona `self` a variant `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Maua ai se faasinomaga mutable (unique) i le taua o loo i ai.
    ///
    /// e mafai ona aoga lenei mea pe a tatou mananao e maua se `MaybeUninit` ua initialized ae te le umiaina o le `MaybeUninit` (puipuia o le faaaogaina o `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Valaau lenei ina e lei initialized atoatoa le aano mafuaaga amioga undefined: e le o aʻe i le telefoni i faamaoniga o le moni o `MaybeUninit<T>` i se tulaga initialized.
    /// Mo se faataitaiga, e mafai ona faaaogaina `.assume_init_mut()` e initialize a `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Faʻaoga saʻo o lenei metotia:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Initializes *uma* le bytes o le buffer sao.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Initialize `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // O lenei ua tatou iloa ua initialized `buf`, ina ia mafai ona `.assume_init()` ai.
    /// // Ae peitai, i le faaaogaina `.assume_init()` e mafai ona faaosofia ai le `memcpy` o le 2048 bytes.
    /// // E folafola atu ua initialized tatou buffer aunoa kopiina ai, tatou faaleleia le `&mut MaybeUninit<[u8; 2048]>` i se `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // ua initialized `buf`: SAOGALEMU.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // O lenei e mafai ona tatou faaaogaina `buf` o se fasi masani:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Sese* faʻaaogaina o lenei metotia:
    ///
    /// E le mafai ona e faʻaaogaina le `.assume_init_mut()` e amata ai se tau aoga:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Ua tatou faia se faasinomaga (mutable) i se uninitialized `bool`!
    ///     // o amioga undefined lenei.⚠️
    /// }
    /// ```
    ///
    /// Mo se faataitaiga, e le mafai [`Read`] i se buffer uninitialized:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) faasinomaga i uninitialized manatua!
    ///                             // o amioga undefined lenei.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Le mafai foi ona e faaaogaina le avanoa fanua tuusao e faia fanua-i-fanua initialization malie:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) faasinomaga i uninitialized manatua!
    ///                  // o amioga undefined lenei.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) faasinomaga i uninitialized manatua!
    ///                  // o amioga undefined lenei.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): O loʻo matou faʻamoemoe nei i luga e sese, pei ona iai matou faʻasino i faʻamatalaga e leʻo faʻaogaina (eg ile `libcore/fmt/float.rs`).
    // E tatau ona tatou faia se faaiuga mulimuli e uiga i le tulafono i luma o stabilization.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // SAFETY: o le tagata telefoni e tatau ona mautinoa o `self` ua amataina.
        // O lenei foi o lona uiga e tatau ona `self` a variant `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Otootoga o le tulaga faatauaina o mai se autau o pusa `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// E oo atu i le Tagata telefoni mai e faamaoniga o elemene uma o le autau ua i ai i se tulaga initialized.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // SAOGALEMU: O lenei saogalemu ao tatou initialised elemene uma
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * O le faamaoniga Tagata telefoni mai o elemene uma o le autau ua initialized
        // * `MaybeUninit<T>` ma T e mautinoa le tutusa faʻatulagaina
        // * e le pau MaybeUnint, o lea e leai se lua-faasaolotoina Ma ua faapea ona e saogalemu ai le liua
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Le mafaufau uma ua initialized elemene, maua se fasi ia i latou.
    ///
    /// # Safety
    ///
    /// E oo atu i le telefoni e faamaonia e faapea o le elemene `MaybeUninit<T>` moni lava i se tulaga initialized.
    ///
    /// Valaau lenei ina ua faamalieina e lei initialized atoatoa mafuaaga amioga undefined.
    ///
    /// Vaʻai [`assume_init_ref`] mo nisi faʻamatalaga ma faʻataʻitaʻiga.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // SAFETY: lafoina fasi i le `*const [T]` e saogalemu talu ai o le tagata telefoni na faʻamaonia lena
        // `slice` o initialized, ua faamaonia and`MaybeUninit` e maua ai le faatulagaga e tasi e pei `T`.
        // O le faasino maua e aloaia talu ai e faatatau i manatua umia e `slice` lea o se faasinomaga ma faapea ona faamaonia ina ia aoga mo le faitauina.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Faapea o elemene uma ua amataina, aumai se fesuiaʻiga fasi ia latou.
    ///
    /// # Safety
    ///
    /// E oo atu i le telefoni e faamaonia e faapea o le elemene `MaybeUninit<T>` moni lava i se tulaga initialized.
    ///
    /// Valaau lenei ina ua faamalieina e lei initialized atoatoa mafuaaga amioga undefined.
    ///
    /// Tagai [`assume_init_mut`] mo nisi auiliiliga ma faataitaiga.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // SAFETY: e tutusa ma le saogalemu tusi mo `slice_get_ref`, ae o loʻo iai a matou
        // faasinomaga mutable lea ua faamaonia foi ina ia aoga mo tusia.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Maua se faʻasino i le muamua elemeni o le laina.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Maua a faʻasino mutable i le elemene muamua o le autau.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Kopi le elemene mai `src` e `this`, toe foi se faasinomaga mutable i le mataupu nei initalized o `this`.
    ///
    /// Afai e le faatino `T` `Copy`, faaaoga [`write_slice_cloned`]
    ///
    /// e tutusa lenei e [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// O lenei galuega tauave a panic pe afai o le fasi e lua finafinau eseese.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SAOGALEMU: na tatou kopiina elemene uma o Len i le tulaga faaleoleo
    /// // le elemene muamua src.len() o le vec e aloaia i le taimi nei.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // SAOGALEMU: &[T] ma&[MaybeUninit<T>] Le faatulagaga lava lea e tasi
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // SAOGALEMU: elemene aloaia ua faatoa kopiina i `this` ina ua initalized
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Clones le elemene mai `src` e `this`, toe foi se faasinomaga mutable i le mataupu nei initalized o `this`.
    /// Soʻo se elemene ua uma ona faʻaaogaina e le mafai ona lafoa.
    ///
    /// A faʻaaoga `T` `Copy`, faʻaaoga [`write_slice`]
    ///
    /// e tutusa lenei e [`slice::clone_from_slice`] ae le pau elemene oi ai nei.
    ///
    /// # Panics
    ///
    /// Lenei gaioiga o le a panic pe a fai o fasi pepa e lua e eseese umi, pe a fai o le faʻatinoina o `Clone` panics.
    ///
    /// Afai ei ai se panic, o le ua uma ona cloned le a pau elemene.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SAFETY: faatoa uma ona tatou faʻailoaina elemeni uma o len i le avanoa avanoa
    /// // le elemene muamua src.len() o le vec e aloaia i le taimi nei.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // E le pei o kopi_from_slice e le taʻua lenei clone_from_slice i luga o le fasi, ona o `MaybeUninit<T: Clone>` e le faʻaogaina Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // SAOGALEMU: lenei fasi mata o le a aofia ai na mea faitino initialized
                // O le mafuaaga lena, ua faatagaina o ia e aveesea ai.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: E manaʻomia e tatou ona vaʻaia faʻasolosolo ona vaeluaina i latou ile tutusa tutusa
        // mo tuaoi siakiina e elided, ma o le a faatupuina ai le optimizer memcpy mo tulaga faigofie (mo se faataitaiga T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // e manaomia leoleo e ono tupu b/c panic le taimi o se clone
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // SAOGALEMU: elemene aloaia faatoa tusia i `this` ina ua initalized
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}