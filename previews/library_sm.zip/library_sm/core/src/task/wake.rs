#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// O le `RawWaker` faʻatagaina le faʻatinoina o se tagata faʻatino galuega e fausia se [`Waker`] lea e maua ai le faʻapitoa amioga ala.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// E aofia ai o se faamatalaga e faasino ai ma se [virtual function pointer table (vtable)][vtable] e customizes le amioga o le `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// O se faʻasino faʻasino tusi, lea e mafai ona faʻaaogaina e faʻaputu ai faʻamatalaga faʻapitoa e pei ona manaʻomia e le tagata faʻatonu.
    /// mafai ona avea lenei eg
    /// a faasino ai aveesea-ituaiga i se `Arc` o loo fesootai ma le galuega.
    /// O le taua o lenei fanua e oo atu pasia i galuega tauave uma o se vaega o le vtable pei o le muamua parameter.
    ///
    data: *const (),
    /// laulau e faasino ai galuega tauave tafailagi e customizes le amioga o lenei waker.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Fausia se `RawWaker` fou mai le `data` faʻasino faasino ma `vtable`.
    ///
    /// e mafai ona faaaoga e faasino ai `data` le e teu ai faamatalaga soʻona faia e pei ona manaomia e le faataunuuina.Lenei mafai faʻapea eg
    /// a faasino ai aveesea-ituaiga i se `Arc` o loo fesootai ma le galuega.
    /// O le tau o lenei faʻasino tusi o le a pasi atu i gaioiga uma o se vaega o le `vtable` o le muamua parakalafa.
    ///
    /// O le `vtable` faʻapitoa le amio a le `Waker` lea na faia mai le `RawWaker`.
    /// Mo taʻotoga taʻitasi i luga o le `Waker`, o le fesoʻotaiga o gaioiga i le `vtable` o le `RawWaker` o le a valaauina o le a valaauina.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// O se laulau e faasino ai galuega tauave tafailagi (vtable) ua faamaoti i le amio o le a [`RawWaker`].
///
/// O le faʻasino tusi pasi i galuega uma i totonu o le vaʻai o le `data` faʻasino mai le faʻamau [`RawWaker`] mea.
///
/// O gaioiga i totonu o lenei faʻavae e naʻo le faamoemoeina e valaauina i luga o le `data` faʻasino o se mea lelei fausiaina [`RawWaker`] mea mai totonu o le [`RawWaker`] faʻatinoina.
/// Valaʻauina se tasi o galuega o loʻo i ai i le faʻaaogaina o soʻo se isi `data` faʻasino tusi o le a mafua ai amio le mafaamatalaina.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// O lenei gaioiga o le a valaʻauina pe a oʻo i le [`RawWaker`] ona faʻapipiʻiina, faʻapei o le [`Waker`] o loʻo teu ai le [`RawWaker`] ua faʻapipiʻiina.
    ///
    /// Le faatinoina o lenei galuega tauave e tatau ona taofia uma punaoa o loo manaomia mo lenei faataitaiga faaopoopo o se [`RawWaker`] ma galuega fesootai.
    /// Valaʻau `wake` ile iʻuga [`RawWaker`] e tatau ona iʻu i le toe fafaguina o le tutusa galuega e ono fafaguina e le muamua [`RawWaker`].
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// O lenei gaioiga o le a valaʻauina pe a valaʻau `wake` i luga o le [`Waker`].
    /// E tatau ona ala i luga le galuega e fesoʻotaʻi ma lenei [`RawWaker`].
    ///
    /// O le faʻatinoina o lenei galuega e tatau ona mautinoa ia faʻasaʻoloto soʻo se mea e fesoʻotaʻi ma lenei taimi o le [`RawWaker`] ma fesoʻotaʻi galuega.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// o le a taʻua lenei galuega tauave ina ua taʻua `wake_by_ref` i le [`Waker`].
    /// E tatau ona ala i luga le galuega e fesoʻotaʻi ma lenei [`RawWaker`].
    ///
    /// O lenei gaioiga e tutusa ma le `wake`, ae le tatau ona faʻaaogaina le faʻamaumauga tuʻuina mai faʻasino.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// E faʻaigoa lenei gaioiga pe a paʻu le [`RawWaker`].
    ///
    /// O le faʻatinoina o lenei galuega e tatau ona mautinoa ia faʻasaʻoloto soʻo se mea e fesoʻotaʻi ma lenei taimi o le [`RawWaker`] ma fesoʻotaʻi galuega.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Fausia se `RawWakerVTable` fou mai le saunia `clone`, `wake`, `wake_by_ref`, ma `drop` galuega.
    ///
    /// # `clone`
    ///
    /// O lenei gaioiga o le a valaʻauina pe a oʻo i le [`RawWaker`] ona faʻapipiʻiina, faʻapei o le [`Waker`] o loʻo teu ai le [`RawWaker`] ua faʻapipiʻiina.
    ///
    /// Le faatinoina o lenei galuega tauave e tatau ona taofia uma punaoa o loo manaomia mo lenei faataitaiga faaopoopo o se [`RawWaker`] ma galuega fesootai.
    /// Valaʻau `wake` ile iʻuga [`RawWaker`] e tatau ona iʻu i le toe fafaguina o le tutusa galuega e ono fafaguina e le muamua [`RawWaker`].
    ///
    /// # `wake`
    ///
    /// O lenei gaioiga o le a valaʻauina pe a valaʻau `wake` i luga o le [`Waker`].
    /// E tatau ona ala i luga le galuega e fesoʻotaʻi ma lenei [`RawWaker`].
    ///
    /// O le faʻatinoina o lenei galuega e tatau ona mautinoa ia faʻasaʻoloto soʻo se mea e fesoʻotaʻi ma lenei taimi o le [`RawWaker`] ma fesoʻotaʻi galuega.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// o le a taʻua lenei galuega tauave ina ua taʻua `wake_by_ref` i le [`Waker`].
    /// E tatau ona ala i luga le galuega e fesoʻotaʻi ma lenei [`RawWaker`].
    ///
    /// O lenei gaioiga e tutusa ma le `wake`, ae le tatau ona faʻaaogaina le faʻamaumauga tuʻuina mai faʻasino.
    ///
    /// # `drop`
    ///
    /// E faʻaigoa lenei gaioiga pe a paʻu le [`RawWaker`].
    ///
    /// O le faʻatinoina o lenei galuega e tatau ona mautinoa ia faʻasaʻoloto soʻo se mea e fesoʻotaʻi ma lenei taimi o le [`RawWaker`] ma fesoʻotaʻi galuega.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// O le `Context` o se galuega e le tutusa.
///
/// I le taimi nei, `Context` naʻo le faʻaaogaina o le ulufale i le `&Waker` e mafai ona faʻaaoga e fafagu ai le galuega o loʻo i ai nei.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Ia mautinoa tatou future-faamaoniga e faasaga i suiga variance e faamalosia le olaga atoa e avea invariant (e contravariant olaga atoa finauga-tulaga ao e covariant olaga atoa toe foi-tulaga).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Fausia se `Context` fou mai le `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Toe foi se faasinomaga i le `Waker` mo le galuega i le taimi nei.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// A `Waker` o se au mo le nofo i luga i se galuega e ala i le logoina o lona faataunuuina e le o saunia e tamoe.
///
/// O lenei au encapsulates a se faataitaiga [`RawWaker`], lea e faamatalaina ai le amioga wakeup faataunuuina-patino.
///
///
/// Faʻaaogaina [`Clone`], [`Send`], ma [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Nofo i luga le galuega e fesootai ma lenei `Waker`.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // O le mea moni e ala ai luga valaʻau e faʻatonuina e ala i se tafaoga tafaʻilagi valaʻau valaʻau i le faʻatinoga ua faʻamatalaina e le tagata faʻatonu.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Aua le valaʻau `drop`-o le fafagu o le a faʻaumatia e `wake`.
        crate::mem::forget(self);

        // SAFETI: E saogalemu lenei aua o `Waker::from_raw` na o le pau le auala
        // e initialize `wake` ma `data` e manaomia ai le tagata e faaaogaina e faailoa atu o loo lagolagoina le konekarate o le `RawWaker`.
        //
        unsafe { (wake)(data) };
    }

    /// Ala i luga le galuega e fesoʻotaʻi ma lenei `Waker` e aunoa ma le faʻaaogaina o le `Waker`.
    ///
    /// E tali tutusa lenei ma `wake`, ae atonu e laʻititi laititi le aoga ile mataupu e maua ai le `Waker` e ana.
    /// O lenei metotia e tatau ona sili atu i le valaʻau `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // O le mea moni e ala ai luga valaʻau e faʻatonuina e ala i se tafaoga tafaʻilagi valaʻau valaʻau i le faʻatinoga ua faʻamatalaina e le tagata faʻatonu.
        //

        // SAFETI: vaai `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Toe foi `true` pe afai ua awoken lenei `Waker` ma se isi `Waker` le galuega lava e tasi.
    ///
    /// O lenei gaioiga galue i luga o le sili-taumafaiga faʻavae, ma ono ono faʻafoʻi sese tusa lava pe o le 'Waker`s o le a fagua le tutusa galuega.
    /// Peitai, afai o lenei galuega toe faʻafoʻi `true`, ua mautinoa o le 'Waker`s o le a fagua le galuega lava e tasi.
    ///
    /// O lenei galuega tauave ua faapitoa faaaogaina mo faamoemoega optimization.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Fausia se `Waker` fou mai [`RawWaker`].
    ///
    /// O le amio a le `Waker` toe faʻafoʻi e le faʻamatalaina pe a fai o le konekalate ua faʻamatalaina i totonu o le "RawWaker`] 's ma le""RawWakerVTable`] pepa faʻamaonia e le lagolagoina.
    ///
    /// O le mea lea o le saogalemu o lenei auala.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // SAFETI: E saogalemu lenei aua o `Waker::from_raw` na o le pau le auala
            // ia amataina `clone` ma `data` manaʻomia le tagata faʻaoga ia amanaʻia o le konekalate o [`RawWaker`] e lagolagoina.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // SAFETI: E saogalemu lenei aua o `Waker::from_raw` na o le pau le auala
        // e initialize `drop` ma `data` e manaomia ai le tagata e faaaogaina e faailoa atu o loo lagolagoina le konekarate o le `RawWaker`.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}