#![stable(feature = "core_hint", since = "1.27.0")]

//! Fautuaga i le tuʻufaʻatasia e aʻafia ai pe faʻapefea ona faʻamauina pe faʻalelei se numera.
//! Faʻailo mafai ono tuʻufaʻatasia taimi poʻo faʻavaivai.

use crate::intrinsics;

/// Logoina le tuufaatasia lea e le mafai ona tatou fesootai lenei manatu i le tulafono, e mafai ai atili optimizations.
///
/// # Safety
///
/// Aapa lenei galuega tauave o atoatoa *amioga undefined*(UB).Aemaise lava, e manatu le tuufaatasia e le tatau lava ona tupu uma UB, ma o lea o le a aveesea ai lala uma o le oo atu i se valaauga e `unreachable_unchecked()`.
///
/// E pei o taimi uma o UB, pe afai e liliu atu lenei manatu mai e sese, o lona uiga, o le mea moni mafai ona tatou fesootai i le valaau `unreachable_unchecked()` totonu oi latou uma tafe pulea e mafai, o le a faaaoga le na tuufaatasia le fuafuaga optimization sese, ma e mafai i nisi taimi e oo lava leaga code foliga e le fesootai, na mafua ai difficult-faʻafitauli i-debug.
///
///
/// Faʻaoga lenei galuega pe a faʻatoa mafai ona e faʻamaonia e le taitai valaʻauina le code.
/// A leai, mafaufau e faaaoga le macro [`unreachable!`], lea e le mafai ai optimizations ae o le a panic pe fasiotia.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` e lelei i taimi uma (e le o), o lea o le a toe foi lava `checked_div` `None`.
/////
///     // O le mea lea, o le isi branch e le mafai ona oʻo iai.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // SAFETY: o le saogalemu konekarate mo `intrinsics::unreachable` tatau
    // lagolagoina e le ua valaʻau.
    unsafe { intrinsics::unreachable() }
}

/// Faʻailoa se masini faʻatonuga e faʻailo ai le masini gaioiga o loʻo tamoʻe i totonu o le pisi-faʻatali spin-loop ("vili loka").
///
/// I luga o le mauaina o le taamilosaga matasele-faʻailo mafai e le gaosiga ona faʻalelei lana amio i le, mo se faʻataʻitaʻiga, sefeina le paoa pe fesuiaʻi hyper-filo.
///
/// O lenei galuega e ese mai [`thread::yield_now`] lea gauai saʻo i le scheduler a faiga, ae e le fegalegaleai `spin_loop` i le faiga o faagaoioia.
///
/// O se tulaga masani faaaogaina mo `spin_loop` ua faatinoina noatia taʻai mautinoa i se matasele CAS i primitives synchronization.
/// Ina ia faatoilaloina faafitauli e pei o inversion faamuamua, ua malosi fautuaina ua faamutaina le matasele vili ina ua mavae se aofaiga gata o iterations ma se syscall poloka talafeagai ua faia.
///
///
/// **Faaaliga**: I fausaga opea le lagolagoina mauaina vili-matasele hints e le faia lenei galuega tauave so o se mea i uma.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // O le tufatufaina o atomic taua o filo o le a faʻaaogaina e faʻamaopoopo ai
/// let live = Arc::new(AtomicBool::new(false));
///
/// // I se pito i tua o le filo o le a tatou seti ai le tau
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Fai ni galuega, ona ola lea o le taua
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Tua i lo tatou filo i le taimi nei, tatou te faatalitali mo le taua e seti
/// while !live.load(Ordering::Acquire) {
///     // O le vili matasele o se faaiteite i le CPU o loo tatou faatalitali, ae atonu e le mo se taimi umi
/////
///     hint::spin_loop();
/// }
///
/// // o lenei ua le taua faatulaga
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // SAFETY: o le `cfg` atr faʻamautinoaina matou te faʻatinoina lenei mea i x86 sini.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // SAFETY: o le `cfg` atr faʻamautinoaina matou te faʻatinoina lenei mea i x86_64 sini.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // SAOGALEMU: o le `cfg` attr mautinoa ai tatou te faaoo lenei i sini aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // SAFETY: o le `cfg` atr faʻamautinoaina e naʻo le faʻatinoina o lenei i luga o lima sini
            // ma le lagolago mo le v6 vaega.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Se galuega tauave e iloagofie e *__ hints __* i le tuufaatasia e avea maximally pessimistic e uiga i mea e mafai ona faia `black_box`.
///
/// E le pei o [`std::convert::identity`], e uunaia a tuufaatasia Rust e manatu e mafai ona faaaoga `black_box` `dummy` i so o se auala aoga e mafai ai e faapea ua faatagaina code Rust e aunoa ma le faailoa amioga undefined i le code valaauga.
///
/// Lenei meatotino faia `black_box` aoga mo le tusiaina tulafono lea e le manaʻomia mautinoa optimization, pei o faʻailoga.
///
/// Manatua Peitai, e na o le `black_box` (ma e mafai ona na o ia) ua aiaia ai i se tulaga "best-effort".O le lautele e mafai ai ona poloka faʻamaoniga mafai ona fetuʻunaʻi faʻalagolago lava i le tulaga ma le code-gen backend o loʻo faʻaaogaina.
/// e le mafai ona faalagolago polokalame i `black_box` mo *saʻo* i soo se auala.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // E manaʻomia e "use" le finauga ile auala e le mafai ai ona vaʻai le LLVM, ma luga o faʻamoemoega e lagolagoina e mafai ona matou faʻaogaina le faʻapotopotoga e faia lenei mea.
    // Ole faʻamatalaina e le LLVM ole faʻapotopotoga tuʻufaʻatasia ose, lelei, ole pusa uliuli.
    // e le o le faatinoga silisili lea, talu ai atonu o deoptimizes sili atu nai lo lo tatou mananao i ai, ae e le o mamao lava lelei.
    //
    //

    #[cfg(not(miri))] // ua na o se faaiteite lenei, o lea e lelei e faamisi i Miri.
    // SAOGALEMU: faapotopotoga ua leai se-op le inline.
    unsafe {
        // FIXME: E le mafai ona faaaogaina `asm!` ona e le lagolagoina MIPS ma isi architectures.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}