//! O le `Clone` trait mo ituaiga e le mafai ona 'kopi faʻapitoa'.
//!
//! I le Rust, o ni ituaiga faigofie o le "implicitly copyable" ma a e tofiaina i latou pe pasi ane e avea ma finauga, o le a talia e le tagata e faʻatauaina se kopi, ae tuʻu le uluaʻi taua i le tulaga.
//! O nei ituaiga te le manaomia faasoasoa atu kopi ma te le finalizers (ie, latou te le o loo umia pusa pe faatino [`Drop`]), ina ia tuufaatasia manatu taugofie i latou ma le saogalemu i le kopiina.
//!
//! Mo isi ituaiga kopi tatau ona faia manino, e ala i le tauaofiaga faʻaogaina le [`Clone`] trait ma valaʻau le [`clone`] metotia.
//!
//! [`clone`]: Clone::clone
//!
//! Faʻaaoga faʻavae faataitaiga:
//!
//! ```
//! let s = String::new(); // meafaigaluega ituaiga manoa Clone
//! let copy = s.clone(); // ina ia mafai ona tatou clone ai
//! ```
//!
//! Ina ia faatinoina le faigofie le trait Clone, e mafai foi ona e faaaogaina `#[derive(Clone)]`.faataitaiga:
//!
//! ```
//! #[derive(Clone)] // tatou faaopoopo atu le trait Clone e fausia Morpheus
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // ma o lea ua mafai ona tatou faʻailoaina!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// O le masani trait mo le agavaʻa faʻamalamalama faʻapitoa se mea.
///
/// E ese mai [`Copy`] i lena [`Copy`] o atoatoa ma matua taugofie, ao `Clone` o taimi uma manino ma e mafai pe le mafai foi ona taugata.
/// Ina ia faamalosia ai nei uiga, e le faatagaina Rust oe e reimplement [`Copy`], ae e mafai ona e reimplement `Clone` ma taufetuli code soʻona faia.
///
/// Talu ai e sili aoao `Clone` nai lo [`Copy`], e mafai ona otometi lava ona faia so o se mea [`Copy`] ona `Clone` foi.
///
/// ## Derivable
///
/// Lenei trait mafai ona faʻaaogaina ma `#[derive]` pe afai o uma fanua e `Clone`.O le `derive`d faʻatinoina o [`Clone`] valaʻau [`clone`] i fanua taʻitasi.
///
/// [`clone`]: Clone::clone
///
/// Mo se fausia lautele, faatino `#[derive]` aiaiga `Clone` i le faaopoopoina noatia `Clone` i le faataamilosaga lautele.
///
/// ```
/// // `derive` meafaigaluega Clone mo Faitauga<T>pe a T o le Klone.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Faʻafefea mafai ona ou faʻaaogaina `Clone`?
///
/// Ituaiga e tatau ona i ai [`Copy`] se faatinoga faatauvaa o `Clone`.Sili atu aloaia:
/// pe afai `T: Copy`, `x: T`, ma `y: &T`, ona `let x = y.clone();` e tutusa `let x = *y;`.
/// E tatau ona faaeteete implementations tusi lesona e lagolagoina lenei invariant;Ae peitai, code saogalemu e le tatau ona faalagolago i ai ina ia mautinoa le saogalemu manatua.
///
/// O se faʻataʻitaʻiga o se tulaga lautele o loʻo taofia ai se faʻasino galuega.I lenei tulaga, o le faatinoga o `Clone` le mafai ona 'derive`d, ae e mafai ona faatinoina e pei:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Faʻaopopo faʻaopoopo
///
/// I se faʻaopopoga i le [implementors listed below][impls], o ituaiga nei e faʻaogaina foʻi le `Clone`:
///
/// * Galuega aitema ituaiga (ie, o le eseʻese ituaiga faʻamatalaina mo galuega tauave taʻitasi)
/// * ituaiga e faasino ai galuega tauave (eg, `fn() -> i32`)
/// * Autau ituaiga, mo ituaiga uma, afai faatino foi le ituaiga mea `Clone` (eg, `[i32; 123456]`)
/// * ituaiga Tuple, pe afai e faatino foi vaega taitasi `Clone` (eg, `()`, `(i32, bool)`)
/// * Tapuni ituaiga, pe a latou le puʻeina se tau mai le siʻosiʻomaga pe afai o ia taua taua puʻeina uma faʻaaogaina `Clone` latou lava.
///   Manatua o fesuiaʻiga puʻeina e le faʻasoa faʻasino taimi uma faʻatino `Clone` (tusa lava pe le o le faʻasino vaʻaia e leai), ae o fesuiaʻiga puʻeina e le suia suia e le faʻatinoina `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Faʻafoʻi mai se kopi o le tau.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str meafaigaluega Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Faia kopi-atofaina mai `source`.
    ///
    /// `a.clone_from(&b)` e tutusa `a = b.clone()` i functionality, ae e mafai ona solipala e toe faʻaaogā le punaoa o `a` e aloese ai mai le faasoasoaina o le manaomia.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Faʻatupuina makro faʻatupuina se impl o le trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): o loo faaaogaina nei structs faapitoa e#[maua] e folafola e vaega uma o a ituaiga meafaigaluega Clone po o Kopi.
//
//
// Nei faʻasologa e le tatau ona aliali mai i tagata faʻaoga.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Faʻatinoga o `Clone` mo ituaiga anamua.
///
/// Implementations e le mafai ona faamatalaina i le Rust ua faatinoina i `traits::SelectionContext::copy_clone_conditions()` i `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// e mafai ona cloned mau faasoa, ae mau mutable *e le mafai ona*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// e mafai ona cloned mau faasoa, ae mau mutable *e le mafai ona*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}