//! Faamatalaina umia iterator le `IntoIter` mo arrays.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// A e ala i le-taua [array] iterator.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Lenei o le laina o loʻo tatou faʻasolosolo i luga.
    ///
    /// Elemene ma faʻasino `i` e leʻi maua ai le `alive.start <= i < alive.end` ae o loʻo aoga pea faʻamaumauga.
    /// O elemene o loʻo iai faʻailoga `i < alive.start` poʻo `i >= alive.end` ua uma ona faʻatagaina ma ua le tatau ona toe faʻaaogaina nei!O na elemene e ua maliliu e mafai ona i ai e oo lava i se tulaga atoatoa uninitialized!
    ///
    ///
    /// Ma o le au faʻaletonu o:
    /// - `data[alive]` o loʻo ola (faʻapea e aofia ai elemeni aoga)
    /// - `data[..alive.start]` ma `data[alive.end..]` ua oti (o lona uiga o le na ua uma ona faitau elemene ma e le tatau ona paʻi toe!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// O elemeni i le `data` e leʻi faʻatagaina.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Fausia se mea fou i luga ole `array` foaʻi.
    ///
    /// *Faʻaliga*: o lenei metotia ono faʻaumatia i le future, pe a maeʻa [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // O le ituaiga `value` o le `i32` iinei, ae le o le `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // SAFETI: O le transmute iinei e moni saogalemu.O le docs o `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` ua mautinoa e maua le tutusa tele ma gatasi
        // > pei `T`.
        //
        // O loʻo faʻaalia foi e le docs se transmute mai se laina o le `MaybeUninit<T>` i se ituaiga o `T`.
        //
        //
        // Faatasi ai ma lena, o lenei initialization faamalieina le invariants.

        // FIXME(LukasKalbertodt): faʻaaoga moni le `mem::transmute` ii, e tasi le taimi e galue ai ma faʻatulagaina lautele:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Seia oo i lena, e mafai ona tatou faaaogaina `mem::transmute_copy` e fatu ai se bitwise kopi o se ituaiga eseese, ona galo ina ia `array` e le paʻu.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Faʻafoʻi mai se fasi fesuiaʻi o elemene uma e le i mauaina.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // SAFETI: Matou te iloa o elemene uma i totonu o le `alive` ua amataina faʻalelei.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Faʻafoʻi mai se fasi fesuiaiga o elemene uma e le i mauaina.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // SAFETI: Matou te iloa o elemene uma i totonu o le `alive` ua amataina faʻalelei.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Maua le isi lisi mai luma.
        //
        // O le faʻateleina o le `alive.start` e le 1 o loʻo tumau ai pea le tagata aʻafia e uiga i le `alive`.
        // Peitai, talu ai lenei suiga, mo sina taimi puʻupuʻu, o le ola sone e le o `data[alive]` toe, ae `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Faitau le elemene mai le laina.
            // SAFETY: `idx` o se faʻasino igoa i le muamua "alive" itulagi o le
            // setiFaitauina o lenei elemene o lona uiga o `data[idx]` ua manatu i ai e ua oti i le taimi nei (ie te le paʻi).
            // Talu ai o le `idx` o le amataga o le ola-sone, o le ola sone ua avea nei `data[alive]`, toe faʻafoʻi uma invariants.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Ia maua le faasino upu e sosoo ai mai le pito i tua.
        //
        // O le faʻaititia o le `alive.end` e le 1 o loʻo taofia ai pea le tagata aʻafia e uiga i le `alive`.
        // Peitai, talu ai lenei suiga, mo sina taimi puʻupuʻu, o le ola sone e le o `data[alive]` toe, ae `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Faitau le elemene mai le laina.
            // SAFETY: `idx` o se faʻasino igoa i le muamua "alive" itulagi o le
            // setiFaitauina o lenei elemene o lona uiga o `data[idx]` ua manatu i ai e ua oti i le taimi nei (ie te le paʻi).
            // A o `idx` o le faaiuga o le ola-faalesone, le ola sone o nei toe `data[alive]`, ma le toefuataiina uma invariants.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // SAOGALEMU: e saogalemu lenei: toe afio mai le tonu `as_mut_slice` laiti fasi
        // o elemene e leʻi aveʻesea ma o loʻo totoe e tiaʻi.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // O le a le paʻu i lalo ona o le invariant `ola.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// lipoti moni lava le iterator le umi saʻo.
// O le numera o "alive" elemeni (o le a faʻatagaina lava) o le umi o le laina `alive`.
// Lenei laina ua decremented i le umi i le `next` poʻo le `next_back`.
// E masani ona faʻaititia e le 1 i na metotia, ae naʻo `Some(_)` e toe faʻafoʻi mai.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Manatua, tatou te le manaomia ina ia fetaui ma le tasi vaega ola tonu, o lea tatou te mafaia na o clone i aveesea 0 e tusa lava po o fea o `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Faʻamaonia elemene ola uma.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Tusi se clone i le autau fou, faafouina lea lona tele ola.
            // Afai cloning panics, o le a tatou sao pau le mea ua mavae.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Na lolomiina o le elemene e lei gauai atu lava: le mafai ona tatou maua toe elemene gauai.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}