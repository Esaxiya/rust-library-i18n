//! pusa mutable Shareable.
//!
//! saogalemu manatua Rust ua faavae i luga o le tulafono lenei: Ona o se mea `T`, ua na mafai ona maua se tasi o nei:
//!
//! - O loʻo iai ni mau e le fesuiaʻi (`&T`) ile mea faitino (e taʻua foi ole **aliasing**).
//! - Mauaina o se tasi faʻavasegaga faʻasino (`&mut T`) i le mea faitino (lea e taʻua o le **mutability**).
//!
//! ua faamalosia e ala i le tuufaatasia Rust lenei.Ae peitai, o loo i ai tulaga e le lava fetuutuunai lenei tulafono.O nisi taimi e manaʻomia le tele o mau i se mea faitino ae suia.
//!
//! Faʻasoaina mutable koneteina i ai e faʻatagaina mutability i se faʻatonutonu auala, e oʻo lava i le i ai o aliasing.Uma [`Cell<T>`] ma [`RefCell<T>`] faataga le faia o lenei mea i se tasi-threaded ala.
//! Peitaʻi, e leʻo saogalemu le `Cell<T>` poʻo le `RefCell<T>` (latou te le faʻaaogaina [`Sync`]).
//! Afai e te manaomia e fai aliasing ma mutation i le va o le tele o filo e mafai e faaaoga [`Mutex<T>`], [`RwLock<T>`] po o ituaiga [`atomic`].
//!
//! Taua o le `Cell<T>` ma `RefCell<T>` ituaiga ono suia e ala i faʻasoa faʻasino (ie
//! le masani `&T` ituaiga), ae o le tele o Rust ituaiga faʻatoa mafai ona suia e ala i tulaga ese (`&mut T`) faʻasino.
//! Tatou te faapea tuuina `Cell<T>` ma `RefCell<T>` 'mutability totonu', i le eseesega ma masani ituaiga Rust o faaaliga 'tuufaasolo mutability'.
//!
//! ituaiga feaveai oo mai i flavors lua: `Cell<T>` ma `RefCell<T>`.meafaigaluega `Cell<T>` mutability totonu e ala i le siitia o tulaga faatauaina i totonu ma fafo o le `Cell<T>`.
//! Ina ia faʻaaoga faʻamatalaga ae le o tulaga taua, e tatau i se tasi ona faʻaaoga le `RefCell<T>` ituaiga, mauaina o se tusitusi loka ae le i suia.`Cell<T>` maua ai metotia e aumai ai ma suia le taimi nei totonu aoga:
//!
//!  - Mo ituaiga e faʻaaogaina [`Copy`], o le [`get`](Cell::get) metotia toe maua mai le taimi nei totonu taua.
//!  - Mo ituaiga e faʻaogaina le [`Default`], o le [`take`](Cell::take) auala e suia ai le tau o loʻo i ai nei i le [`Default::default()`] ma faʻafoʻi mai le sui ua sui.
//!  - Mo ituaiga uma, e suia ai le auala [`replace`](Cell::replace) le taua totonu i le taimi nei ma toe foi mai le suia taua ma le auala [`into_inner`](Cell::into_inner) alu uma le `Cell<T>` ma toe foi mai le taua totonu.
//!  E le gata i lea, o le [`set`](Cell::set) auala e suia ai le tau i totonu, faʻapaʻu le mea ua suia.
//!
//! `RefCell<T>` faʻaaoga taimi o le Rust e faʻatino ai le 'aitalafu malosi', o se gaioiga e mafai ai e se tasi ona tapaina le le tumau, faʻapitoa, faʻaaogaina o auala i totonu.
//! Nonoina tupe mo le 'RefCell<T>'S ua tracked' i runtime ', e le pei ituaiga faasinomaga moni o Rust ua atoa tracked statically, i le taimi e tuufaatasia.
//! Talu ai o `RefCell<T>` nonogatupe e malosi tele e mafai ai ona taumafai e nono se tau aoga ua uma ona suia aitalafu;a tupu lenei mea e mafua ai le filo panic.
//!
//! # O afea e filifili ai i totonu o suiga
//!
//! O le tele o suiga masani masani, pe a fai o se tasi e tatau ona i ai se avanoa tulaga ese e suia ai se tau, o se tasi o elemene autu gagana e mafai ai e Rust ona fefulisaʻi malosi e uiga i le faʻasino igoa, ma puipuia lelei ai faʻalavelave.
//! Ona o lena, sili suia mutability, ma mut mutation i totonu o se mea o se mulimuli avanoa.
//! Talu ai sela ituaiga mafai mutation i le mea o le a faʻaleaogaina i se isi itu, e i ai taimi e ono talafeagai ai le suia i totonu, poʻo le *tatau* faʻaaogaina, eg
//!
//! * Faʻalauiloa mutability 'inside' o se mea le suia
//! * auiliiliga faatinoina o auala le manatu-masuia.
//! * Mutating implementations o [`Clone`].
//!
//! ## Faʻalauiloa mutability 'inside' o se mea le suia
//!
//! E toatele faasoa ituaiga e faasino ai le poto, e aofia ai [`Rc<T>`] ma [`Arc<T>`], tuuina pusa e mafai ona cloned ma faasoa i le va o vaega auai e tele.
//! Ona e mafai ona faateleina-aliased tulaga faatauaina o loo i ai, e mafai ona na ona nono ma `&`, e le `&mut`.
//! A aunoa ma sela e le mafai ona suia faʻamatalaga i totonu o nei atamai atamai uma.
//!
//! O se mea masani le tuʻuina o le `RefCell<T>` i totonu faʻasoa faʻasino ituaiga e toe faʻafoʻi mai ai suiga:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Fai se poloka fou e faaitiitia ai le tulaga lautele o le faanoi maoae
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Manatua afai matou te leʻi faʻatagaina le taimi muamua nonoa o le cache paʻu ese mai le avanoa ona o le mulimuli ane nono o le a mafua ai le malosi filo panic.
//!     //
//!     // o le lamatiaga tele lenei o le faaaogaina o `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Manatua o lenei faʻataʻitaʻiga faʻaaoga `Rc<T>` ae le `Arc<T>`.'RefCell<T>`s e mo ata e tasi le filo.Mafaufau e faaaoga [`RwLock<T>`] po [`Mutex<T>`] pe afai e le tatau faasoa mutability i se tulaga eseese threaded.
//!
//! ## Faʻatinoina faʻamatalaga auiliili-le suia metotia
//!
//! Mai lea taimi i lea taimi atonu e manaʻomia le aua le faʻaalia i se API o loʻo i ai ni suiga e tupu "under the hood".
//! Atonu e mafua ona o le fetaui lelei o le gaioiga e le mafai ona suia, ae faʻapea, o le faʻaaogaina e faʻamalosia ai le faʻatinoina e faia suiga;pe ona e tatau ona faʻaaogaina mutation e faʻatino ai se metotia trait na muamua faʻauigaina e ave `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // O taugata faʻatau e alu ii
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Faʻaogaina o `Clone`
//!
//! Ua naʻo se faʻapitoa, ae masani ai, o le taimi ua tuanaʻi: nana le fesuiaʻi mo gaioiga e foliga mai e le mafai ona suia.
//! o loo faamoemoeina auala [`clone`](Clone::clone) le e le suia ai le taua puna, ma ua tautino mai e `&self`, e le `&mut self`.
//! O le mea lea, soʻo se suiga e tupu i le `clone` auala e tatau ona faʻaaoga ai sela ituaiga.
//! Mo se faataitaiga, tausia [`Rc<T>`] lona faasinomaga taulia i totonu o se `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// O se nofoaga manatua pea suia.
///
/// # Examples
///
/// I lenei faʻataʻitaʻiga, e mafai ona e vaʻaia o `Cell<T>` mafai ai ona suia i totonu o se tulaga e le suia.
/// I nisi upu, e mafai ai "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // SILI: `my_struct` e le mafai ona suia
/// // my_struct.regular_field =New_value;
///
/// // GALUEGA: e ui lava `my_struct` e le masuia, `special_field` o se `Cell`,
/// // lea e mafai ona suia i taimi uma
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Vaʻai le [module-level documentation](self) mo nisi mea.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Faatupu ai se `Cell<T>`, faatasi ai ma le taua `Default` mo T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Fausia se `Cell` fou o loʻo iai le tau taua.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Seti le aofaʻi aofia.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Swaps tulaga faatauaina o sela e lua.
    /// Eseesega i `std::mem::swap` e faapea e le manaomia ai o lenei galuega tauave faasinomaga `&mut`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // SAFETI: O lenei e mafai ona lamatia pe a valaʻauina mai vavae ese filo, ae `Cell`
        // o `!Sync` ina o le a le tupu lenei mea.
        // Lenei foi o le a le faʻaleaogaina ni faʻasino talu `Cell` mautinoa e leai seisi mea o le a faʻasino atu i se tasi o nei 'Cell`s.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Sui le aofaʻi o loʻo iai ile `val`, ma toe faʻafoʻi le tau tuai o loʻo iai.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // SAFETI: Lenei mafai mafua ai faʻamatalaga tuʻuga pe a valaʻauina mai se vavae ese,
        // ae `Cell` o `!Sync` o lea e le tupu lenei.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Unwraps le taua.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Faʻafoʻi mai se kopi o le aofaʻi o le tau.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // SAFETI: Lenei mafai mafua ai faʻamatalaga tuʻuga pe a valaʻauina mai se vavae ese,
        // ae `Cell` o `!Sync` o lea e le tupu lenei.
        unsafe { *self.value.get() }
    }

    /// Faʻafouina le aofia ai aoga faʻaaogaina o se gaioiga ma toe faafoi le fou taua.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Faʻafoʻi mai se faʻasino tonu i faʻamatalaga autu o lenei sela.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Toe foi se faasinomaga mutable i le faamatalaga faavae.
    ///
    /// O lenei valaauga borrows `Cell` mutably (i tuufaatasia-taimi) e faamaonia ai o le a tatou maua le faasinomaga na.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Faʻafoʻi mai le `&Cell<T>` mai le `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // faamautinoa `&mut` avanoa tulaga ese: SAOGALEMU.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Ave le tau o le sela, tuʻu le `Default::default()` i lona tulaga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Faʻafoʻi mai le `&[Cell<T>]` mai le `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // SAFETY: `Cell<T>` ei ai le tutusa manatuaina faʻatulagaina e pei o `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// O se nofoaga manatua mutable ma siaki dynamically tulafono faanoi
///
/// Vaʻai le [module-level documentation](self) mo nisi mea.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// toe foi se mea sese e [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// O se mea sese na toe faafoi e [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// O tulaga lelei e faʻalia ai le numera o le `Ref` ola.Le aoga taua faʻatusatusa i le numera o `RefMut` ola.
// Tele 'RefMut`s na ona toaaga i se taimi pe afai e faatatau i ai mavaevae, nonoverlapping vaega o se `RefCell` (eg, Atumauga eseese o se fasi).
//
// `Ref` ma `RefMut` e lua uma upu i le lapoʻa, ma o lea e ono le lava ai 'Ref`s poʻo' RefMut`s i ai o loʻo i ai ova ma le afa o le `usize` laina.
// O lea la, o le `BorrowFlag` o le a le taitai ona paʻu pe oʻo i lalo.
// Ae peitai, e le o se faamaoniga o lenei mea, o se e mafai ona soo polokalame pathological fatu ma mem::forget 'Ref`s po' RefMut`s.
// O le mea lea, e tatau i tulafono uma ona suʻesuʻe faʻamaonia mo le lolovaia ma lalo ina ia mafai ai ona aloese mai le le saogalemu, poʻo le mea sili amio lelei i le mea na tupu o le lolovaia pe lalo ifo tupu (eg, vaʻai BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Fausia se `RefCell` fou o loʻo iai `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Faʻauma le `RefCell`, faʻafoʻi le afifi afifi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Talu ai e lenei galuega tauave `self` (le `RefCell`) e ala i taua, o le tuufaatasia statically faamaonia ai e le o le taimi nei nono.
        //
        self.value.into_inner()
    }

    /// Suia o le tau aogā afifi i se tasi fou, toe foi i le taua matua, e aunoa ma deinitializing se tasi.
    ///
    ///
    /// O lenei galuega tauave tutusa ma [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics pe a fai o loʻo nono mai le tau.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Sui le afifi taua i se tasi fou fuafuaina mai `f`, toe faʻafoʻi le tuai aoga, aunoa ma deinitializing se tasi.
    ///
    ///
    /// # Panics
    ///
    /// Panics pe a fai o loʻo nono mai le tau.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Swaps le afifi taua o `self` ma le afifi taua o `other`, e aunoa deinitializing se tasi.
    ///
    ///
    /// O lenei gaioiga e tutusa ma [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics pe afai e nono i le taimi nei le taua i se tasi `RefCell`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Immutably borrows le taua afifi.
    ///
    /// O le faanoi tumau seia oo exits tulaga le `Ref` toe foi mai.
    /// Ole tele o nonogatupe e le mafai ona aveina e mafai ona ave i fafo i le taimi e tasi.
    ///
    /// # Panics
    ///
    /// Panics pe afai o le taimi nei mutably nonoina le taua.
    /// Mo se fesuiaʻiga e le o le faʻafaigata, faʻaaoga le [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// O se faʻataʻitaʻiga o panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Faʻaletonu le nonoina o le afifi afifi, faʻafoʻi mai se mea sese pe a fai o le tau aitalafu e ono nonoina
    ///
    ///
    /// O le faanoi tumau seia oo exits tulaga le `Ref` toe foi mai.
    /// Ole tele o nonogatupe e le mafai ona aveina e mafai ona ave i fafo i le taimi e tasi.
    ///
    /// O le eseʻesega-XNXX X XXX.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // SAOGALEMU: faamautinoa `BorrowRef` faapea e na o le avanoa e lē masuia
            // i le tau aoga a o nonoina
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Mutable nonoina le afifi afifi.
    ///
    /// O le faanoi tumau seia oo i le toe foi `RefMut` po o mea uma 'RefMut`s maua mai ai tulaga ese.
    ///
    /// e le mafai ona nonoina le taua ao lenei faanoi e toaga.
    ///
    /// # Panics
    ///
    /// Panics pe a fai o loʻo nono mai le tau.
    /// Mo se fesuiaʻiga e le o le faʻafaigata, faʻaaoga le [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// O se faʻataʻitaʻiga o panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Fetuutuunai nonoina le afifi afifi, toe faafoi se mea sese pe a fai o le tau o loʻo nonoina.
    ///
    ///
    /// O le faanoi tumau seia oo i le toe foi `RefMut` po o mea uma 'RefMut`s maua mai ai tulaga ese.
    /// e le mafai ona nonoina le taua ao lenei faanoi e toaga.
    ///
    /// O le eseʻesega-XNXX X XXX.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // SAFETY: `BorrowRef` mautinoa se avanoa tulaga ese.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Faʻafoʻi mai se faʻasino tonu i faʻamatalaga autu o lenei sela.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Toe foi se faasinomaga mutable i le faamatalaga faavae.
    ///
    /// Lenei valaʻau nono `RefCell` suia (i le tuufaatasia-taimi) o lea e leai se manaʻoga mo maoaʻe siaki.
    ///
    /// Peitaʻi ia faʻaeteete: o lenei metotia faʻamoemoeina `self` e mafai ona suia, o le mea masani e le o le tulaga peʻa faʻaaogaina le `RefCell`.
    ///
    /// Matamata i le auala [`borrow_mut`] ae afai `self` e le mutable.
    ///
    /// Faʻapea foi, faʻamolemole ia e mataala o lenei metotia e mo na o tulaga faʻapitoa ma e masani ona le o le mea e te manaʻo ai.
    /// I le tulaga o le masalosalo, faʻaaoga le [`borrow_mut`] nai lo.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Tatala fusi o le aafiaga o le leoleo leaked i luga o le faanoi o tulaga o le `RefCell`.
    ///
    /// O lenei valaʻau e tai tutusa ma le [`get_mut`] ae e sili atu ona faʻapitoa.
    /// E nonoina `RefCell` faʻalelei ina ia mautinoa e leai ni aitalafu o loʻo iai ma toe setiina le setete suʻesuʻe faʻasoa tupe nono.
    /// E talafeagai lea pe a fai ua faʻasalalau atu ni nonogatupe `Ref` poʻo `RefMut`.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Faʻaletonu le nonoina o le afifi afifi, faʻafoʻi mai se mea sese pe a fai o le tau aitalafu e ono nonoina
    ///
    /// # Safety
    ///
    /// E le pei o `RefCell::borrow`, o le saogalemu o lenei auala ona e le toe foi se `Ref`, ua faapea ona tuua le fuʻa faanoi untouched.
    /// E ono suia le nonoina o le `RefCell` ae o le faʻamatalaga na faʻafoʻi mai e lenei metotia e ola e le o faʻamatalaina amio.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // SAFETI: Matou te siaki e leai seisi o toʻaga e tusitusi nei, ae o lea
            // o le valaʻau le tiute o le faʻamautinoa e leai seisi tusitusi seʻi vagana ua toe faʻafoʻi le toe faʻaogaina.
            // E le gata i lea, o le `self.value.get()` e faʻasino i le tau e anaina e `self` ma e mautinoa ai le aoga mo le olaga atoa o le `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Ave le afifi afifi, ma tuua `Default::default()` i lona tulaga.
    ///
    /// # Panics
    ///
    /// Panics pe a fai o loʻo nono mai le tau.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics pe afai o le taimi nei mutably nonoina le taua.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Fausia le `RefCell<T>`, ma le `Default` aoga mo T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics pe afai e nono i le taimi nei le taua i se tasi `RefCell`.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics pe afai e nono i le taimi nei le taua i se tasi `RefCell`.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics pe afai e nono i le taimi nei le taua i se tasi `RefCell`.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics pe afai e nono i le taimi nei le taua i se tasi `RefCell`.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics pe afai e nono i le taimi nei le taua i se tasi `RefCell`.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics pe afai e nono i le taimi nei le taua i se tasi `RefCell`.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics pe afai e nono i le taimi nei le taua i se tasi `RefCell`.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // O le faʻaopopo tupe e ono aʻafia ai se tau le faitauina (<=0) i mea ia:
            // 1. O le <0, ie o loʻo iai tusi tusitusi, o lea e le mafai ai ona matou faʻatagaina se faitau nonogatupe ona o le tulafono a le Rust.
            // 2.
            // O isize::MAX (o Max aofaiga o le faitauina o borrows) ma e matuai tumu i isize::MIN (o Max aofaiga o tusi borrows) ina le mafai ona tatou faatagaina se faanoi faitau faaopoopo ona isize le mafai ona avea ma sui o le tele o borrows faitau (o lenei na ona tupu pe afai e oe mem::forget sili atu nai lo se tamai aofaʻiga faifai pea o 'Ref`s, e le o se lelei faʻataʻitaʻiga)
            //
            //
            //
            //
            None
        } else {
            // Incrementing faanoi e mafai ona oo i se faitauga taua (> 0) i totonu o nei tulaga:
            // 1. O le=0, o lona uiga e leʻi nonoina, ma o loʻo tatou faia le muamua faitau nonogatupe
            // 2. Na> 0 ma <isize::MAX, ie
            // sa i ai faitau faanoi, ma isize e lava tele e fai ma sui o le tasi toe faitau aitalafu
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Talu mai lenei Ref loo i ai, ua tatou iloa le faanoi fuʻa o se faanoi faitauga.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Taofi le nonogatupe counter mai le soʻose i totonu o se tusi nono.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Wraps a nonoina faasinomaga i se taua i se pusa `RefCell`.
/// O se ituaiga afifi mo se tau le mafaʻafefe nonoina mai le `RefCell<T>`.
///
/// Vaʻai le [module-level documentation](self) mo nisi mea.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Kopi le `Ref`.
    ///
    /// O le `RefCell` ua leva ona nonoina, o lea e le mafai ai ona toilalo.
    ///
    /// Lenei o se fesoʻotaiga gaioiga e manaʻomia le faʻaaogaina o `Ref::clone(...)`.
    /// O le `Clone` faʻatinoga poʻo se metotia o le a faʻalavelave i le salalau o le faʻaaogaina o le `r.borrow().clone()` e faʻapipiʻi ai mea i totonu o le `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Faia se `Ref` fou mo se vaega o le nono faʻamaumauga.
    ///
    /// O le `RefCell` ua leva ona nonoina, o lea e le mafai ai ona toilalo.
    ///
    /// Lenei o se fesoʻotaʻiga gaioiga e manaʻomia le faʻaaogaina o `Ref::map(...)`.
    /// O se metotia o le a faʻalavelave i metotia o le igoa tutusa i luga o mea o le `RefCell` faʻaaogaina e ala i `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Fausia se `Ref` fou mo se filifiliga vaega o le nono faʻamatalaga.
    /// ua toe foi mai le leoleo uluai o se `Err(..)` pe afai e toe afio mai le tapunia `None`.
    ///
    /// O le `RefCell` ua leva ona nonoina, o lea e le mafai ai ona toilalo.
    ///
    /// Lenei o se fesoʻotaʻiga gaioiga e manaʻomia le faʻaaogaina o `Ref::filter_map(...)`.
    /// O se metotia o le a faʻalavelave i metotia o le igoa tutusa i luga o mea o le `RefCell` faʻaaogaina e ala i `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Vavaeina le `Ref` i le tele `Ref`s mo eseese vaega o faʻamatalaga nono.
    ///
    /// O le `RefCell` ua leva ona nonoina, o lea e le mafai ai ona toilalo.
    ///
    /// o se galuega tauave e fesootai lenei e manaomia ona faaaogaina o `Ref::map_split(...)`.
    /// O se metotia o le a faʻalavelave i metotia o le igoa tutusa i luga o mea o le `RefCell` faʻaaogaina e ala i `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Tagata liliu mai i se faasinomaga i le faamatalaga faavae.
    ///
    /// O le faʻavae `RefCell` e le mafai ona toe faʻafetauina ona toe faʻaalia ma o taimi uma e aliali mai ai ua le toe suia.
    ///
    /// E le o se lelei manatu le faʻasili sili atu nai lo le tumau numera o faʻasino.
    /// O le `RefCell` e mafai ona toe nonoina toeititi lava pe a naʻo se laʻititi numera o faʻasologa na tupu i le aofaʻi.
    ///
    /// Lenei o se fesoʻotaiga gaioiga e manaʻomia le faʻaaogaina o `Ref::leak(...)`.
    /// O se metotia o le a faʻalavelave i metotia o le igoa tutusa i luga o mea o le `RefCell` faʻaaogaina e ala i `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // I le faʻagaloina o lenei Ref matou te mautinoa ai e le mafai e le loan counter i le RefCell ona toe foʻi i le UNUSED i totonu ole olaga `'b`.
        // Resetting le faasinomaga o le a manaomia tulaga e Siaki ai se faasinomaga tulaga ese i le RefCell nono.
        // Leai ni isi faʻavasega suiga e mafai ona faia mai le uluaʻi sela.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Fausia se `RefMut` fou mo se vaega o faʻamatalaga nonoina, faʻapea, o le enum variant.
    ///
    /// O le `RefCell` ua uma ona nonoina vave, o lea e le mafai ai ona toilalo.
    ///
    /// o se galuega tauave e fesootai lenei e manaomia ona faaaogaina o `RefMut::map(...)`.
    /// O se metotia o le a faʻalavelave i metotia o le igoa tutusa i luga o mea o le `RefCell` faʻaaogaina e ala i `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): lipea siaki-siaki
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Fausia se `RefMut` fou mo se filifiliga vaega o le nono faʻamatalaga.
    /// ua toe foi mai le leoleo uluai o se `Err(..)` pe afai e toe afio mai le tapunia `None`.
    ///
    /// O le `RefCell` ua uma ona nonoina vave, o lea e le mafai ai ona toilalo.
    ///
    /// Lenei o se fesoʻotaiga gaioiga e manaʻomia le faʻaaogaina o `RefMut::filter_map(...)`.
    /// O se metotia o le a faʻalavelave i metotia o le igoa tutusa i luga o mea o le `RefCell` faʻaaogaina e ala i `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): lipea siaki-siaki
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // SAFETY: gaioiga taofi i luga o se faʻapitoa faʻasino mo le umi
        // o lona valaʻau e ala i le `orig`, ma o le faʻasino tusi ua naʻo le faʻasino i totonu o le galuega faʻatonu e le faʻatagaina ai le faʻasino faapitoa e sola ese.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // SAFETY: tutusa ma luga.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Vavaeina le `RefMut` i le tele o 'RefMut`s mo eseese vaega o le nono faʻamaumauga.
    ///
    /// O le `RefCell` o loʻo tumau pea o le a faʻaauau aitalafu seʻia oʻo ina toe foʻi uma mai le 'RefMut`s.
    ///
    /// O le `RefCell` ua uma ona nonoina vave, o lea e le mafai ai ona toilalo.
    ///
    /// Lenei o se fesoʻotaiga gaioiga e manaʻomia le faʻaaogaina o `RefMut::map_split(...)`.
    /// O se metotia o le a faʻalavelave i metotia o le igoa tutusa i luga o mea o le `RefCell` faʻaaogaina e ala i `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Liua i se suia suia i le autu faʻamatalaga.
    ///
    /// O le faavae `RefCell` mafai ona nonoina mai le toe ma o le a foliga mai ua uma ona mutably nonoina i taimi uma, le faia o le toe foi faasinomaga le na o le totonu.
    ///
    ///
    /// o se galuega tauave e fesootai lenei e manaomia ona faaaogaina o `RefMut::leak(...)`.
    /// O se metotia o le a faʻalavelave i metotia o le igoa tutusa i luga o mea o le `RefCell` faʻaaogaina e ala i `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // I le faʻagaloina o lenei BorrowRefMut matou mautinoa ai o le aitalafu aitalafu i le RefCell le mafai ona toe foi i le UNUSED i totonu o le olaga atoa `'b`.
        // Resetting le faasinomaga o le a manaomia tulaga e Siaki ai se faasinomaga tulaga ese i le RefCell nono.
        // Leai nisi faʻasino mafai ona faia mai le uluaʻi sela i totonu o lena olaga, faia o le taimi nei nonoina na o le pau faʻasino mo le olaga o totoe.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: E le pei o BorrowRefMut::clone, fou ua valaʻauina e fausia le amataga
        // faasinomaga mutable, ma o lea e tatau ona i le taimi nei e leai se mau o lo oi ai.
        // O lea la, ao increments clone le mutable refcount, iinei tatou manino na faatagaina le alu mai le faaaogaina e faaaogaina, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Clones a `BorrowRefMut`.
    //
    // E faʻatoa aoga lea pe a fai o `BorrowRefMut` taʻitasi e faʻaaoga e suʻe ai se fesuiaʻiga o faʻamatalaga i se eseʻesega, leai se felafolafoaʻiga o le uluaʻi mea.
    //
    // e le i se Clone impl ina ia code e le valaau lenei implicitly lenei.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Taofi le nonogatupe mai lalo.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// A afifi ituaiga mo se mutably nonoina taua mai se `RefCell<T>`.
///
/// Vaʻai le [module-level documentation](self) mo nisi mea.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// O le faʻavae taua mo le fesuiaʻiga o totonu i le Rust.
///
/// Afai e i ai sau faʻamatalaga `&T`, ona masani ai lea i le Rust o le tuʻufaʻatasiga faia faʻamaoniga faʻavaeina i luga o le malamalamaaga o `&T` faʻasino i le suia o faʻamatalaga.O le suia o na faʻamatalaga, mo se faʻataʻitaʻiga e ala i se igoa faʻaigoa poʻo le tuʻuina atu o le `&T` i totonu o le `&mut T`, ua manatu o se amioga le faʻamatalaina.
/// `UnsafeCell<T>` opts-i fafo o le faamaoniga lē masuia mo `&T`: a faasoa atu e mafai ona faasino faasinomaga `&UnsafeCell<T>` i faamatalaga e faapea ua mutated.E taʻua lea ole "interior mutability".
///
/// O isi ituaiga e mafai mutability i totonu, e pei o `Cell<T>` ma `RefCell<T>`, mai totonu faaaogaina `UnsafeCell` e afifi latou faamatalaga.
///
/// Faaaliga e na o le faamaoniga lē masuia mo mau faasoa ua aafia i `UnsafeCell`.O le faamaoniga tulagaese mo mau mutable o aafia.E leai se *auala* faʻatulafono e maua ai aliasing `&mut`, e oʻo lava i le `UnsafeCell<T>`.
///
/// O le `UnsafeCell` API lava ia e faigofie tele: [`.get()`] e avatua ia te oe se faʻasino tusi `*mut T` i ona mea.E oʻo atu i le _you_ o le tisainiina tisaini e faʻaaoga saʻo lena faʻasino tusi.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// O le tulafono aliasing Rust tonu e teisi i le flux, ae o le manatu autu o le finauvale:
///
/// - Afai e te faia se faasinomaga le saogalemu i le olaga atoa `'a` (pe a `&T` po o mau faasino `&mut T`) lea e maua e ala i le code saogalemu (mo se faataitaiga, ona e toe foi i ai), ao lea ona e le maua le faamatalaga i so o se auala e feteenai ma lena mau mo le vaega o totoe ole `'a`.
/// Mo se faʻataʻitaʻiga, o lona uiga afai e te ave le `*mut T` mai le `UnsafeCell<T>` ma lafo i le `&T`, ona tatau lea ona tumau le faʻamaumauga i le `T` (modulo soʻo se `UnsafeCell` faʻamaumauga maua i totonu o `T`, ioe) seʻia maeʻa maeʻa le vaitaimi o le faʻasino.
/// E faapena foi, pe afai e te faia se faasinomaga ua faamaloloina `&mut T` e code saogalemu, ao lea ona e le maua le faamatalaga i totonu o le `UnsafeCell` seia oo i lena faasinomaga faamutaina.
///
/// - I taimi uma, e tatau ona e aloese mai tuʻuga faʻamatalaga.Afai filo e tele ai le avanoa i le tasi `UnsafeCell`, ona o so o se tusi e tatau ona i ai se lelei e tupu-i luma o faasino i isi uma accesses (po o le faaaogaina atomics).
///
/// Ina ia fesoasoani i le lelei fuafuaina, o nei tulaga o loʻo manino manino faʻatulafonoina mo tasi-filo code:
///
/// 1. A `&T` faasinomaga e mafai ona faamaloloina i code saogalemu ma e mafai ona galulue faatasi le i ai faatasi ma isi mau `&T`, ae lē i le a `&mut T`
///
/// 2. A `&mut T` faasinomaga e mafai ona faamaloloina i code saogalemu tuuina foi isi `&mut T` po `&T` faatasi o ai i ai.e tatau ona tulaga ese i taimi uma se `&mut T`.
///
/// Faaaliga e ao mutating le anotusi o se `&UnsafeCell<T>` (tusa lava pe o mau isi `&UnsafeCell<T>` igoa pepelo le sela) le afaina (saunia e faamalosia le invariants i luga o se isi ala), o amioga undefined pea le i ai o le tele o aliases `&mut UnsafeCell<T>`.
/// O le, `UnsafeCell` o se afifi ua fuafuaina ina ia maua ai se fesootaiga faapitoa ma _shared_ accesses (_i.e._, e ala i se faamatalaga `&UnsafeCell<_>`);e leai se togafiti faʻataulaitu pe a feagai ma _exclusive_ accesses (_e.g._, ala ile `&mut UnsafeCell<_>`): e le mafai ona faʻaigoa le sela poʻo le tau afifi mo le umi o le `&mut` nono.
///
/// ua faaalia lenei e le [`.get_mut()`] accessor, o se _safe_ getter e gauai a `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Lenei o se faʻataʻitaʻiga faʻaalia auala e faʻalelei leo ai mea o loʻo i totonu o le `UnsafeCell<_>` e ui o loʻo i ai le tele o faʻamatalaga aliasing le sela
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Maua tele/fefaʻasoaaʻi faʻamatalaga i le tutusa `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // SAFETY: i totonu o lenei tulaga e leai ni isi faʻasino i le 'x` mea i totonu,
///     // o lea o lo tatou lelei tulaga ese.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- faanoi-+
///     *p1_exclusive += 27; // |
/// } // <---------- mafai ona e alu i tua atu o lenei manatu -------------------+
///
/// unsafe {
///     // SAFETY: i totonu o lenei tulaga e leai se tasi e manatu e na o le ulufale atu i le 'x` mea i totonu,
///     // ina ia mafai ona tatou maua tele faʻasoa avanoa faʻatasi faʻatasi.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// O le faataitaiga lenei showcases le mea moni e faapea faapitoa avanoa i se `UnsafeCell<T>` faatatau i avanoa faapitoa i lona `T`:
///
/// ```rust
/// #![forbid(unsafe_code)] // ma accesses faapitoa,
///                         // `UnsafeCell` o se pupuni leai-op afifi, o lea e leai se aoga mo `unsafe` iinei.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Maua se tuʻufaʻatasiga-taimi-siaki faʻapitoa tulaga ese i `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Faatasi ai ma se faʻapitoa faʻasino, e mafai ona tatou suia mea i totonu mo le leai se totogi.
/// *p_unique.get_mut() = 0;
/// // Poʻo, tutusa:
/// x = UnsafeCell::new(0);
///
/// // A tatou maua le taua, e mafai ona tatou aumaia mea i totonu mo le leai se totogi.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Fausia se faataitaiga fou o `UnsafeCell` lea o le a afifi le taua ua faamaotiina.
    ///
    ///
    /// Uma auala i le totonu taua auala e auala o `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Unwraps le taua.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Mauaina se suia faʻavasega i le afifi afifi.
    ///
    /// Lenei mafai ona lafo i se faʻasino tusi o soʻo se ituaiga.
    /// Mautinoa o le auala e tulaga ese (leai ni faʻagaoioiga faʻamatalaga, suia pe leai) pe a lafoina i le `&mut T`, ma ia mautinoa e leai ni suiga poʻo ni suiga suia igoa o loʻo faia pe a lafoina i le `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // E mafai ona tatou na lafo i le faasino mai `UnsafeCell<T>` e `T` ona o #[repr(transparent)].
        // Lenei faʻaaogaina le tulaga faʻapitoa o le libstd, e leai se mautinoa mo le tagata faʻaoga tulafono o lenei o le a galue i le future faʻamatalaga o le tuʻufaʻatasia!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Toe foi se faasinomaga mutable i le faamatalaga faavae.
    ///
    /// Lenei valaʻau nonoina le `UnsafeCell` suia (i le tuʻufaʻatasia taimi) lea e mautinoa ai o loʻo ia tatou le faʻamatalaga e tasi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Mauaina se suia faʻavasega i le afifi afifi.
    /// O le eseesega i [`get`] o le taliaina o lenei galuega tauave a faasino ai mata, mea e aoga ina ia aloese mai le foafoaga o mau tumau.
    ///
    /// O le iʻuga e mafai ona lafo i se faʻasino tusi o soʻo se ituaiga.
    /// Ia mautinoa e tulaga ese le avanoa (leai se mau malolosi, mutable pe leai) pe lafo i `&mut T`, ma faamautinoa e leai ni mutations po aliases mutable alu i pe lafo i `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// initialization malie o se `UnsafeCell` manaomia `raw_get`, e pei o le valaau o le a manaomia `get` fatuina o se faasinomaga i faamatalaga uninitialized:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // E mafai ona tatou na lafo i le faasino mai `UnsafeCell<T>` e `T` ona o #[repr(transparent)].
        // Lenei faʻaaogaina le tulaga faʻapitoa o le libstd, e leai se mautinoa mo le tagata faʻaoga tulafono o lenei o le a galue i le future faʻamatalaga o le tuʻufaʻatasia!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Fausia se `UnsafeCell`, ma le `Default` taua mo T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}