//! Tuufaatasi intrinsics.
//!
//! O le faamatalaga e fetaui i ai i `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Le tutusa implementations const loo i `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const intrinsics
//!
//! Note: o so o se suiga i le constness o intrinsics tatau ona talanoaina ma le au gagana.
//! Lenei aofia ai suiga i le mautu o le constness.
//!
//! Ina ia mafai ona faʻaaogaina se mea taua i le taimi e tuʻufaʻatasi ai, e manaʻomia e se tasi ona kopi le faʻatinoga mai le <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> i le `compiler/rustc_mir/src/interpret/intrinsics.rs` ma faʻaopopo le `#[rustc_const_unstable(feature = "foo", issue = "01234")]` i le tagata i totonu.
//!
//!
//! Afai ua manatu se ¯ e ona faaaoga mai a `const fn` ma se uiga `rustc_const_stable`, e tatau ona o le uiga o le vala aut ¯ u ona `rustc_const_stable` foi.
//! O sea suiga e le tatau ona faia e aunoa ma le T-lang consultation, aua na te taoina se vaega i totonu o le gagana e le mafai ona toe faʻataʻitaʻi i le tagata faʻaaoga tulafono e aunoa ma le tuʻufaʻatasia o le lagolago.
//!
//! # Volatiles
//!
//! O le vave suia intrinsics maua ai gaioiga fuafuaina e gaioi i le I/O manatua, lea e mautinoa e le toe faʻaleleia e le faʻavasega i isi isi vevesi intrinsics.Tagai i le LLVM pepa i [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! O le atomic intrinsics maua ai faʻatinoina atomika gaioiga i masini upu, ma le tele ono mafai manatua manatuaina.Latou te usiusitai i le semantics tutusa C++ 11.Tagai i le LLVM pepa i [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! O se vave faʻafouina luga manatua manatuaina:
//!
//! * Maua, o se pa puipui mo le mauaina o se loka.Mulimuli ane e faitau ma tusi faia ina ua mavae le pa.
//! * Tatala, se pa pupuni mo le faamaloloina o se loka.Muamua e faitau ma tusi faia i luma o le pa.
//! * Faʻasolosolo faʻasolosolo, faʻasolosolo faʻasolosolo gaioiga e mautinoa e tupu i le faʻasologa.o le faiga tulaga lenei mo le galulue faatasi ma ituaiga atomika ma e tutusa o `volatile` Java.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// O nei oloa e faaaoga mo faafaigofie sootaga intra-doc
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // SAFETI: vaai `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, o nei intrinsics ave vae mata ona latou mutate manatua aliased, lea e le o aoga aua e `&` po `&mut`.
    //

    /// Faleoloa a tau pe afai o le taua i le taimi nei e tutusa ma le tau aogā `old`.
    ///
    /// O loʻo avanoa le faʻamautuina ole faʻatonuga lea ile ituaiga [`atomic`] e ala ile auala `compare_exchange` ile pasia ole [`Ordering::SeqCst`] e pei o `success` male `failure`.
    ///
    /// Faataitaiga, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Faleoloa a tau pe afai o le taua i le taimi nei e tutusa ma le tau aogā `old`.
    ///
    /// O loʻo avanoa le faʻamautuina ole faʻatonuga lea ile ituaiga [`atomic`] e ala ile auala `compare_exchange` ile pasia ole [`Ordering::Acquire`] e pei o `success` male `failure`.
    ///
    /// Faataitaiga, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Faleoloa a tau pe afai o le taua i le taimi nei e tutusa ma le tau aogā `old`.
    ///
    /// O loʻo avanoa le faʻamautuina o lenei mataupu i luga o [`atomic`] ituaiga e ala i le `compare_exchange` auala e ala i le pasia o le [`Ordering::Release`] e pei o le `success` ma le [`Ordering::Relaxed`] e avea ma `failure`.
    /// Faataitaiga, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Faleoloa a tau pe afai o le taua i le taimi nei e tutusa ma le tau aogā `old`.
    ///
    /// O loʻo avanoa le faʻamautuina ole faʻatonuga lea ile ituaiga [`atomic`] e ala ile auala `compare_exchange` ile pasia ole [`Ordering::AcqRel`] e pei o le `success` ma le [`Ordering::Acquire`] e pei o `failure`.
    /// Faataitaiga, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Faleoloa a tau pe afai o le taua i le taimi nei e tutusa ma le tau aogā `old`.
    ///
    /// O loʻo avanoa le faʻamautuina ole faʻatonuga lea ile ituaiga [`atomic`] e ala ile auala `compare_exchange` ile pasia ole [`Ordering::Relaxed`] e pei o `success` male `failure`.
    ///
    /// Faataitaiga, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Faleoloa a tau pe afai o le taua i le taimi nei e tutusa ma le tau aogā `old`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o loo maua i luga o le ituaiga [`atomic`] e ala i le auala `compare_exchange` ala i le tufaina [`Ordering::SeqCst`] o le `success` ma [`Ordering::Relaxed`] o le faataamilosaga `failure`.
    /// Faataitaiga, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Faleoloa a tau pe afai o le taua i le taimi nei e tutusa ma le tau aogā `old`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o loo maua i luga o le ituaiga [`atomic`] e ala i le auala `compare_exchange` ala i le tufaina [`Ordering::SeqCst`] o le `success` ma [`Ordering::Acquire`] o le faataamilosaga `failure`.
    /// Faataitaiga, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Faleoloa a tau pe afai o le taua i le taimi nei e tutusa ma le tau aogā `old`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o loo maua i luga o le ituaiga [`atomic`] e ala i le auala `compare_exchange` ala i le tufaina [`Ordering::Acquire`] o le `success` ma [`Ordering::Relaxed`] o le faataamilosaga `failure`.
    /// Faataitaiga, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Faleoloa a tau pe afai o le taua i le taimi nei e tutusa ma le tau aogā `old`.
    ///
    /// O loʻo avanoa le faʻamautuina ole faʻatonuga lea ile ituaiga [`atomic`] e ala ile auala `compare_exchange` ile pasia ole [`Ordering::AcqRel`] e pei o le `success` ma le [`Ordering::Relaxed`] e pei o `failure`.
    /// Faataitaiga, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Faleoloa a tau pe afai o le taua i le taimi nei e tutusa ma le tau aogā `old`.
    ///
    /// O loʻo avanoa le faʻamautuina ole faʻatonuga lea ile ituaiga [`atomic`] e ala ile auala `compare_exchange_weak` ile pasia ole [`Ordering::SeqCst`] e pei o `success` male `failure`.
    ///
    /// Faataitaiga, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Faleoloa a tau pe afai o le taua i le taimi nei e tutusa ma le tau aogā `old`.
    ///
    /// O loʻo avanoa le faʻamautuina ole faʻatonuga lea ile ituaiga [`atomic`] e ala ile auala `compare_exchange_weak` ile pasia ole [`Ordering::Acquire`] e pei o `success` male `failure`.
    ///
    /// Faataitaiga, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Faleoloa a tau pe afai o le taua i le taimi nei e tutusa ma le tau aogā `old`.
    ///
    /// O loʻo avanoa le faʻamautuina ole faʻatonuga lea ile ituaiga [`atomic`] e ala ile auala `compare_exchange_weak` ile pasia ole [`Ordering::Release`] e pei o le `success` ma le [`Ordering::Relaxed`] e pei o `failure`.
    /// Faataitaiga, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Faleoloa a tau pe afai o le taua i le taimi nei e tutusa ma le tau aogā `old`.
    ///
    /// O loʻo avanoa le faʻamautuina ole faʻatonuga lea ile ituaiga [`atomic`] e ala ile auala `compare_exchange_weak` ile pasia ole [`Ordering::AcqRel`] e pei o le `success` ma le [`Ordering::Acquire`] e pei o `failure`.
    /// Faataitaiga, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Faleoloa a tau pe afai o le taua i le taimi nei e tutusa ma le tau aogā `old`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o loo maua i luga o le ituaiga [`atomic`] e ala i le auala `compare_exchange_weak` ala i le tufaina [`Ordering::Relaxed`] pei uma o le faataamilosaga `success` ma `failure`.
    ///
    /// Faataitaiga, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Faleoloa a tau pe afai o le taua i le taimi nei e tutusa ma le tau aogā `old`.
    ///
    /// O loʻo avanoa le faʻamautuina o lenei mataupu i luga o [`atomic`] ituaiga e ala i le `compare_exchange_weak` auala e ala i le pasia o le [`Ordering::SeqCst`] e pei o le `success` ma le [`Ordering::Relaxed`] e avea ma `failure`.
    /// Faataitaiga, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Faleoloa a tau pe afai o le taua i le taimi nei e tutusa ma le tau aogā `old`.
    ///
    /// O loʻo avanoa le faʻamautuina o lenei mataupu i luga o [`atomic`] ituaiga e ala i le `compare_exchange_weak` auala e ala i le pasia o le [`Ordering::SeqCst`] e pei o le `success` ma le [`Ordering::Acquire`] e avea ma `failure`.
    /// Faataitaiga, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Faleoloa a tau pe afai o le taua i le taimi nei e tutusa ma le tau aogā `old`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o loo maua i luga o le ituaiga [`atomic`] e ala i le auala `compare_exchange_weak` ala i le tufaina [`Ordering::Acquire`] o le `success` ma [`Ordering::Relaxed`] o le faataamilosaga `failure`.
    /// Faataitaiga, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Faleoloa a tau pe afai o le taua i le taimi nei e tutusa ma le tau aogā `old`.
    ///
    /// O loʻo avanoa le faʻamautuina o lenei mataupu i luga o [`atomic`] ituaiga e ala i le `compare_exchange_weak` auala e ala i le pasia o le [`Ordering::AcqRel`] e pei o le `success` ma le [`Ordering::Relaxed`] e avea ma `failure`.
    /// Faataitaiga, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Avega le taimi nei aoga o le faʻasino tusi.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i le ituaiga [`atomic`] e ala i le auala `load` ala i le tufaina [`Ordering::SeqCst`] o le `order`.
    /// Faataitaiga, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Avega le taimi nei aoga o le faʻasino tusi.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i le ituaiga [`atomic`] e ala i le auala `load` ala i le tufaina [`Ordering::Acquire`] o le `order`.
    /// Faataitaiga, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Avega le taimi nei aoga o le faʻasino tusi.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i le ituaiga [`atomic`] e ala i le auala `load` ala i le tufaina [`Ordering::Relaxed`] o le `order`.
    /// Faataitaiga, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Teuina le tau ile faʻamanatuina o nofoaga.
    ///
    /// O le faʻamautuina faʻamatalaga o lenei intrinsic o loʻo avanoa i luga o le [`atomic`] ituaiga ala i le `store` auala e ala i le pasia o le [`Ordering::SeqCst`] o le `order`.
    /// Faataitaiga, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Teuina le tau ile faʻamanatuina o nofoaga.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i le ituaiga [`atomic`] e ala i le auala `store` ala i le tufaina [`Ordering::Release`] o le `order`.
    /// Faataitaiga, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Teuina le tau ile faʻamanatuina o nofoaga.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i le ituaiga [`atomic`] e ala i le auala `store` ala i le tufaina [`Ordering::Relaxed`] o le `order`.
    /// Faataitaiga, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Faleoloa i le taua i le nofoaga manatua faamaotiina, toe foi i le taua matua.
    ///
    /// O loʻo avanoa le faʻamautuina ole faʻatonuga lea ile ituaiga [`atomic`] e ala ile auala `swap` ile pasia ole [`Ordering::SeqCst`] ole `order`.
    /// Faataitaiga, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Faleoloa i le taua i le nofoaga manatua faamaotiina, toe foi i le taua matua.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i le ituaiga [`atomic`] e ala i le auala `swap` ala i le tufaina [`Ordering::Acquire`] o le `order`.
    /// Faataitaiga, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Faleoloa i le taua i le nofoaga manatua faamaotiina, toe foi i le taua matua.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i le ituaiga [`atomic`] e ala i le auala `swap` ala i le tufaina [`Ordering::Release`] o le `order`.
    /// Faataitaiga, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Faleoloa i le taua i le nofoaga manatua faamaotiina, toe foi i le taua matua.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i le ituaiga [`atomic`] e ala i le auala `swap` ala i le tufaina [`Ordering::AcqRel`] o le `order`.
    /// Faataitaiga, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Faleoloa i le taua i le nofoaga manatua faamaotiina, toe foi i le taua matua.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i le ituaiga [`atomic`] e ala i le auala `swap` ala i le tufaina [`Ordering::Relaxed`] o le `order`.
    /// Faataitaiga, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// E faaopoopo atu i le taua i le taimi nei, ua toe foi mai le taua ua mavae.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i le ituaiga [`atomic`] e ala i le auala `fetch_add` ala i le tufaina [`Ordering::SeqCst`] o le `order`.
    /// Faataitaiga, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// E faaopoopo atu i le taua i le taimi nei, ua toe foi mai le taua ua mavae.
    ///
    /// O le faʻamautuina faʻamatalaga o lenei intrinsic o loʻo avanoa i luga o le [`atomic`] ituaiga ala i le `fetch_add` auala e ala i le pasia o le [`Ordering::Acquire`] o le `order`.
    /// Faataitaiga, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// E faaopoopo atu i le taua i le taimi nei, ua toe foi mai le taua ua mavae.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i le ituaiga [`atomic`] e ala i le auala `fetch_add` ala i le tufaina [`Ordering::Release`] o le `order`.
    /// Faataitaiga, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// E faaopoopo atu i le taua i le taimi nei, ua toe foi mai le taua ua mavae.
    ///
    /// O loʻo avanoa le faʻamautuina ole faʻatonuga lea ile ituaiga [`atomic`] e ala ile auala `fetch_add` ile pasia ole [`Ordering::AcqRel`] ole `order`.
    /// Faataitaiga, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// E faaopoopo atu i le taua i le taimi nei, ua toe foi mai le taua ua mavae.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i le ituaiga [`atomic`] e ala i le auala `fetch_add` ala i le tufaina [`Ordering::Relaxed`] o le `order`.
    /// Faataitaiga, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Toese mai le tau o loʻo iai nei, toe faʻafoʻi le tau muamua.
    ///
    /// O le faʻamautuina faʻamatalaga o lenei intrinsic o loʻo avanoa i luga o le [`atomic`] ituaiga ala i le `fetch_sub` auala e ala i le pasia o le [`Ordering::SeqCst`] o le `order`.
    /// Faataitaiga, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Toese mai le tau o loʻo iai nei, toe faʻafoʻi le tau muamua.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i le ituaiga [`atomic`] e ala i le auala `fetch_sub` ala i le tufaina [`Ordering::Acquire`] o le `order`.
    /// Faataitaiga, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Toese mai le tau o loʻo iai nei, toe faʻafoʻi le tau muamua.
    ///
    /// O le faʻamautuina faʻamatalaga o lenei intrinsic o loʻo avanoa i luga o le [`atomic`] ituaiga ala i le `fetch_sub` auala e ala i le pasia o le [`Ordering::Release`] o le `order`.
    /// Faataitaiga, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Toese mai le tau o loʻo iai nei, toe faʻafoʻi le tau muamua.
    ///
    /// O le faʻamautuina faʻamatalaga o lenei intrinsic o loʻo avanoa i luga o le [`atomic`] ituaiga ala i le `fetch_sub` auala e ala i le pasia o le [`Ordering::AcqRel`] o le `order`.
    /// Faataitaiga, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Toese mai le tau o loʻo iai nei, toe faʻafoʻi le tau muamua.
    ///
    /// O le faʻamautuina faʻamatalaga o lenei intrinsic o loʻo avanoa i luga o le [`atomic`] ituaiga ala i le `fetch_sub` auala e ala i le pasia o le [`Ordering::Relaxed`] o le `order`.
    /// Faataitaiga, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise ma le taua i le taimi nei, ua toe foi mai le taua ua mavae.
    ///
    /// O loʻo avanoa le faʻamautuina ole faʻatonuga lea ile ituaiga [`atomic`] e ala ile auala `fetch_and` ile pasia ole [`Ordering::SeqCst`] ole `order`.
    /// Faataitaiga, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ma le taua i le taimi nei, ua toe foi mai le taua ua mavae.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i le ituaiga [`atomic`] e ala i le auala `fetch_and` ala i le tufaina [`Ordering::Acquire`] o le `order`.
    /// Faataitaiga, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ma le taua i le taimi nei, ua toe foi mai le taua ua mavae.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i le ituaiga [`atomic`] e ala i le auala `fetch_and` ala i le tufaina [`Ordering::Release`] o le `order`.
    /// Faataitaiga, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ma le taua i le taimi nei, ua toe foi mai le taua ua mavae.
    ///
    /// O le faʻamautuina faʻamatalaga o lenei intrinsic o loʻo avanoa i luga o le [`atomic`] ituaiga ala i le `fetch_and` auala e ala i le pasia o le [`Ordering::AcqRel`] o le `order`.
    /// Faataitaiga, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ma le taua i le taimi nei, ua toe foi mai le taua ua mavae.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i le ituaiga [`atomic`] e ala i le auala `fetch_and` ala i le tufaina [`Ordering::Relaxed`] o le `order`.
    /// Faataitaiga, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise nand ma le taua i le taimi nei, ua toe foi mai le taua ua mavae.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u ua i luga o le ituaiga [`AtomicBool`] e ala i le auala `fetch_nand` ala i le tufaina [`Ordering::SeqCst`] o le `order`.
    /// Faataitaiga, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand ma le taua i le taimi nei, ua toe foi mai le taua ua mavae.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u ua i luga o le ituaiga [`AtomicBool`] e ala i le auala `fetch_nand` ala i le tufaina [`Ordering::Acquire`] o le `order`.
    /// Faataitaiga, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand ma le taua i le taimi nei, ua toe foi mai le taua ua mavae.
    ///
    /// O loʻo avanoa le faʻamautuina ole faʻatonuga lea ile ituaiga [`AtomicBool`] e ala ile auala `fetch_nand` ile pasia ole [`Ordering::Release`] ole `order`.
    /// Faataitaiga, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand ma le taua i le taimi nei, ua toe foi mai le taua ua mavae.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u ua i luga o le ituaiga [`AtomicBool`] e ala i le auala `fetch_nand` ala i le tufaina [`Ordering::AcqRel`] o le `order`.
    /// Faataitaiga, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand ma le taua i le taimi nei, ua toe foi mai le taua ua mavae.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u ua i luga o le ituaiga [`AtomicBool`] e ala i le auala `fetch_nand` ala i le tufaina [`Ordering::Relaxed`] o le `order`.
    /// Faataitaiga, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise po o le taua i le taimi nei, ua toe foi mai le taua ua mavae.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i le ituaiga [`atomic`] e ala i le auala `fetch_or` ala i le tufaina [`Ordering::SeqCst`] o le `order`.
    /// Faataitaiga, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise po o le taua i le taimi nei, ua toe foi mai le taua ua mavae.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i le ituaiga [`atomic`] e ala i le auala `fetch_or` ala i le tufaina [`Ordering::Acquire`] o le `order`.
    /// Faataitaiga, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise po o le taua i le taimi nei, ua toe foi mai le taua ua mavae.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i le ituaiga [`atomic`] e ala i le auala `fetch_or` ala i le tufaina [`Ordering::Release`] o le `order`.
    /// Faataitaiga, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise po o le taua i le taimi nei, ua toe foi mai le taua ua mavae.
    ///
    /// O le faʻamautuina faʻamatalaga o lenei intrinsic o loʻo avanoa i luga o le [`atomic`] ituaiga ala i le `fetch_or` auala e ala i le pasia o le [`Ordering::AcqRel`] o le `order`.
    /// Faataitaiga, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise po o le taua i le taimi nei, ua toe foi mai le taua ua mavae.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i le ituaiga [`atomic`] e ala i le auala `fetch_or` ala i le tufaina [`Ordering::Relaxed`] o le `order`.
    /// Faataitaiga, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise xor ma le tau aoga o loʻo iai nei, toe faʻafoʻi le tau talu ai.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i le ituaiga [`atomic`] e ala i le auala `fetch_xor` ala i le tufaina [`Ordering::SeqCst`] o le `order`.
    /// Faataitaiga, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor ma le tau aoga o loʻo iai nei, toe faʻafoʻi le tau talu ai.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i le ituaiga [`atomic`] e ala i le auala `fetch_xor` ala i le tufaina [`Ordering::Acquire`] o le `order`.
    /// Faataitaiga, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor ma le tau aoga o loʻo iai nei, toe faʻafoʻi le tau talu ai.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i le ituaiga [`atomic`] e ala i le auala `fetch_xor` ala i le tufaina [`Ordering::Release`] o le `order`.
    /// Faataitaiga, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor ma le tau aoga o loʻo iai nei, toe faʻafoʻi le tau talu ai.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i le ituaiga [`atomic`] e ala i le auala `fetch_xor` ala i le tufaina [`Ordering::AcqRel`] o le `order`.
    /// Faataitaiga, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor ma le tau aoga o loʻo iai nei, toe faʻafoʻi le tau talu ai.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i le ituaiga [`atomic`] e ala i le auala `fetch_xor` ala i le tufaina [`Ordering::Relaxed`] o le `order`.
    /// Faataitaiga, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Tapulaʻa ma le aoga taimi nei faʻaaogaina se saini faʻatusatusaga.
    ///
    /// O loʻo avanoa le faʻamautuina o lenei faʻamatalaga i luga o le [`atomic`] ua sainiina integer ituaiga e ala i le `fetch_max` auala i le pasia o le [`Ordering::SeqCst`] o le `order`.
    /// Faataitaiga, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tapulaʻa ma le aoga taimi nei faʻaaogaina se saini faʻatusatusaga.
    ///
    /// O loʻo avanoa le faʻamautuina o lenei faʻamatalaga i luga o le [`atomic`] ua sainiina integer ituaiga e ala i le `fetch_max` auala i le pasia o le [`Ordering::Acquire`] o le `order`.
    /// Faataitaiga, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tapulaʻa ma le aoga taimi nei faʻaaogaina se saini faʻatusatusaga.
    ///
    /// O loʻo avanoa le faʻamautuina o lenei faʻamatalaga i luga o le [`atomic`] ua sainiina integer ituaiga e ala i le `fetch_max` auala i le pasia o le [`Ordering::Release`] o le `order`.
    /// Faataitaiga, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tapulaʻa ma le aoga taimi nei faʻaaogaina se saini faʻatusatusaga.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i sainia integer le [`atomic`] ituaiga e ala i le auala `fetch_max` ala i le tufaina [`Ordering::AcqRel`] o le `order`.
    /// Faataitaiga, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tapulaʻa ma le aoga nei.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i sainia integer le [`atomic`] ituaiga e ala i le auala `fetch_max` ala i le tufaina [`Ordering::Relaxed`] o le `order`.
    /// Faataitaiga, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Aupito i maualalo ma le taua i le taimi nei e faaaoga ai se faatusatusaga sainia.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i sainia integer le [`atomic`] ituaiga e ala i le auala `fetch_min` ala i le tufaina [`Ordering::SeqCst`] o le `order`.
    /// Faataitaiga, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Aupito i maualalo ma le taua i le taimi nei e faaaoga ai se faatusatusaga sainia.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i sainia integer le [`atomic`] ituaiga e ala i le auala `fetch_min` ala i le tufaina [`Ordering::Acquire`] o le `order`.
    /// Faataitaiga, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Aupito i maualalo ma le taua i le taimi nei e faaaoga ai se faatusatusaga sainia.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i sainia integer le [`atomic`] ituaiga e ala i le auala `fetch_min` ala i le tufaina [`Ordering::Release`] o le `order`.
    /// Faataitaiga, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Aupito i maualalo ma le taua i le taimi nei e faaaoga ai se faatusatusaga sainia.
    ///
    /// O loʻo avanoa le faʻamautuina o lenei faʻamatalaga i luga o le [`atomic`] ua sainiina integer ituaiga e ala i le `fetch_min` auala i le pasia o le [`Ordering::AcqRel`] o le `order`.
    /// Faataitaiga, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Aupito i maualalo ma le taua i le taimi nei e faaaoga ai se faatusatusaga sainia.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i sainia integer le [`atomic`] ituaiga e ala i le auala `fetch_min` ala i le tufaina [`Ordering::Relaxed`] o le `order`.
    /// Faataitaiga, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maualalo ma le taimi nei aoga faʻaogaina se unsigned faʻatusatusaga.
    ///
    /// O loʻo avanoa le faʻamautuina o lenei faʻamatalaga i luga o le [`atomic`] unsigned integer ituaiga ala i le `fetch_min` auala i le pasia o [`Ordering::SeqCst`] o le `order`.
    /// Faataitaiga, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maualalo ma le taimi nei aoga faʻaogaina se unsigned faʻatusatusaga.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i le ituaiga integer unsigned [`atomic`] e ala i le auala `fetch_min` ala i le tufaina [`Ordering::Acquire`] o le `order`.
    /// Faataitaiga, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maualalo ma le taimi nei aoga faʻaogaina se unsigned faʻatusatusaga.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i le ituaiga integer unsigned [`atomic`] e ala i le auala `fetch_min` ala i le tufaina [`Ordering::Release`] o le `order`.
    /// Faataitaiga, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maualalo ma le taimi nei aoga faʻaogaina se unsigned faʻatusatusaga.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i le ituaiga integer unsigned [`atomic`] e ala i le auala `fetch_min` ala i le tufaina [`Ordering::AcqRel`] o le `order`.
    /// Faataitaiga, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maualalo ma le taimi nei aoga faʻaogaina se unsigned faʻatusatusaga.
    ///
    /// O loʻo avanoa le faʻamautuina o lenei faʻamatalaga i luga o le [`atomic`] unsigned integer ituaiga ala i le `fetch_min` auala i le pasia o [`Ordering::Relaxed`] o le `order`.
    /// Faataitaiga, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Tapulaʻa ma le aoga taimi nei faʻaaogaina se unsigned faʻatusatusaga.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i le ituaiga integer unsigned [`atomic`] e ala i le auala `fetch_max` ala i le tufaina [`Ordering::SeqCst`] o le `order`.
    /// Faataitaiga, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tapulaʻa ma le aoga taimi nei faʻaaogaina se unsigned faʻatusatusaga.
    ///
    /// O loʻo avanoa le faʻamautuina o lenei faʻamatalaga i luga o le [`atomic`] unsigned integer ituaiga ala i le `fetch_max` auala i le pasia o [`Ordering::Acquire`] o le `order`.
    /// Faataitaiga, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tapulaʻa ma le aoga taimi nei faʻaaogaina se unsigned faʻatusatusaga.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i le ituaiga integer unsigned [`atomic`] e ala i le auala `fetch_max` ala i le tufaina [`Ordering::Release`] o le `order`.
    /// Faataitaiga, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tapulaʻa ma le aoga taimi nei faʻaaogaina se unsigned faʻatusatusaga.
    ///
    /// Le gafatia lomiga o maua lenei vala aut ¯ u o loo i le ituaiga integer unsigned [`atomic`] e ala i le auala `fetch_max` ala i le tufaina [`Ordering::AcqRel`] o le `order`.
    /// Faataitaiga, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tapulaʻa ma le aoga taimi nei faʻaaogaina se unsigned faʻatusatusaga.
    ///
    /// O loʻo avanoa le faʻamautuina o lenei faʻamatalaga i luga o le [`atomic`] unsigned integer ituaiga ala i le `fetch_max` auala i le pasia o [`Ordering::Relaxed`] o le `order`.
    /// Faataitaiga, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// O le `prefetch` vala aut ¯ u o se faaiteite i le afi code e faaofi se faatonuga prefetch pe afai e lagolagoina;ese, e a leai se-op.
    /// Prefetches leai se aʻafiaga i amioga a le polokalame ae mafai ona suia ona faʻatinoina uiga.
    ///
    /// Le tatau ona finauga `locality` a tumau integer ma o se specifier nofoaga faaletino e amata mai (0), e leai se nofoaga, e (3), matua saʻili le lotoifale i cache.
    ///
    ///
    /// Lenei mea moni e leai se mautu paga.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// O le `prefetch` vala aut ¯ u o se faaiteite i le afi code e faaofi se faatonuga prefetch pe afai e lagolagoina;ese, e a leai se-op.
    /// Prefetches leai se aʻafiaga i amioga a le polokalame ae mafai ona suia ona faʻatinoina uiga.
    ///
    /// Le tatau ona finauga `locality` a tumau integer ma o se specifier nofoaga faaletino e amata mai (0), e leai se nofoaga, e (3), matua saʻili le lotoifale i cache.
    ///
    ///
    /// Lenei mea moni e leai se mautu paga.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// O le `prefetch` vala aut ¯ u o se faaiteite i le afi code e faaofi se faatonuga prefetch pe afai e lagolagoina;ese, e a leai se-op.
    /// Prefetches leai se aʻafiaga i amioga a le polokalame ae mafai ona suia ona faʻatinoina uiga.
    ///
    /// Le tatau ona finauga `locality` a tumau integer ma o se specifier nofoaga faaletino e amata mai (0), e leai se nofoaga, e (3), matua saʻili le lotoifale i cache.
    ///
    ///
    /// Lenei mea moni e leai se mautu paga.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// O le `prefetch` vala aut ¯ u o se faaiteite i le afi code e faaofi se faatonuga prefetch pe afai e lagolagoina;ese, e a leai se-op.
    /// Prefetches leai se aʻafiaga i amioga a le polokalame ae mafai ona suia ona faʻatinoina uiga.
    ///
    /// Le tatau ona finauga `locality` a tumau integer ma o se specifier nofoaga faaletino e amata mai (0), e leai se nofoaga, e (3), matua saʻili le lotoifale i cache.
    ///
    ///
    /// Lenei mea moni e leai se mautu paga.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Se pa atomika.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o loo maua i [`atomic::fence`] ala i le tufaina [`Ordering::SeqCst`] o le `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Se pa atomika.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o loo maua i [`atomic::fence`] ala i le tufaina [`Ordering::Acquire`] o le `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Se pa atomika.
    ///
    /// O loʻo avanoa le faʻamautuina ole faʻatonuga lea ile [`atomic::fence`] ile pasia ole [`Ordering::Release`] ole `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Se pa atomika.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o loo maua i [`atomic::fence`] ala i le tufaina [`Ordering::AcqRel`] o le `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// A papupuni manatua tuufaatasia-na.
    ///
    /// E le mafai ona toe faʻafesoʻotaʻi le ulufale atu i totonu o lenei papupuni e le tagata na tuʻufaʻatasia, ae leai se faʻatonuga e tuʻuina atu mo ia.
    /// e talafeagai lenei mo galuega i luga o le filo e tasi ina ia mafai ona preempted, e pei o le fegalegaleai ma handlers faailo.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o loo maua i [`atomic::compiler_fence`] ala i le tufaina [`Ordering::SeqCst`] o le `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// A papupuni manatua tuufaatasia-na.
    ///
    /// E le mafai ona toe faʻafesoʻotaʻi le ulufale atu i totonu o lenei papupuni e le tagata na tuʻufaʻatasia, ae leai se faʻatonuga e tuʻuina atu mo ia.
    /// e talafeagai lenei mo galuega i luga o le filo e tasi ina ia mafai ona preempted, e pei o le fegalegaleai ma handlers faailo.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o loo maua i [`atomic::compiler_fence`] ala i le tufaina [`Ordering::Acquire`] o le `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// A papupuni manatua tuufaatasia-na.
    ///
    /// E le mafai ona toe faʻafesoʻotaʻi le ulufale atu i totonu o lenei papupuni e le tagata na tuʻufaʻatasia, ae leai se faʻatonuga e tuʻuina atu mo ia.
    /// e talafeagai lenei mo galuega i luga o le filo e tasi ina ia mafai ona preempted, e pei o le fegalegaleai ma handlers faailo.
    ///
    /// O loʻo avanoa le faʻamautuina ole faʻatonuga lea ile [`atomic::compiler_fence`] ile pasia ole [`Ordering::Release`] ole `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// A papupuni manatua tuufaatasia-na.
    ///
    /// E le mafai ona toe faʻafesoʻotaʻi le ulufale atu i totonu o lenei papupuni e le tagata na tuʻufaʻatasia, ae leai se faʻatonuga e tuʻuina atu mo ia.
    /// e talafeagai lenei mo galuega i luga o le filo e tasi ina ia mafai ona preempted, e pei o le fegalegaleai ma handlers faailo.
    ///
    /// O loʻo avanoa le faʻamautuina ole faʻatonuga lea ile [`atomic::compiler_fence`] ile pasia ole [`Ordering::AcqRel`] ole `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// vala aut ¯ u faamaneta e maua mai i lona uiga mai uiga e fesootai i le galuega.
    ///
    /// Mo se faʻataʻitaʻiga, dataflow faʻaaogaina lenei e tui faʻamaufaʻailogaina faʻamatalaga ina ia `rustc_peek(potentially_uninitialized)` o le a faʻalua-siakiina o dataflow na moni fuafuaina na le faʻaogaina i lena taimi i le faʻatonutonu tafe.
    ///
    ///
    /// O lenei intrinsic e le tatau ona faʻaaogaina i fafo atu o le faʻavasega.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Aborts le faatinoina o le faagasologa.
    ///
    /// O se sili atu tagata e faʻaaoga-faʻauo ma mausali lomiga o lenei gaioiga o [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Logoina le optimizer e le mafai ona tatou fesootai lenei manatu i le tulafono, e mafai ai atili optimizations.
    ///
    /// NB, e matua 'eseʻese lava lenei ma le `unreachable!()` macro: E le pei o le macro, o le panics pe a faʻataunuʻuina, o le *amio le faʻamalamalamaina* e oʻo atu i le code ua faʻailogaina i lenei galuega.
    ///
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Faʻailoa ile tagata faʻamautinoa o se tulaga e moni i taimi uma.
    /// Afai e sese le tulaga, e le faʻamatalaina le amio.
    ///
    /// Leai se tulafono e faia mo lenei mea totino, ae o le a faʻamautinoa e taumafai e faʻasao (ma lona tulaga) i le va o pasi, lea e ono faʻalavelaveina ai le faʻalelei o le siʻosiʻomaga code ma faʻaititia ai le faʻatinoga.
    /// E le tatau ona faʻaaogaina pe a fai o le invariant mafai ona mauaina e le optimizer na o ia lava, pe afai e le mafai ai ni taua tele faʻamaoniga.
    ///
    /// Lenei mea moni e leai se mautu paga.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Hints i le tuufaatasia lena tulaga branch e ono moni.
    /// Toe foi mai le taua pasia i ai.
    ///
    /// So o se faaaogaina isi nai lo faamatalaga `if` atonu o le a lē i ai se taunuuga.
    ///
    /// Lenei mea moni e leai se mautu paga.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Fautuaga i le tagata tuʻufaʻatasia e foliga mai e sese le tulaga o branch.
    /// Toe foi mai le taua pasia i ai.
    ///
    /// So o se faaaogaina isi nai lo faamatalaga `if` atonu o le a lē i ai se taunuuga.
    ///
    /// Lenei mea moni e leai se mautu paga.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Executes se mailei breakpoint, mo le asiasia e se debugger.
    ///
    /// Lenei mea moni e leai se mautu paga.
    pub fn breakpoint();

    /// O le tele o se ituaiga i bytes.
    ///
    /// Sili faapitoa, e le aveesea lenei i bytes i le va o mea faamanuiaina o le ituaiga lava e tasi, e aofia ai padding aafia i lenei suiga.
    ///
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Le faʻatulagaina maualalo o se ituaiga.
    ///
    /// O le faʻamautuina o lenei vaega o le [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Le fetaui lelei o se ituaiga.
    ///
    /// Lenei mea moni e leai se mautu paga.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// O le tele o le taua o loo taʻua i bytes.
    ///
    /// O le faʻamautuina o lenei faʻamatalaga autu o le [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Le talafeagai manaʻoga o le faʻasino taua.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Maua se fasi manoa static o loo i ai le igoa o se ituaiga.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Mauaina se faʻailoga e tutasi le lalolagi i le ituaiga faʻamaoti.
    /// O lenei galuega tauave a toe foi mai le taua lava lea e tasi mo se ituaiga e tusa lava po o fea lava crate ua faamaoniaina i.
    ///
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// A leoleo mo galuega tauave saogalemu e le mafai lava ona faataunuuina pe afai `T` o matua lē ainā:
    /// Lenei o le a tutumau a le o panic, pe leai se mea.
    ///
    /// Lenei mea moni e leai se mautu paga.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// A leoleo mo galuega tauave saogalemu e le mafai lava ona faataunuuina pe afai e le faatagaina `T` o-initialization: O lenei a statically pe panic, po o le faia o se mea.
    ///
    ///
    /// Lenei mea moni e leai se mautu paga.
    pub fn assert_zero_valid<T>();

    /// O se leoleo mo galuega le saogalemu e le mafai ona faʻataunuuina pe a fai e le aoga le `T` i le faʻataʻitaʻiga: Lenei o le a tuʻu i luga ole panic, pe leai se mea e faia.
    ///
    ///
    /// Lenei mea moni e leai se mautu paga.
    pub fn assert_uninit_valid<T>();

    /// Mauaina se faʻasino i se static `Location` faʻailoa ai le mea na valaʻauina ai.
    ///
    /// Mafaufau e faaaoga nai lo [`core::panic::Location::caller`](crate::panic::Location::caller).
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Agai a taua ai o le tulaga lautele e aunoa ma tamoe kelu mataua.
    ///
    /// Lenei o loo i ai mo na [`mem::forget_unsized`];masani `forget` faʻaaogaina `ManuallyDrop` nai lo.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Faʻamatala faʻamatalaga o vaega taua o le tasi ituaiga ma leisi ituaiga.
    ///
    /// Uma ituaiga e tatau ona i ai le tutusa tele.
    /// Poʻo le amataga, poʻo le iʻuga, atonu o le [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` e faʻatatau tutusa i le siʻitia o le tasi ituaiga i le isi.O kopi o le faagutu mai le taua puna i le taua taunuuga, sa galo ai lea o le uluai.
    /// E tutusa ma C's `memcpy` i lalo o le hood, pei lava o le `transmute_copy`.
    ///
    /// Ona `transmute` o se ala-taua taotoga, aafia i lenei suiga o le tulaga faatauaina *transmuted latou lava* e le o se popolega.
    /// Pei o seisi lava galuega, ua maeʻa faʻamautinoa e le tuʻufaʻatasiga uma `T` ma `U`.
    /// Peitaʻi, a faʻasalalauina tulaga taua e *faʻasino i isi mea*(pei o faʻasino, tusi faʻasino, pusa…), e tatau ona mautinoa e le tagata e valaʻau le fetaui lelei o mea taua.
    ///
    /// `transmute` ua **maoaʻe** le saogalemu.O loo i ai se aofaiga tele o ni auala e mafua ai [undefined behavior][ub] ma lenei galuega.`transmute` tatau ona avea ma mulimuli mulimuli.
    ///
    /// O le [nomicon](../../nomicon/transmutes.html) e iai isi faʻamaumauga.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// E i ai ni nai mea e aoga tele `transmute`.
    ///
    /// Liliuina o se faʻasino i se faʻasino tusi.O *le* feaveai i masini lea vae galuega tauave ma faamatalaga vae i ai ituaiga eseese.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Tuuina Atu o se olaga atoa, po o shortening se olaga atoa invariant.ua agai lenei, e matua le saogalemu Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Aua le faanoanoa: tele o le faaaogaina o `transmute` e mafai ona ausia e ala i isi auala.
    /// O loo i lalo talosaga masani o `transmute` lea e mafai ona suia i ao taumafaiga saogalemu.
    ///
    /// Liliu bytes(`&[u8]`) mata e `u32`, `f64`, etc .:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // faaaogaina nai lo `u32::from_ne_bytes`
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // pe faaaoga `u32::from_le_bytes` po `u32::from_be_bytes` e faamaoti le endianness
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Liliu a faasino ai i se `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Faʻaaoga le `as` cast nai lo
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Faʻaliliuina o le `*mut T` i totonu o le `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Faʻaaoga se reborrow nai lo
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Liliu se `&mut T` i se `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // O lenei, tuu faatasi `as` ma reborrowing, ia manatua e le o transitive le chaining o `as` `as`
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Faʻaliliuina o le `&str` i totonu o le `&[u8]`:
    ///
    /// ```
    /// // e le o se lelei auala e faia ai lenei.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // E mafai ona e faʻaaogaina le `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Poʻo le, na o le faʻaaogaina o se manoa byte, pe a fai oe i ai le faʻatonutonu o le manoa moni
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Liliu a `Vec<&T>` i se `Vec<Option<&T>>`.
    ///
    /// Ina ia faʻasalalauina le ituaiga totonu o mea i totonu o se koneteina, e tatau ona e mautinoa ia aua neʻi solia soʻo se isi tagata na faʻaulufaleina koneteina.
    /// Mo `Vec`, o lona uiga e tatau ona tutusa uma le lapoʻa *ma le faʻatulagaina* o ituaiga i totonu.
    /// e mafai ona faalagolago isi pusa i luga o le tele o le ituaiga, ia talafeagai, po o le `TypeId`, lea o le a le mafai tulaga transmuting i uma e aunoa ma le solia o le invariants koneteina.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // clone le vector e pei o le a tatou toe faʻaaogā i latou mulimuli ane
    /// let v_clone = v_orig.clone();
    ///
    /// // Faʻaaogaina transmute: o lenei faʻamoemoe i luga o le faʻamaumauga faʻamaumauga faʻamaumauga o `Vec`, o se leaga manatu ma ono mafua ai Undefined Amioga.
    /////
    /// // Peitaʻi, e leai se kopi.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Ole auala fautuaina lea, saogalemu.
    /// // E le kopi atoa vector, e ui lava, i se autau fou.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Ole auala sao lea ole kopi, le sefe o le "transmuting" a `Vec`, e aunoa ma le faʻamoemoe ile faʻamaumauga o faʻamatalaga.
    /// // Nai lo le moni valaau `transmute`, tatou te faia ai se lafo e faasino ai, ae i le tulaga o le faaliliuina o le ituaiga i totonu uluai (`&i32`) i le fou o se tasi (`Option<&i32>`), o lenei ua caveats tutusa uma.
    /////
    /// // E le gata i le faamatalaga ua tuuina atu i luga, feutagai foi le pepa [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME FAAFOUGA O lenei ina ua vec_into_raw_parts ua e gafatia.
    ///     // Ia mautinoa le uluai e le maligi vector.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Faʻaaogaina `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // E tele auala e faia ai lenei, ma e tele faʻafitauli i le auala (transmute) lea.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // muamua: transmute e le o se ituaiga saogalemu;siaki uma o le T ma
    ///         // U e tutusa tutusa.
    ///         // Lona lua, iinei, e te mau mutable lua e faasino i le manatu e tasi.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // O lenei e oo atu aveese o le faafitauli saogalemu ituaiga;`&mut *` o le a* na *avatu ia te oe se `&mut T` mai se `&mut T` poʻo le `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // Ae peitai, o oe lava e toalua mau mutable faasino atu i le manatu e tasi.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Ole ala lea e fai ai e le faletusi masani.
    /// // Ole auala sili lea ona lelei, pe a fai e te manaʻomia se mea faʻapenei
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Lenei ua i ai nei tolu suia faʻavasegaina faasino i le tutusa manatua.`slice`, le rvalue ret.0, ma le rvalue ret.1.
    ///         // `slice` le faaaogaina lava ina ua mavae `let ptr = ...`, ma ina ia mafai ona tasi le taulimaina o "dead", ma o lea, e na o ni fasi mutable moni e lua.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: E ui o lenei mea e faʻamautuina ai le vaega o loʻo i ai, o loʻo ia i tatou ni tulafono faʻapitoa i le fn fn
    // siaki e taofia ai lona faaaogaina i totonu o `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Faʻafoʻi `true` pe a fai o le ituaiga moni na tuʻuina mai e pei o `T` manaʻomia mataua kelu;toe faafoi `false` pe afai o le moni ituaiga saunia mo `T` faʻaaoga `Copy`.
    ///
    ///
    /// Afai o le ituaiga moni e le manaʻomia le paʻu kelu pe faʻaaogaina `Copy`, lona uiga o le toe faʻatauaina aoga o lenei galuega e le faʻamaonia.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Fuafua le aveesea mai se faasino ai.
    ///
    /// Lenei ua faʻatinoina o se loloto e aloese mai le liua i ma mai se fuainumera, talu ai o le liua o le a lafoaʻia aliasing faʻamatalaga.
    ///
    /// # Safety
    ///
    /// Uma le amata ma le faʻaiuga faʻasino tatau ona tatau ona i tuaʻoi poʻo le tasi byte pasia le faaiuga o se atofaina mea.
    /// Afai foi e faasino ai o mai tuaoi po faatumulia numera tupu lea so o se isi faaaogaina o le taua toe foi o le a iʻu i le amioga undefined.
    ///
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Fuafua le aveesea mai se faʻasino, e ono afifi.
    ///
    /// Lenei o loʻo faʻatinoina o se mea taua e aloese ai mai le liua i ma mai le numera, talu ai o le liua taofiofia nisi faʻamaoniga.
    ///
    /// # Safety
    ///
    /// E le pei o le `offset` intrinsic, e le faʻatapulaʻaina e lenei fatuga le faʻaiʻuga na tusi e tusi i totonu pe tasi le paita i tua atu o le iʻuga o se mea faʻasoasoa, ma e afifiina ma le lua fesoasoani atoatoa.
    /// O le taunuuga o le taua e le ona aloaia e faaaoga e moni manatua avanoa.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Tutusa ma le talafeagai vala aut ¯ u `llvm.memcpy.p0i8.0i8.*`, faatasi ma se aofai o `count`*`size_of::<T>()` ma se aafia i lenei suiga o le
    ///
    /// `min_align_of::<T>()`
    ///
    /// ua faatulagaina e le parameter volatile e `true`, o lea o le a le optimized mai vagana tele e tutusa ma o.
    ///
    /// Lenei mea moni e leai se mautu paga.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Tutusa ma le talafeagai vala aut ¯ u `llvm.memmove.p0i8.0i8.*`, faatasi ma se aofai o `count* size_of::<T>()` ma se aafia i lenei suiga o le
    ///
    /// `min_align_of::<T>()`
    ///
    /// ua faatulagaina e le parameter volatile e `true`, o lea o le a le optimized mai vagana tele e tutusa ma o.
    ///
    /// Lenei mea moni e leai se mautu paga.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Tutusa ma le talafeagai vala aut ¯ u `llvm.memset.p0i8.*`, faatasi ma se aofai o `count* size_of::<T>()` ma se aafia i lenei suiga o `min_align_of::<T>()`.
    ///
    ///
    /// ua faatulagaina e le parameter volatile e `true`, o lea o le a le optimized mai vagana tele e tutusa ma o.
    ///
    /// Lenei mea moni e leai se mautu paga.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Faatinoina se avega volatile mai le faasino `src`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Faia se faleoloa gaogao i le `dst` faʻasino.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Faʻatinoina se avega vevesi mai le `src` faʻasino O le faʻasino tusi e le manaʻomia e faʻafetaui.
    ///
    ///
    /// Lenei mea moni e leai se mautu paga.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Faia se faleoloa gaogao i le `dst` faʻasino.
    /// E le tau manaʻomia le faʻasino tusi.
    ///
    /// Lenei mea moni e leai se mautu paga.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Toe afio mai le aa faatafafa o se `f32`
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Faʻafoʻi le sikuea aʻa o le `f64`
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Tulaʻi mai ai se `f32` i se mana integer.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Siʻi le `f64` i le numera o le paoa.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Faʻafoʻi le sinia o le `f32`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Faʻafoʻi le sinia o le `f64`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Faʻafoʻi le cosine o le `f32`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Toe afio mai le cosine o se `f64`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Tulaʻi mai ai se `f32` i se mana `f32`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Tulaʻi mai ai se `f64` i se mana `f64`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Faʻafoʻi mai le avanoa o le `f32`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Faʻafoʻi mai le avanoa o le `f64`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Faʻafoʻi 2 siitia i le malosiaga o le `f32`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Toe foi 2 faatu mai i le mana o le `f64`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Faʻafoʻi mai le natural logarithm o le `f32`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Toe afio mai le logarithm faalenatura o se `f64`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Toe afio mai le faavae 10 logarithm o se `f32`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Faʻafoʻi mai le faavae 10 logarithm o le `f64`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Faʻafoʻi mai le faavae 2 logarithm o le `f32`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Toe afio mai le faavae 2 logarithm o se `f64`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Faafoi `a * b + c` mo tulaga faatauaina `f32`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Faʻafoʻi `a * b + c` mo `f64` tau.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Toe foi mai le taua aʻiaʻi o se `f32`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Faʻafoʻi mai le aofaʻi atoa o le `f64`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Faʻafoʻi mai le laʻititi ifo o le lua `f32` tau.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Faʻafoʻi mai le laʻititi ifo o le lua `f64` tau.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Faʻafoʻi mai le maualuga o le lua `f32` taua.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Toe afio mai le maualuga o tulaga faatauaina e lua `f64`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Kopi le faʻailoga mai le `y` i le `x` mo `f32` tau.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Kopi le faailoga mai le `y` e `x` mo tulaga faatauaina `f64`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Faʻafoʻi mai le fuainumera pito i tele maualalo ifo pe tutusa i le `f32`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Faʻafoʻi mai le fuainumera pito i tele maualalo ifo pe tutusa i le `f64`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Toe foi mai o le tele integer itiiti nai lo le po o le tutusa i se `f32`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Faʻafoʻi mai le laʻititi numera aofaʻi tele atu pe tutusa i le `f64`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Toe foi le vaega integer o se `f32`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Toe foi le vaega integer o se `f64`.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Faʻafoʻi mai le fuainumera latalata ile `f32`.
    /// Ia faatu se inexact tuusaunoaga opeopea-tulaga pe afai o le finauga e le o se integer.
    pub fn rintf32(x: f32) -> f32;
    /// Toe afio mai le integer lata ane i se `f64`.
    /// Ia faatu se inexact tuusaunoaga opeopea-tulaga pe afai o le finauga e le o se integer.
    pub fn rintf64(x: f64) -> f64;

    /// Faʻafoʻi mai le fuainumera latalata ile `f32`.
    ///
    /// Lenei mea moni e leai se mautu paga.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Toe afio mai le integer lata ane i se `f64`.
    ///
    /// Lenei mea moni e leai se mautu paga.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Faʻafoʻi mai le fuainumera latalata ile `f32`.Faʻataʻamiloina afa auala auala ese mai zero.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Toe afio mai le integer lata ane i se `f64`.Faʻataʻamiloina afa auala auala ese mai zero.
    ///
    /// Le gafatia lomiga o lenei vala aut ¯ u o
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Opeopea faaopoopo e mafai optimizations faavae i luga o tulafono algebraic.
    /// E ono fai mai e maeʻa faʻamatalaga.
    ///
    /// Lenei mea moni e leai se mautu paga.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Opeopea tōʻese e mafai optimizations faavae i luga o tulafono algebraic.
    /// E ono fai mai e maeʻa faʻamatalaga.
    ///
    /// Lenei mea moni e leai se mautu paga.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Opeopea fanafanau e mafai optimizations faavae i luga o tulafono algebraic.
    /// E ono fai mai e maeʻa faʻamatalaga.
    ///
    /// Lenei mea moni e leai se mautu paga.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Vaeluaina vaevaega e faʻatagaina ai faʻalelei faʻavae i algebraic tulafono.
    /// E ono fai mai e maeʻa faʻamatalaga.
    ///
    /// Lenei mea moni e leai se mautu paga.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Opeopea totoe e mafai optimizations faavae i luga o tulafono algebraic.
    /// E ono fai mai e maeʻa faʻamatalaga.
    ///
    /// Lenei mea moni e leai se mautu paga.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Tagata liliu mai ma fptoui/fptosi a LLVM, lea e mafai ona toe foi undef mo le tulaga faatauaina mai le tele
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Faʻamautuina e pei o [`f32::to_int_unchecked`] ma [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Faʻafoʻi mai le numera o fasi fasi seti i totonu o le numera `T`
    ///
    /// e maua lomiga e gafatia o lenei vala aut ¯ u i le primitives integer e ala i le auala `count_ones`.
    /// Faataitaiga,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Toe foi le numera o le taitaiina o unset faagutu (zeroes) i se ituaiga integer `T`.
    ///
    /// O faʻamautuina faʻamaumauga o lenei intrinsic o loʻo avanoa i luga o fuainumera muamua e ala i le `leading_zeros` metotia.
    /// Faataitaiga,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// O se `x` ma taua le a toe foi `0` le si lautele o `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// E pei `ctlz`, ae faaopoopo-le saogalemu e pei ona toe foi `undef` pe a tuuina atu se `x` ma taua `0`.
    ///
    ///
    /// Lenei mea moni e leai se mautu paga.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Toe foi le aofai o trailing unset faagutu (zeroes) i se integer ituaiga `T`.
    ///
    /// e maua lomiga e gafatia o lenei vala aut ¯ u i le primitives integer e ala i le auala `trailing_zeros`.
    /// Faataitaiga,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// O se `x` ma taua le a toe foi `0` le si lautele o `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// E pei `cttz`, ae faaopoopo-le saogalemu e pei ona toe foi `undef` pe a tuuina atu se `x` ma taua `0`.
    ///
    ///
    /// Lenei mea moni e leai se mautu paga.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Tulaga tuufaafeagai le bytes i se ituaiga integer `T`.
    ///
    /// e maua lomiga e gafatia o lenei vala aut ¯ u i le primitives integer e ala i le auala `swap_bytes`.
    /// Faataitaiga,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Tulaga tuufaafeagai le faagutu i se ituaiga integer `T`.
    ///
    /// O faʻamautuina faʻamaumauga o lenei intrinsic o loʻo avanoa i luga o fuainumera muamua e ala i le `reverse_bits` metotia.
    /// Faataitaiga,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Faatinoina siaki integer faaopoopo.
    ///
    /// e maua lomiga e gafatia o lenei vala aut ¯ u i le primitives integer e ala i le auala `overflowing_add`.
    /// Faataitaiga,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Faia siaki toese numera
    ///
    /// O faʻamautuina faʻamaumauga o lenei intrinsic o loʻo avanoa i luga o fuainumera muamua e ala i le `overflowing_sub` metotia.
    /// Faataitaiga,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Faia siaki faʻatele numera
    ///
    /// e maua lomiga e gafatia o lenei vala aut ¯ u i le primitives integer e ala i le auala `overflowing_mul`.
    /// Faataitaiga,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Faatinoina se vaega tonu, e mafua i amioga undefined mea `x % y != 0` po `y == 0` po `x == T::MIN && y == -1`
    ///
    ///
    /// Lenei mea moni e leai se mautu paga.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Faatinoina se vaega e lē siakiina, e mafua i amioga undefined mea `y == 0` po `x == T::MIN && y == -1`
    ///
    ///
    /// fusi manuʻa ua taatitia saogalemu mo lenei vala aut ¯ u o loo maua i luga o le primitives integer e ala i le auala `checked_div`.
    /// Faataitaiga,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Toe foi le vaega o totoe o se vaega e lē siakiina, e mafua i amioga undefined pe `y == 0` po `x == T::MIN && y == -1`
    ///
    ///
    /// fusi manuʻa ua taatitia saogalemu mo lenei vala aut ¯ u o loo maua i luga o le primitives integer e ala i le auala `checked_rem`.
    /// Faataitaiga,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Faatinoina se lē siakiina suiga tauagavale, e mafua i amioga undefined pe `y < 0` po `y >= N`, lea o N le lautele o T i faagutu.
    ///
    ///
    /// fusi manuʻa ua taatitia saogalemu mo lenei vala aut ¯ u o loo maua i luga o le primitives integer e ala i le auala `checked_shl`.
    /// Faataitaiga,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Faia se sifi taumatau le siakiina, mafua ai amio le mafaamatalaina pe a `y < 0` poʻo `y >= N`, lea N o le lautele o T i fasi.
    ///
    ///
    /// fusi manuʻa ua taatitia saogalemu mo lenei vala aut ¯ u o loo maua i luga o le primitives integer e ala i le auala `checked_shr`.
    /// Faataitaiga,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Toe afio mai le taunuuga o se gata e lē siakiina, e mafua i amioga undefined pe `x + y > T::MAX` po `x + y < T::MIN`.
    ///
    ///
    /// Lenei mea moni e leai se mautu paga.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Toe afio mai le taunuuga o se tōʻese lē siakiina, e mafua i amioga undefined pe `x - y > T::MAX` po `x - y < T::MIN`.
    ///
    ///
    /// Lenei mea moni e leai se mautu paga.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Faʻafoʻi le iʻuga o le faʻateleina le faʻailogaina, mafua ai amioga le faʻamatalaina pe a `x *y > T::MAX` poʻo `x* y < T::MIN`.
    ///
    ///
    /// Lenei mea moni e leai se mautu paga.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Faatinoina feauauaʻi tuua.
    ///
    /// e maua lomiga e gafatia o lenei vala aut ¯ u i le primitives integer e ala i le auala `rotate_left`.
    /// Faataitaiga,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Faatinoina vili saʻo.
    ///
    /// O faʻamautuina faʻamaumauga o lenei intrinsic o loʻo avanoa i luga o fuainumera muamua e ala i le `rotate_right` metotia.
    /// Faataitaiga,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Faʻafoʻi (a + b) mod 2 <sup>N</sup>, o N o le lautele o T i fasi.
    ///
    /// O faʻamautuina faʻamaumauga o lenei intrinsic o loʻo avanoa i luga o fuainumera muamua e ala i le `wrapping_add` metotia.
    /// Faataitaiga,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Faʻafoʻi (a, b) mod 2 <sup>N</sup>, o N o le lautele o T i fasi.
    ///
    /// O faʻamautuina faʻamaumauga o lenei intrinsic o loʻo avanoa i luga o fuainumera muamua e ala i le `wrapping_sub` metotia.
    /// Faataitaiga,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Faʻafoʻi (a * b) mod 2 <sup>N</sup>, o N o le lautele o T i fasi.
    ///
    /// O faʻamautuina faʻamaumauga o lenei intrinsic o loʻo avanoa i luga o fuainumera muamua e ala i le `wrapping_mul` metotia.
    /// Faataitaiga,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Computes `a + b`, saturating i tuaoi numeric.
    ///
    /// e maua lomiga e gafatia o lenei vala aut ¯ u i le primitives integer e ala i le auala `saturating_add`.
    /// Faataitaiga,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Faʻatusatusa `a - b`, faʻamalieina i numera numera.
    ///
    /// e maua lomiga e gafatia o lenei vala aut ¯ u i le primitives integer e ala i le auala `saturating_sub`.
    /// Faataitaiga,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Toe foi mai le taua o le discriminant mo le variant i 'v';
    /// afai `T` leai se faʻailoga tagata, faʻafoʻi `0`.
    ///
    /// O le faʻamautuina o lenei faʻamatalaga autu o le [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Toe foi le numera o suiga o le ituaiga lafo `T` i se `usize`;
    /// pe afai `T` e leai se variants, Ua toe foi `0`.o le a faitauina variants matua lē ainā.
    ///
    /// O le e-ona-e gafatia lomiga o lenei vala aut ¯ u o [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// a fausia "try catch" Rust lea e fagua ai le faasino ai galuega tauave `try_fn` ma le faamatalaga e faasino `data`.
    ///
    /// O le finauga lona tolu o se galuega tauave taʻua pe a tupu panic.
    /// Lenei gaioiga ave le faʻasino tusi ma se faʻasino i le sini faʻapitoa-faʻapitoa mea faitino na maua.
    ///
    /// Mo nisi faamatalaga tagai i le puna o le tuufaatasia e faapea foi faatinoga faiva a std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Faamatuu mai se faleoloa `!nontemporal` tusa ma LLVM (tagai i latou docs).
    /// Masalo o le a le mafai ona mautu.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Vaʻai faʻamaumauga o `<*const T>::offset_from` mo auiliiliga.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Vaʻai faʻamaumauga o `<*const T>::guaranteed_eq` mo auiliiliga.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Vaʻai faʻamaumauga o `<*const T>::guaranteed_ne` mo auiliiliga.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Faasoasoa i le tuufaatasia taimi.Le tatau ona valaauina i runtime.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// O nisi o galuega o loo faamatalaina ai iinei ona latou le maua faafuasei i lenei module i le fale o manu.
// Tagai <https://github.com/rust-lang/rust/issues/15702>.
// (E pau foi `transmute` i lenei vaega, ae e le mafai ona afifi ona o le siaki o loo i ai `T` ma `U` le tele lava e tasi.)
//

/// Siaki pe talafeagai lelei le `ptr` ma le `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Kopi `count *size_of::<T>()` bytes mai `src` e `dst`.O le punavai ma e tatau taunuuga* le * fesiliaʻi.
///
/// Mo itulagi o manatua atonu e fesiliaʻi, faʻaaoga le [`copy`] nai lo.
///
/// `copy_nonoverlapping` o semantically tutusa [`memcpy`] a le C, ae faatasi ai ma le poloaiga finauga swapped.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Amioga ua undefined pe afai o so o se ua solia ai tuutuuga nei:
///
/// * `src` tatau ona [valid] mo faitau o `count * size_of::<T>()` bytes.
///
/// * `dst` tatau ona [valid] mo Tusia o bytes `count * size_of::<T>()`.
///
/// * Uma `src` ma `dst` tatau ona faʻasaʻo lelei.
///
/// * Le itulagi o manatua e amata mai i `src` ma se tele o le 'faitau *
///   size_of: :<T>() 'Bytes tatau *le* fesiliaʻi i le itulagi o le manatua e amata mai i `dst` ma le tele lava e tasi.
///
/// E pei [`read`], faatupuina `copy_nonoverlapping` a bitwise kopi o `T`, e tusa lava pe `T` o [`Copy`].
/// Afai `T` e le [`Copy`], e faaaoga *uma* le tulaga faatauaina i le itulagi e amata mai i `*src` ma le itulagi e amata mai i `* dst` mafaia [violate memory safety][read-ownership].
///
///
/// Faaaliga e tusa lava pe le tele kopiina lelei ('faitau * size_of: :<T>() `) o le `0`, o faʻasino e tatau ona le NUL ma faʻalelei lelei.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Manually faatino [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Faagaoioi elemene uma o `src` i `dst`, ma tuua tuufua `src`.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Ia mautinoa o `dst` e lava lona agavaʻa e taofia uma ai le `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // O le valaau ia aveesea o le saogalemu i taimi uma ona o le a lava faasoasoa sili atu nai lo bytes `isize::MAX` `Vec`.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Truncate `src` aunoa ma le lafoa o ona anotusi.
///         // Tatou te faia lenei muamua, e faatoilaloina faafitauli i le tulaga o se mea nisi lalo panics.
///         src.set_len(0);
///
///         // O itulagi e lua e le mafai ona faʻapipiʻi aua e le suia igoa faʻasolosolo, ma lua Eseese vectors e le mafai ona latou mauaina le tutusa manatua.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Faʻailoa ile `dst` o loʻo taofia nei mea o le `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Faia nei siaki naʻo i le taimi tamoe
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // E panicking e tausia laiti codegen aafiaga.
        abort();
    }*/

    // SAOGALEMU: o le e tatau ona saogalemu konekarate mo `copy_nonoverlapping`
    // lagolagoina e ala i le telefoni.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Kopi `count * size_of::<T>()` bytes mai `src` e `dst`.O le punavai ma taunuuga e mafai ona fesiliaʻi.
///
/// Afai o le punavai ma le taunuuga o le a *lava fesiliaʻi*, e mafai ona faaaogaina [`copy_nonoverlapping`] ae.
///
/// `copy` e tutusa tutusa ma C's [`memmove`], ae faʻafesuiaʻi le faʻaupuga ma le poloaʻiga.
/// Ata e faia e pei o le bytes na kopiina mai `src` i se faatulagaga tumau ona kopiina mai le autau e `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Amioga ua undefined pe afai o so o se ua solia ai tuutuuga nei:
///
/// * `src` tatau ona [valid] mo faitau o `count * size_of::<T>()` bytes.
///
/// * `dst` tatau ona [valid] mo Tusia o bytes `count * size_of::<T>()`.
///
/// * Uma `src` ma `dst` tatau ona faʻasaʻo lelei.
///
/// Pei o [`read`], `copy` fausiaina se kopi poto o le `T`, tusa lava pe o le `T` o le [`Copy`].
/// Afai `T` e le [`Copy`], i le faaaogaina uma i tulaga faatauaina i le itulagi e amata mai i `*src` ma le itulagi e amata mai i `* dst` mafaia [violate memory safety][read-ownership].
///
///
/// Faaaliga e tusa lava pe le tele kopiina lelei ('faitau * size_of: :<T>() `) o le `0`, o faʻasino e tatau ona le NUL ma faʻalelei lelei.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Lelei e faatupuina se Rust vector mai se buffer saogalemu:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` e tatau ona saʻo ogatusa mo lona ituaiga ma e lē o ni o.
/// /// * `ptr` e tatau ona aloaia mo le faitauina o `elts` elemene tuaoi o ituaiga `T`.
/// /// * O na elemeni e le tatau ona faʻaaogaina pe a uma ona valaʻau lenei galuega vagana `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // SAFETI: O la matou mataupu muamua e mautinoa ai o le punaoa e ogatusa ma aoga,
///     // ma faamautinoa `Vec::with_capacity` ua tatou maua le faaaogāina avanoa e tusi i latou.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // SAFETI: Na matou fausiaina ma lenei tele gafatia muamua,
///     // ma talu ai ua initialized `copy` nei elemene.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Faia nei siaki naʻo i le taimi tamoe
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // E panicking e tausia laiti codegen aafiaga.
        abort();
    }*/

    // SAFETY: o le saogalemu konekarate mo `copy` tatau ona lagolagoina e le telefoni.
    unsafe { copy(src, dst, count) }
}

/// Seti `count * size_of::<T>()` bytes o faʻamanatuga amata ile `dst` i le `val`.
///
/// `write_bytes` e tutusa [`memset`] a le C, ae faatulagaina `count * size_of::<T>()` bytes e `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Amioga ua undefined pe afai o so o se ua solia ai tuutuuga nei:
///
/// * `dst` tatau ona [valid] mo Tusia o bytes `count * size_of::<T>()`.
///
/// * `dst` e tatau ona ogatusa lelei.
///
/// Gata i lea, e tatau ona mautinoa ai le telefoni e tusi `count * size_of::<T>()` bytes i le tuuina mai itulagi o taunuuga manatua i se taua aloaia o `T`.
/// O le faʻaaogaina o se itulagi o mea e manatuaina na taina o se `T` o loʻo iai se aoga le aoga o le `T` o se amioga le faʻamatalaina.
///
/// Faaaliga e tusa lava pe le tele kopiina lelei ('faitau * size_of: :<T>() ') O `0`, e tatau ona lē soloia ma lelei ogatasi le faasino ai.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Faʻaaoga faʻavae:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Faia o se taua aloaia:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Tuʻufaʻatasia le tau na muamua taofi e ala i le faʻasolosolo o le `Box<T>` ma se faʻailoga e leai sona aoga.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // I le taimi lea, e faaaoga ai po o le pau o `v` taunuuga i amioga undefined.
/// // drop(v); // ERROR
///
/// // E oʻo lava i le faʻamamaina o le `v` "uses" ia, ma o lea e le faʻamatalaina amioga.
/// // mem::forget(v); // ERROR
///
/// // O le mea moni, `v` e le faʻamaoni e tusa ai ma ituaiga masani faʻatulagaina invariants, o lea *soʻo se* faʻagaioiga e le faʻamatalaina amioga.
/////
/// // ia v2 =v;//SESE
///
/// unsafe {
///     // Sei o tatou tuu i totonu o se aoga taua
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // O sala tupe e le pusa
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // SAFETY: o le saogalemu konekarate mo `write_bytes` tatau ona lagolagoina e le telefoni.
    unsafe { write_bytes(dst, val, count) }
}