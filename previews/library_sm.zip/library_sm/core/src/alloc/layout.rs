use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// A o faaaogaina lenei galuega tauave i se nofoaga e tasi ma e mafai ona inlined lona faatinoga, o le taumafaiga muamua ina ia faia faapea faia rustc lemu:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Faatulagaina o se poloka o manatua.
///
/// O se faʻataʻitaʻiga o le `Layout` o loʻo faʻamatalaina mai ai se faʻapitoa o mea e te manatuaina.
/// Oe fausia se `Layout` luga o se sao e tuʻuina atu i se faʻasoasoa.
///
/// O faʻataʻatiaga uma e iai le fesoʻotaʻiga tele ma le paoa-o-lua faʻavasega.
///
/// (Manatua o faʻataʻatiaga e *le* manaʻomia ina ia leai-leai lapoʻa, e ui lava o le `GlobalAlloc` manaʻomia o mea uma e manatuaina talosaga ia leai-leai le tele.
/// O se tagata e valaʻau e tatau ona faʻamautinoaina ua faʻamalieina tulaga faʻapenei, faʻaaoga ni tufatufaina tuʻutuʻuga ma manaʻoga looser, pe faʻaaogaina le sili atu le agamalu `Allocator` interface.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // tele o le poloka talosagaina o manatua, fuaina i bytes.
    size_: usize,

    // gatasi o le poloka talosagaina o manatua, fuaina i bytes.
    // matou mautinoa o lenei e masani lava o le paoa-o-lua, aua o API e pei o `posix_memalign` manaʻomia ma o se talafeagai taofiofi e faʻamalosia luga Layout fausiaina.
    //
    //
    // (Ae ui i lea, matou te le manaʻomia faʻatusatusa le `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Fausia se `Layout` mai le `size` ma le `align`, pe toe faʻafoi mai le `LayoutError` peʻa fai e le ausia tulaga uma nei:
    ///
    /// * `align` e le tatau ona leai,
    ///
    /// * `align` tatau ona avea o se malosiaga o le lua,
    ///
    /// * `size`, ina lapotopoto e oo atu i le tele o lata ane o `align`, e lē tatau faatumulia (ie, o le taua lapotopoto e tatau ona le itiiti ifo po o le tutusa i `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (Le mana-o-lua e faatatau ogatasi!=0.)

        // tele i luga lapotopoto o le:
        //   size_rounded_up=(tele + ogatasi, 1)&(ogatasi, 1)!;
        //
        // Matou te iloa mai luga atu lena laina!=0.
        // Afai e le faʻateleina le faʻaopoopoina (1, 1), ona lelei lea o le taʻamilomilo.
        //
        // Faʻafeagai,&-masking with! (Align, 1) o le a toʻesea ese na o le maualalo-okaina.
        // O lea la pe afai ua faatumulia o tupu ma le aofaiga, o le&-mask le mafai ona toese lava le toe faaleleia o le tele foʻi.
        //
        //
        // I luga atu o lona uiga o le siakiina mo le aofaʻi o le lolovaia e talafeagai uma ma lava.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // SAFETY: o tuutuuga mo `from_size_align_unchecked` sa
        // siaki luga
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Fausia se faʻavasega, aloese uma siaki.
    ///
    /// # Safety
    ///
    /// O lenei gaioiga e le sefe ona e le faʻamaonia le muaʻiloʻoga mai [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // SAFETY: o le tagata telefoni e tatau ona mautinoa o `align` e sili atu nai lo le zero.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// O le tele maualalo bytes mo se poloka manatu o lenei faatulagaga.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// O le aafia i lenei suiga byte maualalo mo se poloka manatu o lenei faatulagaga.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Fausia se `Layout` talafeagai mo le umiaina o le taua o le ituaiga `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // SAFETY: o le laina tutusa e mautinoa e Rust e avea ma malosiʻaga o le lua ma
        // le lapoʻa + faʻatasiga combo e mautinoa e ofi i le matou tuatusi avanoa.
        // O lona iʻuga faʻaaoga le tagata siaki le siakiina iinei e aloese mai le faʻaofiina o le code e panics pe a fai e le o lelei faʻaleleia.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Gaosia faʻataʻatiaga faʻamatalaina se faʻamaumauga e mafai ona faʻaaogaina e tuʻuina atu ai le lagolagoina lagolago mo `T` (lea e mafai ona avea ma trait poʻo isi unsized ituaiga pei o se fasi).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SAFETY: vaai mafuaaga i `new` mo le mafuaʻaga ua faʻaaogaina ai le le saogalemu ituaiga
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Gaosia faʻataʻatiaga faʻamatalaina se faʻamaumauga e mafai ona faʻaaogaina e tuʻuina atu ai le lagolagoina lagolago mo `T` (lea e mafai ona avea ma trait poʻo isi unsized ituaiga pei o se fasi).
    ///
    /// # Safety
    ///
    /// O lenei gaioiga e naʻo le saogalemu e valaʻau ai pe a fai o tulaga nei taofi:
    ///
    /// - Afai o `T` o `Sized`, o lenei gaioiga e saogalemu i taimi uma e valaʻau.
    /// - Afai o le siʻusiʻu le `T` o le:
    ///     - a [slice], o lona uiga o le umi o le slice tail e tatau ona avea ma integer integer, ma le tele o le *atoa taua*(Dynamic tail tail + statically rahi nauna) e tatau ona ofi i le `isize`.
    ///     - a [trait object], ona tatau lea ona vaʻai le vtable vaega o le faʻasino i se vtable aoga mo le ituaiga `T` maua e se coersion faʻamaonia, ma le lapoʻa o le *atoa taua*(malosi siʻusiʻu umi + statically tele faʻatulagaina) tatau ona ofi i le `isize`.
    ///
    ///     - o le (unstable) [extern type], o lona uiga o lenei galuega e sefe lava i taimi uma pe a valaʻau, ae mafai panic pe faʻafoi mai le sese sese, ona e leʻo iloa le faʻatulagaina o le ituaiga i fafo.
    ///     O le amio lava lea e tasi pei o le [`Layout::for_value`] i luga o le faʻasino i le pito i fafo o le siʻusiʻu.
    ///     - ese, ua conservatively le faatagaina e valaau lenei galuega tauave.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // SAFETY: matou pasi pasi muamua o nei gaioiga i le telefoni
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SAFETY: vaai mafuaaga i `new` mo le mafuaʻaga ua faʻaaogaina ai le le saogalemu ituaiga
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Fausia se `NonNull` e tautau, ae fetaui lelei mo lenei Tulaga.
    ///
    /// Manatua o le faʻasino faʻatomuaga ono ono avea ma sui o se faʻasino faasino, o lona uiga e le tatau ona faʻaaogaina o se "not yet initialized" sentinel aoga.
    /// Ituaiga e paie faʻasoa e tatau ona siaki amataina i nisi auala.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // SAFETY: fetaui e mautinoa e leai-leai
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Fausia se faʻatulagaina faʻamatalaina le faʻamaumauga e mafai ona taofia le taua o le faʻatulagaina tutusa ma `self`, ae o lena foi e ogatusa ma gatasi `align` (fuaina i bytes).
    ///
    ///
    /// Afai ua uma ona ausia e `self` le faʻatonuga faʻatulagaina, ona toe faʻafoʻi mai lea o le `self`.
    ///
    /// Manatua o lenei metotia e le faʻaopoopoina soʻo se padding i le aotelega tele, tusa lava pe o le toe faʻataʻotoina ei ai se eseesega gatasi.
    /// I nisi upu, afai `K` tele 16, `K.align_to(32)` o le a *tumau* maua tele 16.
    ///
    /// Toe foi se mea sese pe afai o le tuufaatasiga o `self.size()` ma le tuuina `align` solia ai tuutuuga o loo lisiina i [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// O tupe maua o le aofaiga o padding e tatau ona tatou faaofiina ina ua tuanai `self` ina ia mautinoa ai o le a faamalieina le tuatusi nei `align` (fuaina i bytes).
    ///
    /// faʻataʻitaʻiga, afai o le `self.size()` o le 9, ona toe faʻafoi mai lea e le `self.padding_needed_for(4)` le 3, aua o le aofaʻi maualalo lea o bytes o padding manaʻomia e maua ai se tuatusi 4-laina (manatu o le tutusa manatua poloka amata i le 4-laina faʻatulagaina tuatusi).
    ///
    ///
    /// O le toe faafoi taua o lenei gaioiga e leai se uiga pe a fai o `align` e le o se malosiaga-o-lua.
    ///
    /// Manatua o le aoga o le toe faʻafoʻi manaʻoga manaʻomia `align` ia laʻititi ifo pe tutusa ma le tuʻufaʻatasia o le amata tuatusi mo le atoa atofaina poloka o manatua.Se tasi o auala e faamalieina ai lenei le taofiofiga o le mautinoa `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // taua i luga lapotopoto o le:
        //   len_rounds_up=(len + align, 1)&! (ogatusa, 1);
        // ona tatou toe faʻafoʻi ai lea o le eseesega padding: `len_rounded_up - len`.
        //
        // Matou te faʻaaogaina modular arithmetic i le atoa:
        //
        // 1. laina tutusa e mautinoa o le avea ma> 0, o lea e tutusa, 1 e aoga i taimi uma.
        //
        // 2.
        // `len + align - 1` mafai ona lolovaia e sili atu `align - 1`, o lea o le&-mask ma `!(align - 1)` o le a mautinoa ai i le tulaga o le ova, `len_rounded_up` o ia lava o le 0.
        //
        //    O lea le padding toe foi mai, ina ua faaopoopo atu i `len`, gauai 0, lea trivially faamalieina le gatasi `align`.
        //
        // (Ioe, taumafaiga e tufatufa poloka o mea e manatua ai lona lapoʻa ma padding ova i luga o le auala luga e tatau ona mafua ai le tagata tuʻuina atu ia maua se mea sese.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Fausia se faʻavasega e ala i le faʻataʻamilomiloina o le tele o lenei faʻataʻitaʻiga i luga i le tele o le faʻatulagaina gatasi.
    ///
    ///
    /// e tusa lea ma le faaopoopoina i ai o le taunuuga o `padding_needed_for` i le tele i le taimi nei o le faatulagaga.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // E le mafai ona tupu lenei mea.Upusii mai le auiliili o Lisi:
        // > `size`, pe a faʻataʻamilomilo i le sili atu lata mai o `align`,
        // > tatau ona le lolovaia (ie, o le lapoʻa le tau tatau ona laʻititi ifo
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Fausia se faʻatulagaina faʻamatalaina le faʻamaumauga mo `n` taimi o `self`, ma le talafeagai aofaʻi o padding i le va o latou taʻitasi e mautinoa ai o taimi taʻitasi na tuʻuina atu le tele na talosagaina tele ma gatasi.
    /// I le manuia, toe faafoi `(k, offs)` o `k` o le faʻatulagaina o le faʻasologa ma `offs` o le mamao i le va o le amataga o elemeni taʻitasi i le laina.
    ///
    /// I luga o le arithmetic overflow, faʻafoʻi `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // E le mafai ona tupu lenei mea.Upusii mai le auiliili o Lisi:
        // > `size`, pe a faʻataʻamilomilo i le sili atu lata mai o `align`,
        // > tatau ona le lolovaia (ie, o le lapoʻa le tau tatau ona laʻititi ifo
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // SAFETY: self.align ua uma ona iloa e aoga ma faʻasoa_size na
        // ua uma ona afifi.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Fausia se faʻatulagaina faʻamatalaina le faʻamaumauga mo `self` sosoʻo mai ma le `next`, e aofia ai soʻo se mea e faʻataʻatitia tatau ai ina ia mautinoa o le `next` o le a faʻatulaga lelei, ae *leai se auala savali*.
    ///
    /// Ina ia mafai ona faʻafetaui C faʻaaliga sui `repr(C)`, oe tatau ona valaʻau `pad_to_align` pe a uma ona faʻalauteleina le faʻatulagaina ma uma fanua.
    /// (E leai se auala e faʻafetaui ai le le tumau Rust faʻataʻitaʻiga `repr(Rust)`, as it is unspecified.)
    ///
    /// Manatua o le faʻavasegaina o le faʻatulagaina faʻatulagaina o le sili atu na o latou o `self` ma `next`, ina ia mautinoa faʻavasegaina o vaega uma e lua.
    ///
    /// Toe foi `Ok((k, offset))`, lea `k` o le faatulagaga o le faamaumauga concatenated ma `offset` o le nofoaga o le aiga, i bytes, o le amataga o le `next` tamau i totonu o le faamaumauga concatenated (o le faalialiavale o le faamaumauga lava ia e amata i le aveesea 0).
    ///
    ///
    /// I luga o le arithmetic overflow, faʻafoʻi `LayoutError`.
    ///
    /// # Examples
    ///
    /// Le fuafuaina o le faʻatulagaina o le `#[repr(C)]` fausaga ma faʻasologa o fanua mai ona fanua 'faʻataʻatiaga:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Manatua ia faʻamaeʻaina ma `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // tofotofoga e galue
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Faia ai se faatulagaga o loo faamatalaina ai le faamaumauga mo `n` tulaga o `self`, ma e leai se padding i le va o se faataitaiga taitasi.
    ///
    /// Manatua, e le pei o le `repeat`, `repeat_packed` e le o mautinoa ai o le toe faia o `self` o le a faʻatulaga lelei, tusa lava pe o se faʻataʻitaʻiga o le `self` e fetaui lelei.
    /// I nisi upu, afai o le faʻataʻatiaga na toe faʻafoʻi mai e `repeat_packed` e faʻaaogaina e tufatufa atu ai se faʻavasega, e le o mautinoa o elemeni uma i le laina o le a faʻatulaga lelei.
    ///
    /// I luga o le arithmetic overflow, faʻafoʻi `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Fausia se laʻasaga faʻamatalaina le faʻamaumauga mo `self` sosoʻo ai ma `next` ma leai se faʻaopoopoga padding i le va o le lua.
    /// Talu ai e leai se padding ua faaofiina, e le talafeagai le gatasi o `next`, ma ua lē tuufaatasia *i uma* i le faatulagaga e mafua.
    ///
    ///
    /// I luga o le arithmetic overflow, faʻafoʻi `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Faia ai se faatulagaga o loo faamatalaina ai le faamaumauga mo a `[T; n]`.
    ///
    /// I luga o le arithmetic overflow, faʻafoʻi `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// O faʻavae na tuʻuina atu i le `Layout::from_size_align` poʻo seisi `Layout` fausiaina latou te le faʻamalieina ona faʻamaoniga tusia.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (matou te manaʻomia lenei mea mo lalo ifo o le trait Error)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}