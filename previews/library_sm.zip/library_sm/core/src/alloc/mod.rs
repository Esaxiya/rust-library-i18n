//! Manatu faʻasoa APIs

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// O le `AllocError` mea sese o loʻo faʻailoa mai ai se faʻasoasoaga le aoga e ono mafua mai i le le lava o mea totino poʻo se mea sese pe a tuʻufaʻatasia le tuʻuina mai o finauga ma lenei tagata faʻasoasoa.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (matou te manaʻomia lenei mea mo lalo ifo o le trait Error)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// O le faʻatinoina o le `Allocator` e mafai ona tuʻuina atu, tupu, faʻapipiʻi, ma faʻasoasoa poloka faʻasolitulafono o faʻamatalaga faʻamatalaina ala i le [`Layout`][].
///
/// `Allocator` ua fuafuaina ina ia faatinoina i ZSTs, mau, po o vae atamai ona ua le mafai ona siitia se allocator pei `MyAlloc([u8; N])`, e aunoa ma le faaatoatoaina o le vae i le manatua faasoasoa.
///
/// E le pei o [`GlobalAlloc`][], leai-tele faʻasoaga e faʻatagaina i `Allocator`.
/// Afai e le lagolagoina e le tagata tuʻufaʻatatau lenei mea (pei o le jemalloc) pe toe faʻafoʻi mai se faʻailoga (e pei o `libc::malloc`), e tatau ona maua e le faʻatinoga.
///
/// ### Le taimi nei manatua faasoasoa
///
/// Nisi o metotia manaʻomia le manatuaina poloka ia *taimi nei tuʻuina atu* ala i se faʻasoasoa.O lenei auala e faapea:
///
/// * o le amataga tuatusi mo lena manatua poloka na toe faʻafoʻi mai e [`allocate`], [`grow`], poʻo [`shrink`], ma
///
/// * e le i mulimuli ane deallocated poloka le manatu, i le mea ua lē saʻo deallocated poloka e ala i le pasia e [`deallocate`] pe na suia e ala i le pasia e [`grow`] po [`shrink`] e toe foi `Ok`.
///
/// Afai ua toe foi `grow` po `shrink` `Err`, e tumau pea le faasino pasia aloaia.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Manatu talafeagai
///
/// O nisi o metotia manaʻomia le faʻatulagaina *ofi* a manatua poloka.
/// O le a le uiga mo se faataatiaga e "fit" se auala poloka manatua (po equivalently, mo se manatua poloka e "fit" a faatulagaga) e faapea e tatau ona umia le tulaga nei:
///
/// * O le poloka e tatau ona faʻasoaina i le tutusa tutusa ma [`layout.align()`], ma
///
/// * O le [`layout.size()`] saunia e tatau ona paʻu i le laina `min ..= max`, lea:
///   - `min` o le tele o le faatulagaga sili ona talu ai nei e faaaoga e faasoasoa le poloka, ma
///   - `max` o le lata mai lata mai tele mai [`allocate`], [`grow`], poʻo [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Manatu poloka toe foʻi mai se faʻasoasoa tatau tatau ona faʻasino i aoga manatua ma taofi lo latou aoga seʻia oʻo i le faʻataʻitaʻiga ma uma o ona faʻavasega ua paʻuʻu,
///
/// * cloning poʻo le faʻagaioia o le tufatufaina atu e le tatau ona faʻaleaogaina poloka manatua toe foʻi mai lenei tagata faʻasoa.E tatau ona amio le tagata tufatufaina faʻamau e pei o le tagata e tuʻuina atu, ma
///
/// * soʻo se faʻasino i le poloka manatua o le [*currently allocated*] e mafai ona pasi i seisi lava auala a le tagata e tuʻuina atu.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Taumafai e faʻasoa se poloka o manatua.
    ///
    /// I luga o le manuia, toe faafoi se [`NonNull<[u8]>`][NonNull] fonotaga i le lapoʻa ma gafatia faʻamaoniga o `layout`.
    ///
    /// O le mafai ona i ai poloka toe foi a tele tele atu nai lo faamaoti mai e `layout.size()`, ma e mafai pe le mafai foi i ai initialized ai i totonu.
    ///
    /// # Errors
    ///
    /// Toe foi `Err` faailoa mai ai pe manatua o le vaivai po o le faamalieina `layout` tele a allocator po constraints aafia i lenei suiga.
    ///
    /// O loʻo faʻamalosia pea le faʻatinoina o galuega e toe faʻafoʻi le `Err` ile manatuaina o le tino nai lo le popolevale poʻo le faʻamutaina o le tino, ae le ose mea faigata lea.
    /// (Faʻapitoa: e *faʻatulafonoina* le faʻatinoina o lenei trait i luga o le faʻavae o le vaegatonu faʻatulagaina faletusi e toʻaga i le manatuaina lelava.)
    ///
    /// Ua uunaia tagata e faaaogāina auaunaga e mananao e abort fuafuaina i le tali atu i se mea sese faasoasoa atu i taʻua o le galuega tauave [`handle_alloc_error`], nai lo le aumaia tuusao `panic!` po faapena.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Behaves pei o `allocate`, ae ia mautinoa foʻi o le toe faʻamanatuina e leai se amataga.
    ///
    /// # Errors
    ///
    /// Toe foi `Err` faailoa mai ai pe manatua o le vaivai po o le faamalieina `layout` tele a allocator po constraints aafia i lenei suiga.
    ///
    /// O loʻo faʻamalosia pea le faʻatinoina o galuega e toe faʻafoʻi le `Err` ile manatuaina o le tino nai lo le popolevale poʻo le faʻamutaina o le tino, ae le ose mea faigata lea.
    /// (Faʻapitoa: e *faʻatulafonoina* le faʻatinoina o lenei trait i luga o le faʻavae o le vaegatonu faʻatulagaina faletusi e toʻaga i le manatuaina lelava.)
    ///
    /// Ua uunaia tagata e faaaogāina auaunaga e mananao e abort fuafuaina i le tali atu i se mea sese faasoasoa atu i taʻua o le galuega tauave [`handle_alloc_error`], nai lo le aumaia tuusao `panic!` po faapena.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // SAFETY: `alloc` toe faafoi se aoga manatua poloka
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Deallocates le manatu taʻua e `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` tatau ona faʻailoa se poloka o manatua [*currently allocated*] ala i lenei faʻasoasoa atu, ma
    /// * `layout` tatau [*fit*] lena poloka o manatua.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Taumafai e faʻalautele le poloka manatua.
    ///
    /// Faʻafoʻi mai se [`NonNull<[u8]>`][NonNull] fou o loʻo iai se faʻasino tusi ma le tele o le mea na tuʻuina atu e manatua ai.O le faʻasino tusi e talafeagai mo le taofiofia faʻamatalaga faʻamatalaina e `new_layout`.
    /// Ina ia ausia lenei mea, o le tagata tufatufaina atu ono faʻalauteleina le faʻasoaga faʻasino e `ptr` ia ofi ai le faʻatulagaina fou.
    ///
    /// Afai o lenei toe faafoi `Ok`, o lona uiga o le umiaina o le manatua poloka faʻasino e `ptr` ua faʻaliliuina atu i lenei faasoasoa.
    /// O le mafaufau atonu pe sa mafai foi ona faʻasaʻolotoina, ma e tatau ona manatu e le faʻaogaina seʻi vagana ua toe faʻafoʻi atu i le tagata telefoni e ala i le toe faʻatauaina o lenei metotia.
    ///
    /// Afai o lenei metotia faʻafoʻi `Err`, o lona uiga o le umiaina o le manatuaina poloka e leʻi tuʻuina atu i lenei faʻasoasoa, ma mea o loʻo iai i le poloka manatua e le suia.
    ///
    /// # Safety
    ///
    /// * `ptr` tatau ona faʻailoa se poloka o manatua [*currently allocated*] ala i lenei faʻasoasoa.
    /// * `old_layout` tatau [*fit*] poloka o manatua (O le `new_layout` finauga le manaʻomia ona ofi ai.).
    /// * `new_layout.size()` tatau ona sili atu pe tutusa i le `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Faʻafoʻi `Err` pe a fai o le faʻavae fou e le ausia le aofaʻi o le tufatufaina ma faʻafetauiina tapulaʻa a le tagata tuʻuina atu, pe a fai o le tuputupu aʻe ua le mafai.
    ///
    /// O loʻo faʻamalosia pea le faʻatinoina o galuega e toe faʻafoʻi le `Err` ile manatuaina o le tino nai lo le popolevale poʻo le faʻamutaina o le tino, ae le ose mea faigata lea.
    /// (Faʻapitoa: e *faʻatulafonoina* le faʻatinoina o lenei trait i luga o le faʻavae o le vaegatonu faʻatulagaina faletusi e toʻaga i le manatuaina lelava.)
    ///
    /// Ua uunaia tagata e faaaogāina auaunaga e mananao e abort fuafuaina i le tali atu i se mea sese faasoasoa atu i taʻua o le galuega tauave [`handle_alloc_error`], nai lo le aumaia tuusao `panic!` po faapena.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SAOGALEMU: ona tatau ona sili atu nai lo pe tutusa `new_layout.size()` e
        // `old_layout.size()`, uma tuai ma faasoasoa fou manatua e aoga mo le faitauina ma tusia mo bytes `old_layout.size()`.
        // E le gata i lea, talu ai o le tuai vaegatupe e leʻi maeʻa faʻasoasoaina, e le mafai ona soʻosoʻo `new_ptr`.
        // O lea la, o le valaʻau i le `copy_nonoverlapping` e sefe.
        // O le saogalemu konekarate mo `dealloc` tatau ona lagolagoina e le telefoni.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Behaves pei o `grow`, ae ia mautinoa foi o mea fou ua setiina i le zero ao le i toe faʻafoʻi mai.
    ///
    /// O le poloka manatua o le a aofia ai mea mulimuli mai pe a maeʻa se valaʻaulia manuia i
    /// `grow_zeroed`:
    ///   * Bytes `0..old_layout.size()` e faʻasaoina mai le uluaʻi faʻasoaga.
    ///   * Bytes `old_layout.size()..old_size` o le a faʻasao pe leai, faʻalagolago i le faʻasoaga faʻatinoina.
    ///   `old_size` e faʻasino ile tele ole poloka o mea e manatua a o le i oʻo ile telefoni ole `grow_zeroed`, lea e ono sili atu le lapoʻa nai lo le tele na muamua talosagaina ina ua tuʻuina iai.
    ///   * Bytes `old_size..new_size` ua leai se aoga.`new_size` loo faasino i le tele o le manatu poloka toe foi i le valaau `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` tatau ona faʻailoa se poloka o manatua [*currently allocated*] ala i lenei faʻasoasoa.
    /// * `old_layout` tatau [*fit*] poloka o manatua (O le `new_layout` finauga le manaʻomia ona ofi ai.).
    /// * `new_layout.size()` tatau ona sili atu pe tutusa i le `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Faʻafoʻi `Err` pe a fai o le faʻavae fou e le ausia le aofaʻi o le tufatufaina ma faʻafetauiina tapulaʻa a le tagata tuʻuina atu, pe a fai o le tuputupu aʻe ua le mafai.
    ///
    /// O loʻo faʻamalosia pea le faʻatinoina o galuega e toe faʻafoʻi le `Err` ile manatuaina o le tino nai lo le popolevale poʻo le faʻamutaina o le tino, ae le ose mea faigata lea.
    /// (Faʻapitoa: e *faʻatulafonoina* le faʻatinoina o lenei trait i luga o le faʻavae o le vaegatonu faʻatulagaina faletusi e toʻaga i le manatuaina lelava.)
    ///
    /// Ua uunaia tagata e faaaogāina auaunaga e mananao e abort fuafuaina i le tali atu i se mea sese faasoasoa atu i taʻua o le galuega tauave [`handle_alloc_error`], nai lo le aumaia tuusao `panic!` po faapena.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // SAOGALEMU: ona tatau ona sili atu nai lo pe tutusa `new_layout.size()` e
        // `old_layout.size()`, uma tuai ma faasoasoa fou manatua e aoga mo le faitauina ma tusia mo bytes `old_layout.size()`.
        // E le gata i lea, talu ai o le tuai vaegatupe e leʻi maeʻa faʻasoasoaina, e le mafai ona soʻosoʻo `new_ptr`.
        // O lea la, o le valaʻau i le `copy_nonoverlapping` e sefe.
        // O le saogalemu konekarate mo `dealloc` tatau ona lagolagoina e le telefoni.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Taumafai e tuuitiitia le poloka manatua.
    ///
    /// Faʻafoʻi mai se [`NonNull<[u8]>`][NonNull] fou o loʻo iai se faʻasino tusi ma le tele o le mea na tuʻuina atu e manatua ai.O le faʻasino tusi e talafeagai mo le taofiofia faʻamatalaga faʻamatalaina e `new_layout`.
    /// Ina ia ausia lenei mea, o le allocator mafai ona taofia e le faasoasoaina taʻua e `ptr` ina ia fetaui ma le faatulagaga fou.
    ///
    /// Afai o lenei toe faafoi `Ok`, o lona uiga o le umiaina o le manatua poloka faʻasino e `ptr` ua faʻaliliuina atu i lenei faasoasoa.
    /// O le mafaufau atonu pe sa mafai foi ona faʻasaʻolotoina, ma e tatau ona manatu e le faʻaogaina seʻi vagana ua toe faʻafoʻi atu i le tagata telefoni e ala i le toe faʻatauaina o lenei metotia.
    ///
    /// Afai o lenei metotia faʻafoʻi `Err`, o lona uiga o le umiaina o le manatuaina poloka e leʻi tuʻuina atu i lenei faʻasoasoa, ma mea o loʻo iai i le poloka manatua e le suia.
    ///
    /// # Safety
    ///
    /// * `ptr` tatau ona faʻailoa se poloka o manatua [*currently allocated*] ala i lenei faʻasoasoa.
    /// * `old_layout` tatau [*fit*] poloka o manatua (O le `new_layout` finauga le manaʻomia ona ofi ai.).
    /// * `new_layout.size()` tatau ona laʻititi atu pe tutusa i le `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Faafoi `Err` pe afai o le fou faatulagaga e le ausia le tele o le allocator ma constraints gatasi o le allocator, po o pe afai e vaivai ese ua le mafai.
    ///
    /// O loʻo faʻamalosia pea le faʻatinoina o galuega e toe faʻafoʻi le `Err` ile manatuaina o le tino nai lo le popolevale poʻo le faʻamutaina o le tino, ae le ose mea faigata lea.
    /// (Faʻapitoa: e *faʻatulafonoina* le faʻatinoina o lenei trait i luga o le faʻavae o le vaegatonu faʻatulagaina faletusi e toʻaga i le manatuaina lelava.)
    ///
    /// Ua uunaia tagata e faaaogāina auaunaga e mananao e abort fuafuaina i le tali atu i se mea sese faasoasoa atu i taʻua o le galuega tauave [`handle_alloc_error`], nai lo le aumaia tuusao `panic!` po faapena.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SAFETY: aua `new_layout.size()` tatau ona maualalo ifo pe tutusa i le
        // `old_layout.size()`, uma tuai ma faasoasoa fou manatua e aoga mo le faitauina ma tusia mo bytes `new_layout.size()`.
        // E le gata i lea, talu ai o le tuai vaegatupe e leʻi maeʻa faʻasoasoaina, e le mafai ona soʻosoʻo `new_ptr`.
        // O lea la, o le valaʻau i le `copy_nonoverlapping` e sefe.
        // O le saogalemu konekarate mo `dealloc` tatau ona lagolagoina e le telefoni.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Fausia se "by reference" adapter mo lenei faʻataʻitaʻiga o `Allocator`.
    ///
    /// O le toe faʻaoga mea faʻaoga e faʻaoga foi `Allocator` ma e na o le nonoina lava o lenei.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // SAFETY: o le saogalemu konekarate tatau ona lagolagoina e le telefoni
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SAFETY: o le saogalemu konekarate tatau ona lagolagoina e le telefoni
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SAFETY: o le saogalemu konekarate tatau ona lagolagoina e le telefoni
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SAFETY: o le saogalemu konekarate tatau ona lagolagoina e le telefoni
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}