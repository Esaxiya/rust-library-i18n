//! O se vaega mo le galue ma nono faʻamatalaga.

#![stable(feature = "rust1", since = "1.0.0")]

/// A trait mo le nonoina o faʻamatalaga.
///
/// I Rust, e masani ona maua ai faamatalaga eseese o se ituaiga mo tulaga eseese faaaogaina.
/// Mo se faataitaiga, teuina nofoaga ma le pulega ona e le mafai ona filifilia faapitoa se taua pe a talafeagai ai mo le a faaaogaina faapitoa e ala i ituaiga e faasino ai e pei o [`Box<T>`] po [`Rc<T>`].
/// Ese mai i nei fusi manuʻa ua taatitia lautele e mafai ona faaaoga i so o se ituaiga, o nisi ituaiga tuuina pule oe pe fai vaega tuuina functionality ono taugata.
/// Se faataitaiga mo ituaiga a pei o [`String`] lea faaopoopo le tomai e tuuina atu se manoa i le [`str`] faavae.
/// Lenei e manaʻomia le taofia faʻaopoopo faʻamatalaga le manaʻomia mo se faigofie, e le suia lava manoa.
///
/// O nei ituaiga faʻaavanoaina avanoa i le autu faʻamatalaga e ala i faʻasino i le ituaiga o na faʻamatalaga.ua fai mai i latou e avea ma 'nono e pei' o le ituaiga.
/// Mo se faʻataʻitaʻiga, o le [`Box<T>`] e mafai ona nonoina o le `T` ae o le [`String`] e mafai ona nonoina e avea ma `str`.
///
/// Ituaiga faʻailoa mai e mafai ona nonoina latou o ni ituaiga `T` e ala i le faʻatinoina o le `Borrow<T>`, ma tuʻuina atu ai se faʻasino i le `T` i le trait's [`borrow`] auala.O se ituaiga e saoloto e nonoina o ni nai eseʻese ituaiga.
/// Afai e manaʻo e ono sui aitalafu e pei o le ituaiga-faʻatagaina le faʻavaeina o faʻamatalaga e toe teuteuina, e mafai faʻapipiʻi faʻaaoga [`BorrowMut<T>`].
///
/// E le gata i lea, pe a tuʻuina atu faʻatonuga mo faʻaopopo traits, e manaʻomia le iloiloina pe tatau ona latou amio tutusa ma i latou o le autu autu o se faʻaiuga o le avea o se sui o lena autu autu.
/// Generic code masani lava ona faʻaaogaina le `Borrow<T>` pe a faʻamoemoe i amioga tutusa a nei faʻaopopo trait faʻatinoina.
/// a ono foliga mai nei traits pei faaopoopo trait bounds.
///
/// Aemaise `Eq`, e tatau ona tutusa `Ord` ma `Hash` mo tulaga faatauaina nono ma umia: e tatau ona tuuina atu `x.borrow() == y.borrow()` le taunuuga lava e tasi e pei `x == y`.
///
/// Afai e manaomia e le na code lautele i le galuega mo ituaiga uma e mafai ona maua ai se faasinomaga e fesootai ituaiga `T`, e masani lava e sili atu e faaaoga [`AsRef<T>`] e sili ituaiga e mafai ona saogalemu faatino ai.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// I le avea ai o se faʻamatalaga aoina, [`HashMap<K, V>`] umiaina uma ki ma faʻatauaina.A faʻapea o le ki o faʻamaumauga moni o loʻo afifiina i se ituaiga faʻatonutonuina o se ituaiga, e tatau, peitaʻi, e mafai lava ona sailia se taua faʻaaogaina se faʻasino i le ki o faʻamaumauga.
/// Mo se faʻataʻitaʻiga, afai o le ki o se manoa, o lona uiga e ono teuina ma le faʻafanua hash o se [`String`], ao mafai ona mafai ona suʻe faʻaaoga le [`&str`][`str`].
/// O lea la, `insert` manaʻomia galue i luga o le `String` ao `get` manaʻomia mafai ona mafai ona faʻaaoga se `&str`.
///
/// Faʻafaigofieina, o vaega talafeagai o le `HashMap<K, V>` foliga faʻapea:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // fanua aveʻesea
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// O le atoa hash faʻafanua e lautele i luga o le autu ituaiga `K`.Talu ai o nei ki o loʻo teuina ile faʻafanua o le hash, o lenei ituaiga e tatau ona ia latou ki o faʻamaumauga.
/// A o faʻaofiina se ki-taua ulugaliʻi, o le faʻafanua o loʻo tuʻuina atu ia `K` ma e manaʻomia le sailia o le sao haset pakete ma siaki pe o le ki ua leva ona faʻavae i luga o lena `K`.O le mea lea manaʻomia `K: Hash + Eq`.
///
/// Ina ua saili mo se taua i le faafanua, ae peitai, ua e tuuina atu se faasinomaga i se `K` o le ki i le saili mo le a manaomia e fatu ai i taimi uma o se taua umia.
/// Mo ki manoa, o le a le uiga o lenei manaomia se taua `String` e faia mo na o le sailiga o le tulaga e na maua a `str` o.
///
/// Nai lo lena, o le lautele o le auala `get` i luga o le ituaiga o le faamatalaga autu faavae, na taʻua `Q` i le auala e saini i luga.O loo faapea mai borrows `K` o se `Q` e manaomia ai e faapea `K: Borrow<Q>`.
/// I se faʻaopopoga manaʻomia `Q: Hash + Eq`, o loʻo faʻaalia ai le manaʻoga o `K` ma `Q` i ai faʻatinoina o le `Hash` ma `Eq` traits o loʻo maua ai iʻuga tutusa.
///
/// O le faʻatinoina o le `get` faʻamoemoe faapitoa i luga o le tutusa faʻatinoina o `Hash` e ala i le fuafuaina o le ki o le pakete kesi i le valaʻau `Hash::hash` i luga o le `Q` aoga e ui lava na tuʻuina i lalo le ki faʻavae i luga o le hash aoga fuafuaina mai le `K` taua.
///
///
/// O se taunuuga, o le malologa faafanua asa pe afai e tuuina atu e se afifi `K` a taua `Q` a asa ese `Q`.Mo se faʻataʻitaʻiga, mafaufau e iai sau ituaiga o afifi se manoa ae faʻatusatusa tusi ASCII le amanaʻiaina o latou tulaga:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Talu ai e lua tau tutusa e manaʻomia le gaosia o le tutusa hash taua, o le faʻatinoina o le `Hash` manaʻomia le le amanaʻiaina le ASCII mataupu, faʻapea foi:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Mafai e `CaseInsensitiveString` faʻaoga `Borrow<str>`?E mautinoa lava mafai ona maua ai se faʻasino i se manoa fasi ala ala i lona aofia ai manoa.
/// Ae talu ai ona o lona `Hash` faʻatinoga e eseʻese, e ese a latou amio mai le `str` ma o le mea lea e le tatau ai, o le mea moni, faʻatino `Borrow<str>`.
/// Afai e manaʻo e faʻatagaina isi avanoa i le `str` faʻavae, e mafai ona ia faia e ala i le `AsRef<str>` e le o iai ni manaʻoga faʻaopoopo.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Faʻaletupe e le masuia mai se tau aoga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// A trait mo le nonoina mutably faamatalaga.
///
/// O se soa e [`Borrow<T>`] faatagaina lenei trait se ituaiga e nono o se ituaiga faavae i le tuuina atu o se faasinomaga mutable.
/// Vaʻai [`Borrow<T>`] mo nisi faʻamatalaga i le nonoina o seisi ituaiga.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Fetuutuunai nonoina mai se tau taua.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}