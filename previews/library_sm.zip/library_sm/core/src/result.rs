//! Sese faʻatautaia ma le `Result` ituaiga.
//!
//! [`Result<T, E>`][`Result`] o le ituaiga faʻaaogaina mo le toe foʻi ma faʻalauteleina mea sese.
//! O se enum ma fesuiaʻiga, [`Ok(T)`], o loʻo avea ma se tulaga manuia ma o loʻo iai se tau, ma le [`Err(E)`], o loʻo fai ma sui o mea sese ma o loʻo iai se faʻailoga taua.
//!
//! ```
//! # #[allow(dead_code)]
//! enum Result<T, E> {
//!    Ok(T),
//!    Err(E),
//! }
//! ```
//!
//! Galuega tauave toe foi [`Result`] soo se taimi lava e tatau ma toe faaolaina mea sese.I le `std` crate, [`Result`] e sili ona lauiloa faʻaaoga mo [I/O](../../std/io/index.html).
//!
//! mafai ona faamatalaina se galuega tauave faigofie le toe foi [`Result`] ma faaaogaina e pei o le:
//!
//! ```
//! #[derive(Debug)]
//! enum Version { Version1, Version2 }
//!
//! fn parse_version(header: &[u8]) -> Result<Version, &'static str> {
//!     match header.get(0) {
//!         None => Err("invalid header length"),
//!         Some(&1) => Ok(Version::Version1),
//!         Some(&2) => Ok(Version::Version2),
//!         Some(_) => Err("invalid version"),
//!     }
//! }
//!
//! let version = parse_version(&[1, 2, 3, 4]);
//! match version {
//!     Ok(v) => println!("working with version: {:?}", v),
//!     Err(e) => println!("error parsing header: {:?}", e),
//! }
//! ```
//!
//! Mamanu fetaui i luga o le "Result`] e manino ma tuusaʻo mo faigofie mataupu, ae o le [`Result`] e o mai ma nisi faigofie auala e faʻafaigofie ai ona galulue faʻatasi ma ia.
//!
//! ```
//! let good_result: Result<i32, i32> = Ok(10);
//! let bad_result: Result<i32, i32> = Err(10);
//!
//! // O `is_ok` ma `is_err` metotia faia mea na latou fai mai ai.
//! assert!(good_result.is_ok() && !good_result.is_err());
//! assert!(bad_result.is_err() && !bad_result.is_ok());
//!
//! // `map` faʻaumatia le `Result` ma maua ai le isi.
//! let good_result: Result<i32, i32> = good_result.map(|i| i + 1);
//! let bad_result: Result<i32, i32> = bad_result.map(|i| i - 1);
//!
//! // Faʻaaoga le `and_then` e faʻaauau ai le faitauga.
//! let good_result: Result<bool, i32> = good_result.and_then(|i| Ok(i == 11));
//!
//! // Faʻaaoga le `or_else` e faʻatautaia ai le mea sese.
//! let bad_result: Result<i32, i32> = bad_result.or_else(|i| Ok(i + 20));
//!
//! // Faʻauma le iʻuga ma toe faʻafoʻi mea i le `unwrap`.
//! let final_awesome_result = good_result.unwrap();
//! ```
//!
//! # Iuga e tatau ona faʻaaogaina
//!
//! O se faafitauli ua laugatasia ai i le faaaogaina o tulaga faatauaina o le toe foi e faailoa mea sese e faapea e faigofie lava ona le amanaiaina le toe foi mai le taua, ua faapea ona lē mafai ona taulimaina le mea sese.
//! [`Result`] ua annotated faatasi ma le uiga `#[must_use]`, lea o le a faia ai e le tuufaatasia ona tuuina atu se lapataiga pe a taua Taunuuga ua le amanaiaina.
//! O lenei mea [`Result`] sili ona aoga ma gaioiga e ono fetaiaʻi ma mea sese ae le o le faʻafoʻi mai se aoga aoga.
//!
//! Mafaufau i le [`write_all`] metotia faʻamatalaina mo I/O ituaiga e le [`Write`] trait:
//!
//! ```
//! use std::io;
//!
//! trait Write {
//!     fn write_all(&mut self, bytes: &[u8]) -> Result<(), io::Error>;
//! }
//! ```
//!
//! *Note: O le faʻauigaina moni o le [`Write`] faʻaaogaina le [`io::Result`], ua naʻo se upu uiga tutusa mo le (`Iʻuga ']'<T,`[`io: :Error`]`>...*
//!
//! O lenei metotia e le maua ai se tau, ae atonu e le manuia le tusi.E taua tele le taulimaina o le mea sese, ma *le* tusi se mea faʻapea:
//!
//! ```no_run
//! # #![allow(unused_must_use)] // \o/
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! // Afai e sese `write_all`, ona tatou le iloa lea, aua o le toe faʻafoi taua e le amanaʻiaina.
//! //
//! file.write_all(b"important message");
//! ```
//!
//! Afai oe *faia* tusia lena mea i le Rust, o le tuʻufaʻatasia o le a avatua ia te oe se lapataʻiga (e ala i le le masani ai, faʻatonutonu e le `unused_must_use` lint).
//!
//! Oe ono faʻapea, afai e te le manaʻo e taulima le mea sese, na ona faʻailoa mai o le manuia ile [`expect`].
//! O lenei finagalo panic pe afai e lē mafai e le tusi, tuuina atu o se savali marginally aoga e faailoa ai:
//!
//! ```no_run
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! file.write_all(b"important message").expect("failed to write message");
//! ```
//!
//! Atonu e te faʻamaonia foʻi le manuia:
//!
//! ```no_run
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # let mut file = File::create("valuable_data.txt").unwrap();
//! assert!(file.write_all(b"important message").is_ok());
//! ```
//!
//! Pe faʻasalalau le mea sese luga o le valaʻau faaputuga ma [`?`]:
//!
//! ```
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # use std::io;
//! # #[allow(dead_code)]
//! fn write_message() -> io::Result<()> {
//!     let mut file = File::create("valuable_data.txt")?;
//!     file.write_all(b"important message")?;
//!     Ok(())
//! }
//! ```
//!
//! # Le faagaoioia faailoga fesili, `?`
//!
//! A o tusia le numera e valaʻau ai le tele o gaioiga e toe faʻafoʻi mai le [`Result`] ituaiga, o le sese ona tagofia e ono faigata tele.
//! O le fesili fesili tagata faʻagaioia, [`?`], natia nisi o le boilerplate o faʻalauteleina mea sese luga o le valaʻau faaputuga.
//!
//! Ua suia le mea lea:
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     // Faʻafoʻi vave ile sese
//!     let mut file = match File::create("my_best_friends.txt") {
//!            Err(e) => return Err(e),
//!            Ok(f) => f,
//!     };
//!     if let Err(e) = file.write_all(format!("name: {}\n", info.name).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("age: {}\n", info.age).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("rating: {}\n", info.rating).as_bytes()) {
//!         return Err(e)
//!     }
//!     Ok(())
//! }
//! ```
//!
//! Faatasi ai ma lenei:
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     let mut file = File::create("my_best_friends.txt")?;
//!     // Faʻafoʻi vave ile sese
//!     file.write_all(format!("name: {}\n", info.name).as_bytes())?;
//!     file.write_all(format!("age: {}\n", info.age).as_bytes())?;
//!     file.write_all(format!("rating: {}\n", info.rating).as_bytes())?;
//!     Ok(())
//! }
//! ```
//!
//! *E sili atu le manaia!*
//!
//! O le faʻaiʻuina o le faʻaaliga ma le [`?`] o le a iʻu ai i le faʻamauina le aoga ([`Ok`]) taua, seʻi vagana o le iʻuga o le [`Err`], ma o le mea lea [`Err`] na toe faʻafoʻi mai i le amataga mai le enclosed function.
//!
//!
//! [`?`] faʻatoa mafai ona faʻaaogaina i gaioiga e toe faafoʻi [`Result`] ona o le vave toe foʻi mai o [`Err`] o loʻo maua ai.
//!
//! [`expect`]: Result::expect
//! [`Write`]: ../../std/io/trait.Write.html
//! [`write_all`]: ../../std/io/trait.Write.html#method.write_all
//! [`io::Result`]: ../../std/io/type.Result.html
//! [`?`]: crate::ops::Try
//! [`Ok(T)`]: Ok
//! [`Err(E)`]: Err
//! [`io::Error`]: ../../std/io/struct.Error.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{self, FromIterator, FusedIterator, TrustedLen};
use crate::ops::{self, Deref, DerefMut};
use crate::{convert, fmt, hint};

/// `Result` o se ituaiga e faʻalia le manuia ([`Ok`]) poʻo le toilalo ([`Err`]).
///
/// Tagai i le [module documentation](self) mo faamatalaga auiliili.
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[must_use = "this `Result` may be an `Err` variant, which should be handled"]
#[rustc_diagnostic_item = "result_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Result<T, E> {
    /// O loo i ai le taua manuia
    #[lang = "Ok"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Ok(#[stable(feature = "rust1", since = "1.0.0")] T),

    /// Aofia ai le aoga ole mea sese
    #[lang = "Err"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Err(#[stable(feature = "rust1", since = "1.0.0")] E),
}

/////////////////////////////////////////////////////////////////////////////
// Faʻatinoina faʻatinoga
/////////////////////////////////////////////////////////////////////////////

impl<T, E> Result<T, E> {
    /////////////////////////////////////////////////////////////////////////
    // Fesili ile aoga o loʻo iai
    /////////////////////////////////////////////////////////////////////////

    /// Toe foi `true` pe afai o le taunuuga o [`Ok`].
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_ok(), true);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_ok(), false);
    /// ```
    #[must_use = "if you intended to assert that this is ok, consider `.unwrap()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_ok(&self) -> bool {
        matches!(*self, Ok(_))
    }

    /// Toe foi `true` pe afai o le taunuuga o [`Err`].
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_err(), false);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_err(), true);
    /// ```
    #[must_use = "if you intended to assert that this is err, consider `.unwrap_err()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_err(&self) -> bool {
        !self.is_ok()
    }

    /// Faʻafoʻi `true` pe a fai o le iʻuga o le [`Ok`] taua o loʻo iai le aofaʻi taua.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Result<u32, &str> = Ok(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Ok(y) => x == y,
            Err(_) => false,
        }
    }

    /// Faafoi `true` pe afai o le taunuuga o se taua [`Err`] o loo i le taua na tuuina mai.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_contains_err)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains_err(&"Some error message"), true);
    ///
    /// let x: Result<u32, &str> = Err("Some other error message");
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "result_contains_err", issue = "62358")]
    pub fn contains_err<F>(&self, f: &F) -> bool
    where
        F: PartialEq<E>,
    {
        match self {
            Ok(_) => false,
            Err(e) => f == e,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Mea faʻatatau mo variant taitasi
    /////////////////////////////////////////////////////////////////////////

    /// Tagata liliu mai mai `Result<T, E>` i le [`Option<T>`].
    ///
    /// Faʻaliliu `self` i totonu o le [`Option<T>`], faʻaumatia `self`, ma tiaʻi le mea sese, pe a fai e i ai.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.ok(), Some(2));
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.ok(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok(self) -> Option<T> {
        match self {
            Ok(x) => Some(x),
            Err(_) => None,
        }
    }

    /// Tagata liliu mai mai `Result<T, E>` i le [`Option<E>`].
    ///
    /// Tagata Liliu `self` i se [`Option<E>`], taumafaina `self`, ma discarding le taua le manuia, pe afai ei ai.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.err(), None);
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.err(), Some("Nothing here"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn err(self) -> Option<E> {
        match self {
            Ok(_) => None,
            Err(x) => Some(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Adaptor mo le galue ma faʻamatalaga
    /////////////////////////////////////////////////////////////////////////

    /// Tagata liliu mai mai `&Result<T, E>` i le `Result<&T, &E>`.
    ///
    /// Fausia se `Result` fou, o loʻo iai se faʻasino i le uluaʻi pepa, ae tuʻu le uluaʻi nofoaga i le nofoaga.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.as_ref(), Ok(&2));
    ///
    /// let x: Result<u32, &str> = Err("Error");
    /// assert_eq!(x.as_ref(), Err(&"Error"));
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Result<&T, &E> {
        match *self {
            Ok(ref x) => Ok(x),
            Err(ref x) => Err(x),
        }
    }

    /// Liliu mai `&mut Result<T, E>` e `Result<&mut T, &mut E>`.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// fn mutate(r: &mut Result<i32, i32>) {
    ///     match r.as_mut() {
    ///         Ok(v) => *v = 42,
    ///         Err(e) => *e = 0,
    ///     }
    /// }
    ///
    /// let mut x: Result<i32, i32> = Ok(2);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap(), 42);
    ///
    /// let mut x: Result<i32, i32> = Err(13);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap_err(), 0);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Result<&mut T, &mut E> {
        match *self {
            Ok(ref mut x) => Ok(x),
            Err(ref mut x) => Err(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Suiga aofia ai tulaga taua
    /////////////////////////////////////////////////////////////////////////

    /// Taialaina ai a `Result<T, E>` e `Result<U, E>` ala i le faaaogaina o se galuega tauave i se o loo [`Ok`] taua, ma tuua ai se taua [`Err`] untouched.
    ///
    ///
    /// Lenei gaioiga mafai ona faʻaaogaina e tusia ai iʻuga o lua galuega.
    ///
    /// # Examples
    ///
    /// Lolomi numera i laina taʻitasi o se manoa faʻateleina i le lua.
    ///
    /// ```
    /// let line = "1\n2\n3\n4\n";
    ///
    /// for num in line.lines() {
    ///     match num.parse::<i32>().map(|i| i * 2) {
    ///         Ok(n) => println!("{}", n),
    ///         Err(..) => {}
    ///     }
    /// }
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => Ok(op(t)),
            Err(e) => Err(e),
        }
    }

    /// Faʻaaogaina se gaioiga i le aofia ai taua (pe a fai o [`Ok`]), pe faʻafoʻi le aiaia saunia (pe a [`Err`]).
    ///
    /// O finauga na pasi i le `map_or` o loʻo vaʻai totoʻa iai;pe afai e te le tufaina o le taunuuga o se valaau galuega tauave, ua fautuaina e faaaoga [`map_or_else`], lea ua lazily iloiloina.
    ///
    ///
    /// [`map_or_else`]: Result::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or", since = "1.41.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(_) => default,
        }
    }

    /// Maps a `Result<T, E>` e `U` ala i le faaaogaina o se galuega tauave i se o loo [`Ok`] taua, po o se galuega tauave fallback i se o loo [`Err`] taua.
    ///
    ///
    /// O lenei galuega e mafai ona faaaoga e suʻe se taunuuga faamanuiaina ao le taulimaina o se mea sese.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x : Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 3);
    ///
    /// let x : Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 42);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or_else", since = "1.41.0")]
    pub fn map_or_else<U, D: FnOnce(E) -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(e) => default(e),
        }
    }

    /// Faʻafanua le `Result<T, E>` i le `Result<T, F>` i le faʻaogaina o se gaioiga i le aofaʻi o le [`Err`], ma tuua ai le [`Ok`] le aoga e leʻi tago i ai.
    ///
    ///
    /// Lenei gaioiga mafai ona faʻaaogaina e pasi ai i se manuia taunuʻuga a o tagofia se mea sese.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// fn stringify(x: u32) -> String { format!("error code: {}", x) }
    ///
    /// let x: Result<u32, u32> = Ok(2);
    /// assert_eq!(x.map_err(stringify), Ok(2));
    ///
    /// let x: Result<u32, u32> = Err(13);
    /// assert_eq!(x.map_err(stringify), Err("error code: 13".to_string()));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_err<F, O: FnOnce(E) -> F>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => Err(op(e)),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Fausiaina Iterator
    /////////////////////////////////////////////////////////////////////////

    /// Faʻafoʻi mai se faʻamaufaʻailoga luga o le ono aofia ai tau.
    ///
    /// O le mea faʻasolosolo e maua se tasi taua pe a fai o le iʻuga o le [`Result::Ok`], a leai e leai se mea.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(7);
    /// assert_eq!(x.iter().next(), Some(&7));
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { inner: self.as_ref().ok() }
    }

    /// Faʻafoʻi mai se suiga i luga ole tau talafeagai.
    ///
    /// O le mea faʻasolosolo e maua se tasi taua pe a fai o le iʻuga o le [`Result::Ok`], a leai e leai se mea.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let mut x: Result<u32, &str> = Ok(7);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 40,
    ///     None => {},
    /// }
    /// assert_eq!(x, Ok(40));
    ///
    /// let mut x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: self.as_mut().ok() }
    }

    ////////////////////////////////////////////////////////////////////////
    // Boolean gaioiga i luga o tulaga taua, naunau ma paie
    /////////////////////////////////////////////////////////////////////////

    /// Faʻafoʻi `res` pe a fai o le iʻuga o [`Ok`], a faʻapea e toe faʻafoʻi mai le [`Err`] aoga o `self`.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<&str, &str> = Ok("foo");
    /// assert_eq!(x.and(y), Err("early error"));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("not a 2"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Ok("different result type");
    /// assert_eq!(x.and(y), Ok("different result type"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, res: Result<U, E>) -> Result<U, E> {
        match self {
            Ok(_) => res,
            Err(e) => Err(e),
        }
    }

    /// Valaʻau `op` pe a fai o le iʻuga o [`Ok`], a faʻapea e toe faʻafoʻi le [`Err`] aoga o `self`.
    ///
    ///
    /// O lenei galuega tauave e mafai ona faaaogaina mo le puleaina tafe e faavae i tulaga faatauaina `Result`.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).and_then(sq).and_then(sq), Ok(16));
    /// assert_eq!(Ok(2).and_then(sq).and_then(err), Err(4));
    /// assert_eq!(Ok(2).and_then(err).and_then(sq), Err(2));
    /// assert_eq!(Err(3).and_then(sq).and_then(sq), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Result<U, E>>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => op(t),
            Err(e) => Err(e),
        }
    }

    /// Faʻafoʻi `res` pe a fai o le iʻuga o [`Err`], a faʻapea e toe faʻafoʻi mai le [`Ok`] aoga o `self`.
    ///
    /// o loo iloiloina le naunautai finauga pasia e `or`;afai o loʻo e pasia le iʻuga o le telefoni, e fautuaina e faʻaaoga le [`or_else`], o le e paie ona iloiloina.
    ///
    ///
    /// [`or_else`]: Result::or_else
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Ok(100);
    /// assert_eq!(x.or(y), Ok(2));
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or<F>(self, res: Result<T, F>) -> Result<T, F> {
        match self {
            Ok(v) => Ok(v),
            Err(_) => res,
        }
    }

    /// Valaʻau `op` pe a fai o le iʻuga o [`Err`], a faʻapea e toe faʻafoʻi le [`Ok`] aoga o `self`.
    ///
    ///
    /// Lenei gaioiga mafai ona faʻaaogaina mo pulea tafe faʻavae i luga o taunuʻuga taua.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).or_else(sq).or_else(sq), Ok(2));
    /// assert_eq!(Ok(2).or_else(err).or_else(sq), Ok(2));
    /// assert_eq!(Err(3).or_else(sq).or_else(err), Ok(9));
    /// assert_eq!(Err(3).or_else(err).or_else(err), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F, O: FnOnce(E) -> Result<T, F>>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => op(e),
        }
    }

    /// Faʻafoʻi mai le aofaʻi [`Ok`] aofaʻi poʻo le aiaia saunia.
    ///
    /// O finauga na pasi i le `unwrap_or` o loʻo vaʻai totoʻa iai;afai o loʻo e pasia le iʻuga o le telefoni, e fautuaina e faʻaaoga le [`unwrap_or_else`], o le e paie ona iloiloina.
    ///
    ///
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let default = 2;
    /// let x: Result<u32, &str> = Ok(9);
    /// assert_eq!(x.unwrap_or(default), 9);
    ///
    /// let x: Result<u32, &str> = Err("error");
    /// assert_eq!(x.unwrap_or(default), default);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Ok(t) => t,
            Err(_) => default,
        }
    }

    /// Faʻafoʻi mai le aofaʻi [`Ok`] taua pe faʻatauina mai se tapunia.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// fn count(x: &str) -> usize { x.len() }
    ///
    /// assert_eq!(Ok(2).unwrap_or_else(count), 2);
    /// assert_eq!(Err("foo").unwrap_or_else(count), 3);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce(E) -> T>(self, op: F) -> T {
        match self {
            Ok(t) => t,
            Err(e) => op(e),
        }
    }

    /// Faamatalaga o tupe o lo oi [`Ok`] taua, alu i le taua `self`, e aunoa ma le siakiina o le tulaga faatauaina e le o se [`Err`].
    ///
    ///
    /// # Safety
    ///
    /// Valaʻau lenei metotia luga o le [`Err`] o le *[amioga le faʻamatalaina]*.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, 2);
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// unsafe { x.unwrap_unchecked(); } // Amio le mafaamatalaina!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_ok());
        match self {
            Ok(t) => t,
            // SAOGALEMU: e tatau ona lagolagoina le konekarate le saogalemu e ala i le telefoni.
            Err(_) => unsafe { hint::unreachable_unchecked() },
        }
    }

    /// Faʻafoʻi mai le aofaʻi [`Err`] taua, faʻaumatia le `self` aoga, aunoa ma le siakiina o le tau e le o le [`Ok`].
    ///
    ///
    /// # Safety
    ///
    /// Valaau lenei metotia i se [`Ok`] o * [amioga undefined].
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// unsafe { x.unwrap_err_unchecked() }; // Amio le mafaamatalaina!
    /// ```
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(unsafe { x.unwrap_err_unchecked() }, "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_err_unchecked(self) -> E {
        debug_assert!(self.is_err());
        match self {
            // SAOGALEMU: e tatau ona lagolagoina le konekarate le saogalemu e ala i le telefoni.
            Ok(_) => unsafe { hint::unreachable_unchecked() },
            Err(e) => e,
        }
    }
}

impl<T: Copy, E> Result<&T, E> {
    /// Faʻafanua le `Result<&T, E>` ile `Result<T, E>` ile kopiina o mea o loʻo i le `Ok` vaega.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&t| t)
    }
}

impl<T: Copy, E> Result<&mut T, E> {
    /// Faʻafanua le `Result<&mut T, E>` ile `Result<T, E>` ile kopiina o mea o loʻo i le `Ok` vaega.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone, E> Result<&T, E> {
    /// Faʻafanua le `Result<&T, E>` ile `Result<T, E>` ile faʻailoaina o mea ile vaega ole `Ok`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone, E> Result<&mut T, E> {
    /// Taialaina ai a `Result<&mut T, E>` i se `Result<T, E>` e cloning le anotusi o le vaega `Ok`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T, E: fmt::Debug> Result<T, E> {
    /// Faʻafoʻi mai le aofaʻi [`Ok`] aoga, faʻaumatia le `self` taua.
    ///
    /// # Panics
    ///
    /// Panics pe a fai o le tau o le [`Err`], ma le panic feau e aofia ai le feʻau o loʻo pasia, ma mea o loʻo i le [`Err`].
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.expect("Testing expect"); // panics with `Testing expect: emergency failure`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect", since = "1.4.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed(msg, &e),
        }
    }

    /// Faʻafoʻi mai le aofaʻi [`Ok`] aoga, faʻaumatia le `self` taua.
    ///
    /// Aua o lenei galuega e ono panic, o lona faʻaaogaina e masani ona faʻavaivaia.
    /// Nai lo lena, sili ia faʻaaoga le faʻaogaina o faʻataʻitaʻiga ma faʻatautaia manino le mataupu [`Err`], pe valaʻau i le [`unwrap_or`], [`unwrap_or_else`], poʻo le [`unwrap_or_default`].
    ///
    ///
    /// [`unwrap_or`]: Result::unwrap_or
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    /// [`unwrap_or_default`]: Result::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics pe a fai o le tau o le [`Err`], ma le feau panic na saunia e le ['Err`]' s aoga.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.unwrap(), 2);
    /// ```
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.unwrap(); // panics with `emergency failure`
    /// ```
    ///
    ///
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap(self) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed("called `Result::unwrap()` on an `Err` value", &e),
        }
    }
}

impl<T: fmt::Debug, E> Result<T, E> {
    /// Toe afio mai le o lo o aofia [`Err`] taua, alu i le taua `self`.
    ///
    /// # Panics
    ///
    /// Panics pe afai o le tau aogā o se [`Ok`], faatasi ai ma se savali panic e aofia ai le savali mavae atu, ma le aano o le [`Ok`].
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(10);
    /// x.expect_err("Testing expect_err"); // panics with `Testing expect_err: 10`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect_err", since = "1.17.0")]
    pub fn expect_err(self, msg: &str) -> E {
        match self {
            Ok(t) => unwrap_failed(msg, &t),
            Err(e) => e,
        }
    }

    /// Toe afio mai le o lo o aofia [`Err`] taua, alu i le taua `self`.
    ///
    /// # Panics
    ///
    /// Panics pe a fai o le tau o le [`Ok`], faʻatasi ai ma se feʻau masani panic o loʻo tuʻuina atu e le ['Ok`]' s aoga.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(2);
    /// x.unwrap_err(); // panics with `2`
    /// ```
    ///
    /// ```
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(x.unwrap_err(), "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_err(self) -> E {
        match self {
            Ok(t) => unwrap_failed("called `Result::unwrap_err()` on an `Ok` value", &t),
            Err(e) => e,
        }
    }
}

impl<T: Default, E> Result<T, E> {
    /// Toe afio mai le o lo o aofia [`Ok`] taua po o se faaletonu
    ///
    /// Alu uma le finauga `self` lea, afai [`Ok`], Ua toe foi le taua o loo i ai, e ese mai pe afai [`Err`], toe foi mai le taua faaletonu mo lena ituaiga.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaliliu se manoa i le numera o fuainumera, liliu manoa leaga-fausiaina i le 0 (le masani ai aoga mo fuainumera).
    /// [`parse`] liua se manoa i soʻo se isi ituaiga e faʻaaogaina [`FromStr`], faʻafoʻi mai se [`Err`] i luga o mea sese.
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_unwrap_or_default", since = "1.16.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Ok(x) => x,
            Err(_) => Default::default(),
        }
    }
}

#[unstable(feature = "unwrap_infallible", reason = "newly added", issue = "61695")]
impl<T, E: Into<!>> Result<T, E> {
    /// Toe afio mai le o lo o aofia [`Ok`] taua, ae aua lava nei panics.
    ///
    /// E le pei o [`unwrap`], o lenei metotia e iloa e le taitai panic i luga o faʻaiuga ituaiga o loʻo faʻatinoina mo.
    /// O le mea lea, e mafai ona faʻaaogaina nai lo le `unwrap` o se puipuiga e puipuia ai o le a le mafai ona tuʻufaʻatasia pe a fai o le ituaiga sese o le `Result` e mulimuli ane suia i se mea sese e mafai moni ona tupu.
    ///
    ///
    /// [`unwrap`]: Result::unwrap
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// # #![feature(never_type)]
    /// # #![feature(unwrap_infallible)]
    ///
    /// fn only_good_news() -> Result<String, !> {
    ///     Ok("this is fine".into())
    /// }
    ///
    /// let s: String = only_good_news().into_ok();
    /// println!("{}", s);
    /// ```
    ///
    ///
    #[inline]
    pub fn into_ok(self) -> T {
        match self {
            Ok(x) => x,
            Err(e) => e.into(),
        }
    }
}

impl<T: Deref, E> Result<T, E> {
    /// Tagata liliu mai mai `Result<T, E>` (poʻo `&Result<T, E>`) i le `Result<&<T as Deref>::Target, &E>`.
    ///
    /// Faʻamalosia le [`Ok`] ituaiga o le muamua [`Result`] ala i le [`Deref`](crate::ops::Deref) ma faʻafoʻi mai le [`Result`] fou.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&str, &u32> = Ok("hello");
    /// assert_eq!(x.as_deref(), y);
    ///
    /// let x: Result<String, u32> = Err(42);
    /// let y: Result<&str, &u32> = Err(&42);
    /// assert_eq!(x.as_deref(), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref(&self) -> Result<&T::Target, &E> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut, E> Result<T, E> {
    /// Tagata liliu mai mai `Result<T, E>` (poʻo `&mut Result<T, E>`) i le `Result<&mut <T as DerefMut>::Target, &mut E>`.
    ///
    /// Coerces le [`Ok`] variant o le uluai [`Result`] ala [`DerefMut`](crate::ops::DerefMut) ma toe foi mai le [`Result`] fou.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = "HELLO".to_string();
    /// let mut x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&mut str, &mut u32> = Ok(&mut s);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    ///
    /// let mut i = 42;
    /// let mut x: Result<String, u32> = Err(42);
    /// let y: Result<&mut str, &mut u32> = Err(&mut i);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref_mut(&mut self) -> Result<&mut T::Target, &mut E> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Result<Option<T>, E> {
    /// Transposes a `Result` o se `Option` i se `Option` o se `Result`.
    ///
    /// `Ok(None)` o le a faʻafanua i `None`.
    /// `Ok(Some(_))` ma `Err(_)` o le a faʻafanua i `Some(Ok(_))` ma `Some(Err(_))`.
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x.transpose(), y);
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_result", issue = "82814")]
    pub const fn transpose(self) -> Option<Result<T, E>> {
        match self {
            Ok(Some(x)) => Some(Ok(x)),
            Ok(None) => None,
            Err(e) => Some(Err(e)),
        }
    }
}

impl<T, E> Result<Result<T, E>, E> {
    /// Liliu mai `Result<Result<T, E>, E>` e `Result<T, E>`
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Ok("hello"));
    /// assert_eq!(Ok("hello"), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Err(6));
    /// assert_eq!(Err(6), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Err(6);
    /// assert_eq!(Err(6), x.flatten());
    /// ```
    ///
    /// Flattening na aveesea ai se tasi tulaga o le nesting i se taimi:
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<Result<&'static str, u32>, u32>, u32> = Ok(Ok(Ok("hello")));
    /// assert_eq!(Ok(Ok("hello")), x.flatten());
    /// assert_eq!(Ok("hello"), x.flatten().flatten());
    /// ```
    #[inline]
    #[unstable(feature = "result_flattening", issue = "70142")]
    pub fn flatten(self) -> Result<T, E> {
        self.and_then(convert::identity)
    }
}

impl<T> Result<T, T> {
    /// Faʻafoʻi le [`Ok`] aoga pe a fai o `self` o `Ok`, ma le [`Err`] aoga pe a `self` o `Err`.
    ///
    /// I se isi faaupuga, o lenei galuega tauave toe foi mai le taua (o le `T`) o se `Result<T, T>`, e tusa pe o le taunuuga o `Ok` po `Err`.
    ///
    /// E mafai ona aoga lenei mea faʻatasi ma API pei o [`Atomic*::compare_exchange`], poʻo [`slice::binary_search`], ae naʻo tulaga e te le popole ai pe a fai o le iʻuga o le `Ok` pe leai.
    ///
    ///
    /// [`Atomic*::compare_exchange`]: crate::sync::atomic::AtomicBool::compare_exchange
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_into_ok_or_err)]
    /// let ok: Result<u32, u32> = Ok(3);
    /// let err: Result<u32, u32> = Err(4);
    ///
    /// assert_eq!(ok.into_ok_or_err(), 3);
    /// assert_eq!(err.into_ok_or_err(), 4);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "result_into_ok_or_err", reason = "newly added", issue = "82223")]
    pub const fn into_ok_or_err(self) -> T {
        match self {
            Ok(v) => v,
            Err(v) => v,
        }
    }
}

// o se galuega tauave e ese lenei e faaitiitia ai le tele o tulafono laiti o le auala
#[inline(never)]
#[cold]
#[track_caller]
fn unwrap_failed(msg: &str, error: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, error)
}

/////////////////////////////////////////////////////////////////////////////
// Trait faʻaogaina
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, E: Clone> Clone for Result<T, E> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Ok(x) => Ok(x.clone()),
            Err(x) => Err(x.clone()),
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Ok(to), Ok(from)) => to.clone_from(from),
            (Err(to), Err(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, E> IntoIterator for Result<T, E> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Faʻafoʻi mai se mea faʻaalu i luga o le ono aofia ai tau.
    ///
    /// O le mea faʻasolosolo e maua se tasi taua pe a fai o le iʻuga o le [`Result::Ok`], a leai e leai se mea.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(5);
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, [5]);
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, []);
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self.ok() }
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a Result<T, E> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a mut Result<T, E> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// Le Iterators iʻuga
/////////////////////////////////////////////////////////////////////////////

/// O se faʻasolitulafono luga o se faʻasino i le [`Ok`] ituaiga o le [`Result`].
///
/// O le mea faʻasolosolo e maua se tasi taua pe a fai o le iʻuga o le [`Ok`], a leai e leai se mea.
///
/// Fausia e [`Result::iter`].
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    inner: Option<&'a T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner }
    }
}

/// O se faʻasolosolo luga o se mutable faʻasino i le [`Ok`] ituaiga o le [`Result`].
///
/// Fausia e [`Result::iter_mut`].
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    inner: Option<&'a mut T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// O se iterator i le taua i se [`Ok`] variant o se [`Result`].
///
/// O le mea faʻasolosolo e maua se tasi taua pe a fai o le iʻuga o le [`Ok`], a leai e leai se mea.
///
/// O lenei fausia na faia e le [`into_iter`] metotia luga [`Result`] (saunia e le [`IntoIterator`] trait).
///
///
/// [`into_iter`]: IntoIterator::into_iter
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    inner: Option<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, E, V: FromIterator<A>> FromIterator<Result<A, E>> for Result<V, E> {
    /// Aveina elemeni taʻitasi i le `Iterator`: afai o le `Err`, e leai se isi elemeni e aveina, ma o le `Err` ua toe faʻafoʻi mai.
    /// A leai se `Err` tupu, o se koneteina ma le taua o `Result` taʻitasi ua toe faʻafoʻi mai.
    ///
    /// Lenei o se faʻataʻitaʻiga lea e faʻaopopo ai numera uma i totonu o le vector, siakiina mo le ova:
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_add(1).ok_or("Overflow!")
    /// ).collect();
    /// assert_eq!(res, Ok(vec![2, 3]));
    /// ```
    ///
    /// Lenei o le isi faʻataʻitaʻiga e taumafai e toʻesea se tasi mai le isi lisi o numera, o le taimi lenei siaki mo lalo ifo:
    ///
    /// ```
    /// let v = vec![1, 2, 0];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_sub(1).ok_or("Underflow!")
    /// ).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// ```
    ///
    /// Lenei o se fesuiaiga i luga o le muamua faʻataʻitaʻiga, faʻaalia ai e leai nisi elemeni e aumaia mai `iter` pe a maeʻa le muamua `Err`.
    ///
    /// ```
    /// let v = vec![3, 2, 1, 10];
    /// let mut shared = 0;
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32| {
    ///     shared += x;
    ///     x.checked_sub(2).ok_or("Underflow!")
    /// }).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// Talu ai o le lona tolu elemeni mafua ai le loloto o le tafe, leai nisi elemeni na aveina, o lea o le mulimuli aoga o le `shared` o le 6 (= `3 + 2 + 1`), ae le 16.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Result<A, E>>>(iter: I) -> Result<V, E> {
        // FIXME(#11084): Lenei mafai ona suia i le Iterator::scan pe a fai o lenei faʻatinoina bug ua tapunia.
        //

        iter::process_results(iter.into_iter(), |i| i.collect())
    }
}

#[unstable(feature = "try_trait", issue = "42327")]
impl<T, E> ops::Try for Result<T, E> {
    type Ok = T;
    type Error = E;

    #[inline]
    fn into_result(self) -> Self {
        self
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Ok(v)
    }

    #[inline]
    fn from_error(v: E) -> Self {
        Err(v)
    }
}