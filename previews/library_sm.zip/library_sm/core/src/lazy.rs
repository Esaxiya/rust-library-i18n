//! Le faʻatauaina faʻatauaina ma le tasi taimi faʻatulagaina o faʻamaumauga tumau.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// A feaveai lea e mafai ona tusia e na o le faatasi.
///
/// E le pei o `RefCell`, na maua mai faasoa atu se `OnceCell` mau `&T` i lona taua.
/// E le pei o le `Cell`, e le manaʻomia e le `OnceCell` le kopiina poʻo le suia o le tau e faʻaaoga ai.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // Invariant: tusia ia i le tele o taimi e tasi.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// Faatupu ai se feaveai avanoa fou.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// Maua le faasinomaga i le taua autu.
    ///
    /// Faʻafoʻi `None` peʻa leai se sela.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // SAOGALEMU: Saogalemu ona 'invariant a inner`
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// Maua le faasinomaga mutable le tau faavae.
    ///
    /// Faʻafoʻi `None` peʻa leai se sela.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // SAFETI: Saogalelei aua e tutasi lava tatou avanoa
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// Ua faatulagaina e le anotusi o le sela e `value`.
    ///
    /// # Errors
    ///
    /// O lenei auala e toe foi `Ok(())` pe afai sa gaogao le sela ma `Err(value)` pe afai sa tumu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // SAOGALEMU: Saogalemu ona le mafai ona tatou overlapping borrows mutable
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // SAOGALEMU: o le nofoaga na lenei tatou te faataatia ai le slot, e leai se tuuga
        // ona o reentrancy/concurrency e mafai ai, ma ua tatou siaki e slot o le taimi nei `None`, ina lenei tusi tausia le 'a invariant inner`.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// Aumai mea i totonu o le sela, amataina ile `f` pe a fai o le sela e avanoa.
    ///
    /// # Panics
    ///
    /// Afai `f` panics, ua propagated le panic i le telefoni, ma e tumau uninitialized le sela.
    ///
    ///
    /// O se mea sese le toe faʻamalosia o le sela mai le `f`.O le faia o lea mea e maua ai le panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// Aumai mea i totonu o le sela, amataina ile `f` pe a fai o le sela e avanoa.
    /// Afai sa gaogao le sela ma `f` lē mafai, e toe foi se mea sese.
    ///
    /// # Panics
    ///
    /// Afai `f` panics, ua propagated le panic i le telefoni, ma e tumau uninitialized le sela.
    ///
    ///
    /// O se mea sese le toe faʻamalosia o le sela mai le `f`.O le faia o lea mea e maua ai le panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // Manatua e *nisi* ituaiga o initialization reentrant mafai ona taitai atu ai i UB (tagai i le suega `reentrant_init`).
        // Ou te talitonu na o le aveesea o lenei `assert`, ao le tausia o le a `set/get` leo, ae e foliga mai e sili atu panic, nai lo le faaaogaina leoa se taua matua.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// Faʻauma le sela, faʻafoʻi le tau afifi.
    ///
    /// Faafoi `None` pe afai sa gaogao le sela.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // Ona e `into_inner` `self` e taua, e faamaonia statically le tuufaatasia lea e le o le taimi nei nono.
        // O lea e saogalemu e agai atu `Option<T>`.
        self.inner.into_inner()
    }

    /// E le tau mai o lenei `OnceCell`, agai ai i tua i se tulaga uninitialized.
    ///
    /// E leai se aafiaga ma toe foi `None` pe afai e le i initialized le `OnceCell`.
    ///
    /// ua mautinoa le saogalemu e manaomia ai se faasinomaga mutable.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// O se taua lea e initialized i le avanoa muamua.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   initializing saunia
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// Faia ai se taua paie fou ma le tuuina atu o galuega tauave initializing.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// Faʻamalosi le iloiloga o lenei paie faʻatauaina ma toe faʻafoʻi se faʻasino i le iʻuga.
    ///
    ///
    /// e tutusa lenei i le `Deref` impl, ae o le manino.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// Faatupuina ai le faaaogaina o se taua paie fou `Default` e pei o le galuega tauave initializing.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}