#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! O loʻo iai faʻamatalaga uiga mo le faʻatulagaina ole tuʻufaʻatasia o ituaiga fausia-i totonu.
//!
//! e mafai ona faaaogaina i latou e pei sini o transmutes i code saogalemu mo manipulating le faamatalaga mata saʻo.
//!
//!
//! tatau ona tutusa i taimi uma o latou faamatalaga le ABI faamatalaina i `rustc_middle::ty::layout`.
//!

/// Le faʻatusa o le trait mea pei ole `&dyn SomeTrait`.
///
/// O lenei fausia ei ai le faatulagaga lava lea e tasi o ituaiga e pei o `&dyn SomeTrait` ma `Box<dyn AnotherTrait>`.
///
/// `TraitObject` e mautinoa e faʻafetaui faʻataʻatiaga, ae le o le ituaiga o trait mea (faʻapea, o fanua e le mafai ona sao saʻo i luga o le `&dyn SomeTrait`) pe faʻatonutonuina foʻi le faʻatulagaina (suia le faʻauigaina e le suia ai le faʻatulagaina o le `&dyn SomeTrait`).
///
/// Ua naʻo le fuafuaina e faʻaaogaina e le sefe code lea e manaʻomia le faʻagaeʻetia o le maualalo-tulaga auiliiliga.
///
/// E leai se auala e faʻasino uma ai i trait mea faitele, o lea na o le pau lava le auala e fausia ai tulaga taua o lenei ituaiga o faʻagaioiga pei o [`std::mem::transmute`][transmute].
/// E faapena foi, o le pau le auala e faatupuina ai se mea moni trait mai se taua `TraitObject` o ma `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Synthesizing se mea trait ma mismatched ituaiga-o le tasi e le pe afai o le vtable tutusa i le ituaiga o le taua lea o lo o manatu-maualuga ono le faasino ai faamatalaga e taitai atu ai i amioga undefined.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // se faʻataʻitaʻiga trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // ia tuu atu ia faia le tuufaatasia se mea trait
/// let object: &dyn Foo = &value;
///
/// // vaai atu i le faatusa mata
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // o le faʻasino tusi o le tuatusi o `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // fausia se mea fou, e faasino i se eseese `i32`, o le faaeteete e faaaoga le `i32` vtable mai `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // e tatau ona galue e pei lava na matou fausiaina se trait mea mai le `other_value` tuʻusaʻo
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}