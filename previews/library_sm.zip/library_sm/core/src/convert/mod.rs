//! Traits mo liua i le va o ituaiga.
//!
//! O le traits i lenei vaega e maua ai se auala e faʻaliliu ai mai le tasi ituaiga i le isi ituaiga.
//! E tofu le trait ma mafuaʻaga eseʻese:
//!
//! - Faʻaaoga le [`AsRef`] trait mo le taugofie faʻasino-i-faʻasino liliu mai
//! - Faʻaoga le [`AsMut`] trait mo le taugofie o suiga ua suia
//! - Faʻaaoga le [`From`] trait mo le faʻaaogaina o le taua-i-taua liua
//! - Faʻaaoga le [`Into`] trait mo le faʻaaogaina o le taua-i-taua liua i ituaiga i fafo atu o le taimi nei crate
//! - O le [`TryFrom`] ma le [`TryInto`] traits amio e pei o le [`From`] ma le [`Into`], ae tatau ona faʻatinoina pe a oʻo i le liliuga e mafai ona le manuia.
//!
//! Ua lagolagoina traits i lenei module ua masani ona faaaogaina o trait bounds mo galuega tauave lautele e pei o le i finauga o ituaiga tele.Vaʻai faʻamaumauga o trait taʻitasi mo faʻataʻitaʻiga.
//!
//! I le avea ai o se tusitala faletusi, oe tatau i taimi uma ona manaʻo e faʻaogaina le [`From<T>`][`From`] poʻo le [`TryFrom<T>`][`TryFrom`] nai lo le [`Into<U>`][`Into`] poʻo le [`TryInto<U>`][`TryInto`], ona o le [`From`] ma le [`TryFrom`] e maua ai le sili atu fetuʻutuʻunaʻi ma ofo tutusa tutusa [`Into`] poʻo [`TryInto`] faʻaaoga e leai se tau, faʻafetai i le ie afu i le faʻatulagaina o faletusi.
//! Ina ua le mataituina o se lomiga ao lumanai ai Rust 1.41, e ono talafeagai e faatino [`Into`] po [`TryInto`] tuusao pe a faaliliuina i se ituaiga fafo atu o le taimi nei crate.
//!
//! # Faatinoga Lautele
//!
//! - [`AsRef`] ma le [`AsMut`] taʻutaʻua-faʻafitauli pe a fai o le ituaiga totonu o se faʻasino
//! - [`Mai`]`<U>mo T` faʻauiga ['I totonu`]`</u><T><U>mo U`</u>
//! - ['TryFrom`]' <U>mo T` faatatau ['TryInto`]'</u><T><U>mo U`</u>
//! - [`From`] ma [`Into`] e toe faʻafouina, o lona uiga o ituaiga uma mafai `into` latou lava ma `from` latou lava
//!
//! Vaʻai taʻitasi trait mo faʻataʻitaʻiga faʻaaogaina.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// O le faʻagaioiga galuega.
///
/// Lua mea e taua e maitau e uiga i lenei gaioiga:
///
/// - E le tutusa i taimi uma i se tapunia e pei o `|x| x`, talu ai o le tapunia ono faamalosia `x` i se isi ituaiga.
///
/// - E minoi le sao `x` pasi i le gaioiga.
///
/// E ui e foliga e ese le i ai o se gaioiga e na o le toe faʻafoʻi mai o le sao, e i ai ni mea manaia e faʻaaoga ai.
///
///
/// # Examples
///
/// Faʻaaogaina `identity` e leai se mea i se faʻasologa o isi, manaia, gaioiga:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Ia o lena faafoliga faaopoopo ai le tasi o se galuega manaia.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Faʻaaogaina `identity` o se "do nothing" faʻavae tulaga i se tuutuuga:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Fai nisi mea manaia ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Faʻaaogaina `identity` e teu ai le `Some` ituaiga o le faʻasolosolo o `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Faaaogaina e faia a taugofie faasino i ai-i le-faasinomaga liua.
///
/// Lenei trait e tutusa ma [`AsMut`] o loʻo faʻaaogaina mo le faʻaliliuina i le va o faʻavasega suiga.
/// Afai e te manaʻomia le faia o se taugata faʻaliliuga e sili atu le faʻatinoina o le [`From`] ma le ituaiga `&T` pe tusi se faʻagaioiga gaioiga.
///
/// `AsRef` ei ai le saini tutusa ma [`Borrow`], ae o [`Borrow`] e ese i nai vaega:
///
/// - E le pei o `AsRef`, [`Borrow`] ei ai le palanikeke impl mo soʻo se `T`, ma e mafai ona faʻaaogaina e talia ai se faʻasino poʻo se taua.
/// - [`Borrow`] e manaomia ai foi e [`Hash`], [`Eq`] ma [`Ord`] mo taua nono ua tutusa i latou i le taua o lo o umia.
/// Mo lenei mafuaaga, afai e te manao e faaaoga na o se fanua e tasi o le a fausia e mafai ona faatino `AsRef`, ae le [`Borrow`].
///
/// **Note: e lē tatau ona toilalo lenei trait **.Afai e mafai ona le manuia le faʻaliliuga, faʻaaoga se metotia faʻapitoa e faʻafoʻi mai ai le [`Option<T>`] poʻo le [`Result<T, E>`].
///
/// # Faatinoga Lautele
///
/// - `AsRef` taʻavale-faʻateʻa pe a fai o le ituaiga i totonu o se faʻasino poʻo se fesuiaʻiga mau (eg: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// I le faʻaaogaina o le trait bounds e mafai ai ona tatou taliaina finauga o ituaiga eseʻese pe a mafai ona faʻaliliuina i latou i le ituaiga `T`.
///
/// Mo se faataitaiga: O le fatuina o se galuega tauave lautele e avea ai se `AsRef<str>` tatou faaali atu tatou te mananao e talia uma mau e mafai ona liua i [`&str`] o se finauga.
/// Talu faatino uma [`String`] ma [`&str`] `AsRef<str>` e mafai ona tatou taliaina uma e lua e pei finauga sao.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Faatinoina le liua.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Faʻaaoga e fai se taugofie mutable-i-mutable faʻasino faʻaliliuga.
///
/// O lenei trait e tutusa [`AsRef`] ae faaaoga mo le faaliliuina i le va o mau mutable.
/// Afai e te manaʻomia le faia o se taugata faʻaliliuga e sili atu le faʻatinoina [`From`] ma le ituaiga `&mut T` pe tusi se aganuʻu masani.
///
/// **Note: e lē tatau ona toilalo lenei trait **.Afai e mafai ona le manuia le faʻaliliuga, faʻaaoga se metotia faʻapitoa e faʻafoʻi mai ai le [`Option<T>`] poʻo le [`Result<T, E>`].
///
/// # Faatinoga Lautele
///
/// - `AsMut` taavale-dereferences pe afai o le ituaiga i totonu o se faasinomaga mutable (eg: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Faaaogaina `AsMut` pei trait bound mo a lautele o galuega tauave e mafai ona tatou talia mau mutable uma e mafai ona liua i ituaiga `&mut T`.
/// Ona faatino [`Box<T>`] `AsMut<T>` e mafai ona tatou tusi se galuega tauave `add_one` lena e finauga uma e mafai ona liua i `&mut u64`.
/// Ona faatino [`Box<T>`] `AsMut<T>`, `add_one` talia finauga o ituaiga `&mut Box<u64>` faapea:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Faatinoina le liua.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// O se taua-i-taua liua e faʻaumatia le sao taua.Le faʻafeagai o [`From`].
///
/// Tasi e tatau ona aloese mai le faʻaogaina o le [`Into`] ae faʻaoga [`From`] nai lo.
/// otometi lava ona e maua le faatinoina [`From`] tasi ma se faatinoga o le faafetai [`Into`] i le faatinoga palanikeke i le potutusi o tulaga faatonuina.
///
/// Sili filifili [`Into`] i luga [`From`] pe a faʻamaoti trait bounds luga o le lautele gaioiga ina ia mautinoa o ituaiga e naʻo faʻaaogaina [`Into`] mafai ona faʻaaogaina foi.
///
/// **Note: e lē tatau ona toilalo lenei trait **.Afai e mafai ona le manuia le faʻaliliuga, faʻaaoga [`TryInto`].
///
/// # Faatinoga Lautele
///
/// - [`Mai`]`<T>mo U` faʻailoa `Into<U> for T`
/// - [`Into`] o reflexive, o lona uiga ua faatinoina `Into<T> for T`
///
/// # Faʻaaogaina [`Into`] mo le liua i fafo ituaiga i tuai lomiga o Rust
///
/// O lei oo i Rust 1.41, pe afai o le sa le o se vaega ituaiga taunuuga o le crate le taimi nei ona e le mafai ona faatino [`From`] saʻo.
/// Mo se faʻataʻitaʻiga, ave le tulafono lea:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// O le a mafai ona tuufaatasia i matua lomiga o le gagana ona faaaogaina tulafono orphaning a Rust e avea o se vaega itiiti atili atoatoa.
/// Ina ia alo lenei, e mafai ona faatino [`Into`] saʻo:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// E taua le malamalama o [`Into`] e le o tuʻuina mai se [`From`] faʻatinoina (pei o [`From`] faia ma [`Into`]).
/// O le mea lea, e tatau ona e taumafai i taimi uma e faʻatino [`From`] ona toe paʻu lea i le [`Into`] peʻa le mafai ona faʻaoga [`From`].
///
/// # Examples
///
/// [`String`] meafaigaluega ['Into`]' <'[' Vec`] '<' ['u8`]' >> ':
///
/// Ina ia faʻailoa atu matou te manaʻomia se gaioiga lautele e ave uma finauga e mafai ona liua i se ituaiga faʻamaoti `T`, e mafai ona matou faʻaaogaina le trait bound o le [`Into`] '<T>'.
///
/// Mo se faʻataʻitaʻiga: O le gaioiga `is_hello` ave uma finauga e mafai ona liua i le ['Vec`]`<`[`u8`]`>'.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Faatinoina le liua.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Faʻaaoga e fai taua-i-taua liua a o faʻaaluina le sao taua.O le āloa o [`Into`].
///
/// e tatau ona faamuamua i taimi uma se tasi o le faatinoina o `From` i [`Into`] ona otometi lava ona e maua le faatinoina `From` tasi ma se faatinoga o [`Into`] faafetai i le faatinoga palanikeke i le potutusi o tulaga faatonuina.
///
///
/// Naʻo le [`Into`] e faʻatatau i le taimi e tatau ai ona e muamua i le Rust 1.41 ma liliu i se ituaiga i fafo atu o le crate.
/// `From` sa le mafai ona e faia ai nei ituaiga o liua i muamua lomiga ona o tulafono orphaning a Rust.
/// Tagai [`Into`] mo nisi auiliiliga.
///
/// Sili e faaaoga [`Into`] i le faaaogaina o `From` pe faamaotiina trait bounds i se galuega tauave lautele.
/// Lenei auala, ituaiga e faʻaoga saʻo [`Into`] mafai ona faʻaaogaina o finauga faʻapena foi.
///
/// E aoga tele foʻi le `From` peʻa faia se mea sese e faʻatautaia ai.Ina ua fauina o se galuega tauave e mafai ona toilalo, o le a avea masani ituaiga toe foi mai o le pepa faatumu `Result<T, E>`.
/// O le mea sese simplifies `From` trait taulimaina i le faatagaina o se galuega tauave e toe foi se ituaiga mea sese e tasi e encapsulate le tele o ituaiga mea sese.Tagai i le "Examples" fuaiupu ma [the book][book] mo nisi auiliiliga.
///
/// **Note: Lenei trait le tatau ona toilalo **.Afai e mafai ona toilalo le liua, faaaoga [`TryFrom`].
///
/// # Faatinoga Lautele
///
/// - `From<T> for U` faatatau ['Into`]' <U>mo T`</u>
/// - `From` e faʻafaigofie, o lona uiga o `From<T> for T` o loʻo faʻatinoina
///
/// # Examples
///
/// [`String`] faʻaaogaina `From<&str>`:
///
/// O se manino le liua mai le `&str` i le String ua faia e pei ona taua i lalo:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// A o le faatinoina o mea sese taulimaina e masani lava ona aoga e faatino `From` mo lou lava ituaiga mea sese.
/// E faaliliuina ituaiga mea sese faavae i lo tatou ituaiga lava mea sese masani e encapsulates le ituaiga sese faavae, e mafai ona tatou toe foi se ituaiga mea sese e tasi e aunoa ma le aveesea o faamatalaga i luga o le mafuaaga autu lea.
/// O le '?' tagata faʻagaioia otometi lava ona liua le mafuaʻaga sese ituaiga i la tatou agavaʻa ituaiga sese e ala i le valaʻau `Into<CliError>::into` lea e otometi lava ona faʻatinoina pe a faʻatino `From`.
/// O le tuʻufaʻatasiga ona afaina lea o faʻatinoga o `Into` e tatau ona faʻaaogaina.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Faatinoina le liua.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// O se taumafai liua lea na alu uma `self`, lea e mafai pe le mafai foi ona taugata.
///
/// tusitala Library tatau ona masani lava ona le saʻo faatino lenei trait, ae e tatau ona sili le faatinoina o le [`TryFrom`] trait, lea e ofoina sili fetuutuunai ma maua ai se faatinoga tutusa `TryInto` mo saoloto, e faafetai ai i se palanikeke faatinoga i le potutusi o tulaga faatonuina.
/// Mo nisi faamatalaga i lenei, tagai i le pepa mo [`Into`].
///
/// # Faʻaaogaina `TryInto`
///
/// O lenei e pagatia i le tutusa tapulaʻa ma mafuaʻaga pei o le faʻatinoina [`Into`], vaʻai iina mo auiliiliga.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// O le ituaiga na toe faafoi mai i le tulaga o le liua sese.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Faatinoina le liua.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Faigofie ma le saogalemu ituaiga liua e ono le mafai i se auala faʻatonutonuina i lalo o nisi tulaga.O le tali tutusa a le [`TryInto`].
///
/// e aoga lenei mea pe o loo e faia se liua ituaiga e mafai trivially manuia, ae e mafai ona manaomia foi taulimaina faapitoa.
/// Mo se faataitaiga, e leai se auala e liliu se [`i64`] i se [`i32`] le faaaogaina o le [`From`] trait, ona se [`i64`] mafai ona aofia ai se taua e mafai ona e le o se [`i32`] sui ma le liua o le a aveesea o faamatalaga.
///
/// Atonu e mafai ona faʻatautaia lea e ala i le faʻaitiitia o le [`i64`] i le [`i32`] (e manaʻomia le tuʻuina atu o le [`i64`] 's aoga modulo [`i32::MAX`]) pe naʻo le faʻafoʻi mai o le [`i32::MAX`], poʻo seisi auala.
/// ua faamoemoe le [`From`] trait mo le liua atoatoa, o lea le logoina `TryFrom` trait le Faapolokalameina pe mafai ona alu leaga a liua ituaiga ma faatagaina i latou e filifili le auala e taulimaina ai.
///
/// # Faatinoga Lautele
///
/// - `TryFrom<T> for U` faʻauiga le ['Taʻua I totonu`]` <U>mo T`</u>
/// - [`try_from`] o reflexive, o lona uiga ua faatinoina `TryFrom<T> for T` ma e mafai ona le toilalo-o le ituaiga `Error` fesootai mo le valaauina `T::try_from()` i se taua o ituaiga `T` o [`Infallible`].
/// A o le [`!`] ituaiga ua faʻamautuina [`Infallible`] ma [`!`] o le a tutusa.
///
/// `TryFrom<T>` mafai ona faʻatinoina i lalo:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// E pei ona faamatalaina, meafaigaluega [`i32`] 'TryFrom <' ['i64`]'> ':
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Faʻalologo lemu `big_number`, manaʻomia le sailia ma le tagofiaina o le truncation pe a maeʻa le mea moni.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Toe foi se mea sese ona o le tele foi `big_number` ina ia fetaui i se `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Faafoi `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// O le ituaiga na toe faafoi mai i le tulaga o le liua sese.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Faatinoina le liua.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// lautele IMPLS
////////////////////////////////////////////////////////////////////////////////

// E pei ona sii i luga i luga o&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// E pei ona sii i luga i &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): sui le mea taua i luga mo&/&mut i le sili atu lautele lautele tasi:
// // E pei ona sii i luga i Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Sized> AsRef <U>mo D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut sii i luga i &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): suia le impl i luga mo &mut ma le tasi aoao nei:
// // AsMut sii i luga i DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Lapopoa> AsMut <U>mo MF {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Mai faatatau Atu i
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Mai (ma o lea i totonu) o reflexive
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Mausali le tusi:** e leʻi i ai lenei impl, ae tatou te "reserving space" e faaopoopo ai i le future.
/// Vaʻai [rust-lang/rust#64715][#64715] mo auiliiliga.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): faia se tali e mataupu silisili nai lo.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// faatatau TryFrom TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// liua ua mautinoa e semantically tutusa liua fallible ma se ituaiga mea sese matua lē ainā.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS sima
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// O LE ITUAIGA SES ESEESE LEAI
////////////////////////////////////////////////////////////////////////////////

/// O le ituaiga sese mo mea sese e le mafai ona tupu.
///
/// Talu mai lenei enum e leai se variant, le mafai lava ona i ai moni lava se taua o lenei ituaiga.
/// O lenei e mafai ona aoga mo APIs lautele o loo faaaogaina [`Result`] ma parameterize le ituaiga mea sese, e faailoa ai o le taunuuga o [`Ok`] taimi uma.
///
/// Mo se faataitaiga, o le [`TryFrom`] trait (liua lea na toe foi mai le a [`Result`]) ei ai se faatinoga palanikeke mo ituaiga uma le mea o loo i ai se faatinoga faafeagai [`Into`].
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Ogatasi Future
///
/// O lenei enum ua i ai le matafaioi tutusa e pei [the `!`“never”type][never], lea ua mautu i lenei lomiga o Rust.
/// A faʻamautu le `!`, matou te fuafua e faia `Infallible` o se ituaiga igoa i ai:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... ma iu ai ina deprecate `Infallible`.
///
/// Peitaʻi e tasi le mataupu e mafai ona faʻaaoga ai le `!` syntax ae leʻi faʻamautuina `!` o se ituaiga atoa: i le tulaga o le ituaiga toe foʻi mai.
/// Faʻapitoa lava, e mafai faʻatinoina mo lua eseʻese galuega faʻatulagaina faʻasino ituaiga:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// I le avea ai o `Infallible` o se enum, o lenei tulafono e aoga.
/// Peitai a avea `Infallible` ma igoa faʻaigoa mo le never type, o le a amata ona soʻosoʻo le lua `impl`s ma o lea o le a faʻatagaina e le gagana a le trait tulafono felagolagomaʻi.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}