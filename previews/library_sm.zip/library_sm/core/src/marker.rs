//! traits Anamua ma ituaiga sui meatotino faavae o ituaiga.
//!
//! Rust ituaiga e mafai ona faʻavasegaina i le tele o aoga auala e tusa ai ma a latou meatotino autu.
//! o loo faatusalia nei faavasegaina o traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Ituaiga e mafai ona fesiitaʻi i luga atu o tuaoi tuaoi.
///
/// Lenei trait e otometi lava ona faʻaogaina pe a fuafuaina e le tuʻufaʻatasiga e talafeagai.
///
/// O se faʻataʻitaʻiga o se ituaiga e le o le "Auina Atu" o le faasino-faitau tusi [`rc::Rc`][`Rc`].
/// Afai e lua filo taumafai e faʻamilo ia ['Rc`] s e faʻasino i le tutusa taua-faitauga taua, latou ono taumafai e faʻafou le faitauga faitauga i le taimi e tasi, o le [undefined behavior][ub] aua [`Rc`] e le faʻaaogaina atomic faʻagaioiga.
///
/// O lona tausoga [`sync::Arc`][arc] na te faʻaaogaina atomic gaioiga (faʻatupuina nisi luga) ma o lea o `Send`.
///
/// Tagai [the Nomicon](../../nomicon/send-and-sync.html) mo nisi auiliiliga.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Ituaiga ma a tele pea iloa i le taimi e tuufaatasia.
///
/// Uma le faataamilosaga ituaiga maua se atoatoa noatia o `Sized`.O le faʻapitoa syntax `?Sized` mafai ona faʻaaogaina e aveʻese ai lenei noataga pe a le talafeagai.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // fausia FooUse(Foo<[i32]>);//sese: taumafaina e le o faatinoina mo [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// O le ese o le ituaiga atoatoa `Self` o se trait.
/// O le trait e leai sona uiga `Sized` faʻamau ona e le talafeagai lenei mea ma le [trait mea] s, pe a faʻauigaina, e manaʻomia le galulue o le trait ma tagata uma e mafai ona faʻatino, ma e ono tele.
///
///
/// E ui lava o le a ia tuu atu ia Rust e te faamauina `Sized` i se trait, o le ae le mafai ona e faaaogaina e avea o se trait mea mulimuli ane:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // ia y: &dyn Bar= &Impl;//sese: e le mafai ona faia le trait `Bar` i se mea
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // mo faaletonu, mo se faataitaiga, lea e manaomia ai ona `[T]: !Default` evaluatable
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Ituaiga e mafai ona avea "unsized" i se dynamically-tele ituaiga.
///
/// Mo se faataitaiga, faatino le ituaiga autau lapopoa `[i8; 2]` `Unsize<[i8]>` ma `Unsize<dyn fmt::Debug>`.
///
/// Uma faʻatinoina o `Unsize` e saunia otometi e le tuʻufaʻatasia.
///
/// `Unsize` ua faatinoina mo:
///
/// - `[T; N]` o le `Unsize<[T]>`
/// - `T` o `Unsize<dyn Trait>` pe `T: Trait`
/// - `Foo<..., T, ...>` o `Unsize<Foo<..., U, ...>>` pe afai:
///   - `T: Unsize<U>`
///   - o Foo a fausia
///   - E na o le fanua mulimuli o `Foo` ei ai se ituaiga e aofia ai `T`
///   - `T` e le o se vaega o le ituaiga o so o se isi fanua
///   - `Bar<T>: Unsize<Bar<U>>`, afai o le mulimuli fanua o `Foo` i ai ituaiga `Bar<T>`
///
/// `Unsize` o loo faaaogaina faatasi ma [`ops::CoerceUnsized`] e faatagaina "user-defined" pusa e pei o [`Rc`] e aofia ai ituaiga dynamically le taumafaina.
/// Vaʻai le [DST coercion RFC][RFC982] ma le [the nomicon entry on coercion][nomicon-coerce] mo nisi faʻamatalaga.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Manaomia trait mo constants faaaogaina i afitusi mamanu.
///
/// So o se ituaiga e otometi lava ona faatino e maua mai `PartialEq` lenei trait,*e tusa lava po* pe faatino `Eq` lona ituaiga-tapulaa.
///
/// Afai o se `const` mea o loo i ai se ituaiga e le faatino lenei trait, lea o lena ituaiga pe (1.) e le faatino `PartialEq` (o lona uiga o le a le tuuina atu e le aunoa e auala faatusatusaga, lea na tauaveina e maua tupulaga code), po o (2.) ai meafaigaluega *lona lava* lomiga o `PartialEq` (lea matou te manatu e le ogatasi ma se faʻatusatusaga-tutusa tutusa).
///
///
/// I se tasi o le scenarios e lua i luga, tatou te teena le faaaogaina o sea a faifai pea i se afitusi mamanu.
///
/// Tagai foi i le [structural match RFC][RFC1445], ma [issue 63438] lea malaga faaosofia mai mamanu faale-uiga i lenei trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Manaomia trait mo constants faaaogaina i afitusi mamanu.
///
/// Soʻo se ituaiga e maua `Eq` otometi lava ona faʻaogaina lenei trait, * tusa lava pe o ona ituaiga tapulaʻa faʻataʻitaʻi `Eq`.
///
/// o se Hack lenei e galulue faataamilo i se tapulaa i lo tatou faiga ituaiga.
///
/// # Background
///
/// Tatou te mananao e manaomia ai lena ituaiga o consts faaaogaina i afitusi mamanu maua le uiga `#[derive(PartialEq, Eq)]`.
///
/// I se lalolagi sili atu ona lelei, e mafai ona tatou siaki manaoga e ala i le na o le siakiina o le tuuina ituaiga meafaigaluega uma le `StructuralPartialEq` trait *ma* le `Eq` trait.
/// Ae ui i lea, e mafai ona i ai au ADTs *faia*`derive(PartialEq, Eq)`, ma avea ma mataupu matou te mananaʻo e talia e le tagata tuʻufaʻatasia, ae o le ituaiga faifai pea e le faʻaogaina `Eq`.
///
/// E pei, o se tulaga e pei o lenei:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (O le faafitauli i le tulafono laitiiti i luga o le e le faatino `Wrap<fn(&())>` `PartialEq`, po `Eq`, ona 'mo <' a> fn(&'a _)` does not implement those traits.)
///
/// O le mea lea, e lē mafai faalagolago tatou i faavalevalea siaki mo `StructuralPartialEq` ma na o `Eq`.
///
/// O se Hack i le galuega o loo siomia ai lenei mea, tatou te faaaogaina e lua traits ese tui e le maua mai e lua o le tasi i (`#[derive(PartialEq)]` ma `#[derive(Eq)]`) ma siaki o loo auai uma i latou o se vaega o le siakiina fetaui-fausaga.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Ituaiga o latou tulaga faatauaina e mafai ona faia ni kopi o le na o le kopiina faagutu.
///
/// O le mea masani, o fesuiaʻiga o fusi e iai le 'minoi fua.'I se isi faaupuga:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` ua see i le `y`, ma e le mafai ona faʻaaogaina
///
/// // println! ("{: ?}", x);//sese: faaaogaina o taua faagaeetia
/// ```
///
/// Peitai, afai o se ituaiga meafaigaluega `Copy`, o le ae ua 'kopi semantics':
///
/// ```
/// // E mafai ona tatou maua se faatinoga `Copy`.
/// // `Clone` manaomia foi, e pei o se supertrait o `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` o se kopi o `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// E taua le manatua o nei faataitaiga e lua, na o le pau le eseesega o le, pe o loo e faatagaina o ia e avanoa `x` tuanai ai o le tofiga.
/// I lalo o le pulou, o kopi uma ma le masiʻi atu e mafai ona iʻu ai i kopi kopi i mea e manatua ai, e ui lava o lenei taimi e sili ai ona faʻamautuina ese.
///
/// ## Mafai faapefea ona ou faatino `Copy`?
///
/// E lua auala e faatino `Copy` i lou ituaiga.O le faigofie o le faaaogaina `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// E mafai foʻi ona e faʻaaogaina lima le `Copy` ma le `Clone`:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// O loo i ai se tamai eseesega i le va o le lua: o le a tuu foi fuafuaga `derive` a noatia `Copy` i le faataamilosaga ituaiga, lea e le o manaomia i taimi uma.
///
/// ## O le a le eseesega i le va `Copy` ma `Clone`?
///
/// Kopi tupu implicitly, mo se faataitaiga o se vaega o se tofiga `y = x`.O le amioga a `Copy` e le overloadable;e masani lava o se vaega itiiti-poto faigofie kopi.
///
/// o Cloning se gaoioiga manino, `x.clone()`.O le faʻatinoina o [`Clone`] mafai ona maua ai soʻo se ituaiga-faʻapitoa amioga talafeagai e toe faʻataua saogalemu tulaga faʻatauaina.
/// Mo se faataitaiga, o le faatinoga o [`Clone`] mo [`String`] manaomia e kopi le buffer faasino-ia manoa i le faaputuga.
/// O se faigofie faigofie kopi o le [`String`] taua o le a na o le kopiina o le tusi, e tau atu ai i se faalua maua saoloto i lalo o le laina.
/// Mo lenei mafuaaga, [`String`] o [`Clone`] ae le `Copy`.
///
/// [`Clone`] o se supertrait o `Copy`, o lea o mea uma lea e tatau foi ona faatino `Copy` [`Clone`].
/// Afai o se ituaiga o lea `Copy` moomia le na o lona faatinoga [`Clone`] e toe foi `*self` (tagai i le faataitaiga i luga).
///
/// ## Ina ua mafai ona `Copy` loʻu ituaiga?
///
/// O se ituaiga e mafai ona faatino `Copy` pe afai e faatino ona vaega uma `Copy`.Mo se faʻataʻitaʻiga, o lenei faʻavae e mafai ona avea ma `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// O le faʻavae e mafai ona avea ma `Copy`, ma [`i32`] o `Copy`, o le mea lea `Point` e agavaʻa e avea ma `Copy`.
/// I se faatusatusaga, mafaufau
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// e le mafai ona faatino le fausia `PointList` `Copy`, ona [`Vec<T>`] e le `Copy`.Afai tatou te taumafai e maua se faatinoga `Copy`, o le a tatou maua ai se mea sese:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// O faʻasoa fefaʻasoaaʻi (`&T`) e `Copy` foʻi, o lona uiga o le ituaiga e mafai ona avea ma `Copy`, e tusa lava pe o loʻo taofia faʻasoa faʻasino o ituaiga `T` e *le*`Copy`.
/// Mafaufau i le fausia nei, lea e mafai ona faatino `Copy`, ona ua na umia o se *faasoa faasinomaga* i lo tatou lē `Copy` ituaiga `PointList` mai luga:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Pe a *e le mafai ona* ai `Copy` loʻu ituaiga?
///
/// O nisi ituaiga e le mafai ona kopiina ma le saogalemu.Mo se faataitaiga, kopiina `&mut T` le a faia se faasinomaga mutable aliased.
/// Kopiina le a faaluaina [`String`] tiutetauave mo le puleaina o le ['String`]' s buffer, e tau atu i se lua saoloto.
///
/// Generalizing le tulaga e gata ai, so o se ituaiga faatinoina [`Drop`] le mafai ona `Copy`, ona o loo puleaina o nisi punaoa e ese bytes lona lava [`size_of::<T>`].
///
/// Afai e te taumafai e faatino `Copy` i a fausia po o enum o loo i ai faamatalaga e lē `Copy`, o le ae maua le sese [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## O afea *e tatau ai* laʻu ituaiga `Copy`?
///
/// Tulaga lautele, pe afai e faatino lou ituaiga _can_ `Copy`, e tatau ai.
/// Ia manatua, e ui lava, o le faatinoina o `Copy` o se vaega o le API lautele o lou ituaiga.
/// Afai e mafai ona avea ma le ituaiga lē `Copy` i le future, e mafai ona atamamai e aveese le faatinoga `Copy` le taimi nei, ina ia aloese mai se suiga solia API.
///
/// ## Faʻaopopo faʻaopoopo
///
/// I le faaopoopo atu i le [implementors listed below][impls] foi faatino le ituaiga lalo `Copy`:
///
/// * Galuega aitema ituaiga (ie, o le eseʻese ituaiga faʻamatalaina mo galuega tauave taʻitasi)
/// * ituaiga e faasino ai galuega tauave (eg, `fn() -> i32`)
/// * Ituaiga faʻatulagaina, mo lapoʻa uma, pe a fai o le ituaiga aitema faʻaaoga foi `Copy` (eg, `[i32; 123456]`)
/// * ituaiga Tuple, pe afai e faatino foi vaega taitasi `Copy` (eg, `()`, `(i32, bool)`)
/// * Tapunia ituaiga, afai latou puʻe leai se aoga mai le siosiomaga po o pe afai o sea mauaina uma faatauaina faatino `Copy` i latou lava.
///   Manatua o fesuiaiga pueina e faasoa faasinomaga faatino pea `Copy` (e tusa lava pe e le o le referent), ao fesuiaiga pueina e mutable faasinomaga lava faatino `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) O lenei e mafai ai e le kopiina o se ituaiga e le faatino `Copy` ona o le faamalieina tuaoi olaga atoa (kopiina `A<'_>` pe na `A<'static>: Copy` ma `A<'_>: Clone`).
// Ua ia i matou lenei uiga iinei mo naʻo nei ona o loʻo i ai ni nai faʻapitoa faʻapitoa i luga o `Copy` o loʻo i ai i le faletusi masani, ma e leai se auala e saogalemu ai lenei amio i le taimi nei.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// macro maua faatupuina se impl o le trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Ituaiga e saogalemu e faʻasoa ai faʻamatalaga i le va o filo.
///
/// Lenei trait e otometi lava ona faʻaogaina pe a fuafuaina e le tuʻufaʻatasiga e talafeagai.
///
/// O le faʻauigaina saʻo o le: o le ituaiga `T` o le [`Sync`] pe a na o `&T` o [`Send`].
/// I se isi faaupuga, afai e leai se avanoa o [undefined behavior][ub] (e aofia ai ituaiga faamatalaga) pe a le tufaina o mau `&T` le va o filo.
///
/// E pei ona faʻamoemoeina e se tasi, o ituaiga muamua e pei o [`u8`] ma [`f64`] e [`Sync`] uma, ma e faʻapena lava ituaiga faigofie o loʻo iai latou, pei o tuples, strakes ma enums.
/// O isi faʻataʻitaʻiga o ituaiga [`Sync`] ituaiga aofia ai "immutable" ituaiga pei o `&T`, ma i latou e faigofie ona maua mai suiga, pei o [`Box<T>`][box], [`Vec<T>`][vec] ma tele isi ituaiga aoina.
///
/// (E manaomia e le faataamilosaga lautele e avea [`Sync`] mo o latou pusa e avea ['Sync`].)
///
/// A teisi faateia taunuuga o le faamatalaina o le `&mut T` o `Sync` (pe afai o `T` `Sync`) e ui lava e foliga mai e pei o ina tuuina mutation unsynchronized.
/// O le ki, o se faasinomaga mutable i tua o se faasinomaga faasoa (o, `& &mut T`) ua faitau-gata, e pei ai o se `& &T`.
/// O lea e leai se tulaga lamatia o se faamatalaga tuuga.
///
/// Ituaiga e le `Sync` na e maua "interior mutability" i a lē filo-saogalemu pepa, e pei o [`Cell`][cell] ma [`RefCell`][refcell].
/// O nei ituaiga faatagaina mo mutation o latou anotusi e oo lava i se masuia, faasinomaga faasoa.
/// Mo se faataitaiga o le auala `set` i [`Cell<T>`][cell] e `&self`, o lea e manaomia ai na o se faasinomaga faasoa [`&Cell<T>`][cell].
/// O le faatinoina auala leai se synchronization, ua faapea ona mafai ona [`Cell`][cell] ona `Sync`.
///
/// O le isi faʻataʻitaʻiga o se ituaiga e le o le `Sync` o le faasino-faitau tusi [`Rc`][rc].
/// Tuuina atu so o se faasinomaga [`&Rc<T>`][rc], e mafai ona clone a [`Rc<T>`][rc] fou, le suia o le faitauga o faasinomaga i totonu o se auala lē atomika.
///
/// Mo tulaga ina se tasi e manaomia filo-saogalemu mutability totonu, e tuuina Rust [atomic data types], faapea foi locking manino ala [`sync::Mutex`][mutex] ma [`sync::RwLock`][rwlock].
/// O nei ituaiga faamautinoa e faapea o so o se mutation le mafai ona mafuaaga faamatalaga tuuga, o lea ua `Sync` le ituaiga.
/// Faʻapena foi, [`sync::Arc`][arc] maua ai se filo-saogalemu faʻatusa o [`Rc`][rc].
///
/// So o se ituaiga i totonu tatau foi mutability faaaogaina le afifi [`cell::UnsafeCell`][unsafecell] i le value(s) lea e mafai ona mutated e ala i se faasinomaga faasoa.
/// Le lē mafai ona faia o lenei mea o [undefined behavior][ub].
/// Mo se faataitaiga, ['transmute`][transmute]-ing mai `&T` e `&mut T` ua le aloaia.
///
/// Vaʻai [the Nomicon][nomicon-send-and-sync] mo nisi faʻamatalaga e uiga ile `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): faʻatasi lagolago e faaopoopo faamatalaga i atunuu `rustc_on_unimplemented` i beta, ma ua tuuina atu e siaki pe a tapunia o soo se mea i le filifili manaoga, ona faaopoopo i ai o sea (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// O-tele ituaiga faaaoga e faailoga mea e "act like" latou lava a `T`.
///
/// Faaopoopoina o se `PhantomData<T>` fanua i lou ituaiga taʻu mai e le tuufaatasia o galue lou ituaiga e pei lava faleoloa a le taua o le ituaiga `T`, e ui lava e le moni.
/// O lenei faamatalaga e faaaoga pe a fuafuaina o nisi meatotino saogalemu.
///
/// Mo se faʻamatalaga auiliili pe faʻafefea ona faʻaaoga `PhantomData<T>`, faʻamolemole vaʻai [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Se tusi ghastly 👻👻👻
///
/// E ui e iai uma o latou igoa taufaʻafefe, `PhantomData` ma 'phantom ituaiga' e fesoʻotaʻi, ae le tutusa.A parameter ituaiga phantom o na o se parameter ituaiga lea e le faaaogaina lava.
/// I Rust, o lenei e masani ona mafua ai le tuufaatasia e faitio, ma le vaifofo o le e faaopoopo a "dummy" faaaogaina e ala i le `PhantomData`.
///
/// # Examples
///
/// ## le faataamilosaga faaaogaina olaga atoa
///
/// Masalo o le sili ona masani faʻaaoga mataupu mo `PhantomData` o se faʻavae e i ai lona le ola olaga parakalafa, masani lava o se vaega o nisi le saogalemu code.
/// Mo se faʻataʻitaʻiga, o le vaega `Slice` lea e lua ona faʻailoga o le ituaiga `*const T`, masalo e faʻasino i totonu o se laina i se mea:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// O le faamoemoe e faapea, o na aloaia le faamatalaga faavae mo le olaga atoa `'a`, ina `Slice` le tatau ona outlive `'a`.
/// Peitai, o lenei faamoemoe e le o faʻaalia i le numera, talu ai e leai ni aoga o le olaga atoa `'a` ma o lea e le o manino poʻo le a faʻamatalaga e faʻatatau i ai.
/// E mafai ona matou faʻasaʻoina lenei mea i le taʻuina i le tuʻufaʻatasia e galue *pei o le*`Slice` faʻavae aofia ai se faʻamatalaga `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// O lenei foi i taimi e manaomia ai le annotation `T: 'a`, e faailoa mai ai so o se faasinomaga i totonu o `T` e aoga i le olaga atoa `'a`.
///
/// A initializing a `Slice` oe na tuuina atu i le `PhantomData` taua mo le fanua `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Faaaogaina le faataamilosaga ituaiga
///
/// O nisi taimi e tupu ia te oe faaaogaina le faataamilosaga ituaiga lea e faailoa mai le ituaiga o faamatalaga a fausia o "tied" e, e ui lava e le moni iloa ai ia faamaumauga i le fausia lava ia.
/// O se faʻataʻitaʻiga lea e tulaʻi mai ai ma [FFI].
/// Le faaaogaina Ofisa o fafo 'au o ituaiga `*mut ()` e faasino i Rust tulaga faatauaina o ituaiga eseese.
/// Tatou te iloa ai le faasologa o le ituaiga Rust e faaaoga ai se parameter ituaiga phantom i le fausia `ExternalResource` lea wraps a au.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Umiaina ma le siaki mataua
///
/// Faaopoopoina o se fanua o le ituaiga o loo faailoa mai `PhantomData<T>` lou ituaiga umia faamatalaga o ituaiga `T`.Lenei i le faasologa o loo faapea mai pe a faapau lou ituaiga, e mafai ona aveesea se tasi po o le sili o tulaga o le ituaiga `T`.
/// O lenei ua tuuina atu i luga o le a le iloiloga [drop check] tuufaatasia Rust.
///
/// Afai e leʻo iai sau oe lava *faʻamaumauga o le ituaiga `T`, e sili atu le faʻaoga o se ituaiga faʻasino, pei o le `PhantomData<&'a T>` (ideally) poʻo le `PhantomData<* const T>` (pe a fai e leai se olaga atoa e faʻaaogaina), ina ia le faʻailoa mai e ana oe.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Faʻavae-totonu trait faʻaaogaina e faʻailoa ai le ituaiga o enum discriminants.
///
/// O lenei trait ua otometi faatinoina mo ituaiga uma ma e le faaopoopo atu i so o se faamaoniga e [`mem::Discriminant`].
/// O **amioga undefined** e transmute va `DiscriminantKind::Discriminant` ma `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// O le ituaiga o le discriminant, lea e tatau ona faamalieina ai le manaomia trait bounds e `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Faʻavae-totonu trait faʻaaogaina e fuafua ai pe o se ituaiga o aofia ai soʻo se `UnsafeCell` totonu, ae le ala i se faʻaosofia.
///
/// O lenei e aafia ai, mo se faataitaiga, pe a `static` o lena ituaiga ua tuuina i faitau-na manatua static po writable manatua static.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Ituaiga e mafai ona sefeina saogalemu pe a uma ona pine.
///
/// Rust lava e leai se manatu o ituaiga le mafaagaeetia, ma manatu gaoioiga (eg, e ala i tofiga po o [`mem::replace`]) ina ia saogalemu i taimi uma.
///
/// o loo faaaogaina ituaiga [`Pin`][Pin] le ae le i taofia ai gaoioiga e ala i le faiga o ituaiga.afifi vae `P<T>` i le afifi [`Pin<P<T>>`][Pin] le mafai ona siitia mai.
/// Vaʻai le [`pin` module] faʻamaumauga mo nisi faʻamatalaga i luga o le pineina o pine.
///
/// O le faʻatinoina o le `Unpin` trait mo `T` siʻi le faʻatapulaʻaina o le nonoa o le ituaiga, ona faʻatagaina ai lea ona aveese le `T` mai le [`Pin<P<T>>`][Pin] ma galuega e pei o le [`mem::replace`].
///
///
/// `Unpin` e leai se taunuuga i uma mo faamatalaga lē faamau.
/// Aemaise lava, fiafia uunaʻia [`mem::replace`] faamatalaga `!Unpin` (e galue mo so o se `&mut T`, ae le na pe `T: Unpin`).
/// Ae peitai, e le mafai ona faaaogaina [`mem::replace`] i faamatalaga afifi i totonu o se [`Pin<P<T>>`][Pin] ona e le mafai ona maua le `&mut T` e manaomia mo lena mea, ma *o* o le mea e faia galuega faiga lenei.
///
/// O lea la, o lenei, mo se faataitaiga, e mafai ona na ona faia i ituaiga faatinoina `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Tatou te manaomia se faasinomaga mutable e valaau `mem::replace`.
/// // E mafai ona tatou maua ai se faasinomaga e (implicitly) le aumaia `Pin::deref_mut`, ae ua na mafai ona meafaigaluega `String` `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// O lenei trait ua otometi faatinoina mo le toeitiiti ituaiga uma.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// O se ituaiga faʻailoga e le faʻaogaina `Unpin`.
///
/// Afai o se ituaiga o loo i ai se `PhantomPinned`, o le a le faatino `Unpin` e faaletonu.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Implementations o `Copy` mo ituaiga anamua.
///
/// Implementations e le mafai ona faamatalaina i le Rust ua faatinoina i `traits::SelectionContext::copy_clone_conditions()` i `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// e mafai ona kopiina mau faasoa, ae mau mutable *e le mafai ona*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}