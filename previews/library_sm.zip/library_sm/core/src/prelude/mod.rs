//! O le libcore prelude
//!
//! Lenei module ua fuafuaina mo tagata faʻaaoga o le libcore e le fesoʻotaʻi foʻi ma le libstd.
//! Lenei module e faaulufale mai i le le masani pe a `#![no_std]` o loʻo faʻaaogaina i le tutusa auala e pei o le tulaga masani faletusi's prelude.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// O le 2015 lomiga o le autu prelude.
///
/// Vaʻai le [module-level documentation](self) mo nisi mea.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// O le 2018 lomiga o le autu prelude.
///
/// Vaʻai le [module-level documentation](self) mo nisi mea.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// O le 2021 lomiga o le autu prelude.
///
/// Vaʻai le [module-level documentation](self) mo nisi mea.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Faʻaopopo nisi mea.
}