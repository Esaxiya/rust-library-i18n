#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Tuʻuina mai le faʻasino metadata ituaiga o soʻo se tusitusi-i le ituaiga.
///
/// # Faasino metadata
///
/// E mafai ona mafaufauina i ituaiga o faʻasino tusi ma ituaiga faʻasino i le Rust e pei ona faia i ni vaega se lua:
/// a faasino ai faamatalaga o loo i ai le tuatusi o le manatuaina o le taua, ma o nisi metadata.
///
/// Mo ituaiga statically-size (o loʻo faʻatino ai le `Sized` traits) faʻapea foʻi ma `extern` ituaiga, o faʻasino e fai mai e "manifinifi": metadata e leai se tele ma lona ituaiga e `()`.
///
///
/// Faʻasino i le [dynamically-sized types][dst] fai mai e "lautele" pe "gaʻo", latou e leai-zero-tele metadata:
///
/// * Mo auala o lona fanua mulimuli o le DST, metadata o metadata mo le fanua mulimuli
/// * Mo le `str` ituaiga, metadata o le umi i bytes pei `usize`
/// * Mo ituaiga fasi e pei o `[T]`, metadata o le umi i aitema e pei o `usize`
/// * Mo trait mea pei o `dyn SomeTrait`, metadata o [`DynMetadata<Self>`][DynMetadata] (eg `DynMetadata<dyn SomeTrait>`)
///
/// I le future, o le Rust gagana e ono maua ni ituaiga fou o ituaiga e eseʻese faʻasino metadata.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # O le `Pointee` trait
///
/// O le manatu o lenei trait o lona `Metadata` fesoʻotaʻi ituaiga, o le `()` poʻo le `usize` poʻo le `DynMetadata<_>` e pei ona faʻamatalaina i luga.
/// E otometi lava ona faatinoina mo ituaiga uma.
/// E mafai ona manatu e faʻatinoina i se tulaga lautele, tusa lava pe aunoa ma se fesoʻotaʻiga fusia.
///
/// # Usage
///
/// e mafai ona decomposed vae mata i le tuatusi o faamatalaga ma vaega metadata ma o latou auala [`to_raw_parts`].
///
/// I se isi itu, metadata naʻo ia e mafai ona aumaia i fafo ma le [`metadata`] galuega.
/// E mafai ona pasi se faʻasino i le [`metadata`] ma faʻamalosi le faʻamalosi.
///
/// O le (possibly-wide) faʻasino mafai ona tuʻu faʻatasia faʻatasi mai lona tuatusi ma metadata ma [`from_raw_parts`] poʻo [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Le ituaiga mo metadata ile faʻasino ma faʻasino ile `Self`.
    #[lang = "metadata_type"]
    // NOTE: Tuʻu le trait bounds i le `static_assert_expected_bounds_for_metadata`
    //
    // i `library/core/src/ptr/metadata.rs` i sync faatasi ma i latou iinei:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Vae i ituaiga faatinoina o lenei igoa pepelo trait e "manifinifi".
///
/// E aofia ai ma le faʻavasega-`Sized` ituaiga ma `extern` ituaiga.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: aua le faʻamautuina lenei mea ae le i faʻamautuina ia igoa ole trait i le gagana?
pub trait Thin = Pointee<Metadata = ()>;

/// Aveese le metadata vaega o se faʻasino.
///
/// Tulaga Faatauaina o ituaiga `*mut T`, `&T`, po o le mafai ona mavae tuusao `&mut T` i lenei galuega tauave e pei ona latou faamalosia implicitly e `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // SAFETY: Avanoa le taua mai le `PtrRepr` iuni e saogalemu talu mai * const T
    // ma PtrComponents<T>ia tutusa lau faʻamanatuga.
    // Naʻo le std e mafai ona faia lenei faʻamaoniga.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Fausia se (possibly-wide) raw point mai le tuatusi faʻamaumauga ma metadata.
///
/// O lenei galuega o le saogalemu ae e le ona saogalemu le toe foi atu i e faasino dereference.
/// Mo fasi, vaʻai faʻamaumauga o [`slice::from_raw_parts`] mo le saogalemu manaʻoga.
/// Mo trait mea faitino, o le metadata tatau ona sau mai se faʻasino i le tutusa lava faʻavae ituaiga faʻamama.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // SAFETY: Avanoa le taua mai le `PtrRepr` iuni e saogalemu talu mai * const T
    // ma PtrComponents<T>ia tutusa lau faʻamanatuga.
    // Naʻo le std e mafai ona faia lenei faʻamaoniga.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Faʻatautaia le tutusa gaioiga e pei o le [`from_raw_parts`], seʻi vagana o le mata `*mut` faʻasino tusi ua toe faʻafoʻi, e ese mai i le raw `* const` faʻasino.
///
///
/// Vaʻai faʻamaumauga ole [`from_raw_parts`] mo nisi faʻamatalaga.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // SAFETY: Avanoa le taua mai le `PtrRepr` iuni e saogalemu talu mai * const T
    // ma PtrComponents<T>ia tutusa lau faʻamanatuga.
    // Naʻo le std e mafai ona faia lenei faʻamaoniga.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Tusi lesona tusi manaʻomia e aloese mai `T: Copy` fusifusia.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Tusi lesona tusi manaʻomia e aloese mai `T: Clone` fusifusia.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Le metadata mo le `Dyn = dyn SomeTrait` trait mea ituaiga.
///
/// O se e faasino i se vtable (laulau valaau tafailagi) e faapea ua faatusa i le faamatalaga talafeagai uma e faatiga i le sima ituaiga teuina i totonu o se mea trait.
/// O le vaʻa vaʻaia e aofia ai:
///
/// * tele ituaiga
/// * ituaiga gatasi
/// * a faasino ai i le a `drop_in_place` impl ituaiga (e mafai ona a leai-op mo faamatalaga-manino le matua)
/// * faʻasino i metotia uma mo le faʻaogaina o le ituaiga o le trait
///
/// Manatua o le muamua tolu e faʻapitoa aua e manaʻomia e tufatufa, paʻu, ma fefaʻasoaaʻi soʻo se trait mea.
///
/// E mafai ona faʻaigoaina lenei faʻavae ma se ituaiga parameter e le o se `dyn` trait mea (mo se faʻataʻitaʻiga `DynMetadata<u64>`) ae le o le mauaina o se aoga taua o lena faʻavae.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// O le nauna masani o vtables uma.E sosoʻo mai ma galuega faʻasino mo metotia trait.
///
/// auiliili faatinoga tumaoti o `DynMetadata::size_of` isi
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Faʻafoi mai le lapoʻa o le ituaiga fesoʻotaʻi ma lenei vtable.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Faʻafoʻi le faʻafetauiina o le ituaiga fesoʻotaʻi ma lenei vtable.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Faʻafoʻi mai le lapoʻa ma faʻatasiga faʻatasi o se `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // SAOGALEMU: emitted le tuufaatasia lenei vtable mo se sima ituaiga Rust lea
        // e iloa e iai le faʻatulagaina lelei.rationale tutusa i totonu o `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Tusi lesona tusi aoga manaʻomia e aloese mai `Dyn: $Trait` tuaoi.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}