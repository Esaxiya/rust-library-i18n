use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` ae leai-zero ma covariant.
///
/// Lenei e masani lava o le saʻo mea e faʻaogaina pe a fausia faʻamaumauga faʻavae faʻaaogaina mata faʻailoaina, ae i le iuga e sili atu lamatia le faʻaogaina ona o ona faʻaopopo meatotino.Afai e te le o mautinoa pe tatau ona e faʻaaogaina `NonNull<T>`, na ona faʻaaoga `*mut T`!
///
/// E le pei o `*mut T`, o le faʻasino tatau lava i taimi uma ona leai se aoga, tusa lava pe o le faʻasino e le faʻamamaina lava.O lenei ina ia mafai ai e enums ona faʻaaogaina lenei faʻasaina taua o se faʻailoga tagata-`Option<NonNull<T>>` e tutusa lona tele ma le `* mut T`.
/// Ae peitai e mafai pea dangle pe afai e le dereferenced le faasino ai.
///
/// E le pei o `*mut T`, `NonNull<T>` na filifilia e avea ma tagata sili atu ile `T`.Lenei mafai ai ona faʻaaoga `NonNull<T>` pe a fausia covariant ituaiga, ae faʻalauiloa le aʻafiaga o le le mautonu peʻa faʻaaogaina i se ituaiga e le tatau moni ona covariant.
/// (O le filifiliga faʻafeagai na faia mo `*mut T` e ui lava o le le faʻatonuina e mafai ona mafua mai i le valaʻau i ni galuega le saogalemu.)
///
/// Covariance e saʻo mo le tele o faʻanumeraina saogalemu, pei o `Box`, `Rc`, `Arc`, `Vec`, ma `LinkedList`.Ole mataupu lea aua latou te saunia se lautele API e mulimulitaʻi ile masani fefaʻasoaaʻi XOR faʻafetaui tulafono o Rust.
///
/// Afai o lau ituaiga e le mafai ona saogalemu covariant, oe tatau ona mautinoa o loʻo iai ni isi faʻaopopo fanua e tuʻuina atu invariance.E masani ona avea lenei malae ma ituaiga [`PhantomData`] pei o `PhantomData<Cell<T>>` poʻo `PhantomData<&'a mut T>`.
///
/// Matau o `NonNull<T>` ei ai le `From` faʻataʻitaʻiga mo `&T`.Peitaʻi, e le suia ai le mea moni e faʻapea o le suia e ala i le (faʻasino tusi mai le a) faʻasoa faʻasino e le faʻamatalaina amioga seʻi vagana o le suiga e tupu i totonu o le [`UnsafeCell<T>`].E faapena foi mo le fatuina o se faasinomaga mutable mai se faasinomaga faasoa.
///
/// A o e faʻaaogaina lenei `From` faʻataʻitaʻiga e aunoa ma le `UnsafeCell<T>`, o lou tiute le mautinoa o le `as_mut` e le taitai valaʻauina, ma le `as_ptr` e le faʻaaogaina mo suiga.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` o faʻasino e le o le `Send` aua o faʻamatalaga latou te faʻasino i ai e ono faʻaigoaina.
// NB, o lenei mea e le manaʻomia, ae tatau ona maua ai ni mea sese sili atu.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` o faʻasino e le o le `Sync` aua o faʻamatalaga latou te faʻasino i ai e ono faʻaigoaina.
// NB, o lenei mea e le manaʻomia, ae tatau ona maua ai ni mea sese sili atu.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Fausia se `NonNull` fou o loʻo tautau, ae faʻatulaga lelei.
    ///
    /// E aoga lea mo le amataina o ituaiga e paie faʻasoasoa, pei ole `Vec::new` faia.
    ///
    /// Manatua o le faʻasino faʻatomuaga ono ono avea ma sui o se faʻatonu lelei faʻasino i le `T`, o lona uiga e le tatau ona faʻaaogaina o se "not yet initialized" sentinel aoga.
    /// Ituaiga e paie faʻasoa e tatau ona siaki amataina i nisi auala.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // SAOGALEMU: toe foi mem::align_of() a lē o usize ua lea casted
        // ia a * mut T.
        // O le mea lea, `ptr` e le faʻaleaogaina ma tuutuuga mo le valaʻau new_unchecked() e faʻaaloalo.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Faʻafoʻi mai se faʻasoa faʻasino i le tau.E faʻatusatusa i le [`as_ref`], e le manaʻomia le amataina o le tau.
    ///
    /// Mo le sui fesuiaʻi vaʻai [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Pe a valaauina lenei auala, e tatau ona mautinoa e moni le uma nei:
    ///
    /// * E tatau ona faʻasaʻo lelei le faʻasino tusi.
    ///
    /// * E tatau ona "dereferencable" i le uiga faʻamatalaina i le [the module documentation].
    ///
    /// * E tatau ona e faʻamalosia tulafono faʻaigoa a le Rust, talu ai o le olaga ua toe foʻi mai `'a` ua filifilia faʻapitoa ma e le o atagia mai ai le moni moni o le taimi o faʻamatalaga.
    ///
    ///   Ae maise lava, mo le umi o lenei olaga, o le manatuaina o le faʻasino tusi e le tatau ona suia (seʻi vagana totonu `UnsafeCell`).
    ///
    /// E faʻapipiʻi lenei mea tusa lava pe le o faʻaaogaina le iʻuga o lenei metotia!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // SAFETY: o le tagata telefoni e tatau ona mautinoa o `self` feiloai uma
        // manaʻoga mo se faʻasino.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Faʻafoʻi mai se tulaga ese faʻasino i le tau.I le faatusatusa atu i [`as_mut`], o lenei e le manaomia ai e faapea e tatau ona initialized le taua.
    ///
    /// Mo le vaega faʻasoa vaʻai [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Pe a valaauina lenei auala, e tatau ona mautinoa e moni le uma nei:
    ///
    /// * E tatau ona faʻasaʻo lelei le faʻasino tusi.
    ///
    /// * E tatau ona "dereferencable" i le uiga faʻamatalaina i le [the module documentation].
    ///
    /// * E tatau ona e faʻamalosia tulafono faʻaigoa a le Rust, talu ai o le olaga ua toe foʻi mai `'a` ua filifilia faʻapitoa ma e le o atagia mai ai le moni moni o le taimi o faʻamatalaga.
    ///
    ///   Ae maise lava, mo le umi o lenei olaga, o le manatuaina o le faʻasino tusi e le tatau ona mauaina (faitau pe tusia) e ala i soʻo se isi faʻasino tusi.
    ///
    /// E faʻapipiʻi lenei mea tusa lava pe le o faʻaaogaina le iʻuga o lenei metotia!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // SAFETY: o le tagata telefoni e tatau ona mautinoa o `self` feiloai uma
        // manaʻoga mo se faʻasino.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Faatupu ai se `NonNull` fou.
    ///
    /// # Safety
    ///
    /// `ptr` tatau ona leai se aoga.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SAFETY: o le tagata telefoni e tatau ona mautinoa o `ptr` e leai.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Fausia se `NonNull` fou pe a fai o `ptr` e leai se aoga.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SAFETI: Ua uma ona siaki le faʻasino ma e le o null
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Faʻatautaia le tutusa gaioiga e pei o le [`std::ptr::from_raw_parts`], seʻi vagana o le `NonNull` faʻasino tusi ua toe faʻafoʻi mai, e ese mai i le raw `*const` faʻasino faasino.
    ///
    ///
    /// Tagai i le pepa o [`std::ptr::from_raw_parts`] mo nisi auiliiliga.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // SAFETY: O le iʻuga o `ptr::from::raw_parts_mut` e leai se aoga aua o `data_address` o.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Faʻasaʻo se (atonu lautele) faʻasino tusi i totonu o le tuatusi ma metadata vaega.
    ///
    /// O le faʻasino tusi mafai mulimuli ane toe fausiaina ma [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Mauaina le faʻavae `*mut` faʻasino faasino.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Faʻafoʻi mai se faʻasoa faʻasino i le tau.Afai o le tau ono ono le amanaʻiaina, [`as_uninit_ref`] tatau ona faʻaaoga nai lo.
    ///
    /// Mo le sui fesuiaʻi vaʻai [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Pe a valaauina lenei auala, e tatau ona mautinoa e moni le uma nei:
    ///
    /// * E tatau ona faʻasaʻo lelei le faʻasino tusi.
    ///
    /// * E tatau ona "dereferencable" i le uiga faʻamatalaina i le [the module documentation].
    ///
    /// * O le faʻasino tusi e tatau ona tusi i se amataga faʻavae o `T`.
    ///
    /// * E tatau ona e faʻamalosia tulafono faʻaigoa a le Rust, talu ai o le olaga ua toe foʻi mai `'a` ua filifilia faʻapitoa ma e le o atagia mai ai le moni moni o le taimi o faʻamatalaga.
    ///
    ///   Ae maise lava, mo le umi o lenei olaga, o le manatuaina o le faʻasino tusi e le tatau ona suia (seʻi vagana totonu `UnsafeCell`).
    ///
    /// E faʻapipiʻi lenei mea tusa lava pe le o faʻaaogaina le iʻuga o lenei metotia!
    /// (O le vaega e uiga i le faʻamasaniina e leʻiʻo maeʻa ona faia se faʻaiuga, ae seʻia oʻo i le taimi, o le auala saogalemu se tasi o le faʻamautinoaina ua faʻamaoniaina moni.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SAFETY: o le tagata telefoni e tatau ona mautinoa o `self` feiloai uma
        // manaʻoga mo se faʻasino.
        unsafe { &*self.as_ptr() }
    }

    /// Faʻafoʻi mai se tulaga ese faʻasino i le tau.Afai o le tau ono ono le amanaʻiaina, [`as_uninit_mut`] tatau ona faʻaaoga nai lo.
    ///
    /// Mo le vaega faʻasoa vaʻai [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Pe a valaauina lenei auala, e tatau ona mautinoa e moni le uma nei:
    ///
    /// * E tatau ona faʻasaʻo lelei le faʻasino tusi.
    ///
    /// * E tatau ona "dereferencable" i le uiga faʻamatalaina i le [the module documentation].
    ///
    /// * O le faʻasino tusi e tatau ona tusi i se amataga faʻavae o `T`.
    ///
    /// * E tatau ona e faʻamalosia tulafono faʻaigoa a le Rust, talu ai o le olaga ua toe foʻi mai `'a` ua filifilia faʻapitoa ma e le o atagia mai ai le moni moni o le taimi o faʻamatalaga.
    ///
    ///   Ae maise lava, mo le umi o lenei olaga, o le manatuaina o le faʻasino tusi e le tatau ona mauaina (faitau pe tusia) e ala i soʻo se isi faʻasino tusi.
    ///
    /// E faʻapipiʻi lenei mea tusa lava pe le o faʻaaogaina le iʻuga o lenei metotia!
    /// (O le vaega e uiga i le faʻamasaniina e leʻiʻo maeʻa ona faia se faʻaiuga, ae seʻia oʻo i le taimi, o le auala saogalemu se tasi o le faʻamautinoaina ua faʻamaoniaina moni.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SAFETY: o le tagata telefoni e tatau ona mautinoa o `self` feiloai uma
        // manaʻoga mo se faʻavasega suiga.
        unsafe { &mut *self.as_ptr() }
    }

    /// Tuliesea i se e faasino ai o se isi ituaiga.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // SAOGALEMU: `self` o se faasino `NonNull` lea ua mautinoa e lē soloia
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Faatupuina a lē soloia fasi mata mai le a faasino manifinifi ma a umi.
    ///
    /// O le finauga `len` o le numera o **elemene**, ae le o le numera o bytes.
    ///
    /// Lenei galuega tauave e saogalemu, ae desereferencing le toe faafoi taua e le saogalemu.
    /// Vaʻai faʻamaumauga o [`slice::from_raw_parts`] mo fasi saogalemu manaʻoga.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // fai se fasi faʻasino tusi pe a amata i fafo ma se faʻasino i le muamua elemene
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Manatua o lenei faʻataʻitaʻiga faʻataʻitaʻia faʻaalia se faʻaaogaina o lenei metotia, ae ia tuu le fasi= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // SAFETY: `data` o le `NonNull` faʻasino tusi e mautinoa e leai-leai
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Faʻafoi le umi o se leai-leai fasi fasi.
    ///
    /// O le tau faʻafoi mai o le numera o **elemene**, ae le o le numera o bytes.
    ///
    /// O lenei gaioiga e saogalemu, e tusa lava pe le o le null raw fasi e le mafai ona faʻaletonuina i se fasi ona o le faʻasino tusi e leai se aoga tuatusi.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Faʻafoʻi mai se faʻailoga e leai se aoga i le buffer a le fasi.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // SAOGALEMU: Ua ma iloa `self` o lē soloia.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Faʻafoʻi mai se faʻasino tusi i le buffer a fasi.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Toe foi se faasinomaga faasoa i se fasi o tulaga faatauaina mafai uninitialized.I le faatusatusa atu i [`as_ref`], o lenei e le manaomia ai e faapea e tatau ona initialized le taua.
    ///
    /// Mo le sui fesuiaʻi vaʻai [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Pe a valaauina lenei auala, e tatau ona mautinoa e moni le uma nei:
    ///
    /// * O le faʻasino tusi e tatau ona [valid] mo faitauga mo `ptr.len() * mem::size_of::<T>()` tele bytes, ma e tatau ona faʻasaʻo lelei.O lona uiga faʻapitoa:
    ///
    ///     * O le atoa manatua vaega o lenei fasi tatau ona aofia ai i totonu o se tasi atofaina mea!
    ///       Fasi e le mafai oʻo i totonu o le tele o mea atofaina.
    ///
    ///     * O le faʻasino tusi e tatau ona faʻatasia tusa lava mo zero-umi fasi.
    ///     Tasi mafuaʻaga mo lenei o le enum faʻataʻitaʻiga faʻamautinoaina mafai ona faʻamoemoe i faʻasino (aofia ai fasi o soʻo se umi) o gatasi ma leai-leai e vaʻaia ai latou mai isi faʻamaumauga.
    ///
    ///     E mafai ona e mauaina se faʻasino tusi e mafai ona faʻaaoga e pei o `data` mo fasi e leai se umi e faʻaaoga ai [`NonNull::dangling()`].
    ///
    /// * O le aofaʻi tele `ptr.len() * mem::size_of::<T>()` o le fasi e tatau ona le sili atu nai lo `isize::MAX`.
    ///   Vaʻai le saogalemu pepa faʻamaumauga o [`pointer::offset`].
    ///
    /// * E tatau ona e faʻamalosia tulafono faʻaigoa a le Rust, talu ai o le olaga ua toe foʻi mai `'a` ua filifilia faʻapitoa ma e le o atagia mai ai le moni moni o le taimi o faʻamatalaga.
    ///   Ae maise lava, mo le umi o lenei olaga, o le manatuaina o le faʻasino tusi e le tatau ona suia (seʻi vagana totonu `UnsafeCell`).
    ///
    /// E faʻapipiʻi lenei mea tusa lava pe le o faʻaaogaina le iʻuga o lenei metotia!
    ///
    /// Vaʻai foi [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Faʻafoʻi mai se tulaga ese faʻasino i se fasi vaega atonu e leʻo faʻatauaina taua.E faʻatusatusa i le [`as_mut`], e le manaʻomia le amataina o le tau.
    ///
    /// Mo le vaega faʻasoa vaʻai [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Pe a valaauina lenei auala, e tatau ona mautinoa e moni le uma nei:
    ///
    /// * O le faʻasino tusi e tatau ona [valid] mo faitau ma tusitusi mo `ptr.len() * mem::size_of::<T>()` tele bytes, ma e tatau ona faʻasaʻo lelei.O lona uiga faʻapitoa:
    ///
    ///     * O le atoa manatua vaega o lenei fasi tatau ona aofia ai i totonu o se tasi atofaina mea!
    ///       Fasi e le mafai oʻo i totonu o le tele o mea atofaina.
    ///
    ///     * O le faʻasino tusi e tatau ona faʻatasia tusa lava mo zero-umi fasi.
    ///     Tasi mafuaʻaga mo lenei o le enum faʻataʻitaʻiga faʻamautinoaina mafai ona faʻamoemoe i faʻasino (aofia ai fasi o soʻo se umi) o gatasi ma leai-leai e vaʻaia ai latou mai isi faʻamaumauga.
    ///
    ///     E mafai ona e mauaina se faʻasino tusi e mafai ona faʻaaoga e pei o `data` mo fasi e leai se umi e faʻaaoga ai [`NonNull::dangling()`].
    ///
    /// * O le aofaʻi tele `ptr.len() * mem::size_of::<T>()` o le fasi e tatau ona le sili atu nai lo `isize::MAX`.
    ///   Vaʻai le saogalemu pepa faʻamaumauga o [`pointer::offset`].
    ///
    /// * E tatau ona e faʻamalosia tulafono faʻaigoa a le Rust, talu ai o le olaga ua toe foʻi mai `'a` ua filifilia faʻapitoa ma e le o atagia mai ai le moni moni o le taimi o faʻamatalaga.
    ///   Ae maise lava, mo le umi o lenei olaga, o le manatuaina o le faʻasino tusi e le tatau ona mauaina (faitau pe tusia) e ala i soʻo se isi faʻasino tusi.
    ///
    /// E faʻapipiʻi lenei mea tusa lava pe le o faʻaaogaina le iʻuga o lenei metotia!
    ///
    /// Vaʻai foi [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // E sefe le mea lea a o `memory` e aoga mo faitauga ma tusitusi mo `memory.len()` tele bytes.
    /// // Manatua o le valaʻau `memory.as_mut()` e le faʻatagaina iinei ona o mea i totonu e ono le amanaiaina.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Faʻafoʻi mai se maka manino i se elemeni poʻo se tautua, e aunoa ma le faia o ni tuaoi siaki.
    ///
    /// O le valaʻauina o lenei metotia ma se faʻasino i fafo atu o tuaoi pe a le faʻaaogaina le `self` e *[amioga le faʻamatalaina]* tusa lava pe le o faʻaaogaina le faʻasino tusi.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // SAFETY: o le tagata valaʻau mautinoa le `self` e faʻaletonu ma `index` i totonu o tuaoi.
        // O se faʻaiuga, o le faʻaiuga faʻasino mafai ona le NUL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // SAFETY: O se Faʻailoga tulaga ese e le mafai ona faʻaleaogaina, o lea o tuutuuga mo
        // new_unchecked() e faʻaaloalo.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SAFETY: O se fesuiaʻi mau e le mafai ona faaleaogaina.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // SAOGALEMU: O se faamatalaga e le mafai ona soloia, e faapena le tulaga mo
        // new_unchecked() e faʻaaloalo.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}