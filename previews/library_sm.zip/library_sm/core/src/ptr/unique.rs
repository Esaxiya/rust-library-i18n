use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// O se afifi o loo siomia ai a lē soloia `*mut T` mata lea e faailoa ai e faapea o le possessor o lenei afifi umia le referent.
/// E aoga mo le fausiaina o mea e le masani ai e pei o `Box<T>`, `Vec<T>`, `String`, ma `HashMap<K, V>`.
///
/// E le pei o `*mut T`, `Unique<T>` amio "as if" o se faʻataʻitaʻiga o `T`.
/// E faʻaaogaina `Send`/`Sync` peʻa `T` o `Send`/`Sync`.
/// Ai foi e faatatau i le ituaiga o faamaoniga malosi aliasing e mafai ona faamoemoe se faataitaiga o `T`:
/// e le tatau ona toe teuteu le faʻasino tusi e aunoa ma se auala tulaga ese i lona umiaina Tulaga Ese.
///
/// Afai e te le o mautinoa pe e saʻo e faʻaaoga `Unique` mo au mafuaʻaga, mafaufau e faʻaaoga le `NonNull`, e i ai le semantics vaivai.
///
///
/// E le pei o `*mut T`, o le faasino ai e tatau ona avea i taimi uma e le soloia, e tusa lava pe afai o le faasino o loo lava dereferenced.
/// O lenei ina ia mafai ai e enums ona faʻaaogaina lenei faʻasaina taua o se faʻailoga tagata-`Option<Unique<T>>` e tutusa lona tele ma le `Unique<T>`.
/// Ae peitai e mafai pea dangle pe afai e le dereferenced le faasino ai.
///
/// E le pei o `*mut T`, `Unique<T>` e faʻaopoopo ile `T`.
/// O lenei e tatau ona saʻo i taimi uma mo so o se ituaiga lea tausisia manaoga aliasing a Tulaga Ese.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: e leai se taunuuga o lenei faailoga mo variance, ae e tatau
    // mo dropck ia malamalama o tatou talafeagai a tatou `T`.
    //
    // Mo faʻamatalaga, vaʻai:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` o faʻasino e `Send` pe a fai o `T` o `Send` aua o faʻamatalaga na latou tuʻuina mai e leʻo faʻaalia.
/// Manatua o lenei aliasing invariant e le faʻamalosia e le ituaiga faiga;o le faʻatulagaina o le `Unique` tatau ona faʻamalosia.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` o faʻasino e `Sync` pe a fai o `T` o `Sync` aua o faʻamatalaga na latou tuʻuina mai e leʻo faʻaalia.
/// Manatua o lenei aliasing invariant e le faʻamalosia e le ituaiga faiga;o le faʻatulagaina o le `Unique` tatau ona faʻamalosia.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Faatupu ai se `Unique` fou ua dangling, ae lelei ogatasi.
    ///
    /// E aoga lea mo le amataina o ituaiga e paie faʻasoasoa, pei ole `Vec::new` faia.
    ///
    /// Manatua o le faʻasino faʻatomuaga ono ono avea ma sui o se faʻatonu lelei faʻasino i le `T`, o lona uiga e le tatau ona faʻaaogaina o se "not yet initialized" sentinel aoga.
    /// Ituaiga e paie faʻasoa e tatau ona siaki amataina i nisi auala.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // SAFETY: mem::align_of() toe faafoi mai se aoga, leai-leai faʻasino tusi.O le
        // tulaga e valaʻau ai i le new_unchecked() o loʻo faʻaaloalo.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Faatupu ai se `Unique` fou.
    ///
    /// # Safety
    ///
    /// `ptr` tatau ona leai se aoga.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SAFETY: o le tagata telefoni e tatau ona mautinoa o `ptr` e leai.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Fausia se `Unique` fou pe a fai o `ptr` e leai se aoga.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SAFETI: Ua uma ona siaki le faʻasino ma e le o null.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Mauaina le faʻavae `*mut` faʻasino faasino.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Faʻaleaogaina le aano.
    ///
    /// O le iʻuga o le olaga atoa e noatia ia oe lava, o lenei amio "as if" o se mea moni o se faʻataʻitaʻiga o T o loʻo nonoina.
    /// Afai e manaʻomia le umi o le (unbound) olaga atoa, faʻaaoga le `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SAFETY: o le tagata telefoni e tatau ona mautinoa o `self` feiloai uma
        // manaʻoga mo se faʻasino.
        unsafe { &*self.as_ptr() }
    }

    /// E mafai ona suia le mataupu.
    ///
    /// O le iʻuga o le olaga atoa e noatia ia oe lava, o lenei amio "as if" o se mea moni o se faʻataʻitaʻiga o T o loʻo nonoina.
    /// Afai e manaomia se olaga atoa toe (unbound), faaaoga `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SAFETY: o le tagata telefoni e tatau ona mautinoa o `self` feiloai uma
        // manaʻoga mo se faʻavasega suiga.
        unsafe { &mut *self.as_ptr() }
    }

    /// Tuliesea i se e faasino ai o se isi ituaiga.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // SAFETY: Unique::new_unchecked() fausiaina se fou tulaga ese ma manaʻoga
        // o le faʻasino faasino e aua le faʻaleaogaina.
        // Talu ai tatou o pasi atu ia tatou lava o se faasino upu, e le mafai ona null.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SAFETY: O se fesuiaʻi mau e le mafai ona faaleaogaina
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}