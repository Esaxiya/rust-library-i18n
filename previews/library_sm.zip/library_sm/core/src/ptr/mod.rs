//! Faʻatonutonu puleaina le manatuaina e ala i mata faigofie.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Tele gaioiga i lenei vaega ave mata mata e avea ma finauga ma faitau mai pe tusi ia latou.Mo lenei e saogalemu, e tatau ona nei vae *aloaia*.
//! Pe aoga le faʻasino tusi faʻalagolago i le faʻagaioiga o loʻo faʻaaogaina mo (faitau pe tusitusi), ma le lautele o le manatua na mauaina (faʻapea, e fia bytes o read/written).
//! O le tele o gaioiga e faʻaaoga le `*mut T` ma le `* const T` e faʻaaoga ai naʻo le tasi le aoga, ma o le tulaga lea e aveʻesea ai e le pepa le tele ma faʻapea o le `size_of::<T>()` bytes.
//!
//! O tulafono tonu mo le aoga e leʻi fuafuaina.O faʻamaoniga ua saunia i lenei taimi e matua laitiiti lava:
//!
//! * O le [null] faʻasino tusi e *le mafai* aoga, e oʻo lava i le faʻaaogaina o [size zero][zst].
//! * Mo se faʻasino tusi ia aoga, e talafeagai, ae le o taimi uma e tatau ai, o le faʻasino ia *tatau ona manaʻomia*: o le faʻamanatuina o le tele na tuʻuina mai e amata i le faʻasino e tatau ona i ai uma i totonu o tuaoi o se mea e tasi tuʻuina atu.
//!
//! Manatua o le Rust, o (stack-allocated) fesuiaʻiga uma e manatu o se 'eseʻese tuʻufaʻatasia mea.
//! * E oʻo lava i le faʻagaioiga o le [size zero][zst], e le tatau ona tusi le faʻasino i mea e manaʻomia, e pei o le faʻatulagaina o faʻatonuga e le aoga ai faʻasino e oʻo lava i le tele o galuega.
//! Peitaʻi, o le togiina o soʻo se fuainumera fuainumera *moni* i se faʻasino tusi e aoga mo leai-tele ulufale, tusa lava pe i ai ni manatua na tupu o loʻo i ai i lena tuatusi ma amata faʻasese.
//! E faʻatatau lea i le tusiaina o lau oe tufatufaina atu: o le tufatufaina o ni mea tetele e le faigata tele.
//! O le canonical auala e maua ai se faʻasino tusi e aoga mo leai-tele ulufale o [`NonNull::dangling`].
//! * O auala uma e faʻaaogaina e lenei galuega o le *non-atomic* i le uiga o le [atomic operations] e faʻafesoʻotaʻi ai filo.
//! O lenei auala e undefined amioga e faatino sosoo accesses lua i le nofoaga lava lea e tasi mai filo eseese vagana na uma accesses faitau mai le mafaufau.
//! Matau o lenei e manino lava aofia ai [`read_volatile`] ma [`write_volatile`]: Faʻaaoga gofie e le mafai ona faʻaaogaina mo inter-filo faʻatasi.
//! * O le taunuuga o le faia o se faasinomaga i se e faasino ai e aloaia mo le umi e pei o le mea faavae o le ola ma e leai se faasinomaga (na o vae mata) ua faaaogaina e avanoa le manatu e tasi.
//!
//! O nei auivi, faʻatasi ai ma le faʻaaoga ma le faʻaeteete o le [`offset`] mo faʻasino tusi, ua lava e faʻaoga saʻo ai le tele o mea aoga i le le saogalemu code.
//! o le a tuuina atu e faamau ai aitalafu malosi mulimuli ane, e pei o le ua fuafuaina tulafono [aliasing].
//! Mo nisi faʻamatalaga, vaʻai ile [book] faʻapea foʻi ma le vaega i le faʻasino tuʻuina atu i le [undefined behavior][ub].
//!
//! ## Alignment
//!
//! vae mata o aoga e pei ona faamatalaina i luga e le o lelei ogatusa (i nofoaga ua faamatalaina gatasi "proper" e le ituaiga pointee, o lona uiga, e tatau ona ogatusa `*const T` e `mem::align_of::<T>()`).
//! Ae ui i lea, o le tele o galuega e manaʻomia ai a latou finauga ina ia faʻafetaui lelei, ma o le a faʻailoa manino mai lenei manaʻoga i a latou tusitusiga.
//! E le gata i lea o [`read_unaligned`] ma [`write_unaligned`].
//!
//! Pe o se galuega tauave e manaomia ai ia talafeagai lelei, ona ia faia ai e tusa lava pe afai o le avanoa ua tele 0, o lona uiga, e tusa lava pe afai e le moni paʻi manatua.Mafaufau e faʻaaoga le [`NonNull::dangling`] i ia tulaga.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Faʻataʻitaʻia le tagata faʻaleagaina (pe a fai e iai) le faʻatatau i le tau.
///
/// E tutusa lenei mea ma le valaʻauina o le [`ptr::read`] ma tiaʻi le iʻuga, ae iai mea lelei nei:
///
/// * E manaʻomia * e faʻaaoga le `drop_in_place` e faʻapaʻu i lalo ituaiga faʻamaʻa e pei o trait mea, aua e le mafai ona faitauina i luga o le faʻaputuga ma paʻu masani.
///
/// * E sili atu le faʻauo i le tagata faʻamautinoa e faia lenei mea i luga o le [`ptr::read`] pe a paʻu lima tuʻufaʻatasia manatua (eg, i le faʻatinoina o `Box`/`Rc`/`Vec`), ona o le tuʻufaʻatasia e le manaʻomia le faʻamaonia o le leo e aveʻese le kopi.
///
///
/// * E mafai ona faʻaaogaina e faʻapaʻu ai le [pinned] faʻamatalaga pe a le `T` e le o `repr(packed)` (o faʻamaumauga e le tatau ona minoi ae e leʻi faʻapaʻuina).
///
/// E le mafai ona faʻauʻu ese tulaga taua e leʻo faʻailoaina i le nofoaga, ae tatau ona kopiina i se nofoaga tuʻufaʻatasia muamua faʻaaoga ai le [`ptr::read_unaligned`].Mo ato teu, o lenei gaioiga e faia otometi e le tuʻufaʻatasia.
/// O lona uiga o fanua o teu afifi e le faʻapaʻu i totonu-nofoaga.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Amioga ua undefined pe afai o so o se ua solia ai tuutuuga nei:
///
/// * `to_drop` tatau ona [valid] mo faitau uma ma tusitusi.
///
/// * `to_drop` e tatau ona ogatusa lelei.
///
/// * O le taua `to_drop` togi e tatau ona aoga mo le pa'ū, o lona uiga e tatau ona lagolagoina isi invariants, o lenei ituaiga-faʻalagolago.
///
/// Gata i lea, pe afai `T` e le [`Copy`], e faaaoga ai le faasino-i tulaga faatauaina ua valaau e mafai ona mafua `drop_in_place` amioga undefined.Manatua o `*to_drop = foo` faitau o se faʻaaoga ona o le a mafua ai ona toe paʻu i lalo le tau.
/// [`write()`] mafai ona faʻaaogaina e soʻose faʻamatalaga e aunoa ma le mafua ai ona paʻu.
///
/// Manatua e tusa lava pe o le `T` e tele `0`, o le faʻasino tusi e tatau ona le-NULL ma faʻafetaui lelei.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Faʻaaoga aveese le mea mulimuli mai le vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Maua se faʻasino tonu i le vaega mulimuli i le `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Faʻapuʻupuʻu `v` e taofi ai le mulimuli mea mai le pa'ū i lalo.
///     // Tatou te faia lena mea muamua, e puipuia ai mataupu pe afai o le `drop_in_place` lalo panics.
///     v.set_len(1);
///     // A aunoa ma se valaʻau `drop_in_place`, o le aitema mulimuli o le a le tuʻuina i lalo, ma o le manatuaga na te puleaina o le a faʻasalalauina.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Ia mautinoa o le aitema mulimuli na paʻu i lalo.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Faasilasilaga o le tuufaatasia faatinoina lenei kopi otometi lava ina pau structs teu, o lona uiga, e te le masani ai e popole e uiga i sea mataupu sei vagana ua e valaau manually `drop_in_place`.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Tulafono iinei e le mataupu, ua suia lenei e le kelu moni mataua e ala i le tuufaatasia.
    //

    // SAOGALEMU: tagai i faamatalaga i luga
    unsafe { drop_in_place(to_drop) }
}

/// Fausia se null raw pointer.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Fausia se faʻaleaogaina faʻafanua mata suia.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Tusi lesona tusi manaʻomia e aloese mai `T: Clone` fusifusia.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Tusi lesona tusi manaʻomia e aloese mai `T: Copy` fusifusia.
impl<T> Copy for FatPtr<T> {}

/// Fausia se fasi mata mai se faʻasino tusi ma le umi.
///
/// O le finauga `len` o le numera o **elemene**, ae le o le numera o bytes.
///
/// o le saogalemu o lenei galuega tauave, ae moni lava le faaaogaina o le taua le toe foi o le saogalemu.
/// Vaʻai faʻamaumauga o [`slice::from_raw_parts`] mo fasi saogalemu manaʻoga.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // fai se fasi faʻasino tusi pe a amata i fafo ma se faʻasino i le muamua elemene
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // SAOGALEMU: mauaina o le taua mai le saogalemu iuni `Repr` talu * const [T]
        //
        // ma FatPtr ia tutusa manatua faʻatulagaina.Na std mafai ona e faia lenei faamaoniga.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Faʻatautaia le tutusa gaioiga e pei o le [`slice_from_raw_parts`], seʻi vagana ua toe faʻafoʻi mai se fasi mutable mutia, e ese mai i se fasi e le mafai ona suia.
///
///
/// Tagai i le pepa o [`slice_from_raw_parts`] mo nisi auiliiliga.
///
/// o le saogalemu o lenei galuega tauave, ae moni lava le faaaogaina o le taua le toe foi o le saogalemu.
/// Vaʻai faʻamaumauga o [`slice::from_raw_parts_mut`] mo fasi saogalemu manaʻoga.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // tofi se tau i se faʻasino igoa i le fasi
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // SAOGALEMU: mauaina o le taua mai le saogalemu iuni `Repr` talu * mut [T]
        // ma FatPtr ia tutusa manatua faʻatulagaina
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Swaps tulaga faatauaina i nofoaga mutable e lua o le ituaiga lava e tasi, e aunoa ma deinitializing foi.
///
/// Ae mo tuusaunoaina nei e lua, o lenei gaioiga e tutusa tutusa ma [`mem::swap`]:
///
///
/// * E faagaoioia i luga o vae mata ae le o le mau.
/// A avanoa faʻasino, [`mem::swap`] e tatau ona sili i ai.
///
/// * O le lua faʻasino-i tulaga faatauaina ono fesiliaʻi.
/// A faʻapea e soʻosaʻo mea taua, ona faʻaaogaina lea o le itu fesilia o le `x`.
/// e faaalia lea i le faataitaiga lona lua o loo i lalo.
///
/// # Safety
///
/// Amioga ua undefined pe afai o so o se ua solia ai tuutuuga nei:
///
/// * Uma `x` ma `y` tatau ona avea [valid] mo uma faitau ma tusia.
///
/// * Uma `x` ma `y` tatau ona faʻasaʻo lelei.
///
/// Manatua e tusa lava pe o le `T` e tele `0`, o faʻasino e tatau ona le-NULL ma faʻafetaui lelei.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Faʻafesuiaʻi itulagi e lua e leʻo felavasaʻi:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // o le `array[0..2]` lea
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // o le `array[2..4]` lea
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Swapping itulagi lua overlapping:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // o le `array[0..3]` lea
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // o le `array[1..4]` lea
///
/// unsafe {
///     ptr::swap(x, y);
///     // O faʻailoga `1..3` o le fasi pepa e fesiliaʻi le `x` ma le `y`.
///     // O iʻuga talafeagai e mo i latou e avea ma `[2, 3]`, ina ia o faʻailoga `0..3` e `[1, 2, 3]` (tutusa `y` i luma o le `swap`);po o mo i latou e avea `[0, 1]` ina e faapea indices `1..4` `[0, 1, 2]` (tutusa `x` i luma o le `swap`).
/////
///     // O lenei faʻatinoga ua faʻamatalaina e faia ai le filifiliga mulimuli.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Tuʻu mai ia i matou lava se avanoa e olo ai e galulue ai.
    // Matou te le tau popole fua i mataua: E leai se mea e fai e `MaybeUninit` pe a pa'ū.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Faia le fesuiaiga SAFETY: o le tagata telefoni e tatau ona mautinoa o `x` ma `y` e aoga mo tusitusiga ma fetaui lelei.
    // `tmp` E le mafai ona soʻosoʻo `x` poʻo `y` foi ona o `tmp` faʻatoa tuʻuina atu i luga o le faʻapipiʻi o se tuʻufaʻatasia o mea faitino.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` ma `y` ono fesiliaʻi
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Faʻafesuiaʻi `count * size_of::<T>()` bytes i le va o vaega e lua o manatua e amata i le `x` ma le `y`.
/// Itulagi e lua e tatau ona *le* fesiliaʻi.
///
/// # Safety
///
/// Amioga ua undefined pe afai o so o se ua solia ai tuutuuga nei:
///
/// * Uma `x` ma `y` tatau ona avea [valid] mo faitau uma ma tusia o le `faitau *
///   tele_of: :<T>() `bytes
///
/// * Uma `x` ma `y` tatau ona faʻasaʻo lelei.
///
/// * Le itulagi o manatua e amata mai i `x` ma se tele o le 'faitau *
///   size_of: :<T>() 'Bytes tatau *le* fesiliaʻi i le itulagi o le manatua e amata mai i `y` ma le tele lava e tasi.
///
/// Faaaliga e tusa lava pe le tele kopiina lelei ('faitau * size_of: :<T>() `) o le `0`, o faʻasino e tatau ona le NUL ma faʻalelei lelei.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Faʻaaoga faʻavae:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // SAFETY: o le tagata telefoni e tatau ona mautinoa o `x` ma `y` o
    // aoga mo tusitusiga ma fetaui lelei.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Mo ituaiga laʻititi nai lo le poloka faʻamaonia i lalo, na fesuiaʻi saʻo e aloese mai le pessimizing codegen.
    //
    if mem::size_of::<T>() < 32 {
        // SAFETY: o le tagata telefoni e tatau ona mautinoa o `x` ma `y` e aoga
        // mo tusitusiga, faʻafetaui lelei, ma le soʻosoʻoga.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Ole auala lea e faʻaaoga ai le simd e fesuiaʻi x&y ia lelei.
    // O le suʻesuʻega e faʻaalia ai o le fesuiaʻi o 32 bytes poʻo le 64 bytes i le taimi e sili ona aoga mo le Intel Haswell E.
    // LLVM e sili atu ona mafai ona faʻaleleia pe a fai tatou te tuʻuina atu se faʻavae #[repr(simd)], tusa lava pe tatou te le o faʻaaogaina saʻo lenei faʻavae.
    //
    //
    // FIXME repr(simd) gagau luga emscripten ma redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Faʻataʻamilomilo x&y, kopiina latou `Block` i le taimi E tatau i le tagata faʻalelei ona tatala atoa le matasele mo le tele o ituaiga NB
    // E le mafai ona matou faʻaaogaina se mo matasele e pei ona faʻaigoa faʻaopoopo e le `range` impl `mem::swap`
    //
    let mut i = 0;
    while i + block_size <= len {
        // Fausia ni mea e leʻo faʻamanatuina e avea ma avanoa avanoa O le faʻalauiloaina o le `t` iinei e aloese ai mai le faʻavasegaina o le faaputuga pe a le faʻaaogaina lenei matasele
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // SAFETY: A o `i < len`, ma e pei ona tatau ona faʻamautinoa mai e le ua telefoni o `x` ma `y` e aoga
        // mo bytes `len`, e tatau ona `x + i` ma `y + i` tuatusi aloaia, lea e faataunuuina e le konekarate le saogalemu mo `add`.
        //
        // E le gata i lea, o le tagata e valaʻau e tatau ona mautinoa o `x` ma `y` e aoga mo tusitusiga, faʻafetaui lelei, ma e le soʻosoʻo faʻatasi, lea e faʻataunuuina ai le saogalemu konekarate mo `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Faafesuiaiga o se poloka o bytes o x&y, i le faaaogaina t o se buffer tumau e tatau ona optimized lenei i gaoioiga lelei SIMD maua ai
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Faʻafesuiaʻi niisi bytes
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // SAFETI: vaʻai muamua faʻamatalaga saogalemu.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Siʻi le `src` ile faʻailoga `dst`, toe faafoʻi le `dst` muamua tau.
///
/// E leai se aoga ua toʻesea.
///
/// O lenei galuega o semantically tutusa [`mem::replace`] vagana e faagaoioia i luga o vae mata ae le o le mau.
/// A avanoa faʻasino, [`mem::replace`] e tatau ona sili i ai.
///
/// # Safety
///
/// Amioga ua undefined pe afai o so o se ua solia ai tuutuuga nei:
///
/// * `dst` tatau ona [valid] mo faitau uma ma tusitusi.
///
/// * `dst` e tatau ona ogatusa lelei.
///
/// * `dst` tatau ona tusi i le talafeagai amataina taua o le ituaiga `T`.
///
/// Manatua e tusa lava pe o le `T` e tele `0`, o le faʻasino tusi e tatau ona le-NULL ma faʻafetaui lelei.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` e i ai le tutusa aafiaga e aunoa ma le manaʻomia le le saogalemu poloka.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // SAFETY: o le tagata telefoni e tatau ona mautinoa o `dst` e aoga e avea ai
    // lafo i se faʻavasega suiga (aoga mo tusitusiga, faʻatulagaina, amataina), ma le mafai ona soʻona `src` talu ai `dst` tatau ona tusi i se tuʻu eseʻese mea.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // le mafai ona fesiliaʻi
    }
    src
}

/// Faitau le tau mai `src` e aunoa ma le minoi.O lenei tuua le manatuaina i le `src` le suia.
///
/// # Safety
///
/// Amioga ua undefined pe afai o so o se ua solia ai tuutuuga nei:
///
/// * `src` tatau ona [valid] mo faitau.
///
/// * `src` tatau ona faʻasaʻo lelei.Faʻaaoga le [`read_unaligned`] pe a le o le tulaga lea.
///
/// * `src` tatau ona tusi i le talafeagai amataina taua o le ituaiga `T`.
///
/// Manatua e tusa lava pe o le `T` e tele `0`, o le faʻasino tusi e tatau ona le-NULL ma faʻafetaui lelei.
///
/// # Examples
///
/// Faʻaaoga faʻavae:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Manually faatino [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Fausia se kopi laititi o le tau ile `a` ile `tmp`.
///         let tmp = ptr::read(a);
///
///         // Exiting i lenei tulaga (e ala manino toe foi po o le ala i le valaau se galuega tauave lea panics) o le a mafua ai le taua i `tmp` ona maligi ao taʻua pea le taua lava lea e tasi e `a`.
///         // Ole mea lea e ono faʻaosofia ai amioga le faʻamatalaina pe a fai o `T` e leʻo `Copy`.
/////
/////
///
///         // Fausia se kopi laititi o le tau ile `b` ile `a`.
///         // E sefe le mea lea ona e le mafai e igoa faʻasolosolo ona suia igoa.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // E pei ona i luga, o le alu i fafo e ono faʻaosofia ai amioga le faʻamalamalamaina aua o le tutusa taua e faʻasino i ai `a` ma `b`.
/////
///
///         // Faʻasolo `tmp` i le `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` ua siitia (`write` e umiaina o ana finauga lona lua), o lea ua pa'ū implicitly leai se mea iinei.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Umiaina o le Taua toe foi
///
/// `read` faia se kopi laititi o le `T`, tusa lava pe o le `T` o le [`Copy`].
/// Afai ole `T` e leʻo [`Copy`], o le faʻaaogaina uma o le tau faʻafoʻi ma le tau ile `*src` e mafai ona solia ai le saogalemu o mea e manatua.
/// Manatua o le tofia e taulia `*src` o se faaaogaina aua o le a taumafai e aveesea le taua i `* src`.
///
/// [`write()`] mafai ona faʻaaogaina e soʻose faʻamatalaga e aunoa ma le mafua ai ona paʻu.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` tusi nei i le tutusa faʻavae manatuaga pei `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Tofia e `s2` mafua ai lona taua uluai ona maligi.
///     // I tua atu o lenei manatu, `s` tatau ona le toe faʻaaogaina, ona o le faʻavae manatu ua faʻasaʻolotoina.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // O le tofiaina i le `s` o le a mafua ai ona toe paʻu le tau tuai, ma mafua ai amioga le faʻamatalaina.
/////
///     // s= String::from("bar");//SESE
///
///     // `ptr::write` mafai ona faʻaaogaina e soʻosoʻo se tau e aunoa ma le tuʻuina i lalo.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SAFETY: o le tagata telefoni e tatau ona mautinoa o `src` e aoga mo faitau.
    // `src` E le mafai ona soʻosoʻo `tmp` aua `tmp` na faʻatulagaina i luga o le faʻaputuga o se tuʻueseʻeseina faʻatulaga mea.
    //
    //
    // E le gata i lea, talu ai na faʻatoa matou tusia se tau aoga i le `tmp`, ua mautinoa e amata faʻalelei.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Faitau le tau mai `src` e aunoa ma le minoi.O lenei tuua le manatuaina i le `src` le suia.
///
/// E le pei o [`read`], e galue `read_unaligned` i faʻailoga e leʻo saʻo.
///
/// # Safety
///
/// Amioga ua undefined pe afai o so o se ua solia ai tuutuuga nei:
///
/// * `src` tatau ona [valid] mo faitau.
///
/// * `src` tatau ona tusi i le talafeagai amataina taua o le ituaiga `T`.
///
/// Pei o [`read`], `read_unaligned` fausiaina se kopi poto o le `T`, tusa lava pe o le `T` o le [`Copy`].
/// Afai ole `T` e le o [`Copy`], faʻaaogaina uma le toe faafoʻi le tau ma le tau ile `*src` mafai [violate memory safety][read-ownership].
///
/// Manatua tusa lava pe `T` tele `0`, o le faʻasino tatau ona le-NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## I `packed` laina
///
/// E le mafai nei ona fausia ni mea faʻailoaina i fanua e leʻo saʻo o se vaega ua tumu.
///
/// Taumafai e fausia se faʻasino tonu i le `unaligned` faʻatulaga fanua ma se faʻaaliga pei o le `&packed.unaligned as *const FieldType` fausiaina se faʻatulagaina faʻavaitaʻi faʻasino igoa ae le i faʻaliliuina lena i se raw faasino tonu.
///
/// O lenei mau e faʻavaitaimi ma vave lafo e le taua tele ona o le tuʻufaʻatasia taimi uma e faʻamoemoe o faʻamatalaga e faʻasaʻo lelei.
/// O lona iʻuga, o le faʻaaogaina o le `&packed.unaligned as *const FieldType` e mafua ai le vave o amioga le faʻatino i lau polokalame.
///
/// O se faʻataʻitaʻiga o le a le mea e fai ma faʻafefea ona fesoʻotaʻi lenei i `read_unaligned` o le:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Lenei matou te taumafai e ave le tuatusi o le 32-bit integer e le o gatasi.
///     let unaligned =
///         // O se taimi le tumau saʻo le faʻasino fesoʻotaʻiga ua faia iinei lea e mafua ai le le faʻamatalaina amio e tusa lava pe o le faʻasino na faʻaaogaina pe leai.
/////
///         &packed.unaligned
///         // E le fesoasoani le togi i se tusi faʻasino mata;o le mea sese ua uma ona tupu.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// O le faʻaaogaina saʻo o matata faʻafesoʻotaʻi ma eg `packed.unaligned` e saogalemu peitaʻi.
///
///
///
///
///
///
// FIXME: docs lata faavae i taunuuga o RFC #2582 ma uo.
/// # Examples
///
/// Faitau se aoga taua mai se penefita byte:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SAFETY: o le tagata telefoni e tatau ona mautinoa o `src` e aoga mo faitau.
    // `src` E le mafai ona soʻosoʻo `tmp` aua `tmp` na faʻatulagaina i luga o le faʻaputuga o se tuʻueseʻeseina faʻatulaga mea.
    //
    //
    // E le gata i lea, talu ai na faʻatoa matou tusia se tau aoga i le `tmp`, ua mautinoa e amata faʻalelei.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Overwrites se nofoaga manatua ma le taua taua e aunoa ma le faitauina poʻo le paʻu le tuai aoga.
///
/// `write` e le faʻapaʻu i lalo mea o le `dst`.
/// E sefe le mea lea, ae mafai ona faʻasolo tuʻufaʻatasiga poʻo mea e maua ai, o lea e tatau ai ona faʻaeteete ia aua neʻi soʻosi se mea e tatau ona tiaʻi.
///
///
/// E le gata i lea, e le pa'ū `src`.Semantically, `src` ua siitia i le nofoaga faasino atu e `dst`.
///
/// O lenei e talafeagai mo le amataina uninitialized manatua, po o le faʻasolosolo manatua manatua na muamua [`read`] mai.
///
/// # Safety
///
/// Amioga ua undefined pe afai o so o se ua solia ai tuutuuga nei:
///
/// * `dst` tatau ona [valid] mo tusitusiga.
///
/// * `dst` tatau ona faʻasaʻo lelei.Faʻaaoga [`write_unaligned`] pe a le o le tulaga lea.
///
/// Manatua e tusa lava pe o le `T` e tele `0`, o le faʻasino tusi e tatau ona le-NULL ma faʻafetaui lelei.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Faʻaaoga faʻavae:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Manually faatino [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Fausia se kopi laititi o le tau ile `a` ile `tmp`.
///         let tmp = ptr::read(a);
///
///         // Exiting i lenei tulaga (e ala manino toe foi po o le ala i le valaau se galuega tauave lea panics) o le a mafua ai le taua i `tmp` ona maligi ao taʻua pea le taua lava lea e tasi e `a`.
///         // Ole mea lea e ono faʻaosofia ai amioga le faʻamatalaina pe a fai o `T` e leʻo `Copy`.
/////
/////
///
///         // Fausia se kopi laititi o le tau ile `b` ile `a`.
///         // E sefe le mea lea ona e le mafai e igoa faʻasolosolo ona suia igoa.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // E pei ona i luga, o le alu i fafo e ono faʻaosofia ai amioga le faʻamalamalamaina aua o le tutusa taua e faʻasino i ai `a` ma `b`.
/////
///
///         // Faʻasolo `tmp` i le `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` ua siitia (`write` e umiaina o ana finauga lona lua), o lea ua pa'ū implicitly leai se mea iinei.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // O loʻo matou valaʻau tuʻusaʻo i mea o loʻo i totonu e aloese mai le faʻaaogaina o valaʻau i le code faia e pei o `intrinsics::copy_nonoverlapping` o se afifi galuega.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // SAFETY: o le tagata telefoni e tatau ona mautinoa o `dst` e aoga mo tusitusiga.
    // `dst` E le mafai ona soʻosoʻo `src` aua o le tagata e valaʻau e mafai ona suia avanoa i `dst` ae o `src` e anaina e lenei gaioiga.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Overwrites se nofoaga manatua ma le taua taua e aunoa ma le faitauina poʻo le paʻu le tuai aoga.
///
/// E le pei o le [`write()`], o le faʻasino tusi e ono le fetaui.
///
/// `write_unaligned` e le faʻapaʻu i lalo mea o le `dst`.o le saogalemu o lenei, ae e mafai ona mama o le faasoasoaina po o punaoa, ina le tausiga e tatau ona faia e le overwrite se mea e tatau ona pau.
///
/// E le gata i lea, e le pa'ū `src`.Semantically, `src` ua siitia i le nofoaga faasino atu e `dst`.
///
/// O lenei e talafeagai mo le amataina uninitialized manatua, po o le faʻasolosolo manatua manatua na muamua faitau ma [`read_unaligned`].
///
/// # Safety
///
/// Amioga ua undefined pe afai o so o se ua solia ai tuutuuga nei:
///
/// * `dst` tatau ona [valid] mo tusitusiga.
///
/// Manatua tusa lava pe `T` tele `0`, o le faʻasino tatau ona le-NULL.
///
/// [valid]: self#safety
///
/// ## I `packed` laina
///
/// E le mafai nei ona fausia ni mea faʻailoaina i fanua e leʻo saʻo o se vaega ua tumu.
///
/// Taumafai e fausia se faʻasino tonu i le `unaligned` faʻatulaga fanua ma se faʻaaliga pei o le `&packed.unaligned as *const FieldType` fausiaina se faʻatulagaina faʻavaitaʻi faʻasino igoa ae le i faʻaliliuina lena i se raw faasino tonu.
///
/// O lenei mau e faʻavaitaimi ma vave lafo e le taua tele ona o le tuʻufaʻatasia taimi uma e faʻamoemoe o faʻamatalaga e faʻasaʻo lelei.
/// O lona iʻuga, o le faʻaaogaina o le `&packed.unaligned as *const FieldType` e mafua ai le vave o amioga le faʻatino i lau polokalame.
///
/// O se faataitaiga o le mea e fai ma le auala lenei e faasino i `write_unaligned` o le:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Lenei matou te taumafai e ave le tuatusi o le 32-bit integer e le o gatasi.
///     let unaligned =
///         // O se taimi le tumau saʻo le faʻasino fesoʻotaʻiga ua faia iinei lea e mafua ai le le faʻamatalaina amio e tusa lava pe o le faʻasino na faʻaaogaina pe leai.
/////
///         &mut packed.unaligned
///         // E le fesoasoani le togi i se tusi faʻasino mata;o le mea sese ua uma ona tupu.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// O le faʻaaogaina saʻo o matata faʻafesoʻotaʻi ma eg `packed.unaligned` e saogalemu peitaʻi.
///
///
///
///
///
///
///
///
///
// FIXME: docs lata faavae i taunuuga o RFC #2582 ma uo.
/// # Examples
///
/// Tusi se aoga faʻaoga i se paita pafa:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // SAFETY: o le tagata telefoni e tatau ona mautinoa o `dst` e aoga mo tusitusiga.
    // `dst` E le mafai ona soʻosoʻo `src` aua o le tagata e valaʻau e mafai ona suia avanoa i `dst` ae o `src` e anaina e lenei gaioiga.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // O loʻo matou valaʻau tuʻusaʻo i totonu tagata e aloese mai le faʻaaogaina o valaʻau i le tulafono faʻavae.
        intrinsics::forget(src);
    }
}

/// Faia se le mautonu faitau o le taua mai `src` e aunoa ma le minoi.O lenei tuua le manatuaina i le `src` le suia.
///
/// O gofie gaioiga e faʻamoemoe e galue i luga o le I/O memory, ma e mautinoa e le tuʻulafoaʻi pe toe faʻafouina e le tuʻufaʻatasia i isi galuega gaogao.
///
/// # Notes
///
/// O le Rust e le o i ai i le taimi nei se faʻamaoniga maʻoti ma le faʻamalamalamaina faʻamanatuina faʻatusa, o lea o le tonu semantics o le a le "volatile" o lona uiga iinei e mafai ona suia i le taimi.
/// O le fai mai, o semantics o le a toeititi lava uma mulimuli ane foliga tutusa ma [C11's definition of volatile][c11].
///
/// E le tatau ona suia e le tagata tuʻufaʻatasia le faʻatonuga poʻo le aofaʻi o gaioiga e manatua pea.
/// Ae ui i lea, o gaioiga manatuaina lemu i luga o ituaiga o lapoʻa (faʻataʻitaʻiga, pe afai o le zero-tele ituaiga ua pasi atu i le `read_volatile`) e leai ma e ono le amanaiaina.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Amioga ua undefined pe afai o so o se ua solia ai tuutuuga nei:
///
/// * `src` tatau ona [valid] mo faitau.
///
/// * `src` e tatau ona ogatusa lelei.
///
/// * `src` tatau ona tusi i le talafeagai amataina taua o le ituaiga `T`.
///
/// Pei o [`read`], `read_volatile` fausiaina se kopi poto o le `T`, tusa lava pe o le `T` o le [`Copy`].
/// Afai ole `T` e le o [`Copy`], faʻaaogaina uma le toe faafoʻi le tau ma le tau ile `*src` mafai [violate memory safety][read-ownership].
/// Ae peitai, o le teuina o lē ['Copy`] ituaiga i manatua volatile e toetoe lava a mautinoa le saʻo.
///
/// Manatua e tusa lava pe o le `T` e tele `0`, o le faʻasino tusi e tatau ona le-NULL ma faʻafetaui lelei.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Pei lava ile C, pe o se gaioiga e vevesi e leai sona aoga poʻo le a lava i luga o fesili e aofia ai le o gatasi faʻatasi mai le tele filo.Faʻaaoga gofie e faʻatinoina lava e pei o le faʻaaogaina o le atomika i lena tulaga.
///
/// Aemaise lava, o se tuuga i le va o se `read_volatile` ma so o se tusi faagaoioia i le tasi nofoaga o amioga undefined.
///
/// # Examples
///
/// Faʻaaoga faʻavae:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // E panicking e tausia laiti codegen aafiaga.
        abort();
    }
    // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Faʻataʻitaʻi se tusi gagau o se nofoaga manatua ma le taua taua e aunoa ma le faitauina poʻo le paʻu le tuai aoga.
///
/// O gofie gaioiga e faʻamoemoe e galue i luga o le I/O memory, ma e mautinoa e le tuʻulafoaʻi pe toe faʻafouina e le tuʻufaʻatasia i isi galuega gaogao.
///
/// `write_volatile` e le faʻapaʻu i lalo mea o le `dst`.o le saogalemu o lenei, ae e mafai ona mama o le faasoasoaina po o punaoa, ina le tausiga e tatau ona faia e le overwrite se mea e tatau ona pau.
///
/// E le gata i lea, e le pa'ū `src`.Semantically, `src` ua siitia i le nofoaga faasino atu e `dst`.
///
/// # Notes
///
/// O le Rust e le o i ai i le taimi nei se faʻamaoniga maʻoti ma le faʻamalamalamaina faʻamanatuina faʻatusa, o lea o le tonu semantics o le a le "volatile" o lona uiga iinei e mafai ona suia i le taimi.
/// O le fai mai, o semantics o le a toeititi lava uma mulimuli ane foliga tutusa ma [C11's definition of volatile][c11].
///
/// E le tatau ona suia e le tagata tuʻufaʻatasia le faʻatonuga poʻo le aofaʻi o gaioiga e manatua pea.
/// Ae ui i lea, o gaioiga manatuaina lemu i luga o ituaiga o lapoʻa (faʻataʻitaʻiga, pe afai o le zero-tele ituaiga ua pasi atu i le `write_volatile`) e leai ma e ono le amanaiaina.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Amioga ua undefined pe afai o so o se ua solia ai tuutuuga nei:
///
/// * `dst` tatau ona [valid] mo tusitusiga.
///
/// * `dst` e tatau ona ogatusa lelei.
///
/// Manatua e tusa lava pe o le `T` e tele `0`, o le faʻasino tusi e tatau ona le-NULL ma faʻafetaui lelei.
///
/// [valid]: self#safety
///
/// Pei lava ile C, pe o se gaioiga e vevesi e leai sona aoga poʻo le a lava i luga o fesili e aofia ai le o gatasi faʻatasi mai le tele filo.Faʻaaoga gofie e faʻatinoina lava e pei o le faʻaaogaina o le atomika i lena tulaga.
///
/// Ae maise lava, o le tuʻuga i le va o le `write_volatile` ma soʻo se isi lava faʻagaioiga (faitau poʻo le tusitusi) i luga o le nofoaga e tasi e leʻo faʻamatalaina amioga.
///
/// # Examples
///
/// Faʻaaoga faʻavae:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // E panicking e tausia laiti codegen aafiaga.
        abort();
    }
    // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Faʻasaʻo le togi `p`.
///
/// Fuafua offset (i tuutuuga o elemene o `stride` laa) lea e tatau ona faʻaaogaina i le faʻailoga `p` ina ia faʻasino tusi `p` o le a faʻatulagaina i le `a`.
///
/// Note: O lenei faatinoga ua le faaeteete ofu i le panic.O le UB mo lenei i le panic.
/// Pau lava le suiga moni e mafai ona faia iinei o le suiga o `INV_TABLE_MOD_16` ma fesoʻotaiga tumau.
///
/// Afai tatou te filifili e faʻaavanoa le valaʻau o le intrinsic ma le `a` e le o se malosiʻaga o le lua, atonu o le a sili atu le faʻaaoga tatau na o le suia i se faʻatamaitiiti loʻo faʻatinoina nai lo le taumafai e fetuʻunaʻi lenei mea e ofi ai lena suiga.
///
///
/// So o se fesili atu i@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Faʻaaoga saʻo o mea nei e faʻaleleia atili ai le codegen i le opt-level <=
    // 1, pe a fai o le metotia faʻaliliuga o nei faʻagaioiga e leʻo vaʻaia.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Fuafua faʻatele faʻafuaseʻi modular o `x` modulo `m`.
    ///
    /// O lenei faʻatinoga ua fuafuaina mo `align_offset` ma o loʻo mulimuli mai muamua
    ///
    /// * `m` o se mana-o-lua;
    /// * `x < m`; (pe a `x ≥ m`, pasi ile `x % m` nai lo lena)
    ///
    /// Faʻatinoina o lenei gaioiga le tatau panic.Faavavau lava.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Laulau faʻatele modular laulau modulo 2⁴=16.
        ///
        /// Manatua, o lenei laulau e le aofia ai ni tau aoga pe a fai e leai ni inverse (ie, mo `0⁻¹ mod 16`, `2⁻¹ mod 16`, ma isi)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo lea e faʻamoemoe i ai le `INV_TABLE_MOD_16`.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // SAFETY: `m` e manaʻomia le avea ma malosiaga-o-lua, o le mea lea e leai-zero.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Matou te faʻasolosolo "up" i le faʻaaogaina o le auala lea:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // seʻia oʻo i le 2²ⁿ ≥ mOna mafai lea ona tatou faʻaititia i le `m` manaʻomia i le faia o le iʻuga `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Manatua, matou te faʻaaogaina le afifiina o gaioiga iinei ma le loto i ai-o le uluaʻi faʻavae faʻaaogaina eg, toʻese mai `mod n`.
                // E matua lelei lava le faia o latou `mod usize::MAX` nai lo, aua tatou te faia le iʻuga `mod n` i le iuga lava.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // SAFETY: `a` o se malosiaga-o-lua, o le mea lea e leai-zero.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` O lenei mataupu e mafai ona faʻateleina ona faʻaaogaina i le `-p (mod a)`, peitaʻi o le faia o lea mea e taofia ai le mafai e le LLVM e filifili ni faʻatonuga pei o le `lea`.Nai lo lena tatou te fuafuaina
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // lea e tufatufaina gaioiga faataamilo i le avega-aveina, ae pessimizing `and` lava mo LLVM ia mafai ona faʻaaoga le eseesega faʻamaoniga e iloa e uiga i.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Ua uma ona faʻatulagainaYay!
        return 0;
    } else if stride == 0 {
        // Afai e le o gatasi le faʻasino tusi, ma o le elemeni e leai se tele, e leai la se aofai o elemene o le a faʻavasegaina le faʻasino tusi.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // SAFETY: a o le malosi-o-lua o lea e leai-zero.stride==0 mataupu ua tagofia luga.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // SAFETY: gcdpow ei ai luga-fusia o lena i le tele o numera o bits i se usize.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // SAOGALEMU: gcd o taimi uma e sili atu po o le tutusa i le 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Lenei branch solofanua mo le laina laina laina laina tutusa.
        //
        // ` p + so = 0 mod a `
        //
        // `p` Lenei o le togi faʻatulagaina, `s`, laa o `T`, `o` offset i le `T`s, ma `a`, le talosagaina faʻavasega.
        //
        // I le `g = gcd(a, s)`, ma le faʻamatalaga i luga o loʻo faʻamaonia mai ai o `p` e mafai foi ona vaʻaia e `g`, e mafai ona tatou faʻailoaina `a' = a/g`, `s' = s/g`, `p' = p/g`, ona avea lea o lenei ma tutusa ma:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // O le kuata muamua o le "the relative alignment of `p` to `a`" (vaevaeina e le `g`), o le lona lua o faʻaupuga o le "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (toe vaevaeina e `g`).
        //
        // Vaeluaina e `g` e talafeagai e faia ai le faʻafeagai lelei fausia pe a fai `a` ma `s` e le felagolagomaʻi.
        //
        // E le gata i lea, o le taunuʻuga na faia e lenei fofo e le "minimal", o lea e tatau ai ona ave le faʻaiuga `o mod lcm(s, a)`.E mafai ona tatou suia le `lcm(s, a)` i le na o le `a'`.
        //
        //
        //
        //
        //

        // SAFETY: `gcdpow` ei ai luga-fusia e le sili atu nai lo le numera o trailing 0-bits i `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // SAFETY: `a2` e leai-leai.Sifi `a` e `gcdpow` le mafai ona suia i fafo soʻo se seti faagutu
        // i le `a` (e tasi lava le tasi).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // SAFETY: `gcdpow` ei ai luga-fusia e le sili atu nai lo le numera o trailing 0-bits i `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // SAOGALEMU: `gcdpow` ei ai se le noatia-luga sili atu nai lo le aofai o trailing 0-faagutu i
        // `a`.
        // E le gata i lea, o le toʻesea e le mafai ona ova, ona o `a2 = a >> gcdpow` o le a sili atu le matua sili atu nai lo `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // SAFETY: `a2` o se malosiaga-o-lua, pei ona faʻamaonia i luga.`s2` e matuaʻi laʻititi ifo i le `a2`
        // aua o `(s % a) >> gcdpow` e matua paʻu lava i le `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // E le mafai ona ogatusa i uma.
    usize::MAX
}

/// Faʻatusatusa faʻasino mata mo tutusa.
///
/// E tutusa lava ma le faʻaaogaina o le `==` operator, ae laʻititi ifo le lautele:
/// o finauga e tatau ona avea ma `*const T` raw pointers, ae le o se mea e faʻaaogaina `PartialEq`.
///
/// Lenei mafai ona faʻaaogaina e faʻatusatusa `&T` faʻasino (e faʻamalosi i `*const T` faʻaalia) i la latou tuatusi nai lo le faʻatusatusaina o tulaga faatauaina latou faʻasino i (o le a le `PartialEq for &T` faʻatinoina faia).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// O fasi pepa e faʻatusatusaina foʻi ile latou umi (fat point):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits e faʻatusatusa foʻi i lo latou faʻatinoina:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Faʻasino upu tutusa.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // O mea faitino e tutusa o latou tuatusi, ae e eseʻese faʻatinoga a le `Trait`.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Faʻaliliuga o le faʻamatalaga i se `*const u8` faʻatusatusa ile tuatusi.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Asa a faasino ai mata.
///
/// Lenei mafai ona faʻaaogaina e faʻapipiʻi ai le `&T` faʻasino (lea e faʻamalosi i `*const T` faʻaalia) e lona tuatusi nai lo le aoga o loʻo faʻasino i ai (o le a le `Hash for &T` faʻatinoina faia).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Faʻaaoga mo galuega faʻasino
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: O le va feololo lafo pei usize e manaomia mo AVR
                // o lea o le tuatusi avanoa o le punavai galuega faʻasino vaitau e faʻasaoina i le faʻatonuina mulimuli faʻasino.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: O le va feololo lafo pei usize e manaomia mo AVR
                // o lea o le tuatusi avanoa o le punavai galuega faʻasino vaitau e faʻasaoina i le faʻatonuina mulimuli faʻasino.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Leai ni fesuiaiga gaioiga ma 0 tapulaʻa
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Fausia se `const` raw pointer i se nofoaga, aunoa ma le fausiaina o se vaogatotonu faʻasino.
///
/// Fausiaina se faʻasino ma le `&`/`&mut` e faʻatagaina pe a fai o le faʻasino tusi e fetaui lelei ma faʻasino i faʻamaumauga muamua.
/// Mo mataupu e le taofia ai na manaʻoga, e tatau ona faʻaaoga faʻasino mata.
/// Peitaʻi, `&expr as *const _` faia se faʻasino i luma o lafoina i se raw faʻasino, ma o lena faʻasino e noatia i le tutusa tulafono e pei o isi uma faʻasino.
///
/// O lenei macro e mafai ona faatupuina ai se faasino mata *e aunoa ma* le fatuina o se faasinomaga muamua.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` O le a fausia ai se le faʻafetauiina faʻasino, ma o lea avea Undefined Amioga!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Fausia se `mut` raw pointer i se nofoaga, aunoa ma le fausiaina o se vaogatotonu faʻasino.
///
/// Fausiaina se faʻasino ma le `&`/`&mut` e faʻatagaina pe a fai o le faʻasino tusi e fetaui lelei ma faʻasino i faʻamaumauga muamua.
/// Mo mataupu e le taofia ai na manaʻoga, e tatau ona faʻaaoga faʻasino mata.
/// Peitaʻi, `&mut expr as *mut _` faia se faʻasino i luma o lafoina i se raw faʻasino, ma o lena faʻasino e noatia i le tutusa tulafono e pei o isi uma faʻasino.
///
/// O lenei macro e mafai ona faatupuina ai se faasino mata *e aunoa ma* le fatuina o se faasinomaga muamua.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` O le a fausia ai se le faʻafetauiina faʻasino, ma o lea avea Undefined Amioga!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` malosiaga kopiina o le fanua nai lo le faia o se faʻasino.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}