use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::mem;
use crate::slice::{self, SliceIndex};

#[lang = "const_ptr"]
impl<T: ?Sized> *const T {
    /// Faʻafoʻi `true` peʻa leai se faʻasino o le tusi.
    ///
    /// Manatua o unsized ituaiga o tele ono mafai faʻanumera, ona e naʻo le raw data faʻasino manatu, ae le o latou umi, vivel, ma isi.
    /// O le mea lea, lua manatu e leai se aoga e ono le faʻatusatusaina le tasi i le tasi.
    ///
    /// ## Amio ile taimi ole iloiloga tumau
    ///
    /// Afai e faʻaaogaina lenei galuega i le taimi o le iloiloga tumau, e ono toe faʻafoʻi mai le `false` mo faʻasino e ono leai se aoga i le taimi e uma ai le aoga.
    /// Faapitoa, pe a e faasino i nisi o manatua ua aveesea i tua atu o ona tuaoi i se auala o le taunuuga e faasino ai e soloia, o le a toe foi lava le galuega tauave `false`.
    ///
    /// E leai se ala mo CTFE e iloa ai le tulaga atoatoa o lena manatua, o lea e le mafai ona taʻu atu pe afai o le faasino o le soloia pe leai.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Faʻatusatusa ala i le lafo i se manifinifi faʻasino, o gaʻo manatu e na o le mafaufauina la latou "data" vaega mo leai.
        //
        (self as *const u8).guaranteed_eq(null())
    }

    /// Tuliesea i se e faasino ai o se isi ituaiga.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// Faʻasaʻo se (atonu lautele) faʻasino tusi i totonu o le tuatusi ma metadata vaega.
    ///
    /// O le faʻasino tusi mafai mulimuli ane toe fausiaina ma [`from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// Faafoi `None` pe afai o le faasino o le soloia, po o isi faamatalaga o tupe maua se faasinomaga faasoa i le taua afifi i `Some`.Afai e mafai ona uninitialized le taua, e tatau ona faaaogaina nai lo [`as_uninit_ref`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// A valaʻau lenei metotia, e tatau ona e mautinoa o le *a* o le faʻasino o le NULL *poʻo* uma o mea nei e moni:
    ///
    /// * E tatau ona faʻasaʻo lelei le faʻasino tusi.
    ///
    /// * E tatau ona "dereferencable" i le uiga faʻamatalaina i le [the module documentation].
    ///
    /// * O le faʻasino tusi e tatau ona tusi i se amataga faʻavae o `T`.
    ///
    /// * E tatau ona e faʻamalosia tulafono faʻaigoa a le Rust, talu ai o le olaga ua toe foʻi mai `'a` ua filifilia faʻapitoa ma e le o atagia mai ai le moni moni o le taimi o faʻamatalaga.
    ///   Ae maise lava, mo le umi o lenei olaga, o le manatuaina o le faʻasino tusi e le tatau ona suia (seʻi vagana totonu `UnsafeCell`).
    ///
    /// E faʻapipiʻi lenei mea tusa lava pe le o faʻaaogaina le iʻuga o lenei metotia!
    /// (O le vaega e uiga i le faʻamasaniina e leʻiʻo maeʻa ona faia se faʻaiuga, ae seʻia oʻo i le taimi, o le auala saogalemu se tasi o le faʻamautinoaina ua faʻamaoniaina moni.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Lomiga leai se siaki
    ///
    /// Afai e te mautinoa e le mafai ona faʻaleaogaina le faʻasino ma o loʻo suʻea ni ituaiga `as_ref_unchecked` e toe faʻafoʻi mai le `&T` nai lo le `Option<&T>`, ia e iloa e mafai ona e faʻasasaʻo le faʻasino tusi.
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // SAFETY: o le tagata telefoni e tatau ona mautinoa o `self` e aoga
        // mo se faʻasino pe a fai e le null.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Faʻafoʻi `None` pe a fai e leai se faʻailoga o le faʻasino, a le o lea, toe faʻafoʻi mai se faʻamatalaga tuʻufaʻatasia i le tau na afifi ile `Some`.
    /// E faʻatusatusa i le [`as_ref`], e le manaʻomia le amataina o le tau.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// A valaʻau lenei metotia, e tatau ona e mautinoa o le *a* o le faʻasino o le NULL *poʻo* uma o mea nei e moni:
    ///
    /// * E tatau ona faʻasaʻo lelei le faʻasino tusi.
    ///
    /// * E tatau ona "dereferencable" i le uiga faʻamatalaina i le [the module documentation].
    ///
    /// * E tatau ona e faʻamalosia tulafono faʻaigoa a le Rust, talu ai o le olaga ua toe foʻi mai `'a` ua filifilia faʻapitoa ma e le o atagia mai ai le moni moni o le taimi o faʻamatalaga.
    ///
    ///   Ae maise lava, mo le umi o lenei olaga, o le manatuaina o le faʻasino tusi e le tatau ona suia (seʻi vagana totonu `UnsafeCell`).
    ///
    /// E faʻapipiʻi lenei mea tusa lava pe le o faʻaaogaina le iʻuga o lenei metotia!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // SAFETY: o le tagata telefoni e tatau ona mautinoa o `self` feiloai uma
        // manaʻoga mo se faʻasino.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Fuafua le aveesea mai se faasino ai.
    ///
    /// `count` o loʻo i iunite o le T;faʻataʻitaʻiga, o le `count` o le 3 o loʻo faʻatusalia ai le faʻailoga o le `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Afai o nisi o tulaga nei ua solia, o le iʻuga o Undefined Amioga:
    ///
    /// * Uma le amataina ma le faʻaiuga faʻasino tatau ona tatau ona i tuaʻoi poʻo le tasi byte pasi le faʻaiuga o le tutusa mea faʻasoa.
    /// Manatua o le Rust, o (stack-allocated) fesuiaʻiga uma e manatu o se 'eseʻese tuʻufaʻatasia mea.
    ///
    /// * O le offset fuafuaina,**i bytes**, le mafai ona ova i luga o le `isize`.
    ///
    /// * O le offset i totonu o tuaoi e le mafai ona faʻalagolago i le "wrapping around" o le tuatusi avanoa.O lona uiga, o le aofaʻiga e le faʻatulagaina-atoatoa,**i bytes** tatau ona ofi i se usize.
    ///
    /// taumafai lautele le tuufaatasia ma le potutusi o le tulaga e mautinoa ai le faasoasoaina o le mafai ona ausia se tele pe afai o se aveesea o se popole.
    /// Mo se faʻataʻitaʻiga, `Vec` ma `Box` faʻamautinoa latou te le tuʻuina atu sili atu nai lo `isize::MAX` bytes, o lea o le `vec.as_ptr().add(vec.len())` e saogalemu i taimi uma.
    ///
    /// Ole tele o tulaga faʻavae e le mafai ona fausiaina sea faʻasoasoaga.
    /// Mo se faataitaiga, e leai se iloa 64-si tulaga e mafai ona auauna atu i se talosaga mo le 2 <sup>63</sup> bytes ona tapulaa le itulau-laulau po vaeluaina le va tuatusi.
    /// Peitaʻi, o nisi polokalame 32-bit ma 16-bit atonu e tautuaina ma le manuia se talosaga mo le sili atu i le `isize::MAX` bytes ma mea e pei o le Physical Address Extension.
    ///
    /// I se faʻataʻitaʻiga, o le manatuaina saʻo saʻo mai i tagata tuʻufaʻatasi poʻo faila manatuaina o faila *atonu* ua tele naua e faʻatautaia ai ma lenei galuega.
    ///
    /// Mafaufau e faʻaaoga le [`wrapping_offset`] nai lo pe a fai o nei faʻafitauli e faigata ona faʻamalieina.
    /// Pau lava le lelei o lenei metotia o le mafai ai ona sili atu le faʻamalosiaga faʻatulagaina faʻamautinoaina.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `offset`.
        unsafe { intrinsics::offset(self, count) }
    }

    /// Fuafua le offset mai se faʻasino tusi e faʻaaofia afifi arithmetic.
    ///
    /// `count` o loʻo i iunite o le T;faʻataʻitaʻiga, o le `count` o le 3 o loʻo faʻatusalia ai le faʻailoga o le `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// O lenei taʻotoga lava ia e saogalemu i taimi uma, ae o le faʻaaogaina o le faʻasino tusi e leai.
    ///
    /// O le iʻuga o le faʻasino tusi e tumau pea faʻapipiʻi i le mea tutusa tuʻuina atu e `self` faʻasino i ai.
    /// Atonu e *le* faʻaaogaina e faʻaaoga ai seisi mea eseʻese.Manatua o le Rust, o (stack-allocated) fesuiaʻiga uma e manatu o se 'eseʻese tuʻufaʻatasia mea.
    ///
    /// I nisi upu, `let z = x.wrapping_offset((y as isize) - (x as isize))` le *faia* faia `z` tutusa ma `y` tusa lava pe tatou te manatu `T` e tele `1` ma e leai se lolovaia: `z` o loʻo pipii pea i le mea `x` o loʻo faʻapipiʻiina, ma le faʻamamafaina o le Undefined Amioga vagana `x` ma `y` tusi ile mea tutusa tuʻufaʻatasia.
    ///
    /// Faʻatusatusa i le [`offset`], o lenei metotia faʻatuai ai le manaʻoga o le nofo i totonu o le mea lava tuʻufaʻatasia: [`offset`] e vave faʻauigaina Amioga pe a sopoʻia tuaoi mea;`wrapping_offset` gaosia se faʻasino tusi ae taitai atu lava i Undefined Amioga pe a fai o le faʻasino faʻailoga e le maua pe a o fafo atu-o-tuaʻoi o le mea o loʻo faʻapipiʻi i ai.
    /// [`offset`] mafai ona faʻaleleia sili faʻalelei ma o lea e sili ai i le faʻatinoina-maaleale faʻailoga.
    ///
    /// Ole tuai na siaki e naʻo le tau o le faʻasino na faʻaleaogaina, ae leʻo le aoga i le taimi na fuafuaina ai le iʻuga mulimuli.
    /// Mo se faʻataʻitaʻiga, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` e tutusa i taimi uma ma `x`.I nisi upu, tuua le atofaina mea ona toe ulufale i ai mulimuli ane ua faʻatagaina.
    ///
    /// Afai e te manaʻomia le sopoʻia o mea faʻatapulaʻa, lafo le faʻasino i le numera ma fai le numera iina.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// // Faʻaoga le faʻasino i luga o ni elemeni se lua
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // Lenei matasele lolomia "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SAOGALEMU: o le `arith_offset` vala aut ¯ u ua leai se prerequisites e taʻua.
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// Fuafua le mamao i le va o faʻasino e lua.O le tau faʻafoʻi o loʻo i iunite o T: o le mamao i bytes e vaevaeina e `mem::size_of::<T>()`.
    ///
    /// Lenei gaioiga o le feliuaʻi o [`offset`].
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// Afai o nisi o tulaga nei ua solia, o le iʻuga o Undefined Amioga:
    ///
    /// * Uma le amataina ma isi faʻasino tatau ona tatau ona i tuaʻoi po o le tasi byte pasia le faaiuga o le tutusa mea faitino atofaina.
    /// Manatua o le Rust, o (stack-allocated) fesuiaʻiga uma e manatu o se 'eseʻese tuʻufaʻatasia mea.
    ///
    /// * O mataʻitusi uma e lua e tatau ona maua mai i le faʻasino i le mea e tasi.
    ///   (Vaʻai i lalo mo se faʻataʻitaʻiga.)
    ///
    /// * O le mamao i le va o faʻasino, i bytes, tatau ona o se aofaʻi tonu tele o le tele o `T`.
    ///
    /// * O le mamao i le va o faʻasino,**i bytes**, e le mafai ona ova i luga o le `isize`.
    ///
    /// * O le mamao le i ai i tuaoi e le mafai ona faalagolago i "wrapping around" le va tuatusi.
    ///
    /// e lei tele ituaiga Rust nai lo `isize::MAX` ma Rust faasoasoaina lava afifi i le tuatusi avanoa, o lea lua vae i totonu o nisi o aoga o so o Rust ituaiga o le a faamalieina e le aunoa `T` le tulaga mulimuli e lua.
    ///
    /// E masani foʻi ona mautinoa e le faletusi tulaga masani, o tuʻufaʻatasiga e le oʻo atu i se telē o loʻo iai se faʻalavelave.
    /// Mo se faataitaiga, `Vec` ma `Box` mautinoa latou te lei faasoa sili atu nai lo bytes `isize::MAX`, ina pea faamalieina `ptr_into_vec.offset_from(vec.as_ptr())` le tulaga mulimuli e lua.
    ///
    /// Ole tele o tulaga faʻavae e le mafai ona fausiaina se aofaʻi tele.
    /// Mo se faataitaiga, e leai se iloa 64-si tulaga e mafai ona auauna atu i se talosaga mo le 2 <sup>63</sup> bytes ona tapulaa le itulau-laulau po vaeluaina le va tuatusi.
    /// Peitaʻi, o nisi polokalame 32-bit ma 16-bit atonu e tautuaina ma le manuia se talosaga mo le sili atu i le `isize::MAX` bytes ma mea e pei o le Physical Address Extension.
    /// I se faʻataʻitaʻiga, o le manatuaina saʻo saʻo mai i tagata tuʻufaʻatasi poʻo faila manatuaina o faila *atonu* ua tele naua e faʻatautaia ai ma lenei galuega.
    /// (Manatua o [`offset`] ma [`add`] e i ai foi se tapulaʻa tutusa ma o lea e le mafai ai ona faʻaaogaina luga o ia tele tufatufaina foi.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Lenei gaioiga panics pe a fai o `T` o le Zero-Sized Type ("ZST").
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Sese* faʻaaogaina:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Fai le ptr2_other o le "alias" o ptr2, ae maua mai i le ptr1.
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Talu ai ptr2_other ma ptr2 e mafua mai faʻasino i mea eseese, o le fuafuaina o latou offset o le faʻauigaina amioga, e ui lava latou faʻasino i le tutusa tuatusi!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Amio le faʻamatalaina
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `ptr_offset_from`.
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// Faʻafoʻi pe lua faʻailoga e mautinoa e tutusa.
    ///
    /// I runtime lenei amio galuega tauave e pei `self == other`.
    /// Peitai, i nisi tulaga (eg, tuufaatasia-taimi iloiloga), e le o taimi uma e mafai ai ona fuafuaina le tutusa o lua faasino, o lea o lenei gaioiga mafai spuriously toe foi `false` mo faasino ia mulimuli ane moni avea tutusa.
    ///
    /// Ae a toe faafoi `true`, o le faʻailoga e mautinoa e tutusa.
    ///
    /// O lenei galuega o le faʻata lea o le [`guaranteed_ne`], ae le o lona faʻataʻamilo.O loʻo iai faʻatusatusaga faʻatatau ia e toe faafoi uma ai `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Le toe foi mai le taua e mafai ona suia e faalagolago i luga o le le mafai ona faalagolago lomiga tuufaatasia ma code le saogalemu i luga o le taunuuga o lenei galuega mo le lelei le.
    /// E fautuaina e naʻo le faʻaaogaina o lenei gaioiga mo le faʻamautinoaina o mea e fai pe a fai e le aoga le toe faʻafoi o le `false` i lenei galuega, ae naʻo le faʻatinoga.
    /// O taunuuga o le faaaogaina o lenei auala e faia runtime ma amio code tuufaatasia-taimi ese e lei suesueina.
    /// O lenei metotia e le tatau ona faʻaaogaina e faʻalauiloa ai ni eseesega, ma e le tatau foi ona faʻamautuina ae tatou te leʻi mauaina se malamalama sili atu i lenei mataupu.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self, other)
    }

    /// Faʻafoʻi pe lua faʻailoga ua mautinoa e le tutusa.
    ///
    /// I le taimi faʻatulagaina lenei gaioiga amio pei o `self != other`.
    /// Peitai, i nisi tulaga (eg, tuufaatasia-taimi iloiloga), e le o taimi uma e mafai ai ona fuafuaina le le tutusa o lua faasino, o lea o lenei gaioiga atonu spuriously toe foi `false` mo faasino ia mulimuli ane moni avea ma le tutusa.
    ///
    /// Ae a toe faafoi `true`, o le faʻailoga e mautinoa e le tutusa.
    ///
    /// O lenei galuega o le faʻata lea o le [`guaranteed_eq`], ae le o lona faʻataʻamilo.O loʻo iai faʻatusatusaga faʻatatau ia e toe faafoi uma ai `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Le toe foi mai le taua e mafai ona suia e faalagolago i luga o le le mafai ona faalagolago lomiga tuufaatasia ma code le saogalemu i luga o le taunuuga o lenei galuega mo le lelei le.
    /// E fautuaina e naʻo le faʻaaogaina o lenei gaioiga mo le faʻamautinoaina o mea e fai pe a fai e le aoga le toe faʻafoi o le `false` i lenei galuega, ae naʻo le faʻatinoga.
    /// O taunuuga o le faaaogaina o lenei auala e faia runtime ma amio code tuufaatasia-taimi ese e lei suesueina.
    /// O lenei metotia e le tatau ona faʻaaogaina e faʻalauiloa ai ni eseesega, ma e le tatau foi ona faʻamautuina ae tatou te leʻi mauaina se malamalama sili atu i lenei mataupu.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self, other)
    }

    /// Fuafua le offset mai le faʻasino (faigofie mo `.offset(count as isize)`).
    ///
    /// `count` o loʻo i iunite o le T;faʻataʻitaʻiga, o le `count` o le 3 o loʻo faʻatusalia ai le faʻailoga o le `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Afai o nisi o tulaga nei ua solia, o le iʻuga o Undefined Amioga:
    ///
    /// * Uma le amataina ma le faʻaiuga faʻasino tatau ona tatau ona i tuaʻoi poʻo le tasi byte pasi le faʻaiuga o le tutusa mea faʻasoa.
    /// Manatua o le Rust, o (stack-allocated) fesuiaʻiga uma e manatu o se 'eseʻese tuʻufaʻatasia mea.
    ///
    /// * O le offset fuafuaina,**i bytes**, le mafai ona ova i luga o le `isize`.
    ///
    /// * O le offset i totonu o tuaoi e le mafai ona faʻamoemoe i le "wrapping around" le tuatusi avanoa.O lona uiga, o le aofaʻiga e le gata-maoti e tatau ona ofi i le `usize`.
    ///
    /// taumafai lautele le tuufaatasia ma le potutusi o le tulaga e mautinoa ai le faasoasoaina o le mafai ona ausia se tele pe afai o se aveesea o se popole.
    /// Mo se faʻataʻitaʻiga, `Vec` ma `Box` faʻamautinoa latou te le tuʻuina atu sili atu nai lo `isize::MAX` bytes, o lea o le `vec.as_ptr().add(vec.len())` e saogalemu i taimi uma.
    ///
    /// Ole tele o tulaga faʻavae e le mafai ona fausiaina sea faʻasoasoaga.
    /// Mo se faataitaiga, e leai se iloa 64-si tulaga e mafai ona auauna atu i se talosaga mo le 2 <sup>63</sup> bytes ona tapulaa le itulau-laulau po vaeluaina le va tuatusi.
    /// Peitaʻi, o nisi polokalame 32-bit ma 16-bit atonu e tautuaina ma le manuia se talosaga mo le sili atu i le `isize::MAX` bytes ma mea e pei o le Physical Address Extension.
    ///
    /// I se faʻataʻitaʻiga, o le manatuaina saʻo saʻo mai i tagata tuʻufaʻatasi poʻo faila manatuaina o faila *atonu* ua tele naua e faʻatautaia ai ma lenei galuega.
    ///
    /// Mafaufau e faʻaaoga le [`wrapping_add`] nai lo pe a fai o nei faʻafitauli e faigata ona faʻamalieina.
    /// Pau lava le lelei o lenei metotia o le mafai ai ona sili atu le faʻamalosiaga faʻatulagaina faʻamautinoaina.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Fuafua le offset mai le faʻasino (talafeagai mo `.offset ((faitau o le isize).wrapping_neg())`).
    ///
    /// `count` o loʻo i iunite o le T;faʻataʻitaʻiga, o le `count` o le 3 o loʻo faʻatusalia ai le faʻailoga o le `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Afai o nisi o tulaga nei ua solia, o le iʻuga o Undefined Amioga:
    ///
    /// * Uma le amataina ma le faʻaiuga faʻasino tatau ona tatau ona i tuaʻoi poʻo le tasi byte pasi le faʻaiuga o le tutusa mea faʻasoa.
    /// Manatua o le Rust, o (stack-allocated) fesuiaʻiga uma e manatu o se 'eseʻese tuʻufaʻatasia mea.
    ///
    /// * O le offset fuafuaina e le mafai ona sili atu i le `isize::MAX`**bytes**.
    ///
    /// * O le offset i totonu o tuaoi e le mafai ona faʻalagolago i le "wrapping around" o le tuatusi avanoa.O lona uiga, o le le faʻatapulaʻa-le aofaʻi aofaʻiga tatau ona ofi i se usize.
    ///
    /// taumafai lautele le tuufaatasia ma le potutusi o le tulaga e mautinoa ai le faasoasoaina o le mafai ona ausia se tele pe afai o se aveesea o se popole.
    /// Mo se faʻataʻitaʻiga, `Vec` ma `Box` faʻamautinoa latou te le tuʻuina atu sili atu nai lo `isize::MAX` bytes, o lea o le `vec.as_ptr().add(vec.len()).sub(vec.len())` e saogalemu i taimi uma.
    ///
    /// Ole tele o tulaga faʻavae e le mafai ona fausiaina sea faʻasoasoaga.
    /// Mo se faataitaiga, e leai se iloa 64-si tulaga e mafai ona auauna atu i se talosaga mo le 2 <sup>63</sup> bytes ona tapulaa le itulau-laulau po vaeluaina le va tuatusi.
    /// Peitaʻi, o nisi polokalame 32-bit ma 16-bit atonu e tautuaina ma le manuia se talosaga mo le sili atu i le `isize::MAX` bytes ma mea e pei o le Physical Address Extension.
    ///
    /// I se faʻataʻitaʻiga, o le manatuaina saʻo saʻo mai i tagata tuʻufaʻatasi poʻo faila manatuaina o faila *atonu* ua tele naua e faʻatautaia ai ma lenei galuega.
    ///
    /// Mafaufau e faʻaaoga le [`wrapping_sub`] nai lo pe a fai o nei faʻafitauli e faigata ona faʻamalieina.
    /// Pau lava le lelei o lenei metotia o le mafai ai ona sili atu le faʻamalosiaga faʻatulagaina faʻamautinoaina.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Fuafua le offset mai se faʻasino tusi e faʻaaofia afifi arithmetic.
    /// (faigofie mo `.wrapping_offset(count as isize)`)
    ///
    /// `count` o loʻo i iunite o le T;faʻataʻitaʻiga, o le `count` o le 3 o loʻo faʻatusalia ai le faʻailoga o le `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// O lenei taʻotoga lava ia e saogalemu i taimi uma, ae o le faʻaaogaina o le faʻasino tusi e leai.
    ///
    /// O le iʻuga o le faʻasino tusi e tumau pea faʻapipiʻi i le mea tutusa tuʻuina atu e `self` faʻasino i ai.
    /// Atonu e *le* faʻaaogaina e faʻaaoga ai seisi mea eseʻese.Manatua o le Rust, o (stack-allocated) fesuiaʻiga uma e manatu o se 'eseʻese tuʻufaʻatasia mea.
    ///
    /// I nisi upu, `let z = x.wrapping_add((y as usize) - (x as usize))` e le *faia*`z` tutusa ma `y` tusa lava pe tatou te manatu o `T` e tele `1` ma e leai se lolovaia: `z` o loʻo pipii pea i le mea `x` o loʻo pipii i ai, ma le faʻamamafaina o le Undefined Amioga vagana `x` ma `y` tusi ile mea tutusa tuʻufaʻatasia.
    ///
    /// Faʻatusatusa i le [`add`], o lenei metotia masani ai ona faʻatuai le manaʻoga o le nofo i totonu o le mea lava tuʻufaʻatasia mea: [`add`] e vave faʻauigaina Amioga pe a sopoʻia tuaoi mea;maua `wrapping_add` a faʻasino ae taitaia e Undefined Amioga pe a faʻasino ua dereferenced pe o fafo atu o le tuaoi o le mea ua faapipii i ai.
    /// [`add`] mafai ona faʻaleleia sili faʻalelei ma o lea e sili ai i le faʻatinoina-maaleale faʻailoga.
    ///
    /// Ole tuai na siaki e naʻo le tau o le faʻasino na faʻaleaogaina, ae leʻo le aoga i le taimi na fuafuaina ai le iʻuga mulimuli.
    /// Mo se faʻataʻitaʻiga, `x.wrapping_add(o).wrapping_sub(o)` e tutusa i taimi uma ma `x`.I nisi upu, tuua le atofaina mea ona toe ulufale i ai mulimuli ane ua faʻatagaina.
    ///
    /// Afai e te manaʻomia le sopoʻia o mea faʻatapulaʻa, lafo le faʻasino i le numera ma fai le numera iina.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// // Faʻaoga le faʻasino i luga o ni elemeni se lua
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Lenei matasele lolomia "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Fuafua le offset mai se faʻasino tusi e faʻaaofia afifi arithmetic.
    /// (faʻafaigofieina mo `.wrapping_offset ((faitau o le isize).wrapping_neg())`)
    ///
    /// `count` o loʻo i iunite o le T;faʻataʻitaʻiga, o le `count` o le 3 o loʻo faʻatusalia ai le faʻailoga o le `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// O lenei taʻotoga lava ia e saogalemu i taimi uma, ae o le faʻaaogaina o le faʻasino tusi e leai.
    ///
    /// O le iʻuga o le faʻasino tusi e tumau pea faʻapipiʻi i le mea tutusa tuʻuina atu e `self` faʻasino i ai.
    /// Atonu e *le* faʻaaogaina e faʻaaoga ai seisi mea eseʻese.Manatua o le Rust, o (stack-allocated) fesuiaʻiga uma e manatu o se 'eseʻese tuʻufaʻatasia mea.
    ///
    /// I nisi upu, `let z = x.wrapping_sub((x as usize) - (y as usize))` e le *faia*`z` tutusa ma `y` tusa lava pe tatou te manatu o `T` e tele `1` ma e leai se lolovaia: `z` o loʻo pipii pea i le mea `x` o loʻo pipii i ai, ma le faʻamamafaina o le Undefined Amioga vagana `x` ma `y` tusi ile mea tutusa tuʻufaʻatasia.
    ///
    /// Faatusatusa i [`sub`], aupito faatuai le manaoga lenei metotia o le tumau i totonu o le tasi mea faasoasoa: O [`sub`] Amioga Undefined vave pe a sopoia tuaoi mea;maua `wrapping_sub` a faʻasino ae taitaia e Undefined Amioga pe a faʻasino ua dereferenced pe o fafo atu o le tuaoi o le mea ua faapipii i ai.
    /// [`sub`] mafai ona faʻaleleia sili faʻalelei ma o lea e sili ai i le faʻatinoina-maaleale faʻailoga.
    ///
    /// Ole tuai na siaki e naʻo le tau o le faʻasino na faʻaleaogaina, ae leʻo le aoga i le taimi na fuafuaina ai le iʻuga mulimuli.
    /// Mo se faʻataʻitaʻiga, `x.wrapping_add(o).wrapping_sub(o)` e tutusa i taimi uma ma `x`.I nisi upu, tuua le atofaina mea ona toe ulufale i ai mulimuli ane ua faʻatagaina.
    ///
    /// Afai e te manaʻomia le sopoʻia o mea faʻatapulaʻa, lafo le faʻasino i le numera ma fai le numera iina.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// // Iterate e faaaoga ai se faasino mata i increments o elemene e lua (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Lenei matasele lolomia "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Seti le togi faʻatauaina i `ptr`.
    ///
    /// I le tulaga `self` o le (fat) faʻasino i se ituaiga faʻanumeraina, o lenei gaioiga o le a naʻo le aʻafiaga o le faʻasino vaega, ae mo (thin) faʻasino i ituaiga lapopoa, o le tutusa auga aafiaga o se faigofie tofiga.
    ///
    /// O le iʻuga faʻasino tusi o le a maua le faʻamaoniga o `val`, ie, mo se gaʻo poʻo faʻatonu, o lenei faʻagaioiga e tutusa le tutusa ma le fausiaina o se gaʻo fou faʻatulagaina ma le faʻamaumauga faʻatauaina taua o `val` ae o metadata o `self`.
    ///
    ///
    /// # Examples
    ///
    /// O lenei aoga e aoga tele mo le faʻatagaina o le byte-wisdom pointer arithmetic i luga o ono gaʻo mata:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &arr[0] as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // o le a lolomi "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *const u8) -> Self {
        let thin = &mut self as *mut *const T as *mut *const u8;
        // SAOGALEMU: I le tulaga o se faasino manifinifi, e tutusa lenei gaoioiga
        // i se tofiga faigofie.
        // I le tulaga o se gaʻo tusi, ma le gaʻo pointer faʻatulagaina faʻatulagaina faʻatulagaina, o le muamua fanua o sea faʻasino i taimi uma o le faʻasino tusi, lea e faʻapea foi ona atofaina.
        //
        unsafe { *thin = val };
        self
    }

    /// Faitau le tau mai `self` e aunoa ma le minoi.
    /// O lenei tuua le manatuaina i le `self` le suia.
    ///
    /// Vaʻai [`ptr::read`] mo le saogalemu popolega ma faʻataʻitaʻiga.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `read`.
        unsafe { read(self) }
    }

    /// Faia se le mautonu faitau o le taua mai `self` e aunoa ma le minoi.O lenei tuua le manatuaina i le `self` le suia.
    ///
    /// O gofie gaioiga e faʻamoemoe e galue i luga o le I/O memory, ma e mautinoa e le tuʻulafoaʻi pe toe faʻafouina e le tuʻufaʻatasia i isi galuega gaogao.
    ///
    ///
    /// Tagai [`ptr::read_volatile`] mo popolega saogalemu ma faataitaiga.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Faitau le tau mai `self` e aunoa ma le minoi.
    /// O lenei tuua le manatuaina i le `self` le suia.
    ///
    /// E le pei o le `read`, o le faʻasino tusi e ono le fetaui.
    ///
    /// Vaʻai [`ptr::read_unaligned`] mo le saogalemu popolega ma faʻataʻitaʻiga.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Kopi kopi `count * size_of<T>` bytes mai `self` i le `dest`.
    /// E ono sosoʻo le mafuaʻaga ma le mea e taunuʻu iai
    ///
    /// NOTE: lenei ua i ai le *lava ina finauga* pei [`ptr::copy`].
    ///
    /// Vaʻai [`ptr::copy`] mo le saogalemu popolega ma faʻataʻitaʻiga.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Kopi kopi `count * size_of<T>` bytes mai `self` i le `dest`.
    /// Le mafuaʻaga ma le taunuʻuga atonu *le* soʻosoʻo.
    ///
    /// NOTE: o loʻo iai le *tutusa* finauga finau pei ole [`ptr::copy_nonoverlapping`].
    ///
    /// Vaʻai [`ptr::copy_nonoverlapping`] mo le saogalemu popolega ma faʻataʻitaʻiga.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Fuafua le offset e manaʻomia faʻapipiʻi i le faʻasino tusi ina ia mafai ona ogatasi i le `align`.
    ///
    /// Afai e le mafai ona faʻavasega le faʻasino tusi, o le faʻatinoga e toe faafoi mai le `usize::MAX`.
    /// E faʻatagaina mo le faʻatinoina ia *toe foʻi*`usize::MAX`.
    /// Na e mafai ona faalagolago le faatinoga o lou algorithm i le mauaina o se faaaogāina aveesea iinei, e le ona le saʻo.
    ///
    /// O le aveesea o loo faaalia i le tele o elemene `T`, ma le bytes.O le tau faʻafoʻi mafai ona faʻaaogaina ma le `wrapping_add` auala.
    ///
    /// E leai ni faʻamaoniga poʻo le a lava le faʻapalepaleina o le faʻasino tusi o le a le lolovaia pe ova i tua atu o le faʻasoaga o le faʻasino tusi i totonu.
    ///
    /// E oo atu i le telefoni ina ia mautinoa e le toe foi aveesea e saʻo i mea uma tuutuuga isi nai lo aafia i lenei suiga.
    ///
    /// # Panics
    ///
    /// O le gaioiga panics pe a fai o `align` e le o se malosi-o-lua.
    ///
    /// # Examples
    ///
    /// Avanoa i tafatafa o `u8` o `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // ae o le faʻasino tusi mafai ona faʻatasia ala `offset`, o le a faʻasino i fafo atu o le faʻasoaga
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // SAFETY: `align` na siakiina e avea ma malosiaga o le 2 luga
        unsafe { align_offset(self, align) }
    }
}

#[lang = "const_slice_ptr"]
impl<T> *const [T] {
    /// Faʻafoʻi le umi o se fasi mata.
    ///
    /// O le tau faʻafoi mai o le numera o **elemene**, ae le o le numera o bytes.
    ///
    /// O lenei gaioiga e saogalemu, tusa lava pe le mafai ona lafoina le fasi fasi i se fasi faʻasino aua o le faʻasino tusi e leai se aoga pe leai foi.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // SAFETY: e saogalemu lenei mea ona o `*const [T]` ma `FatPtr<T>` e tutusa o latou faʻatulagaga.
            // Naʻo le `std` e mafai ona faia lenei faʻamaoniga.
            unsafe { Repr { rust: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Faʻafoʻi mai se faʻasino tusi i le buffer a fasi.
    ///
    /// E tutusa lea ma le lafoina o le `self` i le `*const T`, ae sili atu le ituaiga-saogalemu.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), 0 as *const i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// Faʻafoʻi mai se maka manino i se elemeni poʻo se tautua, e aunoa ma le faia o ni tuaoi siaki.
    ///
    /// O le valaʻauina o lenei metotia ma se faʻasino i fafo atu o tuaoi pe a le faʻaaogaina le `self` e *[amioga le faʻamatalaina]* tusa lava pe le o faʻaaogaina le faʻasino tusi.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: SliceIndex<[T]>,
    {
        // SAFETY: o le tagata valaʻau mautinoa le `self` e faʻaletonu ma `index` i totonu o tuaoi.
        unsafe { index.get_unchecked(self) }
    }

    /// Faʻafoʻi `None` pe a fai e leai se faʻailoga o le faʻasino, a le o lea, ia toe faʻafoʻi mai se fasi fefaʻasoaaʻi i le tau na afifiina ile `Some`.
    /// E faʻatusatusa i le [`as_ref`], e le manaʻomia le amataina o le tau.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// A valaʻau lenei metotia, e tatau ona e mautinoa o le *a* o le faʻasino o le NULL *poʻo* uma o mea nei e moni:
    ///
    /// * O le faʻasino tusi e tatau ona [valid] mo faitauga mo `ptr.len() * mem::size_of::<T>()` tele bytes, ma e tatau ona faʻasaʻo lelei.O lona uiga faʻapitoa:
    ///
    ///     * O le atoa manatua vaega o lenei fasi tatau ona aofia ai i totonu o se tasi atofaina mea!
    ///       Fasi e le mafai oʻo i totonu o le tele o mea atofaina.
    ///
    ///     * O le faʻasino tusi e tatau ona faʻatasia tusa lava mo zero-umi fasi.
    ///     Tasi mafuaʻaga mo lenei o le enum faʻataʻitaʻiga faʻamautinoaina mafai ona faʻamoemoe i faʻasino (aofia ai fasi o soʻo se umi) o gatasi ma leai-leai e vaʻaia ai latou mai isi faʻamaumauga.
    ///
    ///     E mafai ona e mauaina se faʻasino tusi e mafai ona faʻaaoga e pei o `data` mo fasi e leai se umi e faʻaaoga ai [`NonNull::dangling()`].
    ///
    /// * O le aofaʻi tele `ptr.len() * mem::size_of::<T>()` o le fasi e tatau ona le sili atu nai lo `isize::MAX`.
    ///   Vaʻai le saogalemu pepa faʻamaumauga o [`pointer::offset`].
    ///
    /// * E tatau ona e faʻamalosia tulafono faʻaigoa a le Rust, talu ai o le olaga ua toe foʻi mai `'a` ua filifilia faʻapitoa ma e le o atagia mai ai le moni moni o le taimi o faʻamatalaga.
    ///   Ae maise lava, mo le umi o lenei olaga, o le manatuaina o le faʻasino tusi e le tatau ona suia (seʻi vagana totonu `UnsafeCell`).
    ///
    /// E faʻapipiʻi lenei mea tusa lava pe le o faʻaaogaina le iʻuga o lenei metotia!
    ///
    /// Vaʻai foi [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// Tulaga Tutusa mo vae
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// Faʻatusatusaga mo faʻasino
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}