//! Panic lagolago ile faletusi masani.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// O se faʻavae tuʻuina mai faʻamatalaga e uiga i le panic.
///
/// `PanicInfo` fausaga ua pasi atu i le panic hook seti e le [`set_hook`] galuega.
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// Toe afio mai le payload e fesootai ma le panic.
    ///
    /// Lenei o le a masani, ae le o taimi uma, avea ma `&'static str` poʻo [`String`].
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// Afai o le `panic!` macro mai le `core` crate (e le mai le `std`) na faʻaaogaina ma se manoa faʻavasega ma ni isi finauga, toe faʻafoʻi mai lena feau sauni e faʻaaoga mo se faʻataʻitaʻiga ma [`fmt::write`]
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// Faʻafoʻi faʻamatalaga e uiga ile nofoaga na amata mai ai le panic, pe a maua.
    ///
    /// Lenei auala o le a toe faʻafoʻi taimi uma [`Some`], ae o lenei ono suia i le future faʻaliliuga.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: Afai e suia lenei mea i nisi taimi toe foʻi Leai,
        // feagai ma lena mataupu ile std::panicking::default_hook ma le std::panicking::begin_panic_fmt.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: e le mafai ona matou faʻaaogaina downcast_ref: :<String>() ii
        // talu ai e le maua le String i se mea taua!
        // O le totogi o se String pe a valaauina `std::panic!` ma tele finauga, ae i lena tulaga o le savali o loʻo avanoa foi.
        //

        self.location.fmt(formatter)
    }
}

/// O se faʻavae aofia ai faʻamatalaga e uiga i le nofoaga o le panic.
///
/// O lenei fausaga na fausia e [`PanicInfo::location()`].
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// Faʻatusatusaga mo tutusa ma faʻasologa e faia i faila, laina, ona pou faʻamuamua.
/// Faʻatusatusa faila o ni manoa, ae le o `Path`, lea e ono le mafaufauina.
/// Vaʻai [`Nofoaga: : faila`] 'pepa mo nisi talanoaga.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// Faʻafoʻi mai le nofoaga na maua ai le tagata telefoni mai i lenei galuega.
    /// Afai o lena gaioiga o le tagata e valaʻauina e faʻamaonia ona o lona valaʻauina nofoaga o le a toe faʻafoʻi mai, ma faʻapea ona alu aʻe i luga le faʻaputuga i le valaʻau muamua i totonu o se le toe suʻesuʻe tino galue.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// Faʻafoʻi le [`Location`] lea na valaʻauina ai.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// Faʻafoʻi mai le [`Location`] mai totonu o lenei faʻamatalaga uiga.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // o le tamoe i le galuega e tasi e le faʻasolosolo i seisi nofoaga, e maua ai e tatou le iʻuga e tasi
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // tamoʻe le tracked gaioiga i se eseʻese nofoaga maua ai se eseʻa aoga
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// Faʻafoʻi le igoa o le faila faila na mafua mai ai le panic.
    ///
    /// # `&str`, le `&Path`
    ///
    /// O le igoa na faʻafoʻi mai e faʻasino i se auala auala i luga o le faʻavasegaina faiga, ae e le aoga e fai ma sui tuʻusaʻo lenei o le `&Path`.
    /// O le faʻaputuina code mafai ona tamoʻe luga o se eseʻese faiga ma le eseʻese `Path` faʻatinoina nai lo le faiga faʻaavanoa mea i totonu ma lenei faletusi e le o iai nei se eseʻese "host path" ituaiga.
    ///
    /// E sili ona amio faateia e tupu pe afai e mafai ona tatou fesootai faila "the same" ala ala tele i le faiga module (e masani lava le faaaogaina o le uiga pe tutusa `#[path = "..."]`), lea e mafai ona mafua ai le mea e foliga mai e tutusa code e toe foi faatauaina eseese mai lenei galuega tauave.
    ///
    ///
    /// # Cross-compilation
    ///
    /// O lenei taua e le talafeagai mo le tufaina e `Path::new` po constructors faapena pe o le tulaga 'au ma tulaga taulaʻiga eseese.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// Faafoi le laina numera mai na amata mai le panic.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// Toe foi mai le koluma mai na amata mai le panic.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// O le trait i totonu e faʻaaoga e le libstd e pasi ai faʻamaumauga mai le libstd i le `panic_unwind` ma isi panic taimi e alu ai.
/// Le fuafuaina e faʻamautuina i soo se taimi lata mai, aua le faʻaogaina.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// Avea le umiaina atoa o mea i totonu.
    /// O le ituaiga toe faafoi o le `Box<dyn Any + Send>`, ae le mafai ona tatou faʻaaogaina le `Box` i le libcore.
    ///
    /// Ina ua maeʻa lenei metotia valaʻauina, naʻo nai dummy default aoga o loʻo totoe i le `self`.
    /// Valaʻau faʻalua lenei metotia, pe valaʻau `get` pe a uma ona valaʻau lenei metotia, o se mea sese.
    ///
    /// ua nonoina le finauga ona maua na o le panic runtime (`__rust_start_panic`) a `dyn BoxMeUp` nono.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// Naʻo le nonoina o mea i totonu.
    fn get(&mut self) -> &(dyn Any + Send);
}