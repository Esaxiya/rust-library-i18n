//! Atomic ituaiga
//!
//! ituaiga atomika tuuina fesootaiga anamua faasoa-manatua le va o filo, ma ua le fale poloka o isi ituaiga sosoo.
//!
//! Lenei module faʻamatalaina atomika lomiga o se filifilia numera o anamua ituaiga, aofia ai [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], ma isi.
//! gaoioiga nei ituaiga atomika e faapea, pe a faaaogaina saʻo, faafetaui faafouga i le va o filo.
//!
//! O metotia taʻitasi e fai ai le [`Ordering`] e fai ma sui o le malosi o le mea e te manatua ai mea o loʻo fai.O nei okaina e tutusa ma le [C++20 atomic orderings][1].Mo nisi faamatalaga tagai i le [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! saogalemu fesuiaiga atomika e faasoa i le va o filo (latou faatino [`Sync`]) ae latou te le faia i latou lava tuuina atu i le auala e fetufaaʻi ai ma mulimuli i le [threading model](../../../std/thread/index.html#the-threading-model) o Rust.
//!
//! O le auala sili ona taatele e faʻasoa ai se fesuiaʻiga o le atomika o le tuʻuina lea i totonu o le [`Arc`][arc] (o se atoma-faʻasino-faitau faʻasoa faʻasino faasino).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! e mafai ona teuina ituaiga atomika i fesuiaiga static, initialized le faaaogaina o le initializers faifai pea e pei o [`AtomicBool::new`].E masani ona faʻaaogaina le Atomic statics mo le faʻatamala ile lalolagi.
//!
//! # Portability
//!
//! Uma atika ituaiga i lenei module e mautinoa e avea [lock-free] pe a fai latou te avanoa.O lona uiga latou te le maua mai totonu a mutex lalolagi.Atomic ituaiga ma faʻagaioiga e le mautinoa e leai se faʻatali.
//! O lona uiga o gaioiga pei o `fetch_or` e ono faʻatinoina ma se faʻatusatusa-ma-swap matasele.
//!
//! e mafai ona faatinoina galuega atomika i le vaega ia faatonuga faatasi ma atomics tele-tele.Mo se faataitaiga nisi fausaga opea faaaogaina 4-byte faatonuga atomika e faatino `AtomicI8`.
//! Manatua e le tatau ona maua lenei faataitai se aafiaga i le saʻo o le tulafono, e le na o se mea e iloa.
//!
//! atonu e le maua le ituaiga atomika i lenei module i uma fausaga opea.O ituaiga atomika iinei e avanoa lautele uma, peitaʻi, ma e masani ona faʻamoemoeina i le taimi nei.O nisi tuusaunoaga iloga o le:
//!
//! * PowerPC ma fausaga opea MIPS ma vae 32-si te le ituaiga `AtomicU64` po `AtomicI64`.
//! * ARM tulaga faʻapipiʻi pei `armv5te` e le mo Linux naʻo faʻaaogaina `load` ma `store` gaioiga, ma aua le lagolagoina Faʻatusatusa ma Faʻafesuia (CAS) gaioiga, pei o `swap`, `fetch_add`, ma isi.
//! Faʻaopopo luga Linux, nei CAS faʻagaioiga o loʻo faʻatinoina e ala i [operating system support], lea e ono sau ma se faʻasalaga faʻasalaga.
//! * ARM sini ma `thumbv6m` na tuuina gaoioiga `load` ma `store`, ma aua le lagolagoina Faatusatusa ma le Faafesuiaiga o gaoioiga (CAS), e pei o `swap`, `fetch_add`, ma isi
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Manatua o future fausaga e ono faʻaopopoina e leai foi se lagolago mo nisi atomic faʻagaioiga.Maximally le a mananao code feaveai ina ia faaeteete i le faaaoga lea ituaiga atomika.
//! `AtomicUsize` ma `AtomicIsize` e masani lava e sili ona feaveai, ae e oo lava ona latou te le maua i soo se mea.
//! Mo faʻasino, o le `std` faletusi manaʻomia pointer-tele atika, e ui `core` leai.
//!
//! Taimi nei oe manaʻomia le faʻaaoga `#[cfg(target_arch)]` muamua lava i tuʻutuʻuga tuʻufaʻatasia i code ma atomics.E i ai foi le le tumau `#[cfg(target_has_atomic)]` faʻapea foi e ono faʻamautuina i le future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! O se faigofie spinlock:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Faatali mo le isi filo e faʻamatuʻu le loka
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Taofi le numera o numera o filo ola:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// O se ituaiga boolean e mafai ona faʻasoa saogalemu i le va o filo.
///
/// O lenei ituaiga ei ai le tasi faatusa i totonu o le mafaufau e pei o se [`bool`].
///
/// **Faaaliga**: ua na maua lenei ituaiga i fausaga opea e lagolagoina atomika uta ma oloa o `u8`.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Fausia se `AtomicBool` amataina i le `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Lelei le faʻatinoina o le lafoina mo AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// O se ituaiga e faasino ai mata lea e mafai ona saogalemu faasoa i le va o filo.
///
/// O lenei ituaiga ei ai le tasi faatusa i totonu o le mafaufau e pei o se `*mut T`.
///
/// **Faaaliga**: ua na maua lenei ituaiga i fausaga opea e lagolagoina atomika uta ma oloa o vae.
/// Lona tele e faalagolago i le telē o le faasino taulaʻiga.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Faatupuina a soloia `AtomicPtr<T>`.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Faʻatonuga o mea e manatua ai le mafaufau
///
/// orderings manatua faamaoti le ala faafetaui gaoioiga atomika manatua.
/// I lona vaivai [`Ordering::Relaxed`], ua synchronized na o le manatu saʻo ootia i le taotoga.
/// I le isi itu, o se faleoloa-avega pea gaoioiga [`Ordering::SeqCst`] faafetaui isi manatua ao le gata i le faasaoina o se poloaiga le aofaiga o sea gaoioiga i le isi itu filo uma.
///
///
/// O faʻatonuga manatua a le Rust o le [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// Mo nisi faamatalaga tagai i le [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Leai ni faʻatonuga faʻatapulaʻaina, naʻo atomika faʻagaioiga.
    ///
    /// Tutusa ma [`memory_order_relaxed`] i C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Ina ua faatasi ai ma se faleoloa, ia avea ma faatonuina galuega uma ua mavae atu i luma o so o se avega o lenei taua ma [`Acquire`] (po o le malosi) okaina.
    ///
    /// Ae maise lava, o tusitusiga uma muamua na vaʻaia na vaʻaia uma i filo e faʻatinoina se [`Acquire`] (pe faʻamalosi) avega o lenei tau.
    ///
    /// Faʻaaliga o le faʻaaogaina o lenei okaina mo se faʻagaioiga e tuʻufaʻatasia avega ma faleoloa e tau atu i le [`Relaxed`] avega gaioiga!
    ///
    /// O lenei okaina ua na talafeagai mo gaoioiga e mafai ona faia se faleoloa.
    ///
    /// E tutusa ma [`memory_order_release`] ile C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// A faʻatasia ma se uta, pe a fai o le utaina taua na tusia e se faleoloa faʻagaioiga ma [`Release`] (pe malosi atu) okaina, ona uma mulimuli ane faʻagaioiga faʻatonutonu pe a maeʻa lena faleoloa.
    /// Ae maise lava, o isi avega mulimuli ane o le a vaʻai i faʻamaumauga tusia i luma o le faleoloa.
    ///
    /// Faasilasilaga o le faaaogaina o lenei okaina mo se taotoga e tuufaatasia le avega ma faleoloa taitaia e se taotoga faleoloa [`Relaxed`]!
    ///
    /// O lenei okaina ua na talafeagai mo gaoioiga e mafai ona faia se avega.
    ///
    /// E tutusa ma [`memory_order_acquire`] ile C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// E i ai aafiaga o uma [`Acquire`] ma [`Release`] faʻatasi:
    /// Mo uta e faʻaaogaina ai le [`Acquire`] okaina.Mo faleʻoloa e faʻaaogaina le [`Release`] okaina.
    ///
    /// Matau i le tulaga o `compare_and_swap`, e mafai o le gaioiga faʻamutaina le faia se faleoloa ma o lea ua naʻo le [`Acquire`] okaina.
    ///
    /// Ae ui i lea, `AcqRel` o le a le faia [`Relaxed`] ulufale.
    ///
    /// O lenei okaina ua na talafeagai mo gaoioiga e tuufaatasia uma avega ma faleoloa.
    ///
    /// E tutusa ma [`memory_order_acq_rel`] ile C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// E pei o ['Acquire`]/[' Release`]/['AcqRel`](mo avega, faleoloa, ma avega-ma-faleoloa gaoioiga, faasologa) faatasi ai ma le faamaoniga faaopoopo filo uma vaai ogatasi faasolosolo uma gaoioiga i le faatulagaga e tasi .
    ///
    ///
    /// Tutusa ma [`memory_order_seq_cst`] i C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// O le [`AtomicBool`] faʻauʻuina i le `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Faatupu ai se `AtomicBool` fou.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Faʻafoʻi mai se fesuiaʻiga faʻafesoʻotaʻi i le autu [`bool`].
    ///
    /// O saogalemu ona o le faamaonia faasinomaga mutable e leai se isi filo ua Mekisiko ma le faaaogaina o faamatalaga atomika.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // SAFETY: o le fesuiaʻiga mau faʻamaonia mautinoaina umiaina.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Ia maua avanoa atomika i se `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // SAFETY: o le fesuiaʻiga faʻamatalaga faʻamaonia tuʻuina ese umiaina, ma
        // gatasi uma `bool` ma `Self` o 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Alu uma le atomika ma toe foi mai le taua o loo i ai.
    ///
    /// E sefe le mea lea talu ai o le pasia o le `self` e le tau e faʻamaonia ai e leai seisi filo e oʻo faʻatasi i le atomic data.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Avega se tau mai le bool.
    ///
    /// `load` ave le [`Ordering`] finauga o loʻo faʻamatalaina ai le manatuaina o le faʻatonuga o lenei gaioiga.
    /// Avanoa talafeagai o [`SeqCst`], [`Acquire`] ma [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics pe a fai o `order` o [`Release`] poʻo [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // SAFETY: soʻo se faʻamaumauga tuʻuga e puipuia e atomic intrinsics ma le mata
        // e aloaia e faasino pasia i ona tatou maua mai se faasinomaga.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Faleoloa a taua i le bool.
    ///
    /// `store` ave le [`Ordering`] finauga o loʻo faʻamatalaina ai le manatuaina o le faʻatonuga o lenei gaioiga.
    /// Avanoa talafeagai o [`SeqCst`], [`Release`] ma [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics pe a fai o `order` o [`Acquire`] poʻo [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // SAFETY: soʻo se faʻamaumauga tuʻuga e puipuia e atomic intrinsics ma le mata
        // e aloaia e faasino pasia i ona tatou maua mai se faasinomaga.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Faleoloa a taua i le bool, toe foi i le taua muamua.
    ///
    /// `swap` ave le [`Ordering`] finauga o loʻo faʻamatalaina ai le manatuaina o le faʻatonuga o lenei gaioiga.E mafaia modes okaina uma.
    /// Manatua o le faaaogaina o [`Acquire`] faia e le vaega faleoloa o lenei taotoga [`Relaxed`], ma le faaaogaina [`Release`] faia e le avega vaega [`Relaxed`].
    ///
    ///
    /// **Note:** O lenei auala e naʻo avanoa i luga o faʻavae e lagolagoina atomic faʻagaioiga luga `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // SAFETY: faʻamaumauga tuʻuga e puipuia e atomic intrinsics.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Faʻasaoina se tau aoga i le [`bool`] pe a fai o le tau aoga nei e tutusa ma le `current` taua.
    ///
    /// Le toe foi mai le taua i taimi uma le taua ua mavae.Afai e tutusa ma `current`, sa faafou lea o le taua.
    ///
    /// `compare_and_swap` e manaomia ai foi se finauga [`Ordering`] lea e faamatalaina ai le okaina manatu o lenei taotoga.
    /// Faasilasilaga e tusa lava pe faaaoga [`AcqRel`], le faagaoioiga mafai toilalo ma o lea na faia ai se avega `Acquire`, ae le maua semantics `Release`.
    /// Faʻaaoga [`Acquire`] faia le faleoloa vaega o lenei gaioiga [`Relaxed`] pe a tupu, ma faʻaaoga [`Release`] faia le avega vaega [`Relaxed`].
    ///
    /// **Note:** O lenei auala e naʻo avanoa i luga o faʻavae e lagolagoina atomic faʻagaioiga luga `u8`.
    ///
    /// # Malaga e `compare_exchange` ma `compare_exchange_weak`
    ///
    /// `compare_and_swap` e tutusa ma `compare_exchange` ma faʻafanua nei mo faʻamanatuga okaina:
    ///
    /// uluai |manuia |iʻuvale
    /// -------- | ------- | -------
    /// Malolo |Malolo |Maua e malolo |maua |Maua Faamatuu |Faʻamalolo |AcqRel malolo |AcqRel |Maua SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` ua faatagaina ina ia toilalo spuriously e tusa lava pe e manumalo le faatusatusaga, lea e faatagaina ai le tuufaatasia e maua ai le sili faapotopotoga code pe a faatusatusa ma o loo faaaogaina Faafesuiaiga i se matasele.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Faʻasaoina se tau aoga i le [`bool`] pe a fai o le tau aoga nei e tutusa ma le `current` taua.
    ///
    /// O le tau faʻafoʻi o se iʻuga faʻaalia ai pe o le tau fou na tusia ma aofia ai le muamua tau.
    /// I luga o le manuia o lenei tau aoga ua mautinoa e tutusa ma `current`.
    ///
    /// `compare_exchange` manaomia le toalua finauga [`Ordering`] e faamatala ai le okaina manatu o lenei taotoga.
    /// `success` faamatala ai le manaomia okaina mo le faagaoioiga faitau-suia-tusi lea e faia pe afai o le faatusatusa atu i `current` sui.
    /// `failure` faamatala le manaʻoga okaina mo le avega gaioiga e faia pe a fai o le faʻatusatusaga le manuia.
    /// Faaaogaina [`Acquire`] o manuia okaina faia e le vaega faleoloa o lenei taotoga [`Relaxed`], ma le faaaogaina [`Release`] faia e le avega faamanuiaina [`Relaxed`].
    ///
    /// O le faʻaletonu okaina mafai ona naʻo [`SeqCst`], [`Acquire`] poʻo [`Relaxed`] ma e tatau ona tutusa ma pe vaivai nai lo le manuia faʻavasegaina.
    ///
    /// **Note:** O lenei auala e naʻo avanoa i luga o faʻavae e lagolagoina atomic faʻagaioiga luga `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SAFETY: faʻamaumauga tuʻuga e puipuia e atomic intrinsics.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Faʻasaoina se tau aoga i le [`bool`] pe a fai o le tau aoga nei e tutusa ma le `current` taua.
    ///
    /// E le pei o [`AtomicBool::compare_exchange`], toilalo faatagaina e spuriously o lenei galuega e tusa lava pe e manumalo le faatusatusaga, e mafai ona taunuu i code sili lelei i nisi fausaga opea.
    ///
    /// O le tau faʻafoʻi o se iʻuga faʻaalia ai pe o le tau fou na tusia ma aofia ai le muamua tau.
    ///
    /// `compare_exchange_weak` manaomia le toalua finauga [`Ordering`] e faamatala ai le okaina manatu o lenei taotoga.
    /// `success` faamatala ai le manaomia okaina mo le faagaoioiga faitau-suia-tusi lea e faia pe afai o le faatusatusa atu i `current` sui.
    /// `failure` faamatala le manaʻoga okaina mo le avega gaioiga e faia pe a fai o le faʻatusatusaga le manuia.
    /// Faaaogaina [`Acquire`] o manuia okaina faia e le vaega faleoloa o lenei taotoga [`Relaxed`], ma le faaaogaina [`Release`] faia e le avega faamanuiaina [`Relaxed`].
    /// O le faʻaletonu okaina mafai ona naʻo [`SeqCst`], [`Acquire`] poʻo [`Relaxed`] ma e tatau ona tutusa ma pe vaivai nai lo le manuia faʻavasegaina.
    ///
    /// **Note:** O lenei auala e naʻo avanoa i luga o faʻavae e lagolagoina atomic faʻagaioiga luga `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SAFETY: faʻamaumauga tuʻuga e puipuia e atomic intrinsics.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// "and" talafeagai faatasi ma se aofaiga boolean.
    ///
    /// Faia se taotoga "and" talafeagai i le taua i le taimi nei ma le finauga `val`, ma seti le tau fou i le taunuuga.
    ///
    /// Faʻafoʻi mai le tau muamua.
    ///
    /// `fetch_and` ave le [`Ordering`] finauga o loʻo faʻamatalaina ai le manatuaina o le faʻatonuga o lenei gaioiga.E mafaia modes okaina uma.
    /// Manatua o le faaaogaina o [`Acquire`] faia e le vaega faleoloa o lenei taotoga [`Relaxed`], ma le faaaogaina [`Release`] faia e le avega vaega [`Relaxed`].
    ///
    ///
    /// **Note:** O lenei auala e naʻo avanoa i luga o faʻavae e lagolagoina atomic faʻagaioiga luga `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // SAFETY: faʻamaumauga tuʻuga e puipuia e atomic intrinsics.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Mafaufauga "nand" ma le taua ole boolean.
    ///
    /// Faia se taotoga "nand" talafeagai i le taua i le taimi nei ma le finauga `val`, ma seti le tau fou i le taunuuga.
    ///
    /// Faʻafoʻi mai le tau muamua.
    ///
    /// `fetch_nand` ave le [`Ordering`] finauga o loʻo faʻamatalaina ai le manatuaina o le faʻatonuga o lenei gaioiga.E mafaia modes okaina uma.
    /// Manatua o le faaaogaina o [`Acquire`] faia e le vaega faleoloa o lenei taotoga [`Relaxed`], ma le faaaogaina [`Release`] faia e le avega vaega [`Relaxed`].
    ///
    ///
    /// **Note:** O lenei auala e naʻo avanoa i luga o faʻavae e lagolagoina atomic faʻagaioiga luga `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // E le mafai ona matou faʻaaogaina atomic_nand ii aua e ono iʻu ai i le bool ma se aoga le aoga.
        // Tupu lenei mea ona e faia le taotoga atomika ma le 8-si integer mai totonu, lea o le a faatuina faagutu le pito i luga 7.
        //
        // Lea e na ona tatou faaaogaina fetch_xor po Faafesuiaiga ae.
        if val {
            // ! (x&moni)== !x E tatau ona tatou suia le bool.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&sese)==moni E tatau ona tatou seti le bool i le mea moni.
            //
            self.swap(true, order)
        }
    }

    /// "or" talafeagai faatasi ma se aofaiga boolean.
    ///
    /// Faia se gaioiga talafeagai "or" luga o le taimi nei aoga ma le finauga `val`, ma seti le fou aoga i le iʻuga.
    ///
    /// Faʻafoʻi mai le tau muamua.
    ///
    /// `fetch_or` ave le [`Ordering`] finauga o loʻo faʻamatalaina ai le manatuaina o le faʻatonuga o lenei gaioiga.E mafaia modes okaina uma.
    /// Manatua o le faaaogaina o [`Acquire`] faia e le vaega faleoloa o lenei taotoga [`Relaxed`], ma le faaaogaina [`Release`] faia e le avega vaega [`Relaxed`].
    ///
    ///
    /// **Note:** O lenei auala e naʻo avanoa i luga o faʻavae e lagolagoina atomic faʻagaioiga luga `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // SAFETY: faʻamaumauga tuʻuga e puipuia e atomic intrinsics.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// "xor" talafeagai faatasi ma se aofaiga boolean.
    ///
    /// Faia se gaioiga talafeagai "xor" luga o le taimi nei aoga ma le finauga `val`, ma seti le fou taua i le iʻuga.
    ///
    /// Faʻafoʻi mai le tau muamua.
    ///
    /// `fetch_xor` ave le [`Ordering`] finauga o loʻo faʻamatalaina ai le manatuaina o le faʻatonuga o lenei gaioiga.E mafaia modes okaina uma.
    /// Manatua o le faaaogaina o [`Acquire`] faia e le vaega faleoloa o lenei taotoga [`Relaxed`], ma le faaaogaina [`Release`] faia e le avega vaega [`Relaxed`].
    ///
    ///
    /// **Note:** O lenei auala e naʻo avanoa i luga o faʻavae e lagolagoina atomic faʻagaioiga luga `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // SAFETY: faʻamaumauga tuʻuga e puipuia e atomic intrinsics.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Faʻafoʻi mai se faʻavasega foliga i le [`bool`] autu.
    ///
    /// Faia o le leai-atomic faitau ma tusitusi luga o le iʻuga fuainumera mafai ona avea ma tuʻuga faʻamatalaga.
    /// O lenei auala e tele lava ina aoga mo FFI, lea mafai ona e faaaogaina le saini galuega tauave `*mut bool` nai lo le `&AtomicBool`.
    ///
    /// Toe foi se `*mut` faʻasino mai se faasoa faasinomaga i lenei atomika e saogalemu ona o le ituaiga atomika galulue ma totonu mutability.
    /// Uma suiga o se atomika suia le taua e ala i le tufatufaina faʻasino, ma mafai ona faia ma le saogalemu pe a na o latou faʻaaogaina atomika faʻagaioiga.
    /// O soo se faaaogaaga o le toe foi e faasino ai mata manaomia ai se poloka `unsafe` ma loo i ai pea e faatumauina ai le tapulaa lava lea e tasi: o gaoioiga i le e tatau ona atomika.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Maua mai le tau, ma faʻaaoga se gaioiga i ai e toe faʻafoʻi mai ai se tau aoga fou.Faʻafoʻi mai le `Result` o `Ok(previous_value)` pe a fai o le gaioiga na toe faʻafoʻi mai `Some(_)`, a le o lena `Err(previous_value)`.
    ///
    /// Note: Lenei ono valaʻau le gaioiga i le tele o taimi pe a fai o le tau na suia mai isi filo i le taimi nei, pe a fai o le gaioiga toe faafoi `Some(_)`, ae o le gaioiga o le a faʻaaogaina naʻo le tasi i le teuina aoga.
    ///
    ///
    /// `fetch_update` manaomia le toalua finauga [`Ordering`] e faamatala ai le okaina manatu o lenei taotoga.
    /// O le muamua o loo faamatalaina ai le okaina manaomia mo ina manumalo mulimuli o le faagaoioiga ao faamatalaina lona lua le okaina manaomia mo avega.
    /// O nei fesoʻotaʻiga ma le manuia ma le faʻaletonu okaina o [`AtomicBool::compare_exchange`] faʻatulagaina.
    ///
    /// O le faʻaaogaina o le [`Acquire`] o le faʻamanuiaina o le okaina e avea ai le faleoloa ma vaega o lenei gaioiga [`Relaxed`], ma le faʻaaogaina o le [`Release`] e mafua ai le manuia mulimuli o le avega [`Relaxed`].
    /// O le (failed) avega okaina faʻatoa mafai ona avea ma [`SeqCst`], [`Acquire`] poʻo le [`Relaxed`] ma e tatau ona tutusa pe laʻititi nai lo le faʻamanuiaga manuia.
    ///
    /// **Note:** O lenei auala e naʻo avanoa i luga o faʻavae e lagolagoina atomic faʻagaioiga luga `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Fausia se `AtomicPtr` fou.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Toe foi se faasinomaga mutable i le faasino autu.
    ///
    /// O saogalemu ona o le faamaonia faasinomaga mutable e leai se isi filo ua Mekisiko ma le faaaogaina o faamatalaga atomika.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Ia maua avanoa atomika i se e faasino ai.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - faamaonia ai le pule e umia tulaga ese le faasinomaga mutable.
        //  - le tutusa o `*mut T` ma `Self` e tutusa i uma tulaga lagolagoina e rust, pei ona faʻamaonia luga.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Alu uma le atomika ma toe foi mai le taua o loo i ai.
    ///
    /// E sefe le mea lea talu ai o le pasia o le `self` e le tau e faʻamaonia ai e leai seisi filo e oʻo faʻatasi i le atomic data.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Avega se tau mai le faʻasino tusi.
    ///
    /// `load` ave le [`Ordering`] finauga o loʻo faʻamatalaina ai le manatuaina o le faʻatonuga o lenei gaioiga.
    /// Avanoa talafeagai o [`SeqCst`], [`Acquire`] ma [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics pe a fai o `order` o [`Release`] poʻo [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // SAFETY: faʻamaumauga tuʻuga e puipuia e atomic intrinsics.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Teuina se taua i le faʻasino tusi.
    ///
    /// `store` ave le [`Ordering`] finauga o loʻo faʻamatalaina ai le manatuaina o le faʻatonuga o lenei gaioiga.
    /// Avanoa talafeagai o [`SeqCst`], [`Release`] ma [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics pe a fai o `order` o [`Acquire`] poʻo [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // SAFETY: faʻamaumauga tuʻuga e puipuia e atomic intrinsics.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Faleoloa a taua i totonu o le faasino ai, toe foi i le taua muamua.
    ///
    /// `swap` ave le [`Ordering`] finauga o loʻo faʻamatalaina ai le manatuaina o le faʻatonuga o lenei gaioiga.E mafaia modes okaina uma.
    /// Manatua o le faaaogaina o [`Acquire`] faia e le vaega faleoloa o lenei taotoga [`Relaxed`], ma le faaaogaina [`Release`] faia e le avega vaega [`Relaxed`].
    ///
    ///
    /// **Note:** ua na maua lenei metotia i fausaga opea e lagolagoina gaoioiga atomika i luga o vae.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // SAFETY: faʻamaumauga tuʻuga e puipuia e atomic intrinsics.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Faleoloa a taua i totonu o le faasino pe afai o le taua i le taimi nei e tutusa ma le tau aogā `current`.
    ///
    /// Le toe foi mai le taua i taimi uma le taua ua mavae.Afai e tutusa ma `current`, sa faafou lea o le taua.
    ///
    /// `compare_and_swap` e manaomia ai foi se finauga [`Ordering`] lea e faamatalaina ai le okaina manatu o lenei taotoga.
    /// Faasilasilaga e tusa lava pe faaaoga [`AcqRel`], le faagaoioiga mafai toilalo ma o lea na faia ai se avega `Acquire`, ae le maua semantics `Release`.
    /// Faʻaaoga [`Acquire`] faia le faleoloa vaega o lenei gaioiga [`Relaxed`] pe a tupu, ma faʻaaoga [`Release`] faia le avega vaega [`Relaxed`].
    ///
    /// **Note:** ua na maua lenei metotia i fausaga opea e lagolagoina gaoioiga atomika i luga o vae.
    ///
    /// # Malaga e `compare_exchange` ma `compare_exchange_weak`
    ///
    /// `compare_and_swap` e tutusa ma `compare_exchange` ma faʻafanua nei mo faʻamanatuga okaina:
    ///
    /// uluai |manuia |iʻuvale
    /// -------- | ------- | -------
    /// Malolo |Malolo |Maua e malolo |maua |Maua Faamatuu |Faʻamalolo |AcqRel malolo |AcqRel |Maua SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` ua faatagaina ina ia toilalo spuriously e tusa lava pe e manumalo le faatusatusaga, lea e faatagaina ai le tuufaatasia e maua ai le sili faapotopotoga code pe a faatusatusa ma o loo faaaogaina Faafesuiaiga i se matasele.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Faleoloa a taua i totonu o le faasino pe afai o le taua i le taimi nei e tutusa ma le tau aogā `current`.
    ///
    /// O le tau faʻafoʻi o se iʻuga faʻaalia ai pe o le tau fou na tusia ma aofia ai le muamua tau.
    /// I luga o le manuia o lenei tau aoga ua mautinoa e tutusa ma `current`.
    ///
    /// `compare_exchange` manaomia le toalua finauga [`Ordering`] e faamatala ai le okaina manatu o lenei taotoga.
    /// `success` faamatala ai le manaomia okaina mo le faagaoioiga faitau-suia-tusi lea e faia pe afai o le faatusatusa atu i `current` sui.
    /// `failure` faamatala le manaʻoga okaina mo le avega gaioiga e faia pe a fai o le faʻatusatusaga le manuia.
    /// Faaaogaina [`Acquire`] o manuia okaina faia e le vaega faleoloa o lenei taotoga [`Relaxed`], ma le faaaogaina [`Release`] faia e le avega faamanuiaina [`Relaxed`].
    ///
    /// O le faʻaletonu okaina mafai ona naʻo [`SeqCst`], [`Acquire`] poʻo [`Relaxed`] ma e tatau ona tutusa ma pe vaivai nai lo le manuia faʻavasegaina.
    ///
    /// **Note:** ua na maua lenei metotia i fausaga opea e lagolagoina gaoioiga atomika i luga o vae.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SAFETY: faʻamaumauga tuʻuga e puipuia e atomic intrinsics.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Faleoloa a taua i totonu o le faasino pe afai o le taua i le taimi nei e tutusa ma le tau aogā `current`.
    ///
    /// E le pei o [`AtomicPtr::compare_exchange`], o lenei gaioiga e faʻatagaina e faʻaletonu le manuia e tusa lava pe o le faʻatusatusaga e alualu i luma, lea e mafai ona maua ai le sili atu lelei tulafono laiti luga o nisi tulaga.
    ///
    /// O le tau faʻafoʻi o se iʻuga faʻaalia ai pe o le tau fou na tusia ma aofia ai le muamua tau.
    ///
    /// `compare_exchange_weak` manaomia le toalua finauga [`Ordering`] e faamatala ai le okaina manatu o lenei taotoga.
    /// `success` faamatala ai le manaomia okaina mo le faagaoioiga faitau-suia-tusi lea e faia pe afai o le faatusatusa atu i `current` sui.
    /// `failure` faamatala le manaʻoga okaina mo le avega gaioiga e faia pe a fai o le faʻatusatusaga le manuia.
    /// Faaaogaina [`Acquire`] o manuia okaina faia e le vaega faleoloa o lenei taotoga [`Relaxed`], ma le faaaogaina [`Release`] faia e le avega faamanuiaina [`Relaxed`].
    /// O le faʻaletonu okaina mafai ona naʻo [`SeqCst`], [`Acquire`] poʻo [`Relaxed`] ma e tatau ona tutusa ma pe vaivai nai lo le manuia faʻavasegaina.
    ///
    /// **Note:** ua na maua lenei metotia i fausaga opea e lagolagoina gaoioiga atomika i luga o vae.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SAOGALEMU: O lenei vala aut ¯ u o saogalemu aua e galue i luga o se faasino ai mata
        // ae matou te mautinoa mautinoa o le faʻasino tusi e aoga (na matou mauaina mai le `UnsafeCell` o loʻo ia matou e ala i le faʻasino) ma le atomika faʻagaioiga lava e faʻatagaina ai matou e faʻafetaui saogalemu le `UnsafeCell` mea.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Maua mai le tau, ma faʻaaoga se gaioiga i ai e toe faʻafoʻi mai ai se tau aoga fou.Faʻafoʻi mai le `Result` o `Ok(previous_value)` pe a fai o le gaioiga na toe faʻafoʻi mai `Some(_)`, a le o lena `Err(previous_value)`.
    ///
    /// Note: Lenei ono valaʻau le gaioiga i le tele o taimi pe a fai o le tau na suia mai isi filo i le taimi nei, pe a fai o le gaioiga toe faafoi `Some(_)`, ae o le gaioiga o le a faʻaaogaina naʻo le tasi i le teuina aoga.
    ///
    ///
    /// `fetch_update` manaomia le toalua finauga [`Ordering`] e faamatala ai le okaina manatu o lenei taotoga.
    /// O le muamua o loo faamatalaina ai le okaina manaomia mo ina manumalo mulimuli o le faagaoioiga ao faamatalaina lona lua le okaina manaomia mo avega.
    /// O nei fesoʻotaʻiga ma le manuia ma le faʻaletonu okaina o [`AtomicPtr::compare_exchange`] faʻatulagaina.
    ///
    /// O le faʻaaogaina o le [`Acquire`] o le faʻamanuiaina o le okaina e avea ai le faleoloa ma vaega o lenei gaioiga [`Relaxed`], ma le faʻaaogaina o le [`Release`] e mafua ai le manuia mulimuli o le avega [`Relaxed`].
    /// O le (failed) avega okaina faʻatoa mafai ona avea ma [`SeqCst`], [`Acquire`] poʻo le [`Relaxed`] ma e tatau ona tutusa pe laʻititi nai lo le faʻamanuiaga manuia.
    ///
    /// **Note:** ua na maua lenei metotia i fausaga opea e lagolagoina gaoioiga atomika i luga o vae.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Faʻaliliua se `bool` i totonu o le `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Lenei macro faʻaiʻu le le faʻaaogaina i luga o nisi tusiata fale.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// O se ituaiga integer lea e mafai ona saogalemu faasoa i le va o filo.
        ///
        /// O lenei ituaiga ua le lava lea e tasi i totonu o le manatuaina o faamatalaga e pei o le ituaiga integer faavae, ['
        ///
        #[doc = $s_int_type]
        /// `].
        /// Mo nisi e uiga i le eseesega i le va atomika ituaiga ma ituaiga lē atomika faapea foi faamatalaga e uiga i le feaveaiga o numera o lenei ituaiga, faamolemole tagai i le [module-level documentation].
        ///
        ///
        /// **Note:** O lenei ituaiga e avanoa na o luga o faʻavae e lagolagoina atomic uta ma faleʻoloa o [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Na amataina le numera atomika i le `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Lafo faʻatinoina faʻatinoina.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Faatupu ai se integer atomika fou.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Faʻafoʻi mai se fesuiaʻiga faʻafesoʻotaʻi i le fuainumera fuainumera.
            ///
            /// O saogalemu ona o le faamaonia faasinomaga mutable e leai se isi filo ua Mekisiko ma le faaaogaina o faamatalaga atomika.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// tuu mut nisi_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (nisi_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - faamaonia ai le pule e umia tulaga ese le faasinomaga mutable.
                //  - le tutusa o `$int_type` ma `Self` e tutusa, pei ona folafola mai e $cfg_align ma faʻamaonia luga.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Alu uma le atomika ma toe foi mai le taua o loo i ai.
            ///
            /// E sefe le mea lea talu ai o le pasia o le `self` e le tau e faʻamaonia ai e leai seisi filo e oʻo faʻatasi i le atomic data.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Avega le tau mai le numera atomika.
            ///
            /// `load` ave le [`Ordering`] finauga o loʻo faʻamatalaina ai le manatuaina o le faʻatonuga o lenei gaioiga.
            /// Avanoa talafeagai o [`SeqCst`], [`Acquire`] ma [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics pe a fai o `order` o [`Release`] poʻo [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // SAFETY: faʻamaumauga tuʻuga e puipuia e atomic intrinsics.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Teuina o se taua i totonu o le atomika numera.
            ///
            /// `store` ave le [`Ordering`] finauga o loʻo faʻamatalaina ai le manatuaina o le faʻatonuga o lenei gaioiga.
            ///  Avanoa talafeagai o [`SeqCst`], [`Release`] ma [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics pe a fai o `order` o [`Acquire`] poʻo [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // SAFETY: faʻamaumauga tuʻuga e puipuia e atomic intrinsics.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Faleoloa a taua i le integer atomika, toe foi i le taua muamua.
            ///
            /// `swap` ave le [`Ordering`] finauga o loʻo faʻamatalaina ai le manatuaina o le faʻatonuga o lenei gaioiga.E mafaia modes okaina uma.
            /// Manatua o le faaaogaina o [`Acquire`] faia e le vaega faleoloa o lenei taotoga [`Relaxed`], ma le faaaogaina [`Release`] faia e le avega vaega [`Relaxed`].
            ///
            ///
            /// **Faaaliga**: O lenei auala e na o le maua i le fausaga opea e lagolagoina gaoioiga atomika i
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: faʻamaumauga tuʻuga e puipuia e atomic intrinsics.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Faʻasaoina se tau aoga i totonu o le atomic integer pe afai o le taimi nei aoga e tutusa ma le `current` taua.
            ///
            /// Le toe foi mai le taua i taimi uma le taua ua mavae.Afai e tutusa ma `current`, sa faafou lea o le taua.
            ///
            /// `compare_and_swap` e manaomia ai foi se finauga [`Ordering`] lea e faamatalaina ai le okaina manatu o lenei taotoga.
            /// Faasilasilaga e tusa lava pe faaaoga [`AcqRel`], le faagaoioiga mafai toilalo ma o lea na faia ai se avega `Acquire`, ae le maua semantics `Release`.
            ///
            /// Faʻaaoga [`Acquire`] faia le faleoloa vaega o lenei gaioiga [`Relaxed`] pe a tupu, ma faʻaaoga [`Release`] faia le avega vaega [`Relaxed`].
            ///
            /// **Faaaliga**: O lenei auala e na o le maua i le fausaga opea e lagolagoina gaoioiga atomika i
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Malaga e `compare_exchange` ma `compare_exchange_weak`
            ///
            /// `compare_and_swap` e tutusa ma `compare_exchange` ma faʻafanua nei mo faʻamanatuga okaina:
            ///
            /// uluai |manuia |iʻuvale
            /// -------- | ------- | -------
            /// Malolo |Malolo |Maua e malolo |maua |Maua Faamatuu |Faʻamalolo |AcqRel malolo |AcqRel |Maua SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` ua faatagaina ina ia toilalo spuriously e tusa lava pe e manumalo le faatusatusaga, lea e faatagaina ai le tuufaatasia e maua ai le sili faapotopotoga code pe a faatusatusa ma o loo faaaogaina Faafesuiaiga i se matasele.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Faʻasaoina se tau aoga i totonu o le atomic integer pe afai o le taimi nei aoga e tutusa ma le `current` taua.
            ///
            /// O le tau faʻafoʻi o se iʻuga faʻaalia ai pe o le tau fou na tusia ma aofia ai le muamua tau.
            /// I luga o le manuia o lenei tau aoga ua mautinoa e tutusa ma `current`.
            ///
            /// `compare_exchange` manaomia le toalua finauga [`Ordering`] e faamatala ai le okaina manatu o lenei taotoga.
            /// `success` faamatala ai le manaomia okaina mo le faagaoioiga faitau-suia-tusi lea e faia pe afai o le faatusatusa atu i `current` sui.
            /// `failure` faamatala le manaʻoga okaina mo le avega gaioiga e faia pe a fai o le faʻatusatusaga le manuia.
            /// Faaaogaina [`Acquire`] o manuia okaina faia e le vaega faleoloa o lenei taotoga [`Relaxed`], ma le faaaogaina [`Release`] faia e le avega faamanuiaina [`Relaxed`].
            ///
            /// O le faʻaletonu okaina mafai ona naʻo [`SeqCst`], [`Acquire`] poʻo [`Relaxed`] ma e tatau ona tutusa ma pe vaivai nai lo le manuia faʻavasegaina.
            ///
            /// **Faaaliga**: O lenei auala e na o le maua i le fausaga opea e lagolagoina gaoioiga atomika i
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // SAFETY: faʻamaumauga tuʻuga e puipuia e atomic intrinsics.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Faʻasaoina se tau aoga i totonu o le atomic integer pe afai o le taimi nei aoga e tutusa ma le `current` taua.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// o lenei gaioiga ua faʻatagaina e faʻaletonu toilalo tusa lava pe o le faʻatusatusaga manuia, lea e mafai ona maua ai i le sili atu lelei tulafono laiti luga o nisi tulaga.
            /// O le tau faʻafoʻi o se iʻuga faʻaalia ai pe o le tau fou na tusia ma aofia ai le muamua tau.
            ///
            /// `compare_exchange_weak` manaomia le toalua finauga [`Ordering`] e faamatala ai le okaina manatu o lenei taotoga.
            /// `success` faamatala ai le manaomia okaina mo le faagaoioiga faitau-suia-tusi lea e faia pe afai o le faatusatusa atu i `current` sui.
            /// `failure` faamatala le manaʻoga okaina mo le avega gaioiga e faia pe a fai o le faʻatusatusaga le manuia.
            /// Faaaogaina [`Acquire`] o manuia okaina faia e le vaega faleoloa o lenei taotoga [`Relaxed`], ma le faaaogaina [`Release`] faia e le avega faamanuiaina [`Relaxed`].
            ///
            /// O le faʻaletonu okaina mafai ona naʻo [`SeqCst`], [`Acquire`] poʻo [`Relaxed`] ma e tatau ona tutusa ma pe vaivai nai lo le manuia faʻavasegaina.
            ///
            /// **Faaaliga**: O lenei auala e na o le maua i le fausaga opea e lagolagoina gaoioiga atomika i
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// tuʻu mut tuai= val.load(Ordering::Relaxed);
            /// matasele {let new=old * 2;
            ///     faafetaui val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // SAFETY: faʻamaumauga tuʻuga e puipuia e atomic intrinsics.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// E faaopoopo atu i le taua i le taimi nei, ua toe foi mai le taua ua mavae.
            ///
            /// Lenei taotoga wraps faataamilo i faatumulia.
            ///
            /// `fetch_add` ave le [`Ordering`] finauga o loʻo faʻamatalaina ai le manatuaina o le faʻatonuga o lenei gaioiga.E mafaia modes okaina uma.
            /// Manatua o le faaaogaina o [`Acquire`] faia e le vaega faleoloa o lenei taotoga [`Relaxed`], ma le faaaogaina [`Release`] faia e le avega vaega [`Relaxed`].
            ///
            ///
            /// **Faaaliga**: O lenei auala e na o le maua i le fausaga opea e lagolagoina gaoioiga atomika i
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: faʻamaumauga tuʻuga e puipuia e atomic intrinsics.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Aveese mai le tau o loʻo iai nei, toe faʻafoʻi le tau talu ai.
            ///
            /// Lenei taotoga wraps faataamilo i faatumulia.
            ///
            /// `fetch_sub` ave le [`Ordering`] finauga o loʻo faʻamatalaina ai le manatuaina o le faʻatonuga o lenei gaioiga.E mafaia modes okaina uma.
            /// Manatua o le faaaogaina o [`Acquire`] faia e le vaega faleoloa o lenei taotoga [`Relaxed`], ma le faaaogaina [`Release`] faia e le avega vaega [`Relaxed`].
            ///
            ///
            /// **Faaaliga**: O lenei auala e na o le maua i le fausaga opea e lagolagoina gaoioiga atomika i
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: faʻamaumauga tuʻuga e puipuia e atomic intrinsics.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitwise "and" ma le taua i le taimi nei.
            ///
            /// Faia se gaioiga "and" laʻititi luga o le taimi nei aoga ma le finauga `val`, ma seti le fou aoga i le iʻuga.
            ///
            /// Faʻafoʻi mai le tau muamua.
            ///
            /// `fetch_and` ave le [`Ordering`] finauga o loʻo faʻamatalaina ai le manatuaina o le faʻatonuga o lenei gaioiga.E mafaia modes okaina uma.
            /// Manatua o le faaaogaina o [`Acquire`] faia e le vaega faleoloa o lenei taotoga [`Relaxed`], ma le faaaogaina [`Release`] faia e le avega vaega [`Relaxed`].
            ///
            ///
            /// **Faaaliga**: O lenei auala e na o le maua i le fausaga opea e lagolagoina gaoioiga atomika i
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: faʻamaumauga tuʻuga e puipuia e atomic intrinsics.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitwise "nand" ma le tau aoga ile taimi nei.
            ///
            /// Faia se gaioiga "nand" laʻititi luga o le taimi nei aoga ma le finauga `val`, ma seti le fou aoga i le iʻuga.
            ///
            /// Faʻafoʻi mai le tau muamua.
            ///
            /// `fetch_nand` ave le [`Ordering`] finauga o loʻo faʻamatalaina ai le manatuaina o le faʻatonuga o lenei gaioiga.E mafaia modes okaina uma.
            /// Manatua o le faaaogaina o [`Acquire`] faia e le vaega faleoloa o lenei taotoga [`Relaxed`], ma le faaaogaina [`Release`] faia e le avega vaega [`Relaxed`].
            ///
            ///
            /// **Faaaliga**: O lenei auala e na o le maua i le fausaga opea e lagolagoina gaoioiga atomika i
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: faʻamaumauga tuʻuga e puipuia e atomic intrinsics.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitwise "or" ma le tau aoga ile taimi nei.
            ///
            /// Faatinoina se bitwise "or" taotoga i le taua i le taimi nei ma le finauga `val`, ma seti le tau fou i le taunuuga.
            ///
            /// Faʻafoʻi mai le tau muamua.
            ///
            /// `fetch_or` ave le [`Ordering`] finauga o loʻo faʻamatalaina ai le manatuaina o le faʻatonuga o lenei gaioiga.E mafaia modes okaina uma.
            /// Manatua o le faaaogaina o [`Acquire`] faia e le vaega faleoloa o lenei taotoga [`Relaxed`], ma le faaaogaina [`Release`] faia e le avega vaega [`Relaxed`].
            ///
            ///
            /// **Faaaliga**: O lenei auala e na o le maua i le fausaga opea e lagolagoina gaoioiga atomika i
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: faʻamaumauga tuʻuga e puipuia e atomic intrinsics.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitwise "xor" ma le tau aoga ile taimi nei.
            ///
            /// Faatinoina se bitwise "xor" taotoga i le taua i le taimi nei ma le finauga `val`, ma seti le tau fou i le taunuuga.
            ///
            /// Faʻafoʻi mai le tau muamua.
            ///
            /// `fetch_xor` ave le [`Ordering`] finauga o loʻo faʻamatalaina ai le manatuaina o le faʻatonuga o lenei gaioiga.E mafaia modes okaina uma.
            /// Manatua o le faaaogaina o [`Acquire`] faia e le vaega faleoloa o lenei taotoga [`Relaxed`], ma le faaaogaina [`Release`] faia e le avega vaega [`Relaxed`].
            ///
            ///
            /// **Faaaliga**: O lenei auala e na o le maua i le fausaga opea e lagolagoina gaoioiga atomika i
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: faʻamaumauga tuʻuga e puipuia e atomic intrinsics.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Maua mai le tau, ma faʻaaoga se gaioiga i ai e toe faʻafoʻi mai ai se tau aoga fou.Faʻafoʻi mai le `Result` o `Ok(previous_value)` pe a fai o le gaioiga na toe faʻafoʻi mai `Some(_)`, a le o lena `Err(previous_value)`.
            ///
            /// Note: Lenei ono valaʻau le gaioiga i le tele o taimi pe a fai o le tau na suia mai isi filo i le taimi nei, pe a fai o le gaioiga toe faafoi `Some(_)`, ae o le gaioiga o le a faʻaaogaina naʻo le tasi i le teuina aoga.
            ///
            ///
            /// `fetch_update` manaomia le toalua finauga [`Ordering`] e faamatala ai le okaina manatu o lenei taotoga.
            /// O le muamua faʻamatalaina le manaʻoga okaina mo le taimi o le gaioiga mulimuli ane manuia ae o le lona lua faʻamatalaina le manaʻoga okaina mo uta.Nei e faʻatatau i le manuia ma le le manuia okaina o
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// O le faʻaaogaina o le [`Acquire`] o le faʻamanuiaina o le okaina e avea ai le faleoloa ma vaega o lenei gaioiga [`Relaxed`], ma le faʻaaogaina o le [`Release`] e mafua ai le manuia mulimuli o le avega [`Relaxed`].
            /// O le (failed) avega okaina faʻatoa mafai ona avea ma [`SeqCst`], [`Acquire`] poʻo le [`Relaxed`] ma e tatau ona tutusa pe laʻititi nai lo le faʻamanuiaga manuia.
            ///
            /// **Faaaliga**: O lenei auala e na o le maua i le fausaga opea e lagolagoina gaoioiga atomika i
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq (x.fetch_update (okaina: : SeqCst, Ordering::SeqCst, |! x | Some(x + 1)), Ok(7));
            /// assert_eq (x.fetch_update (okaina: : SeqCst, Ordering::SeqCst, |! x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Tapulaʻa ma le aoga nei.
            ///
            /// Maua le maualuga o le taimi nei aoga ma le finauga `val`, ma seti le fou taua i le iʻuga.
            ///
            /// Faʻafoʻi mai le tau muamua.
            ///
            /// `fetch_max` ave le [`Ordering`] finauga o loʻo faʻamatalaina ai le manatuaina o le faʻatonuga o lenei gaioiga.E mafaia modes okaina uma.
            /// Manatua o le faaaogaina o [`Acquire`] faia e le vaega faleoloa o lenei taotoga [`Relaxed`], ma le faaaogaina [`Release`] faia e le avega vaega [`Relaxed`].
            ///
            ///
            /// **Faaaliga**: O lenei auala e na o le maua i le fausaga opea e lagolagoina gaoioiga atomika i
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// ia pa=42;
            /// tuu max_foo=foo.fetch_max (pa, Ordering::SeqCst).max(bar);
            /// taʻutino! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: faʻamaumauga tuʻuga e puipuia e atomic intrinsics.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Aupito i maualalo ma le taua i le taimi nei.
            ///
            /// Maua le maualalo o le taimi nei aoga ma le finauga `val`, ma seti le fou taua i le iʻuga.
            ///
            /// Faʻafoʻi mai le tau muamua.
            ///
            /// `fetch_min` ave le [`Ordering`] finauga o loʻo faʻamatalaina ai le manatuaina o le faʻatonuga o lenei gaioiga.E mafaia modes okaina uma.
            /// Manatua o le faaaogaina o [`Acquire`] faia e le vaega faleoloa o lenei taotoga [`Relaxed`], ma le faaaogaina [`Release`] faia e le avega vaega [`Relaxed`].
            ///
            ///
            /// **Faaaliga**: O lenei auala e na o le maua i le fausaga opea e lagolagoina gaoioiga atomika i
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// tuʻu le pa=12;
            /// let min_foo=foo.fetch_min (pa, Ordering::SeqCst).min(bar);
            /// ! Assert_eq (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: faʻamaumauga tuʻuga e puipuia e atomic intrinsics.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Faʻafoʻi mai se faʻavasega suiga i le fuainumera faʻavae.
            ///
            /// Faia o le leai-atomic faitau ma tusitusi luga o le iʻuga fuainumera mafai ona avea ma tuʻuga faʻamatalaga.
            /// O lenei metotia e sili ona aoga mo FFI, lea e mafai ona faʻaaoga ai le saini saini
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Toe foi se `*mut` faʻasino mai se faasoa faasinomaga i lenei atomika e saogalemu ona o le ituaiga atomika galulue ma totonu mutability.
            /// Uma suiga o se atomika suia le taua e ala i le tufatufaina faʻasino, ma mafai ona faia ma le saogalemu pe a na o latou faʻaaogaina atomika faʻagaioiga.
            /// O soo se faaaogaaga o le toe foi e faasino ai mata manaomia ai se poloka `unsafe` ma loo i ai pea e faatumauina ai le tapulaa lava lea e tasi: o gaoioiga i le e tatau ona atomika.
            ///
            ///
            /// # Examples
            ///
            /// `` Le amanaʻia (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// extern "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // SAFETY: Saogalēmū pe a umi o `my_atomic_op` o atomic.
            /// lē saogalemu {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `atomic_store`.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `atomic_load`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `atomic_swap`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Faʻafoʻi mai le tau talu ai (pei __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `atomic_add`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Faʻafoʻi mai le tau muamua (pei o __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `atomic_sub`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `atomic_compare_exchange`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `atomic_compare_exchange_weak`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAOGALEMU: o le telefoni e tatau ona lagolagoina le konekarate saogalemu mo `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// Faʻafoʻi mai le tau maualuga (sainia faʻatusatusaga)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// Faʻafoʻi mai le tau aoga (sainia faʻatusatusaga)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// toe afio mai le Max taua (unsigned faatusatusa)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// toe afio mai le min taua (unsigned faatusatusa)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Se pa atomika.
///
/// Faʻamoemoeina i le faʻatonuga faʻatulagaina, o se pa puipuia le tuʻufaʻatasia ma le CPU mai le toe faʻatulagaina o ni ituaiga o manatuaina gaioiga faʻataʻamiloina.
/// Lea e fausia faʻafesoʻotaʻi-ma sootaga i le va o ia ma atomic faʻagaioiga poʻo pa i isi filo.
///
/// A pa 'A' lea e (ia le itiiti ifo) [`Release`] semantics okaina, synchronizes ma se pa 'B' ma (ia le itiiti ifo) semantics [`Acquire`], pe afai ma pe afai o loo i ai gaoioiga X ma Y, i le faagaoioia i nisi mea atomika 'M' sea ua faasologa A luma X, Y ua faʻatasia faʻatasi aʻo le i matauina e B ma Y le suiga i le M.
/// O lenei e maua ai se tupu-i luma o le faalagolago i le va o se ma B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Faʻagaioiga o le Atomic ma [`Release`] poʻo le [`Acquire`] semantika e mafai foi ona faʻatasia ma se pa.
///
/// A pa lea ei [`SeqCst`] okaina, i le faaopoopo atu i le gata [`Acquire`] ma semantics [`Release`], auai i le faasologa o polokalama o le lalolagi o le isi gaoioiga [`SeqCst`] ma/po o pa.
///
/// Talia [`Acquire`], [`Release`], [`AcqRel`] ma [`SeqCst`] orderings.
///
/// # Panics
///
/// Panics pe a fai o `order` o [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // A aveeseina soofaatasi anamua faavae i spinlock.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Faatali seia oo i le taua o le matua o `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Lenei pa faʻafesoʻotaʻi-ma faleʻoloa i `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // SAFETI: o le faʻaaogaina o se atomic pa e saogalemu.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// O se pa manatuaina tuufaatasia.
///
/// `compiler_fence` e le faʻailoaina se masini code, ae faʻatapulaʻa ituaiga o manatua toe faʻasologa le faʻavasega ua faʻatagaina e faia.Faʻapitoa lava, faʻalagolago i le [`Ordering`] semantics na tuʻuina mai, o le tagata tuʻufaʻatasia mafai ona faʻatagaina mai le minoi faitau pe tusitusi mai luma pe a maeʻa le valaʻau i le isi itu o le valaʻau i le `compiler_fence`.Manatua e faia **le** taofia ai le *meafaigaluega ma mea faapena* mai le faia o le toe okaina.
///
/// e le o se faafitauli lenei i se tasi-threaded, faatinoga mataupu, ae a isi filo ona fesuiai manatua i le taimi lava e tasi, primitives synchronization malosi e pei o [`fence`] e manaomia.
///
/// O le toe okaina na taofia e le eseʻese faʻatonuga semantics o:
///
///  - ma [`SeqCst`], leai se toe okaina o faitau ma tusitusi i luga o lenei itu e faʻatagaina.
///  - ma le [`Release`], faitau muamua ma tusitusi e le mafai ona minoi i tua atu mulimuli ane ai tusitusiga.
///  - ma [`Acquire`], faitau mulimuli ane ma tusitusi e le mafai ona ave i luma o muamua faitauga.
///  - ma [`AcqRel`], o tulafono uma e lua o loʻo faʻamalosia.
///
/// `compiler_fence` e masani na aoga mo le puipuia o se filo mai e faataalise *ma lava*.O le, pe afai o se ua faatinoina filo tuuina atu se vaega e tasi o le tulafono, ma ua motusia ai lea, ma amata faatinoina code isi nofoaga (ao pea i le filo e tasi, ma conceptually pea i luga o le autu lava lea e tasi).I polokalame masani, e mafai ona tupu lenei mea pe a lesitalaina se tagata e faʻatautaia se faʻailoga.
/// I lalo ifo o tulaga maualalo tulafono laiti, o ia tulaga e mafai foi ona tulaʻi mai pe a tagoina faʻalavelave, pe a faʻataʻitaʻia filo lanumeamata ma muaʻi faʻamalosia, ma isi.
/// Ua uunaia au faitau fia iloa e faitau le talanoaga a le kernel Linux o [memory barriers].
///
/// # Panics
///
/// Panics pe a fai o `order` o [`Relaxed`].
///
/// # Examples
///
/// A aunoa ma `compiler_fence`, o le `assert_eq!` i le mulimuli i le code e *le* mautinoa e faʻamanuiaina, e ui lava i mea uma e tutupu i le tasi filo.
/// Ina ia iloa pe aisea, manatua o le tuufaatasia o le saoloto e Faafesuiaiga o le faleoloa e `IMPORTANT_VARIABLE` ma `IS_READ` talu oi laua uma `Ordering::Relaxed`.Afai e, ma ua faaaogaina saʻo ina ua uma ona toe faafou `IS_READY` le Handler faailo, ona o le a vaai Handler faailo `IS_READY=1`, ae `IMPORTANT_VARIABLE=0`.
/// Faʻaaogaina le `compiler_fence` fofo lenei tulaga.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // puipuia muamua tusitusi mai le siitia i tua atu o lenei manatu
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // SAFETI: o le faʻaaogaina o se atomic pa e saogalemu.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Faʻailo le faʻagaioiga o loʻo i totonu o le pisi-faʻatali spin-loop ("vili loka").
///
/// O lenei galuega tauave ua deprecated e finagalo i ai o [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}