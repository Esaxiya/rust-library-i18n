//! Faalapotopotoga mo formatting ma lolomiina manoa.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// Mafai faataatiaga toe foi e `Formatter::align`
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Faailoga e tatau ona aofia i totonu tauagavale-ogatasi.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Faʻailoga o mea i totonu e tatau ona saʻo-tuʻusaʻo.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Faʻailoga o mea i totonu e tatau ona ogatusa-ogatotonu.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// Le ituaiga na toe faʻafoʻi mai e sui auala.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// O le mea sese ituaiga lea e toe foi mai formatting se savali i totonu o se vaitafe.
///
/// E le lagolagoina lenei ituaiga le faaliliuina atu o se mea sese o isi nai lo o se mea sese na tupu.
/// Soʻo se faʻamatalaga faʻaopopo e tatau ona faʻatulagaina e tuʻuina atu i nisi auala.
///
/// O se mea taua e manatua o le ituaiga `fmt::Error` e le tatau ona fenumiai ma [`std::io::Error`] poʻo [`std::error::Error`], lea e ono i ai foʻi i le lautele.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// A trait mo faiga tusitusia po o formatting i Unicode-taliaina buffers po o le vaitafe.
///
/// Lenei trait naʻo taliaina UTF-8 - faʻamaumauga faʻaupuga ae le o [flushable].
/// Afai e naʻo lou manaʻo e talia le Unicode ma e te le manaʻomia flushing, oe tatau ona faʻatino lenei trait;
/// a leai e tatau ona e faʻaaogaina [`std::io::Write`].
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// Tusia se fasi manoa i lenei tusitala, toe foi pe o le manumalo tusi.
    ///
    /// E faʻatoa mafai ona alualu i luma lenei metotia pe a fai o le manoa atoa na tusia lelei, ma o lenei metotia o le a le toe foʻi seʻi maeʻa tusia uma faʻamaumauga pe tupu se mea sese.
    ///
    ///
    /// # Errors
    ///
    /// Lenei gaioiga o le a toe faafoi mai se faʻataʻitaʻiga o [`Error`] i luga o mea sese.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// Tusia le [`char`] i lenei tusitala, toe faafoi pe na manuia le tusi.
    ///
    /// e mafai ona encoded se tasi [`char`] e sili atu nai lo le tasi byte.
    /// E faʻatoa mafai ona alualu i luma lenei metotia pe a fai o le maeʻa tusia o le byte na tusia lelei, ma o lenei metotia o le a le toe foʻi seʻi maeʻa tusia uma faʻamaumauga pe ua tupu se mea sese.
    ///
    ///
    /// # Errors
    ///
    /// Lenei gaioiga o le a toe faafoi mai se faʻataʻitaʻiga o [`Error`] i luga o mea sese.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// Kelu mo le faʻaaogaina o le [`write!`] macro ma faʻatinoina lenei trait.
    ///
    /// O lenei auala e tatau ona masani ona faamaoniaina manually, ae e ala i le macro [`write!`] lava ia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// Fetuunaiga mo le faʻavasegaina.
///
/// faatusa A `Formatter` filifiliga eseese e faatatau i formatting.
/// E le faʻatonuina e tagata faʻaaogaina le 'Formatter`s;o se suia suia i le tasi ua pasi atu i le `fmt` metotia o uma faʻatulagaina traits, pei o [`Debug`] ma [`Display`].
///
///
/// E faʻafesoʻotaʻi ma le `Formatter`, e te valaʻauina ni metotia eseese e suia ai filifiliga eseese e fesoʻotaʻi ma le faʻatulagaina.
/// Mo ni faataitaiga, faamolemole vaai i le pepa o le auala e faamatalaina i `Formatter` lalo.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// O le finauga o se mea sili ona lelei faʻaaogaina vaega faʻatulagaina gaioiga, tutusa ma `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result`.

extern "C" {
    type Opaque;
}

/// O lenei fausia faatusa i ai le "argument" lautele ua aveina e le aiga Xprintf o galuega tauave.O loo i ai se galuega tauave i faatulagaga i le taua na tuuina mai.
/// I le tuʻufaʻatasia o taimi e mautinoa ai o le gaioiga ma le tau e i ai ituaiga saʻo, ona faʻaaogaina ai lea o lenei mea e faʻaaoga ai finauga i se tasi ituaiga.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// O lenei e faamaonia ai se taua fale o manu e tasi mo le faasino ai galuega tauave e fesootai ma indices/counts i le atinae eseese formatting.
//
// Faaaliga o se galuega tauave faamatalaina o sea o le a le saʻo o galuega tauave e masani lava eu unnamed_addr i le taimi nei tuuina i lalo e LLVM IRI, o lea latou lauga e le o manatu taua e LLVM ma e pei e le as_usize lafo mafai ona miscompiled.
//
// I le faiga, tatou te valaau as_usize i lē usize aofia ai faamatalaga (e pei o se mataupu o static tupulaga o le finauga formatting), o lea ua na o se siaki tupe faaopoopo lenei.
//
// Tatou faapitoa e te manao ina ia mautinoa e faapea o le faasino o se galuega tauave i `USIZE_MARKER` ei ai se tuatusi talafeagai *na* i galuega tauave o le ave `&usize` o lo latou finauga muamua.
// O le read_volatile iinei mautinoa ai e mafai ona tatou saunia ai le saogalemu a usize mai le mavae faasinomaga ma e le manatu lenei lauga i se galuega tauave aveina lē usize.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // SAOGALEMU: ptr o se faasinomaga
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // SAFETY: `mem::transmute(x)` e saogalemu aua
        //     1. `&'b T` tausia le olaga atoa na amata mai i le `'b` (ina ia leai se le faʻatapulaʻaina olaga atoa)
        //     2.
        //     `&'b T` ma `&'b Opaque` le faatulagaga manatua lava lea e tasi (pe `T` o `Sized`, e pei ona o iinei) `mem::transmute(f)` e saogalemu talu ai `fn(&T, &mut Formatter<'_>) -> Result` ma `fn(&Opaque, &mut Formatter<'_>) -> Result` le lava ABI (e pei ona umi o `T` o `Sized`)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // SAFETY: O le `formatter` fanua ua faʻatoa setiina i USIZE_MARKER pe a fai
            // o le aoga o le usisa, o lea e saogalemu lenei
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// fuʻa o loo maua i le v1 faatulagaga o format_args
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// A o faʻaaogaina le format_args! () Macro, o lenei gaioiga e faʻaaogaina e fausia ai le finauga Faʻamatalaga.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// O lenei galuega o loo faaaogaina e faamaoti nonstandard tapulaa formatting.
    /// O le `pieces` tatau ona i autau itiiti ifo i le umi e `fmt` e fausia se fausaga finauga aloaia.
    /// Foi, o so o se `Count` totonu `fmt` e `CountIsParam` po `CountIsNextParam` ua e manatu i se finauga foafoaina ma `argumentusize`.
    ///
    /// Ae peitai, o le lē mafai ona faia faapea e le pogai unsafety, ae o le a le amanaiaina mamaʻi.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// Tala Faatatau o le umi o le anotusi formatted.
    ///
    /// ua faamoemoe lenei e tatau ona faaaogaina mo le faatulagaina uluai tulaga `String` pe a faaaogaina `format!`.
    /// Note: e le o le pito i lalo poʻo luga o le tuaoi.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // Afai o le faʻatulagaina manoa amata i se finauga, aua preallocate se mea, vagana umi o fasi e taua.
            //
            //
            0
        } else {
            // E i ai ni finauga, o lea la soʻo se faʻaopoopo tulei o le a toe tuʻuina atu le manoa.
            //
            // Ina ia aloese mai lena, ua tatou "pre-doubling" le malosiaga ii.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// Lenei fausaga sui ai se saogalemu faʻavasega faʻamatalaga o se fusi faʻasologa ma ana finauga.
/// E le mafai ona tupu mai i le taimi ua alu ai talu ai e le mafai ona faia ma le saogalemu, o lea e leai ni tagata fau fale e tuʻuina atu ma e le o faia ni faʻatoʻaga e puipuia ai suiga.
///
///
/// O le macro [`format_args!`] le a faia ma le saogalemu o se faataitaiga o lenei fausaga.
/// O le macro faʻamaonia le faʻatulagaina laina i le tuʻufaʻatasi-taimi o lea o le faʻaaogaina o le [`write()`] ma le [`format()`] gaioiga e mafai ona faʻatinoina saogalemu.
///
/// E mafai ona e faaaogaina le `Arguments<'a>` e toe foi [`format_args!`] i totonu lava `Debug` ma `Display` e pei ona vaaia i lalo.
/// O le faaalia foi faataitaiga faatulagaga `Debug` ma `Display` i le mea lava e tasi: o le manoa faatulagaga interpolated i `format_args!`.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // fasi manoa faatulagaga e lolomi.
    pieces: &'a [&'static str],

    // Faʻamatalaga a le Placeholder, poʻo le `None` pe a fai o mea uma e le masani ai (pei o le "{}{}").
    fmt: Option<&'a [rt::v1::Argument]>,

    // Faʻamatalaga maoaʻe mo le vavalalata, ia faʻafesoʻotaʻi ma fasi manoa.
    // (Uma finauga e muamua atu i se fasi manoa.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// Maua le laina faʻavasega, pe a fai e leai ni finauga e faʻatulagaina.
    ///
    /// Lenei mafai ona faʻaaogaina e aloese ai mai faʻasoaga i le sili ona taua mataupu.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` e tatau ona faatulagaga o le galuega faatino i se Faapolokalameina-feagai, debugging mataupu.
///
/// Tulaga lautele, e tatau ona e na o le faatinoga `derive` a `Debug`.
///
/// A faʻaoga ma le isi fesuiaʻiga faʻamaoniga `#?`, o le gaioiga e sili ona lomia.
///
/// Mo nisi faʻamatalaga i luga o faʻatulaga, vaʻai [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// Lenei trait mafai ona faʻaaogaina ma `#[derive]` pe a fai uma fanua faʻataʻitaʻi `Debug`.
/// A 'derive`d mo structs, o le a faaaoga le suafa o le `struct`, ona `{`, lea o se koma-tuueseeseina lisi o le igoa o fanua taitasi ma `Debug` taua, ona `}`.
/// Mo 'enum`s, o le a faaaoga le suafa o le variant ma, pe afai e talafeagai, `(`, lea o le tulaga faatauaina `Debug` o le fanua, lea `)`.
///
/// # Stability
///
/// O faʻavae mai `Debug` e le faʻamautu, ma e ono suia ma le future Rust.
/// I se faʻaopopoga, `Debug` faʻatinoina o ituaiga saunia e le tulaga faletusi (`libstd`, `libcore`, `liballoc`, ma isi) e le mautu, ma ono mafai foi ona suia ma future Rust lomiga.
///
///
/// # Examples
///
/// Mauaina o se faʻatinoga:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Faʻaaoga lima:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// O loo i ai le tele o fesoasoani metotia i le fausia [`Formatter`] e fesoasoani ia te oe i implementations tusi lesona, e pei o [`debug_struct`].
///
/// `Debug` faʻatinoina le faʻaaogaina o le `derive` poʻo le debug builder API i luga o le [`Formatter`] lagolago aulelei lolomiga faʻaaogaina le isi fuʻa: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// Matagofie-lolomiga ma `#?`:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// Faʻatulaga le taua e faʻaaogaina ai le faʻatulagaina.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// module eseese e reexport le macro `Debug` mai prelude e aunoa ma le trait `Debug`.
pub(crate) mod macros {
    /// macro maua faatupuina se impl o le trait `Debug`.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// Faatulagaga trait mo se faatulagaga avanoa, `{}`.
///
/// `Display` e tai tutusa ma le [`Debug`], ae o le `Display` e mo tagata e faʻagaioia galuega, ma o lea e le mafai ai ona maua.
///
///
/// Mo nisi faʻamatalaga i luga o faʻatulaga, vaʻai [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Le faatinoina o `Display` i luga o se ituaiga:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// Faʻatulaga le taua e faʻaaogaina ai le faʻatulagaina.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// O le `Octal` trait tatau faatulagaga ana galuega faatino e avea o se i base-8.
///
/// Mo anamua integers sainia (`i8` e `i128`, ma `isize`), tulaga faatauaina lelei ua formatted e pei o le faatusa fesoasoani talafeagai o le lua.
///
///
/// Le fuʻa sui, `#`, e faaopoopo a `0o` i luma o le galuega faatino.
///
/// Mo nisi faʻamatalaga i luga o faʻatulaga, vaʻai [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Faʻaaogaina autu ma `i32`:
///
/// ```
/// let x = 42; // 42 o le '52' ile feʻe
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// Faʻaaogaina `Octal` i luga o se ituaiga:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // ona tuuina atu i le faatinoga i32
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// Faʻatulaga le taua e faʻaaogaina ai le faʻatulagaina.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// O le `Binary` trait tatau faatulagaga ana galuega faatino e avea o se i binary.
///
/// Mo anamua integers sainia ([`i8`] e [`i128`], ma [`isize`]), tulaga faatauaina lelei ua formatted e pei o le faatusa fesoasoani talafeagai o le lua.
///
///
/// Le fuʻa sui, `#`, e faaopoopo a `0b` i luma o le galuega faatino.
///
/// Mo nisi faʻamatalaga i luga o faʻatulaga, vaʻai [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Faʻaaogaina autu ma [`i32`]:
///
/// ```
/// let x = 42; // 42 o '101010' i binary
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// Le faatinoina o `Binary` i luga o se ituaiga:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // ona tuuina atu i le faatinoga i32
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// Faʻatulaga le taua e faʻaaogaina ai le faʻatulagaina.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// O le `LowerHex` trait tatau faatulagaga ana galuega faatino e avea o se i hexadecimal, ma `a` ala `f` i le tulaga maualalo.
///
/// Mo anamua integers sainia (`i8` e `i128`, ma `isize`), tulaga faatauaina lelei ua formatted e pei o le faatusa fesoasoani talafeagai o le lua.
///
///
/// O le isi fuʻa, `#`, faʻaopopo le `0x` i luma o le galuega faatino.
///
/// Mo nisi faʻamatalaga i luga o faʻatulaga, vaʻai [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Faʻaaogaina autu ma `i32`:
///
/// ```
/// let x = 42; // 42 o le '2a' i le hex
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// Le faatinoina o `LowerHex` i luga o se ituaiga:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // ona tuuina atu i le faatinoga i32
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// Faʻatulaga le taua e faʻaaogaina ai le faʻatulagaina.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// O le `UpperHex` trait tatau faatulagaga ana galuega faatino e avea o se i hexadecimal, ma `A` ala `F` i le tulaga pito i luga.
///
/// Mo anamua integers sainia (`i8` e `i128`, ma `isize`), tulaga faatauaina lelei ua formatted e pei o le faatusa fesoasoani talafeagai o le lua.
///
///
/// O le isi fuʻa, `#`, faʻaopopo le `0x` i luma o le galuega faatino.
///
/// Mo nisi faʻamatalaga i luga o faʻatulaga, vaʻai [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Faʻaaogaina autu ma `i32`:
///
/// ```
/// let x = 42; // 42 o le '2A' i le hex
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// Faʻaaogaina `UpperHex` i luga o se ituaiga:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // ona tuuina atu i le faatinoga i32
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// Faʻatulaga le taua e faʻaaogaina ai le faʻatulagaina.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// O le `Pointer` trait tatau faatulagaga ana galuega faatino e avea o se nofoaga manatua.
/// ua tuuina masani lenei e pei hexadecimal.
///
/// Mo nisi faʻamatalaga i luga o faʻatulaga, vaʻai [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Faʻaaogaina autu ma `&i32`:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // e maua ai lenei mea e pei ole '0x7f06092ac6d0'
/// ```
///
/// Le faatinoina o `Pointer` i luga o se ituaiga:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // faaaogaina `as` e tagata liliu mai i se `*const T`, lea e faatino e faasino ai, lea e mafai ona tatou faaaogaina
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// Faʻatulaga le taua e faʻaaogaina ai le faʻatulagaina.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// O le `LowerExp` trait tatau faatulagaga ana galuega faatino i tusitusiga faasaienisi ma le maualalo o tulaga `e`.
///
/// Mo nisi faʻamatalaga i luga o faʻatulaga, vaʻai [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// faaaogaina faavae ma `f64`:
///
/// ```
/// let x = 42.0; // 42.0 o '4.2e1' i tusitusiga faasaienisi
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// Le faatinoina o `LowerExp` i luga o se ituaiga:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // tuuina atu o le faatinoina e f64
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// Faʻatulaga le taua e faʻaaogaina ai le faʻatulagaina.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// O le `UpperExp` trait tatau faatulagaga ana galuega faatino i tusitusiga faasaienisi i se tulaga-luga `E`.
///
/// Mo nisi faʻamatalaga i luga o faʻatulaga, vaʻai [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// faaaogaina faavae ma `f64`:
///
/// ```
/// let x = 42.0; // 42.0 o le '4.2E1' i faʻamatalaga faʻasaienisi
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// Faʻaaogaina `UpperExp` i luga o se ituaiga:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // tuuina atu o le faatinoina e f64
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// Faʻatulaga le taua e faʻaaogaina ai le faʻatulagaina.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// O le galuega tauave `write` e se vaitafe galuega faatino, ma se fausia `Arguments` e mafai ona precompiled ma le macro `format_args!`.
///
///
/// O finauga o le a faʻatulagaina e tusa ai ma le faʻapitoa faʻatulagaina manoa i totonu o le gaosiga vaitafe saunia.
///
/// # Examples
///
/// Faʻaaoga faʻavae:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// Faamolemole ia matau ina ia mafai ona sili faaaogaina [`write!`].Faʻataʻitaʻiga:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // E mafai ona tatou faaaogaina le faataamilosaga faaletonu formatting mo finauga uma.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // E tofu lava le spec ma le finauga tutusa e muamua ai le fasi manoa.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // SAOGALEMU: arg ma args.args mai le finauga lava lea e tasi,
                // lea e mautinoa ai o faʻasino igoa e masani ona iai i totonu o tuaoi.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // E le mafai ona na o le tasi fasi tuua manoa trailing.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // SAFETY: arg ma args sau mai le tutusa Taua,
    // lea e mautinoa ai o faʻasino igoa e masani ona iai i totonu o tuaoi.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // Ia maua mai le finauga saʻo
    debug_assert!(arg.position < args.len());
    // SAFETY: arg ma args sau mai le tutusa Taua,
    // lea e faʻamaonia ai lona faʻasino taimi i totonu o tuaoi.
    let value = unsafe { args.get_unchecked(arg.position) };

    // Ona faia loa lea o ni lolomiga
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // SAOGALEMU: cnt ma args mai le finauga lava lea e tasi,
            // lea e faamaonia ai lenei faasino upu o loo i ai pea i totonu o tuaoi.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// Padding tuanai ai o le faaiuga o se mea.Toe foi e `Formatter::padding`.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// Tusi lenei pou padding.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // Matou te mananaʻo e suia lenei
            buf: wrap(self.buf),

            // Ma faasaoina nei
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // Fesoasoani fesoasoani faʻaaoga mo padding ma faʻagasologa faʻafanua finauga e mafai ona faʻaaoga uma faʻatulagaina traits.
    //

    /// Faatinoina le padding saʻo mo se integer lea ua uma ona emitted i se str.
    /// O le str tatau *le* o loo i ai le faailoga mo le integer, o le a faaopoopo i ai e lenei metotia.
    ///
    /// # Arguments
    ///
    /// * is_nonnegative, pe o le integer uluai sa lē lelei po o le o.
    /// * nauna, afai e maua le '#' amio (Alternate), o le nauna lea e tuʻu i luma o le numera.
    ///
    /// * buf, le byte array o le numera ua faʻatulagaina i
    ///
    /// Lenei gaioiga o le a sao tala mo fuʻa saunia faʻapea foi ma le laʻititi maualalo.
    /// O le a le ave saʻo i tala.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // E tatau ona tatou aveese "-" mai le galuega faatino numera.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // Tusia le faailoga pe afai o loo i ai, ma o lea o le pito i luma pe afai na talosagaina
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // O le `width` fanua e sili atu o le a parameter `min-width` i lenei taimi.
        match self.width {
            // Afai e leai se manaoga umi aupito maualalo lea e mafai ona tatou le na tusi le bytes.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Siaki pe afai tatou te i le lautele itiiti, pe afai e faapea e mafai ona tatou foi na tusi le bytes.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Le faailoga ma perefisi alu i luma o le padding pe afai o le tagata ua faatumulia ai o o
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // A leai, o le faʻailoga ma le nauna e alu pe a uma le padding
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// O lenei galuega e manaomia ai se manoa fasi ma faamatuu atu i le buffer lotoifale ina ua maea le faaaogaina o le talafeagai formatting fuʻa faamaotiina.
    /// O fuʻa aloaʻia mo manoa lautele o:
    ///
    /// * lautele, o le lautele maualalo o le a emit
    /// * fill/align - mea e emit ma le mea e emit ai pe afai o le manaoga tuuina manoa e avea padded
    /// * fetaui lelei, o le maualuga aupito maualuga e faʻapipiʻi ai, o le manoa e tipi pe a fai e umi atu nai lo lenei umi
    ///
    /// E maitauina lenei gaioiga le amanaʻiaina le `flag` tapulaʻa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // Ia mautinoa o loo i ai se ala o le anapogi ae luma
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // O le `precision` fanua e mafai ona faʻamatalaina o se `max-width` mo le manoa ua faʻataʻitaʻia.
        //
        let s = if let Some(max) = self.precision {
            // Afai e umi tatou manoa o le le saʻo, tatau lea ona tatou maua truncation.
            // Peitai isi fuʻa pei `fill`, e tatau ona `width` ma `align` galue e avea i taimi uma.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // LLVM iinei e le mafai ona faamaonia e faapea o le a le panic `&s[..i]` `..i`, ae tatou te iloa e le mafai panic.
                // Faaaoga `get` + `unwrap_or` e aloese `unsafe` ma isi faiga e ese te le emit se code panic-e fesootai i ai iinei.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // O le `width` fanua e sili atu o le a parameter `min-width` i lenei taimi.
        match self.width {
            // Afai matou te i lalo o le maualuga umi, ma e leai se tapulaʻa umi uʻamea manaʻomia, ona mafai lea ona tatou emit le manoa
            //
            None => self.buf.write_str(s),
            // Afai tatou te oe i lalo o le lautele aupito maualuga, siaki pe afai tatou te i le lautele aupito i maualalo, pe afai o lea e faigofie lava e pei lava emitting le manoa.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // Afai o matou i lalo uma o le lautele ma le lautele lautele, ona faʻatumu lea o le lautele laʻititi ma le faʻamaoti manoa + sina faʻatulagaina.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Tusi le muai padding ma toe foi le tusitusia mavae le padding.
    /// Tagata telefoni e nafa ma le faʻamautinoaina pe a maeʻa padding ua tusia pe a maeʻa le mea o loʻo teu.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// Ave le faʻavasega vaega ma faʻaogaina le padding.
    /// Faataunuuina o le ua uma ona tuuina atu le Tagata telefoni mai le vaega ma le saʻo manaomia, ina ia mafai ona le amanaiaina e faapea `self.precision`.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // mo le saini nofouta o le saini, matou te tuʻuina muamua le faʻailoga ma amio e pei na leai se matou faʻailoga mai le amataga.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // muamua alu pea se faailoga
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // aveʻese le faʻailoga mai vaega faʻatulaga
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // totoe vaega alu i le masani padding gaioiga.
            let len = formatted.len();
            let ret = if width <= len {
                // leai se padding
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // o le tulaga tutusa lenei mea ma tatou faia ai se auala 'alo
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // SAOGALEMU: e faaaoga lenei mo `flt2dec::Part::Num` ma `flt2dec::Part::Copy`.
            // E saogalemu e faaaoga mo `flt2dec::Part::Num` talu SIA uma `c` le va `b'0'` ma `b'9'`, o lona uiga `s` e aloaia UTF-8.
            // Atonu e sefe foi ile faʻataʻitaʻiga e faʻaaoga mo `flt2dec::Part::Copy(buf)` talu ai o le `buf` e tatau ona manino ASCII, ae e mafai e seisi ona pasi i se leaga leaga mo `buf` i le `flt2dec::to_shortest_str` talu ai ose galuega a le lautele.
            //
            // FIXME: Iloilo pe o lenei mea e ono iʻuga i le UB.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 zeroes
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// Tusia nisi faamatalaga i le buffer faavae o lo o aofia i totonu o lenei formatter.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // e tutusa lenei:
    ///         // tusi! (formatter, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// Tusia nisi faamatalaga formatted i lenei faataitaiga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// Fuʻa mo le faʻatulagaina
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// Uiga faaaogaina o 'fill' i soo se taimi o loo i ai ia talafeagai.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // Tatou faatulaga aafia i lenei suiga i le itu taumatau ma ">".
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// Fuʻa faailoa ai le mea na talosagaina ituaiga o aafia i lenei suiga.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// Filifili faʻapitoa faʻatulagaina integer lautele o le galuega faatino tatau ona.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // Afai tatou te maua a le lautele, tatou te faaaogaina ai
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // A leai ona tatou faia se mea faapitoa
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// Optionally faamaoti tonu mo ituaiga numeric.
    /// A le o lea, o le lautele lautele mo manoa ituaiga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // Afai tatou te maua ai se saʻo, tatou te faaaogaina ai.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // A leai, tatou te le pasi i le 2.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// Fuafua pe na faʻamaonia le fuʻa `+`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// Fuafuaina pe afai na faamaoti le fuʻa `-`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // E te manaʻo i se faʻailoga toʻese?Tuu atu se tasi!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// Fuafuaina pe afai na faamaoti le fuʻa `#`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// Fuafua pe na faʻamaonia le fuʻa `0`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // Matou te le amanaʻia filifiliga a le faila.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: Filifili le mea lautele API tatou te mananao mo nei fuʻa e lua.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// Faatupuina se faufale [`DebugStruct`] fuafuaina e fesoasoani ai i le foafoaga o implementations [`fmt::Debug`] mo structs.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// Fausia se fausiaina `DebugTuple` fuafuaina e fesoasoani i le fausiaina o `fmt::Debug` faʻatinoina mo tuple strowers.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// Faatupuina a fuafuaina tufuga `DebugList` e fesoasoani ai i le foafoaga o implementations `fmt::Debug` mo lisi-e pei o fausaga.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// Faatupuina a fuafuaina tufuga `DebugSet` e fesoasoani ai i le foafoaga o implementations `fmt::Debug` mo seti-e pei o fausaga.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// I lenei faataitaiga sili atu ona faigata, tatou te faaaogaina [`format_args!`] ma `.debug_set()` e fausia ai se lisi o lima fetaui:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// Faatupuina a fuafuaina tufuga `DebugMap` e fesoasoani ai i le foafoaga o implementations `fmt::Debug` mo faafanua-e pei o fausaga.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// Implementations o le autu formatting traits

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // Afai e manaʻomia le sola ese, faʻasolosolo tua i tua ma tusi, a le o le faʻamisi
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // O le isi fuʻa ua uma ona togafitia e LowerHex o se faʻapitoa-o lona uiga pe o le faʻamuamua ma le 0x.
        // Tatou faaaogaina e galulue pe e o tuuina atu, ona aunoa ma ni tuutuuga tuu e maua ai le pito i luma.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// Faʻaaogaina o Display/Debug mo ituaiga autu eseese

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // Ole RefCell e mafai ona nonoina e le mafai ona tatou vaʻai i lona tau iinei.
                // Faaali atu se placeholder ae.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// Afai e te faamoemoe tofotofoga i ai iinei, vaai nai lo i le faila core/tests/fmt.rs, e le o lo faigofie tele le faia o fausaga rt::Piece uma iinei.
//
// O loo i ai tofotofoga foi i le alloc crate, mo i latou o le faasoasoaina o manaomia le fesoasoani.