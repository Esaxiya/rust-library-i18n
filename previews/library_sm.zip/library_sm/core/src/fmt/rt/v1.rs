//! Lenei o se totonu totonu module faʻaaogaina e le ifmt!runtime.O nei fausaga ua emitted e arrays static e precompile manoa faatulagaga luma o taimi.
//!
//! O nei uiga e tutusa o latou tutusa `ct`, ae e ese i le e mafai ona faasoasoa statically nei ma ua teisi optimized mo le runtime
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Mafai faataatiaga e mafai ona talosagaina se vaega o se faatonuga formatting.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Faailoga e tatau ona aofia i totonu tauagavale-ogatasi.
    Left,
    /// Faʻailoga o mea i totonu e tatau ona saʻo-tuʻusaʻo.
    Right,
    /// Faʻailoga o mea i totonu e tatau ona ogatusa-ogatotonu.
    Center,
    /// Leai se avanoa na talosagaina
    Unknown,
}

/// Faʻaogaina e [width](https://doc.rust-lang.org/std/fmt/#width) ma [precision](https://doc.rust-lang.org/std/fmt/#precision) faʻapitoa.
#[derive(Copy, Clone)]
pub enum Count {
    /// Faamaoti mai i se numera moni, faleoloa le taua
    Is(usize),
    /// Faamaoti le faaaogaina `$` ma `*` syntaxes, faleoloa le faasino upu i `args`
    Param(usize),
    /// le faamaoti
    Implied,
}