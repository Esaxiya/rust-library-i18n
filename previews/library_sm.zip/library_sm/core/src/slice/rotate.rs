// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Faʻaaoga le laina `[mid-left, mid+right)` faʻapea o le elemeni i le `mid` avea ma muamua elemeni.Equivalently, e faasolosolo e le tele elemene `left` i le itu tauagavale po o elemene `right` i le itu taumatau.
///
/// # Safety
///
/// e tatau ona aloaia le ituaiga ua faamaoti mai mo le faitau ma le tusitusi.
///
/// # Algorithm
///
/// Algorithm 1 o loʻo faʻaaogaina mo laʻititi tau o `left + right` pe mo `T` tele.
/// O elemene e see atu i o latou tulaga mulimuli taʻitasi i le taimi e amata i le `mid - left` ma agaʻi i luma i le `right` sitepu modulo `left + right`, o se mea e naʻo le tasi le tumau e manaʻomia.
/// Mulimuli ane, ua tatou taunuʻu mai i le `mid - left`.
/// Ae peitaʻi, a le o le `gcd(left + right, right)` e le o 1, o sitepu o loʻo i luga na teʻa ese elemene.
/// Faataitaiga:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// O le mea e lelei ai, o le aofai o le misia o elemeni i le va o elemene faʻamaeʻaina e masani lava ona tutusa, o lea e mafai ai ona tatou faʻapalenia le tatou amataga tulaga ma faia isi taʻamilosaga (o le aofaʻi o numera o taʻamilosaga o le `gcd(left + right, right)` value).
///
/// O le iʻuga o le, o elemene uma e faʻamaeʻaina tasi ma tasi taimi.
///
/// o loo faaaogaina Algorithm 2 pe afai `left + right` e tele ae `min(left, right)` ua lava laiti ina ia fetaui i luga o se buffer faaputuga.
/// ua kopiina le elemene `min(left, right)` i luga o le buffer, o loo faatatau `memmove` i le isi, ma tagata i luga o le buffer ua toe siitia atu i le pu i luga o le isi itu o lea na latou amata.
///
/// Algorithms e mafai ona avea ma faʻataʻitaʻiga sili atu i luga o le taimi e tasi `left + right` avea lapoʻa lava.
/// O le Algorithm 1 e mafai ona faʻataʻitaʻia e ala i le tipiina ma le faʻataʻamilomiloina o taʻamilosaga e tasi i le taimi e tasi, ae e laʻititi foʻi taʻamilosaga ile averesi seʻi vagana ua matua tele le `left + right`, ma o le mea sili ona leaga e tasi le taʻamilosaga e masani ona iai.
/// Ae ui i lea, algorithm 3 faʻaaogaina le toe fesuiaiga o `min(left, right)` elemeni seʻia oʻo ina tuʻua se tamaʻi faʻasolosolo faʻafitauli.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// pe `left < right` le swapping tupu mai le ae le itu tauagavale.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. o loʻo i lalo algorithms mafai ona le manuia pe a fai o nei mataupu e le siakiina
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algorithm 1 Microbenchmarks faʻailoa mai o le averesi faʻatinoga mo soʻoga fesuiaʻiga e sili atu uma ala seia oʻo ile `left + right == 32`, ae o le sili ona leaga faʻatinoga galuega malepe tusa lava pe 16.
            // 24 na filifilia e fai ma ogatotonu.
            // Afai o le tele o `T` e lapoʻa nai lo le 4 `usize`s, o lenei algorithm e sili atu foi nai lo isi algorithms.
            //
            //
            let x = unsafe { mid.sub(left) };
            // amataga o le taʻamilosaga muamua
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` mafai ona maua muamua lima e ala i le fuafuaina `gcd(left + right, right)`, ae e sili atu le vave e faia le tasi matasele lea fuafua le gcd o se itu aʻafiaga, ona faia le toega o le fasi
            //
            //
            let mut gcd = right;
            // faʻailoga faʻailoa mai e sili atu le saoasaoa ona fesuiaʻi taimi le tumau nai lo le faitauina tasi le le tumau tasi, kopi i tua, ona tusia lea le tumau i le faaiuga.
            // E mafua ona o le mea moni o le fesuiaʻi poʻo le suia o taimi le tumau e faʻaaogaina naʻo le tasi le manatuaina tuatusi i le matasele nai lo le manaʻomia e faʻatonutonu lua.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // nai lo le incrementing `i` ma le siakiina lea pe afai ua i fafo o le tuaoi, ua tatou siaki pe o le a alu `i` fafo atu o le tuaoi i le increment sosoo ai.
                // E taofia ai le afifiina o faʻasino poʻo le `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // faaiuga o muamua faataamilo
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // o lenei aiaiga e tatau ona iinei pe a fai o `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // faʻauma le fasi ma isi taʻamilosaga
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` e le o se ituaiga zero-tele, o lea e lelei le vaevaeina i lona tele.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algorithm 2 O le `[T; 0]` iinei e mautinoa ai e fetaui lelei lenei mea mo T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algorithm 3 O loʻo iai se isi auala e faʻafesuiaʻi ai ma mea e aofia ai le sailia o le mea o le ai ai le swap mulimuli o lenei algorithm, ma fesuiaʻi le faʻaaogaina o le vaega mulimuli nai lo le fesuiaʻi o isi 'auʻauna pei o lenei algorithm o loʻo faia, ae o lenei auala e sili atu ona vave.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algorithm 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}