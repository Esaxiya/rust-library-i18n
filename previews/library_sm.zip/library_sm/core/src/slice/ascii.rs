//! Faʻagaioiga ile ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Siaki pe afai o bytes uma i lenei fasi i totonu ole ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Siaki e lua fasi o se ASCII tulaga-le malamalama taʻaloga.
    ///
    /// Tutusa lava ma `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, ae aunoa ma le tuʻuina atu ma le kopiina o taimi.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Faʻaliliuina lenei fasi i le ASCII pito i luga mataupu tutusa i le nofoaga.
    ///
    /// ASCII tusi 'a' e 'z' ua faailogaina e 'A' e 'Z', ae tusi lē ASCII ua suia.
    ///
    /// Ina ia toe faʻafoʻi mai se tau aofaʻi fou e aunoa ma le toe fesuiaʻi o se tasi, faʻaaoga le [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Tagata Liliu lenei fasi i lona ASCII tutusa tulaga i lalo i totonu o le nofoaga.
    ///
    /// O mataitusi ASCII 'A' i le 'Z' e faʻafanua i le 'a' i le 'z', ae o mataitusi e leʻo ASCII e le suia.
    ///
    /// Ina ia toe faʻafoʻi mai se tau maualalo maualalo e aunoa ma le toe fesuiaʻi o se tasi o loʻo i ai, faʻaaoga [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Faʻafoʻi `true` peʻa i ai se byte i le upu `v` o le nonascii (>=128).
/// Snarfed mai `../str/mod.rs`, lea e faia se mea tutusa mo utf8 faʻamaonia.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Optimized ASCII tofotofoga o le a faaaogaina usize-i-a-taimi gaoioiga nai lo le byte-i-a-taimi gaoioiga (pe a mafai).
///
/// O le algorithm matou te faʻaaogaina iinei e faigofie lava.Afai e puʻupuʻu `s`, naʻo le siakiina o paita taʻitasi ma maeʻa ai.A leai:
///
/// - Faitau le upu muamua ma le avega le tutusa.
/// - Faʻasaʻo le faʻasino tusi, faitau upu mulimuli mai seʻia oʻo i le iʻuga ma le faʻatulagaina o uta.
/// - Faitau le `usize` mulimuli mai `s` ma se avega le faʻatulagaina.
///
/// Afai o se tasi o nei avega gaosia se mea e toe foi moni ai `contains_nonascii` (above), ona tatou iloa lea o le tali e sese.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Afai tatou te le mauaina se mea mai le upu-i-le-taimi faʻatinoina, toe paʻu i se scalar matasele.
    //
    // Matou te faia foi lenei mea mo faʻataʻitaʻiga e le lava le faʻatasiga a le `size_of::<usize>()` mo `usize`, aua o se mea uiga ese le edge.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Matou te faitauina i taimi uma le upu muamua le faʻailoaina, o lona uiga o le `align_offset` o
    // 0, matou te toe faitauina le tutusa tutusa aoga mo le faʻatulagaina faitauga.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // SAOGALEMU: E faamaonia `len < USIZE_SIZE` luga.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Sa matou siakiina le mea lea i luga, fai sina faʻaali.
    // Manatua o le `offset_to_aligned` a le `align_offset` poʻo le `USIZE_SIZE`, o mea uma e lua o loʻo manino ona siakiina i luga.
    //
    debug_assert!(offset_to_aligned <= len);

    // SAFETY: upu_ptr o le (fetaui lelei) faʻaoga ptr matou te faʻaaogaina e faitau ai le
    // fasi ogatotonu o le fasi.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` o le byte index o `word_ptr`, faʻaaogaina mo siaki siaki iuga.
    let mut byte_pos = offset_to_aligned;

    // siaki Paranoia e uiga i aafia i lenei suiga, ona e tatou te sauni e faia se vaega o le avega unaligned.
    // I le faʻatinoina o lenei mea e le mafai ona taofiofia se meaola i le `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Faitau upu mulimuli ane seʻia oʻo i le taimi mulimuli upu tuʻufaʻatasia, le aofia ai le mulimuli upu tuʻufaʻatasi na o ia e faia i siʻusiʻu siaki mulimuli ane, ia mautinoa o le siʻu i taimi uma tasi `usize` sili atu i sili atu branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Sanity siaki o le faitauga i tuaoi
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Ma o matou manatu e uiga ile `byte_pos` taofi.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // SAFETI: Matou te iloa o le `word_ptr` e fetaui lelei (ona o
        // `align_offset`), ma matou iloa ua lava a matou paita i le va o `word_ptr` ma le iʻuga
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // SAOGALEMU: Ua tatou iloa o `byte_pos <= len - USIZE_SIZE`, lea o lona uiga o
        // a maeʻa lenei `add`, `word_ptr` o le a sili atu i le tasi-past-the-end.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Sanity siaki ia mautinoa e naʻo le tasi `usize` o totoe.
    // Lenei e tatau ona mautinoa e le matou matasele tulaga.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // SAFETI: O lenei e faʻamoemoe i le `len >= USIZE_SIZE`, lea matou te siakiina i le amataga.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}