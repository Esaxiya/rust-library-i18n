//! galuega tauave saoloto e faia `&[T]` ma `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Fausia se fasi mai le faʻasino tusi ma le umi.
///
/// O le finauga `len` o le numera o **elemene**, ae le o le numera o bytes.
///
/// # Safety
///
/// Amioga ua undefined pe afai o so o se ua solia ai tuutuuga nei:
///
/// * `data` tatau ona [valid] mo faitau mo `len * mem::size_of::<T>()` tele bytes, ma e tatau ona fetaui lelei.O lona uiga faʻapitoa:
///
///     * O le atoa manatua vaega o lenei fasi tatau ona aofia ai i totonu o se tasi atofaina mea!
///       Fasi e le mafai oʻo i totonu o le tele o mea atofaina.Vaʻai [below](#incorrect-usage) mo se faʻataʻitaʻiga le sese le aveina o lenei i le teuga tupe.
///     * `data` e tatau ona e lē soloia ma ogatusa lava mo fasi o-umi.
///     Tasi mafuaʻaga mo lenei o le enum faʻataʻitaʻiga faʻamautinoaina mafai ona faʻamoemoe i faʻasino (aofia ai fasi o soʻo se umi) o gatasi ma leai-leai e vaʻaia ai latou mai isi faʻamaumauga.
///     E mafai ona e mauaina se faʻasino tusi e mafai ona faʻaaoga e pei o `data` mo fasi e leai se umi e faʻaaoga ai [`NonNull::dangling()`].
///
/// * `data` e tatau ona faasino i `len` sosoo initialized lelei tulaga faatauaina o ituaiga `T`.
///
/// * O le mafaufau faʻamanatuina e le toe foʻi fasi e le tatau ona suia mo le umi o le olaga atoa `'a`, vagana totonu totonu o le `UnsafeCell`.
///
/// * O le tele atoa `len * mem::size_of::<T>()` o le fasi e tatau ona i ai se tele atu nai lo `isize::MAX`.
///   Vaʻai le saogalemu pepa faʻamaumauga o [`pointer::offset`].
///
/// # Caveat
///
/// O le olaga atoa mo le ua inferred fasi toe foi mai lona faaaogaina.
/// E taofia ai le faaaogaina sese faafuasei, o loo fautuaina e nonoa ai le olaga atoa i le olaga atoa puna po o fea lava le saogalemu i le mataupu, e pei o le tuuina atu o se galuega tauave fesoasoani le faia o le olaga atoa o le a taua o au mo le fasi, po o annotation manino.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // faʻaali se fasi mo se tasi elemeni
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Le saʻo faʻaaogaina
///
/// O le galuega tauave `join_slices` nei o **lē lelei le** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // O le faʻamatalaga i luga atu e mautinoa ai o `fst` ma `snd` e felataʻi, ae ono mafai lava ona aofia ai i totonu o le _different allocated objects_, o le mea na tupu ai lenei fasi e le faʻamatalaina amioga.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` ma `b` e eseese tufatufaina mea ...
///     let a = 42;
///     let b = 27;
///     // ... e mafai ona ui i lea ona faataatia mai contiguously i manatua: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Faʻatautaia le tutusa gaioiga e pei o le [`from_raw_parts`], seʻi vagana ua toe faʻafoʻi mai se fasi fesuiaʻi.
///
/// # Safety
///
/// Amioga ua undefined pe afai o so o se ua solia ai tuutuuga nei:
///
/// * `data` tatau ona [valid] mo faitau uma ma tusitusi mo `len * mem::size_of::<T>()` tele bytes, ma e tatau ona faʻafetaui lelei.O lona uiga faapitoa:
///
///     * O le atoa manatua vaega o lenei fasi tatau ona aofia ai i totonu o se tasi atofaina mea!
///       Fasi e le mafai oʻo i totonu o le tele o mea atofaina.
///     * `data` e tatau ona e lē soloia ma ogatusa lava mo fasi o-umi.
///     Tasi mafuaʻaga mo lenei o le enum faʻataʻitaʻiga faʻamautinoaina mafai ona faʻamoemoe i faʻasino (aofia ai fasi o soʻo se umi) o gatasi ma leai-leai e vaʻaia ai latou mai isi faʻamaumauga.
///
///     E mafai ona e mauaina se faʻasino tusi e mafai ona faʻaaoga e pei o `data` mo fasi e leai se umi e faʻaaoga ai [`NonNull::dangling()`].
///
/// * `data` e tatau ona faasino i `len` sosoo initialized lelei tulaga faatauaina o ituaiga `T`.
///
/// * Le manatu o loo taʻua e le tatau ona mauaina fasi toe foi e ala i so o se isi e faasino (e le maua mai i le taua o le toe foi) mo le umi o le olaga atoa `'a`.
///   E faasa uma ona faitau ma tusi ulufale.
///
/// * O le tele atoa `len * mem::size_of::<T>()` o le fasi e tatau ona i ai se tele atu nai lo `isize::MAX`.
///   Vaʻai le saogalemu pepa faʻamaumauga o [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Tagata liliu mai o se faasinomaga i T i se fasi o le umi 1 (e aunoa ma le kopiina).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Tagata liliu mai o se faasinomaga i T i se fasi o le umi 1 (e aunoa ma le kopiina).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}