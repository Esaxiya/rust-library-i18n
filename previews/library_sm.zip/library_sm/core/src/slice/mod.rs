// ignore-tidy-filelength

//! Fasi pulega ma le pule saua.
//!
//! Mo nisi faʻamatalaga vaʻai ile [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Pure rust memchr implement, aveese mai le rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// O lenei gaioiga e faʻasalalau lautele ona e leai seisi auala e faʻaalu ai le suʻega o heapsort.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Toe foi le aofai o elemene i totonu o le fasi.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // SAFETY: Const leo aua matou te lafoina i fafo le umi fanua o se usize (lea e tatau ona i ai)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // SAFETY: e saogalemu lenei mea ona o `&[T]` ma `FatPtr<T>` e tutusa o latou faʻatulagaga.
            // Naʻo le `std` e mafai ona faia lenei faʻamaoniga.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Sui ma le `crate::ptr::metadata(self)` peʻa tumau lena mea.
            // E pei o lenei tusitusiga o lenei mafuaʻaga o le "Const-stable functions can only call other const-stable functions" mea sese.
            //

            // SAFETY: Avanoa le taua mai le `PtrRepr` iuni e saogalemu talu mai * const T
            // ma PtrComponents<T>ia tutusa lau faʻamanatuga.
            // Naʻo le std e mafai ona faia lenei faʻamaoniga.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Faʻafoʻi `true` peʻa fai o le fasi umi le umi.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Faʻafoʻi mai le elemene muamua o le fasi, poʻo le `None` peʻa leai se mea.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Faafoi a faʻasino mutable i le elemene muamua o le fasi, po `None` pe afai ua avanoa.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// O tupe maua o le muamua ma le elemene o le malologa o le uma o le fasi, po `None` pe afai ua avanoa.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// O tupe maua o le muamua ma le elemene o le malologa o le uma o le fasi, po `None` pe afai ua avanoa.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Faʻafoʻi mai le mulimuli ma totoe o elemeni uma o le fasi, poʻo le `None` peʻa leai se mea.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Faʻafoʻi mai le mulimuli ma totoe o elemeni uma o le fasi, poʻo le `None` peʻa leai se mea.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Toe afio mai le elemene mulimuli o le fasi, po `None` pe afai ua avanoa.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Faʻafoʻi mai se faʻatulagaina suia i le aitema mulimuli i le fasi.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Faʻafoʻi mai se faʻasino i se elemeni poʻo se tautua faʻalagolago i le ituaiga o faʻasino igoa.
    ///
    /// - Afai e tuuina mai se tulaga, Ua toe foi se faasinomaga i le elemene i lena tofiga po `None` pe afai o tuaoi.
    ///
    /// - Afai e tuuina atu se ituaiga, Ua toe foi le subslice tutusa i lena vaega, po o `None` pe afai o tuaoi.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Faʻafoʻi mai se suiga suia i se elemeni poʻo se tautua faʻalagolago i le ituaiga o faʻasino (vaai [`get`]) poʻo le `None` pe a fai o le faʻasino igoa i fafo atu o tuaoi.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Toe foi se faasinomaga i se elemene po o subslice, e aunoa ma le faia o tuaoi siakiina.
    ///
    /// Mo se isi auala saogalemu vaai [`get`].
    ///
    /// # Safety
    ///
    /// O le valaʻauina o lenei metotia ma se faʻasino i fafo atu o tuaoi o le *[amioga le faʻamatalaina]* e tusa lava pe le o faʻaaogaina le faʻamatalaga e taunuʻu mai.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // SAFETY: o le tagata telefoni e tatau ona lagolagoina le tele o le saogalemu manaʻoga mo `get_unchecked`;
        // o le fasi e faʻaleaogaina aua `self` o se saogalemu faʻasino.
        // O le toe faʻasino faasino e saogalemu aua impls o `SliceIndex` tatau ona mautinoa o lea e.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Faʻafoʻi mai se fesoʻotaʻiga le suia i se elemeni poʻo se faʻasologa, e aunoa ma le faia o tuaoi siaki.
    ///
    /// Mo se isi auala saogalemu vaai [`get_mut`].
    ///
    /// # Safety
    ///
    /// O le valaʻauina o lenei metotia ma se faʻasino i fafo atu o tuaoi o le *[amioga le faʻamatalaina]* e tusa lava pe le o faʻaaogaina le faʻamatalaga e taunuʻu mai.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu manaʻoga mo `get_unchecked_mut`;
        // o le fasi e faʻaleaogaina aua `self` o se saogalemu faʻasino.
        // O le toe faʻasino faasino e saogalemu aua impls o `SliceIndex` tatau ona mautinoa o lea e.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Faʻafoʻi mai se faʻasino tusi i le buffer a fasi.
    ///
    /// Ole tagata e valaʻau e tatau ona mautinoa o le fasi fasi ola le pointer toe faʻatinoina lenei gaioiga, a leai o le a iu lava i le faʻasino i lapisi.
    ///
    /// E tatau foʻi i le tagata telefoni ona faʻamautinoa o le manatuaina o le tusi (non-transitively) manatu i ai e le tusia i (vagana i totonu o le `UnsafeCell`) faʻaogaina lenei faʻasino poʻo se faʻasino tusi mai ai.
    /// Afai e te manaʻomia le suia o mea o loʻo i totonu o le fasi, faʻaaoga le [`as_mut_ptr`].
    ///
    /// Fesuiaʻiga o koneteina faʻasino i lenei fasi mafai mafua ai lona faʻamau e tatau ona toe faʻatulagaina, lea e ono avea ai foʻi ni faʻasino ia te ia le aoga.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Faʻafoʻi mai se faʻailoga faʻafuaseʻi le saogalemu i le buffer o le fasi.
    ///
    /// Ole tagata e valaʻau e tatau ona mautinoa o le fasi fasi ola le pointer toe faʻatinoina lenei gaioiga, a leai o le a iu lava i le faʻasino i lapisi.
    ///
    /// Fesuiaʻiga o koneteina faʻasino i lenei fasi mafai mafua ai lona faʻamau e tatau ona toe faʻatulagaina, lea e ono avea ai foʻi ni faʻasino ia te ia le aoga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Faʻafoʻi mai le lua mata faʻailoaina lautele le fasi.
    ///
    /// O le toe foi laina o le afa-matala, o lona uiga o le iʻuga faʻasino tusi *tasi taimi ua tuanaʻi* le elemene mulimuli o le fasi.
    /// Lenei auala, o se avanoa gaogao o loʻo faʻatusalia e lua tutusa faʻasino, ma le 'eseʻesega i le va o le lua faʻasino foliga o le tele o le fasi.
    ///
    /// Vaʻai [`as_ptr`] mo lapataʻiga i le faʻaaogaina o nei fesoasoani.O le iʻuga faʻasino tusi e manaʻomia le faʻaeteetega, aua e le faʻasino i se elemeni aoga i le fasi.
    ///
    /// O lenei gaioiga e aoga mo fesoʻotaʻiga ma faʻavaomalo fesoʻotaʻiga o loʻo faʻaaogaina ai ni faʻasino se lua e faʻatatau ai le tele o elemene i le manatuaina, e pei ona masani ai i le C++ .
    ///
    ///
    /// E mafai foi ona aoga e siaki pe o se faʻasino i se elemeni e faʻasino i se elemene o lenei fasi:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // SAFETY: O le `add` iinei e saogalemu, aua:
        //
        //   - O faʻasino uma o vaega o le mea e tasi, pei o le faʻasino saʻo i tua o le mea faʻapea foi faitau.
        //
        //   - O le tele o le fasi e le sili atu tele nai lo isize::MAX bytes, pei ona taʻua iinei:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - E leai se afifi faʻataʻamilomilo aofia ai, pei o fasi e le afifi pasia le pito o le tuatusi avanoa.
        //
        // Vaʻai faʻamaumauga ole pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Faʻafoʻi mai le le saogalemu mutable pointers lua faʻasolo le fasi.
    ///
    /// O le toe foi laina o le afa-matala, o lona uiga o le iʻuga faʻasino tusi *tasi taimi ua tuanaʻi* le elemene mulimuli o le fasi.
    /// Lenei auala, o se avanoa gaogao o loʻo faʻatusalia e lua tutusa faʻasino, ma le 'eseʻesega i le va o le lua faʻasino foliga o le tele o le fasi.
    ///
    /// Vaʻai [`as_mut_ptr`] mo lapataʻiga i le faʻaaogaina o nei fesoasoani.
    /// O le iʻuga faʻasino tusi e manaʻomia le faʻaeteetega, aua e le faʻasino i se elemeni aoga i le fasi.
    ///
    /// O lenei gaioiga e aoga mo fesoʻotaʻiga ma faʻavaomalo fesoʻotaʻiga o loʻo faʻaaogaina ai ni faʻasino se lua e faʻatatau ai le tele o elemene i le manatuaina, e pei ona masani ai i le C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // SAFETI: Vaʻai as_ptr_range() luga pe aisea `add` iinei e saogalemu.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Faʻafesuiaʻi elemeni e lua i le fasi.
    ///
    /// # Arguments
    ///
    /// * a, Le faʻasino igoa o le muamua elemeni
    /// * b, Le faʻasino igoa o le elemene lona lua
    ///
    /// # Panics
    ///
    /// e Panics afai `a` po `b` mai le tuaoi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // E le mafai ona ave ni nonogatupe e lua mai le tasi vector, o lea ia e faʻaaoga ai faʻasino mata.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // SAFETY: `pa` ma `pb` na faia mai se fesuiaiga o fesuiaʻiga ma sefe
        // i elemeni i totonu o le fasi ma o lea e mautinoa e aoga ma fetaui.
        // Manatua o le faʻaaogaina o elemeni i tua atu o le `a` ma le `b` e siakiina ma o le a panic pe a oʻo i tuaoi.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Tulaga tuufaafeagai o le faatulagaga o elemene i totonu o le fasi, i le nofoaga.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Mo ituaiga laʻititi, o tagata taʻitasi uma e faitau i le masani auala faʻaalia le lelei.
        // E mafai ona sili atu mea tatou te mafaia, tuʻuina atu lelei load/store le faʻailoaina, e ala i le utaina o se lapoʻa tele ma feliuaʻi se tusi resitala.
        //

        // Lelei tele LLVM o le a faia lenei mea mo i tatou, aua e sili atu lona iloa nai lo tatou faia pe a le fetaui laina faitau e lelei (talu ai o suiga i le va o ARM eseese, mo se faʻataʻitaʻiga) ma o le a le sili fasi fasi o le a.
        // Ae paga lea, e pei o le LLVM 4.0 (2017-05) naʻo le tatalaina le matasele, o lea tatou manaʻomia ai ona faia lenei tatou lava.
        // (Faʻataʻitaʻiga: toe faʻafitauli e faigata ona o itu e mafai ona faʻafetaui ese-o le a, pe a o le umi e ese-o lea e leai se auala o emitting muamua-ma postludes e faʻaaoga atoatoa fetaui SIMD i le ogatotonu.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Faʻaaoga le llvm.bswap intrinsic e toe sui u8s i se faʻaaoga
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // SAOGALEMU: E tele ni mea e siaki iinei:
                //
                // - Manatua o le `chunk` a le o le 4 poʻo le 8 ona o le siaki i luga.Ma `chunk - 1` e lelei.
                // - O le faʻasino igoa ma le index `i` e lelei a o le faʻataʻamiloina o siaki faʻamaoniga
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`
                // - O le faʻasino igoa ma le igoa `ln - i - chunk = ln - (i + chunk)` e lelei:
                //   - `i + chunk > 0` o trivially moni.
                //   - O le matasele siaki faʻamaonia:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, e faʻapea e toʻesea e le alu i lalo.
                // - O le valaauga `read_unaligned` ma `write_unaligned` e lelei:
                //   - `pa` tusi i le faʻasino igoa `i` i le mea `i < ln / 2 - (chunk - 1)` (vaʻai luga) ma le `pb` faʻasino i le faʻasino `ln - i - chunk`, o lona uiga la, e le sili atu `chunk` tele bytes le mamao mai le iʻuga o le `self`.
                //
                //   - So o se manatua initialized e aloaia `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Faʻaaoga le fefulisaʻi-e-16 e faʻafoʻi u16s i le u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // SAFETY: O u32 le faʻailoaina e mafai ona faitauina mai le `i` peʻa `i + 1 < ln`
                // (ma e mautinoa `i < ln`), aua o elemeni taʻitasi o 2 bytes ma o loʻo tatou faitauina le 4.
                //
                // `i + chunk - 1 < ln / 2` # ao tulaga
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Talu ai ona o le itiiti ifo nai lo le umi vaevaeina e 2, e tatau ai ona i ai i tuaoi.
                //
                // O lona uiga o le tuʻaiga `0 < i + chunk <= ln` e faʻaaloalogia i taimi uma, faʻamautinoa o le `pb` faʻasino mafai ona faʻaaoga saogalemu.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // SAFETY: `i` e maualalo i le afa o le umi o le fasi soʻo
            // E saogalemu le mauaina `i` ma `ln - i - 1` (`i` amata i 0 ma o le a le alu atili nai lo `ln / 2 - 1`).
            // O le taunuuga o vae o lea e aloaia ma ogatusa `pa` ma `pb`, ma e mafai ona faitauina mai ma tusia ai.
            //
            //
            unsafe {
                // Faʻafesuiaiga le saogalemu e aloese mai ai i tuaoi siaki i le swap saogalemu.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Faʻafoʻi mai i luga o le fasi.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Toe foi se iterator e mafai ai e toe faaleleia ai tulaga faatauaina taitasi.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Faʻafoʻi mai se faʻasolosolo i tuaoi uma windows o le umi `size`.
    /// O loʻo fesiliaʻi le windows.
    /// Afai e puupuu le fasi nai lo `size`, Ua toe foi se tulaga faatauaina o le iterator.
    ///
    /// # Panics
    ///
    /// Panics afai `size` o 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Afai o le fasi e puʻupuʻu nai lo `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Toe foi se iterator i elemene `chunk_size` o le fasi i se taimi, e amata i le amataga o le fasi.
    ///
    /// O fasi o fasi fasi ma e le felafolafoaʻi.Afai e le vaevaeina e le `chunk_size` le umi o le fasi, ona le maua ai lea o le umi `chunk_size` o le vaega mulimuli.
    ///
    /// Tagai [`chunks_exact`] mo se variant o lenei iterator e toe foi ni oga o pea tonu elemene `chunk_size`, ma [`rchunks`] mo le iterator e tasi ae amata i le faaiuga o le fasi.
    ///
    ///
    /// # Panics
    ///
    /// Panics pe a fai o `chunk_size` o 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Toe foi se iterator i elemene `chunk_size` o le fasi i se taimi, e amata i le amataga o le fasi.
    ///
    /// O ni oga e fasi mutable, ma faia le fesiliaʻi.Afai e le vaevaeina e le `chunk_size` le umi o le fasi, ona le maua ai lea o le umi `chunk_size` o le vaega mulimuli.
    ///
    /// Vaʻai [`chunks_exact_mut`] mo se fesuiaʻiga o lenei iterator e faʻafoʻi 'au o taimi uma lava `chunk_size` elemeni, ma [`rchunks_mut`] mo le tutusa iterator ae amata i le faʻaiuga o le fasi.
    ///
    ///
    /// # Panics
    ///
    /// Panics pe a fai o `chunk_size` o 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Toe foi se iterator i elemene `chunk_size` o le fasi i se taimi, e amata i le amataga o le fasi.
    ///
    /// O ni oga e fasi ma faia le fesiliaʻi.
    /// Afai e le vaevaeina e le `chunk_size` le umi o le fasi, ona aveʻesea ai lea o le mulimuli e oʻo i le `chunk_size-1` elemeni ma mafai ona maua mai i le `remainder` galuega a le iterator.
    ///
    ///
    /// Ona o vaega taʻitasi o loʻo i ai le `chunk_size` elemeni, o le tagata tuʻufaʻatasia e mafai ona sili atu le faʻaleleia o le faʻaiʻuga o le tulafono e sili atu nai lo le tulaga o le [`chunks`].
    ///
    /// Vaʻai [`chunks`] mo se fesuiaʻiga o lenei iterator e faʻapea foi ona toe faafoi mai le mea na totoe o se tamai fasi, ma [`rchunks_exact`] mo le tutusa iterator ae amata i le faaiuga o le fasi.
    ///
    /// # Panics
    ///
    /// Panics pe a fai o `chunk_size` o 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Toe foi se iterator i elemene `chunk_size` o le fasi i se taimi, e amata i le amataga o le fasi.
    ///
    /// O fasi e fai ma fasi suiga, ma aua le soʻosoʻo.
    /// Afai e le vaevaeina e le `chunk_size` le umi o le fasi, ona aveʻesea ai lea o le mulimuli e oʻo i le `chunk_size-1` elemeni ma mafai ona maua mai i le `into_remainder` galuega a le iterator.
    ///
    ///
    /// Ona o vaega taʻitasi o loʻo i ai le `chunk_size` elemeni, e mafai e le tuʻufaʻatasiga ona sili atu le faʻalelei o le faʻaiʻuga o le code nai lo le tulaga o le [`chunks_mut`].
    ///
    /// Tagai [`chunks_mut`] mo se variant o lenei iterator e toe foi mai foi le vaega o totoe o se fāsimea laiti, ma [`rchunks_exact_mut`] mo le iterator e tasi ae amata i le faaiuga o le fasi.
    ///
    /// # Panics
    ///
    /// Panics pe a fai o `chunk_size` o 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Vaelua le fasi i totonu o se fasi 'N'-elemeni faʻasologa, manatu e leai se toega.
    ///
    ///
    /// # Safety
    ///
    /// faatoa mafai lava ona taʻua o lenei mea pe a
    /// - E vaevaeina saʻo le fasi i totonu o 'N'-element chunks (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // SAFETY: 1-elemene fasi e leai ni toega
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // SAFETY: O le fasi umi (6) o le tele o 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Nei o le a unsound:
    /// // tuʻu i lalo: &[[_;5]]= slice.as_chunks_unchecked()//O le fasi fasi umi e le o se faʻatele o le 5 tuʻu i lalo:&[[_;0]]= slice.as_chunks_unchecked()//E le faʻatagaina ni fasi uumi umi
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SAFETY: O la matou muamua mea o le mea tonu e manaʻomia e valaʻau lenei
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SAOGALEMU: Tatou te lafo a fasi o elemene `new_len * N` i
        // a fasi o `new_len` tele o elemene `N` ni oga.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Vaeluaina le fasi i se fasi o 'arrays N`-elemene, e amata i le amataga o le fasi, ma a totoe fasi ma umi matua itiiti ifo nai lo `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics afai `N` o 0. O lenei siaki le a sili ona atonu ona suia i se mea sese le taimi e tuufaatasia i luma e oo atu e gafatia lenei metotia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // SAFETI: Ua uma ona matou popolevale mo le leai, ma mautinoa e ala i le fausiaina
        // o le umi o le subslice o se tele o N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Vaeluaina le fasi i se fasi o 'arrays N`-elemene, e amata i le faaiuga o le fasi, ma a totoe fasi ma umi matua itiiti ifo nai lo `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics afai `N` o 0. O lenei siaki le a sili ona atonu ona suia i se mea sese le taimi e tuufaatasia i luma e oo atu e gafatia lenei metotia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // SAFETI: Ua uma ona matou popolevale mo le leai, ma mautinoa e ala i le fausiaina
        // o le umi o le subslice o se tele o N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Toe foi se iterator i elemene `N` o le fasi i se taimi, e amata i le amataga o le fasi.
    ///
    /// O toʻotoʻo o faʻatonuga faʻasino ma aua le soʻosoʻo.
    /// Afai e le vaevaeina e le `N` le umi o le fasi, ona aveʻesea ai lea o le mulimuli e oʻo i le `N-1` elemeni ma mafai ona maua mai i le `remainder` galuega a le iterator.
    ///
    ///
    /// O lenei metotia o le tutusa tutusa o [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics afai `N` o 0. O lenei siaki le a sili ona atonu ona suia i se mea sese le taimi e tuufaatasia i luma e oo atu e gafatia lenei metotia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Vaelua le fasi i totonu o se fasi 'N'-elemeni faʻasologa, manatu e leai se toega.
    ///
    ///
    /// # Safety
    ///
    /// faatoa mafai lava ona taʻua o lenei mea pe a
    /// - E vaevaeina saʻo le fasi i totonu o 'N'-element chunks (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // SAFETY: 1-elemene fasi e leai ni toega
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // SAFETY: O le fasi umi (6) o le tele o 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Nei o le a unsound:
    /// // tuʻu i lalo: &[[_;5]]= slice.as_chunks_unchecked_mut()//O le fasi fasi umi e le o se faʻatele o le 5 tuʻu i lalo:&[[_;0]]= slice.as_chunks_unchecked_mut()//E le faʻatagaina ni fasi uumi umi
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SAFETY: O la matou muamua mea o le mea tonu e manaʻomia e valaʻau lenei
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SAOGALEMU: Tatou te lafo a fasi o elemene `new_len * N` i
        // a fasi o `new_len` tele o elemene `N` ni oga.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Vaeluaina le fasi i se fasi o 'arrays N`-elemene, e amata i le amataga o le fasi, ma a totoe fasi ma umi matua itiiti ifo nai lo `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics afai `N` o 0. O lenei siaki le a sili ona atonu ona suia i se mea sese le taimi e tuufaatasia i luma e oo atu e gafatia lenei metotia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // SAFETI: Ua uma ona matou popolevale mo le leai, ma mautinoa e ala i le fausiaina
        // o le umi o le subslice o se tele o N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Vaeluaina le fasi i se fasi o 'arrays N`-elemene, e amata i le faaiuga o le fasi, ma a totoe fasi ma umi matua itiiti ifo nai lo `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics afai `N` o 0. O lenei siaki le a sili ona atonu ona suia i se mea sese le taimi e tuufaatasia i luma e oo atu e gafatia lenei metotia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // SAFETI: Ua uma ona matou popolevale mo le leai, ma mautinoa e ala i le fausiaina
        // o le umi o le subslice o se tele o N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Toe foi se iterator i elemene `N` o le fasi i se taimi, e amata i le amataga o le fasi.
    ///
    /// O ni oga o mutable mau autau ma faia le fesiliaʻi.
    /// Afai e le vaevaeina `N` le umi o le fasi, lea o le ae mulimuli i elemene `N-1` le a leai foi ma e mafai ona toe aumai i fafo mai le galuega tauave `into_remainder` o le iterator.
    ///
    ///
    /// O lenei metotia o le tutusa tutusa o [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics afai `N` o 0. O lenei siaki le a sili ona atonu ona suia i se mea sese le taimi e tuufaatasia i luma e oo atu e gafatia lenei metotia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Faʻafoʻi mai se mea faʻasolosolo i luga o le windows o `N` elemene o se fasi, amata i le amataga o le fasi.
    ///
    ///
    /// Ole tutusa tutusa lea ole [`windows`].
    ///
    /// Afai e sili atu le `N` nai lo le tele o le fasi, o le a toe faʻafoʻi leai windows.
    ///
    /// # Panics
    ///
    /// Panics pe a fai o `N` o 0.
    /// Lenei siaki e ono ono suia i se tuʻufaʻatasia taimi sese ao le i faʻamalosia lenei metotia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Toe foi se iterator i elemene `chunk_size` o le fasi i se taimi, e amata i le faaiuga o le fasi.
    ///
    /// O fasi o fasi fasi ma e le felafolafoaʻi.Afai e le vaevaeina e le `chunk_size` le umi o le fasi, ona le maua ai lea o le umi `chunk_size` o le vaega mulimuli.
    ///
    /// Tagai [`rchunks_exact`] mo se variant o lenei iterator e toe foi ni oga o pea tonu elemene `chunk_size`, ma [`chunks`] mo le iterator e tasi ae amata i le amataga o le fasi.
    ///
    ///
    /// # Panics
    ///
    /// Panics pe a fai o `chunk_size` o 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Toe foi se iterator i elemene `chunk_size` o le fasi i se taimi, e amata i le faaiuga o le fasi.
    ///
    /// O ni oga e fasi mutable, ma faia le fesiliaʻi.Afai e le vaevaeina e le `chunk_size` le umi o le fasi, ona le maua ai lea o le umi `chunk_size` o le vaega mulimuli.
    ///
    /// Tagai [`rchunks_exact_mut`] mo se variant o lenei iterator e toe foi ni oga o pea tonu elemene `chunk_size`, ma [`chunks_mut`] mo le iterator e tasi ae amata i le amataga o le fasi.
    ///
    ///
    /// # Panics
    ///
    /// Panics pe a fai o `chunk_size` o 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Toe foi se iterator i elemene `chunk_size` o le fasi i se taimi, e amata i le faaiuga o le fasi.
    ///
    /// O ni oga e fasi ma faia le fesiliaʻi.
    /// Afai e le vaevaeina e le `chunk_size` le umi o le fasi, ona aveʻesea ai lea o le mulimuli e oʻo i le `chunk_size-1` elemeni ma mafai ona maua mai i le `remainder` galuega a le iterator.
    ///
    /// Ona o vaega taʻitasi o loʻo i ai le `chunk_size` elemeni, o le tagata tuʻufaʻatasia e mafai ona sili atu le faʻaleleia o le faʻaiʻuga o le tulafono e sili atu nai lo le tulaga o le [`chunks`].
    ///
    /// Vaʻai [`rchunks`] mo se fesuiaʻiga o lenei iterator e faʻapea foi ona toe faafoi mai le mea na totoe o se tamai fasi, ma [`chunks_exact`] mo le tutusa iterator ae amata i le amataga o le fasi.
    ///
    ///
    /// # Panics
    ///
    /// Panics pe a fai o `chunk_size` o 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Toe foi se iterator i elemene `chunk_size` o le fasi i se taimi, e amata i le faaiuga o le fasi.
    ///
    /// O fasi e fai ma fasi suiga, ma aua le soʻosoʻo.
    /// Afai e le vaevaeina e le `chunk_size` le umi o le fasi, ona aveʻesea ai lea o le mulimuli e oʻo i le `chunk_size-1` elemeni ma mafai ona maua mai i le `into_remainder` galuega a le iterator.
    ///
    /// Ona o vaega taʻitasi o loʻo i ai le `chunk_size` elemeni, e mafai e le tuʻufaʻatasiga ona sili atu le faʻalelei o le faʻaiʻuga o le code nai lo le tulaga o le [`chunks_mut`].
    ///
    /// Vaʻai [`rchunks_mut`] mo se fesuiaʻiga o lenei iterator e faʻapea foi ona toe faafoi mai le mea na totoe o se tamai fasi, ma [`chunks_exact_mut`] mo le tutusa iterator ae amata i le amataga o le fasi.
    ///
    ///
    /// # Panics
    ///
    /// Panics pe a fai o `chunk_size` o 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Faʻafoʻi mai se mea faʻasolosolo i luga o le fasi pepa e maua mai ai le soʻoga faʻataʻamilomiloina o elemeni e faʻaaogaina ai le vavao e tuueseese ai.
    ///
    /// O le predicate e valaʻauina i ni elemeni se lua e mulimuli ia latou lava, o lona uiga o le faʻataʻitaʻiga e valaʻau i le `slice[0]` ma le `slice[1]` ma le `slice[1]` ma le `slice[2]` ma isi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Lenei metotia mafai ona faʻaaogaina e aveʻese mai le faʻavasega lisi:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Faʻafoʻi mai se mea faʻasolosolo i luga o le fasi pepa e maua mai ai ni fesoʻotaʻiga elemeni e le mafai ona fesiliaʻi e faʻaaoga ai le faʻamatalaga e tuʻueseese ai.
    ///
    /// O le predicate e valaʻauina i ni elemeni se lua e mulimuli ia latou lava, o lona uiga o le faʻataʻitaʻiga e valaʻau i le `slice[0]` ma le `slice[1]` ma le `slice[1]` ma le `slice[2]` ma isi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Lenei metotia mafai ona faʻaaogaina e aveʻese mai le faʻavasega lisi:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Vaeluaina le tasi fasi i le lua ile index.
    ///
    /// O le muamua o le ai ai indices uma mai `[0, mid)` (e lē aofia ai le faasino upu `mid` lava) ma o le a aofia ai lona lua indices uma mai `[mid, len)` (e lē aofia ai le faasino upu `len` lava).
    ///
    ///
    /// # Panics
    ///
    /// Panics pe a `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // SAFETY: `[ptr; mid]` ma `[mid; len]` i totonu `self`, lea
        // faʻamalieina manaʻoga o `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// E vaevaeina le tasi fasi fesuiaʻi i le lua i se faasino igoa.
    ///
    /// O le muamua o le ai ai indices uma mai `[0, mid)` (e lē aofia ai le faasino upu `mid` lava) ma o le a aofia ai lona lua indices uma mai `[mid, len)` (e lē aofia ai le faasino upu `len` lava).
    ///
    ///
    /// # Panics
    ///
    /// Panics pe a `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // SAFETY: `[ptr; mid]` ma `[mid; len]` i totonu `self`, lea
        // faʻamalieina manaʻoga o `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Vaevae le tasi fasi i lua i se faasino upu, e aunoa ma le faia o tuaoi siakiina.
    ///
    /// O le muamua o le ai ai indices uma mai `[0, mid)` (e lē aofia ai le faasino upu `mid` lava) ma o le a aofia ai lona lua indices uma mai `[mid, len)` (e lē aofia ai le faasino upu `len` lava).
    ///
    ///
    /// Mo se isi auala saogalemu vaai [`split_at`].
    ///
    /// # Safety
    ///
    /// O le valaʻauina o lenei metotia ma se faʻasino i fafo atu o tuaoi o le *[amioga le faʻamatalaina]* e tusa lava pe le o faʻaaogaina le faʻamatalaga e taunuʻu mai.E tatau i le tagata telefoni ona faʻamautinoa o le `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // SAFETY: Tagata telefoni e tatau ona siaki lena `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Vaevae le tasi fasi mutable i lua i se faasino upu, e aunoa ma le faia o tuaoi siakiina.
    ///
    /// O le muamua o le ai ai indices uma mai `[0, mid)` (e lē aofia ai le faasino upu `mid` lava) ma o le a aofia ai lona lua indices uma mai `[mid, len)` (e lē aofia ai le faasino upu `len` lava).
    ///
    ///
    /// Mo se isi auala saogalemu vaai [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// O le valaʻauina o lenei metotia ma se faʻasino i fafo atu o tuaoi o le *[amioga le faʻamatalaina]* e tusa lava pe le o faʻaaogaina le faʻamatalaga e taunuʻu mai.E tatau i le tagata telefoni ona faʻamautinoa o le `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // SAFETY: Tagata telefoni e tatau ona siaki lena `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` ma `[mid; len]` e le o fesiliaʻi, o lona uiga o le toe faʻafoʻiina mai o se suiga e mafai ona suia.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Toe foi se iterator i subslices valavala ai i elemene e fetaui `pred`.
    /// e le i ai le elemene fetaui i le subslices.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Afai o le muamua elemeni e fetaui, o se fasi avanoa o le muamua aitema toe faafoi mai e le iterator.
    /// Faʻapena foi, afai o le mulimuli elemeni i le fasi e faʻafetaui, o se fasi avanoa o le aitema mulimuli toe faafoi mai e le iterator:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Afai lua elemene fetaui e saʻo tuaoi, o le a le taimi nei se fasi avanoa i le va o i latou:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Faʻafoʻi mai se mea faʻasolosolo i luga o soʻoga faʻamaumauga vaeluaina vavaeʻese e elemene e tutusa `pred`.
    /// e le i ai le elemene fetaui i le subslices.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Toe foi se iterator i subslices valavala ai i elemene e fetaui `pred`.
    /// ua i ai le elemene fetaui i le iuga o le subslice muamua o se terminator.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Afai o le elemeni mulimuli o le fasi e fetaui, o lena elemeni o le a avea ma faʻamutaina o le fasi muamua.
    ///
    /// O lena fasi pepa o le aitema mulimuli toe foi mai e le iterator.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Faʻafoʻi mai se mea faʻasolosolo i luga o soʻoga faʻamaumauga vaeluaina vavaeʻese e elemene e tutusa `pred`.
    /// O le elemeni faʻafetaui o loʻo iai i le subslice talu ai o se faʻamutaina.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Faʻafoʻi mai se faʻavae i luga o subslices vavaeʻese e elemeni e tutusa `pred`, amata i le faaiuga o le fasi ma galue i tua.
    /// e le i ai le elemene fetaui i le subslices.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// E pei o le `split()`, afai o le muamua poʻo le mulimuli elemeni e faʻafetaui, o se fasi avanoa o le muamua (poʻo le mulimuli) aitema toe faʻafoʻi mai e le iterator.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Faʻafoʻi mai se mea faʻasolosolo i luga o soʻoga faʻavasega vaeluaina e elemeni e tutusa `pred`, amata i le faaiuga o le fasi ma galue i tua.
    /// e le i ai le elemene fetaui i le subslices.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Faʻafoʻi mai se faʻavae i luga o subslices vavaeʻese e elemene e tutusa `pred`, faʻatapulaʻa i le toe foʻi mai i le tele o `n` aitema.
    /// e le i ai le elemene fetaui i le subslices.
    ///
    /// O le elemene mulimuli na toe faʻafoʻi mai, pe afai e i ai, o le a aofia ai le toega o le fasi.
    ///
    /// # Examples
    ///
    /// Lolomi le fasi vaeluaina tasi i numera vaeluaina e le 3 (ie, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Faʻafoʻi mai se faʻavae i luga o subslices vavaeʻese e elemene e tutusa `pred`, faʻatapulaʻa i le toe foʻi mai i le tele o `n` aitema.
    /// e le i ai le elemene fetaui i le subslices.
    ///
    /// O le elemene mulimuli na toe faʻafoʻi mai, pe afai e i ai, o le a aofia ai le toega o le fasi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Toe foi se iterator i subslices valavala ai i elemene e fetaui faatapulaaina `pred` i le toe foi i le tele o mea `n`.
    /// E amata i le faaiuga o le fasi ma galue agai i tua.
    /// e le i ai le elemene fetaui i le subslices.
    ///
    /// O le elemene mulimuli na toe faʻafoʻi mai, pe afai e i ai, o le a aofia ai le toega o le fasi.
    ///
    /// # Examples
    ///
    /// Lolomiina le fasi vaeluaina tasi, amata mai le iuga, i numera vaeluaina e 3 (ie, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Toe foi se iterator i subslices valavala ai i elemene e fetaui faatapulaaina `pred` i le toe foi i le tele o mea `n`.
    /// E amata i le faaiuga o le fasi ma galue agai i tua.
    /// e le i ai le elemene fetaui i le subslices.
    ///
    /// O le elemene mulimuli na toe faʻafoʻi mai, pe afai e i ai, o le a aofia ai le toega o le fasi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Faʻafoʻi `true` pe a fai o le fasi fasi mea se elemeni ma le aofaʻi taua.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Afai e te le maua se `&T`, ae na o se `&U` e pei o `T: Borrow<U>` (eg
    /// 'Manoa: nono<str>'), E mafai ona e faaaogaina `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // fasi o le `String`
    /// assert!(v.iter().any(|e| e == "hello")); // saili ile `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Faafoi `true` afai `needle` o se pito i luma o le fasi.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Faʻafoʻi pea `true` pe a fai o `needle` o se fasi avanoa.
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Faʻafoʻi `true` peʻa o `needle` o se faʻauʻuga o le fasi.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Faʻafoʻi pea `true` pe a fai o `needle` o se fasi avanoa.
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Faʻafoʻi mai se faʻamatalaga ma aveese le nauna.
    ///
    /// Afai o le fasi amata i `prefix`, Ua toe foi le subslice tuanai ai o le pito i luma, afifi i `Some`.
    /// Afai `prefix` o avanoa, na toe foi mai le fasi uluai.
    ///
    /// Afai e le amata le fasi i le `prefix`, faʻafoʻi le `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // le a manaomia lenei galuega tauave toe tusia pe afai ma ina SlicePattern atili lavelave.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Faʻafoʻi mai se faʻavae ma aveese le faʻaupuga.
    ///
    /// Afai e faʻaiʻu le fasi i le `suffix`, toe faʻafoʻi le subslice ae le i faʻauuina, afifi i le `Some`.
    /// Afai e gaogao le `suffix`, na ona toe faʻafoʻi mai o le uluaʻi fasi.
    ///
    /// A le uma le fasi i le `suffix`, faʻafoʻi le `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // le a manaomia lenei galuega tauave toe tusia pe afai ma ina SlicePattern atili lavelave.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Binary saili lenei faʻavasega fasi mo se foaʻi elemeni.
    ///
    /// Afai e maua le tau ona toe faʻafoʻi mai lea o le [`Result::Ok`], o loʻo iai le index o le tutusa vaega.
    /// Afai e tele taʻaloga, ona mafai lea ona toe faʻafoʻi soʻo se tasi o matata.
    /// Afai e le maua le tau ona toe faʻafoʻi mai lea o le [`Result::Err`], o loʻo iai le faʻasino tusi e mafai ona tuʻu iai i totonu se elemeni tutusa aʻo tumau pea le faʻavasega lelei.
    ///
    ///
    /// Tagai foi [`binary_search_by`], [`binary_search_by_key`], ma [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Vaʻai i luga se faasologa o le fa elemeni.
    /// O le muamua e maua, ma le tulaga ese faʻatulagaina tulaga;o le lona lua ma le lona tolu e le maua;o le lona fa e mafai ona faʻatusatusa i soʻo se tulaga i `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Afai e te fia faaofi se mea i se vector faavasega, ao tumau pea ituaiga poloaiga:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// suesuega Binary lenei faavasega fasi ma se galuega tauave comparator.
    ///
    /// O le galuega faʻatusatusa e tatau ona faʻatinoina se faʻatonuga e ogatusa ma le faʻasologa o le vaega autu, toe faʻafoʻi mai se faʻasologa o faʻatonuga e faʻailoa mai ai o lana finauga o le `Less`, `Equal` poʻo le `Greater` le manaʻoga o manaʻomia.
    ///
    ///
    /// Afai e maua le tau ona toe faʻafoʻi mai lea o le [`Result::Ok`], o loʻo iai le index o le tutusa vaega.Afai e tele taʻaloga, ona mafai lea ona toe faʻafoʻi soʻo se tasi o matata.
    /// Afai e le maua le tau ona toe faʻafoʻi mai lea o le [`Result::Err`], o loʻo iai le faʻasino tusi e mafai ona tuʻu iai i totonu se elemeni tutusa aʻo tumau pea le faʻavasega lelei.
    ///
    /// Tagai foi [`binary_search`], [`binary_search_by_key`], ma [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Vaʻai i luga se faasologa o le fa elemeni.O le muamua e maua, ma se tulaga ese faʻatulagaina tulaga;o le lona lua ma le lona tolu e le maua;o le lona fa e mafai ona faʻatusatusa i soʻo se tulaga i `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // SAOGALEMU: ua faia saogalemu i le valaau e le invariants nei:
            // - `mid >= 0`
            // - `mid < size`: `mid` e faʻatapulaʻa e `[left; right)` fusia.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // O le mafuaʻaga tatou te faʻaaogaina ai le if/else faʻataʻamilosaga tafe nai lo le faʻataʻitaʻiga ona o le faʻafetauiina o faʻataʻitaʻiga faʻataʻitaʻiga gaioiga, e matua maaleale.
            //
            // O x86 asm mo u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// suesuega Binary lenei faavasega fasi ma se galuega tauave aveesea mai ki.
    ///
    /// Faapea o le fasi na faʻavasegaina e le ki, mo se faʻataʻitaʻiga ma [`sort_by_key`] faʻaaogaina le tutusa ki aveʻesea galuega tauave.
    ///
    /// Afai e maua le tau ona toe faʻafoʻi mai lea o le [`Result::Ok`], o loʻo iai le index o le tutusa vaega.
    /// Afai e tele taʻaloga, ona mafai lea ona toe faʻafoʻi soʻo se tasi o matata.
    /// Afai e le maua le tau ona toe faʻafoʻi mai lea o le [`Result::Err`], o loʻo iai le faʻasino tusi e mafai ona tuʻu iai i totonu se elemeni tutusa aʻo tumau pea le faʻavasega lelei.
    ///
    ///
    /// Vaʻai foʻi [`binary_search`], [`binary_search_by`], ma [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Vaʻai i luga se faasologa o le fa elemeni i se fasi o paga faʻavasegaina e latou elemeni lona lua.
    /// O le muamua e maua, ma le tulaga ese faʻatulagaina tulaga;o le lona lua ma le lona tolu e le maua;o le lona fa e mafai ona faʻatusatusa i soʻo se tulaga i `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // E faʻatagaina le Lint rustdoc::broken_intra_doc_links ona o le `slice::sort_by_key` i le crate `alloc`, ma e faʻapea e leʻi i ai lava pe a fausia `core`.
    //
    // sootaga i lalo crate: #74481.Talu ai o faʻamuamua e naʻo le faʻamaumauga i le libstd (#73423), o lenei mea e le taitaiina atu ai i le motusia sootaga i le faʻatinoga.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Ituaiga o le fasi, ae le mafai ona faasaoina le faatulagaga o elemene tutusa.
    ///
    /// Lenei ituaiga e le mautu (ie, ono toe faʻatulagaina tutusa elemeni), i le nofoaga (ie, e le faʻasoasoaina), ma *O*(*n*\*log(* n*)) sili ona leaga-tulaga.
    ///
    /// # Faʻatinoina nei
    ///
    /// O le algorithm o loʻo i ai nei e faʻavae i luga o le [pattern-defeating quicksort][pdqsort] e Orson Peters, lea e tuʻufaʻatasia ai le vave averesi mataupu o le randomized quicksort ma le vave sili ona leaga o le heapsort, aʻo mauaina laina taimi i luga o fasi ma nisi mamanu.
    /// Na te faʻaaogaina nisi faʻavasega e aloese ai mai tulaga faʻaletonu, ae ma le seed faʻamau e masani ona maua ai amioga mautinoa.
    ///
    /// E masani ona sili atu le vave nai lo le faʻavasega faʻavasegaina, seʻi vagana ai ni nai faʻapitoa mataupu, eg, pe a le fasi aofia ai le tele o concatenated faʻavasega faʻasologa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Faʻavasega le fasi ma se galuega faʻatusatusa, ae ono le faʻasaoina le faʻasologa o tutusa elemeni.
    ///
    /// Lenei ituaiga e le mautu (ie, ono toe faʻatulagaina tutusa elemeni), i le nofoaga (ie, e le faʻasoasoaina), ma *O*(*n*\*log(* n*)) sili ona leaga-tulaga.
    ///
    /// O le galuega faʻatusatusa e tatau ona faʻamatalaina atoa le okaina o elemeni i totonu o le fasi.Afai o le okaina e le atoa, o le faʻatonuga o elemeni e le o faʻamaoti maia.O se oka o se aofaʻiga oka pe a fai o (mo uma `a`, `b` ma `c`):
    ///
    /// * aofaʻi ma antisymmetric: e tasi lava le `a < b`, `a == b` poʻo le `a > b` e moni, ma
    /// * fesuiaʻi, `a < b` ma `b < c` faʻaalia `a < c`.O le tutusa e tatau ona taofia mo uma `==` ma `>`.
    ///
    /// Mo se faʻataʻitaʻiga, a o le [`f64`] e le faʻatinoina [`Ord`] aua `NaN != NaN`, e mafai ona tatou faʻaaogaina le `partial_cmp` e fai ma a tatou galuega faʻavae pe a tatou iloa o le fasi e le o i ai se `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Faʻatinoina nei
    ///
    /// O le algorithm o loʻo i ai nei e faʻavae i luga o le [pattern-defeating quicksort][pdqsort] e Orson Peters, lea e tuʻufaʻatasia ai le vave averesi mataupu o le randomized quicksort ma le vave sili ona leaga o le heapsort, aʻo mauaina laina taimi i luga o fasi ma nisi mamanu.
    /// Na te faʻaaogaina nisi faʻavasega e aloese ai mai tulaga faʻaletonu, ae ma le seed faʻamau e masani ona maua ai amioga mautinoa.
    ///
    /// E masani ona sili atu le vave nai lo le faʻavasega faʻavasegaina, seʻi vagana ai ni nai faʻapitoa mataupu, eg, pe a le fasi aofia ai le tele o concatenated faʻavasega faʻasologa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // faʻavasega faʻavasega
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Faʻavasega le fasi ma le autu aveʻeseʻese gaioiga, ae ono le faʻasaoina le faʻasologa o tutusa elemeni.
    ///
    /// O lenei ituaiga o mautu (o lona uiga, e mafai reorder elemene tutusa), i totonu o le nofoaga (ie, e le faasoasoa), ma *Le*(m\* * n *\* log(*n*)) sili ona leaga-tulaga, lea o le galuega tauave autu o *Le*(*m*).
    ///
    /// # Faʻatinoina nei
    ///
    /// O le algorithm o loʻo i ai nei e faʻavae i luga o le [pattern-defeating quicksort][pdqsort] e Orson Peters, lea e tuʻufaʻatasia ai le vave averesi mataupu o le randomized quicksort ma le vave sili ona leaga o le heapsort, aʻo mauaina laina taimi i luga o fasi ma nisi mamanu.
    /// Na te faʻaaogaina nisi faʻavasega e aloese ai mai tulaga faʻaletonu, ae ma le seed faʻamau e masani ona maua ai amioga mautinoa.
    ///
    /// Ona o lana ki taua valaʻauina, [`sort_unstable_by_key`](#method.sort_unstable_by_key) e foliga mai e telegese nai lo [`sort_by_cached_key`](#method.sort_by_cached_key) i mataupu pe a fai o le ki autu e taugata.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Reorder le fasi e faapea o elemene i `index` o loo i lona tulaga faavasegaina mulimuli.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Toe faʻatulaga le fasi ma se galuega faʻatusa e faʻapea o le elemeni ile `index` o loʻo i lona faʻavasegaina mulimuli i ai.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Toe faʻatulaga le fasi ma se ki o le aveʻeseina o mea taua e pei o le elemeni ile `index` o loʻo i lona faʻavasegaina tulaga mulimuli.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Reorder le fasi e faapea o elemene i `index` o loo i lona tulaga faavasegaina mulimuli.
    ///
    /// O lenei reordering ei ai le meatotino faaopoopo faapea so o se taua i le tulaga o le a `i < index` itiiti ifo po o le tutusa i so o se taua i se tulaga `j > index`.
    /// E le gata i lea, o lenei toe fetuʻunaʻiga e le mautonu (ie
    /// soʻo se numera o tutusa elemeni ono iu i le tulaga `index`), i le nofoaga (ie
    /// e le faʻasoasoaina), ma le *O*(*n*) tulaga sili ona leaga.
    /// Lenei galuega faʻapea foi/lauiloa o "kth element" i isi faletusi.
    /// E toe faʻafoʻi mai le tolu vaega o mea taua nei: o elemeni uma e laititi ifo ile tasi i le faʻasino na tuʻuina atu, o le tau ile faʻasino na tuʻuina atu, ma elemeni uma e sili atu ile tasi i le faʻasino na tuʻuina atu.
    ///
    ///
    /// # Faʻatinoina nei
    ///
    /// O le algorithm o loʻo i ai nei e faʻavae i luga o le vaega filifilia vave o le tutusa quicksort algorithm faʻaaoga mo [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics pe a `index >= len()`, o lona uiga e masani ona panics i luga o gaogao fasi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Saili le median
    /// v.select_nth_unstable(2);
    ///
    /// // E naʻo matou e mautinoa o le fasi fasi o le a avea ma se tasi o mea o loʻo mulimuli mai, faʻavae i luga o le auala matou te faʻavasegaina e uiga i le faʻasino igoa.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Toe faʻatulaga le fasi ma se galuega faʻatusa e faʻapea o le elemeni ile `index` o loʻo i lona faʻavasegaina mulimuli i ai.
    ///
    /// O lenei reordering ei ai le meatotino faaopoopo faapea so o se taua i le tulaga o le a `i < index` itiiti ifo po o le tutusa i so o se taua i se tulaga e faaaoga `j > index` le galuega tauave comparator.
    /// E le gata i lea, o lenei toe fetuʻunaʻiga e le mautonu (ie o soʻo se numera o tutusa elemeni ono iʻu i le tulaga `index`), i le nofoaga (ie le faʻasoasoaina), ma *O*(*n*) sili ona leaga-tulaga.
    /// O lenei gaioiga ua lauiloa foi o le "kth element" i isi faletusi.
    /// E toe faʻafoʻi mai le tolu vaega o mea taua nei: o elemeni uma e laititi ifo ile tasi i le faʻasino na tuʻuina atu, o le tau ile faʻasino na tuʻuina atu, ma elemeni uma e sili atu ile tasi i le faʻasino na tuʻuina atu, e faʻaaogaina ai le galuega faʻatatau.
    ///
    ///
    /// # Faʻatinoina nei
    ///
    /// O le algorithm o loʻo i ai nei e faʻavae i luga o le vaega filifilia vave o le tutusa quicksort algorithm faʻaaoga mo [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics pe a `index >= len()`, o lona uiga e masani ona panics i luga o gaogao fasi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Saili le median e pei o le fasi na vaʻavasega i lalo faʻasologa.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // E naʻo matou e mautinoa o le fasi fasi o le a avea ma se tasi o mea o loʻo mulimuli mai, faʻavae i luga o le auala matou te faʻavasegaina e uiga i le faʻasino igoa.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Toe faʻatulaga le fasi ma se ki o le aveʻeseina o mea taua e pei o le elemeni ile `index` o loʻo i lona faʻavasegaina tulaga mulimuli.
    ///
    /// O lenei toe fetuʻunaiga o loʻo iai se meatotino faʻaopopo o soʻo se tau ile tulaga `i < index` o le a laʻititi ifo pe tutusa i soʻo se tau ile tulaga `j > index` faʻaaogaina o le ki o le aveʻeseina o galuega.
    /// E le gata i lea, o lenei toe fetuʻunaʻiga e le mautonu (ie o soʻo se numera o tutusa elemeni ono iʻu i le tulaga `index`), i le nofoaga (ie le faʻasoasoaina), ma *O*(*n*) sili ona leaga-tulaga.
    /// O lenei gaioiga ua lauiloa foi o le "kth element" i isi faletusi.
    /// E toe faʻafoʻi mai le tolu vaega o mea taua nei: o elemeni uma e laititi ifo ile tasi i le faʻasino na tuʻuina atu, o le tau ile faʻasino na tuʻuina atu, ma elemeni uma e sili atu ile tasi i le faʻasino na tuʻuina atu, e faʻaaoga ai le vaega autu na aveese ai le aveʻesega.
    ///
    ///
    /// # Faʻatinoina nei
    ///
    /// O le algorithm o loʻo i ai nei e faʻavae i luga o le vaega filifilia vave o le tutusa quicksort algorithm faʻaaoga mo [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics pe a `index >= len()`, o lona uiga e masani ona panics i luga o gaogao fasi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Faʻafoʻi le mediani e pei o le vasega na faʻavasegaina e tusa ma le matua aoga.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // E naʻo matou e mautinoa o le fasi fasi o le a avea ma se tasi o mea o loʻo mulimuli mai, faʻavae i luga o le auala matou te faʻavasegaina e uiga i le faʻasino igoa.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Siʻi uma elemeni sosoʻo faʻasolosolo i le iʻuga o le fasi e tusa ma le [`PartialEq`] trait faʻatinoina.
    ///
    ///
    /// Faʻafoʻi lua fasi.O le muamua e leai ni sosoʻo faʻasolosolo toe fai.
    /// O le lona lua o loo i ai duplicates uma i se poloaiga maoti.
    ///
    /// Afai e faavasegaina le fasi, o le uluai toe foi fasi o loo i ai se duplicates.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Siʻi uma uma ae o le muamua o soʻotaga elemeni i le iʻuga o le fasi faʻamalieina a tuʻuina tutusa tutusa.
    ///
    /// Faʻafoʻi lua fasi.O le muamua e leai ni sosoʻo faʻasolosolo toe fai.
    /// O le lona lua o loo i ai duplicates uma i se poloaiga maoti.
    ///
    /// pasia ai le galuega tauave `same_bucket` mau e lua elemene mai le fasi ma e tatau ona fuafuaina pe afai o le elemene faatusatusa tutusa.
    /// O elemeni e pasi i le isi faʻatonuga mai le latou faʻatonuga i le fasi, o lea afai `same_bucket(a, b)` faʻafoʻi `true`, `a` e minoi i le pito o le fasi.
    ///
    ///
    /// Afai e faavasegaina le fasi, o le uluai toe foi fasi o loo i ai se duplicates.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // E ui lava e i ai so matou faʻamatalaga faʻasolosolo i le `self`, e le mafai ona matou faia ni suiga *faʻatatau*.O le `same_bucket` telefoni mafai panic, o lea e tatau ai ona tatou mautinoa o le fasi o i se tulaga faʻamaoni i taimi uma.
        //
        // Le ala tatou te taulimaina lenei e ala i le faaaogaina swaps;tatou iterate i luga o le elemene, swapping ao tatou ina ia i le faaiuga o le elemene tatou te mananao e tausia ai i le pito i luma, ma i latou tatou te mananao e teena o loo i le pito i tua.
        // Ona mafai lea ona tatou vaeluaina le fasi.
        // Lenei taotoga o `O(n)` pea.
        //
        // Faʻataʻitaʻiga: Matou te amata i lenei setete, lea e fai ma sui `r` "sosoo ai
        // faitau "ma `w` fai ma sui" next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Faʻatusatusaina self[r] faʻasaga ia te oe lava [w-1], e le o se mea faʻalua lea, o lea tatou te fesuiaʻi self[r] ma self[w] (leai se aoga e pei o r==w) ona faʻaopoopo uma ai lea o r ma le w, ma tuʻu ai ia i matou ma:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Faʻatusatusaina self[r] faʻasaga ia oe lava [w-1], o lenei tau aoga o se kopi faʻalua, o lea matou te faʻaopopoina `r` ae tuʻu isi mea uma e le suia.
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Faatusatusaina self[r] e faasaga i le tagata lava ia [w-1], e le o se lona lua lenei, ina Faafesuiaiga self[r] ma self[w] ma muamua r ma w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Le toe faʻaluaina, toe fai:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Faalua, advance r. End o fasi.Vaelua i le w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // SAOGALEMU: o le tulaga `while` faamaonia `next_read` ma `next_write`
        // e laʻititi ifo i le `len`, o lona uiga o loʻo i totonu o le `self`.
        // `prev_ptr_write` manatu i se tasi elemene luma `ptr_write`, ae `next_write` amataina i le 1, o lea e le mafai lava e itiiti ifo nai lo `prev_ptr_write` 0 ma ua i totonu o le fasi.
        // faataunuuina ai lenei tulaga manaomia mo le dereferencing `ptr_read`, `prev_ptr_write` ma `ptr_write`, ma mo le faaaogaina `ptr.add(next_read)`, `ptr.add(next_write - 1)` ma `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` e faʻaopoopoina foʻi i le sili atu tasi i le matasele i le tele o lona uiga e leai se elemeni e tuʻu ese pe a manaʻomia e fesuiaʻi.
        //
        // `ptr_read` ma `prev_ptr_write` e le faʻasino lava le mea e tasi.E manaʻomia lenei mo `&mut *ptr_read`, `&mut* prev_ptr_write` ia saogalemu.
        // O le faʻamatalaga e faigofie lava `next_read >= next_write` e moni i taimi uma, ma e faapena foi `next_read > next_write - 1`.
        //
        //
        //
        //
        //
        unsafe {
            // Aloʻese mai tuaoi siaki i le faʻaaogaina o faʻailo mata.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Siʻi uma uma ae o le muamua o soʻotaga elemeni i le iʻuga o le fasi e faʻamautuina i le tutusa ki.
    ///
    ///
    /// Faʻafoʻi lua fasi.O le muamua e leai ni sosoʻo faʻasolosolo toe fai.
    /// O le lona lua o loo i ai duplicates uma i se poloaiga maoti.
    ///
    /// Afai e faavasegaina le fasi, o le uluai toe foi fasi o loo i ai se duplicates.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Faasolo le fasi i totonu o le nofoaga e pei o le muamua `mid` elemene o le fasi agai i le iuga ao le mulimuli `self.len() - mid` elemene siitia i luma.
    /// A maeʻa ona valaʻau `rotate_left`, o le elemeni na muamua atu i le index `mid` o le a avea ma muamua elemeni i le fasi.
    ///
    /// # Panics
    ///
    /// Lenei gaioiga o le a panic pe a fai o `mid` e sili atu nai lo le umi o le fasi.Manatua o `mid == self.len()` faia _not_ panic ma o se leai-op feauauaʻiga.
    ///
    /// # Complexity
    ///
    /// Faʻaauau laina (i le `self.len()`) taimi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Rotating a subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // SAOGALEMU: O le tele `[p.add(mid) - mid, p.add(mid) + k)` o trivially
        // aoga mo le faitauina ma le tusitusi, e pei ona manaomia e `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Faasolo le fasi i totonu o le nofoaga e pei o le muamua `self.len() - k` elemene o le fasi agai i le iuga ao le mulimuli `k` elemene siitia i luma.
    /// A maeʻa ona valaʻau `rotate_right`, o le elemeni na muamua atu i le index `self.len() - k` o le a avea ma muamua elemeni i le fasi.
    ///
    /// # Panics
    ///
    /// O lenei galuega tauave a panic pe afai e sili `k` nai lo le umi o le fasi.Manatua e `k == self.len()` e _not_ panic ma o se feauauaʻii leai-op.
    ///
    /// # Complexity
    ///
    /// Faʻaauau laina (i le `self.len()`) taimi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Feauauaʻi a subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // SAOGALEMU: O le tele `[p.add(mid) - mid, p.add(mid) + k)` o trivially
        // aoga mo le faitauina ma le tusitusi, e pei ona manaomia e `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Faatumuina `self` i elemene e cloning `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Faatumuina `self` ma elemene toe foi ala i le valaau a tapunia pea.
    ///
    /// O lenei auala e faaaoga a tapunia e foafoa ai tulaga faatauaina fou.Afai e te manaʻomia [`Clone`] se tau aoga, faʻaaoga [`fill`].
    /// Afai e te manaʻo e faʻaaoga le [`Default`] trait e faʻatupu ai tau, e mafai ona e pasia le [`Default::default`] e avea ma finauga.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Kopi le elemene mai `src` i `self`.
    ///
    /// e tatau ona tutusa le umi o le `src` pei `self`.
    ///
    /// Afai e faʻaaoga e `T` `Copy`, e mafai ona sili atu le faʻatinoina o le faʻaaogaina o le [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// O lenei galuega tauave a panic pe afai o le fasi e lua finafinau eseese.
    ///
    /// # Examples
    ///
    /// Faʻaluaina o elemene e lua mai se fasi i leisi:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Talu ai o le fasi maua e avea ai o le umi lava lea e tasi, tatou te fasi le fasi puna mai elemene e fa i le lua.
    /// // E panic pe a tatou le faia lenei.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Ua faʻamalosia e le Rust e naʻo le tasi le faʻamatalaga e mafai ona suia e aunoa ma se faʻavasega i se vaega o faʻamatalaga i se tulaga faapitoa.
    /// Ona o lenei, o le taumafai e faʻaaoga le `clone_from_slice` i luga o se fasi e tasi o le a iʻu ai i se tuʻufaʻatasia o le toilalo:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// I le galuega o loo siomia ai lenei mea, e mafai ona tatou faaaogaina [`split_at_mut`] e fatu lua eseese laiti fasi mai se fasi:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Kopi elemene uma mai `src` i `self`, e faaaoga ai a memcpy.
    ///
    /// e tatau ona tutusa le umi o le `src` pei `self`.
    ///
    /// A le faʻaaogaina `T` `Copy`, faʻaaoga [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// O lenei galuega tauave a panic pe afai o le fasi e lua finafinau eseese.
    ///
    /// # Examples
    ///
    /// Kopiina o elemene e lua mai se fasi i leisi:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Talu ai o le fasi maua e avea ai o le umi lava lea e tasi, tatou te fasi le fasi puna mai elemene e fa i le lua.
    /// // E panic pe a tatou le faia lenei.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Ua faʻamalosia e le Rust e naʻo le tasi le faʻamatalaga e mafai ona suia e aunoa ma se faʻavasega i se vaega o faʻamatalaga i se tulaga faapitoa.
    /// Ona o lenei mea, taumafai e faaaoga `copy_from_slice` i luga o se fasi e tasi o le a taunuu ai i le toilalo e tuufaatasia:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// I le galuega o loo siomia ai lenei mea, e mafai ona tatou faaaogaina [`split_at_mut`] e fatu lua eseese laiti fasi mai se fasi:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // O le panic code path na tuʻuina i totonu o se malulu galuega e aua le faʻapipiina le nofoaga telefoni.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // SAFETY: `self` e aoga mo `self.len()` elemeni e ala i faʻauiga, ma `src` sa
        // siaki ia tutusa le umi.
        // O fasi fasi e le mafai ona faʻapipiʻi aua e mafai ona suia faʻatonuga.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Kopi elemene mai le tasi vaega o le fasi i le isi vaega o ia lava, e faaaoga ai se memmove.
    ///
    /// `src` o le tele i totonu o `self` e kopi mai.
    /// `dest` o le amataga faʻasino igoa o le tulaga i totonu `self` e kopi i, lea o le a tutusa le umi ma `src`.
    /// O laina e lua e ono fesiliaʻi.
    /// O pito o laina e lua e tatau ona laʻititi atu pe tutusa i le `self.len()`.
    ///
    /// # Panics
    ///
    /// Lenei gaioiga o le a panic pe a fai o soʻo seisi sili atu i le iʻuga o le fasi, pe afai o le faʻaiuga o `src` e muamua i le amataga.
    ///
    ///
    /// # Examples
    ///
    /// Kopiina o fa bytes i totonu o se fasi:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // SAOGALEMU: o le tuutuuga mo `ptr::copy` ua uma ona siakiina i luga,
        // e pei ona maua i latou mo `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Swaps elemene uma i `self` faatasi ma i latou i `other`.
    ///
    /// O le umi o `other` tatau ona tutusa ma `self`.
    ///
    /// # Panics
    ///
    /// O lenei galuega tauave a panic pe afai o le fasi e lua finafinau eseese.
    ///
    /// # Example
    ///
    /// Faʻafesuiaʻi ni elemeni se lua i ni fasi fasi:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Ua faʻamalosia e le Rust e naʻo le tasi le faʻamatalaga e mafai ona suia i se vaega o faʻamatalaga i se tulaga faapitoa.
    ///
    /// Ona o lenei mea, taumafai e faaaoga `swap_with_slice` i luga o se fasi e tasi o le a taunuu ai i le toilalo e tuufaatasia:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// I le galuega o loo siomia ai lenei mea, e mafai ona tatou faaaogaina [`split_at_mut`] e fatu lua eseese mutable laiti fasi mai se fasi:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // SAFETY: `self` e aoga mo `self.len()` elemeni e ala i faʻauiga, ma `src` sa
        // siaki ia tutusa le umi.
        // O fasi fasi e le mafai ona faʻapipiʻi aua e mafai ona suia faʻatonuga.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Galuega tauave e fuafua mamao o le fasi ogatotonu ma trailing mo `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Ole mea o le a tatou faia e uiga ile `rest` o le sailia lea o le a le tele o 'U's e mafai ona tatou tuʻuina i se maualalo numera o le' T's.
        //
        // Ma le tele o 'T`s tatou te manaomia mo taitasi e "multiple".
        //
        // Mafaufau mo se faataitaiga T=u8 U=u16.Ona mafai lea ona tatou tuʻuina le 1 U i le 2 Ts.Faigofie.
        // O lenei, ia mafaufau mo se faataitaiga o se tulaga pe afai size_of: :<T>=16, size_of::<U>=24.</u>
        // E mafai ona tatou tuu 2 Tatou i nofoaga uma 3 TS i le fasi `rest`.
        // Teisi faigata.
        //
        // Fua Faatatau e fuafua ai lenei o:
        //
        // Tatou= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>TS= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Faʻalauteleina ma faʻafaigofie:
        //
        // Tatou=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=tele_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Laki talu ai o nei mea uma o taimi uma-iloiloina ... faatinoga iinei e le afaina!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // iterative stein's algorithm E tatau lava ona tatou faia lenei `const fn` (ma toe foʻi i le recursive algorithm pe a tatou faia) aua o le faʻamoemoe i le llvm e faʻatonuina nei mea uma o…lelei, e mafua ai ona ou le toʻa.
            //
            //

            // SAFETY: `a` ma `b` o loʻo siaki e avea ma leai ni aoga.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // aveese uma mea taua o le 2 mai le
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // SAFETY: O le `b` ua siakiina ina ia leai-leai.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Faʻaauupegaina i lenei malamalama, e mafai ona tatou mauaina le fia o tatou e mafai ona ofi!
        let us_len = self.len() / ts * us;
        // Ma e fia 'T o le a i totonu o le auala savali!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Transmute le fasi i se fasi o se isi ituaiga, faamautinoaina o aafia i lenei suiga o le ituaiga o loo tausia.
    ///
    /// Lenei metotia vaeluaina le fasi i ni eseese eseʻese tolu: nauna, saʻo faʻatulagaina ogatotonu fasi o se fou ituaiga, ma le faʻavaega fasi.
    /// O le auala e mafai ona faia le fasi ogatotonu o le umi sili mafai e se tuuina ituaiga ma fasi sao, ae na tatau ona faalagolago faatinoga o galuega a lou algorithm i lena, ae le o lona saʻo.
    ///
    /// E faʻatagaina mo faʻamatalaga uma na faʻaulufaleina ina ia toe faʻafoʻi mai e avea ma se nauna poʻo seisi faʻailoga.
    ///
    /// O lenei metotia e leai se mafuaʻaga pe a le o le elemeni faʻaulu `T` poʻo le elemeni o loʻo i ai `U` e leai se tele ma o le a toe faʻafoʻi le uluaʻi fasi e aunoa ma le vaeluaina o se mea.
    ///
    /// # Safety
    ///
    /// O lenei metotia e taua lava o le `transmute` e tusa ai ma elemeni i le toe ogatotonu fasi, o lea o masani masani ai faʻatalanoaga e faatatau i le `transmute::<T, U>` faʻapena foʻi iinei.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Manatua o le tele o lenei gaioiga o le a faia pea-iloiloina,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // faʻataʻitaʻia faʻapitoa le ZST, o lona uiga-aua neʻi e tagoina.
            return (self, &[], &[]);
        }

        // Muamua, saili i le a le taimi tatou te vaeluaina ai i le va o le muamua ma le 2 fasi.
        // Faigofie ile ptr.align_offset.
        let ptr = self.as_ptr();
        // SAFETI: Vaʻai i le `align_to_mut` metotia mo le auiliiliga o le saogalemu tala.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // SAFETY: o lenei `rest` ua mautinoa lava gatasi, o lea `from_raw_parts` i lalo e lelei,
            // talu ai o le tagata na valaʻau mai le faʻamaoniga e mafai ona matou faʻasalalau saogalemu le `T` i le `U`.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Transmute le fasi i se fasi o se isi ituaiga, faamautinoaina o aafia i lenei suiga o le ituaiga o loo tausia.
    ///
    /// Lenei metotia vaeluaina le fasi i ni eseese eseʻese tolu: nauna, saʻo faʻatulagaina ogatotonu fasi o se fou ituaiga, ma le faʻavaega fasi.
    /// O le auala e mafai ona faia le fasi ogatotonu o le umi sili mafai e se tuuina ituaiga ma fasi sao, ae na tatau ona faalagolago faatinoga o galuega a lou algorithm i lena, ae le o lona saʻo.
    ///
    /// E faʻatagaina mo faʻamatalaga uma na faʻaulufaleina ina ia toe faʻafoʻi mai e avea ma se nauna poʻo seisi faʻailoga.
    ///
    /// O lenei metotia e leai se mafuaʻaga pe a le o le elemeni faʻaulu `T` poʻo le elemeni o loʻo i ai `U` e leai se tele ma o le a toe faʻafoʻi le uluaʻi fasi e aunoa ma le vaeluaina o se mea.
    ///
    /// # Safety
    ///
    /// O lenei metotia e taua lava o le `transmute` e tusa ai ma elemeni i le toe ogatotonu fasi, o lea o masani masani ai faʻatalanoaga e faatatau i le `transmute::<T, U>` faʻapena foʻi iinei.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Manatua o le tele o lenei gaioiga o le a faia pea-iloiloina,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // faʻataʻitaʻia faʻapitoa le ZST, o lona uiga-aua neʻi e tagoina.
            return (self, &mut [], &mut []);
        }

        // Muamua, saili i le a le taimi tatou te vaeluaina ai i le va o le muamua ma le 2 fasi.
        // Faigofie ile ptr.align_offset.
        let ptr = self.as_ptr();
        // SAFETI: Lenei matou te mautinoa o le a matou faʻaaogaina faʻailoga talafeagai mo U mo le
        // totoe o le metotia.E faia lea i le faʻasolo atu o le faʻasino i le [T] ma se laina tuʻufaʻatasia mo U.
        // `crate::ptr::align_offset` ua taʻua i se saʻo ogatusa ma aloaia e faasino `ptr` (a oo mai se faasinomaga i `self`) ma se tele o se mana o le lua (talu ai e oo mai i le alignement mo U), le faamalieina o lona constraints saogalemu.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // E le mafai ona matou toe faʻaaogaina le `rest` pe a maeʻa lenei, o lona uiga e faʻaleaogaina lona igoa `mut_ptr`!SAFETY: vaʻai faʻamatalaga mo `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Siaki pe a fai o faʻavasega elemeni o lenei fasi.
    ///
    /// O lona uiga, mo elemeni taʻitasi `a` ma lona elemeni o loʻo mulimuli mai `b`, `a <= b` tatau ona taofia.Afai o le fasi fua maua fua saʻo poʻo le tasi elemeni, `true` ua toe faʻafoʻi mai.
    ///
    /// Manatua afai `Self::Item` ua na `PartialOrd`, ae le `Ord`, o le faamatalaga i luga aʻe o lona uiga e toe foi lenei galuega tauave `false` pe afai o so o se mea e sosoo e lua e le tutusa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Siaki pe afai o elemeni o lenei fasi ua faʻavasegaina faʻaaogaina ai le tuʻufaʻatasiga faʻatatau galuega.
    ///
    /// Nai lo le faʻaaogaina o le `PartialOrd::partial_cmp`, o lenei gaioiga e faʻaaogaina ai le `compare` galuega e tuʻuina atu e fuafua ai le okaina o elemeni e lua.
    /// E ese mai lena, e le tutusa ma [`is_sorted`];iloa atu ona pepa mo nisi faamatalaga.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Siaki pe afai o elemeni o lenei fasi ua faʻavasegaina faʻaaogaina ai le faʻatagaina ki aveʻeseina galuega.
    ///
    /// Nai lo le faʻatusatusaina saʻo o elemeni o le fasi, o lenei gaioiga faʻatusatusa i ki o elemeni, e pei ona fuafuaina e `f`.
    /// E ese mai lena, e le tutusa ma [`is_sorted`];iloa atu ona pepa mo nisi faamatalaga.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Faʻafoʻi mai le faasino upu o le vaevaega faʻavae e tusa ma le tuʻufaʻatasiga tuʻuina atu (o le faʻasino igoa o le muamua elemeni o le vaega lona lua).
    ///
    /// O le fasi ua manatu e vaeluaina e tusa ai ma le predicate.
    /// O lona uiga o elemene uma e toe foʻi ai le faʻamaoniga moni o loʻo i le amataga o le fasi ma elemene uma na toe faʻafoʻi mai ai e le predicate le iuga.
    ///
    /// Mo se faʻataʻitaʻiga, [7, 15, 3, 5, 4, 12, 6] o se vaeluaina i lalo o le faʻamaoniga x% 2!=0 (o numera eseese uma o loʻo i le amataga, e oʻo lava i le iʻuga).
    ///
    /// Afai e le vaeluaina lenei fasi, o le iʻuga na toe foʻi mai e leʻo faʻamatalaina ma leai se uiga, ona o lenei metotia faia se ituaiga o binary saili.
    ///
    /// Tagai foi [`binary_search`], [`binary_search_by`], ma [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // SAFETI: A `left < right`, `left <= mid < right`.
            // Lea e faateleina ai pea `left` ma faaitiitia pea `right`, ma o se tasi o i latou ua filifilia.I itu uma e lua `left <= right` ua faʻamalieina.O le mea lea afai `left < right` i se sitepu, `left <= right` ua faʻamalieina i le isi sitepu.
            //
            // O le mea lea afai lava `left != right`, `0 <= left < right <= len` ua faʻamalieina ma afai o lenei tulaga `0 <= mid < len` ua faʻamalieina foi.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: E manaʻomia e tatou ona vaʻaia faʻasolosolo ona vaeluaina i latou ile tutusa tutusa
        // ia faʻafaigofie ai mo le tagata faʻalelei ona mimilo tuaʻoi siaki.
        // Ae talu ai e le mafai ona faalagolago i tatou foi se specialization manino mo T: Kopi.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Fausia se fasi avanoa.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Fausia se mutia gaogao fasi.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Mamanu i fasi, i le taimi nei, na faʻaaogaina e `strip_prefix` ma `strip_suffix`.
/// I se tulaga future, tatou te faamoemoe e generalize `core::str::Pattern` (lea i le taimi o tusitusiga e gata lava i `str`) e fasi, ma o le a suia lenei trait pe soloia.
///
pub trait SlicePattern {
    /// Le elemeni elemeni o le fasi e fetaui i luga.
    type Item;

    /// O le taimi nei, o le tagata faatau o `SlicePattern` manaomia se fasi.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}