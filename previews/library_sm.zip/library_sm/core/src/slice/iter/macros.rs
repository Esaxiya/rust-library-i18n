//! Macros faʻaaogaina e iterators o fasi.

// Inlining is_empty ma Len faia se eseesega faatinoga tele
macro_rules! is_empty {
    // Le auala matou te faʻavasegaina ai le umi o le ZST iterator, e aoga uma mo le ZST ma le le ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Ina ia aveʻesea ni tuaoi tuaʻoi (vaʻai `position`), matou te fuafuaina le umi i se auala e leʻi mafaufauina.
// (Tofotofoina e le 'codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // o nisi taimi tatou te faʻaaogaina ai i totonu o se poloka le saogalemu

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Lenei _cannot_ faʻaaoga `unchecked_sub` aua matou te faʻamoemoe i le afifiina e fai ma sui o le umi o le umi ZST fasi fagu.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Matou te iloa o le `start <= end`, o lea e mafai ai ona sili atu nai lo `offset_from`, lea e manaʻomia le feutanaʻi i totonu ua sainia.
            // E ala i le talafeagai fuʻa iinei e mafai ona tatou taʻu atu LLVM lenei, lea e fesoasoani ai aveesea siaki tuaoi.
            // SAFETY: E le ituaiga invariant, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // I le faʻamatalaina foʻi ia LLVM o faʻailoga e vavaeʻese e le aofaʻi tonu o le ituaiga tele, e mafai ona faʻaaoga le `len() == 0` i lalo i le `start == end` ae le o le `(end - start) < size`.
            //
            // SAFETY: E ala i le ituaiga invariant, o le faʻailoga e ogatusa ma le
            //         mamao i le va o latou tatau ona o se tele o pointee tele
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// O le faʻasoa faʻamatalaga o le `Iter` ma le `IterMut` faʻamaufaʻailoga
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Faʻafoʻi le muamua elemeni ma faʻasolosolo le amataga o le iterator agai i luma e le 1.
        // Faʻaleleia atili le faʻatinoga pe a faʻatusatusa i se laina galue.
        // E le tatau ona gaogao le faʻailo.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Faʻafoʻi le elemene mulimuli ma faʻaseʻe i tua le iuga o le iterator e le 1.
        // Faʻaleleia atili le faʻatinoga pe a faʻatusatusa i se laina galue.
        // E le tatau ona gaogao le faʻailo.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Faalotovaivaia le iterator pe T a ZST, e ala i le agai i le faaiuga o le iterator tua e `n`.
        // `n` le tatau ona sili atu ile `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Fesoasoani fesoasoani mo le fausiaina o se fasi vaega mai le faʻapipiʻiina.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // SAFETY: o le iterator na faia mai se fasi ma faʻasino tusi
                // `self.ptr` ma le umi `len!(self)`.
                // Lenei mautinoa ai o mea uma e manaʻomia muamua mo `from_raw_parts` ua faʻataunuuina.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Fesoasoani fesoasoani mo le siitia o le amataga o le iterator agai i luma e `offset` elemene, toe faafoi le tuai amataga.
            //
            // Le saogalemu aua o le offset e le tatau ona sili atu ile `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // SAFETY: o le tagata telefoni mai e faʻamaonia o `offset` e le sili atu i le `self.len()`,
                    // lea o loo i totonu o lenei e faasino fou `self` ma faapea ona faamaonia e lē soloia.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Fesoasoani fesoasoani mo le minoi o le pito o le iterator i tua e `offset` elemene, toe faafoi le fou fou.
            //
            // Le saogalemu aua o le offset e le tatau ona sili atu ile `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // SAFETY: o le tagata telefoni mai e faʻamaonia o `offset` e le sili atu i le `self.len()`,
                    // lea e mautinoa e le ova ova ma `isize`.
                    // E le gata i lea, o le iʻuga o le faʻasino tusi o loʻo i tuaoi o `slice`, lea faʻataunuʻuina isi manaoga mo `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // mafai ona faʻatinoina ma fasi, ae o lenei e 'alo ese mai tuaoi siaki

                // SAFETY: `assume` valaʻau e sefe talu mai le fasi 'oti amata faʻasino tusi
                // tatau ona leai se aoga, ma o fasi i luga atu o non-ZSTs e tatau foi ona i ai se non-null end point.
                // O le valaʻau i le `next_unchecked!` e sefe talu ai matou te siakiina pe o le faʻamauga e gaogao muamua.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // O lenei faʻatonutonu ua avanoa nei.
                    if mem::size_of::<T>() == 0 {
                        // E tatau ona tatou faia i lenei auala `ptr` atonu e leʻo 0, ae o `end` mafai (ona o le afifi).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // SAFETY: e le mafai ona 0 pe a le o T o le ZST aua o le ptr e le 0 ma le iʻuga>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // SAUNIGA: O loo matou i tuaoi.`post_inc_start` faia le mea saʻo e oʻo lava i ZSTs.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Matou te faʻaleaogaina le faʻaogaina le aoga, lea e faʻaaoga ai le `try_fold`, aua o lenei faʻataʻitaʻiga faigofie e faʻaitiitia ai LLVM IR ma e vave tele ona tuʻufaʻatasia.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Matou te faʻaleaogaina le faʻaogaina le aoga, lea e faʻaaoga ai le `try_fold`, aua o lenei faʻataʻitaʻiga faigofie e faʻaitiitia ai LLVM IR ma e vave tele ona tuʻufaʻatasia.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Matou te faʻaleaogaina le faʻaogaina le aoga, lea e faʻaaoga ai le `try_fold`, aua o lenei faʻataʻitaʻiga faigofie e faʻaitiitia ai LLVM IR ma e vave tele ona tuʻufaʻatasia.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Matou te faʻaleaogaina le faʻaogaina le aoga, lea e faʻaaoga ai le `try_fold`, aua o lenei faʻataʻitaʻiga faigofie e faʻaitiitia ai LLVM IR ma e vave tele ona tuʻufaʻatasia.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Matou te faʻaleaogaina le faʻaogaina le aoga, lea e faʻaaoga ai le `try_fold`, aua o lenei faʻataʻitaʻiga faigofie e faʻaitiitia ai LLVM IR ma e vave tele ona tuʻufaʻatasia.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Matou te faʻaleaogaina le faʻaogaina le aoga, lea e faʻaaoga ai le `try_fold`, aua o lenei faʻataʻitaʻiga faigofie e faʻaitiitia ai LLVM IR ma e vave tele ona tuʻufaʻatasia.
            // Faʻapea foi, le `assume` aloese mai le siaki tuaʻoi.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // SAOGALEMU: tatou mautinoa i ai i tuaoi e le matasele invariant:
                        // a `i >= n`, `self.next()` faʻafoʻi `None` ma malepe le matasele.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Matou te faʻaleaogaina le faʻaogaina le aoga, lea e faʻaaoga ai le `try_fold`, aua o lenei faʻataʻitaʻiga faigofie e faʻaitiitia ai LLVM IR ma e vave tele ona tuʻufaʻatasia.
            // Faʻapea foi, le `assume` aloese mai le siaki tuaʻoi.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // SAFETY: `i` tatau ona maualalo ifo nai lo `n` talu ona amata ile `n`
                        // ma ua na faaitiitia.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // SAOGALEMU: o le faamaoniga e tatau Tagata telefoni e `i` i tuaoi o
                // o le vaega autu, o lea e le mafai ai e `i` ona ova i le `isize`, ma o faʻamatalaga ua toe foʻi mai e mautinoa e faʻasino i se elemeni o le fasi ma faʻamaonia ai e aoga.
                //
                // Foi faamaonia foi ona e maitauina o le telefoni o loo tatou lava toe valaau i le faasino upu e tasi, ma e leai se isi auala o le a maua lenei subslice ua valaauina, o lea e aoga mo le faamatalaga toe foi i ona mutable i le tulaga o
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // mafai ona faʻatinoina ma fasi, ae o lenei e 'alo ese mai tuaoi siaki

                // SAFETY: `assume` valaʻau e sefe talu ai o le fasi faʻatatau o le faʻailoga tatau ona leai-leai,
                // ma o fasi pepa i luga atu o mea e le o ni ZST e tatau foi ona i ai se faʻailoga e leai se iʻu.
                // O le valaʻau i le `next_back_unchecked!` e sefe talu ai matou te siakiina pe o le faʻamauga e gaogao muamua.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // O lenei faʻatonutonu ua avanoa nei.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // SAOGALEMU: tatou i ai i tuaoi.`pre_dec_end` faia le mea saʻo e oʻo lava i ZSTs.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}