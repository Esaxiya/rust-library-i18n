//! fasi sailiili
//!
//! Lenei module aofia ai se faʻavasega algorithm faʻavae i luga o Orson Peters 'mamanu-faʻatoʻilaloina quicksort, lomia i le: <https://github.com/orlp/pdqsort>
//!
//!
//! e sailiili mautu talafeagai ma libcore ona e le faasoasoa manatua, e le pei o lo tatou fale o manu faatinoga sailiili.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// A pa'ū, kopi mai `src` i le `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // SAFETI: O se vasega fesoasoani lenei.
        //          Faʻamolemole vaʻai i lona faʻaaogaina mo le saʻo.
        //          I se isi itu, e tatau i se tasi ona mautinoa o le `src` ma le `dst` e le oʻo mai e pei ona manaʻomia e `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Sue le muamua elemeni i le taumatau seʻia oʻo ina fetaiaʻi ma se sili atu pe tutusa elemeni.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SAFETY: O le le saogalemu gaioiga i lalo aofia ai le faasino igoa e aunoa ma se noataga siaki (`get_unchecked` ma `get_unchecked_mut`)
    // ma kopiina le manatuaina (`ptr::copy_nonoverlapping`).
    //
    // a.Faasino igoa:
    //  1. Tatou siaki le tele o le autau e>=2.
    //  2. Uma le faasino igoa o le a tatou faia o taimi uma i le va {0 <= index < len} sili.
    //
    // b.ata manatua
    //  1. O loʻo matou mauaina faʻasino tusi e faʻamaonia e aoga.
    //  2. e le mafai ona latou fesiliaʻi ona tatou maua vae i eseesega indices o le fasi.
    //     O lona uiga, `i` ma `i-1`.
    //  3. Afai e fetaui lelei le fasi fasi, o elemeni e faʻasaʻo lelei.
    //     O le matafaioi a le Tagata telefoni mai ina ia mautinoa o loo ogatasi lelei le fasi.
    //
    // Vaʻai manatu i lalo ifo mo nisi faʻamatalaga.
    unsafe {
        // Afai o le muamua elemene elemeni mai-o-faasologa ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Faitau le muamua elemeni i totonu o se faaputuga-vaʻai fesuiaʻi.
            // Afai o se gaoioiga faatusatusaga nei panics, o le a maua le faapau `hole` ma tusi otometi tua elemene i totonu o le fasi.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Faʻasolo le 'i'-th elemeni i le tasi nofoaga i le agavale, ma faʻapea ona suia le pu i le taumatau.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` paʻu ifo ma kopi le `tmp` i le pu o loʻo totoe ile `v`.
        }
    }
}

/// Suiga o le elemene mulimuli i le itu tauagavale seia oo ina fetaiai se elemene laiti po o le tutusa.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SAFETY: O le le saogalemu gaioiga i lalo aofia ai le faasino igoa e aunoa ma se noataga siaki (`get_unchecked` ma `get_unchecked_mut`)
    // ma kopiina le manatuaina (`ptr::copy_nonoverlapping`).
    //
    // a.Faasino igoa:
    //  1. Na matou siakiina le tele o le faʻasologa i>=2.
    //  2. Uma o le faasino igoa o le a tatou faia pea lava pea i le va o `0 <= index < len-1` i sili ona taua.
    //
    // b.ata manatua
    //  1. O loʻo matou mauaina faʻasino tusi e faʻamaonia e aoga.
    //  2. e le mafai ona latou fesiliaʻi ona tatou maua vae i eseesega indices o le fasi.
    //     O lona uiga, `i` ma `i+1`.
    //  3. Afai e fetaui lelei le fasi fasi, o elemeni e faʻasaʻo lelei.
    //     O le matafaioi a le Tagata telefoni mai ina ia mautinoa o loo ogatasi lelei le fasi.
    //
    // Vaʻai manatu i lalo ifo mo nisi faʻamatalaga.
    unsafe {
        // Afai o elemene mulimuli e lua o le-o-faʻatonuga ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Faitau le elemene mulimuli i totonu o se faʻavasega-faʻavasega suiga.
            // Afai o se gaoioiga faatusatusaga nei panics, o le a maua le faapau `hole` ma tusi otometi tua elemene i totonu o le fasi.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Faʻasolo le 'i'-th elemeni i le tasi nofoaga i le taumatau, ma faʻapea ona sui le pu i le agavale.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` paʻu ifo ma kopi le `tmp` i le pu o loʻo totoe ile `v`.
        }
    }
}

/// Vaega eseese se fasi i le suiga tele o fafo atu o le poloaiga elemene o loo siomia ai.
///
/// Faʻafoʻi `true` peʻa faʻavasega le fasi i le iʻuga.Lenei galuega tauave o le *O*(*n*) sili ona leaga-tulaga.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Ole aofaʻi maualuga o paga sosoʻo mai fafo o faʻasologa o le a sifi.
    const MAX_STEPS: usize = 5;
    // Afai o le fasi e puʻupuʻu nai lo lenei, aua le suia soʻo se elemeni.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // SAOGALEMU: tatou uma ona faia manino le siakiina noanoatia `i < len`.
        // O a matou faʻavasegaina mulimuli ane ua naʻo le `0 <= index < len` avanoa
        unsafe {
            // Saili pea e sosoo ai o sosoo mai-o-ina elemene.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Ua tatou faia?
        if i == len {
            return true;
        }

        // Aua le sui elemene i arrays puupuu, ua a tau faatinoga o.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Faʻafesuiaʻi le pea maua o elemene.O lenei tuʻu i latou i le faʻasologa saʻo.
        v.swap(i - 1, i);

        // Sifi le vaega laiti i le agavale.
        shift_tail(&mut v[..i], is_less);
        // Sui le elemene e sili atu i le itu taumatau.
        shift_head(&mut v[i..], is_less);
    }

    // Le mafai ona faʻavasega le fasi i le faʻatapulaʻa numera o sitepu.
    false
}

/// Faʻavasega se fasi fasi faʻaʻeseʻesega, o le *O*(*n*^ 2) sili ona leaga.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Ituaiga `v` faaaogaina heapsort, lea e faamaonia *Le*(*n*\*log(* n*)) sili ona leaga-tulaga.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // O lenei faʻaupuga binary e faʻaaloalo i le tagata le gaoia `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Tamaiti a `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Filifili le sili atu tamaititi.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Taofi pe afai o le invariant taofi i le `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Faʻafesuiaʻi `node` ma le tamaititi sili atu, minoi le tasi sitepu i lalo, ma faʻaauau pea le faʻavasega.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Fausia le faupuega i le taimi linear.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Oso elemene maximal mai le faupuega.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Vasega `v` i elemeni laititi atu nai lo `pivot`, mulimuli ai elemeni sili atu pe tutusa i le `pivot`.
///
///
/// Toe foi le aofai o vaega laiti nai lo `pivot`.
///
/// Faʻavasegaina e faia poloka-i-poloka ina ia mafai ona faʻaititia le tau o paranesi faʻagaioiga.
/// O lenei manatu o loʻo faʻaalia i le [BlockQuicksort][pdf] pepa.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Aofai o elemene i totonu o se poloka masani.
    const BLOCK: usize = 128;

    // O le algorithm partitioning toe laasaga nei seia maea:
    //
    // 1. Lolomi se poloka mai le itu tauagavale e faailoa mai elemene e sili atu po o le tutusa i le pivot.
    // 2. Lolomi se poloka mai le itu taumatau e faailoa elemene laiti nai lo le pivot.
    // 3. Fesuiai elemene iloa i le va o le agavale ma le itu taumatau.
    //
    // Tatou tausia le fesuiaiga nei mo se poloka o elemene:
    //
    // 1. `block` - Aofaʻi o elemeni i le poloka.
    // 2. `start` - Amata le faʻasino i le laina `offsets`.
    // 3. `end` - Faʻaiʻu le faʻasino i le laina `offsets`.
    // 4. 'offset, Indices o fafo-o-oka elemeni i totonu o le poloka.

    // O le poloka i le taimi nei i le itu tauagavale (mai `l` e `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // O le poloka i le taimi nei i le itu taumatau (mai `r.sub(block_r)` to `r`).
    // SAOGALEMU: O le pepa mo .add() taʻua patino e `vec.as_ptr().add(vec.len())` o safe` pea
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: A matou maua VLAs, taumafai e fatu se tasi faʻataʻitaʻiga o le umi `min(v.len(), 2 * BLOCK) `ae
    // sili atu i le lua faʻasologa-tele faʻasologa o le umi `BLOCK`.VLAs atonu e sili atu cache-lelei.

    // Faʻafoʻi mai le numera o elemeni i le va faʻasino `l` (inclusive) ma `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Ua uma ona tatou faia i le vaeluaina poloka-i-poloka pe a latalata `l` ma `r`.
        // Ona tatou faia nisi fono-i le galuega ina ia vaevaea o le elemene o totoe i le va.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Numera o totoe elemeni (e le faʻatusatusa i le mea taua).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Fetuunai lapoʻa poloka ina ia le felafolafoaʻi le itu agavale ma le taumatau, ae ia fetaui lelei e ufiufi ai le avanoa atoa o totoe.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Lolomi elemeni `block_l` mai le itu tauagavale.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // SAOGALEMU: O le gaoioiga unsafety i lalo e aofia ai le faaaogaina o le `offset`.
                //         E tusa ai ma tuutuuga manaʻomia e le gaioiga, matou faʻamalieina i latou ona:
                //         1. `offsets_l` ua faʻatuina-faʻasoaina, ma o lea ua manatu ese ai faʻasoasoa mea.
                //         2. O le galuega tauave toe foi `is_less` a `bool`.
                //            O le togiina o le `bool` o le a le oʻo lava i le `isize`.
                //         3. Ua matou mautinoa o le `block_l` o le `<= BLOCK`.
                //            Ma le isi, `end_l` na seti muamua i le amataga faʻasino o `offsets_` lea na folafolaina i luga o le faaputuga.
                //            O lea la, ua tatou iloa e oʻo lava i le mea e sili ona leaga (o faʻataʻitaʻiga uma a le `is_less` e faʻafoʻi mai le sese) e naʻo le 1 byte na pasi le iʻuga.
                //        O le isi gaioiga le saogalemu iinei o le faʻamamaina `elem`.
                //        Peitaʻi, o le `elem` o le amataga lava lea o le faʻasino tusi i le fasi e aoga pea.
                unsafe {
                    // Faʻatusatusaga leai paranesi.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Lolomi `block_r` elemeni mai le itu taumatau.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // SAOGALEMU: O le gaoioiga unsafety i lalo e aofia ai le faaaogaina o le `offset`.
                //         E tusa ai ma tuutuuga manaʻomia e le gaioiga, matou faʻamalieina i latou ona:
                //         1. `offsets_r` ua faʻatuina-faʻasoaina, ma o lea ua manatu ese ai faʻasoasoa mea.
                //         2. O le galuega tauave toe foi `is_less` a `bool`.
                //            O le togiina o le `bool` o le a le oʻo lava i le `isize`.
                //         3. Ua matou mautinoa o le `block_r` o le `<= BLOCK`.
                //            Ma le isi, `end_r` na seti muamua i le amataga faʻasino o `offsets_` lea na folafolaina i luga o le faaputuga.
                //            O lea, ua tatou iloa e oo lava i le tulaga sili ona leaga (toe foi invocations uma o `is_less` moni) o le a tatou na o ia i le tele 1 byte oo i le iuga.
                //        O le isi gaioiga le saogalemu iinei o le faʻamamaina `elem`.
                //        Ae peitai, `elem` na muamua `1 *sizeof(T)` ua mavae le iuga ma tatou decrement ai e `1* sizeof(T)` ao lei faaaogaina.
                //        Ma, `block_r` na faʻamaonia e sili atu nai lo `BLOCK` ma `elem` o le mea lea o le a sili ona tusi i le amataga o le fasi.
                unsafe {
                    // Faʻatusatusaga leai paranesi.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Numera o fafo-o-oka elemeni e fesuiaʻi i le va o le agavale ma le taumatau itu.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Nai lo le fesuiaʻi tasi pea paga i le taimi, e sili atu le lelei le faia o se cyclic permutation.
            // E le tutusa le tutusa ma le fesuiaʻiga, ae maua mai ai se tali tutusa faʻaaoga ai le laʻititi o mea e manatua.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Sa siitia uma i fafo-o-ina elemene i le poloka tuua.Alu i le isi poloka.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // O elemeni uma i fafo o le oka i le poloka taumatau na aveese.Agai atu i le poloka muamua.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // o le taimi nei e toega uma i sili ona tasi le poloka (pe le itu tauagavale po o le taumatau) i fafo atu o le poloaiga elemene e manaomia ona aveesea.
    // e mafai ona na siitia O elemene totoe i le iuga i totonu oo latou poloka.
    //

    if start_l < end_l {
        // O loʻo tumau pea le poloka tauagavale.
        // Faʻasolo atu ona vaega totoe i fafo atu o le faʻasologa i le itu taumatau taumatau.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // O le poloka taumatau tumau pea.
        // Faʻasese atu ana mea totoe i fafo atu o faʻasologa i le itu agavale tauagavale.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // E leai se isi mea e fai, ua uma.
        width(v.as_mut_ptr(), l)
    }
}

/// Vasega `v` i elemeni laititi atu nai lo `v[pivot]`, mulimuli ai elemeni sili atu pe tutusa i le `v[pivot]`.
///
///
/// Faʻafoʻi mai se tuple o:
///
/// 1. Aofai o elemene laiti nai lo `v[pivot]`.
/// 2. Moni pe a fai o `v` ua maeʻa vaeluaina.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Tuu le pivot i le amataga o fasi.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Faitau le mea taua i totonu o se faaputuga-vaʻai fetuutuunai mo le lelei atoatoa.
        // Afai o se gaoioiga faatusatusaga nei panics, o le a otometi lava ona tusia i tua le pivot i le fasi.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Saili le muamua paga o fafo-o-oka elemeni.
        let mut l = 0;
        let mut r = v.len();

        // SAOGALEMU: O le unsafety i lalo e aofia ai le faasino igoa se autau.
        // Mo le mea muamua: Ua uma ona matou faia tuaoi siaki iinei ma `l < r`.
        // Mo le lona lua: Na matou maua muamua `l == 0` ma `r == v.len()` ma matou siaki lena `l < r` i faʻatinoga uma o le faasino igoa.
        //                     Mai iinei tatou te iloa o le `r` tatau ona sili atu `r == l` lea na faʻaalia e aoga mai le muamua.
        unsafe {
            // Saili le sili elemene muamua nai lo le po o le tutusa i le pivot.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Saili laʻititi le elemeni mulimuli o le mea taua.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` alu i fafo atu o le tulaga ma tusi le mea taua (o se faaputuga-faʻasoasoa fesuiaʻi) toe foi i le fasi mea na i ai muamua.
        // O lenei sitepu e taua tele i le faʻamautinoaina le saogalemu!
        //
    };

    // Tuʻu le mea taua i le va o vaega e lua.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Vasega `v` i elemeni tutusa ma `v[pivot]` mulimuli ai elemeni sili atu nai lo `v[pivot]`.
///
/// Toe foi le aofai o elemene e tutusa i le pivot.
/// E iai le manatu ole `v` e leʻo iai ni elemeni laititi atu nai lo le mea taua.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Tuu le pivot i le amataga o fasi.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Faitau le mea taua i totonu o se faaputuga-vaʻai fetuutuunai mo le lelei atoatoa.
    // Afai o se gaoioiga faatusatusaga nei panics, o le a otometi lava ona tusia i tua le pivot i le fasi.
    // SAFETY: O le faʻasino tusi iinei e aoga aua na maua mai i se faʻasino i se fasi.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Vaelua nei le fasi.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // SAOGALEMU: O le unsafety i lalo e aofia ai le faasino igoa se autau.
        // Mo le mea muamua: Ua uma ona matou faia tuaoi siaki iinei ma `l < r`.
        // Mo le lona lua: Na matou maua muamua `l == 0` ma `r == v.len()` ma matou siaki lena `l < r` i faʻatinoga uma o le faasino igoa.
        //                     Mai iinei tatou te iloa o le `r` tatau ona sili atu `r == l` lea na faʻaalia e aoga mai le muamua.
        unsafe {
            // Saili le muamua elemeni sili atu nai lo le taua.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Saili le elemene mulimuli e tutusa ma le pivot.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Ua tatou faia?
            if l >= r {
                break;
            }

            // Faʻafesuiaʻi le pea maua o fafo-o-oka elemeni.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Tatou maua elemene `l` tutusa i le pivot.Faʻaopopo le 1 i le teuga tupe mo ia lava.
    l + 1

    // `_pivot_guard` alu i fafo atu o le tulaga ma tusi le mea taua (o se faaputuga-faʻasoasoa fesuiaʻi) toe foi i le fasi mea na i ai muamua.
    // O lenei sitepu e taua tele i le faʻamautinoaina le saogalemu!
}

/// Faasalalau nisi elemene faataamilo i se taumafaiga e gagau mamanu e ono mafua ai le paleni vaeluaina i quicksort.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Pseudorandom numera generator mai le pepa "Xorshift RNGs" e George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Ave fua numera numera modulo lenei numera.
        // O le numera e ofi i le `usize` aua o le `len` e le sili atu i le `isize::MAX`.
        let modulus = len.next_power_of_two();

        // O nisi sui tauva taua o le ai ai latalata i lenei faasino igoa.Seʻi o tatou faataʻitaʻia i latou.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Ia faatupuina se numera soo modulo `len`.
            // Ae peitai, ina ia aloese mai le taugata gaoioiga tatou muamua ave modulo a mana o le lua, ona faaitiitia e `len` seia oo ina fetaui lelei i le tele `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` ua faamaonia e itiiti ifo nai lo `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Filifili se mea taua i le `v` ma toe faafoi le faasino igoa ma le `true` pe a fai o le fasi e foliga mai ua uma ona faʻavasega.
///
/// Elemene i `v` ono toe faʻaleleia i le gaioiga.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Maualalo le umi e filifili ai le median-of-medians metotia.
    // fasi puupuu faaaogaina le faigofie median-o-tolu auala.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Tapulaʻa maualuga numera o swaps e mafai ona faia i lenei gaioiga.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Tolu faʻasino tusi lata mai o le a matou filifilia ai se mea taua.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Faitau le aofaʻi atoa o swaps o le a tatou faia a o faʻavasega faʻavasega.
    let mut swaps = 0;

    if len >= 8 {
        // ina ia `v[a] <= v[b]` indices Swaps.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Faʻafesuiaʻi faʻailoga ina ia `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Maua le median o `v[a - 1], v[a], v[a + 1]` ma teu le faʻasino i le `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Saili ni faʻataʻitaʻiga i le pitonuu o `a`, `b`, ma le `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Saili le median i le `a`, `b`, ma le `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // O le aofaʻi maualuga o swaps na faʻatinoina.
        // Avanoa o le fasi ua paʻu ifo pe tele ifo ifo i lalo, o lea feliuaʻi atonu o le a fesoasoani faʻavasega ia vave.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Ituaiga `v` toe faʻasolosolo.
///
/// Afai o le fasi sa a muamua i le autau muamua, ua faamaoti mai e pei `pred`.
///
/// `limit` o le numera o faʻatagaina le paleni faʻavasegaina vaega ae leʻi fesuiaʻi i `heapsort`.
/// Afai o, o le a vave fesuiaʻi lenei galuega tauave e heapsort.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Fasi i lenei Mauaina umi faavasega le faaaogaina o ituaiga faaofiina.
    const MAX_INSERTION: usize = 20;

    // Moni pe afai e talafeagai e faapaleni le partitioning mulimuli.
    let mut was_balanced = true;
    // Moni pe afai e le shuffle le partitioning mulimuli elemene (ua uma ona partitioned le fasi).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // ona faavasega fasi matua puupuu lava le faaaogaina o ituaiga faaofiina.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Afai e tele naua filifiliga le lelei na faia, na o le toe foʻi i tua i se faaputuga ina ia mautinoa `O(n * log(n))` sili ona leaga-tulaga.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Afai na imbalanced le partitioning mulimuli, taumafai le solia o mamanu i le fasi e shuffling nisi elemene o loo siomia ai.
        // Talosia o le a tatou filifilia se sili atu taua i lenei taimi.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Filifili se mea taua ma taumafai e mate pe o le fasi ua maeʻa faʻavasega.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Afai o le vaeluaina mulimuli na paleni paleni ma e leʻi fesuiaʻi elemeni, ma afai filifilia faʻavasega filifiliga o le fasi atonu ua uma ona faʻavasega ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Taumafai e faʻailoa mai ni elemeni e le o faʻasologa lelei ma sui e faʻasaʻo tulaga.
            // Afai o le fasi fasi iʻuga uma ua maeʻa faʻavasegaina, ua uma ona tatou.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Afai o le filifiliga filifilia e tutusa ma le muamua, o lona uiga o le laʻititi elemeni i le fasi.
        // Vavae le fasi i elemeni tutusa ma elemene sili atu nai lo le taua.
        // O lenei tulaga e masani lava ona lavea ina ua fasi o loo i ai le tele o elemene lona lua.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Faʻaauau le faʻavasega elemene sili atu nai lo le taua.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Faʻavasega le fasi.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Vaeluaina le fasi i `left`, `pivot`, ma `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Recurse i le itu puupuu na ina ia faaitiitia ai le aofaiga o valaauga recursive ma faaumatia itiiti avanoa faaputuga.
        // Ona na ona faʻaauau pea ma le itu uumi (o lenei e pei o le siʻusiʻu recursion).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Ituaiga `v` faʻaaogaina le mamanu-faʻatoʻilaloina quicksort, o le *O*(*n*\*log(* n*)) sili ona leaga-tulaga.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // O le faʻavasegaina e leai se uiga taua i luga o zero-tele ituaiga.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Faʻatapulaʻa le numera o faʻapaleni paleni i le `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Mo fasi e oʻo atu i lenei umi atonu e sili atu le vave naʻo le faʻavasegaina.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Filifili se mea taua
        let (pivot, _) = choose_pivot(v, is_less);

        // Afai o le filifiliga filifilia e tutusa ma le muamua, o lona uiga o le laʻititi elemeni i le fasi.
        // Vavae le fasi i elemeni tutusa ma elemene sili atu nai lo le taua.
        // O lenei tulaga e masani lava ona lavea ina ua fasi o loo i ai le tele o elemene lona lua.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Afai tatou te pasia tatou faasino upu, ona tatou te lelei.
                if mid > index {
                    return;
                }

                // A leai, faʻaauau pea le faʻavasega elemene sili atu nai lo le taua.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Vaeluaina le fasi i `left`, `pivot`, ma `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Afai o le ogatotonu==faʻasino, ona maeʻa lea o tatou, talu mai partition() mautinoa o elemeni uma i tua atu o le ogatotonu e sili atu nai lo pe tutusa ma le ogatotonu.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // O le faʻavasegaina e leai se uiga taua i luga o zero-tele ituaiga.Aua le faia se mea.
    } else if index == v.len() - 1 {
        // Saili le elemeni maualuga ma tuʻu i le tulaga mulimuli o le laina.
        // Ua matou saoloto e faʻaaoga le `unwrap()` ii aua ua matou iloa e le tatau ona gaogao le v.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Saili min elemeni ma tuʻu i le tulaga muamua o le faʻavasega.
        // Ua matou saoloto e faʻaaoga le `unwrap()` ii aua ua matou iloa e le tatau ona gaogao le v.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}