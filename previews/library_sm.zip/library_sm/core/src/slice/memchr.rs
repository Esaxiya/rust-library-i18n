// Uluaʻi faʻatinoga na aumai mai le rust-memchr.
// Pule Tau Fatuga 2015 Andrew Gallant, bluss ma Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Faʻaaoga le teuteuga.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Faʻafoʻi `true` pe a fai `x` o loʻo iai ni zero byte.
///
/// Mai *Mataupu Computational*, J. Arndt:
///
/// "O le auga o le toʻese mai le tasi mai le tasi byte ona vaʻai lea mo byte na faʻalauteleina ai le nonogatupe i le sili atu taua
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Faʻafoʻi mai le faʻasino muamua e tutusa ma le byte `x` ile `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // ala Anapogi mo fasi laiti
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Scan mo se tasi byte aoga i le faitauina o lua `usize` upu i le taimi.
    //
    // Vavae `text` i ni vaega se tolu
    // - unaligned amataga vaega, i luma o le muamua upu faʻafetaui tuatusi i tusitusiga
    // - tino, siaki i le 2 upu i le taimi
    // - le vaega totoe ai, <2 afioga tele

    // saili e oʻo atu i se tuaoi tuaoi
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // saili le tino o le anotusi
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // SAOGALEMU: faamaonia a predicate le ao se mamao e le itiiti ifo i le 2 * usize_bytes
        // i le va o le offset ma le faaiuga o le fasi.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // malepe pe a fai e iai se fetaui lelei
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Saili le byte i le maeʻa ai o le taimi na taofi ai le faʻataʻavale o le tino.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Faʻafoʻi mai le faʻasino mulimuli e fetaui ma le paita `x` ile `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Scan mo se tasi byte aoga i le faitauina o lua `usize` upu i le taimi.
    //
    // Vavae `text` i ni vaega se tolu:
    // - le faʻafetaui siʻusiʻu, pe a maeʻa le mulimuli upu faʻafetaui tuatusi i tusitusiga,
    // - tino, siaki e 2 upu i le taimi,
    // - le muamua totoe bytes, <2 upu tele.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Matou te valaʻau lenei na o le mauaina o le umi o le nauna ma faʻauʻu.
        // I le ogatotonu matou te masani ona faʻagasolo taimi e lua i le taimi e tasi.
        // SAFETY: lafoina `[u8]` i `[usize]` e saogalemu seʻi vagana ai mo le tele eseesega o loʻo faʻatautaia e `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Suʻe le tino o le tusitusiga, ia mautinoa matou te le sopoia min_aligned_offset.
    // offset e masani ona ogatusa, o lea naʻo le tofotofoina `>` ua lava ma aloese mai le mafai ova.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // SAFETY: offset amata i le len, suffix.len(), pe afai e sili atu nai lo
        // min_aligned_offset (prefix.len()) o le mamao o loʻo totoe a itiiti mai 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Malepe pe a fai e iai se paita tutusa.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Saili le byte i luma o le tulaga tu le matasele tino.
    text[..offset].iter().rposition(|elt| *elt == x)
}