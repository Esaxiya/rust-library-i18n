#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! Mea faigaluega e fesoʻotaʻi ma galuega faʻatino i fafo atu (FFI) bindings.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// Tutusa ituaiga `void` a C pe a faaaogaina o se [pointer].
///
/// O le mea moni, `*const c_void` e tutusa a `const void*` C ma `*mut c_void` e tutusa `void*` a C.
/// Fai mai, e le tutusa lenei * ma le C's `void` toe foʻi ituaiga, o le Rust's `()` ituaiga.
///
/// Mo faʻataʻitaʻiga faʻasino i ituaiga opaque i le FFI, seʻia oʻo i le `extern type` ua mautu, ua fautuaina e faʻaaoga se afifi newtype e faʻataʻamilomilo i se laina avanoa.
///
/// Tagai i le [Nomicon] mo faamatalaga auiliili.
///
/// E mafai e se tasi ona faʻaaoga le `std::os::raw::c_void` pe a latou mananaʻo e lagolago le tuʻufaʻatasiga tuai o le Rust i lalo i le 1.1.0.
/// Ina ua mavae Rust 1.30.0, na toe auina atu i fafo e lenei faamatalaga.
/// Mo nisi faamatalaga, faamolemole faitau [RFC 2521].
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB, mo LLVM ia amanaʻia le leai o se ituaiga faʻailoga ma e faʻalauteleina galuega pei o malloc(), tatou manaʻomia le avea ma sui o i8 * i le LLVM bitcode.
// O le enum faaaogaina iinei mautinoa lenei ma faaaoga sese e taofia ai o le ituaiga "raw" e na o le mauaina o variants tumaoti.
// Matou te manaʻomia ni lua fesuiaʻiga, aua e faitio le tagata tuʻufaʻatasia e uiga i le repr uiga ese ma tatou manaʻomia le sili atu tasi fesuiaʻiga a leai o le a le nofoia le enum ma a itiiti mai dereferencing ia faʻailo o le UB.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// faatinoga Autu o le a `va_list`.
// O le igoa o le WIP, faʻaaoga `VaListImpl` mo le taimi nei.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // Invariant i `'f`, ina ua nonoa mea `VaListImpl<'f>` taitasi e le itulagi o le galuega o loo faamatalaina i totonu o
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 ABI faatinoga o se `va_list`.
/// Vaʻai le [AArch64 Procedure Call Standard] mo nisi faʻamatalaga.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC ABI faatinoga o se `va_list`.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 ABI faatinoga o se `va_list`.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// Se afifi mo le `va_list`
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Faʻaliliu se `VaListImpl` i totonu o le `VaList` e mimita-fetaui ma C's `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Faʻaliliu se `VaListImpl` i totonu o le `VaList` e mimita-fetaui ma C's `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// e tatau ona faaaogaina le VaArgSafe trait i interfaces tagata lautele, ae peitai, o le trait lava ia e tatau ona faatagaina ina ia faaaogā i fafo lenei module.
// Faʻatagaina tagata faʻaoga e faʻatino le trait mo se ituaiga fou (faʻatagaina le va_arg intrinsic e faʻaaogaina luga o se ituaiga fou) e ono mafua ai amioga le faʻamatalaina.
//
// FIXME(dlrobertson): Ina ia faaaoga le VaArgSafe trait i se Ofisa o le Malo ae faapea foi le mautinoa e mafai ona faaaogaina o se isi nofoaga, o le manaomia trait i le lautele i totonu o se module tumaoti.
// Faʻatasi RFC 2145 ua faatinoina vaai i le faaleleia o lenei.
//
//
//
//
mod sealed_trait {
    /// Trait o loʻo faʻatagaina ai le faʻatagaina ona faʻaaogaina ma [super::VaListImpl::arg].
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Alualu i luma i le isi fin.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `va_arg`.
        unsafe { va_arg(self) }
    }

    /// Kopi le `va_list` ile nofoaga nei.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // SAOGALEMU: e tatau ona lagolagoina le Tagata telefoni mai le konekarate saogalemu mo `va_end`.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // SAFETY: matou tusi i le `MaybeUninit`, ma o lea ua amataina ma `assume_init` e faʻatulafono
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: o lenei e tatau ona valaʻau i le `va_end`, ae leai se auala mama e
        // e faamautinoa mai ai e oo atu i taimi uma `drop` inlined i lona Tagata telefoni, ina ia maua tonu taʻua o le `va_end` mai le galuega lava lea e tasi e pei o le `va_copy` tutusa.
        // `man va_end` o loʻo taua e manaʻomia e C le mea lea, ma o le LLVM e mulimulitaʻi i le C semantics, o lea e tatau ai ona tatou mautinoa o `va_end` e masani ona valaʻauina mai le galuega e tasi e pei o le `va_copy`.
        //
        // Mo nisi faamatalaga, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // O lenei galuega mo le taimi nei, talu `va_end` ua leai se-op i uma sini nei LLVM.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// Lepeti le arglist `ap` ina ua uma initialization ma `va_start` po `va_copy`.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// Kopi le nofoaga oi ai nei o arglist `src` i le arglist `dst`.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// Avega se finauga o ituaiga `T` mai le `va_list` `ap` ma increment le finauga manatu `ap` i ai.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}