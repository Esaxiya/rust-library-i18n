//! Panic lagolago mo libcore
//!
//! O le faletusi autu e le mafai ona faʻamatalaina le fefevale, ae e *faʻailoa* faʻafuaseʻi.
//! O lona uiga o gaioiga i totonu o le libcore e faʻatagaina i le panic, ae ia aoga le crate i luga e tatau ona faʻauigaina le faʻafaigofieina ona faʻaaoga le libcore.
//! Le Ofisa o loo i ai nei mo panicking o le:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Lenei faʻauiga faʻatagaina mo panicking ma soʻo se lautele savali, ae le faʻatagaina mo le toilalo ma le `Box<Any>` taua.
//! (`PanicInfo` naʻo loʻo iai le `&(dyn Any + Send)`, lea matou te faʻatumuina ai se tau aoga ile 'PanicInfo: : internal_constructor`.) O le mafuaʻaga o lenei e le faʻatagaina le faʻatagaina.
//!
//!
//! Lenei module aofia ai ni nai isi faʻafaigofie gaioiga, ae o nei mea ua naʻo le talafeagai lava aitema mo le tuʻufaʻatasia.O panics uma o loʻo faʻatumuina i lenei galuega e tasi.
//! O le faʻailoga saʻo ua folafolaina e ala ile `#[panic_handler]` uiga.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Le faʻavaeina faʻatinoina o le libcore's `panic!` macro pe a leai se faʻatulagaina e faʻaaogaina.
#[cold]
// aua neʻi gaioi seʻi vagana panic_im Mediate_abort e aloese ai mai le faʻailoga i luga o nofoaga telefoni i le tele e mafai ai
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // manaʻomia e codegen mo panic luga lofituina ma isi `Assert` MIR faʻamutaina
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Faaaoga Arguments::new_v1 nai lo le format_args! ("{}", Expr) e ono faaitiitia tele luga.
    // Le faatulagaga_lulu!Faaali atu o le str faaaogaina macro trait e tusi expr, lea valaau Formatter::pad, lea e tatau ona taulimaina manoa truncation ma padding (e ui lava o loo faaaogaina e leai se tasi iinei).
    //
    // O le faʻaaogaina o le Arguments::new_v1 e ono faʻatagaina ai le tagata tuʻufaʻatasia ona aveʻese le Formatter::pad mai le binary faʻatinoga, faʻasaoina i ni nai kilobytes.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // manaʻomia mo Const-iloiloina panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // manaʻomia e codegen mo panic luga OOB array/slice ulufale
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// O le faavae faatinoga a macro `panic!` o libcore pe formatting o loo faaaogaina.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // FAʻAALIGA O lenei gaioiga e le sopoʻia le tuaoi FFI;o le Rust-i-Rust valaʻau e faʻamaonia i le `#[panic_handler]` gaioiga.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // SAFETY: `panic_impl` ua faʻamatalaina i le saogalemu Rust code ma o lea e saogalemu ai e valaʻau.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Galuega i totonu mo `assert_eq!` ma `assert_ne!` macros
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}