//! Manoa togafiti.
//!
//! Mo nisi faʻamatalaga, vaʻai le [`std::str`] module.
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. i fafo atu o tuaoi
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. amata <=iuga
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. uiga tuaoi
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // saili le amio
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` tatau ona itiiti ifo i lo Len ma a SIA tuaoi
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Toe foi mai o le umi o `self`.
    ///
    /// O lenei umi i bytes, e le ['char`] s po graphemes.
    /// I nisi upu, atonu e le o le mea e manatu le tagata le umi o le manoa.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // manaia!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Faʻafoʻi `true` peʻa `self` i ai le umi o zero bytes.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Siaki le mea lea o le `index`-th byte o le muamua byte i le UTF-8 code point series poʻo le iʻuga o le manoa.
    ///
    ///
    /// Le amataga ma le faʻaiuga o le manoa (pe a fai o le `index== self.len()`) o ni tuaʻoi.
    ///
    /// Faʻafoʻi `false` pe a fai o `index` e sili atu nai lo `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // amataga o le `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // byte lona lua o le `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // tolu byte o `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 ma Len e lelei i taimi uma.
        // Suʻesuʻega mo le 0 manino ina ia mafai ai ona faʻamautinoa lelei le siaki faigofie ma faʻamavae le faitauina o manoa faʻamatalaga mo lena tulaga.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // O lenei mea e pei o le faʻamaneta: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Tagata liliu mai se fasi manoa i se fasi byte.
    /// Ina ia liua le byte slice i totonu o se manoa fasi, faʻaaoga le [`from_utf8`] function.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // SAFETY: const leo aua matou te felafolafoai ituaiga e lua ma le faʻataʻatiaga e tasi
        unsafe { mem::transmute(self) }
    }

    /// Faʻaliliuga o se fasi manoa suia i se fesuiaʻiga fasi byte.
    ///
    /// # Safety
    ///
    /// e tatau ona mautinoa ai le Tagata telefoni mai e faapea o le mataupu i totonu o le fasi e aloaia UTF-8 i luma o le faanoi tuluiga ma ua faaaogaina le `str` faavae.
    ///
    ///
    /// Faʻaaoga o le `str` o ona anotusi e le talafeagai UTF-8 e le o faʻamatalaina amioga.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // SAFETY: o le lafo mai `&str` i le `&[u8]` e saogalemu talu mai `str`
        // ei ai le tutusa faʻataʻatiaga ma `&[u8]` (na libstd mafai ona faia lenei faʻamaoniga).
        // O le faʻasino vaʻavaʻa vaʻaia e sefe talu ai e sau mai se mutable faʻasino lea e mautinoa e aoga mo tusitusiga.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Tagata liliu mai se fasi manoa e a faasino ai mata.
    ///
    /// E pei o fasi manoa o se fasi bytes, o le raw faʻasino tusi tusi i le [`u8`].
    /// O lenei e faasino ai o le a faasino i le byte muamua o le fasi manoa.
    ///
    /// E tatau i le tagata telefoni ona faʻamautinoa e le taitai tusi le tusi faʻasino i tua.
    /// Afai e te manaʻomia le suia o mea i totonu o le manoa fasi, faʻaaoga [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Faʻaliliuga o se fasi manogi mutable i se raw faʻatu.
    ///
    /// E pei o fasi manoa o se fasi bytes, o le raw faʻasino tusi tusi i le [`u8`].
    /// O lenei e faasino ai o le a faasino i le byte muamua o le fasi manoa.
    ///
    /// O lou tiutetauave ina ia mautinoa e na o le e oo atu fesuiai le fasi manoa i se auala e tumau pea ona aloaia UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Faʻafoʻi mai le faʻasologa o le `str`.
    ///
    /// Ole auala lea e leʻo faʻaalu ile filifiliga ole `str`.
    /// Faʻafoʻi [`None`] i soʻo se taimi tutusa gaioiga faʻasino igoa o le panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // indices le i UTF-8 tuaoi faasologa
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // i fafo atu o tuaoi
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Faʻafoʻi mai se faʻafesuiaʻi o le `str`.
    ///
    /// Ole auala lea e leʻo faʻaalu ile filifiliga ole `str`.
    /// Faʻafoʻi [`None`] i soʻo se taimi tutusa gaioiga faʻasino igoa o le panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // umi saʻo
    /// assert!(v.get_mut(0..5).is_some());
    /// // i fafo atu o tuaoi
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Faʻafoʻi mai le faʻasologa o `str` e leʻi siakiina.
    ///
    /// o le isi e lē siakiina lenei e le faasino igoa o le `str`.
    ///
    /// # Safety
    ///
    /// O i latou e valaʻaulia lenei galuega e nafa ma le faʻamalieina o nei mataʻupu.
    ///
    /// * O le amataga faʻasino igoa e le tatau ona sili atu i le faʻaiuga faʻasino igoa;
    /// * e tatau ona faasino upu o igoa i totonu o tuaoi o le fasi uluai;
    /// * O faʻasino e tatau ona taoto i UTF-8 faʻasologa tapulaʻa.
    ///
    /// I le le faʻataunuʻuina o lea, o le fasi manoa ua toe faʻafoʻi mai atonu e ono faʻamanatuina ai le manatuaina poʻo le solia o tagata faʻasolosolo fesoʻotaʻi e le `str` ituaiga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // SAOGALEMU: o le telefoni e tatau ona lagolagoina le konekarate saogalemu mo `get_unchecked`;
        // o le fasi e faʻaleaogaina aua `self` o se saogalemu faʻasino.
        // O le toe faʻasino faasino e saogalemu aua impls o `SliceIndex` tatau ona mautinoa o lea e.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Faʻafoʻi mai se faʻafesuiaʻi o le `str`.
    ///
    /// o le isi e lē siakiina lenei e le faasino igoa o le `str`.
    ///
    /// # Safety
    ///
    /// O i latou e valaʻaulia lenei galuega e nafa ma le faʻamalieina o nei mataʻupu.
    ///
    /// * O le amataga faʻasino igoa e le tatau ona sili atu i le faʻaiuga faʻasino igoa;
    /// * e tatau ona faasino upu o igoa i totonu o tuaoi o le fasi uluai;
    /// * O faʻasino e tatau ona taoto i UTF-8 faʻasologa tapulaʻa.
    ///
    /// I le le faʻataunuʻuina o lea, o le fasi manoa ua toe faʻafoʻi mai atonu e ono faʻamanatuina ai le manatuaina poʻo le solia o tagata faʻasolosolo fesoʻotaʻi e le `str` ituaiga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `get_unchecked_mut`;
        // o le fasi e faʻaleaogaina aua `self` o se saogalemu faʻasino.
        // O le toe faʻasino faasino e saogalemu aua impls o `SliceIndex` tatau ona mautinoa o lea e.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Fausia se manoa fasi mai seisi fasi fasi, aloese saogalemu siaki.
    ///
    /// e masani le fautuaina lenei, faaaogaina ma le faaeteete!Mo se isi auala saogalemu vaʻai [`str`] ma [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Lenei fasi fou alu mai `begin` i `end`, aofia ai `begin` ae le aofia ai `end`.
    ///
    /// Ina ia maua se fasi manoa mutable ae, tagai i le auala [`slice_mut_unchecked`].
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// O i latou e valaʻaulia lenei galuega e tali atu ua faʻamalieina tuʻutuʻuga e tolu:
    ///
    /// * `begin` le tatau ona sili atu ile `end`.
    /// * `begin` ma `end` tatau ona byte tulaga i totonu o le manoa fasi.
    /// * `begin` ma `end` tatau ona taʻoto luga UTF-8 faʻasologa tapulaʻa.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // SAOGALEMU: o le telefoni e tatau ona lagolagoina le konekarate saogalemu mo `get_unchecked`;
        // o le fasi e faʻaleaogaina aua `self` o se saogalemu faʻasino.
        // O le toe faʻasino faasino e saogalemu aua impls o `SliceIndex` tatau ona mautinoa o lea e.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Fausia se manoa fasi mai seisi fasi fasi, aloese saogalemu siaki.
    /// e masani le fautuaina lenei, faaaogaina ma le faaeteete!Mo se isi auala saogalemu vaʻai [`str`] ma [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Lenei fasi fou alu mai `begin` i `end`, aofia ai `begin` ae le aofia ai `end`.
    ///
    /// Ina ia maua se fasi manoa masuia ae, tagai i le auala [`slice_unchecked`].
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// O i latou e valaʻaulia lenei galuega e tali atu ua faʻamalieina tuʻutuʻuga e tolu:
    ///
    /// * `begin` le tatau ona sili atu ile `end`.
    /// * `begin` ma `end` tatau ona byte tulaga i totonu o le manoa fasi.
    /// * `begin` ma `end` tatau ona taʻoto luga UTF-8 faʻasologa tapulaʻa.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `get_unchecked_mut`;
        // o le fasi e faʻaleaogaina aua `self` o se saogalemu faʻasino.
        // O le toe faʻasino faasino e saogalemu aua impls o `SliceIndex` tatau ona mautinoa o lea e.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Vaevae le tasi fasi manoa i totonu o le lua i se faasino upu.
    ///
    /// O le finauga, `mid`, e tatau ona avea ma byte offset mai le amataga o le manoa.
    /// E tatau foi ona i luga o le tuaoi o le UTF-8 code point.
    ///
    /// toe foi eo atu i le fasi toalua mai le amataga o le fasi manoa e `mid`, ma mai `mid` i le iuga o le fasi manoa.
    ///
    /// Ina ia maua ni fasi manoa suia nai lo, vaʻai i le [`split_at_mut`] metotia.
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics pe a le o `mid` luga o le UTF-8 code point border, pe a fai ua teʻa le iʻuga o le mulimuli code point o le fasi fasi.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary siaki o le faʻasino igoa o loʻo i totonu i le [0, .len()]
        if self.is_char_boundary(mid) {
            // SAFETY: na o le siakiina o `mid` o loʻo i luga o le char char border.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Vavae se tasi fasi manoa suia i le lua i se faasino igoa.
    ///
    /// O le finauga, `mid`, e tatau ona avea ma byte offset mai le amataga o le manoa.
    /// E tatau foi ona i luga o le tuaoi o le UTF-8 code point.
    ///
    /// toe foi eo atu i le fasi toalua mai le amataga o le fasi manoa e `mid`, ma mai `mid` i le iuga o le fasi manoa.
    ///
    /// Ina ia maua fasi manoa masuia ae, tagai i le auala [`split_at`].
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics pe a le o `mid` luga o le UTF-8 code point border, pe a fai ua teʻa le iʻuga o le mulimuli code point o le fasi fasi.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary siaki o le faʻasino igoa o loʻo i totonu i le [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // SAFETY: na o le siakiina o `mid` o loʻo i luga o le char char border.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Faʻafoʻi mai i lalo se fasefulu i luga o le [`char`] s o se fasi manoa.
    ///
    /// E pei o se manoa fasi e aofia ai le aoga UTF-8, e mafai ona tatou iterate e ala i se manoa fasi e [`char`].
    /// O lenei metotia faʻafoʻi mai se faʻaiuga.
    ///
    /// E taua le manatuaina o le [`char`] e fai ma sui o le Unicode Scalar Value, ma atonu e le tutusa ma lou manatu o le a le 'character'.
    ///
    /// Ole faʻafetauiga ile fuifui fualaʻau atonu o le mea lea e te manaʻo ai.
    /// O lenei gaioiga e le o saunia e le Rust's standard faletusi, siaki crates.io nai lo.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Manatua, [`char`] s atonu e le mafaatusalia lau intuition e uiga i mataʻitusi:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // le 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Faʻafoʻi mai i luga le laina itema i luga o le [`char`] s o se fasi manoa, ma o latou tulaga.
    ///
    /// E pei o se manoa fasi e aofia ai le aoga UTF-8, e mafai ona tatou iterate e ala i se manoa fasi e [`char`].
    /// O lenei auala e toe foi mai se iterator uma nei ['char`] s, faapea foi o latou tulaga byte.
    ///
    /// gauai le iterator tuples.O le tulaga e muamua, o lona lua le [`char`].
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Manatua, [`char`] s atonu e le mafaatusalia lau intuition e uiga i mataʻitusi:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // leai (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // matau le 3 iinei, o le mulimuli amio na aveina lua bytes
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// O se iterator i le bytes o se fasi manoa.
    ///
    /// A o se manoa fasi aofia ai se faʻasologa o bytes, e mafai ona tatou faʻasolosolo ala i se manoa fasi i le byte.
    /// O lenei metotia faʻafoʻi mai se faʻaiuga.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Vaelua se fasi manoa i le lautele.
    ///
    /// toe foi mai le a toe foi iterator fasi manoa e laiti fasi o le fasi uluai manoa, ma valavala ai i so o se aofaiga o whitespace.
    ///
    ///
    /// 'Whitespace' o loʻo faʻauigaina e tusa ma tuutuuga o le Unicode Derived Core Property `White_Space`.
    /// Afai e naʻo lou manaʻo e vaevae ile ASCII whitespace nai lo le, faʻaaoga le [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Uma o ituaiga paʻepaʻe e iloiloina:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Faʻamavae se fasi manoa e le ASCII whitespace.
    ///
    /// O le iterator toe foi le a toe foi fasi manoa e laiti fasi o le fasi uluai manoa, ma valavala ai i so o se aofaiga o whitespace ASCII.
    ///
    ///
    /// Ina ia vaeluaina e Unicode `Whitespace` nai lo lena, faaaoga [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// O ituaiga uma o le ASCII whitespace e iloiloina:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// O se iterator luga o laina o se manoa, pei o fasi manoa.
    ///
    /// O laina e faʻamutaina a le o le laina fou (`\n`) poʻo se taʻavale e toe foʻi mai ma le laina fafaga (`\r\n`).
    ///
    /// Ole filifiliga mulimuli e filifiliga.
    /// O se manoa e faʻaiʻuina i le faʻaiuga o le laina o le a toe faʻafoʻi mai ia laina tutusa e pei o se manoa e tutusa ma aunoa ma se laina mulimuli faʻamutaina.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// E le manaʻomia le iʻuga mulimuli:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// O se faʻasolosolo luga o laina o se manoa.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Faʻafoʻi mai se iterator o `u16` luga o le manoa faʻailogaina pei UTF-16.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Faʻafoʻi `true` pe a fai o le ata tuʻufaʻatasia e fetaui ma se sub-fasi o lenei manoa fasi.
    ///
    /// Faʻafoʻi `false` pe a leai.
    ///
    /// O le [pattern] e mafai ona avea ma `&str`, [`char`], o se fasi vaega o le [`char`] s, poʻo se gaioiga poʻo se tapunia e iloa ai pe fetaui se tagata.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Faafoi `true` pe afai o le tuuina mamanu fetaui a pito i luma o lenei fasi manoa.
    ///
    /// Faʻafoʻi `false` pe a leai.
    ///
    /// O le [pattern] e mafai ona avea ma `&str`, [`char`], o se fasi vaega o le [`char`] s, poʻo se gaioiga poʻo se tapunia e iloa ai pe fetaui se tagata.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Faʻafoʻi `true` pe a fai o le ata tuʻufaʻatasia e fetaui ma le faʻailoga o lenei fasi manoa.
    ///
    /// Faʻafoʻi `false` pe a leai.
    ///
    /// O le [pattern] e mafai ona avea ma `&str`, [`char`], o se fasi vaega o le [`char`] s, poʻo se gaioiga poʻo se tapunia e iloa ai pe fetaui se tagata.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Faʻafoʻi mai le faʻasino igoa o le muamua uiga o lenei manoa fasi e fetaui ma le faʻatusa.
    ///
    /// Faafoi [`None`] pe afai e le fetaui le mamanu.
    ///
    /// O le [pattern] e mafai ona avea ma `&str`, [`char`], o se fasi vaega o le [`char`] s, poʻo se gaioiga poʻo se tapunia e iloa ai pe fetaui se tagata.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// mamanu faigofie:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Sili mamanu lavelave faaaogaina manatu-saoloto faiga ma closures:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Le mauaina le faʻataʻitaʻiga:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Faʻafoʻi mai le index byte mo le tagata muamua o le pito sili ona fetaui o le faʻatusa i lenei fasi manoa.
    ///
    /// Faafoi [`None`] pe afai e le fetaui le mamanu.
    ///
    /// O le [pattern] e mafai ona avea ma `&str`, [`char`], o se fasi vaega o le [`char`] s, poʻo se gaioiga poʻo se tapunia e iloa ai pe fetaui se tagata.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// mamanu faigofie:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Sili atu lavelave faiga ma tapunia:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Le mauaina le faʻataʻitaʻiga:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// O se mea faʻasolosolo i luga o substrings o lenei manoa fasi, vavaeʻese e mataitusi faʻatusatusa i se mamanu.
    ///
    /// O le [pattern] e mafai ona avea ma `&str`, [`char`], o se fasi vaega o le [`char`] s, poʻo se gaioiga poʻo se tapunia e iloa ai pe fetaui se tagata.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator amioga
    ///
    /// O le faʻafoʻi faʻafoʻi o le a avea ma [`DoubleEndedIterator`] pe a fai o le faʻataʻitaʻiga e faʻatagaina le toe suʻesuʻe ma forward/reverse sailiga maua ai elemeni tutusa.
    /// E moni lea mo, eg, [`char`], ae le mo `&str`.
    ///
    /// Afai e mafai ai e le mamanu a faafeagai suesuega ae o lona taunuuga e ono ese mai i se suesuega i luma, e mafai ona faaaoga le auala [`rsplit`].
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// mamanu faigofie:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Pe afai o le mamanu o le a fasi o chars, vaeluaina i tulai taitasi o so o se tagata:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// O se sili atu faigata faʻataʻitaʻiga, faʻaaogaina o se tapunia:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Afai o se manoa o loo i ai le tele eseese o tuaoi, o le a iu ina manoa gaogao i le galuega faatino:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// O vavae ese vavalalata e vavaeʻese e le avanoa avanoa.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Eseese o i le amataga po o le faaiuga o se manoa o loo neighbored e manoa gaogao.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// A faʻaaogaina le manoa gaogao o se tuueseesega, na te tuueseeseina tagata taʻitasi i le manoa, faʻatasi ai ma le amataga ma le iʻuga o le manoa.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// O vavalalata vavalalata e ono taitai atu ai i ni amioga e maofa ai pe a fai o le mea papaʻe e avea o le tuueseesega.O lenei tulafono o le saʻo:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// E _not_ avatu ia oe:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Faʻaaoga [`split_whitespace`] mo lenei amioga.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// O se mea faʻasolosolo i luga o substrings o lenei manoa fasi, vavaeʻese e mataitusi faʻatusatusa i se mamanu.
    /// Eseesega mai le mea faʻasolosolo na gaosia e `split` i le `split_inclusive` tuʻua le vaega faʻafetaui o le faʻamutaina o le substring.
    ///
    ///
    /// O le [pattern] e mafai ona avea ma `&str`, [`char`], o se fasi vaega o le [`char`] s, poʻo se gaioiga poʻo se tapunia e iloa ai pe fetaui se tagata.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Afai o le elemeni mulimuli o le manoa ua faʻatusa, o lena elemeni o le a avea ma faʻamutaina o le muamua substring.
    /// O lena substring o le aitema mulimuli toe foi mai e le iterator.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// O se mea faʻasolosolo i luga o substrings o le fasi manoa tuʻufaʻatasia, vavaeʻese e mataʻitusi fetaui ma se faʻataʻitaʻiga ma gaioi i le faʻatonuga faʻatulagaina.
    ///
    /// O le [pattern] e mafai ona avea ma `&str`, [`char`], o se fasi vaega o le [`char`] s, poʻo se gaioiga poʻo se tapunia e iloa ai pe fetaui se tagata.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator amioga
    ///
    /// O le toe foi iterator manaomia e lagolagoina ai le mamanu a sailiga faafeagai, ma o le a a [`DoubleEndedIterator`] pe afai o se suesuega forward/reverse gauai le elemene e tasi.
    ///
    ///
    /// Mo le faʻasolosolo mai luma, o le [`split`] auala e mafai ona faʻaaogaina.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// mamanu faigofie:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// O se sili atu faigata faʻataʻitaʻiga, faʻaaogaina o se tapunia:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// O se mea faʻasolosolo luga o substrings o le fasi manoa na tuʻufaʻatasia, vavaeʻese e mataʻitusi fetaui ma se faʻataʻitaʻiga.
    ///
    /// O le [pattern] e mafai ona avea ma `&str`, [`char`], o se fasi vaega o le [`char`] s, poʻo se gaioiga poʻo se tapunia e iloa ai pe fetaui se tagata.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Tutusa [`split`], vagana ua misi le substring trailing afai gaogao.
    ///
    /// [`split`]: str::split
    ///
    /// e mafai ona faaaoga auala lenei mo faamatalaga manoa e _terminated_, nai lo _separated_ e se mamanu.
    ///
    /// # Iterator amioga
    ///
    /// O le faʻafoʻi faʻafoʻi o le a avea ma [`DoubleEndedIterator`] pe a fai o le faʻataʻitaʻiga e faʻatagaina le toe suʻesuʻe ma forward/reverse sailiga maua ai elemeni tutusa.
    /// E moni lea mo, eg, [`char`], ae le mo `&str`.
    ///
    /// Afai ole faʻataʻitaʻiga faʻatagaina le toe suʻesuʻe ae o ona iʻuga ono ese mai le sailiga i luma, e mafai ona faʻaaogaina le [`rsplit_terminator`] auala.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// O se mea faʻasolosolo i luga o substrings o `self`, vavaeʻese e mataitusi faʻatusatusa i se mamanu ma faʻatagaina i le faʻatonuga faʻatulagaina.
    ///
    /// O le [pattern] e mafai ona avea ma `&str`, [`char`], o se fasi vaega o le [`char`] s, poʻo se gaioiga poʻo se tapunia e iloa ai pe fetaui se tagata.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Tutusa [`split`], vagana ua misi le substring trailing afai gaogao.
    ///
    /// [`split`]: str::split
    ///
    /// e mafai ona faaaoga auala lenei mo faamatalaga manoa e _terminated_, nai lo _separated_ e se mamanu.
    ///
    /// # Iterator amioga
    ///
    /// O le faʻafoʻi faʻafoʻi manaʻomia le lagolagoina o le faʻataʻitaʻiga le toe suʻesuʻe, ma o le a faʻaluaina faʻaiʻu pe a fai o le forward/reverse suʻesuʻe maua tutusa elemene.
    ///
    ///
    /// Mo le faʻasolosolo mai luma, o le [`split_terminator`] auala e mafai ona faʻaaogaina.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// O se iterator i substrings o le fasi manoa e tuuina mai, ma valavala ai i se mamanu, faatapulaaina i le toe foi i le tele o mea `n`.
    ///
    /// Afai e toe faʻafoʻi mai le `n` substrings, o le substring mulimuli (o le `n`th substring) o le a iai le toega o le manoa.
    ///
    /// O le [pattern] e mafai ona avea ma `&str`, [`char`], o se fasi vaega o le [`char`] s, poʻo se gaioiga poʻo se tapunia e iloa ai pe fetaui se tagata.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator amioga
    ///
    /// O le toe foi o le a le lua iu iterator, ona e le o lelei e lagolagoina ai.
    ///
    /// Afai o le faʻataʻitaʻiga faʻatagaina le toe suʻesuʻe, e mafai ona faʻaaogaina le [`rsplitn`] auala.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// mamanu faigofie:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// O se sili atu faigata faʻataʻitaʻiga, faʻaaogaina o se tapunia:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// O se iterator i substrings o lenei fasi manoa, ma valavala ai i se mamanu, e amata mai i le pito o le manoa, faatapulaaina i le toe foi i le tele o mea `n`.
    ///
    ///
    /// Afai e toe faʻafoʻi mai le `n` substrings, o le substring mulimuli (o le `n`th substring) o le a iai le toega o le manoa.
    ///
    /// O le [pattern] e mafai ona avea ma `&str`, [`char`], o se fasi vaega o le [`char`] s, poʻo se gaioiga poʻo se tapunia e iloa ai pe fetaui se tagata.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator amioga
    ///
    /// O le toe foi o le a le lua iu iterator, ona e le o lelei e lagolagoina ai.
    ///
    /// Mo le vaeluaina mai luma, e mafai ona faʻaaogaina le [`splitn`] auala.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// mamanu faigofie:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// O se sili atu faigata faʻataʻitaʻiga, faʻaaogaina o se tapunia:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Vaeluaina le manoa i luga o le mea na tupu muamua o le delimiter faamaoti ma pito i luma o tupe maua i luma o delimiter ma suffix ina ua uma delimiter.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Vaelua le manoa i le mea mulimuli na tupu mai o le faʻamaoti tuʻusaʻo ma toe faʻafoʻi faʻataʻitaʻiga i luma o le tagata faʻamavae ma faʻapipiʻi ina ua maeʻa le tagata.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// O se mea faʻasolosolo i luga o le vavalalata faʻafetaui o se mamanu i totonu o le fasi manoa tuʻuina atu.
    ///
    /// O le [pattern] e mafai ona avea ma `&str`, [`char`], o se fasi vaega o le [`char`] s, poʻo se gaioiga poʻo se tapunia e iloa ai pe fetaui se tagata.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator amioga
    ///
    /// O le faʻafoʻi faʻafoʻi o le a avea ma [`DoubleEndedIterator`] pe a fai o le faʻataʻitaʻiga e faʻatagaina le toe suʻesuʻe ma forward/reverse sailiga maua ai elemeni tutusa.
    /// E moni lea mo, eg, [`char`], ae le mo `&str`.
    ///
    /// Afai e mafai ai e le mamanu a faafeagai suesuega ae o lona taunuuga e ono ese mai i se suesuega i luma, e mafai ona faaaoga le auala [`rmatches`].
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// O se mea faʻasolosolo i luga o le vavalalata faʻafetaui o se mamanu i totonu o lenei manoa fasi, na maua i le faʻasologa saʻo.
    ///
    /// O le [pattern] e mafai ona avea ma `&str`, [`char`], o se fasi vaega o le [`char`] s, poʻo se gaioiga poʻo se tapunia e iloa ai pe fetaui se tagata.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator amioga
    ///
    /// O le toe foi iterator manaomia e lagolagoina ai le mamanu a sailiga faafeagai, ma o le a a [`DoubleEndedIterator`] pe afai o se suesuega forward/reverse gauai le elemene e tasi.
    ///
    ///
    /// Mo iterating mai le pito i luma, e mafai ona faaaogaina le auala [`matches`].
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// O se mea faʻasolosolo i luga o taʻaloga le tutusa o se mamanu i totonu o lenei manoa fasi faʻapea foi ma le faʻasino igoa o le taʻaloga amata i.
    ///
    /// Mo afitusi o `pat` totonu `self` e fesiliaʻi, na o le ua toe foi indices e talafeagai ma fetaui muamua.
    ///
    /// O le [pattern] e mafai ona avea ma `&str`, [`char`], o se fasi vaega o le [`char`] s, poʻo se gaioiga poʻo se tapunia e iloa ai pe fetaui se tagata.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator amioga
    ///
    /// O le faʻafoʻi faʻafoʻi o le a avea ma [`DoubleEndedIterator`] pe a fai o le faʻataʻitaʻiga e faʻatagaina le toe suʻesuʻe ma forward/reverse sailiga maua ai elemeni tutusa.
    /// E moni lea mo, eg, [`char`], ae le mo `&str`.
    ///
    /// Afai ole faʻataʻitaʻiga faʻatagaina le toe suʻesuʻe ae o ona iʻuga ono ese mai le sailiga i luma, e mafai ona faʻaaogaina le [`rmatch_indices`] auala.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // naʻo le muamua `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// O se iterator i le disjoint fetaui o se mamanu i totonu `self`, gauai atu i le poloaiga e faafeagai faatasi ai ma le faasino upu o le afitusi.
    ///
    /// Mo afitusi o `pat` totonu `self` e fesiliaʻi, na o le indices e talafeagai ma fetaui mulimuli e toe foi mai.
    ///
    /// O le [pattern] e mafai ona avea ma `&str`, [`char`], o se fasi vaega o le [`char`] s, poʻo se gaioiga poʻo se tapunia e iloa ai pe fetaui se tagata.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator amioga
    ///
    /// O le toe foi iterator manaomia e lagolagoina ai le mamanu a sailiga faafeagai, ma o le a a [`DoubleEndedIterator`] pe afai o se suesuega forward/reverse gauai le elemene e tasi.
    ///
    ///
    /// Mo le faʻasolosolo mai luma, o le [`match_indices`] auala e mafai ona faʻaaogaina.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // naʻo le `aba` mulimuli
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Toe foi se fasi manoa i le taitaiga ma le trailing whitespace aveesea.
    ///
    /// 'Whitespace' o loʻo faʻauigaina e tusa ma tuutuuga o le Unicode Derived Core Property `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Faʻafoʻi mai se fasi manoa ma aveeseina le paʻepaʻe.
    ///
    /// 'Whitespace' o loʻo faʻauigaina e tusa ma tuutuuga o le Unicode Derived Core Property `White_Space`.
    ///
    /// # Faʻasino upu
    ///
    /// O se manoa o se faasologa o bytes.
    /// `start` i lenei tulaga o lona uiga o le tulaga muamua o lena manoa byte;mo a tuua-e taumatau gagana e pei o le gagana Peretania po o le gagana Rusia, o le a itu tauagavale lenei, ma le gagana tonu-e-taumatau e pei o le gagana Arapi po o le gagana Eperu, o le a avea lenei ma le itu taumatau.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Toe foi se fasi manoa ma trailing whitespace aveesea.
    ///
    /// 'Whitespace' o loʻo faʻauigaina e tusa ma tuutuuga o le Unicode Derived Core Property `White_Space`.
    ///
    /// # Faʻasino upu
    ///
    /// O se manoa o se faasologa o bytes.
    /// `end` i lenei tulaga o lona uiga o le tulaga mulimuli o lena manoa byte;mo le agavale-i-le taumatau gagana pei o le Igilisi poʻo Lusia, o le a avea ma itu taumatau, ma mo taumatau-i le-agavale gagana pei o Arapi po o le faʻaEperu, o le a avea lenei o le itu tauagavale.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Faʻafoʻi mai se fasi manoa ma aveeseina le paʻepaʻe.
    ///
    /// 'Whitespace' o loʻo faʻauigaina e tusa ma tuutuuga o le Unicode Derived Core Property `White_Space`.
    ///
    /// # Faʻasino upu
    ///
    /// O se manoa o se faasologa o bytes.
    /// 'Left' i lenei tala o lona uiga o le tulaga muamua o le byte manoa;mo se gagana e pei o le gagana Arapi po o Eperu e 'aia tatau e tuua' nai lo le 'tauagavale i le taumatau', o le a le itu _right_ lenei, e le o le itu tauagavale.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Toe foi se fasi manoa ma trailing whitespace aveesea.
    ///
    /// 'Whitespace' o loʻo faʻauigaina e tusa ma tuutuuga o le Unicode Derived Core Property `White_Space`.
    ///
    /// # Faʻasino upu
    ///
    /// O se manoa o se faasologa o bytes.
    /// 'Right' i lenei tala o lona uiga o le mulimuli tulaga o lena byte manoa;mo se gagana pei o Alapi poʻo le gagana Eperu e 'taumatau i le agavale' nai lo le 'agavale i le taumatau', o le _left_ lea o le itu, ae le o le taumatau.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Toe foi se manoa fasi ma prefixes ma suffixes e fetaui se mamanu aveesea soo.
    ///
    /// O le [pattern] e mafai ona avea ma [`char`], o se fasi vaega o le [`char`] s, poʻo se gaioiga poʻo se tapunia e iloa ai pe fetaui se tagata.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// mamanu faigofie:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// O se sili atu faigata faʻataʻitaʻiga, faʻaaogaina o se tapunia:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Manatua vave iloa taʻaloga, faʻasaʻo i lalo pe a
            // e ese fetaui mulimuli
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SAFETY: `Searcher` e iloa e toe faʻafoʻi faʻamaumauga talafeagai.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Faʻafoʻi mai se fasi manoa faʻatasi ma nauna i luma e tutusa ma se mamanu ua aveʻesea uma.
    ///
    /// O le [pattern] e mafai ona avea ma `&str`, [`char`], o se fasi vaega o le [`char`] s, poʻo se gaioiga poʻo se tapunia e iloa ai pe fetaui se tagata.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Faʻasino upu
    ///
    /// O se manoa o se faasologa o bytes.
    /// `start` i lenei tulaga o lona uiga o le tulaga muamua o lena manoa byte;mo a tuua-e taumatau gagana e pei o le gagana Peretania po o le gagana Rusia, o le a itu tauagavale lenei, ma le gagana tonu-e-taumatau e pei o le gagana Arapi po o le gagana Eperu, o le a avea lenei ma le itu taumatau.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // SAFETY: `Searcher` e iloa e toe faʻafoʻi faʻamaumauga talafeagai.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Faʻafoʻi mai se fasi manoa ma aveese le nauna.
    ///
    /// Afai e amata le manoa ile faʻataʻitaʻiga `prefix`, faʻafoʻi mai le substring pe a uma le nauna, faʻamau ile `Some`.
    /// E le pei o le `trim_start_matches`, o lenei metotia e aveʻese ai le nauna i le taimi e tasi.
    ///
    /// Afai e le amata le manoa ma `prefix`, Ua toe foi `None`.
    ///
    /// O le [pattern] e mafai ona avea ma `&str`, [`char`], o se fasi vaega o le [`char`] s, poʻo se gaioiga poʻo se tapunia e iloa ai pe fetaui se tagata.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Toe foi se fasi manoa i le suffix aveesea.
    ///
    /// Afai e muta le manoa ile faʻataʻitaʻiga `suffix`, toe faʻafoʻi mai le substring aʻo leʻi faʻauuina, afifi ile `Some`.
    /// E le pei o le `trim_end_matches`, o lenei metotia e aveʻese ai le faʻailoga i le taimi e tasi.
    ///
    /// Afai e le i faaiuina ai manoa ma `suffix`, Ua toe foi `None`.
    ///
    /// O le [pattern] e mafai ona avea ma `&str`, [`char`], o se fasi vaega o le [`char`] s, poʻo se gaioiga poʻo se tapunia e iloa ai pe fetaui se tagata.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Toe foi se manoa fasi ma suffixes e fetaui se mamanu aveesea soo.
    ///
    /// O le [pattern] e mafai ona avea ma `&str`, [`char`], o se fasi vaega o le [`char`] s, poʻo se gaioiga poʻo se tapunia e iloa ai pe fetaui se tagata.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Faʻasino upu
    ///
    /// O se manoa o se faasologa o bytes.
    /// `end` i lenei tulaga o lona uiga o le tulaga mulimuli o lena manoa byte;mo le agavale-i-le taumatau gagana pei o le Igilisi poʻo Lusia, o le a avea ma itu taumatau, ma mo taumatau-i le-agavale gagana pei o Arapi po o le faʻaEperu, o le a avea lenei o le itu tauagavale.
    ///
    ///
    /// # Examples
    ///
    /// mamanu faigofie:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// O se sili atu faigata faʻataʻitaʻiga, faʻaaogaina o se tapunia:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SAFETY: `Searcher` e iloa e toe faʻafoʻi faʻamaumauga talafeagai.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Faʻafoʻi mai se fasi manoa faʻatasi ma nauna i luma e tutusa ma se mamanu ua aveʻesea uma.
    ///
    /// O le [pattern] e mafai ona avea ma `&str`, [`char`], o se fasi vaega o le [`char`] s, poʻo se gaioiga poʻo se tapunia e iloa ai pe fetaui se tagata.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Faʻasino upu
    ///
    /// O se manoa o se faasologa o bytes.
    /// 'Left' i lenei tala o lona uiga o le tulaga muamua o le byte manoa;mo se gagana e pei o le gagana Arapi po o Eperu e 'aia tatau e tuua' nai lo le 'tauagavale i le taumatau', o le a le itu _right_ lenei, e le o le itu tauagavale.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Toe foi se manoa fasi ma suffixes e fetaui se mamanu aveesea soo.
    ///
    /// O le [pattern] e mafai ona avea ma `&str`, [`char`], o se fasi vaega o le [`char`] s, poʻo se gaioiga poʻo se tapunia e iloa ai pe fetaui se tagata.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Faʻasino upu
    ///
    /// O se manoa o se faasologa o bytes.
    /// 'Right' i lenei tala o lona uiga o le mulimuli tulaga o lena byte manoa;mo se gagana pei o Alapi poʻo le gagana Eperu e 'taumatau i le agavale' nai lo le 'agavale i le taumatau', o le _left_ lea o le itu, ae le o le taumatau.
    ///
    ///
    /// # Examples
    ///
    /// mamanu faigofie:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// O se sili atu faigata faʻataʻitaʻiga, faʻaaogaina o se tapunia:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Parses lenei fasi manoa i se isi ituaiga.
    ///
    /// Ona e aoao `parse`, e mafai ona mafua ai faafitauli i le faaiuga ituaiga.
    /// E pei o lea, `parse` o se tasi o nai taimi e te vaʻaia ai le faʻafesoʻotaʻiga alofa pei o le 'turbofish': `::<>`.
    ///
    /// Lenei fesoasoani i le inferensi algorithm malamalama faʻapitoa i le ituaiga o loʻo e taumafai e faʻavasega i totonu.
    ///
    /// `parse` e mafai ona parse i so o se ituaiga e faatino le [`FromStr`] trait.
    ///

    /// # Errors
    ///
    /// E toe faafoi [`Err`] pe a le mafai ona vaelua lenei manoa fasi i le ituaiga manaʻomia.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Faʻaaogaina le 'turbofish' nai lo le tusia o le `four`.
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Le lē mafai ona parse:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Siaki pe o mataʻitusi uma i lenei manoa o loʻo i totonu o le ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // E mafai ona matou togafitia taʻitasi byte pei o amio ii: o multibyte mataitusi uma amata i le byte e le o i le tulaga lautele, o lea o le a tatou taofi ai iina.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Siaki e lua manoa o le ASCII tulaga-le malamalama taʻaloga.
    ///
    /// Tutusa lava ma `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, ae aunoa ma le tuʻuina atu ma le kopiina o taimi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Faʻaliliuina lenei manoa i lona ASCII pito i luga mataupu tutusa i le nofoaga.
    ///
    /// ASCII tusi 'a' e 'z' ua faailogaina e 'A' e 'Z', ae tusi lē ASCII ua suia.
    ///
    /// Ina ia toe faʻafoʻi mai se tau aofaʻi fou e aunoa ma le toe fesuiaʻi o se tasi, faʻaaoga le [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // SAOGALEMU: saogalemu ona tatou transmute lua ituaiga i le faatulagaga lava lea e tasi.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Tagata Liliu lenei manoa i lona ASCII tutusa tulaga i lalo i totonu o le nofoaga.
    ///
    /// O mataitusi ASCII 'A' i le 'Z' e faʻafanua i le 'a' i le 'z', ae o mataitusi e leʻo ASCII e le suia.
    ///
    /// Ina ia toe faʻafoʻi mai se tau maualalo maualalo e aunoa ma le toe fesuiaʻi o se tasi o loʻo i ai, faʻaaoga [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // SAOGALEMU: saogalemu ona tatou transmute lua ituaiga i le faatulagaga lava lea e tasi.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Toe foi se iterator e lilo SIA taitasi i `self` ma [`char::escape_debug`].
    ///
    ///
    /// Note: na tuuina atu grapheme codepoints e amata le a sao ai mai le manoa.
    ///
    /// # Examples
    ///
    /// I le avea ai ma se faʻaiuga:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Faʻaaoga saʻo `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// e tutusa uma e lua:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Faʻaaogaina `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Toe foi se iterator e lilo SIA taitasi i `self` ma [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// I le avea ai ma se faʻaiuga:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Faʻaaoga saʻo `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// e tutusa uma e lua:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Faʻaaogaina `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Faʻafoʻi se iterator e sola ese mai char taʻitasi i le `self` ma le [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// I le avea ai ma se faʻaiuga:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Faʻaaoga saʻo `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// e tutusa uma e lua:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Faʻaaogaina `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Faatupuina ai se str gaogao
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Faatupuina ai se str mutable gaogao
    #[inline]
    fn default() -> Self {
        // SAFETI: O le manoa gaogao e aoga UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// O se ituaiga igoa taʻutaʻua, e mafai ona faʻaaogaina
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // SAOGALEMU: le saogalemu
        unsafe { from_utf8_unchecked(bytes) }
    };
}