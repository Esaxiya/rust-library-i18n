//! implementations Trait mo `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Faʻaaogaina le okaina o manoa.
///
/// O manoa e okaina [lexicographically](Ord#lexicographical-comparison) e latou taua taua.
/// O lenei oka Unicode numera togi faʻavae luga o latou tulaga i le numera siata.
/// e le ona le lava lenei e tasi e pei "alphabetical" poloaiga, e eseese lava gagana ma locale.
/// O le faʻavasegaina o manoa e tusa ai ma aganuu-taliaina tulaga manaʻomia manaʻomia-faʻapitoa faʻamaumauga o loʻo i fafo atu o le lautele o le `str` ituaiga.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Faʻaaogaina faʻatusatusaga faʻagaioiga i manoa.
///
/// Ua faʻatusatusa manoa i le [lexicographically](Ord#lexicographical-comparison) e le latou taʻiala taua.
/// O lenei faʻatusatusa Unicode code manatu faʻavae luga o latou tulaga i le code siata.
/// e le ona le lava lenei e tasi e pei "alphabetical" poloaiga, e eseese lava gagana ma locale.
/// Faʻatusatusaina manoa e tusa ai ma aganuu-taliaina tulaga manaʻomia manaʻomia-faʻapitoa faʻamaumauga o loʻo i fafo atu o le lautele o le `str` ituaiga.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Meafaigaluega substring slicing ma syntax `&self[..]` po `&mut self[..]`.
///
/// Faʻafoʻi mai se fasi fasi manoa atoa, faʻapea, toe faafoʻi `&self` poʻo `&mut self`.Tutusa ma `&oe lava [0 ..
/// len] `poʻo`&mut oe lava [0 ..
/// len]`.
/// E le pei o isi faʻavasegaina gaioiga, lenei mafai lava panic.
///
/// Lenei taʻotoga o le *O*(1).
///
/// Ae le i oʻo i le 1.20.0, o nei faʻavasegaina gaioiga na lagolagoina pea e le tuʻuina atu faʻatinoina o `Index` ma `IndexMut`.
///
/// Tutusa `&self[0 .. len]` po `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Meafaigaluega substring slicing ma syntax `&self[begin .. end]` po `&mut self[begin .. end]`.
///
/// O tupe maua a fasi o le manoa tuuina mai le tele byte ['begin`, `end`).
///
/// Lenei taʻotoga o le *O*(1).
///
/// Ae le i oʻo i le 1.20.0, o nei faʻavasegaina gaioiga na lagolagoina pea e le tuʻuina atu faʻatinoina o `Index` ma `IndexMut`.
///
/// # Panics
///
/// Panics afai `begin` po e le faasino `end` i le byte amata aveesea o se tagata (e pei ona faamatalaina e `is_char_boundary`), pe afai `begin > end`, po o pe afai `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // nei o le a panic:
/// // byte 2 pepelo i totonu o `ö`:
/// // &s [2 ..3];
///
/// // byte 8 o loʻo taʻoto i totonu o le `老`&s [1 ..
/// // 8];
///
/// // byte 100 o loʻo i fafo atu o le manoa&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SAFETY: na o le siakiina o `start` ma `end` o loʻo i luga o le char char,
            // ma o loo tatou ui i se faasinomaga saogalemu, ina ia tasi foi le toe foi mai le taua.
            // Na matou siakiina foʻi faʻatapulaʻa char, o lea e aoga ai le UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SAOGALEMU: na siaki e `start` ma `end` i se tuaoi SIA.
            // Matou te iloa e tutasi le faʻasino tusi aua na matou mauaina mai le `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SAOGALEMU: o le Tagata telefoni faamaonia e `self` i tuaoi o `slice`
        // ua faamalieina aiaiga uma mo `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SAOGALEMU: tagai faamatalaga mo `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // siaki is_char_boundary o le faasino upu o loo i [0, e lē mafai ona toe faʻaaogā .len()] `get` pei luga, ona o faalavelave NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SAFETY: na o le siakiina o `start` ma `end` o loʻo i luga o le char char,
            // ma o loo tatou ui i se faasinomaga saogalemu, ina ia tasi foi le toe foi mai le taua.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Faʻaaogaina laʻasaga tipiina ma le syntax `&self[.. end]` poʻo le `&mut self[.. end]`.
///
/// Faʻafoʻi mai se fasi fasi manoa na aumai mai le byte range [`0`, `end`).
/// Tutusa i le `&self[0 .. end]` poʻo le `&mut self[0 .. end]`.
///
/// Lenei taʻotoga o le *O*(1).
///
/// Ae le i oʻo i le 1.20.0, o nei faʻavasegaina gaioiga na lagolagoina pea e le tuʻuina atu faʻatinoina o `Index` ma `IndexMut`.
///
/// # Panics
///
/// Panics pe a fai o `end` e le faʻasino i le amataga byte offset o se tagata (pei ona faʻamatalaina e `is_char_boundary`), pe afai `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SAOGALEMU: na siaki e `end` o luga o se tuaoi SIA,
            // ma o loo tatou ui i se faasinomaga saogalemu, ina ia tasi foi le toe foi mai le taua.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SAOGALEMU: na siaki e `end` o luga o se tuaoi SIA,
            // ma o loo tatou ui i se faasinomaga saogalemu, ina ia tasi foi le toe foi mai le taua.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // SAOGALEMU: na siaki e `end` o luga o se tuaoi SIA,
            // ma o loo tatou ui i se faasinomaga saogalemu, ina ia tasi foi le toe foi mai le taua.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Meafaigaluega substring slicing ma syntax `&self[begin ..]` po `&mut self[begin ..]`.
///
/// O tupe maua a fasi o le manoa tuuina mai le tele byte ['begin`, `len`).Tutusa ma '&lava [amata ..
/// Len] `poʻo le`&mut 'oe lava [amata ..
/// len]`.
///
/// Lenei taʻotoga o le *O*(1).
///
/// Ae le i oʻo i le 1.20.0, o nei faʻavasegaina gaioiga na lagolagoina pea e le tuʻuina atu faʻatinoina o `Index` ma `IndexMut`.
///
/// # Panics
///
/// Panics pe a fai o `begin` e le faʻasino i le amataga byte offset o se tagata (pei ona faʻamatalaina e `is_char_boundary`), pe afai `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SAFETY: na o le siakiina o `start` o loʻo i luga o le char char,
            // ma o loo tatou ui i se faasinomaga saogalemu, ina ia tasi foi le toe foi mai le taua.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SAFETY: na o le siakiina o `start` o loʻo i luga o le char char,
            // ma o loo tatou ui i se faasinomaga saogalemu, ina ia tasi foi le toe foi mai le taua.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SAOGALEMU: o le Tagata telefoni faamaonia e `self` i tuaoi o `slice`
        // ua faamalieina aiaiga uma mo `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SAFETY: tutusa ma `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // SAFETY: na o le siakiina o `start` o loʻo i luga o le char char,
            // ma o loo tatou ui i se faasinomaga saogalemu, ina ia tasi foi le toe foi mai le taua.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Faʻaaogaina laʻasaga tipiina ma le syntax `&self[begin ..= end]` poʻo le `&mut self[begin ..= end]`.
///
/// Faʻafoʻi mai se fasimea o le manoa na tuʻuina mai le byte range [`begin`, `end`].Tutusa i le `&self [begin .. end + 1]` poʻo le `&mut self[begin .. end + 1]`, seʻi vagana o le `end` o loʻo i ai le maualuga maualuga mo `usize`.
///
/// Lenei taʻotoga o le *O*(1).
///
/// # Panics
///
/// Panics pe afai e le faasino `begin` i le byte amata aveesea o se tagata (e pei ona faamatalaina e `is_char_boundary`), pe afai e le manatu i `end` le byte faaiuina aveesea o se uiga (`end + 1` a le o se byte amata aveesea po o le tutusa i `len`), pe afai `begin > end`, pe afai `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Faʻaaogaina laʻasaga tipiina ma le syntax `&self[..= end]` poʻo le `&mut self[..= end]`.
///
/// Faʻafoʻi mai se fasimea o le manoa na tuʻuina mai le byte range [0, `end`].
/// Tutusa ma `&self [0 .. end + 1]`, seʻi vagana o `end` o loʻo i ai le maualuga maualuga mo `usize`.
///
/// Lenei taʻotoga o le *O*(1).
///
/// # Panics
///
/// Panics pe a fai o `end` e le faʻasino i le faʻaiuga byte offset o se tagata (`end + 1` o se amataga byte offset pei ona faʻamatalaina e `is_char_boundary`, pe tutusa ma `len`), pe afai `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Parse a taua mai se manoa
///
/// 'O le auala [`from_str`] FromStr`e masani ona faaaoga implicitly, e ala i [' str`] 's auala [`parse`].
/// Vaʻai tusitusiga a le [`parse`] mo faʻataʻitaʻiga.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` E leai se parameter o le olaga atoa, ma o lea e mafai ai ona e naʻo ituaiga vaega e le maua ai se olaga atoa parameter latou.
///
/// I nisi upu, oe mafai parse `i32` ma `FromStr`, ae le o le `&i32`.
/// E mafai ona e parse a fausia o loo i ai se `i32`, ae le o se tasi o loo i ai se `&i32`.
///
/// # Examples
///
/// faatinoga Autu o le `FromStr` i luga o se faataitaiga ituaiga `Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// O le fesoʻotaʻiga sese lea e mafai ona toe faafoi mai parsing.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Faʻamamaina le manoa `s` e faʻafoʻi mai ai le tau o lenei ituaiga.
    ///
    /// A manuia le faʻamatuʻuina, toe faafoʻi le tau i totonu o le [`Ok`], a le o lea, a le o lelei le faʻatulagaina o le manoa toe faafoʻi se mea sese faʻapitoa i totonu o le [`Err`].
    /// O le ituaiga mea sese e faʻapitoa i le faʻatinoina o le trait.
    ///
    /// # Examples
    ///
    /// Faʻaaogaina autu ma [`i32`], o se ituaiga e faʻaaoga `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Tuʻu se `bool` mai se manoa.
    ///
    /// Tuʻuina mai le `Result<bool, ParseBoolError>`, aua `s` atonu pe le mafai moni parseable.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Manatua, i le tele o tulaga, o le `.parse()` metotia luga `str` e sili atu ona talafeagai.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}