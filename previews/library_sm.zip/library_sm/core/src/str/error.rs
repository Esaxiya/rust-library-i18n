//! Faʻauiga le utf8 ituaiga sese.

use crate::fmt;

/// O mea sese e mafai ona tupu pe a taumafai e faʻamatala se faʻasologa o [`u8`] o se manoa.
///
/// E pei o lea, o le `from_utf8` aiga o gaioiga ma metotia mo uma [`String`] s ma [`&str`] s faʻaaogaina lenei mea sese, mo se faʻataʻitaʻiga.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Lenei ituaiga sese auala e mafai ona faʻaaogaina e fausia ai gaioiga pei o le `String::from_utf8_lossy` e aunoa ma le tuʻuina atu o le faʻaupuga manatua:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Faʻafoʻi mai le faasino upu i le manoa na tuʻuina atu i luga e faʻamaonia ai le UTF-8.
    ///
    /// O le faasino upu aupito maualuga e pei o le a toe foi `from_utf8(&input[..index])` `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// use std::str;
    ///
    /// // ni paita le aoga, ile vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 toe foi se Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // le byte lona lua o le aoga iinei
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Tuʻuina atu nisi faʻamatalaga e uiga i le toilalo:
    ///
    /// * `None`: na taunuu faafuasei le faaiuga o le sao.
    ///   `self.valid_up_to()` e 1 i le 3 bytes mai le faʻaiuga o le sao.
    ///   Afai o se byte vaitafe (e pei o se faila po o se mataʻomo fesootaiga) ua decoded incrementally, e mafai ona avea o se `char` aloaia lenei lona UTF-8 faasologa byte ua spanning ni oga tele.
    ///
    ///
    /// * `Some(len)`: na fetaiaʻi se byte e leʻi mafaufauina.
    ///   O le umi saunia o le le saʻo byte faʻasologa e amata i le faasino igoa na tuuina mai e `valid_up_to()`.
    ///   E tatau ona toe amata pe a maeʻa le faʻasologa (ina ua maeʻa ona faʻaofi le [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) i le tulaga o le lossy decoding.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Na toe faʻafoʻi se mea sese ina ua le pasi le `bool` ile faʻaaogaina o le [`from_str`]
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}