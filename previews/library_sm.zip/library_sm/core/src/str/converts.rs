//! Auala e fausia ai se `str` mai bytes fasi.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Liua se fasi bytes i se manoa fasi.
///
/// O le manoa fasi ([`&str`]) e faia i bytes ([`u8`]), ma le byte fasi ([`&[u8]`][byteslice]) e faia i bytes, o lea la o lenei gaioiga liua i le va o le lua.
/// E le fasi byte uma e aloaia fasi manoa, peitai: manaomia ai [`&str`] e aloaia UTF-8.
/// `from_utf8()` siaki ia mautinoa o aoga bytes e UTF-8, ona fai ai lea o le liua.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Afai e te mautinoa o le fasi byte o loʻo aoga UTF-8, ma e te le manaʻo e faʻatupuina i luga o le siaki aoga, o loʻo i ai se le saogalemu faʻamaumauga o lenei gaioiga, [`from_utf8_unchecked`], e i ai le tutusa amioga ae faʻaseʻeina le siaki.
///
///
/// Afai e te manaʻomia se `String` nai lo le `&str`, mafaufau i le [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Talu ai e mafai ona e faʻaputu-tuʻuina atu se `[u8; N]`, ma e mafai ona e aveina se [`&[u8]`][byteslice], o lenei gaioiga o se tasi auala e maua ai se faʻasologa tuʻufaʻatasia.E i ai se faʻataʻitaʻiga o lenei i le faʻataʻitaʻiga vaega i lalo.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Faafoi `Err` pe afai o le fasi e le UTF-8 ai ma se faamatalaga i le mafuaaga fasi tuuina atu e le UTF-8.
///
/// # Examples
///
/// Faʻaaoga faʻavae:
///
/// ```
/// use std::str;
///
/// // nisi bytes, i totonu o le vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Matou te iloa o nei bytes e aoga, o lea ia faʻaaoga le `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Sese paita:
///
/// ```
/// use std::str;
///
/// // ni paita le aoga, ile vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Vaʻai tusitusiga mo [`Utf8Error`] mo nisi faʻamatalaga i luga o ituaiga o mea sese e mafai ona toe faʻafoʻi mai.
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // nisi bytes, i se autau faasoasoa-faaputuga
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Matou te iloa o nei bytes e aoga, o lea ia faʻaaoga le `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // SAFETI: Na o le faʻamoeina faʻamaonia.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Tagata liliu mai se fasi mutable o bytes i se fasi manoa mutable.
///
/// # Examples
///
/// Faʻaaoga faʻavae:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" pei o se suia vector
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // A o matou iloa o nei bytes e aoga, e mafai ona tatou faʻaaogaina `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Sese paita:
///
/// ```
/// use std::str;
///
/// // O ni paita le aoga i le vector e mafai ona suia
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Vaʻai tusitusiga mo [`Utf8Error`] mo nisi faʻamatalaga i luga o ituaiga o mea sese e mafai ona toe faʻafoʻi mai.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // SAFETI: Na o le faʻamoeina faʻamaonia.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Liliu a fasi o bytes i se fasi manoa e aunoa ma le siakiina o le manoa o loo aloaia UTF-8.
///
/// Vaʻai le saogalemu kopi, [`from_utf8`], mo nisi faʻamatalaga.
///
/// # Safety
///
/// O lenei gaioiga e le saogalemu ona e le siakiina pe o le pasi na pasi ia te ia e moni UTF-8.
/// A faʻapea e solia lenei taofiofiga, e le faʻamatalaina amio faʻaiuga, ona o le toega o le Rust manatu o [`&str`] s e aoga UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Faʻaaoga faʻavae:
///
/// ```
/// use std::str;
///
/// // nisi bytes, i totonu o le vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // SAFETY: o le tagata telefoni e tatau ona mautinoa o bytes `v` o UTF-8 aoga.
    // Faamoemoe foi i le `&str` ma le `&[u8]` i le tutusa faʻatulagaina.
    unsafe { mem::transmute(v) }
}

/// Faʻaliliuina se fasi bytes i se manoa fasi e aunoa ma le siakiina o le manoa aofia ai UTF-8 talafeagai;lomiga suia
///
///
/// Vaʻai le le suia, [`from_utf8_unchecked()`] mo nisi faʻamatalaga.
///
/// # Examples
///
/// Faʻaaoga faʻavae:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // SAFETY: o le tagata telefoni e tatau ona mautinoa o le bytes `v`
    // e aoga UTF-8, o lea o le lafo i `*mut str` e saogalemu.
    // E le gata i lea, o le faʻasino tusi e saogalemu aua o lena faʻasino tusi e sau mai se faʻasino lea e mautinoa e aoga mo tusitusiga.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}