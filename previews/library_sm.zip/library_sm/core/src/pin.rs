//! Ituaiga e faʻapipiʻi faʻamaumauga i lona tulaga i manatua.
//!
//! E aoga i nisi taimi le iai o mea faʻamaonia e le minoi, i le uiga e le suia le latou tuʻuina i mea e manatua ai, ma mafai ai ona faʻamoemoeina.
//! O se faʻataʻitaʻiga sili o lea ituaiga vaaiga o le a fausiaina ni auala e taua ai ia oe lava, e pei o le minoi o se mea ma ni ona faailoga ia te ia lava, o le a faaleaogaina ai ia amioga, ma e ono mafua ai ni amioga le mautinoa.
//!
//! I se tulaga maualuga, e faamautinoa a [`Pin<P>`] o le pointee o so o se faasino ituaiga `P` ei ai se nofoaga mautu i manatua, o lona uiga e le mafai ona siitia i se isi nofoaga ma e le mafai ona deallocated ona manatua seia oo ina e oo atu maligi.Matou te fai atu o le pointee o "pinned".maua le iloa tele mea pe a talanoaina ituaiga o TUUFAATASI faamau ma faamatalaga faamau-lē;[see below](#projections-and-structural-pinning) mo nisi auiliiliga.
//!
//! I le faaletonu, o ituaiga uma i le Rust e minoi.
//! Rust faʻatagaina pasia uma ituaiga i-aoga, ma masani poto-faʻasino ituaiga ituaiga e pei o [`Box<T>`] ma `&mut T` faʻatagaina suia ma feʻaveaʻiga le taua o loʻo iai: e mafai ona e alu ese mai le [`Box<T>`], pe mafai ona e faʻaaogaina [`mem::swap`].
//! [`Pin<P>`] wraps a faʻasino ituaiga `P`, ina ['Pin`]' <'[' Box`] '<T>> `gaioiga pei o se masani
//!
//! [`Box<T>`]: when a [`Pin``] <<[`Pusa`] '<T>> `` pa'ū i lalo, faʻapena foi ona faia mea, ma le manatua manatuaina
//!
//! fetuutuunaiE faʻapea foi, [`Pin`]`<&mut T>` e tai pei lava o `&mut T`.Ae ui i lea, [`Pin<P>`] e le faʻatagaina tagata faʻatau maua moni se [`Box<T>`] poʻo le `&mut T` e faʻapipiʻi ai faʻamaumauga, o lona uiga e le mafai ona e faʻaaogaina gaioiga pei o [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` manaomia `&mut T`, ae le mafai ona tatou maua ai.
//!     // Ua matou mau, e le mafai ona fesuiaʻi mea o loʻo i totonu ma nei faʻamatalaga.
//!     // E mafai ona matou faʻaaogaina le `Pin::get_unchecked_mut`, ae e le sefe lena mo se mafuaaga:
//!     // e le faʻatagaina matou ona faʻaogaina mo le aveina o mea mai le `Pin`.
//! }
//! ```
//!
//! E taua le toe taʻua o [`Pin<P>`] e le *suia* le mea moni e faʻapea o le Rust compiler e manatu i ituaiga uma e feʻaveaʻi.[`mem::swap`] tumau ona valaʻau mo soʻo se `T`.Nai lo lena, [`Pin<P>`] puipuia nisi *taua*(tusitusi lima e faʻasino i le [`Pin<P>`]) mai le minoi e ala i le le mafai ona valaʻau metotia e manaʻomia `&mut T` ia latou (pei o [`mem::swap`]).
//!
//! [`Pin<P>`] mafai ona faaaogaina e afifi o so o se faasino ituaiga `P`, ma faapena ai interacts ma [`Deref`] ma [`DerefMut`].A [`Pin<P>`] mea e tatau ona manatu `P: Deref` o se "`P`-style pointer" i se `P::Target` faamau-o lea, o se ['Pin`]' <'[' Box`] '<T>> 'O se umia e faasino i se `T` faamau, ma a [' Pin`] '<' ['Rc`]'<T>> `o se faʻasino faasino-faitau faʻasino i se pin `T`.
//! Mo le saʻo, [`Pin<P>`] faʻamoemoe i le faʻatinoina o [`Deref`] ma [`DerefMut`] aua le alu ese mai a latou `self` parakalafa, ma naʻo taimi uma e toe faʻafoʻi mai ai se faʻasino i pine faʻamatalaga pe a valaauina i latou i luga o se pine faʻasino.
//!
//! # `Unpin`
//!
//! Tele o ituaiga e masani ona feʻaveaʻiga saoloto, e tusa lava pe oomiina, aua latou te le faʻamoemoe i le i ai o se mautu tuatusi.E aofia ai ituaiga masani uma (pei o [`bool`], [`i32`], ma faʻasino) faʻapea foʻi ma ituaiga e aofia ai na o nei ituaiga.O ituaiga e le popole e uiga i le pineina oomi faʻaoga le [`Unpin`] auto-trait, lea e faʻaleaogaina le aafiaga o le [`Pin<P>`].
//! Mo `T: Unpin`, [`Pin`]`<`[`Box`] `<T>>`ma [`Box<T>`] gaioiga tutusa, pei ona faia [`Pin`] `<&mut T>` ma `&mut T`.
//!
//! Manatua e pinning ma [`Unpin`] na aafia ai le faasino-e taina `P::Target`, e le o le ituaiga e faasino `P` lava lena ua ma afifi i [`Pin<P>`].Mo se faʻataʻitaʻiga, pe o le [`Box<T>`] o le [`Unpin`] e leai sona aʻafiaga i amioga a le [`Pin`]`<`['Box`]'<T>>`(iinei, `T` o le faʻasino lima-i le ituaiga).
//!
//! # Faʻataʻitaʻiga: oe lava-referential faʻavae
//!
//! Ae tatou te leʻi alu i nisi auiliiliga o faʻamatalaga e uiga i faʻamaoniga ma filifiliga fesoʻotaʻi ma `Pin<T>`, matou te talanoaina ni faʻataʻitaʻiga pe faʻafefea ona faʻaaogaina.
//! Lagona saoloto e [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // O lenei o se lava-referential faʻatulagaina aua o le fasi fasi fanua faʻasino i le faʻamatalaga fanua.
//! // E le mafai ona logoina le tuufaatasia e uiga i lena ma se faasinomaga e masani ai, e pei ona le mafai ona faamatalaina i lenei mamanu i le tulafono nonogatupe masani ai.
//! //
//! // Nai lo tatou faaaogaina a faasino ai mata, e ui lava o se tasi ua iloa e le e ona soloia, e pei ona tatou iloa o le faasino i le manoa.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Ina ia mautinoa e le minoi faʻamatalaga pe a toe foʻi mai le gaioiga, tatou te tuʻuina i le faʻaputuga o le a tumau ai mo le olaga atoa o le mea, ma na o le pau lava le auala e faʻaaogaina ai o le ala i le faʻasino i ai.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // tatou te faia le faasino faʻatasi le faamatalaga o loo i nofoaga ese o le a ua uma ona siitia ae tatou te lei amata lava
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // matou te iloa e sefe lenei mea aua o le fesuiaʻiina o se fanua e le minoi ai le atoa faʻavae
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // E tatau ona tusi le faʻasino i le nofoaga saʻo, pe a le minoi le faʻavae.
//! //
//! // Le taimi nei, ua tatou saoloto e agai i le e faasino ai.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Talu ai e le faatino o lo tatou ituaiga Unpin, o le a toilalo lenei e tuufaatasia:
//! // tuu mut new_unmove= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Faʻataʻitaʻiga: faʻasolosolo faʻalua-fesoʻotaʻi lisi
//!
//! I se faʻalavelave faʻafuaseʻi fesoʻotaʻi faʻalua, o le aoina e le faʻavasegaina moni le manatuaina mo elemene lava ia.
//! Allocation e pulea e le au faʻatau, ma elemene mafai ona ola i luga o le faaputuga faʻavae e ola puʻupuʻu nai lo le aoina faia.
//!
//! Ina ia faia lenei galuega, o elemeni uma ei ai faʻasino i lona muamua ma le sui i le lisi.faatoa mafai lava ona faaopoopo Elemene pe a faamau i latou, ona alu le elemene o loo siomia ai le a faaleaogaina ai le vae.Lē gata i lea, o le faatinoga [`Drop`] o se elemene lisi fesootai a fonofono i vae o ona muamua ma sui e aveesea lava mai le lisi.
//!
//! Taua, e tatau ona tatou faʻamoemoe i le [`drop`] ua valaauina.Afai o se elemene mafai ona faʻamavaeina pe i se isi itu e le faʻamamaina e aunoa ma le valaauina [`drop`], o le faʻailoga i totonu mai ona tuaoi elemeni o le a le aoga, lea o le a talepeina ai faʻamaumauga faʻavae.
//!
//! Ole mea lea, pinning e sau foʻi ma le [`drop`]-fesoʻotaʻi mautinoa.
//!
//! # `Drop` guarantee
//!
//! O le mafuaʻaga o le pineina o le mafai ona faʻalagolago i le faʻatulagaina o nisi faʻamatalaga i le mafaufau.
//! Ina ia faia lenei galuega, e le na o le minoi o faʻamatalaga e faʻatapulaʻaina;fetuutuunaʻi, toefaʻaleleia, pe i se isi itu le faʻamaonia le manatuaina na faʻaaoga e teu ai faʻamatalaga e faʻatapulaʻaina foi.
//! Concretely, mo faamau faamatalaga e tatau ona e tausia le invariant e *a le ona faalēaogāina lona manatua po o repurposed mai le taimi e oo atu ai e faamau seia oo ina ua taʻua [`drop`]*.E tasi le [`drop`] toe foʻi mai poʻo le panics, e ono toe faʻaaoga le mafaufau.
//!
//! e mafai ona avea "invalidated" e deallocation manatua, ae faapea foi i le suia a [`Some(v)`] e [`None`], po o le valaauina [`Vec::set_len`] e "kill" nisi elemene ese o se vector.E mafai ona repurposed ala i le faaaogaina [`ptr::write`] e overwrite e aunoa ma le valaau atu muamua le destructor.E leai se mea e faʻatagaina mo le faʻailogaina o faʻamatalaga e aunoa ma le valaʻau o le [`drop`].
//!
//! O le ituaiga tonu lenei o faamaoniga o le intrusive fesootai lisi mai le vaega muamua e manaomia ai galuega tauave saʻo.
//!
//! Matau o lenei faamaoniga e le *le* o lona uiga o le manatuaina e le paʻu!E le o lava atoatoa afaina le pea e valaau [`drop`] i luga o se elemene faamau (eg, e mafai ona e valaau pea [`mem::forget`] i se ['Pin`]' <'[' Box`] '<T>> `).I le faataitaiga o le lisi fesootai-faaluaina, o le elemene o le a na o le tumau i le lisi.Ae peitai e mafai e le saoloto po o le toe faʻaaogā le teuina * e aunoa ma le valaau atu ['drop`].
//!
//! # `Drop` implementation
//!
//! Afai o lau ituaiga faʻaaogaina pineina (pei o faʻataʻitaʻiga e lua i luga), oe tatau ona faʻaeteete pe a faʻaogaina [`Drop`].O le [`drop`] gaioiga e manaʻomia le `&mut self`, ae o le mea lea e taʻu o le *e tusa lava pe na muamua faapipiina lou ituaiga*!E pei lava o le faʻapipiʻi e otometi lava ona taʻua o le [`Pin::get_unchecked_mut`].
//!
//! E le mafai ona tupu se faʻafitauli ile saogalemu code aua o le faʻaogaina o se ituaiga e faʻamoemoe ile pine e manaʻomia le sefe code, ae ia e mataala ile filifili e faʻaaoga le pine i lau ituaiga (mo se faʻataʻitaʻiga e ala i le faʻatinoina o nisi faʻagaioiga i luga o le "'Pin`]"<&Self>`poʻo le [`Pin`] `<&mut Self>`) e iai foʻi iʻuga mo lau faʻatinoga [`Drop`]: pe ana fai e mafai ona faʻamau le elemeni o lau ituaiga, e tatau ona e togafitia le [`Drop`] e pei o le faʻaaogaina o le 'Pin'] `<&mut Oe lava>`.
//!
//!
//! Mo se faʻataʻitaʻiga, e mafai ona e faʻaaogaina le `Drop` e faʻapea:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` e le afaina aua ua tatou iloa o lenei taua e le toe faʻaaogaina pe a uma ona paʻu i lalo.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // O le mea moni pa'ū code alu iinei.
//!         }
//!     }
//! }
//! ```
//!
//! O le gaioiga `inner_drop` ei ai le ituaiga e tatau ona i ai [`drop`] *, o lea ia mautinoa ai e te le faʻafuaseʻi ona faʻaaoga `self`/`this` i se auala o loʻo feteʻenaʻi ma pine.
//!
//! Gata i lea, pe afai o outou ituaiga o `#[repr(packed)]`, o le a otometi lava ona agai i le tuufaatasia fanua o loo siomia ai ina ia mafai ona aveesea i latou.Atonu e mafai foi ona faia lena mea mo fanua ia e foliga mai e fetaui lelei.O se taunuuga, e le mafai ona faaaogaina pinning ma se ituaiga `#[repr(packed)]`.
//!
//! # Faʻamatalaga ma Faʻamau Fausaga
//!
//! A o e galue ma faʻamau faʻamau, o le fesili e tulaʻi mai pe faʻafefea e se tasi ona ulufale i fanua o lena fausaga i se metotia e naʻo le (`Pin`]`<&mut Struct>`.
//! O le masani masani o le tusia o fesoasoani fesoasoani (lea e taʻua o * faʻataʻitaʻiga) e liliu ai le (`Pin`]`<&mut Struct> 'i se faʻasino i le fanua, ae o le a le ituaiga e tatau ona i ai lena faʻasino?E ['Pin`]' <&mut Field> 'po o `&mut Field`?
//! O le fesili lava e tasi e tulaʻi mai ma fanua o le `enum`, ma faʻapea foi pe a mafaufau i container/wrapper ituaiga e pei o [`Vec<T>`], [`Box<T>`], poʻo [`RefCell<T>`].
//! (O lenei fesili e faatatau i mutable ma faasoa uma mau, na ona tatou faaaogaina le tulaga masani o le mau mutable iinei mo le ata.)
//!
//! E faʻapea o le mea moni lava e oʻo i le tusitala o faʻamaumauga faʻavae e filifili ai pe o le faʻaosoina o le faʻamoemoe mo se faʻapitoa fanua liliuina [`Pin`]`<&mut Struct> 'i le [' Pin`] `<&mut Field>` poʻo `&mut Field`.E i ai ni faʻafitauli e ui lava, ma o le mea sili ona taua faʻataʻitaʻi o le *tumau*:
//! e mafai ona fanua uma *pe* fana e se faasinomaga faamau,*po o* ua pinning aveesea o se vaega o le fuafuaga.
//! Afai e faia uma mo le fanua e tasi, atonu o le a le lelei!
//!
//! E pei o le tusitala o se faamatalaga fausaga e te maua e filifili mo fanua taitasi pe pinning "propagates" i lenei fanua pe leai.
//! O le pine e faʻapipiʻi e taʻua foi o le "structural", aua e mulimuli i le faʻavae o le ituaiga.
//! I le faafuaiupu e faapea, e faamatala ai le manatu o loo i ai ina ia faia mo soo se filifiliga.
//!
//! ## Pinning *e le* fausaga mo `field`
//!
//! E foliga mai e feteʻenaʻi, o le fanua o le pine pine e le mafai ona faʻapipiʻiina, ae o le filifiliga faigofie lava lea: afai e le faia se ['Pin`]`<&mut Field>', e leai se mea e sese.Ma, afai e te filifili o nisi fanua e leai ni fausaga pinning, na o le pau le mea e te mautinoa ai o le aua neʻi faia se pine faʻasino i lena fanua.
//!
//! Fanua e aunoa ma le faʻatulagaina o pinina atonu e i ai se auala fuafuaina e liliu ai le [`Pin`]` <&mut Struct> 'i le `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // E le afaina lenei mea ona o le `field` e le taitai ona pineina.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! E mafai foi `impl Unpin for Struct`*e tusa lava pe* le ituaiga o `field` e le [`Unpin`].O le a le mea e manatu ai e uiga i le pineina o le pine e le talafeagai pe a leai se [`Pin`]` <&mut Field> 'e faia lava.
//!
//! ## Pinning *o* faʻavae mo `field`
//!
//! O leisi filifiliga o le filifili o le pineina o le "structural" mo le `field`, o lona uiga afai e faʻamau le faʻavae e faʻapea foi le fanua.
//!
//! O lenei faʻatagaina le tusiaina o se aiaiga e faia ai se [`Pin`]`<&mut Field>`, o lea ua molimauina ai o le fanua ua pine
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // E le afaina lenei mea ona o le `field` o le pinini pe a `self` o.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Ae ui i lea, o fausaga fausaga e sau ma ni nai faʻaopopo manaʻoga:
//!
//! 1. O le faʻavae e tatau ona naʻo le [`Unpin`] peʻa fai o le fausaga uma o le [`Unpin`].Lenei o le faaletonu, ae o le [`Unpin`] o se saogalemu trait, o lea la o le tusitala o le auivi o lou tiute lea *le* faʻaopopo se mea e pei o `impl<T> Unpin for Struct<T>`.
//! (Faasilasilaga o le faaopoopoina o se faagaoioiga fuafuaga e manaomia ai le tulafono saogalemu, o lea o le mea moni e faapea [`Unpin`] o se saogalemu e le solia trait le mataupu faavae e na o maua e popole e uiga i se tasi o lenei mea pe afai e te faaaogaina 'unsafe`.)
//! 2. O le faʻaleagaina o le fausaga e le tatau ona aveʻesega faʻafanua fanua mai lana finauga.Ole sao tonu lea na laga ile [previous section][drop-impl]: `drop` ave `&mut self`, ae ole faʻatulagaina (ma le mea lea o ona fanua) atonu na faapipii muamua.
//!     E tatau ona e mautinoa e te le gaioi se fanua i totonu o lau [`Drop`] faʻatinoga.
//!     Ae maise lava, pei ona faʻamatalaina muamua, o lona uiga o lau fausaga e tatau *aua* e avea `#[repr(packed)]`.
//!     Tagai i lea fuaiupu i le auala e tusia [`drop`] i se auala e mafai ona fesoasoani i le tuufaatasia e le faafuasei solia pinning.
//! 3. Oe tatau ona mautinoa ia e lagolagoina le [`Drop` guarantee][drop-guarantee]:
//!     le taimi lava e faamau outou fausia, o le manatua o loo i ai le mataupu e le o overwritten po deallocated e aunoa ma le valaau atu destructors o le anotusi.
//!     Lenei mafai ona faigata, pei ona molimauina e [`VecDeque<T>`]: o le faʻaleagaina o [`VecDeque<T>`] mafai ona le mafai ona valaʻau [`drop`] i luga o elemeni uma pe a fai o se tasi o faʻaleagaina panics.Lenei solia le [`Drop`] mautinoa, aua e mafai ona taʻitaʻia ai elemeni o feutanaʻi e aunoa ma le latou faʻaumatia valaʻauina.([`VecDeque<T>`] e leai ni faʻamatalaga faʻaopoopo, o lenei e le mafua ai unsoundness.)
//! 4. Oe le tatau ona ofoina atu soʻo se isi gaioiga e ono taitai atu ai i faʻamatalaga aveina mai i fafo o le fausaga fanua pe a o lau ituaiga o pine.Mo se faʻataʻitaʻiga, afai o le faʻavae e i ai le [`Option<T>`] ma o loʻo i ai le 'ave'-pei o le faʻagaioiga ma le ituaiga `fn(Pin<&mut Struct<T>>) -> Option<T>`, o lena faʻagaioiga e mafai ona faʻaaogaina e aveese ai le `T` mai se pinini `Struct<T>`-o lona uiga o le pine e le mafai ona fausiaina mo le fanua o loʻo taofia lenei faʻamaumauga
//!
//!     Mo se faataitaiga sili atu ona faigata o le agai i faamatalaga mai i se ituaiga faamau, mafaufau pe afai sa [`RefCell<T>`] se metotia `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Ona e mafai ona tatou faia mea nei:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     O lenei mea mataʻutia, o lona uiga e mafai ona tatou muamua faʻapipiʻi le aano o le [`RefCell<T>`] (faʻaaogaina o le `RefCell::get_pin_mut`) ona faʻasolo atu lea o le mataupu i le faʻaogaina o le fetuutuunai o faʻamatalaga na tatou mauaina mulimuli ane.
//!
//! ## Examples
//!
//! Mo se ituaiga e pei o [`Vec<T>`], o avanoa uma (fausaga pinning pe leai) talafeagai.
//! O le [`Vec<T>`] ma le fausagaina pine e mafai ona i ai ni `get_pin`/`get_pin_mut` metotia e maua ai pine faʻamau i elemeni.Ae ui i lea, e le mafai *faʻatagaina* valaʻau [`pop`][Vec::pop] i luga o le pinini [`Vec<T>`] ona o le a minoi ai le (tino faʻamau) mea i totonu!E le mafai foi ona faʻatagaina le [`push`][Vec::push], lea e ono toe faʻatonuina ma faʻapea foi ona minoi mea i totonu.
//!
//! A [`Vec<T>`] aunoa pinning fausaga mafai `impl<T> Unpin for Vec<T>`, aua o le mataupu e le mafai ona faamau ma le [`Vec<T>`] lava ia o le lelei ma le faagaeetia faapea.
//! Ile taimi la e leai se aʻafiaga ole pinning ile vector.
//!
//! I totonu o le faletusi masani, o ituaiga faʻasino foliga e masani ona leai ni fausaga faʻamau, ma o lea latou te le ofaina pine pine.O le mafuaaga lea o lo o umia `Box<T>: Unpin` mo uma `T`.
//! E maua ai le uiga e faia lenei mea mo ituaiga e faasino ai, ona siitia e le moni lava agai i le `Box<T>` le `T`: mafai ona saoloto e mafai ona feaveai le [`Box<T>`] (aka `Unpin`) e ui lava pe afai o le `T` e leai.O le mea moni, e oo lava ['Pin`]' <'[' Box`] '<T>> 'Ma [' Pin`] '<&mut T>' pea [`Unpin`] i latou lava, ona o le mafuaaga lava lea e tasi: o latou mataupu (o le `T`) ua faamau, ae o le vae i latou lava e mafai ona siitia e aunoa ma le agai i le faamatalaga faamau.
//! Mo uma [`Box<T>`] ma [`Pin`]`<`['Pusa`]`<T>> `, pe o le mea o loʻo faʻamau i totonu e matua tutoʻatasi lava pe o le faʻasino faʻailoga, o lona uiga ole pine ole *e le* faʻavae.
//!
//! Ina ua le faatinoina o se [`Future`] combinator, o le ae masani lava ona manaomia pinning faatulagaga mo le faatietie leisi futures, e pei ona e manaomia ona faamau mau ia i latou e valaau [`poll`].
//! Ae afai o lau combinator o loʻo i ai isi isi faʻamatalaga e le manaʻomia e pine, oe mafai ona faia na fanua e le faʻatulagaina ma o lea e saoloto ulufale ai ia i latou ma se suia suia faʻamatalaga e tusa lava pe a naʻo oe ['Pin`]"&Mut Self>' (faʻapea pei o lau oe [`poll`] faʻatinoina).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// O se pine faʻamau
///
/// Lenei o se afifi faʻataʻamilomilo se ituaiga o faʻailoga e faia ai lena faasino upu "pin" lona taua i le nofoaga, puipuia le taua taua e lena faʻasino mai le faʻaseʻe seʻi vagana ua faʻaaogaina [`Unpin`].
///
///
/// *Vaʻai le [`pin` module] faʻamaumauga mo se faʻamatalaga o le pinina.*
///
/// [`pin` module]: self
///
// Note: o le `Clone` maua mai i lalo mafua ai unsoundness ona e mafai ona faʻatino
// `Clone` mo suia suia.
// Vaʻai <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> mo nisi faʻamatalaga.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// O faʻatinoga nei e le maua mai ina ia mafai ai ona aloese mai faʻafitauli lelei.
// `&self.pointer` e le tatau ona faʻaavanoaina i le le faʻatuatuaina trait faʻatinoga.
//
// Vaʻai <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> mo nisi faʻamatalaga.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Fausia se `Pin<P>` fou faataamilo i se faʻasino i ni faʻamatalaga o se ituaiga e faʻaaogaina [`Unpin`].
    ///
    /// E le pei o `Pin::new_unchecked`, o lenei metotia e saogalemu aua o le faʻasino tusi `P` faʻaleaʻogaina i se [`Unpin`] ituaiga, lea e faʻaleaogaina le pine pine.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // SAFETY: o le taua faʻasino i le `Unpin`, ma e leai ni manaʻoga
        // faataamilo pine.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Unwraps toe foi lenei `Pin<P>` le faasino autu.
    ///
    /// O lenei mea e manaʻomia ai o faʻamatalaga o loʻo i totonu o lenei `Pin` o le [`Unpin`] ina ia mafai ai ona tatou le amanaʻia le aufaʻatasi o loʻo tautau peʻa tatalaina.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Fausia se `Pin<P>` fou faataamilo i se faʻasino i ni faʻamatalaga o se ituaiga e mafai pe le faʻaogaina `Unpin`.
    ///
    /// Afai `pointer` dereferences i se ituaiga `Unpin`, e tatau ona faaaogaina nai lo `Pin::new`.
    ///
    /// # Safety
    ///
    /// O lenei fausia e le sefe aua e le mafai ona tatou mautinoa o le faʻamatalaga na faʻasino e le `pointer` ua uma ona faapipiʻi, o lona uiga e le masii ese faʻamaumauga pe faʻamamaina lona teuina seʻi vagana ua paʻu.
    /// Afai o le fausiaina `Pin<P>` e le o mautinoa o le faʻamaumauga `P` manatu i ai o pine, o le solia o le API konekarate ma ono taitai atu ai i le le faʻamatalaina amioga i mulimuli ane (safe) gaioiga.
    ///
    /// I le faʻaaogaina o lenei metotia, o loʻo e faia le promise e uiga i le `P::Deref` ma le `P::DerefMut` faʻatinoga, pe a fai o iai.
    /// O le mea e sili ona taua, e le tatau ona latou o ese mai a latou finauga `self`: `Pin::as_mut` ma `Pin::as_ref` o le a valaʻau i le `DerefMut::deref_mut` ma le `Deref::deref`*i luga o le pine pininter* ma faʻamoemoe o nei metotia e lagolagoina ai le pineina o vili.
    /// E le gata i lea, e ala i le valaʻauina o lenei metotia oe promise o le faʻasino `P` faʻateʻaina e le toe aveʻesea mai le toe;ae maise lava, e le tatau ona mafai ona maua se `&mut P::Target` ona alu ese lea mai le faʻasino (faʻaaoga, mo se faʻataʻitaʻiga [`mem::swap`]).
    ///
    ///
    /// Mo se faataitaiga, valaau `Pin::new_unchecked` i luga o se `&'a mut T` o le saogalemu ona ao e mafai ona e pine mo le olaga atoa tuuina `'a`, e leai pulea pe sa teuina e faamau faatasi tuluiga `'a`:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // O lona uiga o le pointee `a` e le mafai ona toe minoi.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // O le tuatusi o le `a` na suia i le "b`'s stack slot, o lea na minoi ai `a` e ui lava na matou faʻamauina muamua!Ua tatou solia le konekarate pinning API.
    /////
    /// }
    /// ```
    ///
    /// O le tau, e tasi le pine, e tatau ona faʻamau i luga e faʻavavau (seʻi vagana o lona ituaiga e faʻaaogaina `Unpin`).
    ///
    /// E faʻapena foi, valaʻau `Pin::new_unchecked` i luga o le `Rc<T>` e le sefe aua e ono i ai ni igoa faʻasolosolo i le faʻamatalaga lava e tasi e le o noatia i le faʻatapulaʻaina o pinning:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // O lona uiga o le pointee e le mafai ona toe minoi.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // O lenei, afai `x` o le mau na, ua tatou maua ai se faasinomaga mutable i faamatalaga o le a tatou e faamau i luga, lea e mafai ona tatou faaaogaina e agai i ai e pei ona tatou vaai i ai i le faataitaiga muamua.
    ///     // Ua matou solia le konesina API faʻaoso.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Maua se faamau faasinomaga faasoa mai lenei e faasino faamau.
    ///
    /// Lenei o se lautele auala e alu ai mai `&Pin<Pointer<T>>` i le `Pin<&T>`.
    /// E sefe talu ai, o se vaega o le konekarate a le `Pin::new_unchecked`, e le mafai ona minoi le pointee i le maeʻa ai ona faia o le `Pin<Pointer<T>>`.
    ///
    /// "Malicious" O le faʻaaogaina o `Pointer::Deref` e faʻapea foi ona teʻena e le konekalate o le `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // SAFETI: vaʻai faʻamaumauga i luga o lenei galuega
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Unwraps toe foi lenei `Pin<P>` le faasino autu.
    ///
    /// # Safety
    ///
    /// O lenei galuega e le saogalemu.Oe tatau ona mautinoa o le a faʻaauau pea ona e togafitia le faʻasino `P` pei o pine i le maeʻa ai ona e valaʻau lenei gaioiga, ina ia mafai ai ona faʻamalosia tagata na siakiina le `Pin` ituaiga.
    /// Afai o le numera faʻaaogaina le mafuaʻaga `P` e le faʻaauau ona tausia le pinning invariants o se soliga o le API konekarate ma ono taitai atu ai i le le faʻamatalaina amioga i mulimuli ane (safe) gaioiga.
    ///
    ///
    /// Afai o faʻamatalaga taua o [`Unpin`], e tatau ona faʻaaoga le [`Pin::into_inner`] nai lo lena.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Mauaina se faʻamatalaga suia suia mai lenei pine faʻamau.
    ///
    /// Lenei o se lautele auala e alu ai mai `&mut Pin<Pointer<T>>` i le `Pin<&mut T>`.
    /// E sefe talu ai, o se vaega o le konekarate a le `Pin::new_unchecked`, e le mafai ona minoi le pointee i le maeʻa ai ona faia o le `Pin<Pointer<T>>`.
    ///
    /// "Malicious" O le faʻaaogaina o `Pointer::DerefMut` e faʻapea foi ona teʻena e le konekalate o le `Pin::new_unchecked`.
    ///
    /// O lenei metotia e aoga pe a faia tele telefoni i gaioiga e faʻaumatia le pine pine ituaiga.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // fai se mea
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` faʻaumatia le `self`, ia toe faʻatumu le `Pin<&mut Self>` e ala ile `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // SAFETI: vaʻai faʻamaumauga i luga o lenei galuega
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Tofia se mea taua fou i le mafaufau i tua atu o le pine faʻasino.
    ///
    /// O lenei overwrites faamau faamatalaga, ae e le afaina: e oo atu taufetuli lona destructor i luma o le overwritten, e leai se pinning faamaoniga ua solia.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Fausia se pine fou e ala i le faʻafanuaina o le tau i totonu.
    ///
    /// Mo se faataitaiga, afai e te manao ia i ai se `Pin` o se fanua o se mea, e mafai ona e faaaogaina lenei e maua ai le avanoa i le fanua i se tasi o laina o code.
    /// Ae peitai, o loo i ai le tele o gotchas ma nei "pinning projections";
    /// vaʻai i le [`pin` module] faʻamaumauga mo nisi faʻamatalaga i luga o lena autu.
    ///
    /// # Safety
    ///
    /// O lenei galuega e le saogalemu.
    /// E tatau ona mautinoa e faapea o le faamatalaga e toe foi o le a agai i le umi e le agai i le taua finauga (mo se faataitaiga, talu ai ona o se tasi o fanua o lena taua), ma foi e te le agai i fafo o le finauga e te maua e o le galuega tauave totonu.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // SAOGALEMU: o le e tatau ona saogalemu konekarate mo `new_unchecked`
        // lagolagoina e ala i le telefoni.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Maua se faʻasoa faʻamatalaga mai se pine.
    ///
    /// E sefe le mea lea ona e le mafai ona alu ese mai se faʻasoa faʻasoa.
    /// E foliga mai o loʻo iai se faʻafitauli iinei ma le suia i totonu o le fale: o le mea moni, e *mafai* ona aveese se `T` mai le `&RefCell<T>`.
    /// Ae ui i lea, e le o se faʻafitauli lenei pe a le i ai se `Pin<&T>` faʻasino i le tutusa faʻamatalaga, ma `RefCell<T>` e le faʻatagaina oe e faia se pinned faʻasino i ona mataupu.
    ///
    /// Vaʻai le talanoaga ile ["pinning projections"] mo nisi faʻamatalaga.
    ///
    /// Note: `Pin` faʻapea foi ona faʻaaogaina `Deref` i le taulaʻiga, lea e mafai ona faʻaaogaina e faʻaaoga ai le tau i totonu.
    /// Ae ui i lea, `Deref` naʻo le faʻaaogaina o se faʻamatalaga e ola mo le umi e pei o le nonoina o le `Pin`, ae le o le olaga atoa o le `Pin` lava ia.
    /// O lenei metotia faʻatagaina le faʻaliliuina o le `Pin` i se faʻasino ma le olaga atoa e pei o le muamua `Pin`.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Faʻaliliu lenei `Pin<&mut T>` i totonu o le `Pin<&T>` ma le tutusa olaga.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Maua se mutable faʻasino i le faʻamatalaga i totonu o lenei `Pin`.
    ///
    /// Lenei manaʻomia o faʻamatalaga i totonu o lenei `Pin` o le `Unpin`.
    ///
    /// Note: `Pin` faʻapea foi ona faʻaaogaina `DerefMut` i faʻamaumauga, lea e mafai ona faʻaaogaina e faʻaaoga ai le tau i totonu.
    /// Ae ui i lea, `DerefMut` naʻo le faʻaaogaina o se faʻamatalaga e ola mo le umi e pei o le nonoina o le `Pin`, ae le o le olaga atoa o le `Pin` lava ia.
    ///
    /// O lenei metotia faʻatagaina le faʻaliliuina o le `Pin` i se faʻasino ma le olaga atoa e pei o le muamua `Pin`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Maua se mutable faʻasino i le faʻamatalaga i totonu o lenei `Pin`.
    ///
    /// # Safety
    ///
    /// O lenei galuega e le saogalemu.
    /// Oe tatau ona mautinoa o le a le mafai ona e aveʻesea le faʻamaumauga mai le fesuiaʻiga o faʻamatalaga e te mauaina pe a e valaʻau lenei gaioiga, ina ia mafai ai ona faʻamalosia tagata faʻasolosolo i le `Pin` ituaiga.
    ///
    ///
    /// Pe afai o le faamatalaga faavae o `Unpin`, e tatau ona faaaogaina nai lo `Pin::get_mut`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Fausia se pine fou i le faʻafanuaina o le tau i totonu.
    ///
    /// Mo se faataitaiga, afai e te manao ia i ai se `Pin` o se fanua o se mea, e mafai ona e faaaogaina lenei e maua ai le avanoa i le fanua i se tasi o laina o code.
    /// Ae peitai, o loo i ai le tele o gotchas ma nei "pinning projections";
    /// vaʻai i le [`pin` module] faʻamaumauga mo nisi faʻamatalaga i luga o lena autu.
    ///
    /// # Safety
    ///
    /// O lenei galuega e le saogalemu.
    /// E tatau ona mautinoa e faapea o le faamatalaga e toe foi o le a agai i le umi e le agai i le taua finauga (mo se faataitaiga, talu ai ona o se tasi o fanua o lena taua), ma foi e te le agai i fafo o le finauga e te maua e o le galuega tauave totonu.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // SAFETY: o le telefoni o le nafa ma le le minoi o le
        // taua mai lenei faʻasino.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // SAFETY: pei o le taua o `this` ua mautinoa e leai
        // ua aveʻesea, o lenei valaʻau i le `new_unchecked` e saogalemu.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Maua se faʻamatalaga faʻamau mai se faʻailoga mautu.
    ///
    /// E sefe le mea lea, aua `T` nonoina mo le `'static` olaga atoa, e le uma.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // SAFETY: O le 'static loan e mautinoa ai o le a le avea faʻamatalaga
        // moved/invalidated seʻia paʻu ifo (ia e leai).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Maua se pinable mutable faʻasino mai se static mutable faʻasino.
    ///
    /// E sefe le mea lea, aua `T` nonoina mo le `'static` olaga atoa, e le uma.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // SAFETY: O le 'static loan e mautinoa ai o le a le avea faʻamatalaga
        // moved/invalidated seʻia paʻu ifo (ia e leai).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: o lona uiga o soʻo se impl o `CoerceUnsized` e faʻatagaina le faʻamalosi mai
// o se ituaiga e faʻaaogaina le `Deref<Target=impl !Unpin>` i se ituaiga e faʻaaoga `Deref<Target=Unpin>` e le lelei.
// Soʻo se mea faʻapena e ono le lelei mo isi mafuaʻaga, ae ui i lea, e tatau ona tatou faʻaeteete ia aua neʻi faʻatagaina ia mea e taunuʻu i le std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}