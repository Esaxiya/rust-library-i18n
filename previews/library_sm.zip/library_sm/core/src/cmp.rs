//! Functionality mo okaina ma faatusatusaga.
//!
//! Lenei module aofia ai mea faigaluega eseese mo le okaina ma le faʻatusatusaina o tulaga faatauaina.I le aotelega:
//!
//! * [`Eq`] ma [`PartialEq`] e traits e mafai ai ona e faauigaina tutusa atoa ma vaega i le va o tulaga faatauaina, faasologa.
//! Faʻaaogaina latou overloads le `==` ma `!=` faʻagaioiga.
//! * [`Ord`] ma [`PartialOrd`] o traits e faʻatagaina ai oe ona faʻauiga aofaʻiga ma faʻavaʻaʻesega faʻatulagaina i le va o tau, faʻatulagaina.
//!
//! Le faatinoina o latou overloads le `<`, `<=`, `>`, ma tagata e faagaoioia `>=`.
//! * [`Ordering`] o se enum toe faʻafoʻi mai e le autu galuega o [`Ord`] ma [`PartialOrd`], ma faʻamatalaina se okaina.
//! * [`Reverse`] o se faʻavae e faʻatagaina ai oe ona toe fesuiaʻi se okaina.
//! * [`max`] ma [`min`] o galuega tauave o le fausia ese o [`Ord`] ma mafai ai ona e maua le tapulaa maualuga po o le maualalo o tulaga faatauaina e lua.
//!
//! Mo nisi faamatalaga, tagai i le pepa taitasi o mea taitasi i totonu o le lisi.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait mo faʻatusatusaga tutusa ia e [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation).
///
/// O lenei trait faatagaina mo le tulaga tutusa vaega, mo ituaiga e le i ai se faasino equivalence atoa.
/// Mo se faataitaiga, i opeopea numera tulaga `NaN != NaN`, ina faatino ituaiga tulaga opeopea `PartialEq` ae le [`trait@Eq`].
///
/// Aloaia, le tulaga tutusa e tatau ona (mo uma `a`, `b`, `c` o ituaiga `A`, `B`, `C`):
///
/// - **Symmetric**: afai `A: PartialEq<B>` ma `B: PartialEq<A>`, ia **`a==b` faʻauiga`b==a`**;ma
///
/// - **Transitive**: afai `A: PartialEq<B>` ma `B: PartialEq<C>` ma 'A:
///   PartialEq<C>`, ona **` a==b`ma `b == c` faʻauiga`a==c`**.
///
/// Manatua o le e le o faamalosia `B: PartialEq<A>` (symmetric) ma `A: PartialEq<C>` (transitive) impls i ai, ae faaaoga nei manaoga i soo se taimi latou te faia ai.
///
/// ## Derivable
///
/// Lenei trait mafai ona faʻaaogaina ma `#[derive]`.A maua mai i luga o mea, e lua taimi e tutusa pe a tutusa uma fanua, ma e le tutusa pe a fai e le tutusa ni fanua.A o le "derive`d on enums, o ituaiga eseese e tutusa ia te ia lava ma e le tutusa ma isi suiga.
///
/// ## Mafai faapefea ona ou faatino `PartialEq`?
///
/// `PartialEq` na manaomia ai le auala [`eq`] ina ia faatinoina;ua faamatalaina [`ne`] i tuutuuga o le e ala i le faaletonu.So o se faatinoga tusi lesona o [`ne`]*tatau* faaaloalo i le tulafono o [`eq`] o se inverse saʻolele o [`ne`];o lona uiga, `!(a == b)` pe a naʻo `a != b`.
///
/// Faʻatinoina o `PartialEq`, [`PartialOrd`], ma [`Ord`]*tatau* malilie uma i le tasi.E faigofie lava ona faʻafuaseʻi ona latou le malie i le mauaina o nisi o le traits ma le faʻaogaina faʻatino o isi.
///
/// O se faʻataʻitaʻiga faʻatinoina mo se vaega e lua tusi o loʻo avea ma tusi e tasi pe a tutusa a latou ISBN, tusa lava pe eseʻese foliga.
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Mafai faapefea ona ou faatusatusa ituaiga eseese e lua?
///
/// O le ituaiga e mafai ona faatusatusa i lo o pulea e 'parameter ituaiga o PartialEq`.
/// Mo se faataitaiga, sei o lo matou fetuunaia o tatou code muamua se vaega:
///
/// ```
/// // O le maua meafaigaluega<BookFormat>==<BookFormat>faatusatusaga
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // faatino<Book>==<BookFormat>faatusatusaga
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // Faatino<BookFormat>==<Book>faatusatusaga
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// Ala i le suia `impl PartialEq for Book` e `impl PartialEq<BookFormat> for Book`, tatou te faatagaina 'BookFormat`s e faatusatusa i' Book`s.
///
/// O se faatusatusaga e pei o le tasi i luga, lea e le amanaia ni fanua o le fausia, e mafai ona matautia.E mafai ona taitai atu ai i se solia le fuafuaina o le manaʻoga mo se vaega tutusa tutusa.
/// Mo se faʻataʻitaʻiga, afai na matou tausia le faʻatinoina i luga o le `PartialEq<Book>` mo `BookFormat` ma faʻaopopoina le faʻaogaina o le `PartialEq<Book>` mo le `Book` (a le ala i le `#[derive]` pe ala mai i le faʻaogaina o tusi lesona mai le muamua faʻataʻitaʻiga) o lona uiga o le a solia ai le feaveaʻi:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// Lenei metotia tofotofoga mo `self` ma `other` taua ia tutusa, ma e faʻaaogaina e `==`.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// O lenei auala e tofotofoina mo `!=`.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// macro maua faatupuina se impl o le trait `PartialEq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait mo faatusatusaga tutusa ua [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation).
///
/// O lona uiga, e faʻaopoopo i le `a == b` ma le `a != b` o loʻo matuaʻi fesuiaʻi, e tatau ona tutusa le tutusa (mo `a`, `b` ma `c`) uma:
///
/// - reflexive: `a == a`;
/// - symmetric: faatatau `a == b` `b == a`;ma
/// - transitive: faatatau `a == b` ma `b == c` `a == c`.
///
/// e le mafai ona siakiina lenei meatotino e le na tuufaatasia, ma o lea `Eq` faatatau [`PartialEq`], ma e leai se auala faaopoopo.
///
/// ## Derivable
///
/// e mafai ona faaaoga lenei trait ma `#[derive]`.
/// A 'derive`d, ona e leai se `Eq` auala faaopoopo, ua na logoina ai le tuufaatasia o se faasino equivalence lenei nai lo le a faasino equivalence vaega.
///
/// Manatua o le `derive` taʻiala manaʻomia uma fanua e `Eq`, e le o taimi uma e manaʻomia.
///
/// ## Faʻafefea mafai ona ou faʻaaogaina `Eq`?
///
/// Afai e le mafai ona faaaogaina le fuafuaga `derive`, faamaoti o lou ituaiga meafaigaluega `Eq`, lea e leai se auala e:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // lenei auala e faaaoga faapitoa i#[deriving] e folafola atu e uma vaega o se ituaiga meafaigaluega#[deriving] lava ia, o le auala i le taimi nei atinae eseese deriving le faia o lenei folafolaga e aunoa ma faaaoga ai se metotia i lenei trait o toeitiiti le mafai.
    //
    //
    // O lenei e le tatau lava ona faatinoina e ala i le lima.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// Faʻatupuina makro faʻatupuina se impl o le trait `Eq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: o lenei faʻavae e naʻo le#[maua mai i le
// taʻutino atu o vaega uma o se ituaiga faʻaaogaina Eq.
//
// O lenei fausia le tatau lava ona faaali mai i le tagata e faaaogāina code.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// O se `Ordering` o le taunuuga o se faatusatusaga i le va o tulaga faatauaina e lua.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// O se okaina pe a fai o le faʻatusatusaina o tau e laʻititi nai lo le isi.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// Se faʻasologa pe a faʻatusatusa le tau aoga e tutusa ma le isi.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// Se faʻatonuga pe a faʻapea o le faʻatusatusa taua e sili atu nai lo le isi.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Faʻafoʻi `true` pe a fai o le faʻatonuga o le `Equal` ituaiga.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Faʻafoʻi `true` pe a fai o le okaina e le o le `Equal` ituaiga.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Faafoi `true` pe afai o le okaina o le variant `Less`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Faʻafoʻi `true` pe a fai o le faʻatonuga o le `Greater` ituaiga.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Faʻafoʻi `true` pe a fai o le faʻasologa a le o le `Less` poʻo le `Equal` ituaiga.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Faafoi `true` pe afai o le okaina o le o le variant `Greater` po `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// Faʻataʻalo le `Ordering`.
    ///
    /// * `Less` avea ma `Greater`.
    /// * `Greater` avea ma `Less`.
    /// * `Equal` avea ma `Equal`.
    ///
    /// # Examples
    ///
    /// Amioga masani:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Lenei auala mafai ona faʻaaogaina e fesuiaʻi se faʻatusatusaga:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // faʻavasega le vasega mai le tele i le laʻititi.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Filifili lua faʻasologa.
    ///
    /// Toe foi `self` pe e le `Equal`.A leai, toe faafoi `other`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Filifili le okaina i le galuega na tuuina mai.
    ///
    /// Faʻafoʻi `self` pe a le o `Equal`.
    /// A leai valaʻau `f` ma faʻafoʻi le iʻuga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// A fausia fesoasoani mo okaina faafeagai.
///
/// O lenei fausia o se fesoasoani ia faaaoga ma galuega tauave e pei [`Vec::sort_by_key`] ma e mafai ona faaaogaina e liliu poloaiga o se vaega o se ki.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait mo ituaiga e faia ai se [total order](https://en.wikipedia.org/wiki/Total_order).
///
/// O se oka o se aofaʻiga oka pe a fai o (mo uma `a`, `b` ma `c`):
///
/// - aofaʻi ma le tutusa: e tasi le `a < b`, `a == b` poʻo le `a > b` e moni;ma
/// - fesuiaʻi, `a < b` ma `b < c` faʻaalia `a < c`.O le tutusa e tatau ona taofia mo uma `==` ma `>`.
///
/// ## Derivable
///
/// e mafai ona faaaoga lenei trait ma `#[derive]`.
/// A oʻo mai le auala, o le a maua ai le [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) okaina faʻavae i luga o le pito i luga-o le faʻasologa o faʻatonuga o sui o le aufaigaluega.
///
/// A o le "derive`d on enums, variants e okaina e le latou pito i luga-lalo faʻailoga faʻailoga.
///
/// ## Faʻatusatusaga o tusitusiga
///
/// Lexicographic faʻatusatusaga o se faʻagaioiga ma mea nei:
///  - Lua sequences ua faatusaina elemene e elemene.
///  - O le muamua mismatching elemeni faʻamatalaina lea faʻasologa e lexicographically laʻititi pe sili atu nai lo le isi.
///  - Afai o se tasi faʻasologa o se nauna o le isi, o le faʻapuʻupuʻu faʻasologa e lexicographically laʻititi nai lo le isi.
///  - Afai e toalua faasologa elemene tutusa ma o le umi lava e tasi, lea ua lexicographically tutusa le sequences.
///  - O se faʻasologa gaogao e lexicographically laʻititi ifo nai lo soʻo se leai gaogao faʻasologa.
///  - Lua faʻasologa avanoa e tutusa lexicographically.
///
/// ## Mafai faapefea ona ou faatino `Ord`?
///
/// `Ord` manaʻomia foi le ituaiga avea foi [`PartialOrd`] ma [`Eq`] (lea e manaʻomia [`PartialEq`]).
///
/// Ona e tatau ona e faamatalaina se faatinoga mo [`cmp`].E mafai ona e maua ai le aoga e faaaoga [`cmp`] i fanua o lou ituaiga.
///
/// Implementations o [`PartialEq`], [`PartialOrd`], ma `Ord`*tatau* malie ma le tasi ma le isi.
/// O lona uiga, `a.cmp(b) == Ordering::Equal` pe a na o `a == b` ma `Some(a.cmp(b)) == a.partial_cmp(b)` mo `a` ma `b` uma.
/// E faigofie lava ona faʻafuaseʻi ona latou le malie i le mauaina o nisi o le traits ma le faʻaogaina faʻatino o isi.
///
/// Iinei o se faataitaiga o le mea e te manao e faavasega ai tagata e ala i le maualuga lava, le amanaiaina `id` ma `name`:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// O lenei auala e toe faʻafoʻi mai ai le [`Ordering`] i le va o le `self` ma le `other`.
    ///
    /// E ala i feagaiga, ua toe foi `self.cmp(&other)` le okaina tutusa le faaupuga `self <operator> other` afai e moni.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Faʻatusatusa ma toe faʻafoʻi le maualuga o le lua taua.
    ///
    /// Faʻafoʻi le finauga lona lua pe a fai o le faʻatusatusaga e filifilia ai latou ia tutusa.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// Faʻatusatusa ma toe faʻafoʻi le maualalo o lua tulaga taua.
    ///
    /// Faʻafoʻi le finau muamua pe a fai o le faʻatusatusaga e iloa ai e tutusa.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// Faʻatapulaʻa se tau i se vaitaimi faʻapitoa.
    ///
    /// Faʻafoʻi `max` pe a fai o `self` e sili atu nai lo `max`, ma `min` peʻa `self` e laititi atu i le `min`.
    /// A leai o lenei toe faafoi `self`.
    ///
    /// # Panics
    ///
    /// Panics afai `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// Faʻatupuina makro faʻatupuina se impl o le trait `Ord`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait mo mea taua e mafai ona faʻatusatusa mo se faʻavasega-oka.
///
/// Le faatusatusaga e tatau ona faamalieina, mo mea uma `a`, `b` ma `c`:
///
/// - asymmetry: afai `a < b` lea `!(a > b)`, faapea foi `a > b` atagia `!(a < b)`;ma
/// - fesiitaʻi: `a < b` ma `b < c` faʻaalia `a < c`.O le taofi lava lea e tasi e tatau mo `==` ma `>`.
///
/// Manatua o nei manaʻoga o lona uiga o le trait lava ia e tatau ona faʻataʻitaʻia faʻasolosolo ma suia: pe a `T: PartialOrd<U>` ma `U: PartialOrd<V>` ona `U: PartialOrd<T>` ma le 'T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// e mafai ona faaaoga lenei trait ma `#[derive]`.A maua mai i luga o faʻamau, o le a gaosia ai lexicographic okaina faʻavae i luga o le pito i luga-o le faʻasologa o faʻatonuga o sui o le aufaigaluega.
/// A o le "derive`d on enums, variants e okaina e le latou pito i luga-lalo faʻailoga faʻailoga.
///
/// ## Mafai faapefea ona ou faatino `PartialOrd`?
///
/// `PartialOrd` naʻo le manaʻomia le faʻatinoina ole [`partial_cmp`] metotia, ma isi e mafua mai i le faʻaaogaina faʻatonu.
///
/// Peitaʻi e tumau pea mafai ona faʻatino eseese isi mo ituaiga e leai se aofaʻiga oka.
/// Mo se faataitaiga, mo opeopea numera manatu, `NaN < 0 == false` ma `NaN >= 0 == false` (cf.
/// IEEE 754-2008 fuaiupu 5.11).
///
/// `PartialOrd` e manaomia lou ituaiga e avea [`PartialEq`].
///
/// Faʻatinoina o [`PartialEq`], `PartialOrd`, ma [`Ord`]*tatau* malilie uma i le tasi.
/// E faigofie lava ona faʻafuaseʻi ona latou le malie i le mauaina o nisi o le traits ma le faʻaogaina faʻatino o isi.
///
/// Afai o lau ituaiga o [`Ord`], e mafai ona faatino [`partial_cmp`] ala i le faaaogaina [`cmp`]:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// E mafai foi ona maua ai aoga e faaaoga [`partial_cmp`] i fanua o lou ituaiga.
/// Lenei o se faʻataʻitaʻiga o `Person` ituaiga o loʻo i ai se opeopea-itu `height` fanua na o le pau lea o le fanua e faʻaaogaina mo le faʻavasegaina:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Lenei metotia faʻafoʻi se okaina i le va `self` ma `other` tulaga taua peʻa iai se tasi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// A le mafai faʻatusatusaga:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// O lenei auala e tofotofoina itiiti ifo nai lo (mo `self` ma `other`) ma o loo faaaogaina e le tagata faafoe `<`.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Lenei metotia tofotofoga laʻititi ifo pe tutusa i le (mo `self` ma `other`) ma e faʻaaogaina e le `<=` tagata faʻagaioia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// Lenei metotia tofotofoga sili atu nai lo (mo `self` ma `other`) ma e faʻaaogaina e le `>` tagata faʻagaioia.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// Lenei metotia tofotofoga sili atu nai lo pe tutusa ma (mo `self` ma `other`) ma e faʻaaogaina e le `>=` tagata faʻagaioia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// Faʻatupuina makro faʻatupuina se impl o le trait `PartialOrd`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Faʻatusatusa ma toe faʻafoʻi le maualalo o lua tulaga taua.
///
/// Faʻafoʻi le finau muamua pe a fai o le faʻatusatusaga e iloa ai e tutusa.
///
/// Mai totonu faaaoga se igoa pepelo e [`Ord::min`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Faʻafoʻi mai le laʻititi ifo o le lua faʻatauaina e tusa ai ma le faʻatulagaina faʻatusatusa galuega.
///
/// Faʻafoʻi le finau muamua pe a fai o le faʻatusatusaga e iloa ai e tutusa.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Faʻafoʻi mai le elemene e maua ai le tau maualalo mai le faʻatulagaina gaioiga.
///
/// Faʻafoʻi le finau muamua pe a fai o le faʻatusatusaga e iloa ai e tutusa.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Faʻatusatusa ma toe faʻafoʻi le maualuga o le lua taua.
///
/// Faʻafoʻi le finauga lona lua pe a fai o le faʻatusatusaga e filifilia ai latou ia tutusa.
///
/// Faʻaoga i totonu se igoa alias i le [`Ord::max`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Faʻafoʻi mai le maualuga o lua mea taua e tusa ai ma le faʻatusatusaga faʻatusatusa galuega tauave.
///
/// Faʻafoʻi le finauga lona lua pe a fai o le faʻatusatusaga e filifilia ai latou ia tutusa.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Toe foi le elemene e tuuina mai e le taua aupito maualuga mai le galuega tauave ua faamaotiina.
///
/// Faʻafoʻi le finauga lona lua pe a fai o le faʻatusatusaga e filifilia ai latou ia tutusa.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// Faatinoga o PartialEq, Eq, PartialOrd ma Ord mo ituaiga anamua
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // O le faʻatonuga iinei e taua e faʻatupuina ai le sili atu ona lelei potopoto.
                    // Vaʻai <https://github.com/rust-lang/rust/issues/63758> mo nisi faʻamatalaga.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // a ma le faaliliuina lafo i i8 le eseesega i se okaina faatupuina faapotopotoga sili e silisili ona lelei.
            //
            // Vaʻai <https://github.com/rust-lang/rust/issues/66780> mo nisi faʻamatalaga.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // SAFETY: bool pei o i8 toe faafoi le 0 poʻo le 1, o lea la o le eseʻesega e le mafai ona avea ma seisi mea
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &tusi faʻasino

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}