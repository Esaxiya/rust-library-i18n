use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // e le o le eria luga fale o manu lenei, ae e fesoasoani taugofie tausiga `?` le va o i latou, e tusa lava pe LLVM le mafai i taimi uma e faaaoga ai i le taimi nei.
    //
    // (Faʻanoanoa taunuuga ma filifiliga e le ogatasi, o lea e le mafai ai e le ControlFlow ona faʻatusalia uma.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}