use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // E telegese lava Miri
fn exact_sanity_test() {
    // Lenei suʻega faʻaiʻu tamoʻe mea e mafai ona ou faʻapea o se tulimanu-ish tulaga o le `exp2` faletusi galuega, faʻamatalaina i soʻo se C runtime o tatou faʻaaogaina.
    // I VS 2013 sa foliga mai o lenei galuega tauave a meaola laʻitiiti e pei ua le mafai lenei suega pe fesootai, ae o le VS 2015 ua aliali mai na faatulagaina le meaola laʻitiiti e pei o le suega tamoʻe lava lelei.
    //
    // O le meaola laʻitiiti e foliga mai o se eseesega i le toe taua o `exp2(-1057)`, lea i VS 2013 toe foi se lua i le vaega itiiti mamanu 0x2 ma i VS 2015 e toe foi 0x20000.
    //
    //
    // Mo le taimi nei tau lava le amanaʻiaina lenei suʻesuʻega atoa i luga o le MSVC ona o loʻo suʻesuʻeina i se isi itu ma matou te le o fiafia tele e faʻataʻitaʻi ia tulaga exp2 faʻatinoga.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}