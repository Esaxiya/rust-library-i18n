use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Faaaogaina e faamatala atu tatou faamatalaga o `#[assert_instr]` o loo maua simd intrinsics uma e tofotofo ai lo latou codegen, talu ai nisi o loo īa tua o se faaopoopo `-Ctarget-feature=+unimplemented-simd128` e le i ai se tulaga tutusa i `#[target_feature]` le taimi nei.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}