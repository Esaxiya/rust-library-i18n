`core::arch` - faletusi autu a le Rust intrinsics tusiata fale-patino
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

O le tusiata fale-faalagolago meafaigaluega module `core::arch` intrinsics (eg SIMD).

# Usage 

`core::arch` e maua o se vaega o `libcore` ma ua toe auina atu i fafo e `libstd`.Sili fiafia e faʻaaoga e ala i le `core::arch` poʻo le `std::arch` nai lo le auala atu i lenei crate.
e masani lava ona maua foliga mautu i Rust po uma e ala i le `feature(stdsimd)`.

Faaaogaina `core::arch` ala lenei crate manaomia po uma Rust, ma e mafai (ma e) solia masani.Na pau lava le tulaga i le tatau ai ona e na mafaufau e faaaoga ai e ala i lenei crate o le:

* pe afai e tatau ona e toe tuufaatasia `core::arch` oe lava, eg, ma faapitoa taulaʻiga-foliga mafai e le mafai mo `libcore`/`libstd`.
Note: pe afai e tatau ona e toe tuufaatasia ai mo se taulaʻiga o ni tulaga faatonuina, faamolemole sili faaaogaina `xargo` ma toe tuufaatasia `libcore`/`libstd` pe a talafeagai ai nai lo le faaaogaina o lenei crate.
  
* le faaaogaina o nisi o vaega ina ia mafai ona maua e oo lava i tua faaalia mautu Rust.Matou te taumafai e faʻatumauina nei mea i se mea maualalo.
Afai e te manaomia e faaaoga nisi o nei vaega, faamolemole tatala se mataupu ina ia mafai ona tatou faailoa atu i latou i po uma Rust ma e mafai ona faaaogaina i latou mai iina.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` ua faapitoa tufatufaina i lalo o tuutuuga o faasalaga uma e lua o le laisene ma le Laisene Apache MIT (Version 2.0), ma le vaega o aofia ai i eseese BSD-e pei o laisene.

Tagai LAISENE-APACHE, ma LAISENE-MIT mo faamatalaga auiliili.

# Contribution

Sei vagana ua e manino tulaga e ese ai, so o se saofaga tuuina atu le loto i ai e faaaofia i totonu `core_arch` e outou, e pei ona faamatalaina i le Apache-2.0 laisene, e tatau ona lua ua laiseneina e pei ona taua i luga, e aunoa ma se faaopoopo tuutuuga po o aiaiga.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












