# Fesoasoani i le stdarch

e sili atu le `stdarch` crate lo le naunau e talia saofaga!Muamua o le ae atonu e te manao e siaki mai le repository ma ia mautinoa e oo mo oe tofotofoga:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Afai `<your-target-arch>` o le sini e tolu e pei ona faaaogaina e `rustup`, eg `x86_x64-unknown-linux-gnu` (e aunoa ma se muamua `nightly-` po faapena).
Ia manatua foi o lenei repository manaomia le auala po uma o Rust!
O le tofotofoga i luga faia o le mea moni e manaomia ai po uma rust e avea ma faaletonu i lou faiga, e tuu atu o le faaaogaina `rustup default nightly` (ma `rustup default stable` e solo 'i tua).

Afai o se tasi o laʻasaga i luga le galue, [please let us know][new]!

Sosoʻo luga oe mafai [find an issue][issues] e fesoasoani i luga, ua matou filifilia ni nai ma le [`help wanted`][help] ma [`impl-period`][impl] faʻailoga e ono mafai ona faʻaaogaina nisi fesoasoani. 
Atonu o le a sili ona fiafia i [#40][vendor], faatinoina intrinsics tagata faʻatau atu uma i x86.E maua o le mataupu nisi vae lelei e uiga i le mea e amata ai!

Afai ua e taunuu fesili aoao lagona saoloto e [join us on gitter][gitter] ma fesili o loo siomia ai!Lagona saoloto e ping pe@BurntSushi po@alexcrichton ma fesili.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# E faapefea e tusi faataitaiga mo stdarch intrinsics

E i ai ni nai vaega e tatau ona mafai ai mo le tuuina ¯ e galuega lelei ma e tatau ona na o le a taufetuli i le faataitaiga e ala i `cargo test --doc` ina ua lagolagoina le vaega e le CPU.

O le iʻuga, o le faaletonu `fn main` lea e fausia e `rustdoc` o le a le galue (i le tele o tulaga).
Mafaufau e faʻaaoga le mea lea o se taʻiala e faʻamautinoa ai le aoga o au faʻataʻitaʻiga e pei ona faʻamoemoeina.

```rust
/// # // Tatou te le manaomia cfg_target_feature ina ia mautinoa e na o le faataitaiga
/// # // taufetuli e `cargo test --doc` ina ua lagolagoina le CPU le vaega
/// # #![feature(cfg_target_feature)]
/// # // Matou te manaʻomia target_feature mo le totonu e galue
/// # #![feature(target_feature)]
/// #
/// # // rustdoc i le faʻaaogaina le `extern crate stdarch`, ae matou te manaʻomia le
/// # // `#[macro_use]`
/// # # [Macro_use] extern crate stdarch;
/// #
/// # // Le mea moni autu
/// # fn main() {
/// #     // Na taufetuli lenei pe afai ua lagolagoina `<target feature>`
/// #     pe afai cfg_feature_enabled! ("<target feature>"){
/// #         // Fausia se `worker` gaioiga o le a na o le tamoe pe a fai o le sini autu
/// #         // e lagolagoina ma mautinoa o le `target_feature` ua mafai mo lau tagata faigaluega
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         fn saogalemu worker() {
/// // Tusi lau faʻataʻitaʻiga ii.le a galulue iinei vaega intrinsics faapitoa!Alu vao!
///
/// #         }
///
/// #         le saogalemu { worker(); }
/// #     }
/// # }
```

Afai e le vaai masani nisi o syntax i luga, o loo faamatalaina ai le vaega [Documentation as tests] o le [Rust Book] le syntax `rustdoc` lelei lava.
E pei ona masani ai, lagona saoloto i le [join us on gitter][gitter] ma fesili mai pe na e lavea ni mailei, ma faʻafetai mo lou fesoasoani e faʻaleleia atili pepa o `stdarch`!

# Faatonuga on Isi

E masani fautuaina e te faaaogaina `ci/run.sh` e taufetuli i le tofotofoga.
Peitai e ono le aoga lenei mea ia te oe, eg pe afai oei luga o le Windows.

I lena tulaga e mafai ona paʻu'ū i tua e tamoe `cargo +nightly test` ma `cargo +nightly test --release -p core_arch` mo tofotofoina le tupulaga code.
Faaaliga e manaomia ai nei le toolchain po uma ona faapipii ma mo `rustc` e iloa e uiga i au sini e tolu ma ona CPU.
Aemaise lava e tatau ona e faia le ma liuliuina siosiomaga `TARGET` pei o loo e mo `ci/run.sh`.
E le gata e tatau ona e faataatia `RUSTCFLAGS` (manaomia le `C`) e faailoa ai vaega taulaʻiga, eg `RUSTCFLAGS="-C -target-features=+avx2"`.
e mafai ona faatulagaina foi ona e `-C -target-cpu=native` pe afai o loo e atiina ae "just" faasaga i lo outou CPU nei.

Lapataʻi oe a e faʻaaogaina nei isi faʻatonuga, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], eg
mafai ona toilalo tofotofoga tupulaga faatonuga ona e igoa i latou le disassembler ese, eg
e mafai ona faatupuina ai `vaesenc` nai lo le faatonuga `aesenc` e ui lava latou amio le tasi.
Foi faaoo itiiti nei faatonuga tofotofoga nai lo e masani ona faia, ina ia aua le faateia ina ua e iu lava ina toso-talosagaina ni mea sese e mafai ona faaali atu ai mo tofotofoga e le ufitia iinei.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






