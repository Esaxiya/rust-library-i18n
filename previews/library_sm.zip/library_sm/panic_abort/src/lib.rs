//! Faatinoga o Rust panics ala aborts faagasologa
//!
//! Pe a faatusatusa i le faatinoga e ala i unwinding, o lenei crate o *tele* faigofie!Faapea mai tagata, e le lava e pei vavai, ae iinei alu!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" le payload ma Semi i le abort talafeagai i luga o le tulaga i le fesili.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // valaʻau i le std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // I Windows, faaaoga le processor maoti __fastfail faiga.I le Windows 8 ma mulimuli ane, o lenei o le a faʻamutaina le gaioiga i le taimi nei e aunoa ma le tamoeina o se i totonu o le gaioiga tuʻufaʻatasi handlers.
            // I faʻaiuga muamua o le Windows, o lenei faʻasologa o faʻatonuga o le a togafitia o se faʻatagaina avanoa, faʻamutaina o le gaioiga ae aunoa ma le aloese uma tuʻutuʻuga handlers.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: ole tutusa lea faʻatinoga pei ole libstd's `abort_internal`
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Lenei ... o se mea e le masani ai.O le tl; dr;o lea e manaomia lenei e sosoo saʻo, o lalo ifo o le faamalamalamaga umi.
//
// Taimi nei o le binaries o libcore/libstd tatou vaa o loo tuufaatasia uma i `-C panic=unwind`.e faia lenei mea e mautinoa ai le binaries e maximally talafeagai ma o le tele o tulaga e mafai ai.
// Ae ui i lea, o le tuʻufaʻatasiga, e manaʻomia se "personality function" mo gaioiga uma ua tuʻufaʻatasia ma `-C panic=unwind`.O lenei uiga faʻagaioiga e faigata ona faʻamau i le faʻailoga `rust_eh_personality` ma ua faʻamatalaina e le `eh_personality` lang mea.
//
// So...
// aisea e le na o le faʻamalamalamaina o le lang mea iinei?fesili lelei!O le auala e fesoʻotaʻi ai panic runtime i totonu o le mea moni lava laʻititi i lo latou "sort of" i le compiler's crate faleoloa, ae naʻo le fesoʻotaʻi moni pe a fai o leisi e le o fesoʻotaʻi.
//
// O lenei pito i luga o lona uiga e mafai ona uma lenei crate ma le panic_unwind crate foliga mai i totonu o le faleoloa crate na tuufaatasia, ma afai e faamatala uma le mea `eh_personality` Lang taimi lena o le a lavea se mea sese.
//
// Ina ia tagofia lenei mea o le tuʻufaʻatasiga naʻo manaʻomia le `eh_personality` ua faʻamatalaina pe a fai o le panic runtime o loʻo fesoʻotaʻi i totonu o le le faʻamamaina taimi, ma a leai e le manaʻomia le faʻauigaina (saʻo ia).
// I lenei tulaga, peitai, na faamatalaina ai lenei faletusi lenei faailoga lea o loo i ai i ni nai tagata i se mea.
//
// O le mea moni o lenei faʻailoga ua naʻo le faʻauigaina e alu i luga i le libcore/libstd binaries, ae le tatau ona valaʻauina aua tatou te le fesoʻotaʻi i totonu o le le malologa faʻataʻamiloina uma.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // I x86_64-pc-faamalama-gnu tatou faaaogaina lo tatou lava galuega tauave uiga o le manaoga e toe foi `ExceptionContinueSearch` e pei o loo tatou uia luga o lo tatou faavaa uma.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Tutusa ma luga, o lenei e tutusa ma le `eh_catch_typeinfo` lang aitema e naʻo faʻaaogaina i luga o Emscripten nei.
    //
    // Talu ai o le panics e le faia ni tuusaunoaga ma faʻasalaga mai fafo o loʻo i ai nei UB ma -C panic=faʻamuta (e ui o lenei e ono mafai ona suia), soʻo se catch_unwind telefoni o le a le faʻaaogaina lenei typeinfo.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // O nei mea e lua e valaʻauina e a tatou mea amata i luga i686-pc-windows-gnu, ae latou te le manaʻomia ona faia se mea o lea e leai ni tino.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}