//! Se lisi faʻalua-faʻafesoʻotaʻi ma pule node.
//!
//! O le `LinkedList` faʻatagaina le tuleia ma le faʻaosoina o elemeni i soʻo se iʻuga i taimi uma.
//!
//! NOTE: E toetoe lava a sili atu le lelei i taimi uma e faʻaaoga ai le [`Vec`] poʻo le [`VecDeque`] ona o container-based container e masani lava ona televave, sili atu ona manatua lelei, ma faʻaaoga lelei ai le cache a le CPU.
//!
//!
//! [`Vec`]: crate::vec::Vec
//! [`VecDeque`]: super::vec_deque::VecDeque
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::Ordering;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem;
use core::ptr::NonNull;

use super::SpecExtend;
use crate::boxed::Box;

#[cfg(test)]
mod tests;

/// Se lisi faʻalua-faʻafesoʻotaʻi ma pule node.
///
/// O le `LinkedList` faʻatagaina le tuleia ma le faʻaosoina o elemeni i soʻo se iʻuga i taimi uma.
///
/// NOTE: E toetoe lava a sili atu le lelei i taimi uma e faʻaaoga ai le `Vec` poʻo le `VecDeque` ona o container-based container e masani lava ona televave, sili atu ona manatua lelei, ma faʻaaoga lelei ai le cache a le CPU.
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "LinkedList")]
pub struct LinkedList<T> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<Box<Node<T>>>,
}

struct Node<T> {
    next: Option<NonNull<Node<T>>>,
    prev: Option<NonNull<Node<T>>>,
    element: T,
}

/// O se faʻasolosolo luga o elemene o le `LinkedList`.
///
/// Lenei `struct` faia e [`LinkedList::iter()`].
/// Vaʻai ana faʻamaumauga mo sili atu.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<&'a Node<T>>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.len).finish()
    }
}

// FIXME(#26925) Aveʻese nai lo le `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { ..*self }
    }
}

/// O se fesuiaʻiga suia i luga o elemene o le `LinkedList`.
///
/// Lenei `struct` faia e [`LinkedList::iter_mut()`].
/// Vaʻai ana faʻamaumauga mo sili atu.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    // Matou te le * faʻatauaina faapitoa le lisi atoa iinei, faʻasino i le node's `element` na tufaina atu e le tagata faʻasolosolo!Ia faʻaitete la pe a faʻaaogaina lenei;o metotia valaʻauina e tatau ona nofouta e mafai ona i ai aliasing faʻasino i le `element`.
    //
    //
    list: &'a mut LinkedList<T>,
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IterMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IterMut").field(&self.list).field(&self.len).finish()
    }
}

/// O se umiaina iterator luga o elemene o le `LinkedList`.
///
/// Lenei `struct` na faia e le [`into_iter`] metotia luga [`LinkedList`] (saunia e le `IntoIterator` trait).
/// Vaʻai ana faʻamaumauga mo sili atu.
///
/// [`into_iter`]: LinkedList::into_iter
#[derive(Clone)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    list: LinkedList<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.list).finish()
    }
}

impl<T> Node<T> {
    fn new(element: T) -> Self {
        Node { next: None, prev: None, element }
    }

    fn into_element(self: Box<Self>) -> T {
        self.element
    }
}

// auala tumaoti
impl<T> LinkedList<T> {
    /// Faʻaopopo le node na tuʻuina atu i luma o le lisi.
    #[inline]
    fn push_front_node(&mut self, mut node: Box<Node<T>>) {
        // Lenei metotia faʻaeteete aua neʻi faia mutable faʻasino i nodes atoa, ia tausisi i le faʻamaonia o aliasing pointers i le `element`.
        //
        unsafe {
            node.next = self.head;
            node.prev = None;
            let node = Some(Box::leak(node).into());

            match self.head {
                None => self.tail = node,
                // Le fausiaina o ni suiga fou (unique!) faʻasolosolo soʻotaga `element`.
                Some(head) => (*head.as_ptr()).prev = node,
            }

            self.head = node;
            self.len += 1;
        }
    }

    /// Aveese ma toe faafoi le node i luma o le lisi.
    #[inline]
    fn pop_front_node(&mut self) -> Option<Box<Node<T>>> {
        // Lenei metotia faʻaeteete aua neʻi faia mutable faʻasino i nodes atoa, ia tausisi i le faʻamaonia o aliasing pointers i le `element`.
        //
        self.head.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.head = node.next;

            match self.head {
                None => self.tail = None,
                // Le fausiaina o ni suiga fou (unique!) faʻasolosolo soʻotaga `element`.
                Some(head) => (*head.as_ptr()).prev = None,
            }

            self.len -= 1;
            node
        })
    }

    /// Faʻaopopo le node na tuʻuina i tua o le lisi.
    #[inline]
    fn push_back_node(&mut self, mut node: Box<Node<T>>) {
        // Lenei metotia faʻaeteete aua neʻi faia mutable faʻasino i nodes atoa, ia tausisi i le faʻamaonia o aliasing pointers i le `element`.
        //
        unsafe {
            node.next = None;
            node.prev = self.tail;
            let node = Some(Box::leak(node).into());

            match self.tail {
                None => self.head = node,
                // Le fausiaina o ni suiga fou (unique!) faʻasolosolo soʻotaga `element`.
                Some(tail) => (*tail.as_ptr()).next = node,
            }

            self.tail = node;
            self.len += 1;
        }
    }

    /// Aveesea ma le toe foi mai le node i le tua o le lisi.
    #[inline]
    fn pop_back_node(&mut self) -> Option<Box<Node<T>>> {
        // Lenei metotia faʻaeteete aua neʻi faia mutable faʻasino i nodes atoa, ia tausisi i le faʻamaonia o aliasing pointers i le `element`.
        //
        self.tail.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.tail = node.prev;

            match self.tail {
                None => self.head = None,
                // Le fausiaina o ni suiga fou (unique!) faʻasolosolo soʻotaga `element`.
                Some(tail) => (*tail.as_ptr()).next = None,
            }

            self.len -= 1;
            node
        })
    }

    /// Aveese le fesoʻotaʻiga node mai le lisi o loʻo iai nei.
    ///
    /// Lapataiga: o le a le siakiina o le saunia node e faatatau i le lisi o loʻo i ai nei.
    ///
    /// Lenei metotia faʻaeteete aua neʻi faia mutable faʻasino i le `element`, e faʻatumauina ai le faʻamaonia o aliasing pointers.
    ///
    #[inline]
    unsafe fn unlink_node(&mut self, mut node: NonNull<Node<T>>) {
        let node = unsafe { node.as_mut() }; // lenei tasi o la tatou nei, e mafai ona tatou faia se &mut.

        // Le fausiaina o ni suiga fou (unique!) faʻasolosolo soʻotaga `element`.
        match node.prev {
            Some(prev) => unsafe { (*prev.as_ptr()).next = node.next },
            // o lenei node o le ulu node
            None => self.head = node.next,
        };

        match node.next {
            Some(next) => unsafe { (*next.as_ptr()).prev = node.prev },
            // lenei node o le node siʻusiʻu
            None => self.tail = node.prev,
        };

        self.len -= 1;
    }

    /// Faʻafesoʻotaʻi ni faʻasologa o node i le va o ni node e lua.
    ///
    /// Lapataiga: o le a le siakiina o le saunia node e lua lisi ia e lua.
    #[inline]
    unsafe fn splice_nodes(
        &mut self,
        existing_prev: Option<NonNull<Node<T>>>,
        existing_next: Option<NonNull<Node<T>>>,
        mut splice_start: NonNull<Node<T>>,
        mut splice_end: NonNull<Node<T>>,
        splice_length: usize,
    ) {
        // O lenei metotia e faʻaeteete ia aua neʻi faia ni faʻavasega se tele i nodes atoa i le taimi e tasi, ina ia faʻatumauina le aoga o faʻailoga aliasing i le `element`.
        //
        if let Some(mut existing_prev) = existing_prev {
            unsafe {
                existing_prev.as_mut().next = Some(splice_start);
            }
        } else {
            self.head = Some(splice_start);
        }
        if let Some(mut existing_next) = existing_next {
            unsafe {
                existing_next.as_mut().prev = Some(splice_end);
            }
        } else {
            self.tail = Some(splice_end);
        }
        unsafe {
            splice_start.as_mut().prev = existing_prev;
            splice_end.as_mut().next = existing_next;
        }

        self.len += splice_length;
    }

    /// Aveese uma nodes mai se fesoʻotaʻiga lisi o se faʻasologa o nodes.
    #[inline]
    fn detach_all_nodes(mut self) -> Option<(NonNull<Node<T>>, NonNull<Node<T>>, usize)> {
        let head = self.head.take();
        let tail = self.tail.take();
        let len = mem::replace(&mut self.len, 0);
        if let Some(head) = head {
            let tail = tail.unwrap_or_else(|| unsafe { core::hint::unreachable_unchecked() });
            Some((head, tail, len))
        } else {
            None
        }
    }

    #[inline]
    unsafe fn split_off_before_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // O le vaevaega vaeluaina o le ulu ulu fou o le vaega lona lua
        if let Some(mut split_node) = split_node {
            let first_part_head;
            let first_part_tail;
            unsafe {
                first_part_tail = split_node.as_mut().prev.take();
            }
            if let Some(mut tail) = first_part_tail {
                unsafe {
                    tail.as_mut().next = None;
                }
                first_part_head = self.head;
            } else {
                first_part_head = None;
            }

            let first_part = LinkedList {
                head: first_part_head,
                tail: first_part_tail,
                len: at,
                marker: PhantomData,
            };

            // Faʻamau le ulu ptr o le vaega lona lua
            self.head = Some(split_node);
            self.len = self.len - at;

            first_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }

    #[inline]
    unsafe fn split_off_after_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // O le vaevaega vaeluaina o le siʻusiʻu siʻo fou o le muamua vaega ma umiaina le ulu o le vaega lona lua.
        //
        if let Some(mut split_node) = split_node {
            let second_part_head;
            let second_part_tail;
            unsafe {
                second_part_head = split_node.as_mut().next.take();
            }
            if let Some(mut head) = second_part_head {
                unsafe {
                    head.as_mut().prev = None;
                }
                second_part_tail = self.tail;
            } else {
                second_part_tail = None;
            }

            let second_part = LinkedList {
                head: second_part_head,
                tail: second_part_tail,
                len: self.len - at,
                marker: PhantomData,
            };

            // Faʻamau le tail ptr o le vaega muamua
            self.tail = Some(split_node);
            self.len = at;

            second_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for LinkedList<T> {
    /// Fausia se avanoa `LinkedList<T>`.
    #[inline]
    fn default() -> Self {
        Self::new()
    }
}

impl<T> LinkedList<T> {
    /// Fausia se avanoa `LinkedList`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let list: LinkedList<u32> = LinkedList::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_linked_list_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        LinkedList { head: None, tail: None, len: 0, marker: PhantomData }
    }

    /// Siʻi uma elemeni mai le `other` i le iʻuga o le lisi.
    ///
    /// Lenei toe faʻaaogaina uma nodes mai `other` ma faʻasolo i latou i le `self`.
    /// Ina ua maeʻa lenei taʻotoga, `other` ua gaogao.
    ///
    /// Lenei taʻotoga e tatau ona fuafuaina i le *O*(1) taimi ma le *O*(1) manatuaina.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list1 = LinkedList::new();
    /// list1.push_back('a');
    ///
    /// let mut list2 = LinkedList::new();
    /// list2.push_back('b');
    /// list2.push_back('c');
    ///
    /// list1.append(&mut list2);
    ///
    /// let mut iter = list1.iter();
    /// assert_eq!(iter.next(), Some(&'a'));
    /// assert_eq!(iter.next(), Some(&'b'));
    /// assert_eq!(iter.next(), Some(&'c'));
    /// assert!(iter.next().is_none());
    ///
    /// assert!(list2.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn append(&mut self, other: &mut Self) {
        match self.tail {
            None => mem::swap(self, other),
            Some(mut tail) => {
                // `as_mut` e le afaina iinei ona e iai lo tatou avanoa i le atoaga o lisi uma e lua.
                //
                if let Some(mut other_head) = other.head.take() {
                    unsafe {
                        tail.as_mut().next = Some(other_head);
                        other_head.as_mut().prev = Some(tail);
                    }

                    self.tail = other.tail.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// Siʻi uma elemeni mai le `other` i le amataga o le lisi.
    #[unstable(feature = "linked_list_prepend", issue = "none")]
    pub fn prepend(&mut self, other: &mut Self) {
        match self.head {
            None => mem::swap(self, other),
            Some(mut head) => {
                // `as_mut` e le afaina iinei ona e iai lo tatou avanoa i le atoaga o lisi uma e lua.
                //
                if let Some(mut other_tail) = other.tail.take() {
                    unsafe {
                        head.as_mut().prev = Some(other_tail);
                        other_tail.as_mut().next = Some(head);
                    }

                    self.head = other.head.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// Tuʻuina atu i luma le faʻavasega.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { head: self.head, tail: self.tail, len: self.len, marker: PhantomData }
    }

    /// Tuʻuina atu i luma luma faʻasolosolo ma suia suiga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// for element in list.iter_mut() {
    ///     *element += 10;
    /// }
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&10));
    /// assert_eq!(iter.next(), Some(&11));
    /// assert_eq!(iter.next(), Some(&12));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { head: self.head, tail: self.tail, len: self.len, list: self }
    }

    /// Tuʻuina mai se faʻamau i le pito i luma elemeni.
    ///
    /// O le faʻamau e tusi i le "ghost" leai-elemeni pe a fai o le lisi e avanoa.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front(&self) -> Cursor<'_, T> {
        Cursor { index: 0, current: self.head, list: self }
    }

    /// Tuʻuina mai se faʻamau ma faʻatonutonu gaioiga i le pito i luma elemeni.
    ///
    /// O le faʻamau e tusi i le "ghost" leai-elemeni pe a fai o le lisi e avanoa.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: 0, current: self.head, list: self }
    }

    /// Tuʻuina mai se faʻamau i le pito i tua elemeni.
    ///
    /// O le faʻamau e tusi i le "ghost" leai-elemeni pe a fai o le lisi e avanoa.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back(&self) -> Cursor<'_, T> {
        Cursor { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// Tuʻuina mai se faʻamau ma faʻatonutonu gaioiga i le pito i tua elemeni.
    ///
    /// O le faʻamau e tusi i le "ghost" leai-elemeni pe a fai o le lisi e avanoa.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// Faʻafoʻi `true` peʻa leai se mea ile `LinkedList`.
    ///
    /// O lenei faʻagaioiga e tatau ona fuafuaina ile *O*(1) taimi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert!(dl.is_empty());
    ///
    /// dl.push_front("foo");
    /// assert!(!dl.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.head.is_none()
    }

    /// Faʻafoʻi le umi o le `LinkedList`.
    ///
    /// O lenei faʻagaioiga e tatau ona fuafuaina ile *O*(1) taimi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.len(), 1);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    ///
    /// dl.push_back(3);
    /// assert_eq!(dl.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Aveʻese uma elemeni mai le `LinkedList`.
    ///
    /// O lenei faʻagaioiga e tatau ona fuafuaina i le *O*(*n*) taimi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// dl.clear();
    /// assert_eq!(dl.len(), 0);
    /// assert_eq!(dl.front(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = Self::new();
    }

    /// Faʻafoʻi `true` pe a fai o le `LinkedList` o loʻo iai se elemeni e tutusa ma le tau na tuʻuina atu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// assert_eq!(list.contains(&0), true);
    /// assert_eq!(list.contains(&10), false);
    /// ```
    #[stable(feature = "linked_list_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        self.iter().any(|e| e == x)
    }

    /// Tuʻuina mai se faʻasino i le pito i luma elemeni, poʻo le `None` pe a fai o le lisi e avanoa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        unsafe { self.head.as_ref().map(|node| &node.as_ref().element) }
    }

    /// Tuʻuina mai se suiga suia i le pito i luma elemeni, poʻo le `None` pe a fai o le lisi e gaogao.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// match dl.front_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.front(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        unsafe { self.head.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// Tuʻuina mai se faʻasino i le pito i tua elemeni, pe `None` pe a fai o le lisi e avanoa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        unsafe { self.tail.as_ref().map(|node| &node.as_ref().element) }
    }

    /// Tuʻuina mai se faʻavasega suiga i le pito i tua elemeni, poʻo le `None` pe a fai o le lisi e leai se mea.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    ///
    /// match dl.back_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.back(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        unsafe { self.tail.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// Faʻaopopo muamua se elemeni i le lisi.
    ///
    /// O lenei faʻagaioiga e tatau ona fuafuaina ile *O*(1) taimi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.front().unwrap(), &2);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front().unwrap(), &1);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, elt: T) {
        self.push_front_node(box Node::new(elt));
    }

    /// Aveʻese le muamua elemeni ma toe faʻafoʻi mai, pe `None` pe a fai o le lisi e avanoa.
    ///
    ///
    /// O lenei faʻagaioiga e tatau ona fuafuaina ile *O*(1) taimi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_front(), None);
    ///
    /// d.push_front(1);
    /// d.push_front(3);
    /// assert_eq!(d.pop_front(), Some(3));
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        self.pop_front_node().map(Node::into_element)
    }

    /// Faʻaopopo se elemeni i tua o se lisi.
    ///
    /// O lenei faʻagaioiga e tatau ona fuafuaina ile *O*(1) taimi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(3, *d.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, elt: T) {
        self.push_back_node(box Node::new(elt));
    }

    /// Aveʻese le elemene mulimuli mai se lisi ma toe faʻafoʻi mai, pe `None` peʻa leai se mea.
    ///
    ///
    /// O lenei faʻagaioiga e tatau ona fuafuaina ile *O*(1) taimi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_back(), None);
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(d.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        self.pop_back_node().map(Node::into_element)
    }

    /// Vaeluaina le lisi i le lua i le faʻasino faasino igoa.
    /// Faʻafoʻi mea uma pe a maeʻa le faʻasino igoa, aofia ai ma le faasino igoa.
    ///
    /// O lenei faʻagaioiga e tatau ona fuafuaina i le *O*(*n*) taimi.
    ///
    /// # Panics
    ///
    /// Panics pe a `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// let mut split = d.split_off(2);
    ///
    /// assert_eq!(split.pop_front(), Some(1));
    /// assert_eq!(split.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn split_off(&mut self, at: usize) -> LinkedList<T> {
        let len = self.len();
        assert!(at <= len, "Cannot split off at a nonexistent index");
        if at == 0 {
            return mem::take(self);
        } else if at == len {
            return Self::new();
        }

        // Lalo, matou te faʻasolosolo agaʻi i le i-1`th node, a le mai le amataga poʻo le iʻuga, faʻamoemoeina i fea o le a sili atu ona saoasaoa.
        //
        let split_node = if at - 1 <= len - 1 - (at - 1) {
            let mut iter = self.iter_mut();
            // ae le o le lafoa le faʻaaogaina o le .skip() (lea e fausia ai se mea fou), tatou te feoaʻi faʻatasi ina ia mafai ai ona ulufale i le ulu ulu e aunoa ma le faʻamoemoeina i faʻatinoina auiliiliga o Skip
            //
            //
            for _ in 0..at - 1 {
                iter.next();
            }
            iter.head
        } else {
            // sili atu amata mai le iuga
            let mut iter = self.iter_mut();
            for _ in 0..len - 1 - (at - 1) {
                iter.next_back();
            }
            iter.tail
        };
        unsafe { self.split_off_after_node(split_node, at) }
    }

    /// Aveʻese le elemeni i le faʻasino tusi ma tuʻuina mai.
    ///
    /// O lenei faʻagaioiga e tatau ona fuafuaina i le *O*(*n*) taimi.
    ///
    /// # Panics
    /// Panics pe a fai ile>=len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(linked_list_remove)]
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// assert_eq!(d.remove(1), 2);
    /// assert_eq!(d.remove(0), 3);
    /// assert_eq!(d.remove(0), 1);
    /// ```
    #[unstable(feature = "linked_list_remove", issue = "69210")]
    pub fn remove(&mut self, at: usize) -> T {
        let len = self.len();
        assert!(at < len, "Cannot remove at an index outside of the list bounds");

        // Lalo, matou te faʻasolosolo agaʻi i le lauʻeleʻele i le lisi na tuʻuina mai, a le mai le amataga poʻo le iʻuga, faʻamoemoeina i fea o le a sili atu ona saoasaoa.
        //
        let offset_from_end = len - at - 1;
        if at <= offset_from_end {
            let mut cursor = self.cursor_front_mut();
            for _ in 0..at {
                cursor.move_next();
            }
            cursor.remove_current().unwrap()
        } else {
            let mut cursor = self.cursor_back_mut();
            for _ in 0..offset_from_end {
                cursor.move_prev();
            }
            cursor.remove_current().unwrap()
        }
    }

    /// Fausia se iterator lea e faʻaaogaina se tapunia e fuafua ai pe o se elemeni tatau ona aveʻesea.
    ///
    /// Afai o le tapunia toe foi moni, lea o le elemeni e aveʻese ma maua.
    /// Afai o le tapunia toe foi sese, o le elemene o le a tumau pea i le lisi ma o le a le tuuina atu e le iterator.
    ///
    /// Manatua o le `drain_filter` faʻatagaina oe suia uma elemeni i le faʻamamaina tapuni, tusa lava pe oe filifili e tausi pe aveʻese.
    ///
    ///
    /// # Examples
    ///
    /// Vavaeina o se lisi i le afiafi ma avanoa, toe faʻaaogaina le amataga lisi:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// use std::collections::LinkedList;
    ///
    /// let mut numbers: LinkedList<u32> = LinkedList::new();
    /// numbers.extend(&[1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15]);
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<LinkedList<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens.into_iter().collect::<Vec<_>>(), vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds.into_iter().collect::<Vec<_>>(), vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F>
    where
        F: FnMut(&mut T) -> bool,
    {
        // aloese mai nono mataupu.
        let it = self.head;
        let old_len = self.len;

        DrainFilter { list: self, it, pred: filter, idx: 0, old_len }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for LinkedList<T> {
    fn drop(&mut self) {
        struct DropGuard<'a, T>(&'a mut LinkedList<T>);

        impl<'a, T> Drop for DropGuard<'a, T> {
            fn drop(&mut self) {
                // Faʻaauau le tutusa tutusa matou faia i lalo.E faʻatoa tamoʻe lenei peʻa faʻamataʻu se tagata faʻaumatia.
                // Afai o le tasi panics o le a toʻesea.
                while self.0.pop_front_node().is_some() {}
            }
        }

        while let Some(node) = self.pop_front_node() {
            let guard = DropGuard(self);
            drop(node);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // Manaʻomia se le faʻatapulaʻaina olaga e maua 'a
                let node = &*node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // Manaʻomia se le faʻatapulaʻaina olaga e maua 'a
                let node = &*node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // Manaʻomia se le faʻatapulaʻaina olaga e maua 'a
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &mut node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a mut T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // Manaʻomia se le faʻatapulaʻaina olaga e maua 'a
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &mut node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

/// O se faʻamau i luga ole `LinkedList`.
///
/// O le `Cursor` e pei o se faʻasolosolo, seʻi vagana e mafai ona saoloto ona sailia tua-ma-luma.
///
/// E masani ona malolo Cursors i le va o ni elemeni se lua i le lisi, ma faasino igoa i se auala faʻasolosolo lelei.
/// Ina ia taulimaina o lenei, ei ai se "ghost" e lē o ni elemene o le gauai `None` le va o le ulu ma le siʻusiʻu o le lisi.
///
///
/// A faia, amata amata upu i luma o le lisi, poʻo le "ghost" leai-elemeni pe a fai o le lisi e avanoa.
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct Cursor<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T> Clone for Cursor<'_, T> {
    fn clone(&self) -> Self {
        let Cursor { index, current, list } = *self;
        Cursor { index, current, list }
    }
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for Cursor<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Cursor").field(&self.list).field(&self.index()).finish()
    }
}

/// O se faʻamau i luga ole `LinkedList` ma faʻagaioiga faʻagaioiga.
///
/// O le `Cursor` e pei o se faʻasolosolo, seʻi vagana e mafai ona saoloto le sailia o tua-ma-luma, ma e mafai ona suia ma le saogalemu le lisi i le taimi e faʻataʻamilo ai.
/// O lenei ona ua nonoa le olaga atoa o ana mau gauai atu i lona lava olaga atoa, nai lo le na o le lisi autu.
/// O lona uiga e le mafai e tagata faʻafefe ona avatua tele elemeni i le taimi e tasi.
///
/// E masani ona malolo Cursors i le va o ni elemeni se lua i le lisi, ma faasino igoa i se auala faʻasolosolo lelei.
/// Ina ia taulimaina o lenei, ei ai se "ghost" e lē o ni elemene o le gauai `None` le va o le ulu ma le siʻusiʻu o le lisi.
///
///
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct CursorMut<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a mut LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for CursorMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("CursorMut").field(&self.list).field(&self.index()).finish()
    }
}

impl<'a, T> Cursor<'a, T> {
    /// Faʻafoʻi mai le faasino upu tulaga i totonu ole `LinkedList`.
    ///
    /// Lenei toe faafoʻi `None` pe a fai o le faʻamau o loʻo tusi nei i le "ghost" leai elemeni.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// Siʻi le faʻamau i le isi elemeni o le `LinkedList`.
    ///
    /// Afai o le faʻamau e tusi i le "ghost" leai elemeni ona o lenei o le a faʻasolo atu i le muamua elemeni o le `LinkedList`.
    /// Afai o loʻo faʻasino i le elemeni mulimuli o le `LinkedList` o lona uiga o le a siʻi atu i le "ghost" e leʻo elemeni.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // Sa leai se matou elemeni oi ai nei;o le faʻamau na nofo i le amataga tulaga O le elemeni mulimuli ane e tatau ona avea ma ulu o le lisi
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // Sa i ai le tatou elemeni muamua, o lea tatou o atu i le isi
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// Siʻi le faʻamau i le muamua elemeni o le `LinkedList`.
    ///
    /// Afai o le faʻamau e tusi i le "ghost" leai elemeni ona o lenei o le a faʻasolo atu i le elemeni mulimuli o le `LinkedList`.
    /// Afai o loʻo faʻasino i le muamua elemeni o le `LinkedList` o lona uiga o lenei o le a siʻi atu i le "ghost" leai elemeni.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // Leai se taimi neiUa matou i le amataga o le lisi.Gauai E leai se tasi ma oso i le iuga.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // Fai muamuaTuʻuina atu ma alu i le muamua elemeni.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// Toe foi se faasinomaga i le elemene o le Autu poo le taimi nei e faasino i ai.
    ///
    /// Lenei toe faafoʻi `None` pe a fai o le faʻamau o loʻo tusi nei i le "ghost" leai elemeni.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&self) -> Option<&'a T> {
        unsafe { self.current.map(|current| &(*current.as_ptr()).element) }
    }

    /// Faʻafoʻi mai se faʻasino i le isi elemeni.
    ///
    /// Afai o le faʻamau e tusi i le "ghost" leai elemeni ona toe faafoi lea o le muamua elemene o le `LinkedList`.
    /// Afai o loʻo faʻasino i le elemeni mulimuli o le `LinkedList` ona toe foʻi lea o le `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&self) -> Option<&'a T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &(*next.as_ptr()).element)
        }
    }

    /// Faʻafoʻi mai se faʻasino i le vaega muamua.
    ///
    /// Afai o le faʻamau e tusi i le "ghost" leai elemeni ona toe faʻafoʻi mai lea o le elemeni mulimuli o le `LinkedList`.
    /// Afai o loʻo faʻasino i le muamua elemeni o le `LinkedList` ona toe foʻi lea o le `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&self) -> Option<&'a T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &(*prev.as_ptr()).element)
        }
    }
}

impl<'a, T> CursorMut<'a, T> {
    /// Faʻafoʻi mai le faasino upu tulaga i totonu ole `LinkedList`.
    ///
    /// Lenei toe faafoʻi `None` pe a fai o le faʻamau o loʻo tusi nei i le "ghost" leai elemeni.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// Siʻi le faʻamau i le isi elemeni o le `LinkedList`.
    ///
    /// Afai o le faʻamau e tusi i le "ghost" leai elemeni ona o lenei o le a faʻasolo atu i le muamua elemeni o le `LinkedList`.
    /// Afai o loʻo faʻasino i le elemeni mulimuli o le `LinkedList` o lona uiga o le a siʻi atu i le "ghost" e leʻo elemeni.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // Sa leai se matou elemeni oi ai nei;o le faʻamau na nofo i le amataga tulaga O le elemeni mulimuli ane e tatau ona avea ma ulu o le lisi
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // Sa i ai le tatou elemeni muamua, o lea tatou o atu i le isi
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// Siʻi le faʻamau i le muamua elemeni o le `LinkedList`.
    ///
    /// Afai o le faʻamau e tusi i le "ghost" leai elemeni ona o lenei o le a faʻasolo atu i le elemeni mulimuli o le `LinkedList`.
    /// Afai o loʻo faʻasino i le muamua elemeni o le `LinkedList` o lona uiga o lenei o le a siʻi atu i le "ghost" leai elemeni.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // Leai se taimi neiUa matou i le amataga o le lisi.Gauai E leai se tasi ma oso i le iuga.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // Fai muamuaTuʻuina atu ma alu i le muamua elemeni.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// Toe foi se faasinomaga i le elemene o le Autu poo le taimi nei e faasino i ai.
    ///
    /// Lenei toe faafoʻi `None` pe a fai o le faʻamau o loʻo tusi nei i le "ghost" leai elemeni.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&mut self) -> Option<&mut T> {
        unsafe { self.current.map(|current| &mut (*current.as_ptr()).element) }
    }

    /// Faʻafoʻi mai se faʻasino i le isi elemeni.
    ///
    /// Afai o le faʻamau e tusi i le "ghost" leai elemeni ona toe faafoi lea o le muamua elemene o le `LinkedList`.
    /// Afai o loʻo faʻasino i le elemeni mulimuli o le `LinkedList` ona toe foʻi lea o le `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&mut self) -> Option<&mut T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &mut (*next.as_ptr()).element)
        }
    }

    /// Faʻafoʻi mai se faʻasino i le vaega muamua.
    ///
    /// Afai o le faʻamau e tusi i le "ghost" leai elemeni ona toe faʻafoʻi mai lea o le elemeni mulimuli o le `LinkedList`.
    /// Afai o loʻo faʻasino i le muamua elemeni o le `LinkedList` ona toe foʻi lea o le `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&mut self) -> Option<&mut T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &mut (*prev.as_ptr()).element)
        }
    }

    /// Faʻafoʻi mai se faitauga naʻo tusi e faʻasino i le vaega o loʻo iai nei.
    ///
    /// O le olaga atoa o le `Cursor` toe faʻafoʻi ua fusia i le `CursorMut`, o lona uiga e le mafai ona ola i fafo atu o le `CursorMut` ma o le `CursorMut` ua faʻaʻaisa mo le olaga atoa o le `Cursor`.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn as_cursor(&self) -> Cursor<'_, T> {
        Cursor { list: self.list, current: self.current, index: self.index }
    }
}

// Lenei o le lisi faʻatonutonu gaioiga

impl<'a, T> CursorMut<'a, T> {
    /// Faʻaofi se elemeni fou i le `LinkedList` pe a maeʻa le tasi nei.
    ///
    /// Afai o le faʻamau e tusi i le "ghost" leai elemeni ona faʻaofi lea o le elemeni fou i luma o le `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_after(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, spliced_node, spliced_node, 1);
            if self.current.is_none() {
                // O le "ghost" non-element's index ua suia.
                self.index = self.list.len;
            }
        }
    }

    /// Faʻaofi se elemeni fou i le `LinkedList` ae leʻi oʻo mai nei.
    ///
    /// Afai o le faʻamau e tusi i le "ghost" leai elemeni ona faʻaofi lea o le elemeni fou i le faaiuga o le `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_before(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, spliced_node, spliced_node, 1);
            self.index += 1;
        }
    }

    /// Aveʻese le mea o loʻo i ai nei mai le `LinkedList`.
    ///
    /// O le elemene na aveʻese na toe faʻafoʻi mai, ma o le cursor ua minoi e tusi i le isi elemeni i le `LinkedList`.
    ///
    ///
    /// Afai o le faʻamau o loʻo tusi nei i le "ghost" leai-elemeni ona leai lea o se elemeni e toʻesea ma `None` ua toe faʻafoʻi mai.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current(&mut self) -> Option<T> {
        let unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);
            let unlinked_node = Box::from_raw(unlinked_node.as_ptr());
            Some(unlinked_node.element)
        }
    }

    /// Aveʻese le mea o loʻo i ai nei mai le `LinkedList` e aunoa ma le faʻasoasoaina o le lisi node.
    ///
    /// Le node na aveʻesea ua toe foʻi mai o se `LinkedList` fou o loʻo iai naʻo lenei node.
    /// O le kipi e aveese e tusi i le isi elemeni i le taimi nei `LinkedList`.
    ///
    /// Afai o le faʻamau o loʻo tusi nei i le "ghost" leai-elemeni ona leai lea o se elemeni e toʻesea ma `None` ua toe faʻafoʻi mai.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current_as_list(&mut self) -> Option<LinkedList<T>> {
        let mut unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);

            unlinked_node.as_mut().prev = None;
            unlinked_node.as_mut().next = None;
            Some(LinkedList {
                head: Some(unlinked_node),
                tail: Some(unlinked_node),
                len: 1,
                marker: PhantomData,
            })
        }
    }

    /// Faʻaofiina elemene mai le `LinkedList` tuʻuina atu i le maeʻa ai o le taimi nei.
    ///
    /// Afai o le faʻamau e tusi i le "ghost" le o elemeni ona faʻaofiina lea o elemene fou i le amataga o le `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_after(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, splice_head, splice_tail, splice_len);
            if self.current.is_none() {
                // O le "ghost" non-element's index ua suia.
                self.index = self.list.len;
            }
        }
    }

    /// Faʻaofiina elemene mai le `LinkedList` tuʻuina atu i luma o le taimi nei tasi.
    ///
    /// Afai o le faʻamau e tusi i le "ghost" le o elemeni ona faʻaofi ai lea o elemene fou i le iʻuga o le `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_before(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, splice_head, splice_tail, splice_len);
            self.index += splice_len;
        }
    }

    /// Vaeluaina le lisi i le lua pe a maeʻa le elemeni o loʻo i ai nei.
    /// Lenei o le a toe faʻafoʻi mai se lisi fou aofia ai mea uma pe a maeʻa le faʻamau, ma le uluaʻi lisi taofia mea uma muamua.
    ///
    ///
    /// Afai o le faʻamau e tusi i le "ghost" leai-elemeni ona faʻasolo uma mea o le `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_after(&mut self) -> LinkedList<T> {
        let split_off_idx = if self.index == self.list.len { 0 } else { self.index + 1 };
        if self.index == self.list.len {
            // O le "ghost" non-element's index ua suia i le 0.
            self.index = 0;
        }
        unsafe { self.list.split_off_after_node(self.current, split_off_idx) }
    }

    /// Vavae le lisi i le lua i luma o le taimi nei elemeni.
    /// Lenei o le a toe faafoi mai se fou lisi aofia ai mea uma i luma o le faʻamau, ma le uluaʻi lisi taofia mea uma mulimuli ane.
    ///
    ///
    /// Afai o le faʻamau e tusi i le "ghost" leai-elemeni ona faʻasolo uma mea o le `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_before(&mut self) -> LinkedList<T> {
        let split_off_idx = self.index;
        self.index = 0;
        unsafe { self.list.split_off_before_node(self.current, split_off_idx) }
    }
}

/// O se iterator gaosia e valaau `drain_filter` i LinkedList.
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub struct DrainFilter<'a, T: 'a, F: 'a>
where
    F: FnMut(&mut T) -> bool,
{
    list: &'a mut LinkedList<T>,
    it: Option<NonNull<Node<T>>>,
    pred: F,
    idx: usize,
    old_len: usize,
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Iterator for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        while let Some(mut node) = self.it {
            unsafe {
                self.it = node.as_ref().next;
                self.idx += 1;

                if (self.pred)(&mut node.as_mut().element) {
                    // `unlink_node` e lelei i le aliasing `element` faʻasino.
                    self.list.unlink_node(node);
                    return Some(Box::from_raw(node.as_ptr()).element);
                }
            }
        }

        None
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Drop for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T, F>(&'r mut DrainFilter<'a, T, F>)
        where
            F: FnMut(&mut T) -> bool;

        impl<'r, 'a, T, F> Drop for DropGuard<'r, 'a, T, F>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                self.0.for_each(drop);
            }
        }

        while let Some(item) = self.next() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T: fmt::Debug, F> fmt::Debug for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.list).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.list.pop_front()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.list.len, Some(self.list.len))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.list.pop_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for LinkedList<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Self {
        let mut list = Self::new();
        list.extend(iter);
        list
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for LinkedList<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Faʻaumatia le lisi i totonu o se faʻasolosolo maua elemeni i le taua.
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { list: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a LinkedList<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut LinkedList<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Extend<T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, elem: T) {
        self.push_back(elem);
    }
}

impl<I: IntoIterator> SpecExtend<I> for LinkedList<I::Item> {
    default fn spec_extend(&mut self, iter: I) {
        iter.into_iter().for_each(move |elt| self.push_back(elt));
    }
}

impl<T> SpecExtend<LinkedList<T>> for LinkedList<T> {
    fn spec_extend(&mut self, ref mut other: LinkedList<T>) {
        self.append(other);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &'a T) {
        self.push_back(elem);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq> PartialEq for LinkedList<T> {
    fn eq(&self, other: &Self) -> bool {
        self.len() == other.len() && self.iter().eq(other)
    }

    fn ne(&self, other: &Self) -> bool {
        self.len() != other.len() || self.iter().ne(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for LinkedList<T> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.iter().partial_cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for LinkedList<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.iter().cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for LinkedList<T> {
    fn clone(&self) -> Self {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        let mut iter_other = other.iter();
        if self.len() > other.len() {
            self.split_off(other.len());
        }
        for (elem, elem_other) in self.iter_mut().zip(&mut iter_other) {
            elem.clone_from(elem_other);
        }
        if !iter_other.is_empty() {
            self.extend(iter_other.cloned());
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for LinkedList<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash> Hash for LinkedList<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        for elt in self {
            elt.hash(state);
        }
    }
}

// Faamautinoa o le `LinkedList` ma ona faitau-na faʻailoilo e osi feagaiga i latou ituaiga tapulaʻa.
#[allow(dead_code)]
fn assert_covariance() {
    fn a<'a>(x: LinkedList<&'static str>) -> LinkedList<&'a str> {
        x
    }
    fn b<'i, 'a>(x: Iter<'i, &'static str>) -> Iter<'i, &'a str> {
        x
    }
    fn c<'a>(x: IntoIter<&'static str>) -> IntoIter<&'a str> {
        x
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Send for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for IterMut<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for IterMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Send for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Send> Send for CursorMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for CursorMut<'_, T> {}