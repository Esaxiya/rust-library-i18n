use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef, Root};

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Faʻaputuga luga a atonu underfull node e ala i le tuʻufaʻatasia ma pe gaoi mai se tei.
    /// A faʻamanuiaina ae i le tau o le tuʻumuliina o le neo matua, toe faʻafoʻi lena node matua nati.
    /// Faʻafoʻi mai le `Err` pe a fai o le node o se aʻa gaogao.
    ///
    fn fix_node_through_parent(
        self,
    ) -> Result<Option<NodeRef<marker::Mut<'a>, K, V, marker::Internal>>, Self> {
        let len = self.len();
        if len >= MIN_LEN {
            Ok(None)
        } else {
            match self.choose_parent_kv() {
                Ok(Left(mut left_parent_kv)) => {
                    if left_parent_kv.can_merge() {
                        let parent = left_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        left_parent_kv.bulk_steal_left(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Ok(Right(mut right_parent_kv)) => {
                    if right_parent_kv.can_merge() {
                        let parent = right_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        right_parent_kv.bulk_steal_right(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Err(root) => {
                    if len > 0 {
                        Ok(None)
                    } else {
                        Err(root)
                    }
                }
            }
        }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// E faʻaputu i lalo le avanoa, ma afai o le mafuaʻaga lena e faʻavaivaia ai le matua o lona matua, ona faʻapipiʻi lea o le matua.
    /// Faʻafoʻi `true` peʻa faʻapipiʻi le laʻau, `false` pe a le mafai ona ua leai se mea na faʻaaogaina.
    ///
    /// O lenei metotia e le faʻamoemoeina tuaʻa ua uma ona le amanaiaina le ulufale atu ma panics pe a fetaiaʻi ma se gaogao tuaʻa.
    ///
    ///
    ///
    pub fn fix_node_and_affected_ancestors(mut self) -> bool {
        loop {
            match self.fix_node_through_parent() {
                Ok(Some(parent)) => self = parent.forget_type(),
                Ok(None) => return true,
                Err(_) => return false,
            }
        }
    }
}

impl<K, V> Root<K, V> {
    /// Aveese avanoa avanoa i luga o le pito i luga, ae taofia se lau avanoa pe afai o le atoa laau leai se mea.
    pub fn fix_top(&mut self) {
        while self.height() > 0 && self.len() == 0 {
            self.pop_internal_level();
        }
    }

    /// Faʻaputuputu luga pe tuʻufaʻatasia ni soʻoga i lalo o le laʻau taumatau o le laʻau.
    /// O isi nodes, o mea e le o le aʻa poʻo le pito taumatau o le edge, e tatau ona i ai a itiiti mai MIN_LEN elemeni.
    ///
    pub fn fix_right_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().last_kv().fix_right_border_of_right_edge();
            self.fix_top();
        }
    }

    /// O le clone symmetric o `fix_right_border`.
    pub fn fix_left_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().first_kv().fix_left_border_of_left_edge();
            self.fix_top();
        }
    }

    /// Faʻaputuputu ni vaega node i lalo ole itu taumatau ole laʻau.
    /// O le isi nodes, oi latou e le o le aʻa po o se rightmost edge, e tatau ona saunia i ai e oo atu i elemene MIN_LEN gaoia.
    ///
    pub fn fix_right_border_of_plentiful(&mut self) {
        let mut cur_node = self.borrow_mut();
        while let Internal(internal) = cur_node.force() {
            // Siaki pe o le sili-tamaititi e underfull.
            let mut last_kv = internal.last_kv().consider_for_balancing();
            debug_assert!(last_kv.left_child_len() >= MIN_LEN * 2);
            let right_child_len = last_kv.right_child_len();
            if right_child_len < MIN_LEN {
                // E tatau ona tatou gaoi.
                last_kv.bulk_steal_left(MIN_LEN - right_child_len);
            }

            // Alu i lalo.
            cur_node = last_kv.into_right_child();
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    fn fix_left_border_of_left_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_left_child().first_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }

    fn fix_right_border_of_right_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_right_child().last_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Faʻaputuputu luga le tama agavale, faʻapea o le tama saʻo e le o underfull, ma aiaia se faʻaopopo elemeni e faʻatagaina ai le tuʻufaʻatasia o lana fanau i le taimi e aunoa ma le avea underfull.
    ///
    /// Faʻafoʻi le tamaitiiti tauagavale.
    ///
    fn fix_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let left_len = internal_kv.left_child_len();
        debug_assert!(internal_kv.right_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` e aloese ai mai toe faasaʻoina pe afai tuufaatasia e tupu i luga o le tulaga e sosoo ai.
            let count = (MIN_LEN + 1).saturating_sub(left_len);
            if count > 0 {
                internal_kv.bulk_steal_right(count);
            }
            internal_kv.into_left_child()
        }
    }

    /// Teuina o le tama taumatau, manatu le agavale tamaititi e le underfull, ma aiaia se faʻaopoopo elemeni e faʻatagaina le tuʻufaʻatasia o lana fanau i le taimi e aunoa ma le avea underfull.
    ///
    /// Faʻafoʻi i soʻo se mea na iʻu i ai le tama saʻo.
    ///
    fn fix_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let right_len = internal_kv.right_child_len();
        debug_assert!(internal_kv.left_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` e aloese ai mai toe faasaʻoina pe afai tuufaatasia e tupu i luga o le tulaga e sosoo ai.
            let count = (MIN_LEN + 1).saturating_sub(right_len);
            if count > 0 {
                internal_kv.bulk_steal_left(count);
            }
            internal_kv.into_right_child()
        }
    }
}