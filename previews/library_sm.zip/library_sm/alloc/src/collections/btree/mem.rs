use core::intrinsics;
use core::mem;
use core::ptr;

/// Lenei suia le taua i tua atu o le `v` tulaga ese faʻasino i le valaʻauina o le talafeagai gaioiga.
///
///
/// Afai o le panic e tupu i le `change` tapunia, o le atoa gaioiga o le a toʻesea.
#[allow(dead_code)] // teu e fai ma faʻataʻitaʻiga ma mo future faʻaaogaina
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Lenei suia le taua i tua atu o le `v` tulaga ese faʻasino i le valaʻauina o le talafeagai gaioiga, ma toe faʻafoʻi mai se iʻuga maua i luga o le ala.
///
///
/// Afai o le panic e tupu i le `change` tapunia, o le atoa gaioiga o le a toʻesea.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}