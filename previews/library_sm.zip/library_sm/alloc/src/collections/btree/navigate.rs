use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Aveese le tumau mo se isi, le suia e tutusa o le tutusa tulaga.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Mauaina le lau ese ese laupepa delimiting se faʻapitoa laina i se laʻau.
    /// Faʻafoʻi pe tasi se pea o eseʻese 'au i le laʻau lava e tasi poʻo se pea o avanoa avanoa.
    ///
    /// # Safety
    ///
    /// Vagana `BorrowType` o `Immut`, aua le faʻaogaina faʻalua kopi e asiasi faalua i le KV tutusa.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Tutusa ma `(root1.first_leaf_edge(), root2.last_leaf_edge())` ae sili atu ona aoga.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Mauaina le pea o lau laupepa delimiting se faʻapitoa vaʻaia i se laʻau.
    ///
    /// O le taunuʻuga e aoga tele pe a fai o le laʻau e okaina i le ki, pei o le laʻau i le `BTreeMap` o.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // SAFETI: o a tatou nono ituaiga e le mafai ona suia.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Mauaina le pea o lau laupepa delimiting se atoa laau.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Vaeluaina se faʻapitoa tulaga ese i se pea o lau laupepa delimiting se faʻatulagaina laina.
    /// O le iʻuga e leai se uiga eseʻese faʻasino faʻatagaina (some) suiga, lea e tatau ona faʻaaoga ma le faʻaeteete.
    ///
    /// O le taunuʻuga e aoga tele pe a fai o le laʻau e okaina i le ki, pei o le laʻau i le `BTreeMap` o.
    ///
    ///
    /// # Safety
    /// Aua le faʻaogaina faʻalua kopi e asia ai le KV tutusa faʻalua.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// O loʻo vaeluaina se faʻamatalaga tulaga ese i se pea o lau laupepa e faʻatapulaʻaina atoa le laʻau.
    /// O iʻuga e le o ni mea taua e faʻatagaina ai le fesuiaʻiga (o faʻatauaina naʻo), e tatau foʻi ona faʻaaoga ma le faʻaeteete.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Matou te toe faʻaluaina le aʻa NodeRef ii-matou te le asiasi faʻalua ile KV lava e tasi, ma e le uma le faʻasoasoaina o tau aoga.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// O loʻo vaeluaina se faʻamatalaga tulaga ese i se pea o lau laupepa e faʻatapulaʻaina atoa le laʻau.
    /// O iʻuga e le o ni mea taua e faʻatagaina ai se suiga tele, ma e tatau ona faʻaaoga ma le faʻaeteete tele.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Matou te faʻaluaina le aʻa NodeRef ii-matou te le mafai ona faʻaaoga i se auala e soʻose faʻaoga ai faʻamatalaga na maua mai le aʻa.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Tuuina atu se lau edge au, faʻafoʻi [`Result::Ok`] ma se au i le tuaoi KV i le itu taumatau, a le o le i le lau lava laupepa poʻo se tuaʻa node.
    ///
    /// Afai o le lau edge o le mulimuli mulimuli i le laʻau, faʻafoʻi [`Result::Err`] ma le aʻa aʻa.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Tuuina atu se lau edge au, faʻafoʻi [`Result::Ok`] ma se au i le tuaoi KV i le itu agavale, lea a le o le tutusa laupepa laʻau poʻo se tuaʻa node.
    ///
    /// Afai o le lau edge o le muamua laʻau i le laʻau, faʻafoʻi [`Result::Err`] ma le aʻa node.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Tuʻuina i totonu le edge au, faʻafoʻi [`Result::Ok`] ma se au i le KV tuaoi i le itu taumatau, a le o le i totonu o le faʻatonu i totonu poʻo i se tuaʻa tuaʻoga.
    ///
    /// Afai o le edge i totonu o le mulimuli lea i le laʻau, faʻafoʻi [`Result::Err`] ma le aʻa aʻa.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Tuuina atu le lau edge au i totonu o se laau mate, toe faafoi le isi lau edge i le itu taumatau, ma le autu-taua paʻaga i le va, lea e le gata i le lau lava node, i se tuaa node, pe leai.
    ///
    ///
    /// Lenei metotia faʻapisinisi foi translocates soʻo se node(s) e oʻo i le faaiuga o.
    /// O lona uiga afai e le toe i ai se paʻu taua-taua, o le toe vaega o le laʻau o le a faʻasese ma e leai se mea o totoe e toe faʻafoʻi.
    ///
    /// # Safety
    /// O le edge na aumai e le tatau ona toe faʻafoʻi mai e le paʻaga `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Tuuina atu le lau edge au i totonu o se laau mate, toe faafoi le isi lau edge i le itu tauagavale, ma le autu-taua paʻaga i le va, lea a le o le tutusa laupepa laulaau, i se tuaa node, pe leai.
    ///
    ///
    /// Lenei metotia faʻapisinisi foi translocates soʻo se node(s) e oʻo i le faaiuga o.
    /// O lona uiga afai e le toe i ai se paʻu taua-taua, o le toe vaega o le laʻau o le a faʻasese ma e leai se mea o totoe e toe faʻafoʻi.
    ///
    /// # Safety
    /// O le edge na aumai e le tatau ona toe faʻafoʻi mai e le paʻaga `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Faʻasese se faʻaputuga o faʻapipiʻiga mai laulaʻau e oʻo i le aʻa.
    /// Na o le pau lava lenei o le auala e fegasoloaʻi ai le toega o le laʻau ina ua uma ona fetagofi le `deallocating_next` ma le `deallocating_next_back` i itu uma o le laʻau, ma ua oʻo foi i le tutusa o le edge.
    /// E pei ona fuafuaina na o le valaauina pe a toe ki uma ma taua ua toe faʻafoʻi mai, e leai se faʻamamaina e faia i luga o se tasi o ki po o tulaga taua.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Siʻi le lau edge au i le isi lau edge ma faʻafoʻi faʻasino i le ki ma le aoga i le va.
    ///
    ///
    /// # Safety
    /// E tatau lava ona iai seisi KV ile itu na malaga ai.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Siʻi le lau edge au i le lau muamua edge ma faʻafoʻi faʻasino i le ki ma le aoga i le va.
    ///
    ///
    /// # Safety
    /// E tatau lava ona iai seisi KV ile itu na malaga ai.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Siʻi le lau edge au i le isi lau edge ma faʻafoʻi faʻasino i le ki ma le aoga i le va.
    ///
    ///
    /// # Safety
    /// E tatau lava ona iai seisi KV ile itu na malaga ai.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // O le faia o lenei mea mulimuli e sili atu le saoasaoa, e tusa ai ma faʻailoga.
        kv.into_kv_valmut()
    }

    /// Siʻi le lau edge au i le lau muamua ma faʻafoʻi faʻasino i le ki ma le aoga i le va.
    ///
    ///
    /// # Safety
    /// E tatau lava ona iai seisi KV ile itu na malaga ai.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // O le faia o lenei mea mulimuli e sili atu le saoasaoa, e tusa ai ma faʻailoga.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Siʻi le lau edge au i le isi lau edge ma toe faafoʻi le ki ma le aoga i le va, feʻaveaʻiga soʻo se avanoa tuʻua i tua ae tuua le tutusa edge i ona matua nini tautau.
    ///
    /// # Safety
    /// - E tatau lava ona iai seisi KV ile itu na malaga ai.
    /// - O lena KV e leʻi toe faʻafoʻi mai e le paʻaga `next_back_unchecked` i luga o soʻo se kopi o au o loʻo faʻaaoga e savali ai le laʻau.
    ///
    /// Pau lava le auala saogalemu e faʻaauau ai ma le au faʻafouina o le faʻatusatusaina lea, paʻu i lalo, toe valaʻau lenei metotia i lalo o lona saogalemu tulaga, pe valaʻau le counterpart `next_back_unchecked` i lalo o lona saogalemu tulaga.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Siʻi le lau edge au i le lau muamua edge ma toe faafoʻi le ki ma le aoga i le va, feʻaveaʻiga soʻo se avanoa tuʻu i tua ao tuua le tutusa edge i ona matua nini tautau.
    ///
    /// # Safety
    /// - E tatau lava ona iai seisi KV ile itu na malaga ai.
    /// - O lena lau edge e leʻi toe faʻafoʻi mai e le paʻaga `next_unchecked` i luga o ni kopi o au e faʻaoga e savali ai le laʻau.
    ///
    /// Pau lava le auala saogalemu e faʻaauau ai ma le au faʻafouina o le faʻatusatusaina lea, paʻu i lalo, toe valaʻau lenei metotia i lalo o lona saogalemu tulaga, pe valaʻau le counterpart `next_unchecked` i lalo o lona saogalemu tulaga.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Faʻafoi le lau agavale edge i totonu poʻo lalo o le node, i se isi faʻaupuga, le edge e te manaʻomia muamua pe a faʻatautaia luma (pe mulimuli pe a folau i tua).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Faʻafoʻi le lau pito taumatau edge i totonu poʻo lalo o le node, i se isi faʻaupuga, le edge e te manaʻomia mulimuli pe a folau i luma (pe muamua pe a faʻataʻitaʻi i tua).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Asiasi laupepa laulaʻau ma totonu KVs i le faʻasologa o ki oʻo aʻe, ma asiasi foʻi i totonu i le atoa i le loloto muamua faʻatonuga, o lona uiga o totonu iviite muamua i a latou KV taʻitasi ma a latou tamaʻi node.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Fuafua le numera o elemeni i le (lalo) laʻau.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Faʻafoi le lau edge latalata i le KV mo folauga i luma.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Faʻafoi le lau edge latalata i le KV mo faʻataʻamilosaga i tua.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}