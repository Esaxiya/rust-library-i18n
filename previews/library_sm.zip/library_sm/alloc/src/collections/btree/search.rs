use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// O se aofia aofia ai e vaʻai mo, pei lava o le `Bound::Included(T)`.
    Included(T),
    /// O se faʻatapulaʻa noatia e vaʻai mo, pei lava o `Bound::Excluded(T)`.
    Excluded(T),
    /// O se faʻatonutonu aofia aofia ai, pei lava o le `Bound::Unbounded`.
    AllIncluded,
    /// O se faʻatapulaʻa faʻatapulaʻa noatia.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Vaʻai i luga o le ki aumai i se (sub) laʻau laʻau o loʻo faʻaalu i le node, toe faʻasolosolo.
    /// Faʻafoʻi mai le `Found` ma le au o le tutusa KV, pe a fai e iai.
    /// A leai, faʻafoʻi mai le `GoDown` ma le au o le lau edge o loʻo i ai le ki.
    ///
    /// O le taunuʻuga e aoga tele pe a fai o le laʻau e okaina i le ki, pei o le laʻau i le `BTreeMap` o.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// E alu ifo i le faʻasologa lata mai o le edge fetaui i le pito i lalo o le laina e ese mai le edge tutusa le pito i luga luga, ie, o le latalata latalata i ai e le itiiti ifo ma le tasi ki o loʻo i totonu o le laina.
    ///
    ///
    /// A maua, toe faafoʻi le `Ok` ma lena node, o le paga o faʻailoga a le edge o loʻo faʻatapulaʻaina ai le laina, ma le lua faʻatapulaʻaina o tapulaʻa mo le faʻaauauina o le sailiga i tamaʻi tamaʻi, neʻi i totonu le node.
    ///
    /// Afai e le maua, toe faafoi se `Err` ma le lau edge fetaui i le atoa laina.
    ///
    /// O le taunuʻuga e aoga pe a fai o le laʻau e okaina i le ki.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // Inlining nei fesuiaʻiga tatau ona aloese mai.
        // Matou te manatu o tuaoi lipotia e `range` tumau pea tutusa, ae o se faʻatinoina faʻafitauli mafai ona suia i le va o telefoni (#81138).
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// Maua se edge i le node delimiting le pito i lalo o le laina.
    /// Faʻafoi foi le pito i lalo lalo e faʻaaoga mo le faʻaauauina o le sailiga i le tutusa tamaʻi node, pe a fai o `self` o se i totonu totonu.
    ///
    ///
    /// O le taunuʻuga e aoga pe a fai o le laʻau e okaina i le ki.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// Faʻailoga o `find_lower_bound_edge` mo le pito i luga fusia.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Vaʻai i luga o le ki foaʻi i le node, aunoa ma le toe faʻafoʻi.
    /// Faʻafoʻi mai le `Found` ma le au o le tutusa KV, pe a fai e iai.
    /// A leai, toe faafoi le `GoDown` ma le au o le edge e maua ai le ki (pe a fai o le node o loʻo i totonu) pe o le a le ki e mafai ona tuʻuina i totonu.
    ///
    ///
    /// O le taunuʻuga e aoga tele pe a fai o le laʻau e okaina i le ki, pei o le laʻau i le `BTreeMap` o.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// Faʻafoʻi a le KV index i le node o loʻo i ai le ki (poʻo se tutusa), poʻo le edge index o lo o i ai le ki.
    ///
    ///
    /// O le taunuʻuga e aoga tele pe a fai o le laʻau e okaina i le ki, pei o le laʻau i le `BTreeMap` o.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// Maua se index edge i le node le faʻatapulaʻaina o le pito i lalo o se laina.
    /// Faʻafoi foi le pito i lalo lalo e faʻaaoga mo le faʻaauauina o le sailiga i le tutusa tamaʻi node, pe a fai o `self` o se i totonu totonu.
    ///
    ///
    /// O le taunuʻuga e aoga pe a fai o le laʻau e okaina i le ki.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// Faʻailoga o `find_lower_bound_index` mo le pito i luga fusia.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}