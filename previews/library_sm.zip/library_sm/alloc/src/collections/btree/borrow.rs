use core::marker::PhantomData;
use core::ptr::NonNull;

/// Faʻataʻitaʻi le toe tolopoina o se faʻamatalaga tulaga ese, pe a e iloa o le teteʻe ma ana fanau uma (ie, o faʻasino uma ma faʻasino na maua mai ai) o le a le toe faʻaaogaina i se taimi, pe a maeʻa ona e manaʻo lea e toe faʻaaoga le uluaʻi faʻavae tulaga ese. .
///
///
/// E masani ona tago le tagata nonogatupe ile faʻaputuina o nonogatupe mo oe, peitaʻi o nisi auala e faʻatonutonu ai e faʻasolosolo ona faigata le faʻatonutonu.
/// O le `DormantMutRef` faʻatagaina oe e siaki oe nonoina oe lava, ae o loʻo faʻaalia pea lona faʻaputuga natura, ma faʻapipiʻiina le numera faʻasino upu e manaʻomia e fai ai lenei mea e aunoa ma le le faʻamatalaina o amioga.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Pue se aitalafu tulaga ese, ma vave toe tupe.
    /// Mo le tuʻufaʻatasia, o le olaga atoa o le faʻamatalaga fou e tutusa ma le olaga atoa o le uluaʻi faʻasino, ae oe promise e faʻaaoga ai mo se vaitaimi puʻupuʻu.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // SAFETY: matou te uuina le aitalafu i le atoa 'a ala ile `_marker`, ma matou faʻaalia
        // naʻo lenei mau, o lea e tulaga ese.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Faʻafoʻi i le tulaga ese nono muamua puʻeina.
    ///
    /// # Safety
    ///
    /// O le toe faʻatagaina e tatau ona maeʻa, faʻapea, o le faʻamatalaga na toe faʻafoʻi mai e `new` ma faʻasino uma ma faʻamatalaga na aumai ai, e le tatau ona toe faʻaaogaina.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // SAFETY: o tatou lava tulaga saogalemu faʻapea o lenei faʻasino e toe tulaga ese.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;