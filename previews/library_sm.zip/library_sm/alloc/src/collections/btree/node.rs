// Lenei o se taumafaiga i se faʻatinoga mulimuli i le lelei
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Talu ai o le Rust e leai ni faʻamoemoe faʻalagolago ma le toe faʻataʻitaʻiga o le polymorphic, matou te faia ma le tele o le le saogalemu.
//

// O le autu sini o lenei module o le aloese mai faigata i le togafitia o le laʻau o se lautele (pe a fai e foliga ese foliga) koneteina ma aloese mai le feagai ai ma le tele o le B-Tree invariants.
//
// E pei o lea, e le kea le vaega lea pe o faʻavasega mea e tusia ai, e mafai ona underfull, pe o le a foi le uiga o le underfull.Ae ui i lea, matou te faʻamoemoe i nai tagata aʻafia:
//
// - O laau e tatau ona i ai depth/height toniga.O lona uiga o auala uma i lalo i se laulaʻau mai le node na maua e tutusa lelei le umi.
// - O le node o le umi `n` ei ai `n` ki, `n` taua, ma `n + 1` pito.
//   O lona uiga e oʻo lava i le avanoa leai se mea e tasi le edge.
//   Mo le laupepa laulaʻau, "having an edge" naʻo lona uiga e mafai ona tatou iloa se tulaga i le node, talu ai o lau lau e gaogao ma e le manaʻomia se faʻamaumauga.
// I totonu o le laufanua, o le edge faʻailoa uma se tulaga ma maua ai se faʻasino i se tamaʻi tamaʻi node.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// O le faʻavae faʻailoaina o laupepa laulaʻau ma le vaega o le sui o faʻavaega i totonu.
struct LeafNode<K, V> {
    /// Matou te mananaʻo ia faʻaaloalo i le `K` ma le `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Lenei node's faasino igoa i le matua node's `edges` seti.
    /// `*node.parent.edges[node.parent_idx]` tatau ona tutusa mea ma `node`.
    /// E faʻamautinoaina e amataina lenei mea peʻa leai se aoga le `parent`.
    parent_idx: MaybeUninit<u16>,

    /// Le numera o ki ma faʻataua lenei faleoloa node.
    len: u16,

    /// O faʻamaumauga e teu ai faʻamaumauga moni o le faʻailoga.
    /// E na o le elemene muamua `len` o autau taitasi ua initialized ma aoga.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Faʻailoa muamua se `LeafNode` fou ile nofoaga.
    unsafe fn init(this: *mut Self) {
        // I le avea ai o se tulafono lautele, matou te tuʻuina fanua e le faʻaogaina pe a mafai, aua o lenei e tatau ona tau fai sina saoasaoa ma faigofie e faʻasolosolo ai i Valgrind.
        //
        unsafe {
            // parent_idx, ki, ma mea valea uma atonu o le UseUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Fausia se `LeafNode` fou pusa.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// O le faʻavae faʻavae o node i totonu.E pei foi o le 'LeafNode`s, o nei mea e tatau ona natia i tua o le' BoxedNode`s e puipuia ai le faʻapaʻuina o le ki e le faʻailoaina ma tulaga taua.
/// Soʻo se faʻasino tusi i le `InternalNode` e mafai ona lafo tuʻusaʻo i se faʻasino i le vaega autu o le `LeafNode` o le faʻamau, faʻatagaina le tulafono e galue i luga o laupepa ma faʻavaʻa i totonu lautele e aunoa ma le toe siakiina poʻo le fea o le lua o le faʻasino tusi o loʻo faʻasino i ai.
///
/// O lenei meatotino e mafai e le faʻaaogaina o `repr(C)`.
///
#[repr(C)]
// gdb_providers.py faʻaaoga lenei ituaiga igoa mo introspection.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// O faʻasino i tamaiti o lenei avanoa.
    /// `len + 1` o nei mea ua faʻapea ua amataina ma aoga, seʻi vagana ai le latalata i le iʻuga, a o le laau o loʻo taofia e ala i le nonoina `Dying`, o nisi o nei faʻailo e tautau.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Fausia se `InternalNode` fou pusa.
    ///
    /// # Safety
    /// O le tagata e masani ona faʻailoaina o loʻo i totonu o lo latou mauaina lea e le itiiti ifo ma le tasi le faʻavae muamua ma aoga edge.
    /// O lenei gaioiga e le faʻatuina se ituaiga edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Naʻo le pau le mea e manaʻomia e matou e faʻamautinoaina faʻamatalaga;o pito e atonuUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Se faʻatonutonu, leai-faʻasino faasino i se node.Lenei a le o le umiaina faʻasino i `LeafNode<K, V>` poʻo se umiaina faʻasino i `InternalNode<K, V>`.
///
/// Ae ui i lea, `BoxedNode` e leai se faʻamatalaga e uiga i le lua o ituaiga node o loʻo iai, ma, o se vaega ona o lenei le lava o faʻamatalaga, e le o se tuʻusaʻo ituaiga ma e leai se faʻaumatia.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Le mafuaʻaga o le laʻau.
///
/// Manatua o lenei e leai se mea faʻaleagaina, ma e tatau ona fufulu mama.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Faʻafoʻi mai se laʻau fou, ma ona lava aʻa faʻamau e leai se mea na maua.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` e le tatau ona o.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Mutable nonoina le anaina aa.
    /// E le pei o le `reborrow_mut`, e saogalemu lenei mea aua e le mafai ona faʻaaogaina le tau faʻafuaseʻi e faʻaleagaina ai le aʻa, ma e le mafai foi ona i ai isi faʻasino i le laʻau.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// E tau feololo e nonoina le node aʻa.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Le mafai ona suia fesuiaʻiga i se faʻasino e faʻatagaina le feʻaaliaʻi ma ofaina ni metotia faʻaleagaina ma sinaisi mea.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Faʻaopopo se node fou i totonu ma le tasi edge faʻasino i le muamua node aʻa, faia lena node fou le aʻa node, ma faʻafoʻi ia.
    /// Lenei faʻateleina le maualuga i le 1 ma o le faʻafeagai o `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, vagana ai ua galo ia i tatou o loʻo tatou i ai nei:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Aveʻese le aʻa aʻa i totonu, faʻaaoga lana tama muamua o le aʻa aʻa fou.
    /// E pei ona fuafuaina na o le valaʻauina pe a fai o le aʻa aʻa na o le toatasi le tamaititi, e leai se faʻamamaina e faia i luga o se tasi o ki, taua ma isi tamaiti.
    ///
    /// Lenei faʻaititia le maualuga i le 1 ma o le faʻafeagai o `push_internal_level`.
    ///
    /// Manaʻomia faʻapitoa avanoa i le `Root` mea ae le o le aʻa node;
    /// o le a le faʻaleaogaina isi au pe faʻasino i le aʻa node.
    ///
    /// Panics pe a fai e leai se tulaga i totonu, ie, pe afai o le aʻa aʻa o se lau.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // SAFETY: matou tautino atu o totonu.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // SAFETY: na matou nonoina `self` faʻapitoa ma lona nono ituaiga e faʻapitoa.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // SAFETY: o le muamua edge e amataina i taimi uma.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` e masani ona fiafia i `K` ma `V`, tusa lava pe o le `BorrowType` o `Mut`.
// E sese lenei mea i le tekonolosi, ae le mafai ona maua ai se le saogalemu ona o le faʻaaogaina i totonu o le `NodeRef` aua matou te tumau lautele i le `K` ma le `V`.
//
// Peitaʻi, soʻo se taimi e afifi ai e le lautele le `NodeRef`, ia mautinoa o loʻo iai le sao saʻo.
//
/// O se faʻasino i se node.
///
/// Lenei ituaiga o loʻo i ai le numera o tapulaʻa e faʻatonutonu auala e galue ai:
/// - `BorrowType`: O se dummy ituaiga e faʻamatalaina le ituaiga nono ma aveina se olaga atoa.
///    - A `Immut<'a>` lenei, o le `NodeRef` galue malosi pei o `&'a Node`.
///    - A o le `ValMut<'a>` lenei, o le `NodeRef` galue malosi pei o `&'a Node` e tusa ai ma ki ma laʻau faʻavae, ae faʻatagaina foi le tele o fesuiaʻiga faʻasino i mea taua i totonu o le laʻau e nonofo faʻatasi.
///    - A o `Mut<'a>` lenei, o le `NodeRef` galue malosi pei o `&'a mut Node`, e ui lava faʻaaoga metotia faʻatagaina se suia suia faʻatulagaina i se taua e nonofo faʻatasi.
///    - A o le `Owned` lenei, o le `NodeRef` galue malosi pei o `Box<Node>`, ae leai se mea faʻaleagaina, ma e tatau ona fufulu mama.
///    - A o `Dying` lenei, o le `NodeRef` o loʻo galue malosi e pei o `Box<Node>`, ae i ai metotia e faʻaleagaina ai le laʻau laʻititi, ma masani auala, e ui e leʻi makaina e le sefe e valaʻau ai, e mafai ona valaʻau UB pe a taʻu sese.
///
///   Talu ai soʻo se `NodeRef` faʻatagaina le folau i totonu o le laʻau, `BorrowType` faʻaoga lelei i le laʻau atoa, ae le naʻo le faʻamau o ia lava.
/// - `K` ma `V`: Nei o ituaiga o ki ma tulaga faʻatauaina teuina i le ivi.
/// - `Type`: Lenei mafai ona `Leaf`, `Internal`, pe `LeafOrInternal`.
/// A o `Leaf` lenei, o le `NodeRef` faʻasino i le laupepa laʻau, a o le `Internal` lenei o le `NodeRef` faʻasino i se i totonu node, ma a o `LeafOrInternal` lea o le `NodeRef` e ono faʻasino i soʻo se ituaiga node.
///   `Type` e faʻaigoa `NodeType` peʻa faʻaaogaina i fafo atu o le `NodeRef`.
///
/// Uma `BorrowType` ma `NodeType` faʻatapulaʻa ia metotia tatou faʻaogaina, e faʻaaogaina static ituaiga saogalemu.E i ai tapulaʻa i le auala e mafai ai ona tatou faʻaogaina na tapulaʻa:
/// - Mo ituaiga parakalafa taʻitasi, e mafai ona matou faʻauiga se metotia a le o le lautele pe mo se tasi ituaiga faapitoa.
/// Mo se faʻataʻitaʻiga, e le mafai ona matou faʻauiga se metotia e pei o `into_kv` masani mo `BorrowType` uma, pe tasi mo ituaiga uma o loʻo tauaveina le olaga atoa, aua matou te mananaʻo ia toe faʻafoʻi mai `&'a` faʻasino.
///   O le mea lea, matou te faʻamatalaina mo na o le sili ona mamana ituaiga `Immut<'a>`.
/// - E le mafai ona matou faʻamalosia le faʻamalosi mai le fai atu `Mut<'a>` i le `Immut<'a>`.
///   O le mea lea, e tatau ona tatou faʻaali manino le `reborrow` i luga o le `NodeRef` sili atu le malosi ina ia mafai ai ona oʻo atu i se metotia pei o le `into_kv`.
///
/// O metotia uma ile `NodeRef` e toe faʻafoʻi mai ni ituaiga faʻasino, a le:
/// - Ave le `self` ile tau, ma toe faafoi le olaga atoa ave e `BorrowType`.
///   O nisi taimi, e faʻaaoga ai se auala faʻapena, e tatau ona tatou valaʻau i le `reborrow_mut`.
/// - Ave le `self` ile faʻasino, ma le (implicitly) faʻafoʻi mai le olaga lea o le faʻasino, ae leʻo le olaga atoa na ave e `BorrowType`.
/// I lena auala, o le siaki siaki faʻamaoniaina o le `NodeRef` tumau nonoina pe a fai o le toe faʻafoʻi faʻaaoga na faʻaaogaina.
///   O metotia lagolagoina sisitipi loloʻuina lenei tulafono e ala i le toe faʻafoʻi mai o se maka masani, faʻapea, o se faʻasino e aunoa ma se olaga atoa.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// O le numera o laʻasaga o loʻo vavaeʻese ai le laupepa ma le maualuga o laulaʻau, o le faifai pea o le faʻapogai e le mafai ona faʻamatalaina atoa e `Type`, ma e le faʻaputu foi le ivi lava ia.
    /// Naʻo le pau le mea e tatau ona tatou teuina le maualuga o le aʻa aʻa, ma maua uma isi maualuga node mai ai.
    /// Tatau ona leai pe a fai o `Type` o `Leaf` ma leai-pe a fai `Type` o `Internal`.
    ///
    ///
    height: usize,
    /// Le faʻasino i le laupepa poʻo le iʻa i totonu.
    /// O le faʻauiga o le `InternalNode` e mautinoa ai o le faʻasino tusi e aoga i se tasi itu.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Aveʻese se faʻailoga node na teu e pei o le `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Faʻaalia le faʻamatalaga o se ivi i totonu.
    ///
    /// Faʻafoʻi mai se ptr mata e aloese ai mai le faʻaleaogaina o isi faʻasino i lenei node.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // SAFETY: o le static node ituaiga o `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Nonoina se avanoa faʻapitoa i faʻamatalaga o se node i totonu.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Mauaina le umi o le node.Ole numera lea o ki pe faʻataua.
    /// O le aofai o pito `len() + 1`.
    /// Manatua, e ui lava i le saogalemu, valaʻau lenei galuega tauave mafai ona i ai le itu aʻafiaga o le faʻaleaogaina mutable mau na faia le saogalemu code na faia.
    ///
    pub fn len(&self) -> usize {
        // Taua, tatou na o le `len` avanoa tatou te ulufale ai ii.
        // Afai o le BorrowType o le marker::ValMut, atonu e i ai ni mataʻupu taua e mafai ona suia i mea taua e le tatau ona tatou faʻaleaogaina.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Faʻafoʻi le numera o tulaga na vavaeʻese le laupepa ma laulaʻau.
    /// O le maualuga o le maualuga o lona uiga o le node o se laulaʻau lava ia.
    /// Afai e te ataina ni laau ma le aʻa o loʻo i luga, o loʻo fai mai le numera o le faʻamaualugaina e aliali mai ai le iʻa.
    /// Afai e te vaʻaia ni laʻau ma laulaʻau i luga, o loʻo taʻu mai i le numera le maualuga o le laʻau na faʻalautele i luga ae o le avanoa.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Aveese mo se taimi leisi le isi, le ma suia faʻasino i le tutusa node.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Faʻaalia le vaega laulaʻau o soʻo se laupepa poʻo se faʻamau i totonu.
    ///
    /// Faʻafoʻi mai se ptr mata e aloese ai mai le faʻaleaogaina o isi faʻasino i lenei node.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Le node e tatau ona aoga mo le sili atu le LeafNode vaega.
        // E le o se faʻasino i le NodeRef ituaiga aua matou te le iloa pe tatau ona tulaga ese pe faʻasoa.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Mauaina le matua o le taimi nei node.
    /// Faafoi `Ok(handle)` pe afai o le node nei moni lava ei ai se matua, lea manatu `handle` i le edge o le matua o le manatu i le node nei.
    ///
    /// Faʻafoʻi `Err(self)` peʻa fai o le node nei e leai se matua, toe faʻafoʻi le muamua `NodeRef`.
    ///
    /// O le metotia igoa manatu oe ata ata ma aʻa node luga o loʻo i luga.
    ///
    /// `edge.descend().ascend().unwrap()` ma `node.ascend().unwrap().descend()` tatau uma, i luga o le manuia, leai se mea.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Matou te manaʻomia le faʻaaogaina o faʻailoaina mata i node aua, afai o le BorrowType o le marker::ValMut, e ono i ai ni mataʻupu maoaʻe e mafai ona suia i tulaga taua e le tatau ona tatou faʻaleaogaina.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Manatua o le `self` e tatau ona le totogia.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Manatua o le `self` e tatau ona le totogia.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Faʻaalia le laupepa vaega o soʻo se laupepa poʻo se ua i totonu o se le mafai ona suia.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // SAFETY: e le mafai ona i ai ni suiga i lenei laau nonoina e pei o le `Immut`.
        unsafe { &*ptr }
    }

    /// Faʻaalu se vaʻai i ki o loʻo teuina ile node.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Tutusa i le `ascend`, maua se faʻasino i le node's parent node, ae faʻapena foi ona fegasoloai le node i le taimi nei i le gaioiga.
    /// E le sefe le mea lea aua o le taimi nei o le a avanoa pea e ui lava ona faʻamavae.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Le faʻamautinoaina le faʻamaonia i le tuʻufaʻatasiga o faʻamatalaga tumau o lenei node o le `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Le faʻamautuina faʻamaonia i le tuʻufaʻatasia o faʻamaumauga o faʻamatalaga o lenei node o le `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Aveese le tumau mo se isi, faʻavasegaga faʻasino i le node tutusa.Faʻaeteete, aua o lenei metotia e matua mataʻutia, faʻaluaina talu ai atonu e le vave foliga mai mataʻutia.
    ///
    /// Talu ai e mafai ona feoaʻi solo faʻatonutonuga i soʻo se mea o loʻo siʻomia ai le laʻau, e faigofie lava ona faʻaaogaina le faʻasino faʻasino e faʻatumauina ai le faʻasino tonu, i fafo atu o tuaoi, pe le aoga foi i lalo o tulafono faaputu nono.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) mafaufau e faʻaopopo se isi ituaiga parakalafa ile `NodeRef` e faʻatapulaʻaina le faʻaogaina o auala faʻataʻitaʻi i luga o faʻailo ua toe maua, ma taofia ai le le saogalemu.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Faʻatagaina faʻapitoa avanoa i le lau vaega o soʻo se laupepa poʻo se faʻamau i totonu.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // SAFETY: e i ai so matou avanoa i le atoa avanoa.
        unsafe { &mut *ptr }
    }

    /// Ofo faʻapitoa avanoa i le lau vaega o soʻo se laupepa poʻo totonu node.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // SAFETY: e i ai so matou avanoa i le atoa avanoa.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Nonoina faʻapitoa avanoa i se elemeni o le ki autu teuina.
    ///
    /// # Safety
    /// `index` e i totonu o tuaoi o 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // SAFETY: o le telefoni o le a le mafai ona valaʻau isi metotia ia te oe lava
        // Seʻi vagana ua pa'ū le faʻasologa pito taua, aua o loʻo iai lo matou avanoa faʻapitoa mo le olaga atoa o le nonoina.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Faʻatagaina faʻatagaina se avanoa i se elemeni poʻo se fasi vaega o le nofoaga e teu ai tau.
    ///
    /// # Safety
    /// `index` e i totonu o tuaoi o 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // SAFETY: o le telefoni o le a le mafai ona valaʻau isi metotia ia te oe lava
        // Seʻi vagana ua paʻu le faʻasologa o faʻamaumauga o mea taua, aua e i ai le tatou avanoa tulaga ese mo le olaga atoa o le nonogatupe.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Faʻatagaina faʻatagaina se avanoa i se elemeni poʻo se fasi vaega o le nofoaga e teu ai mea mo edge mea.
    ///
    /// # Safety
    /// `index` e i totonu o tuaoi o le 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // SAFETY: o le telefoni o le a le mafai ona valaʻau isi metotia ia te oe lava
        // Seʻia paʻu le paʻu o le fasi pepa a le edge, ona e iai la matou avanoa faʻapitoa mo le olaga atoa o le nonogatupe.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Le node sili atu nai lo `idx` amata elemeni.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // E na ona matou faia o se faʻasino i le tasi elemeni matou te fiafia i ai, e aloese ai mai faʻaigoa ma mataʻina faʻasino i isi elemene, aemaise lava, i latou na toe foʻi mai i le na valaʻau i muamua faʻamatalaga.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // E tatau ona tatou faʻamalosi atu i faʻatonutonu laina faʻasolo ona o le Rust lomiga #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Faʻatagaina se avanoa faʻapitoa i le umi o le laufanua.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Seti le fesoʻotaʻiga fesoʻotaʻiga i lona matua edge, e aunoa ma le faʻaleaogaina isi faʻasino i le node.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Faʻamama le aʻa aʻa i lona matua edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Faʻaopopo se paʻu taua-taua i le iʻuga o le node.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// O aitema uma na toe faʻafoʻi mai e `range` o se faʻatatauga edge faʻailoga mo le node.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Faʻaopopo le ki-taua paʻaga, ma le edge e alu i le taumatau o lena paga, i le pito o le node.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Siaki pe o le node o le `Internal` node poʻo le `Leaf` node.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// O se faʻasino i se faʻapitoa ki-taua paʻaga poʻo edge i totonu o se node.
/// O le `Node` parameter e tatau ona avea ma `NodeRef`, ae o le `Type` e mafai ona avea ma `KV` (faʻailogaina o se au i luga o le ki-taua lua) poʻo le `Edge` (faʻailogaina o se au i luga o le edge).
///
/// Manatua e oʻo lava i `Leaf` nodes mafai ona i ai ni au `Edge`.
/// Nai lo le fai ma sui o se faʻasino i le tamaʻi node, o nei sui o avanoa o le a faʻailo tamaiti alu i le va o le ki-taua paga.
/// Mo se faʻataʻitaʻiga, i se node ma le umi 2, o le ai ai 3 avanoa edge nofoaga, tasi i le agavale o le node, tasi i le va o lua paga, ma le tasi i le taumatau o le node.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Matou te le manaʻomia le atoa lautele o `#[derive(Clone)]`, ona pau lava le taimi `Node` o le a avea ma 'Clone`able o le taimi o se le ma suia faʻasino ma o lea `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Toe aumai le node o loʻo iai le edge poʻo le taua-taua paʻaga o loʻo faʻasino i ai le au.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Faʻafoʻi le tulaga o lenei 'au i le node.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Fausia se au fou i se paʻu taua-taua i le `node`.
    /// Le saogalemu aua o le tagata e valaʻau e tatau ona mautinoa le `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Mafai ona avea ma lautele faʻatinoina o PartialEq, ae naʻo le faʻaaogaina i lenei module.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Aveese le tumau mo se taimi puʻupuʻu, le mafai ona suia i le nofoaga e tasi.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // E le mafai ona matou faʻaaogaina le Handle::new_kv poʻo le Handle::new_edge aua matou te le iloa le matou ituaiga
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Le faʻamautinoaina le faʻamaonia i le tuʻufaʻatasiga o faʻamatalaga tumau o le au o le au o le `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Aveese le tumau mo se taimi puʻe, suia i luga o le nofoaga e tasi.
    /// Faʻaeteete, aua o lenei metotia e matua mataʻutia, faʻaluaina talu ai atonu e le vave foliga mai mataʻutia.
    ///
    ///
    /// Mo auiliiliga, vaʻai `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // E le mafai ona matou faʻaaogaina le Handle::new_kv poʻo le Handle::new_edge aua matou te le iloa le matou ituaiga
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Fausia se au fou i le edge i le `node`.
    /// Le saogalemu aua o le tagata e valaʻau e tatau ona mautinoa le `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Tuʻuina mai se faʻasino igoa edge tatou te mananaʻo e tuʻu ai i totonu o le uafu ua tumu i le gafatia, faʻatulagaina se talafeagai KV faʻasino igoa o se vaelua vae ma le mea e faʻatino ai le faʻaofiina.
///
/// Ole manulauti ole vaevaega vaʻaia mo lona ki ma lona tau e faʻaiʻu i se node matua;
/// o ki, taua ma itu i le agavale o le vaevae vae avea ma tama agavale;
/// o ki, taua ma itu i le taumatau o le vaevaega avea ma tama saʻo.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // O le Rust lomiga #74834 e taumafai e faʻamatala ia tulafono tutusa.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Faʻaofi se paʻu-taua fou va i le va o le ki-taua paʻaga i le taumatau ma le agavale o lenei edge.
    /// O lenei metotia faʻapea e lava lava avanoa i le node mo le paʻaga fou e ofi ai.
    ///
    /// O le faʻasino faʻasino tusi e faasino i le aofaʻi faʻaofi.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Faʻaofi se paʻu-taua fou va i le va o le ki-taua paʻaga i le taumatau ma le agavale o lenei edge.
    /// Ole auala lea e vaeluaina ai le avanoa pe a le lava le avanoa.
    ///
    /// O le faʻasino faʻasino tusi e faasino i le aofaʻi faʻaofi.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Faʻamau le matua pointer ma le faasino upu i le tamaʻi node e fesoʻotaʻi i ai lenei edge.
    /// E aoga lea pe a suia le faʻasologa o pito,
    fn correct_parent_link(self) {
        // Fausia backpointer e aunoa ma le faʻaleaogaina isi faʻasino i le node.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Faʻaofi se paʻu-taua fou ma se edge o le a alu i le taumatau o lena paʻaga fou i le va o lenei edge ma le ki-taua paʻaga i le taumatau o lenei edge.
    /// O lenei metotia faʻapea e lava lava avanoa i le node mo le paʻaga fou e ofi ai.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Faʻaofi se paʻu-taua fou ma se edge o le a alu i le taumatau o lena paʻaga fou i le va o lenei edge ma le ki-taua paʻaga i le taumatau o lenei edge.
    /// Ole auala lea e vaeluaina ai le avanoa pe a le lava le avanoa.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Faʻaofi se paʻu-taua fou va i le va o le ki-taua paʻaga i le taumatau ma le agavale o lenei edge.
    /// O lenei metotia e vaeluaina le laupepa pe a fai e le lava le potu, ma taumafai e tuʻu le vaevae ese vaega i totonu o le matua node recursively, seʻia oʻo i le aʻa aapa.
    ///
    ///
    /// Afai o le tali faʻaiʻu o le `Fit`, o lona au o le au mafai ona avea ma lenei edge's node poʻo se tuaʻa.
    /// Afai o le tali faʻaiʻu o le `Split`, o le `left` fanua o le a avea maʻaʻa.
    /// O le faʻasino faʻasino tusi e faasino i le aofaʻi faʻaofi.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Maua le node faʻasino e lenei edge.
    ///
    /// O le metotia igoa manatu oe ata ata ma aʻa node luga o loʻo i luga.
    ///
    /// `edge.descend().ascend().unwrap()` ma `node.ascend().unwrap().descend()` tatau uma, i luga o le manuia, leai se mea.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Matou te manaʻomia le faʻaaogaina o faʻailoaina mata i node aua, afai o le BorrowType o le marker::ValMut, e ono i ai ni mataʻupu maoaʻe e mafai ona suia i tulaga taua e le tatau ona tatou faʻaleaogaina.
        // E leai se popole i le ulufale atu i le tulaga maualuga ona o lena taua ua kopiina.
        // Ia e faʻaeteete, a oʻo loa ona faʻamavae le node pointer, ona tatou oʻo lea i le pito o le laina ma se faʻasino (Rust lomiga #73987) ma faʻaleaogaina isi faʻamatalaga i totonu poʻo totonu o le laina, pe a fai e iai se mea.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // E le mafai ona matou valaʻau eseʻese ki ma auala taua, aua o le valaʻau i le lona lua e faʻaleaogaina ai le faʻamatalaga na faʻafoʻi mai e le muamua.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Sui le ki ma le tau o loʻo faʻasino i ai le KV.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Fesoasoani faʻatinoina o `split` mo faapitoa `NodeType`, e ala i le vaʻaia lelei o laupepa faʻamaumauga.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Vaeluaina le faʻavae autu i ni vaega se tolu:
    ///
    /// - O le node ua teuteuina e naʻo le i ai o le ki-taua paʻaga i le agavale o lenei au.
    /// - O le ki ma le taua faʻatatauina e lenei 'au ua aveʻesea.
    /// - Uma-taua paʻaga paga i le taumatau o lenei 'au o loʻo tuʻuina i totonu o se faʻatulagaina node.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Aveʻese le ki-taua paʻaga faʻasino i lenei 'au ma toe faʻafoʻi ia, faʻatasi ai ma le edge na paʻu ifo i totonu le pa-taua taua.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Vaeluaina le faʻavae autu i ni vaega se tolu:
    ///
    /// - O le node ua teuteuina e naʻo le i ai o pito ma ki-taua paʻaga i le agavale o lenei au.
    /// - O le ki ma le taua faʻatatauina e lenei 'au ua aveʻesea.
    /// - Uma pito ma paʻu taua-taua i le itu taumatau o lenei au o loʻo tuʻuina i totonu o se faʻavaʻa avanoa.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Faʻaalia se sauniga mo le iloiloina ma le faʻatinoina o se faʻapaleni gaioiga faʻataʻamilo i totonu totonu taua-taua paʻaga.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Filifili se paleni faʻamatalaga e aofia ai le node o se tamaititi, o lea i le va o le KV vave i le agavale poʻo le taumatau i le matua node.
    /// Faʻafoʻi mai le `Err` peʻa leai se matua.
    /// Panics peʻa gaogao le matua.
    ///
    /// Sili le itu tauagavale, ia sili ona lelei pe a fai o le tuʻufaʻatasia o le node e le ova lona uiga, o lona uiga iinei na o le tele atu o elemene nai lo lona uso agavale ma nai lo lona uso taumatau, pe a fai latou te i ai.
    /// Ile tulaga la, o le tuʻufaʻatasia ma le uso agavale e vave tele, talu ai e naʻo le pau le mea e manaʻomia e tatou e minoi ai le elemeni ole N, ae le o le suia i le taumatau ma feʻaveaʻi nai lo elemene N i luma.
    /// O le gaoi mai le uso tauagavale e masani foi ona televave, talu ai e naʻo le pau le mea e manaʻomia e tatou e sui ai le elemeni N i le itu taumatau, nai lo le sui o le elemene N o le tei a le tuagane i le agavale.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Faʻafoʻi pe mafai ona tuʻufaʻatasia, faʻapea, pe lava le avanoa i se faʻamau e tuʻufaʻatasia ai le KV ogatotonu ma faʻailoga tamaʻi tuaoi uma e lua.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Faia se tuʻufaʻatasiga ma faʻatagaina le tapunia filifili le mea e toe foʻi.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // SAFETY: o le maualuga o nodes ua tuʻufaʻatasia o se tasi i lalo o le maualuga
                // o le faʻamau o lenei edge, o lea i luga aʻe o le zero, o lona uiga la e i totonu.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Faʻatasia le matua-taua paʻaga ma lua latalata tamaiti node i le agavale tamaititi node ma toe faʻafoʻi le nati matua node.
    ///
    ///
    /// Panics seʻi vagana ua tatou `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Tuʻufaʻatasia le matua-taua paʻaga ma uma latalata tamaiti node i le tamaʻi agavale node ma faʻafoʻi lena tamaʻi tamaʻi igoa.
    ///
    ///
    /// Panics seʻi vagana ua tatou `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Faʻapipiʻi le matua-taua lua paʻaga ma lua tamaʻi tamaʻi node i le tamaʻi agavale node ma faʻafoʻi le au edge i totonu o le tamaʻi node le mea na suʻe le tamaititi edge na iu,
    ///
    ///
    /// Panics seʻi vagana ua tatou `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Aveese se paʻu-taua taua mai le tama agavale ma tuu i le teu-taua teuina o le matua, ao tuleia le matua matua-aoga taua paʻaga i le tama taumatau.
    ///
    /// Faʻafoʻi le au i le edge i le tama saʻo e fetaui ma le mea na uma ai le uluaʻi edge na faʻamaonia e `track_right_edge_idx`.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Aveese se paʻu-taua taua mai le tama taumatau ma tuʻu i le teu-taua teuina o le matua, aʻo tuleia le matua matua-aoga taua paʻaga i luga o le tama agavale.
    ///
    /// Faʻafoʻi le au i le edge i le tama agavale na faʻamaoti mai e `track_left_edge_idx`, e leʻi minoi.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// O lenei gaoi pei o `steal_left` ae gaoia tele elemeni i le tasi.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Ia mautinoa e mafai ona tatou gaoia saogalemu.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Faʻasolo lau laupepa.
            {
                // Avanoa avanoa mo gaoia elemeni i le tama saʻo.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Aveese elemene mai le tama agavale i le itu taumatau.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Ave le paga tauagavale-gaoia i le matua.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Faʻasuʻe le paʻu-taua taua a matua i le tama saʻo.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Fai se avanoa mo gaoi pito.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Gaoi pito.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Le symmetric clone o `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Ia mautinoa e mafai ona tatou gaoia saogalemu.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Faʻasolo lau laupepa.
            {
                // Ave le paga-gaoi taumatau ile matua.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Ave le uluaʻi faʻailoga taua a matua i le tama agavale.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Aveese elemeni mai le tama taumatau i le agavale.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Faʻatumu va i mea na gaoia elemeni i ai.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Gaoi pito.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Faʻatumu va i le mea na iai gaoi gaoi.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Aveʻesea soʻo se faʻamatalaga tumau o loʻo faʻapea mai o lenei node o le `Leaf` node.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Aveʻesea soʻo se faʻamaumauga maumaututū o loʻo faʻapea mai o lenei node o le `Internal` node.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Siaki pe o le faʻavae node o se `Internal` node poʻo se `Leaf` node.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Faʻasuʻe le faʻaupuga ina ua uma le `self` mai le tasi node i le tasi.`right` tatau ona gaogao.
    /// Le muamua edge o `right` tumau pea le suia.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Taunuuga o le faʻaofiina, pe a manaʻomia se ivi e faʻalautele i talaatu o lona gafatia.
pub struct SplitResult<'a, K, V, NodeType> {
    // Node suia i le taimi nei laʻau ma elemene ma pito e auai i le agavale o `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Nisi ki ma taua vavae ese, e tuʻuina i se isi mea.
    pub kv: (K, V),
    // Umia, le faʻafesoʻotaʻiina, node fou ma elemene ma pito o loʻo i le itu taumatau o `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Pe o faʻailoga node o lenei ituaiga nono faʻatagaina le sopoia o isi node i le laʻau.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // E le manaʻomia Traversal, e tupu e faʻaaoga ai le iʻuga ole `borrow_mut`.
        // E disabling traversal, ma e na o le faia o mau fou i aʻa, ua tatou iloa o faasinomaga taitasi uma o le ituaiga `Owned` o le a node aʻa.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Faʻaofi se taua i totonu o se fasi vaega amataina elemeni mulimuli mai tasi elemeni le faʻamauina.
///
/// # Safety
/// O le fasi sili atu nai lo `idx` elemene.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Aveʻese ma toe faʻafoi mai se tau mai se fasi vaega uma amataina elemeni, tuʻua i tua o le tasi elemeni le faʻamauina elemeni.
///
///
/// # Safety
/// O le fasi sili atu nai lo `idx` elemene.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Sueina elemene i se fasi `distance` tulaga i le agavale.
///
/// # Safety
/// O le fasi sili atu `distance` elemene.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Sueina elemene i se fasi `distance` tulaga i le taumatau.
///
/// # Safety
/// O le fasi sili atu `distance` elemene.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Siʻi uma tulaga faatauaina mai se fasi vaega amataina i se fasi vaega elemeni, tuʻua `src` pei uma uninitialized.
///
/// Galue pei o `dst.copy_from_slice(src)` ae le manaʻomia `T` e avea `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;