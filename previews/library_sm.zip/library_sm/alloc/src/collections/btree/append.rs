use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Faʻaopopo uma ki-taua paʻaga mai le tuʻufaʻatasia o lua alu faʻalua iterators, faʻaopoopoina a `length` fesuiaʻi i le ala.O le mea mulimuli e faʻafaigofie ai mo le tagata telefoni ona aloese mai se faʻagasologa pe a paʻu se meaʻai lalo.
    ///
    /// Afai e maua uma iterators le ki lava, o lenei metotia toulu le paga mai le iterator agavale ma faʻapipiʻi le paga mai le taumatau taumatau.
    ///
    /// Afai e te manaʻo i le laʻau ia faʻaiʻu i se faʻatonutonu maualuga faʻasologa, pei mo le `BTreeMap`, uma iterators tatau ona gaosia ki i le matua oʻo atu faʻasologa, taʻitasi sili atu nai lo ki uma i le laʻau, e aofia ai ni ki ua i totonu o le laʻau ulufale
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Matou te sauni e tuʻufaʻatasia le `left` ma le `right` i se faʻavasega faʻavasega i taimi faʻasolosolo.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // I le taimi nei, matou te fausiaina se laʻau mai le faʻavasega faʻasologa i laina taimi.
        self.bulk_push(iter, length)
    }

    /// Tulei uma-ki-taua paʻaga i le pito o le laʻau, incrementing a `length` fesuiaʻi i le ala.
    /// O le mea mulimuli e faʻafaigofie ai mo le tagata telefoni ona aloese mai se faʻasolo mai pe a pa le ititi.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Faʻaletonu uma paga taua-taua, tulei i latou i nodes i le tulaga saʻo.
        for (key, value) in iter {
            // Taumafai e unaʻi le mea taua-taua i le lau laulaʻau nei.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Leai se avanoa e totoe, alu i luga ma tulei iina.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Maua se node ma avanoa avanoa, tulei ii.
                                open_node = parent;
                                break;
                            } else {
                                // Alu i luga.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Ua tatou iai i le pito i luga, fausia se node fou aʻa ma tulei iina.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Tulei ki-taua paʻaga ma subtree taumatau fou.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Alu i lalo i le taumatau-sili lau.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Faʻatuputeleina le umi i faʻafitauli uma, ia mautinoa o le faʻafanua e paʻuʻu i lalo mea e faʻaopoopoina e tusa lava pe oʻo i le alualu i luma le iterator panicks.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// O se faʻasolosolo mo le tuʻufaʻatasia o faʻavasega faʻavasega e lua i le tasi
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Afai e tutusa ki e lua, toe faʻafoʻi le paʻu-taua paʻaga mai le saʻo puna.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}