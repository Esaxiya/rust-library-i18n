//! O se faʻalua laina faʻamalama faʻatinoina ma se growable mama buffer.
//!
//! Lenei laina laina *O*(1) amortized faʻaputuputu ma aveʻese mai uma itu o le container.
//! E i ai foʻi le *O*(1) faʻasino igoa pei o le vector.
//! O elemeni o loʻo iai i totonu e le manaʻomia ia kopiina, ma o le laina o le a lafoina pe a fai o le ituaiga i totonu e lafoina.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // Sili mafai ono o le lua

/// O se faʻalua laina faʻamalama faʻatinoina ma se growable mama buffer.
///
/// O le "default" faʻaaogaina o lenei ituaiga o se laina o le faʻaaoga [`push_back`] e faʻaopopo i le laina, ma [`pop_front`] e aveʻese mai le laina.
///
/// [`extend`] ma [`append`] tulei luga o le tua i lenei faiga, ma iterating luga `VecDeque` alu luma i tua.
///
/// Talu ai o le `VecDeque` o se mama faʻamau, o ona elemene e le mautinoa vavalalata i le manatuaina.
/// Afai e te manaʻo e ulufale i elemeni o se tasi fasi, pei o mo lelei faʻavasegaina, oe mafai ona faʻaaoga [`make_contiguous`].
/// E mimilo le `VecDeque` ina ia le afifi ona elemene, ma toe faʻafoʻi se fesuiaʻiga fasi i le nei-contiguous elemeni faʻasologa.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // o le siʻusiʻu ma le ulu e faʻasino i totonu o le puipui.
    // Faʻailo taimi uma tusi i le muamua elemeni e mafai ona faitauina, Ulu taimi uma tusi i le mea e tatau ona tusia ai faʻamaumauga.
    //
    // Afai siʻusiʻu==ulu le faʻamau ua avanoa.O le umi o le ringbuffer ua faʻamatalaina o le mamao i le va o le lua.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// Tamoʻe le faʻaleagaina mo aitema uma i totonu o le fasi pe a pa'ū (masani pe i le taimi o malologa).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // faʻaaoga mataua mo [T]
            ptr::drop_in_place(front);
        }
        // RawVec 'uʻuina translocation
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// Fausia se avanoa `VecDeque<T>`.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// Sili talafeagai
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// Sili talafeagai
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // Mo zero ituaiga ituaiga, tatou i taimi uma i le maualuga gafatia
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// Liliu le ptr i se fasi
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// Liliu le ptr i se mutia fasi
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// Aveese se elemeni mai le faʻamau
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// Tusia se elemeni i totonu o le faʻamau, aveina.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// Faʻafoʻi `true` peʻa fai o le buffer ua atoa lona malosi.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// Faʻafoʻi mai le faʻasino igoa ile faʻavaʻa autu mo se faʻavasega elemeni talafeagai.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// Faʻafoʻi mai le faʻasino igoa i le faʻaputuga autu mo se faʻatulagaina elemeni talafeagai + faʻaopoopoga.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// Faʻafoʻi mai le faʻasino igoa ile faʻafoliga autu mo se faʻavasega elemeni talafeagai, subtrahend.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// Kopi se poloka felavasaʻi o mea e manatua ai le umi mai le src i le dst
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Kopi se poloka felavasaʻi o mea e manatua ai le umi mai le src i le dst
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Kopi se poloka ono afifi o le manatua len umi mai src i le iʻuga.
    /// (abs(dst - src) + len) tatau ona le sili atu nai lo cap() (E tatau ona sili atu ma le tasi le faʻaauau felauaʻi itulagi i le va o src ma dest).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src e le afifi, e le afifi dst
                //
                //        S...
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] D.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // i luma o le src, src e le afifi, e afifi
                //
                //
                //    S...
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. D.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // src ae e te leʻi dst, src e le afifi, e afifi
                //
                //
                //              S...
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. D.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // dst ae le i afifi src, src, dst e afifi
                //
                //
                //    .. S.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] D...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // src ae le i oʻo le dst, src afifi, dst e le afifi
                //
                //
                //    .. S.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] D...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // dst i luma o src, src afifi, dst afifi
                //
                //
                //    ... S.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. D..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // src luma dst, wraps src, wraps dst
                //
                //
                //    .. S..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]... D
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// Frobs le ulu ma le iʻu vaega o loo siomia e taulimaina le mea moni e faapea e na ona tatou reallocated.
    /// Le sefe aua e faʻatuatua i le old_capacity.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // Siʻi le pito sili ona puʻupuʻu o le mama buffer TH
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [...ooooooo.....
        //          ] HT
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // E leai
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// Fausia se avanoa `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// Fausia se avanoa `VecDeque` ma avanoa mo le sili atu `capacity` elemene.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1 talu ai o le ringbuffer masani ona tuua se avanoa e tasi avanoa
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// Tuʻuina atu se faʻasino i le elemeni i le faʻasino faasino igoa.
    ///
    /// Ole elemene ile faʻailoga 0 ole pito i luma ole laina.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Tuʻuina mai se faʻavasega suiga i le elemeni i le faʻasino faasino igoa.
    ///
    /// Ole elemene ile faʻailoga 0 ole pito i luma ole laina.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Faʻafesuiaʻi elemeni i faʻailoga `i` ma `j`.
    ///
    /// `i` ma `j` ono tutusa.
    ///
    /// Ole elemene ile faʻailoga 0 ole pito i luma ole laina.
    ///
    /// # Panics
    ///
    /// Panics pe a fai o faʻasino i fafo atu o tuaoi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// Faʻafoʻi le numera o elemeni e mafai e le `VecDeque` ona taofia e aunoa ma le toe faʻatulagaina.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// Faʻasao le laʻititi gafatia mo tonu `additional` sili elemeni e faʻaofi i le `VecDeque` tuʻuina atu.
    /// E leai se mea pe a fai o le malosi ua lava.
    ///
    /// Manatua o le tagata faʻasoa e ono tuʻuina atu i le aoina sili avanoa nai lo le mea e talosagaina.
    /// O le mea lea gafatia e le mafai ona faʻamoemoeina i le avea ma saʻo itiiti.
    /// Sili [`reserve`] pe a fai o future e ono faʻaofiina.
    ///
    /// # Panics
    ///
    /// Panics pe a fai e oʻo i le `usize` le malosi fou.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// Faʻaagaga gafatia mo le sili atu `additional` sili elemeni e faʻaofi i le tuuina `VecDeque`.
    /// O le aoina ono faʻaavanoa tele avanoa e aloese ai mai faʻataʻitaʻiga masani.
    ///
    /// # Panics
    ///
    /// Panics pe a fai e oʻo i le `usize` le malosi fou.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// Taumafai e faʻasao le laʻititi gafatia mo tonu `additional` sili elemeni e faʻaofi i le `VecDeque<T>` tuʻuina atu.
    ///
    /// A maeʻa ona valaʻau `try_reserve_exact`, o le a sili atu le malosi nai lo pe tutusa i le `self.len() + additional`.
    /// E leai se mea pe a fai o le malosi ua lava.
    ///
    /// Manatua o le tagata faʻasoa e ono tuʻuina atu i le aoina sili avanoa nai lo le mea e talosagaina.
    /// O le mea lea, gafatia le mafai ona faʻamoemoeina i luga ia avea matua mautinoa itiiti.
    /// Sili `reserve` pe a fai o future e ono faʻaofiina.
    ///
    /// # Errors
    ///
    /// Afai o le gafatia overflows `usize`, pe o le faʻasoasoa lipoti lipoti se faʻaletonu, lona uiga ua toe faʻafoʻi mai se mea sese.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Muamua-faʻasao le manatuaina, exiting pe a fai tatou te le mafaia
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Lenei ua matou iloa e le mafai lenei OOM(Out-Of-Memory) i le ogatotonu o la matou galuega faigata
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // faigata tele
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// Taumafai e faʻasao gafatia mo le sili atu `additional` sili elemeni e tuʻuina i le `VecDeque<T>` tuʻuina atu.
    /// O le aoina ono faʻaavanoa tele avanoa e aloese ai mai faʻataʻitaʻiga masani.
    /// A maeʻa ona valaʻau `try_reserve`, o le a sili atu le malosi nai lo pe tutusa i le `self.len() + additional`.
    /// E leai se mea pe a fai ua lava le agavaʻa.
    ///
    /// # Errors
    ///
    /// Afai o le gafatia overflows `usize`, pe o le faʻasoasoa lipoti lipoti se faʻaletonu, lona uiga ua toe faʻafoʻi mai se mea sese.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Muamua-faʻasao le manatuaina, exiting pe a fai tatou te le mafaia
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Lenei ua matou iloa e le mafai OOM i le ogatotonu o la matou galuega faigata
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // faigata tele
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// Faʻapipiʻi le gafatia o le `VecDeque` i le tele e mafai ai.
    ///
    /// O le a pa'ū lalo i lalo latalata i le umi e mafai ai ae o le faasoasoaina mafai ona logoina pea le `VecDeque` o loʻo i ai le avanoa mo ni nai elemene.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// Faʻapaʻu le gafatia o le `VecDeque` ma le pito i lalo maualalo.
    ///
    /// O le gafatia o le a tumau i le sili atu tele pei o uma le umi ma le sapalai taua.
    ///
    ///
    /// Afai o le malosiaga o loʻo i ai nei e laititi atu i lo le tapulaʻa maualalo, o le leai-op lea.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // Tatou te le tau popole fua e uiga i se lolovaʻa aua X `self.len()` X poʻo `self.capacity()` mafai ona avea ma `usize::MAX`.
        // +1 pei o le ringbuffer masani ona tuua se avanoa avanoa.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // E tolu mataupu o le tului:
            //   O elemene uma o loʻo i tuaʻoi o loʻo manaʻomia E felavasaʻi elemeni, ma o le ulu e leai se mea e manaʻomia ai.
            //
            //
            // I isi taimi uma, elemeni tulaga e le afaina.
            //
            // Faʻailoa o elemeni i le ulu e tatau ona minoi.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // Aveese elemeni mai fafo o manaʻoga manaʻomia (tulaga i le maeʻa target_cap)
            if self.tail >= target_cap && head_outside {
                // TH
                //   [. . . . . . . . o o o o o o o . ]
                //    TH
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // TH
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// Faʻapuʻupuʻu le `VecDeque`, tausia le muamua `len` elemeni ma faʻapaʻu le toega.
    ///
    ///
    /// Afai e sili atu le `len` nai lo le umi o le VecDeque`, e leai la se aoga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// Tamoʻe le faʻaleagaina mo aitema uma i totonu o le fasi pe a pa'ū (masani pe i le taimi o malologa).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // Saogalelei aua:
        //
        // * Soʻo se fasi paso pasi i le `drop_in_place` e aoga;le tulaga lona lua ua `len <= front.len()` ma le toe foi i `len > self.len()` faamautinoa `begin <= back.len()` i le tulaga muamua
        //
        // * O le ulu o le VecDeque ua minoi ae le i valaʻauina `drop_in_place`, o lea e leai se aoga e paʻu faʻalua pe a fai o `drop_in_place` panics
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // Ia mautinoa ua paʻu le afa lona lua tusa lava pe o le faʻaumatia i le muamua tasi panics.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// Faʻafoi mai i tua le tua.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// Faʻafoʻi mai i luma-i-tua iterator e faʻafoʻi suia suia.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // SAFETY: Le i totonu `IterMut` saogalemu invariant ua faʻamautuina aua o le
        // `ring` matou te fausiaina o se fasi mea e le mafai ona faʻaaogaina mo le olaga atoa '_.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Faʻafoʻi mai se pea fasi o loʻo iai, i le faʻasologa tatau, mea o loʻo i le `VecDeque`.
    ///
    /// Afai o [`make_contiguous`] na valaʻauina muamua, o elemene uma o le `VecDeque` o le ai i le muamua fasi ma le lona lua fasi o le a gaogao.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// Faʻafoʻi mai se pea fasi o loʻo iai, i le faʻasologa tatau, mea o loʻo i le `VecDeque`.
    ///
    /// Afai o [`make_contiguous`] na valaʻauina muamua, o elemene uma o le `VecDeque` o le ai i le muamua fasi ma le lona lua fasi o le a gaogao.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// Faʻafoʻi mai le numera o elemeni ile `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// Faʻafoʻi `true` peʻa leai se mea ile `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// Fausia se iterator e ufiufi ai le faʻamatalaga faʻapitoa i le `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics pe a fai o le amataga ua sili atu nai lo le iʻuga itu pe afai o le pito mulimuli e sili atu nai lo le umi o le vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // O le atoa atoa aofia uma mataupu
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // O le faʻamatalaga tuʻufaʻatasi o loʻo ia matou i le &self o loʻo taofia pea ile '_ o Iter.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// Faatupuina ai se iterator e aofia ai le tele mutable faamaoti mai i le `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics pe a fai o le amataga ua sili atu nai lo le iʻuga itu pe afai o le pito mulimuli e sili atu nai lo le umi o le vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // O le atoa atoa aofia uma mataupu
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // SAFETY: Le i totonu `IterMut` saogalemu invariant ua faʻamautuina aua o le
        // `ring` matou te fausiaina o se fasi mea e le mafai ona faʻaaogaina mo le olaga atoa '_.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Fausia se faʻamatuʻuina iterator e aveʻese le faʻapitoa laina i le `VecDeque` ma maua ai le aveese aitema.
    ///
    /// Faʻaliga 1: O le elemene laina ua aveʻese tusa lava pe o le faʻasolosolo e le faʻaumatiaina seʻia oʻo i le iʻuga.
    ///
    /// Faʻaliga 2: E leʻo faʻamaonia mai pe fia ni elemeni ua aveʻesea mai le deque, pe a fai e le paʻu le tau o le `Drain`, ae o le aitalafu o loʻo ia taofia e uma (eg, talu ai `mem::forget`).
    ///
    ///
    /// # Panics
    ///
    /// Panics pe a fai o le amataga ua sili atu nai lo le iʻuga itu pe afai o le pito mulimuli e sili atu nai lo le umi o le vector.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // O le atoa atoa faʻamamaina uma mea
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // Manatu saogalemu
        //
        // A faʻavaeina le Drain, e faʻapuʻupuʻu le faʻavae punaoa ina ia mautinoa e leai se faʻaleaʻoaʻoga pe minoi-mai elemeni e mafai ona maua uma pe a fai o le Drain's faʻaumatia e le mafai ona sola.
        //
        //
        // Drain o le a ptr::read fafo tau aoga e aveʻese.
        // A maeʻa, o faʻamatalaga o totoe o le a kopiina i tua e ufiufi ai le pu, ma o le head/tail taua o le a toe faʻaleleia saʻo.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // ua vaeluaina elemene o le deque i ni vaega se tolu:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // T= self.tail;H= self.head;t=drain_tail;h=drain_head
        //
        // Matou te teuina le drain_tail o le self.head, ma le drain_head ma le self.head o le a maeʻa ma mulimuli ane i luga o le Drain.
        // Lenei foi truncates le aoga lelei faʻasologa pe a fai o le Drain ua faʻasalalauina, ua galo ia i tatou e uiga i ono ono siitia tulaga pe a uma le amataga o le drain.
        //
        //
        //        T U H
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" e uiga i le taua mulimuli ane le amataga o le drain seia maeʻa le drain maeʻa ma le Drain faʻaleagaina o loʻo tamoʻe.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // Ma le taua, matou te fausiaina faʻasoa faʻamatalaga mai le `self` ii ma faitau mai ai.
                // Matou te le tusi i le `self` pe toe foʻi i se faʻavasegaga e mafai ona suia.
                // O le mea lea, o le raw point na matou faia i luga, mo `deque`, e tumau lona aoga.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// Faʻamama le `VecDeque`, aveʻese uma tau.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// Faʻafoʻi `true` pe a fai o le `VecDeque` o loʻo iai se elemeni e tutusa ma le tau na tuʻuina atu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// Tuʻuina atu se faʻasino i le pito i luma elemeni, poʻo le `None` pe a fai o le `VecDeque` e leai se mea.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// Tuʻuina atu se faʻavasega suiga i le pito i luma elemeni, poʻo le `None` pe a fai o le `VecDeque` e leai se mea.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// Tuʻuina atu se faʻasino i le pito i tua elemeni, pe `None` pe a fai o le `VecDeque` e leai se mea.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// Tuʻuina mai se faʻavasega suiga i le pito i tua elemeni, poʻo le `None` pe a fai o le `VecDeque` e leai se mea.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// Aveʻese le muamua elemeni ma toe faʻafoʻi mai, pe `None` pe a fai o le `VecDeque` e leai se mea.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// Aveʻese le elemene mulimuli mai le `VecDeque` ma toe faʻafoʻi atu, pe `None` peʻa leai se mea.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// Saunia se elemeni i le `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// Faʻaopopo se elemeni i tua o le `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: E tatau ona tatou mafaufau ile `head == 0` o lona uiga
        // o le `self` e felataʻi?
        self.tail <= self.head
    }

    /// Aveʻese se elemeni mai soʻo se mea i le `VecDeque` ma toe faʻafoʻi mai, ae sui i le elemeni muamua.
    ///
    ///
    /// E le faʻasaoina le okaina, ae o le *O*(1).
    ///
    /// Faʻafoʻi `None` pe a fai o `index` e leai ni tuaoi.
    ///
    /// Ole elemene ile faʻailoga 0 ole pito i luma ole laina.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// Aveʻese se elemeni mai soʻo se mea i le `VecDeque` ma toe faʻafoʻi mai, ae sui i le elemeni mulimuli.
    ///
    ///
    /// E le faʻasaoina le okaina, ae o le *O*(1).
    ///
    /// Faʻafoʻi `None` pe a fai o `index` e leai ni tuaoi.
    ///
    /// Ole elemene ile faʻailoga 0 ole pito i luma ole laina.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// Faʻaofi se elemeni i le `index` i totonu o le `VecDeque`, suia uma elemeni ma faʻasino sili atu nai lo pe tutusa ma `index` agai i tua.
    ///
    ///
    /// Ole elemene ile faʻailoga 0 ole pito i luma ole laina.
    ///
    /// # Panics
    ///
    /// Panics pe a fai o `index` e sili atu nai lo le 'VecDeque` umi
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // Faʻasolo le numera laʻititi o elemeni i le mama buffer ma faʻaofi le mea foaʻi
        //
        // Sili len/2, 1 elemeni o le a siitia. O(min(n, n-i))
        //
        // E tolu mataupu autu:
        //  E vavalalata elemeni
        //      - tulaga faʻapitoa pe a fai o le siʻusiʻu o 0 Elemene e le mautonu ma o le faʻaofi o loʻo i totonu o le siʻusiʻuga Elemene e le o mautonu ma o le faʻaofi o loʻo i totonu o le ulu vaega
        //
        //
        // Mo na mea taʻitasi e iai isi lua mataupu:
        //  Faʻaofi e latalata i le siʻusiʻu Faʻaofi e latalata i le ulu
        //
        // Ki: H, self.head
        //      T, self.tail o, Valid elemene I, Insertion elemene A, O le elemene e tatau ona maeʻa le faʻaofiina togi M, Faʻailoa elemeni na siitia
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [O le oooooo.......
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // vavalalata, faʻaofi latalata i le siʻusiʻu:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           TH
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // sosoʻo, faʻaofi latalata i le siʻu ma le siʻu o 0:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       MM

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // Ua uma ona minoi le siʻusiʻu, o lea matou te kopiina `index - 1` elemene.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // vavalalata, faʻaofi latalata i le ulu:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o I A o o . . . . .]
                    //                       MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // le mautonu, faʻaofi latalata i le siʻusiʻu, siʻusiʻu vaega:
                    //
                    //                   HTI
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // le mautonu, faʻaofi latalata i le ulu, vaega siʻusiʻu:
                    //
                    //           HTI
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       MMMM

                    // kopi elemeni e oʻo i le ulu fou
                    self.copy(1, 0, self.head);

                    // kopi mulimuli elemeni i avanoa avanoa i lalo o le buffer
                    self.copy(0, self.cap() - 1, 1);

                    // agai elemene mai idx e faamuta i luma e le aofia * elemene
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // le mautonu, faʻaofi e latalata i le siʻu, ulu vaega, ma o loʻo i le index zero i le buffer totonu:
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               MMM

                    // kopi elemeni e oʻo i le siʻusiʻu fou
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // kopi mulimuli elemeni i avanoa avanoa i lalo o le buffer
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // le mautonu, faʻaofi latalata i le siʻu, ulu vaega:
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       MMMMMM

                    // kopi elemeni e oʻo i le siʻusiʻu fou
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // kopi mulimuli elemeni i avanoa avanoa i lalo o le buffer
                    self.copy(self.cap() - 1, 0, 1);

                    // aveese elemeni mai le idx-1 e faʻaiʻu i luma e le aofia ai ^ elemeni
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // discontiguous, faaofi le latalata atili i le ulu, o le fuaiupu ulu:
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // atonu ua iʻu ua suia lea e tatau ona tatou recalculate
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// Aveesea ma le toe foi mai le elemene i `index` mai le `VecDeque`.
    /// Poʻo le a lava le pito e latalata i le aveʻesea tulaga o le a siitia e fai potu, ma uma aafia elemeni o le a siitia atu i ni tulaga fou.
    ///
    /// Faʻafoʻi `None` pe a fai o `index` e leai ni tuaoi.
    ///
    /// Ole elemene ile faʻailoga 0 ole pito i luma ole laina.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // E tolu mataupu autu:
        //  O elemene e felataʻi Elemene e le faʻavasegaina ma o le aveʻesega i le siʻusiʻuga vaega E le mautonu elemeni ma o le aveʻesea o le ulu vaega
        //
        //      - faʻapitoa tulaga pe a elemeni e tekinolosi vavalalata, ae self.head =0
        //
        // Mo na mea taʻitasi e iai isi lua mataupu:
        //  Faʻaofi e latalata i le siʻusiʻu Faʻaofi e latalata i le ulu
        //
        // Ki: H, self.head
        //      T, self.tail o, Valid elemeni x, elemeni faʻailogaina mo le aveʻesega R, Faʻailoa elemene ua aveʻesea M, Faʻailoaina elemeni na siitia
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // vavalalata, aveese latalata i le siʻusiʻu:
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               TH
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // vavalalata, aveese latalata i le ulu:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // le mautonu, aveese latalata i le siusiu, siʻusiʻu vaega:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // le mautonu, aveese latalata i le ulu, ulu vaega:
                    //
                    //               RHT
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // le mautonu, aveese latalata i le ulu, vaega siʻusiʻu:
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       MMMM
                    //
                    // poʻo le toʻafilemu-discontiguous, aveʻese i autafa o le ulu, vaega siʻusiʻu:
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         TH
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // tusia ni elemeni i le siusiu vaega
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // Puipuia lalo
                    if self.head != 0 {
                        // kopi muamua elemeni i avanoa avanoa
                        self.copy(self.cap() - 1, 0, 1);

                        // ave elemeni i le ulu vaega tua
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // le mautonu, aveese latalata i le siʻu, ulu vaega:
                    //
                    //           RHT
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       MMMMM

                    // tusi i lalo elemeni i luga o le idx
                    self.copy(1, 0, idx);

                    // kopi mulimuli elemeni i avanoa avanoa
                    self.copy(0, self.cap() - 1, 1);

                    // aveese elemeni mai le siʻusiʻu iuga i luma, le aofia ai le mulimuli
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// Vaeluaina le `VecDeque` i le lua i le faʻasino faasino igoa.
    ///
    /// Faʻafoʻi mai le `VecDeque` fou faʻatulagaina.
    /// `self` aofia ai elemeni `[0, at)`, ma o le `VecDeque` faʻafoʻi o loʻo iai elemeni `[at, len)`.
    ///
    /// Manatua o le mafai o `self` e le suia.
    ///
    /// Ole elemene ile faʻailoga 0 ole pito i luma ole laina.
    ///
    /// # Panics
    ///
    /// Panics pe a `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` taoto i le afa muamua.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // na ona ave uma o le afa lona lua.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` o loʻo taatia i le afa lona lua, manaʻomia ona faʻatauaina elemeni na tatou feosooso ai ile 'afa muamua.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // Faamama le mea o i ai pito o buffers
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// Siʻi uma elemeni o `other` i le `self`, ae tuʻu pea i le `other`.
    ///
    /// # Panics
    ///
    /// Panics pe a fai o le numera fou o elemene ia te ia lava e soʻona soʻona `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // naif impl
        self.extend(other.drain(..));
    }

    /// Faʻataua naʻo elemeni ua faʻamaonia mai e le faʻamatalaga muamua.
    ///
    /// I se isi faaupuga, aveʻese elemeni uma `e` pei o le `f(&e)` faʻafoʻi sese.
    /// O lenei metotia faʻagaioia i le nofoaga, asiasi i elemeni taʻitasi tasi taimi i le uluaʻi faʻasologa, ma faʻasao le faʻasologa o mea taofia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// O le faʻatonuga saʻo e ono aoga mo le siakiina o fafo atu o tulaga, pei o se faʻasino igoa.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // Lenei ono panic pe toʻesea
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // Faalua le lapopoʻa tele.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// Fesuiaʻi le `VecDeque` i le nofoaga ina ia tutusa le `len()` ma le `new_len`, a le o le aveʻesea o sili atu elemeni mai tua pe ala i le faʻaopopoina elemene fausiaina i le valaauina `generator` i tua.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// Faʻatulaga lelei le teuina i totonu o lenei deque o lea o se tasi vavalalata fasi, lea ona toe faʻafoʻi mai.
    ///
    /// O lenei metotia e le tuʻuina atu ma e le suia le faʻasologa o elemeni faʻaofiina.A o toe faʻafoi se mutable fasi, lenei mafai ona faʻaaogaina e faʻavasega se deque.
    ///
    /// O le taimi lava e latalata ai le teuina i totonu, o le [`as_slices`] ma le [`as_mut_slices`] metotia o le a toe faafoi uma mea o le `VecDeque` i se tasi fasi.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// Faʻavasegaina o mea o le deque.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // faʻavasega le deque
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // faʻavasega i se faʻasologa saʻo
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// O le mauaina o le masuia avanoa i le fasi tuaoi.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // ua mafai nei ona tatou mautinoa o le `slice` o loʻo iai uma elemeni o le deque, a o loʻo iai pea le avanoa i le `buf`.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // e lava le avanoa avanoa e kopi ai le siʻu i le tasi le alu, o lona uiga tatou muamua suia le ulu i tua, ona kopi lea o le siʻusiʻu i le sao tulaga.
            //
            //
            // mai: DEFGH .... ABC
            // i: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: Matou te leʻo mafaufauina nei .... ABCDEFGH
            // e vavalalata aua o `head` o le `0` i lenei tulaga.
            // A o tatou ono manaʻo e suia lenei e le taua tele ona o ni nai nofoaga faʻamoemoe `is_contiguous` o lona uiga e mafai ona tatou na fasi fasi `buf[tail..head]`.
            //
            //

            // e lava le avanoa avanoa e kopi ai le ulu i le tasi le alu, o lona uiga tatou muamua suia le siʻu i luma, ona kopi lea o le ulu i le sao tulaga.
            //
            //
            // mai: FGH .... ABCDE
            // i: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // maua fua e laititi nai lo uma ulu ma iʻu, o lona uiga e tatau ona tatou lemu "swap" le siʻu ma le ulu.
            //
            //
            // mai: EFGHI ... ABCD poʻo HIJK.ABCDEFG
            // i: ABCDEFGHI ... poʻo ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // O le faʻafitauli lautele e pei o lenei GHIJKLM ... ABCDEF, ae le i fesuiaʻi se ABCDEFM ... GHIJKL, pe a maeʻa le 1 pasi o swaps ABCDEFGHIJM ... KL, fesuiaʻi seʻia oʻo i le agavale edge e taunuʻu atu i le faleoloa
                //                  - ona toe amataina lea ole algorithm ile faleoloa fou (smaller) O isi taimi e taunuʻu ai le faleoloa temp pe a oʻo i le faaiuga o le buffer le edge sao, o lona uiga ua tatou oʻo ile faʻasologa saʻo ma le tele o swaps!
                //
                // E.g
                // EF..ABCD ABCDEF .., i le maeʻa ai o le fa afa swap ua maeʻa
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// Faʻamilo le faʻalua-iʻuga laina `mid` nofoaga i le agavale.
    ///
    /// Equivalently,
    /// - Faʻaaoga le mea `mid` ile tulaga muamua.
    /// - Faʻapipiʻi le muamua `mid` aitema ma tulei i latou i le iʻuga.
    /// - Faʻaaoga `len() - mid` i le itu taumatau.
    ///
    /// # Panics
    ///
    /// Afai `mid` sili atu nai lo `len()`.
    /// Manatua o `mid == len()` faia _not_ panic ma o se leai-op feauauaʻiga.
    ///
    /// # Complexity
    ///
    /// Faʻaalu `*O*(min(mid, len() - mid))` taimi ma leai se faʻaopoopo avanoa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// Faʻaaoga le faʻalua-iʻuga laina `k` nofoaga i le taumatau.
    ///
    /// Equivalently,
    /// - Faʻaaoga le mea muamua i le tulaga `k`.
    /// - Faʻamau i luga aitema mulimuli `k` ma tulei i luma.
    /// - Faʻaaoga le `len() - k` i le agavale.
    ///
    /// # Panics
    ///
    /// Afai `k` sili atu nai lo `len()`.
    /// Manatua o `k == len()` faia _not_ panic ma o se leai-op feauauaʻiga.
    ///
    /// # Complexity
    ///
    /// Faʻaalu `*O*(min(k, len() - k))` taimi ma leai se faʻaopoopo avanoa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // SAFETY: o auala nei e lua manaʻomia le fesuiaʻiga aofaʻi
    // ia i lalo ifo o le afa le umi o le deque.
    //
    // `wrap_copy` manaʻomia lena `min(x, cap() - x) + copy_len <= cap()`, ae sili atu `min` e le sili atu ma le afa o le gafatia, tusa lava pe o le x, o lea e lelei le valaʻau iinei ona o loʻo tatou valaʻau ma se mea e laititi atu i le afa le umi, e le sili atu ma le afa o le gafatia.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// Binary saili lenei faʻavasega X00 mo se elemeni tuʻuina atu.
    ///
    /// Afai e maua le tau ona toe faʻafoʻi mai lea o le [`Result::Ok`], o loʻo iai le index o le tutusa vaega.
    /// Afai e tele taʻaloga, ona mafai lea ona toe faʻafoʻi soʻo se tasi o matata.
    /// Afai e le maua le tau ona toe faʻafoʻi mai lea o le [`Result::Err`], o loʻo iai le faʻasino tusi e mafai ona tuʻu iai i totonu se elemeni tutusa aʻo tumau pea le faʻavasega lelei.
    ///
    ///
    /// # Examples
    ///
    /// Vaʻai i luga se faasologa o le fa elemeni.
    /// O le muamua e maua, ma le tulaga ese faʻatulagaina tulaga;o le lona lua ma le lona tolu e le maua;o le lona fa e mafai ona faʻatusatusa i soʻo se tulaga i `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// Afai e te manaʻo e tuʻu se aitema i le `VecDeque` faʻavasega, a o tausia le faʻavasega faʻasologa:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// Binary saili lenei faʻavasega `VecDeque` ma se faʻatusa galuega.
    ///
    /// O le galuega faʻatusatusa e tatau ona faʻatinoina se faʻatonuga e ogatusa ma le faʻasologa o mea autu `VecDeque`, toe faʻafoʻi mai se numera code e faʻamaonia ai o lana finauga o le `Less`, `Equal` poʻo le `Greater` nai lo le manaʻoga o loʻo manaʻomia.
    ///
    ///
    /// Afai e maua le tau ona toe faʻafoʻi mai lea o le [`Result::Ok`], o loʻo iai le index o le tutusa vaega.Afai e tele taʻaloga, ona mafai lea ona toe faʻafoʻi soʻo se tasi o matata.
    /// Afai e le maua le tau ona toe faʻafoʻi mai lea o le [`Result::Err`], o loʻo iai le faʻasino tusi e mafai ona tuʻu iai i totonu se elemeni tutusa aʻo tumau pea le faʻavasega lelei.
    ///
    /// # Examples
    ///
    /// Vaʻai i luga se faasologa o le fa elemeni.O le muamua e maua, ma se tulaga ese faʻatulagaina tulaga;o le lona lua ma le lona tolu e le maua;o le lona fa e mafai ona faʻatusatusa i soʻo se tulaga i `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// Binary saili lenei faʻavasega `VecDeque` ma le ki aveʻeseina galuega tauave.
    ///
    /// Faʻapea o le `VecDeque` ua faʻavasegaina e le ki, mo se faʻataʻitaʻiga ma [`make_contiguous().sort_by_key()`](#method.make_contiguous) faʻaaogaina le tutusa autu aveʻeseʻese gaioiga.
    ///
    ///
    /// Afai e maua le tau ona toe faʻafoʻi mai lea o le [`Result::Ok`], o loʻo iai le index o le tutusa vaega.
    /// Afai e tele taʻaloga, ona mafai lea ona toe faʻafoʻi soʻo se tasi o matata.
    /// Afai e le maua le tau ona toe faʻafoʻi mai lea o le [`Result::Err`], o loʻo iai le faʻasino tusi e mafai ona tuʻu iai i totonu se elemeni tutusa aʻo tumau pea le faʻavasega lelei.
    ///
    /// # Examples
    ///
    /// Vaʻai i luga se faasologa o le fa elemeni i se fasi o paga faʻavasegaina e latou elemeni lona lua.
    /// O le muamua e maua, ma le tulaga ese faʻatulagaina tulaga;o le lona lua ma le lona tolu e le maua;o le lona fa e mafai ona faʻatusatusa i soʻo se tulaga i `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// Fesuiaʻi le `VecDeque` i-nofoaga ina ia `len()` tutusa ma new_len, a le o le aveʻesea o sili elemene mai le tua pe ala i le faʻaopopoina faʻamau o `value` i tua.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// Faʻafoʻi mai le faʻasino igoa ile faʻavaʻa autu mo se faʻavasega elemeni talafeagai.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // lapoʻa o taimi uma o se malosiaga o le 2
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// Fuafua le aofai o elemene tuua e tatau ona faitauina i le buffer
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // lapoʻa o taimi uma o se malosiaga o le 2
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // E masani ona vaeluaina i vaega e tolu, mo se faʻataʻitaʻiga: oe lava: [a b c|d e f] isi: [0 1 2 3|4 5] luma=3, ogatotonu=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // E le mafai ona faʻaaoga le Hash::hash_slice i luga o fasi pepa na faʻafoʻi mai e le auala e faʻaaoga e pei o lo latou umi e mafai ona fesuiaʻi i seisi auala e tasi.
        //
        //
        // Naʻo Hasher e faʻamautinoa tutusa mo le tutusa tonu seti o valaʻau i ana auala.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Faʻaaoga le `VecDeque` i totonu o le pito i luma-i-tua ituleti maua elemeni i le taua.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // Lenei gaioiga tatau ona tutusa le amio lelei o le:
        //
        //      mo aitema i le iter.into_iter() {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// Suʻe le [`Vec<T>`] i le [`VecDeque<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// O lenei e 'aloʻese mai le toe faʻatulagaina i mea e mafai ai, ae o aiaiga mo na mea e faigata, ma e mafai ona suia, ma e le tatau ona faʻamoemoeina seʻi vagana o le `Vec<T>` na sau mai `From<VecDeque<T>>` ma e leʻi faʻatulagaina.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // E leai se vaegatupe mo le ZST e popole ai ile gafatia, ae e le mafai e `VecDeque` ile umi ole `Vec`.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // Matou te manaʻomia le toe fua pe a fai o le malosiʻaga e le o se malosiʻaga o le lua, laʻititi pe leai foi a itiiti mai ma le tasi le avanoa avanoa.
            // Tatou te faia lenei ao o pea i le `Vec` faapea o le a pau le mea o loo i panic.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// Suʻe le [`VecDeque<T>`] i le [`Vec<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// E le manaʻomia le toe faʻasoaga, ae manaʻomia le faʻatinoina o le *O*(*n*) faʻamatalaga peʻa fai e leʻo iai le buffer liʻo ile amataga ole faʻasoaga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // Lenei o le *O*(1).
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // Lenei tasi manaʻomia faʻamatalaga toe faʻaleleia.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}