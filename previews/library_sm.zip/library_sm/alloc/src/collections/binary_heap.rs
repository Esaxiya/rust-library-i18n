//! O se faʻamuamua faʻatulagaina faʻatinoina ma se faaputuga binary.
//!
//! Insertion ma popping le sili ona tele elemeni maua *O*(log(*n*)) taimi faigata.
//! Siaki le elemene sili ona tele o *O*(1).O le faʻaliliuina o le vector i se faʻaputuga lua e mafai ona faia i totonu o le nofoaga, ma maua ai le *O*(*n*) faigata.
//! E mafai foi ona liua se faaputuga binary i se vector faʻavasega i totonu o le nofoaga, faʻatagaina e faʻaaoga mo le *O*(*n*\*log(* n*)) i totonu o le nofoaga faaputuga.
//!
//! # Examples
//!
//! Lenei o se lapoʻa faʻataʻitaʻiga e faʻaaogaina [Dijkstra's algorithm][dijkstra] e fofo le [shortest path problem][sssp] luga o le [directed graph][dir_graph].
//!
//! O loʻo faʻaalia mai pe faʻafefea ona faʻaaoga le [`BinaryHeap`] ma ituaiga masani.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // O le faʻamuamua faamuamua faʻamoemoe i `Ord`.
//! // Faʻamalamalama manino le trait o lea o le laina laina avea ma min-faaputuga nai lo le max-heap.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Matau o le tatou flip le okaina i tau.
//!         // I le tulaga o se fusiua tatou faʻatusatusaina tulaga, o lenei laʻasaga e talafeagai e faia ai faʻatinoga o `PartialEq` ma `Ord` tumau.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` e manaʻomia foʻi ona faʻatino.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // O node taʻitasi o loʻo fai ma sui o le `usize`, mo le puʻupuʻu o le faʻatinoga.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Dijkstra's auala puʻupuʻu algorithm.
//!
//! // Amata ile `start` ma faʻaaoga `dist` e siaki ai le lata mai lata mai nei i node uma.O lenei faʻatinoga e le manatua-lelei aua e ono tuua ai faʻalua kopi i le laina.
//! //
//! // E faʻaaogaina foi le `usize::MAX` o se tau o le sentinel, mo se faʻafaigofieina faʻatinoga.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [node]=lata mai nei mai le `start` i le `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Ua matou i le `start`, ma le leai se tau
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Iloilo le tuaoi ma lalo tau node muamua (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // Faʻamata e mafai ona tatou faʻaauau pea ona sailia uma auala puʻupuʻu
//!         if position == goal { return Some(cost); }
//!
//!         // Taua e pei ona ua uma ona tatou mauaina se sili atu auala
//!         if cost > dist[position] { continue; }
//!
//!         // Mo node taʻitasi e mafai ona tatou aʻapa atu i ai, vaʻai pe mafai ona tatou sailia se auala ma se tau maualalo e alu i lenei nofoaga
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Afai o lea, faʻaopopo i le tuaoi ma faaauau
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Malologa, ua tatou mauaina nei se auala sili atu
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Sini e le mafai ona ausia
//!     None
//! }
//!
//! fn main() {
//!     // Lenei o le faʻatonuga kalafi o le a tatou faʻaaogaina.
//!     // O numera numera e fesoʻotaʻi ma setete eseʻese, ma le mamafa o le edge o loʻo faʻatusalia le tau o le sifi ese mai le tasi node i le isi.
//!     //
//!     // Manatua o pito e tasi le auala.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // O le kalafi ua fai ma sui o se vavalalata lisi o faʻasino igoa taʻitasi, e tutusa ma le tau o le tau, o loʻo iai se lisi o tafatafa o pito.
//!     // Filifilia mo lona aoga.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Node 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Node 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Node 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Node 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Node 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// O se faʻamuamua faʻatulagaina faʻatinoina ma se faaputuga binary.
///
/// Lenei o le a avea ma maualuga-faaputuga.
///
/// O se sese mea sese mo se aitema ona toe teuteuina i se auala o le aitema okaina faʻatatau i soʻo se isi lava aitema, e pei ona fuafuaina e le `Ord` trait, suia a o i ai i le faupuega.
///
/// Lenei e mafai naʻo le `Cell`, `RefCell`, tulaga o le lalolagi, I/O, poʻo le le saogalemu.
/// O le amioga e mafua mai i se sese sese e le faʻamaotiina, ae o le a le maua ai i le le faʻamatalaina amio.
/// E mafai ona aofia ai le panics, le saʻo o faʻaiuga, toesea o mea, manatuaina o le solo, ma le faʻamutaina.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Ituaiga inferensi faʻatagaina tatou aveese se manino ituaiga saini (lea o le `BinaryHeap<i32>` i lenei faʻataʻitaʻiga).
/////
/// let mut heap = BinaryHeap::new();
///
/// // E mafai ona matou faʻaaogaina le vaʻai e vaʻai ai i le isi aitema i le faʻaputuga.
/// // I lenei tulaga, e leai ni aitema i ai iina tatou maua leai.
/// assert_eq!(heap.peek(), None);
///
/// // Seʻi o tatou faʻaopopoina ni togi ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // O lenei vaʻaia faʻaali atu le sili ona taua aitema i le faʻaputuga.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // E mafai ona tatou siaki le umi o le faaputuga.
/// assert_eq!(heap.len(), 3);
///
/// // E mafai ona tatou faʻasolosolo mea i luga o le faaputuga, e ui lava na toe faʻafoʻi mai i se faʻatonuga saʻo.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Afai tatou te togiina nei togi, e tatau ona latou toe foʻi mai i le faʻasologa.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // E mafai ona matou kilia le faaputuga o soʻo se aitema.
/// heap.clear();
///
/// // Ua tatau nei ona gaogao le faaputuga.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// A le o le `std::cmp::Reverse` poʻo le `Ord` faʻatinoga masani e mafai ona faʻaaogaina e fai ai le `BinaryHeap` o se faupuega.
/// Lenei faia `heap.pop()` toe faʻafoʻi le laʻititi taua nai lo le sili sili.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Afifi le taua ile `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Afai tatou te popa nei togi i le taimi nei, e tatau ona latou toe foʻi mai i le faʻatonuga faʻasolo.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Faigata taimi
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// O le tau mo `push` o se tau fuafuaina;o le metotia faʻamaumauga maua ai se sili auiliiliga auiliiliga.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Fausaga afifiina se mutable faʻasino i le sili mea i luga o le `BinaryHeap`.
///
///
/// Lenei `struct` na faia e le [`peek_mut`] metotia luga [`BinaryHeap`].
/// Vaʻai ana faʻamaumauga mo sili atu.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // SAFETY: PeekMut ua naʻo le faʻamaʻaʻaina mo le leai-gaogaʻi faʻaputuga.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // SAFE: PeekMut ua naʻo le faʻamaʻaʻaina mo le leai-gaogaʻi faʻaputuga
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // SAFE: PeekMut ua naʻo le faʻamaʻaʻaina mo le leai-gaogaʻi faʻaputuga
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Aveʻese le peeked aoga mai le faʻaputuga ma toe faʻafoʻi.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Fausia se avanoa `BinaryHeap<T>`.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Fausia se avanoa `BinaryHeap` o se maualuga-faʻaputuga.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Fausia se gaogao `BinaryHeap` ma se faʻapitoa gafatia.
    /// O lenei preallocates lava manatuaina mo `capacity` elemeni, ina ia le `BinaryHeap` e le tau faʻatulagaina seʻia oʻo iai ni mea sili atu ma le tele o mea taua.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Faʻafoʻi mai se fesuiaʻiga faʻafesoʻotaʻi i le mea sili ona tele i le faaputuga binary, poʻo le `None` peʻa leai se mea.
    ///
    /// Note: Afai o le `PeekMut` aoga ua faʻasalalau, o le faʻaupuga atonu o loʻo i ai i se tulaga le ogatasi.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Faigata taimi
    ///
    /// Afai e toe faʻaleleia le aitema o lona uiga o le *O*(log(*n*)) le mea sili ona leaga na tupu, a leai o le *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Aveʻese le mea sili ona tele mai le faʻaupuga binary ma faʻafoʻi ia, pe `None` peʻa leai se mea.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Faigata taimi
    ///
    /// O le tau sili ona leaga o le `pop` i luga o le faaputuga o loʻo iai *n* elemeni ole *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // SAFETY: !self.is_empty() o lona uiga o self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Tulei le aitema i luga o le faʻaupuga binary.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Faigata taimi
    ///
    /// O le tau fuafuaina o le `push`, o le averesi i luga o soʻo se okaina o elemeni e mafai ona unaʻia, ma ova atu le aofaʻi o tulei, o le *O*(1).
    ///
    /// O le metric tau sili ona taua lenei pe a tuleia elemeni e le *i ai* i soʻo se faʻavasega mamanu.
    ///
    /// O le taimi faigata faʻaletonu pe a fai o elemeni e tuleia i le tele o siʻitia i luga faʻasologa.
    /// I le sili ona leaga tulaga, elemene tuleia i le alu i luga faʻavasega faʻasologa ma le amortized tau i le tulei o *O*(log(*n*)) faasaga i se faaputuga aofia ai *n* elemeni.
    ///
    /// O le tau sili ona leaga o le *tasi* valaʻau i le `push` o le *O*(*n*).O le sili ona leaga mataupu tupu pe a gafatia gafatia ma manaʻomia se resize.
    /// O le tau faʻatulagaina tau ua amortized i le numera muamua.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // SAFETI: Talu ai na matou tuleia se aitema fou o lona uiga o
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Faʻauma le `BinaryHeap` ma faʻafoʻi mai le vector i le faʻasologa (ascending) faʻasologa.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // SAFETY: `end` alu mai `self.len() - 1` i le 1 (aofia uma),
            //  o lea e masani lava o se talafeagai faʻasino igoa e ulufale ai.
            //  E sefe le ulufale i le faasino igoa 0 (ie `ptr`), aua
            //  1 <=iʻuga <self.len(), o lona uiga self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // SAFETY: `end` alu mai `self.len() - 1` i le 1 (aofia uma) o lea:
            //  0 <1 <=iʻuga <= self.len(), 1 <self.len() O lona uiga o le 0 <faaiu ma le iʻuga <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // O le faʻatinoina o sift_up ma sift_down o loʻo faʻaaoga poloka le saogalemu ina ia mafai ai ona aveese se elemene mai le vector (tuʻua o se pu), sifi faʻatasi ma isi ma toe ave le mea ua ave i tua i le vector i le nofoaga mulimuli o le pu.
    //
    // O le `Hole` ituaiga e faʻaaogaina e fai ma sui o lenei, ma ia mautinoa o le pu na faʻatumuina i tua i le faʻaiuga o lona lautele, e oʻo lava i le panic.
    // Faʻaaogaina se pu e faʻaititia ai le mea masani pe a faʻatusatusa i le faʻaaogaina o swaps, e aofia ai faʻalua i le tele o gaioiga.
    //
    //
    //
    //

    /// # Safety
    ///
    /// O le tagata e valaʻau e tatau ona mautinoa le `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Aveese le tau ile `pos` ma fai se pu.
        // SAFETI: O le tagata telefoni na te faʻamaonia lena pos <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // SAFETY: hole.pos()> amata>=0, o lona uiga hole.pos()> 0
            //  ma o lea hole.pos(), 1 le mafai goto.
            //  Lenei mautinoa le matua <hole.pos() o lea o se aloaia faʻasino igoa ma faʻapea foi!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // SAFETI: Tutusa i luga
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Ave se elemeni ile `pos` ma ave i lalo le faʻaupuga, aʻo ona tamaiti e lapoʻa.
    ///
    ///
    /// # Safety
    ///
    /// O le tagata e valaʻau e tatau ona mautinoa le `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // SAFETI: O le tagata telefoni na te faʻamautinoaina lena pos <faaiuga <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Loari invariant: tamaititi==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // Faʻatusatusa i le toʻatele o tamaiti e toʻalua SAFETY: tamaititi <faaiu, 1 <self.len() ma le tamaititi + 1 <faaiuga <= self.len(), o lea la o latou sao faʻasino igoa.
            //
            //  tamaititi==2 *hole.pos() + 1!= hole.pos() ma le tamaititi + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 poʻo le 2* hole.pos() + 2 e mafai ona oʻo atu pe a fai o le T o le ZST
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // afai ua uma ona tatou faʻatonutonu, taofi.
            // SAUNIGA: tamaititi o le taimi nei a le o le tamaititi matua poʻo le matua matua + 1
            //  Ua uma ona matou faʻamaonia o mea uma e <self.len() ma!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // SAFETY: tutusa ma luga.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // SAFETY: &&auala puʻupuʻu, o lona uiga i le
        //  tulaga lua ua uma ona moni o le tamaititi==faʻaiʻu, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // SAFETI: tamaititi ua uma ona faʻamaonia e avea ma se sao faʻasino igoa ma
            //  tamaititi==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// O le tagata e valaʻau e tatau ona mautinoa le `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // SAFETY: pos <len e mautinoa e le tagata telefoni ma
        //  e mautinoa lava len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Ave se elemeni i le `pos` ma alu i lalo uma i lalo le faaputuga, ona siʻi lea i luga i lona tulaga.
    ///
    ///
    /// Note: E vave atu lea pe a fai o le elemeni e iloa e telē/e tatau ona latalata i lalo.
    ///
    /// # Safety
    ///
    /// O le tagata e valaʻau e tatau ona mautinoa le `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // SAFETI: O le tagata telefoni na te faʻamaonia lena pos <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Loari invariant: tamaititi==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // SAFETI: tamaititi <faaiu, 1 <self.len() ma
            //  tama + 1 <faaiʻui <= self.len(), o lona uiga la, e saʻo faasino igoa.
            //  tamaititi==2 *hole.pos() + 1!= hole.pos() ma le tamaititi + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 poʻo le 2* hole.pos() + 2 e mafai ona oʻo atu pe a fai o le T o le ZST
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // SAFETI: Tutusa i luga
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // SAFETI: tamaititi==faʻaiʻu, 1 <self.len(), o lona uiga o se faʻailoga talafeagai
            //  ma le tamaititi==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // SAFETY: pos o le tulaga i le pu ma ua uma na faʻamaonia
        //  ia avea ma se faʻailoga talafeagai.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // SAFETY: n amata mai self.len()/2 ma alu ifo i lalo i le 0.
            //  Pau lava le mataupu pe a! (N <self.len()) peʻa self.len() ==0, ae faʻamavae e le tulaga matasele.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Siʻi uma elemeni o `other` i le `self`, ae tuʻu pea i le `other`.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` ave O(len1 + len2) gaioiga ma tusa ma le 2 *(len1 + len2) faʻatusatusaga i le sili atu leaga tulaga ae `extend` ave O(len2* log(len1)) gaioiga ma e uiga i le 1 *len2* log_2(len1) faʻatusatusaga i le sili ona leaga mataupu, manatu len1>= len2.
        // Mo faaputuga lapoʻa, o le crossover point le toe mulimuli i lenei mafaufauga ma na mautinoa empirically.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Faʻafoʻi mai se mea faʻasolosolo na te aumaia elemeni i le faʻavasega faʻaputuga.
    /// O elemene na maua mai ua aveʻese mai le uluaʻi faaputuga.
    /// O totoe elemeni o le a aveʻese ile mataua i le faaputuga faʻavasega.
    ///
    /// Note:
    /// * `.drain_sorted()` e *O*(*n*\*log(* n*)); e telegese nai lo `.drain()`.
    ///   E tatau ona e faʻaaogaina le mea mulimuli mo le tele o mataupu.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // aveʻese elemeni uma i le faʻavasega faʻaputuga
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Faʻataua naʻo elemeni ua faʻamaonia mai e le faʻamatalaga muamua.
    ///
    /// I nisi upu, aveʻese uma elemeni `e` pei o le `f(&e)` faʻafoʻi `false`.
    /// O elemene e asia i le faʻasologa (ma le faʻamaotiina) faʻasologa.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // naʻo numera lava e teu ai
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Faʻafoʻi mai se mea faʻasalalau asiasi i mea taua uma ile faʻavae o le vector, i se faʻasologa faʻasolitulafono.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Lolomi 1, 2, 3, 4 i se faʻasologa saʻo
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Faʻafoʻi mai se mea faʻasolosolo na te aumaia elemeni i le faʻavasega faʻaputuga.
    /// O lenei metotia faʻaumatia ai le faaputuga muamua.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Faʻafoʻi mai le mea sili i le faʻaputuga binary, poʻo le `None` peʻa leai se mea.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Faigata taimi
    ///
    /// Tau o le *O*(1) i le sili ona leaga tulaga.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Faʻafoʻi mai le numera o elemene e mafai ona taofia e le faʻaupuga binary e aunoa ma le toe faʻatulagaina.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Faʻasao le laʻititi gafatia mo tonu `additional` sili elemeni e faʻaofi i le `BinaryHeap` tuʻuina atu.
    /// E leai se mea pe a fai o le malosi ua lava.
    ///
    /// Manatua o le tagata faʻasoa e ono tuʻuina atu i le aoina sili avanoa nai lo le mea e talosagaina.
    /// O le mea lea gafatia e le mafai ona faʻamoemoeina i le avea ma saʻo itiiti.
    /// Sili [`reserve`] pe a fai o future e ono faʻaofiina.
    ///
    /// # Panics
    ///
    /// Panics pe a fai e oʻo i le `usize` le malosi fou.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Faʻaagaga gafatia mo le sili atu `additional` sili elemeni e faʻaofi i le `BinaryHeap`.
    /// O le aoina ono faʻaavanoa tele avanoa e aloese ai mai faʻataʻitaʻiga masani.
    ///
    /// # Panics
    ///
    /// Panics pe a fai e oʻo i le `usize` le malosi fou.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Lafoaia le tele faʻaopoopo gafatia e mafai ai.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Lafoaia gafatia ma se pito i lalo lalo.
    ///
    /// O le gafatia o le a tumau i le sili atu tele pei o uma le umi ma le sapalai taua.
    ///
    ///
    /// Afai o le malosiaga o loʻo i ai nei e laititi atu i lo le tapulaʻa maualalo, o le leai-op lea.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Faʻauma le `BinaryHeap` ma faʻafoʻi mai le vector faʻavae i se faʻasologa faʻasolitulafono.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // E lolomiina i se faʻasologa
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Faʻafoʻi le umi o le faʻaupuga binary.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Siaki pe afai e avanoa le faʻaupuga binary.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Faʻamamaina le faaputuga lua, toe faʻafoʻi se iterator luga o le elemene aveʻesea.
    ///
    /// O elemene e aveese i se faʻasologa tatau.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Faʻapaʻu mea uma mai le faupuega binary.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// O le pu e fai ma sui o se pu i se fasi ie, o se faasino igoa e aunoa ma se aoga aoga (aua na aveʻese mai pe faʻaluaina).
///
/// I le pa'ū, `Hole` o le a toe faʻafoʻi le fasi e ala i le faʻatumuina o le pu tulaga ma le tau na muamua aveʻesea.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Fausia se `Hole` fou ile index `pos`.
    ///
    /// Le saogalemu aua o le pos e tatau ona iai i totonu o faʻamaumauga.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // SAFE: pos tatau i totonu o le fasi
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Faʻafoʻi mai se faʻasino i le elemeni ua aveʻesea.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Faʻafoʻi mai se faʻasino i le elemeni ile `index`.
    ///
    /// Le sefe aua o faʻasino e tatau ona i totonu o faʻamaumauga ma e le tutusa ma pos.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Alu ese pu i nofoaga fou
    ///
    /// Le sefe aua o faʻasino e tatau ona i totonu o faʻamaumauga ma e le tutusa ma pos.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // toe faʻatumu le pu
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// O se faʻasolosolo luga o elemene o le `BinaryHeap`.
///
/// Lenei `struct` faia e [`BinaryHeap::iter()`].
/// Vaʻai ana faʻamaumauga mo sili atu.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Aveʻese nai lo le `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// O se umiaina iterator luga o elemene o le `BinaryHeap`.
///
/// O lenei `struct` na faia e [`BinaryHeap::into_iter()`] (saunia e le `IntoIterator` trait).
/// Vaʻai ana faʻamaumauga mo sili atu.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// O se faʻamatuʻuina iterator luga o elemene o le `BinaryHeap`.
///
/// Lenei `struct` faia e [`BinaryHeap::drain()`].
/// Vaʻai ana faʻamaumauga mo sili atu.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// O se faʻamatuʻuina iterator luga o elemene o le `BinaryHeap`.
///
/// Lenei `struct` faia e [`BinaryHeap::drain_sorted()`].
/// Vaʻai ana faʻamaumauga mo sili atu.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Aveʻese elemeni faaputuga i faaputuga faaputuga.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Faʻaliliua se `Vec<T>` i totonu o le `BinaryHeap<T>`.
    ///
    /// O lenei liua e tupu i totonu o le nofoaga, ma maua ai le *O*(*n*) taimi faigata.
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Faʻaliliua se `BinaryHeap<T>` i totonu o le `Vec<T>`.
    ///
    /// Lenei liua e le manaʻomia se faʻagaioiga faʻamatalaga poʻo se faʻasoaga, ma ei ai pea taimi laʻitiiti faigata.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Fausia se faʻaaluina iterator, o lona uiga, o se tasi e aveʻese ai taua uma mai le lua faʻaputuga i se faʻasologa tatau.
    /// E le mafai ona faʻaaogaina le faʻaupuga binary pe a uma ona valaʻau lenei.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Lolomi 1, 2, 3, 4 i se faʻasologa saʻo
    /// for x in heap.into_iter() {
    ///     // x ei ai le ituaiga i32, ae le o le &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}