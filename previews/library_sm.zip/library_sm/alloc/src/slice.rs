//! Se vaʻaiga faʻa-tele i se faʻasologa vavalalata, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Fasi fasi o se vaʻaiga i totonu o se poloka o manatua faʻatusalia o se faʻasino ma le umi.
//!
//! ```
//! // tipiina o le Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // faamalosia le faʻasologa i se fasi
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! O fasi pepa e mafai ona suia pe fefaʻasoaaʻi.
//! O le fasi vaega fefaʻasoaaʻi o le `&[T]`, ae o le ituaiga fesuiaʻi o le `&mut [T]`, o le `T` e fai ma sui o le elemeni vaega.
//! Mo se faʻataʻitaʻiga, e mafai ona e suia le poloka o mea e te manatuaina e faʻapea, o se fasi fesuiaʻi e faʻasino ia:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! O nisi nei o mea o loʻo i ai i lenei vaega:
//!
//! ## Structs
//!
//! E i ai ni faʻasologa e aoga mo fasi pepa, pei o le [`Iter`], o loʻo avea ma faʻasolosolo i luga o se fasi.
//!
//! ## Trait Faʻatinoga
//!
//! E tele faʻatinoga o masani traits mo fasi.O ni faʻataʻitaʻiga e aofia ai:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], mo fasi fasi elemeni o latou ituaiga o [`Eq`] poʻo [`Ord`].
//! * [`Hash`] - mo fasi o latou elemeni ituaiga o [`Hash`].
//!
//! ## Iteration
//!
//! O fasi fasi `IntoIterator`.O le iterator maua faʻamatalaga i le fasi elemeni.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! O le fasi fesuiaiga maua mutable mau faasino i le elemene:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! O lenei iterator maua mutable faʻasino i le fasi a elemene, o lea a o le elemene ituaiga o le fasi o `i32`, o le elemene ituaiga o le faʻamaufaʻailoga o `&mut i32`.
//!
//!
//! * [`.iter`] ma [`.iter_mut`] o auala manino ia e toe faʻafoʻi mai ai le mea masani.
//! * O isi metotia e toe faʻafoʻi atu o [`.split`], [`.splitn`], [`.chunks`], [`.windows`] ma sili atu.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Ole tele ole faʻaaogaina i lenei vaega e faʻaogaina lava ile faʻataʻitaʻiga ole suʻega.
// E sili atu le mama na o le tapeina o le lapataiga e leʻo faʻaaogaina nai lo le faʻasaʻoina.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Fuataga fasi faʻalautelega metotia
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) manaʻomia mo le faʻatinoina o `vec!` macro i le taimi o suʻega NB, vaʻai le `hack` module i lenei faila mo nisi faʻamatalaga.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) manaʻomia mo le faʻatinoina o `Vec::clone` i le taimi o suʻega NB, vaʻai i le `hack` module i lenei faila mo nisi faʻamatalaga.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Faʻatasi ai ma le cfg(test) `impl [T]` e le maua, o nei mea taua e tolu o ni metotia moni ia o loʻo i le `impl [T]` ae le o le `core::slice::SliceExt`, e manaʻomia le tuʻuina atu o nei galuega mo le suʻega `test_permutations`.
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // E le tatau ona matou faʻaopopoina le fesoʻotaʻiga i lenei mea talu ai o lenei e faʻaaogaina i le `vec!` macro tele ma mafua ai le toe faʻaleleia o le tino.
    // Vaʻai #71204 mo faʻatalanoaga ma iʻuga atoatoa.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // aitema na maka amataina i le matasele i lalo
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) e talafeagai mo LLVM e aveʻesea tuaʻoi siaki ma sili atu codegen nai lo zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // o le volt na tuʻufaʻatasia ma amataina i luga e sili atu i lenei umi.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // vaevaeina i luga ma le mafai o `s`, ma muamua i `s.len()` i ptr::copy_to_non_overlapping lalo.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Faʻavasega le fasi.
    ///
    /// Lenei ituaiga e mautu (ie, e le toe faʻatulagaina tutusa elemeni) ma *O*(*n*\*log(* n*)) sili ona leaga-tulaga.
    ///
    /// A talafeagai, e le faʻavasega faʻavasegaina e sili ona e masani ona sili atu le vave nai lo le faʻavasega mautu ma e le faʻavasega ausilali faʻamanatu.
    /// Vaʻai [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Faʻatinoina nei
    ///
    /// O le algorithm o loʻo i ai nei, o se fetuʻunaʻiga, o le faʻasoʻoina o le tuʻufaʻatasia o le ituaiga musuia e le [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Na fuafuaina ia matua televave i mataupu pe a o le fasi e toeititi faʻavasegaina, pe aofia ai ni lua pe sili atu faʻavasega faʻasologa faʻasolo tasi i le isi.
    ///
    ///
    /// E le gata i lea, na te tuʻuina atu le teuina le tumau o le afa o le `self`, ae mo puʻupuʻu, o le le tuʻuina i se faʻamatalaga faʻaopoopo e faʻaaoga.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Faʻavasega le fasi ma se galuega faʻatusa.
    ///
    /// Lenei ituaiga e mautu (ie, e le toe faʻatulagaina tutusa elemeni) ma *O*(*n*\*log(* n*)) sili ona leaga-tulaga.
    ///
    /// O le galuega faʻatusatusa e tatau ona faʻamatalaina atoa le okaina o elemeni i totonu o le fasi.Afai o le okaina e le atoa, o le faʻatonuga o elemeni e le o faʻamaoti maia.
    /// O se oka o se aofaʻiga oka pe a fai o (mo uma `a`, `b` ma `c`):
    ///
    /// * aofaʻi ma antisymmetric: e tasi lava le `a < b`, `a == b` poʻo le `a > b` e moni, ma
    /// * fesuiaʻi, `a < b` ma `b < c` faʻaalia `a < c`.O le tutusa e tatau ona taofia mo uma `==` ma `>`.
    ///
    /// Mo se faʻataʻitaʻiga, a o le [`f64`] e le faʻatinoina [`Ord`] aua `NaN != NaN`, e mafai ona tatou faʻaaogaina le `partial_cmp` e fai ma a tatou galuega faʻavae pe a tatou iloa o le fasi e le o i ai se `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// A talafeagai, e le faʻavasega faʻavasegaina e sili ona e masani ona sili atu le vave nai lo le faʻavasega mautu ma e le faʻavasega ausilali faʻamanatu.
    /// Tagai [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Faʻatinoina nei
    ///
    /// O le algorithm o loʻo i ai nei, o se fetuʻunaʻiga, o le faʻasoʻoina o le tuʻufaʻatasia o le ituaiga musuia e le [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Na fuafuaina ia matua televave i mataupu pe a o le fasi e toeititi faʻavasegaina, pe aofia ai ni lua pe sili atu faʻavasega faʻasologa faʻasolo tasi i le isi.
    ///
    /// E le gata i lea, na te tuʻuina atu le teuina le tumau o le afa o le `self`, ae mo puʻupuʻu, o le le tuʻuina i se faʻamatalaga faʻaopoopo e faʻaaoga.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // faʻavasega faʻavasega
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Faʻavasega le fasi ma le autu aveʻeseʻese galuega tauave.
    ///
    /// Lenei ituaiga e mautu (ie, e le toe faʻatulagaina tutusa elemeni) ma *O*(*m*\* * n *\* log(*n*)) sili ona leaga-tulaga, lea o le ki galuega tauave o *O*(*m*).
    ///
    /// Mo taugata ki autu (faʻataʻitaʻiga
    /// gaioiga e le o ni meatotino faigofie faʻaaogaina poʻo ni faʻagaioiga masani), [`sort_by_cached_key`](slice::sort_by_cached_key) e foliga mai e sili atu ona vave, aua e le toe faʻamatalaina elemene ki.
    ///
    ///
    /// A talafeagai, e le faʻavasega faʻavasegaina e sili ona e masani ona sili atu le vave nai lo le faʻavasega mautu ma e le faʻavasega ausilali faʻamanatu.
    /// Vaʻai [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Faʻatinoina nei
    ///
    /// O le algorithm o loʻo i ai nei, o se fetuʻunaʻiga, o le faʻasoʻoina o le tuʻufaʻatasia o le ituaiga musuia e le [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Na fuafuaina ia matua televave i mataupu pe a o le fasi e toeititi faʻavasegaina, pe aofia ai ni lua pe sili atu faʻavasega faʻasologa faʻasolo tasi i le isi.
    ///
    /// E le gata i lea, na te tuʻuina atu le teuina le tumau o le afa o le `self`, ae mo puʻupuʻu, o le le tuʻuina i se faʻamatalaga faʻaopoopo e faʻaaoga.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Faʻavasega le fasi ma le autu aveʻeseʻese galuega tauave.
    ///
    /// I le taimi o le faʻavasegaina, o le ki galuega tauave e valaʻau na o le tasi i le elemeni.
    ///
    /// Lenei ituaiga e mautu (ie, e le toe faʻatulagaina tutusa elemeni) ma *O*(*m*\* * n *+* n *\* log(*n*)) sili ona leaga-tulaga, lea o le ki galuega tauave o *O*(*m*) .
    ///
    /// Mo galuega faigofie faigofie (faʻataʻitaʻiga, o mea e faʻaaoga e faʻaaoga ai mea totino poʻo faʻagaioiga masani), e foliga mai e vave atu le [`sort_by_key`](slice::sort_by_key).
    ///
    /// # Faʻatinoina nei
    ///
    /// O le algorithm o loʻo i ai nei e faʻavae i luga o le [pattern-defeating quicksort][pdqsort] e Orson Peters, lea e tuʻufaʻatasia ai le vave averesi mataupu o le randomized quicksort ma le vave sili ona leaga o le heapsort, aʻo mauaina laina taimi i luga o fasi ma nisi mamanu.
    /// Na te faʻaaogaina nisi faʻavasega e aloese ai mai tulaga faʻaletonu, ae ma le seed faʻamau e masani ona maua ai amioga mautinoa.
    ///
    /// I le sili ona leaga tulaga, o le algorithm faʻasoaga le tumau teuina i le `Vec<(K, usize)>` le umi o le fasi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Fesoasoani macro mo le faʻavasegaina o la matou vector e se ituaiga laʻititi mafai, e faʻaititia ai le faʻasoaga.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // O elemene o le `indices` e tulaga ese, aua o loʻo faʻasino igoa, o lea la o soʻo se ituaiga o le a mausali e tusa ai ma le uluaʻi fasi.
                // Matou te faʻaaogaina le `sort_unstable` iinei aua e manaʻomia ai le laititi o le faʻasoa o mea.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Kopi le `self` i totonu o le `Vec` fou.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Lenei, `s` ma `x` mafai ona fesuiaʻi tutoʻatasi.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Kopi le `self` i totonu o le `Vec` fou ma le faʻasoasoa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Lenei, `s` ma `x` mafai ona fesuiaʻi tutoʻatasi.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, vaʻai le `hack` module i lenei faila mo nisi faʻamatalaga.
        hack::to_vec(self, alloc)
    }

    /// Faʻaliliu `self` i totonu o le vector e aunoa ma ni clones poʻo se vaeluaina.
    ///
    /// O le iʻuga vector e mafai ona toe liua i totonu o se atigipusa ala Vec<T>'' S auala `into_boxed_slice`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` ua le toe mafai ona faʻaaogaina aua ua liua i le `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, vaʻai le `hack` module i lenei faila mo nisi faʻamatalaga.
        hack::into_vec(self)
    }

    /// Fausia se vector e ala i le toe faia o se fasi `n` taimi.
    ///
    /// # Panics
    ///
    /// Lenei gaioiga o le a panic pe a fai o le malosi o le a masuasua.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// A panic luga ova:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Afai e lapoʻa le `n` ile zero, e mafai ona vaevaeina ile `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` o le numera o loʻo faʻatusalia e le itu agavale o le '1' o le `n`, ma le `rem` o le vaega o totoe o le `n`.
        //
        //

        // Faʻaaogaina `Vec` e ulufale ai i `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` toe fai e faia e faʻaluaina `buf` `expn`-taimi.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Afai o `m > 0`, o loʻo totoe ni mea se i oʻo i le agavale '1'.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` ei ai le mafai o `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) faʻataʻitaʻiga e faia i le kopiina muamua `rem` toe fai mai `buf` lava ia.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // E le faʻapipiʻiina lenei talu mai `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` tutusa ma `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Flattens se fasi `T` i le tasi tau `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Flattens se fasi o `T` i le tasi le taua `Self::Output`, tuʻuina o se tuʻufaʻatasia tuʻufaʻatasia i le va o latou taʻitasi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Flattens se fasi o `T` i le tasi le taua `Self::Output`, tuʻuina o se tuʻufaʻatasia tuʻufaʻatasia i le va o latou taʻitasi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Faʻafoʻi mai le vector o loʻo iai le kopi o lenei fasi fasi pepa taʻitasi e faʻavasegaina i lona tulaga maualuga ASCII.
    ///
    ///
    /// ASCII tusi 'a' e 'z' ua faailogaina e 'A' e 'Z', ae tusi lē ASCII ua suia.
    ///
    /// Ina ia faʻamaualuga le tau ile tulaga, faʻaaoga le [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// O tupe maua a vector o loo i ai se kopi o lenei fasi lea o loo faailogaina byte taitasi i lona ASCII tutusa tulaga maualalo.
    ///
    ///
    /// O mataitusi ASCII 'A' i le 'Z' e faʻafanua i le 'a' i le 'z', ae o mataitusi e leʻo ASCII e le suia.
    ///
    /// Ina ia faʻamau i lalo le tau ile nofoaga, faʻaaoga le [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Faʻalautelega traits mo fasi pepa i luga o ituaiga faʻapitoa o faʻamatalaga
////////////////////////////////////////////////////////////////////////////////

/// Fesoasoani trait mo [`[T]: : concat`](fasi::concat)
///
/// Note: le `Item` ituaiga parakalafa e le faʻaaogaina i lenei trait, ae e faʻatagaina impls ia sili atu lautele.
/// A aunoa ma lea, ua tatou maua lenei mea sese:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// E mafua ona e mafai ona i ai `V` ituaiga ma tele `Borrow<[_]>` impls, pei o le tele `T` ituaiga o le a faʻaaogaina:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Le faʻaiuga ituaiga ina ua maeʻa concatenation
    type Output;

    /// Faʻaaogaina o le [`[T]: : concat`](fasi::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Fesoasoani trait mo [`[T]: : auai`](fasi::auai)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Le faʻaiuga ituaiga ina ua maeʻa concatenation
    type Output;

    /// Faʻaaogaina o le [`[T]: : auai`](fasi::auai)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Faʻatulagaina trait faʻatinoga mo fasi
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // faʻapaʻu se mea i le taulaiga o le a le faʻasolosolo
        target.truncate(self.len());

        // target.len <= self.len talu ai o le truncate luga, o lea o fasi pepa iinei e masani ona totonu-tuaʻoi.
        //
        let (init, tail) = self.split_at(target.len());

        // toe faʻaaoga mea taua o loʻo iai allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Faʻaofi `v[0]` i le muamua faʻavasega faʻasologa `v[1..]` ina ia atoa `v[..]` avea faʻavasega.
///
/// Lenei o le tuʻufaʻatasia subroutine o faʻaofiina ituaiga.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // E tolu auala e faatino ai le faaofiina iinei:
            //
            // 1. Faʻafesuiaʻi elemeni fesoʻotaʻi seʻia oʻo ina muamua le mea muamua i lona taunuʻuga mulimuli.
            //    Ae ui i lea, o lenei auala matou te kopiina faʻamaumauga sili atu nai lo le mea e tatau ai.
            //    Afai e elemene ua fausaga tetele (taugata e kopi), o le a tuai lenei metotia.
            //
            // 2. Faʻafetaui seia maua le nofoaga saʻo mo le muamua elemeni.
            // Ona fesuiaʻi lea o elemeni o loʻo sosoʻo ina ia avanoa ai ma ia tuʻu ai i le pu o loʻo totoe.
            // O se lelei auala.
            //
            // 3. Kopi le muamua elemene i se le tumau fesuiaiga.Faʻasasaʻo seʻia maua le nofoaga saʻo mo ia.
            // Aʻo tatou o atu pea, kopi mea uma na laasia i le slot na muamua atu ia te ia.
            // I le iuga, kopi faʻamaumauga mai le le tumau fesuiaʻiga i le avanoa pu.
            // O lenei metotia e sili ona lelei.
            // O faʻailoga na faʻaalia e sili atu le lelei le faʻatinoga nai lo le 2nd auala.
            //
            // O metotia uma na faʻailogaina, ma o le lona 3 na faʻaalia ai sili ona lelei.Ma na matou filifilia le tasi lena.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // O le ogatotonu tulaga o le faʻaofiina gaioiga e masani ona siaki e `hole`, lea e lua mafuaʻaga:
            // 1. Puipuia le faʻamaoni o le `v` mai le panics i le `is_less`.
            // 2. Faatumulia ai le totoe pu i `v` i le iuga.
            //
            // saogalemu Panic:
            //
            // Afai `is_less` panics i soʻo se taimi i le taimi o le gaioiga, o le `hole` o le a paʻu i lalo ma faʻatumu le pu i le `v` ma le `tmp`, ma faʻamautinoa ai o le `v` o loʻo taofia uma mea faitino na muaʻi uuina faʻatasi tasi.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` paʻu ifo ma kopi le `tmp` i le pu o loʻo totoe ile `v`.
        }
    }

    // A pa'ū, kopi mai `src` i le `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Merges le-faʻaititia faʻatautaia `v[..mid]` ma `v[mid..]` faʻaaogaina `buf` o le tumau teuina, ma teu le faʻaiuga i le `v[..]`.
///
/// # Safety
///
/// O fasi e lua e tatau ona leai se avanoa ma `mid` e tatau ona i totonu o tuaoi.
/// Buffer `buf` tatau ona lava le umi e uu ai se kopi o le puʻupuʻu fasi.
/// Foi, le tatau ona `T` se ituaiga o le taumafaina.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // O le merge process e muamua kopi le puʻupuʻu o le `buf`.
    // Ona suʻea lea o le tamoe kopiina ma le umi tamoe agaʻi i luma (pe i tua), faʻatusatusa a latou isi elemeni le faʻaaogaina ma kopiina le laʻititi (pe sili atu) tasi i le `v`.
    //
    // O le taimi lava e uma ai le puʻupuʻu tamoʻe maeʻa maeʻa, ua maeʻa le gaioiga.A faʻapea e umi le taimi e faʻaumatia ai le umi, ona tatau loa lea ona tatou kopiina soʻo se mea e totoe o le puʻupuʻu e alu i le pu o loʻo totoe i le `v`.
    //
    // O le ogatotonu tulaga o le gaioiga e masani ona siaki e `hole`, lea e lua mafuaʻaga:
    // 1. Puipuia le faʻamaoni o le `v` mai le panics i le `is_less`.
    // 2. Faʻatumu le toega pu i le `v` pe a fai o le umi taufetuli faʻaumatia muamua.
    //
    // saogalemu Panic:
    //
    // Afai `is_less` panics i soʻo se taimi i le taimi o le gaioiga, o le `hole` o le a paʻu i lalo ma faʻatumu le pu i le `v` ma le le masani ai i le `buf`, ma faʻamautinoa ai o le `v` o loʻo taofia uma mea faitino na muaʻi uuina faʻatasi tasi.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // E puʻupuʻu le tauagavale.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Muamua lava, o nei faʻasino tusi faʻasino i le amataga o latou faʻasologa.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Faʻauma le itu laʻititi.
            // Afai e tutusa, sili le tauagavale tamoʻe e tausisi i le mautu.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // e puupuu le taufetuli saʻo.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Muamua lava, o nei faʻasino tusi pasi pasi o latou arrays.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Faʻauma le sili atu itu.
            // Afai e tutusa, sili le sao tamoe e tausisi tumau.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // I le iuga, `hole` pa'ū.
    // Afai o le puʻupuʻu tamoʻe e leʻi maeʻa faʻaumatia, soʻo se mea o totoe o le a kopi nei i le pu i le `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // A pa'ū, kopi le laina `start..end` i le `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` e le o se ituaiga zero-tele, o lea e lelei le vaevaeina i lona tele.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// O lenei tuʻufaʻatasiga ituaiga nonoina nisi (ae le o uma) aitia mai TimSort, lea o loʻo faʻamatalaina auiliili [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// O le matua faailoa algorithm ifo ma lē ua afio ifo subsequences, lea ua valaauina tamoʻe faalenatura.O loʻo i ai le faʻaupuga o faʻatali taufetuli ae e tatau ona tuʻufaʻatasia.
/// Taitasi faatoa maua taufetuli e tulei i luga o le faaputuga, ma ua tuufaatasia nisi taitoalua o tamoʻe tuaoi seia faamalieina nei invariants lua:
///
/// 1. mo `i` uma ile `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. mo `i` uma ile `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// O tagata na aʻafia e mautinoa o le aofaʻiga o taimi e tamoe ai o le *O*(*n*\*log(* n*)) sili ona leaga.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Fasi i lenei Mauaina umi faavasega le faaaogaina o ituaiga faaofiina.
    const MAX_INSERTION: usize = 20;
    // Ose tamoʻega tamoʻe e faʻalauteleina faʻaaoga vaʻavaʻai faʻasologa e lautele le itiiti ifo i lenei tele elemene.
    const MIN_RUN: usize = 10;

    // O le faʻavasegaina e leai se uiga taua i luga o zero-tele ituaiga.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // O faʻavasega puʻupuʻu e faʻavasega i totonu le nofoaga e ala i le faʻaofiina faʻasologa e aloese mai le faʻasoaga.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Faʻavasega se faʻamau e faʻaoga e pei o le valu manatua.Tatou tausia le umi 0 ina ia mafai ona tatou tausia i ai kopi papaʻu o le anotusi o `v` e aunoa ma le lamatia ai le dtors tamoe i kopi pe afai `is_less` panics.
    //
    // Pe a tuufaatasia o ni lua tamoʻe faavasega, umia lenei buffer se kopi o le taufetuli puupuu, lea o le a maua pea le umi i le tele `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Ina ia mafai ona iloa faʻasolosolo taufetuli i `v`, matou te sopoʻia i tua.
    // Atonu e foliga mai o se filifiliga ese, ae mafaufau i le mea moni o merges soʻo alu i le isi itu (forwards).
    // E tusa ai ma faʻailoga, o le tuʻufaʻatasia o luma e fai si vave nai lo le tuʻufaʻatasia i tua.
    // I le faʻaiuga, o le faʻailoaina o tamoʻega e ala i le sopoʻia o tua e faʻaleleia ai le faʻatinoga.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Saili le isi tamoʻega masani, ma feliuaʻi pe a fai e matua paʻu i lalo.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Faʻaofi nisi sili elemeni i le tamoʻe pe a fai e puʻupuʻu.
        // O le faʻaofiina faʻasologa e vave atu nai lo le tuʻufaʻatasia o ituaiga i luga o faʻasologa puʻupuʻu, o lea la e matuaʻi faʻaleleia ai le faʻatinoga.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Tulei lenei tamoʻe i luga o le faaputuga.
        runs.push(Run { start, len: end - start });
        end = start;

        // Tuʻufaʻatasia nisi paga o tafatafa faʻasolosolo e faʻamalieina le au faʻaletonu.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // I le iuga, tasi le tamoʻe tatau ona tumau i le faaputuga.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Iloiloina le faaputuga o tamoʻe ma faailoa le ulugalii e sosoo ai o tamoʻe e tuufaatasia.
    // E sili atu ona faʻapitoa, pe a toe faʻafoʻi mai le `Some(r)`, o lona uiga e tatau ona soʻo faʻatasi i le `runs[r]` ma le `runs[r + 1]`.
    // Afai o le algorithm e tatau ona faʻaauau le fausiaina o se fou tamoʻe, `None` ua toe faʻafoʻi mai.
    //
    // e iloga TimSort mo lona implementations taavale solofanua, e pei ona faamatalaina iinei:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // O le autu o le tala o le: tatou tatau ona faʻamalosia tagata faʻataʻitaʻi i luga o le fa pito i luga o le faaputuga.
    // Faamalosia i latou i le na o pito i luga e tolu o le lava ina ia mautinoa o le a umia pea invariants mo *uma* tamoʻe i le faaputuga.
    //
    // Lenei gaioiga saʻo siaki invariants mo le pito i luga fa tamoe.
    // I se faʻaopopoga, afai o le pito i luga tau amata i le faasino igoa 0, o le a manaʻomia i taimi uma se tuʻufaʻatasiga o galuega seʻia maeʻa maeʻa le faaputuga, ina ia mafai ona faʻamaeʻaina le ituaiga.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}