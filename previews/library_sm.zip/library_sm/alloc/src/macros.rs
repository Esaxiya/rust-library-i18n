/// Fausia se [`Vec`] aofia ai finauga.
///
/// `vec!` faʻatagaina 'Vec`s ia faʻamatalaina i le tutusa syntax o faʻasologa faʻaaliga.
/// E lua ituaiga o lenei macro:
///
/// - Fausia se [`Vec`] o loʻo iai se lisi taua o elemeni:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Fausia se [`Vec`] mai se elemeni tuʻuina atu ma le tele:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Manatua e le pei o faʻavasega faaupuga o lenei syntax lagolagoina uma elemeni o loʻo faʻatinoina [`Clone`] ma le numera o elemene e le tatau ona avea ma tumau.
///
/// Lenei o le a faʻaaogaina le `clone` e faʻalua ai se faʻaaliga, o lea e tatau ai i se tasi ona faʻaeteete i le faʻaaogaina o lenei ma ituaiga o loʻo i ai le le faʻataʻitaʻi `Clone` faʻatinoina.
/// Mo se faʻataʻitaʻiga, `vec![Rc::new(1);5] `o le a fausia ai le vector o le lima faʻasino i le tutusa pusa aofaʻi aofaʻi aofaʻi, ae le lima faʻasino tusi faʻasino i tutoʻatasi atigipusa fuainumera.
///
///
/// Faʻapea foi, maitau o `vec![expr; 0]` ua faʻatagaina, ma maua ai se gaogao vector.
/// a iloiloina pea lenei `expr` Peitai, ma le vave toulu o le taunuuga o le taua, ina ia silafia o aafiaga itu.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): ma cfg(test) o le natura `[T]::into_vec` auala, lea e manaʻomia mo lenei faʻauiga faʻamatalaga, e le o avanoa.
// Ae faʻaaoga le `slice::into_vec` function e naʻo le cfg(test) NB e vaʻai i le slice::hack module i le slice.rs mo nisi faʻamatalaga
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Fausia se `String` faʻaaogaina faʻafesoʻotaʻiga o faʻatonuga taimi.
///
/// O le finauga muamua `format!` mauaina o se faʻavasega laina.Lenei tatau ona avea ma se manoa faʻatulagaina.O le malosiʻaga o le faʻavasega manoa o loʻo i totonu o le `{}` s o loʻo iai.
///
/// Faʻaopoopoga faʻasologa pasia i `format!` suia le `{}` s i totonu o le faʻatulagaina manoa i le faʻatonuga na tuʻuina atu seʻi vagana ua faʻaigoaina pe faʻatulaga tulaga faʻapitoa e faʻaaogaina;vaʻai [`std::fmt`] mo nisi faʻamatalaga.
///
///
/// O le faʻaaoga masani mo `format!` o le faʻaaogaina ma le faʻavasegaina o manoa.
/// O le faʻatasiga lava e tasi o loʻo faʻaaogaina ma le [`print!`] ma le [`write!`] macros, faʻamoemoeina ile faʻamoemoe na taunuʻu iai le manoa.
///
/// Ina ia faʻaliliu se tau e tasi i se manoa, faʻaaoga le [`to_string`] auala.Lenei o le a faʻaaogaina le [`Display`] faʻatulagaina trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics pe a fai o le faʻatulagaina trait faʻatinoina toe faʻafoʻi mai se mea sese.
/// Lenei faʻaalia se le faʻatinoina faʻatinoina talu `fmt::Write for String` le toe faʻafoʻi mai se sese ia lava.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Faʻamalosi AST node i se faʻaupuga e faʻaleleia atili faʻailoilo i tulaga faʻatusa.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}