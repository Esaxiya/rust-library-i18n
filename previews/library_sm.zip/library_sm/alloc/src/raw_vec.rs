#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// O mea o loʻo iai i le faʻamanatuga fou e le faʻailoaina.
    Uninitialized,
    /// O le manatua fou e mautinoa e leai.
    Zeroed,
}

/// O se maualalo-aoga aoga mo sili ergonomically vaevaeina, toe faʻatulagaina, ma le faʻasoasoaina o se buffer o manatua i luga o le faaputuga e aunoa ma le popole i uma tulimanu mataupu aafia ai.
///
/// O lenei ituaiga e sili ona lelei mo le fausiaina o au oe faʻamaumauga faʻusaga e pei o Vec ma VecDeque.
/// Ae faapito tonu lava:
///
/// * Gaosia `Unique::dangling()` i luga o zero-tele ituaiga.
/// * Gaosia `Unique::dangling()` i luga o le leai-umi faʻasoaga.
/// * Aloese mai le faʻasaʻolotoina `Unique::dangling()`.
/// * Puʻe uma taumasuasua i tulaga gafatia fuafuaina (faʻalauiloa i latou i le "capacity overflow" panics).
/// * Leoleo faasaga i le 32-bit sisitema vaeluaina sili atu nai lo isize::MAX bytes.
/// * Leoleo faasaga i le soʻona soʻona o lou umi.
/// * Valaau `handle_alloc_error` mo fallible vaegatupe.
/// * Aofia ai le `ptr::Unique` ma faʻapea faʻaeeina le tagata faʻaaoga ma uma fesoʻotaʻiga aoga.
/// * Faʻaaogaina le sili atu toe faʻafoʻi mai le tagata faʻasoa e faʻaaoga le tele avanoa avanoa.
///
/// Lenei ituaiga e le o taimi uma asiasia le mafaufauaga na te puleaina.A paʻu i lalo *o le a faʻasaolotoina lona manatuaina, ae e* le * taumafai e faʻapaʻu mea o loʻo i totonu.
/// E pule lava le tagata i le `RawVec` e faʻatautaia mea moni * teuina i totonu o le `RawVec`.
///
/// Manatua o le sili atu o le zero-tele ituaiga e masani ona le uma, o lea `capacity()` e toe faafoi `usize::MAX` i taimi uma.
/// O lona uiga e tatau ona e faʻaeteete pe a faʻataʻamilomiloina le ituaiga lea ma le `Box<[T]>`, talu ai e le maua e le `capacity()` le umi.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): E i ai lenei aua `#[unstable]` `const fn`s le manaʻomia le ogatasi ma `min_const_fn` ma o lea e le mafai ai ona valaʻauina i latou i le`min_const_fn`s pe.
    ///
    /// Afai e te suia `RawVec<T>::new` poʻo faʻalagolago, faʻamolemole ia faʻaeteete ia aua neʻi faʻailoaina se mea e ono solia moni le `min_const_fn`.
    ///
    /// NOTE: E mafai ona matou aloese mai lenei hack ma siaki le faʻatulagaina ma nisi `#[rustc_force_min_const_fn]` uiga lea e manaʻomia le mulimulitaʻi ma `min_const_fn` ae le faʻatagaina valaʻauina i `stable(...) const fn`/tagata faʻaoga code le mafai ai `foo` pe a `#[rustc_const_unstable(feature = "foo", issue = "01234")]` o loʻo iai.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Fausia le sili tele mafai `RawVec` (luga o le faʻaupuga sisitema) aunoa ma le faʻasoaga.
    /// Afai o `T` e tele lona lelei, ona faia lea o le `RawVec` ma le agavaʻa `0`.
    /// Afai ole `T` e leai se tele, ona fai ai lea o le `RawVec` ma le agavaʻa `usize::MAX`.
    /// E aoga mo le faʻatinoina o le tuai faʻatupeina.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Fausia se `RawVec` (luga o le faʻaupuga sisitema) ma le saʻo lava le agavaʻa ma faʻafetaui manaʻoga mo le `[T; capacity]`.
    /// E tutusa lea ma le valaʻauina o le `RawVec::new` peʻa o le `capacity` o le `0` pe o le `T` e leai se aofaʻi.
    /// Manatua afai o le `T` e leai se tele o lona uiga o le a e le *mauaina* se `RawVec` ma le manaʻomia gafatia.
    ///
    /// # Panics
    ///
    /// Panics pe a fai o le talosaga talosagaina sili atu `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Aborts i OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Pei ole `with_capacity`, ae e mautinoa le buffer ua leai se.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Toe faʻaleleia le `RawVec` mai le faʻasino tusi ma le agavaʻa.
    ///
    /// # Safety
    ///
    /// O le `ptr` e tatau ona vaeluaina (luga o le faʻaupuga sisitema), ma le `capacity` foaʻi.
    /// O le `capacity` e le mafai ona sili atu i le `isize::MAX` mo ituaiga tetele.(naʻo se atugaluga luga o 32-siʻi sisitema).
    /// ZST vectors ono i ai le agavaʻa e oʻo i le `usize::MAX`.
    /// Afai ole `ptr` ma `capacity` e sau mai le `RawVec`, ona mautinoa lea.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // O Vecs laititi e gūgū.Faapasi i le:
    // - 8 pe a fai o le elemeni tele o le 1, aua soʻo se faʻaputuga tuʻufaʻatasiga e ono faʻataʻamilomiloina se talosaga e itiiti ifo ma le 8 bytes i le sili atu 8 bytes.
    //
    // - 4 pe a fai o elemeni e feololo-tele (<=1 KiB).
    // - 1 ese, ia aloese mai le faʻamaʻimauina tele avanoa mo Vecs puʻupuʻu.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Pei o `new`, ae faʻamalamalamaina luga o le filifiliga o le tuʻuina atu mo le `RawVec` faʻafoʻi.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` lona uiga "unallocated".le amanaiaina ituaiga o le taumafaina.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Pei o `with_capacity`, ae faʻamalamalamaina luga o le filifiliga o le tuʻuina atu mo le `RawVec` faʻafoʻi.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Pei o `with_capacity_zeroed`, ae faʻamalamalamaina luga o le filifiliga o le tuʻuina atu mo le `RawVec` faʻafoʻi.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Faʻaliliua se `Box<[T]>` i totonu o le `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Liliu le buffer atoa i `Box<[MaybeUninit<T>]>` ma le `len` faamaotiina.
    ///
    /// Manatua o lenei o le a toe sui faʻapitoa `cap` suiga atonu na faia.(Vaʻai faʻamatalaga o ituaiga mo auiliiliga.)
    ///
    /// # Safety
    ///
    /// * `len` tatau ona sili atu nai lo pe tutusa ma le lata mai talosagaina tulaga, ma
    /// * `len` tatau ona laʻititi ifo pe tutusa i le `self.capacity()`.
    ///
    /// Manatua, o le manaʻomia gafatia ma `self.capacity()` ono eseʻese, pei o se tagata faʻasoasoa mafai ona soona tuʻuina atu ma faʻafoʻi se sili manatua poloka nai lo le talosagaina.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Sanity-siaki le tasi afa o le saogalemu manaʻoga (tatou le mafai siaki le isi afa).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Matou te 'aloʻalo i le `unwrap_or_else` ii aua e fula le aofaʻi o LLVM IR na fausia.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Toe faʻaleleia le `RawVec` mai se faʻasino tusi, agavaʻa, ma tufatufaina atu.
    ///
    /// # Safety
    ///
    /// O le `ptr` e tatau ona faʻasoaina (ala i le tuʻufaʻatasia `alloc`), ma le `capacity` tuʻuina atu.
    /// O le `capacity` e le mafai ona sili atu i le `isize::MAX` mo ituaiga tetele.
    /// (naʻo se atugaluga luga o 32-siʻi sisitema).
    /// ZST vectors ono i ai le agavaʻa e oʻo i le `usize::MAX`.
    /// Afai ole `ptr` ma `capacity` e sau mai le `RawVec` na faia e ala ile `alloc`, ona mautinoa lea.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Maua se faʻasino tonu i le amataga o le faʻasoaga.
    /// Manatua o le `Unique::dangling()` lenei pe a fai o `capacity == 0` poʻo `T` e leai se fua.
    /// I le tulaga muamua, e tatau ona e faʻaeteete.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Mauaina le agavaʻa o le faʻasoaga.
    ///
    /// Lenei o le a avea ma `usize::MAX` pe a fai o `T` e leai se tele.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Faʻafoʻi mai se faʻasoa faʻasino i le tagata tuʻuina atu lagolagoina lenei `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // E i ai la matou vaega tuʻufaʻatasia o mea e manatuaina, o lea e mafai ai ona tatou aloese mai siaki taimi e maua ai la matou faʻatulagaina nei.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Faʻamautinoa o le faʻamau e aofia ai le sili atu lava avanoa e taofia `len + additional` elemene.
    /// Afai e le lava le agavaʻa, o le a toe tuʻuina atu avanoa faʻatasi ai ma le lagolelei avanoa e faʻamasani ai *O*(1) amio.
    ///
    /// O le a faʻatapulaʻaina lenei amio peʻa fai o le a mafua ai ona ia panic.
    ///
    /// A faʻapea e sili le `len` ile `self.capacity()`, e ono le mafai e le mea moni ona faʻasoasoa le avanoa na talosagaina.
    /// E le sefe le mea lea, ae ole saogalemu le code *oe* tusia e faʻamoemoe i amioga a lenei galuega e ono malepe.
    ///
    /// O lenei e sili ona lelei mo le faʻatinoina o se tele-tulei faʻagaioiga pei o `extend`.
    ///
    /// # Panics
    ///
    /// Panics pe afai o le tulaga fou e sili bytes `isize::MAX`.
    ///
    /// # Aborts
    ///
    /// Aborts i OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // faasao semanu e toʻesea pe atuatuvale pe a fai o le len sili atu i le `isize::MAX` o lea la e saogalemu e fai unchecked nei.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// E tutusa ma le `reserve`, ae toe foʻi i luga o mea sese nai lo le popolevale pe faʻapau.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Faʻamautinoa o le faʻamau e aofia ai le sili atu lava avanoa e taofia `len + additional` elemene.
    /// Afai e leʻo i ai, o le a toe tuʻuina atu le mea maualalo mafai o le manatua tatau.
    /// E masani lava o le aofaʻi tonu lea o mea e manaʻomia, ae o le mea moni, e saoloto le tagata na te tuʻuina atu mea e sili atu nai lo le mea na tatou ole atu ai.
    ///
    ///
    /// A faʻapea e sili le `len` ile `self.capacity()`, e ono le mafai e le mea moni ona faʻasoasoa le avanoa na talosagaina.
    /// E le sefe le mea lea, ae ole saogalemu le code *oe* tusia e faʻamoemoe i amioga a lenei galuega e ono malepe.
    ///
    /// # Panics
    ///
    /// Panics pe afai o le tulaga fou e sili bytes `isize::MAX`.
    ///
    /// # Aborts
    ///
    /// Aborts i OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// E tutusa ma le `reserve_exact`, ae toe foʻi i luga o mea sese nai lo le popolevale pe faʻapau.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Faʻapaʻu le faʻasoaga i lalo i le aofaʻi faʻapitoa.
    /// Afai o le aofaʻi tuuina atu o 0, moni maeʻa deallocates.
    ///
    /// # Panics
    ///
    /// Panics pe a fai o le aofaʻi ua tuʻuina atu e *lapoʻa* nai lo le tulaga o loʻo iai nei.
    ///
    /// # Aborts
    ///
    /// Aborts i OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Faʻafoʻi pe a fai o le buffer manaʻomia e tupu e faʻamalieina le manaʻoga faʻaopoopo manaʻomia.
    /// Masani faʻaaogaina e faia inlining faaleoleo-telefoni mafai aunoa ma le inlining `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // O lenei metotia e masani ona faʻamaonia i le tele o taimi.Lea tatou te mananao ai e avea e pei laiti e mafai ai, e faaleleia ai taimi e tuufaatasia.
    // Ae matou te mananaʻo foi o le tele o mea o loʻo iai i totonu ia mafai ona faʻatusatusaina i taimi uma e mafai ai, ina ia faʻavavevave ai le faʻatupuina o le tulafono.
    // O le mea lea, o lenei metotia e tusia ma le faʻaeteete ina ia o uma tulafono laiti e faʻalagolago i le `T` o loʻo i totonu, ae o le tele o le code e le faʻalagolago i le `T` pe a mafai o loʻo i ai i galuega e le o taʻatele i le `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // E mautinoa lea ile faʻauiga o valaauga.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Talu ona tatou toe faʻafoʻi mai le mafai o `usize::MAX` pe a `elem_size` o
            // 0, o le oʻo mai ii o lona uiga o le `RawVec` ua ova tele.
            return Err(CapacityOverflow);
        }

        // Leai se mea e mafai ona tatou faia e uiga i nei siaki, faʻanoanoa.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Lenei mautinoa ai le tupuolaola faʻatele.
        // O le faʻaluaina e le mafai ona ova ona o `cap <= isize::MAX` ma le ituaiga o `cap` o `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` e le lautele ile `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // O le constraints i lenei auala e tele e tutusa ma i latou i luga o `grow_amortized`, ae o lenei auala e masani lava ona instantiated itiiti masani o ina itiiti faitio.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Talu ai ua tatou toe foi se tulaga o `usize::MAX` pe a le tele ituaiga o
            // 0, o le oʻo mai ii o lona uiga o le `RawVec` ua ova tele.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` e le lautele ile `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// O lenei gaioiga e i fafo atu o le `RawVec` e faʻaititia ai le tuʻufaʻatasia o taimi.Vaʻai le faʻamatalaga luga `RawVec::grow_amortized` mo auiliiliga.
// (O le `A` parameter e le taua, aua o le numera o eseʻese `A` ituaiga vaʻaia i le faʻataʻitaʻiga e sili laititi atu nai lo le numera o `T` ituaiga.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Siaki mo le mea sese iinei e faʻaititia ai le tele o `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // O le tagata tuʻuina atu siaki mo tutusa tutusa
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Faʻasaoloto le manatuaina e le `RawVec`*aunoa* taumafai e faʻapaʻu mea i totonu.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Faʻatinoga tutotonu mo le faʻasaoina o mea sese faaleoleo.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Matou te manaʻomia le mautinoa mea nei:
// * Matou te le faʻavasegaina `> isize::MAX` byte-size mea.
// * Matou te le soʻosoʻo `usize::MAX` ma faʻasoa moni laʻititi.
//
// I luga o le 64-bit, e tatau ona tatou siaki mo le lolovaia talu ai le taumafai e faʻatatau `> isize::MAX` bytes o le a mautinoa le le manuia.
// I luga o le 32-bit ma le 16-bit tatou te manaʻomia e faʻaopopo se faʻaopoopo puipuia mo lenei mea pe a fai o tatou o tamoʻe luga o se tulaga e mafai ona faʻaaogaina uma 4GB i tagata faʻaoga-avanoa, faʻapea, PAE poʻo x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Tasi le galuega tutotonu e nafa ma le lipotia o le mafai gafatia.
// Lenei o le a mautinoa ai o le tulafono augatupulaga fesoʻotaʻi ma nei panics e laiti ona e naʻo le tasi le nofoaga e panics nai lo se faʻaputuga atoa i le module.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}