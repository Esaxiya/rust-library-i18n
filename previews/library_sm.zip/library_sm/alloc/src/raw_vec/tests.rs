use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // O le tusiaina o se suʻega o le tuʻufaʻatasia i le va o le vaega tolu tuʻufaʻatasiga ma le `RawVec` e fai lava sina faigata ona e leʻo faʻaalia e le `RawVec` API metotia faʻasoasoa, o lea e le mafai ai ona tatou siakiina le mea e tupu pe a uma le faʻasoa (i tua atu o le sailia o le panic)
    //
    //
    // Ae ui i lea, naʻo le siakiina o `RawVec` metotia e fai ma sili atu ona ui atu i le Allocator API pe a na ona sefeina le teuina.
    //
    //
    //
    //
    //

    // O se tagata e tuʻuina atu le gūgū e na te faʻaaogaina se aofaʻiga o suauʻu ae e leʻi amataina se taumafaiga.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (mafua ai le toe tuʻuina atu, faʻapea ona faʻaaogaina 50 + 150=200 iunite o suauʻu)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Muamua, `reserve` tuʻuina pei o `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // O le 97 e sili atu i le faʻalua o le 7, o lea e tatau ai ona galue le `reserve` pei o le `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 e itiiti ifo ma le afa o le 12, o lea e tatau ai ona tupu vavaʻa le `reserve`.
        // I le taimi o le tusitusi o lenei suʻega tupu mea e 2, o lea la fou fou e 24, ae ui i lea, tupu vaega o 1.5 e lelei foi.
        //
        // Lea `>= 18` i taʻua maia.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}