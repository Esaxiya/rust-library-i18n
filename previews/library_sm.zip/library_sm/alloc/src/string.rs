//! O le UTF-8 - ua uma ona faʻavasega, ma mafai ona ola.
//!
//! Lenei module aofia ai le [`String`] ituaiga, le [`ToString`] trait mo le liua i manoa, ma le tele o mea sese ituaiga e ono mafua mai i le galulue ma [`String`] s.
//!
//!
//! # Examples
//!
//! E tele auala e fausia ai se [`String`] fou mai se manoa faʻamau:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! E mafai ona e fausiaina se [`String`] fou mai se mea o loʻo i ai i le faʻatasia ma
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Afai e i ai sau vector o aoga UTF-8 bytes, oe mafai ona faia se [`String`] mai ai.E mafai foʻi ona e faʻafetaui.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Matou te iloa o nei bytes e aoga, o lea matou te faʻaaogaina ai le `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// O le UTF-8 - ua uma ona faʻavasega, ma mafai ona ola.
///
/// O le `String` ituaiga o le masani aʻa ituaiga o loʻo i ai le umiaina luga o mea o le manoa.E i ai se vavalalata vavalalata ma lana paaga nono, le muamua [`str`].
///
/// # Examples
///
/// Oe mafai ona faia se `String` mai [a literal string][`str`] ma [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// E mafai ona e faʻaopopoina le [`char`] i le `String` ma le [`push`] metotia, ma faʻaopopo le [`&str`] ma le [`push_str`] auala.
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Afai e i ai sau vector o UTF-8 bytes, e mafai ona e fausiaina se `String` mai ia ma le [`from_utf8`] metotia:
///
/// ```
/// // nisi bytes, i totonu o le vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Matou te iloa o nei bytes e aoga, o lea matou te faʻaaogaina ai le `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `String`s e masani ona aoga UTF-8.E i ai ni nai aʻafiaga, o le muamua o lena afai e te manaʻomia se non-UTF-8 manoa, mafaufau i le [`OsString`].E tali tutusa, ae a aunoa ma le UTF-8 taofiofi.O le lona lua faʻamatalaga o le e le mafai ona faʻasino igoa i totonu o le `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// O le faʻasinoina o igoa ua fuafuaina e avea o se galuega fai taimi faifai pea, ae e le faʻatagaina i matou e le UTF-8 faʻatonuga ona faia lenei mea.E le gata i lea, e leʻo mautinoa poʻo le a le ituaiga mea e tatau ona toe foʻi mai le index: o le byte, o le codepoint, poʻo le grapheme cluster.
/// O [`bytes`] ma [`chars`] metotia faʻafoʻi iterators luga o le muamua lua, faʻatulagaina.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// 'String`s faʻatinoina [`Deref`]`<Target=str>`, ma ia mautofi ai i metotia uma a le ['str`].I le faaopoopo atu, o lenei auala e mafai ona e oo a `String` i se galuega tauave lea e a [`&str`] ala i le faaaogaina o se ampersand (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Lenei o le a fausia ai se [`&str`] mai le `String` ma pasi atu i totonu. O lenei liua e matua taugata, ma o le mea masani, o galuega o le a taliaina [`&str`] s e avea ma finauga seʻi vagana latou te manaʻomia se `String` mo ni mafuaʻaga faapitoa.
///
/// I nisi tulaga Rust le lava faʻamatalaga e faia ai lenei liua, taʻua o le [`Deref`] faamalosia.I le faʻataʻitaʻiga lenei o le manoa fasi [`&'a str`][`&str`] faʻaaogaina le trait `TraitExample`, ma le gaioiga `example_func` aveina soʻo se mea e faʻaaogaina le trait.
/// I lenei tulaga e manaʻomia e le Rust ona faia ni suiga se lua, o le Rust e leai ni auala e faia ai.
/// Mo lena mafuaaga, o le a tuufaatasia le faataitaiga lenei.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// E lua filifiliga o le a aoga nai lo.O le muamua o le a suia le laina `example_func(&example_string);` i le `example_func(example_string.as_str());`, faʻaaogaina le metotia [`as_str()`] e faʻamatala manino mai ai le manoa fasi o loʻo i ai le manoa.
/// O le auala lona lua e suia `example_func(&example_string);` e `example_func(&*example_string);`.
/// I lenei tulaga o loʻo tatou faʻaleaʻoaʻoina se `String` i le [`str`][`&str`], ona toe faʻasino lea o le [`str`][`&str`] i le [`&str`].
/// O le auala lona lua e sili atu idiomatic Peitai uma galuega e faia le liua manino nai lo le faalagolago i luga o le liua atoatoa.
///
/// # Representation
///
/// O le `String` e aofia ai vaega e tolu: o le faʻasino tusi i ni paita, o se umi, ma se gafatia.O le faʻasino tusi i le buffer totonu `String` faʻaaoga e teu ai ana faʻamaumauga.O le umi o le aofai o bytes teuina i le taimi nei i le buffer, ma le tulaga o le tele o le buffer i bytes.
///
/// E pei o lea, o le umi o le a masani ona laʻititi nai lo pe tutusa ma le gafatia.
///
/// O lenei buffer e teu i taimi uma i luga o le faaputuga.
///
/// Oe mafai ona vaʻai i nei ma le [`as_ptr`], [`len`], ma le [`capacity`] metotia:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME FAAFOUGA O lenei ina ua vec_into_raw_parts ua e gafatia.
/// // Puipuia otometi lava le faʻapaʻuina o le String's data
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // tala e sefuluiva sefuluiva paita
/// assert_eq!(19, len);
///
/// // E mafai ona tatou toe fausiaina se String mai le ptr, len, ma le agavaʻa.
/// // E le sefe uma nei mea aua o tatou e nafa ma le faʻamautinoaina o vaega e aoga:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Afai o le `String` e lava lona agavaʻa, faʻaopopo elemene ia te ia e le toe faʻatuina.Mo se faʻataʻitaʻiga, mafaufau i le polokalame lea:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Lenei o le a gaosia i lalo:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// I le taimi muamua, e leai se mea tatou te manatuaina, ae a o tatou faʻaopoopoina i le manoa, e faʻatuputeleina lona agavaʻa talafeagai.Afai matou te faʻaaogaina le [`with_capacity`] auala e faʻasoa ai le sao saʻo muamua:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Tatou te iu i se galuega faatino eseese:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Lenei, e leai se mea e manaʻomia ai le faʻasoaga sili atu manatua i totonu o le matasele.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Ole aoga ole mea sese pe a faʻaliliuina le `String` mai le UTF-8 byte vector.
///
/// Lenei ituaiga o le sese ituaiga mo [`from_utf8`] metotia luga [`String`].
/// Na fuafuaina i se auala e aloese ai ma le faʻaeteete i nofoaga moni: o le [`into_bytes`] metotia o le a toe faʻafoʻi mai ai le byte vector na faʻaaogaina i le taumafaiga o le liliuina.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// O le [`Utf8Error`] ituaiga na saunia e [`std::str`] e faʻatusalia se mea sese e ono tupu pe a faʻaliliuina se fasi o le [`u8`] s i le [`&str`].
/// I lea tulaga, e le o se analogue e `FromUtf8Error`, ma e mafai ona e maua se tasi mai se `FromUtf8Error` e ala i le auala [`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Faʻaaoga faʻavae:
///
/// ```
/// // ni paita le aoga, ile vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Ole aoga ole mea sese pe a faʻaliliuina le `String` mai le UTF-16 byte slice.
///
/// Lenei ituaiga o le sese ituaiga mo [`from_utf16`] metotia luga [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Faʻaaoga faʻavae:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Fausia se fou gaogao `String`.
    ///
    /// Tuuina atu o le `String` e leai se mea, o lenei o le a le tuʻuina atu i seisi muamua buffer.E ui o lona uiga o lenei amataga faʻagaioiga e matua taugata lava, e ono mafua ai le sili atu tufatufaina mulimuli ane pe a e faʻaopopo faʻamatalaga.
    ///
    /// Afai e i ai sau aitia pe fia le tele o faʻamatalaga o le a uuina e le `String`, mafaufau i le [`with_capacity`] auala e puipuia ai le soona toe vaevaeina.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Fausia se fou gaogao `String` ma se faapitoa gafatia.
    ///
    /// `String`s i ai se totonu faʻamau e taofia a latou faʻamatalaga.
    /// O le mafai gafatia o le umi o lena buffer, ma mafai ona faʻafesiliina ma le [`capacity`] metotia.
    /// O lenei auala e faatupuina ai se gaogao `String`, ae o le tasi i se buffer uluai e mafai ona umia bytes `capacity`.
    /// E aoga lenei mea pe a oe ono faʻapipiʻiina se tele o faʻamaumauga i le `String`, faʻaititia le numera o reallocations e manaʻomia e fai.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Afai o le malosiaga tuʻuina atu o le `0`, e leai se faʻasoaga e tupu, ma o lenei metotia e tutusa ma le [`new`] auala.
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // O le String e leai ni chars, e ui lava e i ai le gafatia mo sili atu
    /// assert_eq!(s.len(), 0);
    ///
    /// // O nei mea uma e faia e aunoa ma le toe faʻatulagaina ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... ae o lenei e ono faʻaaogaina ai le manoa
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): ma cfg(test) o le natura `[T]::to_vec` metotia, lea e manaʻomia mo lenei metotia faʻamatalaga, e le avanoa.
    // Talu ai tatou te le manaomia lenei metotia mo tofotofoina faamoemoega, ou na stub ai NB vaai i le module slice::hack i slice.rs mo nisi faamatalaga
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Liliu a vector o bytes i se `String`.
    ///
    /// O le manoa ([`String`]) e faia i bytes ([`u8`]), ma le vector o bytes ([`Vec<u8>`]) e faia i bytes, o lea la, o lenei gaioiga e liua i le va o le lua.
    /// E leʻo uma byte fasi e aoga 'String`s, peitaʻi: `String` manaʻomia e moni UTF-8.
    /// `from_utf8()` siaki ia mautinoa o aoga bytes e UTF-8, ona fai ai lea o le liua.
    ///
    /// Afai e te mautinoa o le fasi byte o loʻo aoga UTF-8, ma e te le manaʻo e faʻatupuina i luga o le siaki aoga, o loʻo i ai se le saogalemu faʻamaumauga o lenei gaioiga, [`from_utf8_unchecked`], e i ai le tutusa amioga ae faʻaseʻeina le siaki.
    ///
    ///
    /// O lenei metotia o le a faʻaeteete e aua le kopiina le vector, mo le lelei o le aoga.
    ///
    /// Afai e te manaʻomia se [`&str`] nai lo le `String`, mafaufau i le [`str::from_utf8`].
    ///
    /// O le fesuiaʻiga o lenei metotia o le [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Faʻafoʻi [`Err`] pe a fai o le fasi e le o UTF-8 ma se faʻamatalaga pe aisea e le o UTF-8 le bytes saunia.O le vector na e see ai i totonu o loʻo aofia ai foʻi.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// // nisi bytes, i totonu o le vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Matou te iloa o nei bytes e aoga, o lea matou te faʻaaogaina ai le `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Sese paita:
    ///
    /// ```
    /// // ni paita le aoga, ile vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Vaʻai tusitusiga mo [`FromUtf8Error`] mo nisi faʻamatalaga i mea e mafai ona e faia ile mea sese lea.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Faʻaliliuina se fasi bytes i se manoa, e aofia ai faʻailoga le aoga.
    ///
    /// O manoa e faia i bytes ([`u8`]), ma o se fasi bytes ([`&[u8]`][byteslice]) e faia i bytes, o lea la, o lenei gaioiga e liua i le va o le lua.E le fasi byte uma o manoa aloaia, peitai: e manaomia manoa ina ia aoga UTF-8.
    /// I le taimi o lenei liuaina, `from_utf8_lossy()` o le a suia soʻo se UTF-8 faasologa faʻasologa ma [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], e pei o lenei:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Afai e te mautinoa o le byte slice e aoga UTF-8, ma e te le manaʻo e faʻatupuina le faʻasolosolo o le liuaina, o loʻo i ai se le saogalemu faʻamaumauga o lenei gaioiga, [`from_utf8_unchecked`], o loʻo i ai le tutusa amioga ae faʻaseʻeina siaki.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// O lenei gaioiga toe faafoi mai le [`Cow<'a, str>`].Afai tatou byte fasi ua le aloaia UTF-8, e tatau ona tatou faaofiina lea o le tagata o le suia, o le a suia ai le tele o le manoa, ma o lea, e manaomia se `String`.
    /// Ae afai e uma ona aloaia UTF-8, tatou te le manaomia se faasoasoa fou.
    /// O lenei ituaiga faʻafoʻi mafai ai ona matou faʻatautaia ia mataupu uma e lua.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// // nisi bytes, i totonu o le vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Sese paita:
    ///
    /// ```
    /// // ni paita le aoga
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Faʻaleaogaina le UTF-16 - faʻanumera vector `v` i totonu o le `String`, faʻafoʻi [`Err`] peʻa o `v` o loʻo i ai ni faʻamaumauga le saʻo.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // E le faia lenei mea e ala i le aoina: : <Result<_, _>> () mo mafuaʻaga e fai ai.
        // FIXME: e mafai ona faʻafaigofieina le gaioiga pe a tapunia #48994.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Faʻaleaogaina le UTF-16 - faʻanumeraina fasi `v` i totonu o le `String`, suia le saʻo faʻamaumauga i le [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// E le pei o [`from_utf8_lossy`] lea toe foi a [`Cow<'a, str>`], Ua toe foi `from_utf16_lossy` a `String` talu mai le UTF-16 e UTF-8 liua e manaomia ai a faasoasoa manatua.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Faʻamamaina le `String` i ona vaega masani.
    ///
    /// Faʻafoʻi le faʻasino manino i faʻavae o faʻamatalaga, le umi o le manoa (i bytes), ma le tuʻufaʻatasia gafatia o faʻamatalaga (i bytes).
    /// O finauga lava ia e tasi ile tutusa tutusa ma finauga ile [`from_raw_parts`].
    ///
    /// Ina ua mavae le valaauina o lenei galuega tauave, e nafa ma le Tagata telefoni mo le manatu muamua e pulea e le `String`.
    /// Pau lava le auala e faia ai lenei mea o le suia lea o le raw point, umi, ma gafatia toe foi i totonu o le `String` ma le [`from_raw_parts`] gaioiga, faʻatagaina le faʻaleagaina ona faia le faʻamamaina.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Fausia se `String` fou mai le umi, agavaʻa, ma le faʻasino tusi.
    ///
    /// # Safety
    ///
    /// E matua le sefe lenei mea, ona o le aofaʻi o tagata na te leʻi siakiina:
    ///
    /// * O le manatua i le `buf` e manaʻomia na faʻapea ona tuʻuina atu e le tutusa tuʻufaʻatasiga o loʻo faʻaaogaina e le faletusi masani, ma le manaʻoga gatasi o le tonu 1.
    /// * `length` manaʻomia ia laʻititi ifo pe tutusa i le `capacity`.
    /// * `capacity` e manaʻomia le saʻo o le tau.
    /// * Ole muamua `length` bytes ile `buf` e manaʻomia le aoga UTF-8.
    ///
    /// O le solia o nei mea e ono tulaʻi mai ai ni faʻafitauli e pei o le faʻaleagaina o vaega o faʻamatalaga i totonu.
    ///
    /// O le anaina o `buf` e faʻamasani lava ona faʻamatuʻu atu i le `String` lea e ono faʻamatuʻu atu, toe tuʻuina atu pe suia mea o loʻo i totonu e manatua e le faʻasino i le manaʻoga.
    /// Ia mautinoa e leai seisi mea e faʻaogaina le faʻasino tusi pe a maeʻa ona valaʻau lenei galuega.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME FAAFOUGA O lenei ina ua vec_into_raw_parts ua e gafatia.
    ///     // Puipuia otometi lava le faʻapaʻuina o le String's data
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Faʻaliliuga o le vector o bytes i le `String` e aunoa ma le siakiina o le manoa o loʻo iai UTF-8 talafeagai.
    ///
    /// Vaʻai le saogalemu kopi, [`from_utf8`], mo nisi faʻamatalaga.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// O lenei gaioiga e le saogalemu ona e le siakiina pe o le pasi na pasi ia te ia e moni UTF-8.
    /// A faʻapea ua solia lenei faʻafitauli, e ono mafua ai le le saogalemu o le manatuaina o mea ma future tagata faʻaaoga le `String`, ona o le isi vaega o le potutusi tulaga masani manatu o 'String`s e aoga UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// // nisi bytes, i totonu o le vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Faʻaliliu se `String` i le byte vector.
    ///
    /// Lenei faʻaumatia le `String`, o lea tatou te le manaʻomia kopi ai ona anotusi.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Otootoga se fasi manoa o loo i ai le atoa `String`.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Faʻaliliuina le `String` i totonu o se fasi manoa suia.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Faʻaopopo se fasi fasi fasi fasi i luga o le pito o lenei `String`.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Faʻafoʻi mai le malosiaga o lenei `String`, i bytes.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Faʻamautinoa o lenei 'String` gafatia e sili atu `additional` bytes lapoʻa nai lo lona umi.
    ///
    /// O le gafatia ono faʻateleina e sili atu i le `additional` bytes pe a filifili, e puipuia ai le toe fetuʻuina o taimi.
    ///
    ///
    /// Afai e te le manaʻo i lenei "at least" amioga, vaʻai i le [`reserve_exact`] auala.
    ///
    /// # Panics
    ///
    /// Panics pe a fai e oʻo i le [`usize`] le malosi fou.
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Atonu e le faʻatupuina moni lenei tulaga:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // Ua i ai nei le umi o le 2 ma le mafai o le 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Talu ai ua uma ona i ai a matou faʻaopopo 8 tulaga, valaʻau lenei ...
    /// s.reserve(8);
    ///
    /// // ... e le tupu tele.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Faʻamautinoaina o lenei 'String` gafatia o `additional` bytes lapoʻa nai lo lona umi.
    ///
    /// Mafaufau e faʻaaoga le [`reserve`] metotia seʻi vagana ua e matua iloa sili atu nai lo le tagata faʻasoasoa.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics pe a fai e oʻo i le `usize` le malosi fou.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Atonu e le faʻatupuina moni lenei tulaga:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // Ua i ai nei le umi o le 2 ma le mafai o le 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Talu ai ua uma ona i ai a matou faʻaopopo 8 tulaga, valaʻau lenei ...
    /// s.reserve_exact(8);
    ///
    /// // ... e le tupu tele.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Taumafai e faʻasao gafatia mo le sili atu `additional` sili elemeni e tuʻuina i le `String` tuʻuina atu.
    /// O le aoina ono faʻaavanoa tele avanoa e aloese ai mai faʻataʻitaʻiga masani.
    /// A maeʻa ona valaʻau `reserve`, o le a sili atu le malosi nai lo pe tutusa i le `self.len() + additional`.
    /// E leai se mea pe a fai ua lava le agavaʻa.
    ///
    /// # Errors
    ///
    /// Afai taumasuasua le malosi, po o le allocator lipoti a toilalo, lea ua toe o se mea sese.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Muamua-faʻasao le manatuaina, exiting pe a fai tatou te le mafaia
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Lenei ua matou iloa e le mafai OOM i le ogatotonu o la matou galuega faigata
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Taumafai e faʻasao le laʻititi gafatia mo tonu `additional` sili elemeni e faʻaofi i le `String` tuʻuina atu.
    ///
    /// A maeʻa ona valaʻau `reserve_exact`, o le a sili atu le malosi nai lo pe tutusa i le `self.len() + additional`.
    /// E leai se mea pe a fai o le malosi ua lava.
    ///
    /// Manatua o le tagata faʻasoa e ono tuʻuina atu i le aoina sili avanoa nai lo le mea e talosagaina.
    /// O le mea lea, gafatia le mafai ona faʻamoemoeina i luga ia avea matua mautinoa itiiti.
    /// Sili `reserve` pe a fai o future e ono faʻaofiina.
    ///
    /// # Errors
    ///
    /// Afai taumasuasua le malosi, po o le allocator lipoti a toilalo, lea ua toe o se mea sese.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Muamua-faʻasao le manatuaina, exiting pe a fai tatou te le mafaia
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Lenei ua matou iloa e le mafai OOM i le ogatotonu o la matou galuega faigata
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Faʻapipiʻi le gafatia o lenei `String` e faʻafetaui lona umi.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Faʻapipiʻi le gafatia o lenei `String` ma se pito i lalo maualalo.
    ///
    /// O le gafatia o le a tumau i le sili atu tele pei o uma le umi ma le sapalai taua.
    ///
    ///
    /// Afai o le malosiaga o loʻo i ai nei e laititi atu i lo le tapulaʻa maualalo, o le leai-op lea.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Appends le tuuina [`char`] i le iuga o lenei `String`.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Faʻafoʻi mai se fasi byte o mea o lenei 'String`.
    ///
    /// O le fesuiaʻiga o lenei metotia o le [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Faʻapuʻupuʻu lenei `String` i le umi faʻamaonia.
    ///
    /// Afai e sili atu le `new_len` nai lo le umi o le manoa i le taimi nei, e leai se aoga.
    ///
    ///
    /// Manatua o lenei metotia e leai se aoga i luga o le tuʻufaʻatasia gafatia o le manoa
    ///
    /// # Panics
    ///
    /// Panics pe a fai e le pepelo le `new_len` i luga o le tuaoi [`char`].
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Aveese le tagata mulimuli mai le manoa faʻamau ma toe faʻafoʻi mai.
    ///
    /// Faʻafoʻi [`None`] pe a fai e leai se mea o lenei `String`.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Aveʻese le [`char`] mai lenei `String` i le byte tulaga ma toe faʻafoʻi mai.
    ///
    /// Lenei o le *O*(*n*) gaioiga, aua e manaʻomia le kopiina o elemeni uma i le buffer.
    ///
    /// # Panics
    ///
    /// Panics pe a fai o `idx` e lapoʻa nai lo pe tutusa ma le 'String` umi, pe a fai e le taoto luga o le [`char`] tuaoi.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Aveese uma matata o le faʻataʻitaʻiga `pat` ile `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// O faʻataʻitaʻiga o le a maitauina ma aveʻese faʻasolosolo, o lea i tulaga pe a oʻo ni faʻataʻitaʻiga, na o le muamua mamanu o le a aveʻesea:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // SAFETY: amataga ma le iʻuga o le ai luga utf8 byte tuaoi i le
        // o le Searcher docs
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Faʻaauau naʻo mataʻitusi na faʻamaoti mai e le predicate.
    ///
    /// I se isi faaupuga, aveʻese uma mataʻitusi `c` faʻapea o le `f(c)` faʻafoʻi `false`.
    /// O lenei metotia faʻagaioia i le nofoaga, asiasi taʻitasi tagata foliga saʻo tasi i le uluaʻi faʻasologa, ma faʻasaoina le faʻasologa o tagata taofia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// O le faʻatonuga saʻo e ono aoga mo le siakiina o fafo atu o tulaga, pei o se faʻasino igoa.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // idx Point i le SIA sosoo
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Faʻaofi se tagata i totonu o lenei `String` i le byte tulaga.
    ///
    /// Lenei o le *O*(*n*) gaioiga aua e manaʻomia le kopiina o elemeni uma i le buffer.
    ///
    /// # Panics
    ///
    /// Panics pe a fai o `idx` e lapoʻa nai lo le umi o le 'String`, pe a le taʻoto luga o le [`char`] tuaoi.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Faʻaofi se manoa fasi i totonu o lenei `String` i le byte tulaga.
    ///
    /// Lenei o le *O*(*n*) gaioiga aua e manaʻomia le kopiina o elemeni uma i le buffer.
    ///
    /// # Panics
    ///
    /// Panics pe a fai o `idx` e lapoʻa nai lo le umi o le 'String`, pe a le taʻoto luga o le [`char`] tuaoi.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Faʻafoʻi mai se suiga suia i mea o lenei `String`.
    ///
    /// # Safety
    ///
    /// O lenei gaioiga e le saogalemu ona e le siakiina pe o le pasi na pasi ia te ia e moni UTF-8.
    /// A faʻapea ua solia lenei faʻafitauli, e ono mafua ai le le saogalemu o le manatuaina o mea ma future tagata faʻaaoga le `String`, ona o le isi vaega o le potutusi tulaga masani manatu o 'String`s e aoga UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Faʻafoʻi le umi o lenei `String`, i bytes, ae le o le ``char`] s poʻo graphemes.
    /// I nisi upu, atonu e le o le mea e manatu le tagata le umi o le manoa.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Faʻafoʻi `true` pe a fai o lenei `String` ei ai le umi o le zero, ma le `false` a leai.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Vaelua le manoa i le lua i le index byte index.
    ///
    /// Faʻafoʻi mai le `String` fou faʻatulagaina.
    /// `self` aofia ai bytes `[0, at)`, ma le `String` faʻafoʻi o loʻo iai bytes `[at, len)`.
    /// `at` tatau ona i luga o le tuaoi o le UTF-8 code point.
    ///
    /// Manatua o le mafai o `self` e le suia.
    ///
    /// # Panics
    ///
    /// Panics pe a fai o `at` e le oi luga o le `UTF-8` code point border, pe afai e sili atu nai lo le mulimuli code code o le manoa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Truncates lenei `String`, aveʻese uma mea.
    ///
    /// E ui o lona uiga o le `String` o le a i ai le umi o le zero, e le paʻi i lona gafatia.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Fausia se faʻamatuʻuina iterator e aveʻese le faʻapitoa laina i le `String` ma maua ai le aveʻesea `chars`.
    ///
    ///
    /// Note: O le elemene laina ua aveʻese tusa lava pe o le faʻasolosolo e le faʻaumatiaina seʻia oʻo i le iʻuga.
    ///
    /// # Panics
    ///
    /// Panics pe afai o le amata manatu po o se iuga tulaga te le pepelo i se tuaoi [`char`], po o pe afai latou te mai le tuaoi.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Aveese le avanoa seʻia oʻo mai le β mai le manoa
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // O le atoa atoaga kilia le manoa
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Manatu saogalemu
        //
        // O le String version o le Drain e leai ni mea taua mo le saogalemu o le vector.
        // O faʻamatalaga e naʻo le bytes manino.
        // Talu ai ona o le aofaʻi o le aveʻesea tupu i Drop, pe a fai o le Drain iterator ua faʻasalalau, o le a le tupu le aveʻesea.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Ave i fafo uma lua nonogatupe.
        // O le &mut String o le a le faʻaaogaina seʻia maeʻa faʻamavaega, i le Mataua.
        let self_ptr = self as *mut _;
        // SAFETY: `slice::range` ma `is_char_boundary` faia le talafeagai tapulaʻa siaki.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Aveʻese le laina faʻatulagaina i le manoa, ma sui i le manoa na tuʻuina atu.
    /// O le manoa na tuʻuina atu e le tau tutusa i le umi.
    ///
    /// # Panics
    ///
    /// Panics pe afai o le amata manatu po o se iuga tulaga te le pepelo i se tuaoi [`char`], po o pe afai latou te mai le tuaoi.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Sui le tulaga i luga seʻia o le β mai le manoa
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Manatu saogalemu
        //
        // O le Change_range e leai se mea e manatua ai le saogalemu o le vector Splice.
        // ole faʻamatalaga a le vector.O faʻamatalaga e naʻo le bytes manino.

        // Lapataʻiga: O le tipiina o lenei fesuiaʻiga o le a le taliaina (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // Lapataʻiga: O le tipiina o lenei fesuiaʻiga o le a le taliaina (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // O le faʻaaogaina o le `range` o le a le malupuipuia (#81138) Matou te manatu o tuaoi na lipotia mai e `range` e tumau pea, ae o le faʻatinoina o le faʻalavelave e mafai ona suia i le va o telefoni.
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Faʻaliliu lenei `String` i totonu o le [`Box`]`<`[`str`] `> '.
    ///
    /// Lenei o le a pa'ū soʻo se sili atu gafatia.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Faafoi a fasi o ['u8`] s bytes na taumafai e liliu i se `String`.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// // ni paita le aoga, ile vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Faʻafoʻi ia bytes na taumafai e faʻaliliu i le `String`.
    ///
    /// O lenei metotia e fausiaina ma le faʻaeteete e aloese ai mai le faʻasoaga.
    /// O le a faʻaumatia le mea sese, aveʻese ese bytes, ina ia le kopi o le bytes le manaʻomia e faia.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// // ni paita le aoga, ile vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Alu se `Utf8Error` e maua atili auiliiliga e uiga i le liua le aoga.
    ///
    /// O le [`Utf8Error`] ituaiga na saunia e [`std::str`] e faʻatusalia se mea sese e ono tupu pe a faʻaliliuina se fasi o le [`u8`] s i le [`&str`].
    /// I lenei lagona, o se faʻatusa i `FromUtf8Error`.
    /// Vaʻai lana faʻamaumauga mo nisi auiliiliga i le faʻaaogaina.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// // ni paita le aoga, ile vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // o le byte muamua e le aoga iinei
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Talu ai o loʻo matou faʻasolosolo i luga o le 'String`s, e mafai ona tatou aloese mai le sili atu ma le tasi le faʻasoaga e ala i le mauaina o le muamua string mai le iterator ma faʻaopopo i ai uma mulimuli ane manoa.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Talu ai tatou te iterating i luga o povi, e mafai ona tatou (potentially) faatoilaloina le itiiti ifo i le tasi faasoasoa e le mauaina o le mea muamua ma appending i ai uma i le mea e mulimuli mai.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// O se faʻafaigofie impl e tuʻuina atu le sui mo le `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Fausia se avanoa `String`.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Faʻaaogaina le `+` tagata faʻagaioia mo le tuʻufaʻatasia o manoa e lua.
///
/// O lenei alu uma le `String` i le itu tauagavale ma le toe faaaogaina lona buffer (faatupulaia ai pe afai e talafeagai).
/// Ua faia lea e aloese mai le tuʻuina atu o se `String` fou ma kopiina atoa mea i luga o gaioiga uma, lea e mafai ona maua ai le *O*(*n*^ 2) taimi tamoe pe a fausia se *n*-byte manoa e ala i le faʻateleina concatenation.
///
///
/// O le manoa i le itu taumatau e naʻo le nonoina;o mea i totonu ua kopiina i le `String` faʻafoʻi.
///
/// # Examples
///
/// Faʻatatau lua 'String`s ave le muamua i le taua ma nonoina le lona lua:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` ua minoi ma ua le toe mafai ona faʻaaogaina ii.
/// ```
///
/// Afai e te manaʻo e faʻaauau pea ona faʻaaoga le muamua `String`, e mafai ona e faʻailoaina ma faʻaopopo i le clone nai lo le:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` o loʻo aoga pea iinei.
/// ```
///
/// Faʻatasia `&str` fasi e mafai ona faia i le faʻaliliuina o le muamua i le `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Faʻaaogaina le `+=` tagata faʻagaioia mo le faʻaopopoina i le `String`.
///
/// ua i ai le amio lava lenei e tasi e pei o le auala [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// O se ituaiga igoa mo [`Infallible`].
///
/// Lenei igoa igoa o loʻo i ai mo tuafaʻafetaui, ma ono iʻu ina leai.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// A trait mo le faʻaliliuina o se tau i le `String`.
///
/// Lenei trait e otometi lava ona faʻaogaina mo soʻo se ituaiga e faʻaaogaina le [`Display`] trait.
/// E pei o lea, `ToString` le tatau ona faʻatino saʻo:
/// [`Display`] tatau ona faʻatinoina nai lo, ma oe maua le `ToString` faʻatinoina mo maua fua.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Faʻaliliua le taua taua i le `String`.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// I lenei faʻatinoga, o le `to_string` metotia panics pe a fai o le `Display` faʻatinoina toe faafoi mai se mea sese.
/// Lenei faʻaalia ai le sese `Display` faʻatinoina talu `fmt::Write for String` le toe faʻafoʻi se sese lava ia.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // O se taʻiala masani o le aua le faʻailoaina lautele galuega.
    // Peitai, o le aveʻesea o le `#[inline]` mai lenei metotia mafua ai le le amanaʻiaina faʻafitauli.
    // Vaʻai <https://github.com/rust-lang/rust/pull/74852>, le taumafaiga mulimuli e taumafai e aveʻese.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Faʻaliliua se `&mut str` i totonu o le `String`.
    ///
    /// O le iʻuga e faʻasoa i luga o le faaputuga.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: suʻega toso i le libstd, lea e mafua ai mea sese iinei
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Faʻaliliua le fasi pusa `str` i le `String`.
    /// E maitauina o le `str` fasi e ana.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Faʻaliliuina le `String` foaʻi i se atigipusa `str` fasi o loʻo umiaina.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Liua se manoa fasi i totonu o le aitalafu ituaiga.
    /// Leai se faʻaputuga vaʻaia e faia, ma le manoa e le kopiina.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Faʻaliliuga o se manoa i totonu o se ituaiga eseese.
    /// Leai se faʻaputuga vaʻaia e faia, ma le manoa e le kopiina.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Faʻaliliuina se faʻamatalaga fesoʻotaʻi i totonu o se ituaiga aitalafu.
    /// Leai se faʻaputuga vaʻaia e faia, ma le manoa e le kopiina.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Faʻaliliuina le `String` tuʻuina atu i le vector `Vec` o loʻo taofia tau o ituaiga `u8`.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// O se mea faʻaalu mo `String`.
///
/// O lenei fausia na faia e le [`drain`] metotia luga [`String`].
/// Vaʻai ana faʻamaumauga mo sili atu.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// O le a faʻaaogaina o&'a mut String i le faʻaleagaina
    string: *mut String,
    /// Amata o le vaega e aveʻese
    start: usize,
    /// Iuga o le vaega e aveese
    end: usize,
    /// Nofoaga o loʻo totoe ile taimi nei e aveʻese
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Faʻaaoga Vec::drain.
            // "Reaffirm" o tuaʻoi siaki e 'alofia panic code le toe faʻaofiina.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Faʻafoʻi mai le toega (sub) manoa o lenei iterator o se fasi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: faʻamalieina AsRef impls lalo pe a faʻamautuina.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Le faʻamalieina pe a faʻamautuina `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>mo Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> mo Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}