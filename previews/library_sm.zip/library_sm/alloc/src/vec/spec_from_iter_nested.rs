use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// Le isi faʻapitoa trait mo Vec::from_iter talafeagai e faʻamuamua lima tuʻufaʻatasi faʻapitoa faʻapitoa vaʻai [`SpecFromIter`](super::SpecFromIter) mo auiliiliga.
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Tatala le uluaʻi faʻamatalaga, ona o le vector o le a faʻalauteleina i luga o lenei faʻamatalaga i mataupu uma pe a le gaogao e le gaogao, ae o le matasele i extend_desugared() o le a le vaʻaia le vector o loʻo tumu i nai faʻasologa faʻasolosolo mulimuli.
        //
        // O lea matou te maua ai le sili atu branch valoʻaga.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // tatau ona faʻatuʻu atu i le spec_extend() talu ai extend() lava ia na faʻamatuʻu mai i spec_from mo avanoa Vecs
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // tatau ona faʻatuʻu atu i le spec_extend() talu ai extend() lava ia na faʻamatuʻu mai i spec_from mo avanoa Vecs
        //
        vector.spec_extend(iterator);
        vector
    }
}