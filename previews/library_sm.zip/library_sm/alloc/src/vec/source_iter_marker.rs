use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Faʻailoga faʻapitoa mo le aoina o se laina paipa faʻasolosolo i totonu o le Vec a o toe faʻaaogaina le faʻavae tuʻufaʻatasiga, ie
/// faʻataunuuina le paipa i le nofoaga.
///
/// O le SourceIter matua trait e talafeagai mo le faʻapitoa galuega e faʻaaoga ai le faʻasoaga e tatau ona toe faʻaaogaina.
/// Ae le lava mo le faʻapitoa e aoga ai.
/// Tagai tuaoi faaopoopo i luga o le impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// O le std-totonu SourceIter/InPlaceIterable traits e faʻaogaina lava e filifili o le Adaptor <Adapter<Adapter<IntoIter>>> (uma e ona core/std).
// Faʻaopopoina tuaʻoi luga o le adapter faʻatinoina (tala atu `impl<I: Trait> Trait for Adapter<I>`) na faʻamoemoe i isi traits ua uma ona makaina o faʻapitoa traits (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. o le faʻailoga e le faʻamoemoeina i olaga o ituaiga tagata sapalaiina-tagata.Modulo le Copy hole, lea e tele isi faʻapitoa ua leva ona faʻamoemoe i ai.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Manaʻoga faʻaopopo e le mafai ona faʻaalia e ala i le trait bounds.Matou te faʻamoemoe i mea uma:
        // a) leai ZSTs ona o le a leai se faʻasoaga e toe faʻaaogaga ma faʻasino arithmetic e panic b) lapoʻa fetaui e pei ona manaʻomia e Alloc konekarate c) laina tutusa pei ona manaʻomia e Alloc konekarate
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // toe paʻu i isi faʻaaogaina lautele
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // faʻaaoga le try-fold talu mai lena taimi
        // - e sili ona lelei le faʻamamaina mo nisi mea faʻapipiʻi
        // - E le pei o le tele o metotia faʻasolosolo i totonu, e naʻo le &mut lava e manaʻomia
        // - e faatagaina i tatou filo le faasino tusi e ala i ana innards ma maua ai i tua i le faaiuga
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // na manuia le faʻamaoniga, aua le faʻapaʻu le ulu
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // siaki pe a fai o le konekalate a SourceIter sa lagolagoina le faʻaliga: afai latou te le mafai matou te le oʻo foi i lenei tulaga
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // siaki le InPlaceIterable konekarate.E faʻatoa mafai lea peʻafai o le iterator na alualu i luma le faʻasino tusi i uma.
        // Afai na te faʻaaogaina le avanoa siaki e ala i le TrustedRandomAccess ona tumau ai lea o le faʻasino autu i lona tulaga muamua ma e le mafai ona tatou faʻaaogaina o se faʻasino.
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // paʻu soʻo se mea taua i le siʻusiʻu o le faʻavae ae taofia le paʻu o le faʻasoaga ia lava taimi IntoIter alu ese mai le lautele pe a fai o le pa'ū panics ona matou faʻapea foi ona faʻasalalauina soʻo se elemeni aoina i dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // le InPlaceIterable konekarate e le mafai ona faʻamaonia tonu iinei ona o le try_fold ei ai se faʻasino faʻapitoa i le punavai faʻasino mea uma e mafai ona tatou faia o le siakiina pe o i ai pea i le tulaga
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}