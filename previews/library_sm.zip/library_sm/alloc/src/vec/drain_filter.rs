use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// O se mea faʻasolosolo e faʻaaogaina se tapunia e fuafua ai pe tatau ona aveʻese se elemeni.
///
/// O lenei fausia na faia e [`Vec::drain_filter`].
/// Vaʻai ana faʻamaumauga mo sili atu.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// O le faasino igoa o le aitema o le a asiasia e le isi valaʻau i le `next`.
    pub(super) idx: usize,
    /// O le aofai o aitema na faʻamaligiina (removed) e oʻo mai i le taimi nei.
    pub(super) del: usize,
    /// O le umi umi o `vec` ae le i faʻamamaina.
    pub(super) old_len: usize,
    /// O le faʻataʻitaʻiga suʻega faamama.
    pub(super) pred: F,
    /// O se fuʻa o loʻo faʻailoa mai ai o le panic na tupu i le faʻaiuga o le suʻega.
    /// O lenei e faʻaaogaina o se faʻaaliga i le paʻu faʻatinoina e taofia ai le taumafaina o le toega o le `DrainFilter`.
    /// Soʻo se mea e leʻo faʻataʻitaʻia o le a toe faʻafoʻi i tua i le `vec`, ae leai ni isi aitema o le a faʻapaʻu pe tofotofoina e le filiga muamua.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// Faʻafoʻi mai se faʻasino i le tagata faʻavae foaʻi.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // Faʻafou le index *ina ua mavae* o le predicate ua valaʻauina.
                // A faʻapea e faʻafou muamua le faʻasino igoa ma le numera muamua o le panics, o le elemeni i lenei faʻasino tusi o le a faʻasalalauina.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // O lenei o se a vevesi le setete tulaga, ma e leai se moni lava manino mea e fai.
                        // Matou te le mananaʻo e taumafai pea e faʻatino le `pred`, o lea matou te naʻo le toe suʻeina uma o elemeni e leʻi faʻatautaia ma taʻu i le vector o loʻo iai pea.
                        //
                        // O le backshift e manaʻomia e puipuia ai le faalua-pa'ū o le mulimuli mea na faʻamamaina ma le manuia aʻo lumanaʻi le panic i le predicate.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // Taumafai e faʻaumatia soʻo se elemeni o totoe pe a fai o le faʻamalamalamaga faʻamalamalamaga e leʻi faʻafefe.
        // O le a tatou toe faʻasolosolo i tua ni elemeni o totoe pe ua uma ona tatou popolevale pe afai o le faʻaaogaina iinei panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}