use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Faʻapitoa trait faʻaaogaina mo Vec::from_iter
///
/// ## Le kalafi sui:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // O se mataupu masani o le pasiina o le vector i se gaioiga e toe faʻaputuputu loa i totonu o le vector.
        // E mafai ona tatou puʻupuʻuina lenei pe a fai e leʻi alualu i luma le IntoIter.
        // A maeʻa ona alualu i luma E mafai foi ona tatou toe faʻaaogaina le manatuaina ma ave faʻamatalaga i luma.
        // Ae naʻo matou faia pe a oʻo i le Vec iʻuga o le a le sili atu le faʻaaogaina gafatia nai lo le fausiaina e ala i le lautele FromIterator faʻatinoga o le a.
        //
        // O lena faʻatapulaʻaina e le matua manaʻomia ona o amioga a le Vec e tuʻuina atu ma le loto i ai e leʻo faʻapitoa.
        // Ae o se filifiliga faautauta.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // tatau ona faʻatuʻu atu i le spec_extend() talu ai extend() lava ia na faʻamatuʻu mai i spec_from mo avanoa Vecs
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Lenei faʻaaogaina `iterator.as_slice().to_vec()` talu ai spec_extend tatau ona faia nisi laʻasaga e mafaufau ai e uiga i le mulimuli gafatia + umi ma faʻapea faia tele galuega.
// `to_vec()` tuusao allocates le aofaiga saʻo ma faatumuina ai tonu.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): ma cfg(test) o le natura `[T]::to_vec` metotia, lea e manaʻomia mo lenei metotia faʻamatalaga, e le avanoa.
    // Nai lo o faaaogaina le `slice::to_vec` galuega tauave lea e na o le maua ma cfg(test) NB vaai i le module slice::hack i slice.rs mo nisi faamatalaga
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}