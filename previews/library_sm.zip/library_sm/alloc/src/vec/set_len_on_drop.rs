// Seti le umi o le volt pe a o le `SetLenOnDrop` aoga alu ese mai le lautele.
//
// O le manatu o le: O le umi fanua i SetLenOnDrop o se fesuiaʻiga o le lotoifale o le a vaʻaia e le optimizer e le alias ma soʻo se faleoloa e ala i le Vec's faʻasino tusi.
// Ole auala lea e suʻesuʻe ai le #32155
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}