//! O se ituaiga vavalalata sosolo ituaiga ma faʻaputuga tuʻuina atu mea, tusia `Vec<T>`.
//!
//! Vectors maua `O(1)` faʻasino igoa, amortized `O(1)` tulei (i le iuga) ma `O(1)` pop (mai le iuga).
//!
//!
//! Vectors faʻamautinoa latou te le tuʻuina atu sili atu nai lo `isize::MAX` bytes.
//!
//! # Examples
//!
//! E mafai ona e faia faʻamalamalama se [`Vec`] ma le [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... pe i le faʻaaogaina o le [`vec!`] macro:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // sefulu sene
//! ```
//!
//! Oe mafai [`push`] taua i luga o le pito o le vector (lea o le a tupu ai le vector pe a manaʻomia):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Ole faʻatauaina ole aoga e tutusa lelei ile faiga tutusa:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! E lagolagoina foi e le Vectors le faasino igoa (e ala ile [`Index`] ma [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// A tuaoi ituaiga autau growable, tusia e pei `Vec<T>` ma folafola 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// O le [`vec!`] macro ua faʻaavanoaina e faʻafaigofie ai ona amataina le amataga.
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// E mafai foi ona amataina elemeni taʻitasi o le `Vec<T>` ma le aofaʻi taua.
/// Atonu e sili atu le aoga nai lo le faʻatinoina o faʻasoaga ma faʻamuamua i laʻasaga eseʻese, ae maise pe a amataina le vector o zeros:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // O mea nei e tutusa, ae ono telegese:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Mo nisi faamatalaga, tagai i [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Faʻaaoga le `Vec<T>` o se lelei faʻaputuga:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Lolomi 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// O le `Vec` ituaiga faʻatagaina le faʻaavanoaina o tau i le faʻasino igoa, aua e faʻaaogaina le [`Index`] trait.O se faʻataʻitaʻiga o le a sili atu ona manino:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // o le a faʻaalia '2'
/// ```
///
/// Peitaʻi ia faʻaeteete: afai e te taumafai e ulufale i se faʻasino tusi e le oi totonu o le `Vec`, o lau polokalama o le panic!Oe le mafai ona faia lenei:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Faʻaoga [`get`] ma [`get_mut`] pe a fai e te manaʻo e siaki pe o i totonu le `Vec` le faʻasino igoa.
///
/// # Slicing
///
/// A `Vec` mafai ona suia.I le isi itu, fasi fasi mea faitino-naʻo mea faitino.
/// Ina ia maua se [slice][prim@slice], faaaoga [`&`].Faʻataʻitaʻiga:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... ma na pau lava lena!
/// // e mafai foʻi ona e faia faʻapenei:
/// let u: &[usize] = &v;
/// // pe faʻapenei:
/// let u: &[_] = &v;
/// ```
///
/// I le Rust, e masani ona pasi ni fasi pepa e avea ma finauga nai lo le vectors pe a e manaʻo e faʻaaoga le faitauga ulufale.E tutusa foi mo [`String`] ma [`&str`].
///
/// # Gafatia ma reallocation
///
/// O le gafatia o le vector o le aofaʻi o avanoa ua atofaina mo soʻo se future elemeni o le a faʻaopopoina i luga o le vector.Lenei e le tatau ona fenumiai ma le *umi* o le vector, o loʻo faʻamaoti mai ai le numera o moni elemeni i totonu o le vector.
/// Afai o le umi o le vector ua sili atu i lona gafatia, o lona gafatia o le a otometi lava ona faʻateleina, ae o ona elemeni e tatau ona toe faʻatulagaina.
///
/// Mo se faʻataʻitaʻiga, o le vector ma le gafatia 10 ma le umi 0 o le a leai se avanoa vector ma avanoa mo 10 sili atu elemene.Tulei 10 po o le itiiti ifo o le a le suia elemene i luga o le vector lona tulaga po o mafuaaga reallocation e tulai mai.
/// Peitai, afai e faateleina le umi o le vector i le 11, o le a maua e reallocate, lea e mafai ona telegese.Mo lenei mafuaʻaga, ua fautuaina e faʻaaoga [`Vec::with_capacity`] i soʻo se taimi e mafai ai ona faʻamaoti mai le telē o le vector e faʻamoemoe e maua.
///
/// # Guarantees
///
/// Ona o lona ofoofogia taua natura, `Vec` faia tele o faʻamaoniga e uiga i lana mamanu.Ole mea lea e mautinoa ai ose mea maualalo ile mea e mafai ai ile tulaga lautele, ma e mafai ona faʻaaoga saʻo ile auala tuai ile numera le saogalemu.Manatua o nei faʻamaoniga faʻasino i le le agavaʻa `Vec<T>`.
/// Afai e faʻaopopo faʻaopoopo ituaiga tapulaʻa (faʻataʻitaʻiga, e lagolago ai tuʻufaʻatasiga tuʻufaʻatasi), o le soʻona faia o a latou mea sese e ono suia ai le amio.
///
/// Sili ona taua, `Vec` o ma o taimi uma o le a avea ma (faʻasino tusi, agavaʻa, umi) tolu tolu.Leai se mea, leai se laʻititi.O le faʻatonuga o nei fanua e leʻo faʻamatalaina atoatoa, ma e tatau ona e faʻaaogaina metotia talafeagai e faʻafetaui ai nei mea.
/// O le faʻasino tusi o le a le mafai ona faaleaogaina, o lea o lenei ituaiga e leai-faʻasino-faʻamanuiaina.
///
/// Ae ui i lea, o le faʻasino tusi atonu le faʻasino tonu i tuʻufaʻatasia manatua.
/// A faʻapitoa lava, afai e te fausiaina se `Vec` ma le agavaʻa 0 ala i le [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], pe ala i le valaʻau atu i le [`shrink_to_fit`] i luga o le Vec avanoa, o le a le faʻaavanoaina manatua.E faʻapena foi, afai e te teuina ni nai fua i totonu o le `Vec`, o le a le tuʻuina avanoa mo i latou.
/// *Manatua i lenei tulaga le `Vec` ono le lipotia se [`capacity`] o 0*.
/// `Vec` le a faasoasoa afai ma pe afai ['Mema: : size_of::<T>`]() * capacity()> 0`.
/// I se tulaga lautele, o le Vec`'s vaevaeina auiliiliga e sili atu ona maaleale-pe a fai e te fuafua e faʻasoa ni mea e faʻaaoga ai le `Vec` ma faʻaaoga mo se isi mea (a le o le pasi atu i le le saogalemu code, poʻo le fausiaina o sau oe manatua-lagolagoina faʻaputuga), ia mautinoa ia faʻaaoga lenei manatua ile faʻaaogaina ole `from_raw_parts` e toe maua mai ai le `Vec` ona tiaʻi ai lea.
///
/// Afai o le `Vec`*ua* tuʻuina atu le manatuaina, ona avea lea o le mea ma manatua o loʻo i luga o le faupuega (e pei ona faʻamatalaina e le tuʻufaʻatasia o Rust ua faʻatulagaina e faʻaaoga e le masani ai), ma lona faʻasino tusi i le [`len`] amataina, vavalalata elemeni i le faʻasologa (o le a sau mea e fai vaʻai pe a fai na e faʻamalosia i se fasi), mulimuli mai ai ma le [`gafatia`]`,`['len`] e leʻo faʻailoaina, elemeni fesoʻotaʻi.
///
///
/// O le vector o loʻo iai elemeni `'a'` ma `'b'` ma le agavaʻa 4 e mafai ona vaʻaia faʻapea i lalo.O le pito i luga o le `Vec`, o loʻo iai se faʻasino i le ulu o le faʻasoaga i le faʻaputuga, umi ma le agavaʻa.
/// O le pito i lalo o le faʻasoaga i luga o le faʻaputuga, o se latalata manatua poloka.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** faʻatusatusa le manatua e leʻo amataina, vaʻai [`MaybeUninit`].
/// - Note: le ABI e le mautu ma `Vec` leai ni faʻamaoniga e uiga i lona manatua faʻatulagaina (aofia ai le faʻasologa o fanua).
///
/// `Vec` e le mafai ona faia se "small optimization" o mea elemeni e moni teuina i luga o le faaputuga mo lua mafuaaga:
///
/// * O le a faʻafaigata ai lava i le le sefeina o le tulafono le faʻasaʻo saʻo o le `Vec`.O mea o loʻo i totonu o le `Vec` e le maua se tuatusi faʻamautu pe a fai na o le minoi, ma o le a sili atu ona faigata ona faʻamautinoa pe o le `Vec` na tufatufaina moni le mafaufau.
///
/// * O le a faʻasalaga le mataupu lautele, faʻatupuina se faʻaopopo branch i luga o avanoa uma.
///
/// `Vec` e le otometi lava ona solomuli ia lava, tusa lava pe leai se mea.Ole mea lea e mautinoa ai e leai se faʻasoaga tatau poʻo ni fetuunaiga e tupu.Emptying a `Vec` ai le faatumuina lea o tua i luga i le tasi [`len`] tatau ona aafia i se valaauga i le allocator.Afai e te manaʻo e faʻasaʻoloto le manatuaina e leʻi faʻaaogaina, faʻaaoga le [`shrink_to_fit`] poʻo le [`shrink_to`].
///
/// [`push`] ma [`insert`] o le a le mafai (toe) faʻasoasoa pe a fai o le lipotia agavaʻa ua lava.[`push`] ma [`insert`]*a*(toe) faasoa afai ['len`]'=='[' capacity`].O lona uiga, o le lipotia gafatia e atoatoa saʻo, ma e mafai ona faʻamoemoe i ai.E mafai foi ona faʻaaogaina e tuʻu fua ai le lima i luga o le mafaufau tuʻufaʻatasia e le `Vec` pe a manaʻomia.
/// Tele metotia faʻaulu * e mafai ona toe suʻe, e tusa lava pe le manaʻomia.
///
/// `Vec` E le faʻamaonia se faʻapitoa tuputupu aʻe fuafuaga pe a toe faʻaalu pe a tumu, pe a valaʻauina [`reserve`].O le taimi nei taʻiala e faʻavae ma ono ono faʻamaonia le manaʻomia e faʻaaoga se le-faʻaauau tuputupu aʻe vaega.Poʻo le a lava le metotia e faʻaaogaina o le a mautinoa mautinoa *O*(1) amortized [`push`].
///
/// `vec![x; n]`, `vec![a, b, c, d]`, ma [`Vec::with_capacity(n)`][`Vec::with_capacity`], o le a gaosia uma se `Vec` ma le mea saʻo lava le malosiaga na talosagaina.
/// Afai [`len`]`==`[`gafatia`], (e pei o le tulaga mo le [`vec!`] macro), ona mafai lea ona liua le `Vec<T>` i ma mai le [`Box<[T]>`][owned slice] e aunoa ma le toe faʻatulagaina poʻo le minoi o elemeni.
///
/// `Vec` o le a le faʻapitoa faʻapipiʻiina soʻo se faʻamatalaga ua aveʻesea mai ia, ae le mafai faʻapitoa ona faʻasaoina.O lona manatuaina uninitialized o valu avanoa e ono faʻaaogaina ai e manaʻo.E masani lava ona na ona faia soʻo se mea e sili ona lelei pe i se isi itu faigofie ona faʻatino.Aua le faalagolago i faamatalaga ua aveesea e ona aveesea mo faamoemoega o le saogalemu.
/// Tusa lava pe e te faʻapaʻu le `Vec`, o lona buffer atonu e toe faʻaaoga e le isi `Vec`.
/// Tusa lava pe e te muaʻi manatua le mea e manatua ai le 'Vec`, e ono le tupu lena mea aua e le manatu le tagata faʻamautinoa o se itu-itu e tatau ona faʻasaoina.
/// E i ai le mataupu e tasi matou te le solia, ae ui i lea: faʻaaoga le `unsafe` code e tusi ai i le sili atu gafatia, ona faʻateleina lea o le umi e faʻafetaui, e aoga i taimi uma.
///
/// I le taimi nei, e le mautinoa e le `Vec` le faʻasologa e paʻu ai elemene.
/// Na suia le faʻasologa i taimi ua tuanaʻi ma ono toe suia.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Metotia faʻavae
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Fausia se fou, leai se aoga `Vec<T>`.
    ///
    /// O le vector o le a le faʻavasegaina seʻi vagana ua tuleia elemeni i ona luga.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Fausia se fou, leai se aoga `Vec<T>` ma le faʻapitoa gafatia.
    ///
    /// O le vector o le a mafai ona taofia tonu `capacity` elemeni e aunoa ma le toe faʻatulagaina.
    /// Afai o le `capacity` o le 0, o le vector o le a le faʻasoaina.
    ///
    /// E taua le maitauina e ui lava o le vector ua toe foʻi mai ua i ai le *gafatia* faʻamaoti, o le vector o le ai ai le zero *umi*.
    ///
    /// Mo se faʻamatalaga o le eseʻesega o le umi ma le agavaʻa, vaʻai i le [Capacity and reallocation] *.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // O le vector e leai ni aitema, e ui lava ona i ai gafatia mo sili atu
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // O nei mea uma e faia e aunoa ma le toe faʻatulagaina ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... ae o lenei e ono avea le vector toe sui
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Fausia saʻo se `Vec<T>` mai vaega masani o le isi vector.
    ///
    /// # Safety
    ///
    /// E matua le sefe lenei mea, ona o le aofaʻi o tagata na te leʻi siakiina:
    ///
    /// * `ptr` manaʻomia na faʻasoa muamua e ala i le 'String`]/' Vec<T>"(sili atu, e foliga mai e le saʻo pe a leai).
    /// * `T` manaʻomia ia tutusa le tele ma le faʻatulagaina pei o le a `ptr` na tuʻuina iai.
    ///   (`T` o le i ai o se laʻititi lava faʻatulagaina gaioiga e le lava, o le tuʻufaʻatasia manaʻomia moni lava e tutusa e faʻamalieina ai le [`dealloc`] manaʻoga e manaʻomia tatau ona tufatufaina ma fefaʻasoaaʻi ma le faʻatulagaina tutusa.)
    ///
    /// * `length` manaʻomia ia laʻititi ifo pe tutusa i le `capacity`.
    /// * `capacity` manaʻomia le mafai na faʻatatauina le faʻasino.
    ///
    /// O le solia o nei mea e ono tulaʻi mai ai ni faʻafitauli e pei o le faʻaleagaina o vaega o faʻamatalaga i totonu.Mo se faʻataʻitaʻiga e le **saogalemu** le fausiaina o le `Vec<u8>` mai le faʻasino i le C `char` faʻasologa ma le umi `size_t`.
    /// E le sefe foʻi le fausia o se tasi mai le `Vec<u16>` ma lona umi, aua e popole le tagata e tuʻuina atu mea i le laina, ma o nei ituaiga e lua e eseese a latou laina.
    /// O le buffer na vaeluaina ma le laina 2 (mo `u16`), ae a maeʻa ona liliu i totonu o le `Vec<u8>` o le a faʻatautaia faʻatasi ma le laina 1.
    ///
    /// O le anaina o `ptr` e faʻamasani lava ona faʻamatuʻu atu i le `Vec<T>` lea e ono faʻamatuʻu atu, toe tuʻuina atu pe suia mea o loʻo i totonu e manatua e le faʻasino i le manaʻoga.
    /// Ia mautinoa e leai seisi mea e faʻaogaina le faʻasino tusi pe a maeʻa ona valaʻau lenei galuega.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME FAAFOUGA O lenei ina ua vec_into_raw_parts ua e gafatia.
    ///     // Taofi le tamoe o le 'v`'s destructor o lea tatou te puleaina atoatoa ai le faʻasoaga.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Toso ese eseʻese vaega taua o faʻamatalaga e uiga ile `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Tusi le manatua i le 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Tuu faatasi foi mea uma i se Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Fausia se fou, leai se aoga `Vec<T, A>`.
    ///
    /// O le vector o le a le faʻavasegaina seʻi vagana ua tuleia elemeni i ona luga.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Fausia se fou, leai se mea `Vec<T, A>` ma le faʻapitoa gafatia ma le saunia tuʻuina atu.
    ///
    /// O le vector o le a mafai ona taofia tonu `capacity` elemeni e aunoa ma le toe faʻatulagaina.
    /// Afai o le `capacity` o le 0, o le vector o le a le faʻasoaina.
    ///
    /// E taua le maitauina e ui lava o le vector ua toe foʻi mai ua i ai le *gafatia* faʻamaoti, o le vector o le ai ai le zero *umi*.
    ///
    /// Mo se faʻamatalaga o le eseʻesega o le umi ma le agavaʻa, vaʻai i le [Capacity and reallocation] *.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // O le vector e leai ni aitema, e ui lava ona i ai gafatia mo sili atu
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // O nei mea uma e faia e aunoa ma le toe faʻatulagaina ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... ae o lenei e ono avea le vector toe sui
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Fausia saʻo se `Vec<T, A>` mai vaega masani o le isi vector.
    ///
    /// # Safety
    ///
    /// E matua le sefe lenei mea, ona o le aofaʻi o tagata na te leʻi siakiina:
    ///
    /// * `ptr` manaʻomia na faʻasoa muamua e ala i le 'String`]/' Vec<T>"(sili atu, e foliga mai e le saʻo pe a leai).
    /// * `T` manaʻomia ia tutusa le tele ma le faʻatulagaina pei o le a `ptr` na tuʻuina iai.
    ///   (`T` o le i ai o se laʻititi lava faʻatulagaina gaioiga e le lava, o le tuʻufaʻatasia manaʻomia moni lava e tutusa e faʻamalieina ai le [`dealloc`] manaʻoga e manaʻomia tatau ona tufatufaina ma fefaʻasoaaʻi ma le faʻatulagaina tutusa.)
    ///
    /// * `length` manaʻomia ia laʻititi ifo pe tutusa i le `capacity`.
    /// * `capacity` manaʻomia le mafai na faʻatatauina le faʻasino.
    ///
    /// O le solia o nei mea e ono tulaʻi mai ai ni faʻafitauli e pei o le faʻaleagaina o vaega o faʻamatalaga i totonu.Mo se faʻataʻitaʻiga e le **saogalemu** le fausiaina o le `Vec<u8>` mai le faʻasino i le C `char` faʻasologa ma le umi `size_t`.
    /// E le sefe foʻi le fausia o se tasi mai le `Vec<u16>` ma lona umi, aua e popole le tagata e tuʻuina atu mea i le laina, ma o nei ituaiga e lua e eseese a latou laina.
    /// O le buffer na vaeluaina ma le laina 2 (mo `u16`), ae a maeʻa ona liliu i totonu o le `Vec<u8>` o le a faʻatautaia faʻatasi ma le laina 1.
    ///
    /// O le anaina o `ptr` e faʻamasani lava ona faʻamatuʻu atu i le `Vec<T>` lea e ono faʻamatuʻu atu, toe tuʻuina atu pe suia mea o loʻo i totonu e manatua e le faʻasino i le manaʻoga.
    /// Ia mautinoa e leai seisi mea e faʻaogaina le faʻasino tusi pe a maeʻa ona valaʻau lenei galuega.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME FAAFOUGA O lenei ina ua vec_into_raw_parts ua e gafatia.
    ///     // Taofi le tamoe o le 'v`'s destructor o lea tatou te puleaina atoatoa ai le faʻasoaga.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Toso ese eseʻese vaega taua o faʻamatalaga e uiga ile `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Tusi le manatua i le 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Tuu faatasi foi mea uma i se Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Faʻamamaina le `Vec<T>` i ona vaega masani.
    ///
    /// Faʻafoʻi le faʻasino upu i le faʻavae o faʻamatalaga, le umi o le vector (i elemeni), ma le faʻasoasoaina gafatia o faʻamatalaga (i elemeni).
    /// O finauga lava ia e tasi ile tutusa tutusa ma finauga ile [`from_raw_parts`].
    ///
    /// A maeʻa ona valaʻau lenei galuega, o le tagata e valaʻau e nafa ma le manatua na muamua faʻatautaia e le `Vec`.
    /// Pau lava le auala e faia ai lenei mea o le suia lea o le raw point, umi, ma gafatia toe foi i totonu o le `Vec` ma le [`from_raw_parts`] gaioiga, faʻatagaina le faʻaleagaina ona faia le faʻamamaina.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Ua mafai nei ona tatou faia suiga i vaega, e pei o le tuʻuina atu o le faʻasino tusi i se ituaiga talafeagai.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Faʻamamaina le `Vec<T>` i ona vaega masani.
    ///
    /// Faʻafoʻi le faʻasino manino i le faʻavae o faʻamatalaga, le umi o le vector (i elemeni), le faʻasoasoaina gafatia o faʻamatalaga (i elemeni), ma le faʻasoasoa.
    /// O finauga lava ia e tasi ile tutusa tutusa ma finauga ile [`from_raw_parts_in`].
    ///
    /// A maeʻa ona valaʻau lenei galuega, o le tagata e valaʻau e nafa ma le manatua na muamua faʻatautaia e le `Vec`.
    /// Pau lava le auala e faia ai lenei mea o le suia lea o le raw point, umi, ma gafatia toe foi i totonu o le `Vec` ma le [`from_raw_parts_in`] gaioiga, faʻatagaina le faʻaleagaina ona faia le faʻamamaina.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Ua mafai nei ona tatou faia suiga i vaega, e pei o le tuʻuina atu o le faʻasino tusi i se ituaiga talafeagai.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Faʻafoʻi mai le numera o elemene e mafai e le vector ona taofia e aunoa ma le toe faʻatulagaina.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Faʻaagaga gafatia mo le sili atu `additional` sili elemeni e faʻaofi i le tuuina `Vec<T>`.
    /// O le aoina ono faʻaavanoa tele avanoa e aloese ai mai faʻataʻitaʻiga masani.
    /// A maeʻa ona valaʻau `reserve`, o le a sili atu le malosi nai lo pe tutusa i le `self.len() + additional`.
    /// E leai se mea pe a fai ua lava le agavaʻa.
    ///
    /// # Panics
    ///
    /// Panics pe afai o le tulaga fou e sili bytes `isize::MAX`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Faʻasao le laʻititi gafatia mo tonu `additional` sili elemeni e faʻaofi i le `Vec<T>` tuʻuina atu.
    ///
    /// A maeʻa ona valaʻau `reserve_exact`, o le a sili atu le malosi nai lo pe tutusa i le `self.len() + additional`.
    /// E leai se mea pe a fai o le malosi ua lava.
    ///
    /// Manatua o le tagata faʻasoa e ono tuʻuina atu i le aoina sili avanoa nai lo le mea e talosagaina.
    /// O le mea lea, gafatia le mafai ona faʻamoemoeina i luga ia avea matua mautinoa itiiti.
    /// Sili `reserve` pe a fai o future e ono faʻaofiina.
    ///
    /// # Panics
    ///
    /// Panics pe a fai e oʻo i le `usize` le malosi fou.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Taumafai e faasao le gafatia mo le itiiti ifo i `additional` sili elemene ona faaofiina i totonu o le `Vec<T>` tuuina mai.
    /// O le aoina ono faʻaavanoa tele avanoa e aloese ai mai faʻataʻitaʻiga masani.
    /// A maeʻa ona valaʻau `try_reserve`, o le a sili atu le malosi nai lo pe tutusa i le `self.len() + additional`.
    /// E leai se mea pe a fai ua lava le agavaʻa.
    ///
    /// # Errors
    ///
    /// Afai taumasuasua le malosi, po o le allocator lipoti a toilalo, lea ua toe o se mea sese.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Muamua-faʻasao le manatuaina, exiting pe a fai tatou te le mafaia
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Lenei ua matou iloa e le mafai OOM i le ogatotonu o la matou galuega faigata
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // faigata tele
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Taumafai e faʻasao le laʻititi gafatia mo tonu `additional` elemeni e faʻaofi i le `Vec<T>` tuʻuina atu.
    /// A maeʻa ona valaʻau `try_reserve_exact`, o le a sili atu le malosi nai lo pe tutusa i le `self.len() + additional` pe a faʻafoi mai le `Ok(())`.
    ///
    /// E leai se mea pe a fai o le malosi ua lava.
    ///
    /// Manatua o le tagata faʻasoa e ono tuʻuina atu i le aoina sili avanoa nai lo le mea e talosagaina.
    /// O le mea lea, gafatia le mafai ona faʻamoemoeina i luga ia avea matua mautinoa itiiti.
    /// Sili `reserve` pe a fai o future e ono faʻaofiina.
    ///
    /// # Errors
    ///
    /// Afai taumasuasua le malosi, po o le allocator lipoti a toilalo, lea ua toe o se mea sese.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Muamua-faʻasao le manatuaina, exiting pe a fai tatou te le mafaia
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Lenei ua matou iloa e le mafai OOM i le ogatotonu o la matou galuega faigata
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // faigata tele
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Faʻapipiʻi le gafatia o le vector i le tele e mafai ai.
    ///
    /// O le a pa'ū lalo i lalo latalata i le umi e mafai ai ae o le faasoasoaina mafai ona logoina pea le vector o loʻo i ai le avanoa mo ni nai elemene.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // O le gafatia e le itiiti ifo nai lo le umi, ma e leai se mea e faia pe a tutusa, o lea e mafai ai ona tatou aloese mai le panic mataupu i le `RawVec::shrink_to_fit` i le na o le valaʻau i ai ma le tele gafatia.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Faʻapipiʻi le gafatia o le vector ma se pito i lalo maualalo.
    ///
    /// O le gafatia o le a tumau i le sili atu tele pei o uma le umi ma le sapalai taua.
    ///
    ///
    /// Afai o le malosiaga o loʻo i ai nei e laititi atu i lo le tapulaʻa maualalo, o le leai-op lea.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Faʻaliliuina le vector i le [`Box<[T]>`][owned slice].
    ///
    /// Manatua o lenei o le a pa'ū soʻo se sili atu gafatia.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Soʻo se sili atu gafatia ua aveʻesea:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Faʻapuʻupuʻu le vector, tausia le muamua `len` elemeni ma faʻapaʻu le toega.
    ///
    /// Afai o le `len` e sili atu nai lo le umi nei a le vector, e leai la se aoga.
    ///
    /// O le [`drain`] metotia mafai ona faʻataʻitaʻi `truncate`, ae mafua ai le sili atu elemeni e toe faʻafoʻi nai lo le pa'ū.
    ///
    ///
    /// Manatua o lenei metotia e leai se aoga i luga o le tuʻufaʻatasia gafatia o le vector.
    ///
    /// # Examples
    ///
    /// Tipiina o le elemeni elemeni vector i ni elemeni e lua:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Leai se truncation tupu pe a `len` sili atu nai lo le vector o loʻo i ai nei umi:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Faʻamutaina pe a tutusa le `len == 0` ma le valaʻauina o le [`clear`] auala.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // E sefe lenei talu ai:
        //
        // * le aloaia o le fasi pasia e `drop_in_place`;o le `len > self.len` mataupu e 'aloese mai le faia o se faʻaletonu fasi, ma
        // * o le `len` o le vector ua faʻamamaina ao le i valaauina `drop_in_place`, ina ia leai se tau o le a paʻu faalua i le tulaga `drop_in_place` na i le panic tasi (pe a fai o le panics faʻalua, o le polokalama toesea).
        //
        //
        //
        unsafe {
            // Note: E faamoemoeina e le o `>` ma le `>=`.
            //       Suiga i le `>=` ei ai leaga faʻatinoga aʻafiaga i nisi tulaga.
            //       Vaʻai #78884 mo nisi mea.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Aveese se fasi fasi pepa o loʻo iai le vector atoa.
    ///
    /// Tutusa `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Otootoga a fasi mutable o le atoa vector.
    ///
    /// Tutusa ma `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Faʻafoʻi mai se faʻasino tusi i le buffer a le vector.
    ///
    /// e tatau ona mautinoa ai le telefoni o le vector outlives le faasino lenei tupe galuega tauave, po o isi mea o le a iu ina e faasino i otaota.
    /// Fesuiaʻiga o le vector ono mafua ai ona faʻatulagaina lona faʻamau, lea e ono avea ai foʻi faʻasino ia te ia e le aoga.
    ///
    /// E tatau foʻi i le tagata telefoni ona faʻamautinoa o le manatuaina o le tusi (non-transitively) manatu i ai e le tusia i (vagana i totonu o le `UnsafeCell`) faʻaogaina lenei faʻasino poʻo se faʻasino tusi mai ai.
    /// Afai e te manaʻomia le suia o mea o loʻo i totonu o le fasi, faʻaaoga le [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Matou te faʻailoaina le fasi metotia o le igoa e tasi e aloese ai mai le ui atu i le `deref`, lea e fausia ai se fesoʻotaʻiga vavalalata.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Faʻafoʻi mai se faʻailoga faʻafuaseʻi le saogalemu i le buffer a le vector.
    ///
    /// e tatau ona mautinoa ai le telefoni o le vector outlives le faasino lenei tupe galuega tauave, po o isi mea o le a iu ina e faasino i otaota.
    ///
    /// Fesuiaʻiga o le vector ono mafua ai ona faʻatulagaina lona faʻamau, lea e ono avea ai foʻi faʻasino ia te ia e le aoga.
    ///
    /// # Examples
    ///
    /// ```
    /// // Allocate vector tele tele mo 4 elemene.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Faʻailoa muamua elemeni e ala i tusi tusitusi manino, ona seti lea o le umi.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Tatou loo faatusa o le auala fasi o le suafa lava lea e tasi e aloese ai mai le a ala `deref_mut`, lea ua faia ai se faasinomaga vailauga.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Faʻafoʻi mai se faʻasino i le tagata faʻavae foaʻi.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Faamalosia le umi o le vector i le `new_len`.
    ///
    /// Lenei o se maualalo-tulaga faʻagaioiga e le taofia ai se tasi o masani masani invariants o le ituaiga.
    /// Masani suia le umi o le vector e faia faʻaaogaina se tasi o le saogalemu gaioiga nai lo, pei o [`truncate`], [`resize`], [`extend`], poʻo [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` tatau ona laʻititi ifo pe tutusa i le [`capacity()`].
    /// - O elemeni i le `old_len..new_len` e tatau ona faʻamataʻuina.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// O lenei metotia e mafai ona aoga mo tulaga o loʻo avea ai le vector o se faʻamau mo isi tulafono, aemaise lava i le FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Ua naʻo se auivi laʻititi mo le faʻataʻitaʻiga doc;
    /// # // aua le faʻaaogaina lenei mea o se amataga mo se faletusi moni.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // I le FFI metotia faʻapitoa, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // SAFETY: A toe faafoi e `deflateGetDictionary` le `Z_OK`, o loʻo taofia e:
    ///     // 1. `dict_length` elemene na amataina.
    ///     // 2.
    ///     // `dict_length` <=le mafai (32_768) e mafai ai ona saogalemu le valaʻau o le `set_len`.
    ///     unsafe {
    ///         // Fai le FFI valaʻau ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... ma faʻafou le umi i le mea na amataina.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Aʻo lelei le faʻataʻitaʻiga lea, o loʻo iai se faʻagasuga o le manatuaina talu ai o le vectors i totonu e leʻi faʻasaʻolotoina ae leʻi oʻo i le `set_len` telefoni.
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` ua gaogao o lea e leai ni elemene manaʻomia e faʻamataʻuina.
    /// // 2. `0 <= capacity` umia i taimi uma soo se mea e `capacity`.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// E masani lava, ii, o le a faʻaaoga e se tasi le [`clear`] nai lo le faʻapa'ū saʻo o mea i totonu ma ia le faʻamamaina leak.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Aveʻese se elemeni mai le vector ma faʻafoʻi mai.
    ///
    /// O le aveese elemeni ua suia e le elemeni mulimuli o le vector.
    ///
    /// E le faʻasaoina le okaina, ae o le O(1).
    ///
    /// # Panics
    ///
    /// Panics pe a fai o `index` e leai ni tuaoi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Ua matou suia le tagata lava ia [index] i le elemene mulimuli.
            // Manatua afai o tuaoi siaki luga sui e tatau ona i se elemene mulimuli (lea e mafai ona ia ola [faasino] lava).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Faaopoopoga se elemene i tulaga `index` i totonu o le vector, fesiitaiga o elemene uma o mulimuli atu ai i le itu taumatau.
    ///
    ///
    /// # Panics
    ///
    /// Panics pe a `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // avanoa mo le elemene fou
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // infallible Le avanoa e tuʻu ai le tau fou
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Sifi mea uma e faʻaavanoa ai avanoa.
                // (Faʻaluaina o le vaega o le `index'th i ni laina se lua.)
                ptr::copy(p, p.offset(1), len - index);
                // Tusi i totonu, tusi faʻatasi le kopi muamua o le vaega o le `index'th.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Aveʻese ma toe faʻafoʻi le elemeni i le tulaga `index` i totonu o le vector, sifi uma elemeni pe a maeʻa i le agavale.
    ///
    ///
    /// # Panics
    ///
    /// Panics pe a fai o `index` e leai ni tuaoi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // le nofoaga o loʻo tatou o mai ai.
                let ptr = self.as_mut_ptr().add(index);
                // kopi i fafo, unsafely i ai o se kopi o le taua i luga o le faaputuga ma i le vector i le taimi e tasi.
                //
                ret = ptr::read(ptr);

                // Sifi mea uma i lalo e faʻatumu lena nofoaga.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Faʻataua naʻo elemeni ua faʻamaonia mai e le faʻamatalaga muamua.
    ///
    /// I nisi upu, aveʻese uma elemeni `e` pei o le `f(&e)` faʻafoʻi `false`.
    /// O lenei metotia faʻagaioia i le nofoaga, asiasi i elemeni taʻitasi tasi taimi i le uluaʻi faʻasologa, ma faʻasao le faʻasologa o mea taofia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Talu ai o le elemene o loo asiasi tonu lava le taimi e tasi i le poloaiga muamua, e mafai ona faaaogaina tulaga fafo e filifili lea elemene e tausia.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Aloese mai le faʻalua pa'ū pe a fai o le pa'ū leoleo e le faʻagaioia, talu ai tatou ono faia ni pu i le taimi o le gaioiga.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-gaosia len-> |^-sosoo e siaki
        //                  | <-tapeina cnt-> |
        //      | <-original_len-> |Tausia: Elemene moni i luga o lea tupe predicate.
        //
        // Pu: uunaʻia po maligi slot elemene.
        // Lē siakiina: Le faʻailogaina elemeni aoga.
        //
        // O lenei mataua leoleo o le a valaʻauina pe a fai o le predicate poʻo le `drop` o elemeni panic.
        // E fesuiaʻi elemeni siakiina e ufiufi pu ma `set_len` i le sao saʻo.
        // I tulaga pe a fai o le predicate ma le `drop` e le paʻu, o le a faʻamautinoaina i fafo.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // SAFETI: Ole faʻasolosolo ona le siakiina o mea e tatau ona aoga talu ai tatou te le paʻi lava iai.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // SAFETI: A maeʻa ona faʻatumuina pu, mea uma o loʻo i contiguous manatua.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // SAFETI: O le elemene e leʻo siakiina e tatau ona aoga.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Muamua alualu i luma e aloese faʻalua mataua pe a `drop_in_place` goto.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // SAFETI: Matou te le toe tago i lenei elemeni pe a pa'ū.
                unsafe { ptr::drop_in_place(cur) };
                // Ua uma ona matou alualu i luma le fata.
                continue;
            }
            if g.deleted_cnt > 0 {
                // SAFETY: `deleted_cnt`> 0, o lea la, e le tatau ona soʻoso le pu pu ma elemeni o loʻo i ai nei.
                // Tatou te faaaogaina kopi mo siitia, ma e leʻi paʻi toe lenei elemene.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // ua faatinoina uma aitema.e mafai ona optimized lenei e `set_len` e LLVM.
        drop(g);
    }

    /// Aveʻese uma ae o le muamua o sosoʻo mulimuli i le vector o loʻo faʻamau i le tutusa ki.
    ///
    ///
    /// Afai o le vector ua faʻavasegaina, o lenei aveʻesea uma duplicates.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Aveʻese uma ae o le muamua o soʻosoʻoga elemeni i le vector faʻamalieina a tuʻuina tutusa tutusa.
    ///
    /// O le `same_bucket` function ua pasia faʻasino i lua elemeni mai le vector ma e tatau ona fuafua pe o elemeni faʻatusatusa tutusa.
    /// O elemeni e pasi i le isi faʻatonuga mai le latou faʻatonuga i le fasi, o lea afai `same_bucket(a, b)` faʻafoʻi `true`, `a` ua aveʻesea.
    ///
    ///
    /// Afai o le vector ua faʻavasegaina, o lenei aveʻesea uma duplicates.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Faʻaopopo se elemeni i tua o le aoina.
    ///
    /// # Panics
    ///
    /// Panics pe afai o le tulaga fou e sili bytes `isize::MAX`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Lenei o le a panic pe toʻesea pe a fai matou te tuʻuina atu> isize::MAX bytes pe afai o le umi faʻaopoopoga o le a lolovaia mo zero-tele ituaiga.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Aveʻese le elemene mulimuli mai le vector ma faʻafoʻi mai, pe [`None`] peʻa leai se mea.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Siʻi uma elemeni o `other` i le `Self`, ae tuʻu pea i le `other`.
    ///
    /// # Panics
    ///
    /// Panics pe a fai o le aofai o elemeni i le vector ova i luga le `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Faʻaopopo elemeni i le `Self` mai isi puipui.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Fausia se faʻamatuʻuina iterator e aveʻese le faʻapitoa laina i le vector ma maua ai le aveese aitema.
    ///
    /// Ina ua iterator **ua** maligi, ua aveesea elemene uma i le tele mai le vector, e tusa lava pe sa le atoatoa susunuina le iterator.
    /// Afai o le iterator **e le** pa'ū (ma [`mem::forget`] faʻataʻitaʻiga), e le faʻamaonia pe fia elemene ua aveʻesea.
    ///
    /// # Panics
    ///
    /// Panics pe a fai o le amataga ua sili atu nai lo le iʻuga itu pe afai o le pito mulimuli e sili atu nai lo le umi o le vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // O le atoa atoaga kilia le vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Manatu saogalemu
        //
        // A o le Drain na muamua faia, e faʻapuʻupuʻuina le umi o le punavai vector ia mautinoa e leai se faʻailoaina poʻo le minoi-mai elemene e mafai ona maua uma pe a fai o le Drain's faʻaumatia e le mafai ona sola.
        //
        //
        // Drain o le a ptr::read fafo tau aoga e aveʻese.
        // A maeʻa, ona toe kopi lea o le siusiu o le vector e toe ufiufi ai le pu, ma o le umi o le vector e toe faʻafouina i le fou fou.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // seti self.vec umi e amata, ia saogalemu i le tulaga Drain ua faʻasalalau
            self.set_len(start);
            // Faʻaaoga le nono i le IterMut e faʻailoa ai amioga nonoina o le atoa Drain iterator (pei o &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Faʻamama le vector, aveʻese uma mea taua.
    ///
    /// Manatua o lenei metotia e leai se aoga i luga o le tuʻufaʻatasia gafatia o le vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Faʻafoʻi mai le numera o elemeni i le vector, faʻapea foi ona faʻaigoa o lona 'length'.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Faʻafoʻi `true` pe a fai o le vector e leai ni elemeni.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Vaeluaina le aoina i le lua i le faʻasino faasino igoa.
    ///
    /// Faʻafoʻi mai se vector fou faʻatulagaina o loʻo iai elemeni i le tulaga `[at, len)`.
    /// A maeʻa le valaʻau, o le uluaʻi vector o le a tuʻua e aofia ai elemene `[0, at)` ma lona gafatia muamua e le suia.
    ///
    ///
    /// # Panics
    ///
    /// Panics pe a `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // e mafai e le vector fou ona ave le muamua buffer ma aloese mai le kopi
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Le mautonu `set_len` ma kopi aitema i le `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Fuafua le `Vec` ile nofoaga ina ia tutusa le `len` ile `new_len`.
    ///
    /// Afai e sili atu le `new_len` nai lo le `len`, o le `Vec` e faʻalauteleina e le eseʻesega, ma isi avanoa taʻitasi faʻatumuina i le iʻuga o le valaʻauina o le tapunia `f`.
    ///
    /// O le toe faafoi taua mai `f` o le a faʻaiʻu i le `Vec` i le faʻasologa na latou gaosia.
    ///
    /// Afai e itiiti ifo nai lo `new_len` `len`, o loo truncated le `Vec`.
    ///
    /// O lenei metotia faʻaaogaina se tapunia e fausia ai ni tulaga fou fou i tuleiga uma.Afai e te manaʻomia [`Clone`] se tau aoga, faʻaaoga [`Vec::resize`].
    /// Afai e te manaʻo e faʻaaoga le [`Default`] trait e faʻatupu ai tau, e mafai ona e pasia [`Default::default`] o le finauga lona lua.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Faʻaaoga ma faʻasolo le `Vec`, toe faʻafoʻi mai se suiga i isi mea, `&'a mut [T]`.
    /// Manatua o le ituaiga `T` e tatau ona sili atu le ola nai lo le olaga filifilia `'a`.
    /// Afai o le ituaiga e naʻo faʻailoga masani, pe leai foi, ona ono filifilia lea e avea ma `'static`.
    ///
    /// O lenei gaioiga e tutusa ma le gaioiga [`leak`][Box::leak] i luga o le [`Box`] seʻi vagana ai e leai se auala e toe maua mai ai le leaked manatua.
    ///
    ///
    /// O lenei aoga e aoga tele mo faʻamatalaga e ola mo le toega o le polokalama olaga.
    /// O le faʻapaʻuina o le faʻamatalaga ua toe foʻi mai o le a mafua ai ona le toe manatua se mea.
    ///
    /// # Examples
    ///
    /// Faigofie faʻaaogaina:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Faʻafoʻi le avanoa avanoa totoe o le vector o se fasi `MaybeUninit<T>`.
    ///
    /// O le fasi ua toe faafoi mai e mafai ona faʻaaogaina e faʻatumu ai le vector i faʻamaumauga (eg
    /// e ala i le faitau mai se faila) ae le i faʻailogaina faʻamatalaga e pei ona amataina faʻaaoga ai le [`set_len`] metotia.
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Allocate vector tele tele mo 10 elemene.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Faatumu ia muamua elemene 3.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Faailoga muamua elemene e tolu o le vector e pei ona amataina.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // O lenei metotia e le faʻaogaina i tuutuuga o `split_at_spare_mut`, e puipuia ai le faʻaleaogaina o faʻasino i le puipui.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Faʻafoʻi mai le vector mea o se fasi `T`, faʻatasi ai ma le totoe avanoa avanoa o le vector o se fasi `MaybeUninit<T>`.
    ///
    /// O le toe faʻaleleia avanoa gafatia mafai ona faʻaaogaina e faʻatumu ai le vector i faʻamaumauga (eg i le faitau mai se faila) ae le i faʻailogaina faʻamaumauga pei muamua e faʻaaoga ai le [`set_len`] metotia.
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Manatua o lenei o se maualalo tulaga API, lea e tatau ona faʻaaogaina ma le faʻaeteete mo faʻamoemoega sili lelei.
    /// Afai e te manaʻomia le faʻaopopoina o faʻamatalaga i le `Vec` e mafai ona e faʻaaogaina [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] poʻo le [`resize_with`], fuafua i ou manaʻoga tonu.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Faʻasao faʻaopoopo avanoa tele mo 10 elemeni.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Faatumu le isi 4 elemene.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Faailoga le 4 elemene o le vector pei ua amataina.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - Len e le amanaiaina ma o lea e le suia lava
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Saogalēmū: suia toe foʻi .2 (&mut usize) e manatu tutusa ma le valaʻauina `.set_len(_)`.
    ///
    /// O lenei auala o loo faaaoga e maua ai le avanoa tulaga ese e uma vaega vec le taimi e tasi i `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` ua mautinoa e aoga mo `len` elemene
        // - `spare_ptr` o loʻo faʻasino atu le tasi elemeni i tua atu o le puipui, o lea e le oʻo ai ma `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Fuafua le `Vec` ile nofoaga ina ia tutusa le `len` ile `new_len`.
    ///
    /// Afai e sili atu le `new_len` nai lo le `len`, o le `Vec` e faʻalauteleina e le eseʻesega, ma isi avanoa taʻitasi e faʻatumuina i le `value`.
    ///
    /// Afai e itiiti ifo nai lo `new_len` `len`, o loo truncated le `Vec`.
    ///
    /// Lenei metotia manaʻomia `T` e faʻatino [`Clone`], ina ia mafai ai ona faʻapipiʻi le pasi pasi.
    /// Afai e te manaʻomia tele fetuʻunaʻiga (pe manaʻo e te faʻamoemoe i le [`Default`] ae le o le [`Clone`]), faʻaaoga le [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Clones ma faʻaopopo elemeni uma i se fasi i le `Vec`.
    ///
    /// Faʻapipiʻi luga o le fasi `other`, faʻamalama taʻitasi elemeni, ona faʻaopopo lea ile `Vec`.
    /// O le `other` vector ua pasi i totonu i le faʻasologa.
    ///
    /// Manatua e lava lenei e tasi o galuega tauave e pei [`extend`] vagana ai ua faapitoa i le galuega ma le fasi ae.
    ///
    /// Afai ma pe a maua e le Rust faʻapitoa lenei galuega e ono faʻaleaogaina (ae avanoa pea).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// E kopiina elemeni mai le `src` e oʻo atu i le iʻuga o le vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` faʻamaonia o le tuʻuina atu avanoa e aoga mo le faʻavasegaina o oe lava
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// O lenei tulafono lautele `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Faʻalautele le vector e le `n` faʻatauaina, faʻaaogaina le foaʻi afi.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Faʻaaoga SetLenOnDrop e galue faataamilo i mea e le iloa ai e le tuʻufaʻatasiga le faleoloa e ala ile `ptr` e oʻo i le self.set_len() aua le faʻaigoa.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Tusi elemene uma vagana ai le mulimuli
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Faʻateleina le uumi i laasaga uma i le tulaga next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // E mafai ona tatou tusi le elemene mulimuli tonu e aunoa cloning fua
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // Len seti e le lautele leoleo
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Aveʻese sosoʻo faʻasolosolo elemeni i le vector e tusa ai ma le [`PartialEq`] trait faʻatinoina.
    ///
    ///
    /// Afai o le vector ua faʻavasegaina, o lenei aveʻesea uma duplicates.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Totonu metotia ma galuega
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` manaʻomia le aoga faʻasino
    /// - `self.capacity() - self.len()` tatau ona `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - Len ua faʻateleina na o le maeʻa amataina elemene
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - Tagata faʻamaonia e faʻamaonia o le src o se faʻailoga talafeagai
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - O le elemene na faʻatoa amataina ile `MaybeUninit::write`, o lea e lelei ai le faʻateleina ole len
            // - Len ua faʻateleina i le maeʻa ai elemeni uma e puipuia le leaks (tagai i le lomiga #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - Tagata faʻamaonia e faʻamaonia o le `src` o se faʻailoga talafeagai
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Uma vae ua foafoaina mai mau tulaga ese fasi ('&mut [_]') ina ia latou aloaia ma faia le fesiliaʻi.
            //
            // - Elemene o: Kopi o lea e OK le kopiina i latou, aunoa ma le faia o se mea ma le uluaʻi taua
            // - `count` e tutusa ma le len o le `source`, o lea e aoga ai le mafuaʻaga mo `count` faitau
            // - `.reserve(count)` Faʻamaonia o le `spare.len() >= count` o lea e leai se aoga mo `count` tusitusi
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - O elemene na faʻatoa amataina e `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Galue masani a le trait mo Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): ma cfg(test) o le natura `[T]::to_vec` metotia, lea e manaʻomia mo lenei metotia faʻamatalaga, e le avanoa.
    // Nai lo o faaaogaina le `slice::to_vec` galuega tauave lea e na o le maua ma cfg(test) NB vaai i le module slice::hack i slice.rs mo nisi faamatalaga
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // faʻapa'ū soʻo se mea e le mafai ona faʻaui
        self.truncate(other.len());

        // self.len <= other.len ona o le truncate luga, ina ia le fasi iinei i taimi uma-tuaoi.
        //
        let (init, tail) = other.split_at(self.len());

        // toe faʻaaoga mea taua o loʻo iai allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Faatupu ai se taumafaina iterator, o, o se tasi lea e tuleia i taua taitasi mai le vector (mai le amataga i le faaiuga).
    /// E le mafai ona faʻaaogaina le vector pe a uma ona valaʻau lenei.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s e iai ituaiga String, ae le &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // lau auala e faʻatagaina ai e le SpecFrom/SpecExtend faʻatinoga faʻatinoina pe a leai se toe faʻaleleia atili e apalai ai
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // O le tulaga lea mo le lautele lautele.
        //
        // Lenei gaioiga tatau ona tutusa le amio lelei o le:
        //
        //      mo aitema i totonu o iterator {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // e le mafai ona faatumulia NB talu mai tatou te maua e alloc le va tuatusi
                self.set_len(len + 1);
            }
        }
    }

    /// Fausia se vaeluaina iterator e suia le faʻatulagaina laina i le vector ma le tuuina `replace_with` iterator ma maua ai le aveeseina aitema.
    ///
    /// `replace_with` E le manaʻomia le tutusa o le umi ma `range`.
    ///
    /// `range` ua aveesea e tusa lava pe le iterator e le susunuina seia oo i le iuga.
    ///
    /// E leʻo faʻamaonia mai pe fia ni elemeni o loʻo aveʻesea mai le vector pe a faʻalu atu le aofaʻi o le `Splice`.
    ///
    /// E faʻatoa faʻaumatia le input iterator `replace_with` peʻa paʻu le tau `Splice`.
    ///
    /// E sili lea pe a fai:
    ///
    /// * Le siʻusiʻu (elemene i le vector ina ua uma `range`) o avanoa,
    /// * poʻo le `replace_with` e maua ai ni mea laʻititi pe tutusa nai lo le umi o le 'lautele'
    /// * po o le maualalo noatia o lona `size_hint()` o tonu.
    ///
    /// A leai, o se vector le tumau e tuʻuina atu ma o le siʻu e faʻalua faʻaluʻi.
    ///
    /// # Panics
    ///
    /// Panics pe a fai o le amataga ua sili atu nai lo le iʻuga itu pe afai o le pito mulimuli e sili atu nai lo le umi o le vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Fausia se iterator lea e faʻaaogaina se tapunia e fuafua ai pe o se elemeni tatau ona aveʻesea.
    ///
    /// Afai o le tapunia toe foi moni, lea o le elemeni e aveʻese ma maua.
    /// Afai o le tapunia toe foi sese, o le elemene o le a tumau pea i le vector ma o le a le maua mai e le iterator.
    ///
    /// Faʻaogaina o lenei metotia e tutusa ma le nei code:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // lau code iinei
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Ae e faigofie ona faʻaaoga le `drain_filter`.
    /// `drain_filter` e sili atu ona lelei, aua e mafai ona backshift elemene o le laina i le tele.
    ///
    /// Manatua o le `drain_filter` e faʻatagaina foi oe e suia uma elemeni i le faʻamamaina tapunia, tusa lava pe e te filifili e teu pe aveʻese.
    ///
    ///
    /// # Examples
    ///
    /// Vaeluaina se autau i evens ma soo se tulaga faigata, reusing le faasoasoaina uluai:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Leoleo faasaga ia i tatou le faʻasalalauina (leak amplification)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Faalautele le faatinoga o kopi elemene mai o mau i luma o le tulei i latou i luga o le Vec.
///
/// O lenei faʻatinoga e faʻapitoa mo fasi fasi, lea e faʻaaogaina ai le [`copy_from_slice`] e faʻaopopoina atoa le fasi i le taimi e tasi.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Faʻaaogaina faʻatusatusaga o vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Faʻaaogaina le okaina o vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // faʻaaoga mataua mo [T] faʻaaoga se fasi fasi e faʻasino i elemene o le vector o se sili ona vaivai ituaiga manaʻomia;
            //
            // mafai ona 'alofia fesili o le faʻamaoni i nisi tulaga
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec 'uʻuina translocation
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Faatupuina ai se gaogao `Vec<T>`.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: suʻega toso i le libstd, lea e mafua ai mea sese iinei
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: suʻega toso i le libstd, lea e mafua ai mea sese iinei
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Mauaina atoa mea o le `Vec<T>` o se faʻavasega, pe a fai o lona tele e fetaui lelei ma le faʻatulagaina o le faʻavasega.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Afai e le tutusa le umi, e toe foi mai le sao i `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// A faʻapea e lelei oe i le naʻo le maua o se nauna i le `Vec<T>`, e mafai ona e valaʻau muamua i le [`.truncate(N)`](Vec::truncate).
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // SAOGALEMU: `.set_len(0)` e masani lava leo.
        unsafe { vec.set_len(0) };

        // SAFETI: O le 'Vec`'s point poʻo faʻatonutonu e masani ona fetaui lelei, ma
        // le aafia i lenei suiga e manaomia e le autau o le lava lea e tasi e pei o le mea.
        // Na matou siaki muamua atu o lava a matou aitema.
        // O aitema o le a le faʻalua-pa'ū pei o le `set_len` taʻu atu i le `Vec` aua le faʻapaʻuina foi i latou.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}