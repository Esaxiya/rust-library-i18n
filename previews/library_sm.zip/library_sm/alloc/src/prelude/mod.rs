//! Le vaegatupe Prelude
//!
//! O le mafuaʻaga o lenei vaega o le faʻaitiitia lea o oloa mai fafo e masani ona faʻaaogaina o le `alloc` crate i le faʻaopopoina o le glob import i le pito i luga o modules.
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;