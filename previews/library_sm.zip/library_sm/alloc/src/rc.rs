//! Nofofua-filo faʻasino-faitauga faʻailoga.'Rc' tu mo le 'Faʻasino
//! Counted'.
//!
//! O le ituaiga [`Rc<T>`][`Rc`] e tuʻufaʻatasia ai le umiaina o le taua o le ituaiga `T`, faʻasoa i le faʻaputuga.
//! Invoking [`clone`][clone] luga [`Rc`] maua ai se fou faʻasino i le tutusa faʻasoaga i le faʻaputuga.
//! A o le [`Rc`] faʻasino mulimuli i se faʻasoaga tuʻuina atu ua faʻaleagaina, o le tau aoga o loʻo teuina i lena faʻasoaga (e masani ona faʻaigoaina o le "inner value") o loʻo pa'ū foi.
//!
//! O fefaʻasoaʻiga fesoʻotaʻiga i le Rust faʻaleaogaina le suia e ala i le le masani ai, ma [`Rc`] e leai se tuusaunoa: oe le mafai masani ona maua se suia faʻavasega i se mea i totonu o le [`Rc`].
//! Afai e te manaomia mutability, tuu se [`Cell`] po [`RefCell`] i totonu o le [`Rc`];vaʻai [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] Faʻaogaina numera e le o ni atomika
//! O lona uiga o le ova i lalo e matua maualalo lava, ae o le [`Rc`] e le mafai ona lafoina i le va o filo, ma o le mea lea [`Rc`] e le faʻaogaina [`Send`][send].
//! O lona iʻuga, o le Rust faʻaputuina o le a siaki *i le tuʻufaʻatasia taimi* e te le o lafoina ['Rc`] s i le va o filo.
//! Afai e te manaʻomia tele-filo, atomic faʻasino faitauga, faʻaaoga [`sync::Arc`][arc].
//!
//! O le [`downgrade`][downgrade] auala e mafai ona faʻaaogaina e fausia ai le leai-pule [`Weak`] faʻasino faasino.
//! E mafai ona avea le [`Weak`] pointer [`faʻafouga '][faʻaleleia] i le [`Rc`], ae o le a toe faʻafoʻi mai le [`None`] pe a fai o le tau na teuina i le faʻasoaga ua maeʻa faʻapaʻu.
//! I se isi faaupuga, `Weak` faʻailoga e le taofia le taua i totonu o le faʻasoaga ola;ae ui i lea, latou *faia* tausia le faʻasoaga (o le faleʻoloa fesoasoani mo le tau i totonu) ola.
//!
//! O le taʻamilosaga i le va o [`Rc`] faʻailoga o le a le mafai lava ona faʻateʻaina.
//! Mo lenei mafuaʻaga, [`Weak`] e faʻaaogaina e gagau ai taʻamilosaga.
//! Mo se faʻataʻitaʻiga, e mafai ona maua e le laau ni faʻailoga malosi [`Rc`] mai matua node i fanau, ma [`Weak`] faʻasino mai tamaiti i tua io latou matua.
//!
//! `Rc<T>` otometi dere rujukan i `T` (ala i le [`Deref`] trait), o lea e mafai ai ona e valaʻauina 'T' auala i luga o le taua o le ituaiga [`Rc<T>`][`Rc`].
//! Ina ia aloese mai taʻutaʻuga feteʻenaʻi ma auala a le 'T`, o metotia a le [`Rc<T>`][`Rc`] lava ia e fesoʻotaʻi gaioiga, valaʻauina faʻaaogaina [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! Rc<T>O faʻatinoga ole traits pei ole `Clone` e mafai foi ona valaʻauina e faʻaaoga ai le tusipasi agavaa atoatoa.
//! Nisi tagata fiafia e faʻaaoga atoatoa agavaʻa faʻasologa, ae o isi e manaʻo e faʻaaoga metotia-valaʻau faʻasologa.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Metotia-valaau faʻasologa
//! let rc2 = rc.clone();
//! // Faʻamatalaga atoatoa agavaʻa
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] e le otometi-faʻaletonu ile `T`, aua o le tau i totonu atonu ua uma ona pa'ū.
//!
//! # Faʻamatalaga o faʻaupuga
//!
//! Fausiaina o se faʻamatalaga fou i le tutusa vaegatupe pei o loʻo i ai nei faitauga faʻatatau tusitusi ua maeʻa faʻaaogaina le `Clone` trait faʻatinoina mo [`Rc<T>`][`Rc`] ma [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // O syntaxes e lua o loʻo i lalo e tutusa.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a ma b lua tusi i le tutusa manatua nofoaga o le foo.
//! ```
//!
//! O le `Rc::clone(&from)` syntax e pito i sili ona manaia ona e faʻaalia manino ai le uiga o le tulafono.
//! I le faʻataʻitaʻiga i luga, o lenei syntax e faʻafaigofie ai ona vaʻaia o lenei tulafono o loʻo fausiaina se mau fou nai lo le kopiina atoa o le foo.
//!
//! # Examples
//!
//! Mafaufau i se ata faʻapitoa e iai le seti o le 'Gadget`s e anaina e le `Owner` foaʻi.
//! Matou te mananaʻo e fai la matou 'Gadget`s faʻasino i la latou `Owner`.E le mafai ona matou faia lenei mea i se anaina tulaga ese, aua e sili atu ma le tasi mea faigaluega e ono avea ma `Owner` lava e tasi.
//! [`Rc`] faʻatagaina matou e fefaʻasoaaʻi `Owner` i le va o le tele o 'Gadget`s, ma maua le `Owner` tumau faʻasoasoa pe a lava o soʻo se `Gadget` togi i ai.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... isi fanua
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... isi fanua
//! }
//!
//! fn main() {
//!     // Fausia se faʻasino-faitauga `Owner`.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Fausia `Gadget`s auai i `gadget_owner`.
//!     // O le faʻailoaina o le `Rc<Owner>` tatou te maua ai se faʻasino fou i le tutusa `Owner` faʻasoaga, faʻateleina le faitauga faitauga i le gaioiga.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Lafoaia la matou `gadget_owner` fesuiaʻi i le lotoifale.
//!     drop(gadget_owner);
//!
//!     // E ui lava i le pau o `gadget_owner`, te mafai lava ona tatou e lolomi mai ai le igoa o le `Owner` o le 'Gadget`s.
//!     // Talu ai na o le tasi le `Rc<Owner>` na matou faʻapaʻu i lalo, ae leʻo le `Owner` e faʻasino i ai.
//!     // Afai lava e i ai isi `Rc<Owner>` faʻasino i le tutusa `Owner` faʻasoaga, o le a tumau pea ola.
//!     // O le fanua vavalalata `gadget1.owner.name` galue aua `Rc<Owner>` otometi faʻaletonu i `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // I le faaiuga o le galuega tauave, ua faaumatia `gadget1` ma `gadget2`, ma faatasi ma i latou faitauina le mulimuli mau i lo tatou `Owner`.
//!     // Gadget Man ua faʻaleagaina foʻi.
//!     //
//! }
//! ```
//!
//! Afai e sui a matou manaʻoga, ma e manaʻomia foi ona mafai ona matou pasi mai le `Owner` i le `Gadget`, o le a tatou feagai ma faʻafitauli.
//! O le [`Rc`] faʻasino mai `Owner` i le `Gadget` faʻalauiloa se taamilosaga.
//! O lona uiga o a latou faʻamaumauga faitau e le mafai ona oʻo i le 0, ma o le faʻasoaga e le mafai ona faʻaleagaina:
//! se faʻamanatuga ua galo.Ina ia mafai ona fealuai i lenei, e mafai ona tatou faʻaaogaina le [`Weak`] faʻasino.
//!
//! O le Rust e faʻafaigata ai lava ona faia lenei matasele i le mea muamua.Ina ia iu i le tulaga faatauaina e lua i lena taimi i le tasi i le isi, o se tasi oi latou e manaomia e avea mutable.
//! E faigata tele lenei mea ona o le [`Rc`] e faʻamalosia le manatuaina o mea e ala i le tuʻuina atu o faʻasoaga faʻasino i le tau e afifi ai, ma o mea nei e le faʻatonuina suiga tuʻusaʻo.
//! E manaomia ona tatou afifi le vaega o le taua tatou te mananao e mutate i se [`RefCell`], lea e saunia *totonu mutability*: a auala e ausia mutability e ala i se faasinomaga faasoa.
//! [`RefCell`] faamalosia le tulafono o nonogatupe a Rust i le taimi na faaleaga ai.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... isi fanua
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... isi fanua
//! }
//!
//! fn main() {
//!     // Fausia se faʻasino-faitauga `Owner`.
//!     // Manatua ua tatou tuʻuina le 'Owner`'s vector o le' Gadget` i totonu o le `RefCell` ina ia mafai ai ona tatou suia e ala i le tufatufaina faʻasino.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Fausia `Gadget`s auai i `gadget_owner`, pei o muamua.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Faʻaopopo le 'Gadget`s ia latou `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` maeʻa aitalafu faʻaiʻu ii.
//!     }
//!
//!     // Faʻaletonu luga o a matou `Gadget`s, lolomiina o latou auiliiliga mai.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` o le `Weak<Gadget>`.
//!         // Talu ai `Weak` faasino e le mafai ona mautinoa le faʻasoaga o loʻo i ai pea, tatou manaʻomia le valaʻau `upgrade`, lea toe faafoi mai le `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // I lenei tulaga matou te iloa o loʻo iai pea le faʻasoaga, o lea tatou naʻo `unwrap` le `Option`.
//!         // I se polokalama sili atu ona faigata, oe ono manaʻomia le alualu i luma sese mea mo se `None` iʻuga.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // I le faaiuga o le gaioiga, `gadget_owner`, `gadget1`, ma `gadget2` ua faʻaleagaina.
//!     // O loo i ai i le taimi nei e leai se malosi vae (`Rc`) i le gadgets, ina ua faaumatia i latou.
//!     // Lenei zeroes le faʻasino faitauga i Gadget Man, o lea na faʻaleagaina ai foi o ia.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Ole repr(C) ile future-faʻamaonia e faʻatatau ile toe faʻafouga ole fanua, e ono faʻalavelave ile [into|from]_raw() sefe o ituaiga feaveaʻi i totonu.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// O se faʻamatalaga fesoʻotaʻiga-faitau toʻatasi 'Rc' tu mo le 'Faʻasino
/// Counted'.
///
/// Vaʻai le [module-level documentation](./index.html) mo nisi faʻamatalaga.
///
/// O metotia masani a le `Rc` e fesoʻotaʻi uma gaioiga, o lona uiga e tatau ona e valaʻauina i latou pei eg, [`Rc::get_mut(&mut value)`][get_mut] nai lo `value.get_mut()`.
/// Lenei aloese mai feteʻenaʻiga ma metotia o le totonu ituaiga `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Lenei unsafety e lelei aua a o ola lenei Rc ua tatou mautinoa o le totonu faasino tonu e aoga.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Fausia se `Rc<T>` fou.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // O loʻo i ai le faʻasino vaivai faʻatauaina e uma malosi faʻasino, lea e mautinoa ai o le vaivai faʻaleagaina e le faʻasaʻolotoina le faʻasoaga a o le malosi faʻaleaga o loʻo tamoʻe, tusa lava pe o le vaivai faʻasino teuina i totonu o le malosi.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Fausia se `Rc<T>` fou faʻaaogaina se vaivai faʻasino ia te ia lava.
    /// Taumafai e faʻaleleia le vaivai faʻasino ae leʻi amataina lenei galuega toe faʻatonu o le a mafua ai le `None` taua.
    ///
    /// Ae ui i lea, o le vaivai faʻamatalaga mafai ona faʻavasega saoloto ma teuina mo le faʻaaogaina i se taimi mulimuli ane.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... tele fanua
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Fausia le totonu i le "uninitialized" setete ma le tasi vaivai faʻasino.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // E taua tatou te le lafoa le umiaina o le vaivai faʻasino, a leai o le manatuaina mafai ona faʻasaʻolotoina i le taimi `data_fn` toe foʻi.
        // Afai matou te manaʻo moni e pasi le umiaina, e mafai ona tatou faia se faʻaopopo vaivai faʻasino mo matou lava, ae o lenei mea o le a mafua ai i faʻaopoopoga faʻafouina i le vaivai faitau faʻamaumauga e ono le manaʻomia se isi faiga.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Malosiaga faʻasino tusi tatau ona umiaina faʻatasi se fefaʻasoaaʻi vaivai vaivaiga, o lea aua le tamoʻe le faʻaumatia mo la tatou tuai vaivaiga faʻasino.
        //
        mem::forget(weak);
        strong
    }

    /// Fausia se `Rc` fou ma mea e leʻo faʻaaogaina.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Faʻamalolo le amataga
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Fausia se fou `Rc` ma mataupu uninitialized, faatasi ai ma le manatu ua faatumuina i bytes `0`.
    ///
    ///
    /// Vaʻai [`MaybeUninit::zeroed`][zeroed] mo faʻataʻitaʻiga o le saʻo ma le le saʻo o le faʻaaogaina o lenei metotia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Fausia se `Rc<T>` fou, toe faʻafoʻi se mea sese pe a fai ua le aoga le faʻasoaga
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // O loʻo i ai le faʻasino vaivai faʻatauaina e uma malosi faʻasino, lea e mautinoa ai o le vaivai faʻaleagaina e le faʻasaʻolotoina le faʻasoaga a o le malosi faʻaleaga o loʻo tamoʻe, tusa lava pe o le vaivai faʻasino teuina i totonu o le malosi.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Fausia se `Rc` fou ma mea e leʻo faʻaaogaina, toe faafoi se mea sese pe a fai ua le manuia le faasoasoaga
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Faʻamalolo le amataga
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Fausia se `Rc` fou ma mea e leʻo faʻaaogaina, ma le faʻamanatuina e faʻatumuina ile `0` bytes, toe faʻafoʻi mai se mea sese pe a fai ua le manuia le faʻasoaga.
    ///
    ///
    /// Vaʻai [`MaybeUninit::zeroed`][zeroed] mo faʻataʻitaʻiga o le saʻo ma le le saʻo o le faʻaaogaina o lenei metotia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Fausia se `Pin<Rc<T>>` fou.
    /// Afai e le faʻatinoina e `T` le `Unpin`, ona faʻapipiʻi lea o le `value` i le mafaufau ma le mafai ona minoi.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Faʻafoʻi le tau i totonu, pe a fai o le `Rc` e tasi lava le tasi faʻamatalaga malosi.
    ///
    /// A leai, ua toe foi se [`Err`] ai i lea lava `Rc` na pasia i totonu.
    ///
    ///
    /// Lenei o le a alualu i luma tusa lava pe i ai ni tulaga ese vaivai faʻasino.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // kopi o le mea o lo o aofia

                // Faʻailoa i Vaivaʻa e le mafai ona faʻalauiloaina i latou e ala i le faʻaitiitia o le malosi faitauga, ona aveʻese lea o le "strong weak" faʻasino manino ae o loʻo tago foi i le paʻu o le mafaufau i le naʻo le fausiaina o se Vaivai vaivai.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Fausia se fasi tusi faitau-faitau fou ma mea e leʻo faʻaaogaina.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Faʻamalolo le amataga
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Fausia se fasi tusi faitau-faitau fou ma mea e leʻo faʻaaogaina, ma le mafaufau e faʻatumuina ile `0` bytes.
    ///
    ///
    /// Vaʻai [`MaybeUninit::zeroed`][zeroed] mo faʻataʻitaʻiga o le saʻo ma le le saʻo o le faʻaaogaina o lenei metotia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Tagata liliu mai i le `Rc<T>`.
    ///
    /// # Safety
    ///
    /// E pei o le [`MaybeUninit::assume_init`], e pule lava le tagata i le tagata e faʻamautinoa mai o le mea i totonu o le mea moni o loʻo i totonu o le amataga tulaga.
    ///
    /// Valaʻauina o lenei pe a fai o le mataupu e leʻi maeʻa faʻamaonia mafuaʻaga vave le faʻauiga amioga.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Faʻamalolo le amataga
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Tagata liliu mai i le `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// E pei o le [`MaybeUninit::assume_init`], e pule lava le tagata i le tagata e faʻamautinoa mai o le mea i totonu o le mea moni o loʻo i totonu o le amataga tulaga.
    ///
    /// Valaʻauina o lenei pe a fai o le mataupu e leʻi maeʻa faʻamaonia mafuaʻaga vave le faʻauiga amioga.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Faʻamalolo le amataga
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Faʻauma le `Rc`, faʻafoʻi mai le faʻailoga na afifi.
    ///
    /// Ina ia aloese mai le manatuaina o le leak le tatau ona faʻafoʻi le faʻasino i se `Rc` faʻaaogaina [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Tuʻuina atu se faʻasino tonu i faʻamatalaga.
    ///
    /// O faitauga e le afaina i soʻo se auala ma e le faʻaumatia le `Rc`.
    /// O le faʻasino tusi e aoga mo le umi e i ai malosi faitauga i le `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // SAFETY: E le mafai ona pasi i le Deref::deref poʻo le Rc::inner ona
        // e manaomia lenei e taofi provenance raw/mut e pei o eg
        // `get_mut` mafai ona tusi e ala i le faʻasino tusi pe a maeʻa le Rc toe maua mai i le `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Fausia se `Rc<T>` mai se faʻailoga masani.
    ///
    /// O le faʻailoga masani na tatau ona faʻafoʻi mai muamua e le telefoni i le [`Rc<U>::into_raw`][into_raw] lea e tatau ona tutusa le tele ma le faʻafetaui o le `U` e pei o le `T`.
    /// E faʻatauvaʻa moni lenei mea pe a fai o `U` o `T`.
    /// Manatua afai o `U` e le `T` ae tutusa le tele ma le faʻatulagaina, e pei lava o le faʻasalalauina o faʻamatalaga o ituaiga eseese.
    /// Vaʻai [`mem::transmute`][transmute] mo nisi faʻamatalaga pe o a tapulaʻa faʻatatau i lenei tulaga.
    ///
    /// O le tagata faʻaaogaina `from_raw` e tatau ona ia mautinoa o se faʻapitoa taua o `T` ua naʻo le faʻapa'ū tasi.
    ///
    /// O lenei galuega o le saogalemu ona e mafai ona taitai talafeagai le faaaogaina e manatua unsafety, e tusa lava pe afai e lei mauaina le `Rc<T>` toe foi mai.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Toe faʻafoʻi i le `Rc` e puipuia ai le tataʻu.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // O isi telefoni i le `Rc::from_raw(x_ptr)` o le a manatua-e le sefe.
    /// }
    ///
    /// // Na faʻasaolotoina le manatuaina ina ua alu ese le `x` i luga atu, o lea la ua taatitia nei `x_ptr`!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Suia le aveesea e maua ai le uluai RcBox.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Fausia se fou [`Weak`] faasino i lenei faʻasoasoaga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Ia mautinoa tatou te le o faia se tulaga vaivai Vaivai
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Maua le numera o [`Weak`] faʻasino i lenei faʻasoaga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Mauaina le numera o malosi (`Rc`) faʻasino i lenei faʻasoaga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Faʻafoʻi `true` peʻa leai ni isi `Rc` poʻo le [`Weak`] faʻasino i lenei faʻasoaga.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Faʻafoʻi mai se faʻamatalaga sui i le `Rc`, pe a leai seisi `Rc` poʻo le [`Weak`] faʻasino i le tutusa faʻasoaga.
    ///
    ///
    /// Faʻafoʻi [`None`] i se isi itu, aua e le sefe le suia o le tuʻufaʻatasiga o tau.
    ///
    /// Vaʻai foʻi ile [`make_mut`][make_mut], lea e [`clone`][clone] le tau i totonu pe a iai isi faʻasino.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Faʻafoʻi mai se faʻamatalaga sui i totonu o le `Rc`, e aunoa ma se siaki.
    ///
    /// Vaʻai foʻi ile [`get_mut`], e sefe ma e siaki talafeagai.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Soʻo seisi lava `Rc` poʻo le [`Weak`] faʻasino i le faʻasoaga e tasi e le tatau ona tuʻufaʻaseseina mo le umi o le nonogatupe toe faʻafoʻi.
    ///
    /// O le mea taua lea pe a leai ni faʻasino faapena, mo se faʻataʻitaʻiga tonu lava pe a maeʻa le `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Matou te faʻaeteete ia *aua* faia se faʻamatalaga e ufiufi ai le "count" fanua, aua o lenei mea e feteʻenaʻi ma le faʻaaogaina o faʻamaumauga faitauga (eg
        // e `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Toe foi `true` pe afai o le lua 'Rc`s faasino atu i le faasoasoaina e tasi (i se uaua tutusa [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Faia se suia suia i le `Rc` tuuina atu.
    ///
    /// Afai e i ai isi faʻailoga `Rc` i le tutusa faʻasoaga, ona `make_mut` o le [`clone`] le tau i totonu i se vaegatupe fou e mautinoa ai le tutoʻatasi ona anaina.
    /// Lenei e taua foi o le faʻamau i luga o tusitusiga.
    ///
    /// Afai e leai ni isi faʻailoga `Rc` i lenei vaegatupe, ona faʻateʻa loaina lea o [`Weak`] faʻasino i lenei faʻasoaga.
    ///
    /// Vaʻai foi i le [`get_mut`], o le a le manuia ae le o le faʻavasega.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Le mafai ona faʻailoaina se mea
    /// let mut other_data = Rc::clone(&data);    // O le a le toefaʻailogaina faʻamaumauga i totonu
    /// *Rc::make_mut(&mut data) += 1;        // Faʻamatalaga pito i totonu o leone
    /// *Rc::make_mut(&mut data) += 1;        // Le mafai ona faʻailoaina se mea
    /// *Rc::make_mut(&mut other_data) *= 2;  // Le mafai ona faʻailoaina se mea
    ///
    /// // O lenei `data` ma `other_data` faʻasino i vaegatupe eseese.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] manatu o le a faʻateʻaina:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Gotta clone the data, o loʻo iai isi Rcs.
            // Muaʻi tuʻuina atu le faʻamanatuga e faʻatagaina ai le tusia saʻo o le faʻatulagaina o tau.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // E naʻo le gaoi o faʻamaumauga, naʻo le pau a le mea o Weaks
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Aveʻese lemu malosi-vaivai ref (leai se mea e fausia ai se pepelo Vaivai vaivai iinei-matou te iloa isi Vaivai mafai ona faʻamamaina mo matou)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // O lenei le saogalemu e lelei lava aua ua mautinoa tatou o le faʻasino tusi na toe foʻi mai o le *pau* faʻasino tusi e toe faʻafoʻi ia T.
        // O la matou faitauga faʻamaoniga ua mautinoa e avea ma 1 i lenei taimi, ma matou manaʻomia le `Rc<T>` lava ia e avea `mut`, o lea matou te toe faʻafoʻi atu ai na o le mafai faʻasino i le faʻasoaga.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Taumafai e faʻanofo le `Rc<dyn Any>` i se sima ituaiga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Allocates se `RcBox<T>` ma lava avanoa mo se taua i totonu mafai-unsized le mea ei ai le taua i le faatulagaga ua tuuina atu.
    ///
    /// O le gaioiga `mem_to_rcbox` e valaʻau ma faʻamaumauga faʻasino ma e tatau ona toe faʻafoʻi mai le (ono gaʻo)-pusa mo le `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Fuafua faʻatulagaina faʻaaoga ai le faʻatulagaina taua faʻatulagaina.
        // I le taimi muamua, sa fuafuaina le faʻatulagaina i luga o le faʻaaliga `&*(ptr as* const RcBox<T>)`, peitaʻi o lenei mea na fausia ai se faʻasesega vaʻai (vaʻai #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Tuʻuina atu le `RcBox<T>` ma lava le avanoa mo le ono-unsized faʻatauaina totonu pe a fai o le tau na i ai le faʻatulagaina saunia, toe faʻafoʻi se mea sese peʻa faʻapea ua le aoga.
    ///
    ///
    /// O le gaioiga `mem_to_rcbox` e valaʻau ma faʻamaumauga faʻasino ma e tatau ona toe faʻafoʻi mai le (ono gaʻo)-pusa mo le `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Fuafua faʻatulagaina faʻaaoga ai le faʻatulagaina taua faʻatulagaina.
        // I le taimi muamua, sa fuafuaina le faʻatulagaina i luga o le faʻaaliga `&*(ptr as* const RcBox<T>)`, peitaʻi o lenei mea na fausia ai se faʻasesega vaʻai (vaʻai #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Faasoasoa mo le faatulagaga.
        let ptr = allocate(layout)?;

        // Faʻailoa muamua le RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Allocates se `RcBox<T>` ma lava avanoa mo se taua i totonu unsized
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Faʻasoa mo le `RcBox<T>` faʻaaogaina le tau aoga.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopi taua o bytes
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Faʻasaʻoloto le faʻasoaga e aunoa ma le faʻapaʻuina o mea i totonu
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Tuʻuina atu le `RcBox<[T]>` ma le umi tuʻuina atu.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Kopi elemene mai fasi i totonu o le Rc <\[T\]> fou
    ///
    /// Le saogalemu aua o le tagata e valaʻau e tatau ona avea le anaina pe fusifusia `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Fausia se `Rc<[T]>` mai se iterator lauiloa o se tasi tele.
    ///
    /// O amioga e le faʻamatalaina e tatau ona sese le lapopoa.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic leoleo a o oʻo i le faʻailoaina o elemene T.
        // I le tulaga o le panic, o elemeni na tusia i totonu o le fou RcBox o le a faʻapaʻuina, ona faʻamatuʻuina lea o le manatuaina.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Faasino i le muamua elemene
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Ua manino.Faʻagalo le leoleo ina neʻi faʻasaoloto le RcBox fou.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Faʻapitoa trait faʻaaogaina mo `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Faʻapapa le `Rc`.
    ///
    /// Lenei o le a faʻaititia ai le malosi faitauga faʻamatalaga.
    /// Afai o le malosi faʻasino faitau aofaʻi aulia leai na o isi faʻasino (pe a iai) o [`Weak`], o lea tatou `drop` le tau i totonu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // E le lolomiina se mea
    /// drop(foo2);   // Lolomi "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // faaleaga le mea aofia ai
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // aveʻese le faʻailo "strong weak" faʻailo nei ua matou faʻaleagaina mea i totonu.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Faia se faʻailoga o le `Rc` faʻasino.
    ///
    /// Lenei faia se isi faʻasino i le tutusa faʻasoaga, faʻateleina le malosi faitauga faitauga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Faatupu ai se `Rc<T>` fou, faatasi ai ma le taua `Default` mo `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack e faʻataga faʻapitoa i `Eq` e ui lava o `Eq` ei ai se metotia.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// O loʻo matou faia lenei faʻapitoa iinei, ae le o se sili atu lautele optimization ile `&T`, aua e faʻapea e faʻaopopo se tau ile uma tutusa siakiina i ref.
/// Matou te manatu o le `Rc`s e faʻaaoga e faʻaputu tele ai tau, e telegese ona faʻapipiʻi, ae mamafa foi e siaki ai le tutusa, mafua ai ona faigofie ona totogi le tau lea.
///
/// E foliga mai e lua foʻi `Rc` clones, e faʻasino i le tau e tasi, nai lo le lua `&T`s.
///
/// E mafai ona tatou faia lenei mea pe a fai o `T: Eq` o se `PartialEq` atonu e ono faʻaletonu lava.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Tutusa mo lua Rc`s.
    ///
    /// Lua 'Rc`s e tutusa pe afai e tutusa o latou tulaga faatauaina i totonu, e tusa lava pe latou teuina i faasoasoa eseese.
    ///
    /// A faʻapea e faʻaaoga `T` `Eq` (o lona uiga o le fesuiaʻiga o le tutusa), lua Rc`s o loʻo faʻasino i le tutusa tufatufaina e tutusa tutusa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Le tutusa mo lua `Rc`s.
    ///
    /// Lua `Rc`s e le tutusa pe a fai o latou tau i totonu e le tutusa.
    ///
    /// A faʻapea e faʻaaoga `T` `Eq` (o loʻo faʻaalia ai le fesuisuiaʻi o le tutusa), lua Rc`s o loʻo faʻasino i le tufatufaga tutusa e le tutusa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Faʻatusatusaga faʻapitoa mo lua Rc`s.
    ///
    /// O le lua faʻatusatusa i le valaʻau `partial_cmp()` i luga o latou taua.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Iti-i lo le faʻatusatusaina mo lua Rc`s.
    ///
    /// O le lua faʻatusatusa i le valaʻau `<` i luga o latou taua.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// 'Itiiti pe tutusa i le' faʻatusatusaga mo lua Rc`s.
    ///
    /// O le lua faʻatusatusa i le valaʻau `<=` i luga o latou taua.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Sili atu-nai lo faʻatusatusaga mo lua Rc`s.
    ///
    /// O loʻo faʻatusatusa ile lua ile valaʻauina ole `>` ile latou itu taua i totonu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 'Sili atu pe tutusa i le' faʻatusatusaga mo lua Rc`s.
    ///
    /// O loʻo faʻatusatusa ile lua ile valaʻauina ole `>=` ile latou itu taua i totonu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Faatusatusaga mo le lua 'Rc`s.
    ///
    /// E lua ua faatusaina i le valaauina `cmp()` i latou tulaga faatauaina i totonu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Faʻasoa se fasi pepa faʻasino ma faitau e faʻatumu i le faʻailoaina o 'v` aitema.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Faʻasoa se fasi manoa faʻasino-faitau ma kopi `v` i totonu.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Faʻasoa se fasi manoa faʻasino-faitau ma kopi `v` i totonu.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Faʻaliliu se atigipusa mea i se fou, faitauga faitauga, faʻasoasoa.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Faʻavasega se fasi tusi faʻasino ma faitau le 'v' i totonu.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Faʻatagaina le Vec e faʻasaoloto lona mafaufau, ae aua le faʻaleagaina ana mea i totonu
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Aveina elemeni taʻitasi i le `Iterator` ma aoina i totonu o le `Rc<[T]>`.
    ///
    /// # faatinoga o Galuega uiga
    ///
    /// ## O le mataupu lautele
    ///
    /// I le tulaga aoao, aoina i `Rc<[T]>` ua faia e aoina muamua i se `Vec<T>`.Lona uiga, pe a tusia mea nei:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// lenei amio e pei o tatou tusia:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // O le vaega muamua o faʻasoasoaga e tupu ii.
    ///     .into(); // O le lona lua vaegatupe mo `Rc<[T]>` tupu iinei.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Lenei o le a tuʻuina atu i le tele o taimi e manaʻomia ai mo le fausiaina o le `Vec<T>` ma ona vaevaeina faʻatasi mo le liliuina o le `Vec<T>` i le `Rc<[T]>`.
    ///
    ///
    /// ## Iterators o le iloa umi
    ///
    /// A faʻapea e faʻaaoga lau `Iterator` `TrustedLen` ma e tusa lona aofaʻi, e tasi le faʻasoaga e faia mo le `Rc<[T]>`.Faataitaiga:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Naʻo le tasi le vaegatupe e tupu iinei.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Faʻapitoa trait faʻaaogaina mo le aoina i `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // O le tulaga lea mo le `TrustedLen` faʻasolosolo.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SAOGALEMU: Tatou te manaomia ina ia mautinoa ai le iterator ei ai se umi tonu ma ua tatou maua.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Pau i tua i le faʻatinoina masani.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` o se faʻaliliuga o le [`Rc`] o loʻo ia te ia le le anaina faʻasino i le faʻasoasoaina faʻasoaga.O le vaegatupe e faʻaaoga e ala i le valaʻau i le [`upgrade`] i luga o le faʻasino o le `Weak`, lea e faʻafoʻi mai ai le ['Option`]`<`[' Rc`] '<T>> `.
///
/// Talu ai o le `Weak` faʻasino e le faitauina agai i le umiaina, o le a le taofia ai le tau o loʻo teuina i le faʻasoaga mai le pa'ū, ma `Weak` lava ia e leai ni faʻamaoniga e uiga i le tau o loʻo iai pea.
/// E faʻapea e ono faʻafoʻi mai le [`None`] pe a fai o le (`upgrade`] d.
/// Manatua peitaʻi o le `Weak` faʻasino *e* puipuia le faʻasoaga ia lava (o le faleʻoloa fesoasoani) mai le faʻasologa.
///
/// O le `Weak` faʻasino e aoga mo le tausia o se le tumau faʻasino i le vaegatupe faʻatautaia e [`Rc`] e aunoa ma le puipuia lona faʻatauaina totonu mai le lafoa.
/// O loʻo faʻaaogaina foi e puipuia ai faʻatonuga faʻasolosolo i le va o [`Rc`] faʻasino, talu ai o le tuʻufaʻatasia o le umiaina o faʻamatalaga e le faʻatagaina ai [`Rc`] ona faʻapaʻu.
/// Mo se faʻataʻitaʻiga, e mafai ona maua e le laau ni faʻailoga malosi [`Rc`] mai matua node i fanau, ma `Weak` faʻasino mai tamaiti i tua io latou matua.
///
/// O le auala masani e maua ai le `Weak` faʻasino o le valaʻau lea i le [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Lenei o le `NonNull` e faʻatagaina ai le faʻamautinoaina o le tele o lenei ituaiga i enums, ae e le o se talafeagai faʻasino faasino.
    //
    // `Weak::new` seti lenei i le `usize::MAX` ina ia le manaʻomia le faʻasoasoa avanoa i luga o le faaputuga.
    // le o se taua o le a maua lava se faasino moni ona ua i ai ia talafeagai RcBox e itiiti ifo i le 2.
    // Faʻatoa mafai lea pe a `T: Sized`;uns01e X01 leai se mea tauto.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Fausia se `Weak<T>` fou, aunoa ma le tuʻuina atu o se manatua.
    /// Valaʻau [`upgrade`] i luga o le toe faʻafoʻi taua maua pea [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Fesoasoani ituaiga e faʻatagaina le faʻaaogaina o faʻasino faitauga e aunoa ma le faia o ni faʻamatalaga e uiga i le faʻamatalaga fanua.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Faʻafoʻi mai se faʻasino tonu i le mea faitino `T` faʻasino e lenei `Weak<T>`.
    ///
    /// E faʻatoa aoga le faʻasino tusi pe a iai ni faʻamatalaga malosi.
    /// O le faʻasino tusi atonu e tautau, le faʻailoaina pe oʻo foʻi i le [`null`] i se isi itu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Faasino uma i le mea e tasi
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // O le malosi iinei e faʻaolaola, o lea e mafai ai lava ona tatou faʻaaoga le mea.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Ae le toe i ai.
    /// // E mafai ona tatou faia weak.as_ptr(), ae o le faʻaaogaina o le faʻasino tusi e taitai atu ai i amioga le faʻamatalaina.
    /// // assert_eq ("talofa", saogalemu {&*weak.as_ptr() })!;
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Afai o tautau le faʻasino, tatou toe faʻafoʻi saʻo le sentinel.
            // Lenei e le mafai ona avea ma se aoga tuatusi totogi, ona o totogi o le mea sili ia tutusa ma tutusa ma RcBox (usize).
            ptr as *const T
        } else {
            // SAFETY: afai o_dangling toe faʻafoʻi sese, o lona uiga o le faʻasino faʻailoga e faʻateʻaina.
            // O le totogi e ono paʻu i lalo i lenei taimi, ma e tatau ona tatou tausia moni, o lea ia faʻaaoga le vaʻai faʻatonu vaʻaia.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Faʻaumatia le `Weak<T>` ma liliuina i se faʻasino tonu.
    ///
    /// Lenei liua le vaivai faʻasino i se raw pointer, a o loʻo faʻasaoina pea le umiaina o le tasi vaivai faʻasino (o le vaivai faitauga e le suia e lenei faʻagaioiga).
    /// E mafai ona toe faʻafoʻi i le `Weak<T>` ma le [`from_raw`].
    ///
    /// O le tapulaa lava lea e tasi o le mauaina o le sini o le e faasino ai e pei o [`as_ptr`] faaaogaina.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Faʻaliliuina se faʻailoga masani na faia e [`into_raw`] i tua i le `Weak<T>`.
    ///
    /// Lenei mafai ona faʻaaogaina e maua saogalemu ai se faʻasino malosi (e ala i le valaʻau [`upgrade`] mulimuli ane) pe faʻasese le vaivai vai i le faʻapaʻuina o le `Weak<T>`.
    ///
    /// E manaomia le umia o se tasi o tusi vaivai (faatasi ai ma le tuusaunoaga o vae faia e [`new`], e pei o nei e leai lava se mea; galue pea le auala i latou).
    ///
    /// # Safety
    ///
    /// O le faʻasino tatau na mafua mai i le [`into_raw`] ma e tatau lava ona anaina lona ono vaivai faʻasino.
    ///
    /// E faʻatagaina ile numera malosi e 0 ile taimi ole valaʻauina ole mea lea.
    /// Ae ui i lea, o lenei e avea le umiaina o se tasi vaivai faʻasino taimi o loʻo avea nei ma faʻasino tonu (o le vaivai faitauga e le suia e lenei faʻagaioiga) ma o lea e tatau ai ona tuʻufaʻatasia ma se valaʻau muamua i le [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Faʻatamaia le faitauga vaivai mulimuli.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Tagai Weak::as_ptr mo mataupu i le auala e maua mai le faasino sao.

        let ptr = if is_dangling(ptr as *mut T) {
            // o se dangling Vaivai lenei.
            ptr as *mut RcBox<T>
        } else {
            // A leai, matou te mautinoa o le faʻasino tusi e sau mai le le mafaamatalaina Vaivaʻa.
            // SAFETY: data_offset e saogalemu e valaʻau ai, pei ptr faʻasino i se moni (ono paʻu) T.
            let offset = unsafe { data_offset(ptr) };
            // O le mea lea, matou te fesuiaʻia le faʻapalapala ina ia maua atoa le RcBox.
            // SAFETY: o le faʻasino na amata mai i se Vaivaiga, o lea o lenei offset e saogalemu.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SAFETI: ua matou toe maua mai le amataga Vaiva tusi, o lea e mafai ai ona fausia le Vaivai.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Taumafai e faʻaleleia le `Weak` faʻasino i le [`Rc`], tolopo le paʻuina o le tau i totonu pe a manuia.
    ///
    ///
    /// Faafoi [`None`] pe afai ua talu ona pau le tau i totonu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Lepeti le vae malosi uma.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Mauaina le numera o malosi (`Rc`) faʻasino faasino i lenei faʻasoaga.
    ///
    /// Afai na faia `self` faʻaaoga [`Weak::new`], o le a toe faafoi 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Maua le numera o `Weak` faʻasino faasino i lenei faʻasoaga.
    ///
    /// Afai e leai se malosi faʻailo tumau, o le a toe foi zero.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // toese le vaivai impltr ptr
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Faʻafoʻi `None` peʻa tautau le faʻasino ma e leai se tuʻuina atu `RcBox`, (ie, ina ua faia lenei `Weak` e `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Matou te faʻaeteete ia *aua* faia se faʻamatalaga e ufiufi ai le "data" fanua, aua o le fanua e ono suia faʻatasi (mo se faʻataʻitaʻiga, pe a paʻu le `Rc` mulimuli, o le faʻamaumauga fanua o le a tuʻu i lalo-nofoaga).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Faʻafoʻi `true` peʻa tusi le lua Vaivai i le tutusa faʻasoaga (tutusa ma [`ptr::eq`]), pe afai e le tusi faʻasino uma i soʻo se faʻasoaga (aua na fausiaina ma `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Talu ai o lenei faʻatusatusaina faʻailoga o lona uiga o le `Weak::new()` o le a tutusa le tasi i le isi, e ui lava latou te le tusi i se faʻasoaga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Faʻatusatusaina `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Faʻapaʻu le faʻasino tusi `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // E le lolomiina se mea
    /// drop(foo);        // Lolomi "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // o le vaivai faitau amata i le 1, ma o le a naʻo le alu i le zero pe a fai o le malosi uma faʻailoga na mouʻese.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Faia se faʻailoga o le `Weak` faʻasino e tusi i le tutusa faʻasoaga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Fausia se `Weak<T>` fou, vaeluaina manatua mo `T` e aunoa ma le amataina.
    /// Valaʻau [`upgrade`] i luga o le toe faʻafoʻi taua maua pea [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Na matou siakiina_add iinei e feutanaʻi ma le mem::forget ma le saogalemu.Ae faapito tonu lava
// afai e te mem::forget Rcs (poʻo Vaivaiga), e mafai ona oʻo i luga le ref-count, ona mafai ai lea ona e faʻasaʻoloto le faʻasoaga a o iai Rcs (poʻo Weaks) o loʻo iai.
//
// Matou te faʻapaʻuina talu ai o lenei o se matua leaga tulaga ua tatou le popole i le mea e tupu-leai se moni polokalama tatau ona mauaina lenei.
//
// Lenei e tatau ona le amanaʻiaina luga aua e te le manaʻomia e faʻapipiʻi nei tele i le Rust faʻafetai i le anaina ma minoi-semantika.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Matou te mananaʻo e faʻapaʻu i luga o le lolovaʻa nai lo le faʻapaʻuina o le tau.
        // O le faitauga faʻamaumauga o le a le avea ma zero pe a valaʻau lenei;
        // ae ui i lea, matou te tuʻuina i lalo se paʻu pepe iinei e faʻaali ai le LLVM i seisi mea e leiloa.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Matou te mananaʻo e faʻapaʻu i luga o le lolovaʻa nai lo le faʻapaʻuina o le tau.
        // O le faitauga faʻamaumauga o le a le avea ma zero pe a valaʻau lenei;
        // ae ui i lea, matou te tuʻuina i lalo se paʻu pepe iinei e faʻaali ai le LLVM i seisi mea e leiloa.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Maua le offset i totonu o le `RcBox` mo le totogiina tua o se faʻasino tusi.
///
/// # Safety
///
/// O le faʻasino tusi e tatau ona tusi i (ma i ai metadata aoga mo) se faʻamaoniga aoga muamua o T, ae o le T ua faʻatagaina e faʻateʻa.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Faʻasaʻo le le faʻamautuina le tau ile faʻaiuga ole RcBox.
    // Talu ai o RcBox o repr(C), o le a avea pea ma mulimuli fanua i le manatuaina.
    // SAFETY: talu ai na o le tasi ituaiga faʻamaʻaina mafai o fasi, trait mea,
    // ma fafo atu ituaiga, o le sao sao manaʻoga manaʻoga ua lava nei e faʻamalieina ai manaʻoga o align_of_val_raw;o se faʻatinoina auiliiliga o le gagana e ono le faʻamoemoeina i fafo atu o std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}