#![stable(feature = "wake_trait", since = "1.51.0")]
//! Ituaiga ma Traits mo le galue ma galuega soʻosoʻosaʻo.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Le faʻatinoina o le fafaguina o se galuega ile pule.
///
/// Lenei trait mafai ona faʻaaogaina e fausia ai se [`Waker`].
/// E mafai e le tagata faʻatonu ona faʻamatalaina le faʻatinoina o lenei trait, ma faʻaaoga lena mea e fausia ai se Waker e pasi atu i galuega o loʻo faʻatinoina i luga o lena tagata faʻatonu.
///
/// Lenei trait o se manatua-saogalemu ma ergonomic isi i le fausiaina o le [`RawWaker`].
/// E lagolagoina le masani a le faʻatinoina o le ata lea o faʻamatalaga na faʻaaoga e fafagu ai se galuega e teuina i totonu o le [`Arc`].
/// Nisi faʻatonu (aemaise i latou mo sisitema sisitema) le mafai ona faʻaaogaina lenei API, ma o le mafuaʻaga lea [`RawWaker`] i ai o se sui mo na faiga.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// O le autu `block_on` gaioiga e manaʻomia le future ma faʻatautaia ia maeʻa i luga o le filo nei.
///
/// **Note:** Lenei faʻataʻitaʻiga fefaʻatauaiga sao mo faigofie.
/// Ina ia mafai ona puipuia le feʻaveaʻina, o le gaosiaina-vasega faʻaogaina o le a manaʻomia foi e faʻatonutonu valaʻau vavalalata i le `thread::unpark` faʻapea foi ma faʻataʻoto o faʻatosinaga.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// O le fafagu e ala i luga le filo nei pe a valaauina.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Faia le future i le maeʻa i luga o le filo nei.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Faʻamau le future ia mafai ai ona palota.
///     let mut fut = Box::pin(fut);
///
///     // Fausia se tala fou e pasi atu i le future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Faia le future i le maeʻa.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Ala maia lenei galuega.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Ala i luga lenei galuega e aunoa ma le faʻaumatia le ala.
    ///
    /// Afai e lagolagoina e le faʻatonu se auala taugofie e ala ai e aunoa ma le faʻaaogaina o le tagata ala, e tatau ona faʻaleaogaina le auala lea.
    /// E faaletonu, e clones le [`Arc`] ma valaauina [`wake`] i le clone.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // SAFETY: O lenei e saogalemu aua raw_waker saogalemu fausiaina
        // o se RawWaker mai Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Lenei galuega tumaoti mo le fausiaina o se RawWaker o loʻo faʻaaogaina, nai lo
// vaʻai lenei i le `From<Arc<W>> for RawWaker` impl, ia mautinoa o le saogalemu o `From<Arc<W>> for Waker` e le faʻamoemoeina i luga o le saʻo trait lafoina, nai lo impls uma valaʻauina lenei gaioiga tuusao ma manino.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Faʻaopopo le faitauga faʻasino o le arc e faʻapipiʻi ai.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Ala i luga taua, siitia le Arc i le Wake::wake galuega
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Ala i luga e ala i le faʻasino, afifi le ala ala i le ManallyDrop e aloese mai le paʻuina i lalo
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Faʻaitiitia le faitauga faitauga o le Arc i luga o le pa'ū
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}