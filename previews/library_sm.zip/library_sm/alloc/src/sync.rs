#![stable(feature = "rust1", since = "1.0.0")]

//! Faʻamaumau-saogalemu faʻasino-faitauga faʻailoga.
//!
//! Vaʻai le [`Arc<T>`][Arc] faʻamaumauga mo nisi faʻamatalaga.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// O se tapulaa lemu i luga o le aofaʻi o faʻasino e ono faia i le `Arc`.
///
/// O le alu i luga aʻe o lenei tapulaʻa o le a faʻateʻa lau polokalame (e ui lava e le manaʻomia) i faʻamatalaga _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer e le lagolagoina pa manatua.
// Ina ia aloese mai le lelei lipoti lelei i le Arc/Vaivai faʻaoga faʻaaogaina atomika avega mo synchronization nai lo.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Se filo-saogalemu faʻasino-faitau faʻailoga.'Arc' tu mo le 'Atomically Reference Counted'.
///
/// O le ituaiga `Arc<T>` e maua ai le tufatufaina o le umiaina o le taua o le ituaiga `T`, faʻasoa i le faʻaputuga.Invoking [`clone`][clone] luga `Arc` maua ai se fou `Arc` faʻataʻitaʻiga, lea e faʻasino i le tutusa faʻasoaga i luga o le faʻaputuga e avea ma punavai `Arc`, aʻo faʻateleina le faitauga faitau.
/// A o le `Arc` faʻasino mulimuli i se faʻasoaga tuʻuina atu ua faʻaleagaina, o le tau aoga o loʻo teuina i lena faʻasoaga (e masani ona faʻaigoaina o le "inner value") o loʻo pa'ū foi.
///
/// Faasoa mau i lē faatagaina mutation e faaletonu Rust, ma `Arc` leai se tuusaunoaga: e le mafai ona maua e masani o se faasinomaga mutable i se mea i totonu o le `Arc`.Afai e te manaʻo e suia e ala i le `Arc`, faʻaaoga [`Mutex`][mutex], [`RwLock`][rwlock], poʻo se tasi o le [`Atomic`][atomic] ituaiga.
///
/// ## Filemu le saogalemu
///
/// E le pei o le [`Rc<T>`], e faʻaaogaina e le `Arc<T>` ni atika mo lona faitauga faʻasino.O lona uiga o le filo-saogalemu.O le le faʻamanuiaina o atomika faʻagaioiga e sili atu le taugata nai lo le masani ona ofi i totonu.Afai e te le o faʻasoaina faʻasoa-faitau aofaʻi i le va o filo, mafaufau e faʻaaoga [`Rc<T>`] mo lalo maualalo.
/// [`Rc<T>`] o se faaletonu saogalemu, ona o le a maua ai so o se taumafaiga i le tuufaatasia e auina atu se [`Rc<T>`] le va o filo.
/// Peitaʻi, e ono filifilia e le faletusi le `Arc<T>` ina ia mafai ai ona fetuʻunaʻi tagata faʻatau potu tusi.
///
/// `Arc<T>` o le a faʻaaoga [`Send`] ma [`Sync`] pe a faʻaaoga e le `T` [`Send`] ma [`Sync`].
/// Aisea e le mafai e tuu a lē filo-saogalemu ituaiga `T` i se `Arc<T>` ina ia filo-saogalemu?Atonu o lenei e fai si taufaʻafefe i le taimi muamua: i le uma, e le o le itu o le `Arc<T>` filo saogalemu?O le ki o le: `Arc<T>` faia e faʻaigoa le saogalemu i le tele o anaina o le tutusa faʻamatalaga, ae le faʻaopoopoina le saogalemu filo i ana faʻamatalaga.
///
/// Mafaufau i le `Arc <'[' RefCell<T>``>> `.
/// [`RefCell<T>`] E le o le [`Sync`], ma afai o `Arc<T>` sa masani ona [`Send`], 'Arc <' ['RefCell<T>"]"> o le a faapena foi.
/// Ae e iai la matou faʻafitauli:
/// [`RefCell<T>`] e le sefe le filo;e faʻamaumau ai le aofaʻi o nonogatupe e faʻaaogaina ai galuega e leʻo ni atomic.
///
/// I le iʻuga, o lona uiga e ono manaʻomia e paga le `Arc<T>` ma ni ituaiga [`std::sync`] ituaiga, masani [`Mutex<T>`][mutex].
///
/// ## Solia taʻamilosaga ile `Weak`
///
/// O le [`downgrade`][downgrade] auala e mafai ona faʻaaogaina e fausia ai le leai-maua [`Weak`] faʻasino faasino.O le [`Weak`] faʻasino tusi mafai ona ['faʻafouina`][faʻaleleia] d i le `Arc`, ae o lenei o le a toe faafoi [`None`] pe a fai o le tau aoga o loʻo teuina i totonu o le faʻasoaga ua uma ona pa'ū.
/// I se isi faaupuga, `Weak` faʻailoga e le taofia le taua i totonu o le faʻasoaga ola;ae ui i lea, latou *tausia* faʻasoaga le faʻasoaga (le faleʻoloa fesoasoani mo le tau) ola.
///
/// O se taamilosaga i le va o vae `Arc` a le mafai ona deallocated.
/// Mo lenei mafuaʻaga, [`Weak`] e faʻaaogaina e gagau ai taʻamilosaga.Mo se faʻataʻitaʻiga, o le laau ono i ai ni malosi `Arc` faʻasino mai matua node i fanau, ma [`Weak`] faʻasino mai tamaiti i tua io latou matua.
///
/// # Faʻamatalaga o faʻaupuga
///
/// Fausiaina o se fou faʻamatalaga mai se o loʻo i ai le faʻasino tusi-faitau faʻasino ua maeʻa faʻaaogaina le `Clone` trait faʻatinoina mo [`Arc<T>`][Arc] ma [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // O syntaxes e lua o loʻo i lalo e tutusa.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b, ma le foo o Arcs uma ia e faʻasino i le nofoaga e tasi e manatua ai
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` otometi dere rujukan i `T` (ala i le [`Deref`][deref] trait), o lea e mafai ai ona e valaʻauina 'T' auala i luga o le taua o le ituaiga `Arc<T>`.Ina ia aloese mai feteʻenaʻiga igoa ma auala a le 'T`, o metotia a le `Arc<T>` lava ia e fesoʻotaʻi gaioiga, valaʻauina faʻaaogaina [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>O faʻatinoga ole traits pei ole `Clone` e mafai foi ona valaʻauina e faʻaaoga ai le tusipasi agavaa atoatoa.
/// Nisi tagata fiafia e faʻaaoga atoatoa agavaʻa faʻasologa, ae o isi e manaʻo e faʻaaoga metotia-valaʻau faʻasologa.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Metotia-valaau faʻasologa
/// let arc2 = arc.clone();
/// // Faʻamatalaga atoatoa agavaʻa
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] e le otometi-faʻaletonu ile `T`, aua o le tau i totonu atonu ua uma ona pa'ū.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Faʻasoaina o faʻamatalaga le masuia i le va o filo:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Manatua matou te le ** faʻatautaia nei suʻega iinei.
// E sili atu le le fiafia o le au fausia fale windows pe a fai e sili atu le filo i le filo autu ona alu ese ai lea i le taimi e tasi (o se mea e le mafai ai ona oti) o lea tatou te 'aloʻalo ese ai mai lenei mea i le le faia o nei suʻega.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Faʻasoaina o le mutable [`AtomicUsize`]:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Vaʻai le [`rc` documentation][rc_examples] mo nisi faʻataʻitaʻiga o le faitauga faʻasino i le lautele.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` o se faʻaliliuga o le [`Arc`] o loʻo ia te ia le le anaina faʻasino i le faʻasoasoaina faʻasoaga.
/// O le vaegatupe e faʻaaogaina e ala i le valaʻau i le [`upgrade`] i luga o le `Weak` faʻasino, lea e faʻafoʻi mai ai le ['Option`]`<`[' Arc`] '<T>> `.
///
/// Talu ai o le `Weak` faʻasino e le faitauina agai i le umiaina, o le a le taofia ai le tau o loʻo teuina i le faʻasoaga mai le pa'ū, ma `Weak` lava ia e leai ni faʻamaoniga e uiga i le tau o loʻo iai pea.
///
/// E faʻapea e ono faʻafoʻi mai le [`None`] pe a fai o le (`upgrade`] d.
/// Manatua peitaʻi o le `Weak` faʻasino *e* puipuia le faʻasoaga ia lava (o le faleʻoloa fesoasoani) mai le faʻasologa.
///
/// O le `Weak` faʻasino e aoga mo le tausia o se le tumau faʻasino i le vaegatupe faʻatautaia e [`Arc`] e aunoa ma le puipuia lona faʻatauaina totonu mai le lafoa.
/// O loʻo faʻaaogaina foi e puipuia ai faʻatonuga faʻasolosolo i le va o [`Arc`] faʻasino, talu ai o le tuʻufaʻatasia o le umiaina o faʻamatalaga e le faʻatagaina ai [`Arc`] ona faʻapaʻu.
/// Mo se faʻataʻitaʻiga, e mafai ona maua e le laau ni faʻailoga malosi [`Arc`] mai matua node i fanau, ma `Weak` faʻasino mai tamaiti i tua io latou matua.
///
/// O le auala masani e maua ai le `Weak` faʻasino o le valaʻau lea i le [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Lenei o le `NonNull` e faʻatagaina ai le faʻamautinoaina o le tele o lenei ituaiga i enums, ae e le o se talafeagai faʻasino faasino.
    //
    // `Weak::new` seti lenei i le `usize::MAX` ina ia le manaʻomia le faʻasoasoa avanoa i luga o le faaputuga.
    // le o se taua o le a maua lava se faasino moni ona ua i ai ia talafeagai RcBox e itiiti ifo i le 2.
    // Faʻatoa mafai lea pe a `T: Sized`;uns01e X01 leai se mea tauto.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Ole repr(C) ile future-faʻamaonia e faʻatatau ile toe faʻafouga ole fanua, e ono faʻalavelave ile [into|from]_raw() sefe o ituaiga feaveaʻi i totonu.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // le aoga usize::MAX galue o se sentinel mo le tumau "locking" le mafai e faʻaleleia ai vaivaiga manaʻoga poʻo le faʻavaivaia malosiaga;e faʻaaogaina lea e aloese mai tuʻuga i `make_mut` ma `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Fausia se `Arc<T>` fou.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Amata le vaivai faʻasino numera pei o le 1 o le vaivai faʻasino tusi o loʻo taofia e le malosi uma faʻasino (kinda), vaʻai std/rc.rs mo nisi faʻamatalaga
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Fausia se `Arc<T>` fou faʻaaogaina se vaivai faʻasino ia te ia lava.
    /// Taumafai e faʻaleleia le vaivai faʻasino ae leʻi amataina lenei galuega toe faʻatonu o le a mafua ai le `None` taua.
    /// Ae ui i lea, o le vaivai faʻamatalaga mafai ona faʻavasega saoloto ma teuina mo le faʻaaogaina i se taimi mulimuli ane.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Fausia le totonu i le "uninitialized" setete ma le tasi vaivai faʻasino.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // E taua tatou te le lafoa le umiaina o le vaivai faʻasino, a leai o le manatuaina mafai ona faʻasaʻolotoina i le taimi `data_fn` toe foʻi.
        // Afai matou te manaʻo moni e pasi le umiaina, e mafai ona tatou faia se faʻaopopo vaivai faʻasino mo matou lava, ae o lenei mea o le a mafua ai i faʻaopoopoga faʻafouina i le vaivai faitau faʻamaumauga e ono le manaʻomia se isi faiga.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // O lenei e mafai ona tatou faʻamalamalamaina muamua le taua i totonu ma liliu la tatou vaivaiga faʻasino i se malosi faʻasino.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // O luga tusi i luga o le faʻamatalaga fanua tatau ona vaʻaia e soʻo se filo e maitauina le leai-zero malosi faitauga.
            // O le mea lea matou te manaʻomia le sili atu "Release" okaina ina ia mafai ona faʻatasia ma le `compare_exchange_weak` i le `Weak::upgrade`.
            //
            // "Acquire" okaina e le manaʻomia.
            // A o iloiloina amio talafeagai a le `data_fn` e naʻo le pau le mea e manaʻomia e tilotilo ai i le mea e mafai ona fai i se faʻasino i le `Weak` e le faʻaleleia:
            //
            // - E mafai *faʻataʻali* le `Weak`, faʻateleina le faitauga vaivai faʻamatalaga.
            // - E mafai ona faʻapaʻu na clones, faʻaititia le vaivai faitau faitauga (ae le oʻo i le zero).
            //
            // O nei aʻafiaga e le afaina ai tatou i soo se auala, ma e leai seisi aʻafiaga e mafai na o le saogalemu le tulafono.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Malosiaga faʻasino tusi tatau ona umiaina faʻatasi se fefaʻasoaaʻi vaivai vaivaiga, o lea aua le tamoʻe le faʻaumatia mo la tatou tuai vaivaiga faʻasino.
        //
        mem::forget(weak);
        strong
    }

    /// Fausia se `Arc` fou ma mea e leʻo faʻaaogaina.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Faʻamalolo le amataga
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Fausia se `Arc` fou ma mea e leʻo faʻaaogaina, ma le mafaufau e faʻatumuina ile `0` bytes.
    ///
    ///
    /// Vaʻai [`MaybeUninit::zeroed`][zeroed] mo faʻataʻitaʻiga o le saʻo ma le le saʻo o le faʻaaogaina o lenei metotia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Fausia se `Pin<Arc<T>>` fou.
    /// Afai e le faʻatinoina e `T` le `Unpin`, ona faʻapipiʻi lea o le `data` i le mafaufau ma le mafai ona minoi.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Fausia se `Arc<T>` fou, toe faʻafoʻi se mea sese pe a fai ua le manuia le faʻasoa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Amata le vaivai faʻasino numera pei o le 1 o le vaivai faʻasino tusi o loʻo taofia e le malosi uma faʻasino (kinda), vaʻai std/rc.rs mo nisi faʻamatalaga
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Fausia se `Arc` fou ma mea e leʻo faʻatulagaina, toe faʻafoʻi mai se mea sese peʻa le manuia le faʻasoaga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Faʻamalolo le amataga
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Fausia se `Arc` fou ma mea e leʻo faʻaaogaina, ma le faʻamanatuina e faʻatumuina ile `0` bytes, toe faʻafoʻi mai se mea sese pe a fai ua le manuia le faʻasoaga.
    ///
    ///
    /// Vaʻai [`MaybeUninit::zeroed`][zeroed] mo faʻataʻitaʻiga o le saʻo ma le le saʻo o le faʻaaogaina o lenei metotia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Toe foi mai le taua i totonu, pe afai o le `Arc` ua tonu se tasi o tusi malosi.
    ///
    /// A leai, o le [`Err`] ua toe faʻafoʻi mai ma le `Arc` tutusa na pasia i totonu.
    ///
    ///
    /// Lenei o le a alualu i luma tusa lava pe i ai ni tulaga ese vaivai faʻasino.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Fai se faʻasino vaivai e faʻamama le faʻamatalaga malosi-vaivai faʻamatalaina
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Fausia se vaega fou atomika faʻasino-faitau fasi ma mea le faʻamatalaina anotusi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Faʻamalolo le amataga
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Fausia se vaega fou atomika faʻasino-faitau fasi ma mea le faʻamatalaina anotusi, ma le manatua faʻatumuina i `0` bytes.
    ///
    ///
    /// Vaʻai [`MaybeUninit::zeroed`][zeroed] mo faʻataʻitaʻiga o le saʻo ma le le saʻo o le faʻaaogaina o lenei metotia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Tagata liliu mai i le `Arc<T>`.
    ///
    /// # Safety
    ///
    /// E pei o le [`MaybeUninit::assume_init`], e pule lava le tagata i le tagata e faʻamautinoa mai o le mea i totonu o le mea moni o loʻo i totonu o le amataga tulaga.
    ///
    /// Valaʻauina o lenei pe a fai o le mataupu e leʻi maeʻa faʻamaonia mafuaʻaga vave le faʻauiga amioga.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Faʻamalolo le amataga
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Tagata liliu mai i le `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// E pei o le [`MaybeUninit::assume_init`], e pule lava le tagata i le tagata e faʻamautinoa mai o le mea i totonu o le mea moni o loʻo i totonu o le amataga tulaga.
    ///
    /// Valaʻauina o lenei pe a fai o le mataupu e leʻi maeʻa faʻamaonia mafuaʻaga vave le faʻauiga amioga.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Faʻamalolo le amataga
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Faʻauma le `Arc`, faʻafoʻi mai le faʻailoga na afifi.
    ///
    /// Ina ia aloese mai le manatuaina o le leak le tatau ona faʻafoʻi le faʻasino i se `Arc` faʻaaogaina [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Tuʻuina atu se faʻasino tonu i faʻamatalaga.
    ///
    /// O faitauga e le afaina i soʻo se auala ma e le faʻaumatia le `Arc`.
    /// E aoga le faʻasino tusi pe afai e i ai le malosi faitauga i le `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // SAFETY: E le mafai ona pasi i le Deref::deref poʻo le RcBoxPtr::inner ona
        // e manaomia lenei e taofi provenance raw/mut e pei o eg
        // `get_mut` mafai ona tusi e ala i le faʻasino tusi pe a maeʻa le Rc toe maua mai i le `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Fausia se `Arc<T>` mai se faʻailoga masani.
    ///
    /// O le faʻailoga masani na tatau ona faʻafoʻi mai muamua e le telefoni i le [`Arc<U>::into_raw`][into_raw] lea e tatau ona tutusa le tele ma le faʻafetaui o le `U` e pei o le `T`.
    /// E faʻatauvaʻa moni lenei mea pe a fai o `U` o `T`.
    /// Manatua afai o `U` e le `T` ae tutusa le tele ma le faʻatulagaina, e pei lava o le faʻasalalauina o faʻamatalaga o ituaiga eseese.
    /// Vaʻai [`mem::transmute`][transmute] mo nisi faʻamatalaga pe o a tapulaʻa faʻatatau i lenei tulaga.
    ///
    /// O le tagata faʻaaogaina `from_raw` e tatau ona ia mautinoa o se faʻapitoa taua o `T` ua naʻo le faʻapa'ū tasi.
    ///
    /// O lenei gaioiga e le saogalemu ona o le le talafeagai faʻaaoga e ono taitai atu ai i le manatuaina unsafety, tusa lava pe o le toe faʻafoʻi `Arc<T>` e le mafai ona faʻaaogaina.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Toe faʻafoʻi i le `Arc` e puipuia ai le tataʻu.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // O isi telefoni i le `Arc::from_raw(x_ptr)` o le a manatua-e le sefe.
    /// }
    ///
    /// // Na faʻasaolotoina le manatuaina ina ua alu ese le `x` i luga atu, o lea la ua taatitia nei `x_ptr`!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Faʻafoʻi le palapala e saili le amataga ArcInner.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Fausia se fou [`Weak`] faasino i lenei faʻasoasoaga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Lenei Malologa e OK ona o loʻo matou siakiina le tau ile CAS i lalo.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // siaki pe a fai o le counter vaivai o le taimi nei "locked";afai o lea, vili.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: o lenei tulafono i le taimi nei le amanaʻiaina le ono mafai ona ova
            // i le usize::MAX;i se tulaga aoao uma Rc ma Arc manaʻomia e fetuʻunaʻi e feagai ma le lolovaia.
            //

            // E le pei o le Clone(), matou te manaʻomia lenei mea ia avea o se Maua mai faitau e faʻafesoʻotaʻi ma le tusi sau mai `is_unique`, ina ia o mea na tutupu i luma atu o lena tusitusi tupu muamua o lenei faitauga.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Ia mautinoa tatou te le o faia se tulaga vaivai Vaivai
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Maua le numera o [`Weak`] faʻasino i lenei faʻasoaga.
    ///
    /// # Safety
    ///
    /// O lenei metotia lava ia e saogalemu, ae o le faʻaaogaina saʻo e manaʻomia ai se faʻaeteetega faʻaopoopo.
    /// O le isi filo e mafai ona suia le faitauga vaivai i soo se taimi, e aofia ai e ono i le va o le valaau lenei metotia ma faia i luga o le taunuuga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // O lenei faʻamatalaga e mautinoa aua ua matou le faʻasoaina le `Arc` poʻo le `Weak` i le va o filo.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Afai o le vaivai faitauga o loʻo lokaina nei, o le tau o le faitauga o le 0 ae leʻi faia le loka.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Mauaina le numera o malosi (`Arc`) faʻasino i lenei faʻasoaga.
    ///
    /// # Safety
    ///
    /// O lenei metotia lava ia e saogalemu, ae o le faʻaaogaina saʻo e manaʻomia ai se faʻaeteetega faʻaopoopo.
    /// O leisi filo mafai ona suia le malosi faitauga i soʻo se taimi, aofia ai ono i le va o valaʻau lenei metotia ma galue i luga o le iʻuga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // O lenei faʻamatalaga e mautinoa aua ua matou le faʻasoaina le `Arc` i le va o filo.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Faʻateleina le malosi faʻasino faitauga i le `Arc<T>` fesoʻotaʻi ma le faʻasino tusi saunia e le tasi.
    ///
    /// # Safety
    ///
    /// O le faʻasino tatau na mauaina e ala i `Arc::into_raw`, ma le fesoʻotaʻi `Arc` faʻataʻitaʻiga tatau ona aoga (ie
    /// o le malosi faitauga tatau ona le itiiti ifo i le 1) mo le umi o lenei metotia.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // O lenei faʻamatalaga e mautinoa aua ua matou le faʻasoaina le `Arc` i le va o filo.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Faʻaauau Arc, ae aua le tago toe totogia i le afifiina i le ManallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Faʻatele nei le toe totogia, ae aua le faʻapaʻu se numera fou
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Faʻatagaina le malosi faʻasino faitauga i luga o le `Arc<T>` fesoʻotaʻi ma le faʻasino tuʻuina atu tasi.
    ///
    /// # Safety
    ///
    /// O le faʻasino tatau na mauaina e ala i `Arc::into_raw`, ma le fesoʻotaʻi `Arc` faʻataʻitaʻiga tatau ona aoga (ie
    /// o le malosi faitauga tatau ona le itiiti ifo i le 1) pe a faʻaaogaina lenei metotia.
    /// O lenei metotia e mafai ona faʻaaogaina e faʻasaʻoloto ai le `Arc` mulimuli ma le teuina o fesoasoani, ae **le tatau** ona valaʻau ina ua maeʻa le `Arc` mulimuli.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // O na manatu taua na mafua ai ona matou te leʻi faʻasoaina le `Arc` i le va o filo.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // O lenei le saogalemu e lelei lava aua a o ola le arc lea matou te mautinoa o le faʻatonuga i totonu e aoga.
        // E le gata i lea, matou te iloa o le `ArcInner` fausaga lava ia o `Sync` aua o faʻamaumauga i totonu o le `Sync` faʻapea foi, o lea ua matou lelei tatalaina mai se le suia faʻasino i nei mea.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Le-laina laina o `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Faʻaleagaina faʻamaumauga i lenei taimi, e ui lava atonu tatou te le faʻasaʻolotoina le pusa faʻasoasoa ia lava (atonu o loʻo iai pea faʻasino vaivai o taatitia solo).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Faʻapaʻu le vaivai ref tuʻufaʻatasia uma e faʻamaoniga malosi
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Faʻafoʻi `true` peʻa fai o le lua Arc e faʻasino i le faʻasoaga e tasi (i se uaua pei o le [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Allocates se `ArcInner<T>` ma lava avanoa mo se taua i totonu mafai-unsized le mea ei ai le taua i le faatulagaga ua tuuina atu.
    ///
    /// O le gaioiga `mem_to_arcinner` e valaʻau ma faʻamaumauga faʻasino ma e tatau ona toe faʻafoʻi mai le (ono gaʻo)-pusa mo le `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Fuafua faʻatulagaina faʻaaoga ai le faʻatulagaina taua faʻatulagaina.
        // I le taimi muamua, sa fuafuaina le faʻatulagaina i luga o le faʻaaliga `&*(ptr as* const ArcInner<T>)`, peitaʻi o lenei mea na fausia ai se faʻasesega vaʻai (vaʻai #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Tuʻuina atu le `ArcInner<T>` ma lava le avanoa mo le ono-unsized faʻatauaina totonu pe a fai o le tau na i ai le faʻatulagaina saunia, toe faʻafoʻi se mea sese pe a faʻapea ua le aoga le faʻasoaga.
    ///
    ///
    /// O le gaioiga `mem_to_arcinner` e valaʻau ma faʻamaumauga faʻasino ma e tatau ona toe faʻafoʻi mai le (ono gaʻo)-pusa mo le `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Fuafua faʻatulagaina faʻaaoga ai le faʻatulagaina taua faʻatulagaina.
        // I le taimi muamua, sa fuafuaina le faʻatulagaina i luga o le faʻaaliga `&*(ptr as* const ArcInner<T>)`, peitaʻi o lenei mea na fausia ai se faʻasesega vaʻai (vaʻai #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Initialize le ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Tuʻuina atu se `ArcInner<T>` ma lava avanoa mo se unsized taua i totonu.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Faʻasoa mo le `ArcInner<T>` faʻaaogaina le tau aoga.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopi taua o bytes
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Faʻasaʻoloto le faʻasoaga e aunoa ma le faʻapaʻuina o mea i totonu
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Tuʻuina atu le `ArcInner<[T]>` ma le umi tuʻuina atu.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Kopi elemene mai fasi i totonu o le faʻafouina Arc <\[T\]>
    ///
    /// Le saogalemu aua o le tagata e valaʻau e tatau ona avea le anaina pe fusifusia `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Fausia se `Arc<[T]>` mai se iterator lauiloa o se tasi tele.
    ///
    /// O amioga e le faʻamatalaina e tatau ona sese le lapopoa.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic leoleo a o oʻo i le faʻailoaina o elemene T.
        // I le mea e tupu ai le panic, o elemeni ua uma ona tusia i totonu o le ArcInner fou o le a tuʻua i lalo, ona faʻamatuʻuina lea o le manatuaina.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Faasino i le muamua elemene
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // manino uma.Faʻagalo le leoleo ina ia aua neʻi faʻasaolotoina le ArcInner fou.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Faʻapitoa trait faʻaaogaina mo `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Faia se faʻailoga o le `Arc` faʻasino.
    ///
    /// Lenei faia se isi faʻasino i le tutusa faʻasoaga, faʻateleina le malosi faitauga faitauga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // O le faʻaaogaina o se faʻavasegaga faʻatonuga e lelei iinei, ona o le malamalama i le uluaʻi faʻamatalaga taofia isi filo mai le tapeina sese o le mea.
        //
        // E pei ona faʻamatalaina ile [Boost documentation][1], O le faʻateleina o le faʻasino mea e mafai ona faia i taimi uma ma memory_order_relaxed: Faʻamatalaga fou i se mea e mafai ona faia mai le taimi nei, ma o le pasia o loʻo i ai le faʻasino mai le tasi filo i le isi e tatau ona uma ona saunia se manaʻoga tuʻufaʻatasia.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Ae peitai e tatau ona tatou puipuia refcounts matautia i se tasi tulaga o 'Mema: : Arcs forget`ing.
        // Afai matou te le faia lenei mea o le faitauga mafai ona oʻo atu ma tagata faʻaoga o le a faʻaaoga-pe a uma fua.
        // Matou te faʻamalieina i le `isize::MAX` luga o le manatu e leai ~2 piliona filo faʻaopoopoina le faitauga faitau i le taimi e tasi.
        //
        // Lenei branch o le a le avea i totonu o soʻo se moni polokalame.
        //
        // Matou te faʻapapāina ona o se polokalame e matua faʻaletonu, ma matou te le popole e lagolagoina.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Faia se suia suia i le `Arc` tuuina atu.
    ///
    /// Afai e i ai isi `Arc` poʻo [`Weak`] faʻasino i le tutusa faʻasoaga, ona `make_mut` o le a fausiaina se vaegatupe fou ma talosagaina [`clone`][clone] i totonu o le tau e faʻamautinoaina tutoʻatasi anaina.
    /// Lenei e taua foi o le faʻamau i luga o tusitusiga.
    ///
    /// Manatua o lenei e ese mai le amio a le [`Rc::make_mut`] lea faʻamavaeina soʻo se `Weak` faʻailoga na totoe.
    ///
    /// Tagai foi [`get_mut`][get_mut], lea o le a le mafai nai lo cloning.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Le mafai ona faʻailoaina se mea
    /// let mut other_data = Arc::clone(&data); // O le a le toefaʻailogaina faʻamaumauga i totonu
    /// *Arc::make_mut(&mut data) += 1;         // Faʻamatalaga pito i totonu o leone
    /// *Arc::make_mut(&mut data) += 1;         // Le mafai ona faʻailoaina se mea
    /// *Arc::make_mut(&mut other_data) *= 2;   // Le mafai ona faʻailoaina se mea
    ///
    /// // O lenei `data` ma `other_data` faʻasino i vaegatupe eseese.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Manatua o loʻo tatou uuina uma se mau taʻutaʻua ma se faʻamatalaga vaivai.
        // O le mea lea, o le faʻamatuʻuina atu o le tatou faʻamatalaga malosi, e le mafai, na o ia lava, e mafua ai ona aveʻesea le mafaufau.
        //
        // Faʻaaoga Maua ia mautinoa o matou vaʻaia ni tusitusiga i le `weak` e tupu aʻo leʻi faʻamatuʻuina tusi (ie, faʻaititia) i le `strong`.
        // Talu ai ua tatou faia se faitauga vaivai, e leai se avanoa e mafai ona deallocated le ArcInner lava ia.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Le isi malosi faʻasino tusi o loʻo i ai, o lea e tatau ai ona tatou faʻavasega.
            // Muaʻi tuʻuina atu le faʻamanatuga e faʻatagaina ai le tusia saʻo o le faʻatulagaina o tau.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Ua lava le malolo i luga atu ona o le mea moni lava o se optimization: tatou te masani lava ona taufetuli ma vaivai vaivaʻa ua faʻapaʻu.
            // O le mea e sili ona leaga, ua tatou faʻamatuʻuina atu se Arc fou e le manaʻomia.
            //

            // Na matou aveʻesea le toe malosi malosi, ae o loʻo iai pea isi vaivaiga vaivai o totoe.
            // O le a matou faʻaseʻeina mea i totonu o se Arc fou, ma faʻaleaogaina isi vaivaiga vaivai.
            //

            // Manatua e le mafai mo le faitauga o le `weak` ona maua mai le usize::MAX (ie, lokaina), talu ai o le faitauga vaivai e faʻatoa mafai ona loka e se filo ma se faʻamatalaga malosi.
            //
            //

            // Faʻatinoina a matou lava faʻailoga vaivai faʻatosinaina, ina ia mafai ona faʻamamaina le ArcInner pe a manaʻomia.
            //
            let _weak = Weak { ptr: this.ptr };

            // E naʻo le gaoi o faʻamaumauga, naʻo le pau a le mea o Weaks
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Sa naʻo matou le tasi faʻamatalaga o soʻo se ituaiga;oso i luga le malosi ref faitauga.
            //
            this.inner().strong.store(1, Release);
        }

        // E pei foi o le `get_mut()`, o le le saogalemu e lelei ona o le tatou faʻamatalaga sa i ai e tutasi lava i le amataina, pe na avea ma se tasi i luga o le faʻavasegaina o mea i totonu.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Faʻafoʻi mai se faʻamatalaga sui i le `Arc`, pe a leai seisi `Arc` poʻo le [`Weak`] faʻasino i le tutusa faʻasoaga.
    ///
    ///
    /// Faʻafoʻi [`None`] i se isi itu, aua e le sefe le suia o le tuʻufaʻatasiga o tau.
    ///
    /// Vaʻai foʻi ile [`make_mut`][make_mut], lea e [`clone`][clone] le tau i totonu pe a iai isi faʻasino.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // O lenei le saogalemu e lelei lava aua ua mautinoa tatou o le faʻasino tusi na toe foʻi mai o le *pau* faʻasino tusi e toe faʻafoʻi ia T.
            // O la matou faitauga faʻamaoniga ua mautinoa e avea ma 1 i lenei taimi, ma matou manaʻomia le Arc lava ia e avea ma `mut`, o lea matou te toe faʻafoʻi atu ai na o le mafai faʻasino i mea i totonu faʻamaumauga.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Faʻafoʻi mai se faʻamatalaga fesoasoani i le `Arc`, e aunoa ma se siaki.
    ///
    /// Vaʻai foʻi ile [`get_mut`], e sefe ma e siaki talafeagai.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Soʻo seisi lava `Arc` poʻo le [`Weak`] faʻasino i le faʻasoaga e tasi e le tatau ona tuʻufaʻaseseina mo le umi o le nonogatupe.
    ///
    /// O le mea taua lea pe a leai ni faʻasino faapena, mo se faʻataʻitaʻiga tonu lava pe a maeʻa le `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Matou te faʻaeteete lava i le *aua* faia se faʻamatalaga e ufiufi ai le "count" fanua, aua o le a faʻaigoa faʻatasi ai ma le sao faʻatasi i faitauga o faʻamatalaga (eg
        // e `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Fuafua pe o le tulaga ese lea o faʻamatalaga (e aofia ai ma refs vaivai) i faʻamatalaga o loʻo mulimuli mai.
    ///
    ///
    /// Manatua o lenei e manaʻomia lokaina le vaivai ref faitauga.
    fn is_unique(&mut self) -> bool {
        // loka le numera tusitusi vaivai pe a fai e foliga mai o matou o le vaivai faʻasino toniga vaivai.
        //
        // O le faʻailoga mauaina iinei mautinoa le tupu-i luma o sootaga ma soʻo se tusitusiga i le `strong` (aemaise i le `Weak::upgrade`) ao le i pa'ū ifo le decrement o le `weak` count (e ala i `Weak::drop`, lea e faʻaaogaina le faʻasaʻoga).
        // Afai o le toe faʻaleleia vaivai ref e leʻi faʻapa'ūina, o le CAS ii o le a le faʻapea o lea matou te le popole ai e faʻatasi.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Lenei manaʻomia le avea ma `Acquire` e faʻafesoʻotaʻi ma le faʻaititia o le `strong` counter i `drop`-naʻo le pau le auala e tupu pe a iai ae o le mulimuli faʻasino o loʻo faʻapaʻu.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // O le faʻamatuʻu tusitusi iinei faʻafesoʻotaʻi ma le faitauga i le `downgrade`, puipuia lelei le luga faitau o `strong` mai tupu pe a maeʻa le tusitusi.
            //
            //
            self.inner().weak.store(1, Release); // tatala le loka
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Faʻapapa le `Arc`.
    ///
    /// Lenei o le a faʻaititia ai le malosi faitauga faʻamatalaga.
    /// Afai o le malosi faʻasino faitau aofaʻi aulia leai na o isi faʻasino (pe a iai) o [`Weak`], o lea tatou `drop` le tau i totonu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // E le lolomiina se mea
    /// drop(foo2);   // Lolomi "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Talu ai `fetch_sub` ua uma ona atomika, tatou te le manaʻomia e faʻatasia ma isi filo seʻi vagana o le a tatou o eseina le mea.
        // O lenei lava manatu tutusa e faatatau i lalo `fetch_sub` i le `weak` faitau.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // O lenei pa e manaʻomia e puipuia ai le toe fetuunaiga o le faʻaaogaina o faʻamatalaga ma le tineia o faʻamatalaga.
        // Aua ua makaina `Release`, o le faʻaititia o le faʻasino faitauga e faʻatasia ma lenei pa `Acquire`.
        // O lona uiga o le faʻaaogaina o faʻamatalaga e tupu ae le i faʻaititia le faitauga faitauga, lea e tupu i luma o lenei pa, lea e tupu ae le i aveʻesea le faʻamaumauga.
        //
        // E pei ona faʻamatalaina ile [Boost documentation][1],
        //
        // > E taua le faʻamalosia o soʻo se avanoa i le mea faitino i le tasi
        // > filo (e ala i se faʻamatalaga na i ai) e * tupu ae le i tapeina
        // > le mea i se filo ese.E 'ausia lenei mea e le "release"
        // > gaioiga pe a maeʻa le tuʻuina o se faʻasino (soʻo se auala i le mea faitino
        // > ala e tatau ona e mautinoa lava na tupu faamatalaga lenei i luma), ma se
        // > "acquire" faagaoioiga ae le i tapeina le mea.
        //
        // A e maise, a o mea o loʻo i totonu o le Arc e masani lava ona le suia, e mafai ona i totonu e tusi i se mea pei o le Mutex<T>.
        // Talu ai e le o maua se Mutex pe a aveʻesea, e le mafai ona matou faʻamoemoeina i lona tuʻufaʻatasia o manatu e faia ai ni tusitusiga i le filo O se vaʻaiga i se faʻaleaga o loʻo tamoʻe ile filo B.
        //
        //
        // Manatua foi o le Maua pa puipui iinei ono mafai ona suia i se Mauaina avega, lea e mafai ona faʻaleleia ai le faʻatinoina i tulaga sili ona feteʻenaʻi.Vaʻai [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Taumafai e faanoanoa le `Arc<dyn Any + Send + Sync>` i se ituaiga sima.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Fausia se `Weak<T>` fou, aunoa ma le tuʻuina atu o se manatua.
    /// Valaʻau [`upgrade`] i luga o le toe faʻafoʻi taua maua pea [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Fesoasoani ituaiga e faʻatagaina le faʻaaogaina o faʻasino faitauga e aunoa ma le faia o ni faʻamatalaga e uiga i le faʻamatalaga fanua.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Faʻafoʻi mai se faʻasino tonu i le mea faitino `T` faʻasino e lenei `Weak<T>`.
    ///
    /// E faʻatoa aoga le faʻasino tusi pe a iai ni faʻamatalaga malosi.
    /// O le faʻasino tusi atonu e tautau, le faʻailoaina pe oʻo foʻi i le [`null`] i se isi itu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Faasino uma i le mea e tasi
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // O le malosi iinei e faʻaolaola, o lea e mafai ai lava ona tatou faʻaaoga le mea.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Ae le toe i ai.
    /// // E mafai ona tatou faia weak.as_ptr(), ae o le faʻaaogaina o le faʻasino tusi e taitai atu ai i amioga le faʻamatalaina.
    /// // assert_eq ("talofa", saogalemu {&*weak.as_ptr() })!;
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Afai o tautau le faʻasino, tatou toe faʻafoʻi saʻo le sentinel.
            // Lenei e le mafai ona avea ma se sao tuatusi totogi, ona o le totogi o le mea sili ia tutusa ma tutusa ma ArcInner (usize).
            ptr as *const T
        } else {
            // SAFETY: afai o_dangling toe faʻafoʻi sese, o lona uiga o le faʻasino faʻailoga e faʻateʻaina.
            // O le totogi e ono paʻu i lalo i lenei taimi, ma e tatau ona tatou tausia moni, o lea ia faʻaaoga le vaʻai faʻatonu vaʻaia.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Faʻaumatia le `Weak<T>` ma liliuina i se faʻasino tonu.
    ///
    /// Lenei liua le vaivai faʻasino i se raw pointer, a o loʻo faʻasaoina pea le umiaina o le tasi vaivai faʻasino (o le vaivai faitauga e le suia e lenei faʻagaioiga).
    /// E mafai ona toe faʻafoʻi i le `Weak<T>` ma le [`from_raw`].
    ///
    /// O le tapulaa lava lea e tasi o le mauaina o le sini o le e faasino ai e pei o [`as_ptr`] faaaogaina.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Faʻaliliuina se faʻailoga masani na faia e [`into_raw`] i tua i le `Weak<T>`.
    ///
    /// Lenei mafai ona faʻaaogaina e maua saogalemu ai se faʻasino malosi (e ala i le valaʻau [`upgrade`] mulimuli ane) pe faʻasese le vaivai vai i le faʻapaʻuina o le `Weak<T>`.
    ///
    /// E manaomia le umia o se tasi o tusi vaivai (faatasi ai ma le tuusaunoaga o vae faia e [`new`], e pei o nei e leai lava se mea; galue pea le auala i latou).
    ///
    /// # Safety
    ///
    /// O le faʻasino tatau na mafua mai i le [`into_raw`] ma e tatau lava ona anaina lona ono vaivai faʻasino.
    ///
    /// E faʻatagaina ile numera malosi e 0 ile taimi ole valaʻauina ole mea lea.
    /// Ae ui i lea, o lenei e avea le umiaina o se tasi vaivai faʻasino taimi o loʻo avea nei ma faʻasino tonu (o le vaivai faitauga e le suia e lenei faʻagaioiga) ma o lea e tatau ai ona tuʻufaʻatasia ma se valaʻau muamua i le [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Faʻatamaia le faitauga vaivai mulimuli.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Tagai Weak::as_ptr mo mataupu i le auala e maua mai le faasino sao.

        let ptr = if is_dangling(ptr as *mut T) {
            // o se dangling Vaivai lenei.
            ptr as *mut ArcInner<T>
        } else {
            // A leai, matou te mautinoa o le faʻasino tusi e sau mai le le mafaamatalaina Vaivaʻa.
            // SAFETY: data_offset e saogalemu e valaʻau ai, pei ptr faʻasino i se moni (ono paʻu) T.
            let offset = unsafe { data_offset(ptr) };
            // O le mea lea, matou te fesuiaʻia le faʻapalapala ina ia maua atoa le RcBox.
            // SAFETY: o le faʻasino na amata mai i se Vaivaiga, o lea o lenei offset e saogalemu.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SAFETI: ua matou toe maua mai le amataga Vaiva tusi, o lea e mafai ai ona fausia le Vaivai.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Taumafai e faʻaleleia le `Weak` faʻasino i le [`Arc`], tolopo le paʻuina o le tau i totonu pe a manuia.
    ///
    ///
    /// Faafoi [`None`] pe afai ua talu ona pau le tau i totonu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Lepeti le vae malosi uma.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Matou te faʻaaogaina le CAS matasele e faʻaopopo ai le malosi faitauga nai lo le fetch_add ona o lenei gaioiga e le tatau ona ave le faʻasino faitauga mai le zero i le tasi.
        //
        //
        let inner = self.inner()?;

        // Avega malolo aua soʻo se tusitusiga o le 0 e mafai ona tatou mataʻituina tuʻua le fanua i se tumau tulaga setete (o lea o le "stale" faitau o le 0 e lelei), ma soʻo se isi aoga faʻamaonia e ala i le CAS i lalo.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Vaʻai manatu i le `Arc::clone` pe aisea tatou te faia ai lenei mea (mo `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Malologa e lelei mo le le manuia mataupu ona e leai ni o tatou faʻamoemoega e uiga i le fou setete.
            // Mauaina talafeagai mo le manuia tulaga e faʻatasia ma `Arc::new_cyclic`, pe a fai o le totonugala taua mafai ona amataina pe a maeʻa `Weak` faʻasino ua uma ona faia.
            // Ile tulaga la, matou te faʻamoemoe e maitau le tau faʻamamaluina atoa.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // leai se siaki i luga
                Err(old) => n = old,
            }
        }
    }

    /// Mauaina le numera o malosi (`Arc`) faʻasino faasino i lenei faʻasoaga.
    ///
    /// Afai na faia `self` faʻaaoga [`Weak::new`], o le a toe faafoi 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Mauaina se faʻatusatusaga o le numera o `Weak` faʻasino faasino i lenei faʻasoaga.
    ///
    /// Afai na faia `self` faʻaaogaina [`Weak::new`], pe afai e leai se toega malosi faʻasino, o le a toe faʻafoʻi 0.
    ///
    /// # Accuracy
    ///
    /// Ona o le faʻatinoina o auiliiliga, o le toe faʻatauaina mafai ona toʻesea e le 1 i soʻo se itu pe a fai o isi filo o loʻo faʻataʻitaʻia soʻo se 'Arc`s poʻo' Vaivai`s faʻasino i le tutusa faʻasoaga.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Talu ai na matou maitauina e le itiiti ifo ma le tasi le faʻasino malosi ina ua uma ona faitauina le faitauga vaivai, matou te iloa o le taua vaivai faʻasino (i ai i soʻo se taimi e malosi ai faʻasino malosi) sa i ai lava i le taimi na matou matauina ai le vaivai faitauga, ma o lea e mafai ai ona toʻesea ma le saogalemu.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Faʻafoʻi `None` peʻa tautau le faʻasino ma e leai se tuʻuina atu `ArcInner`, (ie, ina ua faia lenei `Weak` e `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Matou te faʻaeteete ia *aua* faia se faʻamatalaga e ufiufi ai le "data" fanua, aua o le fanua e ono suia faʻatasi (mo se faʻataʻitaʻiga, pe a paʻu le `Arc` mulimuli, o le faʻamaumauga fanua o le a tuʻu i lalo-nofoaga).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Faʻafoʻi `true` peʻa tusi le lua Vaivai i le tutusa faʻasoaga (tutusa ma [`ptr::eq`]), pe afai e le tusi faʻasino uma i soʻo se faʻasoaga (aua na fausiaina ma `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Talu ai o lenei faʻatusatusaina faʻailoga o lona uiga o le `Weak::new()` o le a tutusa le tasi i le isi, e ui lava latou te le tusi i se faʻasoaga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Faʻatusatusaina `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Faia se faʻailoga o le `Weak` faʻasino e tusi i le tutusa faʻasoaga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Vaʻai manatu i le Arc::clone() pe aisea ua toʻafilemu ai lenei mea.
        // Lenei mafai ona faʻaaoga se fetch_add (le amanaʻiaina le loka) ona o le vaivai faitauga na o lokaina le mea e leai *isi* vaivaiga faʻailoga o loʻo i ai.
        //
        // (Ma e le mafai ona tatou tamoʻe lenei tulafono i lena tulaga).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Tagai i faamatalaga i Arc::clone() mo mafuaaga tatou te faia lenei (mo mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Fausia se `Weak<T>` fou, aunoa ma le tuʻuina atu o le manatua.
    /// Valaʻau [`upgrade`] i luga o le toe faʻafoʻi taua maua pea [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Faʻapaʻu le faʻasino tusi `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // E le lolomiina se mea
    /// drop(foo);        // Lolomi "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Afai tatou te iloa o tatou o le mulimuli vaivai faʻasino, lea o lona taimi e faʻalata uma ai faʻamatalaga.Vaʻai le talanoaga ile Arc::drop() e uiga i faʻatonuga o mea e manatua
        //
        // E le manaʻomia le siaki mo le lokaina iinei, aua o le vaivai faitauga mafai ona loka pe a fai e tasi le tasi le vaivai ref, o lona uiga o le pa'ū na o le mulimuli ane tamoe I luga o totoe vaivai ref, lea e mafai ona tupu pe a maeʻa le loka.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// O loʻo matou faia lenei faʻapitoa iinei, ae le o se sili atu lautele optimization ile `&T`, aua e faʻapea e faʻaopopo se tau ile uma tutusa siakiina i ref.
/// Matou te manatu o le `Arc`s o loʻo faʻaaogaina e faʻaputu tele ai tau, e telegese ona faʻapipiʻi, ae mamafa foʻi e siaki ai le tutusa, ma e faigofie ai ona totogi lenei tau.
///
/// E foliga mai e lua foʻi `Arc` clones, e faʻasino i le tau e tasi, nai lo le lua `&T`s.
///
/// E mafai ona tatou faia lenei mea pe a fai o `T: Eq` o se `PartialEq` atonu e ono faʻaletonu lava.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Tutusa mo lua 'Arc`s.
    ///
    /// Lua `Arc`s e tutusa pe a fai o la latou taua i totonu e tutusa, tusa lava pe o latou teuina i eseese tufatufaina.
    ///
    /// A faʻapea e faʻaaoga `T` `Eq` (o lona uiga o le fesuiaʻiga o le tutusa), lua 'Arc`s e faʻasino i le tutusa faʻasoaga e masani lava ona tutusa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Le tutusa mo le lua 'Arc`s.
    ///
    /// Lua `Arc`s e le tutusa pe a fai o latou tau taua i totonu e le tutusa.
    ///
    /// Afai e faʻaaoga foi e le `T` le `Eq` (o lona uiga o le fesuiaʻiga o le tutusa), lua 'Arc`s e faʻasino i le tau tutusa e le taitai ona tutusa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Faʻatusatusaga faʻapitoa mo lua 'Arc`s.
    ///
    /// O le lua faʻatusatusa i le valaʻau `partial_cmp()` i luga o latou taua.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Iti-i lo le faʻatusatusaina mo lua 'Arc`s.
    ///
    /// O le lua faʻatusatusa i le valaʻau `<` i luga o latou taua.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 'Itiiti pe tutusa i le' faʻatusatusaga mo lua 'Arc`s.
    ///
    /// O le lua faʻatusatusa i le valaʻau `<=` i luga o latou taua.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Sili atu-nai lo faʻatusatusaga mo lua 'Arc`s.
    ///
    /// O loʻo faʻatusatusa ile lua ile valaʻauina ole `>` ile latou itu taua i totonu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'Sili atu pe tutusa i le' faʻatusatusaga mo lua 'Arc`s.
    ///
    /// O loʻo faʻatusatusa ile lua ile valaʻauina ole `>=` ile latou itu taua i totonu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Faʻatusatusaga mo lua 'Arc`s.
    ///
    /// E lua ua faatusaina i le valaauina `cmp()` i latou tulaga faatauaina i totonu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Fausia se `Arc<T>` fou, ma le `Default` aoga mo `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Faʻasoa se fasi pepa faʻasino ma faitau e faʻatumu i le faʻailoaina o 'v` aitema.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Tuʻu se `str` faʻasino-faitau ma kopi `v` i totonu.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Tuʻu se `str` faʻasino-faitau ma kopi `v` i totonu.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Faʻatulaga se mea pusa i se fou, faʻasino-faitauga faʻasoa.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Faʻavasega se fasi tusi faʻasino ma faitau le 'v' i totonu.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Faʻatagaina le Vec e faʻasaoloto lona mafaufau, ae aua le faʻaleagaina ana mea i totonu
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Aveina elemeni taʻitasi i le `Iterator` ma aoina i totonu o le `Arc<[T]>`.
    ///
    /// # faatinoga o Galuega uiga
    ///
    /// ## O le mataupu lautele
    ///
    /// I le tulaga lautele, o le aoina i le `Arc<[T]>` e faia i le muamua aoina i totonu o le `Vec<T>`.O le, pe a tusi lenei:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// lenei amio e pei o tatou tusia:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // O le vaega muamua o faʻasoasoaga e tupu ii.
    ///     .into(); // O le lona lua vaegatupe mo `Arc<[T]>` tupu iinei.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// O le a faasoasoa e pei o le tele o taimi e pei ona manaomia mo le fauina o le `Vec<T>` ma o le a faasoasoa taimi e tasi mo le liliu le `Vec<T>` i le `Arc<[T]>`.
    ///
    ///
    /// ## Iterators o le iloa umi
    ///
    /// A faʻapea e faʻaaoga lau `Iterator` `TrustedLen` ma e tusa lona aofaʻi, e tasi le faʻasoaga e faia mo le `Arc<[T]>`.Faataitaiga:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Naʻo le tasi le vaegatupe e tupu iinei.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Faʻapitoa trait faʻaaogaina mo le aoina i `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // O le tulaga lea mo le `TrustedLen` faʻasolosolo.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SAOGALEMU: Tatou te manaomia ina ia mautinoa ai le iterator ei ai se umi tonu ma ua tatou maua.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Pau i tua i le faʻatinoina masani.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Maua le offset i totonu o le `ArcInner` mo le totogiina tua o se faʻasino tusi.
///
/// # Safety
///
/// O le faʻasino tusi e tatau ona tusi i (ma i ai metadata aoga mo) se faʻamaoniga aoga muamua o T, ae o le T ua faʻatagaina e faʻateʻa.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Faʻasaʻo le le faʻamautuina le tau i le iʻuga o le ArcInner.
    // Talu ai o RcBox o repr(C), o le a avea pea ma mulimuli fanua i le manatuaina.
    // SAFETY: talu ai na o le tasi ituaiga faʻamaʻaina mafai o fasi, trait mea,
    // ma fafo atu ituaiga, o le sao sao manaʻoga manaʻoga ua lava nei e faʻamalieina ai manaʻoga o align_of_val_raw;o se faʻatinoina auiliiliga o le gagana e ono le faʻamoemoeina i fafo atu o std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}