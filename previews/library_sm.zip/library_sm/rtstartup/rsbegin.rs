// rsbegin.o ma rsend.o o lea ua valaauina ai "compiler runtime startup objects".
// O loʻo iai latou tulafono e manaʻomia e faʻatonutonu saʻo ai le taimi faʻapipiʻi.
//
// A fesoʻotaʻi se faʻaaogaina poʻo le dylib ata e fesoʻotaʻi, o tagata uma faʻaoga tulafono ma faletusi e "sandwiched" i le va o nei mea faitino faila e lua, o lea o le numera poʻo le faʻamaumauga mai rsbegin.o avea muamua i vaega taʻitasi o le ata, ae o le numera ma faʻamaumauga mai rsend.o avea ma mulimuli mulimuli.
// O lenei aʻafiaga e mafai ona faʻaaogaina e tuʻu ai faʻailoga i le amataga poʻo le faʻaiuga o se vaega, faʻapena foʻi ma le tuʻuina i totonu o ni ulutala manaʻomia poʻo ni vae.
//
// Manatua, o le mea e ulufale module moni o loo tu i le mea startup runtime C (e masani lava ona taʻua o `crtX.o`), o lea e fagua ai initialization callbacks o isi vaega runtime (faamauina e ala i se isi vaega o faatusa faapitoa).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Faʻailoga amataina o le faʻaupuga faʻamavae le faʻamatalaga vaega
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Faʻalautele avanoa mo le teuina o totonu tusi teuina.
    // O lenei ua faʻauigaina o le `struct object` ile $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Unwind info registration/deregistration masani.
    // Vaʻai faʻamatalaga o le libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // resitala faʻamalamala faʻamatalaga i luga o le amataga amataga
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // unregister i shutdown
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW maoti faamauina masani init/uninit
    pub mod mingw_init {
        // mea faitino startup a MinGW (crt0.o/dllcrt0.o) o le a talosagaina constructors le lalolagi i le vaega .ctors ma .dtors i startup ma o ese.
        // I le tulaga o DLLs, e faia lenei mea pe a fai o le DLL ua utaina ma lau i lalo.
        //
        // O le linker le a faatulaga le vaega, lea e mautinoa ai o loo tu ai lo matou callbacks i le faaiuga o le lisi.
        // Talu ai ua taufetuli constructors ina faafeagai, o lenei e mautinoa ai lo tatou callbacks o le tagata muamua ma le mulimuli fasiotia.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: C faʻailoaina callbacks
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors *: . C callbacks faamutaina
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}