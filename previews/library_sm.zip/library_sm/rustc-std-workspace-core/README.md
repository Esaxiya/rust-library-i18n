# O le `rustc-std-workspace-core` crate

Lenei crate o se shim ma gaogao crate e na o le faalagolago i le `libcore` ma toe auina atu uma ona anotusi.
O le crate o le autu o le faʻamalosia o le tulaga potutusi e faʻalagolago i le crates mai crates.io

Crates luga crates.io o le faletusi masani faʻalagolago i le manaʻomia e faʻalagolago i le `rustc-std-workspace-core` crate mai crates.io, lea e leai se mea.

Matou te faʻaaogaina le `[patch]` e ova ai i lenei crate i lenei nofoaga teu oloa.
O lona iʻuga, o le crates i luga o le crates.io o le a tosoina se faʻalagolago ia edge i le `libcore`, o le vaega ua faʻamatalaina i lenei fale teu oloa.
E tatau ona tusi pito faalagolago uma ina ia mautinoa e fausia Cargo crates manuia!

Manatua o le crates ile crates.io e manaʻomia le faʻalagolago i lenei crate ma le igoa `core` mo mea uma e galulue saʻo.E faia lena mea e mafai ona latou faʻaaogaina:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

E ala i le faʻaaogaina o le `package` ki o le crate ua toe faʻaigoaina i le `core`, o lona uiga e foliga foliga

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

pe a fagua Cargo le tuufaatasia, faamalieina o le faatonuga atoatoa `extern crate core` tui e ala i le tuufaatasia.




