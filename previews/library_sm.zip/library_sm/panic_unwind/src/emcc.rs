//! Unwinding mo *emscripten* taulaʻiga.
//!
//! E ui o le masani a le Rust e faʻamama le faʻatinoina mo Unix fausaga e valaʻau saʻo i totonu o le libunwind API, i luga o Emscripten matou te valaʻau atu i le C++ tatalaina API.
//! Ua naʻo se aoga lea talu ai o le taimi faʻafuaseʻi a Emscripten o taimi uma na te faʻaaogaina na API ma le faʻaaogaina le vavao.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// E fetaui lea ma le faʻatulagaga o le std::type_info ile C++
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // O le taʻitaʻiga `\x01` byte iinei o se faʻailoga faataulaitu ia LLVM ia *aua* faʻatulagaina seisi mangling pei o nauna i se faʻailoga `_`.
    //
    //
    // Lenei faʻailoga o le vtable faʻaaogaina e C++ 's `std::type_info`.
    // Sini o ituaiga `std::type_info`, descriptors ituaiga, ua i ai se e faasino ai i lenei laulau.
    // Ituaiga descriptors o loo taʻua e le fausaga F++ EH faamatalaina i luga ma o le a tatou fausia i lalo.
    //
    // Manatua o le tele moni e tele atu nai lo 3 usize, ae tatou te manaomia lo tatou vtable e faasino atu i le vaega lona tolu.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info mo le vasega elea
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // Masani matou te faʻaaogaina le .as_ptr().add(2) ae e le galue lenei mea i se tulaga faʻavae.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // O lenei le loto i ai e le o faaaogaina le polokalame mangling igoa masani ona tatou te le mananao F++ ina ia mafai ona tuuina atu po o le faiva Rust panics.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // E manaomia lenei ona F++ code mafai ona puʻe tatou execption ma std::exception_ptr ma rethrow ai taimi tele, atonu e oo lava i se isi filo.
    //
    //
    caught: AtomicBool,

    // O lenei manaoga e avea o se Filifiliga ona o le mulimuli i le olaga atoa o le mea F++ semantics: ina catch_unwind uunaʻia le Pusa i fafo o le tuusaunoaga e ao pea tuua le tuusaunoaga mea i se tulaga aloaia ona o lona destructor pea o le a le a valaauina i __cxa_end_catch.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try aumaia moni lava ia i tatou se faʻasino i lenei fausaga.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // Talu ai e le faʻatagaina cleanup() i le panic, ua na ona matou toʻesea.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}