//! Windows SEH
//!
//! I Windows (i le taimi nei na o MSVC), o le tuusaunoaga faaletonu taulimaina faiga ua Tuusaunoaga faatulaga Taulimaina (SEH).
//! E ese mamao atu nai lo Dwarf-faʻavae tuʻusaunoa tagofiaina (faʻataʻitaʻiga, o a isi unix fausaga opea faʻaaogaina) i le tulaga o compiler totonu, o lea LLVM manaʻomia ia i ai le sili atu o le sili atu lagolago mo SEH.
//!
//! I se nutshell, le mea e tupu iinei o le:
//!
//! 1. O le galuega tauave `panic` taʻua i le tulaga o se galuega tauave Windows `_CxxThrowException` e togi a C++ -pei faatagaga faapitoa, triggering le faagasologa unwinding.
//! 2.
//! moa tulaueleele uma e faia e le tuufaatasia faaaogaina le galuega tauave uiga `__CxxFrameHandler3`, se galuega tauave i le CRT, ma le unwinding code i Windows le a faaaogaina lenei galuega tauave uiga e faaoo uma code le faamamaina i luga o le faaputuga.
//!
//! 3. O telefoni uma na tuʻuina mai ile `invoke` o loʻo iai le landing pad seti o se `cleanuppad` LLVM faʻatonuga, e faʻaalia ai le amataga o le faʻamamaina masani.
//! O le tagata (i le sitepu 2, faʻamatalaina i le CRT) e nafa ma le faʻatautaia o le faʻamamaina masani.
//! 4. Mulimuli ane o le "catch" code i le `try` intrinsic (fausia e le tagata tuʻufaʻatasia) faʻatinoina ma faʻailoa mai o le faʻatonutonu e tatau ona toe foi mai i le Rust.
//! Lenei e faia e ala i le `catchswitch` faʻatasi ai ma le `catchpad` faʻatonuga i LLVM IR faʻaupuga, mulimuli ane faʻafoʻi masani pulea i le polokalama ma se `catchret` faʻatonuga.
//!
//! Ni eseesega patino mai le taulimaina tuusaunoaga gcc-faavae o le:
//!
//! * Rust e leai se galuega tauave uiga masani, o nai lo *pea*`__CxxFrameHandler3`.Gata i lea, e leai se faamamăina faaopoopo o loo faatinoina, o lea iu taofi mai soo se C++ tuusaunoaga e tutupu e foliga e pei o le ituaiga o loo tatou tauai.
//! Manatua e tauai se tuusaunoaga i Rust o amioga undefined pea, o lea e tatau ona lelei lenei.
//! * Sa tatou nisi faamatalaga e auina atu i le unwinding tuaoi, aemaise a `Box<dyn Any + Send>`.E pei o ma tuusaunoaga Dwarf ua teuina nei vae e lua e pei o se payload i le ese lava ia.
//! I le MSVC, e ui i lea, e leai se manaʻoga mo se faʻaopoopo faʻaputuga faʻaputuga aua o le valaʻau faaputuga e faʻasaoina ao faʻamamaina galuega tauave o loʻo faʻatinoina.
//! O lenei auala o le vae ua mavae saʻo atu `_CxxThrowException` ua ona toe faaola mai i le galuega faamama i ona tusia i le faaputuga faavaa o le vala aut ¯ u `try`.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // O lenei manaoga e avea o se Filifiliga ona tatou puʻe le tuusaunoaga e faasinomaga ma ua fasiotia lona destructor e le C++ runtime.
    // Pe a tatou ave le Pusa mai le faatagaga faapitoa, e tatau ona tatou tuua le ese mai i se tulaga aloaia mo lona destructor e tamoe e aunoa lua-pau le Pusa.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// ae muamua, o se vaega atoa o faamatalaga ituaiga.E i ai ni nai tulaga-faʻapitoa oddities iinei, ma le tele o na o le matua kopiina mai LLVM.O le faamoemoega o nei mea uma o le faatino o le galuega tauave `panic` i lalo e ala i se valaauga e `_CxxThrowException`.
//
// O lenei galuega e manaomia ai finauga e lua.O le muamua, o le a faasino i le faamatalaga o loo tatou ui i, lea i le tulaga lenei o lo tatou mea trait.Faigofie e maua ai!O le isi, ae peitai, e sili atu ona faigata.
// Lenei o se faʻasino i le `_ThrowInfo` fausaga, ma e masani lava na ona fuafuaina e na o le faʻamatalaina o le tuusaunoaina lafoina.
//
// O le taimi nei o le faamatalaga o lenei ituaiga [1] o se fulufulua itiiti, ma le oddity autu (ma eseesega mai le tusiga i le initoneti) e faapea, i le 32-ūina le vae o vae ae i 64-ūina le vae ua faaalia e pei 32-si offsets mai le `__ImageBase` faʻailoga.
//
// O le macro `ptr_t` ma `ptr!` i le modules o loo i lalo o loo faaaogaina e faaalia ai lenei.
//
// Le paso o ituaiga faamatalaga faapea le totoa foi mea faamatuu LLVM mo lenei ituaiga o taotoga.Mo se faʻataʻitaʻiga, afai e te tuʻufaʻatasia lenei C++ code i le MSVC ma faʻaalu le LLVM IR:
//
//      #include <stdint.h>
//
//      str rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      faaleaogaina foo() { rust_panic a = {0, 1};
//          togi le a;}
//
// Ole mea tonu lena o loʻo matou taumafai e faʻataʻitaʻi.O le tele o tulaga faatauaina e le aunoa o loo i lalo na na kopiina mai LLVM,
//
// I soo se tulaga, na fausiaina uma e nei fausaga i se faiga faapena, ma ua na o teisi verbose mo i tatou.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Manatua matou te le amanaiaina tulafono igoa mangling iinei: matou te le mananaʻo i C++ e mafai ona puʻeina Rust panics i le na o le folafolaina o le `struct rust_panic`.
//
//
// Ina ua toe faaleleia, ia mautinoa e fetaui tonu lava le manoa igoa ituaiga le tasi faaaogaina i `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // O le taʻitaʻiga `\x01` byte iinei o se faʻailoga faataulaitu ia LLVM ia *aua* faʻatulagaina seisi mangling pei o nauna i se faʻailoga `_`.
    //
    //
    // Lenei faʻailoga o le vtable faʻaaogaina e C++ 's `std::type_info`.
    // Sini o ituaiga `std::type_info`, descriptors ituaiga, ua i ai se e faasino ai i lenei laulau.
    // Ituaiga descriptors o loo taʻua e le fausaga F++ EH faamatalaina i luga ma o le a tatou fausia i lalo.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// O lenei ituaiga faʻamatala e faʻaogaina pe a togiina se tuusaunoa.
// O le faiva vaega e taulimaina e le taumafai vala aut ¯ u, lea e faatupuina lona lava TypeDescriptor.
//
// O lenei e lelei talu mai le MSVC runtime faʻaaogaina manoa faʻatusatusaga luga o le ituaiga igoa e faʻafetaui TypeDescriptors nai lo le tutusa faʻasino upu.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destructor faaaogaina pe afai o le++ code F filifili e pueina le ese ma faapau i ai e aunoa ma propagating ai.
// O le vaega puʻeina o le faʻataʻitaʻiina o le a setiina le upu muamua o le tuusaunoa mea i le 0 ina ia o leisi e le faʻaleagaina.
//
// Manatua o le x86 Windows faʻaaogaina le "thiscall" valaʻauina fonotaga mo C++ sui auai galuega ae le o le faʻaaogaina "C" valaʻauina tauaofiaga.
//
// O le exception_copy function e fai lava sina faʻapitoa ii: e faʻaulufaleina e le MSVC faʻasolosolo i lalo o le try/catch poloka ma le panic o loʻo tatou faia iinei o le a faʻaaogaina o se faʻaiuga o le tuʻufaʻatasiga kopi.
//
// E faʻaaogaina e le C++ runtime e lagolago ai le puʻeina o tuusaunoaga ma le std::exception_ptr, e le mafai ona matou lagolagoina ona o le Pusa<dyn Any>e le o clonable.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException faʻamalosia atoa luga o lenei faʻaputuga faʻavae, o lea e leai se mea e sui ai `data` i se faʻaputuga.
    // Tatou na oo a faʻasino faaputuga i lenei galuega tauave.
    //
    // e manaomia iinei le ManuallyDrop talu te le manao tatou Tuusaunoaga ona pau pe unwinding.
    // Nai lo lena o le a pa'ū e exception_cleanup lea e talosagaina e le C++ runtime.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Lenei ... ono foliga mai e faateʻia, ma e matuaʻi saʻo lava.I luga ole 32-bit MSVC o faʻasino i le va o nei fausaga e naʻo lena, faʻasino.
    // I le 64-bit MSVC, peitaʻi, o faʻasino i le va o fausaga o loʻo faʻaalia o ni 32-bit offset mai `__ImageBase`.
    //
    // Ma le iʻuga, i luga ole 32-bit MSVC e mafai ona tatou faʻailoa uma atu nei faʻasino i le 'static`s i luga.
    // I le 64-si MSVC, o le a maua e faailoa tōʻese o vae i statics, lea Rust e le o le taimi nei faatagaina, o lea mafai ona tatou faia moni lava lena.
    //
    // O le isi mea sili ona lelei, lea e faatumuina i nei fausaga i runtime (panicking ua uma ona lava le "slow path").
    // Lea iinei tatou reinterpret fanua o nei e faasino uma e pei 32-si integers ma teuina lea o le tau aogā talafeagai i ai (atomically, e pei ona tupu sosoo panics).
    //
    // Technically le runtime atonu o le a faia a faitau nonatomic o nei fanua, ae i teori latou te leʻi faitau le *sese* taua foi e faapea e le tatau ona tele le leaga ...
    //
    // I soo se tulaga, tatou manaʻomia tatau ona faia se mea e pei o lenei seʻi vagana ua tatou mafai ona faʻaalia atili gaioiga i statics (ma tatou ono le mafai).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // A payload soloia iinei o lona uiga o le a tatou maua iinei mai le faiva (...) o __rust_try.
    // E tupu lenei mea pe a maua se ese mai fafo ole Rust.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Lenei e manaʻomia e le tagata tuʻufaʻatasia ia i ai (eg, o se lang aitema), ae e leʻo valaʻauina moni e le tuʻufaʻatasia ona __C_specific_handler poʻo_except_handler3 o le uiga gaioiga e masani ona faʻaaogaina.
//
// O lea ua na o se stub aborting lenei.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}