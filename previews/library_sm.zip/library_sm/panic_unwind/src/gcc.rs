//! lagolagoina le faatinoga o panics e libgcc/libunwind (i nisi pepa).
//!
//! Mo faamatalaga i tuusaunoaga taulimaina ma faaputuga unwinding faamolemole vaai "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) ma pepa aloaia e fesootai mai ai.
//! Nei faitauina lelei foi:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## O se aotelega puʻupuʻu
//!
//! Tuusaunoaga taulimaina e tupu i vaega e lua: a sailiga vaega ma se vaega tapenaga.
//!
//! I vaega uma e lua, o le faʻamavae savali savali faʻapipiʻi luga mai lalo i lalo faʻaogaina faʻamatalaga mai le faʻaputuga faʻamavae vaega o le nei gaioiga o modules ("module" iinei e faʻasino i se OS module, ie, o se mafai ona faʻaaogaina poʻo se malosi faletusi).
//!
//!
//! Mo faʻaupuga taʻitasi, e faʻailoaina le "personality routine" fesoʻotaʻi, o lona tuatusi o loʻo teuina foʻi ile vaega e faʻamama ai le faʻamatalaga.
//!
//! I le vaega suesuega, o le galuega o se tagata masani, o le suʻesuʻe ese mea ua lafo, ma filifili pe e tatau ona maua i lena tino faaputuga.A maeʻa loa ona faʻailoaina le aufataulima, amata loa le faʻamamaina.
//!
//! I le vaega tapenaga, e fagua ai le unwinder toe masani uiga taitasi.
//! O le taimi lea e filifili ai (pe afai ei ai) manaoga code tapenaga e taufetuli mo le faavaa faaputuga nei.Afai o lea, o le faʻatonutonu ua tuʻuina atu i se branch faʻapitoa i le tino o le tino, o le "landing pad", lea e faʻaosoina ai le au faʻaleagaina, faʻasaolotoina le manatuaina, ma isi.
//! I le faʻaiuga o le pad landing, o le control ua toe faʻafoʻi atu i le unwinder ma unwinding toe amataina.
//!
//! Faʻatasi faaputuga ua unwound i lalo i le tulaga faavaa Handler, unwinding foʻi ona taofi ma le faaliliuina uiga mulimuli masani pulea i le poloka faiva.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// tuusaunoaga a Rust e faailoa vasega.
// Lenei e faʻaaogaina e uiga masani e faʻamautinoa ai pe o le tuʻufaʻatasi na togiina e a latou lava taimi umi.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 ele-tagata faʻatau atu, gagana
    0x4d4f5a_00_52555354
}

// Tusi resitala ids na sii mai le TargetLowering::getExceptionPointerRegister() ma TargetLowering::getExceptionSelectorRegister() LLVM mo le tusiata fale taitasi, ona faailogaina e DWARF tusi resitala numera e ala i tusi resitala laulau faamatalaga (e masani<arch>RegisterInfo.td, ia saili mo "DwarfRegNum").
//
// Tagai foi http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// Ua code nei e faavae i luga o le C GCC ma C++ masani uiga.Mo faamatalaga, tagai:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM EHABI uiga masani.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS Faʻaaoga le masani masani nai lo talu ai na te faʻaaogaina SjLj tatalaina.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // Backtraces i luga o ARM o le a valaʻau ai uiga masani ma tulaga==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // I tulaga na, matou te mananaʻo e faʻaauau pea le faʻamalamalamaga o le faʻaputuga, a leai o tatou tua uma o le a faʻamutaina ile __rust_try
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // O le DWARF faʻamalolo manatu o_Unwind_Context o loʻo taofia mea e pei o le gaioiga ma LSDA faʻasino, peitaʻi o ARM EHABI tuʻuina i latou i le tuʻufaʻatasia mea.
            // Ina ia faʻasaoina saini o galuega e pei o _Unwind_GetLanguageSpecificData(), e naʻo le faʻasino tusi, GCC uiga masani e teu ai se faʻasino i le ese_object i le faʻamatalaga, faʻaaoga le nofoaga faʻasao mo ARM's "scratch register" (r12).
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... A sili atu e mataupu silisili auala o le a e tuuina atu le atoatoa faamatalaga o le a_Unwind_Context aao i tatou libunwind bindings ma aumai le faamatalaga e manaomia mai ai tuusao, bypassing DWARF galuega tauave tulaga ogatasi.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI manaomia e le masani tagata e faafou le taua SP i le cache papupuni o le mea o tuusaunoaga.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // I lima EHABI e nafa ma le masani uiga mo moni unwinding se faavaa faaputuga e tasi ao lei toe foi (lima EHABI failautusi.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // faamatalaina i totonu o libgcc
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // Le masani ai uiga masani, lea e faʻaaoga saʻo i luga o le tele o faʻatulagaina ma le tuusao luga o Windows x86_64 ala i le SEH.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // I x86_64 MinGW faʻatulagaina, o le le faʻamamaina masini o SEH peitaʻi o le faʻamama avega faʻamaumauga (aka LSDA) faʻaaogaina GCC-talafeagai faʻavasegaina.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // O le uiga masani mo le tele o lo tatou sini.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // Le tuatusi faasino 1 byte mavae le faatonuga valaauga, e mafai ona i ai i le tele IP sosoo ai i LSDA laulau tele.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// Fausia faamauina nisi faʻamatalaga unwind
//
// le faatusa o le module taitasi o loo i ai se faavaa o le fuaiupu nisi faʻamatalaga unwind (e masani lava ".eh_frame").A o le module o le loaded/unloaded i totonu o le gaioiga, e tatau ona faʻailoa i le tagata le faʻamamaina mea e uiga i le nofoaga o lenei vaega i mea e te manatuaina.O le auala e ausia ai lena eseese e ala i le tulaga.
// I nisi (eg, Linux), o le unwinder mafai ona e iloa unwind vaega nisi faʻamatalaga i luga o ana lava (e ala i dynamically enumerating modules uta i le taimi nei e ala i le dl_iterate_phdr() API and finding their ".eh_frame" sections); isi, e pei o Windows, e manaomia modules le punouai faamauina latou unwind vaega nisi faʻamatalaga e ala API unwinder.
//
//
// O lenei module faamatalaina faatusa lua ua taʻua ma valaau mai rsbegin.rs e faamauina lo tatou faamatalaga i le runtime GCC.
// Le faatinoga o faaputuga unwinding o (mo le taimi nei) tolopo e libgcc_eh Peitai faaaogaina Rust crates manatu ulufale nei Rust-patino e aloese mai fetauaʻiga gafatia ma so o se runtime GCC.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}