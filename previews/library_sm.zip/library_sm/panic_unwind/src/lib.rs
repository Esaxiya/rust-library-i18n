//! Faatinoga o panics ala unwinding faaputuga
//!
//! O lenei crate o se faatinoga o panics i Rust faaaogaina faiga unwinding faaputuga "most native" o le tulaga o lo o tuufaatasia lenei.
//! E faʻavasegaina lenei mea i ni pakete se tolu i le taimi nei:
//!
//! 1. MSVC sini faʻaoga faʻaaoga le SEH i le `seh.rs` faila.
//! 2. E faʻaaoga e Emscripten tuʻuaga C + i le `emcc.rs` faila.
//! 3. faaaoga isi uma sini libunwind/libgcc i le faila `gcc.rs`.
//!
//! Tele faʻamaumauga e uiga i faʻatinoga taʻitasi e mafai ona maua i vaega taʻitasi.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` e le o faʻaaogaina ma Miri, o lea la, o lapataiga filemu.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Rust runtime's startup mea faʻalagolago i luga o nei faʻailoga, o lea faʻalauiloa latou lautele.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Manulauti le lagolagoina unwinding.
        // - arch=wasm32
        // - os=leai ("bare metal" sini)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Faaaoga le runtime Miri.
        // Tatou lava manaomia ona uta foi le runtime masani i luga, e pei ona faamoemoe rustc nisi mea Lang mai iina e ona faamatalaina.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Faaaoga le runtime moni.
        use real_imp as imp;
    }
}

extern "C" {
    /// Handler i libstd taʻua pe a faapau se mea panic i fafo atu o `catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// Handler i libstd valaauina ina ua maua se faatagaga faapitoa mai fafo.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Ulufale tusi mo le siitiaina o se tuusaunoa, na o le au filifilia i le tulaga-faʻapitoa faʻatinoga.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}