//! Unwinding panics mo Miri.
use alloc::boxed::Box;
use core::any::Any;

// O le ituaiga o totogi o loʻo faʻalauteleina e le afi a le afi e ala i le tatalaina mo i tatou.
// E tatau ona faasino ai le taumafaina.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Miri-tuuina atu o se galuega tauave extern e amata unwinding.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // O le payload tatou oo i `miri_start_panic` le a tonu lava le finauga tatou te maua i `cleanup` lalo.
    // Ma e naʻo le tasi le pusa tatou te faʻatuina i luga, e maua ai se mea faʻatulagaina tele.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Toe maua le autu `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}