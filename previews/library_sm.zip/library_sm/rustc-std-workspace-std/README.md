# O le `rustc-std-workspace-std` crate

Tagai pepa mo le `rustc-std-workspace-core` crate.