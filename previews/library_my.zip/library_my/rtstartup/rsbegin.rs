// rsbegin.o rsend.o ဆိုသည်မှာ "compiler runtime startup objects" ဟုခေါ်သည်။
// ၎င်းတို့တွင် compiler runtime ကိုမှန်ကန်စွာအစပြုနိုင်ရန်လိုအပ်သောကုဒ်များပါရှိသည်။
//
// executable သို့မဟုတ် dylib image ချိတ်ဆက်သောအခါအသုံးပြုသူကုဒ်နှင့်စာကြည့်တိုက်အားလုံးသည်ဤအရာဝတ္ထုဖိုင်နှစ်ခုကြားရှိ "sandwiched" ဖြစ်သည်။ ထို့ကြောင့် rsbegin.o မှကုဒ်သို့မဟုတ်ဒေတာသည်သက်ဆိုင်ရာကဏ္sectionsများတွင်ပထမ ဦး ဆုံးဖြစ်လာပြီး rsend.o မှကုဒ်နှင့်ဒေတာသည်နောက်ဆုံးဖြစ်သည်။
// ဒီအကျိုးသက်ရောက်မှုကိုအပိုင်းတစ်ခုရဲ့အစမှာဒါမှမဟုတ်အဆုံးမှာသင်္ကေတတွေထားရန်အပြင်လိုအပ်သောမည်သည့်ခေါင်းစီးသို့မဟုတ်အောက်ခြေကိုမဆိုထည့်ရန်အသုံးပြုနိုင်သည်။
//
// မှတ်ချက်။ အမှန်တကယ် module entry point သည် C runtime startup object (များသောအားဖြင့် `crtX.o`) ဟုခေါ်သည်။ ၎င်းသည်အခြား runtime component များ၏ initialization callbacks (အခြားအထူးပုံအပိုင်းမှတစ်ဆင့်မှတ်ပုံတင်ထားသော) တွင်တည်ရှိသည်ကိုသတိပြုပါ။
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // stack frame ရဲ့အစကအချက်အလက်အပိုင်းကိုဖြည်လိုက်ပါ
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // unwinder ရဲ့ပြည်တွင်းရေးစာအုပ်-စောင့်ရှောက်မှုအတွက်ခြစ်ရာအာကာသ။
    // ဤသည်ကို $ GCC/unwind-dw2-fde.h တွင် `struct object` ဟုသတ်မှတ်သည်။
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Unwind အင်ဖို registration/deregistration လုပ်ရိုးလုပ်စဉ်။
    // libpanic_unwind ၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // module startup အပေါ် unwind အချက်အလက်မှတ်ပုံတင်ပါ
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // ပိတ်အပေါ်မှတ်ပုံတင်
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-သတ်သတ်မှတ်မှတ် init/uninit လုပ်ရိုးလုပ်စဉ်မှတ်ပုံတင်ခြင်း
    pub mod mingw_init {
        // MinGW ရဲ့ startup တ္ထု (crt0.o/dllcrt0.o) startup လုပ်ထွက်ပေါက်အပေါ် .ctors နှင့် .dtors ကဏ္ဍများအတွက်ကမ္ဘာလုံးဆိုင်ရာတည်ဆောက်မြွက်ပါလိမ့်မယ်။
        // အဆိုပါ DLL ကိုတင်ဆောင်ခြင်းနှင့်မြေပေါ်သို့ချသောအခါ DLLs ၏ဖြစ်ရပ်အတွက်, ဤအမှုကိုပြုသောဖြစ်ပါတယ်။
        //
        // အဆိုပါ linker ကျွန်တော်တို့ရဲ့ပြန်ခေါ်စာရင်း၏အဆုံးတွင်တည်ရှိပြီးဖြစ်ကြောင်းသေချာသည့်ကဏ္ဍ sort ပါလိမ့်မယ်။
        // တည်ဆောက်ကတည်းကကျွန်တော်တို့ရဲ့ပြန်ခေါ်ကွပ်မျက်ခံရပထမဦးဆုံးနှင့်နောက်ဆုံးသူများဖြစ်ကြ၏သောဤလုပ်ဆောင်, ပြောင်းပြန်နိုင်ရန်အတွက် run နေကြသည်။
        //
        //

        #[link_section = ".ctors.65535"] // .ctors ။ * ကို C ပဌနာပြန်ခေါ်
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors ။ *: ကို C ရပ်စဲ callbacks
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}