# stdarch မှပံ့ပိုး

အဆိုပါ `stdarch` crate ပံ့ပိုးပေးမှုများကိုလက်ခံရန်ဆန္ဒရှိထက်ပိုပါ!သင်တို့အားရှေ့ဦးစွာဖြစ်နိုင် repository ကိုထုတ်စစ်ဆေးနှင့်စမ်းသပ်မှုသင်တို့အဘို့အသွားတော်သေချာစေချင်ပါလိမ့်မယ်:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

(မဆိုရှေ့ `nightly-` သို့မဟုတ်အလားတူမပါဘဲ) `rustup` ဥပမာ `x86_x64-unknown-linux-gnu` အသုံးပြုသောအဖြစ် `<your-target-arch>` သုံးဆပစ်မှတ်သည်အဘယ်မှာရှိ။
ဒါ့အပြင်ဒီ repository ကို Rust ၏ညစဉ်ညတိုင်းချန်နယ်တစ်ခုလိုအပ်သည်ကြောင်းကို၎င်းအောက်မေ့!
အထက်ဖော်ပြပါစမ်းသပ်မှုများမှာ `rustup default nightly` (နှင့်ပြန်ပြောင်းရန် `rustup default stable`) ကိုသုံးရန်သင်၏ system တွင်ပုံမှန်ဖြစ်ရန် nightly rust လိုအပ်သည်။

အထက်ပါအဆင့်များမှအလုပ်မလုပ်ပါက [please let us know][new]!

Next ကိုသငျသညျ [find an issue][issues] အပေါ်ထွက်ကိုကူညီနိုင်ထကျနော်တို့အထူးသဖြင့်အချို့အကူအညီနဲ့အသုံးပွုနိုငျသော [`help wanted`][help] နှင့် [`impl-period`][impl] tags များနှင့်အတူအနည်းငယ်မရွေးပါဘူး။ 
x86 တွင်သင်အများဆုံးစိတ်ဝင်စားသူသည်ရောင်းသူ၏ပင်ကိုစရိုက်များကို x86 တွင်အကောင်အထည်ဖော်သည်။ထိုပြissueနာသည်မည်သည့်နေရာတွင်မည်သည့်နေရာတွင်စတင်ရမည်နှင့် ပတ်သက်၍ ကောင်းသောအချက်များရှိသည်။

သငျသညျရရှိပါသည် အကယ်. ယေဘုယျမေးခွန်းများကို [join us on gitter][gitter] အခမဲ့ခံစားရနှင့်န်းကျင်ကိုမေး!မေးခွန်းများကိုအတူ@BurntSushi သို့မဟုတ်@alexcrichton ဖြစ်စေ Ping အခမဲ့ခံစားရသည်။

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# stdarch အခ်ါများအတွက်ဥပမာရေးသားဖို့ဘယ်လို

စနစ်တကျအလုပ်ပေးထားသောအခ်ါအဘို့အဖွင့်ထားရပါမည်နှင့်အင်္ဂါရပ် CPU ကိုကထောက်ခံနေသည်အခါဥပမာအားသာ `cargo test --doc` အားဖြင့် run ရမည်ဟုအနည်းငယ် features တွေရှိပါတယ်။

ရလဒ်အနေနှင့်၊ `rustdoc` မှထုတ်ပေးသောပုံမှန် `fn main` (အများအားဖြင့်) အလုပ်မလုပ်ပါ။
သင်၏နမူနာမျှော်လင့်ထားသည့်အတိုင်းအလုပ်လုပ်ရန်သေချာစေရန်အောက်ပါတို့ကိုလမ်းညွှန်အဖြစ်အသုံးပြုရန်စဉ်းစားပါ။

```rust
/// # // သာဓကကိုသေချာစေရန်ကျွန်ုပ်တို့ cfg_target_feature လိုအပ်သည်
/// # // အဆိုပါ CPU ကိုအဆိုပါအင်္ဂါရပ်ကိုထောက်ပံ့သည့်အခါ `cargo test --doc` အားဖြင့် run
/// # #![feature(cfg_target_feature)]
/// # // ကျနော်တို့အလုပ်ဖို့အခ်ါအဘို့အ target_feature လိုအပ်ပါတယ်
/// # #![feature(target_feature)]
/// #
/// # // ပုံမှန်အားဖြင့် rustdoc `extern crate stdarch` ကိုအသုံးပြုသည်, ဒါပေမယ့်ကျနော်တို့ကလိုအပ်တယ်
/// # // `#[macro_use]`
/// # # [macro_use] ပြင်ပ crate stdarch;
/// #
/// # // အစစ်အမှန်အဓိက function ကို
/// # fn main() {
/// #     // `<target feature>` ကိုသာထောက်ပံ့ပါကဤအရာကိုသာ run ပါ
/// #     cfg_feature_enabled လျှင်! ("<target feature>"){
/// #         // ကိုသာပစ်မှတ်အင်္ဂါရပ်လျှင် run ပါလိမ့်မည်တဲ့ `worker` function ကိုဖန်တီးပါ
/// #         // ထောကျပံ့များနှင့် `target_feature` သင့်ရဲ့အလုပ်သမားများအတွက် enabled ကြောင်းသေချာစေရန်ဖြစ်ပါသည်
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         အန္တရာယ်မကင်း Fn worker() {
/// // သင်၏နမူနာကိုဒီမှာရေးပါ။အင်္ဂါရပ်တိကျသောအခ်ါဒီမှာအလုပ်လုပ်မည်!ရိုင်း Go!
///
/// #         }
///
/// #         အန္တရာယ်မကင်း { worker(); }
/// #     }
/// # }
```

အထက်ပါ syntax အချို့အကျွမ်းတဝင်မကြည့်ဘူးလျှင်, [Rust Book] ၏ [Documentation as tests] အပိုင်းအတော်လေးကောင်းစွာ `rustdoc` syntax ဖော်ပြသည်။
အမြဲအဖြစ်, [join us on gitter][gitter] အခမဲ့ခံစားရနှင့်သင်ဆိုရိုက်သွားထိမှန်လျှင်ကျွန်တော်တို့ကိုမမေးနှင့် `stdarch` ၏စာရွက်စာတမ်းများတိုးတက်လာဖို့ကူညီမှုအတွက်ကျေးဇူးတင်ပါတယ်!

# အခြားရွေးချယ်စရာစမ်းသပ်ခြင်းညွှန်ကြားချက်များ

ဒါဟာယေဘုယျအားဖြင့်သင်စမ်းသပ်မှု run ဖို့ `ci/run.sh` အသုံးပြုအကြံပြုသည်။
သို့သော်၊ သင် Windows တွင်ရှိလျှင်၊

ထိုအခြေအနေမျိုးတွင်သင်သည် code မျိုးဆက်ကိုစမ်းသပ်ရန်အတွက် `cargo +nightly test` နှင့် `cargo +nightly test --release -p core_arch` ကို အသုံးပြု၍ ပြန်သွားနိုင်သည်။
ဤအရာများသည် nightly toolchain ကို install လုပ်ရန်လိုအပ်ပြီး `rustc` သည်သင်၏ target triple နှင့်၎င်း၏ CPU အကြောင်းသိရန်လိုအပ်သည်။
အထူးသဖြင့်သင် `ci/run.sh` အဘို့အလိုတခုတည်းအဖြစ် `TARGET` ပတ်ဝန်းကျင် variable ကိုသတ်မှတ်ထားဖို့လိုပါတယ်။
ထို့အပြင်, သင်သည်ပစ်မှတ် features တွေညွှန်ပြခြင်း (`C` လိုအပ်ပါတယ်) ဥပမာ `RUSTCFLAGS` သတ်မှတ်ထားရန်လိုအပ် `RUSTCFLAGS="-C -target-features=+avx2"`.
သငျသညျ "just" သင့်လက်ရှိ CPU ကိုဆန့်ကျင်ဖွံ့ဖြိုးဆဲနေလျှင်သင်တို့သည်လည်း `-C -target-cpu=native` သတ်မှတ်နိုင်သည်။

[things may go less smoothly than they would with `ci/run.sh`][ci-run-good], ဥပမာ, ဤကအခြားရွေးချယ်စရာညွှန်ကြားချက်ကိုအသုံးပြုတဲ့အခါသတိပေးခံရ
ဥပမာအားဖြင့်ညွှန်ကြားချက်မျိုးစုံစမ်းသပ်မှုများသည်ပျက်ကွက်နိုင်သည်
သူတို့အတူတူပြုမူနေသော်လည်း `vaesenc` အစား `aesenc` ညွှန်ကြားချက်များထုတ်ပေးနိုင်သည်။
ဒါ့အပြင်ထိုအညွှန်ကြားချက်ဒါကြောင့်သင်နောက်ဆုံးမှာ-တောင်းဆိုမှုကိုဆွဲထုတ်တဲ့အခါမှာအချို့သောအမှားများကိုဤနေရာတွင်မဖုံးစမ်းသပ်မှုတက်သည်ကိုပြသအံ့သောငှါအံ့အားသင့်မရကြဘူး, ပုံမှန်အားဖြင့်ပြုသောအမှုမည်ဖြစ်ကြောင်းထက်လျော့နည်းစမ်းသပ်မှု execute ။

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






