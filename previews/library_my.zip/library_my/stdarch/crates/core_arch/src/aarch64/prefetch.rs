#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// [`prefetch`](fn._prefetch.html) ကိုကြည့်ပါ။
pub const _PREFETCH_READ: i32 = 0;

/// [`prefetch`](fn._prefetch.html) ကိုကြည့်ပါ။
pub const _PREFETCH_WRITE: i32 = 1;

/// [`prefetch`](fn._prefetch.html) ကိုကြည့်ပါ။
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// [`prefetch`](fn._prefetch.html) ကိုကြည့်ပါ။
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// [`prefetch`](fn._prefetch.html) ကိုကြည့်ပါ။
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// [`prefetch`](fn._prefetch.html) ကိုကြည့်ပါ။
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// ပေးထားသော `rw` နှင့် `locality` သုံးပြီးလိပ်စာ `p` ပါရှိသည်သော cache ကိုလိုင်းယူခဲ့ပါလော့။
///
/// အဆိုပါ `rw` တစ်ဦးဖြစ်ရပါမည်:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): အဆိုပါ prefetch တစ်ဖတ်များအတွက်ပြင်ဆင်နေသည်။
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): အဆိုပါကြိုတင်ယူထားပြီးတစ်ဦးရေးတို့အတွက်ပြင်ဆင်နေသည်။
///
/// အဆိုပါ `locality` တစ်ဦးဖြစ်ရပါမည်:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): တစ်ကြိမ်သာအသုံးပြုသောဒေတာအတွက် streaming သို့မဟုတ်ယာယီမဟုတ်သောကြိုတင်ရှာဖွေခြင်း။
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): အဆင့်သို့ 3 cache ကိုခေါ်ယူနိုင်သည်။
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): level 2 cache သို့ယူပါ။
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): level 1 cache သို့ယူပါ။
///
/// အဆိုပါကြိုတင်ယူထားပြီး memory ကိုညွှန်ကြားချက်မှတ်ဉာဏ်တစ်သတ်မှတ်ထားသောလိပ်စာကနေ access လုပ်ပါတယ်ဖွယ်ရှိမဝေးတော့တဲ့ future အတွက်ဖြစ်ပေါ်ဖို့ဖြစ်ကြောင်းမှတ်ဉာဏ်စနစ်အချက်ပြ။
/// အဆိုပါမှတ်ဥာဏ်စနစ်ကထိုကဲ့သို့တစ်ဦးသို့မဟုတ်ထိုထက်ပို cache များကိုသို့သတ်မှတ်ထားသောလိပ်စာကြိုလွှတ်တင်ပေးသည်အဖြစ်သူတို့ဖြစ်ပေါ်ပါဘူးအခါမှတ်ဉာဏ် access ကိုအရှိန်မြှင့်ရန်မျှော်လင့်နေကြသည်လုပ်ရပ်များ, ယူခြင်းအားဖြင့်တုံ့ပြန်နိုင်ကြပါသည်။
///
/// ဤအချက်ပြမှုများသည်အရိပ်အမြွက်များသာဖြစ်သောကြောင့်သီးခြား CPU တစ်ခုအနေဖြင့် Prefetch ညွှန်ကြားချက်များအားလုံးကို NOP တစ်ခုအဖြစ်ဆက်ဆံရန်တရားဝင်သည်။
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // ကျနော်တို့ `cache type` =1 (data တွေကို cache ကို) နှင့်အတူ `llvm.prefetch` instrinsic ကိုအသုံးပြုပါ။
    // `rw` နှင့် `strategy` function ကို parameters တွေကိုအပေါ်အခြေခံထားတယ်။
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}