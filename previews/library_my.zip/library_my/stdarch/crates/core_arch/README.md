`core::arch` - Rust ၏အဓိကစာကြည့်တိုက်ဗိသုကာ-တိကျသောအခ်ါများ
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch` module သည်ဗိသုကာ-မှီခိုသည့်ပင်ကိုစရိုက် (ဥပမာ SIMD) ကိုအကောင်အထည်ဖော်သည်။

# Usage 

`core::arch` `libcore` ၏တစ်စိတ်တစ်ပိုင်းအနေဖြင့်ရရှိနိုင်သည်။ ၎င်းကို `libstd` မှပြန်လည်တင်ပို့သည်။ဒီ crate မှတဆင့်ထက် `core::arch` သို့မဟုတ် `std::arch` မှတဆင့်အသုံးပြုခြင်းကို ဦး စားပေးမည်။
မတည်မငြိမ် features တွေအတွက် `feature(stdsimd)` ကနေတဆင့်ညစဉ်ညတိုင်း Rust အတွက်မကြာခဏရရှိနိုင်ပါသည်။

ဤ crate မှတစ်ဆင့် `core::arch` ကိုအသုံးပြုရန်ညစဉ်ညတိုင်း Rust လိုအပ်သည်၊ ၎င်းသည်မကြာခဏချိုးဖျက်နိုင်သည်။ဤ crate မှတစ်ဆင့်အသုံးပြုရန်သင်စဉ်းစားသင့်သည့်တစ်ခုတည်းသောအမှုများမှာ-

* အကယ်၍ သင်သည် `core::arch` ကိုသင်ကိုယ်တိုင်ပြန်လည်စုစည်းရန်လိုအပ်သည်ဆိုပါကဥပမာအားဖြင့် `libcore`/`libstd` အတွက်အသုံးမပြုရသေးသောသီးခြားပစ်မှတ်ထားသည့်အင်္ဂါရပ်များပါဝင်သည်။
Note: သငျသညျ non-စံပစ်မှတ်များအတွက် re-compile ကလိုအပ်တယ်ဆိုရင်အစားဒီ crate အသုံးပြုခြင်း၏သင့်လျော်သောအဖြစ် `xargo` နှင့်ပြန်လည်ရေးသားထား `libcore`/`libstd` သုံးပြီးပိုနှစ်သက်ပါ။
  
* ပင်မတည်မငြိမ် Rust နောက်ကွယ်မှရရှိနိုင်မဖြစ်အံ့သောငှါအခြို့သော features တွေသုံးပြီးပါရှိပါတယ်။ဤအရာများကိုအနိမ့်ဆုံးထားရန်ကျွန်ုပ်တို့ကြိုးစားသည်။
သငျသညျဤအင်္ဂါရပ်အချို့သုံးစွဲဖို့မလိုအပ်ခဲ့လျှင်ကျွန်တော်ညစဉ်ညတိုင်း Rust ၌သူတို့ကိုဖော်ထုတ်နိုင်ပြီးသငျသညျထိုအရပ်မှသူတို့ကိုအသုံးချနိုင်အောင်, ပြဿနာတစ်ခုဖွင့်လှစ်ပါ။

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` အဓိကအားဖြင့်အမျိုးမျိုးသော BSD-တူသောလိုင်စင်ဖြင့်ဖုံးလွှမ်းဝေမျှနှင့်တကွ, MIT လိုင်စင်နှင့် Apache လိုင်စင် (ဗားရှင်း 2.0) နှစ်ဦးစလုံး၏စည်းကမ်းချက်များအောက်မှာဖြန့်ဝေသည်။

အသေးစိတ်အတွက် LICENSE-APACHE နှင့် LICENSE-MIT တို့ကိုကြည့်ပါ။

# Contribution

သငျသညျအတိအလင်းပြည်နယ်မဟုတ်ရင်, ထို Apache-2.0 လိုင်စင်အတွက်သတ်မှတ်ထားသောအဖြစ်ရည်ရွယ်ချက်ရှိရှိ, သငျသညျခွငျးအားဖွငျ့ `core_arch` အတွက်ပါဝင်များအတွက်တင်သွင်းမဆိုအလှူငွေ, မည်သည့်အပိုဆောင်းအသုံးအနှုန်းများသို့မဟုတ်အခြေအနေများမရှိဘဲအထက်အဖြစ်ကို dual လိုင်စင်ရခံရကြလိမ့်မည်မဟုတ်လျှင်။


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












