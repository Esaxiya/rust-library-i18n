use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // အချို့သော X0XX နှင့်တူသောအပို `-Ctarget-feature=+unimplemented-simd128` ၏နောက်ကွယ်တွင် gated ဖြစ်သောကြောင့်အချို့သောအပို `-Ctarget-feature=+unimplemented-simd128` မှတ်ချက်များအား simd ပင်ကိုစရိုက်အားလုံးသည်သူတို့၏ codegen ကိုစမ်းသပ်ရန်ရရှိနိုင်ပါသည်။
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}