//! အဆိုပါ `#[assert_instr]` macro ၏အကောင်အထည်ဖော်မှု
//!
//! အဆိုပါ `stdarch` crate စမ်းသပ်နှင့်လုပ်ငန်းဆောင်တာအမှန်ပင်ငါတို့သည်သူတို့ကိုဆံ့ဖို့မျှော်လင့်နေတဲ့သောညွှန်ကြားချက်ဆံ့မအခိုင်အမာရန်စမ်းသပ်မှုအမှုပေါင်း generate ရန်အသုံးပြုသည့်အခါဤသည်နိုင်တဲ့ macro အသုံးပြုသည်။
//!
//! ဒီမှာလုပ်ထုံးလုပ်နည်းနိုင်တဲ့ macro ကရိုးရှင်းစွာ function ကိုကိုယ်နှိုက်ကသက်ဆိုင်ရာညွှန်ကြားချက်များပါဝင်သည်ပြောဆိုသောအရာမူရင်း token စီးဖို့တစ် `#[test]` function ကို appends, အတော်လေးရိုးရှင်းပါသည်။
//!
//!
//!
//!

extern crate proc_macro;
extern crate proc_macro2;
#[macro_use]
extern crate quote;
extern crate syn;

use proc_macro2::TokenStream;
use quote::ToTokens;

#[proc_macro_attribute]
pub fn assert_instr(
    attr: proc_macro::TokenStream,
    item: proc_macro::TokenStream,
) -> proc_macro::TokenStream {
    let invoc = match syn::parse::<Invoc>(attr) {
        Ok(s) => s,
        Err(e) => return e.to_compile_error().into(),
    };
    let item = match syn::parse::<syn::Item>(item) {
        Ok(s) => s,
        Err(e) => return e.to_compile_error().into(),
    };
    let func = match item {
        syn::Item::Fn(ref f) => f,
        _ => panic!("must be attached to a function"),
    };

    let instr = &invoc.instr;
    let name = &func.sig.ident;

    // avx နှင့်အတူပြုစု x86 ပစ်မှတ်များအတွက် Disable လုပ်ထား assert_instr ကျနော်တို့အဘို့စမ်းသပ်နေသောသူမြားကြောင့်ကွဲပြားခြားနားသောအခ်ါထုတ်လုပ်ဖို့ LLVM ဖြစ်ပေါ်စေသည်သော enabled ။
    //
    //
    let disable_assert_instr = std::env::var("STDARCH_DISABLE_ASSERT_INSTR").is_ok();

    // ညွှန်ကြားချက်စမ်းသပ်မှုအားလုံးမှာဒီရှိန်းပြား emitting မသန်စွမ်းရှောင်ပါလျှင်, ပဲကျွန်တော်တို့ရဲ့ attribute ကိုမပါဘဲမူရင်းကို item ပြန်သွားပါ။
    //
    if !cfg!(optimized) || disable_assert_instr {
        return (quote! { #item }).into();
    }

    let instr_str = instr
        .replace('.', "_")
        .replace('/', "_")
        .replace(':', "_")
        .replace(char::is_whitespace, "");
    let assert_name = syn::Ident::new(&format!("assert_{}_{}", name, instr_str), name.span());
    // ဤရွေ့ကားနာမကိုအမှီကို disassembly နောက်ပိုင်းမှာ၌တွေ့ရှိရန်အဘို့အထူးခြားသောအလုံအလောက်ဖြစ်ဖို့ရှိပါတယ်:
    let shim_name = syn::Ident::new(
        &format!("stdarch_test_shim_{}_{}", name, instr_str),
        name.span(),
    );
    let mut inputs = Vec::new();
    let mut input_vals = Vec::new();
    let ret = &func.sig.output;
    for arg in func.sig.inputs.iter() {
        let capture = match *arg {
            syn::FnArg::Typed(ref c) => c,
            ref v => panic!(
                "arguments must not have patterns: `{:?}`",
                v.clone().into_token_stream()
            ),
        };
        let ident = match *capture.pat {
            syn::Pat::Ident(ref i) => &i.ident,
            _ => panic!("must have bare arguments"),
        };
        if let Some(&(_, ref tokens)) = invoc.args.iter().find(|a| *ident == a.0) {
            input_vals.push(quote! { #tokens });
        } else {
            inputs.push(capture);
            input_vals.push(quote! { #ident });
        }
    }

    let attrs = func
        .attrs
        .iter()
        .filter(|attr| {
            attr.path
                .segments
                .first()
                .expect("attr.path.segments.first() failed")
                .ident
                .to_string()
                .starts_with("target")
        })
        .collect::<Vec<_>>();
    let attrs = Append(&attrs);

    // ပုံမှန်အားဖြင့် Unix (ဘာလို့လဲ?) တွင်ဖြစ်ပျက်သည်ကဲ့သို့မှတ်ပုံတင်တွင် SIMD တန်ဖိုးများကိုလွှဲပြောင်းပေးသော ABI Windows တွင်အသုံးပြုပါ။
    //
    let abi = if cfg!(windows) {
        syn::LitStr::new("vectorcall", proc_macro2::Span::call_site())
    } else {
        syn::LitStr::new("C", proc_macro2::Span::call_site())
    };
    let shim_name_str = format!("{}{}", shim_name, assert_name);
    let to_test = quote! {
        #attrs
        #[no_mangle]
        #[inline(never)]
        pub unsafe extern #abi fn #shim_name(#(#inputs),*) #ret {
            // ပုံမှန်အားဖြင့် optimized mode မှာအဆိုပါ compiler ကတူညီကြည့်သောလုပ်ငန်းဆောင်တာများကိုပေါင်းစည်းပါလိမ့်မယ်ဘယ်မှာ "mergefunc" လို့ခေါ်တဲ့ Pass နှင့်ပြေး။
            // ထွက်ပေါ်လာတဲ့အချက်တွေကတော့တူညီတဲ့ကုဒ်ကိုထုတ်လုပ်ကြတာဖြစ်ပြီးသူတို့ဟာအတူတူခေါက်လိုက်ကြတာပါပဲ။
            // ဤသည်ရှုပ်ထွေးသည့် disassembly ဒီ function ကို၏ကျွန်တော်တို့ရဲ့စစ်ဆေးရေးတက်နှင့်ကျွန်တော်၏ကြီးမားသောပန်ကာမဟုတ်ပါဘူး။
            //
            // ဒီ pass တားဆီးပိတ်ပင်နှင့်ဖြစ်လျက်ရှိရာမှလုပ်ငန်းဆောင်တာကိုကာကွယ်တားဆီးဖို့ကျနော်တို့ codegen ၏စည်းကမ်းချက်များ၌မျှော်လင့်အလွန်တင်းကျပ်စွာပေမယ်ခေါက်ခံရခြင်းမှကုဒ်ကာကွယ်တားဆီးဖို့မဟုတ်ရင်ထူးခြားသောကြောင်းအချို့ code များ generate ပေါင်းစည်း။
            //
            //
            // ဤလုပ်ဆောင်ချက်များကို Wasm32 တွင်ရှောင်ရှားသည်။ ထိုလုပ်ဆောင်ချက်များကိုမသတ်မှတ်ထားသောကြောင့်၎င်းသည်လုပ်ဆောင်မှုဟုခေါ်သောပင်ကိုစရိုက်လက္ခဏာတစ်ခုစီသည်ကျွန်ုပ်တို့၏စမ်းသပ်မှုများကိုချိုးဖောက်သည်။
            // လုပ်ငန်းဆောင်တာထွက်အလှည့ဘာပဲဖြစ်ဖြစ် wasm32 အပေါ်ပေါင်းစည်းဖို့ဆင်တူအလုံအလောက်မရှိကြပေ။
            // ဒီ bug ကို rust-lang/rust#74320 မှာခြေရာခံသည်။
            //
            //
            //
            //
            //
            //
            //
            #[cfg(not(target_arch = "wasm32"))]
            ::stdarch_test::_DONT_DEDUP.store(
                std::mem::transmute(#shim_name_str.as_bytes().as_ptr()),
                std::sync::atomic::Ordering::Relaxed,
            );
            #name(#(#input_vals),*)
        }
    };

    let tokens: TokenStream = quote! {
        #[test]
        #[allow(non_snake_case)]
        fn #assert_name() {
            #to_test

            ::stdarch_test::assert(#shim_name as usize,
                                   stringify!(#shim_name),
                                   #instr);
        }
    };

    let tokens: TokenStream = quote! {
        #item
        #tokens
    };
    tokens.into()
}

struct Invoc {
    instr: String,
    args: Vec<(syn::Ident, syn::Expr)>,
}

impl syn::parse::Parse for Invoc {
    fn parse(input: syn::parse::ParseStream) -> syn::Result<Self> {
        use syn::{ext::IdentExt, Token};

        let mut instr = String::new();
        while !input.is_empty() {
            if input.parse::<Token![,]>().is_ok() {
                break;
            }
            if let Ok(ident) = syn::Ident::parse_any(input) {
                instr.push_str(&ident.to_string());
                continue;
            }
            if input.parse::<Token![.]>().is_ok() {
                instr.push('.');
                continue;
            }
            if let Ok(s) = input.parse::<syn::LitStr>() {
                instr.push_str(&s.value());
                continue;
            }
            println!("{:?}", input.cursor().token_stream());
            return Err(input.error("expected an instruction"));
        }
        if instr.is_empty() {
            return Err(input.error("expected an instruction before comma"));
        }
        let mut args = Vec::new();
        while !input.is_empty() {
            let name = input.parse::<syn::Ident>()?;
            input.parse::<Token![=]>()?;
            let expr = input.parse::<syn::Expr>()?;
            args.push((name, expr));

            if input.parse::<Token![,]>().is_err() {
                if !input.is_empty() {
                    return Err(input.error("extra tokens at end"));
                }
                break;
            }
        }
        Ok(Self { instr, args })
    }
}

struct Append<T>(T);

impl<T> quote::ToTokens for Append<T>
where
    T: Clone + IntoIterator,
    T::Item: quote::ToTokens,
{
    fn to_tokens(&self, tokens: &mut proc_macro2::TokenStream) {
        for item in self.0.clone() {
            item.to_tokens(tokens);
        }
    }
}