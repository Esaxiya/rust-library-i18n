//! ဖြစ်စဉ်ကိုကိုယ်ဝန်ဖျက်ချမှတဆင့် Rust panics ၏အကောင်အထည်ဖော်ရေး
//!
//! unwinding ကနေတဆင့်အကောင်အထည်ဖော်မှုနှင့်နှိုင်းယှဉ်လိုက်တဲ့အခါ, ဒီ crate *အများကြီး* ရိုးရှင်းတဲ့ပါ!ဒါကဖြစ်လျက်ရှိကအတော်လေးအဖြစ်စွယ်စုံမဟုတ်ဘူး, ဒါပေမယ့်ဒီနေရာမှာဝင်က,
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" သက်ဆိုင်သောရပ်နားခြင်းမှ payload နှင့် shim သက်ဆိုင်သည်။
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // std::sys::abort_internal ကိုပဌနာ
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Windows တွင်, Processor ကို-တိကျတဲ့ __fastfail ယန္တရားကိုအသုံးပြုပါ။Windows 8 မှာနောက်ပိုင်းတွင်, ဒီဆို In-ဖြစ်စဉ်ကိုခြွင်းချက်ကိုင်တွယ်ပြေးခြင်းမရှိဘဲချက်ချင်းလုပ်ငန်းစဉ်ရပ်ဆိုင်းပါလိမ့်မယ်။
            // Windows ၏အစောပိုင်းဗားရှင်းများတွင်ညွှန်ကြားချက်၏ဤ sequence ကိုလုပ်ငန်းစဉ်ရပ်စဲထားတဲ့ access ကိုချိုးဖောက်မှုအဖြစ်ကုသပေမယ့်သေချာပေါက်အားလုံးခြွင်းချက်ကိုင်တွယ်ကျော်လွှားမပါဘဲလိမ့်မည်။
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: ၎င်းသည် libstd's `abort_internal` ကဲ့သို့အကောင်အထည်ဖော်မှုနှင့်အတူတူပင်
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// ဒါ ... ထူးဆန်းနေတယ်။အဆိုပါ tl; ဒေါက်တာ;၎င်းသည်မှန်ကန်စွာချိတ်ဆက်ရန်လိုအပ်သည်ဆိုလျှင်ပိုမိုရှည်လျားသောရှင်းပြချက်ကိုအောက်တွင်ဖော်ပြထားသည်။
//
// ယခုကျွန်ုပ်တို့ပို့ဆောင်သော libcore/libstd ၏ binaries များသည် `-C panic=unwind` နှင့်ပေါင်းစည်းထားသည်။ဤအရာသည် binaries များသည်ဖြစ်နိုင်သမျှအခြေအနေများနှင့်အပြည့်အဝသဟဇာတဖြစ်အောင်သေချာစေရန်ပြုလုပ်သည်။
// အဆိုပါ compiler, သို့သော်, `-C panic=unwind` နှင့်အတူပြုစုအားလုံးလုပ်ဆောင်ချက်များကိုများအတွက် "personality function" လိုအပ်သည်။ဤသည်ကိုယ်ရည်ကိုယ်သွေး function ကို `rust_eh_personality` သင်္ကေတမှ hardcoded နှင့် `eh_personality` lang ကို item အားဖြင့်သတ်မှတ်ထားသည်။
//
// So...
// အဘယ်ကြောင့်ဒီနေရာမှာကြောင်း lang ကို item သတ်မှတ်မရ?မေးခွန်းကောင်း!panic Runtime အတွက်နှင့်ဆက်စပ်လျက်ရှိသောအဆိုပါလမ်းကိုအမှန်တကယ်အခြားအမှန်တကယ်နှင့်ဆက်စပ်သည်မပါလျှင်သူတို့က compiler ရဲ့ crate store မှာနေ "sort of" ပေမယ်သာအမှန်တကယ်ဆက်နွယ်နေတဲ့နည်းနည်းမသိမသာ၌တည်ရှိ၏။
//
// ဤသည်အဆုံးသတ်သွားသည်ဆိုလိုသည်မှာဤ crate နှင့် panic_unwind crate တို့သည် compiler ၏ crate စတိုးတွင်ပေါ်လာနိုင်သည်။ အကယ်၍ နှစ် ဦး စလုံး `eh_personality` lang item ကိုသတ်မှတ်လျှင်၎င်းသည်မှားသွားလိမ့်မည်။
//
// ဒီကိုင်တွယ်ရန် compiler ကသာအတွက်နှင့်ဆက်စပ်လျက်ရှိသည့် panic runtime ကအဆိုပါ unwinding runtime ကဖြစ်ပြီး, မဟုတ်ရင်က (ကွက်တိဒါ) သတ်မှတ်ခံရဖို့မလိုအပ်ပါရဲ့လျှင် `eh_personality` သတ်မှတ်ပါတယ်လိုအပ်သည်။
// ဒီနေရာမှာ၊ ဒီစာကြည့်တိုက်ကဒီအမှတ်အသားကိုသတ်မှတ်ရုံသက်သက်အနည်းဆုံးတစ်နေရာရာမှာရှိတယ်။
//
// အမှန်ကတော့ဒီသင်္ကေတကို libcore/libstd binaries တွေနဲ့ချိတ်ဆက်ဖို့အတွက်သတ်မှတ်ထားတာပါ။ ဒါပေမယ့်ကျွန်တော်တို့က unwinding runtime မှာလုံးဝချိတ်ဆက်ထားခြင်းမရှိတဲ့အတွက်အဲဒါကိုဘယ်တော့မှမခေါ်သင့်ဘူး။
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // x86_64-pc-windows-gnu မှာငါတို့ကိုယ်ကိုယ်ကိုယ်ကိုယ်ကိုယ်ကိုယ်တိုင်ကိုယ်ကိုယ်တိုင် function ကိုသုံးတယ်။ သူက frame တွေအားလုံးကိုဖြတ်သွားတိုင်း `ExceptionContinueSearch` ကိုပြန်ပေးရမယ်။
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // အထက်ပါနှင့်ဆင်တူသည်မှာ၎င်းသည်လက်ရှိ Emscripten တွင်သာအသုံးပြုသော `eh_catch_typeinfo` lang item နှင့်ကိုက်ညီသည်။
    //
    // panics သည်ခြွင်းချက်များကိုမထုတ်ပေးပါ၊ နိုင်ငံခြားချွင်းချက်များသည်လက်ရှိတွင် -C panic=abort (၎င်းသည်အပြောင်းအလဲဖြစ်နိုင်သည်ဖြစ်သော်လည်း UB) ဖြစ်သောကြောင့် catch_unwind ခေါ်ဆိုမှုများသည်ဤ typeinfo ကိုဘယ်တော့မျှအသုံးမပြုပါ။
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // အဲဒီနှစျခု i686-PC-ပြတင်းပေါက်-gnu ပေါ်မှာငါတို့ startup တ္ထုအားဖြင့်ခေါ်တော်မူကြသည်, ဒါပေမယ့်အလောင်းတွေ nops ရှိပါတယ်ဒါကြောင့်သူတို့ကဘာမှမလုပ်ပေးရန်မလိုအပ်ပါဘူး။
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}