# အဆိုပါ `rustc-std-workspace-core` crate

ဤ crate သည် Shim နှင့်пуသော crate ဖြစ်ပြီး `libcore` ပေါ်တွင်မူတည်ပြီး၎င်းတွင်ပါ ၀ င်သောအရာအားလုံးကိုပြန်လည်တင်ပို့သည်။
အဆိုပါ crate crates.io ထံမှ crates အပေါ်မူတည်မှစံစာကြည့်တိုက်အားပေး၏ crux ဖြစ်ပါသည်

crates.io အပေါ် Crates စံစာကြည့်တိုက်အချည်းနှီးသောအရာ crates.io မှ `rustc-std-workspace-core` crate အပေါ်မူတည်မှလိုအပ်အပေါ်မူတည်ကြောင်း။

ဤသိုလှောင်ရာနေရာရှိ crate သို့၎င်းကို Override လုပ်ရန် `[patch]` ကိုကျွန်ုပ်တို့အသုံးပြုသည်။
ရလဒ်အနေဖြင့် crates.io ရှိ crates သည်မှီခိုသော edge ကိုဤ repository တွင်ဖော်ပြထားသောဗားရှင်း `libcore` သို့ဆွဲလိမ့်မည်။
ဒါက Cargo အောင်မြင်စွာ crates တည်ဆောက်သေချာစေရန်အပေါငျးတို့သမှီခိုအနားဆွဲသင့်ပါတယ်!

crates.io ရှိ crates သည်ဤ crate ပေါ်တွင် မူတည်၍ အရာအားလုံးမှန်ကန်စွာအလုပ်လုပ်နိုင်ရန်အတွက် `core` ဟူသောအမည်ဖြင့်မှီခိုရန်လိုအပ်သည်။သူတို့လုပ်နိုင်တာကတော့

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

အဆိုပါ `package` key ကိုအသုံးပြုခြင်းမှတဆင့် crate ကတူပါလိမ့်မယ်ဆိုလိုတာက `core` မှအမည်ပြောင်းဖြစ်ပါတယ်

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

Cargo အဆိုပါ compiler အမှီ ပြု. သောအခါ, သွယ်ဝိုက် `extern crate core` ညွှန်ကြားချက်ကျေနပ်အဆိုပါ compiler အားဖြင့်ထိုးသွင်း။




