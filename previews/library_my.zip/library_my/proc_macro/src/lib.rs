//! မက္ကရိုစာရေးဆရာများများအတွက်တစ်ဦးကထောက်ခံမှုစာကြည့်တိုက်သစ်ကိုဘာလို့လဲဆိုတော့ Micro စနစ်နဲ့အခြားသော defining အခါ။
//!
//! စံပြဖြန့်ဖြူးခြင်းမှထောက်ပံ့ပေးသောဤစာကြည့်တိုက်သည်လုပ်ထုံးလုပ်နည်းဆိုင်ရာသတ်မှတ်ထားသော macro အဓိပ္ပာယ်များ၏မျက်နှာပြင်များ၌စားသုံးမှုအမျိုးအစားများကိုထောက်ပံ့ပေးသည်။ ဥပမာ-`#[proc_macro]` function၊ macro attribute `#[proc_macro_attribute]` နှင့် custom derib attributes`#[proc_macro_derive]`။
//!
//!
//! ပိုမိုသိရှိရန် [the book] ကိုကြည့်ပါ။
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// proc_macro ကိုလက်ရှိလည်ပတ်နေသောအစီအစဉ်သို့လက်လှမ်းမီခြင်းရှိမရှိဆုံးဖြတ်သည်။
///
/// အဆိုပါ proc_macro crate သာလုပ်ထုံးလုပ်နည်းဘာလို့လဲဆိုတော့ Micro စနစ်နဲ့အခြားသောများ၏အကောင်အထည်ဖော်မှုအတွင်း၌အသုံးပြုရန်ရည်ရွယ်ထားသည်။ထိုကဲ့သို့သောတည်ဆောက် script ကိုသို့မဟုတ်ယူနစ်စမ်းသပ်မှုသို့မဟုတ်သာမန် Rust binary ကနေအဖြစ်လုပ်ထုံးလုပ်နည်း macro, ပြင်ပကနေ invoked လျှင်ဒီ crate panic ၌ရှိသမျှသောလုပ်ဆောင်ချက်များကို။
///
/// မက္ကရိုနဲ့ Non-နိုင်တဲ့ macro အသုံးပြုမှုကိုအမှုပေါင်းနှစ်ဦးစလုံးထောကျပံ့ဖို့ဒီဇိုင်းဖြစ်ကြောင်း Rust စာကြည့်တိုက်များအတွက်ထည့်သွင်းစဉ်းစားအတူ, `proc_macro::is_available()` အခြေခံအဆောက်အအုံ proc_macro ၏ API ကိုသုံးစွဲဖို့မလိုအပ်ရှိမရှိ detect လုပ်ဖို့ non-စိုးရိမ်မလမ်းလက်ရှိရရှိနိုင်ပါသည်ပေးပါသည်။
/// အခြားမည်သည့် binary ထံမှမဖြစ်၏လျှင်လုပ်ထုံးလုပ်နည်းနိုင်တဲ့ macro, မှားယွင်းသော၏အတွင်းပိုင်းကနေမဖြစ်၏လျှင်စစ်မှန်တဲ့ပြန်သွားပါ။
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// tokens ၏စိတ္တဇစီးဆင်းမှုကိုကိုယ်စားပြုသောဤ crate သို့မဟုတ်အဓိကအားဖြင့် token သစ်ပင်များကိုကိုယ်စားပြုသောဤ crate မှပေးသောအဓိကအမျိုးအစား။
/// အမျိုးအစားများထဲမှစမ်းချောင်းသို့ token သစ်ပင်နံပါတ်စုဆောင်း, အပြန်အလှန်ထို token သစ်ပင်များကျော် iterating များအတွက် interfaces ပေး။
///
///
/// ဤသည် `#[proc_macro]`, `#[proc_macro_attribute]` နှင့် `#[proc_macro_derive]` အဓိပ္ပာယ်များ၏ input ကိုနှင့် output ကိုနှစ်ဦးစလုံးဖြစ်ပါတယ်။
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// မှားယွင်းနေသည် `TokenStream::from_str` ကနေပြန်လေ၏။
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// token သစ်ပင်များမပါသည့်အချည်းနှီးသော `TokenStream` သို့ပြန်သွားသည်။
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// စစ်ဆေးမှုများဒီ `TokenStream` ဗလာဖြစ်နေသည်ဆိုပါက။
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// string ကို tokens သို့ချိုးရန်နှင့် tokens ကို token စီးထဲသို့ခွဲရန်ကြိုးစားသည်။
/// string ကိုဘာသာစကားကိုအတွက်တည်ဆဲမဟုတ်သည်ညီမျှမှုကိုအနားသတ်မျဉ်းသို့မဟုတ်အက္ခရာများပါဝင်မယ်ဆိုရင်ဥပမာ, အကြောင်းပြချက်တစ်ခုအရေအတွက်ကျရှုံးနိုင်ပါစေ။
///
/// အဆိုပါဆန်းစစ်မှုစမ်းချောင်းထဲမှာအားလုံး tokens `Span::call_site()` span ရ။
///
/// NOTE: အချို့သောအမှားများက 0panics ကို `LexError` ပြန်မပို့ဘဲဖြစ်စေနိုင်သည်။နောက်ပိုင်းတွင် `LexError`s သို့အဲဒီချို့ယွင်းချက်ပြောင်းလဲခွင့်ကျနော်တို့ကြိုတင်ယူထား။
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB၊ Bridge သည် `to_string` ကိုသာပံ့ပိုးပေးပြီး၊ `fmt::Display` ကို အခြေခံ၍ အကောင်အထည်ဖော်သည် (နှစ်ခုကြားရှိပုံမှန်ဆက်ဆံရေး၏ပြောင်းပြန်)
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// `token စီးဆင်းမှုကိုကြိုးတစ်ခုအဖြစ် token စီးကြောင်း (modulo spans) သို့ပြန်ပြောင်း။ အရှုံးပြောင်း။ ပြောင်းလဲနိုင်သောကြိုးတစ်ခုအဖြစ်ပုံနှိပ်ထုတ်ဝေသည်။ ဖြစ်နိုင်သည်မှာ` `Delimiter::None` delimiters နှင့်အနုတ်ကိန်းဂဏန်း literals များဖြစ်နိုင်သည်။
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// debugging အဘို့အဆင်ပြေတဲ့ပုံစံ token ပုံနှိပ်။
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// token သစ်ပင်တစ်ခုတည်းပါ ၀ င်သည့် token စီးကိုဖန်တီးသည်။
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// token သစ်ပင်အမြောက်အများကိုစမ်းချောင်းတစ်ခုထဲသို့စုဆောင်းသည်။
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// token စီးများပေါ်ရှိ "flattening" စစ်ဆင်ရေးတစ်ခုသည် token စီးဆင်းမှုများစွာမှ token သစ်ပင်များကိုတစ်ခုတည်းစီးထဲသို့စုဆောင်းသည်။
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) ဖြစ်နိုင်ခြေရှိသောအကောင်းဆုံးအကောင်အထည်ဖော်မှု if/when ကိုသုံးပါ။
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// ထိုကဲ့သို့သောကြားမှာအဖြစ် `TokenStream` အမျိုးအစားများအတွက်အများပိုင်အကောင်အထည်ဖော်မှုအသေးစိတ်ကို။
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// `TokenStream`'s`TokenTree`s ကိုကျော်ဖြတ်ပါ။
    /// အဆိုပါကြားမှာဥပမာ, အကြားမှာ delimited အုပ်စုများသို့ recurse နှင့် token သစ်ပင်များအဖြစ်ပြန်ပြင်လုံးကိုအုပျစုမြားမ "shallow" ဖြစ်ပါတယ်။
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` မတရား tokens ကိုလက်ခံပြီး input ကိုဖော်ပြသည့် `TokenStream` သို့ချဲ့ထွင်သည်။
/// ဥပမာအားဖြင့်၊ `quote!(a + b)` သည်ဖော်ပြချက်တစ်ခုထုတ်ပေးလိမ့်မည်။ အကဲဖြတ်သည့်အခါ `TokenStream` `[Ident("a"), Punct('+', Alone) ကိုတည်ဆောက်သည်။ Ident("b")]`.
///
///
/// Unquoting သည် `$` ဖြင့်ပြုလုပ်ပြီးနောက်တစ်ခုကို unquote term အဖြစ်ခေါ်ဆိုခြင်းဖြင့်အလုပ်လုပ်သည်။
/// `$` ကိုယ်တိုင်ကိုကိုးကားရန် `$$` ကိုသုံးပါ။
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// macro တိုးချဲ့သတင်းအချက်အလက်နှင့်အတူအရင်းအမြစ်ကုဒ်၏ဒေသ။
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// အဆိုပါ span `self` မှာပေးထားသော `message` နှင့်အတူသစ်တစ်ခု `Diagnostic` ဖန်တီးပေးပါတယ်။
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// အဆိုပါနိုင်တဲ့ macro ချက်နှင့်အဓိပ္ပါယ် site ကိုမှာဌာန်းတစ်ဦးက span ။
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// လက်ရှိလုပ်ထုံးလုပ်နည်းဆိုင်ရာ macro ၏ invocation ၏သက်တမ်း။
    /// ဒီ span နှင့်အတူဖန်တီး identifiers သူတို့နိုင်တဲ့ macro ခေါ်ဆိုခ site ကိုမှာနိုင်တဲ့ macro ခေါ်ဆိုခတည်နေရာ (ဖုန်းခေါ် site ကိုသန့်ရှင်းရေး) နှင့်အခြားကုဒ်မှာတိုက်ရိုက်ရေးသားခဲ့လျှင်အဖြစ်ဖြေရှင်းပါလိမ့်မည်ကောင်းစွာအဖြစ်သူတို့ကိုရည်ညွှန်းနိုင်ပါလိမ့်မည်။
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// `macro_rules` တစ်ကိုယ်ရေသန့်ရှင်းရေးကိုကိုယ်စားပြုပြီးတစ်ခါတစ်ရံ macro definition site (local variable များ, label, `$crate`) နှင့်တစ်ခါတစ်ရံ macro call site (အခြားအရာအားလုံး) တွင်ပြသော span ။
    ///
    /// အဆိုပါ span တည်နေရာခေါ်ဆိုမှု-site မှယူထားပါသည်။
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// ဒီ span ညွှန်ပြသည့်သို့မူရင်းအရင်းအမြစ်ဖိုင်။
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// ရှိလျှင် `self` မှထုတ်ပေးခဲ့သည့်အနေဖြင့်ယခင်နိုင်တဲ့ macro တိုးချဲ့အတွက် tokens များအတွက် `Span` ။
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// `self` မှထုတ်လုပ်ခဲ့သောမူလရင်းမြစ်ကုန်ကျစရိတ်။
    /// ဒီ `Span` သည်အခြားနိုင်တဲ့ macro ချဲ့ထွင်ရာမှထုတ်လုပ်ပြီးမခံခဲ့ရလျှင်ပြန်တန်ဖိုးကို `*self` အဖြစ်အတူတူပင်ဖြစ်ပါသည်။
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// ဤ span အတွက်အရင်းအမြစ်ဖိုင်မှစတင်သော line/column ကိုရရှိသည်။
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// အဆုံးသတ် line/column ကိုဒီ span အတွက် source file မှာရပါတယ်။
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// `self` နှင့် `other` ပါ ၀ င်သော span အသစ်တစ်ခုကိုဖန်တီးသည်။
    ///
    /// `self` နှင့် `other` သည်မတူညီသောဖိုင်များမှဖြစ်လျှင် `None` သို့ပြန်သွားသည်။
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// `self` ကဲ့သို့တူညီသော line/column သတင်းအချက်အလက်နှင့်အတူသစ်တစ်ခု span ဖန်တီးဒါပေမယ့် `other` မှာရှိ၏သော်လည်းအဖြစ်ဌာန်းသင်္ကေတဖြစ်သည်။
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// span အသစ်တစ်ခုကို `self` ကဲ့သို့သော resolution resolution အပြုအမူများရှိသော်လည်း `other` ၏ line/column အချက်အလက်နှင့်အတူ span အသစ်တစ်ခုကိုဖန်တီးသည်။
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// သူတို့တန်းတူညီမျှမှုရှိမရှိသိရန် span များနှင့်နှိုင်းယှဉ်သည်။
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// တစ်ထွာနောက်ကွယ်မှအရင်းအမြစ်စာသားကို Returns ။
    /// ဤသည်နေရာများနှင့်မှတ်ချက်များအပါအဝင်မူရင်း source code ကို, ထိန်းသိမ်း။
    /// span သည်အစစ်အမှန်ကုဒ်နံပါတ်နှင့်ကိုက်ညီမှသာရလဒ်ကိုပြသည်။
    ///
    /// Note: မက်ခရို၏ကြည့်ရှုနိုင်သည့်ရလဒ်သည်ဤအရင်းအမြစ်စာသားကိုသာမဟုတ်ဘဲ tokens ကိုသာမှီခိုသင့်သည်။
    ///
    /// ဤလုပ်ဆောင်ချက်၏ရလဒ်သည်ရောဂါရှာဖွေရေးအတွက်သာအကောင်းဆုံးအသုံးပြုရန်ဖြစ်သည်။
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// debugging များအတွက်အဆင်ပြေတဲ့ပုံစံကိုတစ်ထွာအားပရင့်ထုတ်ရန်။
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// `Span` ၏အစသို့မဟုတ်အဆုံးကိုကိုယ်စားပြုသောမျဉ်းကြောင်း-ကော်လံအတွဲ။
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// span (inclusive) စတင်သည်သို့မဟုတ်အဆုံးသတ်သည့် source file ရှိ 1 indexed line ဖြစ်သည်။
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// အဆိုပါ span စတင်သည်သို့မဟုတ် (inclusive) အဆုံးသတ်ထားတဲ့အပေါ်အရင်းအမြစ်ဖိုင်ထဲမှာ (UTF-8 ဇာတ်ကောင်မှာ) ပါ 0 င်-index ကော်လံ။
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// ပေးထားသော `Span` ၏အရင်းအမြစ်ဖိုင်ကို။
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// ဤအရင်းအမြစ်ဖိုင်လမ်းကြောင်းကိုရရှိသွားတဲ့။
    ///
    /// ### Note
    /// ဒီ `SourceFile` နှင့်ဆက်စပ် code ကို span ပြင်ပနိုင်တဲ့ macro ကနေထုတ်လုပ်လိုက်တဲ့ခံခဲ့ရလျှင်ဤနိုင်တဲ့ macro ဤဖိုင်စနစ်တခုတခုအပေါ်မှာအမှန်တကယ်လမ်းကြောင်းကိုမည်မဟုတ်ပါ။
    /// စစ်ဆေးရန် [`is_real`] ကိုသုံးပါ။
    ///
    /// ဒါ့အပြင် `is_real` `true` ပြန်လာလျှင်ပင် `--remap-path-prefix` က command line ပေါ်လွန်ခံခဲ့ရလျှင်, ပေးထားသောအဖြစ်လမ်းကြောင်းကိုအမှန်တကယ်တရားဝင်မဖွစျစခွေငျးငှါမှတ်ချက်။
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// ဤအရင်းအမြစ်ဖိုင်သည်တကယ့်အရင်းအမြစ်ဖိုင်ဖြစ်ပြီးပြင်ပ macro ၏ချဲ့ထွင်မှုမှထုတ်လုပ်ခြင်းမရှိပါက `true` ကိုပြန်ပို့သည်။
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // intercrate span အကောင်အထည်ဖော်နေကြသည်ကျနော်တို့ပြင်ပဘာလို့လဲဆိုတော့ Micro စနစ်နဲ့အခြားသောအတွက်ထုတ်ပေး span များအတွက်အစစ်အမှန်အရင်းအမြစ်ဖိုင်တွေရှိနိုင်ပါသည်သည်အထိဒါက hack ကဖြစ်ပါတယ်။
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// တစ်ဦးကတစ်ခုတည်း token သို့မဟုတ် token သစ်ပင်များ (ဥပမာ `[1, (), ..]`) ၏အနားသတ်မျဉ်း sequence ကို။
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// bracket delimiters ကဝိုင်း token စီးသည်။
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// အမှတ်အသားတစ်ခု။
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// တစ်ဦးကတစ်ခုတည်းပုဒ်ဖြတ်ပုဒ်ရပ်အက္ခရာ (စသည်တို့ကို `+`, `,`, `$`,) ။
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// စာသားစာသား (`'a'`), string (`"hello"`), နံပါတ် (`2.3`), စသည်
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// ပါ ၀ င်သော token သို့မဟုတ် delimited stream ၏ `span` method ကိုလွှဲအပ်။ ဤသစ်ပင်၏သက်တမ်းကိုပြန်သွားသည်။
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// *သာဒီ token* အတွက် span ကိုပြုပြင်သည်။
    ///
    /// ဒီ token တစ် `Group` လျှင်ဖြစ်လျှင်ဤနည်းလမ်းသည်ပြည်တွင်းရေး tokens ၏တစ်ဦးချင်းစီ၏သက်တမ်းကို configure မည်မဟုတ်ကြောင်းမှတ်ချက်, ဒီရိုးရှင်းစွာအသီးအသီးမူကွဲ၏ `set_span` နည်းလမ်းမှလွှဲအပ်မည်ဖြစ်သည်။
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// debugging များအတွက်အဆင်ပြေပုံစံ token သစ်ပင်ပုံနှိပ်။
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // ဤအရာစီဆင်းသက်လာဒီဘာဂ်အတွက် struct အမျိုးအစားထဲမှာ name ကိုရှိပါတယ်, ဒါကြောင့်သွယ်ဝိုက်တစ်ဦးအပိုဆောင်းအလွှာနှင့်အတူနှောငျ့ယှကျဘူး
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB၊ Bridge သည် `to_string` ကိုသာပံ့ပိုးပေးပြီး၊ `fmt::Display` ကို အခြေခံ၍ အကောင်အထည်ဖော်သည် (နှစ်ခုကြားရှိပုံမှန်ဆက်ဆံရေး၏ပြောင်းပြန်)
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// အဆိုပါ token သစ်ပင် `Delimiter::None` အနားသတ်မျဉ်းများနှင့်အနှုတ်လက္ခဏာဂဏန်းတှေနဲ့အတူဖြစ်နိုင်သည် `TokenTree: : Group`s မှလွဲ. တူညီ token သစ်ပင် (modulo span) သို့ losslessly ပြောင်းပြန်ဖြစ်လို့ယူဆတယ်သော string ကိုအဖြစ်အားပရင့်ထုတ်ရန်။
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// တစ် ဦး ကအနားသတ် token စီး။
///
/// `Group` တွင် `TokenStream` ပါ ၀ င်ပြီး `Delimiter`s 'ဝိုင်းရံထားသည်။
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// token သစ်ပင်များအစဉ်လိုက်မည်သို့ခွဲခြားထားသည်ကိုဖော်ပြသည်။
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// တစ်ခုကသွယ်ဝိုက်အနားသတ်မျဉ်းကြောင်း, ဥပမာ, တစ်ဦး "macro variable" `$var` ကနေလာမယ့် tokens န်းကျင်ပေါ်လာလိမ့်မည်။
    /// `$var` `1 + 2` ကဲ့သို့သောကိစ္စရပ်များတွင်အော်ပရေတာ၏ ဦး စားပေးများကိုထိန်းသိမ်းရန်အရေးကြီးသည်။
    /// သွယ်ဝိုက်အနားသတ်မျဉ်းတစ်ခု string ကိုတဆင့်တစ်ဦး token စီး၏ roundtrip ရှင်သန်နိုင်မည်မဟုတ်ပါ။
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// ပေးထားသော delimiter နှင့် token စီးသော `Group` အသစ်တစ်ခုကိုပြုလုပ်သည်။
    ///
    /// ဤတည်ဆောက်မှုသည်ဤအုပ်စုအတွက် span ကို `Span::call_site()` ဟုသတ်မှတ်မည်။
    /// span ကိုပြောင်းဖို့သင်အောက်က `set_span` method ကိုသုံးနိုင်သည်။
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// ဒီ `Group` ၏အပိုင်းအခြားကိုပြန်သွားသည်
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// ဒီ `Group` တွင်သတ်မှတ်ထားသော tokens ၏ `TokenStream` သို့ပြန်သွားသည်။
    ///
    /// အဆိုပါပြန်လာသော token စီးသည့်အနားသတ်မျဉ်းအထက်ပြန်ရောက်မပါဝင်ပါဘူးမှတ်ချက်။
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// တစ်ခုလုံးကို `Group` spanning, ဒီ token စီး၏အနားသတ်မျဉ်းများအတွက် span Returns ။
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// ဤအုပ်စု၏အဖွင့်မျဉ်းကြောင်းကိုညွှန်ပြသည့်သက်တမ်းကိုပြန်သွားသည်။
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// ဤအုပ်စုများ၏ပိတ်ပွဲကိုအနားသတ်မျဉ်းမှညွှန်ပြပြန်သည့် span ။
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// ဤ `Group` ၏အကန့်အသတ်များအတွက် span ကိုပြုပြင်သည်၊ သို့သော်၎င်း၏အတွင်းပိုင်း tokens မဟုတ်ပါ။
    ///
    /// ဤနည်းလမ်းသည် ** **** ** အုပ်စုအတွင်းရှိအတွင်းပိုင်း tokens အားလုံး၏သက်တမ်းကိုသတ်မှတ်မည်မဟုတ်ပါ။ သို့သော်၎င်းသည် delimiter tokens ၏သက်တမ်းကို `Group` အဆင့်တွင်သာသတ်မှတ်လိမ့်မည်။
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB၊ Bridge သည် `to_string` ကိုသာပံ့ပိုးပေးပြီး၊ `fmt::Display` ကို အခြေခံ၍ အကောင်အထည်ဖော်သည် (နှစ်ခုကြားရှိပုံမှန်ဆက်ဆံရေး၏ပြောင်းပြန်)
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// အုပ်စုကို string တစ်ခုအဖြစ်ပုံနှိပ်ထုတ်ဝေပြီး၊ `Delimiter::None` delimiters နှင့်အတူ `TokenTree: : Group`s 'မှလွဲ၍ တူညီသောအုပ်စု (modulo spans) သို့ပြန်လည်ပြောင်း။ ပြောင်းရမည်။
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` သည် `+`, `-` သို့မဟုတ် `#` ကဲ့သို့ပုဒ်ဖြတ်ပုဒ်ရပ်တစ်ခုတည်းဖြစ်သည်။
///
/// `+=` ကဲ့သို့ဇာတ်ကောင်မျိုးစုံအော်ပရေတာများသည် `Punct` ၏သာဓက (၂) ခုအနေဖြင့် `Spacing` ပုံစံအမျိုးမျိုးနှင့်ပြန်လာသည်။
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// တစ်ဦး `Punct` အခြား `Punct` နေဖြင့်ချက်ချင်းနောက်တော်သို့လိုက်သို့မဟုတ်အခြား token သို့မဟုတ်ကြားနေရာလွတ်ခြင်းဖြင့်နောက်တော်သို့လိုက်သည်ကိုပဲဖြစ်ဖြစ်။
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// ဥပမာ `+` `+ =` အတွက် `Alone`, `+ident` သို့မဟုတ် `+()` ဖြစ်ပါတယ်။
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// ဥပမာ `+` `+=` သို့မဟုတ် `'#` အတွက် `Joint` ဖြစ်ပါတယ်။
    /// ထို့အပြင်ကိုးကားမှုတစ်ခုတည်း `'` သည်သက်တမ်းကြာရှည်သည့် `'ident` ကိုဖွဲ့စည်းရန်သတ်မှတ်ချက်များနှင့်တွဲဖက်နိုင်သည်။
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// ပေးထားသောဇာတ်ကောင်နှင့်အကွာအဝေးမှ `Punct` အသစ်တစ်ခုကိုဖန်တီးသည်။
    /// အဆိုပါ `ch` အငြင်းအခုံခိုင်လုံသောပုဒ်ဖြတ်ပုဒ်ရပ်ဇာတ်ကောင်မဟုတ်ရင် function ကိုအလိုတော် panic ဘာသာစကားဖြင့်ခွင့်ပြုရမည်ဖြစ်သည်။
    ///
    /// ပြန်လာသည့် `Punct` သည် `Span::call_site()` ၏ပုံမှန် span ရှိလိမ့်မည်။ ၎င်းကိုအောက်ပါ `set_span` နည်းလမ်းဖြင့်ထပ်မံပြုပြင်နိုင်သည်။
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// `char` အတိုင်းဤပုဒ်ဖြတ်ပုဒ်ရပ်ဇာတ်ကောင်ရဲ့တန်ဖိုးကို Returns ။
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// ဤပုဒ်ဖြတ်ပုဒ်ရပ်အကွာအဝေးကိုပြန်သွားသည်။ ၎င်းသည် token စီးဆင်းမှုရှိအခြား `Punct` နောက်ချက်ချင်းနောက်သို့လိုက်ခြင်းရှိမရှိကိုညွှန်ပြသည်။ ထို့ကြောင့်၎င်းတို့သည်အက္ခရာမျိုးစုံအော်ပရေတာ (`Joint`) သို့ပေါင်းနိုင်သည်၊ သို့မဟုတ်အခြား token သို့မဟုတ် whitespace (`Alone`) တို့နောက်မှ လိုက်၍ ဆက်သွယ်နိုင်သည်။ အဆုံးသတ်ခဲ့သည်
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// ဒီပုဒ်ဖြတ်ပုဒ်ရပ်အက္ခရာအတွက် span ကို return ပြန်ပေးတယ်။
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// ဒီပုဒ်ဖြတ်ပုဒ်ရပ်အက္ခရာအတွက် span ကိုပြုပြင်ပါ။
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB၊ Bridge သည် `to_string` ကိုသာပံ့ပိုးပေးပြီး၊ `fmt::Display` ကို အခြေခံ၍ အကောင်အထည်ဖော်သည် (နှစ်ခုကြားရှိပုံမှန်ဆက်ဆံရေး၏ပြောင်းပြန်)
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// ပုဒ်ဖြတ်ပုဒ်ရပ်ကိုအက္ခရာတစ်ခုတည်းအဖြစ်သို့ပြန်ပြောင်း။ အရှုံးမပေးနိုင်သော string တစ်ခုအဖြစ် print ထုတ်သည်။
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// တစ်ဦးအမှတ်အသား (`ident`) ။
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// ပေးထားသော `string` အဖြစ်သတ်မှတ်ထားသော `span` နှင့်အတူ `Ident` အသစ်တစ်ခုကိုဖန်တီးသည်။
    /// `string` အငြင်းအခုံသည်ဘာသာစကားမှခွင့်ပြုထားသောခိုင်လုံသောအမှတ်အသားဖြစ်ရမည် (သော့ချက်စာလုံးများအပါအဝင်ဥပမာ-`self` သို့မဟုတ် `fn`) ။ဒီလိုမှမဟုတ်ရင် function ကိုအလိုတော် panic ။
    ///
    /// သတိပြုရန်မှာလက်ရှိ rustc ရှိ `span` သည်ဤအမှတ်အသားအတွက်တစ်ကိုယ်ရေသန့်ရှင်းမှုဆိုင်ရာအချက်အလက်များကိုပြုပြင်ပေးသည်။
    ///
    /// ဤအချိန်အဖြစ် `Span::call_site()` အတိအလင်းသူတို့နိုင်တဲ့ macro ခေါ်ဆိုခ၏တည်နေရာမှာတိုက်ရိုက်ရေးသားခဲ့လျှင်အတိုင်းဤ span နှင့်အတူဖန်တီးဖေါ်ထုတ်ဖြေရှင်းလိမ့်မည်ဟုအဓိပ္ပာယ် "call-site" တစ်ကိုယ်ရည်သန့်ရှင်းရေးလုပ်ဖို့အတွက် opts, နှင့်နိုင်တဲ့ macro ခေါ်ဆိုခ site ကိုမှာသည်အခြားကုဒ်ရည်ညွှန်းနိုင်ပါလိမ့်မည် အပြင်ကသူတို့ကို။
    ///
    ///
    /// `Span::def_site()` တူသောနောက်ပိုင်းတွင် span ရွေးရသည့် "definition-site" တစ်ကိုယ်ရည်သန့်ရှင်းရေးလုပ်ဖို့ဒီ span နှင့်အတူဖန်တီးဖေါ်ထုတ်သူတို့ကိုရည်ညွှန်းနိုင်လိမ့်မည်မဟုတ်သည့်နိုင်တဲ့ macro ခေါ်ဆိုခ site ကိုမှာနိုင်တဲ့ macro ချက်နှင့်အဓိပ္ပါယ်နှင့်အခြားကုဒ်၏တည်နေရာမှာပြေလည်လိမ့်မည်ဟုအဓိပ္ပာယ်မှခွင့်ပြုပါလိမ့်မယ်။
    ///
    /// တစ်ကိုယ်ရည်သန့်ရှင်းရေး၏လက်ရှိအရေးပါမှုဒီလုပ်ငန်းခွင်ကြောင့်အခြား tokens မတူပဲ, ဆောက်လုပ်ရေးမှာသတ်မှတ်ထားခံရဖို့တစ် `Span` လိုအပ်သည်။
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// `Ident::new` နှင့်အတူတူပင်, ဒါပေမယ့် (`r#ident`) ကုန်ကြမ်းအမှတ်အသားဖန်တီးပေးပါတယ်။
    /// အဆိုပါ `string` အငြင်းအခုံခိုင်လုံသောအထောက်အထား (သော့ချက်စာလုံးများအပါအဝင်ဥပမာ `fn`) သည်ဘာသာစကားကခွင့်ပြုသောလိမ့်မည်။
    /// သော့ချက်စာလုံး (path)
    /// `self`, `super`) ကိုမထောက်ပံ့ပါ၊ panic ကိုဖြစ်ပေါ်လိမ့်မည်။
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// [`to_string`](Self::to_string) အားဖြင့်ပြန်လာသောတစ်ခုလုံးကို string ကိုလွှမ်းခြုံ, ဒီ `Ident` ၏ span Returns ။
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// ဖြစ်နိုင်သည်က၎င်း၏တစ်ကိုယ်ရေသန့်ရှင်းမှုအခြေအနေပြောင်းလဲခြင်း, ဒီ `Ident` ၏ span ကိုပြုပြင်သည်။
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB၊ Bridge သည် `to_string` ကိုသာပံ့ပိုးပေးပြီး၊ `fmt::Display` ကို အခြေခံ၍ အကောင်အထည်ဖော်သည် (နှစ်ခုကြားရှိပုံမှန်ဆက်ဆံရေး၏ပြောင်းပြန်)
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// ၎င်းအမှတ်အသားအားတူညီသောအမှတ်အသားအဖြစ်သို့ပြန်လည်မလွှဲပြောင်းနိုင်သောပြောင်းလဲမှုဖြစ်သင့်သော string တစ်ခုအနေဖြင့်သတ်မှတ်သည်။
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// တစ်ဦးကပကတိ string ကို (`"hello"`), က byte string ကို (`b"hello"`), ဇာတ်ကောင် (`'a'`), က byte ဇာတ်ကောင် (`b'a'`), (`1`, `1u8`, `2.3`, `2.3f32`) နဲ့တစ်ခုသို့မဟုတ်နောက်ဆက်မပါဘဲတစ်ဦး integer ဖြစ်တဲ့အတွက်သို့မဟုတ် floating အမှတ်အရေအတွက်သည်။
///
/// `true` နှင့် `false` တူသော boolean တှေသူတို့ `Ident`s ဖြစ်ကြောင်း, ဒီမှာပိုင်ကြပါဘူး။
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// အဆိုပါသတ်မှတ်ထားတဲ့တန်ဖိုးပကတိ integer ဖြစ်တဲ့အတွက်အသစ်တခုနောက်ဆက်ဖန်တီးပေးပါတယ်။
        ///
        /// ဤလုပ်ဆောင်ချက်သည် `1u32` ကဲ့သို့သောကိန်းတစ်ခုကိုဖန်တီးလိမ့်မည်။ ထိုနေရာတွင်သတ်မှတ်ထားသောကိန်းတန်ဖိုးသည် token ၏ပထမအပိုင်းဖြစ်သည်။
        /// အနုတ်လက္ခဏာနံပါတ်များမှဖန်တီးထားသော literals များသည် `TokenStream` သို့မဟုတ် string များမှတစ်ဆင့်လှည့်လည်ခရီးသွားခြင်းကိုဆက်လက်ရှင်သန်နိုင်မည်မဟုတ်ပါ။ tokens (`-` နှင့် positive literal) နှစ်ခုလုံးသို့ကျိုးပဲ့နိုင်သည်။
        ///
        ///
        /// ဤနည်းလမ်းမှတဆင့်ဖန်တီးထားသော literals များသည်ပုံမှန်အားဖြင့် `Span::call_site()` span ရှိသည်၊ ၎င်းကိုအောက်တွင်ဖော်ပြထားသော `set_span` နည်းလမ်းဖြင့် configure လုပ်နိုင်သည်။
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// အဆိုပါသတ်မှတ်ထားတဲ့တန်ဖိုးသစ်တစ်ခု unsuffixed ကိန်းပကတိဖန်တီးပေးပါတယ်။
        ///
        /// ဤလုပ်ဆောင်ချက်သည် `1` ကဲ့သို့သောကိန်းတစ်ခုကိုဖန်တီးလိမ့်မည်။ ထိုနေရာတွင်သတ်မှတ်ထားသောကိန်းတန်ဖိုးသည် token ၏ပထမအပိုင်းဖြစ်သည်။
        /// ဤ token တွင်နောက်ဆက်နောက်ဆက်မရှိပါ။ ဆိုလိုသည်မှာ `Literal::i8_unsuffixed(1)` ကဲ့သို့သော invocations များသည် `Literal::u32_unsuffixed(1)` နှင့်ညီမျှသည်။
        /// အနုတ်လက္ခဏာနံပါတ်များထံမှ created လီတာ `TokenStream` သို့မဟုတ်ညှို့မှတဆင့် rountrips ရှင်သန်မည်မဟုတ်ပါနှစ်ယောက် tokens (`-` နှင့်အပြုသဘောဆောင်သည့်ပကတိ) သို့ကျိုးပဲ့နိုင်ပါသည်။
        ///
        ///
        /// ဤနည်းလမ်းမှတဆင့်ဖန်တီးထားသော literals များသည်ပုံမှန်အားဖြင့် `Span::call_site()` span ရှိသည်၊ ၎င်းကိုအောက်တွင်ဖော်ပြထားသော `set_span` နည်းလမ်းဖြင့် configure လုပ်နိုင်သည်။
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// unsuffixed floating-point literal အသစ်တစ်ခုကိုဖန်တီးသည်။
    ///
    /// ဤတည်ဆောက်မှုသည် `Literal::i8_unsuffixed` ကဲ့သို့သော float ၏တန်ဖိုးကို token သို့တိုက်ရိုက်ထုတ်လွှတ်သော်လည်းနောက်ဆက်နောက်ဆက်ကိုမသုံးသောနေရာများနှင့်ဆင်တူသည်။ ထို့ကြောင့်နောက်ပိုင်းတွင် compiler တွင် `f64` ဟုယူဆနိုင်သည်။
    ///
    /// အနုတ်လက္ခဏာနံပါတ်များထံမှ created လီတာ `TokenStream` သို့မဟုတ်ညှို့မှတဆင့် rountrips ရှင်သန်မည်မဟုတ်ပါနှစ်ယောက် tokens (`-` နှင့်အပြုသဘောဆောင်သည့်ပကတိ) သို့ကျိုးပဲ့နိုင်ပါသည်။
    ///
    /// # Panics
    ///
    /// ဤသည် function ကိုသတ်မှတ်ထားသော float ကနျ့ကြောင်းလိုအပ်သည်ဥပမာ, ကအဆုံးမရှိသို့မဟုတ် NaN လျှင်ဤ function ကို panic လိမ့်မည်။
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// နောက်ဆက်တွဲ floating-point literal အသစ်တစ်ခုကိုဖန်တီးသည်။
    ///
    /// ဤသည်လုပ်ငန်းခွင်သတ်မှတ်ထားတဲ့တန်ဖိုး token နှင့် `f32` ၏ရှေ့အစိတ်အပိုင်း token ၏နောက်ဆက်ဖြစ်ပါတယ်ဘယ်မှာ `1.0f32` ကဲ့သို့ပကတိဖန်တီးပါလိမ့်မယ်။
    /// ဤ token သည်အမြဲတမ်း compiler တွင် `f32` ဖြစ်လိမ့်မည်။
    /// အနုတ်လက္ခဏာနံပါတ်များထံမှ created လီတာ `TokenStream` သို့မဟုတ်ညှို့မှတဆင့် rountrips ရှင်သန်မည်မဟုတ်ပါနှစ်ယောက် tokens (`-` နှင့်အပြုသဘောဆောင်သည့်ပကတိ) သို့ကျိုးပဲ့နိုင်ပါသည်။
    ///
    ///
    /// # Panics
    ///
    /// ဤသည် function ကိုသတ်မှတ်ထားသော float ကနျ့ကြောင်းလိုအပ်သည်ဥပမာ, ကအဆုံးမရှိသို့မဟုတ် NaN လျှင်ဤ function ကို panic လိမ့်မည်။
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// unsuffixed floating-point literal အသစ်တစ်ခုကိုဖန်တီးသည်။
    ///
    /// ဤတည်ဆောက်မှုသည် `Literal::i8_unsuffixed` ကဲ့သို့သော float ၏တန်ဖိုးကို token သို့တိုက်ရိုက်ထုတ်လွှတ်သော်လည်းနောက်ဆက်နောက်ဆက်ကိုမသုံးသောနေရာများနှင့်ဆင်တူသည်။ ထို့ကြောင့်နောက်ပိုင်းတွင် compiler တွင် `f64` ဟုယူဆနိုင်သည်။
    ///
    /// အနုတ်လက္ခဏာနံပါတ်များထံမှ created လီတာ `TokenStream` သို့မဟုတ်ညှို့မှတဆင့် rountrips ရှင်သန်မည်မဟုတ်ပါနှစ်ယောက် tokens (`-` နှင့်အပြုသဘောဆောင်သည့်ပကတိ) သို့ကျိုးပဲ့နိုင်ပါသည်။
    ///
    /// # Panics
    ///
    /// ဤသည် function ကိုသတ်မှတ်ထားသော float ကနျ့ကြောင်းလိုအပ်သည်ဥပမာ, ကအဆုံးမရှိသို့မဟုတ် NaN လျှင်ဤ function ကို panic လိမ့်မည်။
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// နောက်ဆက်တွဲ floating-point literal အသစ်တစ်ခုကိုဖန်တီးသည်။
    ///
    /// ဤသည်လုပ်ငန်းခွင်သတ်မှတ်ထားတဲ့တန်ဖိုး token နှင့် `f64` ၏ရှေ့အစိတ်အပိုင်း token ၏နောက်ဆက်ဖြစ်ပါတယ်ဘယ်မှာ `1.0f64` ကဲ့သို့ပကတိဖန်တီးပါလိမ့်မယ်။
    /// ဤ token သည်အမြဲတမ်း compiler တွင် `f64` ဖြစ်လိမ့်မည်။
    /// အနုတ်လက္ခဏာနံပါတ်များထံမှ created လီတာ `TokenStream` သို့မဟုတ်ညှို့မှတဆင့် rountrips ရှင်သန်မည်မဟုတ်ပါနှစ်ယောက် tokens (`-` နှင့်အပြုသဘောဆောင်သည့်ပကတိ) သို့ကျိုးပဲ့နိုင်ပါသည်။
    ///
    ///
    /// # Panics
    ///
    /// ဤသည် function ကိုသတ်မှတ်ထားသော float ကနျ့ကြောင်းလိုအပ်သည်ဥပမာ, ကအဆုံးမရှိသို့မဟုတ် NaN လျှင်ဤ function ကို panic လိမ့်မည်။
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// string ပကတိ။
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// ပကတိစာလုံး။
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// ပကတိ byte string ကို။
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// ဒီပကတိလွှမ်းခြုံ span ပြန်သွားသည်။
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// ဒီပကတိအဘို့ဆက်စပ်သက်တမ်း Configures ။
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// သာအရင်းအမြစ်အကွာအဝေး `range` အတွက် bytes ် `self.span()` ၏အပိုင်းတစ်ပိုင်းကိုသာလျှင်သော `Span` Returns ။
    /// The-မည်ဖြစ်ကြောင်းကိုပွငျဆငျ span လျှင်ပြန် `None` `self` ၏ဘောငျအပြင်ဘက်ဖြစ်ပါတယ်။
    ///
    // FIXME(SergioBenitez): byte range သည် UTF-8 နယ်နိမိတ်မှစတင်ပြီးအဆုံးသတ်ကြောင်းစစ်ဆေးပါ။
    // မဟုတ်ပါကမူရင်းစာသားကိုပုံနှိပ်သောအခါ panic သည်အခြားနေရာများတွင်ဖြစ်လိမ့်မည်။
    // FIXME(SergioBenitez): အသုံးပြုသူအတွက် `self.span()` သည်မည်သည့်အရာသို့အမှန်တကယ်မြေပုံဆွဲသည်ကိုသိရန်လမ်းမရှိသောကြောင့်ဤနည်းလမ်းကိုမျက်မမြင်ဟုသာခေါ်ဆိုနိုင်သည်။
    // ဥပမာအားဖြင့်၊ 'c' ဇာတ်ကောင်အတွက် `to_string()` သည် "'\u{63}'" ကိုပြန်ပို့သည်။အသုံးပြုသူအနေဖြင့်အရင်းအမြစ်စာသားသည် 'c' ဟုတ်၊ မဟုတ် '\u{63}' ဟုတ်မဟုတ်သိရန်လမ်းမရှိချေ။
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) `Option::cloned` နဲ့ဆင်တူပေမယ့် `Bound<&T>` အတွက်တစ်ခုခု။
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB၊ Bridge သည် `to_string` ကိုသာပံ့ပိုးပေးပြီး၊ `fmt::Display` ကို အခြေခံ၍ အကောင်အထည်ဖော်သည် (နှစ်ခုကြားရှိပုံမှန်ဆက်ဆံရေး၏ပြောင်းပြန်)
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// (floating အမှတ်လီတာဖြစ်နိုင်သမျှ Round မှလွဲ.) တူညီသောပကတိသို့ losslessly ပြောင်းပြန်ဖြစ်သင့်တဲ့ string ကိုအဖြစ်ပကတိအားပရင့်ထုတ်ရန်။
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// ပတ်ဝန်းကျင် variable တွေကိုလက်လှမ်းမီ။
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// environment variable တစ်ခုကိုပြန်လည်ရယူပြီးမှီခိုမှုတည်ဆောက်ရန်ထည့်ပါ။
    /// အဆိုပါ compiler ကကွပ်မျက် build စနစ် variable ကိုစုစည်းစဉ်အတွင်းဝင်ရောက်ခဲ့ကွောငျးသိရကြလိမ့်မည်နှင့်သောအခါ variable ကိုအပြောင်းအလဲများကို၏တန်ဖိုးတည်ဆောက် rerun နိုင်ပါလိမ့်မည်။
    ///
    /// မှီတင်းမှုကိုခြေရာခံသည့်မှီခိုမှုအပြင် standard library မှ `env::var` နှင့်ညီမျှသင့်သည်၊ အငြင်းအခုံမှာ UTF-8 ဖြစ်သည်။
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}