use crate::Span;

/// တစ်ဦးအဖြေရှာတဲ့အဆင့်ကိုကိုယ်စားပြုအနေနဲ့ enum ။
#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
#[derive(Copy, Clone, Debug)]
#[non_exhaustive]
pub enum Level {
    /// ချို့ယွင်းချက်တစ်ခု။
    Error,
    /// တစ်ဦးကသတိပေး။
    Warning,
    /// မှတ်စု။
    Note,
    /// အကူအညီသတင်း
    Help,
}

/// Trait `Span`s အစုတခုသို့ကူးပြောင်းနိုင်အမျိုးအစားများအားဖြင့်အကောင်အထည်ဖော်။
#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub trait MultiSpan {
    /// တစ်ဦး `Vec<Span>` သို့ Converter `self` ။
    fn into_spans(self) -> Vec<Span>;
}

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
impl MultiSpan for Span {
    fn into_spans(self) -> Vec<Span> {
        vec![self]
    }
}

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
impl MultiSpan for Vec<Span> {
    fn into_spans(self) -> Vec<Span> {
        self
    }
}

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
impl<'a> MultiSpan for &'a [Span] {
    fn into_spans(self) -> Vec<Span> {
        self.to_vec()
    }
}

/// တစ်ဦးအဖြေရှာတဲ့သတင်းစကားများနှင့်ဆက်စပ်နေသောကလေးများမက်ဆေ့ခ်ျကိုကိုယ်စားပြုတစ်ဦးကဖွဲ့စည်းပုံ။
///
#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
#[derive(Clone, Debug)]
pub struct Diagnostic {
    level: Level,
    message: String,
    spans: Vec<Span>,
    children: Vec<Diagnostic>,
}

macro_rules! diagnostic_child_methods {
    ($spanned:ident, $regular:ident, $level:expr) => {
        /// ဤနည်းလမ်း၏အမည်ဖြင့်သတ်မှတ်ထားသော `spans` နှင့် `message` နှင့်အတူ `self` သို့ကလေးရောဂါရှာဖွေရေးမက်ဆေ့ခ်ျအသစ်တစ်ခုထပ်ထည့်သည်။
        ///
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $spanned<S, T>(mut self, spans: S, message: T) -> Diagnostic
        where
            S: MultiSpan,
            T: Into<String>,
        {
            self.children.push(Diagnostic::spanned(spans, $level, message));
            self
        }

        /// ပေးထားသော `message` နှင့်အတူဤနည်းလမ်းကိုရဲ့နာမတော်ဖြင့်ဖော်ထုတ်အဆင့်နှင့်အတူ `self` အသစ်ကလေးကရောဂါရှာဖွေသတင်းစကားကထပ်ပြောသည်။
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $regular<T: Into<String>>(mut self, message: T) -> Diagnostic {
            self.children.push(Diagnostic::new($level, message));
            self
        }
    };
}

/// တစ် ဦး `Diagnostic` ၏ကလေးများရောဂါရှာဖွေရေးကျော် Iterator ။
#[derive(Debug, Clone)]
#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub struct Children<'a>(std::slice::Iter<'a, Diagnostic>);

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
impl<'a> Iterator for Children<'a> {
    type Item = &'a Diagnostic;

    fn next(&mut self) -> Option<Self::Item> {
        self.0.next()
    }
}

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
impl Diagnostic {
    /// ပေးထားသော `level` နှင့် `message` နှင့်အတူသစ်တစ်ခုအဖြေရှာတဲ့ဖန်တီးပေးပါတယ်။
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn new<T: Into<String>>(level: Level, message: T) -> Diagnostic {
        Diagnostic { level, message: message.into(), spans: vec![], children: vec![] }
    }

    /// ပေးထားသော `level` နှင့် `message` နှင့်အတူအသစ်တစ်ခုကိုရှာဖွေရေးဖန်တီး `spans` ၏ပေးထားသောအစုံမှညွှန်ပြ။
    ///
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn spanned<S, T>(spans: S, level: Level, message: T) -> Diagnostic
    where
        S: MultiSpan,
        T: Into<String>,
    {
        Diagnostic { level, message: message.into(), spans: spans.into_spans(), children: vec![] }
    }

    diagnostic_child_methods!(span_error, error, Level::Error);
    diagnostic_child_methods!(span_warning, warning, Level::Warning);
    diagnostic_child_methods!(span_note, note, Level::Note);
    diagnostic_child_methods!(span_help, help, Level::Help);

    /// `self` များအတွက်အဖြေရှာတဲ့ `level` Returns ။
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn level(&self) -> Level {
        self.level
    }

    /// `level` မှ `self` အတွက်အဆင့်ကိုသတ်မှတ်ပေးသည်။
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn set_level(&mut self, level: Level) {
        self.level = level;
    }

    /// `self` အတွက်သတင်းစကားကိုပြန်ပို့ပေးသည်။
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn message(&self) -> &str {
        &self.message
    }

    /// `self` ရှိမက်ဆေ့ခ်ျကို `message` သို့သတ်မှတ်သည်။
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn set_message<T: Into<String>>(&mut self, message: T) {
        self.message = message.into();
    }

    /// `self` ရှိ `Span`s` ကိုပြန်ပို့သည်။
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn spans(&self) -> &[Span] {
        &self.spans
    }

    /// `self` ရှိ `Span`s` ကို `spans` အဖြစ်သတ်မှတ်သည်။
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn set_spans<S: MultiSpan>(&mut self, spans: S) {
        self.spans = spans.into_spans();
    }

    /// `self` ၏ကလေးများရောဂါရှာဖွေခြင်းနှင့် ပတ်သက်၍ ကြားဖြတ်တစ်ခုကိုပြန်ပို့သည်။
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn children(&self) -> Children<'_> {
        Children(self.children.iter())
    }

    /// ရောဂါရှာဖွေထုတ်လွှတ်ပါ။
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn emit(self) {
        fn to_internal(spans: Vec<Span>) -> crate::bridge::client::MultiSpan {
            let mut multi_span = crate::bridge::client::MultiSpan::new();
            for span in spans {
                multi_span.push(span.0);
            }
            multi_span
        }

        let mut diag = crate::bridge::client::Diagnostic::new(
            self.level,
            &self.message[..],
            to_internal(self.spans),
        );
        for c in self.children {
            diag.sub(c.level, &c.message[..], to_internal(c.spans));
        }
        diag.emit();
    }
}