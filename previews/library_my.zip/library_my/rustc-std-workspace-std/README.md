# အဆိုပါ `rustc-std-workspace-std` crate

`rustc-std-workspace-core` crate အတွက်စာရွက်စာတမ်းများကိုကြည့်ပါ။