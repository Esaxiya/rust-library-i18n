//! `compiler-rt` စာကြည့်တိုက်၏ပရိုဖိုင်းအပိုင်းကိုစုစည်းထားသည်။
//!
//! အသေးစိတ်အတွက် libcompiler_builtins crate အတွက် build.rs ကိုကြည့်ပါ။

use std::env;
use std::path::Path;

fn main() {
    let target = env::var("TARGET").expect("TARGET was not set");
    let cfg = &mut cc::Build::new();

    // FIXME: `rerun-if-changed` ညွှန်ကြားချက်လက်ရှိထုတ်လွှတ်ခြင်းနှင့်တည်ဆောက်ဇာတ်ညွှန်းကြသည်မဟုတ်
    // ဤအရင်းအမြစ်ဖိုင်များ (သို့) ၎င်းတို့တွင်ထည့်သွင်းထားသည့်ခေါင်းစီးများပြောင်းလဲမှုများပြန်လည်စတင်မည်မဟုတ်ပါ။
    let mut profile_sources = vec![
        "GCDAProfiling.c",
        "InstrProfiling.c",
        "InstrProfilingBuffer.c",
        "InstrProfilingFile.c",
        "InstrProfilingMerge.c",
        "InstrProfilingMergeFile.c",
        "InstrProfilingNameVar.c",
        "InstrProfilingPlatformDarwin.c",
        "InstrProfilingPlatformFuchsia.c",
        "InstrProfilingPlatformLinux.c",
        "InstrProfilingPlatformOther.c",
        "InstrProfilingPlatformWindows.c",
        "InstrProfilingUtil.c",
        "InstrProfilingValue.c",
        "InstrProfilingVersionVar.c",
        "InstrProfilingWriter.c",
        // ဤဖိုင်ကို LLVM 10 တွင်အမည်ပြောင်းခဲ့သည်။
        "InstrProfilingRuntime.cc",
        "InstrProfilingRuntime.cpp",
        // ဤဖိုင်များကို LLVM 11 ဆက်ပြောသည်ခဲ့ကြသည်။
        "InstrProfilingInternal.c",
        "InstrProfilingBiasVar.c",
    ];

    if target.contains("msvc") {
        // MSVC အပေါ်အပိုစာကြည့်တိုက်ထဲမှာဆွဲထုတ်မနေပါနဲ့
        cfg.flag("/Zl");
        profile_sources.push("WindowsMMap.c");
        cfg.define("strdup", Some("_strdup"));
        cfg.define("open", Some("_open"));
        cfg.define("fdopen", Some("_fdopen"));
        cfg.define("getpid", Some("_getpid"));
        cfg.define("fileno", Some("_fileno"));
    } else {
        // gcc ၏အင်္ဂါရပ်အမျိုးမျိုးနှင့်ထိုကဲ့သို့သော compiler-rt ၏တည်ဆောက်မှုစနစ်ကိုကူးယူပြီးဖြစ်သည်
        //
        cfg.flag("-fno-builtin");
        cfg.flag("-fomit-frame-pointer");
        cfg.define("VISIBILITY_HIDDEN", None);
        if !target.contains("windows") {
            cfg.flag("-fvisibility=hidden");
            cfg.define("COMPILER_RT_HAS_UNAME", Some("1"));
        } else {
            profile_sources.push("WindowsMMap.c");
        }
    }

    // ငါတို့တည်ဆောက်နေသည့် Unixes များတွင် fnctl() ရှိသည်ဆိုပါစို့
    if env::var_os("CARGO_CFG_UNIX").is_some() {
        cfg.define("COMPILER_RT_HAS_FCNTL_LCK", Some("1"));
    }

    // ၎င်းသည် COMPILER_RT_HAS_ATOMICS ကိုသတ်မှတ်ရန်အတွက်အလွန်ကောင်းမွန်သော heuristic ဖြစ်သင့်သည်
    //
    if env::var_os("CARGO_CFG_TARGET_HAS_ATOMIC")
        .map(|features| features.to_string_lossy().to_lowercase().contains("ptr"))
        .unwrap_or(false)
    {
        cfg.define("COMPILER_RT_HAS_ATOMICS", Some("1"));
    }

    // ကျနော်တို့ကို run မယ်ဆိုရင်ဒီတည်ရှိသင့်ကြောင်းမှတ်ချက် (မဟုတ်ရင်ကျနော်တို့အားလုံးမှာပရိုဖိုင် builtins မတည်မဆောက်ကြဘူး) ။
    //
    let root = Path::new("../../src/llvm-project/compiler-rt");

    let src_root = root.join("lib").join("profile");
    for src in profile_sources {
        let path = src_root.join(src);
        if path.exists() {
            cfg.file(path);
        }
    }

    cfg.include(root.join("include"));
    cfg.warnings(false);
    cfg.compile("profiler-rt");
}