use core::any::TypeId;
use core::intrinsics::assume;

#[test]
fn test_typeid_sized_types() {
    struct X;
    struct Y(u32);

    assert_eq!(TypeId::of::<X>(), TypeId::of::<X>());
    assert_eq!(TypeId::of::<Y>(), TypeId::of::<Y>());
    assert!(TypeId::of::<X>() != TypeId::of::<Y>());
}

#[test]
fn test_typeid_unsized_types() {
    trait Z {}
    struct X(str);
    struct Y(dyn Z + 'static);

    assert_eq!(TypeId::of::<X>(), TypeId::of::<X>());
    assert_eq!(TypeId::of::<Y>(), TypeId::of::<Y>());
    assert!(TypeId::of::<X>() != TypeId::of::<Y>());
}

// `const_assume` feature သည် `assume` အခ်ါကို const context များတွင်အသုံးပြုရန်ခွင့်ပြုထားသည်ကိုစစ်ဆေးပါ။
//
#[test]
fn test_assume_can_be_in_const_contexts() {
    const unsafe fn foo(x: usize, y: usize) -> usize {
        // လုံခြုံမှု: တစ်ခုလုံးကို function ကိုဘေးကင်းလုံခြုံမဟုတျပါဘူး,
        // သို့သော်အခြားနေရာများတွင်အသုံးမယ့်ဥပမာတစ်ခုဖြစ်ပါတယ်။
        unsafe { assume(y != 0) };
        x / y
    }
    let rs = unsafe { foo(42, 97) };
    assert_eq!(rs, 0);
}