use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri ကအရမ်းနှေးတယ်
fn exact_sanity_test() {
    // ဒီစမ်းသပ်မှုကအဆုံးသတ် `exp2` library လုပ်ဆောင်ချက်ရဲ့ထောင့်ကျ is ကိစ္စဖြစ်တာပဲ။ ငါတို့သုံးနေတဲ့ဘယ် runtime မှာမဆိုသတ်မှတ်ထားတယ်။
    // VS 2013 တွင်ဤလုပ်ဆောင်မှုသည်ပြugနာရှိပုံရသည်၊ ချိတ်ဆက်သောအခါစမ်းသပ်မှုမအောင်မြင်သော်လည်း VS 2015 တွင်စမ်းသပ်မှုအဆင်ပြေသည်နှင့် bug သည်ပုံသေဖြစ်နေသည်။
    //
    // အဆိုပါ bug သည် `exp2(-1057)` ၏ return value ခြားနားချက်ဖြစ်ပုံရသည်။ VS 2013 တွင် 0x2 နည်းစနစ်နှင့်နှစ်ဆ ပြန်၍ VS 2015 တွင် 0x20000 ကိုပြန်ပေးသည်။
    //
    //
    // ယခုအချိန်တွင် MSVC တွင်ဤစမ်းသပ်မှုကိုလုံး ၀ လျစ်လျူရှု။ မည်သည့်နေရာတွင်မဆိုစမ်းသပ်ပြီးဖြစ်သောကြောင့်ကျွန်ုပ်တို့သည် platform တစ်ခုစီ၏ exp2 အကောင်အထည်ဖော်မှုကိုစမ်းသပ်ရန်ကျွန်ုပ်တို့အလွန်စိတ်ဝင်စားသည်။
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}