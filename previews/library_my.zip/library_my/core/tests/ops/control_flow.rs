use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // ဤသည်တည်ငြိမ်မျက်နှာပြင်ဧရိယာသည်မဟုတ်, LLVM အမြဲအခုကအားသာချက် ယူ. မသွားနိုင်လျှင်ပင်ထိုသူတို့အားအကြား `?` စျေးပေါစောင့်ရှောက်ကူညီပေးသည်။
    //
    // (ဝမ်းနည်းစရာရလဒ်နှင့် Option ကိုကိုက်ညီမှုရှိပါတယ်, ဒါကြောင့် ControlFlow နှစ်ဦးစလုံးမကိုက်ညီနိုင်ပါတယ်။)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}