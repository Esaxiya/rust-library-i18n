// နှစ်ခုက bytes မှ align
const DATA: [u16; 2] = [u16::from_ne_bytes([0x01, 0x23]), u16::from_ne_bytes([0x45, 0x67])];

const fn unaligned_ptr() -> *const u16 {
    // DATA.as_ptr() ကို bytes နှစ်ခုနဲ့လိုက်ဖက်တဲ့အတွက် 1 byte တစ်ခုထပ်ပေါင်းထည့်ပြီး * const u16 ကိုထုတ်လုပ်ပါတယ်
    unsafe { (DATA.as_ptr() as *const u8).add(1) as *const u16 }
}

#[test]
fn read() {
    use core::ptr;

    const FOO: i32 = unsafe { ptr::read(&42 as *const i32) };
    assert_eq!(FOO, 42);

    const ALIGNED: i32 = unsafe { ptr::read_unaligned(&42 as *const i32) };
    assert_eq!(ALIGNED, 42);

    const UNALIGNED_PTR: *const u16 = unaligned_ptr();

    const UNALIGNED: u16 = unsafe { ptr::read_unaligned(UNALIGNED_PTR) };
    assert_eq!(UNALIGNED, u16::from_ne_bytes([0x23, 0x45]));
}

#[test]
fn const_ptr_read() {
    const FOO: i32 = unsafe { (&42 as *const i32).read() };
    assert_eq!(FOO, 42);

    const ALIGNED: i32 = unsafe { (&42 as *const i32).read_unaligned() };
    assert_eq!(ALIGNED, 42);

    const UNALIGNED_PTR: *const u16 = unaligned_ptr();

    const UNALIGNED: u16 = unsafe { UNALIGNED_PTR.read_unaligned() };
    assert_eq!(UNALIGNED, u16::from_ne_bytes([0x23, 0x45]));
}

#[test]
fn mut_ptr_read() {
    const FOO: i32 = unsafe { (&42 as *const i32 as *mut i32).read() };
    assert_eq!(FOO, 42);

    const ALIGNED: i32 = unsafe { (&42 as *const i32 as *mut i32).read_unaligned() };
    assert_eq!(ALIGNED, 42);

    const UNALIGNED_PTR: *mut u16 = unaligned_ptr() as *mut u16;

    const UNALIGNED: u16 = unsafe { UNALIGNED_PTR.read_unaligned() };
    assert_eq!(UNALIGNED, u16::from_ne_bytes([0x23, 0x45]));
}

// #[test]
// Fn write() {core::ptr ကိုအသုံးပြု;
//
//    const Fn write_aligned()-> i32 {mut=res=0 ကြကုန်အံ့;
//        unsafe {
//            ptr::write(&mut res as *mut _, 42);
//        }
//        res} const ညှိ: i32 = write_aligned();
//    assert_eq (align, 42!);
//
//    write_unaligned() Fn const-> [u16; 2] {ကြကုန်အံ့ mut two_aligned= [0u16; 2];
//        unsut {mut u16 အဖြစ် * mut u8).add(1) အဖြစ် unaligned_ptr= (two_aligned.as_mut_ptr() ကြကုန်အံ့;
//            ptr: : write_unaligned (unaligned_ptr, u16::from_ne_bytes([0x23, 0x45]));} two_aligned} const UNALIGNED: [u16; 2] = write_unaligned();
//
//    assert_eq (UNALIGNED, [u16::from_ne_bytes([0x00, 0x23]), u16::from_ne_bytes([0x45, 0x00])]);}
//
//
//
//
//
//
//
//
//
//

// #[test]
// mut_ptr_write() {const Fn aligned() Fn-> i32 {mut res=0 ကြကုန်အံ့,
//        မလုံခြုံ { (&mut res as *mut i32).write(42); } res} const align လုပ်: i32 = aligned();
//
//    assert_eq (align, 42!);
//
//    write_unaligned() Fn const-> [u16; 2] {ကြကုန်အံ့ mut two_aligned= [0u16; 2];
//        unsut {mut u16 အဖြစ် * mut u8).add(1) အဖြစ် unaligned_ptr= (two_aligned.as_mut_ptr() ကြကုန်အံ့;
//            unaligned_ptr.write_unaligned(u16::from_ne_bytes([0x23, 0x45]));
//        }
//        two_aligned} const UNALIGNED: [u16; 2] = write_unaligned();
//    assert_eq (UNALIGNED, [u16::from_ne_bytes([0x00, 0x23]), u16::from_ne_bytes([0x45, 0x00])]);}
//
//
//
//
//
//
//
//
//
//
//