use core::task::Poll;

#[test]
fn poll_const() {
    // `Poll` ၏နည်းလမ်းများ const အခြေအနေတွင်အသုံးဝင်သောဖြစ်ကြောင်းစစ်ဆေးပါ

    const POLL: Poll<usize> = Poll::Pending;

    const IS_READY: bool = POLL.is_ready();
    assert!(!IS_READY);

    const IS_PENDING: bool = POLL.is_pending();
    assert!(IS_PENDING);
}