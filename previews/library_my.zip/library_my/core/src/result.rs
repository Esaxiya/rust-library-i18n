//! `Result` အမျိုးအစားနှင့်ကိုင်တွယ်နေသည့်အမှား။
//!
//! [`Result<T, E>`][`Result`] အမှားများကိုပြန်ပို့ခြင်းနှင့်ပြန့်ပွားများအတွက်အသုံးပြုအမျိုးအစားဖြစ်ပါတယ်။
//! ၎င်းသည်အောင်မြင်မှုနှင့်တန်ဖိုးတစ်ခုပါ ၀ င်သည့် [`Ok(T)`], နှင့် [`Err(E)`] တို့ပါဝင်သောစာရင်းတစ်ခုဖြစ်ပြီး [`Err(E)`] သည်အမှားကိုကိုယ်စားပြုပြီးအမှားတစ်ခုပါ ၀ င်သည်။
//!
//! ```
//! # #[allow(dead_code)]
//! enum Result<T, E> {
//!    Ok(T),
//!    Err(E),
//! }
//! ```
//!
//! အမှားအယွင်းများကိုမျှော်လင့်ပြီးပြန်လည်ဆယ်တင်နိုင်သည့်အခါတိုင်း Functions များသည် [`Result`] ကိုပြန်ပို့သည်။အဆိုပါ `std` crate ခုနှစ်, [`Result`] အထင်ရှားဆုံး [I/O](../../std/io/index.html) များအတွက်အသုံးပြုသည်။
//!
//! [`Result`] ကိုပြန်လာသည့်ရိုးရှင်းသော function တစ်ခုကိုအောက်ပါအတိုင်းသတ်မှတ်နိုင်သည်။
//!
//! ```
//! #[derive(Debug)]
//! enum Version { Version1, Version2 }
//!
//! fn parse_version(header: &[u8]) -> Result<Version, &'static str> {
//!     match header.get(0) {
//!         None => Err("invalid header length"),
//!         Some(&1) => Ok(Version::Version1),
//!         Some(&2) => Ok(Version::Version2),
//!         Some(_) => Err("invalid version"),
//!     }
//! }
//!
//! let version = parse_version(&[1, 2, 3, 4]);
//! match version {
//!     Ok(v) => println!("working with version: {:?}", v),
//!     Err(e) => println!("error parsing header: {:?}", e),
//! }
//! ```
//!
//! [`Result`] s ပေါ်ရှိပုံစံကိုက်ညီမှုသည်ရိုးရှင်းသောကိစ္စရပ်များအတွက်ရှင်းရှင်းလင်းလင်းပင်ဖြစ်သည်၊ သို့သော် [`Result`] သည်အဆင်ပြေလွယ်ကူသည့်နည်းလမ်းများဖြင့်၎င်းနှင့်အတူအလုပ်လုပ်ရန် ပို၍ ရှင်းလင်းစေသည်။
//!
//! ```
//! let good_result: Result<i32, i32> = Ok(10);
//! let bad_result: Result<i32, i32> = Err(10);
//!
//! // `is_ok` နှင့် `is_err` နည်းလမ်းများသည်သူတို့ပြောသမျှကိုလုပ်ဆောင်သည်။
//! assert!(good_result.is_ok() && !good_result.is_err());
//! assert!(bad_result.is_err() && !bad_result.is_ok());
//!
//! // `map` အဆိုပါ `Result` စားသုံးသည်အခြားထုတ်လုပ်သည်။
//! let good_result: Result<i32, i32> = good_result.map(|i| i + 1);
//! let bad_result: Result<i32, i32> = bad_result.map(|i| i - 1);
//!
//! // ဆက်လက်တွက်ချက်ရန် `and_then` ကိုသုံးပါ။
//! let good_result: Result<bool, i32> = good_result.and_then(|i| Ok(i == 11));
//!
//! // အမှားကိုကိုင်တွယ်ရန် `or_else` ကိုသုံးပါ။
//! let bad_result: Result<i32, i32> = bad_result.or_else(|i| Ok(i + 20));
//!
//! // ရလဒ်လောင်ခြင်းနှင့် `unwrap` အတူ contents တွေကိုပြန်သွားပါ။
//! let final_awesome_result = good_result.unwrap();
//! ```
//!
//! # ရလဒ်များကိုအသုံးပြုရမည်
//!
//! အမှားအယွင်းများကိုညွှန်ပြရန် return value များအသုံးပြုခြင်းနှင့်အတူဘုံပြproblemနာတစ်ခုမှာ return value ကိုလျစ်လျူရှုရန်လွယ်ကူသောကြောင့်အမှားကိုကိုင်တွယ်ရန်ပျက်ကွက်ခြင်းဖြစ်သည်။
//! [`Result`] ရလဒ်ကိုတန်ဖိုးကိုလျစ်လျူရှုတဲ့အခါမှာ compiler ကသတိပေးချက်ထုတ်ပေးလိမ့်မည်ဟုအရာ, `#[must_use]` attribute ကိုအတူမှတ်ချက်ဖြစ်ပါတယ်။
//! ၎င်းသည် [`Result`] အားအမှားအယွင်းများကြုံတွေ့ရနိုင်သော်လည်းအသုံး ၀ င်သောတန်ဖိုးကိုပြန်မပေးသောလုပ်ဆောင်မှုများတွင်အထူးအသုံးဝင်စေသည်။
//!
//! X0 [`Write`] trait မှ I/O အမျိုးအစားများအတွက်သတ်မှတ်ထားသော [`write_all`] နည်းလမ်းကိုစဉ်းစားပါ။
//!
//! ```
//! use std::io;
//!
//! trait Write {
//!     fn write_all(&mut self, bytes: &[u8]) -> Result<(), io::Error>;
//! }
//! ```
//!
//! *Note: [`Write`] ၏အဓိပ္ပာယ်ဖွင့်ဆိုချက်သည် ``ရလဒ် 'အတွက်အဓိပ္ပာယ်တူသော [`io::Result`] ကိုအသုံးပြုသည်<T,`[`io: :Error`]`>`။*
//!
//! ဤနည်းလမ်းကိုတန်ဖိုးထုတ်လုပ်ပါဘူး, ဒါပေမယ့်ရေးကျရှုံးလိမ့်မည်။အမှားအယွင်းကိုကိုင်တွယ်ရန်အလွန်အရေးကြီးသည်၊* ** ** ** ** ** ** ** *\t
//!
//! ```no_run
//! # #![allow(unused_must_use)] // \o/
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! // အကယ်၍ `write_all` အမှားများဖြစ်ပါက return value ကိုလျစ်လျူရှုသောကြောင့်ကျွန်ုပ်တို့ဘယ်တော့မှသိမည်မဟုတ်ပါ။
//! //
//! file.write_all(b"important message");
//! ```
//!
//! သငျသညျ * * Rust ထဲမှာ, compiler ကသငျသညျ (အ `unused_must_use` lint ကထိန်းချုပ်ထားပုံမှန်အားဖြင့်,) သတိပေးပေးမည်ရေးပြုလျှင်။
//!
//! သင်အမှားကိုမကိုင်တွယ်လိုပါက [`expect`] နှင့်အောင်မြင်မှုရိုးရိုးရှင်းရှင်းပြောပါ။
//! ရေးသားမှုမအောင်မြင်ပါက panic သည်အနည်းငယ်သာအသုံးဝင်သောသတင်းစကားကိုဖော်ပြသည်။
//!
//! ```no_run
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! file.write_all(b"important message").expect("failed to write message");
//! ```
//!
//! အောင်မြင်မှုကိုလည်းရိုးရိုးလေးပြောပါလိမ့်မယ်။
//!
//! ```no_run
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # let mut file = File::create("valuable_data.txt").unwrap();
//! assert!(file.write_all(b"important message").is_ok());
//! ```
//!
//! သို့မဟုတ်အမှားကို [`?`] ဖြင့်ခေါ်ဝေါ်သောအမှားများကိုပြန့်ပွားစေပါ။
//!
//! ```
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # use std::io;
//! # #[allow(dead_code)]
//! fn write_message() -> io::Result<()> {
//!     let mut file = File::create("valuable_data.txt")?;
//!     file.write_all(b"important message")?;
//!     Ok(())
//! }
//! ```
//!
//! # မေးခွန်းအမှတ်ပေးသူ၊ `?`
//!
//! [`Result`] type ကိုပြန်ပို့ပေးသော function များစွာကိုခေါ်ဆိုသည့် code ရေးသောအခါအမှားကိုင်တွယ်ခြင်းသည်ငြီးငွေ့ဖွယ်ကောင်းနိုင်သည်။
//! မေးခွန်းအမှတ်အသားအော်ပရေတာ [`?`] သည်အမှားပြန့်ပွားစေသည့် boilerplate အချို့ကိုခေါ်ဝေါ်သော stack ကိုဖုံးကွယ်ထားသည်။
//!
//! ဒါဟာဒီအစားထိုး:
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     // အမှားအပေါ်အစောပိုင်းပြန်လာ
//!     let mut file = match File::create("my_best_friends.txt") {
//!            Err(e) => return Err(e),
//!            Ok(f) => f,
//!     };
//!     if let Err(e) = file.write_all(format!("name: {}\n", info.name).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("age: {}\n", info.age).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("rating: {}\n", info.rating).as_bytes()) {
//!         return Err(e)
//!     }
//!     Ok(())
//! }
//! ```
//!
//! ဒီနှင့်အတူ:
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     let mut file = File::create("my_best_friends.txt")?;
//!     // အမှားအပေါ်အစောပိုင်းပြန်လာ
//!     file.write_all(format!("name: {}\n", info.name).as_bytes())?;
//!     file.write_all(format!("age: {}\n", info.age).as_bytes())?;
//!     file.write_all(format!("rating: {}\n", info.rating).as_bytes())?;
//!     Ok(())
//! }
//! ```
//!
//! *ဒါဟာအများကြီးပိုကောင်းသလိုပဲ!*
//!
//! [`?`] ဖြင့်ဖော်ပြမှုအဆုံးသတ်ခြင်းသည်ရလဒ် [`Err`] မဟုတ်လျှင်၎င်းမှပူးတွဲပါ ၀ င်သည့်လုပ်ဆောင်မှုမှစောစောပြန်လာသည့်အမှုကိစ္စအတွက်မဟုတ်ပါက ([`Ok`]) တန်ဖိုးကိုမဖြည်နိုင်သည့်အောင်မြင်မှုရရှိလိမ့်မည်။
//!
//!
//! [`?`] [`Result`] ကိုပြန်ပို့သောလုပ်ဆောင်မှုများတွင်သာ၎င်းကိုပေးသော [`Err`] ၏အစောပိုင်းပြန်လာမှုကြောင့်သာအသုံးပြုနိုင်သည်။
//!
//! [`expect`]: Result::expect
//! [`Write`]: ../../std/io/trait.Write.html
//! [`write_all`]: ../../std/io/trait.Write.html#method.write_all
//! [`io::Result`]: ../../std/io/type.Result.html
//! [`?`]: crate::ops::Try
//! [`Ok(T)`]: Ok
//! [`Err(E)`]: Err
//! [`io::Error`]: ../../std/io/struct.Error.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{self, FromIterator, FusedIterator, TrustedLen};
use crate::ops::{self, Deref, DerefMut};
use crate::{convert, fmt, hint};

/// `Result` အောင်မြင်မှုအတွက် ([`Ok`]) သို့မဟုတ်ရှုံးနိမ့်သည့် ([`Err`]) ကိုကိုယ်စားပြုသောအမျိုးအစားတစ်ခုဖြစ်သည်။
///
/// အသေးစိတ်အတွက် [module documentation](self) ကိုကြည့်ပါ။
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[must_use = "this `Result` may be an `Err` variant, which should be handled"]
#[rustc_diagnostic_item = "result_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Result<T, E> {
    /// အောင်မြင်မှုတန်ဖိုးပါဝင်သည်
    #[lang = "Ok"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Ok(#[stable(feature = "rust1", since = "1.0.0")] T),

    /// အမှားတန်ဖိုးပါရှိသည်
    #[lang = "Err"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Err(#[stable(feature = "rust1", since = "1.0.0")] E),
}

/////////////////////////////////////////////////////////////////////////////
// အကောင်အထည်ဖော်မှုကိုရိုက်ပါ
/////////////////////////////////////////////////////////////////////////////

impl<T, E> Result<T, E> {
    /////////////////////////////////////////////////////////////////////////
    // ပါရှိသောတန်ဖိုးများကိုမေးမြန်းခြင်း
    /////////////////////////////////////////////////////////////////////////

    /// ရလဒ် [`Ok`] လျှင် `true` ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_ok(), true);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_ok(), false);
    /// ```
    #[must_use = "if you intended to assert that this is ok, consider `.unwrap()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_ok(&self) -> bool {
        matches!(*self, Ok(_))
    }

    /// ရလဒ် [`Err`] လျှင် `true` Returns ။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_err(), false);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_err(), true);
    /// ```
    #[must_use = "if you intended to assert that this is err, consider `.unwrap_err()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_err(&self) -> bool {
        !self.is_ok()
    }

    /// ရလဒ်ပေးထားသောတန်ဖိုးကိုတစ်ခု [`Ok`] တန်ဖိုးကိုလျှင် `true` ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Result<u32, &str> = Ok(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Ok(y) => x == y,
            Err(_) => false,
        }
    }

    /// ရလဒ်ပေးထားသောတန်ဖိုးကိုတစ်ခု [`Err`] တန်ဖိုးကိုလျှင် `true` ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_contains_err)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains_err(&"Some error message"), true);
    ///
    /// let x: Result<u32, &str> = Err("Some other error message");
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "result_contains_err", issue = "62358")]
    pub fn contains_err<F>(&self, f: &F) -> bool
    where
        F: PartialEq<E>,
    {
        match self {
            Ok(_) => false,
            Err(e) => f == e,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // တစ်ခုချင်းစီကိုမူကွဲများအတွက် adapter
    /////////////////////////////////////////////////////////////////////////

    /// `Result<T, E>` မှ [`Option<T>`] သို့ပြောင်းသည်။
    ///
    /// `self` ကို [`Option<T>`] တစ်ခုအဖြစ်ပြောင်းလဲပြီး `self` ကိုစားသုံးသည်ဆိုပါကအမှားကိုဖယ်ထုတ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.ok(), Some(2));
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.ok(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok(self) -> Option<T> {
        match self {
            Ok(x) => Some(x),
            Err(_) => None,
        }
    }

    /// `Result<T, E>` မှ [`Option<E>`] သို့ပြောင်းသည်။
    ///
    /// `self` ကို [`Option<E>`] တစ်ခုအဖြစ်ပြောင်းလဲပြီး `self` ကိုစားသုံးသည်။ အောင်မြင်လျှင်တန်ဖိုးကိုဖယ်ထုတ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.err(), None);
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.err(), Some("Nothing here"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn err(self) -> Option<E> {
        match self {
            Ok(_) => None,
            Err(x) => Some(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // ကိုးကားချက်များနှင့်အလုပ်လုပ်ဘို့ adapter
    /////////////////////////////////////////////////////////////////////////

    /// `&Result<T, E>` မှ `Result<&T, &E>` သို့ပြောင်းသည်။
    ///
    /// `Result` အသစ်တစ်ခုကိုထုတ်လုပ်သည်။ မူရင်းသို့ရည်ညွှန်းချက်ပါရှိသည်။ မူရင်းကိုနေရာတွင်ထားခဲ့သည်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.as_ref(), Ok(&2));
    ///
    /// let x: Result<u32, &str> = Err("Error");
    /// assert_eq!(x.as_ref(), Err(&"Error"));
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Result<&T, &E> {
        match *self {
            Ok(ref x) => Ok(x),
            Err(ref x) => Err(x),
        }
    }

    /// `&mut Result<T, E>` မှ `Result<&mut T, &mut E>` သို့ပြောင်းသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// fn mutate(r: &mut Result<i32, i32>) {
    ///     match r.as_mut() {
    ///         Ok(v) => *v = 42,
    ///         Err(e) => *e = 0,
    ///     }
    /// }
    ///
    /// let mut x: Result<i32, i32> = Ok(2);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap(), 42);
    ///
    /// let mut x: Result<i32, i32> = Err(13);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap_err(), 0);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Result<&mut T, &mut E> {
        match *self {
            Ok(ref mut x) => Ok(x),
            Err(ref mut x) => Err(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // ပါရှိသောတန်ဖိုးများကိုပြောင်းလဲ
    /////////////////////////////////////////////////////////////////////////

    /// ပါ ၀ င်သည့် [`Ok`] တန်ဖိုးတစ်ခုသို့လုပ်ဆောင်ချက်တစ်ခုကို အသုံးပြု၍ `Result<T, E>` သို့ `Result<U, E>` သို့မြေပုံတစ်ခုဆွဲသည်၊ [`Err`] တန်ဖိုးကိုနဂိုအတိုင်းထားရှိသည်။
    ///
    ///
    /// ဒီ function ကို function နှစ်ခု၏ရလဒ်များကို compose လုပ်ရန်အသုံးပြုနိုင်သည်။
    ///
    /// # Examples
    ///
    /// string တစ်ခု၏ line တစ်ခုစီတွင်နှစ်ခုကိုမြှောက်ပါ။
    ///
    /// ```
    /// let line = "1\n2\n3\n4\n";
    ///
    /// for num in line.lines() {
    ///     match num.parse::<i32>().map(|i| i * 2) {
    ///         Ok(n) => println!("{}", n),
    ///         Err(..) => {}
    ///     }
    /// }
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => Ok(op(t)),
            Err(e) => Err(e),
        }
    }

    /// ပါ ၀ င်သည့်တန်ဖိုး ([`Ok`]) ရှိသည့် function ကိုအသုံးချသည် (သို့) ပေးထားသောမူရင်း ([`Err`]) ကိုပြန်လည်ပေးသည်။
    ///
    /// `map_or` သို့အငြင်းပွားမှုများကိုစိတ်အားထက်သန်စွာအကဲဖြတ်သည်။function call တစ်ခု၏ရလဒ်ကိုသင်ဖြတ်သန်းသွားသည်ဆိုလျှင်၎င်းသည်အလွန်ပျင်းရိစွာအကဲဖြတ်ထားသော [`map_or_else`] ကိုအသုံးပြုရန်အကြံပြုသည်။
    ///
    ///
    /// [`map_or_else`]: Result::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or", since = "1.41.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(_) => default,
        }
    }

    /// ပါ ၀ င်သည့် [`Ok`] တန်ဖိုးတစ်ခုသို့မဟုတ် [`Err`] တန်ဖိုးတစ်ခုသို့ကျောထောက်နောက်ခံပေးသောလုပ်ဆောင်ချက်တစ်ခုအား အသုံးပြု၍ `Result<T, E>` သို့ `U` သို့မြေပုံများဆွဲသည်။
    ///
    ///
    /// ဤလုပ်ဆောင်ချက်သည်အမှားတစ်ခုကိုကိုင်တွယ်နေစဉ်အောင်မြင်သောရလဒ်ကိုထုတ်ယူရန်သုံးနိုင်သည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x : Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 3);
    ///
    /// let x : Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 42);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or_else", since = "1.41.0")]
    pub fn map_or_else<U, D: FnOnce(E) -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(e) => default(e),
        }
    }

    /// ပါ ၀ င်သည့် [`Err`] တန်ဖိုးတစ်ခုသို့လုပ်ဆောင်ချက်တစ်ခုကို အသုံးပြု၍ `Result<T, E>` သို့ `Result<T, F>` သို့မြေပုံတစ်ခုဆွဲသည်၊ [`Ok`] တန်ဖိုးကိုနဂိုအတိုင်းထားရှိသည်။
    ///
    ///
    /// ဤလုပ်ဆောင်ချက်သည်အမှားတစ်ခုကိုကိုင်တွယ်နေစဉ်အောင်မြင်သောရလဒ်ကိုဖြတ်သန်းရန်အသုံးပြုနိုင်သည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// fn stringify(x: u32) -> String { format!("error code: {}", x) }
    ///
    /// let x: Result<u32, u32> = Ok(2);
    /// assert_eq!(x.map_err(stringify), Ok(2));
    ///
    /// let x: Result<u32, u32> = Err(13);
    /// assert_eq!(x.map_err(stringify), Err("error code: 13".to_string()));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_err<F, O: FnOnce(E) -> F>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => Err(op(e)),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // ကြားမှာဆောက်လုပ်ရေး
    /////////////////////////////////////////////////////////////////////////

    /// ဖြစ်နိုင်သည်ပါရှိသောတန်ဖိုးကိုကျော်ကြားမှာပြန်သွားသည်။
    ///
    /// အကယ်၍ ရလဒ်သည် [`Result::Ok`] ဖြစ်လျှင်၎င်းသည်မဟုတ်ပါ။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(7);
    /// assert_eq!(x.iter().next(), Some(&7));
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { inner: self.as_ref().ok() }
    }

    /// ဖြစ်နိုင်သည့်ပါ ၀ င်သောတန်ဖိုးအပေါ် mutable ကြားဖြတ်တစ်ခုကိုပြန်ပို့သည်။
    ///
    /// အကယ်၍ ရလဒ်သည် [`Result::Ok`] ဖြစ်လျှင်၎င်းသည်မဟုတ်ပါ။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let mut x: Result<u32, &str> = Ok(7);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 40,
    ///     None => {},
    /// }
    /// assert_eq!(x, Ok(40));
    ///
    /// let mut x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: self.as_mut().ok() }
    }

    ////////////////////////////////////////////////////////////////////////
    // တန်ဖိုးများအပေါ် Boolean စစ်ဆင်ရေး, စိတ်အားထက်သန်ခြင်းနှင့်ပျင်းရိ
    /////////////////////////////////////////////////////////////////////////

    /// အကယ်၍ ရလဒ် [`Ok`] ဖြစ်ပါက `res` ကိုပြန်ပို့သည်မဟုတ်ပါက `self` ၏ [`Err`] တန်ဖိုးကိုပြန်လည်ပေးသည်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<&str, &str> = Ok("foo");
    /// assert_eq!(x.and(y), Err("early error"));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("not a 2"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Ok("different result type");
    /// assert_eq!(x.and(y), Ok("different result type"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, res: Result<U, E>) -> Result<U, E> {
        match self {
            Ok(_) => res,
            Err(e) => Err(e),
        }
    }

    /// အကယ်၍ ရလဒ် [`Ok`] ဖြစ်ပါက `op` ကိုခေါ်ပါကမဟုတ်လျှင် `self` ၏ [`Err`] တန်ဖိုးကိုပြန်လည်ပေးသည်။
    ///
    ///
    /// ဒီ function `Result` တန်ဖိုးများအပေါ်အခြေခံပြီးထိန်းချုပ်မှုစီးဆင်းမှုအတွက်အသုံးပြုနိုင်ပါတယ်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).and_then(sq).and_then(sq), Ok(16));
    /// assert_eq!(Ok(2).and_then(sq).and_then(err), Err(4));
    /// assert_eq!(Ok(2).and_then(err).and_then(sq), Err(2));
    /// assert_eq!(Err(3).and_then(sq).and_then(sq), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Result<U, E>>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => op(t),
            Err(e) => Err(e),
        }
    }

    /// အကယ်၍ ရလဒ် [`Err`] ဖြစ်ပါက `res` ကိုပြန်ပို့သည်မဟုတ်ပါက `self` ၏ [`Ok`] တန်ဖိုးကိုပြန်လည်ပေးသည်။
    ///
    /// `or` သို့အငြင်းပွားမှုများကိုစိတ်အားထက်သန်စွာအကဲဖြတ်သည်။function call တစ်ခု၏ရလဒ်ကိုသင်ဖြတ်သန်းသွားသည်ဆိုလျှင်၎င်းသည်အလွန်ပျင်းရိစွာအကဲဖြတ်ထားသော [`or_else`] ကိုအသုံးပြုရန်အကြံပြုသည်။
    ///
    ///
    /// [`or_else`]: Result::or_else
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Ok(100);
    /// assert_eq!(x.or(y), Ok(2));
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or<F>(self, res: Result<T, F>) -> Result<T, F> {
        match self {
            Ok(v) => Ok(v),
            Err(_) => res,
        }
    }

    /// အကယ်၍ ရလဒ် [`Err`] ဖြစ်ပါက `op` ကိုခေါ်ပါကမဟုတ်လျှင် `self` ၏ [`Ok`] တန်ဖိုးကိုပြန်လည်ပေးသည်။
    ///
    ///
    /// ဒီ function ကိုရလဒ်တန်ဖိုးအပေါ်အခြေခံပြီးထိန်းချုပ်မှုစီးဆင်းမှုအတွက်အသုံးပြုနိုင်ပါသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).or_else(sq).or_else(sq), Ok(2));
    /// assert_eq!(Ok(2).or_else(err).or_else(sq), Ok(2));
    /// assert_eq!(Err(3).or_else(sq).or_else(err), Ok(9));
    /// assert_eq!(Err(3).or_else(err).or_else(err), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F, O: FnOnce(E) -> Result<T, F>>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => op(e),
        }
    }

    /// ပါရှိသော [`Ok`] တန်ဖိုးသို့မဟုတ်ပေးထားသောပုံသေကိုပြန်ပို့သည်။
    ///
    /// `unwrap_or` သို့အငြင်းပွားမှုများကိုစိတ်အားထက်သန်စွာအကဲဖြတ်သည်။function call တစ်ခု၏ရလဒ်ကိုသင်ဖြတ်သန်းသွားသည်ဆိုလျှင်၎င်းသည်အလွန်ပျင်းရိစွာအကဲဖြတ်ထားသော [`unwrap_or_else`] ကိုအသုံးပြုရန်အကြံပြုသည်။
    ///
    ///
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let default = 2;
    /// let x: Result<u32, &str> = Ok(9);
    /// assert_eq!(x.unwrap_or(default), 9);
    ///
    /// let x: Result<u32, &str> = Err("error");
    /// assert_eq!(x.unwrap_or(default), default);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Ok(t) => t,
            Err(_) => default,
        }
    }

    /// ပါ ၀ င်သည့် [`Ok`] value ကို return ပြန်ပေးတယ်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// fn count(x: &str) -> usize { x.len() }
    ///
    /// assert_eq!(Ok(2).unwrap_or_else(count), 2);
    /// assert_eq!(Err("foo").unwrap_or_else(count), 3);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce(E) -> T>(self, op: F) -> T {
        match self {
            Ok(t) => t,
            Err(e) => op(e),
        }
    }

    /// ပါ ၀ င်သည့် [`Ok`] value ကို return ပြန်ပြီး `self` တန်ဖိုးကိုစားပြီး၊ တန်ဖိုးသည် [`Err`] တစ်ခုမဟုတ်ဆိုတာကိုမမှတ်မိဘဲ။
    ///
    ///
    /// # Safety
    ///
    /// ဤနည်းလမ်းကို [`Err`] ဖြင့်ခေါ်ခြင်းသည် *[undefined behavior]* ဖြစ်သည်။
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, 2);
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// unsafe { x.unwrap_unchecked(); } // undefined အပြုအမူ!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_ok());
        match self {
            Ok(t) => t,
            // လုံခြုံမှု: လုံခြုံရေးစာချုပ်အဆိုပါခေါ်ဆိုမှုများကထောကျခံခဲ့ရမည်ဖြစ်သည်။
            Err(_) => unsafe { hint::unreachable_unchecked() },
        }
    }

    /// ပါ ၀ င်သည့် [`Err`] value ကို return ပြန်ပြီး `self` တန်ဖိုးကိုစားပြီး၊ တန်ဖိုးသည် [`Ok`] တစ်ခုမဟုတ်ဆိုတာကိုမမှတ်မိဘဲ။
    ///
    ///
    /// # Safety
    ///
    /// ဤနည်းလမ်းကို [`Ok`] ဖြင့်ခေါ်ခြင်းသည် *[undefined behavior]* ဖြစ်သည်။
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// unsafe { x.unwrap_err_unchecked() }; // undefined အပြုအမူ!
    /// ```
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(unsafe { x.unwrap_err_unchecked() }, "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_err_unchecked(self) -> E {
        debug_assert!(self.is_err());
        match self {
            // လုံခြုံမှု: လုံခြုံရေးစာချုပ်အဆိုပါခေါ်ဆိုမှုများကထောကျခံခဲ့ရမည်ဖြစ်သည်။
            Ok(_) => unsafe { hint::unreachable_unchecked() },
            Err(e) => e,
        }
    }
}

impl<T: Copy, E> Result<&T, E> {
    /// X0 `Ok` အစိတ်အပိုင်းပါအကြောင်းအရာများကိုကူးယူခြင်းအားဖြင့် `Result<&T, E>` တစ်ခုကို `Result<T, E>` တစ်ခုသို့ပုံဖော်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&t| t)
    }
}

impl<T: Copy, E> Result<&mut T, E> {
    /// `Ok` အစိတ်အပိုင်းပါအကြောင်းအရာများကိုကူးယူခြင်းအားဖြင့် `Result<&mut T, E>` တစ်ခုကို `Result<T, E>` တစ်ခုသို့ပုံဖော်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone, E> Result<&T, E> {
    /// X0 `Ok` အစိတ်အပိုင်းတစ်ခု၏အကြောင်းအရာများကိုပုံတူပွားခြင်းဖြင့် `Result<&T, E>` တစ်ခု `Result<T, E>` တစ်ခုသို့မြေပုံထုတ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone, E> Result<&mut T, E> {
    /// X0 `Ok` အစိတ်အပိုင်းတစ်ခု၏အကြောင်းအရာများကိုပုံတူပွားခြင်းဖြင့် `Result<&mut T, E>` တစ်ခု `Result<T, E>` တစ်ခုသို့မြေပုံထုတ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T, E: fmt::Debug> Result<T, E> {
    /// ပါ ၀ င်သည့် [`Ok`] တန်ဖိုးကို `self` တန်ဖိုးကိုလောင်ကျွမ်းစေသည်။
    ///
    /// # Panics
    ///
    /// Panics သည်တန်ဖိုးတစ်ခု [`Err`] ဖြစ်ပါက၊ လွန်ခဲ့သောမက်ဆေ့ခ်ျနှင့် 0X ၏ပါဝင်သည့် Z0panic မက်ဆေ့ခ်ျပါရှိပါက Panics သည်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.expect("Testing expect"); // panics with `Testing expect: emergency failure`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect", since = "1.4.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed(msg, &e),
        }
    }

    /// ပါ ၀ င်သည့် [`Ok`] တန်ဖိုးကို `self` တန်ဖိုးကိုလောင်ကျွမ်းစေသည်။
    ///
    /// ဒီ function ကို panic ၎င်း၏အသုံးပြုမှုကိုယေဘုယျအားဖြင့်စိတ်ပျက်အားလျော့နေသည်ဖြစ်နိုင်သည်ကြောင့်ဖြစ်သည်။
    /// အဲဒီအစား [`Err`] ကိစ္စကိုပုံစံကိုက်ညီပြီးရှင်းလင်းစွာကိုင်တွယ်လိုပါက [`unwrap_or`], [`unwrap_or_else`] သို့မဟုတ် [`unwrap_or_default`] ကိုခေါ်ပါ။
    ///
    ///
    /// [`unwrap_or`]: Result::unwrap_or
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    /// [`unwrap_or_default`]: Result::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics တန်ဖိုးသည် [`Err`] ဖြစ်ပါက [`Err`] ၏တန်ဖိုးမှ panic မက်ဆေ့ခ်ျဖြင့်ပါ။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.unwrap(), 2);
    /// ```
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.unwrap(); // panics with `emergency failure`
    /// ```
    ///
    ///
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap(self) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed("called `Result::unwrap()` on an `Err` value", &e),
        }
    }
}

impl<T: fmt::Debug, E> Result<T, E> {
    /// ပါ ၀ င်သည့် [`Err`] တန်ဖိုးကို `self` တန်ဖိုးကိုလောင်ကျွမ်းစေသည်။
    ///
    /// # Panics
    ///
    /// Panics သည်တန်ဖိုးတစ်ခု [`Ok`] ဖြစ်ပါက၊ လွန်ခဲ့သောမက်ဆေ့ခ်ျနှင့် 0X ၏ပါဝင်သည့် Z0panic မက်ဆေ့ခ်ျပါရှိပါက Panics သည်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(10);
    /// x.expect_err("Testing expect_err"); // panics with `Testing expect_err: 10`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect_err", since = "1.17.0")]
    pub fn expect_err(self, msg: &str) -> E {
        match self {
            Ok(t) => unwrap_failed(msg, &t),
            Err(e) => e,
        }
    }

    /// ပါ ၀ င်သည့် [`Err`] တန်ဖိုးကို `self` တန်ဖိုးကိုလောင်ကျွမ်းစေသည်။
    ///
    /// # Panics
    ///
    /// Panics တန်ဖိုးသည် [`Ok`] ဖြစ်ပါက [`Ok`] 'တန်ဖိုးမှထောက်ပံ့ပေးသော panic မက်ဆေ့ခ်ျနှင့်ပါ။
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(2);
    /// x.unwrap_err(); // panics with `2`
    /// ```
    ///
    /// ```
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(x.unwrap_err(), "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_err(self) -> E {
        match self {
            Ok(t) => unwrap_failed("called `Result::unwrap_err()` on an `Ok` value", &t),
            Err(e) => e,
        }
    }
}

impl<T: Default, E> Result<T, E> {
    /// ပါရှိသော [`Ok`] တန်ဖိုးကိုသို့မဟုတ်ပုံမှန်အတိုင်းပြန်သွားသည်
    ///
    /// X0 `self` အငြင်းအခုံကိုစားသည်။ အကယ်၍ [`Ok`] သည်ပါ ၀ င်သောတန်ဖိုးကိုပြန်ပေးသည်။ မဟုတ်လျှင် [`Err`] လျှင်ထိုအမျိုးအစားအတွက်မူလတန်ဖိုးကိုပြန်ပို့သည်။
    ///
    ///
    /// # Examples
    ///
    /// 0 (ကိန်းများအတွက် default value ကို) သို့ညံ့ဖျင်း-ဖွဲ့စည်းခဲ့ညှို့လှည့်တစ်ဦး integer ဖြစ်တဲ့အတွက်တစ်ဦး string ကိုပြောင်းပေးပါတယ်။
    /// [`parse`] အမှားတစ်ခု [`Err`] ပြန်လာ, [`FromStr`] အကောင်အထည်ဖော်သောအခြားမည်သည့်အမျိုးအစားတစ်ခု string ကိုပြောင်းလဲ။
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_unwrap_or_default", since = "1.16.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Ok(x) => x,
            Err(_) => Default::default(),
        }
    }
}

#[unstable(feature = "unwrap_infallible", reason = "newly added", issue = "61695")]
impl<T, E: Into<!>> Result<T, E> {
    /// ပါ ၀ င်သည့် [`Ok`] တန်ဖိုးကို return ပြန်သည်။
    ///
    /// [`unwrap`] နှင့်မတူဘဲဤနည်းလမ်းသည်၎င်းအတွက်ပြုလုပ်ထားသည့်ရလဒ်အမျိုးအစားများတွင် panic ဘယ်တော့မှမသိပါ။
    /// သို့အတွက်ကြောင့် `Result` ၏အမှားအမျိုးအစားအကြာတွင်အမှန်တကယ်ဖြစ်ပေါ်နိုင်သောမှားယွင်းမှုတစ်ခုသို့ပြောင်းလဲလျှင် compile လုပ်ခြင်းရန်ပျက်ကွက်ပါလိမ့်မယ်တစ်ဦးထိန်းအကာအကွယ်အဖြစ်အစား `unwrap` ၏သုံးနိုင်တယ်။
    ///
    ///
    /// [`unwrap`]: Result::unwrap
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// # #![feature(never_type)]
    /// # #![feature(unwrap_infallible)]
    ///
    /// fn only_good_news() -> Result<String, !> {
    ///     Ok("this is fine".into())
    /// }
    ///
    /// let s: String = only_good_news().into_ok();
    /// println!("{}", s);
    /// ```
    ///
    ///
    #[inline]
    pub fn into_ok(self) -> T {
        match self {
            Ok(x) => x,
            Err(e) => e.into(),
        }
    }
}

impl<T: Deref, E> Result<T, E> {
    /// `Result<T, E>` (သို့မဟုတ် `&Result<T, E>`) မှ `Result<&<T as Deref>::Target, &E>` သို့ပြောင်းသည်။
    ///
    /// [`Deref`](crate::ops::Deref) မှတစ်ဆင့်မူလ [`Result`] ၏ [`Ok`] မူကွဲကိုပေါင်းစည်းပြီး [`Result`] အသစ်ကိုပြန်ပို့သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&str, &u32> = Ok("hello");
    /// assert_eq!(x.as_deref(), y);
    ///
    /// let x: Result<String, u32> = Err(42);
    /// let y: Result<&str, &u32> = Err(&42);
    /// assert_eq!(x.as_deref(), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref(&self) -> Result<&T::Target, &E> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut, E> Result<T, E> {
    /// `Result<T, E>` (သို့မဟုတ် `&mut Result<T, E>`) မှ `Result<&mut <T as DerefMut>::Target, &mut E>` မှ converter ။
    ///
    /// [`DerefMut`](crate::ops::DerefMut) မှတစ်ဆင့်မူလ [`Result`] ၏ [`Ok`] မူကွဲကိုပေါင်းစည်းပြီး [`Result`] အသစ်ကိုပြန်ပို့သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = "HELLO".to_string();
    /// let mut x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&mut str, &mut u32> = Ok(&mut s);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    ///
    /// let mut i = 42;
    /// let mut x: Result<String, u32> = Err(42);
    /// let y: Result<&mut str, &mut u32> = Err(&mut i);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref_mut(&mut self) -> Result<&mut T::Target, &mut E> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Result<Option<T>, E> {
    /// `Option` ၏ `Result` တစ်ခုကို `Result` ၏ `Option` တစ်ခုသို့ပြောင်းသည်။
    ///
    /// `Ok(None)` `None` နဲ့ဆက်စပ်နေမှာပါ။
    /// `Ok(Some(_))` `Err(_)` ကို `Some(Ok(_))` နှင့် `Some(Err(_))` တို့သို့ချိတ်ဆက်ထားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x.transpose(), y);
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_result", issue = "82814")]
    pub const fn transpose(self) -> Option<Result<T, E>> {
        match self {
            Ok(Some(x)) => Some(Ok(x)),
            Ok(None) => None,
            Err(e) => Some(Err(e)),
        }
    }
}

impl<T, E> Result<Result<T, E>, E> {
    /// `Result<Result<T, E>, E>` မှ `Result<T, E>` သို့ပြောင်းသည်
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Ok("hello"));
    /// assert_eq!(Ok("hello"), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Err(6));
    /// assert_eq!(Err(6), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Err(6);
    /// assert_eq!(Err(6), x.flatten());
    /// ```
    ///
    /// သာ Flattening တစ်ကြိမ်အသိုက်ထဲကတစ်ခုအဆင့်ကိုဖယ်ရှားပေး:
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<Result<&'static str, u32>, u32>, u32> = Ok(Ok(Ok("hello")));
    /// assert_eq!(Ok(Ok("hello")), x.flatten());
    /// assert_eq!(Ok("hello"), x.flatten().flatten());
    /// ```
    #[inline]
    #[unstable(feature = "result_flattening", issue = "70142")]
    pub fn flatten(self) -> Result<T, E> {
        self.and_then(convert::identity)
    }
}

impl<T> Result<T, T> {
    /// `self` `Ok` ဖြစ်ပါက [`Ok`] တန်ဖိုး၊ `self` `Err` ဖြစ်ပါက [`Err`] တန်ဖိုးကို return လုပ်သည်။
    ///
    /// တစ်နည်းပြောရရင်ဒီ function က `Result<T, T>` ရဲ့တန်ဖိုး (`T`) ကို return ပြန်ပေးတယ်။ အဲ့တာက `Ok` (သို့) `Err` ပဲဖြစ်ဖြစ်။
    ///
    /// ၎င်းသည် [`Atomic*::compare_exchange`] သို့မဟုတ် [`slice::binary_search`] ကဲ့သို့သော API များနှင့်တွဲဖက်အသုံးဝင်သည်၊ သို့သော်ရလဒ် `Ok` ဟုတ်မဟုတ်ကိုသင်ဂရုမစိုက်သည့်ကိစ္စများတွင်သာဖြစ်နိုင်သည်။
    ///
    ///
    /// [`Atomic*::compare_exchange`]: crate::sync::atomic::AtomicBool::compare_exchange
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_into_ok_or_err)]
    /// let ok: Result<u32, u32> = Ok(3);
    /// let err: Result<u32, u32> = Err(4);
    ///
    /// assert_eq!(ok.into_ok_or_err(), 3);
    /// assert_eq!(err.into_ok_or_err(), 4);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "result_into_ok_or_err", reason = "newly added", issue = "82223")]
    pub const fn into_ok_or_err(self) -> T {
        match self {
            Ok(v) => v,
            Err(v) => v,
        }
    }
}

// ၎င်းသည်နည်းလမ်းများ၏ကုဒ်အရွယ်အစားကိုလျှော့ချရန်သီးခြားလုပ်ဆောင်ချက်ဖြစ်သည်
#[inline(never)]
#[cold]
#[track_caller]
fn unwrap_failed(msg: &str, error: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, error)
}

/////////////////////////////////////////////////////////////////////////////
// Trait အကောင်အထည်ဖော်မှု
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, E: Clone> Clone for Result<T, E> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Ok(x) => Ok(x.clone()),
            Err(x) => Err(x.clone()),
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Ok(to), Ok(from)) => to.clone_from(from),
            (Err(to), Err(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, E> IntoIterator for Result<T, E> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// ဖြစ်နိုင်သည့်ပါ ၀ င်သောတန်ဖိုးများအပေါ်တွင်စားသုံးသည့်ကြားကပြန်ပို့ပေးသည်။
    ///
    /// အကယ်၍ ရလဒ်သည် [`Result::Ok`] ဖြစ်လျှင်၎င်းသည်မဟုတ်ပါ။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(5);
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, [5]);
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, []);
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self.ok() }
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a Result<T, E> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a mut Result<T, E> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// ရလဒ်ကြားဖြတ်
/////////////////////////////////////////////////////////////////////////////

/// တစ်ဦး [`Result`] ၏ [`Ok`] မူကွဲတစ်ခုရည်ညွှန်းကျော်တစ်ဦးကြားမှာ။
///
/// အကယ်၍ ရလဒ်သည် [`Ok`] ဖြစ်လျှင်၎င်းသည်မဟုတ်ပါ။
///
/// [`Result::iter`] ကဖန်တီးသည်။
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    inner: Option<&'a T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner }
    }
}

/// တစ် ဦး [`Result`] ၏ [`Ok`] မူကွဲတစ်ခု mutable ရည်ညွှန်းကျော်တစ်ခုကြားမှာ။
///
/// [`Result::iter_mut`] ကဖန်တီးသည်။
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    inner: Option<&'a mut T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// တစ် ဦး [`Result`] ၏ [`Ok`] မူကွဲအတွက်တန်ဖိုးကိုကျော်ကြားမှာ။
///
/// အကယ်၍ ရလဒ်သည် [`Ok`] ဖြစ်လျှင်၎င်းသည်မဟုတ်ပါ။
///
/// ဤဖွဲ့စည်းပုံကို [`Result`] ([`IntoIterator`] trait မှထောက်ပံ့သည်) ပေါ်တွင် [`into_iter`] နည်းလမ်းဖြင့်ဖန်တီးထားသည်။
///
///
/// [`into_iter`]: IntoIterator::into_iter
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    inner: Option<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, E, V: FromIterator<A>> FromIterator<Result<A, E>> for Result<V, E> {
    /// `Iterator` ထဲက element တစ်ခုချင်းစီကိုယူသည်။ ၎င်းသည် `Err` ဖြစ်ပါကနောက်ထပ်ဒြပ်စင်များကိုယူမသွားဘဲ `Err` ကိုပြန်ပို့သည်။
    /// အဘယ်သူမျှမ `Err` ဖြစ်ပေါ်သင့်ကြောင်း, တစ်ဦးချင်းစီ `Result` ၏တန်ဖိုးများနှင့်အတူတစ်ဦးကွန်တိန်နာပြန်ရောက်နေပါတယ်။
    ///
    /// ဤတွင် vector အတွင်းရှိကိန်းတစ်ခုစီကိုတိုးချဲ့ပြီးပိုလျှံမှုကိုစစ်ဆေးသည်။
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_add(1).ok_or("Overflow!")
    /// ).collect();
    /// assert_eq!(res, Ok(vec![2, 3]));
    /// ```
    ///
    /// နောက်ဥပမာတစ်ခုကအခြားတစ်ခုကိန်းတစ်ခုထဲကတစ်ခုကိုနုတ်ဖို့ကြိုးစားနေတယ်၊ ဒီတစ်ကြိမ်မှာတော့ underflow ကိုစစ်ဆေးတယ်။
    ///
    /// ```
    /// let v = vec![1, 2, 0];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_sub(1).ok_or("Underflow!")
    /// ).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// ```
    ///
    /// ဤတွင်ယခင်နမူနာအပေါ် မူတည်၍ `Err` ပထမ `Err` မှနောက်ထပ်ဒြပ်စင်များကိုယူမသွားကြောင်းဖော်ပြသည်။
    ///
    /// ```
    /// let v = vec![3, 2, 1, 10];
    /// let mut shared = 0;
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32| {
    ///     shared += x;
    ///     x.checked_sub(2).ok_or("Underflow!")
    /// }).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// တတိယ element သည် underflow ဖြစ်စေသောကြောင့်နောက်ထပ် element များကိုယူခြင်းမရှိသောကြောင့် `shared` ၏နောက်ဆုံးတန်ဖိုးသည် 6 (= `3 + 2 + 1`) ဖြစ်ပြီး ၁၆ မဟုတ်ပါ။
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Result<A, E>>>(iter: I) -> Result<V, E> {
        // FIXME(#11084): ဤစွမ်းဆောင်ရည် bug ကိုပိတ်လိုက်သောအခါ၎င်းကို Iterator::scan ဖြင့်အစားထိုးနိုင်သည်။
        //

        iter::process_results(iter.into_iter(), |i| i.collect())
    }
}

#[unstable(feature = "try_trait", issue = "42327")]
impl<T, E> ops::Try for Result<T, E> {
    type Ok = T;
    type Error = E;

    #[inline]
    fn into_result(self) -> Self {
        self
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Ok(v)
    }

    #[inline]
    fn from_error(v: E) -> Self {
        Err(v)
    }
}