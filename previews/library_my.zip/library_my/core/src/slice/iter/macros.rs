//! အချပ်၏ကြားမှာအသုံးပြုသော Macros ။

// is_empty နှင့် len ကိုအသုံးပြုခြင်းသည်ကြီးမားသောစွမ်းဆောင်ရည်ကိုခြားနားစေသည်
macro_rules! is_empty {
    // ZST ကြားခံတစ်ခု၏အရှည်ကိုကျွန်ုပ်တို့ encode လုပ်ပုံသည်၎င်းသည် ZST နှင့် Non-ZST နှစ်ခုလုံးအတွက်အလုပ်လုပ်သည်။
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// အချို့သောဘောငျစစ်ဆေးမှုများဖယ်ရှားပစ်ရ (`position` ကိုကြည့်ပါ), ကျွန်တော်တစ်ဦးအတန်ငယ်မမျှော်လင့်ဘဲလမ်းအတွက်အရှည်တွက်ချက်။
// (`codegen/slice-position-bounds-check` 'ဖြင့်စမ်းသပ်သည်။)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // တစ်ခါတလေငါတို့ကမလုံခြုံတဲ့နေရာမှာသုံးတယ်

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // ကျွန်တော်တို့ဟာရှည်လျား ZST အချပ်ကြားမှာ၏အရှည်ကိုကိုယ်စားပြုဖို့ထုပ်ပေါ်တွင်မူတည်နေသောကြောင့်ဤအ _cannot_ `unchecked_sub` ကိုအသုံးပြုပါ။
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // `start <= end` သည် `offset_from` ထက်ပိုကောင်းသောအရာများကိုလုပ်နိုင်သည်ကိုကျွန်ုပ်တို့သိသည်။
            // ဒီနေရာမှာသင့်လျော်သောအလံ setting အားဖြင့်ငါတို့သည်ကြောင့်ဘောငျစစ်ဆေးမှုများကိုဖယ်ရှားကူညီပေးသည်သော LLVM ဒီပြောပြနိုင်ပါတယ်။
            // လုံခြုံမှု-အမျိုးအစားမှာလျော့ပါးသွားမည်။ `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // LLVM ကိုလည်း LL အရွယ်အစားကိုတိကျစွာသတ်မှတ်ထားသောအရွယ်အစားဖြင့်ခွဲခြားထားခြင်းအားဖြင့် `len() == 0` အစား `len() == 0` ကို `start == end` သို့ပိုကောင်းအောင်လုပ်နိုင်သည်။
            //
            // လုံခြုံမှု-လျော့ပါးသွားမည်ဖြစ်သလိုအမျိုးအစားအားဖြင့်၊
            //         သူတို့အကြားအကွာအဝေး pointee အရွယ်အစားမျိုးစုံဖြစ်ရပါမည်
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// အဆိုပါ `Iter` နှင့် `IterMut` ကြားမှာ၏ shared ချက်နှင့်အဓိပ္ပါယ်
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // ပထမ element ကို return ပြန်ပေးတယ်။
        // ကိုအလွန်တစ်ခု Inline Function ကိုနှိုင်းယှဉ်စွမ်းဆောင်ရည်ကိုပိုမိုကောင်းမွန်စေတယ်။
        // ကြားမှာအချည်းနှီးမဖြစ်ရ
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // နောက်ဆုံး element ကိုပြန်ပို့ပေးပြီးကြားမှာ၏အဆုံးကို 1 အားဖြင့်နောက်ပြန်လှည့်ပေးသည်။
        // ကိုအလွန်တစ်ခု Inline Function ကိုနှိုင်းယှဉ်စွမ်းဆောင်ရည်ကိုပိုမိုကောင်းမွန်စေတယ်။
        // ကြားမှာအချည်းနှီးမဖြစ်ရ
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // T သည် ZST ဖြစ်သည့်အခါကြားမှာအဆုံးကို `n` ကနောက်ပြန်လှည့်ခြင်းဖြင့်ရွေ့လျားမှုကိုချုံ့သည်။
        // `n` `self.len()` ထက်မပိုစေရ။
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // ကြားမှာမှအချပ်ကိုဖန်တီးရန်အတွက်အထောက်အကူ function ကို။
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // လုံခြုံမှု-ကြားမှာအညွှန်းပါတဲ့အနိမ့်အမြင့်ကနေဖန်တီးခဲ့တာပါ
                // `self.ptr` နှင့်အရှည် `len!(self)` ။
                // ဤအချက်သည် `from_raw_parts` အတွက်လိုအပ်ချက်အားလုံးပြည့်စုံမည်ဟုအာမခံသည်။
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // `offset` element များမှ iterator ၏ start ကို forward လုပ်ခြင်း၊ start အဟောင်းကိုပြန်ပို့ခြင်းအတွက် helper function ။
            //
            // စိတ်မချရသောကြောင့် offset သည် `self.len()` ထက်မပိုသောကြောင့်။
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူမှ `offset` သည် `self.len()` ထက်မပိုရန်အာမခံသည်။
                    // ဒါကြောင့်ဒီ pointer အသစ်ဟာ `self` အတွင်းမှာရှိနေပြီး null ဖြစ်ဖို့အာမခံချက်မရှိဘူး။
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // ကြားမှာ၏အဆုံးကို `offset` ဒြပ်စင်များကနောက်သို့ရွေ့လျားပြီးအဆုံးအသစ်ကိုပြန်ပေးရန်အတွက်အထောက်အကူဖြစ်သည်။
            //
            // စိတ်မချရသောကြောင့် offset သည် `self.len()` ထက်မပိုသောကြောင့်။
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူမှ `offset` သည် `self.len()` ထက်မပိုရန်အာမခံသည်။
                    // အရာတစ်ခု `isize` လျှံမအာမခံသည်။
                    // ဒါ့အပြင်ရရှိလာတဲ့ pointer `slice` ၏အခြားလိုအပ်ချက်များကိုဖြည့်သော `slice` ၏ဘောငျ၌တည်ရှိ၏။
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // အချပ်များနှင့်အတူအကောင်အထည်ဖော်နိုင်ပေမယ့်ဒီကန့်သတ်ချက်စစ်ဆေးမှုများကိုရှောင်ရှား

                // လုံခြုံမှု-`assume` ခေါ်ဆိုမှုများသည်အစပိုင်းတွင်စတင်သည်
                // Non-null ဖြစ်ရမည်။ ZST မဟုတ်သော over slices များသည် non-null end pointer ရှိရမည်။
                // ကြားမှာပထမဆုံးအလွတ်ဖြစ်နေသလားဆိုတာကိုစစ်ဆေးပြီးကတည်းက `next_unchecked!` သို့ခေါ်ဆိုမှုသည်လုံခြုံသည်။
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // ဒီကြားမှာအခုအလွတ်ဖြစ်နေပြီ။
                    if mem::size_of::<T>() == 0 {
                        // ဒါကိုလုပ်ဖို့လိုတယ်။ `ptr` ကဘယ်တော့မှ 0 ဖြစ်မှာမဟုတ်ပေမယ့် `end` (trapping ကြောင့်) ဖြစ်နိုင်တယ်။
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // လုံခြုံမှု: ptr 0 သည်မပြီး၊ end>=ptr ဖြစ်သောကြောင့် T သည် ZST မဟုတ်လျှင်အဆုံးသည် 0 မဖြစ်နိုင်ပါ
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // လုံခြုံမှု-ကျွန်ုပ်တို့မှာအကန့်အသတ်ရှိသည်။`post_inc_start` က ZSTs အတွက်တောင်မှမှန်တယ်။
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // ဤရိုးရှင်းသောအကောင်အထည်ဖော်မှုသည် LLVM IR ကိုလျော့နည်းစေပြီး compile လုပ်ရန်ပိုမြန်သောကြောင့် `try_fold` ကိုအသုံးပြုသော default implementation ကိုကျွန်ုပ်တို့ပယ်ဖျက်သည်။
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // ဤရိုးရှင်းသောအကောင်အထည်ဖော်မှုသည် LLVM IR ကိုလျော့နည်းစေပြီး compile လုပ်ရန်ပိုမြန်သောကြောင့် `try_fold` ကိုအသုံးပြုသော default implementation ကိုကျွန်ုပ်တို့ပယ်ဖျက်သည်။
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // ဤရိုးရှင်းသောအကောင်အထည်ဖော်မှုသည် LLVM IR ကိုလျော့နည်းစေပြီး compile လုပ်ရန်ပိုမြန်သောကြောင့် `try_fold` ကိုအသုံးပြုသော default implementation ကိုကျွန်ုပ်တို့ပယ်ဖျက်သည်။
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // ဤရိုးရှင်းသောအကောင်အထည်ဖော်မှုသည် LLVM IR ကိုလျော့နည်းစေပြီး compile လုပ်ရန်ပိုမြန်သောကြောင့် `try_fold` ကိုအသုံးပြုသော default implementation ကိုကျွန်ုပ်တို့ပယ်ဖျက်သည်။
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // ဤရိုးရှင်းသောအကောင်အထည်ဖော်မှုသည် LLVM IR ကိုလျော့နည်းစေပြီး compile လုပ်ရန်ပိုမြန်သောကြောင့် `try_fold` ကိုအသုံးပြုသော default implementation ကိုကျွန်ုပ်တို့ပယ်ဖျက်သည်။
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // ဤရိုးရှင်းသောအကောင်အထည်ဖော်မှုသည် LLVM IR ကိုလျော့နည်းစေပြီး compile လုပ်ရန်ပိုမြန်သောကြောင့် `try_fold` ကိုအသုံးပြုသော default implementation ကိုကျွန်ုပ်တို့ပယ်ဖျက်သည်။
            // ဒါ့အပြင် `assume` ကအကန့်အသတ်မရှိစစ်ဆေးမှုကိုရှောင်ပါတယ်။
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // လုံခြုံမှု-ကျွန်တော်တို့ဟာ loop ကိုလျော့ပါးသွားမည်ဖြစ်သလိုအားဖြင့်နယ်နိမိတ်၌ဖြစ်အာမခံချက်:
                        // `i >= n` ရောက်သောအခါ `self.next()` `None` ကိုပြန်လာပြီး loop break များလုပ်သည်။
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // ဤရိုးရှင်းသောအကောင်အထည်ဖော်မှုသည် LLVM IR ကိုလျော့နည်းစေပြီး compile လုပ်ရန်ပိုမြန်သောကြောင့် `try_fold` ကိုအသုံးပြုသော default implementation ကိုကျွန်ုပ်တို့ပယ်ဖျက်သည်။
            // ဒါ့အပြင် `assume` ကအကန့်အသတ်မရှိစစ်ဆေးမှုကိုရှောင်ပါတယ်။
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // လုံခြုံမှု: `i` သည် `n` မှစတင်ကတည်းက `n` ထက်နိမ့်ရမည်
                        // နှင့်သာလျော့ကျလာခြင်းဖြစ်သည်။
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // လုံခြုံမှု: `i` ၏မှတ်သားသောခေါ်ဆိုသူ၏မဖြစ်မနေအာမခံချက်
                // နောက်ခံအစွန်အဖျားဖြစ်သော `i` သည် `isize` ကိုမလျှံနိုင်ဘဲပြန်ပို့ထားသောရည်ညွှန်းချက်များသည်အချပ်၏ဒြပ်စင်တစ်ခုကိုရည်ညွှန်းရန်အာမခံထားသည်။
                //
                // ထို့အပြင် caller သည်ထပ်တူညွှန်းကိန်းနှင့်ထပ်မံခေါ်ဝေါ်ခြင်းကိုအာမခံခြင်းမရှိဘဲ၊ ဤ subslice ကိုသုံးနိုင်သောအခြားနည်းလမ်းများကိုလည်းခေါ်ယူခြင်းမရှိကြောင်းကိုလည်းသတိပြုပါ။ ထို့ကြောင့်ပြန်လာသောရည်ညွှန်းချက်သည် mutable ဖြစ်ရန်မှန်ကန်သည်။
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // အချပ်များနှင့်အတူအကောင်အထည်ဖော်နိုင်ပေမယ့်ဒီကန့်သတ်ချက်စစ်ဆေးမှုများကိုရှောင်ရှား

                // လုံခြုံမှု-အချပ်၏ start pointer သည် null မဟုတ်သောကြောင့် `assume` ခေါ်ဆိုမှုများသည်လုံခြုံမှုရှိသည်။
                // နှင့် Non-ZSTs ကျော်အချပ်ကိုလည်း non-တရားမဝင်သောအဆုံး pointer ရှိရမည်။
                // ကြားမှာပထမဆုံးအလွတ်ဖြစ်နေသလားဆိုတာကိုစစ်ဆေးပြီးကတည်းက `next_back_unchecked!` သို့ခေါ်ဆိုမှုသည်လုံခြုံသည်။
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // ဒီကြားမှာအခုအလွတ်ဖြစ်နေပြီ။
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // လုံခြုံမှု-ကျွန်ုပ်တို့မှာအကန့်အသတ်ရှိသည်။`pre_dec_end` က ZSTs အတွက်တောင်မှမှန်တယ်။
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}