//! `&[T]` နှင့် `&mut [T]` ဖန်တီးရန်အခမဲ့လုပ်ဆောင်ချက်များကို။

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// pointer နှင့် length တစ်ခုအကန့်တစ်ခုဖြစ်သည်။
///
/// `len` argument သည် **element များ၏နံပါတ်** မဟုတ်ဘဲ bytes အရေအတွက်ဖြစ်သည်။
///
/// # Safety
///
/// အောက်ပါအခြေအနေများမဆိုချိုးဖောက်လျှင်အပြုအမူ undefined သည်:
///
/// * `data` `len * mem::size_of::<T>()` အတွက်များစွာသော bytes အတွက်ဖတ်ရန်အတွက် [valid] ဖြစ်ရမည်၊ ၎င်းကိုစနစ်တကျချိန်ညှိရမည်။အထူးသဖြင့်ဆိုလိုသည်မှာ
///
///     * ဒီအချပ်၏မှတ်ဉာဏ်အကွာအဝေးတစ်ခုလုံးကိုခွဲဝေထားသည့်အရာဝတ္ထုတစ်ခုအတွင်းပါရမည်။
///       ချပ်သည်မျိုးစုံခွဲဝေထားသောအရာဝတ္ထုများကိုဘယ်တော့မှ ဖြတ်၍ မရနိုင်ပါဤအချက်ကိုထည့်သွင်းစဉ်းစားခြင်းမမှန်ကန်သည့်ဥပမာအတွက် [below](#incorrect-usage) ကိုကြည့်ပါ။
///     * `data` Non-null ဖြစ်ရမယ်။ သုညအရှည်ချပ်တွေအတွက်တောင်မြှောက်ထားရမယ်။
///     ထိုသို့ဖြစ်ရခြင်းမှာအကြောင်းရင်းတစ်ခုမှာ enum layout optimization သည် alignment (မည်သည့်အရှည်ရှိသည့်အချပ်များအပါအ ၀ င်) များအားဆက်စပ်နေပြီးအခြား data များနှင့်ခွဲခြားရန် null မဟုတ်သောကိုးကားချက်များအပေါ်မှီခိုနိုင်သည်။
///     [`NonNull::dangling()`] ကို အသုံးပြု၍ သုညအချပ်များအတွက် `data` အဖြစ်သုံးနိုင်သော pointer ကိုသင်ရနိုင်သည်။
///
/// * `data` `len` အမျိုးအစား `T` ၏ဆက်တိုက်စနစ်တကျအစပြုတန်ဖိုးများကိုညွှန်ပြရမည်။
///
/// * အဆိုပါပြန်လာသောအချပ်များကရည်ညွှန်းအဆိုပါမှတ်ဉာဏ်တစ်ခု `UnsafeCell` အတွင်းပိုင်း မှလွဲ. တစ်သက်တာ `'a` များ၏ကြာချိန်များအတွက် mutated မရရမည်ဖြစ်သည်။
///
/// * အချပ်၏စုစုပေါင်းအရွယ်အစား `len * mem::size_of::<T>()` သည် `isize::MAX` ထက်မပိုစေရ။
///   [`pointer::offset`] ၏လုံခြုံရေးစာရွက်စာတမ်းများကိုကြည့်ပါ။
///
/// # Caveat
///
/// ပြန်လာသောအချပ်များအတွက်သက်တမ်း၎င်း၏အသုံးပြုမှုကနေပေါ်မူတည်ပြီးဖြစ်ပါတယ်။
/// မတော်တဆအလွဲသုံးစားမှုကိုကာကွယ်ရန်၊ သက်တမ်းသည်အခြေအနေတွင်လုံခြုံမှုရှိမရှိနှင့်သက်တမ်းကိုဆက်စပ်ရန်အကြံပြုသည်။ ဥပမာအားဖြင့် slice အတွက် host တန်ဖိုးတစ်ခု၏သက်တမ်းကိုယူခြင်းသို့မဟုတ်ရှင်းလင်းပြတ်သားစွာမှတ်သားခြင်းအားဖြင့်ဖြစ်သည်။
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // တစ်ခုတည်းဒြပ်စင်အဘို့အမန်နီးဖက်စ်အချပ်
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### မှားယွင်းစွာအသုံးပြုမှု
///
/// အောက်ပါ `join_slices` function သည် **unsound** ဖြစ်သည်
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // အပေါ်ကအခိုင်အမာပြောဆိုချက်အရ `fst` နှင့် `snd` များသည်တဆက်တည်းဖြစ်သော်လည်း၎င်းတို့သည် _different allocated objects_ အတွင်းတွင်သာရှိကောင်းရှိလိမ့်မည်။
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` နှင့် `b` ကွဲပြားခြားနားသောခွဲဝေအရာဝတ္ထုဖြစ်ကြသည် ...
///     let a = 42;
///     let b = 27;
///     // ... သို့ရာတွင်မှတ်ဉာဏ်ထဲမှာတဆက်တည်းထွက်ချထားစေခြင်းငှါအရာ: |ကခ |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `from_raw_parts` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// [`from_raw_parts`] ကဲ့သို့တူညီသောလုပ်ဆောင်ချက်ကိုလုပ်ဆောင်တစ် mutable အချပ်ပြန်ရောက်ကြောင်းမျှသာ။
///
/// # Safety
///
/// အောက်ပါအခြေအနေများမဆိုချိုးဖောက်လျှင်အပြုအမူ undefined သည်:
///
/// * `data` ဖတ်ရန်နှင့် `len * mem::size_of::<T>()` အတွက်များစွာသော bytes အတွက်နှစ်မျိုးလုံးအတွက် [valid] ဖြစ်ရမည်။ ၎င်းကိုစနစ်တကျချိန်ညှိရမည်။အထူးသဖြင့်ဆိုလိုသည်မှာ
///
///     * ဒီအချပ်၏မှတ်ဉာဏ်အကွာအဝေးတစ်ခုလုံးကိုခွဲဝေထားသည့်အရာဝတ္ထုတစ်ခုအတွင်းပါရမည်။
///       ချပ်သည်မျိုးစုံခွဲဝေထားသောအရာဝတ္ထုများကိုဘယ်တော့မှ ဖြတ်၍ မရနိုင်ပါ။
///     * `data` Non-null ဖြစ်ရမယ်။ သုညအရှည်ချပ်တွေအတွက်တောင်မြှောက်ထားရမယ်။
///     ထိုသို့ဖြစ်ရခြင်းမှာအကြောင်းရင်းတစ်ခုမှာ enum layout optimization သည် alignment (မည်သည့်အရှည်ရှိသည့်အချပ်များအပါအ ၀ င်) များအားဆက်စပ်နေပြီးအခြား data များနှင့်ခွဲခြားရန် null မဟုတ်သောကိုးကားချက်များအပေါ်မှီခိုနိုင်သည်။
///
///     [`NonNull::dangling()`] ကို အသုံးပြု၍ သုညအချပ်များအတွက် `data` အဖြစ်သုံးနိုင်သော pointer ကိုသင်ရနိုင်သည်။
///
/// * `data` `len` အမျိုးအစား `T` ၏ဆက်တိုက်စနစ်တကျအစပြုတန်ဖိုးများကိုညွှန်ပြရမည်။
///
/// * ပြန်လာသောအချပ်အားဖြင့်ရည်ညွှန်းသောမှတ်ဉာဏ်ကိုတစ်သက်တာ `'a` ၏ကြာချိန်အတွက်မည်သည့်အခြား pointer (ပြန်လာတန်ဖိုးမှဆင်းသက်လာမဟုတ်) မှတဆင့်ဝင်ရောက်ခွင့်မပြုရပါ။
///   နှစ်ဦးစလုံးဖတ်ပြီးသားများနှင့်ရေး Access တားမြစ်ထားကြသည်။
///
/// * အချပ်၏စုစုပေါင်းအရွယ်အစား `len * mem::size_of::<T>()` သည် `isize::MAX` ထက်မပိုစေရ။
///   [`pointer::offset`] ၏လုံခြုံရေးစာရွက်စာတမ်းများကိုကြည့်ပါ။
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `from_raw_parts_mut` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// T ကိုရည်ညွှန်းချက်တစ်ခု (ကူးယူခြင်းမရှိဘဲ) အရှည် 1 အပိုင်းအစသို့ပြောင်းလဲခြင်း။
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// T ကိုရည်ညွှန်းချက်တစ်ခု (ကူးယူခြင်းမရှိဘဲ) အရှည် 1 အပိုင်းအစသို့ပြောင်းလဲခြင်း။
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}