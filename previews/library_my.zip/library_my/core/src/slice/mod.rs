// ignore-tidy-filelength

//! အချပ်စီမံခန့်ခွဲမှုနှင့်ခြယ်လှယ်။
//!
//! အသေးစိတ်အတွက် [`std::slice`] ကိုကြည့်ပါ။
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// rust-memchr မှယူထားသောသန့်ရှင်းသော rust memchr အကောင်အထည်ဖော်မှု
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// စမ်းသပ်မှု heapsort ယူနစ်မှအခြားလမ်းမရှိသောကြောင့်ဤ function ကိုအများပြည်သူဖြစ်ပါတယ်။
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// အဆိုပါအချပ်ထဲမှာဒြပ်စင်၏နံပါတ်ပြန်ပို့ပေးသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // SAFETY: const sound သည် length field ကို usize အဖြစ်ထုတ်လွှင့်သောကြောင့်ဖြစ်သည်။
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // လုံခြုံမှု: `&[T]` နှင့် `FatPtr<T>` အတူတူ layout ကိုရှိသည်ကြောင့်ဒီလုံခြုံဖြစ်ပါတယ်။
            // ဒီအာမခံချက်ကို `std` ကသာလုပ်နိုင်ပါတယ်။
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: ကြောင်း const-တည်ငြိမ်ဖြစ်တဲ့အခါ `crate::ptr::metadata(self)` နှင့်အတူအစားထိုးပါ။
            // ဤရေးသားမှုအရ "Const-stable functions can only call other const-stable functions" အမှားဖြစ်ပေါ်စေသည်။
            //

            // လုံခြုံမှု-`PtrRepr` Union မှတန်ဖိုးကိုရယူသုံးစွဲခြင်း * const T သည်ကတည်းကလုံခြုံသည်
            // နှင့် PtrComponents<T>အတူတူမှတ်ဉာဏ်အပြင်အဆင်ရှိသည်။
            // std သာလျှင်ဤအာမခံချက်ကိုပေးနိုင်သည်။
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// အချပ် 0 အရှည်ရှိပါတယ်လျှင် `true` ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// ၎င်းသည်အချပ်၏ပထမဆုံး element သို့မဟုတ် `None` ကို return ပြန်ပေးသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// တစ် ဦး mutable pointer က slice ၏ပထမ ဦး ဆုံးဒြပ်စင်, ဒါမှမဟုတ် `None` သို့ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// ကျန်အပိုင်း၏ပထမ ဦး ဆုံးနှင့်ကျန်အရာအားလုံးကိုပြန်သွားသည် (သို့) `None` ကဗလာမရှိပါက။
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// ကျန်အပိုင်း၏ပထမ ဦး ဆုံးနှင့်ကျန်အရာအားလုံးကိုပြန်သွားသည် (သို့) `None` ကဗလာမရှိပါက။
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// ဒါကြောင့်အချည်းနှီးလျှင်ပြီးခဲ့သည့်နှင့်အချပ်၏ဒြပ်စင်အပေါငျးတို့သကြွင်းသောအရာ Returns, ဒါမှမဟုတ် `None` ။
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// ဒါကြောင့်အချည်းနှီးလျှင်ပြီးခဲ့သည့်နှင့်အချပ်၏ဒြပ်စင်အပေါငျးတို့သကြွင်းသောအရာ Returns, ဒါမှမဟုတ် `None` ။
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// ဒါကြောင့်အချည်းနှီးပင်ဖြစ်သည်လျှင်အချပ်၏နောက်ဆုံးဒြပ်စင် Returns, ဒါမှမဟုတ် `None` ။
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// တစ် ဦး mutable pointer ကိုအချပ်အတွက်နောက်ဆုံး item ကိုပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// အညွှန်းကိန်းအမျိုးအစားပေါ် မူတည်. Element တစ်ခုရဲ့သို့မဟုတ် subslice တစ်ဦးကိုကိုးကား Returns ။
    ///
    /// - တစ်ဦးအနေအထားပေးထားခဲ့လျှင်ဘောငျထဲကနေလျှင်, ထိုအနေအထားသို့မဟုတ် `None` မှာဒြပ်စင်တစ်ခုရည်ညွှန်းပြန်လည်ရောက်ရှိ။
    ///
    /// - အကယ်၍ အကွာအဝေးတစ်ခုပေးထားပါက၎င်းအကွာအဝေးနှင့်ကိုက်ညီပါကထပ်ဆင့်ထပ်ဆင့်သို့မဟုတ် `None` ကိုပြန်လည်သတ်မှတ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// အကယ်၍ ညွှန်းကိန်းကန့်သတ်ချက်မရှိလျှင်အညွှန်း ([`get`] ကိုကြည့်ပါ) သို့မဟုတ် `None` ပေါ် မူတည်၍ element တစ်ခုသို့မဟုတ် subslice တစ်ခုသို့ပြောင်းလဲနိုင်သောရည်ညွှန်းချက်ကိုပြန်ပို့သည်။
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// ကန့်သတ်ချက်များစစ်ဆေးခြင်းမပြုဘဲ, element တစ်ခုသို့မဟုတ် subslice တစ်ခုရည်ညွှန်းပြန်သွားသည်။
    ///
    /// လုံခြုံသောရွေးချယ်စရာတစ်ခုအတွက် [`get`] ကိုကြည့်ပါ။
    ///
    /// # Safety
    ///
    /// Out-of-bounds index ဖြင့်ဤနည်းလမ်းကိုခေါ်ခြင်းသည် *[undefined behavior]* ဖြစ်သည်။ ရရှိလာသောရည်ညွှန်းချက်ကိုမသုံးလျှင်ပင်ဖြစ်သည်။
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `get_unchecked` အတွက်လုံခြုံရေးလိုအပ်ချက်အများစုကိုကိုင်တွယ်ရမည်။
        // `self` သည်လုံခြုံသောရည်ညွှန်းသောကြောင့်အချပ်သည် dereferencable ဖြစ်သည်။
        // `SliceIndex` ၏ impls ကြောင့်ကြောင်းအာမခံရန်ရှိသည်ကြောင့်ပြန်လာသော pointer ကိုဘေးကင်းလုံခြုံသည်။
        unsafe { &*index.get_unchecked(self) }
    }

    /// အကန့်အသတ်မရှိစစ်ဆေးခြင်းမပြုဘဲ element တစ်ခုသို့မဟုတ် subslice တစ်ခုသို့ပြောင်းလဲနိုင်သောရည်ညွှန်းချက်ကိုပြန်ပို့သည်။
    ///
    /// လုံခြုံသောရွေးချယ်စရာတစ်ခုအတွက် [`get_mut`] ကိုကြည့်ပါ။
    ///
    /// # Safety
    ///
    /// Out-of-bounds index ဖြင့်ဤနည်းလမ်းကိုခေါ်ခြင်းသည် *[undefined behavior]* ဖြစ်သည်။ ရရှိလာသောရည်ညွှန်းချက်ကိုမသုံးလျှင်ပင်ဖြစ်သည်။
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `get_unchecked_mut` အတွက်လုံခြုံမှုလိုအပ်ချက်များကိုထိန်းသိမ်းထားရမည်။
        // `self` သည်လုံခြုံသောရည်ညွှန်းသောကြောင့်အချပ်သည် dereferencable ဖြစ်သည်။
        // `SliceIndex` ၏ impls ကြောင့်ကြောင်းအာမခံရန်ရှိသည်ကြောင့်ပြန်လာသော pointer ကိုဘေးကင်းလုံခြုံသည်။
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// pointer တစ်မျိုးသည် slice ၏ကြားခံသို့ပြန်သွားသည်။
    ///
    /// ခေါ်ဆိုသူသည်ဤလုပ်ဆောင်မှုပြန်လာသည့် pointer ကိုအဆက်ဖြတ်ရန်သေချာစေရမည်။ သို့မဟုတ်ပါကအမှိုက်သရိုက်ကိုအဆုံးသတ်လိမ့်မည်။
    ///
    /// ခေါ်ဆိုသူသည် (non-transitively) ညွှန်ပြသည့်မှတ်ဉာဏ်သည်ဤညွှန်ပြသူသို့မဟုတ်၎င်းမှဆင်းသက်လာသည့်မည်သည့်ညွှန်ကိန်းကိုမဆို (`UnsafeCell` အတွင်းမှအပ) မှမည်သည့်အခါမျှရေးသားခြင်းမပြုရန်သေချာစေရမည်။
    /// သင်သည်အချပ်၏ contents mutate ဖို့လိုအပ်ခဲ့လျှင်, [`as_mut_ptr`] ကိုသုံးပါ။
    ///
    /// ဤအချပ်ကရည်ညွှန်းထားသောကွန်တိန်နာကိုပြုပြင်ခြင်းသည်၎င်း၏ကြားခံကိုပြန်လည်နေရာချထားခြင်းကိုဖြစ်စေနိုင်ပြီး၎င်းသည်မည်သည့်ညွှန်ပြချက်များကိုမဆိုဖြစ်စေသက်ရောက်စေသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// မလုံခြုံသော mutable pointer ကို slice's buffer သို့ပြန်သွားသည်။
    ///
    /// ခေါ်ဆိုသူသည်ဤလုပ်ဆောင်မှုပြန်လာသည့် pointer ကိုအဆက်ဖြတ်ရန်သေချာစေရမည်။ သို့မဟုတ်ပါကအမှိုက်သရိုက်ကိုအဆုံးသတ်လိမ့်မည်။
    ///
    /// ဤအချပ်ကရည်ညွှန်းထားသောကွန်တိန်နာကိုပြုပြင်ခြင်းသည်၎င်း၏ကြားခံကိုပြန်လည်နေရာချထားခြင်းကိုဖြစ်စေနိုင်ပြီး၎င်းသည်မည်သည့်ညွှန်ပြချက်များကိုမဆိုဖြစ်စေသက်ရောက်စေသည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// အချပ် spanning နှစ်ခုကုန်ကြမ်းထောက်ပြ Returns ။
    ///
    /// ပြန်လာသောအကွာအဝေးမှာဝက်ပွင့်နေပြီးဆိုလိုသည်မှာအဆုံးညွှန်းက * အတိတ်တစ်ခု၏နောက်ဆုံးအပိုင်းကိုဆိုလိုသည်။
    /// ဤနည်းတစ်ခုအချည်းနှီးသောအချပ်နှစ်ခုညီမျှထောက်ပြခြင်းဖြင့်ကိုယ်စားပြုလျက်, နှစ်ခုထောက်ပြကြားရှိခြားနားချက်အချပ်၏အရွယ်အစားကိုကိုယ်စားပြုသည်။
    ///
    /// ဤအညွှန်းများအသုံးပြုခြင်းအတွက်သတိပေးချက်များအတွက် [`as_ptr`] ကိုကြည့်ပါ။end pointer သည်အစရှိသည့်မှန်ကန်သောဒြပ်စင်ကိုညွှန်ပြခြင်းမရှိသောကြောင့်အထူးသတိပြုရန်လိုအပ်သည်။
    ///
    /// ဒီ function သည် C++ တွင်တွေ့ရလေ့ရှိသည့်အတိုင်းမှတ်ဉာဏ်ထဲရှိဒြပ်စင်အမျိုးမျိုးကိုရည်ညွှန်းရန်အမှတ်အသားနှစ်ခုကိုအသုံးပြုသောနိုင်ငံခြား interfaces နှင့်အပြန်အလှန်ဆက်သွယ်မှုအတွက်အသုံးဝင်သည်။
    ///
    ///
    /// element တစ်ခုမှ pointer တစ်ခုသည်ဤအချပ်၏ element တစ်ခုကိုရည်ညွှန်းခြင်းရှိမရှိစစ်ဆေးရန်လည်းအသုံးဝင်သည်။
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // လုံခြုံမှု-ဒီမှာ `add` ကလုံခြုံတယ်၊
        //
        //   - pointers နှစ်ခုလုံးသည် object တစ်ခု၏တစိတ်တပိုင်းဖြစ်သည်။ အရာဝတ္ထု၏အတိတ်ကိုလည်းမှတ်သားထားသည့်အတိုင်းဖြစ်သည်။
        //
        //   - ဤနေရာတွင်ဖော်ပြခဲ့သည့်အတိုင်းအချပ်၏အရွယ်အစားသည်ဘယ်တော့မျှ isize::MAX bytes ထက်ကြီးသည်မဟုတ်။
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - ပါဝင်ပတ်သက်နေသည့်ပတ် ၀ န်းကျင်တွင်ပတ် ၀ န်းကျင်ပတ် ၀ န်းကျင်မရှိပါ။
        //
        // pointer::add ၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// အချပ်ကို spanning နှစ်ခုမလုံခြုံ mutable ထောက်ပြသည်ပြန်သွားသည်။
    ///
    /// ပြန်လာသောအကွာအဝေးမှာဝက်ပွင့်နေပြီးဆိုလိုသည်မှာအဆုံးညွှန်းက * အတိတ်တစ်ခု၏နောက်ဆုံးအပိုင်းကိုဆိုလိုသည်။
    /// ဤနည်းတစ်ခုအချည်းနှီးသောအချပ်နှစ်ခုညီမျှထောက်ပြခြင်းဖြင့်ကိုယ်စားပြုလျက်, နှစ်ခုထောက်ပြကြားရှိခြားနားချက်အချပ်၏အရွယ်အစားကိုကိုယ်စားပြုသည်။
    ///
    /// ဤအညွှန်းများအသုံးပြုခြင်းအတွက်သတိပေးချက်များအတွက် [`as_mut_ptr`] ကိုကြည့်ပါ။
    /// end pointer သည်အစရှိသည့်မှန်ကန်သောဒြပ်စင်ကိုညွှန်ပြခြင်းမရှိသောကြောင့်အပိုသတိထားရန်လိုအပ်သည်။
    ///
    /// ဒီ function သည် C++ တွင်တွေ့ရလေ့ရှိသည့်အတိုင်းမှတ်ဉာဏ်ထဲရှိဒြပ်စင်အမျိုးမျိုးကိုရည်ညွှန်းရန်အမှတ်အသားနှစ်ခုကိုအသုံးပြုသောနိုင်ငံခြား interfaces နှင့်အပြန်အလှန်ဆက်သွယ်မှုအတွက်အသုံးဝင်သည်။
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // လုံခြုံမှု-ဤနေရာတွင် `add` သည်အဘယ်ကြောင့်အန္တရာယ်ရှိသည်ကိုအထက်ပါ as_ptr_range() တွင်ကြည့်ပါ။
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// အချပ်အတွက်နှစ်ခုဒြပ်စင်ဖလှယ်။
    ///
    /// # Arguments
    ///
    /// * a, ပထမ element ရဲ့အညွှန်းကိန်း
    /// * ခ, ဒုတိယဒြပ်စင်၏အညွှန်းကိန်း
    ///
    /// # Panics
    ///
    /// `a` သို့မဟုတ် `b` သည်သတ်မှတ်ချက်များမရှိလျှင် Panics ။
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // vector တစ်ခုမှ mutable ချေးငွေနှစ်ခုကိုမယူနိုင်ပါ။
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // လုံခြုံမှု-`pa` နှင့် `pb` ကိုလုံခြုံစိတ်ချရသော mutable ကိုးကားချက်များမှဖန်တီးထားပြီးရည်ညွှန်းသည်
        // အချပ်အတွက်ဒြပ်စင်မှထို့ကြောင့်တရားဝင်နှင့် alignment ကိုဖြစ်အာမခံနေကြသည်။
        // `a` နှင့် `b` နောက်ကွယ်မှဒြပ်စင်ကိုရယူသုံး check လုပ်ထားသည်နှင့်ပါလိမ့်မယ် panic သည့်အခါထွက်ဘောငျ၏မှတ်ချက်။
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// နေရာတွင်ရှိအချပ်အတွက်ဒြပ်စင်၏အမိန့်ကိုပြောင်းပြန်။
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // အလွန်သေးငယ်သောအမျိုးအစားများအတွက်သာမန်လမ်းကြောင်းရှိဖတ်ရှုသူတစ် ဦး ချင်းစီသည်ညံ့ဖျင်းစွာလုပ်ဆောင်ကြသည်။
        // ပိုကောင်းအောင်လုပ်နိုင်တယ်၊ ထိရောက်မှုမရှိတဲ့ load/store ကိုသုံးပြီးပိုကြီးတဲ့အပိုင်းအစတစ်ခုကိုတင်ပြီးမှတ်ပုံတင်ကိုပြောင်းပြန်လုပ်ခြင်းအားဖြင့်ပေါ့။
        //

        // အကောင်းဆုံးအားဖြင့် LLVM သည်၎င်းအတွက်ကျွန်ုပ်တို့အတွက်လုပ်ပေးလိမ့်မည်။ ၎င်းသည် unaligned reads သည် (ဥပမာကွဲပြားသော ARM ဗားရှင်းများအကြားပြောင်းလဲမှုရှိခြင်း) နှင့်အကောင်းဆုံးအပိုင်းအစများမည်မျှရှိသည်ကိုကျွန်ုပ်တို့ထက်ပိုမိုသိသည်။
        // ကံမကောင်းစွာပဲ, LLVM 4.0 (2017-05) ၏အဖြစ်ကသာကွင်းဆက် unrolls, ဒါကြောင့်ကျနော်တို့ကသူတို့ကိုယ်သူတို့လုပ်ဖို့လိုအပ်ပါတယ်။
        // (Hypothesis: ပြောင်းပြန်နှစ်ဖက်စလုံးကွဲပြားခြားနား aligned နိုင်ပါတယ်ဘာလို့လဲဆိုတော့ဒုက္ခဖြစ်ပါသည်-အလျားထူးဆန်းအခါဖြစ်လိမ့်မည်-ဒါကြောင့်အလယ်၌အပြည့်အဝ-aligned SIMD သုံးစွဲဖို့အကျူးများနှင့် postludes emitting ၏လမ်းမရှိသောရဲ့။)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // U8s ကိုပြောင်းသုံးရန် llvm.bswap အခ်ါကိုသုံးပါ
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // လုံခြုံမှု-ဤနေရာတွင်စစ်ဆေးရန်အရာများစွာရှိသည်။
                //
                // - အထက်တွင်ဖော်ပြထားသော cfg စစ်ဆေးမှုကြောင့် `chunk` သည် 4 သို့မဟုတ် 8 ဖြစ်မည်ကိုသတိပြုပါ။ဒါကြောင့် `chunk - 1` အပြုသဘောဖြစ်ပါတယ်။
                // - Index `i` ဖြင့် Indexing လုပ်ခြင်းသည်ကွင်းဆက်စစ်ဆေးမှုမှအာမခံသည်
                //   `i + chunk - 1 < ln / 2`
                //   `i < ln / 2 - (chunk - 1) < ln / 2 < ln` <=> ။
                // - အညွှန်းကိန်း `ln - i - chunk = ln - (i + chunk)` ဖြင့်အညွှန်းကိန်းကောင်းသည်။
                //   - `i + chunk > 0` အသေးအဖွဲမှန်သည်။
                //   - ကွင်းဆက်စစ်ဆေးမှုကအာမခံသည်-
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`၊ ထို့ကြောင့်နှုတ်ခြင်းသည်မပြည့်စုံပါ။
                // - `read_unaligned` နှင့် `write_unaligned` ခေါ်ဆိုမှုများသည်အဆင်ပြေပါသည်။
                //   - `pa` `i < ln / 2 - (chunk - 1)` (အထက်တွင်ကြည့်ပါ) နှင့် `pb` အညွှန်းကိန်း `ln - i - chunk` ကိုညွှန်ပြသော `i` ကိုရည်ညွှန်းသည်။ ထို့ကြောင့် X0 `self`၏အဆုံးနှင့်ဝေးသောအကွာအဝေးများစွာသည်အနည်းဆုံး `chunk` ဖြစ်သည်။
                //
                //   - မဆိုစတင်မှတ်ဉာဏ်တရားဝင် `usize` ဖြစ်ပါတယ်။
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // u32 တွင် u16 များကိုပြောင်းရန် rotate-by-16 ကိုသုံးပါ
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // လုံခြုံမှု-`i + 1 < ln` လျှင်မပေါင်းစည်းထားသည့် u32 ကို `i` မှဖတ်နိုင်သည်
                // ဘာလို့လဲဆိုတော့ element တစ်ခုစီက 2 bytes ဖြစ်ပြီး 4 ကိုဖတ်နေလို့ပဲ။
                //
                // `i + chunk - 1 < ln / 2` # နေစဉ်အခြေအနေ
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // 2 သည်ပိုင်းခြားထားသောအရှည်ထက်နည်းသောကြောင့်၎င်းသည် bounds များဖြစ်ရမည်။
                //
                // ဆိုလိုသည်မှာ `pb` အခြေအနေသည်အမြဲတမ်းလေးစားခြင်းဖြစ်ပြီး `pb` pointer ကိုဘေးကင်းစွာအသုံးပြုနိုင်သည်။
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // လုံခြုံမှု-`i` သည်အချပ်၏ထက်ဝက်ခန့်ထက်နိမ့်သည်
            // `i` နှင့် `ln - i - 1` ကိုအသုံးပြုခြင်းသည်အန္တရာယ်ကင်းသည် (`i` 0 မှစတင်ပြီး `ln / 2 - 1` ထက်မပိုပါ) ။
            // ထို့ကြောင့်ရရှိလာသောညွှန်ပြချက်များ `pa` နှင့် `pb` သည်ခိုင်လုံသောနှင့်ကိုက်ညီမှုရှိသည်၊ ဖတ်ပြီးရေးသားနိုင်သည်။
            //
            //
            unsafe {
                // သတ်မှတ်ချက်များကိုရှောင်ရှားရန်လုံခြုံမှုမရှိသောလဲလှယ်ရေးအစီအစဉ်ကိုလုံခြုံသောလဲလှယ်ရေးအစီအစဉ်တွင်စစ်ဆေးပါ။
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// အချပ်ကျော်ကြားမှာပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// တန်ဖိုးတစ်ခုစီကိုပြောင်းလဲခွင့်ပြုသည့်ကြားဖြတ်တစ်ခုကိုပြန်ပို့သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// အရှည် `size` အပေါငျးတို့သတဆက်တည်း windows ကျော်တစ်ဦးကြားမှာ Returns ။
    /// အဆိုပါ windows ထပ်။
    /// အချပ်သည် `size` ထက်တိုတောင်းပါကကြားဖြတ်သည်တန်ဖိုးများကိုပြန်ပို့သည်မဟုတ်ပါ။
    ///
    /// # Panics
    ///
    /// `size` 0 လျှင် Panics
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// အချပ် `size` ထက်တိုတောင်းလျှင်:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// slice ၏အစအ ဦး မှ စတင်၍ တစ်ချိန်တည်းတွင် slice ၏ `chunk_size` element များမှကြားဖြတ်တစ်ခုကိုပြန်ပို့သည်။
    ///
    /// အတုံးတွေဟာချပ်တွေပါ၊`chunk_size` အဆိုပါအချပ်၏အရှည်ကိုဝေမပါဘူးဆိုရင်, ထို့နောက်နောက်ဆုံးအတုံးအရှည် `chunk_size` ရှိလိမ့်မည်မဟုတ်ပေ။
    ///
    /// [`chunks_exact`] ကိုကြည့်ပြီး XTX element များ၏အတိအကျကိုပြန်လည်ပေးသောဤကြားမှာ၏ပုံစံကိုကြည့်ပါ၊ [`rchunks`] သည်တူညီသောကြားမှာအတွက်ဖြစ်သည်။
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` လျှင် Panics 0 င်ဖြစ်ပါတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// slice ၏အစအ ဦး မှ စတင်၍ တစ်ချိန်တည်းတွင် slice ၏ `chunk_size` element များမှကြားဖြတ်တစ်ခုကိုပြန်ပို့သည်။
    ///
    /// အဆိုပါတုံး mutable ချပ်ဖြစ်ကြသည်ကို၎င်း, မထပ်ဘူး။အကယ်၍ `chunk_size` သည်အချပ်၏အရှည်ကိုမခွဲခြားပါကနောက်ဆုံးအပိုင်းအစသည်အရှည် `chunk_size` ရှိလိမ့်မည်မဟုတ်ပါ။
    ///
    /// [`chunks_exact_mut`] ကိုကြည့်ပြီး XTX element များ၏အတိအကျကိုပြန်လည်ပေးသောဤကြားမှာ၏ပုံစံကိုကြည့်ပါ၊ [`rchunks_mut`] သည်တူညီသောကြားမှာအတွက်ဖြစ်သည်။
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` လျှင် Panics 0 င်ဖြစ်ပါတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// slice ၏အစအ ဦး မှ စတင်၍ တစ်ချိန်တည်းတွင် slice ၏ `chunk_size` element များမှကြားဖြတ်တစ်ခုကိုပြန်ပို့သည်။
    ///
    /// အတုံးတွေဟာချပ်တွေပါ၊
    /// အကယ်၍ `chunk_size` သည်အတိုအရှည်ကိုမခွဲထားပါကနောက်ဆုံး `chunk_size-1` ဒြပ်စင်များကိုချန်လှပ်ထားလိမ့်မည်။ ၎င်းသည်ကြားဖြတ်၏ `remainder` function မှပြန်လည်ရယူနိုင်သည်။
    ///
    ///
    /// အတုံးတစ်ခုစီသည် `chunk_size` element များပါ ၀ င်သောကြောင့် compiler သည် [`chunks`] ၏ဖြစ်ရပ်ထက်ရလဒ်ကုဒ်ကိုပိုကောင်းအောင်လုပ်နိုင်သည်။
    ///
    /// [`chunks`] ကိုဒီကြားမှာ၏မျိုးကွဲတစ်ခုအတွက်ကျန်ကိုကျန်အပိုင်းသေးသေးလေးအဖြစ်ပြန်ပို့ပေးပြီး၊ တူညီတဲ့ကြားမှာအတွက် [`rchunks_exact`] ကိုကြည့်ပါ။
    ///
    /// # Panics
    ///
    /// `chunk_size` လျှင် Panics 0 င်ဖြစ်ပါတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// slice ၏အစအ ဦး မှ စတင်၍ တစ်ချိန်တည်းတွင် slice ၏ `chunk_size` element များမှကြားဖြတ်တစ်ခုကိုပြန်ပို့သည်။
    ///
    /// အဆိုပါအတုံး mutable ချပ်များမှာ, ထပ်ကြပါဘူး။
    /// အကယ်၍ `chunk_size` သည်အတိုအရှည်ကိုမခွဲထားပါကနောက်ဆုံး `chunk_size-1` ဒြပ်စင်များကိုချန်လှပ်ထားလိမ့်မည်။ ၎င်းသည်ကြားဖြတ်၏ `into_remainder` function မှပြန်လည်ရယူနိုင်သည်။
    ///
    ///
    /// အတုံးတစ်ခုစီသည် `chunk_size` element များပါ ၀ င်သောကြောင့် compiler သည် [`chunks_mut`] ၏ဖြစ်ရပ်ထက်ရလဒ်ကုဒ်ကိုပိုကောင်းအောင်လုပ်နိုင်သည်။
    ///
    /// [`chunks_mut`] ကိုဒီကြားမှာ၏မျိုးကွဲတစ်ခုအတွက်ကျန်ကိုကျန်အပိုင်းသေးသေးလေးအဖြစ်ပြန်ပို့ပေးပြီး၊ တူညီတဲ့ကြားမှာအတွက် [`rchunks_exact_mut`] ကိုကြည့်ပါ။
    ///
    /// # Panics
    ///
    /// `chunk_size` လျှင် Panics 0 င်ဖြစ်ပါတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// အချပ်ကို `N`-element arrays ၏အချပ်တစ်ခုအဖြစ်ခွဲထုတ်သည်။
    ///
    ///
    /// # Safety
    ///
    /// ဤသည်ကိုသာအခါခေါ်နိုင်ပါသည်
    /// - အဆိုပါအချပ်အတိအကျ `N`-element ကိုတုံး (ခေါ် `self.len() % N == 0`)) သို့ခွဲထွက်။
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // လုံခြုံမှု-၁ ဒြပ်စင်အပိုင်းအစများသည်ဘယ်သောအခါမျှမကျန်တော့ပါ
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // လုံခြုံမှု-(6) အချပ်သည် ၃ မျိုးဖြစ်သည်
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // ဤရွေ့ကားမလုံခြုံပါလိမ့်မယ်:
    /// // အတုံးကြီးများ: &[[_;5]]= slice.as_chunks_unchecked()//အဆိုပါအချပ်အရှည် 5 စေတုံးတစ်မျိုးစုံမဟုတ်ပါဘူး:&[[_;0]]= slice.as_chunks_unchecked()//သုညအရှည်တုံးခွင့်ပြုဘယ်တော့မှနေကြသည်
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // လုံခြုံမှု-ဤလိုအပ်ချက်ကိုခေါ်ဆိုရန်လိုအပ်သည့်အတိအကျမှာကျွန်ုပ်တို့၏လိုအပ်ချက်ဖြစ်သည်
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // လုံခြုံမှု: ကျနော်တို့သို့ `new_len * N` ဒြပ်စင်တစ်ခုအချပ်ကိုနှင်ထုတ်
        // `new_len` အများအပြား `N` ဒြပ်စင်တုံးတစ်အချပ်။
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// slice ကို `N`-element arrays ၏အစ ဦး အဖြစ်အစပိုင်းတွင်အစပိုင်း မှစ၍ `N` ထက်နည်းသောအရှည်ရှိသည့်ကျန်အပိုင်းကိုခွဲသည်။
    ///
    ///
    /// # Panics
    ///
    /// `N` သည် 0. ဖြစ်လျှင် Panics သည်ဤစစ်ဆေးမှုသည်ဤနည်းလမ်းတည်ငြိမ်မှုမရောက်မီ compile time error သို့ပြောင်းလဲသွားလိမ့်မည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // လုံခြုံမှု-ငါတို့ဟာသုညအတွက်ထိတ်လန့်တုန်လှုပ်နေခဲ့ပြီးဆောက်လုပ်ရေးလုပ်ငန်းမှာသေချာအောင်လုပ်ထားတယ်
        // အဆိုပါပlိညာဉ်စာတမ်း၏အရှည် N. ၏မျိုးစုံကြောင်း
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// slice ကို `N`-element arrays ၏အချပ် the the the အစ the အ at အဆုံး starting starting starting starting into, and and and and length length length length length ကျန်အပိုင်းကို `N` ထက်လျော့နည်း less သောအပိုင်းအစခွဲသည်။
    ///
    ///
    /// # Panics
    ///
    /// `N` သည် 0. ဖြစ်လျှင် Panics သည်ဤစစ်ဆေးမှုသည်ဤနည်းလမ်းတည်ငြိမ်မှုမရောက်မီ compile time error သို့ပြောင်းလဲသွားလိမ့်မည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // လုံခြုံမှု-ငါတို့ဟာသုညအတွက်ထိတ်လန့်တုန်လှုပ်နေခဲ့ပြီးဆောက်လုပ်ရေးလုပ်ငန်းမှာသေချာအောင်လုပ်ထားတယ်
        // အဆိုပါပlိညာဉ်စာတမ်း၏အရှည် N. ၏မျိုးစုံကြောင်း
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// slice ၏အစအ ဦး မှ စတင်၍ တစ်ချိန်တည်းတွင် slice ၏ `N` element များမှကြားဖြတ်တစ်ခုကိုပြန်ပို့သည်။
    ///
    /// အတုံးများသည် array ကိုးကားချက်များဖြစ်ပြီးထပ်တူမကျပါ။
    /// `N` အဆိုပါအချပ်၏အရှည်ကိုဝေမပါဘူးဆိုရင်, ထို့နောက် `N-1` ဒြပ်စင်မှနောက်ဆုံးအတက်ချန်လှပ်မည်ဖြစ်ပြီးအဆိုပါကြားမှာ၏ `remainder` function ကိုထံမှထုတ်ယူနိုင်ပါသည်။
    ///
    ///
    /// ဤနည်းလမ်းသည် [`chunks_exact`] ၏ const generic ညီမျှခြင်းဖြစ်သည်။
    ///
    /// # Panics
    ///
    /// `N` သည် 0. ဖြစ်လျှင် Panics သည်ဤစစ်ဆေးမှုသည်ဤနည်းလမ်းတည်ငြိမ်မှုမရောက်မီ compile time error သို့ပြောင်းလဲသွားလိမ့်မည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// အချပ်ကို `N`-element arrays ၏အချပ်တစ်ခုအဖြစ်ခွဲထုတ်သည်။
    ///
    ///
    /// # Safety
    ///
    /// ဤသည်ကိုသာအခါခေါ်နိုင်ပါသည်
    /// - အဆိုပါအချပ်အတိအကျ `N`-element ကိုတုံး (ခေါ် `self.len() % N == 0`)) သို့ခွဲထွက်။
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // လုံခြုံမှု-၁ ဒြပ်စင်အပိုင်းအစများသည်ဘယ်သောအခါမျှမကျန်တော့ပါ
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // လုံခြုံမှု-(6) အချပ်သည် ၃ မျိုးဖြစ်သည်
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // ဤရွေ့ကားမလုံခြုံပါလိမ့်မယ်:
    /// // _ [[&; တုံးပါစေ5]]= slice.as_chunks_unchecked_mut()//ဒီအချပ်အရှည်ဟာ 5 let chunk တွေအများကြီးမဟုတ်ပါဘူး။&[[_;0]]= slice.as_chunks_unchecked_mut()//သုညအရှည်တုံးခွင့်ပြုဘယ်တော့မှနေကြသည်
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // လုံခြုံမှု-ဤလိုအပ်ချက်ကိုခေါ်ဆိုရန်လိုအပ်သည့်အတိအကျမှာကျွန်ုပ်တို့၏လိုအပ်ချက်ဖြစ်သည်
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // လုံခြုံမှု: ကျနော်တို့သို့ `new_len * N` ဒြပ်စင်တစ်ခုအချပ်ကိုနှင်ထုတ်
        // `new_len` အများအပြား `N` ဒြပ်စင်တုံးတစ်အချပ်။
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// slice ကို `N`-element arrays ၏အစ ဦး အဖြစ်အစပိုင်းတွင်အစပိုင်း မှစ၍ `N` ထက်နည်းသောအရှည်ရှိသည့်ကျန်အပိုင်းကိုခွဲသည်။
    ///
    ///
    /// # Panics
    ///
    /// `N` သည် 0. ဖြစ်လျှင် Panics သည်ဤစစ်ဆေးမှုသည်ဤနည်းလမ်းတည်ငြိမ်မှုမရောက်မီ compile time error သို့ပြောင်းလဲသွားလိမ့်မည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // လုံခြုံမှု-ငါတို့ဟာသုညအတွက်ထိတ်လန့်တုန်လှုပ်နေခဲ့ပြီးဆောက်လုပ်ရေးလုပ်ငန်းမှာသေချာအောင်လုပ်ထားတယ်
        // အဆိုပါပlိညာဉ်စာတမ်း၏အရှည် N. ၏မျိုးစုံကြောင်း
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// slice ကို `N`-element arrays ၏အချပ် the the the အစ the အ at အဆုံး starting starting starting starting into, and and and and length length length length length ကျန်အပိုင်းကို `N` ထက်လျော့နည်း less သောအပိုင်းအစခွဲသည်။
    ///
    ///
    /// # Panics
    ///
    /// `N` သည် 0. ဖြစ်လျှင် Panics သည်ဤစစ်ဆေးမှုသည်ဤနည်းလမ်းတည်ငြိမ်မှုမရောက်မီ compile time error သို့ပြောင်းလဲသွားလိမ့်မည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // လုံခြုံမှု-ငါတို့ဟာသုညအတွက်ထိတ်လန့်တုန်လှုပ်နေခဲ့ပြီးဆောက်လုပ်ရေးလုပ်ငန်းမှာသေချာအောင်လုပ်ထားတယ်
        // အဆိုပါပlိညာဉ်စာတမ်း၏အရှည် N. ၏မျိုးစုံကြောင်း
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// slice ၏အစအ ဦး မှ စတင်၍ တစ်ချိန်တည်းတွင် slice ၏ `N` element များမှကြားဖြတ်တစ်ခုကိုပြန်ပို့သည်။
    ///
    /// အတုံးများသည် mutable array ကိုးကားချက်များဖြစ်ပြီးထပ်တူမကျပါ။
    /// အကယ်၍ `N` သည်အတိုအရှည်ကိုမခွဲထားပါကနောက်ဆုံး `N-1` ဒြပ်စင်များကိုချန်လှပ်ထားလိမ့်မည်။ ၎င်းသည်ကြားဖြတ်၏ `into_remainder` function မှပြန်လည်ရယူနိုင်သည်။
    ///
    ///
    /// ဤနည်းလမ်းသည် [`chunks_exact_mut`] ၏ const generic ညီမျှခြင်းဖြစ်သည်။
    ///
    /// # Panics
    ///
    /// `N` သည် 0. ဖြစ်လျှင် Panics သည်ဤစစ်ဆေးမှုသည်ဤနည်းလမ်းတည်ငြိမ်မှုမရောက်မီ compile time error သို့ပြောင်းလဲသွားလိမ့်မည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// အဆိုပါအချပ်ရဲ့အစမှာစတင်မယ့်အချပ်၏ `N` ဒြပ်စင်၏ windows ထပ်ကျော်တစ်ဦးကြားမှာ Returns ။
    ///
    ///
    /// ဤသည် [`windows`] ၏ const generic ညီမျှသည်။
    ///
    /// အကယ်၍ `N` သည်အချပ်အရွယ်ထက်ကြီးလျှင်၎င်းသည် windows ကိုပြန်ပို့လိမ့်မည်မဟုတ်ပါ။
    ///
    /// # Panics
    ///
    /// `N` 0 လျှင် Panics
    /// ဤစစ်ဆေးမှုသည်ဤနည်းလမ်းတည်ငြိမ်ခြင်းမတိုင်မီ compile time error သို့ပြောင်းလဲသွားလိမ့်မည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// slice ရဲ့အဆုံးမှာစပြီး slice ရဲ့ `chunk_size` element တွေပေါ်မှာ iterator ကိုတစ်ကြိမ်ပြန်သွားသည်။
    ///
    /// အတုံးတွေဟာချပ်တွေပါ၊`chunk_size` အဆိုပါအချပ်၏အရှည်ကိုဝေမပါဘူးဆိုရင်, ထို့နောက်နောက်ဆုံးအတုံးအရှည် `chunk_size` ရှိလိမ့်မည်မဟုတ်ပေ။
    ///
    /// [`rchunks_exact`] ကိုကြည့်ပြီး XTX element များ၏အတိအကျကိုပြန်ပေးသောဤကြားမှာ၏မူကွဲနှင့် [`chunks`] ကိုကြည့်ပါ။ သို့သော်၎င်းသည်ထပ်တူပြုရန်အတွက်ဖြစ်သည်။
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` လျှင် Panics 0 င်ဖြစ်ပါတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// slice ရဲ့အဆုံးမှာစပြီး slice ရဲ့ `chunk_size` element တွေပေါ်မှာ iterator ကိုတစ်ကြိမ်ပြန်သွားသည်။
    ///
    /// အဆိုပါတုံး mutable ချပ်ဖြစ်ကြသည်ကို၎င်း, မထပ်ဘူး။အကယ်၍ `chunk_size` သည်အချပ်၏အရှည်ကိုမခွဲခြားပါကနောက်ဆုံးအပိုင်းအစသည်အရှည် `chunk_size` ရှိလိမ့်မည်မဟုတ်ပါ။
    ///
    /// [`rchunks_exact_mut`] ကိုကြည့်ပြီး XTX element များ၏အတိအကျကိုပြန်ပေးသောဤကြားမှာ၏မူကွဲနှင့် [`chunks_mut`] ကိုကြည့်ပါ။ သို့သော်၎င်းသည်ထပ်တူပြုရန်အတွက်ဖြစ်သည်။
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` လျှင် Panics 0 င်ဖြစ်ပါတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// slice ရဲ့အဆုံးမှာစပြီး slice ရဲ့ `chunk_size` element တွေပေါ်မှာ iterator ကိုတစ်ကြိမ်ပြန်သွားသည်။
    ///
    /// အတုံးတွေဟာချပ်တွေပါ၊
    /// အကယ်၍ `chunk_size` သည်အတိုအရှည်ကိုမခွဲထားပါကနောက်ဆုံး `chunk_size-1` ဒြပ်စင်များကိုချန်လှပ်ထားလိမ့်မည်။ ၎င်းသည်ကြားဖြတ်၏ `remainder` function မှပြန်လည်ရယူနိုင်သည်။
    ///
    /// အတုံးတစ်ခုစီသည် `chunk_size` element များပါ ၀ င်သောကြောင့် compiler သည် [`chunks`] ၏ဖြစ်ရပ်ထက်ရလဒ်ကုဒ်ကိုပိုကောင်းအောင်လုပ်နိုင်သည်။
    ///
    /// ဒီကြားမှာတစ်မူကွဲများအတွက်ကြည့်ရှု [`rchunks`] ကြောင့်လည်းသေးငယ်တဲ့အတုံးအဖြစ်ကျန်ရှိသောပြန်လည်ရောက်ရှိနှင့် [`chunks_exact`] အတူတူပင်ကြားမှာအဘို့ပေမယ့်အချပ်ရဲ့အစမှာစတင်။
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` လျှင် Panics 0 င်ဖြစ်ပါတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// slice ရဲ့အဆုံးမှာစပြီး slice ရဲ့ `chunk_size` element တွေပေါ်မှာ iterator ကိုတစ်ကြိမ်ပြန်သွားသည်။
    ///
    /// အဆိုပါအတုံး mutable ချပ်များမှာ, ထပ်ကြပါဘူး။
    /// အကယ်၍ `chunk_size` သည်အတိုအရှည်ကိုမခွဲထားပါကနောက်ဆုံး `chunk_size-1` ဒြပ်စင်များကိုချန်လှပ်ထားလိမ့်မည်။ ၎င်းသည်ကြားဖြတ်၏ `into_remainder` function မှပြန်လည်ရယူနိုင်သည်။
    ///
    /// အတုံးတစ်ခုစီသည် `chunk_size` element များပါ ၀ င်သောကြောင့် compiler သည် [`chunks_mut`] ၏ဖြစ်ရပ်ထက်ရလဒ်ကုဒ်ကိုပိုကောင်းအောင်လုပ်နိုင်သည်။
    ///
    /// [`rchunks_mut`] ကိုဒီကြားမှာ၏မျိုးကွဲတစ်ခုအတွက်ကျန်ကိုကျန်အပိုင်းသေးသေးလေးအဖြစ်ပြန်ပို့ပေးသည်၊ တူညီသောကြားမှာရှိသည့် [`chunks_exact_mut`] ကိုကြည့်ပါ။
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` လျှင် Panics 0 င်ဖြစ်ပါတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// ၎င်းတို့ကိုသီးခြားခွဲထုတ်ရန် predicate ကို အသုံးပြု၍ ထပ်တူမကျသော element များ၏ပြေးမှုများကိုထုတ်လုပ်သည့်အချပ်ကိုကြားဖြတ်ကာပြန်ပို့သည်။
    ///
    /// predicate ကိုသူတို့ကိုယ်သူတို့နောက်ကွယ်မှ element နှစ်ခုဖြင့်ခေါ်သည်။ ဆိုလိုသည်မှာ `slice[0]` နှင့် `slice[1]`၊ ထို့နောက် `slice[1]` နှင့် `slice[2]` တို့နှင့်စသည်။ ဆိုလိုသည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ဤနည်းလမ်းကိုအမျိုးအစားခွဲထားသော subslices များထုတ်ယူရန်အသုံးပြုနိုင်သည်။
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// ၎င်းတို့ကိုသီးခြားခွဲထုတ်ရန် predicate ကို အသုံးပြု၍ မတူသောထပ်တလဲလဲမပြောင်းနိုင်သောရွေ့လျားနေသောလမ်းကြောင်းများထုတ်လုပ်ရန်အချပ်အားကြားဖြတ်တွက်ချက်သည်။
    ///
    /// predicate ကိုသူတို့ကိုယ်သူတို့နောက်ကွယ်မှ element နှစ်ခုဖြင့်ခေါ်သည်။ ဆိုလိုသည်မှာ `slice[0]` နှင့် `slice[1]`၊ ထို့နောက် `slice[1]` နှင့် `slice[2]` တို့နှင့်စသည်။ ဆိုလိုသည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ဤနည်းလမ်းကိုအမျိုးအစားခွဲထားသော subslices များထုတ်ယူရန်အသုံးပြုနိုင်သည်။
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// အပိုင်းတစ်ပိုင်းကိုအညွှန်းတစ်ခုဖြင့်နှစ်ပိုင်းခွဲသည်။
    ///
    /// ပထမတစ်ခုမှာ `[0, mid)` (ညွှန်းကိန်း `mid` သူ့ဟာသူဖယ်ထုတ်ပြီး) မှညွှန်းကိန်းအားလုံးပါ ၀ င်ပြီးဒုတိယတစ်ခုသည် `[mid, len)` (ညွှန်းကိန်း `len` ကိုယ်တိုင် မှလွဲ၍) မှညွန်ပြမှုများအားလုံးပါ ၀ င်လိမ့်မည်။
    ///
    ///
    /// # Panics
    ///
    /// `mid > len` လျှင် Panics ။
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // လုံခြုံမှု-`[ptr; mid]` နှင့် `[mid; len]` တို့သည် `self` အတွင်းတွင်ရှိသည်
        // `from_raw_parts_mut` ၏လိုအပ်ချက်များကိုဖြည့်။
        unsafe { self.split_at_unchecked(mid) }
    }

    /// တစ် ဦး mutable အချပ်တစ်ခုအညွှန်းကိန်းမှာနှစ်ခုသို့ခွဲခြား။
    ///
    /// ပထမတစ်ခုမှာ `[0, mid)` (ညွှန်းကိန်း `mid` သူ့ဟာသူဖယ်ထုတ်ပြီး) မှညွှန်းကိန်းအားလုံးပါ ၀ င်ပြီးဒုတိယတစ်ခုသည် `[mid, len)` (ညွှန်းကိန်း `len` ကိုယ်တိုင် မှလွဲ၍) မှညွန်ပြမှုများအားလုံးပါ ၀ င်လိမ့်မည်။
    ///
    ///
    /// # Panics
    ///
    /// `mid > len` လျှင် Panics ။
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // လုံခြုံမှု-`[ptr; mid]` နှင့် `[mid; len]` တို့သည် `self` အတွင်းတွင်ရှိသည်
        // `from_raw_parts_mut` ၏လိုအပ်ချက်များကိုဖြည့်။
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// အပိုင်းတစ်ပိုင်းကိုအကန့်အသတ်မရှိစစ်ဆေးခြင်းမရှိဘဲအပိုင်းနှစ်ပိုင်းခွဲပါ။
    ///
    /// ပထမတစ်ခုမှာ `[0, mid)` (ညွှန်းကိန်း `mid` သူ့ဟာသူဖယ်ထုတ်ပြီး) မှညွှန်းကိန်းအားလုံးပါ ၀ င်ပြီးဒုတိယတစ်ခုသည် `[mid, len)` (ညွှန်းကိန်း `len` ကိုယ်တိုင် မှလွဲ၍) မှညွန်ပြမှုများအားလုံးပါ ၀ င်လိမ့်မည်။
    ///
    ///
    /// လုံခြုံသောရွေးချယ်စရာတစ်ခုအတွက် [`split_at`] ကိုကြည့်ပါ။
    ///
    /// # Safety
    ///
    /// Out-of-bounds index ဖြင့်ဤနည်းလမ်းကိုခေါ်ခြင်းသည် *[undefined behavior]* ဖြစ်သည်။ ရရှိလာသောရည်ညွှန်းချက်ကိုမသုံးလျှင်ပင်ဖြစ်သည်။ခေါ်ဆိုသူသည် `0 <= mid <= self.len()` ကိုသေချာအောင်လုပ်ရမည်။
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // လုံခြုံမှု: Caller ကြောင်း `0 <= mid <= self.len()` စစ်ဆေးရှိပါတယ်
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// ပြောင်းလဲနိုင်သောအပိုင်းအစတစ်ခုကိုအညွှန်းတစ်ခုတွင်အပိုင်းနှစ်ခုခွဲခြားသည်။
    ///
    /// ပထမတစ်ခုမှာ `[0, mid)` (ညွှန်းကိန်း `mid` သူ့ဟာသူဖယ်ထုတ်ပြီး) မှညွှန်းကိန်းအားလုံးပါ ၀ င်ပြီးဒုတိယတစ်ခုသည် `[mid, len)` (ညွှန်းကိန်း `len` ကိုယ်တိုင် မှလွဲ၍) မှညွန်ပြမှုများအားလုံးပါ ၀ င်လိမ့်မည်။
    ///
    ///
    /// လုံခြုံသောရွေးချယ်စရာတစ်ခုအတွက် [`split_at_mut`] ကိုကြည့်ပါ။
    ///
    /// # Safety
    ///
    /// Out-of-bounds index ဖြင့်ဤနည်းလမ်းကိုခေါ်ခြင်းသည် *[undefined behavior]* ဖြစ်သည်။ ရရှိလာသောရည်ညွှန်းချက်ကိုမသုံးလျှင်ပင်ဖြစ်သည်။ခေါ်ဆိုသူသည် `0 <= mid <= self.len()` ကိုသေချာအောင်လုပ်ရမည်။
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // လုံခြုံမှု: Caller ကြောင်း `0 <= mid <= self.len()` စစ်ဆေးရှိပါတယ်။
        //
        // `[ptr; mid]` နှင့် `[mid; len]` ထပ်မတူသောကြောင့် mutable reference ကိုပြန်ပို့ခြင်းသည်အဆင်ပြေသည်။
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// `pred` နှင့်ကိုက်ညီသော element များဖြင့်ခွဲထားသော subslices များမှကြားဖြတ်တစ်ခုကိုပြန်ပို့သည်။
    /// ကိုက်ညီသော element က subslices တွင်ပါရှိသောမပေးပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// အကယ်၍ ပထမ element သည်လိုက်ဖက်ပါကအချပ်တစ်ကွက်သည်ကြားဖြတ်ကပြန်လာသည့်ပထမဆုံးပစ္စည်းဖြစ်လိမ့်မည်။
    /// အဆိုပါအချပ်အတွက်နောက်ဆုံးဒြပ်စင်ကိုက်ညီလျှင်အလားတူပင်တစ်ဦးအချည်းနှီးသောအချပ်အတွက်ကြားမှာအားဖြင့်ပြန်လာသောပြီးခဲ့သည့် item ကိုဖွစျလိမျ့မညျ:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// ကိုက်ညီသောဒြပ်စင်နှစ်ခုသည်တိုက်ရိုက်ကပ်လျက်ဖြစ်ပါက၎င်းတို့အကြားကွက်လပ်တစ်ခုရှိသည်။
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// `pred` နှင့်လိုက်ဖက်သောဒြပ်စင်များကခွဲခြားထားသည့် mutable subslices များမှကြားဖြတ်တစ်ခုကိုပြန်ပို့သည်။
    /// ကိုက်ညီသော element က subslices တွင်ပါရှိသောမပေးပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// `pred` နှင့်ကိုက်ညီသော element များဖြင့်ခွဲထားသော subslices များမှကြားဖြတ်တစ်ခုကိုပြန်ပို့သည်။
    /// လိုက်ဖက်တဲ့ element က terminator ရဲ့အဆုံးမှာ termator တစ်ခုအဖြစ်ပါ ၀ င်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// အချပ်၏နောက်ဆုံးဒြပ်စင်လိုက်ဖက်လျှင်, ထိုဒြပ်စင်ကိုယခင်အချပ်၏ terminator စဉ်းစားပါလိမ့်မယ်။
    ///
    /// ထိုအချပ်သည်ကြားဖြတ်ခြင်းမှပြန်လာသောနောက်ဆုံးအရာဖြစ်သည်။
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// `pred` နှင့်လိုက်ဖက်သောဒြပ်စင်များကခွဲခြားထားသည့် mutable subslices များမှကြားဖြတ်တစ်ခုကိုပြန်ပို့သည်။
    /// ကိုက်ညီသောဒြပ်စင်တစ်ခု Terminator အဖြစ်ယခင် subslice တွင်ပါရှိသောဖြစ်ပါတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// `pred` နှင့်ကိုက်ညီသော element များဖြင့်ခွဲခြားထားသော subslices များမှကြားဖြတ်တစ်ခုကိုပြန်ပို့သည်။ slice ၏အဆုံးမှစပြီးနောက်ပြန်အလုပ်လုပ်သည်။
    /// ကိုက်ညီသော element က subslices တွင်ပါရှိသောမပေးပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `split()` ကဲ့သို့ပင်ပထမသို့မဟုတ်နောက်ဆုံးဒြပ်စင်လိုက်ဖက်ပါကအချည်းနှီးသောအချပ်သည်ကြားဖြတ်ခြင်းမှပြန်လာသောပထမ (သို့မဟုတ်နောက်ဆုံး) ပစ္စည်းဖြစ်လိမ့်မည်။
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// `pred` နှင့်ကိုက်ညီသော element များဖြင့်ကွဲလွဲထားသော mutable subslices များမှကြားဖြတ်တစ်ခုကိုပြန်ပို့သည်။ slice ၏အဆုံးမှစပြီးနောက်ပြန်အလုပ်လုပ်သည်။
    /// ကိုက်ညီသော element က subslices တွင်ပါရှိသောမပေးပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// `pred` နှင့်လိုက်ဖက်သော element များဖြင့်ခွဲထားသော subslices များမှကြားဖြတ်တစ်ခုကိုပြန်ပို့သည်။ `n` အများဆုံးပစ္စည်းများသို့ပြန်သွားသည်။
    /// ကိုက်ညီသော element က subslices တွင်ပါရှိသောမပေးပါ။
    ///
    /// နောက်ဆုံး element က return ပြန်လာတဲ့အခါမှာကျန်ရှိနေသေးတဲ့ slice ကိုရပါလိမ့်မယ်။
    ///
    /// # Examples
    ///
    /// 3 (ဆိုလိုသည်မှာ `[10, 40]`, `[20, 60, 50]`) ကစားလို့ရတယ်နံပါတ်များအားဖြင့်တစ်ချိန်ကအချပ်အုပ်စုခွဲ Print:
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// `pred` နှင့်လိုက်ဖက်သော element များဖြင့်ခွဲထားသော subslices များမှကြားဖြတ်တစ်ခုကိုပြန်ပို့သည်။ `n` အများဆုံးပစ္စည်းများသို့ပြန်သွားသည်။
    /// ကိုက်ညီသော element က subslices တွင်ပါရှိသောမပေးပါ။
    ///
    /// နောက်ဆုံး element က return ပြန်လာတဲ့အခါမှာကျန်ရှိနေသေးတဲ့ slice ကိုရပါလိမ့်မယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// `pred` နှင့်အများဆုံးကိုက်ညီသော element များဖြင့်ခွဲခြားထားသော subslices များမှကြားခံတစ်ခုကိုပြန်ပို့သည် `n` အများဆုံးပစ္စည်းများသို့ပြန်သွားသည်။
    /// ဒါကအချပ်ရဲ့အဆုံးမှာစပြီးနောက်ပြန်အလုပ်လုပ်တယ်။
    /// ကိုက်ညီသော element က subslices တွင်ပါရှိသောမပေးပါ။
    ///
    /// နောက်ဆုံး element က return ပြန်လာတဲ့အခါမှာကျန်ရှိနေသေးတဲ့ slice ကိုရပါလိမ့်မယ်။
    ///
    /// # Examples
    ///
    /// အဆုံးအပိုင်းအစကိုအဆုံးမှ စ၍ 3 ဖြင့်စားနိုင်သည် (ဥပမာ-`[50]`, `[10, 40, 30, 20]`)
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// `pred` နှင့်အများဆုံးကိုက်ညီသော element များဖြင့်ခွဲခြားထားသော subslices များမှကြားခံတစ်ခုကိုပြန်ပို့သည် `n` အများဆုံးပစ္စည်းများသို့ပြန်သွားသည်။
    /// ဒါကအချပ်ရဲ့အဆုံးမှာစပြီးနောက်ပြန်အလုပ်လုပ်တယ်။
    /// ကိုက်ညီသော element က subslices တွင်ပါရှိသောမပေးပါ။
    ///
    /// နောက်ဆုံး element က return ပြန်လာတဲ့အခါမှာကျန်ရှိနေသေးတဲ့ slice ကိုရပါလိမ့်မယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// အချပ်ပေးထားသောတန်ဖိုးနှင့်အတူ element တစ်ခုပါရှိသည်လျှင် `true` ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// သင့်တွင် `&T` မရှိပါက `&U` ကဲ့သို့သော `&U` (ဥပမာဥပမာ
    /// `String: ချေးပါ<str>`), သငျသညျ `iter().any` အသုံးပွုနိုငျ:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // `String` ၏အချပ်
    /// assert!(v.iter().any(|e| e == "hello")); // `&str` နှင့်ရှာဖွေပါ
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// `needle` အဆိုပါအချပ်တစ်ရှေ့ဆက်လျှင် `true` Returns ။
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// `needle` ဟာအချပ်မရှိရင်အမြဲတမ်း `true` ကိုပြန်ပို့ပေးမှာပါ။
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// `needle` သည်အချပ်၏နောက်ဆက်တစ်ခုဖြစ်ပါက `true` သို့ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// `needle` ဟာအချပ်မရှိရင်အမြဲတမ်း `true` ကိုပြန်ပို့ပေးမှာပါ။
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// ရှေ့ဆက်ကိုဖယ်ရှားပြီးသော subslice တစ်ခုကိုပြန်ပို့သည်။
    ///
    /// အကယ်၍ အချပ်သည် `prefix` ဖြင့်စတင်ပါက၊ `Some` ဖြင့်ပတ်ထားသောရှေ့ဆက်ပုဒ်ပြီးနောက်နောက်ထပ်ခွဲကိုပြန်ပို့သည်။
    /// `prefix` သည်ဗလာလျှင်မူလအချပ်ကိုသာရိုးရိုးလေးပြန်ပို့ပေးသည်။
    ///
    /// အချပ် `prefix` နှင့်အတူစတင်မထားဘူးဆိုရင်, `None` ပြန်လည်ရောက်ရှိ။
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // SlicePattern သည် ပို၍ ရှုပ်ထွေးမှုရှိလာသောအခါနှင့်၎င်း function ကိုပြန်လည်ရေးရန်လိုအပ်လိမ့်မည်။
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// ဖယ်ထားသောနောက်ဆက်နှင့်အတူထပ်ဆင့်ထပ်မံပေးပို့သည်။
    ///
    /// အကယ်၍ အချပ်သည် `suffix` ဖြင့်အဆုံးသတ်ပါက၊ `Some` ပတ်လည်နောက်ဆက်ပုဒ်မတိုင်မီထပ်ဆင့်ထပ်ဆင့်ပေးပို့သည်။
    /// `suffix` သည်ဗလာလျှင်မူလအချပ်ကိုသာရိုးရိုးလေးပြန်ပို့ပေးသည်။
    ///
    /// အချပ် `suffix` နှင့်အတူအဆုံးသတ်မထားဘူးဆိုရင်, `None` ပြန်လည်ရောက်ရှိ။
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // SlicePattern သည် ပို၍ ရှုပ်ထွေးမှုရှိလာသောအခါနှင့်၎င်း function ကိုပြန်လည်ရေးရန်လိုအပ်လိမ့်မည်။
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Binary သည်ပေးထားသောဒြပ်စင်အတွက်ဤခွဲထားသောအချပ်ကိုရှာဖွေသည်။
    ///
    /// အကယ်၍ တန်ဖိုးကိုတွေ့ရှိပါက [`Result::Ok`] သည်သက်ဆိုင်ရာ element ၏ index ပါဝင်သော return ပြန်လာလိမ့်မည်။
    /// အကယ်၍ ပွဲများစွာရှိပါကမည်သည့်ပွဲကိုမဆိုပြန်ပေးနိုင်သည်။
    /// အကယ်၍ တန်ဖိုးကိုရှာမတွေ့ပါက၊ [`Result::Err`] သည်ပြန်လည်စီလိုက်ပြီးကိုက်ညီသောဒြပ်ထုကိုထည့်သွင်းနိုင်ပြီးအစဉ်လိုက်စီစဉ်ထားသည်။
    ///
    ///
    /// [`binary_search_by`], [`binary_search_by_key`] နှင့် [`partition_point`] ကိုလည်းရှုပါ။
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// ဒြပ်စင်လေးခုဆက်တိုက်ကြည့်သည်။
    /// ပထမတစ်ခုမှာထူးခြားစွာဆုံးဖြတ်ထားသည့်အနေအထားဖြင့်ဖြစ်သည်။ဒုတိယနှင့်တတိယတွေ့ရှိမခံရ;စတုတ္ထ `[1, 4]` အတွက်မဆိုအနေအထားကိုက်ညီနိုင်ဘူး။
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// သင် sort order ကိုထိန်းသိမ်းနေစဉ် sorted vector သို့ item တစ်ခုထည့်သွင်းလိုပါက:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Binary သည်ဒီစီထားသောအချပ်ကိုနှိုင်းယှဉ်လုပ်ဆောင်ချက်ဖြင့်ရှာဖွေသည်။
    ///
    /// အဆိုပါနှိုင်းယှဉ် function ကို၎င်း၏အငြင်းအခုံ `Less`, `Equal` သို့မဟုတ် `Greater` လိုချင်သောပစ်မှတ်ရှိမရှိညွှန်ပြတစ်ခုအမိန့်ကုဒ်ပြန်လာ, နောက်ခံအချပ်၏အမျိုးအမိန့်နှင့်အတူတသမတ်တည်းအမိန့်အကောင်အထည်ဖော်သင့်ပါတယ်။
    ///
    ///
    /// အကယ်၍ တန်ဖိုးကိုတွေ့ရှိပါက [`Result::Ok`] သည်သက်ဆိုင်ရာ element ၏ index ပါဝင်သော return ပြန်လာလိမ့်မည်။အကယ်၍ ပွဲများစွာရှိပါကမည်သည့်ပွဲကိုမဆိုပြန်ပေးနိုင်သည်။
    /// အကယ်၍ တန်ဖိုးကိုရှာမတွေ့ပါက၊ [`Result::Err`] သည်ပြန်လည်စီလိုက်ပြီးကိုက်ညီသောဒြပ်ထုကိုထည့်သွင်းနိုင်ပြီးအစဉ်လိုက်စီစဉ်ထားသည်။
    ///
    /// [`binary_search`], [`binary_search_by_key`] နှင့် [`partition_point`] ကိုလည်းရှုပါ။
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// ဒြပ်စင်လေးခုဆက်တိုက်ကြည့်သည်။ပထမတစ်ခုမှာထူးခြားစွာဆုံးဖြတ်ထားသည့်အနေအထားဖြင့်ဖြစ်သည်။ဒုတိယနှင့်တတိယတွေ့ရှိမခံရ;စတုတ္ထ `[1, 4]` အတွက်မဆိုအနေအထားကိုက်ညီနိုင်ဘူး။
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // လုံခြုံမှု-ခေါ်ဆိုမှုကိုအောက်ဖော်ပြပါအချက်အလက်များမှကာကွယ်ထားသည်။
            // - `mid >= 0`
            // - `mid < size`: `mid` ကို `[left; right)` ကန့်သတ်ထားသည်။
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // match မဖြစ်ဘဲ if/else control စီးဆင်းမှုကိုအသုံးပြုရသည့်အကြောင်းအရင်းမှာ perf sensititive ဖြစ်သော match reorders နှိုင်းယှဉ်စစ်ဆင်ရေးများကြောင့်ဖြစ်သည်။
            //
            // ဤသည်မှာ x86 အတွက် x86 asm ဖြစ်သည်။ https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// binary အဓိကထုတ်ယူ function ကိုနှင့်အတူဤစီထားသောအချပ်ရှာတတ်၏။
    ///
    /// အချပ်သည်သော့ဖြင့်စီထားခြင်းဖြစ်သည်ဟုယူဆသည်၊ ဥပမာ [`sort_by_key`] နှင့်အတူတူပင်သော့ထုတ်ယူခြင်းလုပ်ငန်းကိုအသုံးပြုသည်။
    ///
    /// အကယ်၍ တန်ဖိုးကိုတွေ့ရှိပါက [`Result::Ok`] သည်သက်ဆိုင်ရာ element ၏ index ပါဝင်သော return ပြန်လာလိမ့်မည်။
    /// အကယ်၍ ပွဲများစွာရှိပါကမည်သည့်ပွဲကိုမဆိုပြန်ပေးနိုင်သည်။
    /// အကယ်၍ တန်ဖိုးကိုရှာမတွေ့ပါက၊ [`Result::Err`] သည်ပြန်လည်စီလိုက်ပြီးကိုက်ညီသောဒြပ်ထုကိုထည့်သွင်းနိုင်ပြီးအစဉ်လိုက်စီစဉ်ထားသည်။
    ///
    ///
    /// [`binary_search`], [`binary_search_by`] နှင့် [`partition_point`] ကိုလည်းရှုပါ။
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// သူတို့ရဲ့ဒုတိယဒြပ်စင်များက sorted အားလုံးအတွက်တစ် ဦး အချပ်အတွက်လေးခုဒြပ်စင်တစ်ခုစီးရီးကိုတက်ကြည့်ရှုသည်။
    /// ပထမတစ်ခုမှာထူးခြားစွာဆုံးဖြတ်ထားသည့်အနေအထားဖြင့်ဖြစ်သည်။ဒုတိယနှင့်တတိယတွေ့ရှိမခံရ;စတုတ္ထ `[1, 4]` အတွက်မဆိုအနေအထားကိုက်ညီနိုင်ဘူး။
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links ကို `slice::sort_by_key` ကို crate `alloc` ၌တည်ရှိပြီးခွင့်ပြုထားသည်။ `core` ကိုတည်ဆောက်သောအခါ၎င်းကဲ့သို့မရှိသေးပါ။
    //
    // မြစ်အောက်ပိုင်း crate: #74481 လင့်များ။Primitive သာ libstd (#73423) အတွက်မှတ်တမ်းတင်ထားပါသည်ကတည်းက, ဒီအလေ့အကျင့်အတွက်လင့်များကျိုးပဲ့ဖို့ဦးဆောင်တာပါ။
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// အချပ်ကိုခွဲခြားပေမယ့်တူညီသောဒြပ်စင်၏အမိန့်ကိုထိန်းသိမ်းရန်မည်မဟုတ်ပါ။
    ///
    /// ဤအမျိုးအစားသည်မတည်ငြိမ်သော (ဆိုလိုသည်မှာ၊ တူညီသောဒြပ်စင်များကိုပြန်လည်နေရာချထားနိုင်သည်)၊ နေရာတွင် (ဆိုလိုသည်မှာခွဲဝေသတ်မှတ်ခြင်းမရှိပါ) နှင့် *O*(*n*\*log(* n*)) အဆိုးဆုံးအခြေအနေ) ။
    ///
    /// # လက်ရှိအကောင်အထည်ဖော်မှု
    ///
    /// လက်ရှိ algorithm သည် Orson Peters မှ [pattern-defeating quicksort][pdqsort] ကိုအခြေခံသည်။ အမြန်အလျင်အမြန်ကျပန်းအလျင်အမြန်ကောက်ယူသည့်အလျင်နှင့် heapsort ၏အဆိုးရွားဆုံးအမှုနှင့်ပေါင်းစပ်ပြီးအချို့သောပုံစံများနှင့်အချပ်များအတွက် linear အချိန်ရရှိသည်။
    /// deenerate ဖြစ်ပွားမှုများကိုရှောင်ရှားရန်၎င်းသည် randomization ကိုအသုံးပြုသည်။ သို့သော်သတ်မှတ်ထားသော seed ဖြင့်အမြဲတမ်းဆုံးဖြတ်ချက်အတိုင်းပြုမူသည်။
    ///
    /// ၎င်းသည်ပုံမှန်အားဖြင့်တည်ငြိမ်သော sorting ထက်ပိုမိုမြန်ဆန်သည်။ ဥပမာအားဖြင့်ဥပမာ၊ အချပ်သည် concatenated sorted sequences များပါဝင်သောအခါ။
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// အချပ်ကိုနှိုင်းယှဉ်လုပ်ဆောင်ချက်ဖြင့်ခွဲခြားသည်၊ သို့သော်တူညီသောဒြပ်စင်များ၏အစဉ်ကိုထိန်းသိမ်းမည်မဟုတ်ပါ။
    ///
    /// ဤအမျိုးအစားသည်မတည်ငြိမ်သော (ဆိုလိုသည်မှာ၊ တူညီသောဒြပ်စင်များကိုပြန်လည်နေရာချထားနိုင်သည်)၊ နေရာတွင် (ဆိုလိုသည်မှာခွဲဝေသတ်မှတ်ခြင်းမရှိပါ) နှင့် *O*(*n*\*log(* n*)) အဆိုးဆုံးအခြေအနေ) ။
    ///
    /// အဆိုပါနှိုင်းယှဉ် function ကိုအချပ်အတွက်ဒြပ်စင်များအတွက်စုစုပေါင်းအမိန့်သတ်မှတ်ရပေမည်။အော်ဒါမှာယူမှုစုစုပေါင်းမဟုတ်ပါက၊ ဒြပ်စင်များ၏အစီအစဉ်သည်မသတ်မှတ်ပါ။အော်ဒါတစ်ခုသည် (`a`, `b` နှင့် `c` အားလုံးအတွက်) ဖြစ်ပါကစုစုပေါင်းအစီအစဉ်တစ်ခုဖြစ်သည်။
    ///
    /// * စုစုပေါင်းနှင့် antisymmetric: `a < b`, `a == b` သို့မဟုတ် `a > b` ၏အတိအကျတစ်ခုသည်မှန်ကန်သည်
    /// * အကူးအပြောင်း, `a < b` နှင့် `b < c` `a < c` ကိုဆိုလိုသည်။`==` နှင့် `>` နှစ်ခုလုံးအတွက်အတူတူထားရမည်။
    ///
    /// ဥပမာအားဖြင့်၊ [`f64`] [`Ord`] ကို `NaN` မသုံးသောကြောင့် X0XX ကိုအသုံးပြုသည်။ သို့သော် X0XX မပါ ၀ င်သည်ကိုသိသောအခါ `partial_cmp` ကို sort function အဖြစ်သုံးနိုင်သည်။
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # လက်ရှိအကောင်အထည်ဖော်မှု
    ///
    /// လက်ရှိ algorithm သည် Orson Peters မှ [pattern-defeating quicksort][pdqsort] ကိုအခြေခံသည်။ အမြန်အလျင်အမြန်ကျပန်းအလျင်အမြန်ကောက်ယူသည့်အလျင်နှင့် heapsort ၏အဆိုးရွားဆုံးအမှုနှင့်ပေါင်းစပ်ပြီးအချို့သောပုံစံများနှင့်အချပ်များအတွက် linear အချိန်ရရှိသည်။
    /// deenerate ဖြစ်ပွားမှုများကိုရှောင်ရှားရန်၎င်းသည် randomization ကိုအသုံးပြုသည်။ သို့သော်သတ်မှတ်ထားသော seed ဖြင့်အမြဲတမ်းဆုံးဖြတ်ချက်အတိုင်းပြုမူသည်။
    ///
    /// ၎င်းသည်ပုံမှန်အားဖြင့်တည်ငြိမ်သော sorting ထက်ပိုမိုမြန်ဆန်သည်။ ဥပမာအားဖြင့်ဥပမာ၊ အချပ်သည် concatenated sorted sequences များပါဝင်သောအခါ။
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // reverse sorting
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// အချပ်ကိုသော့ထုတ်ယူသောလုပ်ဆောင်မှုဖြင့်ခွဲခြားသည်၊ သို့သော်တူညီသောဒြပ်စင်များ၏အစဉ်ကိုမထိန်းသိမ်းနိုင်ပါ။
    ///
    /// ဤအမျိုးအစားသည်မတည်ငြိမ်သော (ဆိုလိုသည်မှာတူညီသောဒြပ်စင်များကိုပြန်လည်နေရာချထားနိုင်သည်)၊ နေရာတွင် (ဆိုလိုသည်မှာခွဲဝေသတ်မှတ်သည်မရှိ) နှင့် *O*(m\* * n *\* log(*n*)) အဆိုးရွားဆုံး-သော့ချက် function *O)(* မီတာ *) ။
    ///
    /// # လက်ရှိအကောင်အထည်ဖော်မှု
    ///
    /// လက်ရှိ algorithm သည် Orson Peters မှ [pattern-defeating quicksort][pdqsort] ကိုအခြေခံသည်။ အမြန်အလျင်အမြန်ကျပန်းအလျင်အမြန်ကောက်ယူသည့်အလျင်နှင့် heapsort ၏အဆိုးရွားဆုံးအမှုနှင့်ပေါင်းစပ်ပြီးအချို့သောပုံစံများနှင့်အချပ်များအတွက် linear အချိန်ရရှိသည်။
    /// deenerate ဖြစ်ပွားမှုများကိုရှောင်ရှားရန်၎င်းသည် randomization ကိုအသုံးပြုသည်။ သို့သော်သတ်မှတ်ထားသော seed ဖြင့်အမြဲတမ်းဆုံးဖြတ်ချက်အတိုင်းပြုမူသည်။
    ///
    /// သော့ချက်ခေါ်ဆိုမှုမဟာဗျူဟာကြောင့်အဓိကလုပ်ဆောင်ချက်သည်စျေးကြီးသည့်အချိန်များတွင် [`sort_unstable_by_key`](#method.sort_unstable_by_key) သည် [`sort_by_cached_key`](#method.sort_by_cached_key) ထက်နှေးကွေးနိုင်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// `index` ရှိ element သည်၎င်း၏နောက်ဆုံးစီထားသောအနေအထားတွင်ရှိစေရန်အချပ်ကိုပြန်စီပါ။
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// `index` ရှိဒြပ်စင်သည်၎င်း၏နောက်ဆုံးစီစစ်ထားသည့်အနေအထားတွင်ရှိစေရန်အချပ်ကိုနှိုင်းယှဉ်လုပ်ဆောင်ချက်ဖြင့်ပြန်လည်သတ်မှတ်ပါ။
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// `index` ရှိဒြပ်စင်သည်၎င်း၏နောက်ဆုံးစီထားသည့်အနေအထားတွင်ရှိသောသော့ထုတ်ယူသော function နှင့်အချပ်ကိုပြန်စီပါ။
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// `index` ရှိ element သည်၎င်း၏နောက်ဆုံးစီထားသောအနေအထားတွင်ရှိစေရန်အချပ်ကိုပြန်စီပါ။
    ///
    /// ဤသည် reordering အနေအထား `i < index` မှာမဆိုတန်ဖိုးကိုတစ် ဦး အနေအထား `j > index` မှာမဆိုတန်ဖိုးကိုထက်လျော့နည်းသို့မဟုတ်ညီမျှလိမ့်မည်ဟုအပိုဆောင်းပိုင်ဆိုင်မှုရှိပါတယ်။
    /// ထို့အပြင်, ဒီနေရာစီမတည်မငြိမ် (ဆိုလိုသည်မှာဖြစ်ပါသည်
    /// မည်သည့်တူညီသောဒြပ်စင်မဆိုရာထူးသည် `index`) တွင်အဆုံးသတ်နိုင်သည်
    /// နှင့် *အို*(*n*) အဆိုးဆုံး-ခွဲဝေချထားပေးရန်မထားဘူး။
    /// ဒီ function ကိုလည်း/အခြားအစာကြည့်တိုက်အတွက် "kth element" အဖြစ်လူသိများသည်။
    /// ၎င်းသည်အောက်ပါတန်ဖိုးသုံးဆကိုပြန်ပေးသည်။ ပေးထားသောအညွှန်းကိန်းရှိဒြပ်စင်တစ်ခုထက်လျော့နည်းသည်၊ ပေးထားသောအညွှန်းကိန်းရှိတန်ဖိုးနှင့်ပေးထားသောအညွှန်းကိန်းများမှဒြပ်ထုတစ်ခုထက် ပို၍ ကြီးသောဒြပ်စင်အားလုံးဖြစ်သည်။
    ///
    ///
    /// # လက်ရှိအကောင်အထည်ဖော်မှု
    ///
    /// လက်ရှိ algorithm ကို [`sort_unstable`] အတွက်အသုံးပြုသောတူညီသော quicksort algorithm ၏အမြန်ရွေးချယ်မှုအပိုင်းကိုအခြေခံသည်။
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics သည် `index >= len()` ဖြစ်သည်။ ဆိုလိုသည်မှာအမြဲတမ်းအချပ်များပေါ်တွင် panics ဖြစ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // ပျမ်းမျှကိုရှာပါ
    /// v.select_nth_unstable(2);
    ///
    /// // သတ်မှတ်ထားသောညွှန်းကိန်းကိုကျွန်ုပ်တို့ခွဲထားပုံပေါ် မူတည်၍ အချပ်သည်အောက်ပါများထဲမှတစ်ခုဖြစ်လိမ့်မည်ဟုကျွန်ုပ်တို့အာမခံထားသည်။
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// `index` ရှိဒြပ်စင်သည်၎င်း၏နောက်ဆုံးစီစစ်ထားသည့်အနေအထားတွင်ရှိစေရန်အချပ်ကိုနှိုင်းယှဉ်လုပ်ဆောင်ချက်ဖြင့်ပြန်လည်သတ်မှတ်ပါ။
    ///
    /// ဤသည် reordering အနေအထား `i < index` မှာမဆိုတန်ဖိုးကိုနှိုင်းယှဉ် function ကိုသုံးပြီးအနေအထား `j > index` မှာမည်သည့်တန်ဖိုးကိုထက်လျော့နည်းသို့မဟုတ်ညီမျှလိမ့်မည်ဟုအပိုဆောင်းပိုင်ဆိုင်မှုရှိပါတယ်။
    /// ထို့အပြင်, ဒီနေရာစီ (*n*) အဆိုးဆုံး-ကိစ္စတွင် In-ရာအရပျ (ဆိုလိုသည်မှာခွဲဝေချထားပေးရန်ပါဘူး), (ဆိုလိုသည်မှာတန်းတူ element တွေကိုမဆိုအရေအတွက်ကအနေအထားကို `index` မှာတက်အဆုံးသတ်စေခြင်းငှါ) မတည်မငြိမ်ဖြစ်တယ်,*အို။*
    /// ဤလုပ်ဆောင်ချက်ကိုအခြားစာကြည့်တိုက်များတွင် "kth element" ဟုလည်းလူသိများသည်။
    /// ၎င်းသည်အောက်ပါတန်ဖိုးသုံးဆကိုပြန်ပေးသည်။ ပေးထားသောအညွှန်းကိန်းရှိဒြပ်စင်တစ်ခုထက်လျော့နည်းသည်၊ ပေးထားသောအညွှန်းကိန်းရှိတန်ဖိုးနှင့်ပေးထားသောအညွှန်းကိန်းများမှတစ်ခုထက်ပိုသောအရာအားလုံးကိုထောက်ပံ့ပေးသောနှိုင်းယှဉ်လုပ်ဆောင်ချက်ကိုအသုံးပြုသည်။
    ///
    ///
    /// # လက်ရှိအကောင်အထည်ဖော်မှု
    ///
    /// လက်ရှိ algorithm ကို [`sort_unstable`] အတွက်အသုံးပြုသောတူညီသော quicksort algorithm ၏အမြန်ရွေးချယ်မှုအပိုင်းကိုအခြေခံသည်။
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics သည် `index >= len()` ဖြစ်သည်။ ဆိုလိုသည်မှာအမြဲတမ်းအချပ်များပေါ်တွင် panics ဖြစ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // အချပ်ကိုအစဉ်လိုက်စီထားသည့်အတိုင်းပျမ်းမျှကိုရှာပါ။
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // သတ်မှတ်ထားသောညွှန်းကိန်းကိုကျွန်ုပ်တို့ခွဲထားပုံပေါ် မူတည်၍ အချပ်သည်အောက်ပါများထဲမှတစ်ခုဖြစ်လိမ့်မည်ဟုကျွန်ုပ်တို့အာမခံထားသည်။
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// `index` ရှိဒြပ်စင်သည်၎င်း၏နောက်ဆုံးစီထားသည့်အနေအထားတွင်ရှိသောသော့ထုတ်ယူသော function နှင့်အချပ်ကိုပြန်စီပါ။
    ///
    /// ဤသည် reordering အနေအထား `i < index` မှာမည်သည့်တန်ဖိုးကိုသော့ချက်ထုတ်ယူ function ကိုသုံးပြီးအနေအထား `j > index` မှာမည်သည့်တန်ဖိုးကိုထက်လျော့နည်းသို့မဟုတ်ညီမျှလိမ့်မည်ဟုအပိုဆောင်းပိုင်ဆိုင်မှုရှိပါတယ်။
    /// ထို့အပြင်, ဒီနေရာစီ (*n*) အဆိုးဆုံး-ကိစ္စတွင် In-ရာအရပျ (ဆိုလိုသည်မှာခွဲဝေချထားပေးရန်ပါဘူး), (ဆိုလိုသည်မှာတန်းတူ element တွေကိုမဆိုအရေအတွက်ကအနေအထားကို `index` မှာတက်အဆုံးသတ်စေခြင်းငှါ) မတည်မငြိမ်ဖြစ်တယ်,*အို။*
    /// ဤလုပ်ဆောင်ချက်ကိုအခြားစာကြည့်တိုက်များတွင် "kth element" ဟုလည်းလူသိများသည်။
    /// ၎င်းသည်အောက်ပါတန်ဖိုးသုံးဆကိုပြန်ပေးသည်။ ပေးထားသောအညွှန်းကိန်းရှိဒြပ်စင်တစ်ခုထက်လျော့နည်းသည်၊ ပေးထားသောအညွှန်းကိန်းရှိတန်ဖိုးနှင့်ပေးထားသောအညွှန်းကိန်းများထက်တစ်ခုထက်ပိုသောဒြပ်စင်များအားပြန်လည်ထောက်ပံ့ပေးသည်။
    ///
    ///
    /// # လက်ရှိအကောင်အထည်ဖော်မှု
    ///
    /// လက်ရှိ algorithm ကို [`sort_unstable`] အတွက်အသုံးပြုသောတူညီသော quicksort algorithm ၏အမြန်ရွေးချယ်မှုအပိုင်းကိုအခြေခံသည်။
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics သည် `index >= len()` ဖြစ်သည်။ ဆိုလိုသည်မှာအမြဲတမ်းအချပ်များပေါ်တွင် panics ဖြစ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // ပျှမ်းမျှတန်ဖိုးအတိုင်းအတာကိုစီထားသည့်အတိုင်း median ကိုပြန်ပို့ပါ။
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // သတ်မှတ်ထားသောညွှန်းကိန်းကိုကျွန်ုပ်တို့ခွဲထားပုံပေါ် မူတည်၍ အချပ်သည်အောက်ပါများထဲမှတစ်ခုဖြစ်လိမ့်မည်ဟုကျွန်ုပ်တို့အာမခံထားသည်။
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// [`PartialEq`] trait အကောင်အထည်ဖော်မှုအရဆက်တိုက်ထပ်ခါတလဲလဲ element များအားလုံးကို slice ၏အဆုံးသို့ရွှေ့သည်။
    ///
    ///
    /// နှစ်ခုချပ် Returns ။ပထမ ဦး ဆုံးအဘယ်သူမျှမဆက်တိုက်ထပ်ခါတလဲလဲဒြပ်စင်များပါရှိသည်။
    /// ဒုတိယတွင်အဘယ်သူမျှမသတ်မှတ်ထားသောနိုင်ရန်အတွက်အားလုံးမိတ္တူများပါရှိသည်။
    ///
    /// အကယ်၍ အချပ်ကိုစီထားလျှင်ပထမပြန်ရောက်သောအချပ်သည်မိတ္တူပွားများမပါ ၀ င်ပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// ပေးထားသောတန်းတူညီမျှမှုဆက်စပ်မှုကိုကျေနပ်စေရန်အချပ်၏အဆုံးသို့အဆက်မပြတ်သောဒြပ်စင်များမှအပကျန်အားလုံးကိုရွှေ့သည်။
    ///
    /// နှစ်ခုချပ် Returns ။ပထမ ဦး ဆုံးအဘယ်သူမျှမဆက်တိုက်ထပ်ခါတလဲလဲဒြပ်စင်များပါရှိသည်။
    /// ဒုတိယတွင်အဘယ်သူမျှမသတ်မှတ်ထားသောနိုင်ရန်အတွက်အားလုံးမိတ္တူများပါရှိသည်။
    ///
    /// `same_bucket` function သည် slice မှ element နှစ်ခုသို့ရည်ညွှန်းသည်ကိုလွန်သွားသည်။
    /// element တွေကိုသူတို့ရဲ့အစီအစဉ်ကနေဆန့်ကျင်ဘက်အစဉ်လိုက်ဖြတ်ပြီး X0 `same_bucket(a, b)` က `true` ကိုပြန်ပေးတယ်ဆိုရင် `a` ကို slice ရဲ့အဆုံးမှာရွှေ့လိုက်တယ်။
    ///
    ///
    /// အကယ်၍ အချပ်ကိုစီထားလျှင်ပထမပြန်ရောက်သောအချပ်သည်မိတ္တူပွားများမပါ ၀ င်ပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // `self` ကိုပြောင်းလဲနိုင်သောရည်ညွှန်းချက်ရှိသော်လည်းကျွန်ုပ်တို့က * မတရားပြုကျင့်တဲ့အပြောင်းအလဲတွေလုပ်လို့မရဘူး။`same_bucket` ခေါ်ဆိုမှုများသည် panic ဖြစ်နိုင်သည်၊ ထို့ကြောင့်ကျွန်ုပ်တို့သည်အချပ်သည်အမြဲတမ်းမှန်ကန်သောအခြေအနေတွင်ရှိကြောင်းသေချာစေရမည်။
        //
        // ဤအရာကိုကျွန်ုပ်တို့ကိုင်တွယ်ပုံသည်လဲလှယ်ရေးလဲလှယ်ခြင်းအားဖြင့်ဖြစ်သည်။လူအပေါင်းတို့သည်ဒြပ်စင်ကျော်ကျနော်တို့ကြားမှာကျနော်တို့အဆုံးမှာကျွန်တော်စောင့်ရှောက်ရန်ဆန္ဒရှိဒြပ်စင်ရှေ့၌ရှိကြ၏, ကြှနျုပျတို့ငြင်းပယ်ရန်ဆန္ဒရှိသောသူတို့သည်နောက်ကျောမှာဖြစ်ကြောင်းဒါကြောင့်သွားရအဖြစ်ဖလှယ်။
        // ကျနော်တို့ထို့နောက်အချပ်ခွဲနိုင်ပါတယ်။
        // ဒီစစ်ဆင်ရေးနေဆဲ `O(n)` ဖြစ်ပါတယ်။
        //
        // သာဓက-`r` ကိုကိုယ်စားပြုသောဤအခြေအနေတွင်ကျွန်ုပ်တို့စတင်သည်
        // next_write` ကိုဖတ်ပါ။
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // self[r] ကိုမိမိကိုယ်ကို [w-1] နှင့်နှိုင်းယှဉ်ပါက၎င်းသည်မိတ္တူမဟုတ်ပါ၊ ထို့ကြောင့်ကျွန်ုပ်တို့သည် self[r] နှင့် self[w] (r==w ကဲ့သို့အကျိုးသက်ရောက်မှုမရှိ) ကို swap လုပ်ပြီး r နှင့် w နှစ်ခုလုံးကိုတိုး။ ၊
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // self[r] ကိုမိမိကိုယ်ကို [w-1] နှင့်နှိုင်းယှဉ်ပါကဤတန်ဖိုးသည်ထပ်တူဖြစ်သည်၊ ထို့ကြောင့်ကျွန်ုပ်တို့သည် `r` ကိုတိုး။ အခြားအရာအားလုံးကိုမပြောင်းလဲစေဘဲ:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // [w-1] ကိုယ့်ကိုယ်ကိုဆန့်ကျင် self[r] Comparing, ဒီတစ်ထပ်မဟုတ်ပါဘူး, ဒါကြောင့်ကားဟောင်းများလဲလှယ်ရေး self[r] နှင့် self[w] နှင့်ကြိုတင် r နှင့် w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // ထပ်မထပ်ပါ၊
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // နှစ်ထပ်, အချပ်၏ advance r. End ။w မှာခွဲထွက်ပါ
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // လုံခြုံမှု-`while` အခြေအနေသည် `next_read` နှင့် `next_write` ကိုအာမခံသည်
        // အရှင် `self` အတွင်းမှဖြစ်ကြသည် `len` ထက်လျော့နည်းဖြစ်ကြသည်။
        // `prev_ptr_write` `ptr_write` မတိုင်မီ element တစ်ခုကိုညွှန်ပြသော်လည်း `next_write` သည် 1 မှစတင်သည်။ ထို့ကြောင့် `prev_ptr_write` သည် 0 ထက်လျော့နည်းပြီး slice အတွင်း၌ရှိသည်။
        // ဤသည် `ptr_read`, `prev_ptr_write` နှင့် `ptr_write` dereferencing အဘို့နှင့် `ptr.add(next_read)`, `ptr.add(next_write - 1)` နှင့် `prev_ptr_write.offset(1)` သုံးပြီးများအတွက်လိုအပ်ချက်များကိုပြည့်။
        //
        //
        // `next_write` ဒါ့အပြင်သူကဖလှယ်မှုခံရဖို့လိုအပျနိုငျသောအခါအဘယ်သူမျှမဒြပ်စင်ခုန်နေသည်အဓိပ္ပာယ်အရှိဆုံးမှာကွင်းဆက်နှုန်းတစ်ချိန်ကအရှိဆုံးမှာအဆတိုးနေသည်။
        //
        // `ptr_read` နှင့် `prev_ptr_write` သည်တူညီသောဒြပ်စင်ကိုဘယ်သောအခါမျှညွှန်ပြသည်။`&mut *ptr_read`, `&mut* prev_ptr_write` လုံခြုံရန်အတွက်၎င်းသည်လိုအပ်သည်။
        // ရှင်းပြချက်မှာ `next_read >= next_write` သည်အမြဲတမ်းမှန်ကန်မှုရှိသည်၊ ထို့ကြောင့် `next_read > next_write - 1` သည်လည်းမှန်ကန်သည်။
        //
        //
        //
        //
        //
        unsafe {
            // အမှတ်အသားများကိုအသုံးပြုခြင်းဖြင့်နယ်နိမိတ်စစ်ဆေးမှုများကိုရှောင်ပါ။
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// ပထမဆုံးဆက်တိုက်ဒြပ်စင်များအားလုံးမှတစ်ခုတည်းကိုသာသော့တစ်ခုသို့ဖြေရှင်းရန်အချပ်၏အဆုံးသို့ရွှေ့လိုက်သည်။
    ///
    ///
    /// နှစ်ခုချပ် Returns ။ပထမ ဦး ဆုံးအဘယ်သူမျှမဆက်တိုက်ထပ်ခါတလဲလဲဒြပ်စင်များပါရှိသည်။
    /// ဒုတိယတွင်အဘယ်သူမျှမသတ်မှတ်ထားသောနိုင်ရန်အတွက်အားလုံးမိတ္တူများပါရှိသည်။
    ///
    /// အကယ်၍ အချပ်ကိုစီထားလျှင်ပထမပြန်ရောက်သောအချပ်သည်မိတ္တူပွားများမပါ ၀ င်ပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// အစရှိသည့်အချပ်ကိုလှည့ ်၍ ထိုကဲ့သို့သောအချပ်၏ပထမဆုံး `mid` ဒြပ်စင်များသည်အဆုံးသို့ရွေ့သွားပြီးနောက်ဆုံး `self.len() - mid` ဒြပ်စင်များသည်ရှေ့သို့ရွေ့သွားသည်။
    /// `rotate_left` ကိုခေါ်ဆိုပြီးနောက် index `mid` ရှိယခင် element သည် slice ၏ပထမဆုံး element ဖြစ်လာလိမ့်မည်။
    ///
    /// # Panics
    ///
    /// အကယ်၍ `mid` သည်အချပ်အရှည်ထက်ကြီးလျှင်ဤလုပ်ဆောင်မှုသည် panic ဖြစ်သည်။`mid == self.len()` _not_ panic ကိုလုပ်ပြီး op-rotation လုပ်သည်ကိုသတိပြုပါ။
    ///
    /// # Complexity
    ///
    /// `self.len()`) အချိန်အတွက် (linear ကြာပါသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// ထပ်ဆင့်ငှားရမ်းခ:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // လုံခြုံမှု-`[p.add(mid) - mid, p.add(mid) + k)` အကွာအဝေးသည်အသေးအဖွဲဖြစ်သည်
        // `ptr_rotate` ခြင်းဖြင့်လိုအပ်သည့်အဖြစ်, ဖတ်ရှုခြင်းနှင့်ရေးသားခြင်းများအတွက်တရားဝင်။
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// အဆုံးတိုင်အောင်ထိုသို့သောအချပ်အပြောင်းအရွေ့၏ပထမဦးဆုံး `self.len() - k` ဒြပ်စင်သောအရပ်ကို Rotate အဆိုပါအချပ်ကနောက်ဆုံး `k` ဒြပ်စင်ရှေ့ပြောင်းရွှေ့နေစဉ်။
    /// `rotate_right` တောင်းဆိုပြီးနောက်ယခင်ကအညွှန်းကိန်း `self.len() - k` မှာ element ကအချပ်အတွက်ပထမဦးဆုံးဒြပ်စင်ဖြစ်လာပါလိမ့်မယ်။
    ///
    /// # Panics
    ///
    /// အကယ်၍ `k` သည်အချပ်အရှည်ထက်ကြီးလျှင်ဤလုပ်ဆောင်မှုသည် panic ဖြစ်သည်။`k == self.len()` _not_ panic ကိုလုပ်ပြီး op-rotation လုပ်သည်ကိုသတိပြုပါ။
    ///
    /// # Complexity
    ///
    /// `self.len()`) အချိန်အတွက် (linear ကြာပါသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// subslice တစ်ခုလှည့်ပါ
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // လုံခြုံမှု-`[p.add(mid) - mid, p.add(mid) + k)` အကွာအဝေးသည်အသေးအဖွဲဖြစ်သည်
        // `ptr_rotate` ခြင်းဖြင့်လိုအပ်သည့်အဖြစ်, ဖတ်ရှုခြင်းနှင့်ရေးသားခြင်းများအတွက်တရားဝင်။
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// `self` ကို `value` ပုံတူပွားခြင်းဖြင့်ဒြပ်စင်များနှင့်ဖြည့်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// `self` ကို element များဖြင့်ဖြည့်သည်။ closure ကိုအကြိမ်ကြိမ်ခေါ်ခြင်းဖြင့်ဖြစ်သည်။
    ///
    /// ဤနည်းလမ်းသည်တန်ဖိုးအသစ်များကိုဖန်တီးရန်အပိတ်တစ်ခုကိုအသုံးပြုသည်။အကယ်၍ သင်ကပေးထားသောတန်ဖိုး [`Clone`] ကိုအစားထိုးလိုပါက [`fill`] ကိုသုံးပါ။
    /// အကယ်၍ တန်ဖိုးများကိုထုတ်လုပ်ရန် [`Default`] trait ကိုအသုံးပြုလိုပါကသင်သည် [`Default::default`] ကိုအငြင်းအခုံပြုနိုင်သည်။
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// `src` မှ element များကို `self` သို့ကူးပါ။
    ///
    /// `src` ၏အရှည် `self` ကဲ့သို့တူညီသောဖြစ်ရမည်။
    ///
    /// အကယ်၍ `T` က `Copy` ကိုအသုံးပြုသည်ဆိုပါက [`copy_from_slice`] ကိုအသုံးပြုရန်စွမ်းဆောင်နိုင်သည်။
    ///
    /// # Panics
    ///
    /// နှစ်ခုချပ်ကွဲပြားခြားနားသောအရှည်ရှိပါကဒီ function ကို panic ပါလိမ့်မယ်။
    ///
    /// # Examples
    ///
    /// ဒြပ်စင်နှစ်ခုကိုအချပ်တစ်ခုမှနောက်တစ်ခုသို့ကူးယူခြင်း-
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // အချပ်များသည်တူညီသောအရှည်ရှိရမည်ဖြစ်သောကြောင့်ကျွန်ုပ်တို့သည်အရင်းအမြစ်အပိုင်းအစလေးခုမှနှစ်ခုသို့ကိုဖြတ်လိုက်သည်။
    /// // ကျွန်ုပ်တို့ဤသို့မပြုလုပ်ပါက panic ဖြစ်လိမ့်မည်။
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust တစ်ခုသာအထူးသဖြင့်နယ်ပယ်အတွက်အချက်အလက်များ၏တစ်ဦးအထူးသဖြင့်အပိုင်းအစရန်မမပြောင်းလဲနိုင်သောအရာများကိုးကားနှင့်တသားတ mutable ရည်ညွှန်းရှိနိုင်သည်ကိုအတည်ပြုပေးမှာ။
    /// ထို့ကြောင့် `clone_from_slice` slice တစ်ခုတည်းကိုအသုံးပြုရန်ကြိုးစားခြင်းသည် compile လုပ်ခြင်းကိုဖြစ်ပေါ်စေသည်။
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// ဒီကိစ္စကိုဖြေရှင်းနိုင်ဖို့အတွက် [`split_at_mut`] ကိုသုံးပြီးသီးခြားခွဲခြမ်းနှစ်ခုကိုဖန်တီးနိုင်ပါတယ်။
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// `src` မှ element အားလုံးကို memcpy သုံး၍ `self` သို့ကူးပါ။
    ///
    /// `src` ၏အရှည် `self` ကဲ့သို့တူညီသောဖြစ်ရမည်။
    ///
    /// အကယ်၍ `T` `Copy` ကိုအကောင်အထည်မဖော်ပါက [`clone_from_slice`] ကိုသုံးပါ။
    ///
    /// # Panics
    ///
    /// နှစ်ခုချပ်ကွဲပြားခြားနားသောအရှည်ရှိပါကဒီ function ကို panic ပါလိမ့်မယ်။
    ///
    /// # Examples
    ///
    /// အပိုင်းနှစ်ပိုင်းကိုအခြားတစ်ခုသို့ကူးယူခြင်း။
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // အချပ်များသည်တူညီသောအရှည်ရှိရမည်ဖြစ်သောကြောင့်ကျွန်ုပ်တို့သည်အရင်းအမြစ်အပိုင်းအစလေးခုမှနှစ်ခုသို့ကိုဖြတ်လိုက်သည်။
    /// // ကျွန်ုပ်တို့ဤသို့မပြုလုပ်ပါက panic ဖြစ်လိမ့်မည်။
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust တစ်ခုသာအထူးသဖြင့်နယ်ပယ်အတွက်အချက်အလက်များ၏တစ်ဦးအထူးသဖြင့်အပိုင်းအစရန်မမပြောင်းလဲနိုင်သောအရာများကိုးကားနှင့်တသားတ mutable ရည်ညွှန်းရှိနိုင်သည်ကိုအတည်ပြုပေးမှာ။
    /// ထို့ကြောင့် `copy_from_slice` slice တစ်ခုတည်းကိုအသုံးပြုရန်ကြိုးစားခြင်းသည် compile လုပ်ခြင်းကိုဖြစ်ပေါ်စေသည်။
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// ဒီကိစ္စကိုဖြေရှင်းနိုင်ဖို့အတွက် [`split_at_mut`] ကိုသုံးပြီးသီးခြားခွဲခြမ်းနှစ်ခုကိုဖန်တီးနိုင်ပါတယ်။
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // panic ကုဒ်လမ်းကြောင်းသည်ခေါ်ဆိုမှု site ကိုလွင့်မျောမသွားစေရန်အအေးခန်းထဲထည့်ထားသည်။
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // လုံခြုံမှု: `self` ချက်နှင့်အဓိပ္ပါယ်အားဖြင့် `self.len()` ဒြပ်စင်အဘို့အတရားဝင်သည်နှင့်, `src` ခဲ့သည်
        // တူညီသောအရှည်ရှိသည်ဖို့ check လုပ်ထား။
        // mutable ကိုးကားမှုများသီးသန့်ဖြစ်သောကြောင့်, အချပ်ထပ်လို့မရပါဘူး။
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// ဒြပ်စင်ကိုအချပ်၏အစိတ်အပိုင်းတစ်ခုမှအခြားအပိုင်းသို့ကူးပြောင်းကာ memmove ကိုအသုံးပြုသည်။
    ///
    /// `src` ထံမှကူးယူရန် `self` အတွင်းအကွာအဝေးဖြစ်ပါတယ်။
    /// `dest` သည် `self` အတွင်းရှိကူးယူရန်အကွာအဝေး၏အညွှန်းကိန်းဖြစ်သည်၊ ၎င်းသည် `src` နှင့်အတူတူပင်အရှည်ရှိသည်။
    /// နှစ်ခုအကွာအဝေးထပ်လိမ့်မည်။
    /// နှစ်ခုအကွာအဝေး၏အဆုံး `self.len()` ထက်နည်းသို့မဟုတ်ညီမျှဖြစ်ရမည်။
    ///
    /// # Panics
    ///
    /// အကယ်၍ အကွာအဝေးသည်အစက်၏အဆုံးထက်ကျော်လွန်ပါကသို့မဟုတ် `src` ၏အဆုံးသည်အစမစတင်မီဤလုပ်ဆောင်မှုသည် panic ဖြစ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// အချပ်တစ်ခုအတွင်း 4 bytes ကူးယူခြင်း-
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // လုံခြုံမှု: `ptr::copy` များအတွက်အခြေအနေများ, အထက် check လုပ်ထားခဲ့တာအားလုံးရှိသည်ဟု
        // `ptr::add` အဘို့ရှိသူများကဲ့သို့။
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// `other` ရှိအရာအားလုံးကို `other` ရှိအရာများနှင့်လဲလှယ်သည်။
    ///
    /// `other` ၏အရှည်သည် `self` နှင့်တူညီရမည်။
    ///
    /// # Panics
    ///
    /// နှစ်ခုချပ်ကွဲပြားခြားနားသောအရှည်ရှိပါကဒီ function ကို panic ပါလိမ့်မယ်။
    ///
    /// # Example
    ///
    /// ချပ်ကိုဖြတ်ပြီးနှစ်ခု element တွေကိုဖလှယ်:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust သည်အချက်အလက်တစ်ခု၏သီးခြားနယ်ပယ်တစ်ခုတွင်ပြောင်းလဲနိုင်သောရည်ညွှန်းချက်တစ်ခုသာရှိနိုင်သည်ကိုပြenfor္ဌာန်းသည်။
    ///
    /// ထို့ကြောင့် `swap_with_slice` slice တစ်ခုတည်းကိုအသုံးပြုရန်ကြိုးစားခြင်းသည် compile လုပ်ခြင်းကိုဖြစ်ပေါ်စေသည်။
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// ဒီပတ်ပတ်လည်အလုပ်စေရန်, ကျွန်တော်တစ်ဦးအချပ်ကနေနှစ်ခုကွဲပြား mutable ခွဲချပ်ကိုဖန်တီးရန် [`split_at_mut`] အသုံးပွုနိုငျ:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // လုံခြုံမှု: `self` ချက်နှင့်အဓိပ္ပါယ်အားဖြင့် `self.len()` ဒြပ်စင်အဘို့အတရားဝင်သည်နှင့်, `src` ခဲ့သည်
        // တူညီသောအရှည်ရှိသည်ဖို့ check လုပ်ထား။
        // mutable ကိုးကားမှုများသီးသန့်ဖြစ်သောကြောင့်, အချပ်ထပ်လို့မရပါဘူး။
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// အလယ်အလတ်အရှည်နှင့် `align_to{,_mut}` အတွက်အနိမ့်အချပ်တွက်ချက်ရန်လုပ်ဆောင်ချက်။
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // `rest` နဲ့ပတ်သက်ပြီးကျွန်ုပ်တို့ဘာလုပ်မလဲ ```အနိမ့်ဆုံး` `S` အနိမ့်ဆုံး `T`s 'ကိုဘယ်ကရနိုင်မလဲဆိုတာတွက်ဆသည်။
        //
        // ထိုကဲ့သို့သော "multiple" တစ်ခုစီအတွက်မည်မျှလိုအပ်သနည်း။
        //
        // ဥပမာ T-u8 ဦး=u16 ဘို့ဥပမာစဉ်းစားပါ။ပြီးရင် 1 U ကို 2 Ts ထဲထည့်နိုင်တယ်။ရိုးရှင်းသော။
        // အခုဥပမာ size_of: : ကိစ္စတစ်ခုကိုစဉ်းစားပါ။<T>=16, size_of::<U>=24 ။</u>
        // 3 Us တိုင်း၌ 2 Us ကို `rest` အချပ်တွင်ထားနိုင်သည်။
        // နည်းနည်းပိုရှုပ်ထွေးတယ်
        //
        // ဒီတွက်ချက်ရန်ဖော်မြူလာသည်
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // တိုးချဲ့နှင့်ရိုးရှင်း:
        //
        // Us=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) TS=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // ကံကောင်းတာကဒီအရာအလုံးစုံစဉ်ဆက်မပြတ်-အကဲဖြတ်သည်ကတည်းက ... ဒီမှာစွမ်းဆောင်ရည်အရေးမပါ!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // iterative stein ရဲ့ algorithm ဒီ x00X ကိုလုပ်သင့်တယ်။ (လုပ်မယ်ဆိုရင် recursive algorithm ကိုပြန်သွားပါ။) ဘာလို့လဲဆိုတော့ llvm ကိုဒီအရာတွေအားလုံးကိုထိန်းညှိဖို့ဆိုတာကိုမှီခိုနေလို့ပါ။ ဒါကငါ့ကိုမသက်မသာဖြစ်စေတယ်။
            //
            //

            // လုံခြုံမှု-`a` နှင့် `b` ကိုသုညမဟုတ်သောတန်ဖိုးများအဖြစ်စစ်ဆေးသည်။
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // ခကနေ 2 အားလုံးအချက်များဖယ်ရှားလိုက်ပါ
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // လုံခြုံမှု: `b` ကိုသုညမဟုတ်သည့်အတွက်စစ်ဆေးသည်။
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // ဒီဗဟုသုတနဲ့တပ်ဆင်ထားပြီး U `ဘယ်လောက်များများတပ်ဆင်နိုင်မလဲဆိုတာရှာတွေ့နိုင်တယ်။
        let us_len = self.len() / ts * us;
        // ထိုအချပ်အချပ်အတွက်မည်မျှ `T`s ဖြစ်လိမ့်မည်!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// အမျိုးအစားများ၏ alignment ကိုထိန်းသိမ်းထားတာဖြစ်ပါတယ်သေချာအခြားအမျိုးအစားတစ်ဦးအချပ်ဖို့အချပ် Transmute ။
    ///
    /// ဤနည်းလမ်းသည်အချပ်ကိုကွဲပြားသောအချပ်သုံးခုအဖြစ်ခွဲထုတ်သည်-ရှေ့ဆက်၊ အမျိုးအစားအသစ်၏မှန်ကန်စွာကိုက်ညီသည့်အလယ်အလတ်နှင့်နောက်ဆက်-အချပ်ဖြစ်သည်။
    /// ဤနည်းသည်အလယ်အချပ်ကိုပေးထားသောအမျိုးအစားနှင့် input အချပ်အတွက်အမြင့်ဆုံးအရှည်ကိုဖြစ်စေနိုင်သည်၊ သို့သော်သင်၏ algorithm ၏စွမ်းဆောင်ရည်သည်သာ၎င်းကိုမှန်ကန်မှုအပေါ် မူတည်၍ မှီသည်။
    ///
    /// ထည့်သွင်းထားသည့်အချက်အလက်အားလုံးကိုရှေ့ဆက် (သို့) နောက်ဆက် (slix) အဖြစ်ပြန်အပ်ရန်ခွင့်ပြုသည်။
    ///
    /// input method `T` (သို့) output element `U` သည်သုညအရွယ်ရှိပြီးမည်သည့်အရာကိုမျှမခွဲဘဲမူလအချပ်ကိုပြန်ပေးသည့်အခါဤနည်းလမ်းသည်ရည်ရွယ်ချက်မရှိပါ။
    ///
    /// # Safety
    ///
    /// ဤနည်းလမ်းသည်ပြန်လာသောအလယ်အချပ်ရှိဒြပ်စင်များနှင့်သက်ဆိုင်သောအခြေခံအားဖြင့် `transmute` တစ်ခုဖြစ်သည်။ ထို့ကြောင့် `transmute::<T, U>` နှင့်သက်ဆိုင်သောပုံမှန်အသိပေးချက်အားလုံးသည်ဤနေရာတွင်လည်းသက်ဆိုင်သည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // ဒီလုပ်ဆောင်ချက်အများစုကိုစဉ်ဆက်မပြတ်အကဲဖြတ်လိမ့်မယ်၊
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // အထူးသဖြင့် ZST များကိုကိုင်တွယ်ပါ၊ ၎င်းမှာလုံးဝမကိုင်ပါနှင့်။
            return (self, &[], &[]);
        }

        // ပထမနှင့်ဒုတိယအပိုင်းကိုမည်သည့်နေရာတွင်ခွဲခြားသည်ကိုပထမ ဦး စွာရှာဖွေပါ။
        // ptr.align_offset နှင့်အတူလွယ်ကူသော။
        let ptr = self.as_ptr();
        // လုံခြုံမှု-အသေးစိတ်လုံခြုံမှုမှတ်ချက်အတွက် `align_to_mut` နည်းလမ်းကိုကြည့်ပါ။
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // လုံခြုံမှု-ယခု `rest` သည်တိတိကျကျကိုက်ညီမှုရှိသည်၊ ထို့ကြောင့် `from_raw_parts` သည်အောက်ပါအတိုင်းဖြစ်သည်။
            // ခေါ်ဆိုသူသည်ကျွန်ုပ်တို့ `T` ကို `U` သို့ဘေးကင်းစွာလွှဲပြောင်းပေးနိုင်သည်ကိုအာမခံသည်။
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// အမျိုးအစားများ၏ alignment ကိုထိန်းသိမ်းထားတာဖြစ်ပါတယ်သေချာအခြားအမျိုးအစားတစ်ဦးအချပ်ဖို့အချပ် Transmute ။
    ///
    /// ဤနည်းလမ်းသည်အချပ်ကိုကွဲပြားသောအချပ်သုံးခုအဖြစ်ခွဲထုတ်သည်-ရှေ့ဆက်၊ အမျိုးအစားအသစ်၏မှန်ကန်စွာကိုက်ညီသည့်အလယ်အလတ်နှင့်နောက်ဆက်-အချပ်ဖြစ်သည်။
    /// ဤနည်းသည်အလယ်အချပ်ကိုပေးထားသောအမျိုးအစားနှင့် input အချပ်အတွက်အမြင့်ဆုံးအရှည်ကိုဖြစ်စေနိုင်သည်၊ သို့သော်သင်၏ algorithm ၏စွမ်းဆောင်ရည်သည်သာ၎င်းကိုမှန်ကန်မှုအပေါ် မူတည်၍ မှီသည်။
    ///
    /// ထည့်သွင်းထားသည့်အချက်အလက်အားလုံးကိုရှေ့ဆက် (သို့) နောက်ဆက် (slix) အဖြစ်ပြန်အပ်ရန်ခွင့်ပြုသည်။
    ///
    /// input method `T` (သို့) output element `U` သည်သုညအရွယ်ရှိပြီးမည်သည့်အရာကိုမျှမခွဲဘဲမူလအချပ်ကိုပြန်ပေးသည့်အခါဤနည်းလမ်းသည်ရည်ရွယ်ချက်မရှိပါ။
    ///
    /// # Safety
    ///
    /// ဤနည်းလမ်းသည်ပြန်လာသောအလယ်အချပ်ရှိဒြပ်စင်များနှင့်သက်ဆိုင်သောအခြေခံအားဖြင့် `transmute` တစ်ခုဖြစ်သည်။ ထို့ကြောင့် `transmute::<T, U>` နှင့်သက်ဆိုင်သောပုံမှန်အသိပေးချက်အားလုံးသည်ဤနေရာတွင်လည်းသက်ဆိုင်သည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // ဒီလုပ်ဆောင်ချက်အများစုကိုစဉ်ဆက်မပြတ်အကဲဖြတ်လိမ့်မယ်၊
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // အထူးသဖြင့် ZST များကိုကိုင်တွယ်ပါ၊ ၎င်းမှာလုံးဝမကိုင်ပါနှင့်။
            return (self, &mut [], &mut []);
        }

        // ပထမနှင့်ဒုတိယအပိုင်းကိုမည်သည့်နေရာတွင်ခွဲခြားသည်ကိုပထမ ဦး စွာရှာဖွေပါ။
        // ptr.align_offset နှင့်အတူလွယ်ကူသော။
        let ptr = self.as_ptr();
        // လုံခြုံမှု-ဒီနေရာမှာ U အတွက် allin pointers ကိုသုံးမှာသေချာတယ်
        // နည်းလမ်း၏ကျန်။၎င်းကို U. အတွက်ရည်မှန်းသောချိန်ညှိမှုတစ်ခုနှင့်အတူ [T] သို့ညွှန်ပြရန်သွားခြင်းဖြင့်ပြုလုပ်သည်။
        // `crate::ptr::align_offset` မှန်ကန်စွာမြှင့်တင်ပြီးမှန်ကန်သော pointer `ptr` (၎င်းသည် `self` မှရည်ညွှန်းမှုမှဆင်းသက်လာခြင်း) ဖြင့်လည်းကောင်း၊ ၎င်းသည် U အတွက် alignement မှထွက်ပေါ်လာချိန် မှစ၍ စွမ်းအားနှစ်ခု၏အရွယ်အစားနှင့်ခေါ်ဆိုခြင်းဖြစ်ပြီး၎င်းသည်၎င်း၏လုံခြုံရေးကန့်သတ်ချက်များကိုကျေနပ်အားရစေသည်။
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // နောက်မှ `rest` ကိုကျွန်ုပ်တို့ ထပ်၍ မသုံးနိုင်ပါ၊ ၎င်းသည်၎င်း၏ alias `mut_ptr` ကိုပျက်ပြယ်စေလိမ့်မည်။လုံခြုံမှု-`align_to` အတွက်မှတ်ချက်များကိုကြည့်ပါ။
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// ဒီအချပ်၏ဒြပ်စင်များစီထားရှိမရှိစစ်ဆေးသည်။
    ///
    /// ဆိုလိုသည်မှာ၊ `a` တစ်ခုချင်းစီနှင့်၎င်းအောက်ပါ element `b` တစ်ခုစီအတွက်၊ `a <= b` သည်ကိုင်ရမည်။အကယ်၍ အချပ်သည်သုညသို့မဟုတ်တစ်ခုတည်းသောဒြပ်စင်တစ်ခုတည်းဖြစ်ထွန်းလျှင်၊ `true` ကိုပြန်ပို့သည်။
    ///
    /// `Self::Item` သာ `PartialOrd` ဖြစ်တယ်, ဒါပေမဲ့မပေး `Ord` လျှင်မှတ်ချက်, အထက်ပါချက်နှင့်အဓိပ္ပါယ်မဆိုနှစ်ခုဆက်တိုက်ပစ္စည်းများနှိုင်းယှဉ်မရလျှင်ဒီ function ကို `false` ပြန်လည်ရောက်ရှိကြောင်းအဓိပ္ပာယ်သက်ရောက်ကြောင်း။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// ဒီအချပ်၏ဒြပ်စင်ပေးထားသောနှိုင်းယှဉ် function ကိုသုံးပြီး sorted လျှင်စစ်ဆေးသည်။
    ///
    /// အဲဒီအစား `PartialOrd::partial_cmp` အသုံးပြုခြင်း၏, ဒီ function ကိုနှစ်ခုဒြပ်စင်များ၏သာသနာကိုဆုံးဖြတ်ရန်ပေးထားသော `compare` function ကိုအသုံးပြုသည်။
    /// အပြင်ကနေ, က [`is_sorted`] ညီမျှင်;ပိုမိုသိရှိလိုပါက၎င်း၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// ဒီအချပ်၏ဒြပ်စင်ပေးထားသောသော့ထုတ်ယူ function ကိုသုံးပြီး sorted လျှင်စစ်ဆေးသည်။
    ///
    /// အဲဒီအစားကိုတိုက်ရိုက်အချပ်ရဲ့ element တွေကိုနှိုင်းယှဉ်၏ `f` ကဆုံးဖြတ်အဖြစ်, ဒီ function ကို, ထိုဒြပ်စင်၏သော့နှိုင်းယှဉ်။
    /// အပြင်ကနေ, က [`is_sorted`] ညီမျှင်;ပိုမိုသိရှိလိုပါက၎င်း၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// ပေးထားသော predicate (ဒုတိယ partition ကို၏ပထမဦးဆုံးဒြပ်စင်၏အညွှန်းကိန်း) အရ partition ကို point ရဲ့အညွှန်းကိန်း Returns ။
    ///
    /// အဆိုပါအချပ်ပေးထားသော predicate အရသိရသည် partitioned ခံရဖို့ယူဆနေသည်။
    /// အားလုံး element တွေကိုစစ်မှန်တဲ့အဆိုပါ predicate ပြန်ဟာအချပ်ရဲ့ start နှင့်မှားယွင်းသောအဆိုပါ predicate ပြန်အဆုံးမှာနေသောအားလုံးကိုဒြပ်စင်မှာနေသောအဘို့အသောဤနည်းလမ်းများ။
    ///
    /// ဥပမာအားဖြင့်၊ [7, 15, 3, 5, 4, 12, 6] သည်ကြိုတင်ခန့်မှန်းထားသော x% 2!=0 အောက်တွင်အခန်းကန့်တစ်ခုဖြစ်သည် (မကိန်းအားလုံးသည်အစတွင်ရှိသည်၊ အားလုံးအဆုံးမှာပင်ဖြစ်သည်) ။
    ///
    /// အကယ်၍ ဤအချပ်သည် partition မထားပါကဤနည်းသည် binary search ကိုလုပ်ဆောင်သောကြောင့်ရလဒ်သည်မသတ်မှတ်ရ၊ အဓိပ္ပါယ်မရှိပါ။
    ///
    /// [`binary_search`], [`binary_search_by`] နှင့် [`binary_search_by_key`] ကိုလည်းရှုပါ။
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // လုံခြုံမှု-ဘယ်အချိန်မှာ `left < right`၊ `left <= mid < right`.
            // ထို့ကြောင့် `left` သည်အမြဲတမ်းတိုးပွားလာပြီး `right` သည်အမြဲတမ်းလျော့ကျသွားပြီး၎င်းတို့ထဲမှတစ်ခုခုကိုရွေးချယ်သည်။ကိစ္စရပ်နှစ်ခုလုံးတွင် `left <= right` သည်ကျေနပ်မှုရှိသည်။ထို့ကြောင့် `left < right` သည်အဆင့်တစ်ခုတွင် `left <= right` သည်နောက်တစ်ဆင့်တွင်ကျေနပ်မှုရှိသည်။
            //
            // ထို့ကြောင့်နေသမျှကာလပတ်လုံး `left != right` အဖြစ်, `0 <= left < right <= len` ကျေနပ်သည်နှင့်ဤကိစ္စတွင် `0 <= mid < len` လွန်းကျေနပ်မှုလျှင်။
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: ကျနော်တို့ကသူတို့ကိုအတိအကျတူညီအရှည်အထိချပ်ဖို့လိုအပ်ပါတယ်
        // ပိုမိုလွယ်ကူအောင်ပြုလုပ်ပေးသူကိုသတ်မှတ်ထားသောစည်းမျဉ်းစည်းကမ်းများကို elide လုပ်ရန်။
        // Copy ကူး: ဒါပေမယ့်ကျနော်တို့အပေါ်မှီခိုရနိုင်မှာမဟုတ်ဘူးကတည်းကလည်း T-တစ်ခုရှင်းလင်းပြတ်သားစွာအထူးပြုရှိသည်။
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// တစ်ဦးအချည်းနှီးသောအချပ်ဖန်တီးပေးပါတယ်။
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// တစ် ဦး mutable ဗလာအချပ်ကိုဖန်တီးပေးပါတယ်။
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// `strip_prefix` နှင့် `strip_suffix` မှအသုံးပြုသောအချပ်များပုံစံများ။
/// future အမှတ်တစ်ခုတွင်ကျွန်ုပ်တို့သည် `core::str::Pattern` (အရေးအသားရေးသားချိန်တွင် `str` ကန့်သတ်ထားသည်) ကိုအချပ်များအဖြစ်ယေဘူယျပြုလုပ်ရန်မျှော်လင့်သည်။ ထို့နောက်၎င်း trait ကိုအစားထိုးသို့မဟုတ်ဖျက်သိမ်းလိမ့်မည်။
///
pub trait SlicePattern {
    /// အပေါ်လိုက်ဖက်သည့်အချပ်၏ဒြပ်စင်အမျိုးအစား။
    type Item;

    /// လက်ရှိတွင် `SlicePattern` သုံးစွဲသူများသည်အချပ်တစ်ခုလိုအပ်သည်။
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}