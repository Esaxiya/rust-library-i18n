// မူရင်းအကောင်အထည်ဖော်မှု rust-memchr မှယူသည်။
// မူပိုင် ၂၀၁၅ Andrew Gallant, bluss နှင့် Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// ခြင်းကိုသုံးပါ။
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// အကယ်၍ `x` တွင်သုညဘိုက်မရှိလျှင် `true` ကိုပြန်ပို့သည်။
///
/// မှ *ကိစ္စများတွက်ချက်မှု* မှ, ဂျေအာndt:
///
/// "စိတ်ကူးက bytes တစ်ခုချင်းစီထဲကတစ်ခုကိုနှုတ်ယူပြီး၊ အတိုးအကျယ်ပြန့်ဆုံးအထိချေးယူတဲ့ bytes တွေကိုရှာဖို့ဖြစ်တယ်။
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// `text` ရှိ byte `x` နှင့်တူညီသောပထမဆုံးအညွှန်းကိုပြန်ပို့သည်။
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // သေးငယ်တဲ့အချပ်များအတွက်အစာရှောင်ခြင်းလမ်းကြောင်းကို
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // တစ်ကြိမ်လျှင် `usize` စာလုံးနှစ်လုံးဖတ်ခြင်းဖြင့် byte တန်ဖိုးတစ်ခုအတွက် scan လုပ်ပါ။
    //
    // `text` ကိုသုံးပိုင်းခွဲပါ
    // - စာသားထဲမှာပထမ ဦး ဆုံးစကားလုံး alignment ကိုလိပ်စာမီ, unaligned ကန ဦး အစိတ်အပိုင်း
    // - ခန္ဓာကိုယ်တစ်ကြိမ်စကားလုံး ၂ လုံးဖြင့်စစ်ဆေးပါ
    // - နောက်ဆုံးကျန်ရှိသောအစိတ်အပိုင်း, <2 စကားလုံးအရွယ်အစား

    // တစ်ဦးဘက်မလိုက်နယ်နိမိတ်အထိရှာဖွေ
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // စာသား၏ခန္ဓာကိုယ်ရှာဖွေပါ
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // လုံခြုံမှု-while ၏ကြိုတင်ခန့်မှန်းချက်သည်အနည်းဆုံး * * usize_bytes ၏အကွာအဝေးကိုအာမခံသည်
        // အဆိုပါ offset နှင့်အချပ်၏အဆုံးအကြား။
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // ကိုက်ညီတဲ့ byte ရှိရင်ချိုးပါ
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // ခန္ဓာကိုယ်ကွင်းဆက်ရပ်တန့်သည့်အမှတ်ပြီးနောက်ဘိုက်ကိုရှာပါ။
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// `text` အတွက်က byte `x` ကိုက်ညီပြီးခဲ့သည့်အညွှန်းကိန်း Returns ။
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // တစ်ကြိမ်လျှင် `usize` စာလုံးနှစ်လုံးဖတ်ခြင်းဖြင့် byte တန်ဖိုးတစ်ခုအတွက် scan လုပ်ပါ။
    //
    // `text` ကိုသုံးပိုင်းခွဲပါ။
    // - စာသားထဲမှာနောက်ဆုံးစကားလုံးကိုက်ညီလိပ်စာပြီးနောက်, unaligned အမြီး,
    // - တစ်ချိန်တည်းတွင်စကားလုံး ၂ လုံးဖြင့်စစ်ဆေးသည်။
    // - ပထမကျန်ရှိသော bytes, <2 စကားလုံးအရွယ်အစား။
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // ကျနော်တို့ကရှေ့ဆက်နှင့်နောက်ဆက်များ၏အရှည်ရရှိရန်ရုံဒီကိုခေါ်ပါ။
        // အလယ်၌ကျွန်ုပ်တို့သည်အတုံးနှစ်ချပ်စီကိုအမြဲတမ်းလုပ်ဆောင်သည်။
        // လုံခြုံမှု-`[u8]` မှကိုင်တွယ်ရသောအရွယ်အစားကွာခြားချက်များ မှလွဲ၍ `[u8]` သို့ `[usize]` သို့ကူးပြောင်းခြင်းသည်လုံခြုံသည်။
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // စာသား၏ကိုယ်ကိုရှာရန်ကျနော်တို့လက်ဝါးကပ်တိုင် min_aligned_offset မသေချာပါစေ။
    // offset သည်အမြဲတမ်းအစဉ်အမြဲတည်သောကြောင့် `>` ကိုသာစစ်ဆေးခြင်းသည်လုံလောက်ပြီးဖြစ်နိုင်သောလျှံကိုရှောင်ရှားနိုင်သည်။
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // လုံခြုံမှု-offset သည် len, suffix.len() မှစတင်သည်
        // min_aligned_offset (prefix.len()) သည်ကျန်ရှိသောအကွာအဝေးမှာအနည်းဆုံး ၂ * chunk_bytes ဖြစ်သည်။
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // ကိုက်ညီတဲ့ byte ရှိရင်ချိုးပါ။
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // ခန္ဓာကိုယ်ကွင်းဆက်ရပ်တန့်သည့်အချက်မတိုင်မီဘိုက်ကိုရှာပါ။
    text[..offset].iter().rposition(|elt| *elt == x)
}