//! ASCII `[u8]` မှစစ်ဆင်ရေးများ။

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// ဒီအချပ်အတွက်အားလုံး bytes အားလုံး ASCII အကွာအဝေးအတွင်းရှိရှိမရှိစစ်ဆေးသည်။
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// အချပ်နှစ်ခုသည် ASCII case-insensitive match တစ်ခုဖြစ်ကြောင်းစစ်ဆေးသည်။
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` နှင့်အတူတူပင်၊ သို့သော်ယာယီအားခွဲဝေချခြင်းနှင့်ကူးယူခြင်းမပြုလုပ်ရန်။
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// ဒီအချပ်ကို၎င်း၏ ASCII စာလုံးအကြီးနှင့်ညီမျှသောနေရာတွင်ပြောင်းသည်။
    ///
    /// ASCII အက္ခရာများ 'a' မှ 'z' အက္ခရာများကို 'A' သို့ 'Z' သို့ဆက်စပ်ထားသည်၊ သို့သော် ASCII မဟုတ်သောအက္ခရာများမှာမပြောင်းလဲပါ။
    ///
    /// လက်ရှိတန်ဖိုးကိုပြုပြင်မွမ်းမံခြင်းမပြုဘဲ uppercased value အသစ်တစ်ခုကို return ပြန်ရန် [`to_ascii_uppercase`] ကိုသုံးပါ။
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// ဒီအချပ်ကို၎င်း၏ ASCII စာလုံးအငယ်နှင့်ညီမျှသောနေရာတွင်ပြောင်းသည်။
    ///
    /// ASCII အက္ခရာများ 'A' မှ 'Z' အက္ခရာများကို 'a' နှင့် 'z' သို့ဆက်စပ်ထားသည်။ သို့သော် ASCII မဟုတ်သောအက္ခရာများမှာမပြောင်းလဲပါ။
    ///
    /// လက်ရှိတန်ဖိုးကိုပြုပြင်မွမ်းမံခြင်းမပြုဘဲ lowercased value အသစ်တစ်ခုကို return ပြန်ဖို့ [`to_ascii_lowercase`] ကိုသုံးပါ။
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// `v` တွင်ပါရှိသောမည်သည့် byte သည် nonascii (>=128) ဆိုပါက `true` သို့ပြန်သွားသည်။
/// utf8 အတည်ပြုရန်အလားတူအရာတစ်ခုခုပြုလုပ်သော `../str/mod.rs` မှ snarfed ။
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// (ဖြစ်နိုင်လျှင်) byte-at-a-time စစ်ဆင်ရေးအစား usize-at-a-time စစ်ဆင်ရေးကိုသုံးပါလိမ့်မယ် Optimized ASCII စမ်းသပ်မှု။
///
/// ကျနော်တို့ကဒီမှာသုံးတဲ့ algorithm ကိုတော်တော်လေးရိုးရှင်းပါသည်။`s` တိုလွန်းလျှင် byte တစ်ခုချင်းစီကိုစစ်ဆေးပြီး၎င်းကိုလုပ်ဆောင်ပါလိမ့်မည်။မဟုတ်ရင်
///
/// - ပထမ ဦး ဆုံးစာလုံးကို unaligned load ဖြင့်ဖတ်ပါ။
/// - အဆိုပါ pointer align, aligned ဝန်နှင့်အတူအဆုံးသတ်သည်အထိနောက်ဆက်တွဲစကားလုံးများကိုဖတ်ပါ။
/// - `s` မှနောက်ဆုံး `usize` ကို unaligned load ဖြင့်ဖတ်ပါ။
///
/// အကယ်၍ ဤဝန်များမှ `contains_nonascii` (above) မှစစ်မှန်သောပြန်လာသည့်အရာတစ်ခုခုကိုထုတ်လုပ်ပါကအဖြေမှားကြောင်းကျွန်ုပ်တို့သိသည်။
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // ကျွန်တော်တို့ဟာ word-at-a-time implementation ကနေဘာမှမရရှိနိုင်ဘူးဆိုရင် scalar loop ကိုပြန်သွားပါ။
    //
    // `size_of::<usize>()` သည် `usize` အတွက်လုံလောက်သောညှိနှိုင်းမှုမရှိသောဗိသုကာများအတွက်ဤအရာသည်လုပ်ပေးသည်၊ အကြောင်းမှာ၎င်းသည်ထူးဆန်းသော edge အမှုဖြစ်သည်။
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // `align_offset` ဆိုတာကပထမဆုံး unaligned စာလုံးကိုကျနော်တို့အမြဲတမ်းဖတ်ပါတယ်
    // 0, ကျနော်တို့ကအတူတူဖတ်များအတွက်ထပ်တူတန်ဖိုးကိုပြန်ဖတ်ချင်ပါတယ်။
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // လုံခြုံမှု-အထက်တွင်ဖော်ပြထားသော `len < USIZE_SIZE` ကိုကျွန်ုပ်တို့အတည်ပြုပါသည်။
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // ကျနော်တို့အတန်ငယ်လုံးလုံးလြားလြား, အထက်တွင်ဤစစ်ဆေးခဲ့သည်။
    // သတိပြုရမည်မှာ `offset_to_aligned` သည် `align_offset` သို့မဟုတ် `USIZE_SIZE` ဖြစ်စေ၊ နှစ်ခုလုံးသည်အထက်တွင်ရှင်းလင်းစွာစစ်ဆေးထားသည်။
    //
    debug_assert!(offset_to_aligned <= len);

    // လုံခြုံမှု: word_ptr သည်ဖတ်ရန်ကျွန်ုပ်တို့သုံးသော (မှန်ကန်စွာကိုက်ညီသော) usize ptr ဖြစ်သည်
    // အချပ်၏အလယ်ပိုင်းအတုံး။
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` loop end Check များအတွက်အသုံးပြုသည့် `word_ptr` ၏ byte index ဖြစ်သည်။
    let mut byte_pos = offset_to_aligned;

    // ပါရာနိုယာက alignment ကိုစစ်ဆေးတယ်။
    // လက်တွေ့တွင်၎င်းသည် `align_offset` တွင် bug တစ်ခုမဖြစ်စေရ။
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // နောက်ခံစကားလုံးများအထိနောက်ဆုံးအမြန်ဆုံးစကားလုံးကိုဖတ်ပါ၊ အမြီးကိုနောက်တွင်စစ်ဆေးရန်နောက်ဆုံးသတ်မှတ်ထားသောစကားလုံးကိုဖယ်ထုတ်ပြီးအမြီးကိုအမြဲတမ်း `usize` အပို branch `byte_pos == len` သို့သေချာစေပါ။
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // စိတ်ဖောက်ပြန်စာဖတ်ခြင်းဘောငျ၌ရှိ၏စစ်ဆေးပါ
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // ထို `byte_pos` နှင့်ပတ်သက်။ ကျွန်တော်တို့ရဲ့ယူဆချက်ကိုကိုင်။
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // လုံခြုံမှု-ဘာကြောင့်လဲဆိုတော့ `word_ptr` ဟာမှန်မှန်ကန်ကန်ကိုက်ညီမှုရှိတယ်ဆိုတာငါတို့သိတယ်
        // `align_offset`), ပြီးတော့ `word_ptr` နဲ့ end ကြားက bytes အလုံအလောက်ရှိတယ်ဆိုတာငါတို့သိတယ်
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // လုံခြုံမှု-`byte_pos <= len - USIZE_SIZE` ဆိုတာအဲဒါကိုဆိုလိုတာပါ
        // ဒီ `add` ပြီးနောက်, `word_ptr` အများဆုံးမှာတ ဦး တည်း-အတိတ်-The-အဆုံးဖြစ်လိမ့်မည်။
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // `usize` တစ်ခုသာကျန်တော့တာသေချာသည်။
    // ၎င်းကိုကျွန်ုပ်တို့၏ကွင်းဆက်အခြေအနေဖြင့်အာမခံသင့်သည်။
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // လုံခြုံမှု-ဤအရာသည်အစပိုင်း၌ကျွန်ုပ်တို့စစ်ဆေးသော `len >= USIZE_SIZE` ပေါ်တွင်မူတည်သည်။
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}