//! အချပ်စုစည်းခြင်း
//!
//! ဤ module တွင် Orson Peters ၏ပုံစံကိုအနိုင်ယူသောအမြန်နှုန်းအပေါ် အခြေခံ၍ sorting algorithm ပါဝင်သည်။ <https://github.com/orlp/pdqsort>
//!
//!
//! တည်ငြိမ်သော sorting implementation နှင့်မတူသည်မတည်ငြိမ်သော sorting သည် libcore နှင့်သဟဇာတဖြစ်သည်။
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// ကျဆင်းသွားသည့်အခါ, `src` ကနေ `dest` သို့မိတ္တူ။
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // လုံခြုံမှု-ဒါကအကူအညီပေးတဲ့အတန်းဖြစ်တယ်။
        //          မှန်ကန်မှုအတွက်၎င်း၏အသုံးပြုမှုကိုကိုးကားပါ။
        //          အမည်ဝှက်တစ်ခုအနေဖြင့် `src` နှင့် `dst` သည် `ptr::copy_nonoverlapping` မှလိုအပ်သည့်အတိုင်းထပ်တူကျမှုမရှိကြောင်းသေချာစေရမည်။
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// ပထမ element ကိုညာဘက်သို့ရွှေ့လိုက်သည်နှင့်၎င်းသည်ပိုကြီးသောသို့မဟုတ်တန်းတူညီမျှသော element သို့ရောက်ရှိသည်။
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // လုံခြုံမှု-အောက်ဖော်ပြပါလုံခြုံမှုမရှိသောလုပ်ဆောင်မှုများသည်စစ်ဆေးမှုမပါဘဲရည်ညွှန်းခြင်းပါ ၀ င်သည် (`get_unchecked` နှင့် `get_unchecked_mut`)
    // နှင့်မှတ်ဉာဏ် (`ptr::copy_nonoverlapping`) ကူးယူ။
    //
    // က။indexing:
    //  1. ခင်းကျင်း၏အရွယ်အစားကို>=2 သို့စစ်ဆေးခဲ့သည်။
    //  2. ကြှနျုပျတို့သညျပွုပါမညျမြှသော indexing အရှိဆုံးမှာ {0 <= index < len} အကြားအမြဲဖြစ်ပါတယ်။
    //
    // ခ။မှတ်ဉာဏ်ကူးယူခြင်း
    //  1. ကျွန်ုပ်တို့သည်ခိုင်လုံသောဖြစ်ရန်အာမခံသောကိုးကားချက်များကိုရည်ညွှန်းသည်။
    //  2. ကျွန်တော်တို့ကအချပ်၏ခြားနားချက်ညွှန်းကိန်းကိုညွှန်ပြသောကြောင့်သူတို့ထပ်လို့မရပါဘူး
    //     အမည်, `i` နှင့် `i-1` ။
    //  3. အချပ်စနစ်တကျ alignment ကိုလျှင်, ဒြပ်စင်စနစ်တကျ alignment ကိုနေကြသည်။
    //     အချပ်ကိုစနစ်တကျကိုက်ညီမှုရှိစေရန်ခေါ်ဆိုသူ၏တာဝန်ဖြစ်သည်။
    //
    // နောက်ထပ်အသေးစိတ်အတွက်အောက်တွင်ဖော်ပြထားသောမှတ်ချက်များကိုကြည့်ပါ။
    unsafe {
        // ပထမဦးဆုံးဒြပ်စင်နှစ်မျိုးလုံး Out-of-အလို့ငှာရောက်နေတယ်ဆိုရင် ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // တစ်ဦး stack-ခွဲဝေ variable ကိုသို့ပထမဦးဆုံးဒြပ်စင်ဖတ်ပါ။
            // တစ်ဦးကိုအောက်ပါနှိုင်းယှဉ်စစ်ဆင်ရေး panics လြှငျ, `hole` ကျဆင်းသွားရလိမ့်မည်နှင့်အလိုအလျောက်အချပ်ထဲသို့ဒြပ်စင်ကိုပြန်ရေးပါ။
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // `i`-th element တစ်ခုကိုဘယ်ဘက်သို့ရွှေ့ပြီးအပေါက်ကိုညာဘက်သို့ရွှေ့ပါ။
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` ကျဆင်းသွားခြင်းနှင့်ထို့ကြောင့် `v` အတွက်ကျန်ရှိသောအပေါက်ထဲသို့ `tmp` ကော်ပီကူး။
        }
    }
}

/// နောက်ဆုံး element ကိုသေးငယ်သောသို့မဟုတ်တန်းတူညီမျှသော element သို့မရောက်မှီတိုင်အောင်ဘယ်ဘက်သို့ရွှေ့သည်။
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // လုံခြုံမှု-အောက်ဖော်ပြပါလုံခြုံမှုမရှိသောလုပ်ဆောင်မှုများသည်စစ်ဆေးမှုမပါဘဲရည်ညွှန်းခြင်းပါ ၀ င်သည် (`get_unchecked` နှင့် `get_unchecked_mut`)
    // နှင့်မှတ်ဉာဏ် (`ptr::copy_nonoverlapping`) ကူးယူ။
    //
    // က။indexing:
    //  1. Array ၏အရွယ်အစားကို>=2 သို့စစ်ဆေးခဲ့သည်။
    //  2. ကျွန်တော်တို့လုပ်ပေးတဲ့ indexing အားလုံးဟာအမြဲတမ်း `0 <= index < len-1` အကြားဖြစ်တယ်။
    //
    // ခ။မှတ်ဉာဏ်ကူးယူခြင်း
    //  1. ကျွန်ုပ်တို့သည်ခိုင်လုံသောဖြစ်ရန်အာမခံသောကိုးကားချက်များကိုရည်ညွှန်းသည်။
    //  2. ကျွန်တော်တို့ကအချပ်၏ခြားနားချက်ညွှန်းကိန်းကိုညွှန်ပြသောကြောင့်သူတို့ထပ်လို့မရပါဘူး
    //     အမည်ရ `i` နှင့် `i+1` ။
    //  3. အချပ်စနစ်တကျ alignment ကိုလျှင်, ဒြပ်စင်စနစ်တကျ alignment ကိုနေကြသည်။
    //     အချပ်ကိုစနစ်တကျကိုက်ညီမှုရှိစေရန်ခေါ်ဆိုသူ၏တာဝန်ဖြစ်သည်။
    //
    // နောက်ထပ်အသေးစိတ်အတွက်အောက်တွင်ဖော်ပြထားသောမှတ်ချက်များကိုကြည့်ပါ။
    unsafe {
        // ပြီးခဲ့သည့်ဒြပ်စင်နှစ်မျိုးလုံး Out-of-အလို့ငှာရောက်နေတယ်ဆိုရင် ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // နောက်ဆုံး element ကို stack-allokated variable ထဲသို့ဖတ်ပါ။
            // တစ်ဦးကိုအောက်ပါနှိုင်းယှဉ်စစ်ဆင်ရေး panics လြှငျ, `hole` ကျဆင်းသွားရလိမ့်မည်နှင့်အလိုအလျောက်အချပ်ထဲသို့ဒြပ်စင်ကိုပြန်ရေးပါ။
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // အရှင်လက်ဝဲဖို့အပေါက်ပြောင်းလဲ, ညာဘက် `i`-ကြိမ်မြောက် element ကိုတစ်နေရာတည်းရွှေ့ပါ။
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` ကျဆင်းသွားခြင်းနှင့်ထို့ကြောင့် `v` အတွက်ကျန်ရှိသောအပေါက်ထဲသို့ `tmp` ကော်ပီကူး။
        }
    }
}

/// တစ်စိတ်တစ်ပိုင်းအများအပြား Out-of-အလို့ငှာ element တွေကိုန်းကျင်ပြောင်းလဲနေဖြင့်တစ်ဦးအချပ် sorts ။
///
/// အချပ်ကိုအဆုံးမှာ sorted လျှင် `true` ပြန်သွားသည်။ဒီ function *အို*(*n*) အဆိုးဆုံး-ဖြစ်ပါတယ်။
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // အပြောင်းအလဲဖြစ်လိမ့်မည်ဟုကပ်လျက် Out-of-အမိန့်အားလုံးအတွက်အများဆုံးအရေအတွက်။
    const MAX_STEPS: usize = 5;
    // အချပ်သည်ဤထက်တိုသည်ဆိုပါကမည်သည့်ဒြပ်စင်ကိုမျှမရွှေ့ပါနှင့်။
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // လုံခြုံမှု: ကျနော်တို့ပြီးသားအတိအလင်း `i < len` အတူဘောင်းစစ်ဆေးခြင်းကိုပြု၏။
        // ကျွန်ုပ်တို့၏နောက်ဆက်တွဲရည်ညွှန်းချက်အားလုံးသည် `0 <= index < len` အကွာအဝေးသာဖြစ်သည်
        unsafe {
            // နောက်ကပ်လျက် Out-of-order ဒြပ်စင်၏နောက်ထပ် pair တစုံကိုရှာပါ။
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // ငါတို့ပြီးပြီလား
        if i == len {
            return true;
        }

        // စွမ်းဆောင်ရည်ကုန်ကျစရိတ်ရှိသော Array ကိုတိုသော Array တွင်မပြောင်းပါနှင့်။
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // တွေ့ရှိရသောဒြပ်စင်တစ်စုံကိုလဲလှယ်ပါ။ဤသည်မှန်ကန်သောနိုင်ရန်အတွက်သူတို့ကိုတတ်၏။
        v.swap(i - 1, i);

        // သေးငယ်သောဒြပ်စင်ကိုဘယ်ဘက်သို့ရွှေ့ပါ။
        shift_tail(&mut v[..i], is_less);
        // သာ။ ဒြပ်စင်ကိုညာဘက် Shift ။
        shift_head(&mut v[i..], is_less);
    }

    // အချပ်ကိုကန့်သတ်ထားသောအဆင့်များ ခွဲ၍ မစီမံနိုင်ပါ။
    false
}

/// *O*(*n*^ 2) အဆိုးဆုံးဖြစ်သည့် insertion sort ကို အသုံးပြု၍ အချပ်တစ်ခုကိုခွဲခြားသည်။
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// *O*(*n*\*log(* n*)) ၏အဆိုးဆုံးအခြေအနေကိုအာမခံသော heapsort ကို အသုံးပြု၍ `v` ကိုအမျိုးအစားခွဲသည်)
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // ဒါဟာဒွိအမှိုက်ပုံအတွက်လျော့ပါးသွားမည်ဖြစ်သလို `parent >= child` လေးစားပါသည်။
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // `node` ၏ကလေးများ
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // ကြီးမြတ်သောကလေးကိုရွေးချယ်ပါ။
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // လျော့ပါးသွားမည်ဖြစ်သလို `node` မှာကိုင်ထားလျှင်ရပ်တန့်။
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // သာ. ကလေးနဲ့အတူလဲလှယ်ရေး `node`, တဦးတည်းခြေလှမ်းချရွှေ့နှင့် sifting ဆက်လက်။
            v.swap(node, greater);
            node = greater;
        }
    };

    // linear အချိန်အတွက်အမှိုက်ပုံ Build ။
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // အဆိုပါအမှိုက်ပုံကနေလုပျသငျဒြပ်စင် Pop ။
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// `v` ကို `pivot` ထက်သေးငယ်တဲ့ဒြပ်စင်တွေအဖြစ် X0 `pivot` ကိုအခန်းကန့်များ၊
///
///
/// `pivot` ထက်သေးငယ်တဲ့ element အရေအတွက်ကို return လုပ်တယ်။
///
/// ဌာနခွဲလည်ပတ်မှု၏ကုန်ကျစရိတ်ကိုအနည်းဆုံးဖြစ်စေရန်ခွဲခြမ်းခြင်းအားဖြင့်လုပ်ကွက်တစ်ခုစီပြုလုပ်သည်။
/// ဒါကစိတ်ကူးအဆိုပါ [BlockQuicksort][pdf] စာတမ်းတွင်တင်ပြထားပါသည်။
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // ပုံမှန်ပိတ်ပင်တားဆီးမှုအတွက်ဒြပ်စင်အရေအတွက်။
    const BLOCK: usize = 128;

    // partition ကို algorithm ကိုပြီးစီးသည်အထိအောက်ပါအဆင့်တွေကိုကို repeat:
    //
    // 1. ထက် သာ. ကြီးမြတ်ပါသို့မဟုတ်မဏ္ဍိုင်မှတူညီ element တွေကိုသိရှိနိုင်ဖို့လက်ဝဲဘက်ခြမ်းကနေပိတ်ပင်တားဆီးမှုခြေရာကောက်။
    // 2. မဏ္sideိုင်ထက်သေးငယ်သည့်ဒြပ်စင်များကိုခွဲခြားသတ်မှတ်ရန်ညာဘက်ခြမ်းမှ block ကိုခြေရာကောက်ပါ။
    // 3. ဖော်ထုတ် element တွေကိုဘယ်ဘက်နှင့်ညာဘက်အကြားဖလှယ်။
    //
    // အောက်ပါ variable များကို element တစ်ခုအနေဖြင့်ထားရှိပါသည်။
    //
    // 1. `block` - ပိတ်ပင်တားဆီးမှုအတွက်ဒြပ်စင်အရေအတွက်။
    // 2. `start` - အဆိုပါ `offsets` ခင်းကျင်းသို့ pointer ကိုစတင်ပါ။
    // 3. `end` - pointer ကို `offsets` ခင်းကျင်းထဲသို့အဆုံးသတ်ပါ။
    // 4. `offsets, ပိတ်ပင်တားဆီးမှုအတွင်း Out-of-order ဒြပ်စင်၏ညွှန်းကိန်း။

    // လက်ဝဲဘက်ရှိလက်ရှိပိတ်ပင်တားဆီးမှု (`l` မှ `l.add(block_l)`) သို့)
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // လက်ျာဘက်၌ရှိလက်ရှိပိတ်ပင်တားဆီးမှု (`r.sub(block_r)` to `r`) ကနေ။
    // လုံခြုံမှု-.add() အတွက်စာရွက်စာတမ်းများအရ `vec.as_ptr().add(vec.len())` သည်အမြဲတမ်းလုံခြုံမှုရှိသည်ဟုအထူးဖော်ပြသည်
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: ကျနော်တို့ VLAs ရတဲ့အခါ, `မဟုတ်ဘဲအရှည် `min(v.len() ၏တဦးတည်းခင်းကျင်း, 2 * Block) ကိုဖန်တီးကြိုးစားကြ
    // အရှည် `BLOCK` နှစ်ခုပုံသေအရွယ်အစား Array ကိုထက်။VLA များသည် cache-efficient ဖြစ်နိုင်သည်။

    // pointers `l` (inclusive) နှင့် `r` (exclusive) ကြားရှိ element များ၏နံပါတ်ကိုပြန်သွားသည်။
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // `l` နှင့် `r` အလွန်နီးကပ်သောအခါပိုင်းခြားခြင်းအားဖြင့်ပိတ်ဆို့ခြင်းအားဖြင့်လုပ်သည်။
        // ကျန်ရှိနေသေးသောဒြပ်စင်များကိုအကြားပိုင်းခြားနိုင်ရန်အတွက်ကျွန်ုပ်တို့သည် patch-up အလုပ်အချို့ကိုလုပ်သည်။
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // ကျန်ရှိနေသေးသောဒြပ်စင်အရေအတွက် (မဏ္pိုင်နှင့်နှိုင်း ယှဉ်၍ မရပါ) ။
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // ဘယ်ဘက်နှင့်ညာပိတ်ပင်တားဆီးမှုသည်ထပ်နေခြင်းမရှိစေရန်ဘလောက်အရွယ်အစားကိုချိန်ညှိပါ၊ သို့သော်ကျန်ရှိသောကွက်လပ်တစ်ခုလုံးကိုပြည့်ပြည့်ဝဝကိုက်ညီစေရန်ပြုလုပ်ပါ။
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // လက်ဝဲဘက်ခြမ်းကနေသဲလွန်စ `block_l` ဒြပ်စင်။
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // လုံခြုံမှု-အောက်ဖော်ပြပါလုံခြုံမှုမရှိသောလုပ်ဆောင်မှုများတွင် `offset` ကိုအသုံးပြုခြင်းပါဝင်သည်။
                //         လုပ်ဆောင်ချက်မှလိုအပ်သောအခြေအနေများအရကျွန်ုပ်တို့သည်၎င်းတို့ကိုကျေနပ်သည်။
                //         1. `offsets_l` stack-ခွဲဝေဖြစ်ပြီး, အရှင်သီးခြားခွဲဝေအရာဝတ္ထုဆင်ခြင်၏။
                //         2. `is_less` function သည် `bool` တစ်ခုကိုပြန်ပို့သည်။
                //            `bool` ကိုချခြင်းသည် `isize` နှင့်ဘယ်သောအခါမျှမလျောက်ပါ။
                //         3. `block_l` က `<= BLOCK` ဖြစ်မယ်လို့ကျွန်တော်တို့အာမခံထားတယ်။
                //            ထို့အပြင် `end_l` ကိုအစပိုင်း၌ stack တွင်ကြေငြာခဲ့သော `offsets_` ၏ start pointer ဟုသတ်မှတ်ခဲ့သည်။
                //            ထို့ကြောင့်ကျွန်ုပ်တို့သည်အဆိုးဆုံးကိစ္စတွင် (`is_less` ၏ invocations အားလုံးမှားယွင်းစွာပြန်လာခဲ့သည်) တွင်ကျွန်ုပ်တို့သည်အနည်းဆုံး 1 byte အဆုံးကိုကျော်သွားလိမ့်မည်ဟုကျွန်ုပ်တို့သိထားကြသည်။
                //        ဒီမှာလုံခြုံမှုမရှိတဲ့နောက်ထပ်လုပ်ဆောင်မှုတစ်ခုကတော့ `elem` ကို dereferencing လုပ်တာပါ။
                //        သို့သော် `elem` သည်အစပိုင်းတွင်တရားဝင်ဖြစ်သော slice ကိုစတင်ညွှန်ပြသည်။
                unsafe {
                    // ဌာနခွဲမရှိနှိုင်းယှဉ်မှု။
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // `block_r` element တွေကိုညာဘက်ခြမ်းမှာထားပါ။
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // လုံခြုံမှု-အောက်ဖော်ပြပါလုံခြုံမှုမရှိသောလုပ်ဆောင်မှုများတွင် `offset` ကိုအသုံးပြုခြင်းပါဝင်သည်။
                //         လုပ်ဆောင်ချက်မှလိုအပ်သောအခြေအနေများအရကျွန်ုပ်တို့သည်၎င်းတို့ကိုကျေနပ်သည်။
                //         1. `offsets_r` stack-ခွဲဝေဖြစ်ပြီး, အရှင်သီးခြားခွဲဝေအရာဝတ္ထုဆင်ခြင်၏။
                //         2. `is_less` function သည် `bool` တစ်ခုကိုပြန်ပို့သည်။
                //            `bool` ကိုချခြင်းသည် `isize` နှင့်ဘယ်သောအခါမျှမလျောက်ပါ။
                //         3. `block_r` က `<= BLOCK` ဖြစ်မယ်လို့ကျွန်တော်တို့အာမခံထားတယ်။
                //            ထို့အပြင် `end_r` ကိုအစပိုင်း၌ stack တွင်ကြေငြာခဲ့သော `offsets_` ၏ start pointer ဟုသတ်မှတ်ခဲ့သည်။
                //            ထို့ကြောင့်ကျွန်ုပ်တို့သည်အဆိုးဆုံးအခြေအနေ၌ (`is_less` ၏ invocations အားလုံးသည်ပြန်လည်ရောက်ရှိလာသည်) တွင်ကျွန်ုပ်တို့သည်အနည်းဆုံး 1 byte အဆုံးကိုကျော်သွားလိမ့်မည်ဟုကျွန်ုပ်တို့သိထားကြသည်။
                //        ဒီမှာလုံခြုံမှုမရှိတဲ့နောက်ထပ်လုပ်ဆောင်မှုတစ်ခုကတော့ `elem` ကို dereferencing လုပ်တာပါ။
                //        သို့သော် `elem` သည်အဆုံး၌အစပိုင်းတွင် `1 *sizeof(T)` ဖြစ်ခဲ့သည်။ ကျွန်ုပ်တို့သည်၎င်းကိုမ ၀ င်မီ `1* sizeof(T)` ဖြင့်လျှော့ချခဲ့သည်။
                //        ထို့အပြင် `block_r` သည် `BLOCK` ထက်လျော့နည်းသည်ဟုအခိုင်အမာပြောဆိုခဲ့ပြီး `elem` သည်အရှိဆုံးအပိုင်းအစ၏အစကိုညွှန်ပြလိမ့်မည်။
                unsafe {
                    // ဌာနခွဲမရှိနှိုင်းယှဉ်မှု။
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // လက်ဝဲနှင့်လက်ျာဘက်၌အကြားလဲလှယ်ဖို့ Out-of-အလို့ငှာဒြပ်စင်အရေအတွက်။
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // အစားတစ်ကြိမ် pair တစုံဖလှ၏, တကသိသိ permutation ဖျော်ဖြေဖို့ကပိုထိရောက်ဖြစ်ပါတယ်။
            // ၎င်းသည်ဖလှယ်မှုနှင့်လုံးဝမတူပါ၊ သို့သော်နည်းသောမှတ်ဉာဏ်လည်ပတ်မှုများကို အသုံးပြု၍ အလားတူရလဒ်ကိုရရှိသည်။
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // လက်ဝဲပိတ်ပင်တားဆီးမှုရှိ Out-of-order ဒြပ်စင်များပြောင်းရွှေ့ခံခဲ့ရသည်။လာမည့်ပိတ်ပင်တားဆီးမှုသို့ရွှေ့ပါ။
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // မှန်ကန်သောပိတ်ပင်တားဆီးမှုရှိအစဉ်လိုက်အချည်းနှီးသောဒြပ်စင်များအားလုံးရွှေ့ပြောင်းခဲ့သည်။ယခင်ပိတ်ပင်တားဆီးမှုသို့ရွှေ့ပါ။
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // ယခုကျန်ရှိနေသေးသောအရာအားလုံးသည်ရွေ့လျားရန်လိုအပ်သည့်ချွတ်ယွင်းချက်ရှိသောဒြပ်စင်များနှင့်အတူအများဆုံးတစ်ခု (လက်ဝဲဘက် (သို့) ညာ) တစ်ခုခုဖြစ်သည်။
    // ထိုကဲ့သို့သောကျန်ရှိနေသေးသောဒြပ်စင်များကိုသူတို့၏ပိတ်ပင်တားဆီးမှုအတွင်းအဆုံးသို့ရွှေ့ပြောင်းနိုင်သည်။
    //

    if start_l < end_l {
        // ဘယ်ဘက်ပိတ်ပင်တားဆီးမှုနေဆဲဖြစ်သည်။
        // ၎င်း၏ကျန်ရှိသော Out-of-Order ဒြပ်စင်များကိုလက်ျာဘက်သို့ရွှေ့ပါ။
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // လက်ျာပိတ်ပင်တားဆီးမှုနေဆဲဖြစ်သည်။
        // ၎င်း၏ကျန်ရှိသော Out-of-order ဒြပ်စင်ကိုဘယ်ဘက်သို့ရွှေ့ပါ။
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // လုပ်စရာဘာမှမရှိဘူး၊ ငါတို့ပြီးပြီ။
        width(v.as_mut_ptr(), l)
    }
}

/// `v` ကို `v[pivot]` ထက်သေးငယ်တဲ့ဒြပ်စင်တွေအဖြစ် X0 `v[pivot]` ကိုအခန်းကန့်များ၊
///
///
/// တစ် ဦး tuple Returns:
///
/// 1. `v[pivot]` ထက်သေးငယ်တဲ့ဒြပ်စင်အရေအတွက်။
/// 2. အကယ်၍ `v` ကိုအခန်းကန့်ခွဲထားပြီးလျှင်
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // အချပ်၏အစအ ဦး တွင်မဏ္pိုင်ကိုချထားပါ။
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // ထိရောက်မှုအတွက် stiv-allokated variable ထဲသို့မဏ္pိုင်ကိုဖတ်ပါ။
        // အောက်ပါနှိုင်းယှဉ်ပါက panics ဆိုပါကမဏ္ivိုင်သည်အလိုအလျောက်ပြန်လည်ချရေးပေးလိမ့်မည်။
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Out-of-order element တွေရဲ့ပထမဆုံးအတွဲကိုရှာပါ။
        let mut l = 0;
        let mut r = v.len();

        // လုံခြုံမှု-အောက်မှာဖော်ပြထားတဲ့မလုံခြုံမှုက array တစ်ခုကို indexing လုပ်ခြင်းဖြစ်တယ်။
        // ပထမတစ်ခုအတွက်-`l < r` နှင့်ဤနေရာတွင်စစ်ဆေးမှုများကိုပြုလုပ်ထားပြီးဖြစ်သည်။
        // ဒုတိယတစ်ခုအတွက်-ကျွန်ုပ်တို့သည်ကန ဦး ၌ `l == 0` နှင့် `r == v.len()` ရှိပြီး၊ `l < r` ကို indexing operation တိုင်း၌စစ်ဆေးခဲ့သည်။
        //                     ဒီကနေကျွန်ုပ်တို့သည် `r` သည်အနည်းဆုံး `r == l` ဖြစ်ရမယ်၊ ပထမတစ်ခုမှမှန်ကန်ကြောင်းပြသသည်။
        unsafe {
            // ထက်ကြီးသောသို့မဟုတ်ညီမျှသောပထမဆုံး element ကိုရှာပါ။
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // ယင်းမဏ္ဍိုင်ကြောင်းသေးငယ်သည်လွန်ခဲ့သောဒြပ်စင်ကိုရှာပါ။
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` နယ်ပယ်ထဲကထွက်သွားပြီး pivot (stack-allokated variable တစ်ခုဖြစ်တဲ့) ကိုမူလကရှိခဲ့တဲ့အချပ်ထဲကိုပြန်ထည့်လိုက်တယ်။
        // ဒါဟာခြေလှမ်းဘေးကင်းလုံခြုံမှုသေချာအတွက်အရေးပါသည်!
        //
    };

    // နှစ်ခုအခန်းကန့်များအကြားမဏ္pိုင်ထားပါ။
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// `v[pivot]` မှတူညီဒြပ်စင်သို့ partitions `v` `v[pivot]` ထက် သာ. ကြီးမြတ်ဒြပ်စင်ခြင်းဖြင့်နောက်သို့လိုက်ကြ၏။
///
/// element ရဲ့နံပါတ်ကို pivot နှင့်ညီသည်။
/// `v` တွင်မပါသောဒြပ်စင်များမပါ ၀ င်ဟုယူဆရသည်။
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // အချပ်၏အစအ ဦး တွင်မဏ္pိုင်ကိုချထားပါ။
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // ထိရောက်မှုအတွက် stiv-allokated variable ထဲသို့မဏ္pိုင်ကိုဖတ်ပါ။
    // အောက်ပါနှိုင်းယှဉ်ပါက panics ဆိုပါကမဏ္ivိုင်သည်အလိုအလျောက်ပြန်လည်ချရေးပေးလိမ့်မည်။
    // လုံခြုံမှု-ဤနေရာတွင်ညွှန်ပြသည်မှန်ကန်သည်။ အဘယ်ကြောင့်ဆိုသော်၎င်းသည်အချပ်ကိုရည်ညွှန်းချက်မှရရှိသောကြောင့်ဖြစ်သည်။
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // အခုတော့အချပ် partitioner က။
    let mut l = 0;
    let mut r = v.len();
    loop {
        // လုံခြုံမှု-အောက်မှာဖော်ပြထားတဲ့မလုံခြုံမှုက array တစ်ခုကို indexing လုပ်ခြင်းဖြစ်တယ်။
        // ပထမတစ်ခုအတွက်-`l < r` နှင့်ဤနေရာတွင်စစ်ဆေးမှုများကိုပြုလုပ်ထားပြီးဖြစ်သည်။
        // ဒုတိယတစ်ခုအတွက်-ကျွန်ုပ်တို့သည်ကန ဦး ၌ `l == 0` နှင့် `r == v.len()` ရှိပြီး၊ `l < r` ကို indexing operation တိုင်း၌စစ်ဆေးခဲ့သည်။
        //                     ဒီကနေကျွန်ုပ်တို့သည် `r` သည်အနည်းဆုံး `r == l` ဖြစ်ရမယ်၊ ပထမတစ်ခုမှမှန်ကန်ကြောင်းပြသသည်။
        unsafe {
            // မဏ္pိုင်ထက်သာလွန်သောပထမဆုံး element ကိုရှာပါ။
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // နောက်ဆုံးဒြပ်စင်ကိုမဏ္ivိုင်နှင့်တူညီသည်ကိုရှာပါ။
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // ငါတို့ပြီးပြီလား
            if l >= r {
                break;
            }

            // Out-of-Order ဒြပ်စင်များကိုရှာဖွေသည်။
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // `l` element တွေကို pivot နဲ့ညီမျှတယ်။မဏ္pိုင်ကိုယ်တိုင်အတွက်အကောင့်သို့ ၁ ထည့်ပါ။
    l + 1

    // `_pivot_guard` နယ်ပယ်ထဲကထွက်သွားပြီး pivot (stack-allokated variable တစ်ခုဖြစ်တဲ့) ကိုမူလကရှိခဲ့တဲ့အချပ်ထဲကိုပြန်ထည့်လိုက်တယ်။
    // ဒါဟာခြေလှမ်းဘေးကင်းလုံခြုံမှုသေချာအတွက်အရေးပါသည်!
}

/// quicksort တွင်အချိုးမညီသောအခန်းကန့်များဖြစ်ပေါ်စေနိုင်သည့်ပုံစံများကိုချိုးဖျက်ရန်အတွက် element အချို့ကိုပတ်ပတ်လည်တွင်ဖြန့်ကျက်သည်။
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // ဂျော့ခ်ျ Marsaglia အားဖြင့် "Xorshift RNGs" စက္ကူကနေ Pseudorandom နံပါတ်မီးစက်။
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // ကျပန်းနံပါတ်များကိုဒီနံပါတ်ကို modulo ယူပါ။
        // `len` သည် `isize::MAX` ထက်မကြီးသောကြောင့်ဤနံပါတ်သည် `usize` နှင့်ကိုက်ညီသည်။
        let modulus = len.next_power_of_two();

        // တချို့ကမဏ္ဍိုင်ကိုယ်စားလှယ်လောင်းများကဤညွှန်းကိန်းများအနီးအနား၌ဖြစ်လိမ့်မည်။သူတို့ကို random လုပ်ကြပါစို့။
        let pos = len / 4 * 2;

        for i in 0..3 {
            // ကျပန်းနံပါတ်တစ်ခု modulo `len` Generate ။
            // သို့သျောလညျး, အဘိုးထိုက်သောစစ်ဆင်ရေးကိုရှောင်ရှားနိုင်ရန်အတွက်ကျနော်တို့ပထမဦးဆုံးကနှစ်ဦး၏အာဏာ modulo ယူ, ပြီးတော့ကအကွာအဝေး `[0, len - 1]` သို့ကိုက်ညီသည်အထိ `len` အားဖြင့်လျော့ကျသွားသည်။
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` `2 * len` ထက်လျော့နည်းစေရန်အာမခံထားသည်။
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// `v` ရှိမဏ္pိုင်တစ်ခုကိုရွေးချယ်ပြီးအချပ်ကိုစီပြီးသားဖြစ်လျှင်အညွှန်းနှင့် `true` ကိုပြန်လည်ပေးသည်။
///
/// `v` အတွက်ဒြပ်စင်လုပ်ငန်းစဉ်များတွင် reordered ခံရပေလိမ့်မည်။
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // ပျမ်းမျှ-of ပျမ်းမျှနည်းလမ်းရွေးချယ်ဖို့အနည်းဆုံးအရှည်။
    // တိုတောင်းချပ်ရိုးရှင်းသောပျမ်းမျှ-of သုံးနည်းလမ်းကိုအသုံးပြုပါ။
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // ဒီ function ကိုဖျော်ဖြေနိုင်လဲလှယ်ရေးအစီအစဉ်တွေကိုအများဆုံးအရေအတွက်သည်။
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // ကျနော်တို့မဏ္ivိုင်ကိုရွေးချယ်သွားမည့်အနီးရှိအညွှန်းကိန်းသုံးခု။
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // ကျွန်တော်ညွှန်းကိန်း sorting စဉ်ဖျော်ဖြေဖို့အကြောင်းကိုများမှာလဲလှယ်ရေးအစီအစဉ်တွေကိုစုစုပေါင်းအရေအတွက်ကမှတ်တော်မူ၏။
    let mut swaps = 0;

    if len >= 8 {
        // ဒါကြောင့် `v[a] <= v[b]` ဒါညွှန်းကိန်းဖလှယ်မှု။
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // ဒါကြောင့် `v[a] <= v[b] <= v[c]` အညွှန်းကိန်းဖလှယ်မှု။
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // `v[a - 1], v[a], v[a + 1]` ၏ပျမ်းမျှရှာပြီး `a` သို့အညွှန်းကိန်းသိုလှောင်ပါသည်။
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // `a`, `b` နှင့် `c` ၏ရပ်ကွက်များ၌ပျမ်းမျှများကိုရှာပါ။
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // `a`, `b` နှင့် `c` ကြားတွင်ပျမ်းမျှကိုရှာပါ။
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // လဲလှယ်ရေးအစီအစဉ်တွေကိုအများဆုံးအရေအတွက်ကဖျော်ဖြေခဲ့သည်။
        // အခွင့်အလမ်းဟာအချပ်ကဆင်းသို့မဟုတ်အများအားဖြင့်ဆင်း, ဖြစ်ကြပြီး, ဒါကြောင့်နောက်ပြန်ဆုတ်ပိုမိုမြန်ဆန် sort ဖို့ကူညီပေးပါမည်။
        v.reverse();
        (len - 1 - b, true)
    }
}

/// `v` တဲ့ request ကို Sorts ။
///
/// အကယ်၍ အချပ်သည်မူလခင်းကျင်းချက်တွင်ယခင်ရှိခဲ့လျှင်၎င်းကို `pred` ဟုသတ်မှတ်သည်။
///
/// `limit` `heapsort` သို့ပြောင်းခြင်းမပြုမီခွင့်ပြုချက်မညီမျှမှုအခန်းကန့်များ၏နံပါတ်ဖြစ်ပါတယ်။
/// သုညလျှင်ဤ function ကိုချက်ချင်း heapsort ပြောင်းရန်ပါလိမ့်မယ်။
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // ဒီအရှည်အထိအချပ် insertion မျိုးကိုအသုံးပြု။ ခွဲခြားရ။
    const MAX_INSERTION: usize = 20;

    // နောက်ဆုံး partition ကိုကျိုးကြောင်းဆီလျော်ဟန်ချက်ညီခဲ့သည်မှန်လျှင်။
    let mut was_balanced = true;
    // စစ်မှန်သောပြီးခဲ့သည့်ပိုင်ခြားဒြပ်စင် (ထိုအချပ်ပြီးသား partitioned ခဲ့ပါတယ်) မွှေမပြုခဲ့ပါ။
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // အလွန်တိုတောင်းသောအချပ် insertion မျိုးကိုအသုံးပြုပြီးရ။
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // အကယ်၍ မကောင်းသောမဏ္choicesိုင်ရွေးချယ်မှုများစွာကိုလုပ်ခဲ့ပါက `O(n * log(n))` ၏အဆိုးဆုံးအခြေအနေကိုအာမခံနိုင်ရန် heapsort သို့ပြန်သွားပါ။
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // အကယ်၍ နောက်ဆုံးအခန်းကန့်ကိုမျှတမှုမရှိခဲ့လျှင်အချို့သောအရာဝတ္ထုများကိုရွှေ့ခြင်းအားဖြင့်အချပ်တွင်ပုံစံများကိုချိုးဖောက်ပါ။
        // မျှော်လင့်ကျွန်တော်ပိုကောင်းတဲ့မဏ္ဍိုင်ဤအချိန်ကိုရွေးချယ်ပါလိမ့်မယ်။
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // မဏ္ivိုင်တစ်ခုကိုရွေးချယ်ပြီးအချပ်ကိုစီပြီးသားဟုတ်မဟုတ်ကိုခန့်မှန်းပါ။
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // အကယ်၍ နောက်ဆုံးအခန်းကန့်သည်လျောက်ပတ်စွာဟန်ချက်ညီပြီးဒြပ်စင်ကိုမရောနှောပါက၊ မဏ္selectionိုင်ရွေးချယ်မှုကအချပ်ကိုခွဲထားပြီးပြီဟုခန့်မှန်းပါက ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Out-of-order element များကိုဖော်ထုတ်ပြီးရာထူးများကိုပြင်ရန်ကြိုးစားပါ။
            // အချပ်ကိုလုံးဝ sorted ခံရအဆုံးသတ်လျှင်, ငါတို့ပြီးပြီ။
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // ရွေးကောက်တော်မူသောမဏ္ဍိုင်ဟာသူ့အရင်ထွက်ခဲ့တဲ့ညီမျှသည်ဆိုပါက, ထို့နောက်ကအချပ်ထဲမှာအသေးငယ်ဆုံးဒြပ်စင်ဖြစ်ပါသည်။
        // အချပ်ကိုညီမျှသောဒြပ်စင်များနှင့်မတူသောဒြပ်စင်များအဖြစ်ပိုင်းပါ။
        // အဆိုပါအချပ်အများအပြားထပ်အစိတ်အပိုင်းများပါဝင်နေသောအခါဤကိစ္စတွင်များသောအားဖြင့်ဝင်တိုက်သည်။
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // မဏ္pိုင်ထက်ပိုကြီးသောဒြပ်စင်များကို ဆက်၍ ဆက်ပါ။
                v = &mut { v }[mid..];
                continue;
            }
        }

        // အချပ် partition ကို။
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // အချပ်ကို `left`, `pivot` နှင့် `right` သို့ခွဲပါ။
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // ထပ်ခါတလဲလဲခေါ်ဆိုမှုစုစုပေါင်းကိုအနည်းဆုံးနှင့်နည်းနည်း stack အာကာသစားသုံးရန်သာတိုတောင်းဘက်သို့ပြန်သွားပါ။
        // ထို့နောက်ပိုမိုရှည်လျားသောဘက်ကိုဆက်သွားပါ (ဤသည်မှာအမြီးပြန်လည်စီးဆင်းမှုနှင့်ဆင်တူသည်) ။
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// `v` ကို *O*(*n*\*log(* n*)) အဆိုးဆုံး-ဖြစ်သည့်ပုံစံ-အနိုင်ယူသောအမြန်ပို့ခြင်းဖြင့်အသုံးပြုသည်။)
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Sorting သည်သုညအရွယ်အမျိုးအစားများတွင်အဓိပ္ပါယ်မရှိသောအပြုအမူများမရှိပါ။
    if mem::size_of::<T>() == 0 {
        return;
    }

    // မျှတမှုမရှိသောအခန်းကန့်များအရေအတွက်ကို `floor(log2(len)) + 1` ကန့်သတ်ပါ။
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // ဒီအရှည်အထိ၏ချပ်ဘို့ကရိုးရိုးမျိုးသူတို့ကိုဖြစ်ကောင်းပိုမြန်ပါတယ်။
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // မဏ္pိုင်တစ်ခုကိုရွေးပါ
        let (pivot, _) = choose_pivot(v, is_less);

        // ရွေးကောက်တော်မူသောမဏ္ဍိုင်ဟာသူ့အရင်ထွက်ခဲ့တဲ့ညီမျှသည်ဆိုပါက, ထို့နောက်ကအချပ်ထဲမှာအသေးငယ်ဆုံးဒြပ်စင်ဖြစ်ပါသည်။
        // အချပ်ကိုညီမျှသောဒြပ်စင်များနှင့်မတူသောဒြပ်စင်များအဖြစ်ပိုင်းပါ။
        // အဆိုပါအချပ်အများအပြားထပ်အစိတ်အပိုင်းများပါဝင်နေသောအခါဤကိစ္စတွင်များသောအားဖြင့်ဝင်တိုက်သည်။
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // ငါတို့ညွှန်းကိန်းကိုကျော်သွားပြီဆိုရင်ငါတို့ကောင်းတယ်။
                if mid > index {
                    return;
                }

                // သို့မဟုတ်ပါကမဏ္elementsိုင်ထက်ပိုကြီးသောဒြပ်စင်များကို ဆက်၍ ဆက်ပါ။
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // အချပ်ကို `left`, `pivot` နှင့် `right` သို့ခွဲပါ။
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // mid==index ဆိုလျှင်၊ partition() က mid ပြီးနောက်အရာအားလုံးသည် mid ထက်ကြီးသည်သို့မဟုတ်ညီမျှသည်ဟုအာမခံသောကြောင့်ဖြစ်သည်။
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Sorting သည်သုညအရွယ်အမျိုးအစားများတွင်အဓိပ္ပါယ်မရှိသောအပြုအမူများမရှိပါ။ဘာမျှလုပ်ပါ။
    } else if index == v.len() - 1 {
        // max element ကိုရှာပြီး array ၏နောက်ဆုံးအနေအထားတွင်ထားပါ။
        // ငါတို့ဒီမှာ v `unwrap()` ကိုသုံးနိုင်သည်။ ဘာကြောင့်လဲဆိုတော့ v သည်ဗလာမဖြစ်သင့်ဘူးဆိုတာငါတို့သိတယ်
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // min element ကိုရှာပြီး၎င်းကို array ၏ပထမဆုံးနေရာတွင်ထားပါ။
        // ငါတို့ဒီမှာ v `unwrap()` ကိုသုံးနိုင်သည်။ ဘာကြောင့်လဲဆိုတော့ v သည်ဗလာမဖြစ်သင့်ဘူးဆိုတာငါတို့သိတယ်
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}