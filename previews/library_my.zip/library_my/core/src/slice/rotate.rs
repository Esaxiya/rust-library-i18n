// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// `[mid-left, mid+right)` အကွာအဝေးကိုလှည့ ်၍ `mid` ရှိဒြပ်စင်သည်ပထမဆုံးဒြပ်စင်ဖြစ်လာသည်။ညီမျှ, လက်ျာဘက်လက်ဝဲသို့မဟုတ် `right` ဒြပ်စင်ရန်အကွာအဝေး `left` element တွေကိုလှည့်။
///
/// # Safety
///
/// သတ်မှတ်ထားသောအကွာအဝေးစာဖတ်ခြင်းနှင့်ရေးသားခြင်းများအတွက်တရားဝင်ဖြစ်ရမည်။
///
/// # Algorithm
///
/// Algorithm 1 ကို `left + right` ၏တန်ဖိုးများအတွက်သို့မဟုတ်ကြီးမားသော `T` အတွက်အသုံးပြုသည်။
/// `mid - left` မှစတင်ပြီး `right` အဆင့်များ modulo `left + right` အားဖြင့်ဒြပ်စင်များကိုသူတို့၏နောက်ဆုံးရာထူးများသို့တစ်ကြိမ်ပြောင်းရွှေ့သည်။ ဥပမာယာယီတစ်ခုသာလိုအပ်သည်။
/// နောက်ဆုံးတွင်ကျွန်ုပ်တို့သည် `mid - left` သို့ပြန်လာခဲ့သည်။
/// သို့သော် `gcd(left + right, right)` သည် 1 မဟုတ်ပါက၊ အထက်ပါအဆင့်များသည် element များကိုကျော်သွားသည်။
/// ဥပမာ:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// ကံကောင်းထောက်မစွာ, အပြီးသတ်ဒြပ်စင်များအကြားကျော်ကျော်ကျော်ကျော်ကျော်အရေအတွက်ကျော်အမြဲတန်းတူဖြစ်တယ်, ဒါကြောင့်ကျနော်တို့ကကျွန်တော်တို့ရဲ့စတင်အနေအထားကိုထေမိရုံပိုမိုကျည်လုပ်နိုင်ပါတယ် (ကျည်စုစုပေါင်းအရေအတွက်က `gcd(left + right, right)` value) ဖြစ်ပါတယ်။
///
/// နောက်ဆုံးရလဒ်မှာ element များအားတစ်ကြိမ်တည်းနှင့်တစ်ကြိမ်တည်းသာအပြီးသတ်ခြင်းဖြစ်သည်။
///
/// Algorithm 2 ကို `left + right` ကြီးသည်ဆိုပါက `min(left, right)` သည် stack buffer ပေါ်သို့အလုံအလောက်သေးငယ်လျှင်အသုံးပြုသည်။
/// `min(left, right)` ဒြပ်စင်များကိုကြားခံသို့ကူးယူသည်၊ `memmove` ကိုအခြားသူများနှင့်သက်ဆိုင်သည်၊ ကြားခံရှိအရာဝတ္ထုများသည်သူတို့မူလ၏ဆန့်ကျင်ဘက်ဘက်ရှိအပေါက်ထဲသို့ပြန်သွားသည်။
///
/// vectorized နိုင် Algorithms `left + right` အလုံအလောက်ကြီးမားသောဖြစ်လာသည်နှင့်တပြိုင်နက်အထက်ပါထက်သာလွန်သည်။
/// Algorithm 1 ကိုတစ်ပြိုင်နက်တည်းကြိမ်ဖန်များစွာပြုလုပ်ခြင်းနှင့်ဖျော်ဖြေခြင်းဖြင့် vectorized လုပ်နိုင်သည်။ သို့သော် `left + right` ကြီးမားသည်အထိပျမ်းမျှအကြိမ်အနည်းငယ်မျှသာလုပ်နိုင်သည်။ တစ်ခုတည်းသောအလှည့်အပြောင်းတစ်ခု၏အဆိုးရွားဆုံးကိစ္စမှာအမြဲရှိသည်။
/// သေးငယ်လှည့်ပြproblemနာကျန်ကြွင်းသည်အစားအစား, algorithm ကို 3 `min(left, right)` ဒြပ်စင်၏ထပ်ခါတလဲလဲလဲလှယ်အသုံးပြုသည်။
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// လာသောအခါ `left < right` အဆိုပါအလွယ်တကူပြောင်းလဲအသုံးပြုနိုင်စေရန်အစားလက်ဝဲကနေဖြစ်လာတယ်။
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. ဤအမှုများကို check လုပ်ထားကြသည်မဟုတ်လျှင်အောက်ပါ algorithms ပျက်ကွက်နိုင်ပါတယ်
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algorithm 1 Microbenchmarks ကကျပန်းဆိုင်းများအတွက်ပျှမ်းမျှစွမ်းဆောင်ရည်သည် `left + right == 32` လောက်အထိသာလွန်ကောင်းမွန်ကြောင်းဖော်ပြသည်၊ သို့သော်အဆိုးဆုံးလုပ်ဆောင်မှုမှာ ၁၆ ခုဝန်းကျင်ပင်ကျသည်။
            // 24 အလယ်တန်းမြေအဖြစ်ရွေးချယ်ခဲ့သည်။
            // `T` ၏အရွယ်အစား 4 `usize`s ထက်ပိုကြီးတဲ့ဖြစ်တယ်ဆိုရင်, ဒီ algorithm ကိုအခြား algorithms outperforms ။
            //
            //
            let x = unsafe { mid.sub(left) };
            // ပထမ ဦး ဆုံးအလှည့်လည်၏အစ
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` `gcd(left + right, right)` တွက်ချက်ခြင်းအားဖြင့်လက်ကိုအရင်တွေ့နိုင်ပါတယ်။ ဒါပေမယ့် gcd ကိုဘေးထွက်ဆိုးကျိုးအဖြစ်တွက်ချက်ပြီးရင်ကျန်အပိုင်းတွေကိုလုပ်ဖို့ loop တစ်ခုလုပ်ဖို့ပိုမြန်တယ်။
            //
            //
            let mut gcd = right;
            // စံသတ်မှတ်ချက်များအရယာယီတစ်ခုအားတစ်ကြိမ်ဖတ်ခြင်း၊ နောက်သို့ကူးခြင်းနှင့်၎င်းကိုအဆုံးတွင်ယာယီရေးသားခြင်းအစားယာယီအားတစ်ဆင့်ပြောင်းလဲခြင်းသည်ပိုမိုမြန်ကြောင်းဖော်ပြသည်။
            // အကြောင်းမှာယာယီနေရာချထားခြင်းများကိုလဲလှယ်ခြင်း (သို့) အစားထိုးခြင်းသည်နှစ်ခုကိုစီမံရန်မလိုအပ်ဘဲကွင်းဆက်အတွင်းရှိမှတ်ဉာဏ်လိပ်စာတစ်ခုတည်းကိုသာအသုံးပြုခြင်းကြောင့်ဖြစ်နိုင်သည်။
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // အစား `i` incrementing ပြီးတော့ကဘောငျအပြင်ဘက်လျှင် `i` လာမည့် increment ပေါ်တွင်မှတ်သားအပြင်ဘက်သို့သွားပါလိမ့်မယ်လျှင်, ငါတို့သည်စစ်ဆေးစစ်ဆေးနေ၏။
                // ဤသည်ထောက်ပြသို့မဟုတ် `usize` ၏မည်သည့်ထုပ်ပိုးမှုကိုကာကွယ်ပေးသည်။
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // ပထမ ဦး ဆုံးအလှည့်လည်၏အဆုံး
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // `left + right >= 15` လျှင်ဒီခြွင်းချက်ကဒီမှာဖြစ်ရပါမည်
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // ပိုပြီးကျည်နှင့်အတူအတုံးကိုပြီးအောင်
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` ၎င်း၏အရွယ်အစားအားဖြင့်ကိုဝေမှအဆင်ပြေမယ့်ဒါတစ်သုညအရွယ်အစားအမျိုးအစားမဟုတ်ပါဘူး။
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algorithm 2 ဤနေရာတွင် `[T; 0]` သည်၎င်းကို T နှင့်သင့်လျော်စွာကိုက်ညီစေရန်ဖြစ်သည်
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algorithm 3 အခြား algorithm များလဲခြင်းဖြင့်ဒီ algorithm ရဲ့နောက်ဆုံး swap ကိုဘယ်မှာရှာမလဲဆိုတာနှင့်ဒီ algorithm လုပ်နေတာနဲ့တူသောကပ်လျက်အပိုင်းအစများကိုလဲလှယ်မည့်အစားထိုနောက်ဆုံး chunk ကိုသုံးပြီးလဲလှယ်ခြင်းပါ ၀ င်သော်လည်းဒီနည်းလမ်းသည်ပိုမိုမြန်ဆန်သည်။
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algorithm 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}