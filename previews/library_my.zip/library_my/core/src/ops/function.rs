/// မပြောင်းလဲနိုင်သောအရာများရှိသည့်ခေါ်ဆိုမှုအော်ပရေတာ၏မူကွဲ။
///
/// `Fn` ၏ဖြစ်ရပ်များကိုအခြေအနေပြောင်းလဲခြင်းမရှိပဲထပ်တလဲလဲခေါ်နိုင်သည်။
///
/// *ဤ trait (`Fn`) ကို [function pointers] (`fn`) နှင့်မရောထွေးပါနှင့်။*
///
/// `Fn` သိမ်းဆည်းထားသည့် variable များကိုမပြောင်းလဲနိုင်သောအရာများသာရိုက်ကူးခြင်းသို့မဟုတ်လုံးဝကိုလုံးဝမဖမ်းယူနိုင်သည့်ပိတ်ထားခြင်းများနှင့်အလိုအလျောက်အကောင်အထည်ဖော်သည် ((safe) [function pointers])(အချို့အချက်အလက်များနှင့်အတူ၊ သူတို့၏အသေးစိတ်အချက်အလက်များကိုကြည့်ပါ။)
///
/// ထို့အပြင်လည်း `Fn` အကောင်အထည်ဖော်ဆောင်ရွက်နေသောဆိုအမျိုးအစား `F`, `&F` သုံးကိရိယာ `Fn` များအတွက်။
///
/// [`FnMut`] နှင့် [`FnOnce`] နှစ်ခုစလုံးသည် `Fn` ၏ထူးကဲသောကြောင့် `Fn` ၏မည်သည့်ဥပမာကိုမဆို [`FnMut`] သို့မဟုတ် [`FnOnce`] မျှော်လင့်ထားသည့် parameter တစ်ခုအဖြစ်အသုံးပြုနိုင်သည်။
///
/// X-`Fn` ကို function-type အမျိုးအစား parameter တစ်ခုလက်ခံလိုလျှင်၎င်းကိုထပ်ခါတလဲလဲနှင့် mutating state (ဥပမာ-တစ်ပြိုင်နက်တည်းခေါ်ဆိုသောအခါ) တွင်ခေါ်ဆိုရန်လိုသည့်အခါအကန့်အသတ်ဖြင့်သာသုံးပါ။
/// အကယ်၍ သင်သည်ထိုကဲ့သို့သောတင်းကျပ်သောလိုအပ်ချက်များကိုမလိုအပ်ပါက [`FnMut`] သို့မဟုတ် [`FnOnce`] ကို bounds အဖြစ်သုံးပါ။
///
/// ဤအကြောင်းအရာနှင့် ပါတ်သက်၍ နောက်ထပ်သတင်းအချက်အလက်များအတွက် [chapter on closures in *The Rust Programming Language*][book] ကိုကြည့်ပါ။
///
/// `Fn` traits အတွက်အထူး syntax (ဥပမာဥပမာ
/// `Fn(usize, bool) -> usize`) ။ဤနည်းပညာ၏အသေးစိတ်အချက်အလက်များကိုစိတ်ဝင်စားသူများသည် [the relevant section in the *Rustonomicon*][nomicon] ကိုရည်ညွှန်းနိုင်သည်။
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## ပိတ်ပွဲခေါ်ဆိုခြင်း
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## တစ် ဦး `Fn` parameter သည်အသုံးပြုခြင်း
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ဒါကြောင့် regex က `&str: !FnMut` ကိုမှီခိုအားထားနိုင်အောင်
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// ခေါ်ဆိုမှုကိုလုပ်ဆောင်သည်။
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// တစ် ဦး mutable လက်ခံကြာသောခေါ်ဆိုမှုအော်ပရေတာ၏ဗားရှင်း။
///
/// `FnMut` ၏ဖြစ်ရပ်များကိုအကြိမ်ကြိမ်ခေါ်ဆိုနိုင်ပြီးအခြေအနေကိုပြောင်းလဲစေနိုင်သည်။
///
/// `FnMut` သိမ်းဆည်းထားသော variable များသို့ပြောင်းနိုင်သောရည်ညွှန်းချက်များနှင့် [`Fn`] ကိုအကောင်အထည်ဖော်သောအမျိုးအစားအားလုံး (ဥပမာ-(safe) [function pointers] (`FnMut` သည် [`Fn`] ၏အလွန်ပုံတူသောကြောင့်) မှအလိုအလျောက်အကောင်အထည်ဖော်သည်။
/// ထို့အပြင် `FnMut` ကိုသုံးသောမည်သည့် `F` အမျိုးအစားအတွက်မဆို `&mut F` သည်လည်း `FnMut` ကိုအသုံးပြုသည်။
///
/// [`FnOnce`] သည် `FnMut` ၏ supertrait ဖြစ်သဖြင့် [`FnOnce`] ကိုမျှော်လင့်သည့်နေရာတွင် `FnMut` ၏မည်သည့်ဥပမာကိုမဆိုအသုံးပြုနိုင်သည်။ [`Fn`] သည် `FnMut` ၏ subtrait တစ်ခုဖြစ်သောကြောင့် [`Fn`] ၏မည်သည့်ဥပမာကိုမဆို `FnMut` မျှော်လင့်ထားသောနေရာတွင်အသုံးပြုနိုင်သည်။
///
/// `FnMut` ကို function-type အမျိုးအစား parameter တစ်ခုလက်ခံချင်တယ်ဆိုရင် state ကို mutate လုပ်ဖို့အတွက်ထပ်ခါတလဲလဲခေါ်ဖို့လိုတဲ့အခါ bound တစ်ခုအနေနဲ့သုံးပါ။
/// သင် parameter သည်ပြည်နယ် mutate ချင်ကြဘူးဆိုရင်, [`Fn`] တစ် ဦး ခညျြနှောငျအဖြစ်အသုံးပြု;ထပ်ခါတလဲလဲဖုန်းခေါ်ရန်မလိုအပ်ပါက [`FnOnce`] ကိုသုံးပါ။
///
/// ဤအကြောင်းအရာနှင့် ပါတ်သက်၍ နောက်ထပ်သတင်းအချက်အလက်များအတွက် [chapter on closures in *The Rust Programming Language*][book] ကိုကြည့်ပါ။
///
/// `Fn` traits အတွက်အထူး syntax (ဥပမာဥပမာ
/// `Fn(usize, bool) -> usize`) ။ဤနည်းပညာ၏အသေးစိတ်အချက်အလက်များကိုစိတ်ဝင်စားသူများသည် [the relevant section in the *Rustonomicon*][nomicon] ကိုရည်ညွှန်းနိုင်သည်။
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## တစ် ဦး Mutably ဖမ်းယူပိတ်ပစ်ခေါ်ဆို
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## တစ် ဦး `FnMut` parameter သည်အသုံးပြုခြင်း
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ဒါကြောင့် regex က `&str: !FnMut` ကိုမှီခိုအားထားနိုင်အောင်
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// ခေါ်ဆိုမှုကိုလုပ်ဆောင်သည်။
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// by-value receiver တစ်ခုကိုခေါ်သောအော်ပရေတာ၏မူကွဲ။
///
/// `FnOnce` ၏ဖြစ်ရပ်များကိုခေါ်နိုင်သည်၊ အကြိမ်ပေါင်းများစွာခေါ်။ မရပါ။ဤအကြောင်းကြောင့် အကယ်၍ အမျိုးအစားနှင့် ပတ်သက်၍ လူသိများသည့်တစ်ခုတည်းသောအရာက၎င်းသည် `FnOnce` ကိုအသုံးပြုသည်ဆိုလျှင်၎င်းကိုတစ်ကြိမ်သာခေါ်ဆိုနိုင်သည်။
///
/// `FnOnce` ဖမ်းဆီးရမိ variable တွေကိုလောင်စေခြင်းငှါပိတ်ပစ်အဖြစ် [`FnMut`] အကောင်အထည်ဖေါ်သောသူအပေါင်းတို့သည်အမျိုးအစားများ, ဥပမာ (safe) [function pointers] (`FnOnce` [`FnMut`] တစ် supertrait ဖြစ်ပါတယ်ကတည်းက) ကအလိုအလျှောက်အကောင်အထည်ဖော်နေပါတယ်။
///
///
/// [`Fn`] နှင့် [`FnMut`] နှစ်ခုလုံးသည် `FnOnce` ၏လက်အောက်ငယ်သားများဖြစ်သောကြောင့် [`Fn`] သို့မဟုတ် [`FnMut`] ၏မည်သည့်ဥပမာကိုမဆို `FnOnce` မျှော်လင့်ထားသည့်နေရာတွင်အသုံးပြုနိုင်သည်။
///
/// `FnOnce` ကို function-type အမျိုးအစား parameter တစ်ခုလက်ခံချင်ရင်တစ်ချိန်တည်းမှာဖုန်းခေါ်ဖို့လိုတဲ့အခါဘောင်တစ်ခုအနေနဲ့အသုံးပြုပါ။
/// အကယ်၍ သင်သည် parameter ကိုထပ်ခါတလဲလဲခေါ်ရန်လိုပါက [`FnMut`] ကို bound တစ်ခုအနေဖြင့်အသုံးပြုပါ။သင့်အနေဖြင့်အခြေအနေကိုပြောင်းလဲရန်မလိုအပ်ပါက [`Fn`] ကိုသုံးပါ။
///
/// ဤအကြောင်းအရာနှင့် ပါတ်သက်၍ နောက်ထပ်သတင်းအချက်အလက်များအတွက် [chapter on closures in *The Rust Programming Language*][book] ကိုကြည့်ပါ။
///
/// `Fn` traits အတွက်အထူး syntax (ဥပမာဥပမာ
/// `Fn(usize, bool) -> usize`) ။ဤနည်းပညာ၏အသေးစိတ်အချက်အလက်များကိုစိတ်ဝင်စားသူများသည် [the relevant section in the *Rustonomicon*][nomicon] ကိုရည်ညွှန်းနိုင်သည်။
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## တစ် ဦး `FnOnce` parameter သည်အသုံးပြုခြင်း
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` ယင်း၏သိမ်းဆည်းထားသည့် variable များကိုစားသုံးသည်၊ ထို့ကြောင့်၎င်းကိုတစ်ကြိမ်ထက် ပို၍ မ run နိုင်ပါ။
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // `func()` ကိုထပ်မံလုပ်ရန်ကြိုးစားခြင်းသည် `func` အတွက် `use of moved value` အမှားတစ်ခုဖြစ်လိမ့်မည်။
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` မရှိတော့ဒီအချက်မှာမဖြစ်၏နိုင်ပါသည်
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ဒါကြောင့် regex က `&str: !FnMut` ကိုမှီခိုအားထားနိုင်အောင်
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// ဖုန်းအော်ပရေတာပြီးနောက်ပြန်လာသောအမျိုးအစား။
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// ခေါ်ဆိုမှုကိုလုပ်ဆောင်သည်။
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}