use crate::ops::Try;

/// စောစောစီးစီးထွက်သွားသင့်သလားသို့မဟုတ်ပုံမှန်အတိုင်းဆက်လက်လုပ်ဆောင်သင့်သလားခွဲစိတ်မှုတစ်ခုကိုပြောခဲ့သည်။
///
/// သင်အသုံးပြုသူအားစောစီးစွာထွက်ခွာရန်ဆုံးဖြတ်လိုသည့်နေရာများ (graph traversals (သို့) visitors ည့်သည်များ) ကဲ့သို့သောအရာများကိုဖော်ထုတ်ရာတွင်အသုံးပြုသည်။
/// enum ရှိခြင်းအားဖြင့်၎င်းကိုရှင်းရှင်းလင်းလင်းဖြစ်စေသည်-"wait, what did `false` mean again?" ကိုအံ့သြစရာမဟုတ်တော့ဘဲတန်ဖိုးတစ်ခုပါ ၀ င်သည်။
///
/// # Examples
///
/// [`Iterator::try_for_each`] မှစောစီးစွာထွက်ခွာခြင်း-
///
/// ```
/// #![feature(control_flow_enum)]
/// use std::ops::ControlFlow;
///
/// let r = (2..100).try_for_each(|x| {
///     if 403 % x == 0 {
///         return ControlFlow::Break(x)
///     }
///
///     ControlFlow::Continue(())
/// });
/// assert_eq!(r, ControlFlow::Break(13));
/// ```
///
/// အခြေခံသစ်ပင်ဖြတ်သန်းမှု
///
/// ```no_run
/// #![feature(control_flow_enum)]
/// use std::ops::ControlFlow;
///
/// pub struct TreeNode<T> {
///     value: T,
///     left: Option<Box<TreeNode<T>>>,
///     right: Option<Box<TreeNode<T>>>,
/// }
///
/// impl<T> TreeNode<T> {
///     pub fn traverse_inorder<B>(&self, mut f: impl FnMut(&T) -> ControlFlow<B>) -> ControlFlow<B> {
///         if let Some(left) = &self.left {
///             left.traverse_inorder(&mut f)?;
///         }
///         f(&self.value)?;
///         if let Some(right) = &self.right {
///             right.traverse_inorder(&mut f)?;
///         }
///         ControlFlow::Continue(())
///     }
/// }
/// ```
#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum ControlFlow<B, C = ()> {
    /// ပုံမှန်အဖြစ်စစ်ဆင်ရေး၏နောက်ထပ်အဆင့်ကိုအပေါ်ကိုရွှေ့။
    Continue(C),
    /// နောက်ဆက်တွဲအဆင့်များမပြေးဘဲစစ်ဆင်ရေးမှထွက်ပါ။
    Break(B),
    // ဟုတ်ပါတယ်, မျိုးကွဲများ၏အမိန့်အမျိုးအစား parameters တွေကိုမကိုက်ညီပါ။
    // `ControlFlow<A, B>` <-> `Result<B, A>` သည် `Try` အကောင်အထည်ဖော်မှုတွင် op-convert အဖြစ်ပြောင်းလဲနိုင်ရန်ဤအရာသည်၎င်းတို့သည်ဤအစီအစဉ်အတိုင်းဖြစ်သည်။
    //
}

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
impl<B, C> Try for ControlFlow<B, C> {
    type Ok = C;
    type Error = B;
    #[inline]
    fn into_result(self) -> Result<Self::Ok, Self::Error> {
        match self {
            ControlFlow::Continue(y) => Ok(y),
            ControlFlow::Break(x) => Err(x),
        }
    }
    #[inline]
    fn from_error(v: Self::Error) -> Self {
        ControlFlow::Break(v)
    }
    #[inline]
    fn from_ok(v: Self::Ok) -> Self {
        ControlFlow::Continue(v)
    }
}

impl<B, C> ControlFlow<B, C> {
    /// အကယ်၍ ၎င်းသည် `Break` မူကွဲတစ်ခုဖြစ်ပါက `true` သို့ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// assert!(ControlFlow::<i32, String>::Break(3).is_break());
    /// assert!(!ControlFlow::<String, i32>::Continue(3).is_break());
    /// ```
    #[inline]
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub fn is_break(&self) -> bool {
        matches!(*self, ControlFlow::Break(_))
    }

    /// အကယ်၍ ၎င်းသည် `Continue` မူကွဲတစ်ခုဖြစ်ပါက `true` သို့ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// assert!(!ControlFlow::<i32, String>::Break(3).is_continue());
    /// assert!(ControlFlow::<String, i32>::Continue(3).is_continue());
    /// ```
    #[inline]
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub fn is_continue(&self) -> bool {
        matches!(*self, ControlFlow::Continue(_))
    }

    /// X0XX ကို X001X သို့ပြောင်းသည် `ControlFlow` ဆိုလျှင် `ControlFlow` `Break` နှင့် `None` မဟုတ်ပါ။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// assert_eq!(ControlFlow::<i32, String>::Break(3).break_value(), Some(3));
    /// assert_eq!(ControlFlow::<String, i32>::Continue(3).break_value(), None);
    /// ```
    #[inline]
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub fn break_value(self) -> Option<B> {
        match self {
            ControlFlow::Continue(..) => None,
            ControlFlow::Break(x) => Some(x),
        }
    }

    /// X0XX သို့ X01X သို့ Maps တစ်ခုတည်ရှိပြီး break တန်ဖိုးကိုလျှောက်ထားခြင်းအားဖြင့် Maps လုပ်သည်။
    ///
    #[inline]
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub fn map_break<T, F>(self, f: F) -> ControlFlow<T, C>
    where
        F: FnOnce(B) -> T,
    {
        match self {
            ControlFlow::Continue(x) => ControlFlow::Continue(x),
            ControlFlow::Break(x) => ControlFlow::Break(f(x)),
        }
    }
}

impl<R: Try> ControlFlow<R, R::Ok> {
    /// `Try` ကိုအကောင်အထည်ဖော်သည့်မည်သည့်အမျိုးအစားမှမဆို `ControlFlow` တစ်ခုဖန်တီးပါ။
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    #[inline]
    pub fn from_try(r: R) -> Self {
        match Try::into_result(r) {
            Ok(v) => ControlFlow::Continue(v),
            Err(v) => ControlFlow::Break(Try::from_error(v)),
        }
    }

    /// `ControlFlow` ကို `Try` ကိုအကောင်အထည်ဖော်သည့်မည်သည့်အမျိုးအစားသို့မဆိုပြောင်းပါ။
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    #[inline]
    pub fn into_try(self) -> R {
        match self {
            ControlFlow::Continue(v) => Try::from_ok(v),
            ControlFlow::Break(v) => v,
        }
    }
}

impl<B> ControlFlow<B, ()> {
    /// `Continue` တွင်တန်ဖိုးမရှိသောကြောင့်မကြာခဏဖြစ်လေ့ဖြစ်ထရှိသော်လည်း `(())` ကိုသင်ကြိုက်နှစ်သက်ပါကစာရိုက်ခြင်းကိုရှောင်ရှားရန်နည်းလမ်းတစ်ခုဖြစ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// let mut partial_sum = 0;
    /// let last_used = (1..10).chain(20..25).try_for_each(|x| {
    ///     partial_sum += x;
    ///     if partial_sum > 100 { ControlFlow::Break(x) }
    ///     else { ControlFlow::CONTINUE }
    /// });
    /// assert_eq!(last_used.break_value(), Some(22));
    /// ```
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub const CONTINUE: Self = ControlFlow::Continue(());
}

impl<C> ControlFlow<(), C> {
    /// `try_for_each` ကဲ့သို့ API များသည် `Break` နှင့်တန်ဖိုးများမလိုအပ်ပါ၊ ထို့ကြောင့်သင်နှစ်သက်ပါက၎င်းသည် `(())` စာရိုက်ခြင်းကိုရှောင်ရှားရန်နည်းလမ်းတစ်ခုဖြစ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// let mut partial_sum = 0;
    /// (1..10).chain(20..25).try_for_each(|x| {
    ///     if partial_sum > 100 { ControlFlow::BREAK }
    ///     else { partial_sum += x; ControlFlow::CONTINUE }
    /// });
    /// assert_eq!(partial_sum, 108);
    /// ```
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub const BREAK: Self = ControlFlow::Break(());
}