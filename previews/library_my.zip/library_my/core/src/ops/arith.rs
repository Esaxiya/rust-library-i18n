/// အပိုဆောင်းအော်ပရေတာ `+` ။
///
/// သတိပြုပါ `Rhs` သည်ပုံမှန်အားဖြင့် `Self` ဖြစ်သည်၊ သို့သော်၎င်းသည်မဖြစ်မနေလိုအပ်သည်။
/// ဥပမာအားဖြင့်၊ [`std::time::SystemTime`] သည် `Add<Duration>` ကို သုံး၍ ပုံစံ `SystemTime = SystemTime + Duration` ၏လည်ပတ်မှုကိုခွင့်ပြုသည်။
///
///
/// [`std::time::SystemTime`]: ../../std/time/struct.SystemTime.html
///
/// # Examples
///
/// ## `Add`able အချက်များ
///
/// ```
/// use std::ops::Add;
///
/// #[derive(Debug, Copy, Clone, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl Add for Point {
///     type Output = Self;
///
///     fn add(self, other: Self) -> Self {
///         Self {
///             x: self.x + other.x,
///             y: self.y + other.y,
///         }
///     }
/// }
///
/// assert_eq!(Point { x: 1, y: 0 } + Point { x: 2, y: 3 },
///            Point { x: 3, y: 3 });
/// ```
///
/// ## ယေဘုယျအားဖြင့် `Add` အကောင်အထည်ဖော်
///
/// ယေဘူယျအားဖြင့် `Add` trait ကိုအကောင်အထည်ဖော်သည့်တူညီသော `Point` struct ၏ဥပမာတစ်ခုဤတွင်တွေ့နိုင်သည်။
///
/// ```
/// use std::ops::Add;
///
/// #[derive(Debug, Copy, Clone, PartialEq)]
/// struct Point<T> {
///     x: T,
///     y: T,
/// }
///
/// // အကောင်အထည်ဖော်မှုဆက်စပ်ဆက်စပ် `Output` ကိုအသုံးပြုသည်သတိပြုပါ။
/// impl<T: Add<Output = T>> Add for Point<T> {
///     type Output = Self;
///
///     fn add(self, other: Self) -> Self::Output {
///         Self {
///             x: self.x + other.x,
///             y: self.y + other.y,
///         }
///     }
/// }
///
/// assert_eq!(Point { x: 1, y: 0 } + Point { x: 2, y: 3 },
///            Point { x: 3, y: 3 });
/// ```
///
#[lang = "add"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(all(_Self = "{integer}", Rhs = "{float}"), message = "cannot add a float to an integer",),
    on(all(_Self = "{float}", Rhs = "{integer}"), message = "cannot add an integer to a float",),
    message = "cannot add `{Rhs}` to `{Self}`",
    label = "no implementation for `{Self} + {Rhs}`"
)]
#[doc(alias = "+")]
pub trait Add<Rhs = Self> {
    /// အဆိုပါ `+` အော်ပရေတာလျှောက်ထားပြီးနောက်ရရှိလာတဲ့အမျိုးအစား။
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output;

    /// အဆိုပါ `+` စစ်ဆင်ရေးလုပ်ဆောင်တယ်။
    ///
    /// # Example
    ///
    /// ```
    /// assert_eq!(12 + 1, 13);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn add(self, rhs: Rhs) -> Self::Output;
}

macro_rules! add_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Add for $t {
            type Output = $t;

            #[inline]
            #[rustc_inherit_overflow_checks]
            fn add(self, other: $t) -> $t { self + other }
        }

        forward_ref_binop! { impl Add, add for $t, $t }
    )*)
}

add_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64 }

/// အနုတ်အော်ပရေတာ `-` ။
///
/// သတိပြုပါ `Rhs` သည်ပုံမှန်အားဖြင့် `Self` ဖြစ်သည်၊ သို့သော်၎င်းသည်မဖြစ်မနေလိုအပ်သည်။
/// ဥပမာအားဖြင့်၊ [`std::time::SystemTime`] သည် `Sub<Duration>` ကို သုံး၍ ပုံစံ `SystemTime = SystemTime - Duration` ၏လည်ပတ်မှုကိုခွင့်ပြုသည်။
///
///
/// [`std::time::SystemTime`]: ../../std/time/struct.SystemTime.html
///
/// # Examples
///
/// ## `နုတ်ယူနိုင်သောအချက်များ
///
/// ```
/// use std::ops::Sub;
///
/// #[derive(Debug, Copy, Clone, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl Sub for Point {
///     type Output = Self;
///
///     fn sub(self, other: Self) -> Self::Output {
///         Self {
///             x: self.x - other.x,
///             y: self.y - other.y,
///         }
///     }
/// }
///
/// assert_eq!(Point { x: 3, y: 3 } - Point { x: 2, y: 3 },
///            Point { x: 1, y: 0 });
/// ```
///
/// ## ယေဘုယျအားဖြင့် `Sub` အကောင်အထည်ဖော်
///
/// ယေဘူယျအားဖြင့် `Sub` trait ကိုအကောင်အထည်ဖော်သည့်တူညီသော `Point` struct တစ်ခု၏ဥပမာတစ်ခုဖြစ်သည်။
///
/// ```
/// use std::ops::Sub;
///
/// #[derive(Debug, PartialEq)]
/// struct Point<T> {
///     x: T,
///     y: T,
/// }
///
/// // အကောင်အထည်ဖော်မှုဆက်စပ်ဆက်စပ် `Output` ကိုအသုံးပြုသည်သတိပြုပါ။
/// impl<T: Sub<Output = T>> Sub for Point<T> {
///     type Output = Self;
///
///     fn sub(self, other: Self) -> Self::Output {
///         Point {
///             x: self.x - other.x,
///             y: self.y - other.y,
///         }
///     }
/// }
///
/// assert_eq!(Point { x: 2, y: 3 } - Point { x: 1, y: 0 },
///            Point { x: 1, y: 3 });
/// ```
///
#[lang = "sub"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "cannot subtract `{Rhs}` from `{Self}`",
    label = "no implementation for `{Self} - {Rhs}`"
)]
#[doc(alias = "-")]
pub trait Sub<Rhs = Self> {
    /// `-` အော်ပရေတာကိုလျှောက်ထားပြီးနောက်ရရှိလာတဲ့အမျိုးအစား။
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output;

    /// အဆိုပါ `-` စစ်ဆင်ရေးလုပ်ဆောင်တယ်။
    ///
    /// # Example
    ///
    /// ```
    /// assert_eq!(12 - 1, 11);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn sub(self, rhs: Rhs) -> Self::Output;
}

macro_rules! sub_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Sub for $t {
            type Output = $t;

            #[inline]
            #[rustc_inherit_overflow_checks]
            fn sub(self, other: $t) -> $t { self - other }
        }

        forward_ref_binop! { impl Sub, sub for $t, $t }
    )*)
}

sub_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64 }

/// အဆိုပါမြှောက်အော်ပရေတာ `*` ။
///
/// သတိပြုပါ `Rhs` သည်ပုံမှန်အားဖြင့် `Self` ဖြစ်သည်၊ သို့သော်၎င်းသည်မဖြစ်မနေလိုအပ်သည်။
///
/// # Examples
///
/// ## `Mul`tipliable ဆင်ခြင်တုံတရားနံပါတ်များ
///
/// ```
/// use std::ops::Mul;
///
/// // ဂဏန်းသင်္ချာ၏အခြေခံသီအိုရီအရအနိမ့်ဆုံးသတ်မှတ်ထားသောဆင်ခြင်တုံတရားနံပါတ်များသည်ထူးခြားသည်။
/// // ထို့ကြောင့် `Rational`s ကိုပုံစံမျိုးစုံဖြင့်ထိန်းသိမ်းထားခြင်းအားဖြင့်ကျွန်ုပ်တို့သည် `Eq` နှင့် `PartialEq` ကိုရယူနိုင်သည်။
/////
/// #[derive(Debug, Eq, PartialEq)]
/// struct Rational {
///     numerator: usize,
///     denominator: usize,
/// }
///
/// impl Rational {
///     fn new(numerator: usize, denominator: usize) -> Self {
///         if denominator == 0 {
///             panic!("Zero is an invalid denominator!");
///         }
///
///         // အကြီးမြတ်ဆုံးဘုံကွဲပြားခြင်းအားဖြင့်ခွဲဝေခြင်းဖြင့်နိမ့်ဆုံးအသုံးအနှုန်းများမှလျှော့ချပါ။
/////
///         let gcd = gcd(numerator, denominator);
///         Self {
///             numerator: numerator / gcd,
///             denominator: denominator / gcd,
///         }
///     }
/// }
///
/// impl Mul for Rational {
///     // ဆင်ခြင်တုံတရားနံပါတ်များ၏မြှောက်တစ်ခုပိတ်ထားသောစစ်ဆင်ရေးဖြစ်ပါတယ်။
///     type Output = Self;
///
///     fn mul(self, rhs: Self) -> Self {
///         let numerator = self.numerator * rhs.numerator;
///         let denominator = self.denominator * rhs.denominator;
///         Self::new(numerator, denominator)
///     }
/// }
///
/// // Euclid ၏နှစ်ပေါင်းထောင်ပေါင်းများစွာသောအမြင့်ဆုံးဘုံကွဲပြားမှုကိုရှာဖွေရန်အတွက် algorithm ။
/////
/// fn gcd(x: usize, y: usize) -> usize {
///     let mut x = x;
///     let mut y = y;
///     while y != 0 {
///         let t = y;
///         y = x % y;
///         x = t;
///     }
///     x
/// }
///
/// assert_eq!(Rational::new(1, 2), Rational::new(2, 4));
/// assert_eq!(Rational::new(2, 3) * Rational::new(3, 4),
///            Rational::new(1, 2));
/// ```
///
/// ## linear algebra ၌ရှိသကဲ့သို့ scalars အားဖြင့် vectors ကိုမြှောက်
///
/// ```
/// use std::ops::Mul;
///
/// struct Scalar { value: usize }
///
/// #[derive(Debug, PartialEq)]
/// struct Vector { value: Vec<usize> }
///
/// impl Mul<Scalar> for Vector {
///     type Output = Self;
///
///     fn mul(self, rhs: Scalar) -> Self::Output {
///         Self { value: self.value.iter().map(|v| v * rhs.value).collect() }
///     }
/// }
///
/// let vector = Vector { value: vec![2, 4, 6] };
/// let scalar = Scalar { value: 3 };
/// assert_eq!(vector * scalar, Vector { value: vec![6, 12, 18] });
/// ```
#[lang = "mul"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "cannot multiply `{Self}` by `{Rhs}`",
    label = "no implementation for `{Self} * {Rhs}`"
)]
#[doc(alias = "*")]
pub trait Mul<Rhs = Self> {
    /// `*` အော်ပရေတာကိုလျှောက်ထားပြီးနောက်ရရှိလာတဲ့အမျိုးအစား။
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output;

    /// အဆိုပါ `*` စစ်ဆင်ရေးလုပ်ဆောင်တယ်။
    ///
    /// # Example
    ///
    /// ```
    /// assert_eq!(12 * 2, 24);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn mul(self, rhs: Rhs) -> Self::Output;
}

macro_rules! mul_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Mul for $t {
            type Output = $t;

            #[inline]
            #[rustc_inherit_overflow_checks]
            fn mul(self, other: $t) -> $t { self * other }
        }

        forward_ref_binop! { impl Mul, mul for $t, $t }
    )*)
}

mul_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64 }

/// ဌာနခွဲအော်ပရေတာ `/` ။
///
/// သတိပြုပါ `Rhs` သည်ပုံမှန်အားဖြင့် `Self` ဖြစ်သည်၊ သို့သော်၎င်းသည်မဖြစ်မနေလိုအပ်သည်။
///
/// # Examples
///
/// ## `Div`idable ဆင်ခြင်တုံတရားနံပါတ်များ
///
/// ```
/// use std::ops::Div;
///
/// // ဂဏန်းသင်္ချာ၏အခြေခံသီအိုရီအရအနိမ့်ဆုံးသတ်မှတ်ထားသောဆင်ခြင်တုံတရားနံပါတ်များသည်ထူးခြားသည်။
/// // ထို့ကြောင့် `Rational`s ကိုပုံစံမျိုးစုံဖြင့်ထိန်းသိမ်းထားခြင်းအားဖြင့်ကျွန်ုပ်တို့သည် `Eq` နှင့် `PartialEq` ကိုရယူနိုင်သည်။
/////
/// #[derive(Debug, Eq, PartialEq)]
/// struct Rational {
///     numerator: usize,
///     denominator: usize,
/// }
///
/// impl Rational {
///     fn new(numerator: usize, denominator: usize) -> Self {
///         if denominator == 0 {
///             panic!("Zero is an invalid denominator!");
///         }
///
///         // အကြီးမြတ်ဆုံးဘုံကွဲပြားခြင်းအားဖြင့်ခွဲဝေခြင်းဖြင့်နိမ့်ဆုံးအသုံးအနှုန်းများမှလျှော့ချပါ။
/////
///         let gcd = gcd(numerator, denominator);
///         Self {
///             numerator: numerator / gcd,
///             denominator: denominator / gcd,
///         }
///     }
/// }
///
/// impl Div for Rational {
///     // ဆင်ခြင်တုံတရားကိန်းဂဏန်းများ၏ဌာနခွဲတစ်ခုပိတ်ထားသောစစ်ဆင်ရေးဖြစ်ပါတယ်။
///     type Output = Self;
///
///     fn div(self, rhs: Self) -> Self::Output {
///         if rhs.numerator == 0 {
///             panic!("Cannot divide by zero-valued `Rational`!");
///         }
///
///         let numerator = self.numerator * rhs.denominator;
///         let denominator = self.denominator * rhs.numerator;
///         Self::new(numerator, denominator)
///     }
/// }
///
/// // Euclid ၏နှစ်ပေါင်းထောင်ပေါင်းများစွာသောအမြင့်ဆုံးဘုံကွဲပြားမှုကိုရှာဖွေရန်အတွက် algorithm ။
/////
/// fn gcd(x: usize, y: usize) -> usize {
///     let mut x = x;
///     let mut y = y;
///     while y != 0 {
///         let t = y;
///         y = x % y;
///         x = t;
///     }
///     x
/// }
///
/// assert_eq!(Rational::new(1, 2), Rational::new(2, 4));
/// assert_eq!(Rational::new(1, 2) / Rational::new(3, 4),
///            Rational::new(2, 3));
/// ```
///
/// ## linear algebra ၌ရှိသကဲ့သို့စကေးအားဖြင့် vectors ပိုင်းခြား
///
/// ```
/// use std::ops::Div;
///
/// struct Scalar { value: f32 }
///
/// #[derive(Debug, PartialEq)]
/// struct Vector { value: Vec<f32> }
///
/// impl Div<Scalar> for Vector {
///     type Output = Self;
///
///     fn div(self, rhs: Scalar) -> Self::Output {
///         Self { value: self.value.iter().map(|v| v / rhs.value).collect() }
///     }
/// }
///
/// let scalar = Scalar { value: 2f32 };
/// let vector = Vector { value: vec![2f32, 4f32, 6f32] };
/// assert_eq!(vector / scalar, Vector { value: vec![1f32, 2f32, 3f32] });
/// ```
#[lang = "div"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "cannot divide `{Self}` by `{Rhs}`",
    label = "no implementation for `{Self} / {Rhs}`"
)]
#[doc(alias = "/")]
pub trait Div<Rhs = Self> {
    /// `/` အော်ပရေတာကိုလျှောက်ထားပြီးနောက်ရရှိလာတဲ့အမျိုးအစား။
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output;

    /// အဆိုပါ `/` စစ်ဆင်ရေးလုပ်ဆောင်တယ်။
    ///
    /// # Example
    ///
    /// ```
    /// assert_eq!(12 / 2, 6);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn div(self, rhs: Rhs) -> Self::Output;
}

macro_rules! div_impl_integer {
    ($($t:ty)*) => ($(
        /// ဒီစစ်ဆင်ရေးဟာသုညဆီသို့လှည့်ပတ်သွားပြီးရလဒ်အတိအကျကိုမည်သည့်အစိတ်အပိုင်းမဆိုဖြတ်လိုက်တယ်။
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Div for $t {
            type Output = $t;

            #[inline]
            fn div(self, other: $t) -> $t { self / other }
        }

        forward_ref_binop! { impl Div, div for $t, $t }
    )*)
}

div_impl_integer! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

macro_rules! div_impl_float {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Div for $t {
            type Output = $t;

            #[inline]
            fn div(self, other: $t) -> $t { self / other }
        }

        forward_ref_binop! { impl Div, div for $t, $t }
    )*)
}

div_impl_float! { f32 f64 }

/// ကျန်ရှိသောအော်ပရေတာ `%` ။
///
/// သတိပြုပါ `Rhs` သည်ပုံမှန်အားဖြင့် `Self` ဖြစ်သည်၊ သို့သော်၎င်းသည်မဖြစ်မနေလိုအပ်သည်။
///
/// # Examples
///
/// ဤဥပမာသည် `SplitSlice` အရာဝတ္ထုတစ်ခုပေါ်တွင် `Rem` ကိုအသုံးပြုသည်။
/// `Rem` ကိုအကောင်အထည်ဖော်ပြီးနောက် `%` အော်ပရေတာကို သုံး၍ အချပ်၏ကျန်အပိုင်းများကိုသတ်မှတ်ထားသောအရှည်၏ညီမျှသောအချပ်များအဖြစ်ခွဲလိုက်ပြီးနောက်မည်သည့်အရာများဖြစ်မည်ကိုရှာဖွေရန်လူတစ်ယောက်ကိုအသုံးပြုနိုင်သည်။
///
///
/// ```
/// use std::ops::Rem;
///
/// #[derive(PartialEq, Debug)]
/// struct SplitSlice<'a, T: 'a> {
///     slice: &'a [T],
/// }
///
/// impl<'a, T> Rem<usize> for SplitSlice<'a, T> {
///     type Output = Self;
///
///     fn rem(self, modulus: usize) -> Self::Output {
///         let len = self.slice.len();
///         let rem = len % modulus;
///         let start = len - rem;
///         Self {slice: &self.slice[start..]}
///     }
/// }
///
/// // ကျွန်ုပ်တို့သည်&[0, 1, 2, 3, 4, 5, 6, 7] ကိုအရွယ်အစား 3 အချပ်များသို့ခွဲဝေလိုပါကကျန်ရှိသောသည်ကျန် [6, 7] ဖြစ်လိမ့်မည်။
/////
/// assert_eq!(SplitSlice { slice: &[0, 1, 2, 3, 4, 5, 6, 7] } % 3,
///            SplitSlice { slice: &[6, 7] });
/// ```
///
#[lang = "rem"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "cannot mod `{Self}` by `{Rhs}`",
    label = "no implementation for `{Self} % {Rhs}`"
)]
#[doc(alias = "%")]
pub trait Rem<Rhs = Self> {
    /// `%` အော်ပရေတာကိုလျှောက်ထားပြီးနောက်ရရှိလာတဲ့အမျိုးအစား။
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output;

    /// အဆိုပါ `%` စစ်ဆင်ရေးလုပ်ဆောင်တယ်။
    ///
    /// # Example
    ///
    /// ```
    /// assert_eq!(12 % 10, 2);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rem(self, rhs: Rhs) -> Self::Output;
}

macro_rules! rem_impl_integer {
    ($($t:ty)*) => ($(
        /// ဒီစစ်ဆင်ရေး `n % d == n - (n / d) * d` ကျေနပ်။
        /// ရလဒ်မှာဘယ်ဘက်အော်ပရာနှင့်တူညီသောလက္ခဏာရှိသည်။
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Rem for $t {
            type Output = $t;

            #[inline]
            fn rem(self, other: $t) -> $t { self % other }
        }

        forward_ref_binop! { impl Rem, rem for $t, $t }
    )*)
}

rem_impl_integer! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

macro_rules! rem_impl_float {
    ($($t:ty)*) => ($(

        /// နှစ်ခု float ၏ဌာနခွဲကနေကျန်ရှိသော။
        ///
        /// ကျန်ရှိနေသောမြတ်များနှင့်တူညီသောနိမိတ်လက္ခဏာကိုရှိပါတယ်နှင့်အဖြစ်တွက်ချက်သည်: `x - (x / y).trunc() * y`.
        ///
        /// # Examples
        ///
        /// ```
        /// let x: f32 = 50.50;
        /// let y: f32 = 8.125;
        /// let remainder = x - (x / y).trunc() * y;
        ///
        /// // စစ်ဆင်ရေးနှစ်ခုလုံးအတွက်အဖြေမှာ 1.75 ဖြစ်သည်
        /// assert_eq!(x % y, remainder);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Rem for $t {
            type Output = $t;

            #[inline]
            fn rem(self, other: $t) -> $t { self % other }
        }

        forward_ref_binop! { impl Rem, rem for $t, $t }
    )*)
}

rem_impl_float! { f32 f64 }

/// အဆိုပါ unary negation အော်ပရေတာ `-` ။
///
/// # Examples
///
/// `-` ကိုအသုံးပြုခြင်းသည်၎င်း၏တန်ဖိုးကိုပျက်ပြယ်စေရန် `Sign` အတွက် `Neg` တစ်ခုအကောင်အထည်ဖော်မှုဖြစ်သည်။
///
///
/// ```
/// use std::ops::Neg;
///
/// #[derive(Debug, PartialEq)]
/// enum Sign {
///     Negative,
///     Zero,
///     Positive,
/// }
///
/// impl Neg for Sign {
///     type Output = Self;
///
///     fn neg(self) -> Self::Output {
///         match self {
///             Sign::Negative => Sign::Positive,
///             Sign::Zero => Sign::Zero,
///             Sign::Positive => Sign::Negative,
///         }
///     }
/// }
///
/// // အနှုတ်လက္ခဏာကအနှုတ်ဖြစ်တယ်။
/// assert_eq!(-Sign::Positive, Sign::Negative);
/// // နှစ်ဆအနှုတ်လက္ခဏာကအပေါင်းဖြစ်တယ်။
/// assert_eq!(-Sign::Negative, Sign::Positive);
/// // သုညသည်၎င်း၏ကိုယ်ပိုင် negation ဖြစ်သည်။
/// assert_eq!(-Sign::Zero, Sign::Zero);
/// ```
#[lang = "neg"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "-")]
pub trait Neg {
    /// `-` အော်ပရေတာကိုလျှောက်ထားပြီးနောက်ရရှိလာတဲ့အမျိုးအစား။
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output;

    /// အဆိုပါ unary `-` စစ်ဆင်ရေးလုပ်ဆောင်တယ်။
    ///
    /// # Example
    ///
    /// ```
    /// let x: i32 = 12;
    /// assert_eq!(-x, -12);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn neg(self) -> Self::Output;
}

macro_rules! neg_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Neg for $t {
            type Output = $t;

            #[inline]
            #[rustc_inherit_overflow_checks]
            fn neg(self) -> $t { -self }
        }

        forward_ref_unop! { impl Neg, neg for $t }
    )*)
}

neg_impl! { isize i8 i16 i32 i64 i128 f32 f64 }

/// အပိုဆောင်းတာဝနျကိုအော်ပရေတာ `+=` ။
///
/// # Examples
///
/// ဤဥပမာသည် X0 `AddAssign` trait ကိုအကောင်အထည်ဖော်သည့် `Point` struct တစ်ခုကိုဖန်တီးပြီးနောက် mutable `Point` သို့ add-assigning ကိုပြသသည်။
///
///
/// ```
/// use std::ops::AddAssign;
///
/// #[derive(Debug, Copy, Clone, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl AddAssign for Point {
///     fn add_assign(&mut self, other: Self) {
///         *self = Self {
///             x: self.x + other.x,
///             y: self.y + other.y,
///         };
///     }
/// }
///
/// let mut point = Point { x: 1, y: 0 };
/// point += Point { x: 2, y: 3 };
/// assert_eq!(point, Point { x: 3, y: 3 });
/// ```
#[lang = "add_assign"]
#[stable(feature = "op_assign_traits", since = "1.8.0")]
#[rustc_on_unimplemented(
    message = "cannot add-assign `{Rhs}` to `{Self}`",
    label = "no implementation for `{Self} += {Rhs}`"
)]
#[doc(alias = "+")]
#[doc(alias = "+=")]
pub trait AddAssign<Rhs = Self> {
    /// အဆိုပါ `+=` စစ်ဆင်ရေးလုပ်ဆောင်တယ်။
    ///
    /// # Example
    ///
    /// ```
    /// let mut x: u32 = 12;
    /// x += 1;
    /// assert_eq!(x, 13);
    /// ```
    #[stable(feature = "op_assign_traits", since = "1.8.0")]
    fn add_assign(&mut self, rhs: Rhs);
}

macro_rules! add_assign_impl {
    ($($t:ty)+) => ($(
        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl AddAssign for $t {
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn add_assign(&mut self, other: $t) { *self += other }
        }

        forward_ref_op_assign! { impl AddAssign, add_assign for $t, $t }
    )+)
}

add_assign_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64 }

/// အနှုတ်တာ ၀ န်ထမ်းအော်ပရေတာ `-=` ။
///
/// # Examples
///
/// ဤဥပမာသည် X0 `SubAssign` trait ကိုအကောင်အထည်ဖော်သည့် `Point` struct တစ်ခုကိုဖန်တီးပြီးနောက် mutable `Point` သို့ခွဲခွဲခြင်းကိုပြသည်။
///
///
/// ```
/// use std::ops::SubAssign;
///
/// #[derive(Debug, Copy, Clone, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl SubAssign for Point {
///     fn sub_assign(&mut self, other: Self) {
///         *self = Self {
///             x: self.x - other.x,
///             y: self.y - other.y,
///         };
///     }
/// }
///
/// let mut point = Point { x: 3, y: 3 };
/// point -= Point { x: 2, y: 3 };
/// assert_eq!(point, Point {x: 1, y: 0});
/// ```
#[lang = "sub_assign"]
#[stable(feature = "op_assign_traits", since = "1.8.0")]
#[rustc_on_unimplemented(
    message = "cannot subtract-assign `{Rhs}` from `{Self}`",
    label = "no implementation for `{Self} -= {Rhs}`"
)]
#[doc(alias = "-")]
#[doc(alias = "-=")]
pub trait SubAssign<Rhs = Self> {
    /// အဆိုပါ `-=` စစ်ဆင်ရေးလုပ်ဆောင်တယ်။
    ///
    /// # Example
    ///
    /// ```
    /// let mut x: u32 = 12;
    /// x -= 1;
    /// assert_eq!(x, 11);
    /// ```
    #[stable(feature = "op_assign_traits", since = "1.8.0")]
    fn sub_assign(&mut self, rhs: Rhs);
}

macro_rules! sub_assign_impl {
    ($($t:ty)+) => ($(
        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl SubAssign for $t {
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn sub_assign(&mut self, other: $t) { *self -= other }
        }

        forward_ref_op_assign! { impl SubAssign, sub_assign for $t, $t }
    )+)
}

sub_assign_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64 }

/// အဆိုပါမြှောက်သတ်မှတ်ချက်အော်ပရေတာ `*=` ။
///
/// # Examples
///
/// ```
/// use std::ops::MulAssign;
///
/// #[derive(Debug, PartialEq)]
/// struct Frequency { hertz: f64 }
///
/// impl MulAssign<f64> for Frequency {
///     fn mul_assign(&mut self, rhs: f64) {
///         self.hertz *= rhs;
///     }
/// }
///
/// let mut frequency = Frequency { hertz: 50.0 };
/// frequency *= 4.0;
/// assert_eq!(Frequency { hertz: 200.0 }, frequency);
/// ```
#[lang = "mul_assign"]
#[stable(feature = "op_assign_traits", since = "1.8.0")]
#[rustc_on_unimplemented(
    message = "cannot multiply-assign `{Self}` by `{Rhs}`",
    label = "no implementation for `{Self} *= {Rhs}`"
)]
#[doc(alias = "*")]
#[doc(alias = "*=")]
pub trait MulAssign<Rhs = Self> {
    /// အဆိုပါ `*=` စစ်ဆင်ရေးလုပ်ဆောင်တယ်။
    ///
    /// # Example
    ///
    /// ```
    /// let mut x: u32 = 12;
    /// x *= 2;
    /// assert_eq!(x, 24);
    /// ```
    #[stable(feature = "op_assign_traits", since = "1.8.0")]
    fn mul_assign(&mut self, rhs: Rhs);
}

macro_rules! mul_assign_impl {
    ($($t:ty)+) => ($(
        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl MulAssign for $t {
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn mul_assign(&mut self, other: $t) { *self *= other }
        }

        forward_ref_op_assign! { impl MulAssign, mul_assign for $t, $t }
    )+)
}

mul_assign_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64 }

/// အဆိုပါဌာနခွဲတာဝနျကိုအော်ပရေတာ `/=` ။
///
/// # Examples
///
/// ```
/// use std::ops::DivAssign;
///
/// #[derive(Debug, PartialEq)]
/// struct Frequency { hertz: f64 }
///
/// impl DivAssign<f64> for Frequency {
///     fn div_assign(&mut self, rhs: f64) {
///         self.hertz /= rhs;
///     }
/// }
///
/// let mut frequency = Frequency { hertz: 200.0 };
/// frequency /= 4.0;
/// assert_eq!(Frequency { hertz: 50.0 }, frequency);
/// ```
#[lang = "div_assign"]
#[stable(feature = "op_assign_traits", since = "1.8.0")]
#[rustc_on_unimplemented(
    message = "cannot divide-assign `{Self}` by `{Rhs}`",
    label = "no implementation for `{Self} /= {Rhs}`"
)]
#[doc(alias = "/")]
#[doc(alias = "/=")]
pub trait DivAssign<Rhs = Self> {
    /// အဆိုပါ `/=` စစ်ဆင်ရေးလုပ်ဆောင်တယ်။
    ///
    /// # Example
    ///
    /// ```
    /// let mut x: u32 = 12;
    /// x /= 2;
    /// assert_eq!(x, 6);
    /// ```
    #[stable(feature = "op_assign_traits", since = "1.8.0")]
    fn div_assign(&mut self, rhs: Rhs);
}

macro_rules! div_assign_impl {
    ($($t:ty)+) => ($(
        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl DivAssign for $t {
            #[inline]
            fn div_assign(&mut self, other: $t) { *self /= other }
        }

        forward_ref_op_assign! { impl DivAssign, div_assign for $t, $t }
    )+)
}

div_assign_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64 }

/// ကျန်ရှိသောတာဝန်အော်ပရေတာ `%=` ။
///
/// # Examples
///
/// ```
/// use std::ops::RemAssign;
///
/// struct CookieJar { cookies: u32 }
///
/// impl RemAssign<u32> for CookieJar {
///     fn rem_assign(&mut self, piles: u32) {
///         self.cookies %= piles;
///     }
/// }
///
/// let mut jar = CookieJar { cookies: 31 };
/// let piles = 4;
///
/// println!("Splitting up {} cookies into {} even piles!", jar.cookies, piles);
///
/// jar %= piles;
///
/// println!("{} cookies remain in the cookie jar!", jar.cookies);
/// ```
#[lang = "rem_assign"]
#[stable(feature = "op_assign_traits", since = "1.8.0")]
#[rustc_on_unimplemented(
    message = "cannot mod-assign `{Self}` by `{Rhs}``",
    label = "no implementation for `{Self} %= {Rhs}`"
)]
#[doc(alias = "%")]
#[doc(alias = "%=")]
pub trait RemAssign<Rhs = Self> {
    /// အဆိုပါ `%=` စစ်ဆင်ရေးလုပ်ဆောင်တယ်။
    ///
    /// # Example
    ///
    /// ```
    /// let mut x: u32 = 12;
    /// x %= 10;
    /// assert_eq!(x, 2);
    /// ```
    #[stable(feature = "op_assign_traits", since = "1.8.0")]
    fn rem_assign(&mut self, rhs: Rhs);
}

macro_rules! rem_assign_impl {
    ($($t:ty)+) => ($(
        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl RemAssign for $t {
            #[inline]
            fn rem_assign(&mut self, other: $t) { *self %= other }
        }

        forward_ref_op_assign! { impl RemAssign, rem_assign for $t, $t }
    )+)
}

rem_assign_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64 }