/// `*v` ကဲ့သို့မပြောင်းလဲနိုင်သောအရာများဖယ်ရှားခြင်းပြုလုပ်သောစစ်ဆင်ရေးများအတွက်အသုံးပြုခဲ့သည်။
///
/// မပြောင်းလဲနိုင်သောအရာများရှိအခြေအနေများရှိ (unary) `*` အော်ပရေတာနှင့်ရှင်းလင်းပြတ်သားစွာ dereferencing စစ်ဆင်ရေးများတွင်အသုံးပြုခြင်းအပြင် `Deref` သည်အခြေအနေများစွာတွင် compiler မှလုံးလုံးလြားလြားအသုံးပြုသည်။
/// ဒီယန္တရားကို ['`Deref` coercion'][more] လို့ခေါ်တယ်။
/// ပြောင်းလဲနိုင်သောအခြေအနေတွင် [`DerefMut`] ကိုအသုံးပြုသည်။
///
/// စမတ်ထောက်ပြသူများအတွက် `Deref` ကိုအသုံးပြုခြင်းသည်သူတို့နောက်ကွယ်ရှိဒေတာများကိုလွယ်ကူစွာရရှိစေသည်၊ ထို့ကြောင့်၎င်းတို့သည် `Deref` ကိုအကောင်အထည်ဖော်သည်။
/// အခြားတစ်ဖက်တွင်, `Deref` နှင့် [`DerefMut`] နှင့်ပတ်သက်။ စည်းမျဉ်းစည်းကမ်းတွေကို smart pointers ထားရှိရန်အထူးဒီဇိုင်းရေးဆွဲခဲ့ကြသည်။
/// ထို့ကြောင့် `ရှုပ်ထွေးမှုကိုရှောင်ရှားရန် ** Deref ကို smart pointers များအတွက်သာအသုံးပြုသင့်သည်။
///
/// အလားတူအကြောင်းပြချက်များအတွက် ** ဤ trait သည်ဘယ်တော့မျှကျရှုံးလိမ့်မည်မဟုတ်ပါ။ဆွေးနွေးမှုပြုလုပ်စဉ်အတွင်းပျက်ကွက်မှုသည် `Deref` ကိုလုံးလုံးလျားလျားမဖြစ်မနေသုံးသောအခါအလွန်ရှုပ်ထွေးနိုင်သည်။
///
/// # `Deref` အတင်းအကျပ်အကြောင်းပိုမို
///
/// အကယ်၍ `T` `Deref<Target = U>` ကိုအသုံးပြုပြီး `x` သည် `T` အမျိုးအစားတန်ဖိုးဖြစ်ပါက၊
///
/// * မပြောင်းလဲနိုင်သောအရာများဖြစ်သော `*x` (`T` သည်ရည်ညွှန်းမှုမဟုတ်သောအမှတ်အသားမဟုတ်သော) `* Deref::deref(&x)` နှင့်ညီမျှသည်။
/// * `&T` အမျိုးအစားတန်ဖိုးများကိုအမျိုးအစား `&U` တန်ဖိုးများသို့အတင်းအကျပ်ခေါ်ဆောင်သွားသည်
/// * `T` လုံး ၀ လုံးလုံးလျားလျား `U` အမျိုးအစား (immutable) နည်းလမ်းများအားလုံးကိုအကောင်အထည်ဖော်သည်။
///
/// အသေးစိတ်သိလိုပါက [the chapter in *The Rust Programming Language*][book] နှင့် [the dereference operator][ref-deref-op], [method resolution] နှင့် [type coercions] ရှိရည်ညွှန်းကဏ္sectionsများကိုလေ့လာပါ။
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Struct ကို dereferencing အားဖြင့်ကြည့်ရှုနိုင်သောတစ်ခုတည်းသောလယ်နှင့်အတူတစ် ဦး က struct ။
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// dereferencing ပြီးနောက်ရလဒ်အမျိုးအစား။
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// တန်ဖိုး Dereferences ။
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// `*v = 1;` ကဲ့သို့ mutable dereferencing စစ်ဆင်ရေးများအတွက်အသုံးပြုခဲ့သည်။
///
/// mutable အခြေအနေတွင် (unary) `*` အော်ပရေတာနှင့်ရှင်းလင်းပြတ်သားစွာ dereferencing စစ်ဆင်ရေးအတွက်အသုံးပြုခံရအပြင်, `DerefMut` ကိုလည်းအခြေအနေများစွာအတွက် compiler ကလုံးလုံးလြားလြားအသုံးပြုသည်။
/// ဒီယန္တရားကို ['`Deref` coercion'][more] လို့ခေါ်တယ်။
/// မပြောင်းလဲနိုင်သောအရာများပါဝင်သည့်အခြေအနေများတွင် [`Deref`] ကိုအသုံးပြုသည်။
///
/// Smart pointers များအတွက် `DerefMut` ကိုအသုံးပြုခြင်းသည်၎င်းတို့နောက်ကွယ်ရှိဒေတာများကို mutating လုပ်ခြင်းကြောင့် `DerefMut` ကိုအကောင်အထည်ဖော်ခြင်းဖြစ်သည်။
/// အခြားတစ်ဖက်တွင်, [`Deref`] နှင့် `DerefMut` နှင့်ပတ်သက်။ စည်းမျဉ်းစည်းကမ်းတွေကို smart pointers ထားရှိရန်အထူးဒီဇိုင်းရေးဆွဲခဲ့ကြသည်။
/// ထို့ကြောင့် ``DerefMut` သည်ရှုပ်ထွေးမှုများကိုရှောင်ရှားနိုင်ရန်အတွက် smart pointers များအတွက်သာလုပ်ဆောင်သင့်သည်။
///
/// အလားတူအကြောင်းပြချက်များအတွက် ** ဤ trait သည်ဘယ်တော့မျှကျရှုံးလိမ့်မည်မဟုတ်ပါ။ဆွေးနွေးမှုပြုလုပ်စဉ်အတွင်းပျက်ကွက်မှုသည် `DerefMut` ကိုလုံးလုံးလျားလျားမဖြစ်မနေသုံးသောအခါအလွန်ရှုပ်ထွေးနိုင်သည်။
///
/// # `Deref` အတင်းအကျပ်အကြောင်းပိုမို
///
/// အကယ်၍ `T` `DerefMut<Target = U>` ကိုအသုံးပြုပြီး `x` သည် `T` အမျိုးအစားတန်ဖိုးဖြစ်ပါက၊
///
/// * ပြောင်းလဲနိုင်သောအခြေအနေများတွင် `*x` (`T` သည်ရည်ညွှန်းမှုတစ်ခုမဟုတ်သောအမှတ်အသားမဟုတ်သော) `* DerefMut::deref_mut(&mut x)` နှင့်ညီမျှသည်။
/// * `&mut T` အမျိုးအစားတန်ဖိုးများကိုအမျိုးအစား `&mut U` တန်ဖိုးများသို့အတင်းအကျပ်ခေါ်ဆောင်သွားသည်
/// * `T` လုံး ၀ လုံးလုံးလျားလျား `U` အမျိုးအစား (mutable) နည်းလမ်းများအားလုံးကိုအကောင်အထည်ဖော်သည်။
///
/// အသေးစိတ်သိလိုပါက [the chapter in *The Rust Programming Language*][book] နှင့် [the dereference operator][ref-deref-op], [method resolution] နှင့် [type coercions] ရှိရည်ညွှန်းကဏ္sectionsများကိုလေ့လာပါ။
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// struct ကို dereferencing အားဖြင့်ပြုပြင်မွမ်းမံနိုင်သောတစ်ခုတည်းသောလယ်နှင့်အတူတစ် ဦး က struct ။
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// အပြန်အလှန်တန်ဖိုးကို dereferences ။
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// struct တစ်ခုသည် method receiver အနေဖြင့် `arbitrary_self_types` feature မပါပဲအသုံးပြုနိုင်သည်ကိုဖော်ပြသည်။
///
/// ၎င်းကို `Box<T>`, `Rc<T>`, `&T` နှင့် `Pin<P>` ကဲ့သို့သော stdlib pointer အမျိုးအစားများကအကောင်အထည်ဖော်သည်။
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}