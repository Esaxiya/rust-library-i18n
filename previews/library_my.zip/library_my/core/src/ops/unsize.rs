use crate::marker::Unsize;

/// Trait သည်၎င်းသည် pointer သို့မဟုတ်ညှပ်သည့်အရာဖြစ်ကြောင်းညွှန်ပြသော၎င်းသည် pointee ပေါ်တွင် unsizing လုပ်ဆောင်နိုင်သည်။
///
/// အသေးစိတ်အတွက် [DST coercion RFC][dst-coerce] နှင့် [the nomicon entry on coercion][nomicon-coerce] တွင်ကြည့်ပါ။
///
/// builtin pointer အမျိုးအစားများအတွက် `T` မှ pointers သည် `T: Unsize<U>` လျှင်ပါးလွှာသော pointer မှအဆီ pointer သို့ပြောင်းခြင်းဖြင့် `U` သို့ pointers သို့ဖိအားပေးလိမ့်မည်။
///
/// စိတ်ကြိုက်အမျိုးအစားများအတွက် `Foo<T>` သို့ `Foo<U>` သို့အတင်းအကျပ်စေခိုင်းမှုသည်ဤနေရာတွင်အတင်းအကျပ်စေခိုင်းခြင်းသည် `CoerceUnsized<Foo<U>> for Foo<T>` တစ်ခု၏သက်ရောက်မှုကိုဖြစ်ပေါ်စေသည်။
/// `Foo<T>` တွင် `T` ပါဝင်သော Non-phantomdata နယ်ပယ်တစ်ခုတည်းသာရှိလျှင်ထိုသို့သောအကျိုးသက်ရောက်ခြင်းကိုရေးသားနိုင်သည်။
/// ထိုလယ်အမျိုးအစား `Bar<T>` ဖြစ်ပါက `CoerceUnsized<Bar<U>> for Bar<T>` တစ်ခုအကောင်အထည်ဖော်မှုတည်ရှိရမည်။
/// အဆိုပါ coercion `Bar<T>` လယ်ပြင် `Bar<U>` သို့အတင်းအကျပ်နှင့် `Foo<U>` ဖန်တီးရန် `Foo<T>` ကနေကျန်လယ်ကွက်ဖြည့်ခြင်းဖြင့်အလုပ်လုပ်ပါလိမ့်မယ်။
/// ၎င်းသည် pointer field တစ်ခုသို့ထိရောက်စွာတူးဖော်ပြီး၎င်းကိုဖိအားပေးလိမ့်မည်။
///
/// ယေဘုယျအားဖြင့် smart pointers များအတွက် X0XX ကိုအကောင်အထည်ဖော်လိမ့်မည်။
/// `Cell<T>` နှင့် `RefCell<T>` ကဲ့သို့ `T` ကိုတိုက်ရိုက် embed လုပ်သော wrapper အမျိုးအစားများအတွက်သင် `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` ကိုတိုက်ရိုက်အကောင်အထည်ဖော်နိုင်သည်။
///
/// ဤသည် `Cell<Box<T>>` ကဲ့သို့သောအမျိုးအစားများကိုအတင်းအကျပ်စေခိုင်းလိမ့်မည်။
///
/// [`Unsize`][unsize] pointers နောက်မှာရှိလျှင် DSTs သို့အတင်းအကျပ်စေခိုင်းသည့်အမျိုးအစားများကိုမှတ်သားရန်အသုံးပြုသည်။၎င်းကို compiler မှအလိုအလျောက်အကောင်အထည်ဖော်သည်။
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T က-> &mut ဦး
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T က-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T က-> * mut ဦး
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T က-> * const ဦး
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const ဦး
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T က->* mut ဦး
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T က->* const ဦး
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T က->* const ဦး
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// ဤအရာသည်အရာဝတ္ထုဘေးကင်းလုံခြုံမှုအတွက်အသုံးပြုသည်၊ နည်းလမ်းတစ်ခု၏လက်ခံအမျိုးအစားကိုပေးပို့နိုင်ကြောင်းစစ်ဆေးသည်။
///
/// ဥပမာ trait ကိုအကောင်အထည်ဖော်ခြင်း။
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T က-> &mut ဦး
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T က->* const ဦး
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T က->* mut ဦး
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}