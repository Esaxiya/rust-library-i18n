/// မပြောင်းလဲနိုင်သောအရာများရှိအခြေအနေများတွင်စစ်ဆင်ရေး (`container[index]`) ကိုရည်ညွှန်းသည်။
///
/// `container[index]` တကယ်တော့ `*container.index(index)` အတွက် syntactic သကြား, ဒါပေမယ့်မပြောင်းလဲနိုင်သောအရာများတန်ဖိုးကိုအဖြစ်အသုံးပြုတဲ့အခါမှသာ။
/// တစ် ဦး mutable တန်ဖိုးကိုမေတ္တာရပ်ခံလျှင်, [`IndexMut`] အစားအသုံးပြုသည်။
/// `value` အမျိုးအစား [`Copy`] ကိုသုံးပါကထိုကဲ့သို့သော `let value = v[index]` ကဲ့သို့ကောင်းသောအရာများကိုခွင့်ပြုသည်။
///
/// # Examples
///
/// အောက်ဖော်ပြပါဥပမာသည် `Index` ကိုဖတ်ရန်တစ်ခုတည်းသော `NucleotideCount` ကွန်တိန်နာပေါ်တွင်တစ် ဦး ချင်းစီ၏အရေအတွက်ကိုအညွှန်းကိန်း syntax ဖြင့်ပြန်လည်ရယူစေခြင်းဖြစ်သည်။
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// indexing ပြီးနောက်ပြန်လာအမျိုးအစား။
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// အဆိုပါ indexing (`container[index]`) စစ်ဆင်ရေးကိုလုပ်ဆောင်တယ်။
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// mutable အခင်းအကျင်းအတွက်စစ်ဆင်ရေး (`container[index]`) indexing အတွက်အသုံးပြုခဲ့သည်။
///
/// `container[index]` တကယ်တော့ `*container.index_mut(index)` အတွက် syntactic သကြား, ဒါပေမယ့်တစ် ဦး mutable တန်ဖိုးကိုအဖြစ်အသုံးပြုတဲ့အခါမှသာ။
/// တစ်ဦးမပြောင်းလဲနိုင်သောအရာများတန်ဖိုးကိုမေတ္တာရပ်ခံလျှင်, [`Index`] trait အစားအသုံးပြုသည်။
/// ၎င်းသည် `v[index] = value` ကဲ့သို့ကောင်းသောအရာများကိုခွင့်ပြုသည်။
///
/// # Examples
///
/// နှစ်ဖက်စလုံးပါသည့် `Balance` struct တစ်ခု၏ရိုးရှင်းသောအကောင်အထည်ဖော်မှုတစ်ခုစီသည်အပြန်အလှန်အားဖြင့်မပြောင်းလဲနိုင်သောအရာများနှင့်ရည်ညွှန်းနိုင်သည်။
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // ဤကိစ္စတွင် `*balance.index(Side::Right)` သည် `* balance.index(Side::Right)` အတွက်သကြားဖြစ်သည်။ အဘယ်ကြောင့်ဆိုသော်ကျွန်ုပ်တို့သည်စာဖတ်ခြင်းမဟုတ်ဘဲ * `balance[Side::Right]` ကိုသာဖတ်ခြင်းဖြစ်သည်။
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // သို့သော် `balance[Side::Left]` သည် `balance[Side::Left]` ကိုရေးသောကြောင့် `balance[Side::Left]` သည်သကြားဖြစ်သည်။
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// အဆိုပါ mutable indexing (`container[index]`) စစ်ဆင်ရေးလုပ်ဆောင်တယ်။
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}