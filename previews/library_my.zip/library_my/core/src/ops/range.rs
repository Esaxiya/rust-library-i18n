use crate::fmt;
use crate::hash::Hash;

/// တစ်ခုကန့်သတ်မဲ့အကွာအဝေး (`..`) ။
///
/// `RangeFull` အဓိကအားဖြင့် [slicing index] အဖြစ်အသုံးပြုသည်။ ၎င်း၏အတိုကောက် `..` ဖြစ်သည်။
/// ၎င်းသည် [`Iterator`] တစ်ခုအနေဖြင့်မဖြစ်နိုင်ပါ၊ အကြောင်းမှာ၎င်းတွင်အစမှတ်မရှိသောကြောင့်ဖြစ်သည်။
///
/// # Examples
///
/// `..` syntax သည် `RangeFull` ဖြစ်သည်။
///
/// ```
/// assert_eq!((..), std::ops::RangeFull);
/// ```
///
/// ၎င်းတွင် [`IntoIterator`] အကောင်အထည်ဖော်မှုမရှိပါ၊ ထို့ကြောင့်သင်သည်၎င်းကို `for` ကွင်းဆက်တွင်တိုက်ရိုက်အသုံးမပြုနိုင်ပါ။
/// ဒီဟာ compile လိမ့်မည်မဟုတ်:
///
/// ```compile_fail,E0277
/// for i in .. {
///     // ...
/// }
/// ```
///
/// [slicing index] အဖြစ်အသုံးပြုသော `RangeFull` သည်အပြည့်အဝခင်းကျင်းမှုကိုအချပ်အဖြစ်ထုတ်လုပ်သည်။
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]); // ဒါက `RangeFull` ပါ
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeFull"]
#[doc(alias = "..")]
#[derive(Copy, Clone, Default, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFull;

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for RangeFull {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")
    }
}

/// (half-open) အကွာအဝေးသည် (`start..end`) အထက်နှင့်အထူးသီးသန့်တည်ရှိသည်။
///
///
/// `start..end` အကွာအဝေးတွင် `start <= x < end` နှင့်တန်ဖိုးအားလုံးပါ ၀ င်သည်။
/// `start >= end` ဆိုပါကဗလာဖြစ်သည်။
///
/// # Examples
///
/// `start..end` syntax သည် `Range` ဖြစ်သည်။
///
/// ```
/// assert_eq!((3..5), std::ops::Range { start: 3, end: 5 });
/// assert_eq!(3 + 4 + 5, (3..6).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]); // ဒါက `Range` ပါ
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
#[lang = "Range"]
#[doc(alias = "..")]
#[derive(Clone, Default, PartialEq, Eq, Hash)] // ကူးယူခြင်းမပြုပါ-#27186 ကိုကြည့်ပါ
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Range<Idx> {
    /// အကွာအဝေး (inclusive) ၏အောက်ပိုင်း။
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
    /// အကွာအဝေး (exclusive) ၏ခညျြနှောငျ။
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for Range<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> Range<Idx> {
    /// `item` အကွာအဝေးတွင်ပါရှိသောလျှင် `true` ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).contains(&2));
    /// assert!( (3..5).contains(&3));
    /// assert!( (3..5).contains(&4));
    /// assert!(!(3..5).contains(&5));
    ///
    /// assert!(!(3..3).contains(&3));
    /// assert!(!(3..2).contains(&3));
    ///
    /// assert!( (0.0..1.0).contains(&0.5));
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// အကွာအဝေးပစ္စည်းမပါရှိပါက `true` သို့ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).is_empty());
    /// assert!( (3..3).is_empty());
    /// assert!( (3..2).is_empty());
    /// ```
    ///
    /// နှစ်ဖက်စလုံးသည်နှိုင်းယှဉ်။ မရနိုင်ပါကအကွာအဝေးမှာလွတ်နေသည်။
    ///
    /// ```
    /// assert!(!(3.0..5.0).is_empty());
    /// assert!( (3.0..f32::NAN).is_empty());
    /// assert!( (f32::NAN..5.0).is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    pub fn is_empty(&self) -> bool {
        !(self.start < self.end)
    }
}

/// အကွာအဝေး (`start..`) အောက်တွင်သာအကျုံးဝင်သည်။
///
/// `RangeFrom` `start..` တွင် `x >= start` နှင့်တန်ဖိုးအားလုံးပါ ၀ င်သည်။
///
/// *မှတ်စု*: [`Iterator`] အကောင်အထည်ဖော်မှုတွင်ပါ ၀ င်သည့်အချက်အလက် (ပါ ၀ င်သည့်အချက်အလက်အမျိုးအစားသည်၎င်း၏ကိန်းဂဏန်းအကန့်အသတ်သို့ရောက်သောအခါ) panic၊ wrap သို့မဟုတ် saturate ကိုခွင့်ပြုသည်။
/// ဤအပြုအမူအား [`Step`] trait ၏အကောင်အထည်ဖော်မှုဖြင့်သတ်မှတ်သည်။
/// မူလတန်းကိန်းများအတွက်ပုံမှန်စည်းမျဉ်းများအတိုင်းလိုက်နာပြီး၊ လျှံထွက်မှုစစ်ဆေးခြင်းပရိုဖိုင်းကိုလေးစားသည်။ (debug in panic, release in wrap) ။
/// Overflow သည်သင်ထင်သည်ထက်စော။ ဖြစ်တတ်သည်ကိုလည်းသတိပြုပါ။ Overflow သည် `next` သို့ခေါ်ဆိုသည့်အခါအများဆုံးတန်ဖိုးကိုဖြစ်ပေါ်စေသည်၊ အကွာအဝေးကိုနောက်တန်ဖိုးတစ်ခုရရန်ပြည်နယ်သို့သတ်မှတ်ထားရမည်ဖြစ်သောကြောင့်ဖြစ်သည်။
///
///
/// [`Step`]: crate::iter::Step
///
/// # Examples
///
/// `start..` syntax သည် `RangeFrom` ဖြစ်သည်။
///
/// ```
/// assert_eq!((2..), std::ops::RangeFrom { start: 2 });
/// assert_eq!(2 + 3 + 4, (2..).take(3).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]); // ဒါက `RangeFrom` ပါ
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
///
///
#[lang = "RangeFrom"]
#[doc(alias = "..")]
#[derive(Clone, PartialEq, Eq, Hash)] // ကူးယူခြင်းမပြုပါ-#27186 ကိုကြည့်ပါ
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFrom<Idx> {
    /// အကွာအဝေး (inclusive) ၏အောက်ပိုင်း။
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeFrom<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeFrom<Idx> {
    /// `item` အကွာအဝေးတွင်ပါရှိသောလျှင် `true` ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..).contains(&2));
    /// assert!( (3..).contains(&3));
    /// assert!( (3..).contains(&1_000_000_000));
    ///
    /// assert!( (0.0..).contains(&0.5));
    /// assert!(!(0.0..).contains(&f32::NAN));
    /// assert!(!(f32::NAN..).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// (`..end`) အထက်တွင်သာအကန့်အသတ်ရှိသည်။
///
/// `RangeTo` `..end` တွင် `x < end` နှင့်တန်ဖိုးအားလုံးပါ ၀ င်သည်။
/// ၎င်းသည် [`Iterator`] တစ်ခုအနေဖြင့်မဖြစ်နိုင်ပါ၊ အကြောင်းမှာ၎င်းတွင်အစမှတ်မရှိသောကြောင့်ဖြစ်သည်။
///
/// # Examples
///
/// `..end` syntax သည် `RangeTo` ဖြစ်သည်။
///
/// ```
/// assert_eq!((..5), std::ops::RangeTo { end: 5 });
/// ```
///
/// ၎င်းတွင် [`IntoIterator`] အကောင်အထည်ဖော်မှုမရှိပါ၊ ထို့ကြောင့်သင်သည်၎င်းကို `for` ကွင်းဆက်တွင်တိုက်ရိုက်အသုံးမပြုနိုင်ပါ။
/// ဒီဟာ compile လိမ့်မည်မဟုတ်:
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeTo<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..5 {
///     // ...
/// }
/// ```
///
/// [slicing index] တစ်ခုအနေဖြင့်အသုံးပြုသောအခါ `RangeTo` သည် `end` ညွှန်းကိန်းအညွှန်းမတိုင်မီ array element အားလုံး၏အချပ်ကိုထုတ်လုပ်သည်။
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]); // ဒါက `RangeTo` ပါ
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeTo"]
#[doc(alias = "..")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeTo<Idx> {
    /// အကွာအဝေး (exclusive) ၏ခညျြနှောငျ။
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeTo<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeTo<Idx> {
    /// `item` အကွာအဝေးတွင်ပါရှိသောလျှင် `true` ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..5).contains(&-1_000_000_000));
    /// assert!( (..5).contains(&4));
    /// assert!(!(..5).contains(&5));
    ///
    /// assert!( (..1.0).contains(&0.5));
    /// assert!(!(..1.0).contains(&f32::NAN));
    /// assert!(!(..f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// အကွာအဝေးသည် (`start..=end`) အောက်နှင့်အထက်တွင်အကျုံးဝင်သည်။
///
/// `RangeInclusive` `start..=end` တွင်တန်ဖိုးအားလုံး `x >= start` နှင့် `x <= end` ပါရှိသည်။ဒါဟာ `start <= end` မဟုတ်လျှင်ဗလာဖြစ်နေသည်။
///
/// ဒီကြားမှာ [fused] ဖြစ်တယ်၊ ဒါပေမယ့်ကြားဖြတ်ပြီးတဲ့နောက် `start` နဲ့ `end` ရဲ့သတ်သတ်မှတ်မှတ်တန်ဖိုးတွေဟာ **မသတ်မှတ်ရသေးဘူး**[`.is_empty()`] ကနောက်ထပ်တန်ဖိုးများကိုထုတ်လုပ်တော့မယ်ဆိုရင် `true` ကိုပြန်ပေးလိမ့်မယ်။
///
///
/// [fused]: crate::iter::FusedIterator
/// [`.is_empty()`]: RangeInclusive::is_empty
///
/// # Examples
///
/// `start..=end` syntax သည် `RangeInclusive` ဖြစ်သည်။
///
/// ```
/// assert_eq!((3..=5), std::ops::RangeInclusive::new(3, 5));
/// assert_eq!(3 + 4 + 5, (3..=5).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]); // ဒါက `RangeInclusive` ပါ
/// ```
///
///
#[lang = "RangeInclusive"]
#[doc(alias = "..=")]
#[derive(Clone, PartialEq, Eq, Hash)] // ကူးယူခြင်းမပြုပါ-#27186 ကိုကြည့်ပါ
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeInclusive<Idx> {
    // သတိပြုရန်မှာ future တွင်ကိုယ်စားပြုမှုကိုပြောင်းလဲရန်ခွင့်ပြုရန်ဤနေရာတွင်ရှိသည့်အကွက်များသည်အများသုံးမဟုတ်ပါ။ကျနော်တို့ plausibly start/end ဖော်ထုတ်နိုင်နေချိန်မှာကျွန်တော် mode ကိုထောကျပံ့ပေးချင်ကြပါဘူးဒါကြောင့်အထူးသဖြင့်, (future/current) ပုဂ္ဂလိကလယ်ကွင်းပြောင်းလဲနေတဲ့မပါဘဲသူတို့ကိုပြင်ဆင်ခြင်း, မမှန်ကန်ကြောင်းအပြုအမူဖို့ဦးဆောင်လမ်းပြလိမ့်မည်။
    //
    //
    //
    //
    pub(crate) start: Idx,
    pub(crate) end: Idx,

    // ဒီလယ်ကွင်းမှာ
    //  - `false` ဆောက်လုပ်ရေးအပေါ်သို့
    //  - `false` ကြားမှာ Element တစ်ခုရဲ့လြှော့သိရပါတယ်နှင့်ကြားမှာမောမပါသောအခါ
    //  - `true` ကြားမှာအဆိုပါကြားမှာ exhaust ဖို့အသုံးပြုထားပြီးအခါ
    //
    // ဤသည် PartialOrd ခညျြနှောငျသို့မဟုတ်အထူးပြုမရှိဘဲ PartialEq နှင့် Hash ကိုထောက်ပံ့ရန်လိုအပ်သည်။
    pub(crate) exhausted: bool,
}

impl<Idx> RangeInclusive<Idx> {
    /// အသစ်ပါ ၀ င်သည့်အကွာအဝေးကိုဖန်တီးပေးသည်။`start..=end` ရေးသားခြင်းနှင့်ညီသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ops::RangeInclusive;
    ///
    /// assert_eq!(3..=5, RangeInclusive::new(3, 5));
    /// ```
    #[lang = "range_inclusive_new"]
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    #[rustc_promotable]
    #[rustc_const_stable(feature = "const_range_new", since = "1.32.0")]
    pub const fn new(start: Idx, end: Idx) -> Self {
        Self { start, end, exhausted: false }
    }

    /// အကွာအဝေး (inclusive) ၏အောက်ပိုင်းဘောင်းပြန်သွားသည်။
    ///
    /// ကြားဖြတ်ခြင်းအတွက်အားလုံးပါဝင်နိုင်သောအကွာအဝေးကိုအသုံးပြုသောအခါကြားဖြတ်ခြင်းအဆုံးသတ်ပြီးနောက် `start()` နှင့် [`end()`] ၏တန်ဖိုးများကိုမဖော်ပြနိုင်ပါ။
    /// အားလုံးပါ ၀ င်သောအကွာအဝေးအလွတ်ရှိမရှိကိုဆုံးဖြတ်ရန် `start() > end()` နှင့်နှိုင်းယှဉ်မည့်အစား [`is_empty()`] နည်းလမ်းကိုအသုံးပြုပါ။
    ///
    /// Note: အကွာအဝေးပင်ပန်းနွမ်းနယ်ဖို့ကြားမှာထားပြီးပြီးနောက်ဒီနည်းလမ်းအားဖြင့်ပြန်လာသောတန်ဖိုးသတ်မှတ်မဖြစ်ပါတယ်။
    ///
    /// [`end()`]: RangeInclusive::end
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).start(), &3);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn start(&self) -> &Idx {
        &self.start
    }

    /// အကွာအဝေး (inclusive) ၏အထက်ဘောင်းပြန်သွားသည်။
    ///
    /// ကြားဖြတ်ခြင်းအတွက်အားလုံးပါဝင်နိုင်သောအကွာအဝေးကိုအသုံးပြုသောအခါကြားဖြတ်ခြင်းအဆုံးသတ်ပြီးနောက် [`start()`] နှင့် `end()` ၏တန်ဖိုးများကိုမဖော်ပြနိုင်ပါ။
    /// အားလုံးပါ ၀ င်သောအကွာအဝေးအလွတ်ရှိမရှိကိုဆုံးဖြတ်ရန် `start() > end()` နှင့်နှိုင်းယှဉ်မည့်အစား [`is_empty()`] နည်းလမ်းကိုအသုံးပြုပါ။
    ///
    /// Note: အကွာအဝေးပင်ပန်းနွမ်းနယ်ဖို့ကြားမှာထားပြီးပြီးနောက်ဒီနည်းလမ်းအားဖြင့်ပြန်လာသောတန်ဖိုးသတ်မှတ်မဖြစ်ပါတယ်။
    ///
    /// [`start()`]: RangeInclusive::start
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).end(), &5);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn end(&self) -> &Idx {
        &self.end
    }

    /// သို့ `RangeInclusive` ကိုဖျက်သည်။
    ///
    /// Note: အကွာအဝေးပင်ပန်းနွမ်းနယ်ဖို့ကြားမှာထားပြီးပြီးနောက်ဒီနည်းလမ်းအားဖြင့်ပြန်လာသောတန်ဖိုးသတ်မှတ်မဖြစ်ပါတယ်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).into_inner(), (3, 5));
    /// ```
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    pub fn into_inner(self) -> (Idx, Idx) {
        (self.start, self.end)
    }
}

impl RangeInclusive<usize> {
    /// `SliceIndex` implementations အတွက်သီးသန့် `Range` သို့ပြောင်းသည်။
    /// ဖုန်းခေါ်ဆိုသူသည် `end == usize::MAX` နှင့်ဆက်ဆံရန်တာဝန်ရှိသည်။
    #[inline]
    pub(crate) fn into_slice_range(self) -> Range<usize> {
        // ငါတို့မကုန်သေးဘူးဆိုရင် `start..end + 1` ကိုရိုးရှင်းအောင်လုပ်ချင်တယ်။
        // အကယ်၍ ကျွန်ုပ်တို့သည်ကုန်သွားလျှင်၊ `end + 1..end + 1` ဖြင့်ဖြတ်ခြင်းကအဆုံးမှတ်အတွက်အကန့်အသတ်နှင့်သာစစ်ဆေးနိုင်သည့်အချည်းနှီးသောအကွာအဝေးကိုကျွန်ုပ်တို့အားပေးသည်။
        //
        let exclusive_end = self.end + 1;
        let start = if self.exhausted { exclusive_end } else { self.start };
        start..exclusive_end
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        if self.exhausted {
            write!(fmt, " (exhausted)")?;
        }
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeInclusive<Idx> {
    /// `item` အကွာအဝေးတွင်ပါရှိသောလျှင် `true` ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).contains(&2));
    /// assert!( (3..=5).contains(&3));
    /// assert!( (3..=5).contains(&4));
    /// assert!( (3..=5).contains(&5));
    /// assert!(!(3..=5).contains(&6));
    ///
    /// assert!( (3..=3).contains(&3));
    /// assert!(!(3..=2).contains(&3));
    ///
    /// assert!( (0.0..=1.0).contains(&1.0));
    /// assert!(!(0.0..=1.0).contains(&f32::NAN));
    /// assert!(!(0.0..=f32::NAN).contains(&0.0));
    /// assert!(!(f32::NAN..=1.0).contains(&1.0));
    /// ```
    ///
    /// ကြားဖြတ်ပြီးသောအခါဤနည်းလမ်းသည် `false` ကိုအမြဲပြန်ပို့သည်။
    ///
    /// ```
    /// let mut r = 3..=5;
    /// assert!(r.contains(&3) && r.contains(&5));
    /// for _ in r.by_ref() {}
    /// // တိကျသောလယ်ကွင်းတန်ဖိုးများကိုဤနေရာတွင်မဖော်ပြထားပါ
    /// assert!(!r.contains(&3) && !r.contains(&5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// အကွာအဝေးပစ္စည်းမပါရှိပါက `true` သို့ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).is_empty());
    /// assert!(!(3..=3).is_empty());
    /// assert!( (3..=2).is_empty());
    /// ```
    ///
    /// နှစ်ဖက်စလုံးသည်နှိုင်းယှဉ်။ မရနိုင်ပါကအကွာအဝေးမှာလွတ်နေသည်။
    ///
    /// ```
    /// assert!(!(3.0..=5.0).is_empty());
    /// assert!( (3.0..=f32::NAN).is_empty());
    /// assert!( (f32::NAN..=5.0).is_empty());
    /// ```
    ///
    /// ဤနည်းလမ်းသည်ကြားဖြတ်ခြင်းပြီးဆုံးပြီးနောက် `true` ကိုပြန်လည်ပေးသည်။
    ///
    /// ```
    /// let mut r = 3..=5;
    /// for _ in r.by_ref() {}
    /// // တိကျသောလယ်ကွင်းတန်ဖိုးများကိုဤနေရာတွင်မဖော်ပြထားပါ
    /// assert!(r.is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    #[inline]
    pub fn is_empty(&self) -> bool {
        self.exhausted || !(self.start <= self.end)
    }
}

/// အကွာအဝေး (`..=end`) အထက်တွင်သာအကျုံးဝင်သည်။
///
/// `RangeToInclusive` `..=end` တွင် `x <= end` နှင့်တန်ဖိုးအားလုံးပါ ၀ င်သည်။
/// ၎င်းသည် [`Iterator`] တစ်ခုအနေဖြင့်မဖြစ်နိုင်ပါ၊ အကြောင်းမှာ၎င်းတွင်အစမှတ်မရှိသောကြောင့်ဖြစ်သည်။
///
/// # Examples
///
/// `..=end` syntax သည် `RangeToInclusive` ဖြစ်သည်။
///
/// ```
/// assert_eq!((..=5), std::ops::RangeToInclusive{ end: 5 });
/// ```
///
/// ၎င်းတွင် [`IntoIterator`] အကောင်အထည်ဖော်မှုမရှိပါ၊ ထို့ကြောင့်သင်သည်၎င်းကို `for` ကွင်းဆက်တွင်တိုက်ရိုက်အသုံးမပြုနိုင်ပါ။ဤသည် compile မည်မဟုတ်:
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeToInclusive<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..=5 {
///     // ...
/// }
/// ```
///
/// [slicing index] အဖြစ်အသုံးပြုသောအခါ `RangeToInclusive` သည် `end` ညွှန်ပြသည့်အညွှန်းအပါအ ၀ င် array element အားလုံး၏အချပ်ကိုထုတ်လုပ်သည်။
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]); // ဒါက `RangeToInclusive` ပါ
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
///
#[lang = "RangeToInclusive"]
#[doc(alias = "..=")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeToInclusive<Idx> {
    /// အကွာအဝေး (inclusive) ၏ခညျြနှောငျ
    #[stable(feature = "inclusive_range", since = "1.26.0")]
    pub end: Idx,
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeToInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeToInclusive<Idx> {
    /// `item` အကွာအဝေးတွင်ပါရှိသောလျှင် `true` ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..=5).contains(&-1_000_000_000));
    /// assert!( (..=5).contains(&5));
    /// assert!(!(..=5).contains(&6));
    ///
    /// assert!( (..=1.0).contains(&1.0));
    /// assert!(!(..=1.0).contains(&f32::NAN));
    /// assert!(!(..=f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

// RangeToInclusive<Idx>မှမဆိုလိုပါ <RangeTo<Idx>> underflow က (..0).into() နဲ့ဖြစ်နိုင်တယ်
//

/// သော့တစ်ခုအကွာအဝေးတစ်ခုအဆုံးမှတ်။
///
/// # Examples
///
/// `Bound`s များသည်အကွာအဝေးအမှတ်များဖြစ်သည်။
///
/// ```
/// use std::ops::Bound::*;
/// use std::ops::RangeBounds;
///
/// assert_eq!((..100).start_bound(), Unbounded);
/// assert_eq!((1..12).start_bound(), Included(&1));
/// assert_eq!((1..12).end_bound(), Excluded(&12));
/// ```
///
/// `Bound`s tuple ကို [`BTreeMap::range`] အတွက်အငြင်းပွားမှုအဖြစ်အသုံးပြုခြင်း။
/// သတိပြုရမည်မှာများသောအားဖြင့်၎င်းအစား range syntax (`1..5`) ကိုအသုံးပြုခြင်းသည်ပိုကောင်းသည်။
///
/// ```
/// use std::collections::BTreeMap;
/// use std::ops::Bound::{Excluded, Included, Unbounded};
///
/// let mut map = BTreeMap::new();
/// map.insert(3, "a");
/// map.insert(5, "b");
/// map.insert(8, "c");
///
/// for (key, value) in map.range((Excluded(3), Included(8))) {
///     println!("{}: {}", key, value);
/// }
///
/// assert_eq!(Some((&3, &"a")), map.range((Unbounded, Included(5))).next());
/// ```
///
/// [`BTreeMap::range`]: ../../std/collections/btree_map/struct.BTreeMap.html#method.range
#[stable(feature = "collections_bound", since = "1.17.0")]
#[derive(Clone, Copy, Debug, Hash, PartialEq, Eq)]
pub enum Bound<T> {
    /// အားလုံးပါဝင်နိုင်သောဘောင်း။
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Included(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// သီးသန့်ခညျြနှောငျ။
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Excluded(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// အဆုံးမဲ့အဆုံးမှတ်။ဒီ ဦး တည်ချက်အတွက်အဘယ်သူမျှမခညျြနှောငျရှိကွောငျးညွှန်ပြ။
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Unbounded,
}

#[unstable(feature = "bound_as_ref", issue = "80996")]
impl<T> Bound<T> {
    /// `&Bound<T>` မှ `Bound<&T>` သို့ပြောင်းသည်။
    #[inline]
    pub fn as_ref(&self) -> Bound<&T> {
        match *self {
            Included(ref x) => Included(x),
            Excluded(ref x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }

    /// `&mut Bound<T>` မှ `Bound<&T>` သို့ပြောင်းသည်။
    #[inline]
    pub fn as_mut(&mut self) -> Bound<&mut T> {
        match *self {
            Included(ref mut x) => Included(x),
            Excluded(ref mut x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }
}

impl<T: Clone> Bound<&T> {
    /// `Bound<&T>` ကို `Bound<T>` တစ်ခုသို့ဆွဲချပြီးအကန့်အသတ်ရှိသော contents များကိုပုံတူပွားပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(bound_cloned)]
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((1..12).start_bound(), Included(&1));
    /// assert_eq!((1..12).start_bound().cloned(), Included(1));
    /// ```
    #[unstable(feature = "bound_cloned", issue = "61356")]
    pub fn cloned(self) -> Bound<T> {
        match self {
            Bound::Unbounded => Bound::Unbounded,
            Bound::Included(x) => Bound::Included(x.clone()),
            Bound::Excluded(x) => Bound::Excluded(x.clone()),
        }
    }
}

/// `RangeBounds` `..`, `a..`, `..b`, `..=c`, `d..e`, ဒါမှမဟုတ် `f..=g` တူသောအကွာအဝေး syntax ကထုတ်လုပ် Rust ရဲ့ built-in အကွာအဝေးအမျိုးအစားများဖြင့်အကောင်အထည်ဖော်နေသည်။
///
#[stable(feature = "collections_range", since = "1.28.0")]
pub trait RangeBounds<T: ?Sized> {
    /// အညွှန်းကိန်းခညျြနှောငျစတင်ပါ။
    ///
    /// စတင်တန်ဖိုးကို `Bound` တစ်ခုအဖြစ်ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((..10).start_bound(), Unbounded);
    /// assert_eq!((3..10).start_bound(), Included(&3));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn start_bound(&self) -> Bound<&T>;

    /// အဆုံးအညွှန်းကိန်းခညျြနှောငျ။
    ///
    /// အဆုံးတန်ဖိုးကို `Bound` တစ်ခုအဖြစ်ပြန်ပို့သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((3..).end_bound(), Unbounded);
    /// assert_eq!((3..10).end_bound(), Excluded(&10));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn end_bound(&self) -> Bound<&T>;

    /// `item` အကွာအဝေးတွင်ပါရှိသောလျှင် `true` ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// အခိုင်အမာ! ((3..5).contains(&4));
    /// assert!(!(3..5).contains(&2));
    ///
    /// အခိုင်အမာ! ((0.0..1.0).contains(&0.5));
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    #[stable(feature = "range_contains", since = "1.35.0")]
    fn contains<U>(&self, item: &U) -> bool
    where
        T: PartialOrd<U>,
        U: ?Sized + PartialOrd<T>,
    {
        (match self.start_bound() {
            Included(ref start) => *start <= item,
            Excluded(ref start) => *start < item,
            Unbounded => true,
        }) && (match self.end_bound() {
            Included(ref end) => item <= *end,
            Excluded(ref end) => item < *end,
            Unbounded => true,
        })
    }
}

use self::Bound::{Excluded, Included, Unbounded};

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T: ?Sized> RangeBounds<T> for RangeFull {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        if self.exhausted {
            // ကြားမှာကုန်သွားတဲ့အခါမှာများသောအားဖြင့် start==end ရှိတယ်၊ ဒါပေမယ့်အကွာအဝေးဟာဘာမှမပါဘဲအချည်းနှီးဖြစ်ချင်တယ်။
            //
            Excluded(&self.end)
        } else {
            Included(&self.end)
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for (Bound<T>, Bound<T>) {
    fn start_bound(&self) -> Bound<&T> {
        match *self {
            (Included(ref start), _) => Included(start),
            (Excluded(ref start), _) => Excluded(start),
            (Unbounded, _) => Unbounded,
        }
    }

    fn end_bound(&self) -> Bound<&T> {
        match *self {
            (_, Included(ref end)) => Included(end),
            (_, Excluded(ref end)) => Excluded(end),
            (_, Unbounded) => Unbounded,
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<'a, T: ?Sized + 'a> RangeBounds<T> for (Bound<&'a T>, Bound<&'a T>) {
    fn start_bound(&self) -> Bound<&T> {
        self.0
    }

    fn end_bound(&self) -> Bound<&T> {
        self.1
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}