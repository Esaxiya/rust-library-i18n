//! Overloadable အော်ပရေတာများ။
//!
//! ဤ traits ကိုအကောင်အထည်ဖော်ခြင်းသည်သင့်အားအချို့သောအော်ပရေတာများကိုတင်ရန်ခွင့်ပြုသည်။
//!
//! ဤ traits အချို့ကို prelude မှတင်သွင်းသောကြောင့်၎င်းတို့သည် Rust အစီအစဉ်တိုင်းတွင်ရရှိနိုင်သည်။traits မှထောက်ပံ့သောအော်ပရေတာများသာလျှင်အလွန်အကျွံတင်နိုင်သည်။
//! ဥပမာ, ထို့အပြင်အော်ပရေတာ (`+`) အဆိုပါ [`Add`] trait မှတဆင့်ပိရနိုင်ပေမယ့်တာဝန်ကျတဲ့အော်ပရေတာ (`=`) မျှကျောထောက်နောက်ခံ trait ရှိပါတယ်ကတည်းက၎င်း၏ semantic ရိုက်တဲ့ပြီးရင်၏လမ်းမရှိသောဖြစ်ပါတယ်။
//! ထို့အပြင်ဤ module သည်အော်ပရေတာအသစ်များဖန်တီးရန်မည်သည့်ယန္တရားကိုမျှမပေးပါ။
//! traitless overloading သို့မဟုတ် custom အော်ပရေတာများလိုအပ်လျှင် Rust ၏ syntax ကိုတိုးချဲ့ရန် macros သို့မဟုတ် compiler plugins များကိုသင်ကြည့်သင့်သည်။
//!
//! အော်ပရေတာ traits ၏အကောင်အထည်ဖော်မှုများသည်၎င်းတို့၏သက်ဆိုင်ရာအခြေအနေများတွင်ပုံမှန်မဟုတ်သောအဓိပ္ပါယ်များနှင့် [operator precedence] ကိုသတိရသင့်သည်။
//! ဥပမာအားဖြင့်၊ [`Mul`] ကိုအကောင်အထည်ဖော်သောအခါလုပ်ဆောင်မှုသည်မြှောက်ခြင်းနှင့် (နှင့်ဆက်စပ်မှုကဲ့သို့မျှော်လင့်ထားသည့်ဂုဏ်သတ္တိများကိုမျှဝေခြင်း) နှင့်ဆင်တူပါသည်။
//!
//! သတိပြုရမည်မှာ `&&` နှင့် `||` အော်ပရေတာတိုတိုတိုတိုသည်ရလဒ်ကိုအထောက်အကူပြုမှသာဒုတိယ operand ကိုသာအကဲဖြတ်သည်။ဒီအပြုအမူကို traits မှပြnot္ဌာန်းနိုင်ခြင်းမရှိသောကြောင့် `&&` နှင့် `||` ကို overloadable operator များအဖြစ်မထောက်ပံ့ပါ။
//!
//! အော်ပရေတာအတော်များများသည်သူတို့၏ operand များကိုတန်ဖိုးဖြင့်ယူကြသည်။built-in အမျိုးအစားများနှငျ့ပတျသကျသော Non-ယေဘုယျအခင်းအကျင်းအတွက်, ဒီများသောအားဖြင့်ပြဿနာတစ်ခုမဟုတ်ပါဘူး။
//! တန်ဖိုးအော်ပရေတာကသူတို့ကိုလောင်တစ်ဆင့်ပြီးတစ်ဆင့်ဖို့ကိုကန့်ကွက်အဖြစ်ပြန်သုံးခံရဖို့ရှိသည်လျှင်သို့သော်ယေဘုယျကုဒ်တွင်ဤအော်ပရေတာကို အသုံးပြု. အချို့သည်အာရုံစိုက်မှုလိုအပ်တယ်။ရွေးစရာတစ်ခုမှာ [`clone`] ကိုရံဖန်ရံခါအသုံးပြုရန်ဖြစ်သည်။
//! အခြားရွေးချယ်စရာမှာကိုးကားချက်များအတွက်အပိုအော်ပရေတာအကောင်အထည်ဖော်မှုများပေးသောပါဝင်သည့်အမျိုးအစားများအပေါ်မှီခိုရန်ဖြစ်သည်။
//! ဥပမာအားဖြင့်၊ အသုံးပြုသူသတ်မှတ်ထားသော `T` အမျိုးအစားကိုထပ်မံထောက်ပံ့ရန်အတွက်၊ `T` နှင့် `&T` နှစ်ခုလုံးသည် traits [`Add<T>`][`Add`] နှင့် [`Add<&T>`][`Add`] ကိုအကောင်အထည်ဖော်ရန်ယေဘူယျကုဒ်ကိုမလိုအပ်ဘဲပုံတူမျိုးပွားခြင်းမရှိဘဲရေးနိုင်ရန်ကောင်းသည်။
//!
//!
//! # Examples
//!
//! ဤဥပမာသည် X0 [`Add`] နှင့် [`Sub`] ကိုအကောင်အထည်ဖော်သည့် `Point` struct တစ်ခုကိုဖန်တီးပြီး ```` `နှစ်ခုပေါင်းထည့်ခြင်းနှင့်နုတ်ခြင်းကိုပြသသည်။
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! ဥပမာတစ်ခုအားအကောင်အထည်ဖော်ရန် trait တစ်ခုချင်းစီအတွက်စာရွက်စာတမ်းများကိုကြည့်ပါ။
//!
//! [`Fn`], [`FnMut`] နှင့် [`FnOnce`] traits ကို functions များကဲ့သို့သော invoked အမျိုးအစားများအားဖြင့်အကောင်အထည်ဖော်သည်။သတိပြုရမှာက [`Fn`] `&self`၊ [`FnMut`] `&mut self` ကိုယူပြီး [`FnOnce`] `self` ကိုယူတယ်။
//! ၎င်းတို့သည်ဥပမာအားဖြင့်မဖြစ်မနေသုံးနိုင်သည့်နည်းလမ်းသုံးမျိုးနှင့်ကိုက်ညီသည်-ခေါ်ဆိုမှု-ရည်ညွှန်းချက်၊ ခေါ်ဆိုမှု-ပြောင်းလဲခြင်း-ရည်ညွှန်းချက်နှင့်ခေါ်ဆိုမှု-တန်ဖိုး။
//! ဤ traits ၏အသုံးအများဆုံးအသုံးပြုမှုမှာလုပ်ဆောင်ချက် (သို့) ပိတ်ပစ်ခြင်းများကိုအငြင်းပွားမှုများအဖြစ်ယူသောအဆင့်မြင့်လုပ်ဆောင်ချက်များကိုအကန့်အသတ်ဖြင့်သာပြုရန်ဖြစ်သည်။
//!
//! [`Fn`] ကို parameter တစ်ခုအဖြစ်ယူခြင်း:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! [`FnMut`] ကို parameter တစ်ခုအဖြစ်ယူခြင်း:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! [`FnOnce`] ကို parameter တစ်ခုအဖြစ်ယူခြင်း:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` ယင်း၏သိမ်းဆည်းထားသည့် variable များကိုစားသုံးသည်၊ ထို့ကြောင့်၎င်းကိုတစ်ကြိမ်ထက် ပို၍ မ run နိုင်ပါ
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // `func()` ကိုထပ်မံလုပ်ရန်ကြိုးစားခြင်းသည် `func` အတွက် `use of moved value` အမှားတစ်ခုဖြစ်လိမ့်မည်
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` မရှိတော့ဒီအချက်မှာမဖြစ်၏နိုင်ပါသည်
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;