/// `?` အော်ပရေတာ၏အပြုအမူကိုစိတ်ကြိုက်ပြုပြင်ရန်အတွက် trait ။
///
/// `Try` ကိုအကောင်အထည်ဖော်သည့်အမျိုးအစားသည် success/failure dichotomy ၏စည်းကမ်းချက်များအရ၎င်းကိုကြည့်ရှုရန်နည်းလမ်းကောင်းတစ်ခုဖြစ်သည်။
/// ဤ trait သည်ထိုအောင်မြင်မှုသို့မဟုတ်ပျက်ကွက်မှုတန်ဖိုးများကိုရှိပြီးသားဥပမာမှထုတ်ယူခြင်းနှင့်အောင်မြင်မှု (သို့) ကျရှုံးခြင်းတန်ဖိုးမှဥပမာတစ်ခုကိုအသစ်ဖန်တီးရန်ခွင့်ပြုသည်။
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// အောင်မြင်မှုအဖြစ်ရှုမြင်သောအခါဤတန်ဖိုးအမျိုးအစား။
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// ပျက်ကွက်အဖြစ်ရှုမြင်သောအခါဤတန်ဖိုးအမျိုးအစား။
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// အဆိုပါ "?" အော်ပရေတာသက်ဆိုင်သည်။`Ok(t)` တစ်ပြန်လာသည်ဆိုလိုသည်မှာကွပ်မျက်မှုသည်ပုံမှန်ဆက်လုပ်သင့်ပြီး `?` ၏ရလဒ်မှာတန်ဖိုး `t` ဖြစ်သည်။
    /// `Err(e)` တစ်ပြန်လာသည်ဆိုလိုသည်မှာကွပ်မျက်မှုသည် branch အား `catch` အတွင်းအကျဆုံးအကျဆုံးသို့မဟုတ်လုပ်ဆောင်ချက်မှပြန်လာခြင်းဖြစ်သည်ဟုဆိုလိုသည်။
    ///
    /// တစ် ဦး `Err(e)` ရလဒ်ပြန်ရောက်လျှင်, `e` တန်ဖိုးကို (သူ့ဟာသူ `Try` အကောင်အထည်ဖော်ရမယ်) ၏ပူးတွဲနယ်ပယ်၏ပြန်လာအမျိုးအစားအတွက် "wrapped" ဖြစ်လိမ့်မည်။
    ///
    /// အထူးသ `X::from_error(From::from(e))` တန်ဖိုးကို return ပြန်ပေးတယ်။ `X` ဆိုတာ enclosing function ရဲ့ return type ဖြစ်တယ်။
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// ပေါင်းစပ်ရလဒ်တည်ဆောက်ရန်အမှားတန်ဖိုးကိုခြုံ။
    /// ဥပမာအားဖြင့်, `Result::Err(x)` နှင့် `Result::from_error(x)` ညီမျှကြသည်။
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// ပေါင်းစပ်ရလဒ်တည်ဆောက်ရန် OK ကိုတန်ဖိုးကိုခြုံ။
    /// ဥပမာအားဖြင့်, `Result::Ok(x)` နှင့် `Result::from_ok(x)` ညီမျှကြသည်။
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}