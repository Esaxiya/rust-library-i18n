//! ဒီမော်ဂျူးသုံးကိရိယာ runtime ကရောင်ပြန်ဟပ်မှုမှတဆင့်ဆို `'static` အမျိုးအစားပြောင်းလဲနေသောစာရိုက်နိုင်ပါတယ်သော `Any` trait ။
//!
//! `Any` သူ့ဟာသူ `TypeId` ကိုရရှိရန်အသုံးပြုနိုင်ပြီး trait အရာဝတ္ထုတစ်ခုအနေဖြင့်အသုံးပြုသောအခါပိုမိုသောအင်္ဂါရပ်များရှိသည်။
//! အဆိုပါပါရှိသောတန်ဖိုးကိုပေးထားသောအမျိုးအစားလျှင် `&dyn Any` (ကချေး trait အရာဝတ္ထု) အဖြစ်ပြုလုပ်စမ်းသပ်ငှါ, `is` နှင့် `downcast_ref` နည်းလမ်းများရှိပြီး, အမျိုးအစားအဖြစ်အတွင်းစိတ်တန်ဖိုးကိုတစ်ဦးကိုကိုးကားရဖို့။
//! `&mut dyn Any` သကဲ့သို့, `downcast_mut` နည်းလမ်းအတွင်းတန်ဖိုးအားတစ်ဦး mutable ကိုကိုးကားရတဲ့အတှကျလည်းရှိသေး၏။
//! `Box<dyn Any>` တစ်ဦး `Box<T>` မှပြောင်းလဲရန်ကြိုးစားသော `downcast` နည်းလမ်း, ကထပ်ပြောသည်။
//! အသေးစိတ်ကို [`Box`] စာရွက်စာတမ်းများတွင်ကြည့်ပါ။
//!
//! `&dyn Any` တန်ဖိုးတစ်ခုသတ်မှတ်ထားကွန်ကရစ်အမျိုးအစားဖြစ်ပြီး, အမျိုးအစားသုံးကိရိယာတစ်ခု trait ရှိမရှိစမ်းသပ်ဖို့အသုံးပြုရနိုင်မှာမဟုတ်ဘူးရှိမရှိစမ်းသပ်ဖို့ကန့်သတ်ထားကြောင်းမှတ်ချက်။
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # စမတ်ထောက်ပြနှင့် `dyn Any`
//!
//! တစ်ဦး trait အရာဝတ္ထုအဖြစ် `Any` တွေကိုအသုံးပြုတဲ့အခါအထူးသဖြင့် `Box<dyn Any>` သို့မဟုတ် `Arc<dyn Any>` တူသောအမျိုးအစားများနှင့်အတူ, စိတ်တွင်ထားရန်အပြုအမူတစ်ခုမှာအပိုင်းအစ, ရိုးရှင်းစွာတန်ဖိုးအပေါ် `.type_id()` တောင်းဆိုအခြေခံ trait အရာဝတ္ထု,* * ကိုကွန်တိန်နာ၏ `TypeId` မဟုတ်ထုတ်လုပ်ဦးမည်ဖြစ်ပါသည်။
//!
//! ဤအရာဝတ္တုရဲ့ `TypeId` ပြန်လာကြလိမ့်မည်သည့်အစား `&dyn Any` သို့စမတ် pointer ကိုပြောင်းလဲနေဖြင့်ရှောင်ရှားနိုင်ပါသည်။
//! ဥပမာ:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // သင်ဤအရာကိုလိုချင်သည်။
//! let actual_id = (&*boxed).type_id();
//! // ... ဒီထက်
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! ကျွန်တော်တစ်ဦး function ကိုကူးမြောက်တန်ဖိုးကနေ log out ချင်ဘယ်မှာအခြေအနေကိုစဉ်းစားပါ။
//! ကျနော်တို့နေတဲ့သုံးကိရိယာဘာဂ်အလုပ်လုပ်တန်ဖိုးကိုသိကြပေမယ့်ကျနော်တို့က၎င်း၏ကွန်ကရစ်အမျိုးအစားမသိရပါဘူး။ကျနော်တို့အချို့အမျိုးအစားများကိုအထူးကုသမှုပေးချင်: ဤအမှု၌ String ၏အရှည်ထွက်ပုံနှိပ်ကြိုတင်သူတို့ရဲ့တန်ဖိုးတန်ဖိုးထားသည်။
//! compile လုပ်သည့်အချိန်တွင်ကျွန်ုပ်တို့တန်ဖိုး၏တိကျသောအမျိုးအစားကိုမသိသောကြောင့် runtime reflection ကိုအသုံးပြုရန်လိုအပ်သည်။
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Debug ကိုအကောင်အထည်ဖော်သောမည်သည့်အမျိုးအစားအတွက် logger function ကို။
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // တစ်ဦး `String` ကြှနျတျောတို့၏တန်ဖိုးကိုပြောင်းဖို့ကြိုးစားပါ။
//!     // အောင်မြင်လျှင် String ၏အရှည်နှင့်၎င်း၏တန်ဖိုးကိုထုတ်ချင်သည်။
//!     // မဟုတ်ပါကတစ်ဦးကွဲပြားခြားနားအမျိုးအစားင်: ရုံ unadorned ထဲက print ထုတ်။
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // ဒီ function ကသူနှင့်အတူအလုပ်လုပ်ခြင်းမပြုမီ၎င်း၏ parameter သည်ထွက် log ရန်လိုသည်။
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... တခြားအလုပ်ကို
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// မည်သည့် trait
///////////////////////////////////////////////////////////////////////////////

/// ပြောင်းလဲနေသောစာရိုက်ခြင်းကိုတုပရန် trait ။
///
/// အများစုမှာအမျိုးအစားများ `Any` အကောင်အထည်ဖော်ရန်။သို့သော် non-`'static` ရည်ညွှန်းပါရှိသည်ရာမဆိုအမျိုးအစားမ။
/// အသေးစိတ်များအတွက် [module-level documentation][mod] ကိုကြည့်ပါ။
///
/// [mod]: crate::any
// ကျနော်တို့ကမလုံခြုံကုဒ် (ဥပမာ `downcast`) တွင်တစ်ဦးတည်းသော impl ရဲ့ `type_id` function ကိုဖွင့်များ၏အသေးစိတ်အချက်အလက်ကိုအပေါ်အားကိုးသော်လည်းဤသည်မှာ trait, မလုံခြုံဘူး။ပုံမှန်အားဖြင့်, ထိုပြဿနာတစ်ခုပါလိမ့်မယ်, ဒါပေမယ့် `Any` ၏တစ်ခုတည်းသော impl တစ်စောင်အကောင်အထည်ဖော်မှုကြောင့်အဘယ်သူမျှမကအခြားကုဒ် `Any` အကောင်အထည်ဖော်နိုင်ပါတယ်။
//
// ငါတို့ရှိသမျှသည်အကောင်အထည်ဖော်မှုကိုထိန်းချုပ်ကတည်းကပါကကျိုးအကြောင်းမရှိအလိုမရှိ--ကျနော်တို့ plausibly ဒီ trait မလုံခြုံစေနိုင်ကြောင်းဒါပေမဲ့ကျွန်တော်တကယ်နှစ်ဦးစလုံးမလိုအပ်မယ့်အဖြစ်ကိုမရွေးချယ်မလုံခြုံ traits နှင့်အန္တရာယ်မကင်းနည်းလမ်းများ (ဆိုလိုသည်မှာ၏ဂုဏ်ထူးနှင့် ပတ်သက်. အသုံးပြုသူများကိုရှုပ်ထွေးစေခြင်းငှါ `type_id` သည်ဖုန်းခေါ်ဆိုရန်အဆင်သင့်ရှိနေသေးသော်လည်းစာရွက်စာတမ်းများတွင်ဖော်ပြလိုသည်။
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// `self` ၏ `TypeId` ရရှိသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// မည်သည့် trait အရာဝတ္ထုများအတွက် extension ကိုနည်းလမ်းများ။
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// ဥပမာ-thread တစ်ခုသို့ဆက်သွယ်ခြင်း၏ရလဒ်ကိုပုံနှိပ်။ `unwrap` နှင့်သုံးနိုင်သည်။
// dispatch upcasting နှင့်အလုပ်လုပ်သည်ဆိုပါကနောက်ဆုံးတွင်မလိုအပ်တော့ပါ။
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// boxed type သည် `T` နှင့်အတူတူဖြစ်ပါက `true` သို့ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // ဤလုပ်ဆောင်ချက်သည် instantiated အမျိုးအစား၏ `TypeId` ကိုရယူပါ။
        let t = TypeId::of::<T>();

        // trait အရာဝတ္ထု (`self`) ရှိအမျိုးအစား `TypeId` ကိုရယူပါ။
        let concrete = self.type_id();

        // တန်းတူညီမျှမှုပေါ်နှစ်ဦးစလုံး `TypeId`s နှိုင်းယှဉ်ကြည့်ပါ။
        t == concrete
    }

    /// အကယ်၍ ၎င်းသည် `T` အမျိုးအစားမဟုတ်ပါက box box မှရည်ညွှန်းချက်အချို့ကိုရည်ညွန်းသည်။ သို့မဟုတ်မဟုတ်လျှင် `None` ။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // လုံခြုံမှု: ရုံကျွန်ုပ်တို့သည်မှန်ကန်သောအမျိုးအစားကိုညွှန်ပြနေကြသည်ရှိမရှိ check လုပ်ထား, ကြှနျုပျတို့အပေါ်အားကိုးနိုင်ပါတယ်
            // မှတ်ဉာဏ်လုံခြုံရေးအတွက်ကြောင်းစစ်ဆေးမှုများငါတို့ရှိသမျှသည်အမျိုးအစားများကိုများအတွက်မဆိုအကောင်အထည်ဖော်ခဲ့ကြသောကြောင့်၎င်း,သူတို့ကကျွန်တော်တို့ရဲ့ impl နှင့်အတူဆန့်ကျင်မယ်လို့အဖြစ်အဘယ်သူမျှမကအခြား impls တည်ရှိနိုင်ပါတယ်။
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// အကယ်၍ ၎င်းသည်အမျိုးအစားမဟုတ်ပါက `T` သို့မဟုတ် `None` ရှိပါက boxed value သို့ပြောင်းနိုင်သောအညွှန်းအချို့ကိုပြန်ပို့သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // လုံခြုံမှု: ရုံကျွန်ုပ်တို့သည်မှန်ကန်သောအမျိုးအစားကိုညွှန်ပြနေကြသည်ရှိမရှိ check လုပ်ထား, ကြှနျုပျတို့အပေါ်အားကိုးနိုင်ပါတယ်
            // မှတ်ဉာဏ်လုံခြုံရေးအတွက်ကြောင်းစစ်ဆေးမှုများငါတို့ရှိသမျှသည်အမျိုးအစားများကိုများအတွက်မဆိုအကောင်အထည်ဖော်ခဲ့ကြသောကြောင့်၎င်း,သူတို့ကကျွန်တော်တို့ရဲ့ impl နှင့်အတူဆန့်ကျင်မယ်လို့အဖြစ်အဘယ်သူမျှမကအခြား impls တည်ရှိနိုင်ပါတယ်။
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// အမျိုးအစား `Any` အပေါ်သတ်မှတ်ထားတဲ့နည်းလမ်းကိုမှ forwarding ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// အမျိုးအစား `Any` အပေါ်သတ်မှတ်ထားတဲ့နည်းလမ်းကိုမှ forwarding ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// အမျိုးအစား `Any` အပေါ်သတ်မှတ်ထားတဲ့နည်းလမ်းကိုမှ forwarding ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// အမျိုးအစား `Any` အပေါ်သတ်မှတ်ထားတဲ့နည်းလမ်းကိုမှ forwarding ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// အမျိုးအစား `Any` အပေါ်သတ်မှတ်ထားတဲ့နည်းလမ်းကိုမှ forwarding ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// အမျိုးအစား `Any` အပေါ်သတ်မှတ်ထားတဲ့နည်းလမ်းကိုမှ forwarding ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID နှင့်၎င်း၏နည်းလမ်းများ
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` သည်အမျိုးအစားတစ်ခုအတွက်ကမ္ဘာလုံးဆိုင်ရာထူးခြားသောအမှတ်အသားဖြစ်သည်။
///
/// `TypeId` တစ်ခုချင်းစီသည်ရှင်းလင်းပြတ်သားသောအရာဝတ္ထုတစ်ခုဖြစ်သည်။ ၎င်းသည်အတွင်းရှိအရာများကိုစစ်ဆေးခြင်းကိုခွင့်မပြုသော်လည်းပုံတူပွားခြင်း၊ နှိုင်းယှဉ်ခြင်း၊ ပုံနှိပ်ခြင်းနှင့်ပြခြင်းစသည့်အခြေခံလုပ်ဆောင်မှုများကိုခွင့်ပြုသည်။
///
///
/// တစ်ဦးက `TypeId` လက်ရှိဒီကန့်သတ်သည့် future အတွက်ဖယ်ရှားစေခြင်းငှါ `'static` မှရသောသည်ဟုဝန်ခံကြလော့, ဒါပေမယ့်အမျိုးအစားများကိုသာရရှိနိုင်ပါသည်။
///
/// `TypeId` သည် `Hash`, `PartialOrd` နှင့် `Ord` ကိုအသုံးပြုနေစဉ် Rust ထုတ်ပြန်ချက်များအကြား hashes နှင့် ordering သည်ကွဲပြားလိမ့်မယ်လို့သတိပြုသင့်ပါတယ်။
/// သင့်ရဲ့ကုဒ်သူတို့အတွင်းပိုင်းအပေါ်မှီခိုသတိပြုပါ!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// အဆိုပါ `TypeId` ဒီယေဘုယျ function ကိုအတူ instantiated ထားပြီးအမျိုးအစား၏ Returns ။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// တစ်ဦး string ကိုအချပ်အဖြစ်အမျိုးအစား၏နာမကိုပြန်ပို့ပေးသည်။
///
/// # Note
///
/// ဒီရောဂါရှာဖွေရေးအသုံးပြုရန်ရည်ရွယ်သည်။
/// ပြန်လာသည့် string ၏ contents နှင့် format အတိအကျကိုဖော်ပြရန်မလိုအပ်ပါ။ အမျိုးအစားအတွက်အကောင်းဆုံးကြိုးစားအားထုတ်မှုဖြစ်သည်။
/// ဥပမာအားဖြင့်, `type_name::<Option<String>>()` ပြန်လာစေခြင်းငှါကြိုးကြား `"Option<String>"` နှင့် `"std::option::Option<std::string::String>"` ဖြစ်ကြသည်။
///
///
/// မျိုးစုံအမျိုးအစားများကိုတူညီသောအမျိုးအစားနာမကိုအမှီပြုနိုင်သောကြောင့်ပြန်လာသော string ကိုအမျိုးအစားတစ်ခု၏ထူးခြားသောအမှတ်အသားအဖြစ်သတ်မှတ်ခြင်းမပြုရ။
/// အလားတူစွာ၊ type တစ်ခု၏အစိတ်အပိုင်းအားလုံးသည်ပြန်လာသည့် string တွင်ပေါ်လာလိမ့်မည်ဟူသောအာမခံချက်မရှိပါ-ဥပမာအားဖြင့်၊ သက်တမ်းသတ်မှတ်သူများကိုလက်ရှိမထည့်ပါ။
/// ထို့အပြင်ထွက်ရှိသည့် compiler ဗားရှင်းအကြားပြောင်းလဲသွားစေနိုင်သည်။
///
/// လက်ရှိအကောင်အထည်ဖော်မှု compiler ကရောဂါရှာဖွေရေးနှင့် debuginfo ကဲ့သို့တူညီသောအခြေခံအဆောက်အဦများကိုအသုံးပြုသည်, သို့သော်ဤအာမခံချက်မပေးပါ။
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// string slice တစ်ခုအနေဖြင့် point-to value အမျိုးအစားရဲ့အမည်ကို return လုပ်သည်။
/// ၎င်းသည် `type_name::<T>()` နှင့်အတူတူပင်ဖြစ်သော်လည်း variable အမျိုးအစားကိုအလွယ်တကူမရရှိနိုင်သောနေရာတွင်အသုံးပြုနိုင်သည်။
///
/// # Note
///
/// ဒါဟာရောဂါရှာဖွေအသုံးပြုရန်ရည်ရွယ်ထားသည်။အမျိုးအစား၏အတိအကျပါ ၀ င်မှုနှင့်ပုံစံကိုအတိအကျဖော်ပြခြင်းမရှိပါ။
/// ဥပမာအားဖြင့် `type_name_of_val::<Option<String>>(None)` သည် `"Option<String>"` သို့မဟုတ် `"std::option::Option<std::string::String>"` ကိုပြန်ပို့နိုင်သည်။ သို့သော် `"foobar"` က
///
/// ထို့အပြင်ထွက်ရှိသည့် compiler ဗားရှင်းအကြားပြောင်းလဲသွားစေနိုင်သည်။
///
/// ဤလုပ်ဆောင်မှုသည် trait အရာဝတ္ထုများကိုမဖြေရှင်းနိုင်ပါ။ ဆိုလိုသည်မှာ `type_name_of_val(&7u32 as &dyn Debug)` သည် `"dyn Debug"` ကိုပြန်ပို့နိုင်သည်၊ သို့သော် `"u32"` မဟုတ်ပါ။
///
/// အမျိုးအစားအမည်ကိုအမျိုးအစားတစ်ခု၏ထူးခြားသောအမှတ်အသားအဖြစ်မသတ်မှတ်သင့်ပါ။
/// မျိုးစုံသည်တူညီသောအမျိုးအစားအမည်ကိုမျှဝေနိုင်သည်။
///
/// လက်ရှိအကောင်အထည်ဖော်မှု compiler ကရောဂါရှာဖွေရေးနှင့် debuginfo ကဲ့သို့တူညီသောအခြေခံအဆောက်အဦများကိုအသုံးပြုသည်, သို့သော်ဤအာမခံချက်မပေးပါ။
///
/// # Examples
///
/// ပုံမှန်ကိန်းနှင့် float အမျိုးအစားများကို print ထုတ်။
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}