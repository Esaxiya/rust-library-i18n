//! မှတ်ဉာဏ်ခွဲဝေခြင်း API များ

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// အဆိုပါ `AllocError` အမှားကဒီခွဲဝေချထားပေးရန်နှင့်အတူပေးထားသော input ကိုအငြင်းပွားမှုများပေါင်းစပ်တဲ့အခါမှာအရင်းအမြစ်ကုန်ခမ်းနားမှုသို့မဟုတ်အမှားတစ်ခုခုကြောင့်ဖြစ်နိုင်သည်တစ်ခုခွဲဝေပျက်ကွက်ဖော်ပြသည်။
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (ဤအရာသည် trait အမှား၏အောက်ပိုင်း impl အတွက်ကျွန်ုပ်တို့လိုအပ်သည်။)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// `Allocator` ၏အကောင်အထည်ဖော်မှုသည် [`Layout`][] မှတစ်ဆင့်ဖော်ပြထားသောအချက်အလက်များ၏လွတ်လပ်စွာလုပ်ပိုင်ခွင့်များကိုခွဲဝေချခြင်း၊ ကြီးထွားခြင်း၊ ချုံ့ခြင်းနှင့်ဖယ်ရှားခြင်းပြုလုပ်နိုင်သည်။
///
/// `Allocator` ကိုးကားချက်များသို့မဟုတ် smart pointers များပေါ်တွင်အကောင်အထည်ဖော်ရန်ဒီဇိုင်းပြုလုပ်ထားသည်။ အဘယ်ကြောင့်ဆိုသော် `MyAlloc([u8; N])` ကဲ့သို့သောခွဲဝေချထားပေးသူရှိခြင်းသည်ရွေ့လျားနိုင်သည့်မှတ်ဉာဏ်သို့ညွှန်ပြချက်များကိုမွမ်းမံခြင်းမရှိဘဲရွှေ့ပြောင်း။ မရနိုင်သောကြောင့်ဖြစ်သည်။
///
/// [`GlobalAlloc`][] နှင့်မတူသည်မှာ `Allocator` တွင်သုညအရွယ်ပမာဏကိုခွင့်ပြုထားသည်။
/// တစ်ခုနောက်ခံခွဲဝေဤ (jemalloc လိုမျိုး) ကိုထောကျပံ့သို့မဟုတ် (ထိုကဲ့သို့သော `libc::malloc` ကဲ့သို့) တရားမဝင်သော pointer ကိုပြန်လာမပါဘူးဆိုရင်, ဒီအကောင်အထည်ဖော်မှုအားဖြင့်ဖမ်းမိထားရပါမည်။
///
/// ### လောလောဆယ်ခွဲဝေထားသောမှတ်ဉာဏ်
///
/// အဆိုပါနည်းလမ်းများ၏အချို့တစ်ခွဲဝေမှတဆင့် *တစ်ဦးမှတျဉာဏျပိတ်ပင်တားဆီးမှု* လက်ရှိခွဲဝေစေခြင်းလိုအပ်သည်။ဆိုလိုသည်မှာ
///
/// * ကြောင်းမှတ်ဉာဏ်ပိတ်ပင်တားဆီးမှုများအတွက်စတင်လိပ်စာယခင်က [`allocate`], [`grow`], ဒါမှမဟုတ် [`shrink`] အားဖြင့်ပြန်လာသောနှင့်
///
/// * လုပ်ကွက်ဖြစ်စေ [`deallocate`] မှလွန်ခံရသို့မဟုတ် `Ok` ပြန်လည်ရောက်ရှိကြောင်း [`grow`] သို့မဟုတ် [`shrink`] မှလွန်ခံရဖြင့်ပြောင်းလဲခဲ့ကြသည်တိုက်ရိုက် deallocated နေကြသည်ရှိရာမှတ်ဉာဏ်ပိတ်ပင်တားဆီးမှုနောက်ပိုင်းတွင်, deallocated နိုင်ခြင်းမရှိသေးပေ။
///
/// `grow` သို့မဟုတ် `shrink` `Err` ကိုပြန်ပို့ပါက၊ လွန်ခဲ့သောအညွှန်းသည်မှန်ကန်နေဆဲဖြစ်သည်။
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### မှတ်ဉာဏ်လျောက်ပတ်
///
/// အဆိုပါနည်းလမ်းများ၏အချို့တစ် layout ကို * * တစ်ဦးမှတျဉာဏျပိတ်ပင်တားဆီးမှု fit ကြောင်းလိုအပ်သည်။
/// "fit" အတွက် layout အတွက်ဆိုလိုတာက memory block ဆိုတာ (ဒါမှမဟုတ်ညီမျှစွာ၊ "fit" အတွက် layout တစ်ခုအတွက် layout layout အတွက်) ကအောက်ဖော်ပြပါအခြေအနေများကိုကိုင်တွယ်ရမည်။
///
/// * အဆိုပါပိတ်ပင်တားဆီးမှု [`layout.align()`] ကဲ့သို့တူညီသော alignment ကိုအတူခွဲဝေရမည်ဖြစ်သည်နှင့်
///
/// * အဆိုပါ [`layout.size()`] ရှိရာ, ထိုအကွာအဝေး `min ..= max` လဲရမယ်ထောက်ပံ့:
///   - `min` သည် block ကိုခွဲဝေရန်မကြာသေးမီကအသုံးပြုခဲ့သော layout ၏အရွယ်အစားဖြစ်သည်
///   - `max` [`allocate`], [`grow`], ဒါမှမဟုတ် [`shrink`] ရာမှပြန်လာသောနောက်ဆုံးပေါ်အမှန်တကယ်အရွယ်အစားဖြစ်ပါတယ်။
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * ခွဲဝေချထားပေးသူမှပြန်လာသည့်မှတ်ဉာဏ်သည်လုပ်ပိုင်ခွင့်များနှင့်ခိုင်လုံသောမှတ်ဉာဏ်ကိုညွှန်ပြရမည်။
///
/// * ပုံတူပွားခြင်းသို့မဟုတ်ရွေ့လျားခွဲဝေချထားမှားနေသောမှတ်ဉာဏ်လုပ်ကွက်ဒီခွဲဝေရာမှပြန်လာသောမပြုရပါ။တစ်ဦးကပုံတူမျိုးပွားခွဲဝေတူညီခွဲဝေလိုပဲအလုပ်လုပ်တယ်ရမယ်, နှင့်
///
/// * [*currently allocated*] သောမှတ်ဥာဏ်ပိတ်ပင်တားဆီးမှုမှမဆို pointer ကိုခွဲဝေချထား၏အခြားမည်သည့်နည်းလမ်းမှလွန်နိုင်ပါသည်။
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// မှတ်ဉာဏ်တစ်ကွက်ခွဲဝေချထားပေးရန်ကြိုးစားသည်။
    ///
    /// အောင်မြင်မှုရရှိပြီးနောက် `layout` ၏အရွယ်အစားနှင့်ညှိနှိုင်းမှုဆိုင်ရာအာမခံချက်များနှင့်ကိုက်ညီသည့် [`NonNull<[u8]>`][NonNull] ကိုပြန်ပို့သည်။
    ///
    /// ပြန်လာသောပိတ်ပင်တားဆီးမှုသည် `layout.size()` မှသတ်မှတ်ထားသောအရွယ်အစားပိုကြီးနိုင်သည်၊ ၎င်းတွင်ပါ ၀ င်သည့်အကြောင်းအရာများကိုအစပြုနိုင်သည်သို့မဟုတ်မကျမည်။
    ///
    /// # Errors
    ///
    /// Returning `Err` သည် memory သည်ကုန်သွားပြီလားသို့မဟုတ် `layout` သည် allocator ရဲ့အရွယ်အစားသို့မဟုတ် alignment limitings နဲ့မကိုက်ညီဘူးဆိုတာဖော်ပြတယ်။
    ///
    /// ထိတ်လန့်ခြင်းသို့မဟုတ်ဖျက်သိမ်းခြင်းထက်မှတ်ဉာဏ်ကုန်ခန်းသွားသောအခါ `Err` သို့ပြန်သွားရန်အကောင်အထည်ဖော်မှုကိုအားပေးသည်။ သို့သော်၎င်းသည်တင်းကျပ်သောလိုအပ်ချက်မဟုတ်ပါ။
    /// (အထူးသဖြင့်၊ ၎င်းသည်မှတ်ဥာဏ်အားကုန်ခန်းသွားသောအခြေခံဇာတိခွဲဝေချထားပေးသည့်စာကြည့်တိုက်ပေါ်၌ trait ကိုအကောင်အထည်ဖော်ခြင်းသည် * တရားဝင်ဖြစ်သည်။)
    ///
    /// ခွဲဝေချထားမှုအမှားတစ်ခုအတွက်တွက်ချက်မှုကိုဖျက်သိမ်းလိုသောဖောက်သည်များသည် `panic!` သို့မဟုတ်အလားတူတိုက်ရိုက်မဟုတ်ဘဲ [`handle_alloc_error`] function ကိုခေါ်ရန်တိုက်တွန်းသည်။
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// `allocate` ကဲ့သို့ပြုမူသည်၊ သို့သော်ပြန်လာသောမှတ်ဉာဏ်သည်သုည-အစပြုကြောင်းသေချာစေသည်။
    ///
    /// # Errors
    ///
    /// Returning `Err` သည် memory သည်ကုန်သွားပြီလားသို့မဟုတ် `layout` သည် allocator ရဲ့အရွယ်အစားသို့မဟုတ် alignment limitings နဲ့မကိုက်ညီဘူးဆိုတာဖော်ပြတယ်။
    ///
    /// ထိတ်လန့်ခြင်းသို့မဟုတ်ဖျက်သိမ်းခြင်းထက်မှတ်ဉာဏ်ကုန်ခန်းသွားသောအခါ `Err` သို့ပြန်သွားရန်အကောင်အထည်ဖော်မှုကိုအားပေးသည်။ သို့သော်၎င်းသည်တင်းကျပ်သောလိုအပ်ချက်မဟုတ်ပါ။
    /// (အထူးသဖြင့်၊ ၎င်းသည်မှတ်ဥာဏ်အားကုန်ခန်းသွားသောအခြေခံဇာတိခွဲဝေချထားပေးသည့်စာကြည့်တိုက်ပေါ်၌ trait ကိုအကောင်အထည်ဖော်ခြင်းသည် * တရားဝင်ဖြစ်သည်။)
    ///
    /// ခွဲဝေချထားမှုအမှားတစ်ခုအတွက်တွက်ချက်မှုကိုဖျက်သိမ်းလိုသောဖောက်သည်များသည် `panic!` သို့မဟုတ်အလားတူတိုက်ရိုက်မဟုတ်ဘဲ [`handle_alloc_error`] function ကိုခေါ်ရန်တိုက်တွန်းသည်။
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // လုံခြုံမှု: `alloc` သည်မှန်ကန်သောမှတ်ဉာဏ်ပိတ်ဆို့မှုကိုပြန်လည်ပေးသည်
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// `ptr` အားဖြင့်ရည်ညွှန်းမှတ်ဉာဏ် Deallocates ။
    ///
    /// # Safety
    ///
    /// * `ptr` ဒီ allocator မှတဆင့်မှတ်ဉာဏ် [*currently allocated*] တစ်ပိတ်ပင်တားဆီးမှုဖျောညှနျးရမယ်, နှင့်
    /// * `layout` မဖြစ်မနေ [*fit*] မှတ်ဉာဏ်၏ပိတ်ပင်တားဆီးမှု။
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// မှတ်ဉာဏ်ပိတ်ပင်တားဆီးမှုတိုးချဲ့ဖို့ကြိုးစားခြင်း။
    ///
    /// pointer နှင့်ခွဲဝေထားသောမှတ်ဉာဏ်၏အရွယ်အစားပါ ၀ င်သည့် [`NonNull<[u8]>`][NonNull] အသစ်တစ်ခုကိုပြန်ပို့သည်။pointer သည် `new_layout` မှဖော်ပြထားသည့်အချက်အလက်များကိုကိုင်တွယ်ရန်သင့်တော်သည်။
    /// ၎င်းကိုပြီးမြောက်ရန်အတွက်ခွဲဝေချထားပေးသူသည် `ptr` မှရည်ညွှန်းထားသောခွဲဝေချထားမှုအသစ်ကို layout အသစ်နှင့်ကိုက်ညီအောင်တိုးချဲ့နိုင်သည်။
    ///
    /// ဒီ `Ok` ပြန်လာလျှင်, `ptr` အားဖြင့်ရည်ညွှန်းမှတ်ဉာဏ်ပိတ်ပင်တားဆီးမှု၏ပိုင်ဆိုင်မှုဒီခွဲဝေလွှဲပြောင်းခဲ့တာဖြစ်ပါတယ်။
    /// အဆိုပါမှတ်ဉာဏ်သို့မဟုတ်မ may လွတ်မြောက်လာပြီစေခြင်းငှါ, ဒါကြောင့်ဒီနည်းလမ်းကို၏ပြန်လာတန်ဖိုးကိုမှတဆင့်ထပ်မံခေါ်ဆိုသူ၏ပြန်လည်လွှဲပြောင်းခံခဲ့ရသည်မဟုတ်လျှင်အသုံးမပြုနိုင်ထည့်သွင်းစဉ်းစားရပါမည်။
    ///
    /// ဒီနည်းလမ်းကို `Err` ပြန်လာလျှင်, ထိုမှတ်ဉာဏ်ပိတ်ပင်တားဆီးမှု၏ပိုင်ဆိုင်မှုဒီခွဲဝေလွှဲပြောင်းနိုင်ခြင်းမရှိသေးပေ, နှင့်မှတ်ဉာဏ်ပိတ်ပင်တားဆီးမှုရဲ့ contents unaltered ဖြစ်ကြသည်။
    ///
    /// # Safety
    ///
    /// * `ptr` ဒီခွဲဝေမှတဆင့်မှတ်ဉာဏ် [*currently allocated*] တစ်ပိတ်ပင်တားဆီးမှုဖျောညှနျးရမည်ဖြစ်သည်။
    /// * `old_layout` မှတ်ဉာဏ်၏ပိတ်ပင်တားဆီးမှု [*fit*] (ဒီ `new_layout` အငြင်းအခုံက fit မလိုအပ်ပါဘူး။) ရပါမည်။
    /// * `new_layout.size()` `old_layout.size()` ထက်ကြီးရင်ဖြစ်ရမယ်။
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// `Err` သစ်ကို layout ကိုခွဲဝေချထားရဲ့အရွယ်အစားနှင့်ခွဲဝေချထား၏ alignment ကိုသတ်ဖြည့်ဆည်းခြင်းသို့မဟုတ်လျှင်ကြီးထွားလာမပါဘူးဆိုရင်မဟုတ်ရင်ပျက်ကွက်ပြန်သွားပါ။
    ///
    /// ထိတ်လန့်ခြင်းသို့မဟုတ်ဖျက်သိမ်းခြင်းထက်မှတ်ဉာဏ်ကုန်ခန်းသွားသောအခါ `Err` သို့ပြန်သွားရန်အကောင်အထည်ဖော်မှုကိုအားပေးသည်။ သို့သော်၎င်းသည်တင်းကျပ်သောလိုအပ်ချက်မဟုတ်ပါ။
    /// (အထူးသဖြင့်၊ ၎င်းသည်မှတ်ဥာဏ်အားကုန်ခန်းသွားသောအခြေခံဇာတိခွဲဝေချထားပေးသည့်စာကြည့်တိုက်ပေါ်၌ trait ကိုအကောင်အထည်ဖော်ခြင်းသည် * တရားဝင်ဖြစ်သည်။)
    ///
    /// ခွဲဝေချထားမှုအမှားတစ်ခုအတွက်တွက်ချက်မှုကိုဖျက်သိမ်းလိုသောဖောက်သည်များသည် `panic!` သို့မဟုတ်အလားတူတိုက်ရိုက်မဟုတ်ဘဲ [`handle_alloc_error`] function ကိုခေါ်ရန်တိုက်တွန်းသည်။
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // လုံခြုံမှု: `new_layout.size()` ထက် သာ. ကြီးမြတ်သို့မဟုတ်ညီမျှဖို့သူဖြစ်ရမည်ဘာဖြစ်လို့လဲဆိုတော့
        // `old_layout.size()`, အဟောင်းနှင့်အသစ်မှတ်ဉာဏ်ခွဲဝေမှုနှစ်ခုလုံးသည်ဖတ်ရှုခြင်းနှင့် `old_layout.size()` bytes အတွက်ရေးခြင်းများအတွက်မှန်ကန်သည်။
        // ထို့အပြင်အဟောင်းခွဲဝေချထားပေးခြင်းကိုမရသေးသောကြောင့်, သူက `new_ptr` ထပ်လို့မရပါဘူး။
        // ထို့ကြောင့် `copy_nonoverlapping` သို့ခေါ်ဆိုမှုသည်လုံခြုံသည်။
        // `dealloc` အတွက်လုံခြုံမှုစာချုပ်ကိုဖုန်းခေါ်ဆိုသူမှထောက်ခံရမည်။
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// `grow` ကဲ့သို့ပြုမူသည်၊ သို့သော်၎င်းကိုအကြောင်းအရာအသစ်များကိုပြန်မပို့မီသုညအဖြစ်သတ်မှတ်သည်။
    ///
    /// အဆိုပါမှတ်ဉာဏ်ပိတ်ပင်တားဆီးမှုမှအောင်မြင်တဲ့ခေါ်ဆိုခပြီးနောက်အောက်ပါအကြောင်းအရာများကိုဆံ့ပါလိမ့်မယ်
    /// `grow_zeroed`:
    ///   * bytes `0..old_layout.size()` မူရင်းခွဲဝေရာမှထိန်းသိမ်းထားကြသည်။
    ///   * ခွဲဝေချထားပေးသောအကောင်အထည်ဖော်မှုပေါ် မူတည်၍ bytes `old_layout.size()..old_size` ကိုထိန်းသိမ်းသို့မဟုတ်သုညလိမ့်မည်။
    ///   `old_size` ကြိုတင်ပြုလုပ်ခွဲဝေသောအခါမူလကမေတ္တာရပ်ခံခဲ့အရွယ်အစားထက်ပိုမိုကြီးမားစေခြင်းငှါအရာ `grow_zeroed` ခေါ်ဆိုခြင်း, ရန်မှတ်ဉာဏ်ပိတ်ပင်တားဆီးမှု၏အရွယ်အစားကိုရည်ညွှန်းသည်။
    ///   * bytes `old_size..new_size` သည်သုညဖြစ်သည်။`new_size` သည် `grow_zeroed` ခေါ်ဆိုမှုမှပြန်လာသည့်မှတ်ဉာဏ်ပိတ်ဆို့မှု၏အရွယ်အစားကိုရည်ညွှန်းသည်။
    ///
    /// # Safety
    ///
    /// * `ptr` ဒီခွဲဝေမှတဆင့်မှတ်ဉာဏ် [*currently allocated*] တစ်ပိတ်ပင်တားဆီးမှုဖျောညှနျးရမည်ဖြစ်သည်။
    /// * `old_layout` မှတ်ဉာဏ်၏ပိတ်ပင်တားဆီးမှု [*fit*] (ဒီ `new_layout` အငြင်းအခုံက fit မလိုအပ်ပါဘူး။) ရပါမည်။
    /// * `new_layout.size()` `old_layout.size()` ထက်ကြီးရင်ဖြစ်ရမယ်။
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// `Err` သစ်ကို layout ကိုခွဲဝေချထားရဲ့အရွယ်အစားနှင့်ခွဲဝေချထား၏ alignment ကိုသတ်ဖြည့်ဆည်းခြင်းသို့မဟုတ်လျှင်ကြီးထွားလာမပါဘူးဆိုရင်မဟုတ်ရင်ပျက်ကွက်ပြန်သွားပါ။
    ///
    /// ထိတ်လန့်ခြင်းသို့မဟုတ်ဖျက်သိမ်းခြင်းထက်မှတ်ဉာဏ်ကုန်ခန်းသွားသောအခါ `Err` သို့ပြန်သွားရန်အကောင်အထည်ဖော်မှုကိုအားပေးသည်။ သို့သော်၎င်းသည်တင်းကျပ်သောလိုအပ်ချက်မဟုတ်ပါ။
    /// (အထူးသဖြင့်၊ ၎င်းသည်မှတ်ဥာဏ်အားကုန်ခန်းသွားသောအခြေခံဇာတိခွဲဝေချထားပေးသည့်စာကြည့်တိုက်ပေါ်၌ trait ကိုအကောင်အထည်ဖော်ခြင်းသည် * တရားဝင်ဖြစ်သည်။)
    ///
    /// ခွဲဝေချထားမှုအမှားတစ်ခုအတွက်တွက်ချက်မှုကိုဖျက်သိမ်းလိုသောဖောက်သည်များသည် `panic!` သို့မဟုတ်အလားတူတိုက်ရိုက်မဟုတ်ဘဲ [`handle_alloc_error`] function ကိုခေါ်ရန်တိုက်တွန်းသည်။
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // လုံခြုံမှု: `new_layout.size()` ထက် သာ. ကြီးမြတ်သို့မဟုတ်ညီမျှဖို့သူဖြစ်ရမည်ဘာဖြစ်လို့လဲဆိုတော့
        // `old_layout.size()`, အဟောင်းနှင့်အသစ်မှတ်ဉာဏ်ခွဲဝေမှုနှစ်ခုလုံးသည်ဖတ်ရှုခြင်းနှင့် `old_layout.size()` bytes အတွက်ရေးခြင်းများအတွက်မှန်ကန်သည်။
        // ထို့အပြင်အဟောင်းခွဲဝေချထားပေးခြင်းကိုမရသေးသောကြောင့်, သူက `new_ptr` ထပ်လို့မရပါဘူး။
        // ထို့ကြောင့် `copy_nonoverlapping` သို့ခေါ်ဆိုမှုသည်လုံခြုံသည်။
        // `dealloc` အတွက်လုံခြုံမှုစာချုပ်ကိုဖုန်းခေါ်ဆိုသူမှထောက်ခံရမည်။
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// မှတ်ဉာဏ်ပိတ်ဆို့မှုကိုကျုံ့ရန်ကြိုးစားသည်။
    ///
    /// pointer နှင့်ခွဲဝေထားသောမှတ်ဉာဏ်၏အရွယ်အစားပါ ၀ င်သည့် [`NonNull<[u8]>`][NonNull] အသစ်တစ်ခုကိုပြန်ပို့သည်။pointer သည် `new_layout` မှဖော်ပြထားသည့်အချက်အလက်များကိုကိုင်တွယ်ရန်သင့်တော်သည်။
    /// ဒီလိုဆောင်ရွက်ရန်, ခွဲဝေသစ်ကို layout ကို fit မှ `ptr` အားဖြင့်ရည်ညွှန်းခွဲဝေချထားကျုံ့စေနိုင်သည်။
    ///
    /// ဒီ `Ok` ပြန်လာလျှင်, `ptr` အားဖြင့်ရည်ညွှန်းမှတ်ဉာဏ်ပိတ်ပင်တားဆီးမှု၏ပိုင်ဆိုင်မှုဒီခွဲဝေလွှဲပြောင်းခဲ့တာဖြစ်ပါတယ်။
    /// အဆိုပါမှတ်ဉာဏ်သို့မဟုတ်မ may လွတ်မြောက်လာပြီစေခြင်းငှါ, ဒါကြောင့်ဒီနည်းလမ်းကို၏ပြန်လာတန်ဖိုးကိုမှတဆင့်ထပ်မံခေါ်ဆိုသူ၏ပြန်လည်လွှဲပြောင်းခံခဲ့ရသည်မဟုတ်လျှင်အသုံးမပြုနိုင်ထည့်သွင်းစဉ်းစားရပါမည်။
    ///
    /// ဒီနည်းလမ်းကို `Err` ပြန်လာလျှင်, ထိုမှတ်ဉာဏ်ပိတ်ပင်တားဆီးမှု၏ပိုင်ဆိုင်မှုဒီခွဲဝေလွှဲပြောင်းနိုင်ခြင်းမရှိသေးပေ, နှင့်မှတ်ဉာဏ်ပိတ်ပင်တားဆီးမှုရဲ့ contents unaltered ဖြစ်ကြသည်။
    ///
    /// # Safety
    ///
    /// * `ptr` ဒီခွဲဝေမှတဆင့်မှတ်ဉာဏ် [*currently allocated*] တစ်ပိတ်ပင်တားဆီးမှုဖျောညှနျးရမည်ဖြစ်သည်။
    /// * `old_layout` မှတ်ဉာဏ်၏ပိတ်ပင်တားဆီးမှု [*fit*] (ဒီ `new_layout` အငြင်းအခုံက fit မလိုအပ်ပါဘူး။) ရပါမည်။
    /// * `new_layout.size()` `old_layout.size()` ထက်သေးငယ်သို့မဟုတ်ညီမျှရမည်။
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// ပြန် `Err` သစ်ကို layout ကိုခွဲဝေချထားရဲ့အရွယ်အစားနှင့်ခွဲဝေချထား၏ alignment ကိုသတ်မကိုက်ညီ, ဒါမှမဟုတ်ကျုံ့မဟုတ်ရင်ပျက်ကွက်လျှင်လျှင်။
    ///
    /// ထိတ်လန့်ခြင်းသို့မဟုတ်ဖျက်သိမ်းခြင်းထက်မှတ်ဉာဏ်ကုန်ခန်းသွားသောအခါ `Err` သို့ပြန်သွားရန်အကောင်အထည်ဖော်မှုကိုအားပေးသည်။ သို့သော်၎င်းသည်တင်းကျပ်သောလိုအပ်ချက်မဟုတ်ပါ။
    /// (အထူးသဖြင့်၊ ၎င်းသည်မှတ်ဥာဏ်အားကုန်ခန်းသွားသောအခြေခံဇာတိခွဲဝေချထားပေးသည့်စာကြည့်တိုက်ပေါ်၌ trait ကိုအကောင်အထည်ဖော်ခြင်းသည် * တရားဝင်ဖြစ်သည်။)
    ///
    /// ခွဲဝေချထားမှုအမှားတစ်ခုအတွက်တွက်ချက်မှုကိုဖျက်သိမ်းလိုသောဖောက်သည်များသည် `panic!` သို့မဟုတ်အလားတူတိုက်ရိုက်မဟုတ်ဘဲ [`handle_alloc_error`] function ကိုခေါ်ရန်တိုက်တွန်းသည်။
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // လုံခြုံမှု-ဘာလို့လဲဆိုတော့ `new_layout.size()` ဟာထက်ငယ်တာဒါမှမဟုတ်ညီမျှရမယ်
        // `old_layout.size()`, မှတ်ဉာဏ်ခွဲဝေအဟောင်းနှင့်အသစ်နှစ်မျိုးလုံးဖတ်နှင့် `new_layout.size()` bytes အဘို့အရေးသားခဲ့သည်များအတွက်တရားဝင်ဖြစ်ကြသည်။
        // ထို့အပြင်အဟောင်းခွဲဝေချထားပေးခြင်းကိုမရသေးသောကြောင့်, သူက `new_ptr` ထပ်လို့မရပါဘူး။
        // ထို့ကြောင့် `copy_nonoverlapping` သို့ခေါ်ဆိုမှုသည်လုံခြုံသည်။
        // `dealloc` အတွက်လုံခြုံမှုစာချုပ်ကိုဖုန်းခေါ်ဆိုသူမှထောက်ခံရမည်။
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// `Allocator` ၏ဤဥပမာတစ်ခု "by reference" adapter ဖန်တီးပေးပါတယ်။
    ///
    /// အဆိုပါပြန်လာသော adapter လည်း `Allocator` အကောင်အထည်ဖော်ဆောင်ရွက်နေသောနှင့်ရိုးရှင်းစွာဒီချေးပါလိမ့်မယ်။
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူမှလုံခြုံရေးစာချုပ်ကိုထိန်းသိမ်းရမည်
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူမှလုံခြုံရေးစာချုပ်ကိုထိန်းသိမ်းရမည်
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူမှလုံခြုံရေးစာချုပ်ကိုထိန်းသိမ်းရမည်
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူမှလုံခြုံရေးစာချုပ်ကိုထိန်းသိမ်းရမည်
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}