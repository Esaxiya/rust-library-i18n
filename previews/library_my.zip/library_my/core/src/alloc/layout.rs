use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// ဒီ function ကိုတစ်နေရာတည်းတွင်အသုံးပြုသည်နှင့်၎င်း၏အကောင်အထည်ဖော်မှု inlined နိုင်နေစဉ်, လုပ်ဖို့ယခင်ကြိုးစားမှုဒါ rustc နှေးကွေးဖန်ဆင်း:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// မှတ်ဉာဏ်တစ်ဘလောက်၏ layout ။
///
/// `Layout` ၏ဥပမာတစ်ခုသည်အထူး layout memory ကိုဖော်ပြသည်။
/// သင်ကခွဲဝေချထားပေးသူပေးရမယ့်ထည့်သွင်းမှုတစ်ခုအနေနဲ့ `Layout` ကိုတည်ဆောက်တယ်။
///
/// အပြင်အဆင်အားလုံးမှာဆက်စပ်တဲ့အရွယ်အစားနဲ့ power-of-two alignment တွေရှိတယ်။
///
/// (`GlobalAlloc` အနေဖြင့်မှတ်ဉာဏ်တောင်းဆိုမှုအားလုံးသည်သုညမဟုတ်သောအရွယ်အစားရှိရန်လိုအပ်သော်လည်း layout များသည်သုညမဟုတ်သောအရွယ်အစားရှိရန်မလိုအပ်ပါ။
/// ခေါ်သူတစ် ဦး သည်ဤကဲ့သို့သောအခြေအနေများကိုသေချာစေရန်၊ ပိုမိုတိကျသောလိုအပ်ချက်များရှိသည့်ခွဲဝေချထားပေးသူများကိုသုံးရန်သို့မဟုတ်ပိုမိုနူးညံ့သော `Allocator` interface ကိုသုံးရန်သေချာစေရမည်။)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // bytes ဖြင့်တိုင်းတာမှတ်ဉာဏ်၏မေတ္တာရပ်ခံပိတ်ပင်တားဆီးမှု၏အရွယ်အစား, ။
    size_: usize,

    // bytes ဖြင့်တိုင်းတာမှတ်ဉာဏ်၏မေတ္တာရပ်ခံပိတ်ပင်တားဆီးမှုများ alignment ကို။
    // API ၏ `posix_memalign` ကဲ့သို့၎င်းသည် Layout တည်ဆောက်သူများအတွက်ချမှတ်ရန်သင့်လျော်သောကန့်သတ်ချက်များကြောင့်၎င်းသည်အမြဲတမ်း power-of-နှစ်ခုဖြစ်ကြောင်းသေချာပါသည်။
    //
    //
    // (သို့သော်ကျွန်ုပ်တို့သည်အလားတူ `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.) မလိုအပ်ပါ
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// ပေးထားသော `size` နှင့် `align` နေ `Layout` Constructs, ဒါမှမဟုတ်အောက်ပါအခြေအနေများမဆိုတွေ့ဆုံခဲ့ကြသည်မဟုတ်လျှင် `LayoutError` ပြန်လည်ရောက်ရှိ:
    ///
    /// * `align` သုညမဖြစ်ရ
    ///
    /// * `align` နှစ်ခုရဲ့စွမ်းအားတစ်ခုဖြစ်ရမယ်၊
    ///
    /// * `size`, အနီးဆုံး `align` ကိုမြှောက်လိုက်တဲ့အခါမလျှော်ရ။ (ဆိုလိုသည်မှာ rounded value သည် `usize::MAX` ထက်နည်းရမည်သို့မဟုတ်ညီရမည်)
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (power-of-နှစ်ခု align!=0. ဆိုလို။)

        // rounded up အရွယ်အစားသည်:
        //   size_rounded_up=(အရွယ်အစား + align, 1)&(align, 1);
        //
        // ကျနော်တို့က align အထက်မှကိုသိ!=0 ။
        // ဖြည့်စွက်ခြင်း (align, 1) သည်မလျောက်ပါက၊
        //
        // အပြန်အလှန်အားဖြင့်&!-kasking! (align, 1) သည် low-order-bits များကိုသာနုတ်ပါလိမ့်မည်။
        // အကယ်၍ overflow sum သည် sum နှင့်အတူဖြစ်ပေါ်လျှင်၊&-mask သည် overflow ကိုဖြုတ်ပစ်ရန်လုံလောက်သောနုတ်နိုင်မည်မဟုတ်ပါ။
        //
        //
        // အထက်တွင်ဖော်ပြချက်များအရ၊
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // လုံခြုံမှု-`from_size_align_unchecked` အတွက်အခြေအနေများရှိသည်
        // အပေါ်က check လုပ်ထား
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// စစ်ဆေးမှုများအားလုံးကိုကျော်လွှားပြီးအပြင်အဆင်တစ်ခုဖန်တီးသည်။
    ///
    /// # Safety
    ///
    /// [`Layout::from_size_align`] ၏ကြိုတင်စည်းကမ်းချက်များကိုအတည်မပြုနိုင်သောကြောင့်ဤလုပ်ဆောင်မှုသည်မလုံခြုံပါ။
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // လုံခြုံမှု-ဖုန်းပြောသူသည် `align` သည်သုညထက်ကြီးကြောင်းသေချာစေရမည်။
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// ဤအပြင်အဆင်၏မှတ်ဉာဏ်ပိတ်ဆို့မှုအတွက်အနည်းဆုံးအရွယ်အစား bytes ။
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// ဒီအပြင်အဆင်၏မှတ်ဉာဏ်ပိတ်ပင်တားဆီးမှုအတွက်အနည်းဆုံး byte alignment ။
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// အမျိုးအစား `T` တန်ဖိုးကိုကိုင်ထားရန်သင့်တော်သော `Layout` တစ်ခုတည်ဆောက်သည်။
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // လုံခြုံမှု-Rust သည် align အားနှစ်လုံးနှင့်စွမ်းအင်အဖြစ်အာမခံသည်
        // size + align combo သည်ကျွန်ုပ်တို့၏လိပ်စာနေရာနှင့်ကိုက်ညီရန်အာမခံသည်။
        // ရလဒ်မှာ panics ကုဒ်ကိုကောင်းမွန်စွာကောင်းမွန်စွာမပြုပြင်နိုင်လျှင်ထည့်သွင်းခြင်းကိုရှောင်ရှားရန်ဤနေရာတွင်ဤနေရာတွင်မစစ်ဆေးရသေးသောဆောက်လုပ်ရေးလုပ်ငန်းကိုအသုံးပြုပါ။
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T` (trait သို့မဟုတ် slice ကဲ့သို့သောအခြား unsized type ဖြစ်နိုင်သည့်) အတွက် backing structure ကိုခွဲဝေချထားပေးရန်အသုံးပြုနိုင်သည့် record တစ်ခုကို layout layout ပြုလုပ်သည်။
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // လုံခြုံမှု: ဒီမလုံခြုံမူကွဲသုံးပြီးအဘယ်ကြောင့် `new` အတွက်တွေ့မြင်ကျိုးကြောင်းဆင်ခြင်
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T` (trait သို့မဟုတ် slice ကဲ့သို့သောအခြား unsized type ဖြစ်နိုင်သည့်) အတွက် backing structure ကိုခွဲဝေချထားပေးရန်အသုံးပြုနိုင်သည့် record တစ်ခုကို layout layout ပြုလုပ်သည်။
    ///
    /// # Safety
    ///
    /// အောက်ဖော်ပြပါအခြေအနေများရှိပါကဤလုပ်ဆောင်မှုသည်ဖုန်းခေါ်ဆိုခြင်းအတွက်လုံခြုံမှုရှိသည်။
    ///
    /// - အကယ်၍ `T` သည် `Sized` ဖြစ်ပါကဤလုပ်ဆောင်မှုသည်ဖုန်းဆက်ရန်အမြဲလုံခြုံသည်။
    /// - `T` ၏အရွယ်အစားမရှိသောအမြီးသည်အကယ်။
    ///     - တစ်ဦး [slice], ထို့နောက်အချပ်အမြီး၏အရှည်တစ်ဦး intialized integer ဖြစ်တဲ့အတွက်သူဖြစ်ရမည်, နှင့် *တစ်ခုလုံးကိုတန်ဖိုးကို၏အရွယ်အစား*(ပြောင်းလဲနေသောအမြီးအရှည် + statically အရွယ်ရှေ့ဆက်) `isize` အတွက် fit ရမည်ဖြစ်သည်။
    ///     - တစ်ဦး [trait object], ထို့နောက် pointer ၏ vtable တစ်စိတ်တစ်ပိုင်း `T` တစ်ခု unsizing coersion ကဝယ်ယူအမျိုးအစားများအတွက်တရားဝင် vtable ထောက်ပြရမယ်, နှင့် *တစ်ခုလုံးကိုတန်ဖိုးကို၏အရွယ်အစား*(ပြောင်းလဲနေသောအမြီးအရှည် + statically အရွယ်ရှေ့ဆက်) `isize` အတွက် fit ရမည်ဖြစ်သည်။
    ///
    ///     - (unstable) [extern type] တစ်ခုဖြစ်လျှင်၊ ဤလုပ်ဆောင်မှုသည်အမြဲတမ်းလုံခြုံမှုရှိနိုင်သည်။ သို့သော်ပြင်ပအမျိုးအစား၏အပြင်အဆင်ကိုမသိသောကြောင့် panic သို့မဟုတ်မှားယွင်းသောတန်ဖိုးကိုပြန်ပို့နိုင်သည်။
    ///     ဒီအပြင်ပ type ကိုအမြီးတစ်ဦးကိုကိုးကားအပေါ် [`Layout::for_value`] ကဲ့သို့တူညီသောအပြုအမူဖြစ်ပါတယ်။
    ///     - မဟုတ်ရင်, ကထိန်းသိမ်းစောင့်ရှောက်ရေးဒီ function ကိုခေါ်ခြင်းခွင့်မပြုပါ။
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // လုံခြုံမှု-ဤလုပ်ဆောင်ချက်များ၏လိုအပ်ချက်များကိုခေါ်ဆိုသူထံသို့ကျွန်ုပ်တို့လွှဲပြောင်းသည်
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // လုံခြုံမှု: ဒီမလုံခြုံမူကွဲသုံးပြီးအဘယ်ကြောင့် `new` အတွက်တွေ့မြင်ကျိုးကြောင်းဆင်ခြင်
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `NonNull` ကို dangling ပြုလုပ်ပေးသည်၊ သို့သော်ဤ Layout အတွက်ကောင်းစွာချိန်ညှိထားသည်။
    ///
    /// သတိပြုရန်မှာ pointer တန်ဖိုးသည်မှန်ကန်သော pointer တစ်ခုဖြစ်နိုင်သည်ဟုဆိုလိုသည်၊ ဆိုလိုသည်မှာ၎င်းသည် "not yet initialized" sentinel value တစ်ခုအဖြစ်အသုံးမပြုရပါ။
    /// လေးတွဲ့စွာခွဲဝေချထားပေးရန်ကြောင်းအမျိုးအစားများတခြားနည်းလမ်းဖြင့်စတင်ခြင်းကိုခြေရာခံရပေမည်။
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // လုံခြုံမှု: align Non-သုညဖြစ်ဖို့အာမခံ
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// `self` ကဲ့သို့တူညီသော layout ကိုတစ်တန်ဖိုးကိုကိုင်နိုငျသောစံချိန်ဖော်ပြတဲ့ layout ကိုဖန်တီးပေးပေမယ့်လည်း alignment ကို `align` (bytes ဖြင့်တိုင်းတာ) ကို aligned ဖြစ်ပါတယ်။
    ///
    ///
    /// အကယ်၍ `self` သည်သတ်မှတ်ထားသောသတ်မှတ်ချက်နှင့်ကိုက်ညီပြီးပါက `self` ကိုပြန်ပို့သည်။
    ///
    /// ဤနည်းလမ်းသည်ပြန်လာသော layout တွင်ကွဲပြားခြားနားသော alignment ရှိမရှိမည်သို့ပင်ဖြစ်စေ၊ padding တစ်ခုလုံးကိုအရွယ်အစားသို့ထည့်သွင်းခြင်းမပြုကြောင်းသတိပြုပါ။
    /// တစ်နည်းအားဖြင့် `K` အရွယ်အစား 16 ရှိပါက `K.align_to(32)` သည် * ၁၆ အထိရှိလိမ့်မည်။
    ///
    /// `self.size()` နှင့်ပေးထားသော `align` ပေါင်းစပ်မှုသည် [`Layout::from_size_align`] တွင်ဖော်ပြထားသောအခြေအနေများကိုချိုးဖောက်ပါကအမှားတစ်ခုကိုပြန်ပို့သည်။
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// အောက်ပါလိပ်စာသည် `align` (bytes ဖြင့်တိုင်းတာသည်) ကျေနပ်မှုရှိစေရန်သေချာစေရန် `self` ပြီးနောက်ထည့်သွင်းရမည့် padding ပမာဏကိုပြန်ပို့ပေးသည်။
    ///
    /// ဥပမာ `self.size()` သည် ၉ ဖြစ်ပါက `self.padding_needed_for(4)` သည် ၃ ကိုပြန်ပို့သည်။ ၄ င်းသည် ၄ ခုသောလိပ်စာတစ်ခုရရှိရန်လိုအပ်သော padding ၏ bytes အနည်းဆုံးအရေအတွက်ဖြစ်သည်။ (သက်ဆိုင်ရာမှတ်ဉာဏ်ပိတ်ဆို့မှုသည် ၄ ခုသောလိပ်စာမှစတင်သည်ဟုယူဆသည်) ။
    ///
    ///
    /// `align` အာဏာ-of နှစ်ခုမပါလျှင်ဒီ function ကို၏ပြန်လာတန်ဖိုးကိုအဘယ်သူမျှမအဓိပ္ပာယ်ကိုရှိပါတယ်။
    ///
    /// အဆိုပါပြန်လာသောတန်ဖိုးကို၏ utility ကိုထက်နည်းသို့မဟုတ်မှတ်ဉာဏ်၏တပြင်လုံးကိုခွဲဝေပိတ်ပင်တားဆီးမှုများအတွက်စတင်လိပ်စာ၏ alignment ကိုမှတူညီဖြစ် `align` လိုအပ်သည်မှတ်ချက်။ဒီကန့်သတ်ချက်ကိုဖြည့်ဆည်းပေးနိုင်တဲ့နည်းတစ်နည်းက `align <= self.align()` ကိုသေချာစေသည်။
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // rounded တက်တန်ဖိုးကိုဖြစ်ပါသည်:
        //   len_rounded_up=(len + align, 1)&(align, 1);
        // ပြီးတော့ padding ခြားနားချက်ကိုပြန်ပေးတယ်။ `len_rounded_up - len`.
        //
        // တစ်လျှောက်လုံး modular arithmetic ကိုအသုံးပြုသည်။
        //
        // 1. align> 0 င်ဖြစ်ဖို့အာမခံ, ဒါ align, 1 အစဉ်အမြဲခိုင်လုံသောဖြစ်ပါတယ်။
        //
        // 2.
        // `len + align - 1` အများဆုံး `align - 1` ဖြင့်ပြည့်လျှံသွားနိုင်သည်၊ ထို့ကြောင့် `!(align - 1)` နှင့်&-mask သည်လျှံထွက်မှုဖြစ်လျှင် `len_rounded_up` ကိုယ်တိုင် ၀ ၀ ဖြစ်လိမ့်မည်။
        //
        //    ထို့ကြောင့် `len` မှဆက်ပြောသည်အခါပြန်လာသော padding ကို, အရာအသေးအဖွဲဝါ alignment ကို `align`, 0 ဖြစ်ထွန်း။
        //
        // (အဘယ်သူ၏အရွယ်အစားနှင့် padding ကိုလျတ်အထက်ပါထုံးစံအတွက်ခွဲဝေဘာပဲဖြစ်ဖြစ်မှားယွင်းမှုတစ်ခုလိုက်လျောစေသင့်တယ်မှတ်ဉာဏ်၏လုပ်ကွက်ခွဲဝေချထားပေးရန်ဖို့ကြိုးစားမှု, သင်တန်း၏။)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// ဒီ layout ၏အရွယ်အစားကို layout ၏ alignment ကို multiple အထိမြှောက်ခြင်းဖြင့် layout ကိုဖန်တီးသည်။
    ///
    ///
    /// ၎င်းသည် `padding_needed_for` ၏ရလဒ်ကိုအပြင်အဆင်၏လက်ရှိအရွယ်အစားသို့ပေါင်းခြင်းနှင့်ညီသည်။
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // ဒီဟာလျှံလို့မရဘူးLayout ၏လျော့ပါးသွားမည်ဖြစ်သလိုထံမှကိုးကား:
        // > `size`, အနီးဆုံး `align` ကိုမြှောက်လိုက်တဲ့အခါ၊
        // > () သည် rounded value သည်ထက်နည်းရမည်
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// `self` ၏ `n` ဖြစ်ရပ်များအတွက်မှတ်တမ်းကိုဖော်ပြထားသည့်အပြင်အဆင်တစ်ခုစီအားတစ်ခုနှင့်တစ်ခုအကြားသင့်တော်သောပမာဏနှင့်အတူ၎င်းင်း၏အရွယ်အစားနှင့်ညှိနှိုင်းမှုကိုသေချာစေရန်စီစဉ်ထားသည်။
    /// အောင်မြင်မှုတွင်, `k` ယင်းစစ်ခင်းကျင်း၏အဆင်အပြင်သည်နှင့် `offs` ယင်းစစ်ခင်းကျင်းတစ်ဦးချင်းစီဒြပ်စင်ရဲ့ start အကြားအကွာအဝေးသည်အဘယ်မှာရှိ `(k, offs)` ပြန်လည်ရောက်ရှိ။
    ///
    /// ဂဏန်းသင်္ချာပိုလျှံတွင်, `LayoutError` ပြန်လည်ရောက်ရှိ။
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // ဒီဟာလျှံလို့မရဘူးLayout ၏လျော့ပါးသွားမည်ဖြစ်သလိုထံမှကိုးကား:
        // > `size`, အနီးဆုံး `align` ကိုမြှောက်လိုက်တဲ့အခါ၊
        // > () သည် rounded value သည်ထက်နည်းရမည်
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // လုံခြုံမှု: self.align ပြီးသားတရားဝင်ဖြစ်ဖို့လူသိများသည်နှင့် alloc_size ခဲ့
        // ပြီးသွားပြီ
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// `self` အတွက်စံချိန်တင် layout တစ်ခုဖန်တီးပြီး `next` နှင့် `next` စနစ်တကျကိုက်ညီမှုရှိစေရန်လိုအပ်သည့် padding များပါ ၀ င်သည်။ သို့သော်နောက်ကွယ်မှ padding မရှိပါ။
    ///
    /// `repr(C)` layout ကိုကို C ကိုယ်စားပြုမှုကိုက်ညီရန်အလို့ငှာ, သင်တို့ရှိသမျှသည်လယ်ကွင်းနှင့်အတူ layout ကိုတိုးချဲ့ပြီးနောက် `pad_to_align` မခေါ်သင့်ပါတယ်။
    /// (ပုံမှန် Rust ကိုယ်စားပြုမှုပုံစံ `repr(Rust)`, as it is unspecified.) နှင့်ကိုက်ညီရန်နည်းလမ်းမရှိပါ
    ///
    /// အစိတ်အပိုင်းနှစ်ခုစလုံး၏ညှိနှိုင်းမှုကိုသေချာစေရန်အလို့ငှာရလဒ်အဆင်အပြင်ကိုချိန်ညှိခြင်းသည် `self` နှင့် `next` တို့၏အမြင့်ဆုံးဖြစ်မည်ကိုသတိပြုပါ။
    ///
    /// `k` သည် concatenated record ၏ layout ဖြစ်ပြီး `offset` သည် bytes တွင် concatenated record အတွင်းတွင်ထည့်သွင်းထားသော `next` ၏ start ၏ဆွေမျိုးတည်နေရာဖြစ်သော `Ok((k, offset))` ကိုပြန်သွားသည် (စံချိန်ကိုယ်တိုင်က offset 0 တွင်စတင်သည်ဟုယူဆသည်) ။
    ///
    ///
    /// ဂဏန်းသင်္ချာပိုလျှံတွင်, `LayoutError` ပြန်လည်ရောက်ရှိ။
    ///
    /// # Examples
    ///
    /// `#[repr(C)]` ဖွဲ့စည်းပုံနှင့်အကွက်တွင်၎င်း၏ကွက်လပ်များ၏အပြင်အဆင်များမှအဆင်အပြင်ကိုတွက်ချက်ရန်
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // `pad_to_align` နဲ့အပြီးသတ်ဖို့သတိရပါ!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // အဲဒါအလုပ်လုပ်တယ်ဆိုတာစစ်ဆေးပါ
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// `self` ၏ `n` ဖြစ်ရပ်များအတွက်စံချိန်တင်ဖော်ပြမှုပုံစံတစ်ခုကိုဖန်တီးသည်။
    ///
    /// သတိပြုပါ၊ `repeat` နှင့်မတူဘဲ `repeat_packed` သည် `self` ၏ထပ်ခါတလဲလဲဖြစ်ရပ်များသည် `self` ၏ဥပမာအားဖြင့်စနစ်တကျကိုက်ညီမှုရှိလျှင်တောင်မှစနစ်တကျမြှင့်တင်သွားမည်ဟုအာမမခံပါ။
    /// တစ်နည်းအားဖြင့် `repeat_packed` မှပြန်လာသော layout ကို array တစ်ခုခွဲဝေရန်အသုံးပြုသည်ဆိုပါက array အတွင်းရှိ element များအားလုံးကိုစနစ်တကျညှိနှိုင်းလိမ့်မည်ဟုအာမခံချက်မရှိပါ။
    ///
    /// ဂဏန်းသင်္ချာပိုလျှံတွင်, `LayoutError` ပြန်လည်ရောက်ရှိ။
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// `self` အတွက်စံချိန်တင် layout ကိုဖန်တီးပြီး `next` နောက်နှစ်ခုထပ်အပိုထပ်မရှိဘဲ layout တစ်ခုဖန်တီးသည်။
    /// အဘယ်သူမျှမ padding ကိုဖြည့်စွက်တာဖြစ်ပါတယ်ကတည်းက `next` ၏ alignment ကိုဆီလျှော်သည်နှင့်ထွက်ပေါ်လာသော layout ကိုသို့အားလုံး *မှာ* ထည့်သွင်းမထားပါ။
    ///
    ///
    /// ဂဏန်းသင်္ချာပိုလျှံတွင်, `LayoutError` ပြန်လည်ရောက်ရှိ။
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// `[T; n]` အတွက်စံချိန်တင်မည့်ပုံစံကိုဖန်တီးသည်။
    ///
    /// ဂဏန်းသင်္ချာပိုလျှံတွင်, `LayoutError` ပြန်လည်ရောက်ရှိ။
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// `Layout::from_size_align` သို့မဟုတ်အချို့သောအခြား `Layout` လုပ်ငန်းခွင်သို့ပေးသော parameters သည်၎င်း၏မှတ်တမ်းတင်ထားသောကန့်သတ်ချက်များကိုကျေနပ်မှုမရှိပါ။
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (ဤအရာသည် trait အမှား၏အောက်ပိုင်း impl အတွက်ကျွန်ုပ်တို့လိုအပ်သည်။)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}