//! အဆိုပါ libcore prelude
//!
//! ဤ module သည် libstd နှင့်လည်းချိတ်ဆက်မှုမရှိသော libcore အသုံးပြုသူများအတွက်ရည်ရွယ်သည်။
//! `#![no_std]` ကိုပုံမှန်စာကြည့်တိုက်၏ prelude ကဲ့သို့တူညီသောနည်းလမ်းဖြင့်အသုံးပြုသည့်အခါဤ module ကိုပုံမှန်အားဖြင့်တင်သွင်းသည်။
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// အဓိက prelude ၏ ၂၀၁၅ ဗားရှင်း။
///
/// ပိုပြီးများအတွက် [module-level documentation](self) ကိုကြည့်ပါ။
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// အဓိက prelude ၏ 2018 ဗားရှင်း။
///
/// ပိုပြီးများအတွက် [module-level documentation](self) ကိုကြည့်ပါ။
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// 2021 အဓိက prelude ဗားရှင်း။
///
/// ပိုပြီးများအတွက် [module-level documentation](self) ကိုကြည့်ပါ။
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: ပိုပြီးသောအရာတို့ကိုထည့်ပါ။
}