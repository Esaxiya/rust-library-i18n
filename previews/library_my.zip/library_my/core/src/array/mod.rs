//! လူတယောက်အရှည်အထိ fixed-အရှည် Array ကိုအဘို့အ `Eq` တူသောအရာအကောင်အထည်ဖော်မှု။
//! နောက်ဆုံးတော့အားလုံးအရှည်မှယဘေုယနိုင်မည်ဖြစ်သင့်သည်။
//!
//! *[See also the array primitive type](array).*
//!

#![stable(feature = "core_array", since = "1.36.0")]

use crate::borrow::{Borrow, BorrowMut};
use crate::cmp::Ordering;
use crate::convert::{Infallible, TryFrom};
use crate::fmt;
use crate::hash::{self, Hash};
use crate::iter::TrustedLen;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{Index, IndexMut};
use crate::slice::{Iter, IterMut};

mod iter;

#[stable(feature = "array_value_iter", since = "1.51.0")]
pub use iter::IntoIter;

/// `T` တစ်ခုရည်ညွှန်းချက်ကိုအရှည် 1 (ခင်းကျင်းခြင်းမရှိဘဲ) တစ်ခုအညွှန်းတစ်ခုအဖြစ်ရည်ညွှန်းသည်။
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_ref<T>(s: &T) -> &[T; 1] {
    // လုံခြုံမှု-`&T` သို့ `&[T; 1]` သို့ပြောင်းခြင်းသည်အသံဖြစ်သည်။
    unsafe { &*(s as *const T).cast::<[T; 1]>() }
}

/// `T` သို့ပြောင်းလဲနိုင်သောရည်ညွှန်းချက်ကို (ကူးယူခြင်းမရှိဘဲ) အရှည် ၁ ခင်းကျင်းခြင်းသို့ပြောင်းနိုင်သောရည်ညွှန်းချက်အဖြစ်ပြောင်းသည်။
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_mut<T>(s: &mut T) -> &mut [T; 1] {
    // လုံခြုံမှု: `&mut [T; 1]` မှ `&mut T` ပြောင်းသံကိုဖြစ်ပါတယ်။
    unsafe { &mut *(s as *mut T).cast::<[T; 1]>() }
}

/// utility trait fixed အရွယ်အစား Array ကိုသာအကောင်အထည်ဖော်
///
/// ဤ trait သည်အခြား traits များကို metadata bloat မဖြစ်စေဘဲပုံသေအရွယ်အစားရှိသော Array များပေါ်တွင်အကောင်အထည်ဖော်နိုင်သည်။
///
/// implementors များကို fixed-size Array များကန့်သတ်ရန် trait သည်လုံခြုံမှုမရှိကြောင်းမှတ်သားထားသည်။
/// ဒီ trait ၏အသုံးပြုသူတစ်ဦး implementors (ဥပမာ, မလုံခြုံစတင်ခြင်းအတွက်) တစ်ဦး fixed size ကိုခင်းကျင်း၏မှတ်ဉာဏ်ထဲမှာအတိအကျ layout ကိုရှိသည်ယူဆနိုင်ပါတယ်။
///
///
/// သတိပြုရန်မှာ traits [`AsRef`] နှင့် [`AsMut`] သည်ပုံသေအရွယ်အစားမတူသောအမျိုးအစားများအတွက်အလားတူနည်းလမ်းများဖြစ်သည်။
/// Implementors အစားသူတို့အား traits ကြိုက်တတ်တဲ့သငျ့သညျ။
///
///
///
#[unstable(feature = "fixed_size_array", issue = "27778")]
pub unsafe trait FixedSizeArray<T> {
    /// converter မပြောင်းလဲနိုင်သောအရာများအချပ်ဖို့ခင်းကျင်း
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_slice(&self) -> &[T];
    /// array ကို mutable slice အဖြစ်ပြောင်းသည်
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_mut_slice(&mut self) -> &mut [T];
}

#[unstable(feature = "fixed_size_array", issue = "27778")]
unsafe impl<T, A: Unsize<[T]>> FixedSizeArray<T> for A {
    #[inline]
    fn as_slice(&self) -> &[T] {
        self
    }
    #[inline]
    fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }
}

/// slice တစ်ခုမှ array သို့ပြောင်းလဲခြင်းပျက်ကွက်သောအခါအမှားအမျိုးအစားပြန်လာသည်။
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone)]
pub struct TryFromSliceError(());

#[stable(feature = "core_array", since = "1.36.0")]
impl fmt::Display for TryFromSliceError {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self.__description(), f)
    }
}

impl TryFromSliceError {
    #[unstable(
        feature = "array_error_internals",
        reason = "available through Error trait and this method should not \
                     be exposed publicly",
        issue = "none"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "could not convert slice to array"
    }
}

#[stable(feature = "try_from_slice_error", since = "1.36.0")]
impl From<Infallible> for TryFromSliceError {
    fn from(x: Infallible) -> TryFromSliceError {
        match x {}
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsRef<[T]> for [T; N] {
    #[inline]
    fn as_ref(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsMut<[T]> for [T; N] {
    #[inline]
    fn as_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> Borrow<[T]> for [T; N] {
    fn borrow(&self) -> &[T] {
        self
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> BorrowMut<[T]> for [T; N] {
    fn borrow_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<T, const N: usize> TryFrom<&[T]> for [T; N]
where
    T: Copy,
{
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<[T; N], TryFromSliceError> {
        <&Self>::try_from(slice).map(|r| *r)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a [T]> for &'a [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<&[T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_ptr() as *const [T; N];
            // လုံခြုံမှု-အရှည်နှင့်ကိုက်ညီမှုရှိမရှိကိုစစ်ဆေးသောကြောင့်ဖြစ်သည်
            unsafe { Ok(&*ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a mut [T]> for &'a mut [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &mut [T]) -> Result<&mut [T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_mut_ptr() as *mut [T; N];
            // လုံခြုံမှု-အရှည်နှင့်ကိုက်ညီမှုရှိမရှိကိုစစ်ဆေးသောကြောင့်ဖြစ်သည်
            unsafe { Ok(&mut *ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, const N: usize> Hash for [T; N] {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        Hash::hash(&self[..], state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for [T; N] {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&&self[..], f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a [T; N] {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a mut [T; N] {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> Index<I> for [T; N]
where
    [T]: Index<I>,
{
    type Output = <[T] as Index<I>>::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(self as &[T], index)
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> IndexMut<I> for [T; N]
where
    [T]: IndexMut<I>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(self as &mut [T], index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B; N]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &[B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&mut [B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&mut [B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&mut [B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &mut [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

// NOTE: အချို့သောလျော့နည်းအရေးကြီးသောအကျိုးသက်ရောက်မှုများ code bloat ကိုလျှော့ချရန်ချန်လှပ်ထားပါသည်
// __impl_slice_eq2!{ [A; $N], &'b [B; $N] } __impl_slice_eq2! { [A; $N], &'b mut [B; $N] }
//

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, const N: usize> Eq for [T; N] {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, const N: usize> PartialOrd for [T; N] {
    #[inline]
    fn partial_cmp(&self, other: &[T; N]) -> Option<Ordering> {
        PartialOrd::partial_cmp(&&self[..], &&other[..])
    }
    #[inline]
    fn lt(&self, other: &[T; N]) -> bool {
        PartialOrd::lt(&&self[..], &&other[..])
    }
    #[inline]
    fn le(&self, other: &[T; N]) -> bool {
        PartialOrd::le(&&self[..], &&other[..])
    }
    #[inline]
    fn ge(&self, other: &[T; N]) -> bool {
        PartialOrd::ge(&&self[..], &&other[..])
    }
    #[inline]
    fn gt(&self, other: &[T; N]) -> bool {
        PartialOrd::gt(&&self[..], &&other[..])
    }
}

/// Array [lexicographically](Ord#lexicographical-comparison) ကိုနှိုင်းယှဉ်ခြင်း။
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, const N: usize> Ord for [T; N] {
    #[inline]
    fn cmp(&self, other: &[T; N]) -> Ordering {
        Ord::cmp(&&self[..], &&other[..])
    }
}

// `[T; 0]` သည်ပုံမှန်အားဖြင့်အကောင်အထည်ဖော်ရန်မလိုအပ်ပါ။ ကွဲပြားသောနံပါတ်များအတွက်ကွဲပြားသော impl blocks များမပါရှိပါက Default impls ကို const generics များနှင့်မပြုလုပ်နိုင်ပါ။
//
//

macro_rules! array_impl_default {
    {$n:expr, $t:ident $($ts:ident)*} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] where T: Default {
            fn default() -> [T; $n] {
                [$t::default(), $($ts::default()),*]
            }
        }
        array_impl_default!{($n - 1), $($ts)*}
    };
    {$n:expr,} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] {
            fn default() -> [T; $n] { [] }
        }
    };
}

array_impl_default! {32, T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T}

#[lang = "array"]
impl<T, const N: usize> [T; N] {
    /// element တစ်ခုချင်းစီကို function `f` ကိုအသုံးချပြီး `self` ကဲ့သို့အရွယ်အစားတူညီသည့် array တစ်ခုကိုပြန်ပို့သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_map)]
    /// let x = [1, 2, 3];
    /// let y = x.map(|v| v + 1);
    /// assert_eq!(y, [2, 3, 4]);
    ///
    /// let x = [1, 2, 3];
    /// let mut temp = 0;
    /// let y = x.map(|v| { temp += 1; v * temp });
    /// assert_eq!(y, [1, 4, 9]);
    ///
    /// let x = ["Ferris", "Bueller's", "Day", "Off"];
    /// let y = x.map(|v| v.len());
    /// assert_eq!(y, [6, 9, 3, 3]);
    /// ```
    #[unstable(feature = "array_map", issue = "75243")]
    pub fn map<F, U>(self, f: F) -> [U; N]
    where
        F: FnMut(T) -> U,
    {
        // လုံခြုံမှု: ကြှနျုပျတို့သညျဤကြားမှာအတိအကျ `N` လိုက်လျောလိမ့်မည်ဟုအချို့သောအဘို့ကိုသိရ
        // items.
        unsafe { collect_into_array_unchecked(&mut IntoIter::new(self).map(f)) }
    }

    /// Array နှစ်ခုကို array တစ်ခုစီသို့ 'zips up' လုပ်သည်။
    ///
    /// `zip()` ပထမ element ကပထမ array ကနေထွက်လာတယ်၊ နောက် element ကဒုတိယ array ကလာတာ။
    ///
    /// တနည်းအားဖြင့်၎င်းသည် Array နှစ်ခုကိုတစ်ခုတည်းသို့ zip လုပ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_zip)]
    /// let x = [1, 2, 3];
    /// let y = [4, 5, 6];
    /// let z = x.zip(y);
    /// assert_eq!(z, [(1, 4), (2, 5), (3, 6)]);
    /// ```
    ///
    #[unstable(feature = "array_zip", issue = "80094")]
    pub fn zip<U>(self, rhs: [U; N]) -> [(T, U); N] {
        let mut iter = IntoIter::new(self).zip(IntoIter::new(rhs));

        // လုံခြုံမှု: ကြှနျုပျတို့သညျဤကြားမှာအတိအကျ `N` လိုက်လျောလိမ့်မည်ဟုအချို့သောအဘို့ကိုသိရ
        // items.
        unsafe { collect_into_array_unchecked(&mut iter) }
    }

    /// တစ်ခုလုံးခင်းကျင်းင်တစ်ဦးအချပ် Returns ။`&s[..]` ညီမျှ။
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// တစ်ခုလုံးခင်းကျင်းင်တစ်ဦး mutable အချပ် Returns ။
    /// `&mut s[..]` နှင့်ညီမျှသည်။
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// element တစ်ခုချင်းစီကိုငှားယူပြီး `self` ကဲ့သို့အရွယ်အစားတူသောကိုးကားစရာများကိုပြန်လည်ပေးပို့သည်။
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&f64; 3] = floats.each_ref();
    /// assert_eq!(float_refs, [&3.1, &2.7, &-1.0]);
    /// ```
    ///
    /// ဤနည်းလမ်းသည် [`map`](#method.map) ကဲ့သို့သောအခြားနည်းလမ်းများနှင့်ပေါင်းစပ်ပါကအထူးအသုံးဝင်သည်။
    /// ဤနည်းအားဖြင့်မူရင်း array ကို၎င်း၏ element များ `Copy` မဟုတ်လျှင်ရွေ့လျားခြင်းကိုရှောင်ရှားနိုင်သည်။
    ///
    /// ```
    /// #![feature(array_methods, array_map)]
    ///
    /// let strings = ["Ferris".to_string(), "♥".to_string(), "Rust".to_string()];
    /// let is_ascii = strings.each_ref().map(|s| s.is_ascii());
    /// assert_eq!(is_ascii, [true, false, true]);
    ///
    /// // ကျနော်တို့နေဆဲမူရင်းခင်းကျင်းရယူနိုင်သည်ကြောင့်ပြောင်းရွှေ့နိုင်ခြင်းမရှိသေးပေ။
    /// assert_eq!(strings.len(), 3);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_ref(&self) -> [&T; N] {
        // လုံခြုံမှု: ကြှနျုပျတို့သညျဤကြားမှာအတိအကျ `N` လိုက်လျောလိမ့်မည်ဟုအချို့သောအဘို့ကိုသိရ
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter()) }
    }

    /// mutably တစ်ဦးချင်းစီဒြပ်စင်ငှါးနှင့် `self` ကဲ့သို့တူညီသောအရွယ်အစားနှင့်အတူ mutable ကိုးကားတွေရဲ့ array ပြန်လည်ရောက်ရှိ။
    ///
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let mut floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&mut f64; 3] = floats.each_mut();
    /// *float_refs[0] = 0.0;
    /// assert_eq!(float_refs, [&mut 0.0, &mut 2.7, &mut -1.0]);
    /// assert_eq!(floats, [0.0, 2.7, -1.0]);
    /// ```
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_mut(&mut self) -> [&mut T; N] {
        // လုံခြုံမှု: ကြှနျုပျတို့သညျဤကြားမှာအတိအကျ `N` လိုက်လျောလိမ့်မည်ဟုအချို့သောအဘို့ကိုသိရ
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter_mut()) }
    }
}

/// `iter` မှ `N` ပစ္စည်းများကိုဆွဲထုတ်ပြီး၎င်းတို့ကိုမက်ထရစ်အဖြစ်ပြန်ပို့သည်။
/// အကယ်၍ ကြားနေသည် `N` ပစ္စည်းများထက်နည်းပါကဤလုပ်ဆောင်မှုသည်သတ်မှတ်ထားသောအပြုအမူကိုပြသည်။
///
///
/// ပိုမိုသိရှိလိုပါက [`collect_into_array`] တွင်ကြည့်ပါ။
///
/// # Safety
///
/// ဒါဟာ `iter` အနည်းဆုံး `N` ပစ္စည်းများမှာဖြစ်ထွန်းကြောင်းအာမခံချက်ပေးဖို့ခေါ်ဆိုသူ၏အထိဖြစ်ပါတယ်။
/// ဒီအခွအေနေချိုးဖောက် undefined အပြုအမူကိုဖြစ်ပေါ်စေသည်။
unsafe fn collect_into_array_unchecked<I, const N: usize>(iter: &mut I) -> [I::Item; N]
where
    // Note: `TrustedLen` ကဒီမှာအတန်ငယ်စမ်းသပ်မှုတစ်ခုဖြစ်ပါသည်။ဒါရုံတစ်ခုပါ
    // Internal function ဒါကြောင့်ဒီကန့်သတ်ချက်ဟာမကောင်းတဲ့အကြံတစ်ခုဖြစ်ခဲ့ရင်ဖယ်ရှားပစ်ဖို့လိုပါတယ်။
    // အောက်ပါအနိမ့်ဆုံး `debug_assert!` ကိုလည်းဖယ်ရှားရန်သတိရပါ။
    //
    I: Iterator + TrustedLen,
{
    debug_assert!(N <= iter.size_hint().1.unwrap_or(usize::MAX));
    debug_assert!(N <= iter.size_hint().0);

    match collect_into_array(iter) {
        Some(array) => array,
        // လုံခြုံမှု-လုပ်ဆောင်ချက်စာချုပ်ပါ ၀ င်သည်။
        None => unsafe { crate::hint::unreachable_unchecked() },
    }
}

/// `iter` မှ `N` ပစ္စည်းများကိုဆွဲထုတ်ပြီး၎င်းတို့ကိုမက်ထရစ်တစ်ခုအဖြစ်ပြန်လည်ပေးသည်။အကယ်၍ ကြားနေသူသည် `N` ပစ္စည်းများထက်နည်းလျှင်အချိန်ပြန်လျှင် `None` ကိုပြန်ပို့ပြီးထုတ်ပေးသောအရာများအားလုံးကျဆင်းသွားသည်။
///
/// iterator သည် mutable reference တစ်ခုအနေဖြင့်ဖြတ်သန်းသွားပြီး၊ ဤလုပ်ဆောင်မှုသည် `N` အကြိမ်အများစုတွင် `next` ကိုခေါ်သောကြောင့်၎င်းသည်ကျန်ရှိသောပစ္စည်းများပြန်လည်ရယူရန်အတွက်နောက်မှအသုံးပြုနိုင်သည်။
///
///
/// အကယ်၍ `iter.next()` သည်ထိတ်လန့်သွားလျှင်၊
///
///
///
///
fn collect_into_array<I, const N: usize>(iter: &mut I) -> Option<[I::Item; N]>
where
    I: Iterator,
{
    if N == 0 {
        // လုံခြုံမှု-အချည်းနှီးသောခင်းကျင်းခြင်းသည်အမြဲတမ်းလူနေမှုအဆင့်အတန်းရှိပြီးတရားဝင်ကျဆင်းမှုမရှိသေးပါ။
        return unsafe { Some(mem::zeroed()) };
    }

    struct Guard<T, const N: usize> {
        ptr: *mut T,
        initialized: usize,
    }

    impl<T, const N: usize> Drop for Guard<T, N> {
        fn drop(&mut self) {
            debug_assert!(self.initialized <= N);

            let initialized_part = crate::ptr::slice_from_raw_parts_mut(self.ptr, self.initialized);

            // လုံခြုံမှု-ဤကုန်ကြမ်းအချပ်သည်အစပျိုးပစ္စည်းများသာဖြစ်သည်။
            unsafe {
                crate::ptr::drop_in_place(initialized_part);
            }
        }
    }

    let mut array = MaybeUninit::uninit_array::<N>();
    let mut guard: Guard<_, N> =
        Guard { ptr: MaybeUninit::slice_as_mut_ptr(&mut array), initialized: 0 };

    while let Some(item) = iter.next() {
        // လုံခြုံမှု: `guard.initialized` သည် ၀ မှ 0 တွင်စတင်သည်၊
        // loop နှင့် N (သို့) `array.len()`) သို့ရောက်သောအခါ loop ကိုဖျက်သိမ်းသည်။
        //
        unsafe {
            array.get_unchecked_mut(guard.initialized).write(item);
        }
        guard.initialized += 1;

        // မြေတပြင်လုံးခင်းကျင်းနခံခဲ့ရလျှင်စစ်ဆေးပါ။
        if guard.initialized == N {
            mem::forget(guard);

            // လုံခြုံမှု: အထက်တွင်အခြေအနေကိုအားလုံးဒြပ်စင်များမှာပြောဆိုသော
            // initialized.
            let out = unsafe { MaybeUninit::array_assume_init(array) };
            return Some(out);
        }
    }

    // `guard.initialized` `N` သို့မရောက်မီကြားဖြတ်သည်ကုန်ဆုံးမှသာယင်းသို့ရောက်ရှိနိုင်သည်။
    //
    // ဒါ့အပြင် `guard` အားလုံးပြီးသားန element တွေကိုရုတ်သိမ်းဒီမှာကျဆင်းသွားကြောင်းသတိပြုပါ။
    None
}