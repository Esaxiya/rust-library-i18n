//! အဆိုပါ `IntoIter` Array ကိုအဘို့ကြားမှာပိုင်အဖြစ်သတ်မှတ်ပါတယ်။

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// by-တန်ဖိုးကို [array] ကြားမှာတစ်ဦး။
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// ဒါကကျနော်တို့ကျော် iterating နေသောခင်းကျင်းသည်။
    ///
    /// `alive.start <= i < alive.end` သေးလြှော့နှင့်တရားဝင်ခင်းကျင်း entries တွေကိုဖြစ်ကြသည်ကြပြီမဟုတ်ဘယ်မှာအညွှန်းကိန်း `i` နှင့်အတူ elements ။
    /// ညွန်ကိန်းအညွှန်းများဖြစ်သော `i < alive.start` သို့မဟုတ် `i >= alive.end` ပါ ၀ င်သောဒြပ်ပေါင်းများကိုထုတ်လုပ်ပြီးဖြစ်ပြီးပြီ။သူများသည်အသေအကျိတ်ဒြပ်စင်လုံးဝ uninitialized ပြည်နယ်အတွက်ဖြစ်လိမ့်မယ်!
    ///
    ///
    /// ဒီတော့လျော့ပါးသွားမည်ဖြစ်သလိုနေသောခေါင်းစဉ်:
    /// - `data[alive]` အသက်ရှင်နေသည် (ဆိုလိုသည်မှာခိုင်လုံသောဒြပ်စင်များပါရှိသည်)
    /// - `data[..alive.start]` နှင့် `data[alive.end..]` (ဆိုလိုသည်မှာဒြပ်စင်ပြီးသားကိုဖတ်ရှုခဲ့ကြခြင်းနှင့်တော့ဘူးတို့ထိမရရမယ်!) သေကြ
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// သေးလြှော့ရကြပြီမဟုတ်ကြောင်း `data` အတွက် element တွေ။
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// ပေးထားသော `array` ကျော်ကြားဖြတ်အသစ်ဖန်တီးသည်။
    ///
    /// *မှတ်စု*: ဤနည်းလမ်းသည် [`IntoIterator` is implemented for arrays][array-into-iter] ပြီးနောက် future တွင်ကန့်ကွက်ခံရနိုင်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // `value` အမျိုးအစားအစား `&i32` ၏, ဒီမှာ `i32` ဖြစ်ပါသည်
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // လုံခြုံမှု-ဒီကနေကူးစက်နိုင်တဲ့ပစ္စည်းကတကယ်အန္တရာယ်ကင်းတယ်။`MaybeUninit` ၏စာရွက်စာတမ်းများ
        // promise:
        //
        // > `MaybeUninit<T>` တူညီတဲ့အရွယ်အစားနှင့် alignment ကိုရှိသည်ဖို့အာမခံချက်ဖြစ်ပါတယ်
        // > `T` အဖြစ်။
        //
        // မှတ်တမ်းမှတ်ရာများသည် `MaybeUninit<T>` ၏အစုအဝေးတစ်ခုမှ `T` တစ်ခုအထိပြန့်ပွားမှုကိုပြသသည်။
        //
        //
        // ကြောင်းနှင့်အတူ, ဒီစတင်လျော့ပါးသွားမည်ဖြစ်သလိုကျေနပ်။

        // FIXME(LukasKalbertodt): အမှန်တကယ်ဒီမှာ `mem::transmute` ကိုသုံးပါ၊ ၎င်းသည် const generics နှင့်အလုပ်လုပ်သည်နှင့်တပြိုင်နက်
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // ထိုအချိန်အထိကျွန်ုပ်တို့သည် `mem::transmute_copy` ကို သုံး၍ bitwise copy ကိုအခြားအမျိုးအစားတစ်ခုအဖြစ်ဖန်တီးနိုင်သည်။ ထို့နောက် `array` ကိုမေ့သွားအောင်မေ့သွားသည်။
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// သေးအလျှော့ပေးလိုက်လျောကြပြီမဟုတ်အားလုံးဒြပ်စင်တစ်ခုမပြောင်းလဲနိုင်သောအရာများအချပ်ပြန်သွားသည်။
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // လုံခြုံမှု-`alive` အတွင်းရှိအရာ ၀ တ္ထုများအားလုံးကိုစနစ်တကျအစပြုထားသည်ကိုကျွန်ုပ်တို့သိသည်။
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// သေးလြှော့ရကြပြီမဟုတ်သောသူအပေါင်းတို့သည်ဒြပ်စင်တစ်ခု mutable အချပ် Returns ။
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // လုံခြုံမှု-`alive` အတွင်းရှိအရာ ၀ တ္ထုများအားလုံးကိုစနစ်တကျအစပြုထားသည်ကိုကျွန်ုပ်တို့သိသည်။
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // အိမ်ရှေ့ကနေလာမယ့်အညွှန်းကိန်းကိုရယူပါ။
        //
        // `alive.start` ကို 1 တိုးခြင်းဖြင့် `alive` နှင့်ပတ်သက်ပြီးလျော့ပါးသွားမည်မဟုတ်ပေ။
        // သို့သော်ဤပြောင်းလဲမှုကြောင့်အချိန်တိုအတွင်းသက်ရှိဇုန်သည် `data[alive]` မဟုတ်တော့ဘဲ `data[idx..alive.end]` ဖြစ်သည်။
        //
        self.alive.next().map(|idx| {
            // array ထဲက element ကိုဖတ်ပါ။
            // လုံခြုံမှု: `idx` ၏ယခင် "alive" ဒေသတွင်းသို့ထားတဲ့အညွှန်းကိန်းဖြစ်ပါသည်
            // ခင်းကျင်း။ဤ element ကိုဖတ်ခြင်းသည်ဆိုလိုသည်မှာ `data[idx]` ကိုယခုသေပြီ (ဆိုလိုသည်မှာထိစရာမဟုတ်ပါ) ဟုဆိုလိုသည်။
            // `idx` သည်သက်ရှိဇုန်၏အစဖြစ်သဖြင့်သက်ရှိဇုန်သည်နောက်တဖန် `data[alive]` ဖြစ်ပြီးလျော့ပါးသွားမည်ဖြစ်သောလူအားလုံးကိုပြန်ယူပေးသည်။
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // နောက်ကျောကနေနောက်အညွှန်းကိန်းရယူပါ။
        //
        // 1 `alive.end` လျော့ကျလာ `alive` ပတ်သက်. လျော့ပါးသွားမည်ဖြစ်သလိုထိန်းသိမ်းထားသည်။
        // သို့သော်ဤပြောင်းလဲမှုကြောင့်အချိန်တိုအတွင်းသက်ရှိဇုန်သည် `data[alive]` မဟုတ်တော့ဘဲ `data[alive.start..=idx]` ဖြစ်သည်။
        //
        self.alive.next_back().map(|idx| {
            // array ထဲက element ကိုဖတ်ပါ။
            // လုံခြုံမှု: `idx` ၏ယခင် "alive" ဒေသတွင်းသို့ထားတဲ့အညွှန်းကိန်းဖြစ်ပါသည်
            // ခင်းကျင်း။ဤ element ကိုဖတ်ခြင်းသည်ဆိုလိုသည်မှာ `data[idx]` ကိုယခုသေပြီ (ဆိုလိုသည်မှာထိစရာမဟုတ်ပါ) ဟုဆိုလိုသည်။
            // `idx` သည်သက်ရှိဇုန်၏အဆုံးဖြစ်သဖြင့်သက်ရှိဇုန်သည်နောက်တဖန် `data[alive]` ဖြစ်သည်။
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // လုံခြုံမှု: ဒီလုံခြုံဖြစ်ပါသည်: `as_mut_slice` အတိအကျခွဲစိပ်ပြန်လည်ရောက်ရှိ
        // သေးထွက်ပြောင်းရွှေ့ကြောင်းကျဆင်းသွားခံရဖို့ဆက်လက်တည်ရှိကြပြီမဟုတ်ကြောင်းဒြပ်စင်၏။
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // အဆိုပါလျော့ပါးသွားမည်ဖြစ်သလို `alive.start <=ကြောင့် underflow ဘယ်တော့မှလိမ့်မည်
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// အဆိုပါကြားမှာအမှန်ပင်မှန်ကန်သောအရှည်ကတင်ပြထားပါတယ်။
// (နေဆဲလြှော့မည်) "alive" ဒြပ်စင်အရေအတွက်အကွာအဝေး `alive` ၏အရှည်သည်။
// ဒီအကွာအဝေး `next` သို့မဟုတ် `next_back` ဖြစ်စေအရှည်အတွက်လျော့နည်းသွားသည်။
// ၎င်းနည်းလမ်းများတွင်၎င်းကို 1 ဖြင့်အမြဲတစေလျှော့ချပေးသည်၊ သို့သော် `Some(_)` ပြန်လာမှသာလျှင်။
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // သတိပြုပါ၊ ကျွန်ုပ်တို့အသက်ရှင်နေသည့်တူညီသောအကွာအဝေးနှင့်တူညီရန်မလိုအပ်ပါ။ ထို့ကြောင့် `self` သည်မည်သည့်နေရာတွင်ရှိနေသည်ဖြစ်စေကျွန်ုပ်တို့ offset 0 သို့ပုံတူကူးယူနိုင်သည်။
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // အားလုံးသက်ရှိဒြပ်စင် Clone ။
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Clone အသစ်တစ်ခုကို array ထဲကိုရေးထည့်ပြီးရင် live range ကို update လုပ်ပါ။
            // panics ပုံတူပွားခြင်းလျှင်, ငါတို့သည်မှန်ကန်စွာယခင်ပစ္စည်းများ drop ပါလိမ့်မယ်။
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // အလျှော့ပေးလိုက်လျောခြင်းမရှိသေးသော element များကိုသာသာ print ထုတ်ပါ။
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}