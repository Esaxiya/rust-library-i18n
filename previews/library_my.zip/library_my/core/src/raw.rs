#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! built-in အမျိုးအစားများ compiler ၏ layout အတွက် struct definitions ပါဝင်သည်။
//!
//! ၄ င်းတို့ကိုမလုံခြုံသောကုဒ်နံပါတ်များမှတိုက်ရိုက်ထုတ်လွှင့်ရန်အတွက် transmutes ၏ပစ်မှတ်များအဖြစ်အသုံးပြုနိုင်သည်။
//!
//!
//! သူတို့ရဲ့အဓိပ္ပါယ်က `rustc_middle::ty::layout` မှာဖော်ပြထားတဲ့ ABI နဲ့အမြဲတမ်းကိုက်ညီသင့်တယ်။
//!

/// `&dyn SomeTrait` ကဲ့သို့သော trait အရာဝတ္ထုတစ်ခု၏ကိုယ်စားပြုမှု။
///
/// ဤတည်ဆောက်ပုံသည် `&dyn SomeTrait` နှင့် `Box<dyn AnotherTrait>` ကဲ့သို့သောပုံစံနှင့်အတူတူဖြစ်သည်။
///
/// `TraitObject` အပြင်အဆင်များနှင့်ကိုက်ညီရန်အာမခံချက်ရှိသည်၊ သို့သော်၎င်းသည် trait အရာဝတ္ထုအမျိုးအစားမဟုတ်ပါ (ဥပမာ-နယ်ပယ်များသည် `&dyn SomeTrait` တွင်တိုက်ရိုက်ကြည့်ရှုနိုင်ခြင်းမရှိပါ) သို့မဟုတ်၎င်း layout ကိုမထိန်းချုပ်နိုင်ပါ။ (အဓိပ္ပါယ်ပြောင်းလဲခြင်းသည် `&dyn SomeTrait` ၏အပြင်အဆင်ကိုပြောင်းလဲလိမ့်မည်မဟုတ်) ။
///
/// ၎င်းသည် low-level အသေးစိတ်အချက်အလက်များကိုစီမံရန်လိုအပ်သော unsafe code ဖြင့်သာအသုံးပြုရန်ဒီဇိုင်းပြုလုပ်ထားသည်။
///
/// ယေဘူယျအားဖြင့် trait အရာဝတ္ထုများအားလုံး ၀ ရည်ညွှန်းရန်နည်းလမ်းမရှိပါ။ ထို့ကြောင့်ဤအမျိုးအစားများ၏တန်ဖိုးများကိုဖန်တီးရန်တစ်ခုတည်းသောနည်းလမ်းမှာ [`std::mem::transmute`][transmute] ကဲ့သို့သောလုပ်ဆောင်ချက်များဖြင့်ဖြစ်သည်။
/// အလားတူပင် `TraitObject` တန်ဖိုးတစ်ခုမှ trait ၀ တ္ထုအမှန်ကိုဖန်တီးရန်တစ်ခုတည်းသောနည်းလမ်းမှာ `transmute` နှင့်ဖြစ်သည်။
///
/// [transmute]: crate::intrinsics::transmute
///
/// မတူညီသောအမျိုးအစားများ-trait အရာဝတ္ထုတစ်ခုအားစုစည်းခြင်းသည် vtable သည်အချက်ပြညွှန်ပြသောတန်ဖိုးအမျိုးအစားနှင့်မကိုက်ညီသောကြောင့်အဓိပ္ပာယ်မဲ့သောအပြုအမူကိုဖြစ်ပေါ်စေသည်။
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // ဥပမာတစ်ခု trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // အဆိုပါ compiler က trait အရာဝတ္ထုစေကုန်အံ့
/// let object: &dyn Foo = &value;
///
/// // ကုန်ကြမ်းကိုယ်စားပြုမှုကိုကြည့်ပါ
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // ဒေတာညွှန်ပြ `value` ၏လိပ်စာဖြစ်ပါတယ်
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // `object` ထံမှ `i32` vtable သုံးစွဲဖို့သတိထားဖြစ်ခြင်း, တစ်ဦးကွဲပြားခြားနားသော `i32` မှညွှန်ပြအသစ်တစ်ခုအရာဝတ္ထုတည်ဆောက်
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // ကျွန်ုပ်တို့သည် `other_value` ထဲက trait အရာဝတ္ထုကိုတိုက်ရိုက်တည်ဆောက်ခဲ့သည့်နည်းတူအလုပ်လုပ်သင့်သည်
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}