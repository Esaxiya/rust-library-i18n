#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // အဆိုပါခေါ်ဆိုမှုများထုတ်ဝေပေါ် မူတည်. `$crate::panic::panic_2015` သို့မဟုတ် `$crate::panic::panic_2021` ဖြစ်စေရန်ချဲ့ထွင်။
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// နှစ်ခုအသုံးအနှုန်းတွေ ([`PartialEq`] သုံးပြီး) တစ်ဦးချင်းစီကတခြားညီမျှဖြစ်ကြောင်းပြောဆိုသော။
///
/// panic တွင်, ဒီနိုင်တဲ့ macro သူတို့ရဲ့ဒီဘာဂ်ကိုယ်စားပြုအတူအသုံးအနှုန်းတွေများ၏တန်ဖိုးများကို print ထုတ်ပါလိမ့်မယ်။
///
///
/// [`assert!`] ကဲ့သို့ဤ macro သည်ဒုတိယပုံစံရှိပြီး panic စိတ်ကြိုက်မက်ဆေ့ခ်ျပို့နိုင်သည်။
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // အောက်တွင်ဖော်ပြထားသော reborrows ရည်ရွယ်ချက်ရှိရှိဖြစ်ကြသည်။
                    // ၎င်းတို့မရှိလျှင်ချေးယူရန်အတွက် stack slot ကိုတန်ဖိုးများကိုနှိုင်းယှဉ်ခြင်းမပြုမီပင်စတင်လုပ်ဆောင်သည်။ သိသိသာသာနှေးကွေးစေသည်။
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // အောက်တွင်ဖော်ပြထားသော reborrows ရည်ရွယ်ချက်ရှိရှိဖြစ်ကြသည်။
                    // ၎င်းတို့မရှိလျှင်ချေးယူရန်အတွက် stack slot ကိုတန်ဖိုးများကိုနှိုင်းယှဉ်ခြင်းမပြုမီပင်စတင်လုပ်ဆောင်သည်။ သိသိသာသာနှေးကွေးစေသည်။
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// နှစ်ခုအသုံးအနှုန်းတွေမဟုတ် ([`PartialEq`] သုံးပြီး) တစ်ဦးချင်းစီကတခြားမှတူညီပြောဆိုသော။
///
/// panic တွင်, ဒီနိုင်တဲ့ macro သူတို့ရဲ့ဒီဘာဂ်ကိုယ်စားပြုအတူအသုံးအနှုန်းတွေများ၏တန်ဖိုးများကို print ထုတ်ပါလိမ့်မယ်။
///
///
/// [`assert!`] ကဲ့သို့ဤ macro သည်ဒုတိယပုံစံရှိပြီး panic စိတ်ကြိုက်မက်ဆေ့ခ်ျပို့နိုင်သည်။
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // အောက်တွင်ဖော်ပြထားသော reborrows ရည်ရွယ်ချက်ရှိရှိဖြစ်ကြသည်။
                    // ၎င်းတို့မရှိလျှင်ချေးယူရန်အတွက် stack slot ကိုတန်ဖိုးများကိုနှိုင်းယှဉ်ခြင်းမပြုမီပင်စတင်လုပ်ဆောင်သည်။ သိသိသာသာနှေးကွေးစေသည်။
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // အောက်တွင်ဖော်ပြထားသော reborrows ရည်ရွယ်ချက်ရှိရှိဖြစ်ကြသည်။
                    // ၎င်းတို့မရှိလျှင်ချေးယူရန်အတွက် stack slot ကိုတန်ဖိုးများကိုနှိုင်းယှဉ်ခြင်းမပြုမီပင်စတင်လုပ်ဆောင်သည်။ သိသိသာသာနှေးကွေးစေသည်။
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// တစ်ဦး boolean စကားရပ် runtime မှာ `true` ကြောင်းကိုပြောဆိုသော။
///
/// ပေးထားသည့်စကားရပ် runtime မှာ `true` မှအကဲဖြတ်မရနိုငျပါလျှင်ဤအ [`panic!`] နိုင်တဲ့ macro မြွက်ပါလိမ့်မယ်။
///
/// [`assert!`] လိုပဲဒီ macro မှာဒုတိယ version ပါရှိပြီး panic message တစ်ခုပါ ၀ င်နိုင်သည်။
///
/// # Uses
///
/// [`assert!`] မတူဘဲ, `debug_assert!` ထုတ်ပြန်ချက်များသာပုံမှန်အားဖြင့်တည်ဆောက်မဟုတ်တဲ့ optimized အတွက် enabled နေကြသည်။
/// `-C debug-assertions` အဆိုပါ compiler ကမှလွန်နေသည်မဟုတ်လျှင်တစ်ဦး optimized တည်ဆောက် `debug_assert!` ထုတ်ပြန်ချက်များ execute လိမ့်မည်မဟုတ်ပါ။
/// ဒါကလွှတ်ပေးရန်တည်ဆောက်အတွက်ပစ္စုပ္ပန်ဖြစ်ပေမယ့်ဖှံ့ဖွိုးတိုးတကာလအတွင်းအထောက်အကူဖြစ်နိုင်သည်လည်းစျေးကြီးဖြစ်ကြောင်းစစ်ဆေးမှုများအဘို့အ `debug_assert!` အသုံးဝင်သောစေသည်။
/// `debug_assert!` တိုးချဲ့၏ရလဒ် type ကို check လုပ်ထားအမြဲဖြစ်ပါတယ်။
///
/// မစစ်ဆေးရသေးသောအခိုင်အမာသည်ရှေ့နောက်မညီသည့်အခြေအနေတွင်ရှိသောပရိုဂရမ်တစ်ခုကိုဆက်လက်လည်ပတ်ခွင့်ပြုသည်၊ ၎င်းသည်မမျှော်လင့်သောအကျိုးဆက်များရှိနိုင်သည်၊ သို့သော်လုံခြုံစိတ်ချရသောကုဒ်တွင်သာဖြစ်ပျက်နေသရွေ့လုံခြုံစိတ်ချရမှုမရှိပါ။
///
/// အခိုင်အမာများ၏စွမ်းဆောင်ရည်ကုန်ကျစရိတ်သို့သော်ယေဘုယျအားဖြင့်တိုင်းတာမဟုတ်ပါဘူး။
/// `debug_assert!` နှင့်အတူ [`assert!`] အစားထိုးအရှင်သာသာဘေးကင်းလုံခြုံကုဒ်အတွက်ပိုပြီးအရေးကြီးနှံ့နှံ့စပ်စပ်ကိုအပြီးအားပေးအားမြှောက်များနှင့်နေပါသည်!
///
/// # Examples
///
/// ```
/// // ဤအအခိုင်အမာများအတွက် panic မက်ဆေ့ခ်ျကိုပေးထားသည့်စကားရပ်၏ stringified တန်ဖိုးကိုဖြစ်ပါတယ်။
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // အလွန်ရိုးရှင်းတဲ့ function ကို
/// debug_assert!(some_expensive_computation());
///
/// // ထုံးစံသတင်းစကားနှင့်အတူအခိုင်အမာ
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// အသုံးအနှုန်းနှစ်ခုသည်တစ်ခုနှင့်တစ်ခုတူညီသည်ဟုပြောဆိုသည်။
///
/// panic တွင်, ဒီနိုင်တဲ့ macro သူတို့ရဲ့ဒီဘာဂ်ကိုယ်စားပြုအတူအသုံးအနှုန်းတွေများ၏တန်ဖိုးများကို print ထုတ်ပါလိမ့်မယ်။
///
/// [`assert_eq!`] မတူဘဲ, `debug_assert_eq!` ထုတ်ပြန်ချက်များသာပုံမှန်အားဖြင့်တည်ဆောက်မဟုတ်တဲ့ optimized အတွက် enabled နေကြသည်။
/// `-C debug-assertions` အဆိုပါ compiler ကမှလွန်နေသည်မဟုတ်လျှင်တစ်ဦး optimized တည်ဆောက် `debug_assert_eq!` ထုတ်ပြန်ချက်များ execute လိမ့်မည်မဟုတ်ပါ။
/// ဒါကလွှတ်ပေးရန်တည်ဆောက်အတွက်ပစ္စုပ္ပန်ဖြစ်ပေမယ့်ဖှံ့ဖွိုးတိုးတကာလအတွင်းအထောက်အကူဖြစ်နိုင်သည်လည်းစျေးကြီးဖြစ်ကြောင်းစစ်ဆေးမှုများအဘို့အ `debug_assert_eq!` အသုံးဝင်သောစေသည်။
///
/// `debug_assert_eq!` တိုးချဲ့၏ရလဒ် type ကို check လုပ်ထားအမြဲဖြစ်ပါတယ်။
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// နှစ်ခုအသုံးအနှုန်းတွေအချင်းချင်းတန်းတူမစပ်ဆိုင်ကြောင်းကိုပြောဆိုသော။
///
/// panic တွင်, ဒီနိုင်တဲ့ macro သူတို့ရဲ့ဒီဘာဂ်ကိုယ်စားပြုအတူအသုံးအနှုန်းတွေများ၏တန်ဖိုးများကို print ထုတ်ပါလိမ့်မယ်။
///
/// [`assert_ne!`] မတူဘဲ, `debug_assert_ne!` ထုတ်ပြန်ချက်များသာပုံမှန်အားဖြင့်တည်ဆောက်မဟုတ်တဲ့ optimized အတွက် enabled နေကြသည်။
/// `-C debug-assertions` အဆိုပါ compiler ကမှလွန်နေသည်မဟုတ်လျှင်တစ်ဦး optimized တည်ဆောက် `debug_assert_ne!` ထုတ်ပြန်ချက်များ execute လိမ့်မည်မဟုတ်ပါ။
/// ၎င်းသည် `debug_assert_ne!` အားစျေးကြီးလွန်းသောဖြန့်ချိမှုတည်ဆောက်မှုတွင်ပါ ၀ င်နိုင်သော်လည်းဖွံ့ဖြိုးမှုကာလအတွင်းအသုံးဝင်နိုင်သည်။
///
/// `debug_assert_ne!` တိုးချဲ့၏ရလဒ် type ကို check လုပ်ထားအမြဲဖြစ်ပါတယ်။
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// ပေးထားသောစကားရပ်ပေးထားသောပုံစံများမဆိုကိုက်ညီခြင်းရှိမရှိပြန်သွားပါ။
///
/// `match` ဟူသောစကားရပ်တွင်ကဲ့သို့ပင်ပုံစံကို `if` နှင့်ပုံစံအားဖြင့်ချည်နှောင်ထားသောအမည်များကိုကြည့်ရှုနိုင်သောအစောင့်တပ်ဖွဲ့တို့ကနောက်မှလိုက်နိုင်သည်။
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// ရလဒ် Unwraps သို့မဟုတ်ယင်း၏အမှားပျံ့နှံ့ရောက်ရှိသွားသည်။
///
/// `try!` operator ကို `try!` နေရာတွင်အစားထိုးခဲ့ပြီးအစားထိုးအသုံးပြုသင့်သည်။
/// ထို့အပွငျ `try` သငျသညျကိုအသုံးပြုရပါမည်ဆိုပါကဒါ, သင် [raw-identifier syntax][ris] သုံးစွဲဖို့လိုအပ်ပါလိမ့်မည်, Rust 2018 ခုနှစ်တွင်တစ်ဦးယူထားတဲ့စကားလုံးဖြစ်ပါသည်: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` ပေးထားသော [`Result`] ကိုက်ညီမှုမရှိပါ။`Ok` မူကွဲတွင်ဖော်ပြချက်သည်ထုပ်ထားသောတန်ဖိုး၏တန်ဖိုးဖြစ်သည်။
///
/// အဆိုပါ `Err` မူကွဲ၏အမှု၌ကအတွင်းပိုင်းအမှားရယူ။`try!` ထို့နောက် `From` သုံးပြီးပြောင်းလဲခြင်းကိုလုပ်ဆောင်တယ်။
/// ဤသည်အထူးပြုအမှားများနှင့်ပိုပြီးယေဘုယျသူတွေကိုအကြားအလိုအလျောက်ပြောင်းလဲပေးစွမ်းသည်။
/// ရရှိလာတဲ့အမှားကိုချက်ချင်းပြန်ပေးတယ်။
///
/// အစောပိုင်းပြန်လာမှုကြောင့် `try!` သည် [`Result`] ကိုပြန်ပို့သောလုပ်ဆောင်မှုများတွင်သာအသုံးပြုနိုင်သည်။
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // အမြန်အမှားပြန်လာ၏ဦးစားပေးနည်းလမ်း
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // အမြန်အမှားပြန်လာ၏ယခင်နည်းလမ်း
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // ဒီညီမျှခြင်းသည်
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// အချက်အလက်များကိုကြားခံအဖြစ်ရေးသည်။
///
/// ဤသည်နိုင်တဲ့ macro တစ် 'writer', format တစ်ခုက string နှင့်အငြင်းပွားမှုများများစာရင်းကိုလက်ခံခဲ့သည်။
/// ငြင်းခုံပုသတ်မှတ်ထားတဲ့ပုံစံ string ကိုအညီချပ်မည်ဖြစ်ပြီးရလဒ်စာရေးဆရာမှအောင်မြင်ပြီးပါလိမ့်မည်။
/// အဆိုပါစာရေးဆရာတစ်ဦး `write_fmt` နည်းလမ်းနှင့်အတူမည်သည့်တန်ဖိုးကိုဖြစ်နိုင်သည်;ယေဘုယျအားဖြင့်ဒီ [`fmt::Write`] ဒါမှမဟုတ် [`io::Write`] trait ဖြစ်စေ၏အကောင်အထည်ဖော်မှုကနေလာပါတယ်။
/// အဆိုပါနိုင်တဲ့ macro ပြန်သမျှ `write_fmt` နည်းလမ်းကိုပြန်;အများအားတစ်ဦး [`fmt::Result`], ဒါမှမဟုတ်တစ်ဦး [`io::Result`] ။
///
/// ပုံစံ string ကို syntax အပေါ်ပိုမိုသောအချက်အလက်များအဘို့အ [`std::fmt`] ကိုကြည့်ပါ။
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// တစ်ဦးက module တစ်ခု `std::fmt::Write` နှင့် `std::io::Write` နှစ်ဦးစလုံးတင်သွင်းရန်နှင့်အရာဝတ္ထုပုံမှန်အားဖြင့်နှစ်ဦးစလုံးကိုအကောင်အထည်ဖော်ကြဘူးအဖြစ်လည်းကောင်းအကောင်အထည်ဖော်အရာဝတ္ထုအပေါ် `write!` ခေါ်နိုင်ပါတယ်။
///
/// သို့သော်မော်ကျူးသူတို့၏အမည်များပဋိပက္ခမဒါ traits အရည်အချင်းပြည့်မီတင်သွင်းရပါမည်:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // အသုံးပြုမှု fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // အသုံးပြုမှု io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: ဒီ macro ကို `no_std` setups တွေမှာလည်းသုံးနိူင်တယ်။
/// `no_std` ဆက်တင်တစ်ခုတွင်သင်ကအစိတ်အပိုင်းများ၏အကောင်အထည်ဖော်မှုအသေးစိတ်အတွက်သင့်တွင်တာဝန်ရှိသည်။
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// ပုံစံချထားသောအချက်အလက်များကိုကြားခံအသစ်တစ်ခုနှင့်အတူကြားခံထဲသို့ရေးပါ။
///
/// အားလုံးပလက်ဖောင်းတွင် NEWLINE အဆိုပါ LINE FEED ဇာတ်ကောင်တစ်ဦးတည်း (`\n`/`U+000A`) (အပိုမရှိ Carriage Return (`\r`/`U+000D`) ဖြစ်ပါတယ်။
///
/// ပိုမိုသိရှိလိုပါက, [`write!`] ကြည့်ပါ။အမျိုးအစား string ကို syntax အပေါ်သတင်းအချက်အလက်အဘို့, [`std::fmt`] ကိုကြည့်ပါ။
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// တစ်ဦးက module တစ်ခု `std::fmt::Write` နှင့် `std::io::Write` နှစ်ဦးစလုံးတင်သွင်းရန်နှင့်အရာဝတ္ထုပုံမှန်အားဖြင့်နှစ်ဦးစလုံးကိုအကောင်အထည်ဖော်ကြဘူးအဖြစ်လည်းကောင်းအကောင်အထည်ဖော်အရာဝတ္ထုအပေါ် `write!` ခေါ်နိုင်ပါတယ်။
/// သို့သော်မော်ကျူးသူတို့၏အမည်များပဋိပက္ခမဒါ traits အရည်အချင်းပြည့်မီတင်သွင်းရပါမည်:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // အသုံးပြုမှု fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // အသုံးပြုမှု io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// လက်လှမ်းမမှီပါ code ကိုဖော်ပြသည်။
///
/// ဒါက compiler တချို့ code တွေကိုလက်လှမ်းမမှီပါကြောင်းမဆုံးဖြတ်နိုင်ကြောင်းအသုံးဝင်သောမဆိုအချိန်ဖြစ်ပါသည်။ဥပမာ:
///
/// * ကိုယ်ရံတော်အခြေအနေများနှင့်အတူလက်နက်ကိုက်ညီ။
/// * dynamically အဆုံးသတ်ကြောင်းကွင်းဆက်။
/// * သည် dynamically အဆုံးသတ်ခြင်းကြောင်းကြားမှာ။
///
/// အကယ်၍ ကုဒ်ကိုလက်လှမ်းမမှီနိုင်ဟုဆုံးဖြတ်ချက်သည်မမှန်ကန်ပါကပရိုဂရမ်သည် [`panic!`] နှင့်ချက်ချင်းအဆုံးသတ်သွားမည်။
///
/// ဒီနိုင်တဲ့ macro ၏မလုံခြုံရှိသော counterpart code ကိုရောက်ရှိလျှင် undefined အပြုအမူကိုဖြစ်ပေါ်စေပါလိမ့်မယ်ရသော [`unreachable_unchecked`] function ကိုဖြစ်ပါတယ်။
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// ဤသည်အစဉ်အမြဲ [`panic!`] မည်။
///
/// # Examples
///
/// ပွဲစဉ်လက်နက်:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // ထွက် commented လျှင်အမှား compile
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // x/3 ၏အဆင်းရဲဆုံးအကောင်အထည်ဖော်မှုတစ်ခု
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// "not implemented" ၏သတင်းစကားနှင့်အတူစိုးရိမ်မနေဖြင့် unimplemented ကုဒ်ဖော်ပြသည်။
///
/// ဒါဟာသင့်ရဲ့ကုဒ်သင်၌ရှိသမျှကို အသုံးပြု. ၏စီစဉ်မထားတဲ့မျိုးစုံနည်းလမ်းများလိုအပ်သည်တစ် trait စမ်းသပ်လုပ်ဆောင်မှုသို့မဟုတ်အကောင်အထည်ဖော်နေလျှင်အသုံးဝင်သည်အရာ,-စစ်ဆေးမှုများရိုက်ထည့်ခွင့်ပြုပါတယ်။
///
/// `todo!` နောက်ပိုင်းတွင်လုပ်ဆောင်နိုင်စွမ်းကိုအကောင်အထည်ဖော်တစ်ဦးရည်ရွယ်ချက်သဘောဆောငျနှင့်မက်ဆေ့ခ်ျကို "not yet implemented" နေစဉ် `unimplemented!` နှင့် [`todo!`] အကြားခြားနားချက်, `unimplemented!` မျှထိုကဲ့သို့သောတောင်းဆိုမှုများပြုလုပ်ကြောင်း။
/// ၎င်း၏သတင်းစကား "not implemented" ဖြစ်ပါတယ်။
/// ဒါ့အပြင်အချို့ IDEs `todo အထိမ်းအမှတ်မည်!` s ကို။
///
/// # Panics
///
/// `unimplemented!` တစ်ဦး fixed, တိကျတဲ့သတင်းစကားနှင့်အတူ `panic!` ဘို့ပဲအတိုကောက်ဖြစ်ပါတယ်ဘာဖြစ်လို့လဲဆိုတော့ဒါကအမြဲ [`panic!`] မည်။
///
/// `panic!` လိုပဲ, ဒီနိုင်တဲ့ macro ထုံးစံတန်ဖိုးများကိုပြသဘို့ဒုတိယပုံစံရှိပါတယ်။
///
/// # Examples
///
/// ကျွန်တော်တစ်ဦး trait `Foo` ရှိတယ်ပြောပါ:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// ကျနော်တို့ 'MyStruct' အဘို့, ဒါပေမယ့်ကိုသာ `bar()` function ကိုအကောင်အထည်ဖေါ်ရန်သဘာဝကျပါတယ်တချို့အကြောင်းပြချက် `Foo` အကောင်အထည်ဖော်ချင်ပါတယ်။
/// `baz()` နှင့် `qux()` နေဆဲ `Foo` ကျွန်တော်တို့ရဲ့အကောင်အထည်ဖော်ရေးအတွက်သတ်မှတ်ခံရဖို့လိုအပ်ပါလိမ့်မည်, ဒါပေမယ့်ကျွန်တော်တို့ရဲ့ကုဒ် compile ခွင့်ပြုပါရန်သူတို့ရဲ့အဓိပ္ပာယ်အတွက် `unimplemented!` ကိုသုံးနိုင်သည်။
///
/// ကျနော်တို့နေဆဲ unimplemented နည်းလမ်းများရောက်ရှိလျှင်ကျွန်တော်တို့ရဲ့အစီအစဉ်ကိုရပ်တန့်ပြေးရှိသည်ဖို့ချင်တယ်။
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // `baz` က `MyStruct` ဆိုတာအဓိပ္ပါယ်မရှိဘူး၊ ဒါကြောင့်ငါတို့မှာယုတ္တိဗေဒလုံးဝမရှိဘူး။
/////
///         // ဤသည် "thread 'main' panicked at 'not implemented'" ပြပေးလိမ့်မယ်။
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // ကြှနျုပျတို့ unimplemented ဖို့မက်ဆေ့ခ်ျကို add နိုင်ပါတယ်, ဒီမှာအချို့ယုတ္တိဗေဒရှိသည်!ကျွန်တော်တို့ရဲ့ပျက်ကွက်ဖော်ပြရန်။
///         // ဤသည်ကိုပြသပါလိမ့်မယ်: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// မပြီးဆုံးသေးသောကုဒ်ဖော်ပြသည်။
///
/// သငျသညျစမ်းသပ်လုပ်ဆောင်မှုများနှင့်ဖွင့်သင့်ရဲ့ကုဒ် typecheck ရှိသည်ဖို့ရှာဖွေနေလျှင်ဤသည်အသုံးဝင်သောနိုင်ပါတယ်။
///
/// [`unimplemented!`] နှင့် `todo!` အကြားခြားနားချက်မှာ `todo!` သည်လုပ်ဆောင်နိုင်မှုကိုနောက်ပိုင်းတွင်ဖော်ပြရန်နှင့်မက်ဆေ့ခ်ျသည် "not yet implemented" ဖြစ်သော်လည်း `unimplemented!` သည်ထိုကဲ့သို့သောပြောဆိုမှုများကိုမပြုလုပ်သောကြောင့်ဖြစ်သည်။
/// ၎င်း၏သတင်းစကား "not implemented" ဖြစ်ပါတယ်။
/// ဒါ့အပြင်အချို့ IDEs `todo အထိမ်းအမှတ်မည်!` s ကို။
///
/// # Panics
///
/// ဤသည်အစဉ်အမြဲ [`panic!`] မည်။
///
/// # Examples
///
/// ဤတွင်တိုးတက်မှုကုဒ်၏ဥပမာတစ်ခုဖြစ်သည်။ကျနော်တို့က trait `Foo` ရှိသည်:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// `Foo` ကိုကျွန်ုပ်တို့၏အမျိုးအစားတစ်ခုတွင်အသုံးပြုလိုသော်လည်းပထမ ဦး ဆုံး `bar()` ကိုသာလုပ်လိုသည်။compile လုပ်ခြင်း, ငါတို့၏ကုဒ်အဘို့အလို့ငှာ, ငါတို့သည် `todo!` အသုံးပွုနိုငျဒါ `baz()` အကောင်အထည်ဖေါ်ဖို့လိုပါတယ်:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // အကောင်အထည်ဖော်မှုကဒီမှာသွား
///     }
///
///     fn baz(&self) {
///         // ယခု baz() အကောင်အထည်ဖော်အကြောင်းကိုစေရဲ့မရစိုးရိမ်ပူပန်
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // ကျနော်တို့တောင်မှ baz() သုံးပြီးကြသည်မဟုတ်, ဒါကြောင့်ဒီဒဏ်ငွေဖြစ်ပါသည်။
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// built-in macros ၏အဓိပ္ပာယ်။
///
/// macro ဂုဏ်သတ္တိများ (တည်ငြိမ်မှု၊ မြင်သာမှုစသဖြင့်) အများစုကိုဤနေရာတွင် source code မှယူထားသည်၊ ချဲ့ထားသောလုပ်ဆောင်ချက်များမှလွဲပြီး macro inputs ကို output များသို့အသွင်ပြောင်းသည်။ ထိုလုပ်ဆောင်ချက်များကို compiler မှပေးသည်။
///
///
pub(crate) mod builtin {

    /// ကြုံတွေ့ရပါက စုစည်း၍ ပေးထားသောအမှားသတင်းစကားနှင့်ကျရှုံးသွားစေသည်။
    ///
    /// အမှားအယွင်းအခြေအနေများအတွက်ပိုမိုကောင်းမွန်သောအမှားမက်ဆေ့ခ်ျများပေးရန် crate သည်ခြွင်းချက်ဆိုင်ရာနည်းဗျူဟာတစ်ခုကိုအသုံးပြုသောအခါဤ macro ကိုအသုံးပြုသင့်သည်။
    ///
    /// ဒါဟာ [`panic!`] ၏ compiler-Level ပုံစံရဲ့, ဒါပေမယ့် *မဟုတ်ဘဲ* runtime မှာထက် * * စုစည်းစဉ်အတွင်းမှားယွင်းမှုတစ်ခုထုတ်လွှတ်ပေးပါသည်။
    ///
    /// # Examples
    ///
    /// နှစ်ဦးကထိုကဲ့သို့သောဥပမာဘာလို့လဲဆိုတော့ Micro စနစ်နဲ့အခြားသောနှင့် `#[cfg]` ပတ်ဝန်းကျင်မှာဖြစ်ကြသည်။
    ///
    /// ထုတ်လွှတ်မှုပိုကောင်း compiler ကအမှားတစ်ခုနိုင်တဲ့ macro မမှန်ကန်တဲ့တန်ဖိုးများကိုလွန်လျှင်။
    /// နောက်ဆုံး branch မရှိပဲ, compiler နေဆဲမှားယွင်းမှုတစ်ခုထုတ်လွှတ်မယ်လို့ပေမယ့်အမှားရဲ့မက်ဆေ့ခ်ျကိုနှစ်ခုတရားဝင်တန်ဖိုးများကိုဖော်ပြမည်မဟုတ်ပေ။
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// ထုတ်လွှတ်မှု compiler ကအမှား features တွေများစွာထဲကတစ်ခုမရရှိနိုင်ပါ။
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// အခြား string ကို-ပုံစံဘာလို့လဲဆိုတော့ Micro စနစ်နဲ့အခြားသောအဘို့အ parameters တွေကို Constructs ။
    ///
    /// လွန်ခဲ့သောအပိုဆောင်းအငြင်းပွားမှုများအတွက် `{}` ပါဝင်သည့် format ချသည့် string literal ကိုယူခြင်းဖြင့်ဤ macro လုပ်ဆောင်သည်။
    /// `format_args!` output ကို string အဖြစ်အဓိပ္ပာယ်ကောက်ယူခြင်းနှင့်အငြင်းပွားမှုများတစ်ခုတည်းအမျိုးအစားသို့ canonicalizes နိုင်သေချာစေရန်အပိုဆောင်း parameters တွေကိုပြင်ဆင်။
    /// မည်သည့် [`Debug`] အကောင်အထည်ဖော်ရေးအတွက်ပုံစံ string ကိုအတွင်း `{:?}` မှလွန်ခြင်းကိုလုပ်နိုင်တဲ့အဖြစ်သုံးကိရိယာဟာ [`Display`] trait, `format_args!` မှလွန်နိုင်သည့်အခြေအနေမဆိုတန်ဖိုး။
    ///
    ///
    /// ဤသည်နိုင်တဲ့ macro အမျိုးအစား [`fmt::Arguments`] ၏တန်ဖိုးထုတ်လုပ်သည်။ဤတန်ဖိုးကိုအသုံး ၀ င်သည့်ပြန်လည်ညွန်ပြမှုကိုလုပ်ဆောင်ရန်အတွက် [`std::fmt`] အတွင်းရှိ macros များသို့လွှဲပြောင်းနိုင်သည်။
    /// အားလုံးကအခြားပုံစံဘာလို့လဲဆိုတော့ Micro စနစ်နဲ့အခြားသော (စသည်တို့ကို [`format နဲ့!`] [`write!`], [`println!`]) ဒီတစ်ခုမှတဆင့် proxied နေကြသည်။
    /// `format_args!`, ၎င်း၏ဆင်းသက်လာဘာလို့လဲဆိုတော့ Micro စနစ်နဲ့အခြားသောမတူဘဲအမှိုက်ပုံခွဲတမ်းရှောင်။
    ///
    /// X0 `Debug` နှင့် `Display` အခင်းအကျင်းများတွင် `format_args!` ပြန်လာသည့် [`fmt::Arguments`] တန်ဖိုးကိုသင်သုံးနိုင်သည်။
    /// ဥပမာကလည်းရှိုးပွဲနဲ့အတူတူပါပဲမှ `Debug` နှင့် `Display` ပုံစံတစ်ခုကို: `format_args!` အတွက် Interpol format နဲ့ string ကို။
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// ပိုမိုသိရှိလိုပါက, [`std::fmt`] အတွက်စာရွက်စာတမ်းများကိုကြည့်ပါ။
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// `format_args` နဲ့အတူတူပဲ၊ ဒါပေမယ့်နောက်ဆုံးမှာ newline တစ်ခုထပ်ထည့်လိုက်တယ်။
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// compile လုပ်ခြင်းအချိန်မှာပတ်ဝန်းကျင် variable ကိုကြည့်ရှုစစ်ဆေး။
    ///
    /// ဤသည်နိုင်တဲ့ macro အမျိုးအစား `&'static str` တစ်ခုစကားရပ်အလျှော့ပေးလိုက်လျော, compile လုပ်ခြင်းအချိန်တွင်အမည်ရှိပတ်ဝန်းကျင် variable ကို၏တန်ဖိုးမှချဲ့ထွင်ပါလိမ့်မယ်။
    ///
    ///
    /// ပတ်ဝန်းကျင် variable ကိုသတ်မှတ်မထားဘူးဆိုရင်, ထို့နောက်တစ် ဦး စုစည်းအမှားထုတ်လွှတ်လိမ့်မည်။
    /// စုစည်းရေးသားထားအမှားထုတ်လွှတ်မှုမပြုရန်, အစား [`option_env!`] နိုင်တဲ့ macro ကိုအသုံးပြုပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// သငျသညျဒုတိယ parameter သည်အဖြစ် string ကိုဖြတ်သန်းနေဖြင့် error message ကိုစိတ်ကြိုက်နိုင်သည်
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// `documentation` environment variable ကိုသတ်မှတ်မထားပါကအောက်ပါအမှားကိုသင်ရရှိလိမ့်မည်။
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// လုပ်နိုင်သော compile လုပ်ခြင်းအချိန်မှာပတ်ဝန်းကျင် variable ကိုကြည့်ရှုစစ်ဆေး။
    ///
    /// အကယ်၍ အမည်သတ်မှတ်ထားသည့် environment variable သည် compile လုပ်သည့်အချိန်တွင်ရောက်ရှိနေပါက၎င်းသည် value ၏ `Some` ဖြစ်သော `Option<&'static str>` type expression သို့တိုးချဲ့လိမ့်မည်။
    /// ပတ်ဝန်းကျင် variable ကိုလက်ရှိမပါရှိလျှင်, သို့ဖြစ်လျှင်ဤ `None` မှချဲ့ထွင်ပါလိမ့်မယ်။
    /// ဒီအမျိုးအစားပေါ်ပိုမိုသောအချက်အလက်များအဘို့အ [`Option<T>`][Option] ကိုကြည့်ပါ။
    ///
    /// မသက်ဆိုင်ပတ်ဝန်းကျင် variable ကိုပစ္စုပ္ပန်သို့မဟုတ်မရှိမရှိ၏ဤနိုင်တဲ့ macro တွေကိုအသုံးပြုတဲ့အခါစုစည်းရေးသားထားအချိန်အမှားထုတ်လွှတ်ဘယ်တော့မှဖြစ်ပါတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// အမှတ်အသားတစ်ခုအားခွဲခြားသတ်မှတ်သည်။
    ///
    /// ဤသည်နိုင်တဲ့ macro အသစ်တစ်ခုကိုအမှတ်အသားဖြစ်သောတစ်ဦးစကားရပ်အလျှော့ပေးလိုက်လျော, ရှိသမျှတဦးတည်းသို့သူတို့ကိုငါကော်မာ-separated ဖေါ်ထုတ်မဆိုအရေအတွက်ကကြာနှင့် concatenates ။
    /// တစ်ကိုယ်ရည်သန့်ရှင်းရေးကဒီလိုနိုင်တဲ့ macro ဒေသခံ variable တွေကိုဖမ်းယူနိုင်သောစေသည်မှတ်ချက်။
    /// ဒါ့အပြင်အထွေထွေစည်းမျဉ်းအဖြစ်, ဘာလို့လဲဆိုတော့ Micro စနစ်နဲ့အခြားသောသာ item ကိုကြေညာချက်သို့မဟုတ်စကားရပ်အနေအထားအတွက်ခွင့်ပြုထားပါသည်။
    /// ဆိုလိုသည်မှာသင်သည်ဤ macro ကို အသုံးပြု၍ ရှိပြီးသား variable များ၊ functions များသို့မဟုတ် modules စသည်တို့ကိုရည်ညွှန်းသော်လည်း၊ အသစ်တစ်ခုကိုသင် သတ်မှတ်၍ မရပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (အသစ်၊ ပျော်စရာ၊ နာမည်) { }//ဤနည်းဖြင့်အသုံးမပြုနိုင်ပါ။
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// literals တွေကို static string အချပ်တစ်ခုနဲ့ပေါင်းလိုက်တယ်။
    ///
    /// ဤသည်နိုင်တဲ့ macro left-to-ညာဘက် concatenated ပကတိအပေါငျးတို့သကိုကိုယ်စားပြုထားတဲ့အမျိုးအစား `&'static str` တစ်ခုစကားရပ်အလျှော့ပေးလိုက်လျော, ကော်မာ-separated လီတာဆိုအရေအတွက်ကိုကြာပါသည်။
    ///
    ///
    /// Integer နှင့် floating point literals များသည် concatenated ပြုလုပ်ရန်အတွက်တင်းကြပ်ထားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ကမဖြစ်၏ခဲ့သည့်အပေါ်လိုင်းအရေအတွက်တိုးချဲ့။
    ///
    /// [`column!`] နှင့် [`file!`] နှင့်အတူဤဘာလို့လဲဆိုတော့ Micro စနစ်နဲ့အခြားသောရင်းမြစ်အတွင်းတည်နေရာနဲ့ပတ်သက်တဲ့ Developer များအတွက်သတင်းအချက်အလက် debugging ကိုပေး။
    ///
    /// အဆိုပါတိုးချဲ့စကားရပ်အမျိုးအစား `u32` ရှိပြီး 1-based ဖြစ်ပါတယ်, ဒါစသည်တို့ကို 1 ဖိုင်တိုင်းကိုအကဲဖြတ်အတွင်းပထမဆုံးလိုင်း, 2 မှဒုတိယ,
    /// ဤသည်ဘုံ compiler နဲ့သို့မဟုတ်ပေါ်ပြူလာအယ်ဒီတာများအားဖြင့်အမှားမက်ဆေ့ခ်ျများနှင့်ကိုက်ညီသည်။
    /// အဆိုပါပြန်လာသောလိုင်း *သေချာပေါက်* အ `line!` invocation အလိုလိုလိုင်း, ဒါပေမယ့်အစား `line!` နိုင်တဲ့ macro ၏ invocation အထိဦးဆောင်ပထမဦးဆုံးနိုင်တဲ့ macro invocation မဟုတ်ပါဘူး။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// ကမဖြစ်၏ခဲ့သည့်မှာကော်လံအရေအတွက်တိုးချဲ့။
    ///
    /// [`line!`] နှင့် [`file!`] နှင့်အတူဤဘာလို့လဲဆိုတော့ Micro စနစ်နဲ့အခြားသောရင်းမြစ်အတွင်းတည်နေရာနဲ့ပတ်သက်တဲ့ Developer များအတွက်သတင်းအချက်အလက် debugging ကိုပေး။
    ///
    /// တိုးချဲ့ထားသောစကားရပ်သည် `u32` အမျိုးအစားဖြစ်ပြီး ၁ အခြေခံသည်။ ထို့ကြောင့်လိုင်းတစ်ခုစီ၏ပထမကော်လံသည် ၁၊ ဒုတိယသို့မှ ၂ အထိစသည်တို့ဖြစ်သည်။
    /// ဤသည်ဘုံ compiler နဲ့သို့မဟုတ်ပေါ်ပြူလာအယ်ဒီတာများအားဖြင့်အမှားမက်ဆေ့ခ်ျများနှင့်ကိုက်ညီသည်။
    /// အဆိုပါပြန်လာသောကော်လံ *သေချာပေါက်* အ `column!` invocation အလိုလိုလိုင်း, ဒါပေမယ့်အစား `column!` နိုင်တဲ့ macro ၏ invocation အထိဦးဆောင်ပထမဦးဆုံးနိုင်တဲ့ macro invocation မဟုတ်ပါဘူး။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// ကမဖြစ်၏ခဲ့သည့်အတွက်ဖိုင်အမည်ကိုမှတိုးချဲ့။
    ///
    /// [`line!`] နှင့် [`column!`] နှင့်အတူဤဘာလို့လဲဆိုတော့ Micro စနစ်နဲ့အခြားသောရင်းမြစ်အတွင်းတည်နေရာနဲ့ပတ်သက်တဲ့ Developer များအတွက်သတင်းအချက်အလက် debugging ကိုပေး။
    ///
    /// တိုးချဲ့ထားသောစကားရပ်တွင် `&'static str` အမျိုးအစားရှိပြီးပြန်လာသောဖိုင်သည် `file!` macro ၏ invocation မဟုတ်ဘဲပထမဆုံး `file!` macro ၏ invocation သို့ ဦး တည်သွားသောပထမဆုံး macro invocation ဖြစ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// ၎င်း၏အငြင်းပွားမှုများ Stringifies ။
    ///
    /// ဤ macro သည် `&'static str` ၏ဖော်ပြချက်ကိုထုတ်ပေးလိမ့်မည်။ ၎င်းသည် macro သို့ကူးပြောင်းလိုက်သော tokens အားလုံး၏ stringification ဖြစ်သည်။
    /// macro invocation ကိုယ်နှိုက်၏ syntax ပေါ်တွင်အကန့်အသတ်မရှိ။
    ///
    /// မှတ်ချက် tokens အဆိုပါ future အတွက်ပြောင်းလဲနိုင်ပါသည်အတွက် input ကို၏ကျယ်ပြန့်သောရလဒ်များကိုသော။သင် output ကိုအပေါ်အားကိုးလျှင်သင်သတိထားရပါမည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// UTF-8 encoded file တစ်ခု string အဖြစ်ပါဝင်သည်။
    ///
    /// ၎င်းဖိုင်သည်လက်ရှိဖိုင်နှင့်နှိုင်းယှဉ်ပါကတည်ရှိသည်။
    /// အဆိုပါထောက်ပံ့ပေးလမ်းကြောင်းကို compile လုပ်ခြင်းအချိန်မှာပလက်ဖောင်း-တိကျတဲ့လမ်းအတွက်အဓိပ္ပာယ်ကောက်ယူသည်။
    /// ဥပမာအားဖြင့်ဒါ, `\` Unix အပေါ်မှန်ကန်စွာ compile မဟုတ်ဘူးဘယ်ဘက်မျဉ်းစောင်းင်တစ်ဦး Windows လမ်းကြောင်းနဲ့ invocation ။
    ///
    ///
    /// ဤသည်နိုင်တဲ့ macro ဖိုင်ကိုရဲ့ contents ဖြစ်သည့်အမျိုးအစား `&'static str` တစ်ခုစကားရပ်လိုက်လျောပါလိမ့်မယ်။
    ///
    /// # Examples
    ///
    /// အောက်ပါအကြောင်းအရာများကိုနှင့်တူညီသော directory ထဲတွင်ဖိုင်နှစ်ခုရှိပါတယ်ယူဆ:
    ///
    /// 'spanish.in' ဖိုင်ကို:
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// file ကို 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// 'main.rs' ပြုစုနှင့်ရရှိလာတဲ့ binary "adiós" print ထုတ်ပါလိမ့်မယ် running ။
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// တစ်ဦးက byte ခင်းကျင်းတစ်ဦးကိုကိုးကားအဖြစ်ဖိုင်တစ်ခုပါဝင်ပါသည်။
    ///
    /// ၎င်းဖိုင်သည်လက်ရှိဖိုင်နှင့်နှိုင်းယှဉ်ပါကတည်ရှိသည်။
    /// အဆိုပါထောက်ပံ့ပေးလမ်းကြောင်းကို compile လုပ်ခြင်းအချိန်မှာပလက်ဖောင်း-တိကျတဲ့လမ်းအတွက်အဓိပ္ပာယ်ကောက်ယူသည်။
    /// ဥပမာအားဖြင့်ဒါ, `\` Unix အပေါ်မှန်ကန်စွာ compile မဟုတ်ဘူးဘယ်ဘက်မျဉ်းစောင်းင်တစ်ဦး Windows လမ်းကြောင်းနဲ့ invocation ။
    ///
    ///
    /// ဤသည်နိုင်တဲ့ macro ဖိုင်ကိုရဲ့ contents ဖြစ်သည့်အမျိုးအစား `&'static [u8; N]` တစ်ခုစကားရပ်လိုက်လျောပါလိမ့်မယ်။
    ///
    /// # Examples
    ///
    /// အောက်ပါအကြောင်းအရာများကိုနှင့်တူညီသော directory ထဲတွင်ဖိုင်နှစ်ခုရှိပါတယ်ယူဆ:
    ///
    /// 'spanish.in' ဖိုင်ကို:
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// file ကို 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// 'main.rs' ပြုစုနှင့်ရရှိလာတဲ့ binary "adiós" print ထုတ်ပါလိမ့်မယ် running ။
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// လက်ရှိ module လမ်းကြောင်းကိုကိုယ်စားပြုမယ့် string ကိုမှချဲ့ထွင်။
    ///
    /// လက်ရှိ module ကိုလမ်း crate root ပြန်ဖွင့်ဦးဆောင် module တွေ၏အဆင့်ဆင့်အဖြစ်ယူဆနိုင်ပါတယ်။
    /// ပြန်လာသောလမ်းကြောင်း၏ပထမအစိတ်အပိုင်းမှာလက်ရှိပြုစုနေသော crate ၏အမည်ဖြစ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// compile လုပ်ခြင်းအချိန်မှာ configuration ကိုအလံ၏ boolean ပေါင်းစပ်တန်ဖိုး။
    ///
    /// အဆိုပါ `#[cfg]` attribute ကိုအပြင်, ဒီနိုင်တဲ့ macro configuration ကိုအလံ၏ boolean စကားရပ်အကဲဖြတ်ခွင့်ပြုပေးတာဖြစ်ပါတယ်။
    /// ဤသည်ကိုမကြာခဏလျော့နည်းမိတ္တူပွားစေပါတယ်။
    ///
    /// ဒီနိုင်တဲ့ macro အား syntax အဆိုပါ [`cfg`] attribute ကကဲ့သို့တူညီသော syntax ဖြစ်ပါတယ်။
    ///
    /// `cfg!`, `#[cfg]` မတူဘဲစစ်မှန်တဲ့သို့မဟုတ်မှားယွင်းသောမှမဆို code ကိုသာအကဲဖြတ်ကိုဖယ်ရှားမပေးပါဘူး။
    /// ဥပမာအားဖြင့်၊ if/else အသုံးအနှုန်းရှိလုပ်ကွက်အားလုံးသည် `cfg!` ကိုအခြေအနေအတွက်အသုံးပြုသောအခါတရားဝင်ဖြစ်ရန်လိုအပ်သည်၊ မည်သို့ပင်ဖြစ်စေ `cfg!` အကဲဖြတ်သည်။
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// ဆက်စပ်သည်နှင့်အညီတစ်ဦးစကားရပ်သို့မဟုတ်တစ်ဦးကို item အဖြစ်ဖိုင်တစ်ဖိုင် Parses ။
    ///
    /// အဆိုပါဖိုင် (အလားတူ module တွေတွေ့ရှိဘယ်လောက်မှ) လက်ရှိဖိုင်ဆွေမျိုးတည်ရှိသည်။ပေးထားသောလမ်းကြောင်းကို compile time တွင် platform-specific ဖြင့်အဓိပ္ပာယ်ကောက်ယူသည်။
    /// ဥပမာအားဖြင့်ဒါ, `\` Unix အပေါ်မှန်ကန်စွာ compile မဟုတ်ဘူးဘယ်ဘက်မျဉ်းစောင်းင်တစ်ဦး Windows လမ်းကြောင်းနဲ့ invocation ။
    ///
    /// ဖိုင်ကိုတစ်ခုစကားရပ်အဖြစ်သရုပျခှဲလျှင်, က unhygienically ပတျဝနျးကငျြကုဒ်ထဲမှာထည့်ထားလိမ့်မယ်ဘာဖြစ်လို့လဲဆိုတော့ဒီနိုင်တဲ့ macro အသုံးပြုခြင်းမကြာခဏမကောင်းတဲ့စိတ်ကူးဖြစ်ပါတယ်။
    /// လက်ရှိဖိုင်ထဲမှာအမည်တူရှိသည် variable တွေကိုသို့မဟုတ်လုပ်ဆောင်ချက်များကိုရှိပါတယ်လျှင်ဒီ variable တွေကိုသို့မဟုတ်ဖိုင်ကိုမည်ဟုမျှော်လင့်သောအရာကိုအနေဖြင့်ကွဲပြားခြားနားသောဖြစ်ခြင်းလုပ်ဆောင်ချက်များကိုဖြစ်ပေါ်နိုင်ပါတယ်။
    ///
    ///
    /// # Examples
    ///
    /// အောက်ပါအကြောင်းအရာများကိုနှင့်တူညီသော directory ထဲတွင်ဖိုင်နှစ်ခုရှိပါတယ်ယူဆ:
    ///
    /// 'monkeys.in' ဖိုင်ကို:
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// file ကို 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// 'main.rs' ကိုစုစည်းပြီးရရှိလာတဲ့ binary ကို run ခြင်းက "🙈🙊🙉🙈🙊🙉" ကို print ထုတ်ပါလိမ့်မယ်။
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// တစ်ဦး boolean စကားရပ် runtime မှာ `true` ကြောင်းကိုပြောဆိုသော။
    ///
    /// ပေးထားသည့်စကားရပ် runtime မှာ `true` မှအကဲဖြတ်မရနိုငျပါလျှင်ဤအ [`panic!`] နိုင်တဲ့ macro မြွက်ပါလိမ့်မယ်။
    ///
    /// # Uses
    ///
    /// အခိုင်အမာအမြဲဒီဘာဂ်နှင့်ဖြန့်ချိတည်ဆောက်နှစ်ဦးစလုံးအတွက် check လုပ်ထားကြသဖြင့်, disabled မရနိုင်ပါ။
    /// ဖြန့်ချိအတွက်ဖွင့်မဖြစ်ကြောင်းအခိုင်အမာများအတွက်ကြည့်ရှု [`debug_assert!`] default အနေဖြင့်တည်ဆောက်။
    ///
    /// အန္တရာယ်မကင်းကုဒ်ချိုးဖောက် unsafety ဖို့ဦးဆောင်လမ်းပြနိုင်လျှင်, ထို Run-အချိန်လျော့ပါးသွားမည်ဖြစ်သလိုပြဋ္ဌာန်းရန်မှ `assert!` အပေါ်အားကိုးနိုငျသညျ။
    ///
    /// `assert!` ၏အခြားအသုံးပြုမှု-အမှုပေါင်း (အဘယ်သူ၏ချိုးဖောက်မှု unsafety မှုမပေးနိုငျသညျ) လုံခြုံကုဒ်ထဲမှာ Run-အချိန်လျော့ပါးသွားမည်ဖြစ်သလိုစမ်းသပ်နှင့်ပြဋ္ဌာန်းပါဝင်သည်။
    ///
    ///
    /// # စိတ်ကြိုက်မက်ဆေ့ခ်ျများ
    ///
    /// ဤသည်နိုင်တဲ့ macro မိမိစိတ်ကြိုက် panic သတင်းစကားနှင့်အတူသို့မဟုတ်ပုံစံများအတွက်ငြင်းခုံခြင်းမရှိဘဲပေးနိုင်ပါသည်ရှိရာဒုတိယပုံစံရှိပါတယ်။
    /// ဤပုံစံများအတွက် syntax များအတွက် [`std::fmt`] ကိုကြည့်ပါ။
    /// အဆိုပါအခိုင်အမာပျက်ကွက်လျှင် format နဲ့ငြင်းခုံအဖြစ်အသုံးပြုအသုံးအနှုန်းတွေသာအကဲဖြတ်လိမ့်မည်။
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // ဤအအခိုင်အမာများအတွက် panic မက်ဆေ့ခ်ျကိုပေးထားသည့်စကားရပ်၏ stringified တန်ဖိုးကိုဖြစ်ပါတယ်။
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // အလွန်ရိုးရှင်းတဲ့ function ကို
    ///
    /// assert!(some_computation());
    ///
    /// // ထုံးစံသတင်းစကားနှင့်အတူအခိုင်အမာ
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// inline စည်းဝေးပွဲကို။
    ///
    /// အဆိုပါအသုံးပြုမှုများအတွက် [unstable book] ကိုဖတ်ပါ။
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM-စတိုင် inline စည်းဝေးပွဲကို။
    ///
    /// အဆိုပါအသုံးပြုမှုများအတွက် [unstable book] ကိုဖတ်ပါ။
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// inline စည်းဝေးပွဲကို module-Level ။
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Print စံ output ကိုသို့ tokens လွန်။
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// ဖွင့်မည်သို့မဟုတ်အခြားဘာလို့လဲဆိုတော့ Micro စနစ်နဲ့အခြားသော debugging အတှကျအသုံးပွုလုပ်ဆောင်ချက်ကို tracing ပိတ်။
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Attribute macro သည် derive macros များကိုအသုံးပြုခဲ့သည်။
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Attribute macro သည် function ကိုအသုံးချပြီး unit test သို့ပြောင်းသည်။
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// attribute နိုင်တဲ့ macro တစ်ဦးအခြေခံစံနှုန်းစမ်းသပ်မှုသို့လှည့်တစ်ဦး function ကိုမှလျှောက်လွှာတင်ခဲ့တယ်။
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// အဆိုပါ `#[test]` နှင့် `#[bench]` ဘာလို့လဲဆိုတော့ Micro စနစ်နဲ့အခြားသောတစ်ခုအကောင်အထည်ဖော်မှုအသေးစိတ်။
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// attribute နိုင်တဲ့ macro ကမ္ဘာလုံးဆိုင်ရာခွဲဝေအဖြစ်မှတ်ပုံတင်ရန်အငြိမ်ဖို့လျှောက်လွှာတင်ခဲ့တယ်။
    ///
    /// [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html) ကိုလည်းရှုပါ။
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// အဆိုပါလွန်လမ်းကြောင်းကိုလက်လှမ်းဖြစ်ပြီး, မဟုတ်ရင်ကဖယ်ရှားပေးလျှင်အသုံးချမယ့်ပစ္စည်းစောင့်ရှောက်။
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// သူအသုံးပြုသောကုဒ်အပိုင်းအစ၌ရှိသော `#[cfg]` နှင့် `#[cfg_attr]` attribute အားလုံးကိုချဲ့ထွင်သည်။
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// `rustc` compiler ၏မတည်မငြိမ်အကောင်အထည်ဖော်မှုအသေးစိတ်, မသုံးပါနဲ့။
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// `rustc` compiler ၏မတည်မငြိမ်အကောင်အထည်ဖော်မှုအသေးစိတ်, မသုံးပါနဲ့။
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}