#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker` သည်အလုပ်တစ်ခုကိုအကောင်အထည်ဖော်သူ၏အကောင်အထည်ဖော်သူအားစိတ်ကြိုက်နိုးကြားစေသောအပြုအမူများကိုထောက်ပံ့ပေးသော [`Waker`] ကိုဖန်တီးရန်ခွင့်ပြုသည်။
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// ၎င်းတွင် data pointer နှင့် `RawWaker` ၏အပြုအမူကိုစိတ်ကြိုက်ပြုပြင်သည်။
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// အုပ်ချုပ်သူမှလိုအပ်သည့်အတိုင်းမတရားဒေတာများကိုသိမ်းဆည်းရန်အသုံးပြုနိုင်သည့်ဒေတာအချက်ပြ။
    /// ဒါကဥပမာဖြစ်နိုင်ပါတယ်
    /// အလုပ်နှင့်ဆက်စပ်ကြောင်းတစ်ခု `Arc` ဖို့ type ကို-ဖျက် pointer ။
    /// ဒီ field ရဲ့တန်ဖိုးကိုပထမဦးဆုံး parameter သည်အတိုင်း vtable ၏အစိတ်အပိုင်းတစ်ခုဖြစ်ကြောင်းအားလုံးလုပ်ဆောင်ချက်များကိုမှလွန်ရောက်လာပါတယ်။
    ///
    data: *const (),
    /// ဒီ waker ၏အပြုအမူကိုစိတ်ကြိုက်ပြုလုပ်ထားသော Virtual function pointer table ။
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// ပေးထားသော `data` pointer နှင့် `vtable` မှ `RawWaker` အသစ်တစ်ခုကိုဖန်တီးသည်။
    ///
    /// `data` pointer သည်အမှုဆောင်အရာရှိမှလိုအပ်သည့်အတိုင်းမတရားဒေတာကိုသိမ်းဆည်းရန်အသုံးပြုနိုင်သည်။ဒါကဥပမာဖြစ်နိုင်ပါတယ်
    /// အလုပ်နှင့်ဆက်စပ်ကြောင်းတစ်ခု `Arc` ဖို့ type ကို-ဖျက် pointer ။
    /// ဒီ pointer ၏တန်ဖိုးကိုပထမဦးဆုံး parameter သည်အတိုင်း `vtable` ၏အစိတ်အပိုင်းတစ်ခုဖြစ်ကြောင်းအားလုံးလုပ်ဆောင်ချက်များကိုမှအောင်မြင်ပြီးရပါလိမ့်မယ်။
    ///
    /// အဆိုပါ `vtable` တစ် `RawWaker` ကနေဖန်တီးရရှိသည့် `Waker` ၏အပြုအမူ customizes ။
    /// `Waker` ပေါ်ရှိလုပ်ဆောင်မှုတစ်ခုစီတိုင်းအတွက်နောက်ခံ `RawWaker` ၏ `vtable` ရှိဆက်စပ်လုပ်ဆောင်မှုကိုခေါ်လိမ့်မည်။
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// [`RawWaker`] ၏အပြုအမူကိုသတ်မှတ်ပေးသော virtual function pointer table (vtable) ။
///
/// vtable အတွင်းရှိလုပ်ဆောင်မှုအားလုံးသို့လွှဲပြောင်းပေးသော pointer သည် [`RawWaker`] object မှ `data` pointer ဖြစ်သည်။
///
/// ဒီ struct အတွင်းရှိလုပ်ဆောင်ချက်များကိုသာ [`RawWaker`] အကောင်အထည်ဖော်မှုအတွင်းပိုင်းကနေစနစ်တကျဆောက်လုပ်ထား [`RawWaker`] အရာဝတ္ထု၏ `data` pointer အပေါ်ကိုခေါ်ခံရဖို့ရည်ရွယ်နေကြသည်။
/// အခြားမည်သည့် `data` pointer ကိုသုံးပြီးပါရှိသောလုပ်ဆောင်ချက်များကိုများထဲမှ Calling undefined အပြုအမူကိုဖြစ်ပေါ်စေပါလိမ့်မယ်။
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// အဆိုပါ [`RawWaker`] ပုံတူမျိုးပွားရရှိသည့်အခါဒီ function ဟာ [`RawWaker`] သိမ်းဆည်းထားထားတဲ့အတွက် [`Waker`] ပုံတူမျိုးပွားရရှိဥပမာအခါ, ဟုခေါ်ဝေါ်ခြင်းကိုခံရပါလိမ့်မယ်။
    ///
    /// ဤလုပ်ဆောင်ချက်၏အကောင်အထည်ဖော်မှုသည်ဤအပိုဆောင်း [`RawWaker`] နှင့်ဆက်စပ်သောအလုပ်အတွက်လိုအပ်သောအရင်းအမြစ်များအားလုံးကိုထိန်းသိမ်းထားရမည်။
    /// ရရှိလာတဲ့ [`RawWaker`] ပေါ်က `wake` ကိုခေါ်ခြင်းဟာမူလ [`RawWaker`] ကနိုးလာလိမ့်မယ်လို့တူညီတဲ့အလုပ်တစ်ခုကိုနိုးထစေသင့်ပါတယ်။
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// `wake` ကို [`Waker`] တွင်ခေါ်သည့်အခါဤလုပ်ဆောင်မှုကိုခေါ်လိမ့်မည်။
    /// ၎င်းသည် [`RawWaker`] နှင့်သက်ဆိုင်သောအလုပ်ကိုနှိုးရမည်ဖြစ်သည်။
    ///
    /// ဤလုပ်ဆောင်ချက်၏အကောင်အထည်ဖော်မှုသည် [`RawWaker`] နှင့်ဆက်စပ်သောအလုပ်၏ဆက်စပ်မှုရှိသည့်မည်သည့်အရင်းအမြစ်ကိုမဆိုထုတ်လွှတ်ရန်သေချာစေရမည်။
    ///
    ///
    wake: unsafe fn(*const ()),

    /// `wake_by_ref` ကို [`Waker`] တွင်ခေါ်သည့်အခါဤလုပ်ဆောင်မှုကိုခေါ်လိမ့်မည်။
    /// ၎င်းသည် [`RawWaker`] နှင့်သက်ဆိုင်သောအလုပ်ကိုနှိုးရမည်ဖြစ်သည်။
    ///
    /// ဒီ function `wake` ဆင်တူသည်, သို့သော်ထောက်ပံ့ဒေတာ pointer ကိုမပယ်မရှားရပေမည်။
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// [`RawWaker`] ကျဆင်းသွားသောအခါဤလုပ်ဆောင်မှုကိုခေါ်သည်။
    ///
    /// ဤလုပ်ဆောင်ချက်၏အကောင်အထည်ဖော်မှုသည် [`RawWaker`] နှင့်ဆက်စပ်သောအလုပ်၏ဆက်စပ်မှုရှိသည့်မည်သည့်အရင်းအမြစ်ကိုမဆိုထုတ်လွှတ်ရန်သေချာစေရမည်။
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// ပေးထားသော `clone`, `wake`, `wake_by_ref` နှင့် `drop` လုပ်ဆောင်ချက်များမှ `RawWakerVTable` အသစ်တစ်ခုကိုဖန်တီးသည်။
    ///
    /// # `clone`
    ///
    /// အဆိုပါ [`RawWaker`] ပုံတူမျိုးပွားရရှိသည့်အခါဒီ function ဟာ [`RawWaker`] သိမ်းဆည်းထားထားတဲ့အတွက် [`Waker`] ပုံတူမျိုးပွားရရှိဥပမာအခါ, ဟုခေါ်ဝေါ်ခြင်းကိုခံရပါလိမ့်မယ်။
    ///
    /// ဤလုပ်ဆောင်ချက်၏အကောင်အထည်ဖော်မှုသည်ဤအပိုဆောင်း [`RawWaker`] နှင့်ဆက်စပ်သောအလုပ်အတွက်လိုအပ်သောအရင်းအမြစ်များအားလုံးကိုထိန်းသိမ်းထားရမည်။
    /// ရရှိလာတဲ့ [`RawWaker`] ပေါ်က `wake` ကိုခေါ်ခြင်းဟာမူလ [`RawWaker`] ကနိုးလာလိမ့်မယ်လို့တူညီတဲ့အလုပ်တစ်ခုကိုနိုးထစေသင့်ပါတယ်။
    ///
    /// # `wake`
    ///
    /// `wake` ကို [`Waker`] တွင်ခေါ်သည့်အခါဤလုပ်ဆောင်မှုကိုခေါ်လိမ့်မည်။
    /// ၎င်းသည် [`RawWaker`] နှင့်သက်ဆိုင်သောအလုပ်ကိုနှိုးရမည်ဖြစ်သည်။
    ///
    /// ဤလုပ်ဆောင်ချက်၏အကောင်အထည်ဖော်မှုသည် [`RawWaker`] နှင့်ဆက်စပ်သောအလုပ်၏ဆက်စပ်မှုရှိသည့်မည်သည့်အရင်းအမြစ်ကိုမဆိုထုတ်လွှတ်ရန်သေချာစေရမည်။
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// `wake_by_ref` ကို [`Waker`] တွင်ခေါ်သည့်အခါဤလုပ်ဆောင်မှုကိုခေါ်လိမ့်မည်။
    /// ၎င်းသည် [`RawWaker`] နှင့်သက်ဆိုင်သောအလုပ်ကိုနှိုးရမည်ဖြစ်သည်။
    ///
    /// ဒီ function `wake` ဆင်တူသည်, သို့သော်ထောက်ပံ့ဒေတာ pointer ကိုမပယ်မရှားရပေမည်။
    ///
    /// # `drop`
    ///
    /// [`RawWaker`] ကျဆင်းသွားသောအခါဤလုပ်ဆောင်မှုကိုခေါ်သည်။
    ///
    /// ဤလုပ်ဆောင်ချက်၏အကောင်အထည်ဖော်မှုသည် [`RawWaker`] နှင့်ဆက်စပ်သောအလုပ်၏ဆက်စပ်မှုရှိသည့်မည်သည့်အရင်းအမြစ်ကိုမဆိုထုတ်လွှတ်ရန်သေချာစေရမည်။
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// asynchronous လုပ်ငန်းတစ်ခု၏ `Context` ။
///
/// လက်ရှိတွင် `Context` သည်လက်ရှိအလုပ်ကိုနိုးရန်အတွက်အသုံးပြုနိုင်သည့် `&Waker` ကိုသာအသုံးပြုခွင့်ပေးသည်။
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // (ပြန်လာ-အနေအထားကိုဘဝသက်တမ်း covariant နေစဉ်အငြင်းအခုံ-အနေအထားကိုဘဝသက်တမ်း contravariant ဖြစ်ကြသည်) လျော့ပါးသွားမည်ဖြစ်သလိုဖြစ်ဖို့တစ်သက်တာအတင်းအကျပ်အားဖြင့်ကှဲလှဲအပြောင်းအလဲများကိုဆန့်ကျင်ကျနော်တို့ future-အထောက်အထားအာမခံပါသည်။
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// `&Waker` တစ်ခုမှ `Context` အသစ်တစ်ခုကိုဖန်တီးပါ။
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// လက်ရှိအလုပ်အတွက် `Waker` တစ်ခုရည်ညွှန်းပြန်သွားသည်။
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker` ဆိုသည်မှာအလုပ်တစ်ခုကိုနိုးရန်အတွက်၎င်းကို၎င်း၏ executor ကို run ရန်အဆင်သင့်ဖြစ်ကြောင်းအသိပေးခြင်းဖြစ်သည်။
///
/// ဤလက်ကိုင်သည်အမှုဆောင်အရာရှိ-တိကျသောနိုးထမှုအပြုအမူကိုသတ်မှတ်ပေးသော [`RawWaker`] ဥပမာတစ်ခုပါ ၀ င်သည်။
///
///
/// အကောင်အထည်ဖော်မှု [`Clone`], [`Send`] နှင့် [`Sync`] ။
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// ဒီ `Waker` နဲ့သက်ဆိုင်တဲ့အလုပ်ကိုနှိုးပါ။
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // အမှန်တကယ် Wakeup ခေါ်ဆိုခအတွက် executor နေဖြင့်သတ်မှတ်သောအကောင်အထည်ဖော်မှုတစ်ဦးကို virtual function ကိုဖုန်းခေါ်ဆိုမှုမှတဆင့်လွှဲအပ်သည်။
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // `drop` ကိုမခေါ်ပါနှင့်-waker သည် `wake` မှစားလိမ့်မည်။
        crate::mem::forget(self);

        // လုံခြုံမှု-`Waker::from_raw` သည်တစ်ခုတည်းသောနည်းလမ်းဖြစ်သောကြောင့်၎င်းသည်လုံခြုံသည်
        // အသုံးပြုသူမှ `RawWaker` ၏စာချုပ်အားအတည်ပြုသည်ကိုအသိအမှတ်ပြုရန်လိုအပ်သည့် `wake` နှင့် `data` ကိုအစပြုရန်။
        //
        unsafe { (wake)(data) };
    }

    /// `Waker` ကိုမသုံးပဲဤ `Waker` နှင့်သက်ဆိုင်သောအလုပ်ကိုနှိုးပါ။
    ///
    /// ၎င်းသည် `wake` နှင့်ဆင်တူသော်လည်းပိုင်ဆိုင်သည့် `Waker` ရှိပါကအနည်းငယ်လျော့နည်းနိုင်သည်။
    /// ဤနည်းလမ်းကို `waker.clone().wake()` သို့ခေါ်ဆိုခြင်းကိုပိုမိုနှစ်သက်သင့်သည်။
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // အမှန်တကယ် Wakeup ခေါ်ဆိုခအတွက် executor နေဖြင့်သတ်မှတ်သောအကောင်အထည်ဖော်မှုတစ်ဦးကို virtual function ကိုဖုန်းခေါ်ဆိုမှုမှတဆင့်လွှဲအပ်သည်။
        //

        // လုံခြုံမှု: `wake` ကိုကြည့်ပါ
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// အကယ်၍ ဤ `Waker` နှင့်အခြား `Waker` အတူတူပင်အလုပ်ကိုနိုးလျှင် `true` သို့ပြန်သွားသည်။
    ///
    /// ဤလုပ်ဆောင်ချက်သည်အကောင်းဆုံးအားထုတ်မှုအခြေခံပေါ်တွင်အလုပ်လုပ်သည်။ `Waker ၏လုပ်ငန်းသည်တူညီသောအလုပ်ကိုနိုးထလာစေသည့်တိုင်မှားသွားနိုင်သည်။
    /// ဒီ function ကို `true` ပြန်လာလျှင်မည်သို့ပင်ဆို, က `Waker`s တူညီသောတာဝန်နှိုးမည်အကြောင်းအာမခံသည်။
    ///
    /// ဒီ function ကိုအဓိကအားဖြင့် optimization ရည်ရွယ်ချက်များအတွက်အသုံးပြုသည်။
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// [`RawWaker`] ကနေအသစ်တခု `Waker` ဖန်တီးပေးပါတယ်။
    ///
    /// အတွက်သတ်မှတ်ထားတဲ့စာချုပ်လျှင်ပြန်ရောက် `Waker` ၏အပြုအမူ undefined ဖြစ်ပါတယ် [`RawWaker`] '' s နှင့် [`RawWakerVTable`] 's စာရွက်စာတမ်းများထောက်မပေးပါ။
    ///
    /// ထို့ကြောင့်ဤနည်းလမ်းမလုံခြုံသည်။
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // လုံခြုံမှု-`Waker::from_raw` သည်တစ်ခုတည်းသောနည်းလမ်းဖြစ်သောကြောင့်၎င်းသည်လုံခြုံသည်
            // အသုံးပြုသူမှ [`RawWaker`] ၏စာချုပ်အားအတည်ပြုသည်ကိုအသိအမှတ်ပြုရန်လိုအပ်သည့် `clone` နှင့် `data` ကိုအစပြုရန်။
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // လုံခြုံမှု-`Waker::from_raw` သည်တစ်ခုတည်းသောနည်းလမ်းဖြစ်သောကြောင့်၎င်းသည်လုံခြုံသည်
        // `RawWaker` ၏စာချုပ်ထောကျခံခဲ့ကြောင်းဝန်ခံရန်အသုံးပြုသူလိုအပ် `drop` နှင့် `data` စတငျဖို့။
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}