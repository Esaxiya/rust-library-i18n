//! types များအကြားစကားဝိုင်းအတွက် Traits ။
//!
//! ဤ module ရှိ traits သည်အမျိုးအစားတစ်ခုမှအခြားအမျိုးအစားသို့ပြောင်းရန်နည်းလမ်းတစ်ခုဖြစ်သည်။
//! တစ်ခုချင်းစီကို trait တစ်ဦးကွဲပြားခြားနားရည်ရွယ်ချက်တာဝန်ထမ်းဆောင်:
//!
//! - စျေးပေါရည်ညွှန်း-to-ရည်ညွှန်းပြောင်းလဲမှုများအတွက် [`AsRef`] trait အကောင်အထည်ဖော်ပါ
//! - စျေးသက်သာပြီးပြောင်းလဲနိုင်သောပြောင်းလဲမှုများအတွက် [`AsMut`] trait ကိုအကောင်အထည်ဖော်ပါ
//! - Value-To-တန်ဖိုးကိုစကားလက်ဆုံပြောဆိုမှုများစားသုံးများအတွက် [`From`] trait အကောင်အထည်ဖော်ရန်
//! - လက်ရှိ crate ပြင်ပရှိတန်ဖိုးများနှင့်တန်ဖိုးပြောင်းလဲမှုများကိုအသုံးပြုရန်အတွက် [`Into`] trait ကိုအကောင်အထည်ဖော်ပါ။
//! - [`TryFrom`] နှင့် [`TryInto`] traits သည် [`From`] နှင့် [`Into`] ကဲ့သို့ပြုမူသော်လည်းပြောင်းလဲခြင်းမအောင်မြင်သောအခါအကောင်အထည်ဖော်သင့်သည်။
//!
//! ဤ module ရှိ traits ကိုယေဘူယျလုပ်ဆောင်ချက်များအတွက် trait bounds အဖြစ်မကြာခဏအသုံးပြုသည်။ အငြင်းပွားမှုမျိုးစုံအတွက်ငြင်းခုံခြင်းများကိုထောက်ခံသည်။ဥပမာများအတွက် trait တစ်ခုချင်းစီ၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
//!
//! စာကြည့်တိုက်စာရေးသူတစ် ဦး အနေဖြင့်သင်သည် [`Into<U>`][`Into`] သို့မဟုတ် [`TryInto<U>`][`TryInto`] ထက် [`From<T>`][`From`] သို့မဟုတ် [`TryFrom<T>`][`TryFrom`] ကိုအမြဲတမ်းအသုံးပြုသင့်သည်။ [`From`] နှင့် [`TryFrom`] သည်ပိုမိုလွယ်ကူစွာပြောင်းလွယ်ပြင်လွယ်ရှိသောကြောင့်စံပြစာကြည့်တိုက်တွင်အပြည့်အ ၀ အကောင်အထည်ဖော်ခြင်းအားဖြင့်ညီမျှသော [`Into`] သို့မဟုတ် [`TryInto`] အကောင်အထည်ဖော်မှုကိုအခမဲ့ပေးသည်။
//! ကြိုတင် Rust 1.41 တစ်ဗားရှင်းပစ်မှတ်ထားသောအခါ, လက်ရှိ crate အပြင်ဘက်အမျိုးအစားမှပြောင်းလဲတဲ့အခါမှာတိုက်ရိုက် [`Into`] သို့မဟုတ် [`TryInto`] အကောင်အထည်ဖေါ်ရန်လိုအပ်သောဖြစ်နိုင်သည်။
//!
//! # generic အကောင်အထည်ဖော်မှု
//!
//! - [`AsRef`] နှင့်အတွင်းပိုင်းအမျိုးအစားကိုကိုးကားပါလျှင်နှင့် [`AsMut`] အလိုအလျောက် dereference
//! - [`From`]`<U>T` အဘို့ `[` Into`] အဓိပ္ပာယ်သက်ရောက်</u><T><U>U` အတွက်</u>
//! - [`TryFrom`]`<U>အတွက် T` သည်</u> [`TryInto`]`<U>ကိုဆိုလိုသည်</u><T><U>U` အတွက်</u>
//! - [`From`] [`Into`] သည် reflexive ဖြစ်သည်။ ဆိုလိုသည်မှာ၎င်းတို့အားလုံးသည် `into` နှင့် `from` သူတို့ကိုယ်တိုင်လုပ်နိုင်သည်
//!
//! အသုံးပြုမှုဥပမာများအတွက် trait တစ်ခုချင်းစီကိုကြည့်ပါ။
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// ဝိသေသလက္ခဏာ function ကို။
///
/// အရာနှစ်ခုကဒီ function ကိုအကြောင်းကိုမှတ်စုအရေးကြီးလှသည်:
///
/// - ပိတ်ပစ်တစ်ဦးကွဲပြားခြားနားအမျိုးအစားသို့ `x` အကြပ်ကိုင်လာဖို့စခွေငျးငှါကတည်းကဒါဟာအမြဲ `|x| x` ကဲ့သို့သောပိတ်သိမ်းညီမျှမဟုတ်ပါဘူး။
///
/// - ၎င်းသည် `x` ၏လုပ်ဆောင်ချက်ကိုလွှဲပြောင်းပေးသည်။
///
/// input ကိုပြန်ပို့ပေးသော function တစ်ခုရှိခြင်းသည်ထူးဆန်းနေပုံရသော်လည်းစိတ်ဝင်စားဖွယ်အသုံးပြုမှုအချို့ရှိသည်။
///
///
/// # Examples
///
/// အခြားစိတ်ဝင်စားဖွယ်, လုပ်ငန်းဆောင်တာတစ်ခု sequence ကိုအတွက်ဘာမျှလုပ် `identity` အသုံးပြုခြင်း:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // ရဲ့တဦးတည်းဖြည့်စွက်ထားတဲ့စိတ်ဝင်စားစရာကောင်းတဲ့ function ကြောင်းဟန်ဆောင်ကြပါစို့။
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// တစ်ဦးခြွင်းချက်တစ်ခု "do nothing" အခြေစိုက်စခန်းကိစ္စတွင်အဖြစ် `identity` အသုံးပြုခြင်း:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // ပိုပြီးစိတ်ဝင်စားစရာကောင်းတဲ့အရာတွေကိုလုပ်ပါ။
///
/// let _results = do_stuff(42);
/// ```
///
/// `Option<T>` ကို အသုံးပြု၍ `Option<T>` ၏ကြားဖြတ်တစ်ခု၏ `Some` အမျိုးအစားများကိုထိန်းသိမ်းရန်:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// တစ်ဦးစျေးပေါရည်ညွှန်း-to-ရည်ညွှန်းပြောင်းလဲခြင်းလုပ်ဖို့ကိုအသုံးပြုခဲ့သည်။
///
/// ဤသည် trait mutable ညွှန်းဆိုအကြားပြောင်းလဲအသုံးပြုသည်အရာ [`AsMut`] ဆင်တူသည်။
/// အကယ်၍ သင်သည်အကုန်အကျများသောပြောင်းလဲခြင်းကိုပြုလုပ်ရန်လိုအပ်ပါက `&T` အမျိုးအစားနှင့် [`From`] ကိုအကောင်အထည်ဖော်ရန်သို့မဟုတ်စိတ်ကြိုက်လုပ်ဆောင်ချက်တစ်ခုရေးရန်ပိုကောင်းသည်။
///
/// `AsRef` [`Borrow`] ကဲ့သို့တူညီသောလက်မှတ်ရှိပါတယ်, ဒါပေမယ့် [`Borrow`] အနည်းငယ်ရှုထောင့်မှာရှိတဲ့ကွဲပြားခြားနားသည်:
///
/// - `AsRef` နှင့်မတူဘဲ [`Borrow`] သည် `T` အတွက်လုံးလုံးလျားလျားအဓိပ္ပာယ်သက်ရောက်သည်။ ရည်ညွှန်းမှုသို့မဟုတ်တန်ဖိုးတစ်ခုခုကိုလက်ခံရန်အသုံးပြုနိုင်သည်။
/// - [`Borrow`] ထို့အပြင်ငှားရမ်းထားသောတန်ဖိုးအတွက် [`Hash`], [`Eq`] နှင့် [`Ord`] တို့သည်ပိုင်ဆိုင်သည့်တန်ဖိုးနှင့်ညီမျှရန်လိုအပ်သည်။
/// သင်တစ်ဦး struct သာတစ်ခုတည်းသောလယ်ချေးချင်တယ်ဆိုရင်ဒီအကြောင်းပြချက်များအတွက်, သငျသညျ [`Borrow`] `AsRef` အကောင်အထည်ဖော်ဖို့, ဒါပေမယ့်မရဘူး။
///
/// **Note: ဤ trait သည်ပျက်မည်မဟုတ်ပါ။ **ပြောင်းလဲခြင်းကျရှုံးနိုင်လျှင်တစ်ဦး [`Option<T>`] တစ်ခုသို့မဟုတ် [`Result<T, E>`] ပြန်လည်ရောက်ရှိသည့်ဆက်ကပ်အပ်နှံနည်းလမ်းကိုအသုံးပြုပါ။
///
/// # generic အကောင်အထည်ဖော်မှု
///
/// - `AsRef` အကယ်၍ အတွင်းပိုင်းအမျိုးအစားသည်ရည်ညွှန်းမှုသို့မဟုတ်ပြောင်းလဲနိုင်သောရည်ညွှန်းချက်ဖြစ်ပါကအလိုအလျောက်ဖျက်သိမ်းခြင်း (ဥပမာ- `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// trait bounds ကိုအသုံးပြုခြင်းအားဖြင့်၎င်းတို့သည်သတ်မှတ်ထားသော `T` အမျိုးအစားသို့ပြောင်းလဲနိုင်သရွေ့မတူကွဲပြားသောအငြင်းပွားမှုများကိုလက်ခံနိုင်သည်။
///
/// ဥပမာ: တစ်ခု `AsRef<str>` ကြာတဲ့ယေဘုယျ function ကိုကိုအားဖြင့်ကျွန်ုပ်တို့တစ်ဦးအငြင်းအခုံအဖြစ် [`&str`] ကူးပြောင်းနိုင်ပါတယ်သမျှသောညွှန်းဆိုကိုလက်မခံချင်သောဖော်ပြ။
/// [`String`] နှင့် [`&str`] နှစ်ဦးစလုံးကျနော်တို့ input ကိုအငြင်းအခုံအဖြစ်နှစ်ဦးစလုံးလက်ခံနိုင်သည် `AsRef<str>` အကောင်အထည်ဖော်ကတည်းက။
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// ပြောင်းလဲခြင်းလုပ်ဆောင်တယ်။
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// တစ်ဦးစျေးပေါ mutable-to-mutable ရည်ညွှန်းပြောင်းလဲခြင်းလုပ်ဖို့ကိုအသုံးပြုခဲ့သည်။
///
/// ဤ trait သည် [`AsRef`] နှင့်ဆင်တူသော်လည်း mutable reference များအကြားပြောင်းလဲရန်အသုံးပြုသည်။
/// သင်တစ်ဦးအကုန်အကျပြောင်းလဲခြင်းလုပ်ဖို့လိုအပ်ခဲ့လျှင်၎င်းသည်အမျိုးအစား `&mut T` နှင့်အတူ [`From`] အကောင်အထည်ဖော်ရန်တစ်ခုသို့မဟုတ်ထုံးစံ function ကိုရေးသားဖို့ သာ. ကောင်း၏။
///
/// **Note: ဤ trait သည်ပျက်မည်မဟုတ်ပါ။ **ပြောင်းလဲခြင်းကျရှုံးနိုင်လျှင်တစ်ဦး [`Option<T>`] တစ်ခုသို့မဟုတ် [`Result<T, E>`] ပြန်လည်ရောက်ရှိသည့်ဆက်ကပ်အပ်နှံနည်းလမ်းကိုအသုံးပြုပါ။
///
/// # generic အကောင်အထည်ဖော်မှု
///
/// - `AsMut` အကယ်၍ အတွင်းပိုင်းအမျိုးအစားသည်ပြောင်းလဲနိုင်သောရည်ညွှန်းချက်ဖြစ်ပါက (ဥပမာ- `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// ယေဘူယျလုပ်ဆောင်မှုအတွက် `AsMut` ကို trait bound အဖြစ်အသုံးပြုခြင်းသည် `&mut T` အမျိုးအစားသို့ကူးပြောင်းနိုင်သောပြောင်းလဲနိုင်သောရည်ညွှန်းချက်များကိုလက်ခံနိုင်သည်။
/// [`Box<T>`] `AsMut<T>` အကောင်အထည်ဖော်ဆောင်ရွက်နေသောကြောင့် `&mut u64` ကူးပြောင်းနိုင်ပါတယ်သောသူအပေါင်းတို့သည်အငြင်းပွားမှုများကြာတဲ့ function ကို `add_one` ရေးလိုက်နိုင်ပါတယ်။
/// [`Box<T>`] က `AsMut<T>` ကိုသုံးသောကြောင့် `add_one` သည် `&mut Box<u64>` အမျိုးအစား၏အငြင်းပွားမှုများကိုလက်ခံသည်။
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// ပြောင်းလဲခြင်းလုပ်ဆောင်တယ်။
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// အဆိုပါ input တန်ဖိုးကိုစားသုံးတဲ့တန်ဖိုးကို-to-တန်ဖိုးကိုပြောင်းလဲခြင်း။[`From`] ၏ဆန့်ကျင်ဘက်။
///
/// တဦးတည်း [`Into`] အကောင်အထည်ဖော်ရှောင်ရှားခြင်းနှင့်အစား [`From`] အကောင်အထည်ဖော်သင့်ပါတယ်။
/// အကောင်အထည်ဖော်ရေး [`From`] အလိုအလျောက်စံစာကြည့်တိုက်အတွက်စောင်အကောင်အထည်ဖော်မှုမှ [`Into`] ကျေးဇူးတင်စကားတစ်ခုအကောင်အထည်ဖော်ရေးနှင့်တသားတပေးပါသည်။
///
/// [`Into`] ကိုသာအကောင်အထည်ဖော်သောအမျိုးအစားများကိုကောင်းစွာအသုံးပြုနိုင်မည်ကိုသေချာစေရန်ယေဘူယျလုပ်ဆောင်ချက်တစ်ခုတွင် trait bounds ကိုသတ်မှတ်သောအခါ [`Into`] ထက် [`From`] ကိုအသုံးပြုပါ။
///
/// **Note: ဤသည် trait ** ကျရှုံးမပြုရပါ။ပြောင်းလဲခြင်းကျရှုံးနိုင်လျှင်, [`TryInto`] ကိုအသုံးပြုပါ။
///
/// # generic အကောင်အထည်ဖော်မှု
///
/// - [`From`]`<T>U` အဘို့အ `Into<U> for T` ဆိုလို
/// - [`Into`] `Into<T> for T` အကောင်အထည်ဖော်ကြောင်း, ဆိုလိုတာက reflex ဖြစ်ပါသည်
///
/// # Rust ၏ဟောင်းများကိုဗားရှင်းအတွက်ပြင်ပအမျိုးအစားများမှဘာသာပြောင်းမှုအတွက် [`Into`] အကောင်အထည်ဖော်
///
/// Rust 1.41 မတိုင်မီက destination သည်အမျိုးအစားလက်ရှိ crate ၏အစိတ်အပိုင်းတစ်ခုမဟုတ်ခဲ့လျှင်သင်တိုက်ရိုက် [`From`] အကောင်အထည်မဖော်နိုင်ဘူး။
/// ဥပမာ, ဒီ code ကိုယူ:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// ဤသည် Rust ရဲ့မိဘမဲ့စည်းမျဉ်းစည်းကမ်းတွေကိုနည်းနည်းပိုတင်းကျပ်ဖြစ်ဖို့အသုံးပြုကြောင့်ဘာသာစကား၏အဟောင်းတွေဗားရှင်းအတွက် compile ရန်ပျက်ကွက်ပါလိမ့်မယ်။
/// ၎င်းကိုရှောင်ရှားရန်အတွက်သင်သည် [`Into`] ကိုတိုက်ရိုက်အကောင်အထည်ဖော်နိုင်သည်။
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// ဒါဟာ [`Into`] ([`From`] [`Into`] နှင့်အတူမကဲ့သို့) တစ်ဦး [`From`] အကောင်အထည်ဖော်မှုပေးတော်မမူကြောင်းကိုနားလည်သဘောပေါက်ရန်အရေးကြီးပါသည်။
/// ထို့ကြောင့်, သင်အမြဲ [`From`] အကောင်အထည်ဖော်ပြီးတော့ [`From`] အကောင်အထည်ဖော်မရနိုငျပါလျှင် [`Into`] ပြန်လဲကျဖို့ကြိုးစားသင့်ပါတယ်။
///
/// # Examples
///
/// [`String`] သုံးကိရိယာ [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// ယေဘူယျလုပ်ဆောင်ချက်သည်သတ်မှတ်ထားသော `T` အမျိုးအစားသို့ပြောင်းလဲနိုင်သည့်အငြင်းပွားမှုများအားလုံးကိုဖော်ပြလိုကြောင်းဖော်ပြရန်ကျွန်ုပ်တို့သည် [`Into`] ၏ trait bound ကိုအသုံးပြုနိုင်သည်။<T>`။
///
/// ဥပမာ: အဆိုပါ function ကို `is_hello` `တစ်ဦး [` Vec`]`<`[`u8`]`> သို့ကူးပြောင်းနိုင်ပါတယ်သောသူအပေါင်းတို့သည်အငြင်းပွားမှုများကြာပါသည်။
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// ပြောင်းလဲခြင်းလုပ်ဆောင်တယ်။
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// ထည့်သွင်းတန်ဖိုးကိုစားသုံးနေစဉ်တန်ဖိုး-to-တန်ဖိုးပြောင်းလဲမှုများလုပ်ဖို့အသုံးပြုခဲ့သည်။ဒါဟာ [`Into`] များ၏အပြန်အလှန်ဖြစ်ပါတယ်။
///
/// တစ်ခုမှာအမြဲအလိုအလြောကျ `From` အကောင်အထည်ဖော်စံစာကြည့်တိုက်အတွက်စောင်အကောင်အထည်ဖော်မှုမှ [`Into`] ကျေးဇူးတင်စကားတစ်ခုအကောင်အထည်ဖော်မှုနှင့်အတူတဦးတည်းကိုထောက်ပံ့ပေးနေသောကြောင့် [`Into`] ကျော် `From` အကောင်အထည်ဖော်ကြိုက်တတ်တဲ့သငျ့သညျ။
///
///
/// ကြိုတင် Rust 1.41 တစ်ဗားရှင်းပစ်မှတ်ထားနှင့်လက်ရှိ crate အပြင်ဘက်အမျိုးအစားမှပြောင်းလဲလာသောအခါ [`Into`] သာလျှင်အကောင်အထည်ဖေါ်။
/// `From` ဘာဖြစ်လို့လဲဆိုတော့ Rust ရဲ့မိဘမဲ့စည်းမျဉ်းများအစောပိုင်း version အတွက်ပြောင်းလဲခြင်းသည်ဤအမျိုးအစားများကိုလုပ်ဖို့မတတျနိုငျဖြစ်ခဲ့သည်။
/// အသေးစိတ်အတွက် [`Into`] ကိုကြည့်ပါ။
///
/// တစ်ဦးယေဘုယျ function ကိုအပေါ် trait bounds သတ်မှတ်ခြင်းသည့်အခါ `From` သုံးပြီးကျော် [`Into`] သုံးပြီးမှုဦးစားပေး။
/// ဤနည်းကိုတိုက်ရိုက် [`Into`] အကောင်အထည်ဖော်ရန်ကြောင်းအမျိုးအစားများအပြင်အငြင်းပွားမှုများအဖြစ်အသုံးပြုနိုင်ပါသည်။
///
/// အမှားကိုင်တွယ်သည့်အခါ `From` သည်အလွန်အသုံးဝင်သည်။ပျက်ကွက်နိုင်စွမ်းသော function ကိုဆောက်လုပ်သောအခါ, ပြန်လာ type ကိုယေဘုယျအားဖြင့်ပုံစံ `Result<T, E>` ၏ဖြစ်လိမ့်မည်။
/// `From` trait သည်လုပ်ဆောင်ချက်တစ်ခုအားအမှားမျိုးစုံကိုခြုံငုံမိသောအမှားအယွင်းတစ်ခုအားပြန်လာခွင့်ပြုခြင်းဖြင့်အမှားကိုင်တွယ်ခြင်းကိုရိုးရှင်းစေသည်။အသေးစိတ်များအတွက် "Examples" အပိုင်းများနှင့် [the book][book] ကိုကြည့်ပါ။
///
/// **Note: ဤသည် trait ** ကျရှုံးမပြုရပါ။ပြောင်းလဲခြင်းကျရှုံးနိုင်လျှင်, [`TryFrom`] ကိုအသုံးပြုပါ။
///
/// # generic အကောင်အထည်ဖော်မှု
///
/// - `From<T> for U` <U>T`များအတွက်</u> [`Into`]` ကိုဆိုလို
/// - `From` reflexive သည် `From<T> for T` ကိုအကောင်အထည်ဖော်သည်
///
/// # Examples
///
/// [`String`] `From<&str>` ကိုအသုံးပြုသည်။
///
/// `&str` တစ်ခုမှ String တစ်ခုသို့ရှင်းလင်းစွာပြောင်းလဲခြင်းကိုအောက်ပါအတိုင်းပြုလုပ်သည်။
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// အမှားကိုင်တွယ်မှုပြုလုပ်နေစဉ် `From` ကိုသင့်ကိုယ်ပိုင်အမှားအမျိုးအစားအတွက်အသုံးချတတ်သည်။
/// နောက်ခံအမှားအမျိုးအစား encapsulates ကျွန်တော်တို့ရဲ့ကိုယ်ပိုင်ထုံးစံအမှားအမျိုးအစားမှနောက်ခံအမှားအမျိုးအစားများကိုပြောင်းလဲခွငျးအားဖွငျ့ကြှနျုပျတို့နောက်ခံအကြောင်းရင်းအပေါ်သတင်းအချက်အလက်ဆုံးရှုံးမပါဘဲတစ်ခုတည်းအမှား type ကိုပြန်လာနိုင်ပါတယ်။
/// အဆိုပါ '?' အော်ပရေတာကိုအလိုအလျောက် `From` အကောင်အထည်ဖော်တဲ့အခါမှာအလိုအလျှောက်ပေးသော `Into<CliError>::into` ခေါ်ဆိုခြင်းဖြင့်ကျွန်တော်တို့ရဲ့ထုံးစံအမှားအမျိုးအစားဖို့နောက်ခံအမှား type ကိုပြောင်းပေးပါတယ်။
/// `Into` ၏အကောင်အထည်ဖော်မှုကိုအသုံးပြုရပါမည်ဖြစ်သောအဆိုပါ compiler ထို့နောက်အခြ။
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// ပြောင်းလဲခြင်းလုပ်ဆောင်တယ်။
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// တစ်ဦးသို့မဟုတ်မ may စျေးကြီးဖြစ်နိုင်သည်သော `self` စားသုံးကြောင်းပြောင်းလဲခြင်းကြိုးစားခဲ့တယ်။
///
/// စာကြည့်တိုက်စာရေးသူများအနေဖြင့်ဤ trait ကိုတိုက်ရိုက်အကောင်အထည်မဖော်သင့်ပါ။ သို့သော်ပုံမှန်စာကြည့်တိုက်တွင်အပြည့်အ ၀ အကောင်အထည်ဖော်ခြင်းကြောင့်၎င်းသည်ညီမျှသော `TryInto` အကောင်အထည်ဖော်မှုကိုအခမဲ့ထောက်ပံ့ပေးသော [`TryFrom`] trait ကို ပိုမို၍ အသုံးချသင့်သည်။
/// ဒီအပေါ်ပိုမိုသောအချက်အလက်များအဘို့, [`Into`] များအတွက်မှတ်တမ်းတင်ကြည့်ရှုပါ။
///
/// # `TryInto` ကိုအကောင်အထည်ဖော်
///
/// ဤသည် [`Into`], အသေးစိတျအဘို့ထိုအရပ်၌တွေ့မြင်အကောင်အထည်ဖော်ကဲ့သို့တူညီသောကန့်သတ်ခြင်းနှင့်ဆင်ခြင်ခြင်းကြုံတွေ့နေကြရသည်။
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// အမျိုးအစားပြောင်းလဲခြင်းအမှား၏ဖြစ်ရပ်အတွက်ပြန်လာ၏။
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// ပြောင်းလဲခြင်းလုပ်ဆောင်တယ်။
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// အချို့သောအခြေအနေများတွင်တစ်ဦးထိန်းချုပ်ထားလမ်းအတွက်ကျရှုံးစေခြင်းငှါရိုးရှင်းပြီးလုံခြုံစိတ်ချရသော type conversion ။၎င်းသည် [`TryInto`] ၏အပြန်အလှန်ဖြစ်သည်။
///
/// သင်အသေးအဖွဲအောင်မြင်မှုရနိုင်သော်လည်းအထူးကိုင်တွယ်ရန်လိုအပ်သောအမျိုးအစားပြောင်းလဲခြင်းတစ်ခုကိုပြုလုပ်သောအခါ၎င်းသည်အသုံးဝင်သည်။
/// ဥပမာအားဖြင့် X0 [`From`] trait ကို အသုံးပြု၍ [`i64`] ကို [`i32`] သို့ [`i32`] သို့ပြောင်းလဲရန်နည်းလမ်းမရှိပါ။ အဘယ်ကြောင့်ဆိုသော် [`i64`] တွင် [`i32`] ကိုယ်စားပြု၍ မရနိုင်သည့်အတွက်ပြောင်းလဲခြင်းသည်ဒေတာများဆုံးရှုံးနိုင်သည်။
///
/// ၎င်းသည် [`i64`] ကို [`i32`] (မရှိမဖြစ်လိုအပ်သော [`i64`] 's တန်ဖိုး modulo [`i32::MAX`] ပေးခြင်း)) သို့ပြန်သွားခြင်းအားဖြင့်သို့မဟုတ် [`i32::MAX`] ကိုရိုးရှင်းစွာပြန်ပို့ခြင်းသို့မဟုတ်အခြားနည်းလမ်းတစ်ခုဖြင့်ကိုင်တွယ်နိုင်သည်။
/// အဆိုပါ [`From`] trait စုံလင်သောစကားဝိုင်းအတွက်ရည်ရွယ်တာဖြစ်ပါတယ်, ဒါကြောင့် `TryFrom` trait အမျိုးအစားပြောင်းလဲခြင်းမကောင်းတဲ့သွားနိုင်သည့်အခါပရိုဂရမ်မာအကြောင်းကြားနှင့်သူတို့ကကိုင်တွယ်ရန်မည်သို့မည်ပုံဆုံးဖြတ်ပေးနိုင်ပါတယ်။
///
/// # generic အကောင်အထည်ဖော်မှု
///
/// - `TryFrom<T> for U` ဆိုလို [`TryInto`]`<U>T` များအတွက်</u>
/// - [`try_from`] reflexive သည် `TryFrom<T> for T` ကိုအကောင်အထည်ဖော်။ မရနိုင်ပါဟုဆိုလိုသည်။ `T` အမျိုးအစား `T` အမျိုးအစားအား X0 `T::try_from()` ဟုခေါ်သော `Error` အမျိုးအစားသည် [`Infallible`] ဖြစ်သည်။
/// [`!`] အမျိုးအစားတည်ငြိမ်သောအခါ [`Infallible`] နှင့် [`!`] နှင့်ညီမျှလိမ့်မည်။
///
/// `TryFrom<T>` အောက်မှာဖေါ်ပြတဲ့အတိုင်းအကောင်အထည်ဖော်နိုင်ပါတယ်:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// ဖော်ပြထားသကဲ့သို့, [`i32`] သုံးကိရိယာ `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // တိတ်တဆိတ်, `big_number` truncates ဆိုတဲ့အချက်ကိုပြီးနောက်ခြင်းကိုဖော်ထုတ်မယ်နှင့်ကိုင်တွယ်ရန်လိုအပ်သည်။
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // `big_number` တစ်ခု `i32` အတွက် fit လွန်းကြီးတွေဖြစ်ပါတယ်အမှားတစ်ခုကြောင့် Returns ။
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // `Ok(3)` သို့ပြန်သွားသည်
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// အမျိုးအစားပြောင်းလဲခြင်းအမှား၏ဖြစ်ရပ်အတွက်ပြန်လာ၏။
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// ပြောင်းလဲခြင်းလုပ်ဆောင်တယ်။
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// General IMPLS
////////////////////////////////////////////////////////////////////////////////

// ရုတ်သိမ်းပေးရန်အဖြစ်&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// &mut ကျော်ဓာတ်လှေကားအဖြစ်
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742) အောက်ပါပိုပြီးယေဘုယျတဦးတည်းနှင့်အတူ&/&mut များအတွက်အထက်တွင် impls အစားထိုးရန်:
// // Deref ကျော်ဓာတ်လှေကားအဖြစ်
// ဆိုလိုသည်မှာ <D: ?Sized + Deref<Target: AsRef<U>?>, ဦး: <U>-> &U {as_ref(&self) Fn: D {များအတွက်</u> SIZE> AsRef
//
//         self.deref().as_ref()
//     }
// }

// &mut ကျော် LIFT AsMut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742) အောက်ပါပိုပြီးယေဘုယျတဦးတည်းနှင့်အတူ &mut များအတွက်အထက်တွင် impl အစားထိုးရန်:
// // DerefMut ကျော် LIFT AsMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, ဦး: <U>D</u> အရွယ်အစား> အရွယ်အစား> AsMut <U>{fn as_mut(&mut self)-> &mut ဦး {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// ကနေစဆိုလို
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// ကနေ (နှင့်အရှင်ထဲသို့) reflex ဖြစ်ပါသည်
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **တည်ငြိမ်ရေးမှတ်စု:** ဒီ impl သေးမတည်ရှိပါဘူး, ဒါပေမယ့်ကျွန်တော် "reserving space" အဆိုပါ future ထဲမှာထည့်သွင်းဖို့ရှိပါတယ်။
/// အသေးစိတ်ကို [rust-lang/rust#64715][#64715] ကိုကြည့်ပါ။
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): အစားအခြေခံပြင်ဆင်ချက်လုပ်ပါ။
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom သည် TryInto ကိုဆိုလိုသည်
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// မှားယှငျးနိုငျဘာသာပြောင်းထားတဲ့လူနေထိုင်မှုမရှိအမှားအမျိုးအစားနှင့်အတူ fallible စကားဝိုင်းများဝေါဟာရအသုံးအနှုံးနှင့်ညီမျှကြသည်။
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// ကွန်ကရစ် IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// no-အမှားအမှား TYPE
////////////////////////////////////////////////////////////////////////////////

/// ဘယ်တော့မှမဖြစ်နိုင်သည့်အမှားများအတွက်အမှားအမျိုးအစား။
///
/// ဤ enum ၌မူကွဲမရှိပါ၊ ဤအမျိုးအစား၏တန်ဖိုးသည်ဘယ်တော့မျှအမှန်တကယ်တည်ရှိနိုင်မည်မဟုတ်ပါ။
/// ဤသည်သည် [`Result`] ကို သုံး၍ အမှားအမျိုးအစားကိုတိုင်းတာသောယေဘူယျ APIs များအတွက်ရလဒ်ဖြစ်နိုင်ပြီးရလဒ်မှာအမြဲတမ်း [`Ok`] ဖြစ်သည်။
///
/// ဥပမာအားဖြင့်၊ [`TryFrom`] trait ([`Result`] ကိုပြန်ပေးသောပြောင်းလဲခြင်း) သည် [`Into`] အကောင်အထည်ဖော်မှုတည်ရှိရာအမျိုးအစားအားလုံးအတွက်လုံးလုံးလျားလျားအကောင်အထည်ဖော်မှုရှိသည်။
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future compatibility
///
/// ဤ enum သည် Rust ၏မူကွဲတွင်တည်ငြိမ်သော [the `!`“never”type][never] နှင့်အတူတူပင်ဖြစ်သည်။
/// `!` တည်ငြိမ်သောအခါ, ငါတို့ `Infallible` ကအမျိုးအစား alias ကိုအောင်စီစဉ်:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... နှင့်နောက်ဆုံးတွင် `Infallible` ကန့်ကွက်။
///
/// တစ်ဦး function ကိုရဲ့ပြန်လာအမျိုးအစားများ၏အနေအထား: သို့သော်လည်း `!` full-စုံတဲ့အမျိုးအစားအဖြစ်တည်ငြိမ်မီ `!` syntax ကိုအသုံးပြုနိုင်ပါတယ်ရှိရာတစျခုအမှုလည်းမရှိ။
/// အထူးသဖြင့်၎င်းသည်ကွဲပြားခြားနားသော function pointer အမျိုးအစားနှစ်ခုအတွက်ဖြစ်နိုင်ချေရှိသောအကောင်အထည်ဖော်မှုဖြစ်သည်။
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// `Infallible` သည် enum တစ်ခုဖြစ်သောကြောင့်ဤကုဒ်သည်မှန်ကန်သည်။
/// သို့သော် `Infallible` သည် never type အတွက် alias တစ်ခုဖြစ်လာသည့်အခါ `impl`s နှစ်ခုသည်ထပ်နေလိမ့်မည်၊ ထို့ကြောင့် trait ကွက်တိဝင်စည်းမျဉ်းစည်းကမ်းများအားပိတ်ပင်လိမ့်မည်။
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}