//! `f32` single-precision floating point အမျိုးအစားနှင့်သက်ဆိုင်သောစဉ်ဆက်မပြတ်။
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! သင်္ချာသိသာထင်ရှားသောနံပါတ်များကို `consts` sub-module တွင်ဖော်ပြထားသည်။
//!
//! ဒီ module (တိုက်ရိုက် `consts` sub-module ကိုအတွက်သတ်မှတ်ထားသောအနေဖြင့်ကွဲပြားကဲ့သို့) အတွက်တိုက်ရိုက်သတ်မှတ်ထားသောကိန်းဂဏန်းများအတွက်, ကုဒ်အသစ်အစား `f32` type ကိုအပေါ်တိုက်ရိုက်သတ်မှတ်ဆက်စပ်ဆက်စပ်ရုံကလွဲပြီးအသုံးပြုသင့်ပါတယ်။
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// `f32` ၏အတွင်းပိုင်းကိုယ်စားပြုမှု၏ radix သို့မဟုတ် base ။
/// အစား [`f32::RADIX`] ကိုသုံးပါ။
///
/// # Examples
///
/// ```rust
/// // ကန့်ကွက်ခံထားလမ်း
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // ရည်ရွယ်လမ်း
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// အခြေစိုက်စခန်း 2 အတွက်သိသာထင်ရှားသောဂဏန်းအရေအတွက်။
/// အစား [`f32::MANTISSA_DIGITS`] ကိုသုံးပါ။
///
/// # Examples
///
/// ```rust
/// // ကန့်ကွက်ခံထားလမ်း
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // ရည်ရွယ်လမ်း
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// အခြေစိုက်စခန်း 10 အတွက်သိသာထင်ရှားသောဂဏန်း၏ခန့်မှန်းအရေအတွက်။
/// အစား [`f32::DIGITS`] ကိုသုံးပါ။
///
/// # Examples
///
/// ```rust
/// // ကန့်ကွက်ခံထားလမ်း
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // ရည်ရွယ်လမ်း
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] `f32` များအတွက်တန်ဖိုး။
/// အစား [`f32::EPSILON`] ကိုသုံးပါ။
///
/// ဤသည် `1.0` နှင့်လာမည့်ပိုကြီးတဲ့ကိုယ်စားပြုနံပါတ်အကြားခြားနားချက်ဖြစ်ပါတယ်။
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // ကန့်ကွက်ခံထားလမ်း
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // ရည်ရွယ်လမ်း
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// အသေးငယ်ဆုံးကနျ့ `f32` တန်ဖိုး။
/// အစား [`f32::MIN`] ကိုသုံးပါ။
///
/// # Examples
///
/// ```rust
/// // ကန့်ကွက်ခံထားလမ်း
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // ရည်ရွယ်လမ်း
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// အသေးငယ်ဆုံးအပြုသဘောဆောင်တဲ့ပုံမှန် `f32` တန်ဖိုး။
/// အစား [`f32::MIN_POSITIVE`] ကိုသုံးပါ။
///
/// # Examples
///
/// ```rust
/// // ကန့်ကွက်ခံထားလမ်း
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // ရည်ရွယ်လမ်း
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// အကြီးမားဆုံးကနျ့ `f32` တန်ဖိုး။
/// အစား [`f32::MAX`] ကိုသုံးပါ။
///
/// # Examples
///
/// ```rust
/// // ကန့်ကွက်ခံထားလမ်း
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // ရည်ရွယ်လမ်း
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// 2 ထပ်ကိန်း၏နိမ့်ဆုံးဖြစ်နိုင်သောသာမန်စွမ်းအားထက်သာလွန်သည်။
/// အစား [`f32::MIN_EXP`] ကိုသုံးပါ။
///
/// # Examples
///
/// ```rust
/// // ကန့်ကွက်ခံထားလမ်း
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // ရည်ရွယ်လမ်း
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// 2 ထပ်ကိန်း၏အများဆုံးဖြစ်နိုင်သောစွမ်းအား။
/// အစား [`f32::MAX_EXP`] ကိုသုံးပါ။
///
/// # Examples
///
/// ```rust
/// // ကန့်ကွက်ခံထားလမ်း
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // ရည်ရွယ်လမ်း
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// 10 ထပ်ကိန်း၏အနည်းဆုံးဖြစ်နိုင်သမျှပုံမှန်စွမ်းအင်။
/// အစား [`f32::MIN_10_EXP`] ကိုသုံးပါ။
///
/// # Examples
///
/// ```rust
/// // ကန့်ကွက်ခံထားလမ်း
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // ရည်ရွယ်လမ်း
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// 10 ထပ်ကိန်း၏အများဆုံးဖြစ်နိုင်သမျှပါဝါ။
/// အစား [`f32::MAX_10_EXP`] ကိုသုံးပါ။
///
/// # Examples
///
/// ```rust
/// // ကန့်ကွက်ခံထားလမ်း
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // ရည်ရွယ်လမ်း
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// နံပါတ် (NaN) မဟုတ်ပါ
/// အစား [`f32::NAN`] ကိုသုံးပါ။
///
/// # Examples
///
/// ```rust
/// // ကန့်ကွက်ခံထားလမ်း
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // ရည်ရွယ်လမ်း
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// Infinity (∞) ။
/// အစား [`f32::INFINITY`] ကိုသုံးပါ။
///
/// # Examples
///
/// ```rust
/// // ကန့်ကွက်ခံထားလမ်း
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // ရည်ရွယ်လမ်း
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// အနုတ်လက္ခဏာအသင်္ချေ (−∞) ။
/// အစား [`f32::NEG_INFINITY`] ကိုသုံးပါ။
///
/// # Examples
///
/// ```rust
/// // ကန့်ကွက်ခံထားလမ်း
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // ရည်ရွယ်လမ်း
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// အခြေခံသင်္ချာကိန်းသေ။
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: cmath ထံမှသင်္ချာရုံကလွဲပြီးနှင့်အတူအစားထိုးလိုက်ပါ။

    /// Archimedes '' စဉ်ဆက်မပြတ် (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// အပြည့်အဝစက်ဝိုင်းစဉ်ဆက်မပြတ် (τ)
    ///
    /// 2πနှင့်ညီသည်။
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// Euler ၏နံပါတ် (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// `f32` ၏အတွင်းပိုင်းကိုယ်စားပြုမှု၏ radix သို့မဟုတ် base ။
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// အခြေစိုက်စခန်း 2 အတွက်သိသာထင်ရှားသောဂဏန်းအရေအတွက်။
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// အခြေစိုက်စခန်း 10 အတွက်သိသာထင်ရှားသောဂဏန်း၏ခန့်မှန်းအရေအတွက်။
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] `f32` များအတွက်တန်ဖိုး။
    ///
    /// ဤသည် `1.0` နှင့်လာမည့်ပိုကြီးတဲ့ကိုယ်စားပြုနံပါတ်အကြားခြားနားချက်ဖြစ်ပါတယ်။
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// အသေးငယ်ဆုံးကနျ့ `f32` တန်ဖိုး။
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// အသေးငယ်ဆုံးအပြုသဘောဆောင်တဲ့ပုံမှန် `f32` တန်ဖိုး။
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// အကြီးမားဆုံးကနျ့ `f32` တန်ဖိုး။
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// 2 ထပ်ကိန်း၏နိမ့်ဆုံးဖြစ်နိုင်သောသာမန်စွမ်းအားထက်သာလွန်သည်။
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// 2 ထပ်ကိန်း၏အများဆုံးဖြစ်နိုင်သောစွမ်းအား။
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// 10 ထပ်ကိန်း၏အနည်းဆုံးဖြစ်နိုင်သမျှပုံမှန်စွမ်းအင်။
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// 10 ထပ်ကိန်း၏အများဆုံးဖြစ်နိုင်သမျှပါဝါ။
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// နံပါတ် (NaN) မဟုတ်ပါ
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// Infinity (∞) ။
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// အနုတ်လက္ခဏာအသင်္ချေ (−∞) ။
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// ဒီတန်ဖိုးကို `NaN` လျှင် `true` ပြန်သွားသည်။
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): သယ်ဆောင်ရလွယ်ကူမှုနှင့်ပတ်သက်သောစိုးရိမ်မှုများကြောင့် `abs` ကို libcore တွင်လူသိရှင်ကြားမတွေ့နိုင်ပါ၊ ထို့ကြောင့်ဤအကောင်အထည်ဖော်မှုကိုပြည်တွင်း၌ကိုယ်ပိုင်အသုံးပြုရန်ဖြစ်သည်။
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// အကယ်၍ ဤတန်ဖိုးသည်အပြုသဘောအကန့်အသတ် (သို့) အနုတ်လက္ခဏာအသင်္ချေနှင့် `false` မဟုတ်လျှင် `true` သို့ပြန်သွားသည်
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// ဒီနံပါတ်ကအဆုံးမဲ့မဟုတ်သလို `NaN` မဟုတ်လျှင် `true` ကိုပြန်ပို့ပေးသည်။
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // သီးခြားစီ NaN ကိုကိုင်တွယ်ရန်မလိုအပ်ပါ။ အကယ်၍ self သည် NaN ဖြစ်ပါကနှိုင်းယှဉ်ချက်သည်လိုချင်သောအတိုင်းမမှန်ပါ။
        //
        self.abs_private() < Self::INFINITY
    }

    /// နံပါတ် [subnormal] လျှင် `true` ပြန်သွားသည်။
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // `0` နှင့် `min` အကြားတန်ဖိုးများကိုပုံမှန်မဟုတ်သောဖြစ်ကြသည်။
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// နံပါတ်သုည, အဆုံးမဲ့, [subnormal], ဒါမှမဟုတ် `NaN` မပါလျှင် `true` ပြန်သွားသည်။
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // `0` နှင့် `min` အကြားတန်ဖိုးများကိုပုံမှန်မဟုတ်သောဖြစ်ကြသည်။
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// နံပါတ်၏ floating point အမျိုးအစားကိုပြန်သွားသည်။
    /// တစ်ခုသာပိုင်ဆိုင်မှုကိုစမ်းသပ်ဖို့သွားလျှင်, ယေဘုယျအားဖြင့်အစားသတ်သတ်မှတ်မှတ် predikat ကိုအသုံးပြုရန်ပိုမိုမြန်ဆန်သည်။
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// `self` တွင် `+0.0`, `NaN`s အပေါင်းလက္ခဏာဆောင်သောလက္ခဏာနှင့်အပြုသဘောဆောင်သောအပြုအမူများအပါအ ၀ င်အပေါင်းလက္ခဏာဆောင်သောလက္ခဏာရှိလျှင် `true` ကိုပြန်ပို့သည်။
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// `self` တွင် `-0.0`, `NaN`s အနုတ်လက္ခဏာနိမိတ်လက္ခဏာနှင့်အနုတ်လက္ခဏာမပါသောအနုတ်လက္ခဏာရှိလျှင် `true` ကိုပြန်ပို့သည်။
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // IEEE754 ကဆိုသည်မှာ isSignMinus(x) သည်အနုတ်လက္ခဏာရှိမှသာလျှင်မှန်သည်။
        // isSignMinus သည်သုညနှင့် NaNs များနှင့်လည်းသက်ဆိုင်သည်။
        self.to_bits() & 0x8000_0000 != 0
    }

    /// နံပါတ်တစ်ခု၏အပြန်အလှန် (inverse) ကိုယူသည်။ `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// radians ဒီဂရီမှပြောင်းလဲ။
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // ပိုမိုကောင်းမွန်သောတိကျမှုအတွက်စဉ်ဆက်မပြတ်အသုံးပြုပါ။
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// ဒီဂရီ radians မှဒီဂရီပြောင်းလဲ။
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// နံပါတ်နှစ်ခု၏အမြင့်ဆုံးကိုပြန်ပို့ပေးသည်။
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// အကယ်၍ အငြင်းပွားမှုတစ်ခုသည် NaN ဖြစ်ပါကအခြားအငြင်းအခုံကိုပြန်ရလိမ့်မည်။
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// နံပါတ်နှစ်ခု၏အနိမ့်ဆုံးကိုပြန်ပို့သည်။
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// အကယ်၍ အငြင်းပွားမှုတစ်ခုသည် NaN ဖြစ်ပါကအခြားအငြင်းအခုံကိုပြန်ရလိမ့်မည်။
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// သုညသို့မျဉ်းဖြောင့်ရှိပြီးမည်သည့် Primitive integer type ကိုမဆိုထိုတန်ဖိုးသည်အကန့်အသတ် ရှိ၍ ၎င်းနှင့်ကိုက်ညီသည်ဟုယူဆသည်။
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// တန်ဖိုးက-
    ///
    /// * `NaN` မဟုတ်ပါဘူး
    /// * အဆုံးမဲ့မဖြစ်
    /// * ၎င်း၏ဒfractionမကိန်းအစိတ်အပိုင်းကိုပယ်ဖျက်ပြီးနောက်, ပြန်လာအမျိုးအစား `Int` အတွက်ကိုယ်စားပြု Be
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `FloatToInt::to_int_unchecked` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// `u32` မှကုန်ကြမ်း transmutation ။
    ///
    /// ၎င်းသည်လက်ရှိပလက်ဖောင်းအားလုံးပေါ်ရှိ `transmute::<f32, u32>(self)` နှင့်တူညီသည်။
    ///
    /// ဤစစ်ဆင်ရေး၏သယ်ဆောင်ရလွယ်ကူမှုနှင့် ပတ်သက်၍ ဆွေးနွေးမှုအချို့အတွက် `from_bits` ကိုကြည့်ပါ။
    ///
    /// ဒီ function က *numeric* value ကို bitwise တန်ဖိုးနဲ့မထိန်းသိမ်းနိုင်အောင်ကြိုးစားနေတဲ့ `as` casting နဲ့ကွဲပြားတာကိုသတိပြုပါ။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() မနှင်းဘူး
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // လုံခြုံမှု-`u32` သည်ရိုးရှင်းသော datatype အဟောင်းတစ်ခုဖြစ်သည်။ ထို့ကြောင့်ကျွန်ုပ်တို့သည်၎င်းကိုအမြဲတမ်းလွှဲပြောင်းပေးနိုင်သည်
        unsafe { mem::transmute(self) }
    }

    /// `u32` မှကုန်ကြမ်း transmutation ။
    ///
    /// ၎င်းသည်လက်ရှိပလက်ဖောင်းအားလုံးပေါ်ရှိ `transmute::<u32, f32>(v)` နှင့်တူညီသည်။
    /// အကြောင်းရင်းနှစ်ရပ်ကြောင့်ဒီဟာမယုံနိုင်လောက်အောင်သယ်ဆောင်ရလွယ်ကူတယ်
    ///
    /// * Floats နှင့် Ints များသည်ထောက်ပံ့ထားသောပလက်ဖောင်းအားလုံးတွင်တူညီသည်။
    /// * IEEE-754 သည် float များ၏ bit layout ကိုအလွန်တိကျစွာဖော်ပြသည်။
    ///
    /// သို့သော်လည်းသတိပေးချက်တစ်ခုရှိသည်။ ၂၀၀၈ IEEE-754 ဗားရှင်းမတိုင်မီတွင် NaN အချက်ပြနည်းကိုမည်သို့အနက်ဖွင့်ရမည်ကိုအမှန်တကယ်မသတ်မှတ်ထားပါ။
    /// ပလက်ဖောင်းအများစု (အထူးသဖြင့် x86 နှင့် ARM) သည် ၂၀၀၈ ခုနှစ်တွင်နောက်ဆုံး၌စံသတ်မှတ်ထားသောအနက်ကိုကောက်ယူခဲ့သော်လည်းအချို့မှာမူ (အထူးသဖြင့် MIPS) ကိုအသုံးပြုခဲ့သည်။
    /// ရလဒ်အနေနှင့် MIPS ရှိအချက်ပြသည့် NaNs အားလုံးသည် x86 တွင်တိတ်ဆိတ်သော NaNs များဖြစ်ပြီးအပြန်အလှန်အားဖြင့်။
    ///
    /// ဤအချက်သည်အချက်အလတ်-အပြန်အလှန်ပလက်ဖောင်းကိုထိန်းသိမ်းရန်ကြိုးစားနေမည့်အစားဤအကောင်အထည်ဖော်မှုသည်တိကျသောပမာဏကိုထိန်းသိမ်းရန်အားပေးသည်။
    /// ဆိုလိုသည်မှာ NaNs တွင် encoded လုပ်ထားသော payloads များအားဤနည်းလမ်း၏ရလဒ်သည် x86 machine မှ MIPS တစ်ခုသို့ network သို့ပေးပို့လျှင်ပင်ထိန်းသိမ်းလိမ့်မည်ကိုဆိုလိုသည်။
    ///
    ///
    /// ဤနည်းလမ်း၏ရလဒ်များကို၎င်းတို့ကိုထုတ်လုပ်သည့်တူညီသောဗိသုကာပညာဖြင့်သာကြိုးကိုင်ခြယ်လှယ်ပါကသယ်ယူပို့ဆောင်ရေးအတွက်စိုးရိမ်စရာမရှိပါ။
    ///
    /// သွင်းအားစုသည် NaN မဟုတ်လျှင်သယ်ဆောင်ရလွယ်ကူမှုအတွက်စိုးရိမ်စရာမရှိပါ။
    ///
    /// သင်အချက်ပြမှုကိုဂရုမစိုက်လျှင် (ဖြစ်နိုင်ဖွယ်ရှိသည်) ထို့နောက်သယ်ဆောင်ရလွယ်ကူမှုအတွက်စိုးရိမ်စရာမရှိပါ။
    ///
    /// ဒီ function က *numeric* value ကို bitwise တန်ဖိုးနဲ့မထိန်းသိမ်းနိုင်အောင်ကြိုးစားနေတဲ့ `as` casting နဲ့ကွဲပြားတာကိုသတိပြုပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // လုံခြုံမှု-`u32` သည်ရိုးရှင်းသော datatype အဟောင်းတစ်ခုဖြစ်သည်။ ထို့ကြောင့်ကျွန်ုပ်တို့သည်၎င်းမှအမြဲထုတ်လွှင့်နိုင်သည်
        // ဒါဟာ sNaN နှင့်အတူလုံခြုံရေးကိစ္စများအလွန်အမင်းခဲ့ကြသည်ထွက်လှည့်!ဟရဲရေ!
        unsafe { mem::transmute(v) }
    }

    /// Big-endian (network) byte order အရဒီ floating point နံပါတ်ရဲ့ memory memory ကို byte ခင်းကျင်းမှုအဖြစ်ပြန်ပို့ပါ။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// နည်းလွန်းသော endian byte order ရှိ byte ခင်းကျင်းမှုအဖြစ်ဤ floating point number ၏ memory ကိုပြန်ပို့ပါ။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// မူလက byte အမိန့်ဖြင့်ဤ floating point နံပါတ်၏ memory ကိုယ်စားပြုမှုကို return ပြန်ပေးပါ။
    ///
    /// target platform ၏ endianness ကိုအသုံးပြုသောကြောင့်သယ်ဆောင်ရလွယ်ကူသောကုဒ်သည်အစားထိုးရန်သင့်လျော်သလို [`to_be_bytes`] သို့မဟုတ် [`to_le_bytes`] ကိုအသုံးပြုသင့်သည်။
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// မူလက byte အမိန့်ဖြင့်ဤ floating point နံပါတ်၏ memory ကိုယ်စားပြုမှုကို return ပြန်ပေးပါ။
    ///
    ///
    /// [`to_ne_bytes`] ဖြစ်နိုင်ရင်ဒီထက်ပိုပြီး ဦး စားပေးသင့်တယ်။
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // လုံခြုံမှု-`f32` သည်ရိုးရှင်းသော datatype အဟောင်းတစ်ခုဖြစ်သည်။ ထို့ကြောင့်ကျွန်ုပ်တို့သည်၎င်းကိုအမြဲတမ်းလွှဲပြောင်းပေးနိုင်သည်
        unsafe { &*(self as *const Self as *const _) }
    }

    /// ကြီးမားသော endian တွင် byte ခင်းကျင်းခြင်းအနေနှင့်၎င်းကိုယ်စားပြုခြင်းမှ floating point value တစ်ခုဖန်တီးပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// နည်းနည်း endian တွင် byte ခင်းကျင်းခြင်းအဖြစ်ကိုယ်စားပြုမှုမှ floating point တန်ဖိုးတစ်ခုကိုဖန်တီးပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// ဇာတိ endian တွင် byte array အဖြစ်ကိုယ်စားပြုမှုမှ floating point တန်ဖိုးတစ်ခုဖန်တီးပါ။
    ///
    /// target platform ၏ endianness ကိုအသုံးပြုသောကြောင့်သယ်ဆောင်ရလွယ်ကူသောကုဒ်သည်သင့်လျော်သောအစား [`from_be_bytes`] သို့မဟုတ် [`from_le_bytes`] ကိုအသုံးပြုလိုသည်။
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// ကိုယ့်ကိုယ်ကိုနှင့်အခြားတန်ဖိုးများအကြားတစ် ဦး အမိန့်ပြန်သွားသည်။
    /// floating point နံပါတ်များအကြားပုံမှန်တစ်စိတ်တစ်ပိုင်းနှိုင်းယှဉ်ချက်နှင့်မတူဘဲ IEEE 754 (2008 revision) floating point standard တွင်ဖော်ပြထားသည့်အတိုင်း totalOrder predicate နှင့်အညီအစဉ်လိုက်ထုတ်ပေးသည်။
    /// တန်ဖိုးများကိုအောက်ပါအတိုင်းစီစဉ်ထားသည်။
    /// - အနုတ်လက္ခဏာတိတ်ဆိတ် NaN
    /// - အနုတ်လက္ခဏာအချက်ပြ NaN
    /// - အနုတ်လက္ခဏာအသင်္ချေ
    /// - အနှုတ်လက္ခဏာနံပါတ်များ
    /// - အပျက်သဘောဆောင်သောပုံမှန်မဟုတ်သောနံပါတ်များ
    /// - အနုတ်သုည
    /// - အပေါင်းသုည
    /// - အပြုသဘောပုံမှန်မဟုတ်သောနံပါတ်များ
    /// - အပြုသဘောဆောင်သောနံပါတ်များ
    /// - အပြုသဘောအသင်္ချေ
    /// - အပြုသဘောအချက်ပြ NaN
    /// - အပြုသဘောတိတ်ဆိတ် NaN
    ///
    /// ဤလုပ်ဆောင်ချက်သည် [`PartialOrd`] နှင့် X0XX အကောင်အထည်ဖော်မှုများနှင့်အမြဲတမ်းသဘောမတူကြောင်းသတိပြုပါ။အထူးသဖြင့် `total_cmp` ကအနုတ်နှင့်အပေါင်းသုညကိုညီမျှသည်ဟုမှတ်ယူထားသည်။
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // ဆိုးကျိုးများရှိပါကနှစ်ခု၏ဖြည့်သွင်းကိန်းများကဲ့သို့အလားတူ layout ကိုရရှိရန်အမှတ်အသား မှလွဲ၍ bits အားလုံးကိုလှန်လိုက်ပါ
        //
        // ဒီဟာဘာကြောင့်အလုပ်လုပ်ရတာလဲIEEE 754 float များသည် fields ၃ ခုဖြင့်ပါဝင်သည်။
        // bit, exponent နှင့် mantissa တို့ကိုသင်္ကေတလုပ်ပါ။ထပ်ကိန်းနှင့် mantissa လယ်ကွင်းများ၏အစုတစ်ခုသည်၎င်းတို့၏ bitwise အစီအစဉ်သည်ပြင်းအားကိုသတ်မှတ်သောဂဏန်းပမာဏနှင့်ညီမျှသည်။
        // ပမာဏကိုပုံမှန်အားဖြင့် NaN တန်ဖိုးများတွင်သတ်မှတ်ခြင်းမရှိသော်လည်း IEEE 754 totalOrder သည် NaN တန်ဖိုးများကို bitwise order အတိုင်းလိုက်နာရန်လည်းသတ်မှတ်သည်။ဤသည် doc မှတ်ချက်၌ရှင်းပြသည်အမိန့်ကို ဦး ဆောင်လမ်းပြ။
        // သို့သော်အနုတ်လက္ခဏာနှင့်အပြုသဘောဆောင်သောဂဏန်းများအတွက်ပမာဏ၏ကိုယ်စားပြုမှုသည်အတူတူဖြစ်သည်-နိမိတ်လက္ခဏာနည်းနည်းသာကွဲပြားသည်။
        // floats များကိုလက်မှတ်ရေးထိုးထားသောကိန်းဂဏန်းများအဖြစ်အလွယ်တကူနှိုင်းယှဉ်နိုင်ရန်ကျွန်ုပ်တို့သည်အနုတ်လက္ခဏာနံပါတ်များအတွက် exponent နှင့် mantissa-bits များကိုလှန်လှောရန်လိုအပ်သည်။
        // ကျွန်ုပ်တို့သည်နံပါတ်များကို "two's complement" ပုံစံသို့ထိရောက်စွာပြောင်းလဲနိုင်သည်။
        //
        // လှန်လှောလုပ်ရန်ကျွန်ုပ်တို့သည်မျက်နှာဖုံးနှင့် XOR တစ်ခုကိုဆောက်လုပ်သည်။
        // ကျွန်ုပ်တို့သည် "all-ones except for the sign bit" mask ကိုအနှုတ်လက္ခဏာပြထားသောတန်ဖိုးများမှဖြောင့်တန်းစွာတွက်ချက်သည်။ right shifting sign-extends integer၊ ထို့ကြောင့် "fill" mask သည်နိမိတ်လက္ခဏာ bits ပါသော mask ပြီးနောက်နောက်ထပ်သုညနည်းနည်းတိုးရန် unsigned သို့ပြောင်းသည်။
        //
        // အပေါင်းလက္ခဏာဆောင်သောတန်ဖိုးများတွင် mask သည်သုညဖြစ်သည်။ ထို့ကြောင့်၎င်းသည် op-op ဖြစ်သည်။
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// တန်ဖိုးတစ်ခုကို၎င်းသည် NaN မဟုတ်လျှင်ကန့်သတ်ချက်တစ်ခုသို့ကန့်သတ်ပါ။
    ///
    /// ပြန် `max` `self` `min` ထက်လျော့နည်းပါက `self` `max` ထက် သာ. ကြီးမြတ်နှင့် `min` လျှင်။
    /// ဒီလိုမှမဟုတ်ရင်ဒီ `self` ပြန်လည်ရောက်ရှိ။
    ///
    /// ကန ဦး တန်ဖိုးအဖြစ်ကောင်းစွာ NaN ခဲ့လျှင်ဒီ function ကို NaN ပြန်လာသတိပြုပါ။
    ///
    /// # Panics
    ///
    /// X0X, `min` NaN ဖြစ်လျှင် Panics, သို့မဟုတ် `max` NaN ဖြစ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}