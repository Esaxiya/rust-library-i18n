//! စိတ်တိုင်းကျမတရားတိကျစွာနံပါတ် (bignum) အကောင်အထည်ဖော်မှု။
//!
//! ဤသည် stack မှတ်ဉာဏ်၏ကုန်ကျစရိတ်မှာအမှိုက်ပုံခွဲဝေရှောင်ရှားရန်ဒီဇိုင်းပြုလုပ်ထားသည်။
//! အသုံးအများဆုံး bignum အမျိုးအစား `Big32x40` သည် 32 × 40=1,280 bits ဖြင့်ကန့်သတ်ထားပြီး stack memory ၏ 160 bytes အများဆုံးရှိသည်။
//! ၎င်းသည်ဖြစ်နိုင်သမျှအကန့်အသတ်ရှိသော `f64` တန်ဖိုးများကိုလှည့်ပတ်သွားခြင်းအတွက်လုံလောက်သည်။
//!
//! နိယာမအားဖြင့်ကွဲပြားခြားနားသောသွင်းအားစုများအတွက် bignum type များစွာရှိနိုင်သည်။ သို့သော် code bloat ကိုရှောင်ကြဉ်ရန်ကျွန်ုပ်တို့ဤသို့မပြုလုပ်ပါ။
//!
//! Bignum တစ်ခုချင်းစီသည်အမှန်တကယ်အသုံးပြုမှုအတွက်ခြေရာခံနေဆဲဖြစ်သဖြင့်ပုံမှန်အားဖြင့်အရေးမကြီးပါ။
//!

// ဒီ module သည် dec2flt နှင့် flt2dec အတွက်သာဖြစ်ပြီး၊ coretests ကြောင့်သာအများသုံးဖြစ်သည်။
// ဒါဟာအစဉ်အမြဲတည်ငြိမ်ခံရဖို့ရည်ရွယ်သည်မဟုတ်။
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// bignums လိုအပ်သည်ဂဏန်းသင်္ချာစစ်ဆင်ရေး။
pub trait FullOps: Sized {
    /// `(carry', v')` သည် `carry' * 2^W + v' = self + other + carry` သို့ပြန်သွားသည်။ `W` သည် `Self` ရှိ bits အရေအတွက်ဖြစ်သည်။
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// `(carry', v')` သည် `carry'*2^W + v' = self* other + carry` သို့ပြန်သွားသည်။ `W` သည် `Self` ရှိ bits အရေအတွက်ဖြစ်သည်။
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// `(carry', v')` သည် X0 `carry'*2^W + v' = self* other + other2 + carry` သို့ပြန်သွားသည်။ `W` သည် `Self` ရှိ bits အရေအတွက်ဖြစ်သည်။
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// `(quo, rem)` သည် `borrow *2^W + self = quo* other + rem` နှင့် `0 <= rem < other` သို့ပြန်သွားသည်။ `W` သည် `Self` ရှိ bits အရေအတွက်ဖြစ်သည်။
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // ဒီဟာကလျှံလို့မရဘူး၊output `0` နှင့် `2 * 2^nbits - 1` အကြားဖြစ်ပါတယ်။
                    // FIXME: LLVM သည်၎င်းကို ADC သို့မဟုတ်အလားတူဖြစ်စေမည်လား။
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // ဒီဟာလျှံလို့မရဘူး၊
                    // output `0` နှင့် `2^nbits * (2^nbits - 1)` အကြားဖြစ်ပါတယ်။
                    // FIXME: LLVM သည်၎င်းကို ADC သို့မဟုတ်အလားတူဖြစ်စေမည်လား။
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // ဒီဟာလျှံလို့မရဘူး၊
                    // output `0` နှင့် `2^nbits * (2^nbits - 1)` အကြားဖြစ်ပါတယ်။
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // ဒီဟာကလျှံလို့မရဘူး၊output `0` နှင့် `other * (2^nbits - 1)` အကြားဖြစ်ပါတယ်။
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // RFC #521 ကိုကြည့်ရှုပါ။
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// ဂဏန်း 5 ကိုယ်စားပြုများ၏စွမ်းရည်၏ဇယား။အထူးသဖြင့်စွမ်းအင်ငါးခုပါသည့်အကြီးဆုံး {u8, u16, u32} တန်ဖိုးနှင့်ထပ်ညွှန်းကိန်းဖြစ်သည်။
/// `mul_pow5` တွင်အသုံးပြုသည်။
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// stack-ခွဲဝေကျပန်း-တိကျစွာ (အချို့သောန့်သတ်ချက်အထိ) ကိန်း။
        ///
        /// ၎င်းကိုသတ်မှတ်ထားသောအရွယ်အစား ("digit") အမျိုးအစားအရွယ်အစားဖြင့်ခင်းကျင်းထားသည်။
        /// ခင်းကျင်းပြသခြင်းသည်အလွန်ကြီးမားသောပမာဏမဟုတ် (ပုံမှန်အားဖြင့်တစ်ရာခန့် bytes) ရှိသော်လည်း၎င်းကိုမဆင်မခြင်ကူးယူခြင်းသည်စွမ်းဆောင်ရည်ကျဆင်းစေနိုင်သည်။
        ///
        /// ထို့ကြောင့်ဤရည်ရွယ်ချက်ရှိရှိ `Copy` မဟုတ်ပါဘူး။
        ///
        /// လျှံများမှုရှိပါက bignums panic သို့ ၀ င်ရောက်နိုင်သောစစ်ဆင်ရေးအားလုံး။
        /// ကြီးမားသောလုံလောက်သော bignum အမျိုးအစားများကိုအသုံးပြုရန်ခေါ်သူသည်တာဝန်ရှိသည်။
        pub struct $name {
            /// တစ်ခုမှာအပေါင်းအများဆုံးအသုံးပြုသည့် "digit" သို့ offset ။
            /// ဤသည်လျော့နည်းမထားဘူး, ဒါကြောင့်တွက်ချက်မှုအမိန့်သတိထားပါ။
            /// `base[size..]` သုညဖြစ်သင့်သည်။
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` `W` သည်ဂဏန်းအမျိုးအစားတွင် bits အရေအတွက်ဖြစ်သည်။
            base: [$ty; $n],
        }

        impl $name {
            /// ဂဏန်းတစ်လုံးမှ bignum ပြုလုပ်သည်။
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// b00um ကို `u64` တန်ဖိုးမှပြုလုပ်သည်။
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// အတွင်းပိုင်းဂဏန်းများကို `[a, b, c, ...]` အစရှိသည့်တန်ဖိုးတစ်ခုအဖြစ်ပြန်ပို့သည်။ ဂဏန်းတန်ဖိုးသည် `a + b *2^W + c* 2^(2W) + ...` ဖြစ်သည်၊ `W` သည်ဂဏန်းအမျိုးအစားရှိဘစ်အရေအတွက်ဖြစ်သည်။
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// bit 0 သည်အနည်းဆုံးသော `i`-th bit` ကိုပြန်သွားသည်။
            /// တနည်းအားဖြင့်အလေးချိန် `2^i` နှင့်အတူနည်းနည်း။
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// bignum သည်သုညဖြစ်ပါက `true` ကိုပြန်ပို့သည်။
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// ဒီတန်ဖိုးကိုကိုယ်စားပြုဖို့လိုအပ်တဲ့-bits ၏နံပါတ်ပြန်သွားသည်။
            /// သတိပြုရန်မှာသုညသည် 0 bits လိုအပ်သည်။
            pub fn bit_length(&self) -> usize {
                // သုညဖြစ်သောအထင်ရှားဆုံးဂဏန်းများကိုကျော်သွားပါ။
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // ဂဏန်းမရှိသောဂဏန်းများမရှိပါ။ ဆိုလိုသည်မှာကိန်းသည်သုညဖြစ်သည်။
                    return 0;
                }
                // ၎င်းကို leading_zeros() နှင့် bit shift များဖြင့်ပိုကောင်းအောင်ပြုလုပ်နိုင်သည်၊ သို့သော်၎င်းသည်လုပ်ရန်မလွယ်ကူပေ။
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// `other` ကိုသူ့ဟာသူထပ်ထည့်လိုက်ပြီး၎င်း၏ကိုယ်ပိုင်ပြောင်းနိုင်သောရည်ညွှန်းချက်ကိုပြန်လည်ပေးသည်။
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// `other` ကိုသူ့ဟာသူနုတ်ပြီး၎င်းသည်ကိုယ်ပိုင်ပြောင်းလဲနိုင်သောရည်ညွှန်းချက်ကိုပြန်လည်ပေးသည်။
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// သူ့ဟာသူသည်ဂဏန်းအရွယ် `other` ဖြင့်မြှောက်ပြီး၎င်း၏ပြောင်းလဲနိုင်သောရည်ညွှန်းချက်ကိုပြန်လည်ပေးသည်။
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// `2^bits` အားဖြင့်သူ့ဟာသူမြှောက်များနှင့်၎င်း၏ကိုယ်ပိုင်ပြောင်းလဲနိုင်သောရည်ညွှန်းပြန်လည်ရောက်ရှိ။
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // `digits * digitbits`-bits အားဖြင့်ပြောင်းကုန်ပြီ
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // `bits`-bits အားဖြင့်ပြောင်းကုန်ပြီ
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // self.base [.. digit] သည်သုည ဖြစ်၍ ပြောင်းရန်မလိုအပ်ပါ
                }

                self.size = sz;
                self
            }

            /// `5^e` အားဖြင့်သူ့ဟာသူမြှောက်များနှင့်၎င်း၏ကိုယ်ပိုင်ပြောင်းလဲနိုင်သောရည်ညွှန်းပြန်လည်ရောက်ရှိ။
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // အဲဒီမှာ 2 ^ n ပေါ်တွင် n trail ကပ်တွယ်နေသောသုညများအတိအကျရှိပြီးတစ်ခုတည်းသောသက်ဆိုင်ရာဂဏန်းအရွယ်အစားနှစ်ခုကဆက်တိုက်ပါဝါတွေဖြစ်တယ်၊ ဒါကြောင့်ဒီဇယားသည်အသင့်တော်ဆုံးအညွှန်းဖြစ်သည်။
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // ဖြစ်နိုင်သမျှကာလပတ်လုံးအကြီးမားဆုံးဂဏန်းတစ်ခုပါဝါဖြင့်မြှောက်ပါ။
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... ထို့နောက်ကျန်ရှိသောချွတ်ပြီးအောင်။
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` (`W` သည် digit type အတွက် bits အရေအတွက်) ရှိသည့်အရေအတွက်အားဖြင့်မိမိကိုယ်ကိုမြှောက်သည်။
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // အတွင်းပိုင်းလုပ်ရိုးလုပ်စဉ်။လာသောအခါ aa.len() <= bb.len() အခါအကောင်းဆုံးအလုပ်လုပ်ပါတယ်။
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// သူ့ဟာသူအားဂဏန်းအရွယ်အစား `other` ဖြင့်ခွဲခြားပြီး၎င်း၏ပြောင်းလဲနိုင်သောရည်ညွှန်းချက် *နှင့်* ကျန်ရှိသောကိုပြန်လည်ပေးသည်။
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// မိမိကိုယ်ကိုအခြား bignum ဖြင့်ခွဲပါ။ `q` ကိုလိုင်းနှင့်အတူ overwrite လုပ်ပြီးကျန်ကို `r` ဖြင့်ထပ်ပါ။
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // ထံမှယူမိုက်မဲနှေးကွေး base-2 ရှည်လျားသောဌာနခွဲ
                // https://en.wikipedia.org/wiki/Division_algorithm
                // FIXME သည်ရှည်သောဌာနခွဲအတွက်ပိုမိုကြီးမားသောအခြေစိုက်စခန်း ($ty) ကိုအသုံးပြုသည်။
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // 1 မှ q ၏နည်းနည်း `i` သတ်မှတ်မည်။
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// `Big32x40` အတွက်ဂဏန်းအမျိုးအစား။
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// ဒီတစ်ခုသာစမ်းသပ်ဘို့အသုံးပြုသည်။
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}