macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// ဒီကိန်းအမျိုးအစားကကိုယ်စားပြုနိုင်တဲ့အငယ်ဆုံးတန်ဖိုး။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// ဒီကိန်းအမျိုးအစားကကိုယ်စားပြုနိုင်တဲ့အကြီးဆုံးတန်ဖိုး။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// ဒီကိန်းအမျိုးအစားရဲ့အရွယ်အစားက bits ။
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// ပေးထားသောအခြေစိုက်စခန်းရှိ string အချပ်ကိုကိန်းဂဏန်းအဖြစ်ပြောင်းသည်။
        ///
        /// အဆိုပါ string ကိုဂဏန်းအားဖြင့်နောက်တော်သို့လိုက်တစ်ခု optional ကို `+` နိမိတ်လက္ခဏာကိုဖြစ်လိမ့်မည်ဟုမျှော်လင့်နေသည်။
        ///
        /// whitespace ကို ဦး ဆောင်ခြင်းနှင့်တွယ်ကပ်ထားခြင်းသည်အမှားတစ်ခုဖြစ်သည်။
        /// Digits များသည် `radix` ပေါ် မူတည်၍ ဤစာလုံးများ၏အစိတ်အပိုင်းတစ်ခုဖြစ်သည်။
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// `radix` 2 ကနေ 36 အထိအကွာအဝေး၌မပါလျှင်ဤ function ကို panics ။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// `self` ၏ binary ကိုယ်စားပြုမှုရှိသူအရေအတွက်ကိုပြန်ပို့သည်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// `self` ၏ binary ကိုယ်စားပြုမှုတွင်သုညအရေအတွက်ကိုပြန်ပို့သည်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// `self` ၏ binary ကိုယ်စားပြုမှုတွင် ဦး ဆောင်သောသုညအရေအတွက်ကိုပြန်ပို့သည်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// `self` ၏ binary ကိုယ်စားပြုမှုတွင်တွယ်ကပ်နေသည့်သုညများကိုပြန်ပို့သည်။
        ///
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// `self` ၏ binary ကိုယ်စားပြုမှုတွင် ဦး ဆောင်သူ ဦး ရေကိုပြန်ပို့သည်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// `self` ၏ binary ကိုယ်စားပြုမှုအတွက်တွယ်ကပ်သူမြား၏နံပါတ်ပြန်သွားသည်။
        ///
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// ဘယ်ဘက်သို့ bits များကိုသတ်မှတ်ထားသောငွေပမာဏ `n` ဖြင့်ပြောင်းသည်။ အကန့်အသတ်များကိုကိန်းပြည့်အဆုံးသို့ပြောင်းသည်။
        ///
        ///
        /// ကျေးဇူးပြု၍ သတိပြုပါကဤသည် `<<` shifting operator နှင့်တူညီသည်မဟုတ်ပါ။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// bits များကိုညာဘက်သို့သတ်မှတ်ထားသောပမာဏဖြစ်သော `n` ဖြင့်ပြောင်းသည်။ အကန့်အသတ်များကိုကိန်း၏အစသို့ပြောင်းသည်။
        ///
        ///
        /// ကျေးဇူးပြု၍ သတိပြုပါကဤသည် `>>` shifting operator နှင့်တူညီသည်မဟုတ်ပါ။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// ကိန်းစစ်ရဲ့ byte order ကိုပြောင်းပြန်လုပ်တယ်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// မီတာ= n.swap_bytes() ကြကုန်အံ့,
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// ကိန်းမှာရှိတဲ့-bits အစဉ်လိုက်ပြောင်းပြန်။
        /// အနိမ့်ဆုံးသိသာထင်ရှားသော bit သည်အရေးအပါဆုံး bit ဖြစ်လာသည်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// မီတာ= n.reverse_bits() ကြကုန်အံ့,
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// ကြီးမားသော endian မှသည် target ၏ endianness သို့ကိန်းတစ်ခုပြောင်းသည်။
        ///
        /// ကြီးမားတဲ့ endian တွင်ဤသည်ကိုမ-Op ဖြစ်ပါတယ်။
        /// နည်းနည်း endian တွင် bytes လဲလှယ်နေကြသည်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// cfg လျှင် (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } else {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// endian end ကနေ target ရဲ့ endianness သို့ integer တစ်ခုပြောင်းပေးသည်။
        ///
        /// နည်းနည်း endian တွင်ဤသည်ကိုမ-Op ဖြစ်ပါတယ်။
        /// ကြီးမားသော endian တွင် bytes များကိုလဲလှယ်သည်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// cfg လျှင် (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } else {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// ပစ်မှတ်ရဲ့ endianness ကနေ `self` ကြီးတွေ endian သို့ပြောင်းလဲ။
        ///
        /// ကြီးမားတဲ့ endian တွင်ဤသည်ကိုမ-Op ဖြစ်ပါတယ်။
        /// နည်းနည်း endian တွင် bytes လဲလှယ်နေကြသည်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// cfg လျှင် (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } အခြား { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // သို့မဟုတ်မဖြစ်?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// `self` ကို target ၏ endianness မှ endian သို့အနည်းငယ်ပြောင်းသည်။
        ///
        /// နည်းနည်း endian တွင်ဤသည်ကိုမ-Op ဖြစ်ပါတယ်။
        /// ကြီးမားသော endian တွင် bytes များကိုလဲလှယ်သည်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// cfg လျှင် (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } အခြား { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// integer ထို့အပြင် checked ။
        /// လျှံဖြစ်ပွားခဲ့သည်လျှင် `None` ပြန်လာ, `self + rhs` တွက်ချက်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ကိန်းပြည့်ဖြည့်စွက်ခြင်းကိုမစစ်ဆေးပါ။လျှံမပေါ်နိုင်ဟုယူဆပြီး `self + rhs` တွက်ချက်မှုများ။
        /// ၎င်းသည်သတ်မှတ်ထားသောအပြုအမူကိုမည်သည့်အချိန်တွင်ဖြစ်ပေါ်စေသည်
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `unchecked_add` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// ကိန်းနုတ် Checked ။
        /// လျှံဖြစ်ပွားခဲ့သည်လျှင် `None` ပြန်လာ, `self - rhs` တွက်ချက်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ကိန်းအစစ်မစစ်ပါ။လျှံမပေါ်နိုင်ဟုယူဆပြီး `self - rhs` တွက်ချက်မှုများ။
        /// ၎င်းသည်သတ်မှတ်ထားသောအပြုအမူကိုမည်သည့်အချိန်တွင်ဖြစ်ပေါ်စေသည်
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `unchecked_sub` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Check ကိန်းအတိုး။
        /// လျှံဖြစ်ပွားခဲ့သည်လျှင် `None` ပြန်လာ, `self * rhs` တွက်ချက်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ဂဏန်းတိုးခြင်းကိုမစစ်ဆေးပါနှင့်။လျှံမပေါ်နိုင်ဟုယူဆပြီး `self * rhs` တွက်ချက်မှုများ။
        /// ၎င်းသည်သတ်မှတ်ထားသောအပြုအမူကိုမည်သည့်အချိန်တွင်ဖြစ်ပေါ်စေသည်
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `unchecked_mul` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// integer ဌာနခွဲ Checked ။
        /// `rhs == 0` လျှင် `None` ပြန်လာ, `self / rhs` တွက်ချက်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // လုံခြုံမှု-div အားသုညဖြင့်စစ်ဆေးပြီးအလိုမရှိသောအမျိုးအစားများသည်အခြားမည်သည့်အရာမျှရှိသည်
                // ဌာနခွဲများအတွက်ပျက်ကွက် Modes သာ
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Euclidean ဌာနခွဲကိုစစ်ဆေး။
        /// `rhs == 0` လျှင် `None` ပြန်လာ, `self.div_euclid(rhs)` တွက်ချက်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// integer ကျန်ရှိသော checked ။
        /// `rhs == 0` လျှင် `None` ပြန်လာ, `self % rhs` တွက်ချက်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // လုံခြုံမှု-div အားသုညဖြင့်စစ်ဆေးပြီးအလိုမရှိသောအမျိုးအစားများသည်အခြားမည်သည့်အရာမျှရှိသည်
                // ဌာနခွဲများအတွက်ပျက်ကွက် Modes သာ
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Euclidean modulo ကိုစစ်ဆေးခဲ့သည်။
        /// `rhs == 0` လျှင် `None` ပြန်လာ, `self.rem_euclid(rhs)` တွက်ချက်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Checked negation ။`မိမိကိုယ်ကို==မဟုတ်လျှင် `None` ပြန်လာ, `-self` တွက်ချက်
        /// 0`.
        ///
        /// မည်သည့်အပြုသဘောကိန်းပြည့်ကိုမဆိုပယ်ဖျက်ခြင်းသည်လျတ်လိမ့်မည်ကိုသတိပြုပါ။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Check ပြောင်းကုန်ပြီဘယ်ဘက်။
        /// `rhs` သည် `self` ရှိ bits အရေအတွက်နှင့်ညီမျှသည်ဆိုပါက `self << rhs` ကိုပြန်ပေးသည်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Checked ပြောင်းကုန်ပြီညာဘက်။
        /// `rhs` သည် `self` ရှိ bits အရေအတွက်နှင့်ညီမျှသည်ဆိုပါက `self >> rhs` ကိုပြန်ပေးသည်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ထပ်ကိန်းကိုစစ်ဆေး။
        /// လျှံဖြစ်ပွားခဲ့သည်လျှင် `None` ပြန်လာ, `self.pow(exp)` တွက်ချက်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // exp!=0 ကတည်းကနောက်ဆုံး exp သည် 1 ဖြစ်ရမည်။
            // ထပ်ကိန်း၏နောက်ဆုံးအပိုင်းကိုသီးခြားစီကိုင်တွယ်ပါ၊ အဘယ့်ကြောင့်ဆိုသော်အခြေစိုက်စခန်းကိုနောက်တဖန်နှစ်ထပ်ခြင်းကမလိုအပ်သောကြောင့်မလိုအပ်သောလျှံများဖြစ်စေနိုင်သည်။
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// ကိန်းပြည့်ထပ်ထပ်ထပ်ဖြည့်ပါ။
        /// လျှို့ဝှက်နံပါတ်များကိုပြည့်လျှံနေမည့်အစား `self + rhs` ကိုတွက်ချက်သည်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// integer ကိန်းနုတ်။
        /// လျှို့ဝှက်နံပါတ်များကိုပြည့်လျှံနေမည့်အစား `self - rhs` ကိုတွက်ချက်သည်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// သုညကိန်းမြှောက်ခြင်း။
        /// လျှို့ဝှက်နံပါတ်များကိုပြည့်လျှံနေမည့်အစား `self * rhs` ကိုတွက်ချက်သည်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// သုညကိန်းထပ်ကိန်း။
        /// လျှို့ဝှက်နံပါတ်များကိုပြည့်လျှံနေမည့်အစား `self.pow(exp)` ကိုတွက်ချက်သည်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// (modular) ထို့အပြင်ထုပ်ပိုး။
        /// အမျိုးအစား၏နယ်နိမိတ်မှာလှည့်ပတ်ထုပ်, `self + rhs` တွက်ချက်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// (modular) အနုတ်ထုပ်။
        /// `self - rhs` ကိုတွက်ချက်သည်အမျိုးအစား၏နယ်နိမိတ်အတွင်းလှည့်ပတ်နေသည်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// (modular) မြှောက်ထုပ်ပိုး။
        /// အမျိုးအစား၏နယ်နိမိတ်မှာလှည့်ပတ်ထုပ်, `self * rhs` တွက်ချက်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ဤဥပမာသည် integer type များအကြားမျှဝေသည်ကိုသတိပြုပါ။
        /// ဒီမှာ `u8` ကိုဘာကြောင့်အသုံးပြုရတာလဲဆိုတာကိုရှင်းပြပေးပါတယ်။
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// (modular) ဌာနခွဲအရှေ့ဥရောပ, တောင်အာဖရိက။`self / rhs` တွက်ချက်သည်။
        /// လက်မှတ်မထိုးအမျိုးအစားများအပေါ်ထုပ်ဌာနခွဲရုံပုံမှန်ဌာနခွဲဖြစ်ပါတယ်။
        /// ထုပ်အစဉ်အဆက်ဖြစ်ပျက်နိုင်လမ်းမရှိသောရှိပါတယ်။
        /// ဤလုပ်ဆောင်ချက်သည်တည်ရှိသည်။ ထို့ကြောင့်ထုပ်ခြင်းလုပ်ငန်းများတွင်လုပ်ဆောင်မှုအားလုံးကိုမှတ်သားသည်။
        ///
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Euclidean ဌာနခွဲအရှေ့ဥရောပ, တောင်အာဖရိက။`self.div_euclid(rhs)` တွက်ချက်သည်။
        /// လက်မှတ်မထိုးအမျိုးအစားများအပေါ်ထုပ်ဌာနခွဲရုံပုံမှန်ဌာနခွဲဖြစ်ပါတယ်။
        /// ထုပ်အစဉ်အဆက်ဖြစ်ပျက်နိုင်လမ်းမရှိသောရှိပါတယ်။
        /// ဤလုပ်ဆောင်ချက်သည်တည်ရှိသည်။ ထို့ကြောင့်ထုပ်ခြင်းလုပ်ငန်းများတွင်လုပ်ဆောင်မှုအားလုံးကိုမှတ်သားသည်။
        /// အပြုသဘောဆောင်သောကိန်းများအတွက်ကွဲပြားခြင်း၏ဘုံအဓိပ္ပါယ်များအားလုံးသည်တူညီကြသောကြောင့်၎င်းသည် `self.wrapping_div(rhs)` နှင့်အတိအကျတူညီသည်။
        ///
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// ကျန်ရှိသော (modular) ထုပ်။`self % rhs` တွက်ချက်သည်။
        /// unsigned အမျိုးအစားများအပေါ်ထုပ်ကျန်ရှိသောတွက်ချက်မှုသည်သာမန်ကျန်ရှိသောတွက်ချက်မှုဖြစ်သည်။
        ///
        /// ထုပ်အစဉ်အဆက်ဖြစ်ပျက်နိုင်လမ်းမရှိသောရှိပါတယ်။
        /// ဤလုပ်ဆောင်ချက်သည်တည်ရှိသည်။ ထို့ကြောင့်ထုပ်ခြင်းလုပ်ငန်းများတွင်လုပ်ဆောင်မှုအားလုံးကိုမှတ်သားသည်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Euclidean modulo ထုပ်ပိုး။`self.rem_euclid(rhs)` တွက်ချက်သည်။
        /// unsigned အမျိုးအစားများအပေါ်ထုပ် modulo တွက်ချက်မှုရုံပုံမှန်ကျန်ရှိသောတွက်ချက်မှုဖြစ်ပါတယ်။
        /// ထုပ်အစဉ်အဆက်ဖြစ်ပျက်နိုင်လမ်းမရှိသောရှိပါတယ်။
        /// ဤလုပ်ဆောင်ချက်သည်တည်ရှိသည်။ ထို့ကြောင့်ထုပ်ခြင်းလုပ်ငန်းများတွင်လုပ်ဆောင်မှုအားလုံးကိုမှတ်သားသည်။
        /// အပြုသဘောဆောင်သောကိန်းများအတွက်ကွဲပြားခြင်း၏ဘုံအဓိပ္ပါယ်များအားလုံးသည်တူညီကြသောကြောင့်၎င်းသည် `self.wrapping_rem(rhs)` နှင့်အတိအကျတူညီသည်။
        ///
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// (modular) negation အရှေ့ဥရောပ, တောင်အာဖရိက။
        /// အမျိုးအစား၏နယ်နိမိတ်မှာလှည့်ပတ်ထုပ်, `-self` တွက်ချက်။
        ///
        /// unsigned အမျိုးအစားများသည်အနုတ်လက္ခဏာနှင့်မတူသောကြောင့်ဤ function ၏ applications များအားလုံးသည် `-0` မှအပခြုံပါလိမ့်မည်။
        /// သက်ဆိုင်ရာလက်မှတ်ထိုးထားသောအမျိုးအစား၏အများဆုံးထက်သေးငယ်သောတန်ဖိုးများအတွက်ရလဒ်သည်သက်ဆိုင်ရာလက်မှတ်ထိုးထားသောတန်ဖိုးကိုသတ်မှတ်ခြင်းနှင့်အတူတူပင်ဖြစ်သည်။
        ///
        /// မည်သည့်ပိုကြီးသောတန်ဖိုးများမဆို `MAX` သည်သက်ဆိုင်ရာလက်မှတ်ထိုးထားသောအမျိုးအစား၏အများဆုံးဖြစ်သော `MAX + 1 - (val - MAX - 1)` နှင့်ညီမျှသည်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ဤဥပမာသည် integer type များအကြားမျှဝေသည်ကိုသတိပြုပါ။
        /// ဒီမှာ `i8` ကိုဘာကြောင့်အသုံးပြုရတာလဲဆိုတာကိုရှင်းပြပေးပါတယ်။
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-free bitwise shift-left;
        /// `mask` သည် `self << mask(rhs)` ကို ၀ င်ပါသည်။ ၎င်းသည် `rhs` ၏မည်သည့်မြင့်မားသောအမိန့်ကိုမဆို bits များကိုဖယ်ရှားပေးပြီး၎င်းသည် shift သည် type ၏ bitwidth ထက်ကျော်လွန်စေနိုင်သည်။
        ///
        /// ; ဒီ * * တစ်-left လှည့်အတိုင်းမပေးကြောင်းမှတ်ချက်အလှည့်လက်ဝဲဘက်ရှိ RHS ၏ RHS သည်အခြားအဆုံးသို့ LHS မှထွက်သွားသော bit များထက်အမျိုးအစားအတိုင်းအတာကိုသာကန့်သတ်ထားသည်။
        /// Primitive integer type အားလုံးသည် [`rotate_left`](Self::rotate_left) function ကိုအကောင်အထည်ဖော်သည်။ ၎င်းသည်သင်အစားသင်လိုချင်သောအရာဖြစ်နိုင်သည်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // လုံခြုံမှု-အမျိုးအစား၏အရွယ်အစားအားဖြင့်ဖုံးအုပ်ထားခြင်းကကျွန်ုပ်တို့ကိုမရွှေ့နိုင်အောင်သေချာစေသည်
            // အပြင်ကထွက်
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-အခမဲ့ bitwise shift-right;
        /// `mask` သည် `self >> mask(rhs)` ကို ၀ င်ပါသည်။ ၎င်းသည် `rhs` ၏မည်သည့်မြင့်မားသောအမိန့်ကိုမဆို bits များကိုဖယ်ရှားပေးပြီး၎င်းသည် shift သည် type ၏ bitwidth ထက်ကျော်လွန်စေနိုင်သည်။
        ///
        /// သတိပြုရန်မှာ၎င်းသည် * လှည့်-ညာကဲ့သို့တူညီမှုမရှိကြောင်းသတိပြုပါ။အလှည့်အပြောင်းတွင်ရှိသော RHS ၏ RHS သည်အခြားအဆုံးသို့ LHS မှထွက်သွားသော bit များထက်အမျိုးအစားအတိုင်းအတာကိုသာကန့်သတ်ထားသည်။
        /// Primitive integer type အားလုံးသည် [`rotate_right`](Self::rotate_right) function ကိုအကောင်အထည်ဖော်သည်။ ၎င်းသည်သင်အစားသင်လိုချင်သောအရာဖြစ်နိုင်သည်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // လုံခြုံမှု-အမျိုးအစား၏အရွယ်အစားအားဖြင့်ဖုံးအုပ်ထားခြင်းကကျွန်ုပ်တို့ကိုမရွှေ့နိုင်အောင်သေချာစေသည်
            // အပြင်ကထွက်
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// (modular) အဆထုပ်ပိုး။
        /// အမျိုးအစား၏နယ်နိမိတ်မှာလှည့်ပတ်ထုပ်, `self.pow(exp)` တွက်ချက်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // exp!=0 ကတည်းကနောက်ဆုံး exp သည် 1 ဖြစ်ရမည်။
            // ထပ်ကိန်း၏နောက်ဆုံးအပိုင်းကိုသီးခြားစီကိုင်တွယ်ပါ၊ အဘယ့်ကြောင့်ဆိုသော်အခြေစိုက်စခန်းကိုနောက်တဖန်နှစ်ထပ်ခြင်းကမလိုအပ်သောကြောင့်မလိုအပ်သောလျှံများဖြစ်စေနိုင်သည်။
            //
            //
            acc.wrapping_mul(base)
        }

        /// `self` + `rhs` တွက်ချက်သည်
        ///
        /// ဂဏန်းသင်္ချာပိုလျှံမှုဖြစ်ပေါ်လိမ့်မည်လားဆိုသည်ကိုညွှန်ပြသည့် boolean နှင့်အတူထပ်ပေါင်းထည့်မှုကို tuple သို့ပြန်သွားသည်။
        /// အကယ်၍ လျှံများပိုမိုများပြားလာပါကထုပ်ထားသောတန်ဖိုးကိုပြန်ပေးသည်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self`, `rhs` တွက်ချက်သည်
        ///
        /// ဂဏန်းသင်္ချာပိုလျှံမှုပေါ်ပေါက်မလားဆိုတာကို boolean နဲ့အနုတ်တစ် tuple ကိုပြန်ပို့ပေးတယ်။
        /// အကယ်၍ လျှံများပိုမိုများပြားလာပါကထုပ်ထားသောတန်ဖိုးကိုပြန်ပေးသည်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` နှင့် `rhs` ၏မြှောက်တွက်ချက်။
        ///
        /// ဂဏန်းသင်္ချာပိုလျှံမှုရှိမရှိကိုညွှန်းသော boolean နှင့်အတူမြှောက်ခြင်းအစုတစ်ခုကိုပြန်ပို့သည်။
        /// အကယ်၍ လျှံများပိုမိုများပြားလာပါကထုပ်ထားသောတန်ဖိုးကိုပြန်ပေးသည်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ဤဥပမာသည် integer type များအကြားမျှဝေသည်ကိုသတိပြုပါ။
        /// ဒီမှာ `u32` ကိုဘာကြောင့်အသုံးပြုရတာလဲဆိုတာကိုရှင်းပြပေးပါတယ်။
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` `rhs` အားဖြင့်ပိုင်းခြားသောအခါ divisor တွက်ချက်သည်။
        ///
        /// တစ် ဦး ဂဏန်းသင်္ချာ Overflow ပေါ်ပေါက်လိမ့်မယ်ရှိမရှိညွှန်ပြ Boolean နှင့်အတူ divisor တစ် tuple ပြန်သွားသည်။
        /// သတိပြုရန်မှာ unsigned integer များသည် overflow မဖြစ်သဖြင့်ဒုတိယတန်ဖိုးသည် `false` ဖြစ်သည်။
        ///
        /// # Panics
        ///
        /// `rhs` သည် 0 ဖြစ်ပါကဤလုပ်ဆောင်မှုသည် panic ဖြစ်သည်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Euclidean ဌာနခွဲ `self.div_euclid(rhs)` ၏တွက်ချက်မှုကိုတွက်ချက်သည်။
        ///
        /// တစ် ဦး ဂဏန်းသင်္ချာ Overflow ပေါ်ပေါက်လိမ့်မယ်ရှိမရှိညွှန်ပြ Boolean နှင့်အတူ divisor တစ် tuple ပြန်သွားသည်။
        /// သတိပြုရန်မှာ unsigned integer များသည် overflow မဖြစ်သဖြင့်ဒုတိယတန်ဖိုးသည် `false` ဖြစ်သည်။
        /// အပြုသဘောဆောင်သောကိန်းများအတွက်ကွဲပြားခြင်း၏ဘုံအဓိပ္ပါယ်များအားလုံးသည်တူညီကြသောကြောင့်၎င်းသည် `self.overflowing_div(rhs)` နှင့်အတိအကျတူညီသည်။
        ///
        ///
        /// # Panics
        ///
        /// `rhs` သည် 0 ဖြစ်ပါကဤလုပ်ဆောင်မှုသည် panic ဖြစ်သည်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// `self` ကို `rhs` ဖြင့်ခွဲသောအခါကျန်ရှိသောတွက်ချက်မှုများ။
        ///
        /// ဂဏန်းသင်္ချာပိုလျှံမှုဖြစ်ပေါ်လိမ့်မည်လားဆိုသည်ကိုညွှန်ပြသည့် boolean နှင့်အတူခွဲဝေပြီးနောက်ကျန်ရှိနေသေးသော tuple တစ်ခုသို့ပြန်သွားသည်။
        /// သတိပြုရန်မှာ unsigned integer များသည် overflow မဖြစ်သဖြင့်ဒုတိယတန်ဖိုးသည် `false` ဖြစ်သည်။
        ///
        /// # Panics
        ///
        /// `rhs` သည် 0 ဖြစ်ပါကဤလုပ်ဆောင်မှုသည် panic ဖြစ်သည်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// ကျန်ရှိသော `self.rem_euclid(rhs)` ကို Euclidean division မှတွက်ချက်သည်။
        ///
        /// ဂဏန်းသင်္ချာပိုလျှံမှုဖြစ်ပေါ်လိမ့်မည်လားဆိုသည်ကိုညွှန်ပြသည့် boolean နှင့်အတူခွဲထုတ်ပြီးနောက် modulo ၏ tuple တစ်ခုသို့ပြန်သွားသည်။
        /// သတိပြုရန်မှာ unsigned integer များသည် overflow မဖြစ်သဖြင့်ဒုတိယတန်ဖိုးသည် `false` ဖြစ်သည်။
        /// အပြုသဘောဆောင်သောကိန်းများအတွက်ကွဲပြားခြင်း၏ဘုံအဓိပ္ပာယ်ဖွင့်ဆိုချက်များသည်တူညီသောကြောင့်ဤလုပ်ဆောင်မှုသည် `self.overflowing_rem(rhs)` နှင့်အတိအကျတူညီသည်။
        ///
        ///
        /// # Panics
        ///
        /// `rhs` သည် 0 ဖြစ်ပါကဤလုပ်ဆောင်မှုသည် panic ဖြစ်သည်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// တစ် ဦး လျှံဖက်ရှင်အတွက်ကိုယ့်ကိုယ်ကို Negates ။
        ///
        /// ဒီ unsigned value ကို၏ negation ကိုကိုယ်စားပြုသောတန်ဖိုးကိုပြန်လာရန်ထုပ်စစ်ဆင်ရေးကိုအသုံးပြု။ `!self + 1` ပြန်သွားသည်။
        /// အပြုသဘောမရသောတန်ဖိုးများအတွက် overflow သည်အမြဲတမ်းဖြစ်လေ့ရှိသော်လည်း 0 ကို negating သည် overflow မဖြစ်ခြင်းကိုသတိပြုပါ။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// `rhs`-bits မှကျန်ရှိသောမိမိကိုယ်ကိုပြောင်းနိုင်သည်။
        ///
        /// ပြောင်းလဲမှုတန်ဖိုးသည် bits အရေအတွက်ထက်ကြီးသည် (သို့) ညီမျှမှုရှိ/မရှိကိုညွှန်ပြသည့် boolean တစ်ခုနှင့်အတူမိမိကိုယ်ကို၏ shift version ၏ tuple တစ်ခုသို့ပြန်သွားသည်။
        /// အကယ်၍ shift value သည်အလွန်ကြီးလွန်းပါကတန်ဖိုးသည် (N-1) ဖြစ်သည်။ N သည် bits အရေအတွက်ဖြစ်သည်။ ထို့နောက်၎င်းတန်ဖိုးကို shift ကိုလုပ်ဆောင်ရန်အသုံးပြုသည်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// မိမိကိုယ်ကို `rhs`-bits ဖြင့်လက်ျာဘက်ရွှေ့နိုင်သည်။
        ///
        /// ပြောင်းလဲမှုတန်ဖိုးသည် bits အရေအတွက်ထက်ကြီးသည် (သို့) ညီမျှမှုရှိ/မရှိကိုညွှန်ပြသည့် boolean တစ်ခုနှင့်အတူမိမိကိုယ်ကို၏ shift version ၏ tuple တစ်ခုသို့ပြန်သွားသည်။
        /// အကယ်၍ shift value သည်အလွန်ကြီးလွန်းပါကတန်ဖိုးသည် (N-1) ဖြစ်သည်။ N သည် bits အရေအတွက်ဖြစ်သည်။ ထို့နောက်၎င်းတန်ဖိုးကို shift ကိုလုပ်ဆောင်ရန်အသုံးပြုသည်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// `exp` ၏စွမ်းအားကိုမိမိကိုယ်ကိုမြှင့်တင်ခြင်း၊
        ///
        /// ထပ်ကိန်းဖြစ်ပျက်မှုရှိမရှိကိုညွှန်ပြသည့် bool နှင့်ထပ်ကဖော်ပြသည့် tuple တစ်ခုသို့ပြန်သွားသည်။
        ///
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, စစ်မှန်တဲ့));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // overflowing_mul ၏ရလဒ်များကိုသိမ်းဆည်းရန်နေရာလွတ်ခြစ်ပါ။
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // exp!=0 ကတည်းကနောက်ဆုံး exp သည် 1 ဖြစ်ရမည်။
            // ထပ်ကိန်း၏နောက်ဆုံးအပိုင်းကိုသီးခြားစီကိုင်တွယ်ပါ၊ အဘယ့်ကြောင့်ဆိုသော်အခြေစိုက်စခန်းကိုနောက်တဖန်နှစ်ထပ်ခြင်းကမလိုအပ်သောကြောင့်မလိုအပ်သောလျှံများဖြစ်စေနိုင်သည်။
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// `exp` ၏စွမ်းအားကိုမိမိကိုယ်ကိုမြှင့်တင်ခြင်း၊
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // exp!=0 ကတည်းကနောက်ဆုံး exp သည် 1 ဖြစ်ရမည်။
            // ထပ်ကိန်း၏နောက်ဆုံးအပိုင်းကိုသီးခြားစီကိုင်တွယ်ပါ၊ အဘယ့်ကြောင့်ဆိုသော်အခြေစိုက်စခန်းကိုနောက်တဖန်နှစ်ထပ်ခြင်းကမလိုအပ်သောကြောင့်မလိုအပ်သောလျှံများဖြစ်စေနိုင်သည်။
            //
            //
            acc * base
        }

        /// Euclidean ဌာနခွဲလုပ်ဆောင်တယ်။
        ///
        /// အပြုသဘောဆောင်သောကိန်းများအတွက်ကွဲပြားခြင်း၏ဘုံအဓိပ္ပါယ်များအားလုံးသည်တူညီကြသောကြောင့်၎င်းသည် `self / rhs` နှင့်အတိအကျတူညီသည်။
        ///
        ///
        /// # Panics
        ///
        /// `rhs` သည် 0 ဖြစ်ပါကဤလုပ်ဆောင်မှုသည် panic ဖြစ်သည်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// ကျန်ရှိသော `self (mod rhs)` ၏အနည်းဆုံးတွက်ချက်သည်
        ///
        /// အပြုသဘောဆောင်သောကိန်းများအတွက်ကွဲပြားခြင်း၏ဘုံအဓိပ္ပါယ်များအားလုံးသည်တူညီကြသောကြောင့်၎င်းသည် `self % rhs` နှင့်အတိအကျတူညီသည်။
        ///
        ///
        /// # Panics
        ///
        /// `rhs` သည် 0 ဖြစ်ပါကဤလုပ်ဆောင်မှုသည် panic ဖြစ်သည်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// X0 `self == 2^k` အချို့ `k` အတွက်သာလျှင် `true` ကိုပြန်ပေးသည်။
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // နှစ်ခုရဲ့နောက်စွမ်းအားတစ်ခုထက်နည်းနည်းပြန်သွားသည်။
        // (8u8 အတွက်နောက်ထပ်စွမ်းအင်သည် 8u8 နှင့် 6u8 အတွက် 8u8 ဖြစ်သည်)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // ဤနည်းလမ်းသည်အလွန်လျှံသည်မဟုတ်၊ `next_power_of_two` လျှံမှုကိစ္စများတွင်ကဲ့သို့အများဆုံးအမြင့်ဆုံးတန်ဖိုးကိုပြန်ပေးသည်။
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // လုံခြုံမှု-`p > 0` သည် ဦး ဆောင်သောသုညများလုံးဝမပါဝင်နိုင်သောကြောင့်ဖြစ်သည်။
            // ဆိုလိုသည်မှာ၎င်းအပြောင်းအလဲသည်အမြဲတမ်းအကန့်အသတ်ရှိသည်၊ ဆိုလိုသည်မှာအငြင်းပွားမှုသည်သုညမဟုတ်သည့်အခါအချို့သောပရိုဆက်ဆာများ (ဥပမာ Intel Pre-haswell) သည် ပို၍ အကျိုးရှိသော ctlz ပင်ကိုစရိုက်များရှိသည်။
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// `self` ထက်ကြီးသောသို့မဟုတ်ညီမျှသောနှစ်ခု၏အငယ်ဆုံးသောစွမ်းအင်ကိုပြန်ပို့သည်။
        ///
        /// return value overflows (ဥပမာ-`uN` type အတွက် `self > (1 << (N-1))`) သည် panics debug mode နှင့် return value ကို 0 သို့လွှတ်လိုက်မယ် (method က 0 ကို return နိုင်သည့်တစ်ခုတည်းသောအခြေအနေ) ။
        ///
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// `n` ထက်ကြီးသောသို့မဟုတ်ညီမျှသောနှစ်ခု၏အငယ်ဆုံးသောစွမ်းအင်ကိုပြန်ပို့သည်။
        /// အကယ်၍ နှစ်ခု၏နောက်စွမ်းအားသည် type ၏အများဆုံးတန်ဖိုးထက်သာပါက `None` ကိုပြန်ပို့ပါလိမ့်မည်။ သို့မဟုတ်ပါကနှစ်ခု၏ပါဝါကို `Some` တွင်ရစ်ပတ်ထားသည်။
        ///
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// `n` ထက်ကြီးသောသို့မဟုတ်ညီမျှသောနှစ်ခု၏အငယ်ဆုံးသောစွမ်းအင်ကိုပြန်ပို့သည်။
        /// အကယ်၍ နှစ်ခု၏နောက်စွမ်းအားသည် type ၏အများဆုံးတန်ဖိုးထက်ကြီးပါက return value ကို `0` သို့ပတ်ထားသည်။
        ///
        ///
        /// # Examples
        ///
        /// အခြေခံအသုံးပြုမှု-
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Big-endian (network) byte order တွင်ဤကိန်း၏ memory ကိုကိုယ်စားပြုသည်။
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// ဒီကိန်း၏ memory ကို end byian order ဖြင့် byte array အဖြစ်ပြန်ပို့ပါ။
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// ဒီကိန်း၏မှတ်ဉာဏ်ကိုယ်စားပြုမှုကို byte ခင်းကျင်းသည့်အနေဖြင့်မူလ byte အမိန့်ဖြင့်ပြန်ပို့ပါ။
        ///
        /// target platform ၏ endianness ကိုအသုံးပြုသောကြောင့်သယ်ဆောင်ရလွယ်ကူသောကုဒ်သည်အစားထိုးရန်သင့်လျော်သလို [`to_be_bytes`] သို့မဟုတ် [`to_le_bytes`] ကိုအသုံးပြုသင့်သည်။
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     cfg လျှင် (target_endian= "big"){က bytes ။
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } else {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // လုံခြုံမှု: ကိန်းဂဏန်းများသည်ကိန်းစစ်သည်များအနေဖြင့်ရိုးရှင်းသော datatypes အဟောင်းများဖြစ်သောကြောင့်ကျွန်ုပ်တို့အမြဲတမ်းလုပ်နိုင်သည်
        // သူတို့ကိုက bytes ၏ Array ကိုမှ transmute
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // လုံခြုံမှု-ကိန်းဂဏန်းများသည်ရိုးရှင်းသော datatypes အဟောင်းများဖြစ်သဖြင့်၎င်းတို့ကိုအမြဲတမ်းပြောင်းလဲနိုင်သည်
            // bytes ၏ Array ကို
            unsafe { mem::transmute(self) }
        }

        /// ဒီကိန်း၏မှတ်ဉာဏ်ကိုယ်စားပြုမှုကို byte ခင်းကျင်းသည့်အနေဖြင့်မူလ byte အမိန့်ဖြင့်ပြန်ပို့ပါ။
        ///
        ///
        /// [`to_ne_bytes`] ဖြစ်နိုင်ရင်ဒီထက်ပိုပြီး ဦး စားပေးသင့်တယ်။
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// bytes= num.as_ne_bytes();
        /// assert_eq!(
        ///     cfg လျှင် (target_endian= "big"){က bytes ။
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } else {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // လုံခြုံမှု-ကိန်းဂဏန်းများသည်ရိုးရှင်းသော datatypes အဟောင်းများဖြစ်သဖြင့်၎င်းတို့ကိုအမြဲတမ်းပြောင်းလဲနိုင်သည်
            // bytes ၏ Array ကို
            unsafe { &*(self as *const Self as *const _) }
        }

        /// ကြီးမားသော endian တွင် byte ခင်းကျင်းခြင်းအနေဖြင့်၎င်းကိုယ်စားပြုသော endian integer တန်ဖိုးကိုဖန်တီးပါ။
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto ကိုသုံးပါ။
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input ကို=ကြွင်းသောအရာ;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// နည်းနည်း endian ထဲမှာ byte ခင်းကျင်းတစ်ခုအနေနဲ့သူ့ရဲ့ endian integer value ကို create လုပ်ပါ။
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto ကိုသုံးပါ။
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input ကို=ကြွင်းသောအရာ;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// ဇာတိ endianness ရှိ byte ခင်းကျင်းခြင်းအဖြစ်မှတ်ဉာဏ်ကိုယ်စားပြုမှုမှ endian endian integer တန်ဖိုးကိုဖန်တီးပါ။
        ///
        /// target platform ၏ endianness ကိုအသုံးပြုသောကြောင့်သယ်ဆောင်ရလွယ်ကူသောကုဒ်သည်သင့်လျော်သောအစား [`from_be_bytes`] သို့မဟုတ် [`from_le_bytes`] ကိုအသုံးပြုလိုသည်။
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } else {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto ကိုသုံးပါ။
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input ကို=ကြွင်းသောအရာ;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // လုံခြုံမှု: ကိန်းဂဏန်းများသည်ကိန်းစစ်သည်များအနေဖြင့်ရိုးရှင်းသော datatypes အဟောင်းများဖြစ်သောကြောင့်ကျွန်ုပ်တို့အမြဲတမ်းလုပ်နိုင်သည်
        // သူတို့ကို transmute
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // လုံခြုံမှု-ကိန်းဂဏန်းများသည်ရိုးရှင်းသော datatypes အဟောင်းများဖြစ်သဖြင့်၎င်းတို့အားအမြဲတမ်းလွှဲပြောင်းပေးနိုင်သည်
            unsafe { mem::transmute(bytes) }
        }

        /// ကုဒ်အသစ်သည်ပိုသုံးလိုသည်
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// ဒီကိန်းအမျိုးအစားကကိုယ်စားပြုနိုင်တဲ့အသေးငယ်ဆုံးတန်ဖိုးကို return လုပ်သည်။
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// ကုဒ်အသစ်သည်ပိုသုံးလိုသည်
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// ဒီကိန်းအမျိုးအစားကကိုယ်စားပြုနိုင်သည့်အကြီးဆုံးတန်ဖိုးကိုပြန်ပို့သည်။
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}