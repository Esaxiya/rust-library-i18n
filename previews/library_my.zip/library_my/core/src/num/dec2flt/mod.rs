//! IEEE 754 binary floating point နံပါတ်များသို့ decimal string များပြောင်းလဲခြင်း။
//!
//! # ပြstatementနာကြေညာချက်
//!
//! `12.34e56` လိုဒdecimalမစာကြောင်းကိုပေးတယ်။
//! ဤသည် string ကိုအရေးပါသော (`12`), အစိတ်အပိုင်း (`34`) နှင့်ထပ်ကိန်း (`56`) အစိတ်အပိုင်းများပါဝင်သည်။အစိတ်အပိုင်းများအားလုံးသည်ရွေးချယ်နိုင်ပြီးပျောက်ဆုံးနေပါကသုညအဖြစ်အဓိပ္ပာယ်ကောက်ယူသည်။
//!
//! ကျနော်တို့ဒstringမ string ကိုအတိအကျတန်ဖိုးနှင့်အနီးဆုံးသော IEEE 754 floating point နံပါတ်ရှာပါ။
//! သိထားသည်မှာဒdecimalမကွီများစွာသည်အခြေခံနှစ်ခုတွင်အဆုံးသတ်ကိုယ်စားပြုမှုများမရှိခြင်းကြောင့်ကျွန်ုပ်တို့သည် 0.5 ယူနစ်များကိုနောက်ဆုံးနေရာ၌ (တစ်နည်းအားဖြင့်ဖြစ်နိုင်သမျှ) ကိုဝိုင်းရံထားသည်။
//! ချည်နှောင်ခြင်းများ၊ ဒdecimalမတန်ဖိုးများသည်နှစ်ဆက်တိုက် float နှစ်ခုအကြားတွင်တစ်ဝက်စီတန်ဖိုးများကိုနှစ်ဝက်မှညီမျှခြင်းနည်းဗျူဟာဖြင့်လည်းဖြေရှင်းနိုင်ပြီးဘဏ်လုပ်ငန်းရှင်၏ပတ် ၀ န်းကျင်ဟုလည်းလူသိများသည်။
//!
//! ပြောရန်မလိုပါ၊ အကောင်အထည်ဖော်ရန်ရှုပ်ထွေးမှုနှင့် CPU သံသရာအတွက်အလွန်ခက်ခဲပါသည်။
//!
//! # Implementation
//!
//! ပထမ ဦး စွာကျွန်ုပ်တို့သည်နိမိတ်လက္ခဏာများကိုလျစ်လျူရှုခဲ့သည်။သို့မဟုတ်ပါကကျွန်ုပ်တို့သည်ပြောင်းလဲခြင်းလုပ်ငန်းစဉ်အစတွင်၎င်းကိုအဆုံးသတ်ပြီးအဆုံးသတ်တွင်ပြန်လည်ဖယ်ရှားပေးသည်။
//! edge ကိစ္စများတွင်မှန်ကန်သည်။ IEEE float များသည်သုည ၀ န်းကျင်တွင် ဖြစ်၍ တစ်ခုသည်ပထမဆုံး bit ကိုလှန်လိုက်သည်။
//!
//! ထို့နောက်ကျွန်ုပ်တို့သည်ထပ်ကိန်းကိုချိန်ညှိခြင်းဖြင့်ဒpointမအမှတ်ကိုဖယ်ရှားသည်။ Conceptually၊ `12.34e56` သည် `1234e54` အဖြစ်သို့ပြောင်းလဲသွားသည်။ ၎င်းသည် `f = 1234` နှင့် integer `e = 54` နှင့်အတူဖော်ပြသည်။
//! ခွဲခြမ်းစိတ်ဖြာခြင်းအဆင့်အတန်းမှကုဒ်အားလုံးနီးပါးအား `(f, e)` ကိုယ်စားပြုမှုကိုအသုံးပြုသည်။
//!
//! ထို့နောက်စက်၏အရွယ်အစားနှင့်သေးငယ်သောပုံသေအရွယ် floating point နံပါတ်များ (ပထမ `f32`/`f64`၊ ထို့နောက် 64 bit significand, `Fp`) ပါသည့်အမျိုးအစားများကိုအသုံးပြုပြီး ပိုမို၍ ယေဘုယျနှင့်ပိုမိုစျေးကြီးသောအထူးအမှုပေါင်းများ၏ရှည်လျားသောကွင်းဆက်ကိုစမ်းသပ်သည်။
//!
//! ဤအရာအားလုံးမအောင်မြင်ပါကကျွန်ုပ်တို့သည်ကျည်ဆံကိုကိုက်ပြီး `f * 10^e` ကိုအပြည့်အဝတွက်ချက်ခြင်းနှင့်အကောင်းဆုံးခန့်မှန်းတွက်ချက်မှုကိုရှာဖွေခြင်းပါဝင်သောရိုးရိုးလေးနှင့်အလွန်နှေးကွေးသော algorithm ကိုအသုံးပြုသည်။
//!
//! အဓိကအားဖြင့်ဤ module နှင့်၎င်း၏ကလေးများသည်ဖော်ပြထားသော algorithms ကိုအကောင်အထည်ဖော်သည်။
//! "How to Read Floating Point Numbers Accurately" ဝီလျံဒီ
//! Clinger, အွန်လိုင်းရရှိနိုင်: <http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.45.4152>
//!
//! ထို့အပြင်စက္ကူတွင်အသုံးပြုသော်လည်းများစွာသောအထောက်အကူပြုလုပ်ဆောင်ချက်များကို Rust (သို့မဟုတ်အနည်းဆုံး core တွင်) တွင်မရရှိနိုင်ပါ။
//! ကျွန်ုပ်တို့၏ဗားရှင်းသည်ဖြည့်စွက်ခြင်းနှင့်မပြည့်စုံခြင်းများကိုကိုင်တွယ်ရန်နှင့်ပုံမှန်မဟုတ်သောနံပါတ်များကိုကိုင်တွယ်ရန်လိုလားမှုတို့ကြောင့်ထို့အပြင်ရှုပ်ထွေးသည်။
//! Bellerophon နှင့် Algorithm R တို့တွင်လျှံများ၊
//! သွင်းအားစုများသည်အရေးပါသောဒေသသို့မရောက်မီကျွန်ုပ်တို့ (စက္ကူအပိုင်း ၈ တွင်ဖော်ပြထားသည့်ပြုပြင်မှုများနှင့်အတူ) Algorithm M ကိုရှေးရိုးစွဲပြောင်းလိုက်သည်။
//!
//! အာရုံစိုက်ရန်လိုအပ်သည့်အခြားရှုထောင့်တစ်ခုမှာ `RawFloat`` trait ဖြစ်ပြီးလုပ်ဆောင်ချက်အားလုံးနီးပါးကို parametrized လုပ်သည်။တစ်ခုက `f64` ကိုခွဲခြမ်းစိတ်ဖြာရန်နှင့်ရလဒ်ကို `f32` သို့ချရန်လုံလောက်သည်ဟုထင်နိုင်သည်။
//! ကံမကောင်းစွာဖြင့်ဤကမ္ဘာသည်ကျွန်ုပ်တို့နေထိုင်သောကမ္ဘာမဟုတ်ပါ၊ ၎င်းသည်အခြေစိုက်စခန်းနှစ်ခု (သို့) တစ်ဝက်မှတောင်မှတစ်ဝက်မျှကိုအသုံးပြုခြင်းနှင့်လုံးဝမသက်ဆိုင်ပါ။
//!
//! ဥပမာအားဖြင့်ဒ00မဂဏန်းနှစ်လုံးနှင့်ဒdecimalမဂဏန်းလေးလုံးပါသောဒ00မအမျိုးအစားကိုကိုယ်စားပြုသော `d2` နှင့် `d4` အမျိုးအစားနှစ်မျိုးကိုသုံးသပ်။ "0.01499" ကို input အဖြစ်ယူပါ။ရဲ့အသုံးပြုမှုကိုတစ်ဝက်-up, ရှာနိုင်ပါတယ်ကြပါစို့။
//! ဒdecimalမဂဏန်းနှစ်ခုသို့တိုက်ရိုက်သွားခြင်းက `0.01` ကိုပေးသည်။ သို့သော်ကျွန်ုပ်တို့သည်ဂဏန်းလေးလုံးသို့ ဦး စွာလှည့်ပါက `0.0150` ကိုရရှိသည်။ ၎င်းသည် `0.02` အထိမြှောက်ထားသည်။
//! အကယ်၍ သင် 0.5 ULP တိကျမှုကိုသင်လိုချင်ပါက *အရာအားလုံး* အပြည့်အဝတိကျစွာနှင့်ပတ်ပတ်လည် *အဆုံးသတ်* အဆုံးသတ် * အတွက်တစ်ပြိုင်နက်တည်းအသားတင်ဘစ်အားလုံးကိုထည့်သွင်းစဉ်းစားခြင်းအားဖြင့်ပြုလုပ်ရန်လိုအပ်သည်။
//!
//! FIXME: ကုဒ်နံပါတ်မိတ္တူပွားရန်လိုအပ်သော်လည်းကုဒ်၏အစိတ်အပိုင်းများကိုမူ ထပ်မံ၍ ကူးယူခြင်းမပြုနိုင်ပါ။
//! Algorithms ၏ကြီးမားသောအစိတ်အပိုင်းများသည် float type နှင့်မသက်ဆိုင်ဘဲ parameter များအနေနှင့်လည်းအသုံးပြုနိုင်သည်။
//!
//! # Other
//!
//! ပြောင်းလဲခြင်း *ဘယ်တော့မှမ* panic သင့်ပါတယ်။
//! အဲဒီမှာကုဒ်ထဲမှာအခိုင်အမာနှင့်ရှင်းလင်းပြတ်သားစွာ panics, ဒါပေမယ့်သူတို့ကဘယ်တော့မှမဖြစ်သင့်သည်နှင့်ပြည်တွင်းစိတ်ဖောက်ပြန်စစ်ဆေးမှုများအဖြစ်သာအစေခံ။မည်သည့် panics ကိုမဆို bug ဟုသတ်မှတ်သင့်သည်။
//!
//! ယူနစ်စစ်ဆေးမှုများရှိသော်လည်း၎င်းတို့သည်မှန်ကန်မှုကိုသေချာစေရန်အလွန်အမင်းမလုံလောက်ပါ၊ ၎င်းတို့သည်ဖြစ်နိုင်ချေရှိသောအမှားအယွင်းများ၏ရာခိုင်နှုန်းကိုသာဖုံးအုပ်ထားသည်။
//! ပိုမိုကျယ်ပြန့်သောစစ်ဆေးမှုများကို directory `src/etc/test-float-parse` တွင် Python script တစ်ခုအနေဖြင့်တွေ့ရှိနိုင်သည်။
//!
//! integer overflow နဲ့ပတ်သက်တဲ့မှတ်စု-ဒီဖိုင်ရဲ့အစိတ်အပိုင်းတော်တော်များများကဒသမကိန်းထပ်ကိန်း `e` နဲ့ဂဏန်းသင်္ချာကိုလုပ်တယ်။
//! အဓိကအားဖြင့်ကျွန်ုပ်တို့သည်ဒdecimalမအမှတ်ကိုလှည့်ပတ်: ပထမဒdecimalမဂဏန်းမတိုင်မီ၊ နောက်ဆုံးဒdecimalမဂဏန်းပြီးနောက်နှင့်စသည်တို့ဖြစ်သည်။ဂရုမစိုက်လျှင်ဤသည်လျှံနိုင်ပါတယ်။
//! ကျွန်ုပ်တို့သည်သေးငယ်သောထပ်ညွှန်းကိန်းများကိုသာဖြန့်ဝေရန်ခွဲခြမ်းစိတ်ဖြာခြင်းဆပ်moduleကိုမှီခိုသည်။ "sufficient" သည် "such that the exponent +/- the number of decimal digits fits into a 64 bit integer" ကိုဆိုလိုသည်။
//! ပိုကြီးတဲ့ထပ်ညွန်းကိန်းကိုလက်ခံပါတယ်၊ ဒါပေမယ့်ငါတို့ကဂဏန်းသင်္ချာမလုပ်ဘူး၊ ချက်ချင်းပဲ {positive,negative} {zero,infinity} အဖြစ်ပြောင်းလိုက်တယ်။
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![doc(hidden)]
#![unstable(
    feature = "dec2flt",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

use crate::fmt;
use crate::str::FromStr;

use self::num::digits_to_big;
use self::parse::{parse_decimal, Decimal, ParseResult, Sign};
use self::rawfp::RawFloat;

mod algorithm;
mod num;
mod table;
// ဤရွေ့ကားနှစ်ခုသူတို့ရဲ့ကိုယ်ပိုင်စမ်းသပ်မှုရှိသည်။
pub mod parse;
pub mod rawfp;

macro_rules! from_str_float_impl {
    ($t:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl FromStr for $t {
            type Err = ParseFloatError;

            /// base 10 ရှိ string ကို float အဖြစ်ပြောင်းသည်။
            /// ရွေးချယ်နိုင်သောဒdecimalမကိန်းကိုလက်ခံသည်။
            ///
            /// ဤ function သည်ထိုကဲ့သို့သောကဲ့သို့သောညှို့လက်ခံခဲ့သည်
            ///
            /// * '3.14'
            /// * '-3.14'
            /// * '2.5E10', အလားတူပင် '2.5e10'
            /// * '2.5E-10'
            /// * '5.'
            /// * '.5', သို့မဟုတ်, တူညီတဲ့, '0.5'
            /// * 'inf', '-inf', 'NaN'
            ///
            /// whitespace ကို ဦး ဆောင်ခြင်းနှင့်တွယ်ကပ်ထားခြင်းသည်အမှားတစ်ခုဖြစ်သည်။
            ///
            /// # Grammar
            ///
            /// အောက်ပါ [EBNF] သဒ္ဒါကိုလိုက်နာသောကြိုးအားလုံးသည် [`Ok`] ကိုပြန်ပို့ပေးလိမ့်မည်။
            ///
            ///
            /// ```txt
            /// Float  ::= Sign? ( 'inf' | 'NaN' | Number )
            /// Number ::= ( Digit+ |
            ///              Digit+ '.' Digit* |
            ///              Digit* '.' Digit+ ) Exp?
            /// Exp    ::= [eE] Sign? Digit+
            /// Sign   ::= [+-]
            /// Digit  ::= [0-9]
            /// ```
            ///
            /// [EBNF]: https://www.w3.org/TR/REC-xml/#sec-notation
            ///
            /// # လူသိများ bug တွေ
            ///
            /// အချို့သောအခြေအနေများတွင်မှန်ကန်သော float တစ်ခုကိုဖန်တီးမည့်အစားအချို့သောအမှားများကိုပြန်ပေးသင့်သည်။
            /// အသေးစိတ်အတွက် [issue #31407] ကိုကြည့်ပါ။
            ///
            /// [issue #31407]: https://github.com/rust-lang/rust/issues/31407
            ///
            /// # Arguments
            ///
            /// * src, တစ် ဦး က string ကို
            ///
            /// # ပြန်သွားတန်ဖိုးကို
            ///
            /// `Err(ParseFloatError)` string ကိုတရားဝင်နံပါတ်ကိုယ်စားပြုမပါလျှင်။
            /// ဒီလိုမှမဟုတ်ရင် `n` `src` ကကိုယ်စားပြုထားတဲ့ floating-point number ဖြစ်သည့် `Ok(n)` ။
            ///
            #[inline]
            fn from_str(src: &str) -> Result<Self, ParseFloatError> {
                dec2flt(src)
            }
        }
    };
}
from_str_float_impl!(f32);
from_str_float_impl!(f64);

/// float ကိုခွဲခြမ်းစိတ်ဖြာသည့်အခါပြန်လာနိုင်သည့်အမှားတစ်ခု။
///
/// ဤအမှား [`f32`] နှင့် [`f64`] များအတွက် [`FromStr`] အကောင်အထည်ဖော်မှုအတွက်အမှားအမျိုးအစားအဖြစ်အသုံးပြုသည်။
///
///
/// # Example
///
/// ```
/// use std::str::FromStr;
///
/// if let Err(e) = f64::from_str("a.12") {
///     println!("Failed conversion to f64: {}", e);
/// }
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseFloatError {
    kind: FloatErrorKind,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum FloatErrorKind {
    Empty,
    Invalid,
}

impl ParseFloatError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            FloatErrorKind::Empty => "cannot parse float from empty string",
            FloatErrorKind::Invalid => "invalid float literal",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseFloatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

fn pfe_empty() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Empty }
}

fn pfe_invalid() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Invalid }
}

/// ကြွင်းသောအရာများကိုစစ်ဆေးခြင်းနှင့်အတည်ပြုခြင်းမပြုဘဲဒaမစာကြောင်းတစ်ခုနှင့်ကျန်တဲ့အပိုင်းကိုခွဲထုတ်ပါတယ်။
fn extract_sign(s: &str) -> (Sign, &str) {
    match s.as_bytes()[0] {
        b'+' => (Sign::Positive, &s[1..]),
        b'-' => (Sign::Negative, &s[1..]),
        // string မမှန်ကန်ပါကကျွန်ုပ်တို့သည်ဘယ်သောအခါမှသင်္ကေတကိုမသုံးပါ၊ ထို့ကြောင့်ဤနေရာတွင်အတည်ပြုရန်မလိုအပ်ပါ။
        _ => (Sign::Positive, s),
    }
}

/// ဒstringမစာကြောင်းတစ်ခုကို floating point number အဖြစ်ပြောင်းသည်။
fn dec2flt<T: RawFloat>(s: &str) -> Result<T, ParseFloatError> {
    if s.is_empty() {
        return Err(pfe_empty());
    }
    let (sign, s) = extract_sign(s);
    let flt = match parse_decimal(s) {
        ParseResult::Valid(decimal) => convert(decimal)?,
        ParseResult::ShortcutToInf => T::INFINITY,
        ParseResult::ShortcutToZero => T::ZERO,
        ParseResult::Invalid => match s {
            "inf" => T::INFINITY,
            "NaN" => T::NAN,
            _ => {
                return Err(pfe_invalid());
            }
        },
    };

    match sign {
        Sign::Positive => Ok(flt),
        Sign::Negative => Ok(-flt),
    }
}

/// decimal-to-float ကူးပြောင်းခြင်းအတွက်အဓိကအလုပ်လုပ်တဲ့မြင်းက: preprocessing အားလုံးကို orchestrate လုပ်ပြီးမည်သည့် algorithm ကိုအမှန်တကယ်ပြောင်းလဲသင့်သည်ကိုတွက်ဆပါ။
///
fn convert<T: RawFloat>(mut decimal: Decimal<'_>) -> Result<T, ParseFloatError> {
    simplify(&mut decimal);
    if let Some(x) = trivial_cases(&decimal) {
        return Ok(x);
    }
    // Remove/shift ဒdecimalမအမှတ်ထွက်။
    let e = decimal.exp - decimal.fractional.len() as i64;
    if let Some(x) = algorithm::fast_path(decimal.integral, decimal.fractional, e) {
        return Ok(x);
    }
    // Big32x40 သည် 1280 bits ဖြင့်သာကန့်သတ်ထားသည်။ ၎င်းသည် ၃၈၅ ခုမြောက်ဂဏန်းများကိုဘာသာပြန်သည်။
    // အကယ်၍ ကျွန်ုပ်တို့သည်ဤထက်ကျော်လျှင်ကျွန်ုပ်တို့ crash လိမ့်မည်၊ ထို့ကြောင့် (10 ^ 10 အတွင်း) အလွန်နီးကပ်ခြင်းမတိုင်မီကျွန်ုပ်တို့အမှားလုပ်မိသည်။
    let upper_bound = bound_intermediate_digits(&decimal, e);
    if upper_bound > 375 {
        return Err(pfe_invalid());
    }
    let f = digits_to_big(decimal.integral, decimal.fractional);

    // ယခုထပ်ညွှန်းကိန်းသည် 16 bit နှင့်ကိုက်ညီပြီးအဓိက algorithms များတစ်လျှောက်တွင်အသုံးပြုသည်။
    let e = e as i16;
    // FIXME ဤကန့်သတ်ချက်များသည်ရှေးရိုးစွဲမဟုတ်ပါ။
    // Bellerophon ၏ပျက်ကွက်မှုပုံစံများကိုပိုမိုဂရုတစိုက်ဆန်းစစ်လေ့လာခြင်းက၎င်းကိုအမြန်နှုန်းအလွန်မြန်စေရန်အတွက်၎င်းကိုအသုံးပြုခွင့်ပေးသည်။
    let exponent_in_range = table::MIN_E <= e && e <= table::MAX_E;
    let value_in_range = upper_bound <= T::MAX_NORMAL_DIGITS as u64;
    if exponent_in_range && value_in_range {
        Ok(algorithm::bellerophon(&f, e))
    } else {
        Ok(algorithm::algorithm_m(&f, e))
    }
}

// ရေးထားသည့်အတိုင်း၎င်းသည်ဆိုးဝါးစွာကောင်းမွန်စေသည် (#27130 တွင်ကြည့်ပါ။ ၎င်းသည်ကုဒ်ဟောင်း၏မူကွဲကိုရည်ညွှန်းသည်)
// `inline(always)` ကြောင်းများအတွက်ပြသနာကိုကျော်လွှားနိုင်စေရန်ဖြစ်ပါတယ်။
// ခေါ်ဆိုမှုဆိုဒ်နှစ်ခုသာရှိပြီးကုဒ်အရွယ်အစားကိုပိုမိုဆိုးရွားစေသည်မဟုတ်ပါ။

/// သုညကိုပြောင်းရန်လိုအပ်သည့်တိုင်သုညများကိုဖြစ်နိုင်လျှင်ချွတ်ပါ
#[inline(always)]
fn simplify(decimal: &mut Decimal<'_>) {
    let is_zero = &|&&d: &&u8| -> bool { d == b'0' };
    // ဤသုညများကိုချုံ့ခြင်းသည်ဘာမှမပြောင်းလဲသော်လည်းမြန်ဆန်သောလမ်းကြောင်း (<15 digit) ကိုဖွင့်နိုင်သည်။
    let leading_zeros = decimal.integral.iter().take_while(is_zero).count();
    decimal.integral = &decimal.integral[leading_zeros..];
    let trailing_zeros = decimal.fractional.iter().rev().take_while(is_zero).count();
    let end = decimal.fractional.len() - trailing_zeros;
    decimal.fractional = &decimal.fractional[..end];
    // ပုံစံ၏ ၀.၁ ... x နှင့် x ... ၀.၀ ကိုရိုးရှင်းအောင်ပြုလုပ်ပါ၊
    // ၎င်းသည်အမြဲတမ်းအနိုင်ရလိမ့်မည်မဟုတ်ပါ (အမြန်လမ်းကြောင်းမှအချို့သောနံပါတ်များကိုတွန်းထုတ်ပေးနိုင်သည်) ဖြစ်သော်လည်းအခြားအစိတ်အပိုင်းများကို (အထူးသဖြင့်တန်ဖိုး၏ပမာဏကိုခန့်မှန်းခြင်း) သိသိသာသာရိုးရှင်းစေသည်။
    //
    if decimal.integral.is_empty() {
        let leading_zeros = decimal.fractional.iter().take_while(is_zero).count();
        decimal.fractional = &decimal.fractional[leading_zeros..];
        decimal.exp -= leading_zeros as i64;
    } else if decimal.fractional.is_empty() {
        let trailing_zeros = decimal.integral.iter().rev().take_while(is_zero).count();
        let end = decimal.integral.len() - trailing_zeros;
        decimal.integral = &decimal.integral[..end];
        decimal.exp += trailing_zeros as i64;
    }
}

/// ပေးထားသောဒdecimalမတွင်အလုပ်လုပ်နေစဉ် Algorithm R နှင့် Algorithm M တွက်ချက်မည့်အကြီးဆုံးတန်ဖိုး၏အရွယ်အစား (log10) ပေါ်တွင်အမြန်-and-ညစ်ပတ်အထက်အပေါ်သို့ပြန်သွားသည်။
///
fn bound_intermediate_digits(decimal: &Decimal<'_>, e: i64) -> u64 {
    // ကျွန်ုပ်တို့အတွက်အလွန်အစွမ်းထက်ဆုံးသွင်းအားစုများကို trivial_cases() နှင့် parser တို့ကြောင့်ဤနေရာတွင်လျှံကျခြင်းနှင့် ပတ်သက်၍ အလွန်အမင်းစိတ်ပူစရာမလိုပါ။
    //
    let f_len: u64 = decimal.integral.len() as u64 + decimal.fractional.len() as u64;
    if e >= 0 {
        // ကိစ္စတွင်အီး>=0, နှစ် ဦး စလုံး algorithms `f * 10^e` အကြောင်းကိုတွက်ချက်။
        // Algorithm R သည်ဤရှုပ်ထွေးသည့်တွက်ချက်မှုများကိုဆက်လက်လုပ်ဆောင်သော်လည်း၎င်းသည်အထက်အပိုင်းကိုကြိုတင်လျှော့ချထားသောကြောင့်အထက်အကန့်အတွက်၎င်းကိုလျစ်လျူရှုနိုင်သည်၊ ထို့ကြောင့်ကျွန်ုပ်တို့တွင်ကြားခံများများစွာရှိသည်။
        //
        f_len + (e as u64)
    } else {
        // အကယ်၍ e <0 ဖြစ်ပါက Algorithm R သည်အတူတူပင်လုပ်သော်လည်း Algorithm M သည်ကွဲပြားသည်။
        // `f << k / 10^e` သည် In-range significand ဖြစ်သည့်အပြုသဘောဆောင်သောကိန်းတစ်ခုရရှိရန်ကြိုးစားသည်။
        // ဤသည်အကြောင်းကို `2^53 *f* 10^e` <`10^17 *f* 10^e` ဖြစ်ပေါ်လိမ့်မည်။
        // ၎င်းကို ၀.၃၃ ... ၃၃ (၃၇၅ x ၃) ဖြစ်ပေါ်စေသည်။
        f_len + e.unsigned_abs() + 17
    }
}

/// ဒtheမဂဏန်းများကိုပင်မကြည့်ဘဲသိသာနေသည့်ရေလျှံများနှင့်စီးဆင်းမှုများကိုစစ်ဆေးသည်။
fn trivial_cases<T: RawFloat>(decimal: &Decimal<'_>) -> Option<T> {
    // သုညတွေရှိပေမယ့် simplify() ကချွတ်လိုက်တယ်
    if decimal.integral.is_empty() && decimal.fractional.is_empty() {
        return Some(T::ZERO);
    }
    // ဤသည် ceil(log10(the real value)) ၏ရေနံစိမ်းအကြမ်းဖျင်းဖြစ်သည်။
    // ဤနေရာတွင်လျှံထွက်ခြင်းနှင့် ပတ်သက်၍ အလွန်အမင်းစိတ်ပူစရာမလိုပါ။ အဘယ်ကြောင့်ဆိုသော် input အရှည်သည်အလွန်သေးငယ်သော (အနည်းဆုံး ၂ ^ ၆၄ နှင့်နှိုင်းယှဉ်ပါက) နှင့်ခွဲခြမ်းစိတ်ဖြာခြင်းသည်အကြွင်းမဲ့တန်ဖိုး 10 ^ 18 ထက်ကြီးသော (10 ^ 19 short) ဖြစ်သော exponents များကိုကိုင်တွယ်နေသည်။ 2 ^ 64) ၏။
    //
    //
    let max_place = decimal.exp + decimal.integral.len() as i64;
    if max_place > T::INF_CUTOFF {
        return Some(T::INFINITY);
    } else if max_place < T::ZERO_CUTOFF {
        return Some(T::ZERO);
    }
    None
}