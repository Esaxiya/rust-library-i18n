//! ပုံစံ၏ဒdecimalမ string ကိုအတည်ပြုခြင်းနှင့်ပြိုကွဲခြင်း:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! တနည်းအားဖြင့်စံချိန်တင် floating-point syntax ကိုချွင်းချက်နှစ်ခုနှင့်အတူ-နိမိတ်လက္ခဏာမရှိ၊ "inf" နှင့် "NaN" ကိုကိုင်တွယ်ခြင်းမရှိ။ဤရွေ့ကားယာဉ်မောင်း function ကို (super::dec2flt) အားဖြင့်ကိုင်တွယ်နေကြသည်။
//!
//! ခိုင်လုံသောသွင်းအားစုများကိုအသိအမှတ်ပြုရန်လွယ်ကူသော်လည်းဤ module သည်မရေမတွက်နိုင်သောမမှန်ကန်သောအပြောင်းအလဲများကို panic ကိုလုံးဝပယ်ချရန်နှင့်အခြား module များသည် panic (သို့မဟုတ် overflow) ကိုအားမကိုးကြောင်းစစ်ဆေးမှုများကိုပြုလုပ်ရန်လိုအပ်သည်။
//!
//! ပိုမိုဆိုးရွားစေရန်အရာအားလုံးသည်သွင်းအားစုတစ်ခုတည်းမှဖြတ်သွားသည့်အခါဖြစ်ပျက်သည်။
//! ထို့ကြောင့်၊ တစ်ခုခုကိုပြုပြင်သည့်အခါသတိထားပါ၊ အခြား module များနှင့်ထပ်မံစစ်ဆေးပါ။
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// ဒstringမ string ၏စိတ်ဝင်စားဖွယ်အစိတ်အပိုင်းများ။
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// အဆိုပါဒဿမထပ်ကိန်း, နည်းပါးလာထက် 18 ဒဿမဂဏန်းရှိသည်ဖို့အာမခံချက်။
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// input string သည်ခိုင်လုံသော floating point နံပါတ်ဟုတ်မဟုတ်စစ်ဆေးပါ။ ၎င်းသည်အဓိကအပိုင်း၊ အပိုင်းကိန်းနှင့်ထပ်ကိန်းကိုရှာပါ။
/// ဆိုင်းဘုတ်များမကိုင်ပါဘူး
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // 'e' မတိုင်မီဂဏန်းမရှိပါ
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // အနည်းဆုံးဂဏန်းတစ်ခုစီလိုအပ်သည်။
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // ဒpartမကိန်းအစိတ်အပိုင်းအပြီးအမှိုက် Trailing
            }
        }
        _ => Invalid, // ပထမ ဦး ဆုံးဂဏန်း string ကိုအပြီးအမှိုက် Trailing
    }
}

/// ဒdecimalမကိန်းဂဏန်းများကိုပထမဆုံးဂဏန်းမဟုတ်သောအက္ခရာများအထိဖယ်ထုတ်နိုင်သည်။
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// ထပ်ကိန်းထုတ်ယူမှုနှင့်အမှားစစ်ဆေးခြင်းကို။
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // ထပ်ကိန်းပြီးနောက်အမှိုက် Trailing
    }
    if number.is_empty() {
        return Invalid; // အချည်းနှီးသောထပ်ကိန်း
    }
    // ဤအချိန်၌ကျွန်ုပ်တို့သည်ကျိန်းသေသောကိန်းဂဏန်းများရှိသည်။၎င်းသည် `i64` ထဲသို့ထည့်ရန်အလွန်ရှည်လွန်းနိုင်သော်လည်း၎င်းသည်ကြီးမားပါက input သည်သုညသို့မဟုတ်အဆုံးမဲ့ဖြစ်သည်။
    // ဒtheမဂဏန်းတွင်သုညတစ်ခုစီသည်ထပ်ကိန်းကို +/-၁ ဖြင့်သာချိန်ညှိပေးသောကြောင့် exp=10 ^ 18 တွင် input သည်အဆုံးသတ်ဖြစ်ခြင်းနှင့်အဝေးမှနီးကပ်ရန်သုည ၁၇ exabyte (!) ဖြစ်ရမည်။
    //
    // ဤသည်ကိုကျွန်ုပ်တို့ဖြည့်တင်းရန်လိုအပ်သည်အသုံးပြုမှုကိစ္စမဟုတ်ပါဘူး။
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}