//! အနည်းငယ်သောအပြုသဘောဆောင်သည့် IEEE 754 float များပေါ်တွင်ဖြုန်းတီးနေသည်။အနုတ်နံပါတ်များကိုမကိုင်တွယ်သင့်ပါ။
//! ပုံမှန် floating point နံပါတ်များသည် (frac, exp) ကဲ့သို့သော canonical ကိုယ်စားပြုမှုရှိသည်။ ထိုကဲ့သို့တန်ဖိုးသည် 2 <sup>exp</sup> * (N + bits အရေအတွက်ဖြစ်သော 1 + sum(frac[N-i] / 2<sup>i</sup>))) ဖြစ်သည်။
//!
//! Subnormals အနည်းငယ်ကွဲပြားခြားနားခြင်းနှင့်လိုက်တယ်, ဒါပေမယ့်တူညီတဲ့နိယာမသက်ဆိုင်ပါသည်။
//!
//! သို့သော်ဤနေရာတွင်ကျွန်ုပ်တို့သည်သူတို့ကို (sig, k) အဖြစ် f အပြုသဘောဖြင့်ကိုယ်စားပြုပြီး၊ တန်ဖိုးမှာ f ဖြစ်သည်။
//! ၂ <sup>င</sup> ။"hidden bit" ကိုရှင်းလင်းပြတ်သားစွာဖော်ပြခြင်းအပြင်၊ ဒီထပ်ကိန်းကို mantissa shift ဟုခေါ်သည်။
//!
//! နောက်တစ်နည်းပြောရရင်တော့ပုံမှန်အားဖြင့် float တွေကို (1) လို့ရေးထားပေမယ့်ဒီမှာ (2) လို့ရေးထားတယ်။
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! (1) ကို **ဒrepresentationမကိန်းကိုယ်စားပြုမှု** နှင့် (2) ကို **အဓိကကျသောကိုယ်စားပြုမှု** ဟုခေါ်သည်။
//!
//! ဒီ module ထဲမှာအတော်များများလုပ်ဆောင်ချက်များကိုသာပုံမှန်နံပါတ်များကိုကိုင်တွယ်။dec2flt လုပ်ရိုးလုပ်စဉ်များသည်အလွန်သေးငယ်ပြီးအလွန်ကြီးမားသောနံပါတ်များအတွက်တစ်ကမ္ဘာလုံးအတိုင်းအတာနှင့်မှန်ကန်သောနှေးကွေးသောလမ်းကြောင်း (Algorithm M) ကိုရှေးရိုးစွဲအတိုင်းယူသည်။
//! ၎င်း algorithm သည် subnormals နှင့်သုညများကိုကိုင်တွယ်သော next_float() သာလိုအပ်သည်။
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// အခြေခံအားဖြင့် `f32` နှင့် `f64` အတွက်ကူးပြောင်းခြင်းကုဒ်များကိုပုံတူပွားခြင်းမှရှောင်ရှားရန်ကူညီသူ trait ။
///
/// ၎င်းသည်အဘယ်ကြောင့်လိုအပ်ကြောင်းမိဘအုပ်ထိန်းသူ၏မှတ်ချက်ကိုကြည့်ပါ။
///
/// **ဘယ်တော့မှ** အခြားအမျိုးအစားများအတွက်အသုံးမပြုသင့်ပါ၊ သို့မဟုတ် dec2flt module အပြင်ဘက်တွင်အသုံးပြုသင့်သည်။
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// `to_bits` နှင့် `from_bits` အသုံးပြုသောအမျိုးအစား။
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// တစ်ခုကိန်းတစ်ခုကုန်ကြမ်း transmutation လုပ်ဆောင်တယ်။
    fn to_bits(self) -> Self::Bits;

    /// တစ်ခုကိန်းကနေကုန်ကြမ်း transmutation လုပ်ဆောင်တယ်။
    fn from_bits(v: Self::Bits) -> Self;

    /// ဒီနံပါတ်ထဲကျသွားတဲ့အမျိုးအစားကိုပြန်ပို့ပေးတယ်။
    fn classify(self) -> FpCategory;

    /// mantissa, exponent နှင့်ကိန်းဂဏန်းများအဖြစ်သင်္ကေတပြသည်။
    fn integer_decode(self) -> (u64, i16, i8);

    /// အဆိုပါ float decodes ။
    fn unpack(self) -> Unpacked;

    /// အတိအကျကိုယ်စားပြုနိုင်သည့်သေးငယ်တဲ့ကိန်းမှ Cast ။
    /// Panic သည့်ကိန်းကိုယ်စားပြုမရနိုငျပါလျှင်, ဒီ module တစ်ခုအတွက်နဲ့အခြားကုဒ်တစ်ခုကိုဖြစ်ပျက်ပါစေဘယ်တော့မှရန်သေချာစေသည်။
    fn from_int(x: u64) -> Self;

    /// Pre-တွက်ချက်ဇယားမှတန်ဖိုး 10 <sup>e</sup> ရရှိသည်။
    /// `e >= CEIL_LOG5_OF_MAX_SIG` များအတွက် Panics ။
    fn short_fast_pow10(e: usize) -> Self;

    /// နာမည်ကဘာလဲ
    /// မူရင်းအခက်အခဲများကိုကျော်လွှားရန်နှင့် LLVM အဆက်မပြတ်ခေါက်ရန်မျှော်လင့်ခြင်းထက်ခက်ခဲသော code များသည်ပိုမိုလွယ်ကူသည်။
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Overflow သို့မဟုတ်သုညသို့မဟုတ်ထုတ်လုပ်နိုင်ခြင်းမရှိသောသွင်းအားစုများ၏ဆယ်စုနှစ်ဂဏန်းများအပေါ်တွင်မူတည်သည်
    /// ပုံမှန်မဟုတ်သောဖြစ်ကောင်းဖြစ်နိုင်အများဆုံးပုံမှန်တန်ဖိုးဒdecimalမကိန်း, ဤအရပ်မှနာမကိုအမှီ။
    const MAX_NORMAL_DIGITS: usize;

    /// အထင်ရှားဆုံးဒdecimalမဂဏန်းသည်ဤထက်ကြီးသောနေရာတန်ဖိုးရှိပါကထိုနံပါတ်သည်အကန့်အသတ်မဲ့ဖြစ်သည်။
    ///
    const INF_CUTOFF: i64;

    /// အထင်ရှားဆုံးဒdecimalမဂဏန်းသည်ဤထက်နည်းသောနေရာတန်ဖိုးတစ်ခုရှိပါကထိုနံပါတ်သည်အမှန်အားသုညသို့ဝိုင်းထားသည်။
    ///
    const ZERO_CUTOFF: i64;

    /// ထပ်ကိန်းကိန်းအတွက် bits အရေအတွက်။
    const EXP_BITS: u8;

    /// လျှို့ဝှက် bit *အပါအဝင် significand* အတွက် bits အရေအတွက်။
    const SIG_BITS: u8;

    /// လျှို့ဝှက် bit ကိုဖယ်ထုတ်ပြီး significand * အတွက် bits အရေအတွက်။
    const EXPLICIT_SIG_BITS: u8;

    /// ဒrepresentationမကိန်းကိုယ်စားပြုမှု၏အများဆုံးတရားဝင်ထပ်ကိန်း။
    const MAX_EXP: i16;

    /// subnormals များဖယ်ထုတ်ခြင်း၊
    const MIN_EXP: i16;

    /// `MAX_EXP` ပေါင်းစပ်ကိုယ်စားပြုမှုများအတွက်ဆိုလိုသည်မှာပြောင်းကုန်ပြီလျှောက်ထား။
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` encoded (ဆိုလိုသည်မှာ offset ဘက်လိုက်မှုဖြင့်)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` ပေါင်းစပ်ကိုယ်စားပြုမှုများအတွက်ဆိုလိုသည်မှာပြောင်းကုန်ပြီလျှောက်ထား။
    const MIN_EXP_INT: i16;

    /// ပေါင်းစပ်ကိုယ်စားပြုမှုအတွက်အများဆုံးပုံမှန် significand ။
    const MAX_SIG: u64;

    /// အရေးပါသောကိုယ်စားပြုမှုအတွက်အနည်းဆုံးပုံမှန် significand ။
    const MIN_SIG: u64;
}

// အများအားဖြင့် #34344 အတွက်ပြသနာကိုကျော်လွှားနိုင်စေရန်။
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// mantissa, exponent နှင့်ကိန်းဂဏန်းများအဖြစ်သင်္ကေတပြသည်။
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // ထပ်ကိန်းဘက်လိုက်မှု + mantissa ပြောင်းကုန်ပြီ
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe သည် `as` သည်ပလက်ဖောင်းအားလုံးပေါ်တွင်မှန်ကန်စွာလည်ပတ်ခြင်းရှိ၊ မရှိမသေချာပါ။
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// mantissa, exponent နှင့်ကိန်းဂဏန်းများအဖြစ်သင်္ကေတပြသည်။
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // ထပ်ကိန်းဘက်လိုက်မှု + mantissa ပြောင်းကုန်ပြီ
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe သည် `as` သည်ပလက်ဖောင်းအားလုံးပေါ်တွင်မှန်ကန်စွာလည်ပတ်ခြင်းရှိ၊ မရှိမသေချာပါ။
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// `Fp` ကိုအနီးဆုံးစက်အမျိုးအစား float သို့ပြောင်းသည်။
/// ပုံမှန်မဟုတ်သောရလဒ်များကိုမကိုင်တွယ်ပါ။
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f 64 bit ဆိုတာက xe မှာ mantissa shift ၆၃ ရှိတယ်
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// တစ်ဝက်-to-ပင်နှင့်အတူ 64-bit နဲ့ significand T::SIG_BITS-bits ကိုပတ်ပတ်လည်။
/// ထပ်ကိန်းထပ်လျှံကိုမကိုင်တွယ်ပါ။
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // mantissa ပြောင်းကုန်ပြီ Adjust
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// ပုံမှန်နံပါတ်များအတွက် `RawFloat::unpack()` ၏ပြောင်းပြန်။
/// အကယ်၍ တန်ဖိုးနှင့်ကိန်းသေသည်ပုံမှန်နံပါတ်များအတွက်မမှန်ကန်ပါက Panics ။
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // လျှို့ဝှက်နည်းနည်းကိုဖယ်ရှားပါ
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // ထပ်ကိန်းကိုဘက်လိုက်မှုနှင့် mantissa shift အတွက်ထပ်ကိန်းကိုချိန်ညှိပါ
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // နိမိတ်လက္ခဏာကို 0 ("+") တွင်ချန်ထားပါ။ ကျွန်ုပ်တို့၏နံပါတ်များမှာအပေါင်းပါ
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// ပုံမှန်မဟုတ်သောတည်ဆောက်ပါ။mantissa ၀ ၀ ကိုသုညအဖြစ်သတ်မှတ်သည်။
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // ထပ်ကိန်းထပ်ကိန်းသည် ၀ ဖြစ်သည်၊ သင်္ကေတ bit မှာ 0 ဖြစ်သည်။ ထို့ကြောင့်ကျွန်ုပ်တို့သည် bits များကိုပြန်လည်အနက်ဖွင့်ရသည်။
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Fp နှင့် bignum ခန့်မှန်းပါ။ဝက်-to-ပင်နှင့်အတူ 0.5 ULP အတွင်းပတ်ပတ်လည်။
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // ကျနော်တို့ `start` အညွှန်းကိန်းမတိုင်မီ bits များအားလုံးကိုဖြတ်တောက်သည်။ ဆိုလိုသည်မှာကျွန်ုပ်တို့သည် `start` ပမာဏဖြင့်ထိရောက်စွာညာဘက်ကိုရွှေ့ခြင်း၊ ထို့ကြောင့်၎င်းသည်ကျွန်ုပ်တို့လိုအပ်သောထပ်ကိန်းလည်းဖြစ်သည်။
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // (half-to-even) ပတ်ပတ်လည်ကိုဖြတ်လိုက်သည့်အရာပေါ်မူတည်သည်။
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// အငြင်းအခုံထက်အလွန်သေးငယ်သည့်အကြီးဆုံး floating point နံပါတ်ကိုရှာသည်။
/// subnormals, သုညသို့မဟုတ် exponent underflow ကိုမကိုင်တွယ်ပါ။
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// ယင်းငြင်းခုံထက်တင်းကြပ်စွာပိုကြီးတဲ့အသေးဆုံး floating အမှတ်အရေအတွက်သည်ကိုရှာပါ။
// ဤသည်စစ်ဆင်ရေး, ဆိုလိုသည်မှာ, next_float(inf) ==အပေါ်က saturating ဖြစ်ပါတယ်။
// ဤ module ရှိကုဒ်အများစုနှင့်မတူဘဲ၊ ဒီလုပ်ဆောင်ချက်သည်သုည၊
// သို့သော်၊ အခြားသော code အားလုံးကဲ့သို့ပင်၊ ၎င်းသည် NaN နှင့်အနှုတ်လက္ခဏာနံပါတ်များနှင့်မသက်ဆိုင်ပါ။
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // ဒီဟာကသိပ်ကိုကောင်းလွန်းပေမယ့်အလုပ်ဖြစ်တယ်။
        // 0.0 အဆိုပါ All-သုညစကားလုံးအဖြစ် encoded ဖြစ်ပါတယ်။ပုံမှန်မဟုတ်သောအရာများသည် 0x000m ဖြစ်သည်။ m သည် mantissa ဖြစ်သည်။
        // အထူးသဖြင့်အငယ်ဆုံး subnormal သည် 0x0 ... 01 ဖြစ်ပြီးအကြီးဆုံးသည် 0x000F ... F ဖြစ်သည်။
        // အငယ်ဆုံးပုံမှန်နံပါတ်က 0x0010 ... 0, ဒီထောင့်အဖုံးကကောင်းကောင်းအလုပ်လုပ်တယ်။
        // အကယ်၍ increment သည် mantissa လျှံသွားလျှင် carry bit သည်ကျွန်ုပ်တို့လိုချင်သောထပ်ကိန်းကိုတိုး။ mantissa bits သည်သုညဖြစ်လာသည်။
        // အဘယ်ကြောင့်ဆိုသော်ဝှက်ထား bit မှာစည်းဝေးကြီး, ဒီလည်းကျနော်တို့ချင်အတိအကျကဘာလဲ!
        // နောက်ဆုံးအနေနဲ့ f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}