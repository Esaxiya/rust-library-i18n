//! စက္ကူကနေအမျိုးမျိုးသော algorithms ။

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Fp အတွက် significand-bits အရေအတွက်
const P: u32 = 64;

// ကျွန်ုပ်တို့သည် *all* exponents များအတွက်အကောင်းဆုံးခန့်မှန်းတွက်ချက်မှုကိုရိုးရှင်းစွာသိမ်းဆည်းထားသဖြင့် "h" နှင့်ဆက်စပ်သောအခြေအနေများကိုချန်လှပ်ထားနိုင်သည်။
// ဤသည်စုံတွဲတစ်တွဲကီလိုဂရမ်များအတွက်စွမ်းဆောင်ရည်ကုန်သွယ်။

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// အများဆုံးဗိသုကာများတွင် floating point စစ်ဆင်ရေးတစ်ခုရှင်းလင်းပြတ်သားစွာနည်းနည်းအရွယ်အစားရှိသည်, ထို့ကြောင့်တွက်ချက်မှု၏တိကျမှုနှုန်း-စစ်ဆင်ရေးအခြေခံပေါ်မှာဆုံးဖြတ်သည်။
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// x86 တွင် x87 FPU ကို SSE/SSE2 တိုးချဲ့မှုများမရရှိပါက float လုပ်ငန်းများအတွက်အသုံးပြုသည်။
// x87 FPU သည်ပုံမှန်အားဖြင့်တိကျမှု 80 bits ဖြင့်အလုပ်လုပ်သည်။ ဆိုလိုသည်မှာတန်ဖိုးများကိုနောက်ဆုံးတွင်ကိုယ်စားပြုသောအခါနှစ်ဆထပ်ကိန်းဖြစ်ခြင်းကိုဖြစ်ပေါ်စေသည်။
//
// 32/64 float တန်ဖိုးများကိုနည်းနည်း။၎င်းကိုကျော်လွှားရန် FPU control word ကိုတွက်ချက်မှုများကိုလိုချင်သောတိကျမှုဖြင့်ပြုလုပ်နိုင်သည်။
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// FPU ထိန်းချုပ်မှုစာလုံး၏မူလတန်ဖိုးကိုထိန်းသိမ်းရန်အသုံးပြုသောဖွဲ့စည်းပုံ။ ဖွဲ့စည်းပုံကျဆင်းသောအခါ၎င်းကိုပြန်လည်တည်ဆောက်ရန်ဖြစ်သည်။
    ///
    ///
    /// x87 FPU သည် ၁၆-bits register တစ်ခုဖြစ်သည်။
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// နယ်ပယ်အားလုံး၏မှတ်တမ်းများကို IA-32 Architectures Software Developer လက်စွဲ (အတွဲ ၁) တွင်ရရှိနိုင်သည်။
    ///
    /// အောက်ပါကုဒ်နှင့်သက်ဆိုင်သောတစ်ခုတည်းသောနယ်ပယ်မှာ PC၊ Precision Control ဖြစ်သည်။
    /// FPU မှလုပ်ဆောင်သောလုပ်ငန်း၏တိကျမှုကိုဤနယ်ပယ်ကဆုံးဖြတ်သည်။
    /// ၎င်းကိုသတ်မှတ်နိုင်သည်-
    ///  - 0b00, တစ်ခုတည်းတိကျဆိုလိုသည်မှာ 32-bits ကို
    ///  - 0b10, နှစ်ဆတိကျစွာဆိုလိုသည်မှာ, 64-bits ကို
    ///  - 0b11၊ နှစ်ဆတိုးချဲ့ထားသောတိကျမှု (ဆိုလိုသည်မှာ 80-bits (default state)) 0b01 တန်ဖိုးကိုထိန်းသိမ်းထားပြီးအသုံးမပြုသင့်ပါ။
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // လုံခြုံမှု-`fldcw` ညွှန်ကြားချက်ကိုမှန်ကန်စွာအလုပ်လုပ်နိုင်အောင်စစ်ဆေးပြီးဖြစ်သည်
        // မည်သည့် `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: ကျွန်ုပ်တို့သည် LLVM 8 နှင့် LLVM 9 ကိုအထောက်အပံ့ပေးရန် ATT syntax ကိုအသုံးပြုသည်။
                options(att_syntax, nostack),
            )
        }
    }

    /// FPU ၏တိကျသောနယ်ပယ်ကို `T` သို့သတ်မှတ်ပြီး `FPUControlWord` ကိုပြန်ပို့သည်။
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // `T` အတွက်သင့်လျော်သော Precision Control field အတွက်တန်ဖိုးကိုတွက်ချက်ပါ။
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // ၃၂ ခု
            8 => 0x0200, // 64 bit
            _ => 0x0300, // ပုံမှန် 80 bits
        };

        // `FPUControlWord` တည်ဆောက်ပုံပြတ်တောက်သွားသောအခါထိန်းချုပ်မှုစာလုံး၏မူလတန်ဖိုးကိုရယူပြီးနောက်မှပြန်လည်ထားရှိပါ။ လုံခြုံမှု: X0 `fnstcw` ညွှန်ကြားချက်ကိုစစ်ဆေးပြီးမည်သည့် `u16` နှင့်မဆိုမှန်ကန်စွာအလုပ်လုပ်နိုင်မည်။
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: ကျွန်ုပ်တို့သည် LLVM 8 နှင့် LLVM 9 ကိုအထောက်အပံ့ပေးရန် ATT syntax ကိုအသုံးပြုသည်။
                options(att_syntax, nostack),
            )
        }

        // လိုချင်သောတိကျစွာထိန်းချုပ်မှုစကားလုံးကိုသတ်မှတ်ပါ။
        // ၎င်းကိုတိကျမှုဟောင်း (bits 8 and 9, 0x300) ကိုဖယ်ရှားပြီးအထက်တွင်တွက်ချက်သောတိကျသောအလံဖြင့်အစားထိုးခြင်းဖြင့်၎င်းကိုရရှိသည်။
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// စက်အရွယ်အစားနှင့်ကိန်းဂဏန်းများ သုံး၍ Bellerophon ၏အမြန်လမ်းကြောင်း။
///
/// ၎င်းသည်သီးခြား function တစ်ခုထဲသို့ထုတ်ယူလိုက်ခြင်းကြောင့်၎င်းသည် bignum ကိုမတည်ဆောက်မှီကြိုးပမ်းနိုင်သည်။
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95 ။
    // တန်ဖိုးအတိအကျကိုအဆုံးအနီး MAX_SIG နှင့်နှိုင်းယှဉ်သည်။ ၎င်းသည်အမြန်၊ စျေးပေါသောငြင်းပယ်မှုဖြစ်သည် (ကျန်တဲ့ကုဒ်ရဲ့ underflow ကိုစိုးရိမ်ခြင်းမှလွတ်မြောက်စေသည်) ။
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // အစာရှောင်လမ်းကြောင်းသည်အရေးကြီးသောဂဏန်းသင်္ချာအပေါ် မူတည်၍ အလယ်အလတ်ပတ် ၀ န်းကျင်မပါဘဲမှန်ကန်သော-bits အရေအတွက်သို့ဝိုင်းခြင်းအပေါ်မူတည်သည်။
    // x86 (SSE သို့မဟုတ် SSE2 မပါဘဲ) တွင် x87 FPU stack ၏တိကျမှုကိုပြောင်းလဲရန်လိုအပ်ပြီး၎င်းသည် 64/32 bit သို့တိုက်ရိုက်လည်ပတ်သည်။
    // `set_precision` function သည်ကမ္ဘာလုံးဆိုင်ရာအခြေအနေ (x87 FPU ၏ထိန်းချုပ်မှုစကားလုံးကဲ့သို့) ကိုပြောင်းလဲခြင်းအားဖြင့်၎င်းကိုချိန်ညှိရန်လိုအပ်သည့်ဗိသုကာပညာအပေါ်တိကျမှန်ကန်စွာသတ်မှတ်ရန်ဂရုစိုက်သည်။
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // အဆိုပါကိစ္စတွင်အီး <0 အခြား branch သို့ခေါက်မရပါ။
    // အနုတ်လက္ခဏာစွမ်းအားများသည် binary တွင်ထပ်ကိန်းတစ်စိတ်တစ်ပိုင်းကိုထပ်မံဖြစ်ပေါ်စေသည်။ ၎င်းသည်ဝိုင်းနေသော၎င်းသည်နောက်ဆုံးရလဒ်အတွက် (နှင့်ရံဖန်ရံခါအတော်လေးသိသိသာသာ!) အမှားများကိုဖြစ်ပေါ်စေသည်။
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algorithm Bellerophon သည်အသေးအဖွဲသင်္ကေတမဟုတ်သောဂဏန်းခွဲခြမ်းစိတ်ဖြာမှုမှဖြောင့်မတ်သည်။
///
/// ၎င်းသည် ``f`` float တစ်ခုသို့ 64 bit အချက်အလတ်နှင့်တန်ဖိုးရှိပြီး `10^e` ကိုအနီးစပ်ဆုံး floating point format ဖြင့်မြှောက်သည်။၎င်းသည်မှန်ကန်သောရလဒ်ရရှိရန်မကြာခဏလုံလောက်သည်။
/// သို့သော် (ordinary) float နှစ်ခုကြားရှိ float နှစ်ခုကြားတွင်တစ်ဝက်နီးကပ်လာလျှင်အနီးစပ်ဆုံးတွက်ချက်မှုနှစ်ခုကိုမြှောက်ခြင်းဖြင့်ပေါင်းစပ်သော rounding error သည်ရလဒ်ကိုအနည်းငယ် bit များဖြင့်ချွတ်ပစ်နိုင်သည်။
/// ဒီလိုဖြစ်တဲ့အခါ Algorithm R ဟာကြားဖြတ်တွက်ချက်မှုများပြုလုပ်သည်။
///
/// အဆိုပါလက်-လှိုင်း "close to halfway" စက္ကူအတွက်ကိန်းဂဏန်းခွဲခြမ်းစိတ်ဖြာခြင်းအားဖြင့်တိကျစွာလုပ်ဖြစ်ပါတယ်။
/// Clinger ၏စကားများ:
///
/// > အနည်းဆုံးသိသာထင်ရှားသော bit ၏ယူနစ်တွင်ဖော်ပြထားသည် Slop သည်အမှားအတွက်အားလုံးပါဝင်နိုင်သည်
/// > f * 10 ^ အီးမှအကြမ်းဖျင်း၏ floating point တွက်ချက်မှုကာလအတွင်းစုဆောင်း။(slop ဖြစ်ပါတယ်
/// > စစ်မှန်တဲ့အမှားအတွက်မဟုတ်ဘဲအနီးစပ်ဆုံး z နဲ့ z အကြားခြားနားချက်ကိုကန့်သတ်ထားသည်
/// > significand ၏ p bits ကိုအသုံးပြုသောအကောင်းဆုံးဖြစ်နိုင်ခြေရှိသောခန့်မှန်းချက်။)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // abs(e) <log5(2^N) ဖြစ်ရပ်များသည် fast_path() ၌ရှိသည်
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // slop သည် n bits သို့ rounding သည့်အခါထူးခြားမှုတစ်ခုလုပ်ရန်လုံလောက်ပါသလား။
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// `f * 10^e` ၏ floating point approximation ကိုတိုးတက်စေသည့်ကြားဖြတ် algorithm ။
///
/// တစ်ခုချင်းစီကိုကြားမှာတစ်ခုစီသည်နောက်ဆုံးနေရာတွင်တစ်ခုနှင့်တစ်ခုနီးသည်။ အကယ်၍ `z0` သည်အနည်းငယ်နူးညံ့စွာရပ်တန့်သွားပါကပေါင်းစပ်ရန်အလွန်ကြာမြင့်စွာကြာသည်။
/// ကံကောင်းတာက Bellerophon ကို fallback အဖြစ်အသုံးပြုတဲ့အခါမှာ ULP တစ်ခုလုံးက start approximation ကိုပိတ်ထားတယ်။
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // `x / y` အတိအကျ `(f *10^e) / (m* 2^k)` ဖြစ်သည့်အပြုသဘောဆောင်သောကိန်းများကို `x`, `y` ကိုရှာပါ။
        // ၎င်းသည် `e` နှင့် `k` ၏နိမိတ်လက္ခဏာများကိုကိုင်တွယ်ဖြေရှင်းခြင်းကိုရှောင်ရှားရုံသာမကနံပါတ်များကိုသေးငယ်စေရန် `10^e` နှင့် `2^k` တို့၏ဘုံနှစ်ခု၏စွမ်းအားကိုလည်းဖယ်ရှားပေးသည်။
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // ကျွန်ုပ်တို့၏ bignums သည်အနုတ်လက္ခဏာနံပါတ်များကိုမပံ့ပိုးသောကြောင့်၎င်းသည်အကြွင်းမဲ့တန်ဖိုး + နိမိတ်လက္ခဏာအချက်အလက်ကိုအသုံးပြုသောကြောင့်၎င်းကိုနည်းနည်းအဆင်မပြေစွာရေးထားသည်။
        // m_digits ဖြင့်မြှောက်ခြင်းသည်မလျှံနိုင်ပါ။
        // အကယ်၍ `x` သို့မဟုတ် `y` အလုံအလောက်ကြီးသည်ဆိုပါကကျွန်ုပ်တို့လျှံထွက်ခြင်းနှင့် ပတ်သက်၍ စိုးရိမ်ရန်လိုအပ်သည်ဆိုပါက `make_ratio` သည်အပိုင်းအစကို 2 ^ 64 သို့မဟုတ်ထို့ထက်ပိုမိုသောအချက်ဖြင့်လျှော့ချနိုင်လောက်အောင်ကြီးမားသည်။
        //
        //
        let (d2, d_negative) = if x >= y {
            // X ကိုမလိုအပ်ဘဲ clone() ကိုသိမ်းပါ။
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // သို့တိုင် y လိုအပ်, မိတ္တူပါစေ။
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// `f` သည်ပုံမှန်အားဖြင့် input ဒdecimalမဂဏန်းများကိုကိုယ်စားပြုပြီး `m` သည် floating point approximation ၏အချက်အချာဖြစ်သည့် `x = f` နှင့် `y = m` အရအချိုး `x / y` ကို `(f *10^e) / (m* 2^k)` နှင့်ညီမျှစေပြီးနှစ်ခုစလုံး၏စွမ်းအားအားဖြင့်လျှော့ချနိုင်သည်။
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // ကျနော်တို့နှစ်ခုအချို့ပါဝါအားဖြင့်အပိုင်းကိုလျှော့ချကြောင်းမှလွဲ။ က x=f *10 ^ အီး, y က=မီတာ* 2 ^ k ။
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m ဤသည်မလျောက်နိုင်ပါ။ အဘယ်ကြောင့်ဆိုသော်၎င်းသည်အပေါင်း `e` နှင့်အနုတ် `k` လိုအပ်ပြီး၎င်းသည် ၁ အလွန်နီးကပ်သောတန်ဖိုးများအတွက်သာဖြစ်နိုင်ပြီးဆိုလိုသည်မှာ `e` နှင့် `k` သည်အလွန်သေးငယ်သောဖြစ်သည်။
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k အထက်တွင်ကြည့်ရှုသည်ဖြစ်စေဤသည်မှာလျတ်ခြင်းထက်မပြည့်စုံပါ။
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), နောက်တဖန်နှစ်ခု၏ဘုံပါဝါအားဖြင့်လျှော့ချ။
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// သဘောတရားအရ Algorithm M သည်ဒdecimalမကို float သို့ပြောင်းလဲရန်အရိုးရှင်းဆုံးနည်းလမ်းဖြစ်သည်။
///
/// ကျွန်ုပ်တို့သည် `f * 10^e` နှင့်ညီမျှသောအချိုးအစားကိုဖွဲ့စည်းသည်။ ၎င်းသည်ခိုင်လုံသော float significand နှင့်မပေးမချင်းစွမ်းအားနှစ်ခုကိုလွှင့်ထုတ်သည်။
/// binary ထပ်ကိန်း `k` ဆိုသည်မှာကျွန်ုပ်တို့သည်ပိုင်းဝေသို့မဟုတ်ပိုင်းခြေကိုနှစ်ဆမြှောက်သောအကြိမ်အရေအတွက်ဖြစ်သည်၊ ဆိုလိုသည်မှာအချိန်တိုင်း `f *10^e` သည် `(u / v)* 2^k` နှင့်ညီသည်။
/// ကျွန်ုပ်တို့သည်အဓိပ္ပါယ်နှင့်အဓိပ္ပါယ်ကိုသိရှိပြီးပါကကျန်ရှိနေသေးသောဌာနခွဲကိုစစ်ဆေးခြင်းဖြင့်သာလှည့်လည်လေ့လာရန်လိုအပ်သည်။ ၎င်းသည်အောက်ဖော်ပြပါအထောက်အကူပြုလုပ်ငန်းများ၌ပြုလုပ်သည်။
///
///
/// ဤ algorithm သည်အလွန်နှေးသည်။
/// သို့သော်၎င်းသည် overflow၊ underflow နှင့် subnormal results အတွက်လိုက်လျောညီထွေဖြစ်အောင်ပြုလုပ်ရန်အလွယ်ကူဆုံးသော algorithms ဖြစ်သည်။
/// Bellerophon နှင့် Algorithm R တို့လွှမ်းမိုးလာသောအခါဤအကောင်အထည်ဖော်မှုကျော်လွန်သွားသည်။
/// စီးဆင်းမှုများနှင့်လျှံထွက်ခြင်းများကိုရှာဖွေရန်လွယ်ကူသည်။ အချိုးသည် In-range significand မဟုတ်သော်လည်း minimum/maximum ထပ်ကိန်းကိုရောက်ရှိခဲ့သည်။
/// လျှံများပြည့်ဝြဖစ်စဉ်ကျွန်ုပ်တို့သည်အကန့်အသတ်မဲ့ပြန်လာသည်။
///
/// underflow နှင့် subnormals များကိုကိုင်တွယ်ခြင်းသည် ပို၍ ခက်ခဲသည်။
/// ကြီးမားသောပြproblemနာတစ်ခုမှာနိမ့်ဆုံးဂဏန်းနှင့်အညီ၊
/// အသေးစိတ်အတွက် underflow() ကိုကြည့်ပါ။
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // ဖြစ်နိုင်ချေရှိသည့်အကောင်းဆုံး FIXME-Big_to_fp ကိုယေဘူယျပြုလုပ်ပါ။ ထို့ကြောင့် fp_to_float(big_to_fp(u)) ၏ညီမျှခြင်းကို double rounding မပါဘဲလုပ်နိုင်သည်။
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // အနည်းဆုံးထပ်ကိန်းကိုရပ်ရန်လိုသည်။ အကယ်၍ `k < T::MIN_EXP_INT` ကိုစောင့်သည်ဆိုလျှင်ကျွန်ုပ်တို့သည်နှစ်ခုဆခွဲကိန်းအားဖြင့်ပိတ်သွားလိမ့်မည်။
            // ကံမကောင်းစွာပဲဒီဟာကိန်းဂဏန်းတွေကိုအနိမ့်ဆုံးဂဏန်းနဲ့အထူးပြုရမယ်။
            // FIXME သည်ပိုမိုကြော့ရှင်းသည့်ဖော်မြူလာကိုရှာဖွေသော်လည်း `tiny-pow10` test ကိုအမှန်မှန်ကန်စွာသေချာအောင်လုပ်ပါ။
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// bit အလျားကိုစစ်ဆေးခြင်းဖြင့် Algorithm M ကြားဖြတ်ချက်အများစုကိုကျော်သွားသည်။
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // bit length သည်အခြေခံ logarithm နှစ်ခုနှင့် log(u / v) = log(u), log(v) တို့၏ခန့်မှန်းချက်ဖြစ်သည်။
    // ခန့်မှန်းချက်သည်အများဆုံးအားဖြင့် ၁ ခုရှိသော်လည်းအမြဲတမ်းခန့်မှန်းတွက်ချက်မှုနည်းသောကြောင့် log(u) နှင့် log(v) ပေါ်ရှိအမှားသည်တူညီသောအမှတ်အသားဖြစ်ပြီးဖျက်သိမ်းခြင်း (နှစ်ခုလုံးကြီးမားလျှင်)
    // ထို့ကြောင့် log(u / v) အတွက်အမှားမှာအများဆုံးတစ်ခုဖြစ်သည်။
    // ပစ်မှတ်အချိုးသည် u/v သည် In-range significand ရှိသည့်နေရာဖြစ်သည်။ထို့ကြောင့်ကျွန်ုပ်တို့၏ရပ်စဲခွအေနအေ log2(u / v) အဆိုပါ significand-bits, plus/minus တဦးတည်းဖြစ်ခြင်းဖြစ်ပါတယ်။
    // FIXME ဒုတိယနည်းနည်းကိုကြည့်ခြင်းကခန့်မှန်းချက်ကိုတိုးတက်စေပြီးကွဲပြားမှုများကိုလည်းရှောင်ရှားနိုင်သည်။
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Underflow သို့မဟုတ်ပုံမှန်မဟုတ်သော။အဓိက function ကိုမှချန်ထားပါ။
            break;
        }
        if *k == T::MAX_EXP_INT {
            // လျှံ။အဓိက function ကိုမှချန်ထားပါ။
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // အချိုးသည်အနိမ့်ဆုံးဂဏန်းရှိသည့်အကန့်အသတ်ရှိသည့်အချက်အချာကျမှုမဟုတ်ပါ။ ထို့ကြောင့်ကျွန်ုပ်တို့သည်ပိုလျှံသော-bits များကိုပတ်ပတ်လည်နှင့်ထပ်ညွှန်းကိန်းကိုအညီချိန်ညှိရန်လိုအပ်သည်။
    // ယခုအစစ်အမှန်တန်ဖိုးသည်ဤပုံစံနှင့်တူသည်။
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc ။(rem မှကိုယ်စားပြုသည်)
    //
    // ထို့ကြောင့်, rounded-off bits!= 0.5 ULP ဖြစ်တဲ့အခါ, သူတို့ကသူတို့ကိုယ်သူတို့အပေါ် rounding ဆုံးဖြတ်။
    // သူတို့ညီမျှပြီးကျန်ကသုညမဟုတ်တော့လျှင်တန်ဖိုးကိုထပ်တိုးရန်လိုအပ်သည်။
    // rounded off bits သည် 1/2 ဖြစ်ပြီးကျန်သည်သုညဖြစ်မှသာကျွန်ုပ်တို့သည်တစ်ဝက်မှညနေအထိအခြေအနေရှိသည်။
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// သာမန်လှည့်လည်-to-ပင်, ဌာနခွဲ၏ကျန်ရှိသောအပေါ်အခြေခံပြီးပတ်ပတ်လည်ရှိခြင်းအားဖြင့် obfuscated ။
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}