//! bignums အတွက်အသုံး ၀ င်သည့်လုပ်ဆောင်ချက်များသည်နည်းလွန်းခြင်းမရှိသောနည်းလမ်းများအဖြစ်သို့ပြောင်းလဲသွားသည်။

// FIXME ဒီ module ရဲ့နာမည်ကနည်းနည်းကံဆိုးတာပဲ။ ဘာလို့လဲဆိုတော့အခြား module တွေ X `core::num` X ကိုလည်းတင်တယ်။

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// `ones_place` ထက်သိသာထင်ရှားသည့် bit များအားလုံးကို truncating လုပ်ခြင်းသည် 0.5 ULP ထက်နည်းသော၊ တန်းတူ (သို့) ပို၍ ကြီးသောဆွေမျိုးအမှားများကိုစမ်းသပ်သည်။
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // ကျန်ရှိသော bits အားလုံးသည်သုညဖြစ်ပါက= 0.5 ULP၊ မဟုတ်ပါ။ > 0.5 bits မရှိတော့လျှင် (half_bit==0) အောက်တွင်ဖော်ပြထားသည်မှာ Equal ကိုမှန်ကန်စွာပြန်ပို့သည်။
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// တစ်ဦး `u64` သာဒဿမဂဏန်း်တစ်ဦး ASCII string ကိုပြောင်းပေးပါတယ်။
///
/// စီးလွင့်ခြင်းသို့မဟုတ်မမှန်ကန်သောစာလုံးများကိုစစ်ဆေးခြင်းမပြုလုပ်ပါ။ အကယ်၍ ခေါ်ဆိုသူ၏သတိထားမှုမရှိပါကရလဒ်သည်အတုအယောင်ဖြစ်ပြီး panic (`unsafe` မဟုတ်ပါ) ဖြစ်နိုင်သည်။
/// ထို့အပြင်အချည်းနှီးသောညှို့သုညအဖြစ်ကုသနေကြသည်။
/// ဘာဖြစ်လို့လဲဆိုတော့ဒီ function ကိုတည်ရှိ
///
/// 1. `&[u8]` တွင် `FromStr` ကိုအသုံးပြုရန်မှာ `from_utf8_unchecked` လိုအပ်သည်
/// 2. `integral.parse()` နှင့် `fractional.parse()` ၏ရလဒ်များကိုအတူတကွပေါင်းစပ်ခြင်းသည်ဤလုပ်ဆောင်ချက်တစ်ခုလုံးထက်ပိုမိုရှုပ်ထွေးသည်။
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// ASCII digit in string ကို bignum အဖြစ်ပြောင်းသည်။
///
/// `from_str_unchecked` ကဲ့သို့ဤလုပ်ဆောင်မှုသည်ခွဲခြမ်းစိတ်ဖြာသူကိုဂဏန်းမဟုတ်သောပေါင်းစပ်မှုမှမှီခိုသည်။
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// bignum ကို 64 bit integer အဖြစ်ပြောင်းသည်။နံပါတ်ကအရမ်းကြီးလွန်းလျှင် Panics
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// - bits ၏အကွာအဝေးထုတ်ယူ။

/// အညွှန်း 0 သည်အနည်းဆုံးသိသိသာသာနည်းပြီးအကွာအဝေးသည်ပုံမှန်အတိုင်းတဝက်ဖွင့်ထားသည်။
/// Panics သည်ပြန်လည်ထည့်သွင်းရန်အတွက် fit ထက်ပိုသော-bits များကိုထုတ်ယူရန်တောင်းဆိုပါက။
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}