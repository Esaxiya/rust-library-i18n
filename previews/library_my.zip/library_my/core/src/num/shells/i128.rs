//! 128-bit ကိန်းဂဏန်းများအရလက်မှတ်ထိုးထားသောကိန်းအမျိုးအစားအတွက်စဉ်ဆက်မပြတ်
//!
//! *[See also the `i128` primitive type][i128].*
//!
//! Code အသစ်သည် Primitive type အပေါ်တွင်သက်ဆိုင်သော Constant များကိုတိုက်ရိုက်အသုံးပြုသင့်သည်။

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i128`"
)]

int_module! { i128, #[stable(feature = "i128", since="1.26.0")] }