//! အဆိုပါ pointer အရွယ်လက်မှတ်ရေးထိုးခဲ့ integer type ကိုအဘို့အစဉ်ဆက်မပြတ်။
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! Code အသစ်သည် Primitive type အပေါ်တွင်သက်ဆိုင်သော Constant များကိုတိုက်ရိုက်အသုံးပြုသင့်သည်။

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }