//! 8-bit unsigned integer type အတွက်အမြဲတမ်း။
//!
//! *[See also the `u8` primitive type][u8].*
//!
//! Code အသစ်သည် Primitive type အပေါ်တွင်သက်ဆိုင်သော Constant များကိုတိုက်ရိုက်အသုံးပြုသင့်သည်။

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u8`"
)]

int_module! { u8 }