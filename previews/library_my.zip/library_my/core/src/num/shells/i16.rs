//! 16-bit မှာကိန်းသေကိန်းသေအတွက်ကိန်းသေ။
//!
//! *[See also the `i16` primitive type][i16].*
//!
//! Code အသစ်သည် Primitive type အပေါ်တွင်သက်ဆိုင်သော Constant များကိုတိုက်ရိုက်အသုံးပြုသင့်သည်။

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i16`"
)]

int_module! { i16 }