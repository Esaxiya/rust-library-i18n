//! တစ် ဦး ချင်းစီအစိတ်အပိုင်းများနှင့်အမှားအကွာအဝေးသို့ floating-point တန်ဖိုးကို decodes ။

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// ဒီကုဒ်မပါသောလက်မှတ်မထိုးရသေးသောတန်ဖိုး၊
///
/// - မူလတန်ဖိုး `mant * 2^exp` နှင့်ညီသည်။
///
/// - `(mant - minus)*2^exp` မှ `(mant + plus)* 2^exp` သို့မည်သည့်နံပါတ်မဆိုမူလတန်ဖိုးသို့ဝလိမ့်မည်။
/// `inclusive` `true` ဖြစ်မှသာအကွာအဝေးအားလုံးပါဝင်နိုင်သည်။
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// အဆိုပါခဲ့သည်ဆို၏ mantissa ။
    pub mant: u64,
    /// အနိမ့်အမှားအကွာအဝေး။
    pub minus: u64,
    /// အထက်အမှားအကွာအဝေး။
    pub plus: u64,
    /// Base 2 မှာထပ်ကိန်းထပ်ကိန်း
    pub exp: i16,
    /// အမှားအကွာအဝေးအားလုံးပါဝင်နိုင်သောအခါမှန်သည်။
    ///
    /// IEEE 754 တွင်မူရင်း mantissa ပင်ဖြစ်ခဲ့စဉ်ကမှန်ကန်သည်။
    pub inclusive: bool,
}

/// လက်မှတ်မထိုးတန်ဖိုးကို။
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// အပြုသဘောသို့မဟုတ်အနှုတ်ဖြစ်စေ Infinities ။
    Infinite,
    /// သုည, အပြုသဘောသို့မဟုတ်အနုတ်လက္ခဏာဖြစ်စေ။
    Zero,
    /// နောက်ထပ် decoded လယ်ကွင်းနှင့်အတူကနျ့နံပါတ်များကို။
    Finite(Decoded),
}

/// `decode`d which ဖြစ်နိုင်သည့် floating point အမျိုးအစား။
pub trait DecodableFloat: RawFloat + Copy {
    /// အနည်းဆုံးအပြုသဘောပုံမှန်တန်ဖိုး။
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// ပေးထားသော floating point number တစ်ခုမှနိမိတ်လက္ခဏာ (မှန်လျှင်မှန်) နှင့် `FullDecoded` တန်ဖိုးကိုပြန်ပို့သည်။
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // အိမ်နီးချင်းများ (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode အမြဲတမ်းထပ်ညွှန်းကိန်းကိုထိန်းသိမ်းသည်၊ ထို့ကြောင့် mantissa သည်ပုံမှန်မဟုတ်သောပမာဏအတွက်ဖြစ်သည်။
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // အိမ်နီးချင်းများ (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // ဘယ်မှာ maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // အိမ်နီးချင်းများ (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}