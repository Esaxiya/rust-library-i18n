/*!

Floating-point number to decimal conversion routines.

# Problem statement

We are given the floating-point number `v = f * 2^e` with an integer `f`,
and its bounds `minus` and `plus` such that any number between `v - minus` and
`v + plus` will be rounded to `v`. For the simplicity we assume that
this range is exclusive. Then we would like to get the unique decimal
representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero.

- It's correctly rounded when parsed back: `v - minus < V < v + plus`.
  Furthermore it is shortest such one, i.e., there is no representation
  with less than `n` digits that is correctly rounded.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Note that
  there might be two representations satisfying this uniqueness requirement,
  in which case some tie-breaking mechanism is used.

We will call this mode of operation as to the *shortest* mode. This mode is used
when there is no additional constraint, and can be thought as a "natural" mode
as it matches the ordinary intuition (it at least prints `0.1f32` as "0.1").

We have two more modes of operation closely related to each other. In these modes
we are given either the number of significant digits `n` or the last-digit
limitation `limit` (which determines the actual `n`), and we would like to get
the representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero, unless `n` was zero in which case only `k` is returned.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Again,
  there might be some tie-breaking mechanism.

When `limit` is given but not `n`, we set `n` such that `k - n = limit`
so that the last digit `d[n-1]` is scaled by `10^(k-n) = 10^limit`.
If such `n` is negative, we clip it to zero so that we will only get `k`.
We are also limited by the supplied buffer. This limitation is used to print
the number up to given number of fractional digits without knowing
the correct `k` beforehand.

We will call the mode of operation requiring `n` as to the *exact* mode,
and one requiring `limit` as to the *fixed* mode. The exact mode is a subset of
the fixed mode: the sufficiently large last-digit limitation will eventually fill
the supplied buffer and let the algorithm to return.

# Implementation overview

It is easy to get the floating point printing correct but slow (Russ Cox has
[demonstrated](http://research.swtch.com/ftoa) how it's easy), or incorrect but
fast (naïve division and modulo). But it is surprisingly hard to print
floating point numbers correctly *and* efficiently.

There are two classes of algorithms widely known to be correct.

- The "Dragon" family of algorithm is first described by Guy L. Steele Jr. and
  Jon L. White. They rely on the fixed-size big integer for their correctness.
  A slight improvement was found later, which is posthumously described by
  Robert G. Burger and R. Kent Dybvig. David Gay's `dtoa.c` routine is
  a popular implementation of this strategy.

- The "Grisu" family of algorithm is first described by Florian Loitsch.
  They use very cheap integer-only procedure to determine the close-to-correct
  representation which is at least guaranteed to be shortest. The variant,
  Grisu3, actively detects if the resulting representation is incorrect.

We implement both algorithms with necessary tweaks to suit our requirements.
In particular, published literatures are short of the actual implementation
difficulties like how to avoid arithmetic overflows. Each implementation,
available in `strategy::dragon` and `strategy::grisu` respectively,
extensively describes all necessary justifications and many proofs for them.
(It is still difficult to follow though. You have been warned.)

Both implementations expose two public functions:

- `format_shortest(decoded, buf)`, which always needs at least
  `MAX_SIG_DIGITS` digits of buffer. Implements the shortest mode.

- `format_exact(decoded, buf, limit)`, which accepts as small as
  one digit of buffer. Implements exact and fixed modes.

They try to fill the `u8` buffer with digits and returns the number of digits
written and the exponent `k`. They are total for all finite `f32` and `f64`
inputs (Grisu internally falls back to Dragon if necessary).

The rendered digits are formatted into the actual string form with
four functions:

- `to_shortest_str` prints the shortest representation, which can be padded by
  zeroes to make *at least* given number of fractional digits.

- `to_shortest_exp_str` prints the shortest representation, which can be
  padded by zeroes when its exponent is in the specified ranges,
  or can be printed in the exponential form such as `1.23e45`.

- `to_exact_exp_str` prints the exact representation with given number of
  digits in the exponential form.

- `to_exact_fixed_str` prints the fixed representation with *exactly*
  given number of fractional digits.

They all return a slice of preallocated `Part` array, which corresponds to
the individual part of strings: a fixed string, a part of rendered digits,
a number of zeroes or a small (`u16`) number. The caller is expected to
provide a large enough buffer and `Part` array, and to assemble the final
string from resulting `Part`s itself.

All algorithms and formatting functions are accompanied by extensive tests
in `coretests::num::flt2dec` module. It also shows how to use individual
functions.

*/

// ဤသည်ကိုကျယ်ကျယ်ပြန့်ပြန့်မှတ်တမ်းတင်ထားသော်လည်း၎င်းသည်မူအရပုဂ္ဂလိကပိုင်ဖြစ်ပြီးစမ်းသပ်မှုအတွက်သာလူသိရှင်ကြားဖြစ်သည်။
// ငါတို့ကိုမဘော်ပြကြနှင့်။
#![doc(hidden)]
#![unstable(
    feature = "flt2dec",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

pub use self::decoder::{decode, DecodableFloat, Decoded, FullDecoded};

use crate::mem::MaybeUninit;

pub mod decoder;
pub mod estimator;

/// ဒစ်ဂျစ်တယ်မျိုးဆက် algorithms ။
pub mod strategy {
    pub mod dragon;
    pub mod grisu;
}

/// အတိုဆုံး mode အတွက်လိုအပ်သောကြားခံ၏အနည်းဆုံးအရွယ်အစား။
///
/// ၎င်းသည်ရရှိရန်နည်းနည်းအသေးအဖွဲဖြစ်သည်၊ သို့သော်၎င်းသည်အတိုဆုံးရလဒ်နှင့်အတူ format ချခြင်း algorithms မှဒsignificantမဂဏန်းအရေအတွက်အများဆုံးတစ်ခုဖြစ်သည်။
///
/// အတိအကျပုံသေနည်း `ceil(# bits in mantissa * log_10 2 + 1)` ဖြစ်ပါတယ်။
pub const MAX_SIG_DIGITS: usize = 17;

/// `d` တွင်ဒdecimalမဂဏန်းများပါ ၀ င်ပါကနောက်ဆုံးဂဏန်းကိုတိုး။ သယ်ဆောင်ပါ။
/// ကအရှည်ကိုပြောင်းလဲစေသည့်အခါလာမယ့်ဂဏန်းပြန်သွားသည်။
#[doc(hidden)]
pub fn round_up(d: &mut [u8]) -> Option<u8> {
    match d.iter().rposition(|&c| c != b'9') {
        Some(i) => {
            // [[i + 1..n] အားလုံးကိုးဖြစ်သည်
            d[i] += 1;
            for j in i + 1..d.len() {
                d[j] = b'0';
            }
            None
        }
        None if d.len() > 0 => {
            // 999..999 တိုးမြှင့်ထပ်ကိန်းနှင့်အတူ 1000..000 မှကျည်
            d[0] = b'1';
            for j in 1..d.len() {
                d[j] = b'0';
            }
            Some(b'0')
        }
        None => {
            // တစ် ဦး အချည်းနှီးသောကြားခံတက်လာ (နည်းနည်းထူးဆန်းပေမယ့်ကျိုးကြောင်းဆီလျော်)
            Some(b'1')
        }
    }
}

/// ကားချပ်အစိတ်အပိုင်းများ။
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Part<'a> {
    /// သုညဂဏန်းအရေအတွက်ပေးထားသော။
    Zero(usize),
    /// ဂဏန်း ၅ လုံးအထိပကတိနံပါတ်။
    Num(u16),
    /// ပေးထားသော bytes ၏စာလုံးမိတ္တူ။
    Copy(&'a [u8]),
}

impl<'a> Part<'a> {
    /// ပေးထားသောအစိတ်အပိုင်း၏အတိအကျ byte အရှည်ကိုပြန်သွားသည်။
    pub fn len(&self) -> usize {
        match *self {
            Part::Zero(nzeroes) => nzeroes,
            Part::Num(v) => {
                if v < 1_000 {
                    if v < 10 {
                        1
                    } else if v < 100 {
                        2
                    } else {
                        3
                    }
                } else {
                    if v < 10_000 { 4 } else { 5 }
                }
            }
            Part::Copy(buf) => buf.len(),
        }
    }

    /// ပေးထားသောကြားခံထဲသို့အစိတ်အပိုင်းတစ်ခုရေးသားခဲ့သည်။
    /// ကြားခံမလုံလောက်ပါကရေးသားထားသော bytes သို့မဟုတ် `None` အရေအတွက်ကိုပြန်သွားသည်။
    /// (၎င်းသည်တစ်စိတ်တစ်ပိုင်းအားဖြင့်ရေးသားထားသော bytes များကိုကြားခံတွင်ချန်ထားဆဲဖြစ်နိုင်သည်။ ၎င်းကိုမမှီပါနှင့်။)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        let len = self.len();
        if out.len() >= len {
            match *self {
                Part::Zero(nzeroes) => {
                    for c in &mut out[..nzeroes] {
                        *c = b'0';
                    }
                }
                Part::Num(mut v) => {
                    for c in out[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                }
                Part::Copy(buf) => {
                    out[..buf.len()].copy_from_slice(buf);
                }
            }
            Some(len)
        } else {
            None
        }
    }
}

/// တစ်ခုသို့မဟုတ်တစ်ခုထက်ပိုသောအစိတ်အပိုင်းများပါ ၀ င်သည့် format ချထားသောရလဒ်။
/// ၎င်းကို byte buffer တွင်ရေးသား။ ခွဲဝေထားသော string သို့ပြောင်းလဲနိုင်သည်။
#[allow(missing_debug_implementations)]
#[derive(Clone)]
pub struct Formatted<'a> {
    /// `""`, `"-"` သို့မဟုတ် `"+"` တစ်ခုခုကိုကိုယ်စားပြုသော byte slice
    pub sign: &'static str,
    /// Formatted အစိတ်အပိုင်းများကိုနိမိတ်လက္ခဏာတစ်ခုနှင့် optional သုည padding ပြီးနောက်ပြန်ဆိုရန်။
    pub parts: &'a [Part<'a>],
}

impl<'a> Formatted<'a> {
    /// ပေါင်းစပ် format ၏ရလဒ်အတိအကျ byte အရှည်ပြန်သွားသည်။
    pub fn len(&self) -> usize {
        let mut len = self.sign.len();
        for part in self.parts {
            len += part.len();
        }
        len
    }

    /// Formatt လုပ်ထားသောအစိတ်အပိုင်းများအားပေးထားသည့်ကြားခံထဲသို့ရေးသည်။
    /// ကြားခံမလုံလောက်ပါကရေးသားထားသော bytes သို့မဟုတ် `None` အရေအတွက်ကိုပြန်သွားသည်။
    /// (၎င်းသည်တစ်စိတ်တစ်ပိုင်းအားဖြင့်ရေးသားထားသော bytes များကိုကြားခံတွင်ချန်ထားဆဲဖြစ်နိုင်သည်။ ၎င်းကိုမမှီပါနှင့်။)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        if out.len() < self.sign.len() {
            return None;
        }
        out[..self.sign.len()].copy_from_slice(self.sign.as_bytes());

        let mut written = self.sign.len();
        for part in self.parts {
            let len = part.write(&mut out[written..])?;
            written += len;
        }
        Some(written)
    }
}

/// အနည်းဆုံးဒfractionမကိန်းဂဏန်းအရေအတွက်ဖြင့်ဒdecimalမဂဏန်း `0.<...buf...> * 10^exp` ကိုဒdecimalမပုံစံသို့ပေးသည်။
///
/// ရလဒ်သည်ထောက်ပံ့ထားသောအစိတ်အပိုင်းများကိုသိမ်းဆည်းထားပြီးရေးသားထားသောအပိုင်းအစများကိုပြန်ပို့ပေးသည်။
///
/// `frac_digits` ဒီထက် `buf` အတွက်အမှန်တကယ်ဒဿမကိန်းဂဏန်းများ၏အရေအတွက်ထက်နိုင်ပါတယ်;
/// ကလျစ်လျူရှုလိမ့်မည်နှင့်အပြည့်အဝဂဏန်းပုံနှိပ်လိမ့်မည်။၎င်းကိုဂဏန်းပြန်ဆိုပြီးနောက်နောက်ထပ်သုညပုံနှိပ်ရန်သာအသုံးပြုသည်။
/// ထို့ကြောင့် 0 of `frac_digits` သည်ဆိုလိုသည်မှာပေးထားသောဂဏန်းများနှင့်အခြားမည်သည့်အရာမျှမဆိုပုံနှိပ်နိုင်သည်။
///
fn digits_to_dec_str<'a>(
    buf: &'a [u8],
    exp: i16,
    frac_digits: usize,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 4);

    // အကယ်၍ နောက်ဆုံးဂဏန်းအနေအထားတွင်ကန့်သတ်ချက်များရှိပါက `buf` ကို virtual သုညဖြင့်ကျန်နေစေသည်ဟုယူဆရသည်။
    // virtual သုည၏နံပါတ်, `nzeroes`, `max(0, exp + frac_digits - buf.len())` ညီမျှသည်, ဒါကြောင့်နောက်ဆုံးဂဏန်း `exp - buf.len() - nzeroes` ၏အနေအထားကို `-frac_digits` ထက်မပိုစေ:
    //
    //
    //                       |<-virtual->|
    //       | <----buf----> |သုည |exp
    //    0. 1 2 3 4 5 6 7 8 9 _ _ _ _ _ _ x ကို 10
    //    |                  |           |
    // 10 ^ exp 10^(exp-buf.len()) 10^(exp-buf.len()-nzeroes)
    //
    // `nzeroes` လျှံကိုရှောင်ရှားနိုင်ရန်အတွက်တစ် ဦး ချင်းစီကိုတွက်ချက်သည်။
    //

    if exp <= 0 {
        // ဒdecimalမအမှတ်ဂဏန်းပြန်ဆိုမတိုင်မီဖြစ်ပါသည်: [0.][000...000][1234][____]
        let minus_exp = -(exp as i32) as usize;
        parts[0] = MaybeUninit::new(Part::Copy(b"0."));
        parts[1] = MaybeUninit::new(Part::Zero(minus_exp));
        parts[2] = MaybeUninit::new(Part::Copy(buf));
        if frac_digits > buf.len() && frac_digits - buf.len() > minus_exp {
            parts[3] = MaybeUninit::new(Part::Zero((frac_digits - buf.len()) - minus_exp));
            // လုံခြုံမှု-element `..4` ကိုစတင်ပါတယ်။
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
        } else {
            // လုံခြုံမှု-element `..3` ကိုစတင်ပါတယ်။
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
        }
    } else {
        let exp = exp as usize;
        if exp < buf.len() {
            // ဒtheမအချက်သည်ဂဏန်းပြန်ဆိုထားသောဂဏန်းများဖြစ်သည်။ [12][.][34][____]
            parts[0] = MaybeUninit::new(Part::Copy(&buf[..exp]));
            parts[1] = MaybeUninit::new(Part::Copy(b"."));
            parts[2] = MaybeUninit::new(Part::Copy(&buf[exp..]));
            if frac_digits > buf.len() - exp {
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits - (buf.len() - exp)));
                // လုံခြုံမှု-element `..4` ကိုစတင်ပါတယ်။
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // လုံခြုံမှု-element `..3` ကိုစတင်ပါတယ်။
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
            }
        } else {
            // ဂဏန်းပြန်ဆိုပြီးနောက်ဒdecimalမအမှတ်သည် [1234][____0000] သို့မဟုတ် [1234][__][.][__] ။
            parts[0] = MaybeUninit::new(Part::Copy(buf));
            parts[1] = MaybeUninit::new(Part::Zero(exp - buf.len()));
            if frac_digits > 0 {
                parts[2] = MaybeUninit::new(Part::Copy(b"."));
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits));
                // လုံခြုံမှု-element `..4` ကိုစတင်ပါတယ်။
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // လုံခြုံမှု-element `..2` ကိုစတင်ပါတယ်။
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) }
            }
        }
    }
}

/// ပေးထားသောဒdecimalမဂဏန်း `0.<...buf...> * 10^exp` ကိုအနည်းဆုံးသတ်မှတ်ထားသောဂဏန်းအရေအတွက်နှင့်ထပ်ကိန်းပုံစံသို့ format လုပ်သည်။
///
/// `upper` သည် `true` ဖြစ်သည့်အခါထပ်ညွှန်းကို `E` ကရှေ့ဆက်ပြလိမ့်မည်။မဟုတ်ရင် `e` ပါ။
/// ရလဒ်သည်ထောက်ပံ့ထားသောအစိတ်အပိုင်းများကိုသိမ်းဆည်းထားပြီးရေးသားထားသောအပိုင်းအစများကိုပြန်ပို့ပေးသည်။
///
/// `min_digits` `buf` ရှိအမှန်တကယ်သိသာထင်ရှားသောဂဏန်းအရေအတွက်ထက်နည်းနိုင်သည်။
/// ကလျစ်လျူရှုလိမ့်မည်နှင့်အပြည့်အဝဂဏန်းပုံနှိပ်လိမ့်မည်။၎င်းကိုဂဏန်းပြန်ဆိုပြီးနောက်နောက်ထပ်သုညပုံနှိပ်ရန်သာအသုံးပြုသည်။
/// ထို့ကြောင့် `min_digits == 0` ဆိုသည်မှာ၎င်းသည်ပေးထားသောဂဏန်းများနှင့်အခြားမည်သည့်အရာကိုမဆိုသာပုံနှိပ်မည်ဟုဆိုလိုသည်။
///
fn digits_to_exp_str<'a>(
    buf: &'a [u8],
    exp: i16,
    min_ndigits: usize,
    upper: bool,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 6);

    let mut n = 0;

    parts[n] = MaybeUninit::new(Part::Copy(&buf[..1]));
    n += 1;

    if buf.len() > 1 || min_ndigits > 1 {
        parts[n] = MaybeUninit::new(Part::Copy(b"."));
        parts[n + 1] = MaybeUninit::new(Part::Copy(&buf[1..]));
        n += 2;
        if min_ndigits > buf.len() {
            parts[n] = MaybeUninit::new(Part::Zero(min_ndigits - buf.len()));
            n += 1;
        }
    }

    // 0.1234 x 10 ^ exp= 1.234 x 10 ^ (exp-1)
    let exp = exp as i32 - 1; // exp i16::MIN ဖြစ်တဲ့အခါ underflow ကိုရှောင်ကြဉ်ပါ
    if exp < 0 {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E-" } else { b"e-" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(-exp as u16));
    } else {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E" } else { b"e" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(exp as u16));
    }
    // လုံခြုံမှု-element `..n + 2` ကိုစတင်ပါတယ်။
    unsafe { MaybeUninit::slice_assume_init_ref(&parts[..n + 2]) }
}

/// Formatting ရွေးချယ်မှုများကိုလက်မှတ်ထိုးပါ။
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Sign {
    /// အနုတ်လက္ခဏာမဟုတ်သောသုညတန်ဖိုးများအတွက်သာ `-` ကိုထုတ်သည်။
    Minus, // -inf -1 0 င် 0 င် 1 inf inf
    /// (အနုတ်သုညအပါအဝင်) မည်သည့်အနုတ်လက္ခဏာတန်ဖိုးများအတွက်သာ `-` ကိုထုတ်သည်။
    MinusRaw, // -inf -1 -0 0 င် 1 အပေါ်က nan
    /// အနုတ်လက္ခဏာမဟုတ်သောသုညတန်ဖိုးများအတွက် `-` သို့မဟုတ်အခြားမဟုတ်သည့် `+` ကိုပုံနှိပ်နိုင်သည်။
    MinusPlus, // -inf -1 +0 +0 +1 + Inf Nan
    /// (အနုတ်သုညအပါအဝင်) မည်သည့်အနုတ်လက္ခဏာတန်ဖိုးများအတွက် `-` သို့မဟုတ်မဟုတ်ရင် `+` ကိုပုံနှိပ်ပါ။
    MinusPlusRaw, // -inf -1 -0 +0 +1 + Inf Nan
}

/// format လုပ်မည့်နိမိတ်နှင့်သက်ဆိုင်သော static byte string ကို return လုပ်သည်။
/// ၎င်းသည် `""`, `"+"` သို့မဟုတ် `"-"` ဖြစ်နိုင်သည်။
fn determine_sign(sign: Sign, decoded: &FullDecoded, negative: bool) -> &'static str {
    match (*decoded, sign) {
        (FullDecoded::Nan, _) => "",
        (FullDecoded::Zero, Sign::Minus) => "",
        (FullDecoded::Zero, Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (FullDecoded::Zero, Sign::MinusPlus) => "+",
        (FullDecoded::Zero, Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
        (_, Sign::Minus | Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (_, Sign::MinusPlus | Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
    }
}

/// ပေးထားသော floating point နံပါတ်ကိုအနည်းဆုံးဒfractionမကိန်းဂဏန်းအရေအတွက်ဖြင့်ပုံစံချသည်။
/// ပေးထားသော byte buffer ကို scratch တစ်ခုအနေဖြင့်အသုံးပြုနေစဉ်ရလဒ်ကို supply parts array ထဲမှာသိမ်းထားမည်။
/// `upper` လက်ရှိတွင်အသုံးမပြုသော်လည်း future ဆုံးဖြတ်ချက်မှအဆုံးသတ်မဟုတ်သောတန်ဖိုးများဖြစ်သည့် `inf` နှင့် `nan` ကိုပြောင်းလဲရန်ဆုံးဖြတ်ခဲ့သည်။
///
/// ပြန်ဆိုရမည့်အပိုင်းသည်အမြဲတမ်း `Part::Sign` ဖြစ်သည် (၎င်းသည်နိမိတ်လက္ခဏာမပြပါကကြိုးမျှင်တစ်ခုဖြစ်နိုင်သည်) ။
///
/// `format_shortest` နောက်ခံကိန်းဂဏန်း-မျိုးဆက် function ကိုဖြစ်သင့်သည်။
/// ၎င်းသည်၎င်းသည်အစပျိုးသည့်ကြားခံ၏အစိတ်အပိုင်းကိုပြန်ပေးသင့်သည်။
/// သငျသညျဖြစ်ကောင်းဤအဘို့အ `strategy::grisu::format_shortest` ချင်လိမ့်မယ်။
///
/// `frac_digits` `v` ရှိအမှန်တကယ်ဒfractionမကိန်းဂဏန်းအရေအတွက်ထက်နည်းနိုင်သည်။
/// ကလျစ်လျူရှုလိမ့်မည်နှင့်အပြည့်အဝဂဏန်းပုံနှိပ်လိမ့်မည်။၎င်းကိုဂဏန်းပြန်ဆိုပြီးနောက်နောက်ထပ်သုညပုံနှိပ်ရန်သာအသုံးပြုသည်။
/// ထို့ကြောင့် 0 of `frac_digits` သည်ဆိုလိုသည်မှာပေးထားသောဂဏန်းများနှင့်အခြားမည်သည့်အရာမျှမဆိုပုံနှိပ်နိုင်သည်။
///
/// byte buffer သည်အနည်းဆုံး `MAX_SIG_DIGITS` bytes အရှည်ရှိသင့်သည်။
/// `[+][0.][0000][2][0000]` နှင့် `[+][0.][0000][2][0000]` ကဲ့သို့အဆိုးဆုံးကိစ္စကြောင့်အနည်းဆုံး ၄ ပိုင်းရနိုင်သည်။
///
///
///
pub fn to_shortest_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);
    assert!(buf.len() >= MAX_SIG_DIGITS);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // လုံခြုံမှု-element `..1` ကိုစတင်ပါတယ်။
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // လုံခြုံမှု-element `..1` ကိုစတင်ပါတယ်။
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // လုံခြုံမှု-element `..2` ကိုစတင်ပါတယ်။
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // လုံခြုံမှု-element `..1` ကိုစတင်ပါတယ်။
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
        }
    }
}

/// ပေးထားသော floating point နံပါတ်ကိုဒီကိန်းဂဏန်းပေါ်မူတည်ပြီးဒformမပုံစံ (သို့) ထပ်ကိန်းပုံစံကို format လုပ်တယ်။
/// ပေးထားသော byte buffer ကို scratch တစ်ခုအနေဖြင့်အသုံးပြုနေစဉ်ရလဒ်ကို supply parts array ထဲမှာသိမ်းထားမည်။
/// `upper` Non-finite values (`inf` နှင့် `nan`) ဒါမှမဟုတ် exponent ရှေ့ဆက် (`e` သို့မဟုတ် `E`) ၏ဖြစ်ရပ်ကိုဆုံးဖြတ်ရန်အသုံးပြုသည်။
/// ပြန်ဆိုရမည့်အပိုင်းသည်အမြဲတမ်း `Part::Sign` ဖြစ်သည် (၎င်းသည်နိမိတ်လက္ခဏာမပြပါကကြိုးမျှင်တစ်ခုဖြစ်နိုင်သည်) ။
///
/// `format_shortest` နောက်ခံကိန်းဂဏန်း-မျိုးဆက် function ကိုဖြစ်သင့်သည်။
/// ၎င်းသည်၎င်းသည်အစပျိုးသည့်ကြားခံ၏အစိတ်အပိုင်းကိုပြန်ပေးသင့်သည်။
/// သငျသညျဖြစ်ကောင်းဤအဘို့အ `strategy::grisu::format_shortest` ချင်လိမ့်မယ်။
///
/// `dec_bounds` သည် `(lo, hi)` ရှုပ်ထွေးမှုတစ်ခုဖြစ်ပြီး၎င်းသည်နံပါတ်ကို `10^lo <= V < 10^hi` မှသာဒdecimalမအဖြစ်သတ်မှတ်သည်။
/// ဤအချက်သည် `v` အစား *သိသာသော*`V` ဖြစ်ကြောင်းသတိပြုပါ။ထို့ကြောင့်ထပ်ညွှန်းပုံစံဖြင့်ပုံနှိပ်ဖော်ပြသောထပ်ကိန်းသည်မည်သည့်ရှုပ်ထွေးမှုကိုမဆိုရှောင်ရှားရန်ဤအကွာအဝေးတွင်မရှိနိုင်ပါ။
///
///
/// byte buffer သည်အနည်းဆုံး `MAX_SIG_DIGITS` bytes အရှည်ရှိသင့်သည်။
/// `[+][1][.][2345][e][-][6]` ကဲ့သို့အဆိုးဆုံးကိစ္စကြောင့်အနည်းဆုံး ၆ ပိုင်းရနိုင်သည်။
///
///
///
///
///
pub fn to_shortest_exp_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    dec_bounds: (i16, i16),
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(dec_bounds.0 <= dec_bounds.1);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // လုံခြုံမှု-element `..1` ကိုစတင်ပါတယ်။
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // လုံခြုံမှု-element `..1` ကိုစတင်ပါတယ်။
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            parts[0] = if dec_bounds.0 <= 0 && 0 < dec_bounds.1 {
                MaybeUninit::new(Part::Copy(b"0"))
            } else {
                MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }))
            };
            // လုံခြုံမှု-element `..1` ကိုစတင်ပါတယ်။
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            let vis_exp = exp as i32 - 1;
            let parts = if dec_bounds.0 as i32 <= vis_exp && vis_exp < dec_bounds.1 as i32 {
                digits_to_dec_str(buf, exp, 0, parts)
            } else {
                digits_to_exp_str(buf, exp, 0, upper, parts)
            };
            Formatted { sign, parts }
        }
    }
}

/// ပေးထားသောဒီကုဒ်နံပါတ်မှတွက်ချက်ထားသည့်အမြင့်ဆုံးကြားခံပမာဏအတွက်မဟုတ်ဘဲရေနံစိမ်းခန့်မှန်းခြင်း (အပေါ်ဆုံး) ကိုပြန်ပို့သည်။
///
/// အတိအကျကန့်သတ်ချက်မှာ
///
/// - `exp < 0` တွင်အများဆုံးအရှည်မှာ `ceil(log_10 (5^-exp * (2^64 - 1)))` ဖြစ်သည်။
/// - `exp >= 0` တွင်အများဆုံးအရှည်မှာ `ceil(log_10 (2^exp * (2^64 - 1)))` ဖြစ်သည်။
///
/// `ceil(log_10 (x^exp * (2^64 - 1)))` `ceil(log_10 (2^64 - 1)) + ceil(exp *log_10 x)` ထက်နည်းသည်၊ `20 + (1 + exp* log_10 x)` ထက်နည်းသည်။
/// ကျွန်ုပ်တို့၏ရည်ရွယ်ချက်များအတွက်လုံလောက်သောအချက်အလက်များ `log_10 2 < 5/16` နှင့် `log_10 5 < 12/16` ကိုကျွန်ုပ်တို့အသုံးပြုသည်။
///
/// ဒါကိုကျွန်တော်တို့ဘာလို့လိုတာလဲ။`format_exact` လုပ်ဆောင်ချက်များသည်နောက်ဆုံးဂဏန်းကန့်သတ်ချက်ဖြင့်ကန့်သတ်မထားပါက buffer တစ်ခုလုံးကိုဖြည့်ပေးလိမ့်မည်။ သို့သော်တောင်းဆိုသောဂဏန်းအရေအတွက်မှာရယ်စရာကောင်းလောက်သည် (ဥပမာ-ဂဏန်းပေါင်း ၃၀,၀၀၀) ။
///
/// Buffer အများစုမှာသုညတွေနဲ့ပြည့်နေလိမ့်မယ်။ ဒါကြောင့်ကျွန်တော်တို့ buffer အားလုံးကိုကြိုတင်ခွဲဝေချထားပေးချင်တယ်။
/// အကျိုးဆက်အား၊
/// `f64` အတွက်ကြားခံ၏ 826 bytes သည်လုံလောက်သင့်သည်။၎င်းကိုအဆိုးရွားဆုံးသောနံပါတ်နှင့်နှိုင်းယှဉ်ကြည့်ပါက ၇၇၀ bytes (သည့်အခါ `exp = -1074`) ။
///
///
///
///
///
fn estimate_max_buf_len(exp: i16) -> usize {
    21 + ((if exp < 0 { -12 } else { 5 } * exp as i32) as usize >> 4)
}

/// Formats သည်ထူးခြားသောဂဏန်းအရေအတွက်အတိအကျဖြင့်ထပ်ကိန်းပုံစံသို့ floating point နံပါတ်ကိုပေးထားသည်။
/// ပေးထားသော byte buffer ကို scratch တစ်ခုအနေဖြင့်အသုံးပြုနေစဉ်ရလဒ်ကို supply parts array ထဲမှာသိမ်းထားမည်။
/// `upper` ထပ်ကိန်းရှေ့ဆက် (`e` သို့မဟုတ် `E`) ၏ဖြစ်ရပ်ကိုဆုံးဖြတ်ရန်အသုံးပြုသည်။
/// ပြန်ဆိုရမည့်အပိုင်းသည်အမြဲတမ်း `Part::Sign` ဖြစ်သည် (၎င်းသည်နိမိတ်လက္ခဏာမပြပါကကြိုးမျှင်တစ်ခုဖြစ်နိုင်သည်) ။
///
/// `format_exact` နောက်ခံကိန်းဂဏန်း-မျိုးဆက် function ကိုဖြစ်သင့်သည်။
/// ၎င်းသည်၎င်းသည်အစပျိုးသည့်ကြားခံ၏အစိတ်အပိုင်းကိုပြန်ပေးသင့်သည်။
/// သငျသညျဖြစ်ကောင်းဤအဘို့အ `strategy::grisu::format_exact` ချင်လိမ့်မယ်။
///
/// `ndigits` သည်ကြီးမားလွန်းသဖြင့်သတ်မှတ်ထားသောနံပါတ်များကိုသာအမြဲတမ်းရေးသားလိမ့်မည်မဟုတ်လျှင် byte buffer သည်အနည်းဆုံး `ndigits` bytes အရှည်ဖြစ်သည်။
/// (`f64` အတွက် tipping point သည် 800 ခန့်ရှိသောကြောင့် 1000 bytes လုံလောက်စွာရှိသင့်သည်။) `[+][1][.][2345][e][-][6]` ကဲ့သို့အဆိုးဆုံးအခြေအနေကြောင့်အနည်းဆုံးအစိတ်အပိုင်း ၆ ခုရသင့်သည်။
///
///
///
///
///
pub fn to_exact_exp_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    ndigits: usize,
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(ndigits > 0);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // လုံခြုံမှု-element `..1` ကိုစတင်ပါတယ်။
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // လုံခြုံမှု-element `..1` ကိုစတင်ပါတယ်။
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if ndigits > 1 {
                // [0.][0000][e0]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(ndigits - 1));
                parts[2] = MaybeUninit::new(Part::Copy(if upper { b"E0" } else { b"e0" }));
                Formatted {
                    sign,
                    // လုံခြုံမှု-element `..3` ကိုစတင်ပါတယ်။
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }));
                Formatted {
                    sign,
                    // လုံခြုံမှု-element `..1` ကိုစတင်ပါတယ်။
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= ndigits || buf.len() >= maxlen);

            let trunc = if ndigits < maxlen { ndigits } else { maxlen };
            let (buf, exp) = format_exact(decoded, &mut buf[..trunc], i16::MIN);
            Formatted { sign, parts: digits_to_exp_str(buf, exp, ndigits, upper, parts) }
        }
    }
}

/// ဒသမကိန်းဂဏန်းအတိအကျနှင့်အတူဒatingမပုံစံသို့ floating point နံပါတ်ပေးထားသောအမျိုးအစားများ။
/// ပေးထားသော byte buffer ကို scratch တစ်ခုအနေဖြင့်အသုံးပြုနေစဉ်ရလဒ်ကို supply parts array ထဲမှာသိမ်းထားမည်။
/// `upper` လက်ရှိတွင်အသုံးမပြုသော်လည်း future ဆုံးဖြတ်ချက်မှအဆုံးသတ်မဟုတ်သောတန်ဖိုးများဖြစ်သည့် `inf` နှင့် `nan` ကိုပြောင်းလဲရန်ဆုံးဖြတ်ခဲ့သည်။
/// ပြန်ဆိုရမည့်အပိုင်းသည်အမြဲတမ်း `Part::Sign` ဖြစ်သည် (၎င်းသည်နိမိတ်လက္ခဏာမပြပါကကြိုးမျှင်တစ်ခုဖြစ်နိုင်သည်) ။
///
/// `format_exact` နောက်ခံကိန်းဂဏန်း-မျိုးဆက် function ကိုဖြစ်သင့်သည်။
/// ၎င်းသည်၎င်းသည်အစပျိုးသည့်ကြားခံ၏အစိတ်အပိုင်းကိုပြန်ပေးသင့်သည်။
/// သငျသညျဖြစ်ကောင်းဤအဘို့အ `strategy::grisu::format_exact` ချင်လိမ့်မယ်။
///
/// `frac_digits` ဤမျှကြီးမားလွန်းသဖြင့်ကိန်းဂဏန်းများကိုသတ်မှတ်ထားသောနံပါတ်များကိုသာရေးသားလိမ့်မည်မဟုတ်လျှင် byte buffer သည် output အတွက်လုံလောက်သည်။
/// (`f64` အတွက် tipping point သည် 800 ခန့်ရှိပြီး 1000 bytes လောက်ရှိသင့်သည်။) X0XX နှင့်အဆိုးဆုံးအဖြစ် X0XX ကဲ့သို့အနည်းဆုံးအစိတ်အပိုင်း ၄ ခုရရှိနိုင်သည်။
///
///
///
///
///
pub fn to_exact_fixed_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // လုံခြုံမှု-element `..1` ကိုစတင်ပါတယ်။
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // လုံခြုံမှု-element `..1` ကိုစတင်ပါတယ်။
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // လုံခြုံမှု-element `..2` ကိုစတင်ပါတယ်။
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // လုံခြုံမှု-element `..1` ကိုစတင်ပါတယ်။
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= maxlen);

            // ဒါကြောင့် * `frac_digits` ရယ်စရာကြီးမားသောကြောင်းဖြစ်နိုင်ပါတယ်။
            // `format_exact` ဤအမှု၌ဂဏန်းများကို rendering အဆုံးသတ်သွားလိမ့်မည်။ အဘယ်ကြောင့်ဆိုသော်ကျွန်ုပ်တို့သည် `maxlen` ကန့်သတ်ချက်ရှိသောကြောင့်ဖြစ်သည်။
            //
            let limit = if frac_digits < 0x8000 { -(frac_digits as i16) } else { i16::MIN };
            let (buf, exp) = format_exact(decoded, &mut buf[..maxlen], limit);
            if exp <= limit {
                // ကန့်သတ်ချက်ကိုမလိုက်နာနိုင်ပါ၊ ထို့ကြောင့် `exp` မည်သို့ပင်ဖြစ်ပါစေယင်းသည်သုညကဲ့သို့ပြန်ဆိုသင့်သည်။
                // ၎င်းတွင်ကန့်သတ်ချုပ်နှောင်ခြင်းကိုနောက်ဆုံးအပြီးသတ်မှသာလိုက်နာသောအမှုမပါ ၀ င်ပါ။၎င်းသည် `exp = limit + 1` နှင့်ပုံမှန်ကိစ္စဖြစ်သည်။
                //
                debug_assert_eq!(buf.len(), 0);
                if frac_digits > 0 {
                    // [0.][0000]
                    parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                    parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                    Formatted {
                        sign,
                        // လုံခြုံမှု-element `..2` ကိုစတင်ပါတယ်။
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                    }
                } else {
                    parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                    Formatted {
                        sign,
                        // လုံခြုံမှု-element `..1` ကိုစတင်ပါတယ်။
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                    }
                }
            } else {
                Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
            }
        }
    }
}