//! "Floating-Point နံပါတ်များကိုလျင်မြန်စွာနှင့်တိကျမှန်ကန်စွာပုံနှိပ်ခြင်း" ပုံ ၃ ၏တိုက်ရိုက် (သို့သော်အနည်းငယ်ပိုကောင်းသော) Rust ဘာသာပြန်ချက်။
//!
//!
//! [^1]: Burger, RG နှင့် Dybvig, RK 1996. floating-point နံပါတ်များကိုပုံနှိပ်ခြင်း
//!   လျင်မြန်စွာနှင့်တိကျစွာ။SIGPLAN မဟုတ်။31, 5 (မေလ။ 1996), 108-116 ။

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// 10 ^ အတွက် `Digit`s အတွက်ကြိုတင်တွက်ချက်ထားသည့် Array များ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// တဲ့အခါမှာ `x < 16 * scale` သာအသုံးဝင်သော;`scaleN` `scale.mul_small(N)` ဖြစ်သင့်သည်
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Dragon အတွက်အတိုဆုံး mode အကောင်အထည်ဖော်မှု။
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // format လုပ်ဖို့ `v` နံပါတ်ဖြစ်ကြောင်းလူသိများသည်:
    // - `mant * 2^exp` နှင့်ညီသည်;
    // - မူရင်းအမျိုးအစားအတွက် `(mant - 2 *minus)* 2^exp` အားဖြင့်ရှေ့ပြေး;နှင့်
    // - မူရင်းအမျိုးအစားအတွက် `(mant + 2 *plus)* 2^exp` အားဖြင့်နောက်သို့လိုက်ကြ၏။
    //
    // သိသာစွာ `minus` နှင့် `plus` သည်သုညမဖြစ်နိုင်ပါ။အနည်းဆုံးဂဏန်းတစ်ခုကိုထုတ်ပေးသည်။ ဆိုလိုသည်မှာ `mant` သည်လည်းသုညမဖြစ်နိုင်ပါ။
    //
    // ဆိုလိုသည်မှာ `low = (mant - minus)*2^exp` နှင့် `high = (mant + plus)* 2^exp` အကြားမည်သည့်ကိန်းဂဏန်းမဆိုကိန်းဂဏန်းအတိအကျကိုဖော်ပြပေးမည်ဖြစ်ပြီးမူလ mantissa ပင် (ဥပမာ-`!mant_was_odd`) ဖြစ်ချိန်ကန့်သတ်ချက်များပါဝင်သည်။
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` `if d.inclusive {a <= b} else {a < b}` ဖြစ်သည်
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // `10^(k_0-1) < high <= 10^(k_0+1)` ကျေနပ်အောင်မူရင်းသွင်းအားစုမှ `k_0` ခန့်မှန်း။
    // `10^(k-1) < high <= 10^k` ကျေနပ်နှစ်သိမ့်သော `k` ကိုနောက်ပိုင်းတွက်ချက်သည်။
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // `{mant, plus, minus} * 2^exp` ကိုအပိုင်းအစပုံစံအဖြစ်ပြောင်းလဲပါ။
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // `10^k` အားဖြင့် `mant` ဝေယူ။ယခု `scale / 10 < mant + plus <= scale * 10` ။
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // fixup သည့်အခါ `mant + plus > scale` (သို့မဟုတ် `>=`) ။
    // ကျွန်ုပ်တို့သည် `scale` ကိုအမှန်တကယ်ပြုပြင်ခြင်းမဟုတ်ပါ၊ ကန ဦး မြှောက်ခြင်းကိုအစားထိုးနိုင်သည်။
    // ယခု `scale < mant + plus <= scale * 10` နှင့်ကျွန်ုပ်တို့သည်ဂဏန်းများထုတ်လုပ်ရန်အဆင်သင့်ဖြစ်သည်။
    //
    // `d[0]` * သည် `scale - plus < mant < scale` ဖြစ်သည့်အခါသုညဖြစ်နိုင်သည်ကိုသတိပြုပါ။
    // ဤကိစ္စတွင် rounding-up အခြေအနေ (အောက်တွင်ဖော်ပြထားသော `up`) ကိုချက်ချင်းအစပျိုးလိမ့်မည်။
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // 10 `scale` ချုံ့ချဲ့ညီမျှ
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // ဂဏန်းမျိုးဆက်များအတွက် cache ကို `(2, 4, 8) * scale` ။
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // `d[0..n-1]` သည်ယခုအချိန်အထိထုတ်လုပ်ထားသောဂဏန်းများဖြစ်သည်။
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (အရှင် `mant / scale < 10`) ရှိရာ `d[i..j]` `ဃ [i] * 10 ^ (JI) + များအတွက်အတိုကောက်ဖြစ်ပါတယ် ...
        // + ဃ [ည-1] * 10 + d[j]` ။

        // ဂဏန်းတစ်ခုထုတ်ပေး: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // ဤသည်မှာပြုပြင်ထားသော Dragon algorithm ၏ရိုးရှင်းသောဖော်ပြချက်ဖြစ်သည်။
        // များစွာသောအလယ်အလတ်အနကျအဓိပ်ပါယျနှင့်ပြည့်စုံအငြင်းပွားမှုများအဆင်ပြေဘို့ချန်လှပ်ထားပါသည်။
        //
        // `n` ကိုကျွန်တော် update လုပ်ခဲ့သည့်အတိုင်းပြုပြင်ထားသော invariants ဖြင့်စတင်ပါ။
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // `d[0..n-1]` သည် `low` နှင့် `high` ကြားတွင်အတိုဆုံးကိုယ်စားပြုမှုဖြစ်သည်ဟုယူဆပါ။ ဆိုလိုသည်မှာ `d[0..n-1]` သည်အောက်ပါနှစ်ခုစလုံးကိုကျေနပ်သော်လည်း `d[0..n-2]` ကမူမပေးနိုင်ပါ။
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (Biectivity: `v` အထိဂဏန်းများ);နှင့်
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (နောက်ဆုံးဂဏန်းမှန်ကန်သော)
        //
        // ဒုတိယအခွအေနေ `2 * mant <= scale` မှရိုးရှင်းစွာ။
        // လျော့ကျသွားမည်ဖြစ်ခြင်း `mant`, `low` နှင့် `high` ၏စည်းကမ်းချက်များ၌ဖြေရှင်းခြင်းကပထမအခြေအနေ၏ရိုးရိုးရှင်းရှင်းပုံစံဖြစ်သည်။ `-plus < mant < minus`.
        // `-plus < 0 <= mant` ကစပြီး `mant < minus` နဲ့ `2 * mant <= scale` တို့မှာတိုတောင်းတဲ့အတိုဆုံးကိုယ်စားပြုမှုရှိတယ်။
        // (ယခင် mantissa ပင်ဖြစ်လျှင် `mant <= minus` ဖြစ်လာသည်။)
        //
        // ဒုတိယ (`2 * mant> scale`) မကိုင်ပါကနောက်ဆုံးဂဏန်းကိုတိုးရန်လိုသည်။
        // ၎င်းသည်ထိုအခြေအနေကိုပြန်လည်ထူထောင်ရန်အတွက်လုံလောက်ပါသည်။ ဂဏန်းမျိုးဆက်သည် `0 <= v / 10^(k-n) - d[0..n-1] < 1` ကိုအာမခံသည်ကိုကျွန်ုပ်တို့သိပြီးဖြစ်သည်
        // ဤကိစ္စတွင်ပထမ ဦး ဆုံးအခွအေနေ `-plus < mant - scale < minus` ဖြစ်လာသည်။
        // `mant < scale` ကတည်းကမျိုးဆက်နောက်မှာငါတို့မှာ `scale < mant + plus` ရှိတယ်။
        // (မူလ mantissa ပင်ဖြစ်လျှင် `scale <= mant + plus` ဖြစ်လာသည်။)
        //
        // တိုတိုပြောရရင်:
        // - `mant < minus` (သို့မဟုတ် `<=`) ရှိသည့်အခါ `down` ကိုရပ်တန့်ပြီးပတ်ပတ်လည်တွင်ကြည့်ပါ။
        // - လာသောအခါ `scale < mant + plus` (သို့မဟုတ် `<=`) `up` (နောက်ဆုံးဂဏန်းတိုးမြှင့်) ကိုရပ်တန့်နှင့်ပတ်ပတ်လည်။
        // - မဟုတ်ရင်ထုတ်လုပ်စောင့်ရှောက်လော့။
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // ကျနော်တို့ကအတိုဆုံးကိုယ်စားပြုမှုရှိသည်, ထို rounding မှဆက်လက်ဆောင်ရွက်

        // လျော့ပါးသွားမည်ဖြစ်သလို restore ။
        // ၎င်းသည် algorithm ကိုအမြဲအဆုံးသတ်စေသည်။ `minus` နှင့် `plus` သည်အမြဲတမ်းတိုးများလာသည်၊ သို့သော် `mant` ကို modulo `scale` နှင့် `scale` ကိုပြုပြင်သည်။
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // i) rounding-up အခြေအနေပေါ်ပေါက်လာသောအခါ (၂) အခြေအနေနှစ်ခုစလုံးကိုဖြစ်ပေါ်စေပြီးလည်ပတ်ခြင်းကိုပိုမိုနှစ်သက်သည်။
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // rounding up သည်အရှည်ကိုပြောင်းလဲမယ်ဆိုရင်ထပ်ကိန်းလည်းပြောင်းသင့်တယ်။
        // ဤအခြေအနေသည်ကျေနပ်လောက်ရန်ခက်ခဲ (ဖြစ်နိုင်ခြေမရှိ) ဖြစ်နိုင်သည်ဟုထင်ရသော်လည်းကျွန်ုပ်တို့ဒီမှာလုံခြုံမှုရှိပြီးပုံမှန်ဖြစ်သည်။
        //
        // လုံခြုံမှု-အထက်ပါမှတ်ဉာဏ်ကိုကျွန်ုပ်တို့စတင်ခဲ့သည်။
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // လုံခြုံမှု-အထက်ပါမှတ်ဉာဏ်ကိုကျွန်ုပ်တို့စတင်ခဲ့သည်။
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Dragon အတွက်တိကျသောနှင့်ပုံသေ mode ကိုအကောင်အထည်ဖော်မှု။
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // `10^(k_0-1) < v <= 10^(k_0+1)` ကျေနပ်မူရင်းသွင်းအားစုများအနေဖြင့် `k_0` ခန့်မှန်း။
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // `10^k` အားဖြင့် `mant` ဝေယူ။ယခု `scale / 10 < mant <= scale * 10` ။
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // fix ဘယ်အချိန်မှာ `mant + plus >= scale`, ဘယ်မှာ `plus / scale = 10^-buf.len() / 2` fixup ။
    // ပုံသေအရွယ်အစား bignum ကိုထိန်းသိမ်းရန် `mant + floor(plus) >= scale` ကိုကျွန်ုပ်တို့အမှန်တကယ်အသုံးပြုသည်။
    // ကျွန်ုပ်တို့သည် `scale` ကိုအမှန်တကယ်ပြုပြင်ခြင်းမဟုတ်ပါ၊ ကန ဦး မြှောက်ခြင်းကိုအစားထိုးနိုင်သည်။
    // ထပ်မံ၍ အတိုဆုံးသော algorithm ဖြင့် `d[0]` သည်သုညဖြစ်သော်လည်းနောက်ဆုံးတွင်တက်လိမ့်မည်။
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // 10 `scale` ချုံ့ချဲ့ညီမျှ
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // အကယ်၍ ကျွန်ုပ်တို့သည်နောက်ဆုံးဂဏန်းကန့်သတ်ချက်နှင့်အလုပ်လုပ်နေပါက၊ နှစ်ဆထပ်ခြင်းမှရှောင်ရှားရန်အတွက်အမှန်တကယ်ပြန်ဆိုခြင်းမပြုမီကြားခံကိုအတိုကောက်လိုသည်။
    //
    // rounding up ဖြစ်သည့်အခါကျွန်ုပ်တို့သည် buffer ကိုထပ်မံတိုးရန်လိုသည်ကိုသတိပြုပါ။
    let mut len = if k < limit {
        // အိုး၊ ဂဏန်း * တစ်လုံးတောင်မှမထုတ်လုပ်နိုင်ဘူး။
        // ကျွန်တော်တို့မှာ 9.5 လိုတစ်ခုခုရပြီး ၁၀ ကိုဝိုင်းလိုက်တဲ့အခါဒါဖြစ်နိုင်တယ်။
        // ကျနော်တို့ `k == limit` သည့်အခါဖြစ်ပေါ်ခြင်းနှင့်အတိအကျဂဏန်းတစျခုထုတ်လုပ်ရန်ဖို့ဖြစ်သည့်နောက်ပိုင်းတွင် rounding-up, အမှု၏ချွင်းချက်နှင့်အတူတစ် ဦး အချည်းနှီးသောကြားခံပြန်သွားပါ။
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // ဂဏန်းမျိုးဆက်များအတွက် cache ကို `(2, 4, 8) * scale` ။
        // (ဒီဟာစျေးကြီးတယ်၊ ဒါကြောင့်ကြားခံမဲ့ဖြစ်နေရင်သူတို့ကိုမတွက်ပါနဲ့။)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // အောက်ပါဂဏန်းအားလုံးသည်သုညဖြစ်သည်။ ဤတွင်ရပ်သည်။အစား, ကျန်ရှိသောဂဏန်းဖြည့်ပါ။
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // လုံခြုံမှု-အထက်ပါမှတ်ဉာဏ်ကိုကျွန်ုပ်တို့စတင်ခဲ့သည်။
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // အောက်ပါဂဏန်းများသည်အတိအကျ ၅၀၀၀ ဖြစ်ပါကဂဏန်းအလယ်၌ရပ်ပါကမြှောက်ပါကကြိုတင်ဂဏန်းကိုစစ်ဆေး။ အမြှောက်သို့ပြန်လှည့်ပါ။
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // လုံခြုံမှု-`buf[len-1]` ကိုအစပြုထားသည်။
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // rounding up သည်အရှည်ကိုပြောင်းလဲမယ်ဆိုရင်ထပ်ကိန်းလည်းပြောင်းသင့်တယ်။
        // ဒါပေမယ့်ကျွန်တော်တို့ကသတ်မှတ်ထားတဲ့ဂဏန်းအရေအတွက်ကိုတောင်းခံထားတယ်၊ ဒါကြောင့်ကြားခံကိုမပြောင်းပါနဲ့ ...
        // လုံခြုံမှု-အထက်ပါမှတ်ဉာဏ်ကိုကျွန်ုပ်တို့စတင်ခဲ့သည်။
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... အစားထိုးသတ်မှတ်ထားသောတိကျမှန်ကန်မှုကိုတောင်းခံခြင်းမရှိပါက။
            // မူရင်းကြားခံအချည်းနှီးဖြစ်ခဲ့ပါက `k == limit` (edge ကိစ္စ) မှသာဂဏန်းအပိုထပ်ထည့်နိုင်သည်ကိုကျွန်ုပ်တို့စစ်ဆေးရန်လိုသည်။
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // လုံခြုံမှု-အထက်ပါမှတ်ဉာဏ်ကိုကျွန်ုပ်တို့စတင်ခဲ့သည်။
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}