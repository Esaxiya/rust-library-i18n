//! အဓိကကျတဲ့ကဏ္ဍအမျိုးအစားများမှပြောင်းလဲခြင်းများအတွက်အမျိုးအစားများကိုအမှား။

use crate::convert::Infallible;
use crate::fmt;

/// တစ် ဦး check လုပ်ထားအရေးပါသောအမျိုးအစားပြောင်းလဲခြင်းပျက်ကွက်သည့်အခါအမှားအမျိုးအစားပြန်လာ၏။
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // အထက်ပါ `From<Infallible> for TryFromIntError` ကဲ့သို့သောကုဒ်များသည် `Infallible` `!` ၏နာမည်ပြောင်ဖြစ်လာသည့်အခါဆက်လက်အလုပ်လုပ်နေစေရန်သေချာအောင်လုပ်ပါ။
        //
        //
        match never {}
    }
}

/// တစ်ခုကိန်းတစ်ခုစစ်တမ်းကောက်သောအခါပြန်လာနိုင်သည့်အမှားတစ်ခု။
///
/// ဤအမှားသည် [`i8::from_str_radix`] ကဲ့သို့သောအစပြုကိန်းအမျိုးအစားများအတွက် `from_str_radix()` လုပ်ဆောင်ချက်များအတွက်အမှားအမျိုးအစားအဖြစ်အသုံးပြုသည်။
///
/// # ဖြစ်နိုင်ခြေရှိသောအကြောင်းရင်းများ
///
/// ကစံ input ကိုမှရရှိသောအခါကအခြားအကြောင်းတရားများအနက် `ParseIntError` ကြောင့် string ကိုဥပမာအတွက်ဦးဆောင်သို့မဟုတ်ကပ်တွယ်မှုကိုကြားနေရာလွတ်၏ခြွငျးကိုခံရနိုင်ပါတယ်။
///
/// [`str::trim()`] နည်းလမ်းကိုအသုံးပြုခြင်းအားဖြင့်ခွဲခြမ်းစိတ်ဖြာခြင်းမပြုမီ whitespace မရှိတော့ပါ။
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// အပြည့်အစုံကို parsing ပျက်ပြားစေသည့်အမှားအယွင်းအမျိုးမျိုးကိုသိမ်းဆည်းရန် Enum ။
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// ခွဲခြမ်းစိတ်ဖြာတန်ဖိုးကိုဗလာ။
    ///
    /// အခြားအကြောင်းတရားများအနက်, ဒီမူကွဲတစ်ခုအချည်းနှီးသော string ကိုခွဲခြမ်းစိတ်ဖြာသည့်အခါတည်ဆောက်လိမ့်မည်။
    Empty,
    /// ၎င်း၏အခြေအနေတွင်မမှန်ကန်တဲ့ဂဏန်းပါရှိသည်။
    ///
    /// အခြားအကြောင်းတရားများအနက် ASCII char မဟုတ်သော string တစ်ခုကိုခွဲခြမ်းစိတ်ဖြာသောအခါဤမူကွဲကိုတည်ဆောက်လိမ့်မည်။
    ///
    /// `+` (သို့) `-` ကို string တစ်ခုထဲမှာသူ့ဟာသူဒါမှမဟုတ်နံပါတ်အလယ်မှာနေရာချတဲ့အခါမှာဒီမူကွဲကိုတည်ဆောက်ပါတယ်။
    ///
    ///
    InvalidDigit,
    /// Integer ဟာကြီးမားတဲ့ပစ်မှတ်ကိန်းအမျိုးအစားထဲမှာသိုလှောင်ဖို့သိပ်ကြီးလွန်းတယ်။
    PosOverflow,
    /// integer type ကို integer ဖြစ်တဲ့အတွက်ပစ်မှတ်ထဲမှာသိမ်းထားဖို့လည်းသေးငယ်သည်။
    NegOverflow,
    /// တန်ဖိုးသုညဖြစ်ခဲ့သည်
    ///
    /// ခွဲခြမ်းစိတ်ဖြာခြင်း string ကိုသုညတန်ဖိုးရှိသည့်အခါဤမူကွဲထုတ်လွှတ်လိမ့်မည်, ဒါကသုညမဟုတ်သောအမျိုးအစားများအတွက်တရားမဝင်လိမ့်မည်။
    ///
    Zero,
}

impl ParseIntError {
    /// တစ်ခုကိန်းပျက်ကွက်မှု၏အသေးစိတ်အကြောင်းရင်းထုတ်ပေးသည်။
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}