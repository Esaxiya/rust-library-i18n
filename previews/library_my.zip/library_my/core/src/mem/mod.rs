//! မှတ်ဉာဏ်နှင့်ဆက်ဆံရာတွင်အခြေခံလုပ်ဆောင်ချက်များ။
//!
//! ဒီမော်ဂျူး, အမျိုးအစားများ၏အရွယ်အစားနှင့် alignment ကို querying စတင်လုပ်ဆောင်ခြင်းနှင့်မှတ်ဉာဏ်ကြိုးကိုင်အတွက် function ပါရှိသည်။
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// ပိုင်ဆိုင်မှုနှင့် "forgets" ကိုတန်ဖိုးနှင့် ပတ်သက်၍ ယူသည်။ ၎င်း၏ပျက်စီးခြင်းကိုမ run ဘဲ ** ။
///
/// မဆိုအရင်းအမြစ်များကိုတန်ဖိုးထိုကဲ့သို့သောအမှိုက်ပုံမှတ်ဉာဏ်သို့မဟုတ်ဖိုင်တစ်ဖိုင်လက်ကိုင်အဖြစ်, စီမံခန့်ခွဲတစ်ခုလက်လှမ်းမမှီပါပြည်နယ်အတွက်အစဉ်အမြဲနေရစ်ပါလိမ့်မယ်။သို့သော်၊ ဤမှတ်ဉာဏ်မှညွှန်ပြသူများဆက်လက်တည်ရှိနေမည်ကိုအာမမခံပါ။
///
/// * သငျသညျမှတျဉာဏျပေါက်ကြားလိုပါက [`Box::leak`] ကြည့်ပါ။
/// * သင်မှတ်ဉာဏ်တစ်ကုန်ကြမ်း pointer ကိုရယူလိုလျှင် [`Box::into_raw`] ကြည့်ပါ။
/// * အကယ်၍ သင်သည်တန်ဖိုးတစ်ခုကိုစနစ်တကျဖယ်ရှားလိုလျှင်၎င်းကိုဖျက်ဆီးခြင်းကို run ပါက [`mem::drop`] ကိုကြည့်ပါ။
///
/// # Safety
///
/// `forget` `unsafe` ဟုမသတ်မှတ်ပါ၊ အဘယ်ကြောင့်ဆိုသော် Rust ၏ဘေးကင်းလုံခြုံမှုအာမခံချက်များတွင်ဖျက်စက်များအမြဲတမ်းလည်ပတ်မည့်အာမခံချက်မပါဝင်သောကြောင့်ဖြစ်သည်။
/// ဥပမာအားဖြင့်, program တစ်ခု [`Rc`][rc] သုံးပြီးရည်ညွှန်းသံသရာဖန်တီးနိုင်ပါတယ်, ဒါမှမဟုတ် destructors running မရှိဘဲထွက်ပေါက်မှ [`process::exit`][exit] ခေါ်ဆိုပါ။
/// ထို့ကြောင့်လုံခြုံကုဒ်ကနေ `mem::forget` ခွင့်ပြုအခြေခံကျကျ Rust ရဲ့ဘေးကင်းလုံခြုံမှုအာမခံချက်မပြောင်းပါဘူး။
///
/// ထိုကဲ့သို့သောမှတ်ဉာဏ်သို့မဟုတ် I/O အရာဝတ္ထုအဖြစ်အရင်းအမြစ်များကိုပေါက်ကြားများသောအားဖြင့်မလိုလားအပ်သောဖြစ်ပါတယ်ဟုပြောသည်။
/// FFI သို့မဟုတ်အန္တရာယ်ကင်းသောကုဒ်များအတွက်အထူးအသုံးပြုမှုကိစ္စများတွင်လိုအပ်ချက်ပေါ်လာသည်၊ သို့သော်ထိုအချိန်တွင်ပင် [`ManuallyDrop`] သည်ပုံမှန်အားဖြင့်ပိုမိုနှစ်သက်သည်။
///
/// တန်ဖိုးတစ်ခုကိုမေ့သွားသောကြောင့်သင်ရေးထားသောမည်သည့် `unsafe` code မဆိုဤဖြစ်နိုင်ခြေကိုခွင့်ပြုရမည်။သင်တစ်ဦးတန်ဖိုးကိုပြန်လာနှင့်ခေါ်ဆိုသူ၏သေချာပေါက်တန်ဖိုးရဲ့ destructor run လိမ့်မည်ဟုမျှော်လင့်ထားလို့မရပါဘူး။
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// `mem::forget` ၏ canonical လုံခြုံအသုံးပြုမှု `Drop` trait အားဖြင့်အကောင်အထည်ဖော်နေတဲ့တန်ဖိုးကရဲ့ destructor ကျော်လွှားဖို့ဖြစ်ပါတယ်။ဥပမာအားဖြင့်, ဒီ `File`, ဆိုလိုသည်မှာပေါက်ကြားပါလိမ့်မယ်
/// အဆိုပါ variable ကိုယူအာကာသပေမယ့်ဘယ်တော့မှမနီးစပ်နောက်ခံစနစ်အားအရင်းအမြစ်ပြန်လည်:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// နောက်ခံအရင်းအမြစ်များ၏ပိုင်ဆိုင်မှုသည်ယခင်ကကို C ကုဒ်ဖို့ကုန်ကြမ်းဖိုင် descriptor ကိုထုတ်လွှင့်ခြင်းဖြင့်ဥပမာအားဖြင့်, Rust ၏ code ကိုအပြင်ဘက်သို့ပြောင်းရွှေ့ခံခဲ့ရသည်သောအခါဤအသုံးဝင်သည်။
///
/// # `ManuallyDrop` နှင့်အတူ relationship
///
/// *Memory* ပိုင်ဆိုင်မှုကိုလွှဲပြောင်းရန် `mem::forget` ကိုသုံးနိုင်သော်လည်းအမှားပြုလေ့ရှိသည်။
/// [`ManuallyDrop`] အစားကိုအသုံးပြုရပါမည်။ဥပမာဒီကုဒ်ကိုစဉ်းစားပါ။
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // `v` ၏မာတိကာကို အသုံးပြု၍ `String` ကိုတည်ဆောက်ပါ
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // ယင်း၏မှတ်ဉာဏ်ယခု `s` ကစီမံခန့်ခွဲသောကြောင့် `v` ပေါက်ကြား
/// mem::forget(v);  // အမှား, v မမှန်ကန်နှင့်တစ်ဦး function ကိုမှမရောက်ရဘဲရမယ်
/// assert_eq!(s, "Az");
/// // `s` လုံးလုံးလြားလြားကျဆင်းသွားနှင့်၎င်း၏မှတ်ဉာဏ် deallocated ဖြစ်ပါတယ်။
/// ```
///
/// အပေါ်ကဥပမာနဲ့ပြissuesနာနှစ်ခုရှိတယ်။
///
/// * ပိုပြီးကုဒ် `String` ၏ဆောက်လုပ်ရေးနှင့် `mem::forget()` ၏ invocation အကြားကဆက်ပြောသည်ကြသည်မှန်လျှင်အတူတူပင်မှတ်ဉာဏ် `v` နှင့် `s` နှစ်ဦးစလုံးအားဖြင့်ကိုင်တွယ်သည်ကို ထောက်. , ကအတွင်း panic နှစ်ဆအခမဲ့ဖြစ်ပေါ်စေလိမ့်မယ်။
/// * `v.as_mut_ptr()` ခေါ်ဆိုနှင့် `s` ဖို့အချက်အလက်များ၏ပိုင်ဆိုင်မှုထုတ်လွှင့်ပြီးနောက်, `v` တန်ဖိုးကိုမှားနေပါသည်။
/// တန်ဖိုးရုံ (ကစစ်ဆေးခြင်းမည်မဟုတ်သည့်) `mem::forget` သို့ပြောင်းရွှေ့နေသည်တောင်မှအခါ, အချို့အမျိုးအစားများ dangling သို့မဟုတ်မရှိတော့ပိုင်ဆိုင်သည့်အခါသူတို့ကိုညျြးစေသူတို့ရဲ့တန်ဖိုးများအပေါ်တင်းကျပ်သောလိုအပ်ချက်များကိုရှိသည်။
/// မတူညီသောတန်ဖိုးများကိုမည်သည့်နည်းနှင့်မဆိုအသုံးပြုခြင်း၊ ၎င်းတို့ထံလွှဲပြောင်းခြင်း (သို့) ၄ င်းတို့ကို functions များမှပြန်ပို့ခြင်းများအပါအ ၀ င် undefined behavior and compiler ရဲ့ယူဆချက်ကိုချိုးဖျက်နိုင်ပါတယ်။
///
/// `ManuallyDrop` သို့ပြောင်းခြင်းသည်ပြbothနာနှစ်ခုလုံးကိုရှောင်သည်။
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // ယင်း၏ကုန်ကြမ်းအစိတ်အပိုင်းများသို့ကျွန်တော် disassemble `v` မီ, သေချာပါကကျဆင်းခဲ့ရပါဘူးစေ!
/////
/// let mut v = ManuallyDrop::new(v);
/// // အခုတော့ `v` disassemble ။ဤရွေ့ကားစစ်ဆင်ရေး panic, ဒါကြောင့်တစ်ယိုစိမ့်ရှိပါတယ်မဖွစျနိုငျနိုငျပါဘူး။
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // နောက်ဆုံးအနေနဲ့တစ် `String` တည်ဆောက်။
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` လုံးလုံးလြားလြားကျဆင်းသွားနှင့်၎င်း၏မှတ်ဉာဏ် deallocated ဖြစ်ပါတယ်။
/// ```
///
/// `ManuallyDrop` double-free ကိုကြံ့ခိုင်စွာကာကွယ်ပေးသည်မှာဘာဖြစ်လို့လဲဆိုတော့ငါတို့ဟာ `v` ပျက်စီးမှုကို disable လုပ်သောကြောင့်ဖြစ်သည်။
/// `mem::forget()` ဘာလို့လဲဆိုတော့သူက argument ကိုသုံးပြီး `v` မှလိုအပ်သမျှကိုထုတ်ယူပြီးမှသာဖုန်းခေါ်ခိုင်းလို့ပါ။
/// `ManuallyDrop` တည်ဆောက်မှုနှင့် string ကိုတည်ဆောက်ခြင်းအကြား panic ကိုစတင်ခဲ့သော်လည်း (ကုဒ်တွင်ပြထားသည့်အတိုင်းမရနိုင်ပါ) ၎င်းသည်နှစ်ဆအခမဲ့မဟုတ်ဘဲယိုစိမ့်မှုဖြစ်ပေါ်စေလိမ့်မည်။
/// တစ်နည်းအားဖြင့် `ManuallyDrop` သည် (နှစ်ဆ) ကျဆင်းခြင်း၏ဘေးတွင်မှားယွင်းခြင်းထက်ယိုစိမ့်မှုဘက်၌မှားယွင်းမှုရှိသည်။
///
/// ထို့အပြင် `ManuallyDrop` ကပိုင်ဆိုင်မှုကို `s` သို့လွှဲပြောင်းပြီးနောက် "touch" `v` ကိုအသုံးပြုခြင်းမှကျွန်ုပ်တို့အားကာကွယ်ပေးသည်-`v` နှင့်အပြန်အလှန်ဆက်သွယ်မှု၏နောက်ဆုံးအဆင့်သည်ဖျက်လိုဖျက်ဆီးကိုမ run ဘဲလုံးဝရှောင်ရှားသည်။
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// [`forget`] လိုပဲဒါပေမယ့် unsized values တွေကိုလည်းလက်ခံတယ်။
///
/// ဤလုပ်ဆောင်ချက်သည် `unsized_locals` အင်္ဂါရပ်တည်ငြိမ်သောအခါဖယ်ရှားရန်ရည်ရွယ်ထားခြင်းဖြစ်သည်။
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// bytes မှာအမျိုးအစားတစ်ခု၏အရွယ်အစားကိုပြန်ပို့သည်။
///
/// ပို၍ တိကျစွာပြောရလျှင်၎င်းသည် alignment padding အပါအ ၀ င် array အမျိုးအစားနှင့်ဆက်နွယ်နေသော element များအကြား bytes များမှ offset ဖြစ်သည်။
///
/// ထို့ကြောင့်မည်သည့်အမျိုးအစား `T` နှင့် `n` အရှည်အတွက်မဆို `[T; n]` သည်အရွယ်အစား `n * size_of::<T>()` ရှိသည်။
///
/// ယေဘုယျအားဖြင့်အမျိုးအစားတစ်ခု၏အရွယ်အစားသည် compilations တွင်တည်ငြိမ်မှုမရှိသော်လည်း Primitives ကဲ့သို့တိကျသောအမျိုးအစားများဖြစ်သည်။
///
/// အောက်ပါဇယားသည် Primitive များအတွက်အရွယ်အစားကိုဖော်ပြထားသည်။
///
/// အမျိုးအစားsize_of: :<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |၄
///
/// ထို့အပြင် `usize` နှင့် `isize` မှာအရွယ်အစားတူညီကြသည်။
///
/// `*const T`, `&T`, `Box<T>`, `Option<&T>` နှင့် `Option<Box<T>>` အမျိုးအစားများအားလုံးသည်အရွယ်တူတူညီကြသည်။
/// အကယ်၍ `T` အရွယ်အစားရှိပါကထိုအမျိုးအစားအားလုံးသည် `usize` အရွယ်နှင့်တူညီကြသည်။
///
/// pointer တစ်ခု၏ mutability သည်၎င်း၏အရွယ်အစားကိုမပြောင်းလဲပါ။ထိုကဲ့သို့သောကဲ့သို့, `&T` နှင့် `&mut T` အတူတူပင်အရွယ်အစားရှိသည်။
/// အလားတူပင် `*const T` နှင့် `* mut T` သည်။
///
/// # `#[repr(C)]` ပစ္စည်းအရွယ်အစား
///
/// ပစ္စည်းများအတွက် `C` ကိုယ်စားပြုမှုကိုသတ်မှတ် layout ကိုရှိပါတယ်။
/// နယ်ပယ်အားလုံးတည်ငြိမ်သောအရွယ်အစားရှိသရွေ့ဤပုံစံဖြင့်ပစ္စည်းအရွယ်အစားသည်တည်ငြိမ်သည်။
///
/// ## Structs ၏အရွယ်အစား
///
/// `structs` အတွက်အရွယ်အစားကိုအောက်ပါ algorithm မှဆုံးဖြတ်သည်။
///
/// ကြေငြာချက်အမိန့်ဖြင့်အမိန့်ပေးသည့် struct အတွက်လယ်တစ်ခုချင်းစီအတွက်:
///
/// 1. လယ်ပြင်၏အရွယ်အစားထည့်ပါ။
/// 2. လက်ရှိအရွယ်အစားကိုအနီးဆုံးရှိ [alignment] ၏မျိုးစုံသို့မြှောက်ပါ။
///
/// နောက်ဆုံးအနေဖြင့် struct ၏အရွယ်အစားကိုအနီးဆုံး၎င်း၏ [alignment] သို့လှည့်ပတ်ကြည့်ပါ။
/// ဖွဲ့စည်းပုံ၏ချိန်ညှိခြင်းသည်များသောအားဖြင့်၎င်း၏နယ်မြေအားလုံး၏အကြီးမားဆုံးသောညှိနှိုင်းမှုဖြစ်သည်။၎င်းကို `repr(align(N))` အသုံးပြု၍ ပြောင်းလဲနိုင်သည်။
///
/// `C` နှင့်မတူသည်မှာသုညအရွယ်ဖွဲ့စည်းပုံသည်တစ်ဘိုက်အရွယ်အထိတက်သည်။
///
/// ## Enums အရွယ်အစား
///
/// ခွဲခြားဆက်ဆံခံရသူ မှလွဲ၍ မည်သည့်အချက်အလက်မျှမပါသည့်စာရင်းစစ်များသည်၎င်းတို့ပြုစုထားသောစင်မြင့်ပေါ်ရှိ C enums နှင့်အရွယ်အစားတူသည်။
///
/// ## သမဂ္ဂအရွယ်အစား
///
/// ပြည်ထောင်စု၏အရွယ်အစားသည်၎င်း၏အကြီးဆုံးလယ်ကွင်း၏အရွယ်အစားဖြစ်သည်။
///
/// `C` နှင့်မတူသည်မှာသုညအရွယ်သမဂ္ဂများသည်တစ်ဘိုက်အရွယ်အထိတက်သည်။
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // တချို့က Primitive
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Array အချို့
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // pointer အရွယ်အစားတန်းတူရေး
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// `#[repr(C)]` ကိုအသုံးပြုခြင်း။
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // ပထမဆုံးလယ်ကွင်း၏အရွယ်အစားမှာ ၁ ဖြစ်သည်။ ထို့ကြောင့်အရွယ်အစားသို့ ၁ ထည့်ပါ။အရွယ်အစား 1 ဖြစ်ပါတယ်။
/// // ဒုတိယ field ရဲ့ alignment ကို 2 ဖြစ်တယ်, ဒါ padding ကိုများအတွက်အရွယ်အစား 1 မှထည့်ပါ။အရွယ်အစား 2 ဖြစ်ပါတယ်။
/// // ဒုတိယလယ်ကွင်း၏အရွယ်အစားဒီတော့အရွယ်အစား 2 add, 2 ဖြစ်ပါတယ်။Size ကို 4 ဖြစ်ပါတယ်။
/// // တတိယ field ရဲ့ alignment ကိုဒါ padding ကိုများအတွက်အရွယ်အစား 0 add, 1 ဖြစ်ပါတယ်။အရွယ်အစား 4 ဖြစ်ပါတယ်။
/// // တတိယလယ်ကွင်း၏အရွယ်အစားဒီတော့အရွယ်အစား 1 မှ add, 1 ဖြစ်ပါတယ်။အရွယ်အစား 5 ဖြစ်ပါတယ်။
/// // (၎င်း၏လယ်ကွင်းများကြားအကြီးဆုံး alignment ကို 2 ကြောင့်), ဒါကြောင့် padding ကိုများအတွက်အရွယ်အစား 1 မှ add နောက်ဆုံးတွင် struct ၏ alignment ကို 2 ဖြစ်ပါတယ်။
/// // Size ကို 6 ဖြစ်ပါတယ်။
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuple structs တူညီတဲ့စည်းမျဉ်းစည်းကမ်းတွေကိုလိုက်နာပါ။
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // လယ်ကွင်းကိုပြန်လည်နေရာချထားအရွယ်အစားကိုလျှော့ချနိုင်သည်ကိုသတိပြုပါ။
/// // `second` မတိုင်မီ `third` ကိုထည့်ခြင်းဖြင့် padding bytes နှစ်ခုလုံးကိုဖယ်ထုတ်နိုင်သည်။
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // ပြည်ထောင်စုအရွယ်အစားအကြီးဆုံးလယ်ကွင်း၏အရွယ်အစားဖြစ်ပါတယ်။
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// bytes က point-to value ရဲ့အရွယ်အစားကို return လုပ်တယ်။
///
/// ဤသည်များသောအားဖြင့် `size_of::<T>()` နှင့်အတူတူပင်ဖြစ်ပါသည်။
/// သို့သော် `T` * တွင် statically-လူသိများသောအရွယ်အစားမရှိပါ၊ ဥပမာ slice [`[T]`][slice] သို့မဟုတ် [trait object] ရှိလျှင် `size_of_val` ကို dynamically-လူသိများသောအရွယ်အစားရရှိရန်အသုံးပြုနိုင်သည်။
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // လုံခြုံမှု-`val` သည်ရည်ညွှန်းမှုတစ်ခုဖြစ်သောကြောင့်၎င်းသည်မှန်ကန်သောကုန်ကြမ်းညွှန်းကိန်းဖြစ်သည်
    unsafe { intrinsics::size_of_val(val) }
}

/// bytes က point-to value ရဲ့အရွယ်အစားကို return လုပ်တယ်။
///
/// ဤသည်များသောအားဖြင့် `size_of::<T>()` နှင့်အတူတူပင်ဖြစ်ပါသည်။သို့သော် `T` * တွင် statically-လူသိများသောအရွယ်အစားမရှိပါ၊ ဥပမာ slice [`[T]`][slice] သို့မဟုတ် [trait object] ဆိုလျှင် `size_of_val_raw` ကို dynamically-လူသိများသောအရွယ်အစားရရှိရန်အသုံးပြုနိုင်သည်။
///
/// # Safety
///
/// အောက်ဖော်ပြပါအခြေအနေများရှိပါကဤလုပ်ဆောင်မှုသည်ဖုန်းခေါ်ဆိုခြင်းအတွက်လုံခြုံမှုရှိသည်။
///
/// - အကယ်၍ `T` သည် `Sized` ဖြစ်ပါကဤလုပ်ဆောင်မှုသည်ဖုန်းဆက်ရန်အမြဲလုံခြုံသည်။
/// - `T` ၏အရွယ်အစားမရှိသောအမြီးသည်အကယ်။
///     - [slice] တစ်ခုအနေနှင့်အချပ်အမြီး၏အရှည်သည်ပဏာမကိန်းပြည့်ဖြစ်ရမည်။ တန်ဖိုးတစ်ခုလုံး *၏အရွယ်အစား*(ရွေ့လျားနေသောအမြီးအရှည် + ပုံသေအရွယ်အစားရှေ့ဆက်) သည် `isize` နှင့်ကိုက်ညီရမည်။
///     - [trait object] တစ်ခုဖြစ်လျှင် pointer ၏ vtable အပိုင်းသည် unsizing coercion ဖြင့်ရရှိသောတရားဝင် vtable ကိုညွှန်ပြရမည်။ တန်ဖိုးတစ်ခုလုံး * (dynamic tail length + statically size prefix) ၏အရွယ်အစားသည် `isize` နှင့်ကိုက်ညီရမည်။
///
///     - (unstable) [extern type] တစ်ခုဖြစ်လျှင်၊ ဤလုပ်ဆောင်မှုသည်အမြဲတမ်းလုံခြုံမှုရှိနိုင်သည်။ သို့သော်ပြင်ပအမျိုးအစား၏အပြင်အဆင်ကိုမသိသောကြောင့် panic သို့မဟုတ်မှားယွင်းသောတန်ဖိုးကိုပြန်ပို့နိုင်သည်။
///     ဤသည်မှာ [`size_of_val`] ကဲ့သို့သောအပြုအမူတစ်ခုဖြစ်ပြီးပြင်ပအမြီးရှိသည့်အမျိုးအစားကိုရည်ညွှန်းသည်။
///     - မဟုတ်ရင်, ကထိန်းသိမ်းစောင့်ရှောက်ရေးဒီ function ကိုခေါ်ခြင်းခွင့်မပြုပါ။
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // လုံခြုံမှု-ခေါ်ဆိုသူသည်မှန်ကန်သောကုန်ကြမ်းအညွှန်းကိုပြသရမည်
    unsafe { intrinsics::size_of_val(val) }
}

/// [ABI] အမျိုးအစားတစ်ခု၏အနိမ့်ဆုံးညှိနှိုင်းမှုကိုပြန်ပို့သည်။
///
/// `T` အမျိုးအစားတန်ဖိုးတစ်ခုသို့ရည်ညွှန်းမှုသည်ဤအရေအတွက်၏များပြားမှုဖြစ်ရမည်။
///
/// ဤသည် struct fields များအတွက်အသုံးပြုသည် alignment ကိုဖြစ်ပါတယ်။ဒါဟာ ဦး စားပေး alignment ကိုထက်သေးငယ်ဖြစ်နိုင်သည်။
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// [ABI]-`val` ညွှန်ပြသောတန်ဖိုးအမျိုးအစား၏အနည်းဆုံး alignment ကို return လုပ်သည်။
///
/// `T` အမျိုးအစားတန်ဖိုးတစ်ခုသို့ရည်ညွှန်းမှုသည်ဤအရေအတွက်၏များပြားမှုဖြစ်ရမည်။
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // လုံခြုံမှု-val ဟာရည်ညွှန်းတဲ့အရာဖြစ်တယ်
    unsafe { intrinsics::min_align_of_val(val) }
}

/// [ABI] အမျိုးအစားတစ်ခု၏အနိမ့်ဆုံးညှိနှိုင်းမှုကိုပြန်ပို့သည်။
///
/// `T` အမျိုးအစားတန်ဖိုးတစ်ခုသို့ရည်ညွှန်းမှုသည်ဤအရေအတွက်၏များပြားမှုဖြစ်ရမည်။
///
/// ဤသည် struct fields များအတွက်အသုံးပြုသည် alignment ကိုဖြစ်ပါတယ်။ဒါဟာ ဦး စားပေး alignment ကိုထက်သေးငယ်ဖြစ်နိုင်သည်။
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// [ABI]-`val` ညွှန်ပြသောတန်ဖိုးအမျိုးအစား၏အနည်းဆုံး alignment ကို return လုပ်သည်။
///
/// `T` အမျိုးအစားတန်ဖိုးတစ်ခုသို့ရည်ညွှန်းမှုသည်ဤအရေအတွက်၏များပြားမှုဖြစ်ရမည်။
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // လုံခြုံမှု-val ဟာရည်ညွှန်းတဲ့အရာဖြစ်တယ်
    unsafe { intrinsics::min_align_of_val(val) }
}

/// [ABI]-`val` ညွှန်ပြသောတန်ဖိုးအမျိုးအစား၏အနည်းဆုံး alignment ကို return လုပ်သည်။
///
/// `T` အမျိုးအစားတန်ဖိုးတစ်ခုသို့ရည်ညွှန်းမှုသည်ဤအရေအတွက်၏များပြားမှုဖြစ်ရမည်။
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// အောက်ဖော်ပြပါအခြေအနေများရှိပါကဤလုပ်ဆောင်မှုသည်ဖုန်းခေါ်ဆိုခြင်းအတွက်လုံခြုံမှုရှိသည်။
///
/// - အကယ်၍ `T` သည် `Sized` ဖြစ်ပါကဤလုပ်ဆောင်မှုသည်ဖုန်းဆက်ရန်အမြဲလုံခြုံသည်။
/// - `T` ၏အရွယ်အစားမရှိသောအမြီးသည်အကယ်။
///     - [slice] တစ်ခုအနေနှင့်အချပ်အမြီး၏အရှည်သည်ပဏာမကိန်းပြည့်ဖြစ်ရမည်။ တန်ဖိုးတစ်ခုလုံး *၏အရွယ်အစား*(ရွေ့လျားနေသောအမြီးအရှည် + ပုံသေအရွယ်အစားရှေ့ဆက်) သည် `isize` နှင့်ကိုက်ညီရမည်။
///     - [trait object] တစ်ခုဖြစ်လျှင် pointer ၏ vtable အပိုင်းသည် unsizing coercion ဖြင့်ရရှိသောတရားဝင် vtable ကိုညွှန်ပြရမည်။ တန်ဖိုးတစ်ခုလုံး * (dynamic tail length + statically size prefix) ၏အရွယ်အစားသည် `isize` နှင့်ကိုက်ညီရမည်။
///
///     - (unstable) [extern type] တစ်ခုဖြစ်လျှင်၊ ဤလုပ်ဆောင်မှုသည်အမြဲတမ်းလုံခြုံမှုရှိနိုင်သည်။ သို့သော်ပြင်ပအမျိုးအစား၏အပြင်အဆင်ကိုမသိသောကြောင့် panic သို့မဟုတ်မှားယွင်းသောတန်ဖိုးကိုပြန်ပို့နိုင်သည်။
///     ဤသည်မှာ [`align_of_val`] ကဲ့သို့သောအပြုအမူတစ်ခုဖြစ်ပြီးပြင်ပအမြီးရှိသည့်အမျိုးအစားကိုရည်ညွှန်းသည်။
///     - မဟုတ်ရင်, ကထိန်းသိမ်းစောင့်ရှောက်ရေးဒီ function ကိုခေါ်ခြင်းခွင့်မပြုပါ။
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // လုံခြုံမှု-ခေါ်ဆိုသူသည်မှန်ကန်သောကုန်ကြမ်းအညွှန်းကိုပြသရမည်
    unsafe { intrinsics::min_align_of_val(val) }
}

/// အကယ်၍ `T` အမျိုးအစားတန်ဖိုးများကျဆင်းလျှင် `true` သို့ပြန်သည်။
///
/// ၎င်းသည် optimization အရိပ်အမြွက်သက်သက်သာဖြစ်သည်။
/// ၎င်းသည်အမှန်တကယ်ဖယ်ရှားရန်မလိုအပ်သောအမျိုးအစားများအတွက် `true` ကိုပြန်ပို့နိုင်သည်။
/// ထိုကဲ့သို့သောအစဉ်အမြဲ `true` ပြန်လာဒီ function ကို၏တရားဝင်အကောင်အထည်ဖော်မှုဖြစ်လိမ့်မည်။ဒီ function က `false` ကိုတကယ်ပြန်လာရင် `T` မှာဘေးထွက်ဆိုးကျိုးမရှိဘူးဆိုတာသေချာပါတယ်။
///
/// collection များကိုကဲ့သို့အဆင့်နိမ့်သောအကောင်အထည်ဖော်မှုများ၊ ဒေတာများကိုကိုယ်တိုင်လက်ဖြင့် drop လုပ်ရန်လိုအပ်သည်၊ ၄ င်းတို့ကိုဖျက်ဆီးလိုက်သည့်အခါ၎င်းတို့၏ contents များအားလုံးကိုမလိုအပ်ဘဲဖယ်ရှားပစ်ရန်ရှောင်ကြဉ်ရန်ဤ function ကိုအသုံးပြုသင့်သည်။
///
/// ဒါက release builds (ခြားနားသောဘေးထွက်ဆိုးကျိုးမရှိသော loop တစ်ခုကိုအလွယ်တကူရှာဖွေတွေ့ရှိပြီးဖယ်ရှားပစ်နိုင်သည့်နေရာ) တွင်ကွဲပြားခြားနားမှုမရှိစေရ။ သို့သော်မကြာခဏ debug တည်ဆောက်ခြင်းအတွက်ကြီးမားသောအနိုင်ရသည်။
///
/// [`drop_in_place`] သည်ဤစစ်ဆေးမှုကိုပြုလုပ်ပြီးပြီဖြစ်သည်။ ထို့ကြောင့်သင်၏ပမာဏကို [`drop_in_place`] ခေါ်ဆိုမှုအနည်းငယ်သို့အနည်းငယ်လျှော့ချနိုင်ပါက၎င်းကိုအသုံးပြုရန်မလိုအပ်ပါ။
/// အထူးသဖြင့်သင်သည် [`drop_in_place`] ကိုအချပ်တစ်ခုလုပ်နိုင်သည်၊ ၎င်းသည်တန်ဖိုးများအားလုံးအတွက်လိုအပ်ချက်တစ်ခုတည်းလိုအပ်သည်။
///
/// ထို့ကြောင့် Vec ကဲ့သို့သောအမျိုးအစားများသည် `needs_drop` ကိုအတိအလင်းမသုံးပဲ `drop_in_place(&mut self[..])` သာဖြစ်သည်။
/// အခြားတစ်ဖက်တွင် [`HashMap`] ကဲ့သို့သောအမျိုးအစားများသည်တန်ဖိုးများကိုတစ်ကြိမ်စီကျဆင်းစေပြီးဤ API ကိုအသုံးပြုသင့်သည်။
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// စုဆောင်းမှုတစ်ခုက `needs_drop` ကိုဘယ်လိုအသုံးပြုမလဲဆိုတာဥပမာတစ်ခုပေးပါ။
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // ဒေတာ drop
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// All-zero byte-ပုံစံဖြင့်ကိုယ်စားပြုသောအမျိုးအစား `T` ၏တန်ဖိုးကိုပြန်ပို့သည်။
///
/// ဆိုလိုသည်မှာဥပမာအားဖြင့် `(u8, u16)` ရှိ padding byte သည်သုညမဟုတ်ပါ။
///
/// All-zero byte-ပုံစံသည်အချို့သော `T` အမျိုးအစားများ၏မှန်ကန်သောတန်ဖိုးကိုကိုယ်စားပြုသည်ဟူသောအာမခံချက်မရှိပါ။
/// ဥပမာအားဖြင့်၊ သုည byte ပုံစံသည်ကိုးကားထားသောအမျိုးအစားများ (`&T`, `&mut T`) နှင့် functions pointers များအတွက်တရားဝင်တန်ဖိုးမဟုတ်ပါ။
/// ထိုကဲ့သို့သောအမျိုးအစားများတွင် `zeroed` ကိုအသုံးပြုခြင်းသည် [undefined behavior][ub] ကိုချက်ချင်းဖြစ်ပေါ်စေသည်။ အဘယ်ကြောင့်ဆိုသော် [the Rust compiler assumes][inv] ကမူရင်းတန်ဖိုးတွင်အမြဲတမ်းကန ဦး ထည့်သွင်းစဉ်းစားထားသောတန်ဖိုးဖြစ်သည်။
///
///
/// ဤသည် [`MaybeUninit::zeroed().assume_init()`][zeroed] ကဲ့သို့တူညီသောအကျိုးသက်ရောက်မှုရှိပါတယ်။
/// ၎င်းသည်တစ်ခါတစ်ရံ FFI အတွက်အသုံးဝင်သော်လည်းယေဘုယျအားဖြင့်ရှောင်ကြဉ်သင့်သည်။
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// ဒီ function ကိုမှန်ကန်စွာအသုံးပြုခြင်း-ကိန်းပြည့်ကိုသုညနဲ့စတင်ခြင်း။
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *မှားယွင်းသော* ဤလုပ်ဆောင်မှုကိုအသုံးပြုခြင်း-ရည်ညွှန်းချက်ကိုသုညဖြင့်စတင်ခြင်း။
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // undefined အပြုအမူ!
/// let _y: fn() = unsafe { mem::zeroed() }; // တဖန်!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူမှ All-သုညတန်ဖိုး `T` အတွက်မှန်ကန်ကြောင်းအာမခံရမည်။
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// ဘာမှမလုပ်စဉ် Rust ၏ပုံမှန်မှတ်ဉာဏ်-အစပြုစစ်ဆေးမှုများကို `T` အမျိုးအစားထုတ်လုပ်ရန်ဟန်ဆောင်ခြင်းဖြင့်ရှောင်ကွင်းသည်။
///
/// **ဤလုပ်ဆောင်မှုကိုကန့်ကွက်ထားသည်။** အစား [`MaybeUninit<T>`] ကိုသုံးပါ။
///
/// ကန့်ကွက်ရခြင်း၏အကြောင်းအရင်းမှာ function ကိုအခြေခံအားဖြင့်မှန်ကန်စွာ အသုံးပြု၍ မရပါ။ ၎င်းသည် [`MaybeUninit::uninit().assume_init()`][uninit] နှင့်အတူတူပင်အကျိုးသက်ရောက်မှုရှိသည်။
///
/// [`assume_init` documentation][assume_init] ရှင်းပြသည့်အတိုင်းတန်ဖိုးများကိုစနစ်တကျစတင်သည်။
/// အကျိုးဆက်အားဥပမာအားဖြင့်ခေါ်ခြင်း
/// `mem::uninitialized::<bool>()` `true` (သို့) `false` တို့မဖြစ်သည့် `bool` ကိုပြန်ပို့ခြင်းအတွက်ချက်ချင်းအဓိပ္ပာယ်မဲ့သောအပြုအမူကိုဖြစ်ပေါ်စေသည်။
/// ပိုဆိုးသည်မှာဤနေရာတွင်ပြန်လည်ရောက်ရှိလာသည့်မှတ်ပုံတင်မရှိသောမှတ်ဉာဏ်သည်အထူးတလည်ဖြစ်သည်။ compiler က၎င်းတွင်ပုံသေတန်ဖိုးမရှိကြောင်းသိထားသည်။
/// ၎င်းသည်ကိန်းရှင်တစ်လုံးတည်းရှိသည့်တိုင်အောင် variable တစ်ခုတွင် uninitialized data ရှိခြင်းသည်အပြုအမူအားသတ်မှတ်ခြင်းမဟုတ်ပါ။
/// (uninitialized ကိန်းန်းကျင်စည်းမျဉ်းစည်းကမ်းတွေကိုသေးအပြီးသတ်ကြသည်မဟုတ်ကြောင်းသတိပြုပါ, ဒါပေမဲ့သူတို့ဖြစ်ကြသည်သည်အထိပြုလုပ်သူတို့ကိုရှောင်ရှားရန်အကြံပြုလိုတယ်။)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူမှ `T` အတွက် unitialized တန်ဖိုးမှန်ကန်ကြောင်းအာမခံရမည်။
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// တစ်ခုခုကို deinitializing မပါဘဲ, mutable တည်နေရာနှစ်ခုမှာတန်ဖိုးများကိုဖလှယ်။
///
/// * သင်ပုံမှန်သို့မဟုတ်အတုတန်ဖိုးနှင့်လဲလှယ်လိုပါက [`take`] ကိုကြည့်ပါ။
/// * အကယ်၍ သင်တန်ဖိုးဖြတ်ထားသောတန်ဖိုးနှင့်လဲလှယ်လိုပါကတန်ဖိုးဟောင်းကိုပြန်ယူလိုပါက [`replace`] တွင်ကြည့်ပါ။
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // လုံခြုံမှု-ကုန်ကြမ်းလမ်းညွှန်များအားလုံးသည်စိတ်ကျေနပ်ဖွယ်ကောင်းသော mutable ကိုးကားချက်များမှဖန်တီးထားခြင်းဖြစ်သည်
    // `ptr::swap_nonoverlapping_one` အပေါ်သတ်
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// `dest` ၏မူလတန်ဖိုး `T` ကိုအရင် `dest` တန်ဖိုးပြန်ပေးသည်။
///
/// * သင်က variable နှစ်ခု၏တန်ဖိုးများကိုအစားထိုးလိုပါက [`swap`] ကိုကြည့်ပါ။
/// * သင်ကပုံမှန်တန်ဖိုးအစားလွန်တန်ဖိုးနှင့်အစားထိုးချင်လျှင်, [`replace`] ကိုကြည့်ပါ။
///
/// # Examples
///
/// ရိုးရိုးဥပမာတစ်ခု-
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` "empty" တန်ဖိုးတစ်ခုဖြင့်အစားထိုးခြင်းဖြင့် struct field တစ်ခု၏ပိုင်ဆိုင်မှုကိုရယူနိုင်သည်။
/// `take` မရှိပါကသင်ဤကဲ့သို့သောပြissuesနာများနှင့်ရင်ဆိုင်နိုင်ပါသည်။
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// သတိပြုပါမှာ `T` သည် [`Clone`] ကိုသေချာပေါက်အကောင်အထည်ဖော်ရန်မလိုအပ်ပါ၊ ထို့ကြောင့်၎င်းသည် `self.buf` ကိုပင်ပုံတူကူး။ မရပါ။
/// သို့သော် `take` ကို X0 `self.buf` မှမူလတန်ဖိုး `self` မှဖယ်ထုတ်ခြင်းဖြင့်၎င်းကိုပြန်လည်ပေးအပ်နိုင်သည်။
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// `src` ကိုညွန်ပြထားသော `dest` သို့ပြောင်းပြီးယခင် `dest` တန်ဖိုးကိုပြန်ပေးသည်။
///
/// မတန်ဖိုးကျဆင်းသွားသည်။
///
/// * သင်က variable နှစ်ခု၏တန်ဖိုးများကိုအစားထိုးလိုပါက [`swap`] ကိုကြည့်ပါ။
/// * သင်ပုံမှန်တန်ဖိုးဖြင့်အစားထိုးလိုပါက [`take`] ကိုကြည့်ပါ။
///
/// # Examples
///
/// ရိုးရိုးဥပမာတစ်ခု-
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` အခြားတန်ဖိုးတစ်ခုဖြင့်အစားထိုးခြင်းဖြင့် struct field ၏စားသုံးမှုကိုခွင့်ပြုပါတယ်။
/// `replace` မရှိပါကသင်ဤကဲ့သို့သောပြissuesနာများနှင့်ရင်ဆိုင်နိုင်ပါသည်။
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// သတိပြုပါမှာ `T` သည် [`Clone`] ကိုသေချာပေါက်အကောင်အထည်ဖော်ရန်မလိုအပ်ပါ။ ထို့ကြောင့် `self.buf[i]` ကိုပင်ပုံတူကူး။ မရပါ။
/// သို့သော် `replace` သည်မူလတန်ဖိုးကို `self` မှမူလတန်ဖိုးကိုဖယ်ထုတ်ပြီး၎င်းကိုပြန်ပို့နိုင်သည်။
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // လုံခြုံမှု-`dest` မှဖတ်ပြီးနောက်တွင် `src` ကိုတိုက်ရိုက်ရေးသည်။
    // အဟောင်းတန်ဖိုးကိုပုံတူမဟုတ်ကြောင်းထိုကဲ့သို့သော။
    // အဘယ်အရာမျှမကျဆင်းသွားသည်နှင့်ဤနေရာတွင်ဘာမျှ panic နိုင်ပါတယ်။
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// တန်ဖိုးတစ်ခုစီ။
///
/// ၎င်းသည် [`Drop`][drop] ၏အငြင်းပွားမှု၏အကောင်အထည်ဖော်မှုကိုခေါ်ခြင်းဖြင့်ပြုလုပ်သည်။
///
/// ၎င်းသည် `Copy` ကိုအကောင်အထည်ဖော်သောအမျိုးအစားများအတွက်ထိရောက်စွာဘာမှမလုပ်ပါ
/// integers.
/// ထိုသို့သောတန်ဖိုးများကိုကူးယူပြီး _then_ ကို function ထဲသို့ပြောင်းသည်။ ထို့ကြောင့် function ခေါ်ဆိုမှုပြီးနောက်တန်ဖိုးဆက်လက်တည်ရှိနေသည်။
///
///
/// ဒီ function မှော်မဟုတ်ပါဘူးကစာသားအဖြစ်သတ်မှတ်ထားသည်
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// ဘာလို့လဲဆိုတော့ `_x` ကို function ထဲကိုရွှေ့လိုက်တာနဲ့ function ကိုမလာခင်အလိုအလျောက်ကျသွားတယ်။
///
/// [drop]: Drop
///
/// # Examples
///
/// အခြေခံအသုံးပြုမှု-
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // အတိအလင်း vector drop
/// ```
///
/// runt01 မှာ [`RefCell`] ကချေးယူတဲ့စည်းမျဉ်းစည်းကမ်းတွေကိုလိုက်နာတဲ့အတွက် `drop` က [`RefCell`] loan ကိုလွှတ်ပေးနိုင်ပါတယ်
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // ဒီ slot ကပေါ် mutable ချေးငှါးလက်လွှတ်
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Integer များနှင့် [`Copy`] ကိုအကောင်အထည်ဖော်သည့်အခြားအမျိုးအစားများကို `drop` မှမထိခိုက်ပါ။
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // `x` ၏မိတ္တူပြောင်းရွှေ့ခြင်းနှင့်ကျဆင်းသွားသည်
/// drop(y); // `y` တစ်ဦးမိတ္တူပြောင်းရွှေ့ကျဆင်းသွားခြင်းဖြစ်သည်
///
/// println!("x: {}, y: {}", x, y.0); // နေဆဲမရရှိနိုင်
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// `src` ကို `&U` အမျိုးအစားဟုအဓိပ္ပာယ်ဖွင့်ပြီး၎င်းသည်ပါ ၀ င်သည့်တန်ဖိုးကိုမရွေ့စေဘဲ `src` ကိုဖတ်သည်။
///
/// ဒီ function က X0 `&T` bytes `&U` ကို `&U` ကို transmut လုပ်ပြီး `&U` ကိုဖတ်ခြင်းအားဖြင့် [`size_of::<U>`][size_of] bytes အတွက်တရားဝင်သည် pointer `src` သည်မှန်ကန်သည်ဟုယူဆလိမ့်မည် (`&U` သည် `&T` ထက်ပိုမိုတိကျစွာသတ်မှတ်ချက်လိုအပ်ချက်များကိုပြုလုပ်သည့်တိုင်)
/// ၎င်းသည်ပါ ၀ င်သည့်တန်ဖိုးမိတ္တူတစ်ခုအား `src` မှထွက်ခွာမည့်အစားဖန်တီးလိမ့်မည်။
///
/// `T` နှင့် `U` အရွယ်အစားကွဲပြားလျှင်၎င်းသည် compile time error မဟုတ်သော်လည်း `T` နှင့် `U` အတူတူပင်အရွယ်အစားရှိသည့်ဤလုပ်ဆောင်ချက်ကိုသာအသုံးပြုရန်တိုက်တွန်းသည်။`U` `T` ထက်ကြီးရင်ဒီ function က [undefined behavior][ub] ကိုအစပျိုးသည်။
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // 'foo_array' မှအချက်အလက်များကိုကူးယူပြီး 'Foo' အဖြစ်ဆက်ဆံပါ
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // အဆိုပါကူးယူ data တွေကိုပြုပြင်မွမ်းမံ
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // 'foo_array' ရဲ့ contents ပြောင်းလဲသင့်သည်မဟုတ်
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // U သည်မြင့်မားသော alignment လိုအပ်ချက်ရှိပါက src သည်သင့်လျော်စွာညှိနှိုင်း။ မရပါ။
    if align_of::<U>() > align_of::<T>() {
        // လုံခြုံမှု-`src` ဆိုသည်မှာဖတ်ရှုခြင်းအတွက်မှန်ကန်ကြောင်းသေချာစေရန်ရည်ညွှန်းသည်။
        // ခေါ်ဆိုသူသည်အမှန်တကယ်ပျံ့နှံ့ခြင်းအန္တရာယ်ကင်းကြောင်းအာမခံရမည်။
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // လုံခြုံမှု-`src` ဆိုသည်မှာဖတ်ရှုခြင်းအတွက်မှန်ကန်ကြောင်းသေချာစေရန်ရည်ညွှန်းသည်။
        // `src as *const U` ကိုမှန်မှန်ကန်ကန်ကိုက်ညီမှုရှိမရှိစစ်ဆေးကြည့်ပြီးပါပြီ။
        // ခေါ်ဆိုသူသည်အမှန်တကယ်ပျံ့နှံ့ခြင်းအန္တရာယ်ကင်းကြောင်းအာမခံရမည်။
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// enum တစ် ဦး ၏ခွဲခြားဆက်ဆံမှုကိုကိုယ်စားပြုမပါသောအမျိုးအစား။
///
/// ပိုမိုသိရှိလိုပါကများအတွက်ဒီ module ထဲမှာ [`discriminant`] function ကိုကြည့်ပါ။
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. T. Z အပေါ်တွင်မည်သည့်အကန့်အသတ်မှမလိုသောကြောင့်ဤ trait အကောင်အထည်ဖော်မှုကိုမရရှိနိုင်

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// ထူးခြား `v` အတွက် enum မူကွဲဖော်ထုတ်တန်ဖိုးကိုပြန်သွားသည်။
///
/// အကယ်၍ `T` သည် enum မဟုတ်ပါကဤ function ကိုခေါ်ဆိုခြင်းသည်သတ်မှတ်ထားသောအပြုအမူကိုဖြစ်ပေါ်စေလိမ့်မည်မဟုတ်သော်လည်း return value ကိုမဖော်ပြနိုင်ပါ။
///
///
/// # Stability
///
/// အဆိုပါ enum ချက်နှင့်အဓိပ္ပါယ်ပြောင်းလဲလျှင်တစ် enum မူကွဲများ၏ခွဲခြားဆက်ဆံမှုကိုပြောင်းလဲလိမ့်မည်။
/// အချို့သောမူကွဲတစ်ခု၏ခွဲခြားဆက်ဆံမှုသည်တူညီသော compiler နှင့်အတူ compilations အကြားပြောင်းလဲလိမ့်မည်မဟုတ်ပါ။
///
/// # Examples
///
/// ၎င်းကိုဒေတာများသယ်ဆောင်သော enums များကိုနှိုင်းယှဉ်ရာတွင်အမှန်တကယ်ဒေတာကိုဂရုမပြုဘဲနှိုင်းယှဉ်နိုင်သည်။
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// enum အမျိုးအစား `T` ရှိမူကွဲအရေအတွက်ကိုပြန်ပို့ပေးသည်။
///
/// အကယ်၍ `T` သည် enum မဟုတ်ပါကဤ function ကိုခေါ်ဆိုခြင်းသည်သတ်မှတ်ထားသောအပြုအမူကိုဖြစ်ပေါ်စေလိမ့်မည်မဟုတ်သော်လည်း return value ကိုမဖော်ပြနိုင်ပါ။
/// ထိုနည်းတူစွာ `T` သည် `usize::MAX` ထက်မူကွဲများပိုမိုပြည့်စုံသော enum တစ်ခုဖြစ်ပါကပြန်လာသည့်တန်ဖိုးကိုသတ်မှတ်မထားပါ။
/// လူနေထိုင်မှုမရှိသောမူကွဲများကိုရေတွက်လိမ့်မည်။
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}