use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// `T` ၏ uninitialized သာဓကတည်ဆောက်ရန်တစ်ဦးက wrapper အမျိုးအစား။
///
/// # Initialization လျော့ပါးသွားမည်ဖြစ်သလို
///
/// အဆိုပါ compiler, ယေဘုယျအားဖြင့်တစ်ဦး variable ကိုစနစ်တကျ variable ကိုရဲ့အမျိုးအစားများ၏လိုအပ်ချက်တွေနဲ့အညီနကြောင်းယူဆတယ်။ဥပမာအားဖြင့်၊ ရည်ညွှန်းထားသောအမျိုးအစားတစ်ခုအားချိန်ညှိပြီး NULL မဟုတ်ပါ။
/// ဒါကမဖြစ်မနေ *အမြဲ* ပင်မလုံခြုံကုဒ်ထဲမှာထောကျခံခဲ့ခြင်းကိုခံရတစ်ခုလျော့ပါးသွားမည်ဖြစ်သလိုဖြစ်ပါတယ်။
/// အကျိုးဆက်အဖြစ်, ရည်ညွှန်းအမျိုးအစားတစ်ခု variable ကိုသုည-စတင်လုပ်ဆောင်ချက်ချင်း [undefined behavior][ub], ထိုရည်ညွှန်းအစဉ်အဆက် access memory ကိုရန်အသုံးပြုရရှိရှိမရှိနေပါစေဖြစ်ပေါ်စေသည်:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // undefined အပြုအမူ!⚠️
/// // `MaybeUninit<&i32>` နှင့်အတူတူညီကုဒ်:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // undefined အပြုအမူ!⚠️
/// ```
///
/// ဤသည်ထိုကဲ့သို့သော Run-အချိန်စစ်ဆေးမှုများ eliding နှင့် `enum` layout ကိုပိုကောင်းအောင်အဖြစ်အမျိုးမျိုးသောပိုမိုကောင်းမွန်ရေး, များအတွက် compiler များကအမြတ်ထုတ်သည်။
///
/// တစ်ဦး `bool` အမြဲ `true` သို့မဟုတ် `false` ဖြစ်ရမည်စဉ်အလားတူပင်လုံးဝ uninitialized မှတ်ဉာဏ်, မည်သည့်အကြောင်းအရာပေမည်။ထို့ကြောင့်တစ်ဦး uninitialized `bool` ကို undefined အပြုအမူဖြစ်ပါသည်:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // undefined အပြုအမူ!⚠️
/// // `MaybeUninit<bool>` အတူညီမျှကုဒ်:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // undefined အပြုအမူ!⚠️
/// ```
///
/// ထို့အပြင် uninitialized memory သည်ပုံသေတန်ဖိုး ("it won't change without being written to" ဆိုလိုသည် "fixed") မရှိသောကြောင့်ဖြစ်သည်။တူညီသော uninitialized byte အကြိမ်ပေါင်းများစွာကိုဖတ်ခြင်းသည်ကွဲပြားခြားနားသောရလဒ်များကိုပေးနိုင်သည်။
/// ဤသည်က variable ကိုမဟုတ်ရင်မဆို *fixed* နည်းနည်းပုံစံကိုင်နိုင်သည့်တစ်ဦး integer ဖြစ်တဲ့အတွက်အမျိုးအစားရှိပါတယ်လျှင်ပင်တစ် variable ကိုအတွက် uninitialized ဒေတာရှိသည်ဖို့အပြုအမူ undefined စေသည်:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // undefined အပြုအမူ!⚠️
/// // `MaybeUninit<i32>` အတူညီမျှကုဒ်:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // undefined အပြုအမူ!⚠️
/// ```
/// (uninitialized ကိန်းန်းကျင်စည်းမျဉ်းစည်းကမ်းတွေကိုသေးအပြီးသတ်ကြသည်မဟုတ်ကြောင်းသတိပြုပါ, ဒါပေမဲ့သူတို့ဖြစ်ကြသည်သည်အထိပြုလုပ်သူတို့ကိုရှောင်ရှားရန်အကြံပြုလိုတယ်။)
///
/// ကြောင်း၏ထိပ်တွင်အများစုအမျိုးအစားများမျှသာအမျိုးအစားကိုအဆင့်မှာနထည့်သွင်းစဉ်းစားထားကြောင်းကျော်လွန်ပြီးနောက်ထပ်လျော့ပါးသွားမည်ဖြစ်သလိုရှိသည်သတိရပါ။
/// ဥပမာအားဖြင့် `1`-initialized [`Vec<T>`] ကို (လက်ရှိအကောင်အထည်ဖော်မှုအောက်တွင်၊ ဤသည်တည်ငြိမ်သောအာမခံချက်မဟုတ်ပါ) အစပြုသည်ဟုမှတ်ယူသည်။ အဘယ်ကြောင့်ဆိုသော် compiler ကသိသောတစ်ခုတည်းသောလိုအပ်ချက်မှာ data pointer သည် null မဟုတ်သောကြောင့်ဖြစ်သည်။
/// ထိုကဲ့သို့သော `Vec<T>` တစ်ခုကိုဖန်တီးခြင်းသည် * ချက်ချင်းမသင့်လျော်သောအပြုအမူများကိုဖြစ်ပေါ်စေသည်မဟုတ်သော်လည်း (၎င်းကိုဖယ်ရှားခြင်းအပါအ ၀ င်) လုံခြုံစိတ်ချရသောလုပ်ဆောင်မှုအများစုနှင့်အတူသတ်မှတ်ထားသောအပြုအမူများကိုဖြစ်ပေါ်စေသည်။
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` uninitialized ဒေတာနှင့်အတူကိုင်တွယ်ရန်မလုံခြုံကုဒ် enable လုပ်ဖို့ဆောင်ရွက်ပါသည်။
/// ဤနေရာတွင်ရှိသောဒေတာများကို အစပြု၍ မရခြင်းဖြစ်နိုင်သည်ကိုညွှန်ပြသူသည် compiler သို့အချက်ပြသည်။
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // တစ်ဦးအတိအလင်း uninitialized ရည်ညွှန်းဖန်တီးပါ။
/// // အဆိုပါ compiler တစ် `MaybeUninit<T>` အတွင်းပိုင်းအချက်အလက်မမှန်ကန်ပါစေခြင်းငှါအဘယ်သူသိနိုင်နှင့်ဤအရပ်မှဒီ UB မဟုတ်ပါဘူး:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // ခိုင်လုံသောတန်ဖိုးထားကြ၏။
/// unsafe { x.as_mut_ptr().write(&0); }
/// // ကန ဦး ဒေတာများကိုထုတ်ယူပါ-`x` ကိုစနစ်တကျစတင်ပြီးမှသာဤအရာသည်ခွင့်ပြုသည်။
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// ထို့နောက် compiler သည်ဤကုဒ်နံပါတ်အတွက်မမှန်ကန်သောယူဆချက်များ၊
///
/// သငျသညျနည်းနည်း `Option<T>` နဲ့တူပေမယ့် Run-အချိန်ခြေရာခံခြင်းမဆိုမပါဘဲနှင့်ဘေးကင်းလုံခြုံရေးစစ်ဆေးမှုများမဆိုမပါဘဲအဖြစ် `MaybeUninit<T>` စဉ်းစားနိုင်ပါတယ်။
///
/// ## out-pointers
///
/// သငျသညျ "out-pointers" အကောင်အထည်ဖော်ရန် `MaybeUninit<T>` အသုံးပွုနိုငျ: အစား function ကိုကနေဒေတာတွေကိုပြန်လာ၏, သို့ရလဒ်ထားရန်အချို့သော (uninitialized) မှတ်ဉာဏ်ကတစ် pointer ကိုဖြတ်သန်းရတယ်။
/// ကထိန်းချုပ်ဖို့ခေါ်ဆိုမှုများအတွက်အရေးကြီးပါသည်တဲ့အခါဒီကအသုံးကျနိုင်ပါသည်မည်သို့မှတ်ဉာဏ်ရလဒ်ခွဲဝေရရှိထဲမှာသိမ်းထားတဲ့, နှင့်သင်မလိုအပ်တဲ့ရွေ့လျားကိုရှောင်ရှားချင်သည်။
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` အရေးကြီးသောအရာ, ဟောင်း contents တွေကို drop မထားဘူး။
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // ယခုတွင် `v` ကိုအစပျိုးသည်ကိုကျွန်ုပ်တို့သိပြီဖြစ်သည်။၎င်းသည် vector ကိုစနစ်တကျကျဆင်းသွားစေသည်။
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## element တစ်ခုချင်းစီမှ array တစ်ခုကိုစတင်ခြင်း
///
/// `MaybeUninit<T>` ကြီးမားတဲ့စစ်ခင်းကျင်းဒြပ်စင်-by-element ကိုစတငျဖို့အသုံးပြုနိုင်ပါတယ်:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // `MaybeUninit` ၏ uninitialized ခင်းကျင်းမှုကိုဖန်တီးပါ။
///     // ကျနော်တို့ကဒီမှာနရှိသည်ဟုဟုဆိုကာနေကြသည်အမျိုးအစားစတင်ခြင်းလိုအပ်မထားတဲ့ `MaybeUninit`s, တစည်းသောကွောငျ့ထို `assume_init` လုံခြုံဖြစ်ပါတယ်။
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // `MaybeUninit` ကိုဖြုတ်လိုက်တာဘာမှမလုပ်ဘူး
///     // ထို့ကြောင့်အစား `ptr::write` ၏ကုန်ကြမ်း pointer ကိုတာဝနျကို အသုံးပြု. ကျဆင်းသွားခံရဖို့အဟောင်း uninitialized တန်ဖိုးကိုဖြစ်ပေါ်စေပါဘူး။
/////
///     // တစ်ဦး panic ဒီကွင်းဆက်စဉ်အတွင်းရှိလျှင်လည်း, ကျွန်တော်တစ်ဦးမှတ်ဥာဏ်ယိုစိမ့်ရှိသည်, ဒါပေမယ့်ဘယ်သူမျှမမှတ်ဉာဏ်ဘေးကင်းလုံခြုံမှုပြဿနာလည်းမရှိ။
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // အရာအားလုံးကိုအစပြုသည်
///     // ကနဦးပုံစံဖို့ခင်းကျင်း Transmute ။
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// အနိမ့်အဆင့်ဒေတာဖွဲ့စည်းတည်ဆောက်ပုံများတွင်တွေ့နိုင်သည့်တစိတ်တပိုင်းအစပျိုးအစီအစဉ်များနှင့်လည်းသင်အလုပ်လုပ်နိုင်သည်။
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // `MaybeUninit` ၏ uninitialized ခင်းကျင်းမှုကိုဖန်တီးပါ။
/// // ကျနော်တို့ကဒီမှာနရှိသည်ဟုဟုဆိုကာနေကြသည်အမျိုးအစားစတင်ခြင်းလိုအပ်မထားတဲ့ `MaybeUninit`s, တစည်းသောကွောငျ့ထို `assume_init` လုံခြုံဖြစ်ပါတယ်။
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // ကျနော်တို့တာဝန်ပေးခဲ့ကြသည့်ဒြပ်စင်များ၏အရေအတွက်ကိုရေတွက်။
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Array အတွင်းရှိ item တစ်ခုစီအတွက်ကျွန်ုပ်တို့ခွဲဝေချထားပါ။
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## တစ်ဦး struct လယ်ကွင်း-by-Field စတင်လုပ်ကိုင်
///
/// သင်က [`std::ptr::addr_of_mut`] နိုင်တဲ့ macro လယ်ကွင်းများက structs လယ်ကိုစတငျဖို့, `MaybeUninit<T>` ကိုသုံးပါနှင့်နိုင်သည်
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // `name` field ကိုစတင်ခြင်း
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // `list` field ကိုစတင်ခြင်း panic တစ်ခုရှိလျှင် `String` field ထဲတွင် `String` ယိုစိမ့်သည်။
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // ကျနော်တို့အနေနဲ့န Foo ရဖို့ `assume_init` မခေါ်နိုင်အောင်အားလုံးလယ်ကွင်း, စတင်ဖို့နေကြသည်။
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` `T` ကဲ့သို့တူညီသောအရွယ်အစား, alignment ကိုနှင့် ABI ရှိသည်ဖို့အာမခံချက်ဖြစ်ပါတယ်:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// သို့သော် *`MaybeUninit<T>` ပါ ၀ င်သည့်အမျိုးအစား* တစ်ခုသည်ထပ်တူပုံစံမဟုတ်ကြောင်းသတိရပါ။Rust တစ် `Foo<T>` လယ် `T` နှင့် `U` အတူတူပင်အရွယ်အစားနှင့် alignment ကိုရှိလျှင်ပင်တစ် `Foo<U>` ကဲ့သို့တူညီသောအမိန့်ရှိသည်ယေဘုယျအာမခံချက်ထဲမှာမပါဘူး။
///
/// ထို့အပြင်တစ်ဦး `MaybeUninit<T>` အဆိုပါ compiler အလားအလာပိုကြီးတဲ့အရွယ်အစားရရှိလာတဲ့, non-zero/niche-filling ပိုမိုကောင်းမွန်ရေးလျှောက်ထားနိုင်ဘူးဆိုနည်းနည်းတန်ဖိုးကိုတရားဝင်သည်ဘာဖြစ်လို့လဲဆိုတော့:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// `T` FFI-လုံခြုံလျှင်, ဒါ `MaybeUninit<T>` ဖြစ်ပါတယ်။
///
/// `MaybeUninit` `#[repr(transparent)]` (ညွှန်ပြပါက `T` ကဲ့သို့တူညီသောအရွယ်အစား, alignment ကိုနှင့် ABI မှအာမခံ) ဖြစ်ပါသည်နေစဉ်, ဒီ * * ယခင်အသိပေးချက်မဆိုပြောင်းလဲပစ်မထားဘူး။
/// `Option<T>` နှင့် `Option<MaybeUninit<T>>` တွင်မတူညီသောအရွယ်အစားရှိဆဲဖြစ်ပြီး၊ `T` အမျိုးအစားပါ ၀ င်သည့်အမျိုးအစားများကိုထိုလယ်ကွင်းသည် `MaybeUninit<T>` ထက်ကွဲပြားခြားနားစွာချထားနိုင်သည်။
/// `MaybeUninit` Union type ဖြစ်ပြီးသမဂ္ဂများရှိ `#[repr(transparent)]` သည်မတည်မငြိမ်ဖြစ်သည် ([the tracking issue](https://github.com/rust-lang/rust/issues/60405)) ကိုကြည့်ပါ) ။
/// အချိန်ကြာလာသည်နှင့်အမျှသမဂ္ဂများအပေါ် `#[repr(transparent)]` ၏တိကျသောအာမခံချက်များသည်တဖြည်းဖြည်းပြောင်းလဲလာပြီး `MaybeUninit` သည် `#[repr(transparent)]` ဖြစ်နိုင်သည်သို့မဟုတ်မကျန်ရှိတော့ပေ။
/// ဒါက `MaybeUninit<T>` ကအတူတူပင်အရွယ်အစား, alignment ကိုနှင့် `T` အဖြစ် ABI ရှိကြောင်း *အမြဲ* အာမခံချက်ကြလိမ့်မည်ကိုကလည်း,ဒါကြောင့်ပဲအာမခံချက်တဖြည်းဖြည်းတိုးတက်ပြောင်းလဲစေခြင်းငှါ `MaybeUninit` သုံးကိရိယာလမ်းကိုကြောင်းပါပဲ။
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang item အတွက်ကျွန်တော်တို့ကတခြားအမျိုးအစားတွေကိုထုပ်လို့ရပြီ။ဒီသည်မီးစက်များအတွက်အသုံးဝင်သည်။
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // ကျွန်တော်တို့အဘို့အလုံအလောကျနနေလျှင် `T::clone()` တောင်းဆိုဘဲ, ကြှနျုပျတို့သိနိုင်မှာမဟုတ်ဘူး။
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// ပေးထားသောတန်ဖိုးနှင့်အတူစတင်အသစ်တစ်ခုကို `MaybeUninit<T>` ဖန်တီးပေးပါတယ်။
    /// ဒီ function ကို၏ပြန်လာတန်ဖိုးကိုအပေါ် [`assume_init`] ဖုန်းခေါ်လုံခြုံဖြစ်ပါတယ်။
    ///
    /// တစ်ဦး `MaybeUninit<T>` ကျဆင်းနေ `T` ရဲ့တစ်စက်ကုဒ်မခေါ်ဘယ်တော့မှလိမ့်မည်ဟုမှတ်ချက်။
    /// ဒါဟာနတယ်လျှင်သေချာ `T` ကျဆင်းသွားရရှိစေရန်သင်၏တာဝန်ဖြစ်သည်။
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// uninitialized ပြည်နယ်တစ်ခုတွင် `MaybeUninit<T>` အသစ်တစ်ခုကိုဖန်တီးသည်။
    ///
    /// တစ်ဦး `MaybeUninit<T>` ကျဆင်းနေ `T` ရဲ့တစ်စက်ကုဒ်မခေါ်ဘယ်တော့မှလိမ့်မည်ဟုမှတ်ချက်။
    /// ဒါဟာနတယ်လျှင်သေချာ `T` ကျဆင်းသွားရရှိစေရန်သင်၏တာဝန်ဖြစ်သည်။
    ///
    /// ဥပမာအချို့အတွက် [type-level documentation][MaybeUninit] ကိုကြည့်ပါ။
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// တစ်ဦး uninitialized ပြည်နယ်အတွက်, `MaybeUninit<T>` ပစ္စည်းအသစ်တခုခင်းကျင်းကိုဖန်တီးပါ။
    ///
    /// Note: ခင်းကျင်းသောပကတိ syntax [repeating const expressions](https://github.com/rust-lang/rust/issues/49147) ကိုခွင့်ပြုသည့်အခါ future Rust ဗားရှင်းတွင်ဤနည်းလမ်းသည်မလိုအပ်ပါ။
    ///
    /// အောက်ပါဥပမာသည် `let mut buf = [MaybeUninit::<u8>::uninit(); 32];` ကိုသုံးနိုင်သည်။
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// အမှန်တကယ်ဖတ်ပြီးသော (ဖြစ်နိုင်သည်သေးငယ်သည်) အချက်အလက်၏အချပ်ကိုပြန်သွားသည်
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // လုံခြုံမှု: An `[MaybeUninit<_>; LEN]` တရားဝင်သည် uninitialized ။
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// မှတ်ဉာဏ် `0` နှင့်အတူ bytes ဖြည့်ခံနှင့်အတူတစ်ဦး uninitialized ပြည်နယ်သစ်တစ်ခု `MaybeUninit<T>` ဖန်တီးပေးပါတယ်။ထိုသို့ပြီးသားလျော်သောစတင်ခြင်းစေသည်ရှိမရှိ `T` ပေါ်တွင်မူတည်သည်။
    ///
    /// ဥပမာအားဖြင့်, `MaybeUninit<usize>::zeroed()` န, ဒါပေမယ့်ကိုးကားတရားမဝင်သောမဖြစ်ရဘာဖြစ်လို့လဲဆိုတော့ `MaybeUninit<&'static i32>::zeroed()` မဟုတ်ဖြစ်ပါတယ်။
    ///
    /// တစ်ဦး `MaybeUninit<T>` ကျဆင်းနေ `T` ရဲ့တစ်စက်ကုဒ်မခေါ်ဘယ်တော့မှလိမ့်မည်ဟုမှတ်ချက်။
    /// ဒါဟာနတယ်လျှင်သေချာ `T` ကျဆင်းသွားရရှိစေရန်သင်၏တာဝန်ဖြစ်သည်။
    ///
    /// # Example
    ///
    /// ဒီ function ကို၏မှန်ကန်သောအသုံးပြုမှု: သုညနဲ့ struct စတင်လုပ်ဆောင်သည် struct အပေါငျးတို့သလယ်ကွင်းခိုင်လုံသောတန်ဖိုးကိုအဖြစ်နည်းနည်း-ပုံစံ 0 င်ကိုင်နိုင်မည်ဖြစ်ပါသည်။
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *ဒီ function ကို၏မှားယွင်းနေ* အသုံးပြုမှု: `0` အမျိုးအစားများအတွက်တရားဝင်နည်းနည်း-ပုံစံမပါသောအခါ `x.zeroed().assume_init()` တောင်းဆို:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // တစ်စုံအတွင်းပိုင်းကျနော်တို့ခိုင်လုံသောခွဲခြားဆက်ဆံမှုမရှိပါဘူးတဲ့ `NotZero` ဖန်တီးပါ။
    /// // ဤသည် undefined အပြုအမူဖြစ်ပါတယ်။⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // လုံခြုံမှု-`u.as_mut_ptr()` သည်ခွဲဝေထားသောမှတ်ဉာဏ်ကိုညွှန်ပြသည်။
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// အဆိုပါ `MaybeUninit<T>` ၏တန်ဖိုးကိုသတ်မှတ်ပေးသည်။
    /// ဤသည်ကကျဆင်းနေခြင်းမရှိဘဲမည်သည့်ယခင်တန်ဖိုးကို overwrites ဒါကြောင့်သင် destructor running skip ချင်မဟုတ်လျှင်ဒီနှစ်ကြိမ်မသုံးစွဲဖို့သတိထားပါ။
    ///
    /// သင့်ရဲ့အဆင်ပြေဘို့, ဒီကိုလည်း `self` ၏ (ယခုလုံခြုံစွာန) အကြောင်းအရာများကိုတစ်ဦး mutable ရည်ညွှန်းပြန်လည်ရောက်ရှိ။
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // လုံခြုံမှု: ကျနော်တို့ကဒီတန်ဖိုးကိုန။
        unsafe { self.assume_init_mut() }
    }

    /// အဆိုပါပါရှိသောတန်ဖိုးကိုတစ် pointer ကိုရရှိသွားတဲ့။
    /// ဤညွှန်ပြသူမှဖတ်ခြင်းသို့မဟုတ်ရည်ညွှန်းခြင်းသို့ပြောင်းလဲခြင်းသည် `MaybeUninit<T>` ကိုအစပြုခြင်းမရှိပါကသတ်မှတ်ထားသောအပြုအမူဖြစ်သည်။
    /// ဒီ pointer (non-transitively) အချက်များမှ (တစ်ဦး `UnsafeCell<T>` အတွင်းပိုင်း မှလွဲ.) undefined အပြုအမူကြောင်းကိုမှတ်ဉာဏ်မှရေးသားခြင်း။
    ///
    /// # Examples
    ///
    /// ဤနည်းလမ်းကိုမှန်ကန်စွာအသုံးပြုခြင်း-
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // အဆိုပါ `MaybeUninit<T>` သို့ရည်ညွှန်းဖန်တီးပါ။ကျွန်တော်နသောကွောငျ့ဤသည်အဆင်ပြေသည်။
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *ဒီနည်းလမ်းရဲ့မှားယွင်းနေ* အသုံးပြုမှု:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // ကျနော်တို့က uninitialized vector ကိုရည်ညွှန်းကိုဖန်တီးလိုက်ပြီ။ဤသည် undefined အပြုအမူဖြစ်ပါတယ်။⚠️
    /// ```
    ///
    /// (uninitialized ဒေတာမှကိုးကားန်းကျင်စည်းမျဉ်းစည်းကမ်းတွေကိုသေးအပြီးသတ်ကြသည်မဟုတ်ကြောင်းသတိပြုပါ, ဒါပေမဲ့သူတို့ဖြစ်ကြသည်သည်အထိပြုလုပ်သူတို့ကိုရှောင်ရှားရန်အကြံပြုလိုတယ်။)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` နှင့် `ManuallyDrop` နှစ်ခုစလုံးသည် `repr(transparent)` ဖြစ်သည်။ ထို့ကြောင့်ကျွန်ုပ်တို့သည် pointer ကိုချနိုင်သည်။
        self as *const _ as *const T
    }

    /// ပါ ၀ င်သည့်တန်ဖိုးတစ်ခုသို့ပြောင်းလဲနိုင်သော pointer ကိုရရှိသည်။
    /// ဤညွှန်ပြသူမှဖတ်ခြင်းသို့မဟုတ်ရည်ညွှန်းခြင်းသို့ပြောင်းလဲခြင်းသည် `MaybeUninit<T>` ကိုအစပြုခြင်းမရှိပါကသတ်မှတ်ထားသောအပြုအမူဖြစ်သည်။
    ///
    /// # Examples
    ///
    /// ဤနည်းလမ်းကိုမှန်ကန်စွာအသုံးပြုခြင်း-
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<Vec<u32>>` သို့ရည်ညွှန်းတစ်ခုဖန်တီးပါ။
    /// // ဒါကိုအစပြုလို့ဒါကအဆင်ပြေပါတယ်။
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *ဒီနည်းလမ်းရဲ့မှားယွင်းနေ* အသုံးပြုမှု:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // ကျနော်တို့က uninitialized vector ကိုရည်ညွှန်းကိုဖန်တီးလိုက်ပြီ။ဤသည် undefined အပြုအမူဖြစ်ပါတယ်။⚠️
    /// ```
    ///
    /// (uninitialized ဒေတာမှကိုးကားန်းကျင်စည်းမျဉ်းစည်းကမ်းတွေကိုသေးအပြီးသတ်ကြသည်မဟုတ်ကြောင်းသတိပြုပါ, ဒါပေမဲ့သူတို့ဖြစ်ကြသည်သည်အထိပြုလုပ်သူတို့ကိုရှောင်ရှားရန်အကြံပြုလိုတယ်။)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` နှင့် `ManuallyDrop` နှစ်ခုစလုံးသည် `repr(transparent)` ဖြစ်သည်။ ထို့ကြောင့်ကျွန်ုပ်တို့သည် pointer ကိုချနိုင်သည်။
        self as *mut _ as *mut T
    }

    /// အဆိုပါ `MaybeUninit<T>` ကွန်တိန်နာကနေတန်ဖိုး Extracts ။ဒါကရရှိလာတဲ့ `T` ပုံမှန်တစ်စက်ကိုင်တွယ်ရန်ဘာသာရပ်တစ်ခုဖြစ်သည်ကြောင့်ဒေတာ, ကျဆင်းသွားရလိမ့်မည်ဟုသေချာစေရန်အကောင်းဆုံးနည်းလမ်းဖြစ်ပါတယ်။
    ///
    /// # Safety
    ///
    /// ဒါဟာ `MaybeUninit<T>` တကယ်တစ်ခု Initiative ပြည်နယ်အတွင်းရှိကြောင်းအာမခံချက်ပေးဖို့ခေါ်ဆိုသူ၏အထိဖြစ်ပါတယ်။အကြောင်းအရာသေးအပြည့်အဝနမပါသည့်အခါဤအ Calling ချက်ချင်း undefined အပြုအမူကိုဖြစ်ပေါ်စေသည်။
    /// အဆိုပါ [type-level documentation][inv] ဒီကန ဦး လျော့ပါးသွားမည်ဖြစ်သလိုအကြောင်းကိုပိုမိုသောအချက်အလက်များပါရှိသည်။
    ///
    /// [inv]: #initialization-invariant
    ///
    /// ကြောင်း၏ထိပ်တွင်အများစုအမျိုးအစားများမျှသာအမျိုးအစားကိုအဆင့်မှာနထည့်သွင်းစဉ်းစားထားကြောင်းကျော်လွန်ပြီးနောက်ထပ်လျော့ပါးသွားမည်ဖြစ်သလိုရှိသည်သတိရပါ။
    /// ဥပမာအားဖြင့် `1`-initialized [`Vec<T>`] ကို (လက်ရှိအကောင်အထည်ဖော်မှုအောက်တွင်၊ ဤသည်တည်ငြိမ်သောအာမခံချက်မဟုတ်ပါ) အစပြုသည်ဟုမှတ်ယူသည်။ အဘယ်ကြောင့်ဆိုသော် compiler ကသိသောတစ်ခုတည်းသောလိုအပ်ချက်မှာ data pointer သည် null မဟုတ်သောကြောင့်ဖြစ်သည်။
    ///
    /// ထိုကဲ့သို့သော `Vec<T>` တစ်ခုကိုဖန်တီးခြင်းသည် * ချက်ချင်းမသင့်လျော်သောအပြုအမူများကိုဖြစ်ပေါ်စေသည်မဟုတ်သော်လည်း (၎င်းကိုဖယ်ရှားခြင်းအပါအ ၀ င်) လုံခြုံစိတ်ချရသောလုပ်ဆောင်မှုအများစုနှင့်အတူသတ်မှတ်ထားသောအပြုအမူများကိုဖြစ်ပေါ်စေသည်။
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// ဤနည်းလမ်းကိုမှန်ကန်စွာအသုံးပြုခြင်း-
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *ဒီနည်းလမ်းရဲ့မှားယွင်းနေ* အသုံးပြုမှု:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` သေးနဒါကြောင့်ဒီနောက်ဆုံးလိုင်း undefined အပြုအမူစေသောမခံခဲ့ရ။⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // လုံခြုံမှု: `self` နသောခေါ်ဆိုသူ၏မဖြစ်မနေအာမခံ။
        // ဆိုလိုသည်မှာ `self` သည် `value` မူကွဲတစ်ခုဖြစ်သည်။
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// `MaybeUninit<T>` ကွန်တိန်နာမှတန်ဖိုးကိုဖတ်သည်။ရရှိလာတဲ့ `T` ပုံမှန်တစ်စက်ကိုင်တွယ်ရန်ဘာသာရပ်ဖြစ်ပါသည်။
    ///
    /// အခါတိုင်းတတ်နိုင်သမျှကြောင့်တားဆီးသည့် `MaybeUninit<T>` များ၏ content duplicating သောအစား [`assume_init`] သုံးစွဲဖို့ပိုကောင်းပါတယ်။
    ///
    /// # Safety
    ///
    /// ဒါဟာ `MaybeUninit<T>` တကယ်တစ်ခု Initiative ပြည်နယ်အတွင်းရှိကြောင်းအာမခံချက်ပေးဖို့ခေါ်ဆိုသူ၏အထိဖြစ်ပါတယ်။အကြောင်းအရာကိုအပြည့်အဝအစပြုခြင်းမရှိသေးသည့်အချိန်တွင်ဤအရာကိုခေါ်ဆိုခြင်းသည်မသေချာသည့်အပြုအမူကိုဖြစ်ပေါ်စေသည်။
    /// အဆိုပါ [type-level documentation][inv] ဒီကန ဦး လျော့ပါးသွားမည်ဖြစ်သလိုအကြောင်းကိုပိုမိုသောအချက်အလက်များပါရှိသည်။
    ///
    /// ထို့အပြင်၎င်းသည် `MaybeUninit<T>` တွင်တူညီသောဒေတာမိတ္တူတစ်ခုကျန်ခဲ့သည်။
    /// ယင်းအချက်အလက်များ၏မျိုးစုံမိတ္တူ (`assume_init_read` ခေါ်ဆိုခြင်းဖြင့်အကြိမ်ပေါင်းများစွာ, ဒါမှမဟုတ်ပထမဦးဆုံးခေါ်ဆိုမှု `assume_init_read` ပြီးတော့ [`assume_init`]) ကို အသုံးပြု. အခါ, ကဒေတာအမှန်ပင်ကော်ပီပွားယူစေခြင်းငှါသေချာစေရန်သင်၏တာဝန်ဖြစ်သည်။
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ဤနည်းလမ်းကိုမှန်ကန်စွာအသုံးပြုခြင်း-
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` `Copy` ဖြစ်ပါသည်, ဒါကြောင့်ကျနော်တို့အကြိမ်ပေါင်းများစွာဖတ်ပါလိမ့်မည်။
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `None` တန်ဖိုးကိုပုံတူပွားခြင်းသည်အဆင်ပြေပါသည်။ ထို့ကြောင့်ကျွန်ုပ်တို့သည်အကြိမ်ပေါင်းများစွာဖတ်ရှုနိုင်ပါသည်။
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *ဒီနည်းလမ်းရဲ့မှားယွင်းနေ* အသုံးပြုမှု:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // ယခုငါတို့ vector တူညီသောမိတ္တူနှစ်စောင်ကိုဖန်တီးလိုက်သည်၊ သူတို့နှစ် ဦး လုံးကျဆင်းသွားသည့်အခါအခမဲ့ဖြစ်သည်။
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // လုံခြုံမှု: `self` နသောခေါ်ဆိုသူ၏မဖြစ်မနေအာမခံ။
        // `self` မှစတင်ခြင်းကိုပြုလုပ်သင့်သောကြောင့် `self.as_ptr()` မှစာဖတ်ခြင်းသည်လုံခြုံသည်။
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// အရပ်ဌာန၌ပါရှိသောတန်ဖိုးကိုပြန်လည်ရုပ်သိမ်းသွားခဲ့သည်။
    ///
    /// သင် `MaybeUninit` ၏ပိုင်ဆိုင်မှုရှိပါက, သင်မယ့်အစား [`assume_init`] ကိုသုံးနိုင်သည်။
    ///
    /// # Safety
    ///
    /// ဒါဟာ `MaybeUninit<T>` တကယ်တစ်ခု Initiative ပြည်နယ်အတွင်းရှိကြောင်းအာမခံချက်ပေးဖို့ခေါ်ဆိုသူ၏အထိဖြစ်ပါတယ်။အကြောင်းအရာကိုအပြည့်အဝအစပြုခြင်းမရှိသေးသည့်အချိန်တွင်ဤအရာကိုခေါ်ဆိုခြင်းသည်မသေချာသည့်အပြုအမူကိုဖြစ်ပေါ်စေသည်။
    ///
    /// `T` (သို့မဟုတ်ယင်း၏အဖွဲ့ဝင်) ၏ `Drop` အကောင်အထည်ဖော်မှုဒီအပေါ်အားကိုးဖြစ်နိုင်သည်အဖြစ်ကြောင်း၏ထိပ်တွင်, အမျိုးအစား `T` အပေါငျးတို့သနောက်ထပ်လျော့ပါးသွားမည်ဖြစ်သလို, ဝစွာစားရကြမည်။
    /// ဥပမာအားဖြင့် `1`-initialized [`Vec<T>`] ကို (လက်ရှိအကောင်အထည်ဖော်မှုအောက်တွင်၊ ဤသည်တည်ငြိမ်သောအာမခံချက်မဟုတ်ပါ) အစပြုသည်ဟုမှတ်ယူသည်။ အဘယ်ကြောင့်ဆိုသော် compiler ကသိသောတစ်ခုတည်းသောလိုအပ်ချက်မှာ data pointer သည် null မဟုတ်သောကြောင့်ဖြစ်သည်။
    ///
    /// သို့သော်ထိုကဲ့သို့သော `Vec<T>` ကိုဖြုတ်လိုက်ခြင်းသည်သတ်မှတ်ထားသောအပြုအမူကိုဖြစ်ပေါ်စေသည်။
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // လုံခြုံမှု: `self` နသောခေါ်ဆိုသူ၏မဖြစ်မနေအာမခံချက်နှင့်
        // ရဲ `T` အပေါငျးတို့သလျော့ပါးသွားမည်ဖြစ်သလို။
        // သောအမှုဖြစ်လျှင်အရပ်ဌာန၌တနျဖိုးကျဆင်းနေလုံခြုံဖြစ်ပါတယ်။
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// အဆိုပါပါရှိသောတန်ဖိုးကိုတစ်ဦး shared ရည်ညွှန်းရရှိသွားတဲ့။
    ///
    /// ကျနော်တို့နထားပြီးပေမယ့် `MaybeUninit` ၏ပိုင်ဆိုင်မှု (`.assume_init()`) ၏အသုံးပြုမှုကိုကာကွယ်ပေးနိုင်မယ့် `MaybeUninit` ရယူချင်တဲ့အခါဒီအသုံးကျနိုင်ပါသည်။
    ///
    /// # Safety
    ///
    /// အကြောင်းအရာကိုအပြည့်အဝအစပြုခြင်းမရှိသေးပါကဖုန်းခေါ်ဆိုမှုသည်အဓိပ္ပာယ်မဲ့သောအပြုအမူကိုဖြစ်ပေါ်စေသည်-`MaybeUninit<T>` သည်အစစ်အမှန်အခြေအနေတွင်ရှိကြောင်းအာမခံသူသည်သူမအပေါ်မူတည်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ### ဤနည်းလမ်းကိုမှန်ကန်စွာအသုံးပြုခြင်း-
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Initiative `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // အခုဆိုရင်ကျွန်တော်တို့ရဲ့ `MaybeUninit<_>` စတင်ဖို့သိကြောင်း, အဲဒါကိုတစ်ဦး shared ရည်ညွှန်းဖန်တီးဖို့အဆင်ပြေသည်:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // လုံခြုံမှု-`x` ကိုအစပြုထားသည်။
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### ဒီနည်းလမ်းရဲ့ *မှားယွင်းနေ* သုံးစွဲမှု:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // ကျနော်တို့က uninitialized vector ကိုရည်ညွှန်းကိုဖန်တီးလိုက်ပြီ။ဤသည် undefined အပြုအမူဖြစ်ပါတယ်။⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // `MaybeUninit` ကိုအသုံးပြုပြီး `MaybeUninit` ကိုစတင်ပါ။
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // တစ်ဦး uninitialized `Cell<bool>` ဖို့ကိုးကားစရာ: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // လုံခြုံမှု: `self` နသောခေါ်ဆိုသူ၏မဖြစ်မနေအာမခံ။
        // ဆိုလိုသည်မှာ `self` သည် `value` မူကွဲတစ်ခုဖြစ်သည်။
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// ပါ ၀ င်သောတန်ဖိုးကိုပြောင်းလဲနိုင်သော (unique) ရည်ညွှန်းမှုရရှိသည်။
    ///
    /// ကျနော်တို့နထားပြီးပေမယ့် `MaybeUninit` ၏ပိုင်ဆိုင်မှု (`.assume_init()`) ၏အသုံးပြုမှုကိုကာကွယ်ပေးနိုင်မယ့် `MaybeUninit` ရယူချင်တဲ့အခါဒီအသုံးကျနိုင်ပါသည်။
    ///
    /// # Safety
    ///
    /// အကြောင်းအရာကိုအပြည့်အဝအစပြုခြင်းမရှိသေးပါကဖုန်းခေါ်ဆိုမှုသည်အဓိပ္ပာယ်မဲ့သောအပြုအမူကိုဖြစ်ပေါ်စေသည်-`MaybeUninit<T>` သည်အစစ်အမှန်အခြေအနေတွင်ရှိကြောင်းအာမခံသူသည်သူမအပေါ်မူတည်သည်။
    /// ဥပမာအားဖြင့် `.assume_init_mut()` ကို `MaybeUninit` တစ်ခုကိုအစပျိုးရန်အသုံးမပြုပါ။
    ///
    /// # Examples
    ///
    /// ### ဤနည်းလမ်းကိုမှန်ကန်စွာအသုံးပြုခြင်း-
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// *input* buffer ၏ bytes များအားလုံးကိုအစပြုစေသည်။
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Initiative `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // အခုဆိုရင်ကျွန်တော်တို့ဟာအဲဒါကို `.assume_init()` နိုင်အောင် `buf`, စတင်ဖို့လျက်ရှိသည်ကိုငါသိ၏။
    /// // သို့သော် `.assume_init()` ကိုအသုံးပြုခြင်းသည် 2048 bytes ၏ `memcpy` ကိုဖြစ်ပေါ်စေသည်။
    /// // ကျွန်တော်တို့ရဲ့ကြားခံတစ်ခုကိုကူးယူခြင်းမရှိဘဲနထားပြီးအခိုင်အမာစေရန်, ကျွန်တော်တစ်ဦး `&mut [u8; 2048]` ဖို့ `&mut MaybeUninit<[u8; 2048]>` upgrade:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // လုံခြုံမှု: `buf` နလျက်ရှိသည်။
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // ယခုကျွန်ုပ်တို့သည် `buf` ကိုပုံမှန်အချပ်တစ်ခုအဖြစ်သုံးနိုင်သည်။
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### ဒီနည်းလမ်းရဲ့ *မှားယွင်းနေ* သုံးစွဲမှု:
    ///
    /// သင်တစ်ဦးတန်ဖိုးကိုစတငျဖို့ `.assume_init_mut()` မသုံးနိုင်သည်
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // ကျနော်တို့အနေနဲ့ uninitialized `bool` တစ် (mutable) ရည်ညွှန်း created ပွီ!
    ///     // ဤသည် undefined အပြုအမူဖြစ်ပါတယ်။⚠️
    /// }
    /// ```
    ///
    /// ဥပမာအားဖြင့်သင်သည် [`Read`] ကို uninitialized buffer တစ်ခုထဲသို့မသွင်းနိူင်ပါ။
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) uninitialized မှတ်ဉာဏ်မှရည်ညွှန်း!
    ///                             // ဤသည် undefined အပြုအမူဖြစ်ပါတယ်။
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// မလယ်ပြင်-by-Field တဖြည်းဖြည်းစတင်ခြင်းလုပ်ဖို့တိုက်ရိုက်လယ်ကို access ကိုအသုံးပွုနိုငျ:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) uninitialized မှတ်ဉာဏ်မှရည်ညွှန်း!
    ///                  // ဤသည် undefined အပြုအမူဖြစ်ပါတယ်။
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) uninitialized မှတ်ဉာဏ်မှရည်ညွှန်း!
    ///                  // ဤသည် undefined အပြုအမူဖြစ်ပါတယ်။
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): ကျွန်ုပ်တို့သည်လက်ရှိအထက်ပါအမှားအယွင်းများအပေါ်မှီခိုရသည်။ ဆိုလိုသည်မှာကျွန်ုပ်တို့သည်အသိအမှတ်မပြုထားသောအချက်အလက်များကိုကိုးကားထားသည် (ဥပမာ-`libcore/fmt/float.rs`) ။
    // ကျနော်တို့တည်ငြိမ်ရှေ့တော်၌ထိုစည်းမျဉ်းစည်းကမ်းတွေအကြောင်းနောက်ဆုံးဆုံးဖြတ်ချက်ချသင့်ပါတယ်။
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // လုံခြုံမှု: `self` နသောခေါ်ဆိုသူ၏မဖြစ်မနေအာမခံ။
        // ဆိုလိုသည်မှာ `self` သည် `value` မူကွဲတစ်ခုဖြစ်သည်။
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// တန်ဖိုးများကို `MaybeUninit` ကွန်တိန်နာတစ်ခုခင်းကျင်းမှထုတ်ယူ။
    ///
    /// # Safety
    ///
    /// ဒါဟာစစ်ခင်းကျင်း၌ရှိသမျှသောဒြပ်စင်တစ်ခု Initiative ပြည်နယ်အတွက်ဖြစ်ကြောင်းအာမခံချက်ပေးဖို့ခေါ်ဆိုသူ၏အထိဖြစ်ပါတယ်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // လုံခြုံမှု: ငါတို့ရှိသမျှသည်ဒြပ်စင် initialised အဖြစ်အခုတော့ဘေးကင်းလုံခြုံ
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * အဆိုပါစစ်ခင်းကျင်း၌ရှိသမျှသောဒြပ်စင်နဖြစ်ကြောင်းအဆိုပါခေါ်ဆိုသူ၏အာမခံချက်
        // * `MaybeUninit<T>` နှင့် T အတူတူ layout ကိုရှိသည်အာမခံနေကြသည်
        // * Unint ကမကျဘူးဒါကြောင့် double-frees မရှိဘူး
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// လူအပေါင်းတို့သည်ဒြပ်စင်နနေကြတယ်ယူဆရင်သူတို့တစ်ဦးအချပ်ရ။
    ///
    /// # Safety
    ///
    /// ဒါဟာ `MaybeUninit<T>` element တွေကိုတကယ်တစ်ခု Initiative ပြည်နယ်အတွက်ဖြစ်ကြောင်းအာမခံချက်ပေးဖို့ခေါ်ဆိုသူ၏အထိဖြစ်ပါတယ်။
    ///
    /// အကြောင်းအရာသေးအပြည့်အဝအကြောင်းတရားများအပြုအမူ undefined နမပါသည့်အခါဤအ Calling ။
    ///
    /// အသေးစိတ်များနှင့်ဥပမာအဘို့အ [`assume_init_ref`] ကိုကြည့်ပါ။
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူမှအာမခံသောကြောင့် `*const [T]` သို့အချပ်ကိုချခြင်းသည်လုံခြုံသည်
        // `slice` စတင်လုပ်ဆောင်သည်နှင့် `MaybeUninit` သည် `T` ကဲ့သို့ layout တစ်ခုရရှိရန်အာမခံထားသည်။
        // ဒါကြောင့်တစ်ဦးကိုကိုးကားသည်နှင့်, အရှင်ဖတ်ဘို့တရားဝင်ဖြစ်ဖို့အာမခံပေးသော `slice` ကပိုင်ဆိုင်မှတ်ဉာဏ်ကိုရည်ညွှန်းကတည်းကရရှိသော pointer ကိုတရားဝင်သည်။
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Element တွေအားလုံးကိုအစပျိုးလိုက်မယ်ဆိုရင်သူတို့ကို mutable slice တစ်ခုယူလိုက်ပါ။
    ///
    /// # Safety
    ///
    /// ဒါဟာ `MaybeUninit<T>` element တွေကိုတကယ်တစ်ခု Initiative ပြည်နယ်အတွက်ဖြစ်ကြောင်းအာမခံချက်ပေးဖို့ခေါ်ဆိုသူ၏အထိဖြစ်ပါတယ်။
    ///
    /// အကြောင်းအရာသေးအပြည့်အဝအကြောင်းတရားများအပြုအမူ undefined နမပါသည့်အခါဤအ Calling ။
    ///
    /// အသေးစိတ်များနှင့်ဥပမာအဘို့အ [`assume_init_mut`] ကိုကြည့်ပါ။
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // `slice_get_ref` အဘို့ဘေးကင်းလုံခြုံမှုမှတ်စုဆင်တူပေမယ့်ကျွန်တော်တစ်ဦးရှိသည်: လုံခြုံမှု
        // ထို့အပြင်ရေးသားချက်များအတွက်တရားဝင်ဖြစ်ဖို့အာမခံထားသော mutable ရည်ညွှန်း။
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// အဆိုပါစစ်ခင်းကျင်း၏ပထမဦးဆုံးဒြပ်စင်တစ်ခု pointer ကိုရရှိသွားတဲ့။
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// အဆိုပါစစ်ခင်းကျင်း၏ပထမဦးဆုံးဒြပ်စင်တစ်ခု mutable pointer ကိုရရှိသွားတဲ့။
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// `this` ၏ယခု initalized အကြောင်းအရာများကိုတစ်ဦး mutable ရည်ညွှန်းပြန်လာမိတ္တူ `this` မှ `src` ကနေဒြပ်စင်။
    ///
    /// `T` `Copy` အကောင်အထည်ဖော်မပါဘူးဆိုရင်, [`write_slice_cloned`] ကိုသုံးပါ
    ///
    /// ဒါက [`slice::copy_from_slice`] နဲ့ဆင်တူတယ်။
    ///
    /// # Panics
    ///
    /// နှစ်ခုချပ်ကွဲပြားခြားနားသောအရှည်ရှိပါကဒီ function ကို panic ပါလိမ့်မယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // လုံခြုံမှု: ငါတို့သည်ရုံအားလပ်ချိန်မှာစွမ်းရည်သို့ Len အပေါငျးတို့သ element တွေကိုကူးယူပါပြီ
    /// // အဆိုပါ Vec ကာကွယ်ဆေးကိုရေရဲ့ပထမဦးဆုံး src.len() ဒြပ်စင်သည်ယခုအခါတရားဝင်ဖြစ်ကြသည်။
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // လုံခြုံမှု: &[T က] နှင့်&[MaybeUninit<T>] တူညီ layout ကိုရှိ
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // လုံခြုံမှု: က initalized ဖြစ်ပါတယ်ဒါကြောင့်သက်တမ်းရှိဒြပ်စင်ရုံ `this` သို့ကူးယူပြီ
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// element များကို `src` မှ `this` သို့ Clone လုပ်ပြီးယခု `this` ၏အတိုကောက်စာလုံးများကို mutable reference တစ်ခုပြန်ပေးသည်။
    /// မဆိုပြီးသား initalized ဒြပ်စင်ကျဆင်းသွားလိမ့်မည်မဟုတ်ပါ။
    ///
    /// `T` သုံးကိရိယာ `Copy` လြှငျ, [`write_slice`] ကိုသုံးပါ
    ///
    /// ဤသည် [`slice::clone_from_slice`] ဆင်တူသော်လည်းလက်ရှိ element တွေကို drop မထားဘူး။
    ///
    /// # Panics
    ///
    /// ဒီ function panic နှစ်ခုချပ်ကွဲပြားခြားနားသောအရှည်ရှိသည်, သို့မဟုတ် `Clone` panics များ၏အကောင်အထည်ဖော်မှုလျှင်မည်။
    ///
    /// အကယ်၍ panic ရှိပါက၊ ပုံတူပွားထားသော element များကိုပယ်ဖျက်လိမ့်မည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // ဘေးကင်းလုံခြုံမှု-len ၏ဒြပ်စင်များအားလုံးကိုစွမ်းဆောင်ရည်မြှင့်တင်ရုံမျှသာပြုလုပ်ပြီးဖြစ်သည်
    /// // အဆိုပါ Vec ကာကွယ်ဆေးကိုရေရဲ့ပထမဦးဆုံး src.len() ဒြပ်စင်သည်ယခုအခါတရားဝင်ဖြစ်ကြသည်။
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // copy_from_slice နှင့်မတူသည်မှာ `MaybeUninit<T: Clone>` Clone ကိုအကောင်အထည်မဖော်သောကြောင့်၎င်းသည် slice ပေါ်တွင် clone_from_slice ဟုမခေါ်ပါ။
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // လုံခြုံမှု: ဤကုန်ကြမ်းအချပ်သာ Initiative အရာဝတ္ထုဆံ့ပါလိမ့်မယ်
                // ကြောင်းအဘယ်ကြောင့်ထိုသို့ drop ခွင့်ပြုခဲ့တာဖြစ်ပါတယ်ရဲ့။
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: ကျနော်တို့ကသူတို့ကိုအတိအကျတူညီအရှည်အထိချပ်ဖို့လိုအပ်ပါတယ်
        // အကန့်အသတ်မရှိဖယ်ရှားရန်နှင့် optimizer သည်ကိစ္စရပ်များအတွက် memcpy ကိုထုတ်ပေးလိမ့်မည် (ဥပမာ T= u8) ။
        //
        let len = this.len();
        let src = &src[..len];

        // ကိုယ်ရံတော် b/c panic တစ်ဦးကိုယ်ပွားကာလအတွင်းဖြစ်ပျက်စေခြင်းငှါ, လိုအပျ
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // လုံခြုံမှု-ခိုင်လုံသောဒြပ်စင်များကို `this` သို့သာရေးထားပြီးဖြစ်သည်
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}