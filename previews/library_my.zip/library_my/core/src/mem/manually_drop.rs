use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// `T` ၏ဖျက်ဆီးခြင်းကိုအလိုအလျောက်ခေါ်ခြင်းမှ compiler ကိုတားဆီးမည့်အိတ်တစ်ခု။
/// ဤသည် wrapper 0 င်ကုန်ကျစရိတ်ဖြစ်ပါသည်။
///
/// `ManuallyDrop<T>` `T` ကဲ့သို့တူညီသော layout ကိုပိုမိုကောင်းမွန်ရေးမှဘာသာရပ်ဖြစ်ပါသည်။
/// အကျိုးဆက်ကြောင့် *အ compiler ကသူ့ရဲ့အကြောင်းအရာတွေကိုအကြောင်းကိုစေသည်သောယူဆချက်အပေါ်အဘယ်သူမျှမသက်ရောက်* ရှိပါတယ်။
/// ဥပမာအားဖြင့်, [`mem::zeroed`] အတူ `ManuallyDrop<&mut T>` စတင်လုပ်ဆောင် undefined အပြုအမူဖြစ်ပါတယ်။
/// သင် uninitialized data ကိုကိုင်တွယ်ရန်လိုအပ်ပါကအစား [`MaybeUninit<T>`] ကိုသုံးပါ။
///
/// တစ်ဦး `ManuallyDrop<T>` အတွင်းပိုင်းတန်ဖိုးကိုရယူသုံးအန္တရာယ်ကင်းကြောင်းမှတ်ချက်။
/// ဆိုလိုသည်မှာအကြောင်းအရာများကိုရုပ်သိမ်းလိုက်သော `ManuallyDrop<T>` ကိုအများသုံးလုံခြုံသည့် API မှမထုတ်ဖော်သင့်ပါ။
/// Correspondingly, `ManuallyDrop::drop` မလုံခြုံသည်။
///
/// # `ManuallyDrop` နှင့်အမိန့် drop ။
///
/// Rust တန်ဖိုးများကိုတစ်ဦးကောင်းမွန်စွာသတ်မှတ် [drop order] ရှိပါတယ်။
/// သေချာလယ်ကွင်းသို့မဟုတ်ဒေသခံတွေတိကျတဲ့နိုင်ရန်အတွက်ကျဆင်းသွားသည်ဟုစေခြင်းငှါ, သွယ်ဝိုက်တစ်စက်အလို့ငှာမှန်ကန်သောတဦးတည်းကြောင်းထိုကဲ့သို့သောကြေညာချက်များပြန်စီ။
///
/// `ManuallyDrop` ကို အသုံးပြု၍ drop order ကိုထိန်းချုပ်ရန်ဖြစ်နိုင်သည်၊ သို့သော်၎င်းသည်မလုံခြုံသောကုဒ်နံပါတ်လိုအပ်သည်။ unwinding ၏ရှေ့မှောက်တွင်မှန်ကန်စွာလုပ်ဆောင်ရန်ခက်ခဲသည်။
///
///
/// သင်တစ်ဦးသတ်သတ်မှတ်မှတ်လယ်အခြားသူတွေပြီးနောက်ကျဆင်းသွားကြောင်းသေချာစေရန်ချင်တယ်ဆိုရင်ဥပမာ, က struct ၏နောက်ဆုံးသောလယ်လုပ်:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` `children` ပြီးနောက်ကျဆင်းသွားပါလိမ့်မည်။
///     // Rust သည်နယ်ပယ်များအားကြေငြာသည့်အနေဖြင့်ကျဆင်းသွားသည်ကိုအာမခံသည်။
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// ကိုယ်တိုင်ကျဆင်းသွားခံရဖို့တန်ဖိုးခြုံ။
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // သင်သည်တန်ဖိုးကိုလုံခြုံစွာလည်ပတ်နိုင်သည်
    /// assert_eq!(*x, "Hello");
    /// // ဒါပေမယ့် `Drop` ကိုဒီမှာ run မှာမဟုတ်ဘူး
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// အဆိုပါ `ManuallyDrop` ကွန်တိန်နာကနေတန်ဖိုး Extracts ။
    ///
    /// ဒါကတန်ဖိုးကိုနောက်တဖန်ကျဆင်းသွားခံရဖို့ခွင့်ပြုပါတယ်။
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // ဒါက `Box` ပြန်လည်ရုပ်သိမ်းသွားခဲ့သည်။
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// အဆိုပါ `ManuallyDrop<T>` ကွန်တိန်နာထဲကတန်ဖိုးကိုကြာပါသည်။
    ///
    /// ဤနည်းလမ်းကိုအဓိကအားတစ်စက်အတွက်တန်ဖိုးများကိုထွက်ရွေ့လျားရည်ရွယ်သည်။
    /// တန်ဖိုးကိုကိုယ်တိုင်လျှော့ချရန် [`ManuallyDrop::drop`] ကိုအသုံးပြုမည့်အစား၊ သင်ဤနည်းကို သုံး၍ တန်ဖိုးကိုယူပြီးမည်သို့ပင်ဖြစ်စေသုံးနိုင်သည်။
    ///
    /// ဖြစ်နိုင်လျှင် `ManuallyDrop<T>` ကိုအသုံးပြုခြင်းသည် `ManuallyDrop<T>` ၏အကြောင်းအရာများကိုပုံတူကူးချခြင်းကိုတားဆီးသောကြောင့်ဖြစ်သည်။
    ///
    ///
    /// # Safety
    ///
    /// ဒီ function ဝေါဟာရအသုံးအနှုံးမပြောင်းလဲဒီကွန်တိန်နာ၏ပြည်နယ်ထွက်ခွာနောက်ထပ်အသုံးပြုမှုတားဆီးမရှိဘဲပါရှိသောတန်ဖိုးကိုထွက်လှုံ့ဆော်ပေး။
    /// ဒါဟာ `ManuallyDrop` နောက်တဖန်မသုံးကြောင်းသေချာစေရန်သင်၏တာဝန်ဖြစ်သည်။
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // လုံခြုံမှု: ငါတို့သည်အာမခံသောတစ်ဦးကိုကိုးကားမှဖတ်
        // ဖတ်များအတွက်တရားဝင်ဖြစ်ရန်။
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// ကိုယ်တိုင်ပါရှိသောတန်ဖိုးကိုပြန်လည်ရုပ်သိမ်းသွားခဲ့သည်။ဒါကပါရှိသောတန်ဖိုးကိုတစ် pointer နှင့်အတူ [`ptr::drop_in_place`] တောင်းဆိုဖို့အတိအကျညီမျှသည်။
    /// အဆိုပါပါရှိသောတန်ဖိုးကိုတစ်ဗူး struct ဖြစ်ပါသည်မဟုတ်လျှင်ကဲ့သို့သောသည်, destructor တန်ဖိုးကိုရွေ့လျားခြင်းမရှိဘဲ In-ရာအရပျဟုခေါ်ဝေါ်ခြင်းကိုခံရလိမ့်မည်, ဤသို့လုံခြုံစွာ [pinned] data တွေကို drop ဖို့အသုံးပြုနိုင်ပါသည်။
    ///
    /// သင်တန်ဖိုးပိုင်ဆိုင်မှုရှိပါက, သင်မယ့်အစား [`ManuallyDrop::into_inner`] ကိုသုံးနိုင်သည်။
    ///
    /// # Safety
    ///
    /// ဒီ function မှာပါ ၀ င်တဲ့ value ရဲ့ destructor ကို run တယ်။
    /// ဖျက်ဆီးသူကိုယ်တိုင်ပြုလုပ်ခဲ့သောအပြောင်းအလဲများ မှလွဲ၍ မှတ်ဉာဏ်သည်မပြောင်းလဲဘဲကျန်ရှိနေသေးသည်။ compiler ကမူ `T` အမျိုးအစားအတွက်မှန်ကန်သော bit-pattern ကိုဆက်လက်ထိန်းသိမ်းထားသည်။
    ///
    ///
    /// သို့သော်၊ ဒီ "zombie" တန်ဖိုးကိုလုံခြုံတဲ့ကုဒ်နဲ့မထိတွေ့သင့်ဘူး၊ ဒီ function ကိုတစ်ကြိမ်ထက်မကမခေါ်သင့်ဘူး။
    /// အကြိမ်ပေါင်းများစွာပြုလုပ်ကျဆင်းသွားခဲ့ရဲ့ပြီးနောက်တန်ဖိုးကိုသုံးပါ, ဒါမှမဟုတ်တန်ဖိုးကျဆင်း, (`drop` ဘာပေါ် မူတည်.) Undefined အပြုအမူကိုဖြစ်ပေါ်စေနိုင်ပါတယ်။
    /// ဤသည်ပုံမှန်အားဖြင့်အမျိုးအစားစနစ်ဖြင့်တားဆီးတာဖြစ်ပါတယ်, ဒါပေမယ့် `ManuallyDrop` ၏အသုံးပြုသူများ compiler ကနေအကူအညီမပါဘဲသူတွေကိုအာမခံချက်ထောက်ရမည်ဖြစ်သည်။
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // လုံခြုံမှု: ကျွန်တော်တစ်ဦး mutable ရည်ညွှန်းခြင်းဖြင့်ရန်ထောက်ပြတန်ဖိုးကျဆင်းနေတယ်
        // အရာအရေးအသားတရားဝင်ဖြစ်ဖို့အာမခံသည်။
        // ဒါဟာ `slot` နောက်တဖန်ကျဆင်းသွားမဟုတ်ကြောင်းသေချာစေရန်အဆိုပါခေါ်ဆိုမှုမှတက်သည်။
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}