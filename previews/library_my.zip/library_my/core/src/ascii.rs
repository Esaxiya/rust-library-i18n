//! ASCII strings နဲ့ဇာတ်ကောင်အပေါ်စစ်ဆင်ရေး။
//!
//! Rust ရှိ string လုပ်ဆောင်မှုအများစုသည် UTF-8 string များပေါ်တွင်လုပ်ဆောင်သည်။
//! သို့သော်အချိန်များတွင်သာတိကျတဲ့စစ်ဆင်ရေးများအတွက် ASCII တဲ့ character set ထည့်သွင်းစဉ်းစားဖို့ပိုပြီးသဘာဝကျပါတယ်။
//!
//! [`escape_default`] function သည်ပေးထားသော character ၏ထွက်ပြေးလွတ်မြောက်သော version ၏ bytes များကိုကြားခံတစ်ခုပေးသည်။
//!
//!

#![stable(feature = "core_ascii", since = "1.26.0")]

use crate::fmt;
use crate::iter::FusedIterator;
use crate::ops::Range;
use crate::str::from_utf8_unchecked;

/// ထွက်ပြေးလွတ်မြောက်သော byte ဗားရှင်းတစ်ခုကိုကြားဖြတ်။
///
/// ဤ `struct` ကို [`escape_default`] function ဖြင့်ဖန်တီးသည်။
/// ပိုမိုသိရှိလိုပါက၎င်း၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct EscapeDefault {
    range: Range<usize>,
    data: [u8; 4],
}

/// `u8` ၏လွတ်ကင်းသောဗားရှင်းကိုထုတ်လုပ်သည့်ကြားဖြတ်တစ်ခုကိုပြန်ပို့သည်။
///
/// ပုံမှန်အားဖြင့် C++ 11 နှင့်အလားတူ C-family ဘာသာစကားများအပါအ ၀ င်ဘာသာစကားအမျိုးမျိုးဖြင့်တရားဝင်ဖြစ်သော literals များထုတ်လုပ်ရန်ဘက်လိုက်မှုဖြင့်ရွေးချယ်သည်။
/// တိကျသောစည်းမျဉ်းများမှာ
///
/// * Tab သည် `\t` အဖြစ်ထွက်ပြေးသည်။
/// * သယ်ယူပို့ဆောင်ရေးပြန်လာ `\r` အဖြစ်ထွက်ပြေးလွတ်မြောက်သည်။
/// * Line feed သည် `\n` ကဲ့သို့လွတ်သွားသည်။
/// * လူပျိုကိုးကား `\'` လွတ်သကဲ့သို့ဖြစ်ပါတယ်။
/// * နှစ်ချက်ကိုးကား `\"` လွတ်သကဲ့သို့ဖြစ်ပါတယ်။
/// * Backslash သည် `\\` ကဲ့သို့လွတ်သွားသည်။
/// * 'Printable ASCII' အကွာအဝေးမှ `0x20` .. `0x7e` ပါ ၀ င်သောမည်သည့်အက္ခရာမှမလွတ်မြောက်ပါ။
/// * အခြားမည်သည့် char ပုံစံ '\xNN' ၏ hex ထွက်ပြေးသောအခါပေးအပ်ထားတယ်။
/// * ယူနီကုတ်ထွက်ပေါက်များကိုဤလုပ်ဆောင်မှုမှမည်သည့်အခါကမျှထုတ်လုပ်ခြင်းမရှိပါ။
///
/// # Examples
///
/// ```
/// use std::ascii;
///
/// let escaped = ascii::escape_default(b'0').next().unwrap();
/// assert_eq!(b'0', escaped);
///
/// let mut escaped = ascii::escape_default(b'\t');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b't', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\r');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'r', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\n');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'n', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\'');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'\'', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'"');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'"', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\\');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'\\', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\x9d');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'x', escaped.next().unwrap());
/// assert_eq!(b'9', escaped.next().unwrap());
/// assert_eq!(b'd', escaped.next().unwrap());
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn escape_default(c: u8) -> EscapeDefault {
    let (data, len) = match c {
        b'\t' => ([b'\\', b't', 0, 0], 2),
        b'\r' => ([b'\\', b'r', 0, 0], 2),
        b'\n' => ([b'\\', b'n', 0, 0], 2),
        b'\\' => ([b'\\', b'\\', 0, 0], 2),
        b'\'' => ([b'\\', b'\'', 0, 0], 2),
        b'"' => ([b'\\', b'"', 0, 0], 2),
        b'\x20'..=b'\x7e' => ([c, 0, 0, 0], 1),
        _ => ([b'\\', b'x', hexify(c >> 4), hexify(c & 0xf)], 4),
    };

    return EscapeDefault { range: 0..len, data };

    fn hexify(b: u8) -> u8 {
        match b {
            0..=9 => b'0' + b,
            _ => b'a' + b - 10,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Iterator for EscapeDefault {
    type Item = u8;
    fn next(&mut self) -> Option<u8> {
        self.range.next().map(|i| self.data[i])
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.range.size_hint()
    }
    fn last(mut self) -> Option<u8> {
        self.next_back()
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl DoubleEndedIterator for EscapeDefault {
    fn next_back(&mut self) -> Option<u8> {
        self.range.next_back().map(|i| self.data[i])
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ExactSizeIterator for EscapeDefault {}
#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for EscapeDefault {}

#[stable(feature = "ascii_escape_display", since = "1.39.0")]
impl fmt::Display for EscapeDefault {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // လုံခြုံမှု: `escape_default` သည်မှန်ကန်သော utf-8 အချက်အလက်များကိုသာဖန်တီးသောကြောင့်ဖြစ်သည်
        f.write_str(unsafe { from_utf8_unchecked(&self.data[self.range.clone()]) })
    }
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for EscapeDefault {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("EscapeDefault { .. }")
    }
}