//! ပျင်းရိတန်ဖိုးများနှင့်အငြိမ်အချက်အလက်များ၏တဦးတည်းအချိန်စတင်ခြင်း။

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// တစ်ခါသာရေးသားနိုင်သည့်တစ်ဦးကလာပ်စည်း။
///
/// `RefCell` နှင့်မတူဘဲ `OnceCell` သည်၎င်း၏တန်ဖိုးနှင့်မျှဝေထားသော `&T` ကိုးကားချက်များကိုသာထောက်ပံ့ပေးသည်။
/// `Cell` မတူဘဲတစ် `OnceCell` ကဝင်ရောက်ဖို့တန်ဖိုးကိုကူးယူသို့မဟုတ်အစားထိုးမလိုအပ်ပါဘူး။
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // လျော့ပါးသွားမည်ဖြစ်သလို: တစ်ချိန်ကအရှိဆုံးမှာရေးသား။
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// ဗလာဆဲလ်အသစ်တစ်ခုကိုဖန်တီးသည်။
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// နောက်ခံတန်ဖိုးရည်ညွှန်းရရှိသွားတဲ့။
    ///
    /// ဆဲလ်အချည်းနှီးလျှင် `None` Returns ။
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // လုံခြုံမှု-အတွင်းပိုင်း၏လျော့ပါးသွားမည်ဖြစ်ခြင်းကြောင့်လုံခြုံသည်
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// နောက်ခံတန်ဖိုးကိုဖို့ mutable ရည်ညွှန်းရရှိသွားတဲ့။
    ///
    /// ဆဲလ်အချည်းနှီးလျှင် `None` Returns ။
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // လုံခြုံမှု: ကို Safe ကျနော်တို့ထူးခြားတဲ့လက်လှမ်းရှိသည်ကြောင့်
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// `value` ဖို့ဆဲလ်ရဲ့ contents ကိုသတ်မှတ်ပေးသည်။
    ///
    /// # Errors
    ///
    /// ဤနည်းလမ်းကိုကြောင့်အပြည့်အဝကြီးလျှင်ဆဲလ်ဗလာနှင့် `Err(value)` ခဲ့လျှင် `Ok(())` ပြန်လည်ရောက်ရှိ။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // လုံခြုံမှု: ကို Safe ကျနော်တို့ mutable ချေးထပ်မပေးနိုငျသောကွောငျ့
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // လုံခြုံမှု: ဒီကျွန်ုပ်တို့သည် slot ကသတ်မှတ်ထားရှိရာသာရာအရပျဖြစ်ပါသည်, အဘယ်သူမျှမလူမျိုး
        // ကြောင့် reentrancy/concurrency ဖြစ်နိုင်ဖြစ်ကြသည်ကို၎င်း, ကျနော်တို့ slot ကလက်ရှိ `None` ဖြစ်တယ်, ဒါဒီရေးသားမှုကတော့ `inner` ရဲ့လျော့ပါးသွားမည်ဖြစ်သလိုထိန်းသိမ်းထားကြောင်း check လုပ်ထားပါတယ်။
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// ဆဲလ်အတွင်းရှိအရာဝတ္ထုများကိုရရှိသည်။
    ///
    /// # Panics
    ///
    /// အကယ်၍ `f` panics ဖြစ်ပါက panic သည်ခေါ်ဆိုသူထံသို့ပြန့်ပွားသွားပြီးဆဲလ်မှာအသိအမှတ်ပြုခံရခြင်းမရှိသေးပါ။
    ///
    ///
    /// `f` မှဆဲလ်ကိုပြန်စတင်တပ်ဆင်ခြင်းသည်မှားသည်။တစ်ဦး panic အတွက်ဒါရလဒ်များကိုလုပ်နေတာ။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// ဆဲလ်အတွင်းရှိအရာဝတ္ထုများကိုရရှိသည်။
    /// ဆဲလ်အလွတ်နှင့် `f` ပျက်ကွက်လျှင်, အမှားတစ်ခုပြန်လာ။
    ///
    /// # Panics
    ///
    /// အကယ်၍ `f` panics ဖြစ်ပါက panic သည်ခေါ်ဆိုသူထံသို့ပြန့်ပွားသွားပြီးဆဲလ်မှာအသိအမှတ်ပြုခံရခြင်းမရှိသေးပါ။
    ///
    ///
    /// `f` မှဆဲလ်ကိုပြန်စတင်တပ်ဆင်ခြင်းသည်မှားသည်။တစ်ဦး panic အတွက်ဒါရလဒ်များကိုလုပ်နေတာ။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // * အချို့သောပြန်လည်နေရာချထားမှုပုံစံများကိုစတင်ခြင်းသည် UB ဆီသို့ ဦး တည်နိုင်သည် (`reentrant_init` test ကိုကြည့်ပါ) ။
        // ငါဒီ `assert` ကိုဖယ်ရှားရုံသာ `set/get` ကိုစောင့်ရှောက်နေစဉ်အသံဖြစ်လိမ့်မယ်လို့ယုံကြည်ပါတယ်, ဒါပေမယ့်သူကတန်ဖိုးအဟောင်းကိုတိတ်တဆိတ်သုံးခြင်းထက် panic ပိုကောင်းပုံရသည်။
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// အဆိုပါပတ်ရစ်တန်ဖိုးကိုပြန်, ဆဲလ်စားသုံး။
    ///
    /// ဆဲလ်အချည်းနှီးဖြစ်ခဲ့သည်လျှင် `None` Returns ။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // `into_inner` တန်ဖိုး `self` ကြာသောကြောင့်, compiler statically ကြောင့်လက်ရှိချေးမဟုတ်ကြောင်းစစ်ဆေးပေးတယ်။
        // ဒါကြောင့် `Option<T>` ကိုထွက်ခွာရန်လုံခြုံသည်။
        self.inner.into_inner()
    }

    /// ဒီ `OnceCell` ထဲကတန်ဖိုးကိုယူပြီး၎င်းကို uninitialized state သို့ပြန်ပြောင်းသည်။
    ///
    /// အဆိုပါ `OnceCell` နန့်မမူလျှင်အဘယ်သူမျှမသက်ရောက်ခြင်းနှင့်ပြန် `None` ရှိပါတယ်။
    ///
    /// အန္တရာယ်ကင်းရှင်းရေးတစ် mutable ရည်ညွှန်းလိုအပ်သဖြင့်အာမခံချက်ဖြစ်ပါတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// ပထမ ၀ င်ရောက်မှုတွင်အစပြုသည်။
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   အဆင်သင့်စတင်
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// ပေးထားသောကန ဦး function ကိုအတူသစ်တစ်ခုပျင်းရိတန်ဖိုးကိုဖန်တီးပေးပါတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// ဒီပျင်းရိတန်ဖိုးကိုအကဲဖြတ်ခြင်းကိုတွန်းအားပေးပြီးရလဒ်ကိုရည်ညွှန်းသည်။
    ///
    ///
    /// ဒါက `Deref` impl ညီမျှဖြစ်တယ်, ဒါပေမဲ့ရှင်းလင်းပြတ်သားစွာဖြစ်ပါတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// အဆိုပါစတင်လုပ်ဆောင် function ကိုအဖြစ် `Default` သုံးပြီးအသစ်တစ်ခုကိုပျင်းရိတန်ဖိုးကိုဖန်တီးပေးပါတယ်။
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}