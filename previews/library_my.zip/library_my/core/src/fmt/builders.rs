#![allow(unused_imports)]

use crate::fmt::{self, Debug, Formatter};

struct PadAdapter<'buf, 'state> {
    buf: &'buf mut (dyn fmt::Write + 'buf),
    state: &'state mut PadAdapterState,
}

struct PadAdapterState {
    on_newline: bool,
}

impl Default for PadAdapterState {
    fn default() -> Self {
        PadAdapterState { on_newline: true }
    }
}

impl<'buf, 'state> PadAdapter<'buf, 'state> {
    fn wrap<'slot, 'fmt: 'buf + 'slot>(
        fmt: &'fmt mut fmt::Formatter<'_>,
        slot: &'slot mut Option<Self>,
        state: &'state mut PadAdapterState,
    ) -> fmt::Formatter<'slot> {
        fmt.wrap_buf(move |buf| {
            *slot = Some(PadAdapter { buf, state });
            slot.as_mut().unwrap()
        })
    }
}

impl fmt::Write for PadAdapter<'_, '_> {
    fn write_str(&mut self, mut s: &str) -> fmt::Result {
        while !s.is_empty() {
            if self.state.on_newline {
                self.buf.write_str("    ")?;
            }

            let split = match s.find('\n') {
                Some(pos) => {
                    self.state.on_newline = true;
                    pos + 1
                }
                None => {
                    self.state.on_newline = false;
                    s.len()
                }
            };
            self.buf.write_str(&s[..split])?;
            s = &s[split..];
        }

        Ok(())
    }
}

/// [`fmt::Debug`](Debug) အကောင်အထည်ဖော်မှုနှင့်အတူကူညီမယ့် struct ။
///
/// သငျသညျအထွက်ရန်သင့် [`Debug::fmt`] အကောင်အထည်ဖော်မှု၏အစိတ်အပိုင်းတစ်ခုအဖြစ်တစ်ဦး၏ format struct ဆန္ဒရှိသောအခါဤအသုံးဝင်သည်။
///
///
/// ၎င်းကို [`Formatter::debug_struct`] နည်းလမ်းဖြင့်တည်ဆောက်နိုင်သည်။
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// struct Foo {
///     bar: i32,
///     baz: String,
/// }
///
/// impl fmt::Debug for Foo {
///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
///         fmt.debug_struct("Foo")
///            .field("bar", &self.bar)
///            .field("baz", &self.baz)
///            .finish()
///     }
/// }
///
/// assert_eq!(
///     format!("{:?}", Foo { bar: 10, baz: "Hello World".to_string() }),
///     "Foo { bar: 10, baz: \"Hello World\" }",
/// );
/// ```
#[must_use = "must eventually call `finish()` on Debug builders"]
#[allow(missing_debug_implementations)]
#[stable(feature = "debug_builders", since = "1.2.0")]
pub struct DebugStruct<'a, 'b: 'a> {
    fmt: &'a mut fmt::Formatter<'b>,
    result: fmt::Result,
    has_fields: bool,
}

pub(super) fn debug_struct_new<'a, 'b>(
    fmt: &'a mut fmt::Formatter<'b>,
    name: &str,
) -> DebugStruct<'a, 'b> {
    let result = fmt.write_str(name);
    DebugStruct { fmt, result, has_fields: false }
}

impl<'a, 'b: 'a> DebugStruct<'a, 'b> {
    /// ထုတ်လုပ်လိုက်တဲ့ struct output ကိုအားအသစ်သောလယ်ပြင်၌ထည့်ပေးသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Bar {
    ///     bar: i32,
    ///     another: String,
    /// }
    ///
    /// impl fmt::Debug for Bar {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_struct("Bar")
    ///            .field("bar", &self.bar) // ကျနော်တို့ `bar` လယ်ကိုထည့်ပါ။
    ///            .field("another", &self.another) // ကျနော်တို့ `another` လယ်ပြင်ထည့်ပါ။
    ///            // ကျနော်တို့တောင်မှ (အကြောင်းမှာအဘယ်ကြောင့်မပေး?) မတည်ရှိပါဘူးတဲ့လယ်ကွင်းထည့်ပါ။
    ///            .field("not_existing_field", &1)
    ///            .finish() // ငါတို့သွားဖို့ကောင်းတယ်
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Bar { bar: 10, another: "Hello World".to_string() }),
    ///     "Bar { bar: 10, another: \"Hello World\", not_existing_field: 1 }",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn field(&mut self, name: &str, value: &dyn fmt::Debug) -> &mut Self {
        self.result = self.result.and_then(|_| {
            if self.is_pretty() {
                if !self.has_fields {
                    self.fmt.write_str(" {\n")?;
                }
                let mut slot = None;
                let mut state = Default::default();
                let mut writer = PadAdapter::wrap(&mut self.fmt, &mut slot, &mut state);
                writer.write_str(name)?;
                writer.write_str(": ")?;
                value.fmt(&mut writer)?;
                writer.write_str(",\n")
            } else {
                let prefix = if self.has_fields { ", " } else { " { " };
                self.fmt.write_str(prefix)?;
                self.fmt.write_str(name)?;
                self.fmt.write_str(": ")?;
                value.fmt(self.fmt)
            }
        });

        self.has_fields = true;
        self
    }

    /// ဒီတည်ဆောက်ပုံကိုပြည့်စုံလုံလောက်မှုမရှိခြင်းအဖြစ်မှတ်သားသည်။ debug ကိုယ်စားပြုမှုတွင်မပြသောအခြားနယ်ပယ်အချို့ရှိသည်ကိုစာဖတ်သူကိုပြသသည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(debug_non_exhaustive)]
    /// use std::fmt;
    ///
    /// struct Bar {
    ///     bar: i32,
    ///     hidden: f32,
    /// }
    ///
    /// impl fmt::Debug for Bar {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_struct("Bar")
    ///            .field("bar", &self.bar)
    ///            .finish_non_exhaustive() // အချို့သောအခြား field(s) တည်ရှိကြောင်းပြပါ။
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Bar { bar: 10, hidden: 1.0 }),
    ///     "Bar { bar: 10, .. }",
    /// );
    /// ```
    #[unstable(feature = "debug_non_exhaustive", issue = "67364")]
    pub fn finish_non_exhaustive(&mut self) -> fmt::Result {
        self.result = self.result.and_then(|_| {
            // Non-ပြည့်စုံစေ့စပ်စက် (`..`) ကိုခပ်ပွင့်လင်းသတ္တုအထိမ်းအချုပ်လိုအပ်ပါက (အဘယ်သူမျှမလယ်ကွင်း) ။
            if self.is_pretty() {
                if !self.has_fields {
                    self.fmt.write_str(" {\n")?;
                }
                let mut slot = None;
                let mut state = Default::default();
                let mut writer = PadAdapter::wrap(&mut self.fmt, &mut slot, &mut state);
                writer.write_str("..\n")?;
            } else {
                if self.has_fields {
                    self.fmt.write_str(", ..")?;
                } else {
                    self.fmt.write_str(" { ..")?;
                }
            }
            if self.is_pretty() {
                self.fmt.write_str("}")?
            } else {
                self.fmt.write_str(" }")?;
            }
            Ok(())
        });
        self.result
    }

    /// output ကိုပြီးဆုံးနှင့်ကြုံတွေ့မဆိုအမှားပြန်လည်ရောက်ရှိ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Bar {
    ///     bar: i32,
    ///     baz: String,
    /// }
    ///
    /// impl fmt::Debug for Bar {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_struct("Bar")
    ///            .field("bar", &self.bar)
    ///            .field("baz", &self.baz)
    ///            .finish() // သင်က "finish" ကိုဖုန်းခေါ်ရန်လိုသည်
    ///                      // ပုံစံ struct ။
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Bar { bar: 10, baz: "Hello World".to_string() }),
    ///     "Bar { bar: 10, baz: \"Hello World\" }",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn finish(&mut self) -> fmt::Result {
        if self.has_fields {
            self.result = self.result.and_then(|_| {
                if self.is_pretty() { self.fmt.write_str("}") } else { self.fmt.write_str(" }") }
            });
        }
        self.result
    }

    fn is_pretty(&self) -> bool {
        self.fmt.alternate()
    }
}

/// [`fmt::Debug`](Debug) အကောင်အထည်ဖော်မှုနှင့်အတူကူညီမယ့် struct ။
///
/// သငျသညျအထွက်ရန်သင့် [`Debug::fmt`] အကောင်အထည်ဖော်မှု၏အစိတ်အပိုင်းတစ်ခုအဖြစ်တစ်ဦး၏ format tuple ဆန္ဒရှိသောအခါဤအသုံးဝင်သည်။
///
///
/// ၎င်းကို [`Formatter::debug_tuple`] နည်းလမ်းဖြင့်တည်ဆောက်နိုင်သည်။
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// struct Foo(i32, String);
///
/// impl fmt::Debug for Foo {
///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
///         fmt.debug_tuple("Foo")
///            .field(&self.0)
///            .field(&self.1)
///            .finish()
///     }
/// }
///
/// assert_eq!(
///     format!("{:?}", Foo(10, "Hello World".to_string())),
///     "Foo(10, \"Hello World\")",
/// );
/// ```
#[must_use = "must eventually call `finish()` on Debug builders"]
#[allow(missing_debug_implementations)]
#[stable(feature = "debug_builders", since = "1.2.0")]
pub struct DebugTuple<'a, 'b: 'a> {
    fmt: &'a mut fmt::Formatter<'b>,
    result: fmt::Result,
    fields: usize,
    empty_name: bool,
}

pub(super) fn debug_tuple_new<'a, 'b>(
    fmt: &'a mut fmt::Formatter<'b>,
    name: &str,
) -> DebugTuple<'a, 'b> {
    let result = fmt.write_str(name);
    DebugTuple { fmt, result, fields: 0, empty_name: name.is_empty() }
}

impl<'a, 'b: 'a> DebugTuple<'a, 'b> {
    /// ထုတ်လုပ်ပြီး tuple struct output ကိုမှအသစ်တစ်ခုကိုလယ်ကထပ်ပြောသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32, String);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///            .field(&self.0) // ကျနော်တို့ပထမ ဦး ဆုံးလယ်ပြင်ထည့်ပါ။
    ///            .field(&self.1) // ကျနော်တို့ဒုတိယလယ်ကိုထည့်ပါ။
    ///            .finish() // ငါတို့သွားဖို့ကောင်းတယ်
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(10, "Hello World".to_string())),
    ///     "Foo(10, \"Hello World\")",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn field(&mut self, value: &dyn fmt::Debug) -> &mut Self {
        self.result = self.result.and_then(|_| {
            if self.is_pretty() {
                if self.fields == 0 {
                    self.fmt.write_str("(\n")?;
                }
                let mut slot = None;
                let mut state = Default::default();
                let mut writer = PadAdapter::wrap(&mut self.fmt, &mut slot, &mut state);
                value.fmt(&mut writer)?;
                writer.write_str(",\n")
            } else {
                let prefix = if self.fields == 0 { "(" } else { ", " };
                self.fmt.write_str(prefix)?;
                value.fmt(self.fmt)
            }
        });

        self.fields += 1;
        self
    }

    /// output ကိုပြီးဆုံးနှင့်ကြုံတွေ့မဆိုအမှားပြန်လည်ရောက်ရှိ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32, String);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///            .field(&self.0)
    ///            .field(&self.1)
    ///            .finish() // သင်က "finish" ကိုဖုန်းခေါ်ရန်လိုသည်
    ///                      // ပုံစံ tuple ။
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(10, "Hello World".to_string())),
    ///     "Foo(10, \"Hello World\")",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn finish(&mut self) -> fmt::Result {
        if self.fields > 0 {
            self.result = self.result.and_then(|_| {
                if self.fields == 1 && self.empty_name && !self.is_pretty() {
                    self.fmt.write_str(",")?;
                }
                self.fmt.write_str(")")
            });
        }
        self.result
    }

    fn is_pretty(&self) -> bool {
        self.fmt.alternate()
    }
}

struct DebugInner<'a, 'b: 'a> {
    fmt: &'a mut fmt::Formatter<'b>,
    result: fmt::Result,
    has_fields: bool,
}

impl<'a, 'b: 'a> DebugInner<'a, 'b> {
    fn entry(&mut self, entry: &dyn fmt::Debug) {
        self.result = self.result.and_then(|_| {
            if self.is_pretty() {
                if !self.has_fields {
                    self.fmt.write_str("\n")?;
                }
                let mut slot = None;
                let mut state = Default::default();
                let mut writer = PadAdapter::wrap(&mut self.fmt, &mut slot, &mut state);
                entry.fmt(&mut writer)?;
                writer.write_str(",\n")
            } else {
                if self.has_fields {
                    self.fmt.write_str(", ")?
                }
                entry.fmt(self.fmt)
            }
        });

        self.has_fields = true;
    }

    fn is_pretty(&self) -> bool {
        self.fmt.alternate()
    }
}

/// [`fmt::Debug`](Debug) အကောင်အထည်ဖော်မှုနှင့်အတူကူညီမယ့် struct ။
///
/// သငျသညျအထွက်ရန်သင့် [`Debug::fmt`] အကောင်အထည်ဖော်မှု၏အစိတ်အပိုင်းတစ်ခုအဖြစ်ပစ္စည်းများကိုတစ်ဦး၏ format set ကိုဆန္ဒရှိသောအခါဤအသုံးဝင်သည်။
///
///
/// ဒါက [`Formatter::debug_set`] နည်းလမ်းအားဖြင့်ဆောက်လုပ်ထားနိုင်ပါသည်။
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// struct Foo(Vec<i32>);
///
/// impl fmt::Debug for Foo {
///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
///         fmt.debug_set().entries(self.0.iter()).finish()
///     }
/// }
///
/// assert_eq!(
///     format!("{:?}", Foo(vec![10, 11])),
///     "{10, 11}",
/// );
/// ```
#[must_use = "must eventually call `finish()` on Debug builders"]
#[allow(missing_debug_implementations)]
#[stable(feature = "debug_builders", since = "1.2.0")]
pub struct DebugSet<'a, 'b: 'a> {
    inner: DebugInner<'a, 'b>,
}

pub(super) fn debug_set_new<'a, 'b>(fmt: &'a mut fmt::Formatter<'b>) -> DebugSet<'a, 'b> {
    let result = fmt.write_str("{");
    DebugSet { inner: DebugInner { fmt, result, has_fields: false } }
}

impl<'a, 'b: 'a> DebugSet<'a, 'b> {
    /// set ကို output ကိုမှအသစ်တခု entry ကိုထည့်သွင်းသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>, Vec<u32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_set()
    ///            .entry(&self.0) // ပထမဦးဆုံး "entry" ကထပ်ပြောသည်။
    ///            .entry(&self.1) // ဒုတိယ "entry" ကထပ်ပြောသည်။
    ///            .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![10, 11], vec![12, 13])),
    ///     "{[10, 11], [12, 13]}",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn entry(&mut self, entry: &dyn fmt::Debug) -> &mut Self {
        self.inner.entry(entry);
        self
    }

    /// အဆိုပါသတ်မှတ်ချက်ကို output entries တွေကိုတစ်ခုကြားမှာရဲ့ contents ကထပ်ပြောသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>, Vec<u32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_set()
    ///            .entries(self.0.iter()) // ပထမဦးဆုံး "entry" ကထပ်ပြောသည်။
    ///            .entries(self.1.iter()) // ဒုတိယ "entry" ကထပ်ပြောသည်။
    ///            .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![10, 11], vec![12, 13])),
    ///     "{10, 11, 12, 13}",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn entries<D, I>(&mut self, entries: I) -> &mut Self
    where
        D: fmt::Debug,
        I: IntoIterator<Item = D>,
    {
        for entry in entries {
            self.entry(&entry);
        }
        self
    }

    /// output ကိုပြီးဆုံးနှင့်ကြုံတွေ့မဆိုအမှားပြန်လည်ရောက်ရှိ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_set()
    ///            .entries(self.0.iter())
    ///            .finish() // အဆိုပါဖွဲ့စည်းပုံ format နဲ့အဆုံးသတ်ထားသည်။
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![10, 11])),
    ///     "{10, 11}",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn finish(&mut self) -> fmt::Result {
        self.inner.result.and_then(|_| self.inner.fmt.write_str("}"))
    }
}

/// [`fmt::Debug`](Debug) အကောင်အထည်ဖော်မှုနှင့်အတူကူညီမယ့် struct ။
///
/// သင်၏ [`Debug::fmt`] အကောင်အထည်ဖော်မှု၏အစိတ်အပိုင်းတစ်ခုအနေဖြင့်ပုံစံချထားသည့်အရာများကိုစာရင်းပြုစုလိုပါက၎င်းသည်အသုံးဝင်သည်။
///
///
/// ၎င်းကို [`Formatter::debug_list`] နည်းလမ်းဖြင့်တည်ဆောက်နိုင်သည်။
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// struct Foo(Vec<i32>);
///
/// impl fmt::Debug for Foo {
///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
///         fmt.debug_list().entries(self.0.iter()).finish()
///     }
/// }
///
/// assert_eq!(
///     format!("{:?}", Foo(vec![10, 11])),
///     "[10, 11]",
/// );
/// ```
#[must_use = "must eventually call `finish()` on Debug builders"]
#[allow(missing_debug_implementations)]
#[stable(feature = "debug_builders", since = "1.2.0")]
pub struct DebugList<'a, 'b: 'a> {
    inner: DebugInner<'a, 'b>,
}

pub(super) fn debug_list_new<'a, 'b>(fmt: &'a mut fmt::Formatter<'b>) -> DebugList<'a, 'b> {
    let result = fmt.write_str("[");
    DebugList { inner: DebugInner { fmt, result, has_fields: false } }
}

impl<'a, 'b: 'a> DebugList<'a, 'b> {
    /// စာရင်း output ကိုအသစ်တစ်ခု entry ကိုထပ်ထည့်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>, Vec<u32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_list()
    ///            .entry(&self.0) // ကျနော်တို့ပထမ ဦး ဆုံး "entry" ထည့်ပါ။
    ///            .entry(&self.1) // ကျနော်တို့ဒုတိယ "entry" ထည့်ပါ။
    ///            .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![10, 11], vec![12, 13])),
    ///     "[[10, 11], [12, 13]]",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn entry(&mut self, entry: &dyn fmt::Debug) -> &mut Self {
        self.inner.entry(entry);
        self
    }

    /// စာရင်းထွက်ရှိဖို့ entries တွေကိုတစ်ခုကြားမှာရဲ့ contents ကထပ်ပြောသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>, Vec<u32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_list()
    ///            .entries(self.0.iter())
    ///            .entries(self.1.iter())
    ///            .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![10, 11], vec![12, 13])),
    ///     "[10, 11, 12, 13]",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn entries<D, I>(&mut self, entries: I) -> &mut Self
    where
        D: fmt::Debug,
        I: IntoIterator<Item = D>,
    {
        for entry in entries {
            self.entry(&entry);
        }
        self
    }

    /// output ကိုပြီးဆုံးနှင့်ကြုံတွေ့မဆိုအမှားပြန်လည်ရောက်ရှိ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_list()
    ///            .entries(self.0.iter())
    ///            .finish() // အဆိုပါဖွဲ့စည်းပုံ format နဲ့အဆုံးသတ်ထားသည်။
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![10, 11])),
    ///     "[10, 11]",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn finish(&mut self) -> fmt::Result {
        self.inner.result.and_then(|_| self.inner.fmt.write_str("]"))
    }
}

/// [`fmt::Debug`](Debug) အကောင်အထည်ဖော်မှုနှင့်အတူကူညီမယ့် struct ။
///
/// သငျသညျအထွက်ရန်သင့် [`Debug::fmt`] အကောင်အထည်ဖော်မှု၏အစိတ်အပိုင်းတစ်ခုအဖြစ်တစ်ဦး၏ format မြေပုံဆန္ဒရှိသောအခါဤအသုံးဝင်သည်။
///
///
/// ဒါက [`Formatter::debug_map`] နည်းလမ်းအားဖြင့်ဆောက်လုပ်ထားနိုင်ပါသည်။
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// struct Foo(Vec<(String, i32)>);
///
/// impl fmt::Debug for Foo {
///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
///     }
/// }
///
/// assert_eq!(
///     format!("{:?}", Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
///     "{\"A\": 10, \"B\": 11}",
/// );
/// ```
#[must_use = "must eventually call `finish()` on Debug builders"]
#[allow(missing_debug_implementations)]
#[stable(feature = "debug_builders", since = "1.2.0")]
pub struct DebugMap<'a, 'b: 'a> {
    fmt: &'a mut fmt::Formatter<'b>,
    result: fmt::Result,
    has_fields: bool,
    has_key: bool,
    // newlines ၏အခြေအနေကိုသော့နှင့်တန်ဖိုးများအကြားခြေရာခံသည်
    state: PadAdapterState,
}

pub(super) fn debug_map_new<'a, 'b>(fmt: &'a mut fmt::Formatter<'b>) -> DebugMap<'a, 'b> {
    let result = fmt.write_str("{");
    DebugMap { fmt, result, has_fields: false, has_key: false, state: Default::default() }
}

impl<'a, 'b: 'a> DebugMap<'a, 'b> {
    /// မြေပုံအထွက်သို့အသစ်တစ်ခုထည့်သွင်းသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_map()
    ///            .entry(&"whole", &self.0) // ကျနော်တို့ "whole" entry ကိုထည့်ပါ။
    ///            .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     "{\"whole\": [(\"A\", 10), (\"B\", 11)]}",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn entry(&mut self, key: &dyn fmt::Debug, value: &dyn fmt::Debug) -> &mut Self {
        self.key(key).value(value)
    }

    /// မြေပုံ output ကိုအသစ်ဝင်ရောက်မှု၏အဓိကအစိတ်အပိုင်းကထပ်ပြောသည်။
    ///
    /// ဤနည်းလမ်းကိုအတူတကွ `value` နှင့်တကွ, ပြည့်စုံ entry ကိုရှေ့ပြေးကိုမသိရသည့်အခါအသုံးပြုရနိုင်သော `entry` တစ်ခုကအခြားရွေးချယ်စရာဖြစ်ပါတယ်။
    ///
    /// အသုံးပြုရန်ဖြစ်နိုင်သည့်အခါ `entry` နည်းလမ်းကို ဦး စားပေးရွေးချယ်ပါ။
    ///
    /// # Panics
    ///
    /// `key` `value` မတိုင်မီခေါ်ဆိုရမည်ဖြစ်ပြီး `key` သို့ခေါ်ဆိုမှုတစ်ခုစီတိုင်းကို `value` သို့ခေါ်ဆိုရမည်။
    /// ဒီလိုမှမဟုတ်ရင်ဒီနည်းလမ်း panic လိမ့်မည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_map()
    ///            .key(&"whole").value(&self.0) // ကျနော်တို့ "whole" entry ကိုထည့်ပါ။
    ///            .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     "{\"whole\": [(\"A\", 10), (\"B\", 11)]}",
    /// );
    /// ```
    #[stable(feature = "debug_map_key_value", since = "1.42.0")]
    pub fn key(&mut self, key: &dyn fmt::Debug) -> &mut Self {
        self.result = self.result.and_then(|_| {
            assert!(
                !self.has_key,
                "attempted to begin a new map entry \
                                    without completing the previous one"
            );

            if self.is_pretty() {
                if !self.has_fields {
                    self.fmt.write_str("\n")?;
                }
                let mut slot = None;
                self.state = Default::default();
                let mut writer = PadAdapter::wrap(&mut self.fmt, &mut slot, &mut self.state);
                key.fmt(&mut writer)?;
                writer.write_str(": ")?;
            } else {
                if self.has_fields {
                    self.fmt.write_str(", ")?
                }
                key.fmt(self.fmt)?;
                self.fmt.write_str(": ")?;
            }

            self.has_key = true;
            Ok(())
        });

        self
    }

    /// အသစ်တစ်ခု entry ကို၏တန်ဖိုးကိုတစ်စိတ်တစ်ပိုင်းမြေပုံ output ကိုထည့်သွင်းသည်။
    ///
    /// ဤနည်းလမ်းကိုအတူတကွ `key` နှင့်တကွ, ပြည့်စုံ entry ကိုရှေ့ပြေးကိုမသိရသည့်အခါအသုံးပြုရနိုင်သော `entry` တစ်ခုကအခြားရွေးချယ်စရာဖြစ်ပါတယ်။
    ///
    /// အသုံးပြုရန်ဖြစ်နိုင်သည့်အခါ `entry` နည်းလမ်းကို ဦး စားပေးရွေးချယ်ပါ။
    ///
    /// # Panics
    ///
    /// `key` `value` မတိုင်မီခေါ်ဆိုရမည်ဖြစ်ပြီး `key` သို့ခေါ်ဆိုမှုတစ်ခုစီတိုင်းကို `value` သို့ခေါ်ဆိုရမည်။
    /// ဒီလိုမှမဟုတ်ရင်ဒီနည်းလမ်း panic လိမ့်မည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_map()
    ///            .key(&"whole").value(&self.0) // ကျနော်တို့ "whole" entry ကိုထည့်ပါ။
    ///            .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     "{\"whole\": [(\"A\", 10), (\"B\", 11)]}",
    /// );
    /// ```
    #[stable(feature = "debug_map_key_value", since = "1.42.0")]
    pub fn value(&mut self, value: &dyn fmt::Debug) -> &mut Self {
        self.result = self.result.and_then(|_| {
            assert!(self.has_key, "attempted to format a map value before its key");

            if self.is_pretty() {
                let mut slot = None;
                let mut writer = PadAdapter::wrap(&mut self.fmt, &mut slot, &mut self.state);
                value.fmt(&mut writer)?;
                writer.write_str(",\n")?;
            } else {
                value.fmt(self.fmt)?;
            }

            self.has_key = false;
            Ok(())
        });

        self.has_fields = true;
        self
    }

    /// မြေပုံ output ကိုမှ entries တွေကိုတစ်ခုကြားမှာရဲ့ contents ကထပ်ပြောသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_map()
    ///            // တစ်ဦးချင်းစီ entries တွေကို '' ပထမဦးဆုံးလယ် "key" ဖြစ်လာပါလိမ့်မယ်ဒါကြောင့်ကျွန်တော်တို့ရဲ့ Vec ကာကွယ်ဆေးကိုရေ map ။
    /////
    ///            .entries(self.0.iter().map(|&(ref k, ref v)| (k, v)))
    ///            .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     "{\"A\": 10, \"B\": 11}",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn entries<K, V, I>(&mut self, entries: I) -> &mut Self
    where
        K: fmt::Debug,
        V: fmt::Debug,
        I: IntoIterator<Item = (K, V)>,
    {
        for (k, v) in entries {
            self.entry(&k, &v);
        }
        self
    }

    /// output ကိုပြီးဆုံးနှင့်ကြုံတွေ့မဆိုအမှားပြန်လည်ရောက်ရှိ။
    ///
    /// # Panics
    ///
    /// `key` `value` မတိုင်မီခေါ်ဆိုရမည်ဖြစ်ပြီး `key` သို့ခေါ်ဆိုမှုတစ်ခုစီတိုင်းကို `value` သို့ခေါ်ဆိုရမည်။
    /// ဒီလိုမှမဟုတ်ရင်ဒီနည်းလမ်း panic လိမ့်မည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_map()
    ///            .entries(self.0.iter().map(|&(ref k, ref v)| (k, v)))
    ///            .finish() // အဆိုပါဖွဲ့စည်းပုံ format နဲ့အဆုံးသတ်ထားသည်။
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     "{\"A\": 10, \"B\": 11}",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn finish(&mut self) -> fmt::Result {
        self.result.and_then(|_| {
            assert!(!self.has_key, "attempted to finish a map with a partial entry");

            self.fmt.write_str("}")
        })
    }

    fn is_pretty(&self) -> bool {
        self.fmt.alternate()
    }
}