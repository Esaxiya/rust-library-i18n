//! ညှို့ပုံစံနှင့်ပုံနှိပ်များအတွက်အသုံးအဆောင်များ။

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// `Formatter::align` အားဖြင့်ပြန်လာသောဖြစ်နိုင်ပါ့မလား align
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// ပါ ၀ င်သောအရာများသည်ဘယ်ဘက်နှင့်ကိုက်ညီသင့်ကြောင်းဖော်ပြသည်
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// contents တွေကို Right-aligned သင့်ကြောင်းညွှန်ပြ။
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// ပါ ၀ င်သည့်အကြောင်းအရာများသည်ဗဟိုနှင့်ကိုက်ညီသင့်ကြောင်းညွှန်ပြသည်။
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// Formatter နည်းလမ်းများအားဖြင့်ပြန်လာသောအမျိုးအစား။
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// တစ်စီးသို့မက်ဆေ့ခ်ျကိုပုံစံချရာမှပြန်လာသောသောအမှားအမျိုးအစား။
///
/// ဤအမျိုးအစားသည်အမှားတစ်ခုဖြစ်ပွားခြင်း မှလွဲ၍ အခြားအမှားတစ်ခု၏ထုတ်လွှင့်ခြင်းကိုမထောက်ပံ့ပါ။
/// မည်သည့်အပိုသတင်းအချက်အလက်မဆိုအခြားနည်းလမ်းများမှတဆင့်ထုတ်လွှင့်ရန်စီစဉ်ပေးရမည်။
///
/// မှတ်မိဖို့အရေးပါသောအရာအမျိုးအစားကို `fmt::Error` သင်သည်နယ်ပယ်တွင်လည်းရှိစေခြင်းငှါအရာ [`std::io::Error`] သို့မဟုတ် [`std::error::Error`] နှင့်အတူရောထွေးမဖြစ်သင့်သောကြောင့်ဖြစ်သည်။
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// တစ်ဦးက trait ရေးသားခြင်းသို့မဟုတ်ယူနီကုဒ်-လက်ခံကြားခံသို့မဟုတ်မြစ်ရေထဲသို့ပုံစံသည်။
///
/// ဤ trait သည် UTF-8 - encoded data များကိုသာလက်ခံပြီး [flushable] မဟုတ်ပါ။
/// သင်သည် Unicode ကိုသာလက်ခံရန်နှင့် flushing မလိုအပ်လျှင် trait ကိုသင်အသုံးပြုသင့်သည်။
/// မဟုတ်ရင်သင် [`std::io::Write`] အကောင်အထည်ဖော်သင့်ပါတယ်။
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// ဤစာရေးသူသို့ string အတိုတစ်ခုရေးသည်။
    ///
    /// တစ်ခုလုံးကို string ကိုအချပ်ကိုအောင်မြင်စွာရေးသားခဲ့လျှင်ဤနည်းလမ်းကိုသာအောင်မြင်နိုင်သည်, အပေါင်းတို့နှင့်တကွဒေတာတိကျမ်းစာ၌လာသည်ထားပြီးသို့မဟုတ်မှားယွင်းမှုတစ်ခုဖြစ်ပေါ်သည်အထိဒီနည်းလမ်းကိုပြန်လာလိမ့်မည်မဟုတ်ပါ။
    ///
    ///
    /// # Errors
    ///
    /// ဒီ function ကအမှားပေါ် [`Error`] တစ်ခုဥပမာအားဖြင့်ပြန်လာပါလိမ့်မယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// ဤရေးသားသူသို့ [`char`] ကိုရေးသည်၊ ရေးသည်အောင်မြင်ခဲ့သည်ဖြစ်စေပြန်သည်။
    ///
    /// [`char`] တစ်ခုတည်းကို byte တစ်ခုထက်ပိုပြီး encode လုပ်နိူင်တယ်။
    /// တစ်ခုလုံးက byte sequence ကိုအောင်မြင်စွာရေးသားခဲ့လျှင်ဤနည်းလမ်းကိုသာအောင်မြင်နိုင်သည်, အပေါင်းတို့နှင့်တကွဒေတာတိကျမ်းစာ၌လာသည်ထားပြီးသို့မဟုတ်မှားယွင်းမှုတစ်ခုဖြစ်ပေါ်သည်အထိဒီနည်းလမ်းကိုပြန်လာလိမ့်မည်မဟုတ်ပါ။
    ///
    ///
    /// # Errors
    ///
    /// ဒီ function ကအမှားပေါ် [`Error`] တစ်ခုဥပမာအားဖြင့်ပြန်လာပါလိမ့်မယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// ဒီ trait ၏ implementors အတူ [`write!`] နိုင်တဲ့ macro ၏အသုံးပြုမှုများအတွက်ကော်။
    ///
    /// ဤနည်းလမ်းကိုယေဘုယျအားဖြင့်ကိုယ်တိုင်မလုပ်သင့်ပါ၊ သို့သော် [`write!`] macro ကိုယ်တိုင်မှတဆင့်အသုံးပြုသင့်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// format အတွက် configuration ကို။
///
/// တစ်ဦးက `Formatter` ပုံစံနှင့်ဆက်စပ်သောအမျိုးမျိုးသော options များကိုကိုယ်စားပြုသည်။
/// အသုံးပြုသူများကိုတိုက်ရိုက် `Formatter`s တည်ဆောက်မထင်သော်လည်း,တဦးတည်းမှတစ်ဦး mutable ရည်ညွှန်း [`Debug`] နှင့် [`Display`] တူသောအားလုံးပုံစံ traits ၏ `fmt` နည်းလမ်းမှအောင်မြင်ပြီးဖြစ်ပါတယ်။
///
///
/// တစ်ဦး `Formatter` နှင့်အတူအပြန်အလှန်စေရန်, သငျသညျပုံစံနှင့်ဆက်စပ်သောအမျိုးမျိုးသော options များပြောင်းလဲပစ်ရန်အမျိုးမျိုးသောနည်းလမ်းများခေါ်ပါလိမ့်မယ်။
/// ဥပမာအားဖြင့်၊ အောက်တွင်ဖော်ပြထားသော `Formatter` တွင်ဖော်ပြထားသောနည်းလမ်းများ၏မှတ်တမ်းကိုကြည့်ပါ။
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// အငြင်းအခုံမရှိမဖြစ်လိုအပ်တဲ့အနေနဲ့တစ်စိတ်တစ်ပိုင်း `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result` ညီမျှ, function ကိုပုံစံလျှောက်ထား optimized ဖြစ်ပါတယ်။

extern "C" {
    type Opaque;
}

/// ဤသည် struct သည် Xprintf မိသားစုလုပ်ဆောင်ချက်မှရရှိသောယေဘူယျ "argument" ကိုကိုယ်စားပြုသည်။ဒါဟာပေးထားသောတန်ဖိုးကို format တစ်ခု function ကိုပါဝင်သည်။
/// compile လုပ်ခြင်းထိုအချိန်တွင်က function ကိုနှင့်တန်ဖိုးမှန်ကန်သောအမျိုးအစားများရှိသည်ရဖို့သေချာနေပါတယ်, ပြီးတော့ဒီ struct တဦးတည်းအမျိုးအစားမှအငြင်းပွားမှုများ canonicalize အသုံးပြုသည်။
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// ဒါကပုံစံအခြေခံအဆောက်အအုံထဲမှာ indices/counts နဲ့သက်ဆိုင်တဲ့ function ကို pointer ဘို့တစ်ခုတည်းတည်ငြိမ်တန်ဖိုးကိုအာမခံပါသည်။
//
// လုပ်ဆောင်ချက်များကို unnamed_addr ဟုအမြဲအမှတ်အသားပြုထားသောကြောင့်၎င်းကိုသတ်မှတ်ထားသော function တစ်ခုသည်လက်ရှိ LLVM IR သို့နိမ့်ကျသည်နှင့်အမြဲတမ်းအမှတ်အသားပြုထားသောကြောင့်၎င်းတို့၏လိပ်စာကို LLVM အတွက်အရေးကြီးသည်ဟုမယူဆသောကြောင့် as_usize cast ကိုမှားယွင်းကောက်ယူနိုင်သည်။
//
// လက်တွေ့တွင်၊ (static Generation အငြင်းပွားမှုကိစ္စရပ်များအနေဖြင့်) data အသုံးပြုမှုမရှိသောပါသည့် as_usize ကိုကျွန်ုပ်တို့ဘယ်တော့မှမခေါ်ပါ၊ ထို့ကြောင့်၎င်းသည်ထပ်ဆင့်စစ်ဆေးမှုမျှသာဖြစ်သည်။
//
// အဓိကအားဖြင့် `USIZE_MARKER` ရှိ function pointer သည် *01* နှင့်သာသက်ဆိုင်သောလိပ်စာများကို ၄ င်းတို့၏ပထမဆုံးအငြင်းအခုံအဖြစ်ယူသောလုပ်ဆောင်ချက်များအတွက်သေချာစေချင်သည်။
// ဤနေရာတွင် read_volatile ကကျွန်ုပ်တို့အားလွန်ခဲ့သောရည်ညွှန်းချက်မှ usize ကိုလုံခြုံစွာအဆင်သင့်ဖြစ်စေရန်နှင့်ဤလိပ်စာသည်အသုံးမပြုသောလုပ်ဆောင်မှုကိုညွှန်ပြခြင်းမရှိစေရန်သေချာစေသည်။
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // လုံခြုံမှု: ptr တစ်ဦးကိုကိုးကားဖြစ်ပါသည်
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // လုံခြုံမှု: `mem::transmute(x)` လုံခြုံသောကွောငျ့ဖွစျပါသညျ
        //     1. `&'b T` `'b` နှင့်အစပြုထားသည့်သက်တမ်းကို (အကန့်အသတ်မရှိသက်တမ်းမရှိစေရန်) ထိန်းသိမ်းထားသည်။
        //     2.
        //     `&'b T` (`T` `Sized` အခါကဤနေရာတွင်သည်အတိုင်း,) နှင့် `&'b Opaque` `fn(&T, &mut Formatter<'_>) -> Result` နှင့် `fn(&Opaque, &mut Formatter<'_>) -> Result` (ရှည်လျားသော `T` `Sized` ဖြစ်သကဲ့သို့ကဲ့သို့) တူညီသော ABI ရှိစဉ်ကတည်းက `mem::transmute(f)` လုံခြုံအတူတူပင်မှတ်ဉာဏ် layout ကိုရှိ
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // လုံခြုံမှု-`formatter` field ကို USIZE_MARKER သာသတ်မှတ်ထားသည်
            // တန်ဖိုးတစ်ခု usize ဖြစ်တယ်, ဒါကြောင့်ဒီလုံခြုံဖြစ်ပါတယ်
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// format_args ၏ v1 format နဲ့ရရှိနိုင်အလံများ
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// အဆိုပါ format_args! () နိုင်တဲ့ macro အသုံးပြုတဲ့အခါ, ဒီ function ကို Arguments ဖွဲ့စည်းပုံမှာထုတ်လုပ်ဖို့အသုံးပြုသည်။
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// ဒီ function စံမမှန်ပုံစံ parameters များကိုသတ်မှတ်အသုံးပြုသည်။
    /// ခိုင်လုံသော Arguments ဖွဲ့စည်းပုံကိုတည်ဆောက်ရန် `pieces` array သည်အနည်းဆုံးနေသမျှကာလပတ်လုံး `fmt` ဖြစ်ရပါမည်။
    /// ထို့အပြင် `fmt` သို့မဟုတ် `CountIsParam` အတွင်းရှိ X0 `CountIsNextParam` အတွင်းရှိမည်သည့် `Count` မဆို `argumentusize` နှင့်ဖန်တီးထားသောအငြင်းပွားမှုကိုညွှန်ပြရမည်။
    ///
    /// သို့သော်ထိုသို့ပြုလုပ်ရန်ပျက်ကွက်ခြင်းသည်လုံခြုံမှုမရှိဟုမဆိုလိုပါ။
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// ပုံစံစာသားရဲ့အရှည်ခန့်မှန်းထားသည်။
    ///
    /// ဤသည် `format!` တွေကိုအသုံးပြုတဲ့အခါကနဦး `String` စွမ်းရည် setting များအတွက်အသုံးပြုခံရဖို့ရည်ရွယ်တာဖြစ်ပါတယ်။
    /// Note: ဤသည်အောက်ပိုင်းနှင့်အထက်ပိုင်းလည်းမဟုတ်။
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // ပုံစံ string ကိုတစ်ဦးအငြင်းအခုံနှင့်အတူစတင်သည် အကယ်. အပိုင်းပိုင်း၏အရှည်သိသိသာသာဖြစ်ပါသည်မဟုတ်လျှင်, preallocate မဟုတ်ဘာမှလုပ်ပါ။
            //
            //
            0
        } else {
            // အငြင်းပွားမှုများအချို့ရှိသည်, ဒါကြောင့်မဆိုအပိုဆောင်းတွန်းအားပေး string ကိုပြန်လည်ခွဲဝေပါလိမ့်မယ်။
            //
            // ဒါကိုရှောင်ရှားရန်ကျွန်ုပ်တို့ဒီမှာစွမ်းရည် "pre-doubling" ရှိတယ်။
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// ဤဖွဲ့စည်းပုံသည်လုံခြုံစွာကြိုတင်စုစည်းထားသော format string ၏ဗားရှင်းနှင့်၎င်း၏အငြင်းပွားမှုများကိုကိုယ်စားပြုသည်။
/// ဒါဟာလုံခြုံစွာပြုမိမရနိုငျသောကွောငျ့ runtime မှာထုတ်လုပ်ပြီးမရနိုင်, ဒါကြောင့်အဘယ်သူမျှမတည်ဆောက်ပေးထားသောနှင့်လယ်ကွင်းပြုပြင်မွမ်းမံကာကွယ်တားဆီးဖို့ပုဂ္ဂလိကဖြစ်ကြ၏။
///
///
/// [`format_args!`] macro သည်ဤတည်ဆောက်ပုံ၏ဥပမာတစ်ခုကိုလုံခြုံစွာဖန်တီးလိမ့်မည်။
/// အဆိုပါ [`write()`] နှင့် [`format()`] လုပ်ဆောင်ချက်များကို၏အသုံးပြုမှုကိုလုံခြုံစွာလုပ်ဆောင်နိုင်ပါတယ်ဒါနိုင်တဲ့ macro compile လုပ်ခြင်း-အချိန်တွင် format နဲ့ string ကို validates ။
///
/// X0XX နှင့် `Display` အခင်းအကျင်းများအောက်တွင်ဖော်ပြထားသည့်အတိုင်းပြန်လာသည့် `Arguments<'a>` ကိုသင်အသုံးပြုနိုင်သည်။
/// ဥပမာကလည်းရှိုးပွဲနဲ့အတူတူပါပဲမှ `Debug` နှင့် `Display` ပုံစံတစ်ခုကို: `format_args!` အတွက် Interpol format နဲ့ string ကို။
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // ပုံနှိပ်ရန် string ကိုအပိုင်းပိုင်း format လုပ်ပါ။
    pieces: &'a [&'static str],

    // Placeholder ကျန်တာတွေ, ဒါမှမဟုတ် `None` အားလုံးကျန်တာတွေ ("{}{}" ကဲ့သို့) ကို default လျှင်။
    fmt: Option<&'a [rt::v1::Argument]>,

    // string ကိုအပိုင်းပိုင်းနှင့်အတူ interleaved ခံရဖို့ Interpol များအတွက် dynamic အငြင်းပွားမှုများ။
    // (ကျွန်တော်ငြင်းခုံတစ်ဦး string ကိုအပိုင်းအစတို့ကရှေ့ပြေးဖြစ်ပါတယ်။)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// ကချပ်ခံရဖို့အဘယ်သူမျှမငြင်းခုံရှိပါတယ်လျှင်, ၏ format string ကိုရယူပါ။
    ///
    /// ဤသည်ကိုအများဆုံးအသေးအဖွဲကိစ္စများတွင်ခွဲတမ်းမှရှောင်ရှားရန်အသုံးပြုနိုင်ပါသည်။
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` စကားစပ် debugging, တစ်ဦးပရိုဂရမ်မာ-face အတွက် output ကို format သငျ့သညျ။
///
/// ယေဘုယျအားဖြင့်စကားပြော, သင်ရုံ `derive` တစ် `Debug` အကောင်အထည်ဖော်မှုသင့်ပါတယ်။
///
/// ယင်းအခြား format နဲ့သတ်မှတ်ထားတဲ့ `#?` နှင့်အတူအသုံးပြုသောအခါ, output ကိုတော်တော်လေး-ပုံနှိပ်ဖြစ်ပါတယ်။
///
/// Formatters အကြောင်းပိုမိုသိရှိလိုပါက [the module-level documentation][module] တွင်ကြည့်ပါ။
///
/// [module]: ../../std/fmt/index.html
///
/// နယ်ပယ်အားလုံး `Debug` ကိုအကောင်အထည်ဖော်မည်ဆိုလျှင်ဤ trait ကို `#[derive]` နှင့်အသုံးပြုနိုင်သည်။
/// structs များအတွက်သည့်အခါ `derive`d ကြောင့် `}` ပြီးတော့, `{` ထို့နောက်အသီးအသီးသောလယ်ရဲ့အမည်နှင့် `Debug` တန်ဖိုးထို့နောက်ကော်မာ-separated စာရင်း `struct` ၏နာမတော်ကိုသုံးပါလိမ့်မယ်။
/// သက်ဆိုင်လျှင် `enum`s သည်လယ်ကွင်းများ `Debug` တန်ဖိုးများ, ထို့နောက် `)` ပြီးတော့, `(` အဆိုပါမူကွဲ၏အမည်ကိုသုံးပါနှင့်မည်ဖြစ်သည်။
///
/// # Stability
///
/// ဆင်းသက်လာ `Debug` ကို formats တည်ငြိမ်မဟုတ်ဖြစ်ကြသည်ကို၎င်း, ဒါ future Rust ဗားရှင်းနဲ့အတူပြောင်းလဲသွားစေနိုင်သည်။
/// ထို့အပြင်စံစာကြည့်တိုက် (စသည်တို့ကို `libstd`, `libcore`, `liballoc`,) ကထောက်ပံ့ပေးအမျိုးအစားများ `Debug` Implementation ကိုတည်ငြိမ်မဟုတ်လည်း future Rust ဗားရှင်းနဲ့အတူပြောင်းလဲသွားစေနိုင်သည်။
///
///
/// # Examples
///
/// အကောင်အထည်ဖော်မှုတစ်ခုရရှိခြင်း
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// ကိုယ်တိုင်အကောင်အထည်ဖော်:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// ထိုကဲ့သို့သော [`debug_struct`] အဖြစ်ကို manual အကောင်အထည်ဖော်မှုအားဖြင့်သင်တို့ကိုကူညီဖို့ရန် [`Formatter`] struct အပေါ်အထောက်အနည်းလမ်းများ၏နံပါတ်ရှိပါသည်။
///
/// `Debug` [`Formatter`] သို့မဟုတ် [`Formatter`] ရှိ debug builder API ကို သုံး၍ အစဉ်လိုက်အခြားအလံကို သုံး၍ တော်တော်လေးပုံနှိပ်နိုင်သည်။ `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// `#?` နှင့်အတူတော်တော်လေး-ပုံနှိပ်:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// ပေးထားသော formatter သုံးပြီးတန်ဖိုး Formats ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// အဆိုပါ trait `Debug` မပါဘဲ prelude ကနေနိုင်တဲ့ macro `Debug` reexport မှသီးခြား module တစ်ခု။
pub(crate) mod macros {
    /// trait `Debug` ၏အကျိုးသက်ရောက်မှုကိုထုတ်လုပ်သည့် macro ကိုရယူပါ။
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// ဗလာပုံစံတစ်ခုအတွက် trait ကို format လုပ်ပါ။ `{}`.
///
/// `Display` [`Debug`] နှင့်ဆင်တူသော်လည်း `Display` သည်အသုံးပြုသူနှင့်သက်ဆိုင်သော output အတွက်ဖြစ်သည်။
///
///
/// Formatters အကြောင်းပိုမိုသိရှိလိုပါက [the module-level documentation][module] တွင်ကြည့်ပါ။
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// အမျိုးအစားပေါ် `Display` အကောင်အထည်ဖော်:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// ပေးထားသော formatter သုံးပြီးတန်ဖိုး Formats ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// `Octal` trait သည်၎င်း၏ output ကို base-8 တွင်နံပါတ်အဖြစ် format လုပ်သင့်သည်။
///
/// စရိုက်တွေလက်မှတ်ရေးထိုးခဲ့ကိန်း (`i128` မှ `i8` နှင့် `isize`) အတွက်အနှုတ်တန်ဖိုးနှစ်ခုရဲ့အဖြည့်ကိုယ်စားပြုမှုအဖြစ်ချပ်နေကြသည်။
///
///
/// အခြားအလံ, `#`, က output များ၏ရှေ့မှောက်၌တစ်ဦး `0o` ကထပ်ပြောသည်။
///
/// Formatters အကြောင်းပိုမိုသိရှိလိုပါက [the module-level documentation][module] တွင်ကြည့်ပါ။
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` ဖြင့်အခြေခံအသုံးပြုမှု-
///
/// ```
/// let x = 42; // 42 octal အတွက် '52' ဖြစ်ပါသည်
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// အမျိုးအစားပေါ် `Octal` အကောင်အထည်ဖော်:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // i32 ရဲ့အကောင်အထည်ဖော်မှုမှလွှဲအပ်
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// ပေးထားသော formatter သုံးပြီးတန်ဖိုး Formats ။
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// အဆိုပါ `Binary` trait binary အတွက်နံပါတ်အဖြစ်က၎င်း၏ output ကို format သငျ့သညျ။
///
/// စရိုက်တွေလက်မှတ်ရေးထိုးခဲ့ကိန်း ([`i128`] မှ [`i8`] နှင့် [`isize`]) အတွက်အနှုတ်တန်ဖိုးနှစ်ခုရဲ့အဖြည့်ကိုယ်စားပြုမှုအဖြစ်ချပ်နေကြသည်။
///
///
/// အခြားအလံ, `#`, output ကိုများ၏ရှေ့မှောက်၌ `0b` ကထပ်ပြောသည်။
///
/// Formatters အကြောင်းပိုမိုသိရှိလိုပါက [the module-level documentation][module] တွင်ကြည့်ပါ။
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// [`i32`] ဖြင့်အခြေခံအသုံးပြုမှု-
///
/// ```
/// let x = 42; // 42 binary အတွက် '101010' ဖြစ်ပါတယ်
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// `Binary` အမျိုးအစားတစ်မျိုးကိုအကောင်အထည်ဖော်ခြင်း-
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // i32 ရဲ့အကောင်အထည်ဖော်မှုမှလွှဲအပ်
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// ပေးထားသော formatter သုံးပြီးတန်ဖိုး Formats ။
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// `LowerHex` trait သည်၎င်း၏ output ကို hexadecimal တွင်နံပါတ်အဖြစ် format လုပ်သင့်သည်။ `a` မှ `f` သည်စာလုံးအသေးဖြင့်ဖြစ်သည်။
///
/// စရိုက်တွေလက်မှတ်ရေးထိုးခဲ့ကိန်း (`i128` မှ `i8` နှင့် `isize`) အတွက်အနှုတ်တန်ဖိုးနှစ်ခုရဲ့အဖြည့်ကိုယ်စားပြုမှုအဖြစ်ချပ်နေကြသည်။
///
///
/// အခြားအလံ, `#`, output ကိုများ၏ရှေ့မှောက်၌ `0x` ကထပ်ပြောသည်။
///
/// Formatters အကြောင်းပိုမိုသိရှိလိုပါက [the module-level documentation][module] တွင်ကြည့်ပါ။
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` ဖြင့်အခြေခံအသုံးပြုမှု-
///
/// ```
/// let x = 42; // 42 hex အတွက် '2a' ဖြစ်ပါတယ်
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// အမျိုးအစားပေါ် `LowerHex` အကောင်အထည်ဖော်:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // i32 ရဲ့အကောင်အထည်ဖော်မှုမှလွှဲအပ်
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// ပေးထားသော formatter သုံးပြီးတန်ဖိုး Formats ။
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// `UpperHex` trait သည်၎င်း၏ output ကို hexadecimal တွင်နံပါတ်အဖြစ် format လုပ်သင့်သည်။ `A` မှ `F` သည်စာလုံးအကြီးနှင့်ဖြစ်သည်။
///
/// စရိုက်တွေလက်မှတ်ရေးထိုးခဲ့ကိန်း (`i128` မှ `i8` နှင့် `isize`) အတွက်အနှုတ်တန်ဖိုးနှစ်ခုရဲ့အဖြည့်ကိုယ်စားပြုမှုအဖြစ်ချပ်နေကြသည်။
///
///
/// အခြားအလံ, `#`, output ကိုများ၏ရှေ့မှောက်၌ `0x` ကထပ်ပြောသည်။
///
/// Formatters အကြောင်းပိုမိုသိရှိလိုပါက [the module-level documentation][module] တွင်ကြည့်ပါ။
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` ဖြင့်အခြေခံအသုံးပြုမှု-
///
/// ```
/// let x = 42; // 42 hex အတွက် '2A' ဖြစ်ပါသည်
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// အမျိုးအစားပေါ် `UpperHex` အကောင်အထည်ဖော်:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // i32 ရဲ့အကောင်အထည်ဖော်မှုမှလွှဲအပ်
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// ပေးထားသော formatter သုံးပြီးတန်ဖိုး Formats ။
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// `Pointer` trait သည်၎င်း၏ output ကို memory location အဖြစ် format လုပ်သင့်သည်။
/// ဒီအလေ့ hexadecimal အဖြစ်ပေးအပ်သည်။
///
/// Formatters အကြောင်းပိုမိုသိရှိလိုပါက [the module-level documentation][module] တွင်ကြည့်ပါ။
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `&i32` နှင့်အတူအခြေခံအသုံးပြုမှု:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // ဒီ '0x7f06092ac6d0' တူတစ်ခုခုထုတ်လုပ်
/// ```
///
/// အမျိုးအစားပေါ် `Pointer` အကောင်အထည်ဖော်:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // ကျနော်တို့သုံးနိုငျသောညွှန်းအကောင်အထည်ဖော်ဆောင်ရွက်နေသောသော `*const T` မှပြောင်းလဲမှ `as` ကိုသုံးပါ
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// ပေးထားသော formatter သုံးပြီးတန်ဖိုး Formats ။
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// `LowerExp` trait သည်၎င်း၏ output ကိုသိပ္ပံနည်းကျသင်္ကေတဖြင့်စာလုံးအသေး `e` ဖြင့် format လုပ်သင့်သည်။
///
/// Formatters အကြောင်းပိုမိုသိရှိလိုပါက [the module-level documentation][module] တွင်ကြည့်ပါ။
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64` ဖြင့်အခြေခံအသုံးပြုမှု-
///
/// ```
/// let x = 42.0; // 42.0 '4.2e1' သိပ္ပံနည်းကျသင်္ကေတ၌တည်ရှိ၏
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// အမျိုးအစားပေါ် `LowerExp` အကောင်အထည်ဖော်:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // f64 ရဲ့အကောင်အထည်ဖော်မှုမှကိုယ်စားလှယ်
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// ပေးထားသော formatter သုံးပြီးတန်ဖိုး Formats ။
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// အဆိုပါ `UpperExp` trait တစ်ခုအထက်-ကိစ္စတွင် `E` နှင့်အတူသိပ္ပံနည်းကျသင်္ကေတအတွက်သူ့ရဲ့ output ကို format သငျ့သညျ။
///
/// Formatters အကြောင်းပိုမိုသိရှိလိုပါက [the module-level documentation][module] တွင်ကြည့်ပါ။
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64` ဖြင့်အခြေခံအသုံးပြုမှု-
///
/// ```
/// let x = 42.0; // 42.0 '4.2E1' သိပ္ပံနည်းကျသင်္ကေတ၌တည်ရှိ၏
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// `UpperExp` အမျိုးအစားတစ်မျိုးကိုအကောင်အထည်ဖော်ခြင်း-
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // f64 ရဲ့အကောင်အထည်ဖော်မှုမှကိုယ်စားလှယ်
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// ပေးထားသော formatter သုံးပြီးတန်ဖိုး Formats ။
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// အဆိုပါ `write` function ကိုတစ်ဦး output stream ကိုယူပြီးလျှင်, `format_args!` နိုင်တဲ့ macro နှင့်အတူ precompiled နိုင်ထားတဲ့ `Arguments` struct ။
///
///
/// အဆိုပါအငြင်းပွားမှုများပေးထားသော output ကိုစီးထဲသို့သတ်မှတ်ထားသော format ကို string ကိုအရသိရသည် format လုပ်လိမ့်မည်။
///
/// # Examples
///
/// အခြေခံအသုံးပြုမှု-
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// [`write!`] ကိုအသုံးပြုခြင်းသည်ပိုကောင်းသည်ကိုသတိပြုပါ။ဥပမာ-
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // အငြင်းပွားမှုများအားလုံးအတွက် default formatting parameters များကိုသုံးနိုင်သည်။
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // တိုင်း spec တစ်ဦး string ကိုအပိုင်းအစတို့ကရှေ့ပြေးသောသက်ဆိုင်ရာအငြင်းအခုံရှိပါတယ်။
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // လုံခြုံမှု: arg နှင့် args.args သည်တူညီသော argumenti မှဆင်းသက်သည်။
                // သောအညွှန်းကိန်းဘောငျအတှငျးကအမြဲရှိပါတယ်အာမခံပါသည်။
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // ကျန်ရှိနေသေးသောကြိုးတစ်ချောင်းသာကျန်တော့သည်။
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // လုံခြုံမှု: arg နှင့် args အတူတူ Arguments ကလာ,
    // သောအညွှန်းကိန်းဘောငျအတှငျးကအမြဲရှိပါတယ်အာမခံပါသည်။
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // မှန်ကန်သောအငြင်းအခုံထုတ်ယူပါ
    debug_assert!(arg.position < args.len());
    // လုံခြုံမှု: arg နှင့် args အတူတူ Arguments ကလာ,
    // အရာသည်၎င်း၏အညွှန်းကိန်းဘောငျအတှငျးကအမြဲဖြစ်ပါသည်အာမခံပါသည်။
    let value = unsafe { args.get_unchecked(arg.position) };

    // ထိုအခါအမှန်တကယ်ပုံနှိပ်အချို့လုပ်ပါ
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // လုံခြုံမှု: cnt နှင့် args အတူတူ Arguments ကလာ,
            // ဒီအညွှန်းကိန်းနယ်နိမိတ်အတွင်းအမြဲအာမခံပါသည်။
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// တစ်ခုခု၏အဆုံးပြီးနောက် padding ။`Formatter::padding` အားဖြင့်ပြန်သွား၏။
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// ဒီ post padding ရေးပါ။
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // ငါတို့ဒီဟာကိုပြောင်းချင်တယ်
            buf: wrap(self.buf),

            // ထိုအထိန်းသိမ်းထားပါ
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // padding နှင့် processing အားလုံးပုံစံ traits အသုံးပွုနိုငျကွောငျးကိုငြင်းခုံပုံစံအတွက်အသုံးပြု helper နည်းလမ်းများ။
    //

    /// ပြီးသားတစ်ဦး str သို့ထုတ်လွှတ်ထားပြီးသည့်ကိန်းများအတွက်မှန်ကန်သော padding ကိုလုပ်ဆောင်တယ်။
    /// str တွင် *တွင်* ကိန်းသေအရိပ်လက္ခဏာမပါ ၀ င်ပါ။
    ///
    /// # Arguments
    ///
    /// * is_nonnegative သည်မူလကိန်းသည်အပေါင်းလားသုညလားဆိုတာလား။
    /// * ရှေ့ဆက်, '#' ဇာတ်ကောင် (Alternate) ပေးလျှင်, ဒီနံပါတ်များ၏ရှေ့မှောက်၌ထားရန်ရှေ့ဆက်ဖြစ်ပါတယ်။
    ///
    /// * buf, နံပါတ်ကို format လုပ်ထားပြီးသော byte ခင်းကျင်း
    ///
    /// ဒီ function ကိုမှန်ကန်စွာနိမ့်ဆုံးအကျယ်အဖြစ်ပေးအလံများအတွက်အကောင့်ပါလိမ့်မယ်။
    /// ဒါဟာအကောင့်သို့တိကျစွာယူလိမ့်မည်မဟုတ်ပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // ကျွန်ုပ်တို့သည်နံပါတ်ထွက်ရှိမှုမှ "-" ကိုဖယ်ရှားရန်လိုအပ်သည်။
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // ကမေတ္တာရပ်ခံခဲ့ပါတယ်လျှင်တည်ရှိပါလျှင်နိမိတ်လက္ခဏာ, အဲဒီနောက်ရှေ့ဆက်ရေးသားခဲ့သည်
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // အဆိုပါ `width` လယ်ကိုဒီအမှတ်တစ်ဦး `min-width` parameter သည်ပိုမိုဖြစ်ပါတယ်။
        match self.width {
            // အဘယ်သူမျှမနိမ့်ဆုံးအရှည်လိုအပ်ချက်ရှိပါတယ်လျှင်ကျွန်တော့် bytes ကိုရေးနိုင်ပါတယ်။
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // ကျွန်တော်တို့ကအနည်းဆုံး width ရှိသလားစစ်ဆေးကြည့်ပါ။ ပြီးတော့ဒါဆို bytes တွေကိုရေးရုံပဲ။
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // အဆိုပါဝစွာဇာတ်ကောင်သုညလျှင်နိမိတ်လက္ခဏာနှင့်ရှေ့ဆက်အဆိုပါ padding ကိုမရောက်မီဝင်
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // ဒီလိုမှမဟုတ်ရင်နိမိတ်လက္ခဏာနှင့်ရှေ့ဆက်အဆိုပါ padding ကိုအပြီးဝင်
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// ဒီ function ဟာ string ကိုအချပ်ကြာနှင့်သတ်မှတ်ထားသောသက်ဆိုင်ရာပုံစံအလံလျှောက်ထားပြီးနောက်ပြည်တွင်းရေးကြားခံကထုတ်လွှတ်ပေးပါသည်။
    /// ယေဘူယျညှို့များအတွက်အသိအမှတ်ပြုအလံများမှာ
    ///
    /// * width, emit လုပ်ရမည့်အနိမ့်ဆုံးအကျယ်
    /// * fill/align - အကယ်၍ ပေးထားသော string ကို padded လုပ်ရန်လိုအပ်ပါကမည်သည်ထုတ်လွှတ်ရမည်နှင့်မည်သည့်နေရာတွင်ထုတ်လွှတ်ရမည်နည်း
    /// * တိကျမှု၊ ထုတ်လွှတ်ရန်အမြင့်ဆုံးအရှည်၊ အကယ်၍ ၎င်းအရှည်ထက်ပိုရှည်ပါကကြိုးမျှင်ကိုချုံ့သည်
    ///
    /// အထူးသဤ function ကို `flag` parameters တွေကိုလျစ်လျူရှု။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // ရှေ့တွင်အစာရှောင်လမ်းကြောင်းရှိသည်ကိုသေချာအောင်လုပ်ပါ
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // အဆိုပါ `precision` လယ်ပြင်ကို format ခံရ string ကိုများအတွက် `max-width` အဖြစ်အဓိပ္ပာယ်ကောက်ယူနိုင်ပါသည်။
        //
        let s = if let Some(max) = self.precision {
            // အကယ်၍ ကျွန်ုပ်တို့၏ string သည်တိကျမှုထက်ပိုရှည်ပါကကျွန်ုပ်တို့သည်အကန့်အသတ်ရှိရမည်။
            // သို့သော် `fill`, `width` နှင့် `align` ကဲ့သို့သောအခြားအလံများသည်ပုံမှန်အတိုင်းလုပ်ဆောင်ရမည်။
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // ဤနေရာတွင် LLVM `..i` panic `&s[..i]` မကြောင်းသက်သေမပြနိုင်ပေမယ့်ကျနော်တို့က panic မပြုနိုင်ကြောင်းကိုငါသိ၏။
                // `unsafe` ကိုရှောင်ရှားဖို့နဲ့မဟုတ်ရင်ဒီနေရာမှာမဆို panic-ဆက်စပ်ကုဒ်ထုတ်လွှတ်ဘူးအသုံးပြုမှု `get` + `unwrap_or` ။
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // အဆိုပါ `width` လယ်ကိုဒီအမှတ်တစ်ဦး `min-width` parameter သည်ပိုမိုဖြစ်ပါတယ်။
        match self.width {
            // ကျနော်တို့အများဆုံးအရှည်အောက်မှာနေနှင့်မျှမနိမ့်ဆုံးအရှည်လိုအပ်ချက်ရှိပါတယ်လျှင်, ကျွန်တော့် string ကိုထုတ်လွှတ်နိုင်ပါတယ်
            //
            None => self.buf.write_str(s),
            // ဒါကြောင့်ပဲ string ကို emitting အဖြစ်လွယ်ကူသောအဖြစ်ဖွင့်နိုင်အောင်လျှင်, အနိမ့်ဆုံး width ကိုကျော်နေလျှင်ကျနော်တို့အများဆုံး width ကိုအောက်မှာစစ်ဆေးမှုများဆိုရင်။
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // ကျနော်တို့အများဆုံးနှင့်အနည်းဆုံး width ကိုနှစ်ဦးစလုံးအောက်မှာနေလျှင်, သတ်မှတ်ထားသော string ကို + အချို့သော alignment ကိုအတူနိမ့်ဆုံး width ကိုတက်ဖြည့်ပါ။
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// pre-padding ကိုရေးရန်နှင့်မရေးထားသော Post-padding ကိုပြန်သွားပါ။
    /// ခေါ်ဆို Post-padding ကိုရာတေးသံဖြစ်ခြင်းကြောင်းအရာအပြီးတိကျမ်းစာ၌လာသည်ကားရေးအတွက်တာဝန်ရှိသည်။
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// အဆိုပါချပ်အစိတ်အပိုင်းများကိုယူ။ padding ကိုသက်ဆိုင်ပါသည်။
    /// အဆိုပါခေါ်ဆိုမှုပြီးသား `self.precision` လျစ်လျူရှုထားနိုင်ပါတယ်ဒါကြောင်း, လိုအပ်သောတိကျစွာအတူအစိတ်အပိုင်းများကိုပြန်ဆိုတော်မူကြောင်းကိုယူဆတယ်။
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // ကျနော်တို့ရှေ့ဦးစွာ မှစ. အဘယ်သူမျှမနိမိတ်လက္ခဏာရှိခဲ့လျှင်အဖြစ်နိမိတ်လက္ခဏာ-သတိထားသုည padding ကိုများအတွက်ကျနော်တို့ပထမဦးဆုံးနိမိတ်ပြုမူဆပ်။
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // နိမိတ်လက္ခဏာကိုအမြဲပထမဦးဆုံးအတတ်
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // အဆိုပါချပ်အစိတ်အပိုင်းများကနေနိမိတ်လက္ခဏာကိုဖယ်ရှား
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // ကျန်ရှိနေသေးသောအစိတ်အပိုင်းများကိုသာမန် padding လုပ်ငန်းစဉ်မှဖြတ်သွားသည်
            let len = formatted.len();
            let ret = if width <= len {
                // အဘယ်သူမျှမ padding ကို
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // ဒီဘုံကိစ္စတွင်ဖြစ်ပြီးကျွန်တော်တစ်ဦးဖြတ်လမ်းယူ
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // လုံခြုံမှု-ဤအရာကို `flt2dec::Part::Num` နှင့် `flt2dec::Part::Copy` အတွက်အသုံးပြုသည်။
            // `flt2dec::Part::Num` အတွက် char `c` တိုင်းသည် `b'0'` နှင့် `b'9'` အကြားရှိသည်။ `s` သည် UTF-8 ဖြစ်သည်။
            // `buf` လွင်ပြင် ASCII ဖြစ်သင့်ကတည်းကဒါဟာ `flt2dec::Part::Copy(buf)` များအတွက်သုံးစွဲဖို့အလေ့အကျင့်လည်းဖြစ်ကောင်းလုံခြုံရဲ့, ဒါပေမယ့်တစ်စုံတစ်ယောက်က `flt2dec::to_shortest_str` သို့ `buf` များအတွက်မကောင်းတဲ့တန်ဖိုးရှောက်သွားဘို့ကအများပြည်သူ function ကိုတစ်ခုဖြစ်သည်ကတည်းကဖြစ်နိုင်ပါတယ်။
            //
            // FIXME: ဒီ UB ဖြစ်ပေါ်နိုင်ခြင်းရှိမရှိဆုံးဖြတ်ပါ။
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 သုည
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// ဒီ formatter အတွင်းပါရှိသောနောက်ခံကြားခံတချို့ဒေတာများကိုရေးသားခဲ့သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // ဒီညီမျှခြင်းသည်
    ///         // ရေးပါ! (Formatter, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// တချို့၏ format သတင်းအချက်အလက်ဒီဥပမာသို့ရေးသားခဲ့သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// ပုံစံချခြင်းအတွက်အလံများ
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// alignment ကိုလည်းမရှိအခါတိုင်းဇာတ်ကောင် 'fill' အဖြစ်အသုံးပြုခဲ့သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // ကျနော်တို့ ">" နှင့်အတူညာဘက် alignment ကိုခန့်ထား၏။
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// ညှိနှိုင်းမှုကိုဘယ်လိုပုံစံကိုမေတ္တာရပ်ခံခဲ့သည်ကိုညွှန်ပြအလံ။
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// လုပ်နိုင်သောက output ဖြစ်သင့်ကြောင်းအကျယ်ကိန်းသတ်မှတ်ထားသော။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // ကျွန်တော်တစ်ဦး width ကိုလက်ခံရရှိလျှင်, ငါတို့သည်အသုံးပြုရန်
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // ဒီလိုမှမဟုတ်ရင်ငါတို့အထူးဘာမှမလုပ်ဘူး
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// လုပ်နိုင်သောဂဏန်းအမျိုးအစားများများအတွက်တိကျသတ်မှတ်ထားသော။
    /// တနည်းအား string ကိုအမျိုးအစားများများအတွက်အများဆုံး width ကို။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // ကျွန်တော်တစ်ဦးတိကျစွာရရှိခဲ့လျှင်, ငါတို့သည်ကြောင့်သုံးပါ။
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // ဒီလိုမှမဟုတ်ရင်ကျနော်တို့ 2 default ။
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// အဆိုပါ `+` အလံသတ်မှတ်ထားသောခဲ့လျှင်ဆုံးဖြတ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// အဆိုပါ `-` အလံသတ်မှတ်ထားသောခဲ့လျှင်ဆုံးဖြတ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // သင်တစ်ဦးအနုတ်လက္ခဏာသက်သေလိုသလား?တစ်ခုရှိ!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// အဆိုပါ `#` အလံသတ်မှတ်ထားသောခဲ့လျှင်ဆုံးဖြတ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// အဆိုပါ `0` အလံသတ်မှတ်ထားသောခဲ့သည်ဆိုပါကဆုံးဖြတ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // ကျနော်တို့ formatter ရဲ့ရွေးချယ်မှုများလျစ်လျူရှု။
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: ဒီနှစ်ခုအလံအဘို့အလိုခငျြလူထုအဘယျသို့ API ကိုဆုံးဖြတ်ပါ။
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// structs များအတွက် [`fmt::Debug`] အကောင်အထည်ဖော်မှု၏ဖန်ဆင်းခြင်းနှင့်အတူကူညီပေးဖို့ဒီဇိုင်း [`DebugStruct`] ဆောက်ဖန်တီးပေးပါတယ်။
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// tuple structs များအတွက် `fmt::Debug` အကောင်အထည်ဖော်မှု၏ဖန်ဆင်းခြင်းနှင့်အတူကူညီပေးဖို့ဒီဇိုင်း `DebugTuple` ဆောက်ဖန်တီးပေးပါတယ်။
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// စာရင်းတူသောအဆောက်အဦများအတွက် `fmt::Debug` အကောင်အထည်ဖော်မှု၏ဖန်ဆင်းခြင်းနှင့်အတူကူညီပေးဖို့ဒီဇိုင်း `DebugList` ဆောက်ဖန်တီးပေးပါတယ်။
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// Set-တူသောအဆောက်အဦများအတွက် `fmt::Debug` အကောင်အထည်ဖော်မှု၏ဖန်ဆင်းခြင်းနှင့်အတူကူညီပေးဖို့ဒီဇိုင်း `DebugSet` ဆောက်ဖန်တီးပေးပါတယ်။
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// ဒီပိုမိုရှုပ်ထွေးဥပမာမှာကျွန်တော်တို့ဟာပွဲစဉ်လက်နက်များစာရင်းကိုတည်ဆောက်ရန် [`format_args!`] နှင့် `.debug_set()` ကိုသုံးပါ:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// မြေပုံနှင့်တူသောအဆောက်အ ဦ များအတွက် `fmt::Debug` အကောင်အထည်ဖော်မှုကိုဖန်တီးရာတွင်ကူညီရန်ဒီဇိုင်းပြုလုပ်ထားသော `DebugMap` တည်ဆောက်သူကိုဖန်တီးသည်။
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// traits ပုံစံအဓိကအကောင်အထည်ဖော်ရေး

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // အကယ်၍ char သည်လွတ်မြောက်ရန်လိုအပ်ပါက backlog ကိုယခုခဏသာုတ်။ ရေးပါ၊ အခြားတစ်ခုကိုကျော်ပါ
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // အခြားအလံပြီးသားက 0x နှင့်အတူရှေ့ဆက်ဖို့ရှိမရှိရည်ညွှန်းအထူးဖြစ်ခြင်းအဖြစ် LowerHex ခြင်းဖြင့်ကုသနိုင်သည်။
        // ကျနော်တို့သုညသို့မဟုတ်မရှိမရှိတိုးချဲ့, ပြီးတော့ခြွင်းချက်မရှိဟာရှေ့ဆက်ရကသတ်မှတ်ထားထုတ်လုပ်ကိုင်ဖို့ကသုံးပါ။
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// အမျိုးမျိုးသော core အမျိုးအစားများအတွက် Display/Debug ၏အကောင်အထည်ဖော်မှု

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // RefCell ကိုအပြန်အလှန်ချေးယူသည်။ ထို့ကြောင့်၎င်းသည်၎င်း၏တန်ဖိုးကိုကျွန်ုပ်တို့မကြည့်နိုင်ပါ။
                // အစားအမှတ်အသားပြပါ။
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// သငျသညျစမ်းသပ်မှုကဒီမှာဖြစ်လိမ့်မည်ဟုမျှော်လင့်လျှင်, core/tests/fmt.rs ဖိုင်မှာအစားကြည့်ပါကအများကြီးပိုမိုလွယ်ကူဒီမှာ rt::Piece အဆောက်အဦများအပေါငျးတို့သကိုထက်ရဲ့။
//
// ခွဲဝေချထားရန်လိုအပ်သောသူများအတွက် alloc crate တွင်စမ်းသပ်မှုများရှိသည်။