//! ဒါက ifmt အသုံးပြုသောကာပြည်တွင်းရေး module တစ်ခုပါ!runtime ။ဤရွေ့ကားအဆောက်အဦရှေ့တွင်အချိန် precompile format နဲ့ညှို့မှငြိမ် Array ကိုမှထုတ်လွှတ်နေကြသည်။
//!
//! ဤရွေ့ကားအဓိပ္ပာယ်ကသူတို့ `ct` equivalents ဆင်တူပေမယ့်ဒီလိုမျိုး statically ခွဲဝေနိုင်ပြီးအနည်းငယ် runtime များအတွက် optimized ဖြစ်ကြောင်းထဲမှာကွာခြား
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// ဖြစ်နိုင်ချေရှိသော align များကို format လုပ်ရန်ညွှန်ကြားချက်၏အစိတ်အပိုင်းတစ်ခုအနေဖြင့်တောင်းဆိုနိုင်သည်။
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// ပါ ၀ င်သောအရာများသည်ဘယ်ဘက်နှင့်ကိုက်ညီသင့်ကြောင်းဖော်ပြသည်
    Left,
    /// contents တွေကို Right-aligned သင့်ကြောင်းညွှန်ပြ။
    Right,
    /// ပါ ၀ င်သည့်အကြောင်းအရာများသည်ဗဟိုနှင့်ကိုက်ညီသင့်ကြောင်းညွှန်ပြသည်။
    Center,
    /// အဘယ်သူမျှမ alignment ကိုမေတ္တာရပ်ခံခဲ့သည်။
    Unknown,
}

/// [width](https://doc.rust-lang.org/std/fmt/#width) နှင့် [precision](https://doc.rust-lang.org/std/fmt/#precision) သတ်မှတ်ထားတဲ့အသုံးပြုသော။
#[derive(Copy, Clone)]
pub enum Count {
    /// ပကတိနံပါတ်နှင့်အတူသတ်မှတ်ထားသော, တန်ဖိုးသိုလှောင်ထားသည်
    Is(usize),
    /// `$` နှင့် `*` Syntax ကို အသုံးပြု. သတ်မှတ်ထားသော, `args` သို့အညွှန်းကိန်းသိုလှောင်
    Param(usize),
    /// မသတ်မှတ်ထားပါ
    Implied,
}