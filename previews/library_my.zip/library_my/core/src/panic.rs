//! စံစာကြည့်တိုက်တွင် Panic အထောက်အပံ့။

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// panic အကြောင်းသတင်းအချက်အလက်ပေးသည့်ဖွဲ့စည်းပုံ။
///
/// `PanicInfo` ဖွဲ့စည်းပုံဟာ [`set_hook`] function ကိုအားဖြင့်သတ်မှတ်ထားတဲ့ panic hook လွန်နေသည်။
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// panic နှင့်သက်ဆိုင်သော payload ကိုပြန်သွားသည်။
    ///
    /// ၎င်းသည် `&'static str` သို့မဟုတ် [`String`] ဖြစ်သော်လည်းပုံမှန်မဟုတ်ပါ။
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// အကယ်၍ `core` crate (`std` မှမဟုတ်) မှ Formating string နှင့်အပိုဆောင်းအငြင်းပွားမှုများမှအသုံးပြုခဲ့သည့် `panic!` macro သည်ထိုမက်ဆေ့ခ်ျကို [`fmt::write`] နှင့်အတူအသုံးပြုရန်အဆင်သင့်ရှိနေသည်။
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// အကယ်၍ ရရှိနိုင်ပါက panic သည်မူလတည်ရှိသည့်နေရာနှင့်ပတ်သက်သောသတင်းအချက်အလက်ကိုပြန်ပို့သည်။
    ///
    /// ဤနည်းလမ်းသည်လက်ရှိတွင် [`Some`] ကိုအမြဲတမ်းပြန်ပို့ပေးမည်ဖြစ်သော်လည်း၎င်းသည် future ဗားရှင်းများတွင်ပြောင်းလဲနိုင်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: အကယ်၍ ၎င်းကိုတစ်ခါတစ်ရံမှပြန်ပို့ရန်ပြောင်းလဲပါက၊
        // std::panicking::default_hook နှင့် std::panicking::begin_panic_fmt ရှိထိုကိစ္စရပ်ကိုကိုင်တွယ်ပါ။
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: downcast_ref ကိုမသုံးနိုင်ပါ: :<String>() ဒီမှာ
        // နောက်ပိုင်းတွင် String ကို libcore တွင်မရပါ။
        // `std::panic!` ကိုငြင်းခုံမှုများစွာဖြင့်ခေါ်ဆိုသည့်အခါ payload သည် String တစ်ခုဖြစ်သည်။ သို့သော်ထိုကိစ္စတွင်သတင်းစကားလည်းရနိုင်သည်။
        //

        self.location.fmt(formatter)
    }
}

/// panic ၏တည်နေရာနှင့်ပတ်သက်သောသတင်းအချက်အလက်များပါ ၀ င်သောဖွဲ့စည်းပုံ။
///
/// ဤဖွဲ့စည်းပုံကို [`PanicInfo::location()`] မှဖန်တီးသည်။
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// တန်းတူညီမျှမှုနှင့်အစီအစဉ်များအတွက်နှိုင်းယှဉ်မှုများကိုဖိုင်၊ လိုင်း၊ ထို့နောက်ကော်လံ ဦး စားပေးဖြင့်ပြုလုပ်သည်။
/// Files များကို strings များနှင့်နှိုင်းယှဉ်သည်။ `Path` မဟုတ်ပါ။ ၎င်းသည်မမျှော်လင့်ဘဲဖြစ်လာနိုင်သည်။
/// ပိုမို၍ ဆွေးနွေးရန် [Location: : file`] ၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// ဒီ function ၏ခေါ်ဆိုသူ၏မူလတည်နေရာကိုပြန်သွားသည်။
    /// အကယ်၍ ထို function ၏ခေါ်ဆိုသူ၏မှတ်စုကိုမှတ်သားထားပါက၎င်းသည်၎င်း၏ခေါ်ဆိုမှုတည်နေရာကိုပြန်ပို့လိမ့်မည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// ၎င်းကိုခေါ်သော [`Location`] ကိုပြန်ပို့သည်။
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// ဒီ function ရဲ့အဓိပ္ပာယ်အတွင်းကနေ [`Location`] ကိုပြန်သွားသည်။
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // ကွဲပြားခြားနားသောနေရာတွင်အတူတူ untracked function ကို run ကျွန်တော်တို့ကိုအတူတူပင်ရလဒ်ကိုပေးသည်
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // ကွဲပြားခြားနားသောတည်နေရာအတွက် tracked function ကိုအပြေးတစ် ဦး ကွဲပြားခြားနားတန်ဖိုးကိုထုတ်လုပ်သည်
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// panic သည်မူလအရင်းအမြစ်ဖိုင်အမည်ကိုပြန်ပို့သည်။
    ///
    /// # `&str`, `&Path` မဟုတ်ပါဘူး
    ///
    /// ပြန်လာသောအမည်သည် compiling system ရှိအရင်းအမြစ်လမ်းကြောင်းကိုရည်ညွှန်းသည်။ သို့သော်၎င်းကို `&Path` အဖြစ်တိုက်ရိုက်ကိုယ်စားပြုရန်မသင့်လျော်။
    /// စုစည်းထားသောကုဒ်သည်ပါဝင်သည့်အကြောင်းအရာများကိုထောက်ပံ့ပေးသည့်စနစ်နှင့်မတူညီသော `Path` အကောင်အထည်ဖော်မှုရှိသည့်အခြားစနစ်တစ်ခုတွင်အလုပ်လုပ်နိုင်သည်။ ယခုစာကြည့်တိုက်တွင် "host path" အမျိုးအစားကွဲပြားသည်။
    ///
    /// "the same" ဖိုင်သည် module စနစ် (များသောအားဖြင့် `#[path = "..."]` attribute သို့မဟုတ်အလားတူအသုံးပြုခြင်း) မှလမ်းကြောင်းများစွာမှတစ်ဆင့်ရောက်ရှိနိုင်သည့်အခါအံ့သြဖွယ်ကောင်းသောအပြုအမူသည်ဤ function မှကွဲပြားခြားနားသောတန်ဖိုးများကိုတူညီသောကုဒ်တစ်ခုပေါ်လာစေနိုင်သည်။
    ///
    ///
    /// # Cross-compilation
    ///
    /// ဤသည်မှာတန်ဖိုးကိုအိမ်ရှင်ပလက်ဖောင်းနှင့်ပစ်မှတ်ပလက်ဖောင်းကွာခြားသည့်အခါ `Path::new` သို့မဟုတ်အလားတူတည်ဆောက်မှဖြတ်သန်းဘို့အသင့်လျော်ဘူး။
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// panic မှဆင်းသက်လာသောလိုင်းနံပါတ်ကိုပြန်ပို့သည်။
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// panic ၏မူလကော်လံကို return ပြန်ပေးသည်။
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// libstd မှ libstd မှဒေတာများကို `panic_unwind` နှင့်အခြား panic runtime များသို့ပို့ရန်အသုံးပြုသောအတွင်းပိုင်း trait
/// မကြာမီမည်သည့်အချိန်တည်ငြိမ်ခံရဖို့ရည်ရွယ်ဘဲ, မသုံးကြဘူး။
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// contents တွေကိုအပြည့်အဝပိုင်ဆိုင်မှုယူပါ။
    /// return type ဆိုတာတကယ်တော့ `Box<dyn Any + Send>` ဖြစ်တယ်။ ဒါပေမယ့် libcore မှာ `Box` ကိုသုံးလို့မရဘူး။
    ///
    /// ဒီနည်းလမ်းကိုခေါ်ပြီးတဲ့နောက်မှာတော့ `self` မှာသာမန်အတုတန်ဖိုးအနည်းငယ်ကျန်ပါသေးတယ်။
    /// ဤနည်းလမ်းကိုနှစ်ကြိမ်ခေါ်ခြင်းသို့မဟုတ်ဤနည်းလမ်းကိုခေါ်ဆိုပြီးနောက် `get` ကိုခေါ်ခြင်းသည်မှားသည်။
    ///
    /// အဘယ်ကြောင့်ဆိုသော် panic runtime (`__rust_start_panic`) သည် `dyn BoxMeUp` ကိုသာငှားရမ်းသောကြောင့်ဖြစ်သည်။
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// အကြောင်းအရာတွေကိုပဲချေးပါ။
    fn get(&mut self) -> &(dyn Any + Send);
}