//! '' လုံးလုံးလြားလြားကူးယူ '' မရနိုငျသောအမျိုးအစားများကိုများအတွက် `Clone` trait ။
//!
//! Rust မှာတော့တချို့ရိုးရှင်းတဲ့အမျိုးအစားများ "implicitly copyable" ဖြစ်ကြပြီးသူတို့ကိုသင် assign သို့မဟုတ်အငြင်းပွားမှုများအဖြစ်ကသူတို့ကိုလွန်သွားသောအခါ, လက်ခံရာဌာန၌မူလတန်ဖိုးကိုထွက်ခွာ, တစ်ဦးမိတ္တူရပါလိမ့်မယ်။
//! ဤအမျိုးအစားများသည်ကူးယူရန်ခွဲဝေရန်မလိုအပ်ပါ။ အပြီးသတ်အကဲဖြတ်သူများမရှိပါ (ဆိုလိုသည်မှာ၎င်းတို့တွင်ပိုင်ဆိုင်သောသေတ္တာများသို့မဟုတ် [`Drop`] ကိုအကောင်အထည်ဖော်ခြင်းမရှိပါ)၊ ထို့ကြောင့် compiler က၎င်းတို့အားစျေးပေါ။ ကူးယူရန်လုံခြုံသည်ဟုမှတ်ယူသည်။
//!
//! အခြားအမျိုးအစားများအတွက်မူ [`Clone`] trait ကိုအကောင်အထည်ဖော်ပြီး [`clone`] method ကိုခေါ်ဆိုခြင်းအားဖြင့်မိတ္တူများကိုရှင်းလင်းစွာပြုလုပ်ရမည်။
//!
//! [`clone`]: Clone::clone
//!
//! အခြေခံအသုံးပြုမှုဥပမာ-
//!
//! ```
//! let s = String::new(); // string type ကိုသုံးကိရိယာ Clone
//! let copy = s.clone(); // ဒါကြောင့်ကျနော်တို့က clone နိုင်ပါတယ်
//! ```
//!
//! အလွယ်တကူ Clone trait အကောင်အထည်ဖော်ပေးရန်, သငျသညျမြားကိုလညျး `#[derive(Clone)]` ကိုသုံးနိုင်သည်။ဥပမာ-
//!
//! ```
//! #[derive(Clone)] // ကျနော်တို့ Morpheus struct ဖို့ Clone trait add
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // ယခုငါတို့က Clone နိုင်ပါတယ်!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// အတိအလင်း object တစ်ခုပွားနိုင်စွမ်းများအတွက်တစ်ဦးကဘုံ trait ။
///
/// [`Copy`] နှင့်မတူသည်မှာ [`Copy`] သည်သွယ်ဝိုက်။ စျေးသိပ်မကြီးသည့်အပြင် `Clone` သည်အမြဲတမ်းရှင်းလင်းပြီးစျေးကြီးမည်သို့မဟုတ်မကျနိုင်သော်လည်း
/// ဤဝိသေသလက္ခဏာများကိုပြenfor္ဌာန်းရန် Rust သည်သင့်အား [`Copy`] ကို ထပ်မံ၍ ထပ်မံ၍ ခွင့်ပြုမည်မဟုတ်သော်လည်းသင်သည် `Clone` ကိုထပ်မံပေါင်းစပ်။ မတရားကုဒ်ကို run နိုင်သည်။
///
/// `Clone` သည်ယေဘူယျအားဖြင့် [`Copy`] ထက်ပိုမိုသောကြောင့် [`Copy`] ကို `Clone` အဖြစ်အလိုအလျောက်ပြုလုပ်နိုင်သည်။
///
/// ## Derivable
///
/// အားလုံးလယ်ကွင်း `Clone` လျှင်ဤသည် trait `#[derive]` နှငျ့အသုံးပွုနိုငျသညျ။[`Clone`] ၏ `derive`d အကောင်အထည်ဖော်မှုသည်လယ်ကွင်းတိုင်းတွင် [`clone`] ကိုခေါ်ဆိုသည်။
///
/// [`clone`]: Clone::clone
///
/// ယေဘုယျ struct တစ်ခုအတွက် `#[derive]` သည်ယေဘူယျသတ်မှတ်ချက်များအပေါ်တွင် `Clone` ကိုပေါင်းထည့်ခြင်းအားဖြင့် `Clone` ကိုအခြေအနေအရအကောင်အထည်ဖော်သည်။
///
/// ```
/// // `derive` သုံးကိရိယာ Clone စာဖတ်ခြင်းများအတွက်<T>T ကကိုယ်ပွားအခါ။
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## `Clone` ကိုမည်သို့အကောင်အထည်ဖော်နိုင်မည်နည်း။
///
/// [`Copy`] အမျိုးအစားများသည် `Clone` ၏အသေးအဖွဲအကောင်အထည်ဖော်မှုရှိသင့်သည်။ပိုများသောတရားဝင်:
/// `T: Copy`, `x: T` နှင့် `y: &T` လျှင်, `let x = y.clone();` `let x = *y;` မှညီမျှသည်။
/// manual Implementation ကိုဒီလျော့ပါးသွားမည်ဖြစ်သလိုထောက်ဖို့သတိထားရပါမည်;သို့သော်အန္တရာယ်မကင်းကုဒ်မှတ်ဉာဏ်ဘေးကင်းလုံခြုံရေးသေချာစေရန်ပေါ်မှာအားမကိုးရပါမည်။
///
/// ဥပမာတစ်ခုသည် function pointer ကိုကိုင်ထားသည့်ယေဘူယျတည်ဆောက်ပုံဖြစ်သည်။ဤကိစ္စတွင်ခုနှစ်, `Clone` များ၏အကောင်အထည်ဖော်မှု `derive`d မဖွစျနိုငျ, ဒါပေမယ့်အဖြစ်အကောင်အထည်ဖော်နိုင်ပါတယ်:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## အပိုဆောင်း implementors
///
/// [implementors listed below][impls] အပြင် `Clone` ကိုလည်းအောက်ပါအမျိုးအစားများသည်အကောင်အထည်ဖော်သည်-
///
/// * function ကို item အမျိုးအစားများ (ဆိုလိုသည်မှာတစ်ဦးချင်းစီ function ကိုများအတွက်သတ်မှတ်ထားတဲ့ကွဲပြားအမျိုးအစားများ)
/// * function pointer အမျိုးအစားများ (ဥပမာ, `fn() -> i32`)
/// * အကယ်၍ item type သည် `Clone` (ဥပမာ `[i32; 123456]`) ကိုသုံးပါကအရွယ်အစားအားလုံးအတွက် Array အမျိုးအစားများ။
/// * အကယ်၍ အစိတ်အပိုင်းတစ်ခုစီသည် `Clone` (ဥပမာ-`()`, `(i32, bool)`) ကိုသုံးပါက Tuple အမျိုးအစားများ
/// * ပိတ်သိမ်းအမျိုးအစားများကိုသူတို့ရှိသမျှသည်ထိုကဲ့သို့သောဖမ်းမိတန်ဖိုးများ `Clone` သူတို့ကိုယ်သူတို့အကောင်အထည်ဖော်ရန်ပတ်ဝန်းကျင်ကနေသို့မဟုတ်လျှင်အဘယ်သူမျှမတနျဖိုးကိုဖမ်းယူလျှင်။
///   shared ကိုးကားခြင်းဖြင့်ဖမ်းမိသော variable များသည်အမြဲတမ်း `Clone` ကိုသုံးသည် (ရည်ညွှန်းချက်မပါလျှင်ပင်) သည်၊ mutable ရည်ညွှန်းချက်အရဖမ်းယူနိုင်သော variable များသည် `Clone` ကိုဘယ်သောအခါမျှအကောင်အထည်ဖော်မည်မဟုတ်ပါ
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// တန်ဖိုးမိတ္တူတစ်ခုပေးသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str သုံးကိရိယာ Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Performance copy-တာဝန်ကျရာ `source` မှ။
    ///
    /// `a.clone_from(&b)` လုပ်ဆောင်နိုင်စွမ်းကိုအတွက် `a = b.clone()` ညီမျှဖြစ်တယ်, ဒါပေမဲ့မလိုအပ်တဲ့ခွဲတမ်းရှောင်ရှားရန် `a` ၏အရင်းအမြစ်များကိုပြန်သုံးဖို့အသီးသီးတွင်နိုင်ပါသည်။
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// trait `Clone` ၏အကျိုးသက်ရောက်မှုကိုထုတ်လုပ်သည့် macro ကိုရယူပါ။
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): ဤဖွဲ့စည်းပုံကို#[derive] တစ်ခုတည်းကသာအသုံးပြုပြီးအမျိုးအစားတစ်ခုစီ၏အစိတ်အပိုင်းအားလုံးသည် Clone သို့မဟုတ် Copy ကိုသုံးသည်ဟုဖော်ပြရန်ဖြစ်သည်။
//
//
// ဤရွေ့ကား structs အသုံးပြုသူကုဒ်ထဲမှာပေါ်လာဘယ်တော့မှသငျ့သညျ။
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// စရိုက်အမျိုးအစားများများအတွက် `Clone` အကောင်အထည်ဖော်ရေး။
///
/// Rust တွင်ဖော်ပြထားခြင်းမရှိသောလုပ်ဆောင်ချက်များသည် `rustc_trait_selection` ရှိ `traits::SelectionContext::copy_clone_conditions()` တွင်အကောင်အထည်ဖော်သည်။
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// မျှဝေထားသောကိုးကားချက်များကိုပုံတူပွားနိုင်သည်။
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// မျှဝေထားသောကိုးကားချက်များကိုပုံတူပွားနိုင်သည်။
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}