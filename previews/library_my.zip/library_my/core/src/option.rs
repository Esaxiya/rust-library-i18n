//! optional ကိုတန်ဖိုးများ။
//!
//! [`Option`] အမျိုးအစားသည်ရွေးချယ်နိုင်သောတန်ဖိုးကိုကိုယ်စားပြုသည်။ [`Option`] တိုင်းသည် [`Some`] ဖြစ်စေ၊ တန်ဖိုးတစ်ခုသို့မဟုတ် [`None`] ပါ ၀ င်သည်။
//! [`Option`] အမျိုးအစားများသည် Rust ကုဒ်တွင်အလွန်အသုံးများသည်၊
//!
//! * ကန ဦး တန်ဖိုးများ
//! * ၄ င်းတို့၏ input range တစ်ခုလုံးထက်ပိုပြီးမသတ်မှတ်ထားသော function များအတွက် return value (တစ်စိတ်တစ်ပိုင်း functions)
//! * ရိုးရှင်းသည့်အမှားအယွင်းများကိုအစီရင်ခံရန်မဟုတ်ပါက [`None`] သည်အမှားပေါ်သို့ပြန်ရောက်သည်
//! * optional struct လယ်ကွင်း
//! * ငှားရမ်းနိုင်သည့် Struct fields သို့မဟုတ် "taken"
//! * optional function ကိုအငြင်းပွားမှုများ
//! * Nullable ထောက်ပြ
//! * ခက်ခဲသောအခြေအနေများမှအရာများကိုလဲလှယ်ခြင်း
//!
//! [`Option`] s များသည်ပုံမှန်အားဖြင့်ပုံစံ၏ကိုက်ညီမှုနှင့်တွဲဖက်ပြီးတန်ဖိုးတစ်ခု၏တည်ရှိမှုကိုမေးမြန်းရန်နှင့်အရေးယူရန်ဖြစ်သည်။
//!
//!
//! ```
//! fn divide(numerator: f64, denominator: f64) -> Option<f64> {
//!     if denominator == 0.0 {
//!         None
//!     } else {
//!         Some(numerator / denominator)
//!     }
//! }
//!
//! // function ရဲ့ return value က option တစ်ခုဖြစ်တယ်
//! let result = divide(2.0, 3.0);
//!
//! // တန်ဖိုးကိုပြန်လည်ရယူရန်ပုံစံကိုက်ညီခြင်း
//! match result {
//!     // အဆိုပါဌာနခွဲတရားဝင်ဖြစ်ခဲ့သည်
//!     Some(x) => println!("Result: {}", x),
//!     // အဆိုပါဌာနခွဲမမှန်ကန်ခဲ့သည်
//!     None    => println!("Cannot divide by 0"),
//! }
//! ```
//!
//!
//!
//!
//!
// FIXME: `Option` ကိုနည်းလမ်းများစွာဖြင့်လက်တွေ့တွင်မည်သို့အသုံးပြုသည်ကိုပြပါ
//
//! # Options နှင့် pointers ("nullable" pointers)
//!
//! Rust ၏ pointer အမျိုးအစားများသည်မှန်ကန်သောတည်နေရာကိုအမြဲညွှန်ပြရမည်။အဘယ်သူမျှမ "null" ကိုးကားရှိပါတယ်။အဲဒီအစား Rust မှာ optional ပိုင်ဆိုင်တဲ့ box လိုမျိုး optional * pointers တွေရှိတယ်။ ``Option`] `<` [`Box<T>`]`>`။
//!
//! အောက်ဖော်ပြပါဥပမာသည် [`Option`] ကို အသုံးပြု၍ [`i32`] optional box တစ်ခုကိုဖန်တီးသည်။
//! အတွင်းပိုင်း [`i32`] တန်ဖိုးကို ဦး စွာအသုံးပြုရန်အတွက်၊ `check_optional` function သည်သေတ္တာတန်ဖိုးရှိမရှိဆုံးဖြတ်ရန်ပုံစံကိုက်ညီမှုကိုသုံးရန်လိုအပ်သည်ကိုသတိပြုပါ (ဆိုလိုသည်မှာ၎င်းသည် [`Some(...)`][`Some`]) သို့မဟုတ် ([`None`]) မဟုတ်) ။
//!
//!
//! ```
//! let optional = None;
//! check_optional(optional);
//!
//! let optional = Some(Box::new(9000));
//! check_optional(optional);
//!
//! fn check_optional(optional: Option<Box<i32>>) {
//!     match optional {
//!         Some(p) => println!("has value {}", p),
//!         None => println!("has no value"),
//!     }
//! }
//! ```
//!
//! # Representation
//!
//! Rust သည်အောက်ပါ `T` အမျိုးအစားများကိုအကောင်းဆုံးဖြစ်စေရန်အာမခံသည်။ [`Option<T>`] သည်အရွယ်အစား `T` နှင့်တူသည်။
//!
//! * [`Box<U>`]
//! * `&U`
//! * `&mut U`
//! * `fn`, `extern "C" fn`
//! * [`num::NonZero*`]
//! * [`ptr::NonNull<U>`]
//! * `#[repr(transparent)]` ဤစာရင်းထဲတွင်အမျိုးအစားများများထဲမှန်းကျင် struct ။
//!
//! အထက်ပါကိစ္စရပ်များအတွက် `T` ၏ခိုင်လုံသောတန်ဖိုးများမှ `Option<T>` နှင့် `Some::<T>(_)` မှ `T` သို့ (`None::<T>` မှ `T` သို့ကူးပြောင်းခြင်းသည်မသေချာသည့်အပြုအမူ) မှတစ်ခုဖြစ်သည်ကိုထပ်မံအာမခံနိုင်သည်။
//!
//! # Examples
//!
//! [`Option`] ၏အခြေခံပုံစံကိုက်ညီမှု-
//!
//! ```
//! let msg = Some("howdy");
//!
//! // ပါရှိသော string ကိုတစ် ဦး ကိုကိုးကားယူပါ
//! if let Some(m) = &msg {
//!     println!("{}", *m);
//! }
//!
//! // ပါရှိသော string ကိုဖယ်ရှားခြင်း, Option ကိုဖျက်ဆီး
//! let unwrapped_msg = msg.unwrap_or("default message");
//! ```
//!
//! ရလဒ်တစ်ခုကို loop တစ်ခုမတိုင်မီ [`None`] သို့စတင်ပါ။
//!
//! ```
//! enum Kingdom { Plant(u32, &'static str), Animal(u32, &'static str) }
//!
//! // တဆင့်ရှာဖွေအချက်အလက်များ၏စာရင်းတစ်ခု။
//! let all_the_big_things = [
//!     Kingdom::Plant(250, "redwood"),
//!     Kingdom::Plant(230, "noble fir"),
//!     Kingdom::Plant(229, "sugar pine"),
//!     Kingdom::Animal(25, "blue whale"),
//!     Kingdom::Animal(19, "fin whale"),
//!     Kingdom::Animal(15, "north pacific right whale"),
//! ];
//!
//! // ကျွန်တော်တို့ဟာအကြီးဆုံးတိရစ္ဆာန်ရဲ့နာမည်ကိုရှာမယ်၊ ဒါပေမယ့် `None` ကိုပဲရပြီ။
//! //
//! let mut name_of_biggest_animal = None;
//! let mut size_of_biggest_animal = 0;
//! for big_thing in &all_the_big_things {
//!     match *big_thing {
//!         Kingdom::Animal(size, name) if size > size_of_biggest_animal => {
//!             // ယခုငါတို့ကြီးမားသောတိရိစ္ဆာန်၏အမည်ကိုတွေ့ပြီ
//!             size_of_biggest_animal = size;
//!             name_of_biggest_animal = Some(name);
//!         }
//!         Kingdom::Animal(..) | Kingdom::Plant(..) => ()
//!     }
//! }
//!
//! match name_of_biggest_animal {
//!     Some(name) => println!("the biggest animal is {}", name),
//!     None => println!("there are no animals :("),
//! }
//! ```
//!
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Box<U>`]: ../../std/boxed/struct.Box.html
//! [`num::NonZero*`]: crate::num
//! [`ptr::NonNull<U>`]: crate::ptr::NonNull
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{FromIterator, FusedIterator, TrustedLen};
use crate::pin::Pin;
use crate::{
    fmt, hint, mem,
    ops::{self, Deref, DerefMut},
};

/// `Option` အမျိုးအစား။ပိုမိုသိရှိရန် [the module level documentation](self) ကိုကြည့်ပါ။
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[rustc_diagnostic_item = "option_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Option<T> {
    /// တန်ဖိုးမရှိပါ
    #[lang = "None"]
    #[stable(feature = "rust1", since = "1.0.0")]
    None,
    /// အချို့တန်ဖိုး `T`
    #[lang = "Some"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Some(#[stable(feature = "rust1", since = "1.0.0")] T),
}

/////////////////////////////////////////////////////////////////////////////
// အကောင်အထည်ဖော်မှုကိုရိုက်ပါ
/////////////////////////////////////////////////////////////////////////////

impl<T> Option<T> {
    /////////////////////////////////////////////////////////////////////////
    // ပါရှိသောတန်ဖိုးများကိုမေးမြန်းခြင်း
    /////////////////////////////////////////////////////////////////////////

    /// option ကိုတစ် ဦး [`Some`] တန်ဖိုးကိုလျှင် `true` ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_some(), true);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_some(), false);
    /// ```
    #[must_use = "if you intended to assert that this has a value, consider `.unwrap()` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_some(&self) -> bool {
        matches!(*self, Some(_))
    }

    /// option ကိုတစ် ဦး [`None`] တန်ဖိုးကိုလျှင် `true` ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_none(), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_none(), true);
    /// ```
    #[must_use = "if you intended to assert that this doesn't have a value, consider \
                  `.and_then(|| panic!(\"`Option` had a value when expected `None`\"))` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_none(&self) -> bool {
        !self.is_some()
    }

    /// အကယ်၍ option သည်ပေးထားသောတန်ဖိုးပါဝင်သော [`Some`] တန်ဖိုးဖြစ်ပါက `true` ကိုပြန်ပို့သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Option<u32> = Some(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Some(y) => x == y,
            None => false,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // ကိုးကားချက်များနှင့်အလုပ်လုပ်ဘို့ adapter
    /////////////////////////////////////////////////////////////////////////

    /// `&Option<T>` မှ `Option<&T>` သို့ပြောင်းသည်။
    ///
    /// # Examples
    ///
    /// `Option <` [`String`]`>`` Option တစ်ခုကို `Option <` [`usize`]`>`သို့ေူပာင်းလဲ။ မူရင်းကိုထိန်းသိမ်းသည်။
    /// [`map`] method သည် `self` argument ကိုမူရင်းကိုစားသုံးခြင်းအားဖြင့်တန်ဖိုးအားဖြင့်ရယူသည်။ ထို့ကြောင့်ဒီနည်းပညာသည် `Option` ကိုပထမဆုံး `Option` ကိုမူလအတွင်းရှိတန်ဖိုးကိုရည်ညွှန်းရန်ယူသည်။
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let text: Option<String> = Some("Hello, world!".to_string());
    /// // ပထမ ဦး စွာ `Option<String>` ကို `as_ref` ဖြင့် `Option<&String>` သို့ချပစ်ပါ။ ထို့နောက် *ကြောင်း*`map` ဖြင့်စားသုံးပါ၊ `text` ကို stack တွင်ထားပါ။
    /////
    /// let text_length: Option<usize> = text.as_ref().map(|s| s.len());
    /// println!("still can print text: {:?}", text);
    /// ```
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Option<&T> {
        match *self {
            Some(ref x) => Some(x),
            None => None,
        }
    }

    /// `&mut Option<T>` မှ `Option<&mut T>` သို့ပြောင်းသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// match x.as_mut() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Option<&mut T> {
        match *self {
            Some(ref mut x) => Some(x),
            None => None,
        }
    }

    /// [`Pin`]`<&Option မှပြောင်းသည်<T>>`` ```` Option <`[` Pin`]`<&T>>` ။
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_ref(self: Pin<&Self>) -> Option<Pin<&T>> {
        // လုံခြုံမှု: `x` သည် `self` မှလာသောကြောင့်ခိုင်ခံ့မှုရှိရန်အာမခံသည်
        // သောအရင်ကမရှိသေးတဲ့ဖြစ်ပါတယ်။
        unsafe { Pin::get_ref(self).as_ref().map(|x| Pin::new_unchecked(x)) }
    }

    /// [`Pin`]`<&mut Option မှပြောင်းသည်<T>>`` ```` `Option <` [`Pin`]`<&mut T>>`။
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_mut(self: Pin<&mut Self>) -> Option<Pin<&mut T>> {
        // လုံခြုံမှု: `get_unchecked_mut` သည် X0 `self` အတွင်းရှိ `Option` ကိုမည်သည့်အခါမျှမရွှေ့ပါ။
        // `x` ၎င်းသည်အရင်ကမရှိသေးသော `self` မှလာသည်။
        unsafe { Pin::get_unchecked_mut(self).as_mut().map(|x| Pin::new_unchecked(x)) }
    }

    /////////////////////////////////////////////////////////////////////////
    // ပါရှိသောတန်ဖိုးများကိုရယူခြင်း
    /////////////////////////////////////////////////////////////////////////

    /// ပါ ၀ င်သည့် [`Some`] တန်ဖိုးကို `self` တန်ဖိုးကိုလောင်ကျွမ်းစေသည်။
    ///
    /// # Panics
    ///
    /// Panics သည်တန်ဖိုး `msg` မှပေးသောထုံးစံ panic မက်ဆေ့ခ်ျပါသော [`None`] ဖြစ်ပါက။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("value");
    /// assert_eq!(x.expect("fruits are healthy"), "value");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// x.expect("fruits are healthy"); // panics with `fruits are healthy`
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Some(val) => val,
            None => expect_failed(msg),
        }
    }

    /// ပါ ၀ င်သည့် [`Some`] တန်ဖိုးကို `self` တန်ဖိုးကိုလောင်ကျွမ်းစေသည်။
    ///
    /// ဒီ function ကို panic ၎င်း၏အသုံးပြုမှုကိုယေဘုယျအားဖြင့်စိတ်ပျက်အားလျော့နေသည်ဖြစ်နိုင်သည်ကြောင့်ဖြစ်သည်။
    /// အဲဒီအစား [`None`] ကိစ္စကိုပုံစံကိုက်ညီပြီးရှင်းလင်းစွာကိုင်တွယ်လိုပါက [`unwrap_or`], [`unwrap_or_else`] သို့မဟုတ် [`unwrap_or_default`] ကိုခေါ်ပါ။
    ///
    ///
    /// [`unwrap_or`]: Option::unwrap_or
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    /// [`unwrap_or_default`]: Option::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics သည်ကိုယ်ပိုင်တန်ဖိုး [`None`] နှင့်ညီလျှင်။
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("air");
    /// assert_eq!(x.unwrap(), "air");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// assert_eq!(x.unwrap(), "air"); // fails
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn unwrap(self) -> T {
        match self {
            Some(val) => val,
            None => panic!("called `Option::unwrap()` on a `None` value"),
        }
    }

    /// ပါရှိသော [`Some`] တန်ဖိုးသို့မဟုတ်ပေးထားသောပုံသေကိုပြန်ပို့သည်။
    ///
    /// `unwrap_or` သို့အငြင်းပွားမှုများကိုစိတ်အားထက်သန်စွာအကဲဖြတ်သည်။function call တစ်ခု၏ရလဒ်ကိုသင်ဖြတ်သန်းသွားသည်ဆိုလျှင်၎င်းသည်အလွန်ပျင်းရိစွာအကဲဖြတ်ထားသော [`unwrap_or_else`] ကိုအသုံးပြုရန်အကြံပြုသည်။
    ///
    ///
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(Some("car").unwrap_or("bike"), "car");
    /// assert_eq!(None.unwrap_or("bike"), "bike");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Some(x) => x,
            None => default,
        }
    }

    /// ပါ ၀ င်သည့် [`Some`] value ကို return ပြန်ပေးတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 10;
    /// assert_eq!(Some(4).unwrap_or_else(|| 2 * k), 4);
    /// assert_eq!(None.unwrap_or_else(|| 2 * k), 20);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce() -> T>(self, f: F) -> T {
        match self {
            Some(x) => x,
            None => f(),
        }
    }

    /// ပြန်သည့်တန်ဖိုး [`None`] မဟုတ်ကြောင်းစစ်ဆေးနေမရှိပဲ, `self` တန်ဖိုးကိုစားသုံး, [`Some`] တန်ဖိုးကိုပါရှိသည်။
    ///
    ///
    /// # Safety
    ///
    /// ဤနည်းလမ်းကို [`None`] သို့ခေါ်ဆိုခြင်းသည် *[undefined behavior]* ဖြစ်သည်။
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x = Some("air");
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air");
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Option<&str> = None;
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air"); // undefined အပြုအမူ!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_some());
        match self {
            Some(val) => val,
            // လုံခြုံမှု: လုံခြုံရေးစာချုပ်အဆိုပါခေါ်ဆိုမှုများကထောကျခံခဲ့ရမည်ဖြစ်သည်။
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // ပါရှိသောတန်ဖိုးများကိုပြောင်းလဲ
    /////////////////////////////////////////////////////////////////////////

    /// ပါ ၀ င်သည့်တန်ဖိုးတစ်ခုအတွက် function တစ်ခုကိုအသုံးပြုခြင်းအားဖြင့် `Option<T>` မှ `Option<U>` သို့ Maps လုပ်သည်။
    ///
    /// # Examples
    ///
    /// `Option <` [`String`]`>`` Option တစ်ခုကို `Option <` [`usize`]`>`သို့ေူပာင်းလဲ။ မူရင်းကိုစားသုံးသည်။
    ///
    /// [`String`]: ../../std/string/struct.String.html
    /// ```
    /// let maybe_some_string = Some(String::from("Hello, World!"));
    /// // `Option::map` `maybe_some_string` စားသုံးတန်ဖိုးအားဖြင့် * မိမိကိုယ်ကိုကြာပါသည်
    /// let maybe_some_len = maybe_some_string.map(|s| s.len());
    ///
    /// assert_eq!(maybe_some_len, Some(13));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, f: F) -> Option<U> {
        match self {
            Some(x) => Some(f(x)),
            None => None,
        }
    }

    /// ပါ ၀ င်သည့်တန်ဖိုး (ရှိလျှင်ရှိ) ကို function တစ်ခုကိုအသုံးချသည် (သို့) ပေးထားသော default (ပြန်လျှင်) ကိုပြန်ပေးသည်။
    ///
    /// `map_or` သို့အငြင်းပွားမှုများကိုစိတ်အားထက်သန်စွာအကဲဖြတ်သည်။function call တစ်ခု၏ရလဒ်ကိုသင်ဖြတ်သန်းသွားသည်ဆိုလျှင်၎င်းသည်အလွန်ပျင်းရိစွာအကဲဖြတ်ထားသော [`map_or_else`] ကိုအသုံးပြုရန်အကြံပြုသည်။
    ///
    ///
    /// [`map_or_else`]: Option::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default,
        }
    }

    /// ပါ ၀ င်သည့်တန်ဖိုး (ရှိလျှင်ရှိ) အတွက် function တစ်ခုကိုအသုံးချသည် (သို့) ပုံမှန်မဟုတ်လျှင်တွက်ချက်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x = Some("foo");
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 42);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or_else<U, D: FnOnce() -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default(),
        }
    }

    /// `Option<T>` ကို [`Result<T, E>`] အဖြစ်ပြောင်းသည်။ [`Some(v)`] ကို [`Ok(v)`] သို့ [`None`] သို့ [`Err(err)`] သို့ပုံဆွဲသည်။
    ///
    /// `ok_or` သို့အငြင်းပွားမှုများကိုစိတ်အားထက်သန်စွာအကဲဖြတ်သည်။function call တစ်ခု၏ရလဒ်ကိုသင်ဖြတ်သန်းသွားသည်ဆိုလျှင်၎င်းသည်အလွန်ပျင်းရိစွာအကဲဖြတ်ထားသော [`ok_or_else`] ကိုအသုံးပြုရန်အကြံပြုသည်။
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err)`]: Err
    /// [`Some(v)`]: Some
    /// [`ok_or_else`]: Option::ok_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or(0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or(0), Err(0));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or<E>(self, err: E) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err),
        }
    }

    /// `Option<T>` ကို [`Result<T, E>`] အဖြစ်ပြောင်းသည်။ [`Some(v)`] ကို [`Ok(v)`] သို့ [`None`] သို့ [`Err(err())`] သို့ပြောင်းသည်။
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err())`]: Err
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or_else(|| 0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or_else(|| 0), Err(0));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or_else<E, F: FnOnce() -> E>(self, err: F) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err()),
        }
    }

    /// `value` ကို option ထဲသို့ထည့်ပြီး၎င်းသည် mutable reference တစ်ခုကိုပြန်ပို့သည်။
    ///
    /// အကယ်၍ option တွင်တန်ဖိုးတစ်ခုပါ ၀ င်ပါကတန်ဖိုးဟောင်းကိုကျဆင်းသွားသည်။
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(option_insert)]
    ///
    /// let mut opt = None;
    /// let val = opt.insert(1);
    /// assert_eq!(*val, 1);
    /// assert_eq!(opt.unwrap(), 1);
    /// let val = opt.insert(2);
    /// assert_eq!(*val, 2);
    /// *val = 3;
    /// assert_eq!(opt.unwrap(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "option_insert", reason = "newly added", issue = "78271")]
    pub fn insert(&mut self, value: T) -> &mut T {
        *self = Some(value);

        match self {
            Some(v) => v,
            // လုံခြုံမှု-အပေါ်မှာပြထားတဲ့ code ကဒီ option ကိုဖြည့်ခဲ့တယ်
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // ကြားမှာဆောက်လုပ်ရေး
    /////////////////////////////////////////////////////////////////////////

    /// ဖြစ်နိုင်သည်ပါရှိသောတန်ဖိုးကိုကျော်ကြားမှာပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(4);
    /// assert_eq!(x.iter().next(), Some(&4));
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn iter(&self) -> Iter<'_, T> {
        Iter { inner: Item { opt: self.as_ref() } }
    }

    /// ဖြစ်နိုင်သည့်ပါ ၀ င်သောတန်ဖိုးအပေါ် mutable ကြားဖြတ်တစ်ခုကိုပြန်ပို့သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(4);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    ///
    /// let mut x: Option<u32> = None;
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: Item { opt: self.as_mut() } }
    }

    /////////////////////////////////////////////////////////////////////////
    // တန်ဖိုးများအပေါ် Boolean စစ်ဆင်ရေး, စိတ်အားထက်သန်ခြင်းနှင့်ပျင်းရိ
    /////////////////////////////////////////////////////////////////////////

    /// အကယ်၍ option သည် [`None`] ဖြစ်ပါက [`None`] ကိုပြန်ပို့ပေးလျှင်၊
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), None);
    ///
    /// let x = Some(2);
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), Some("foo"));
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, optb: Option<U>) -> Option<U> {
        match self {
            Some(_) => optb,
            None => None,
        }
    }

    /// အကယ်၍ option သည် [`None`] ဖြစ်ပါက [`None`] ကိုပြန်ပို့သည်။ မဟုတ်ပါက `f` ကိုထုပ်ထားသောတန်ဖိုးနှင့်ခေါ်။ ရလဒ်ကိုပြန်ပို့သည်။
    ///
    ///
    /// တချို့ကဘာသာစကားများဒီစစ်ဆင်ရေး flatmap ခေါ်ဆိုပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// fn sq(x: u32) -> Option<u32> { Some(x * x) }
    /// fn nope(_: u32) -> Option<u32> { None }
    ///
    /// assert_eq!(Some(2).and_then(sq).and_then(sq), Some(16));
    /// assert_eq!(Some(2).and_then(sq).and_then(nope), None);
    /// assert_eq!(Some(2).and_then(nope).and_then(sq), None);
    /// assert_eq!(None.and_then(sq).and_then(sq), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Option<U>>(self, f: F) -> Option<U> {
        match self {
            Some(x) => f(x),
            None => None,
        }
    }

    /// အကယ်၍ option သည် [`None`] ဖြစ်ပါက [`None`] ကိုပြန်ပို့ပေးသည်၊ မဟုတ်ပါက `predicate` ကိုထုပ်ထားသောတန်ဖိုးနှင့်ခေါ်။ ပြန်ပို့သည်-
    ///
    ///
    /// - [`Some(t)`] `predicate` (`t` ဟာပတ်ရစ်တန်ဖိုးကိုသည်အဘယ်မှာရှိ) `true` ပြန်လာလျှင်, နှင့်
    /// - [`None`] `predicate` `false` ပြန်ရောက်လျှင်။
    ///
    /// ဤလုပ်ဆောင်ချက်သည် [`Iterator::filter()`] နှင့်ဆင်တူသည်။
    /// `Option<T>` သည်တစ်ခုသို့မဟုတ်သုညဒြပ်ပေါင်းများကြားတွင်ကြားဖြတ်တစ်ခုအဖြစ်သင်မြင်ယောင်ကြည့်နိုင်သည်။
    /// `filter()` သငျသညျကိုစောင့်ရှောက်ရန်ဖြစ်သောဒြပ်စင်ဆုံးဖြတ်ပေးနိုင်ပါတယ်။
    ///
    /// # Examples
    ///
    /// ```rust
    /// fn is_even(n: &i32) -> bool {
    ///     n % 2 == 0
    /// }
    ///
    /// assert_eq!(None.filter(is_even), None);
    /// assert_eq!(Some(3).filter(is_even), None);
    /// assert_eq!(Some(4).filter(is_even), Some(4));
    /// ```
    ///
    /// [`Some(t)`]: Some
    ///
    #[inline]
    #[stable(feature = "option_filter", since = "1.27.0")]
    pub fn filter<P: FnOnce(&T) -> bool>(self, predicate: P) -> Self {
        if let Some(x) = self {
            if predicate(&x) {
                return Some(x);
            }
        }
        None
    }

    /// တန်ဖိုးပါ ၀ င်လျှင် option ကို return ပြန်သည်။ မဟုတ်ရင် `optb` ကို return ပြန်ပေးသည်။
    ///
    /// `or` သို့အငြင်းပွားမှုများကိုစိတ်အားထက်သန်စွာအကဲဖြတ်သည်။function call တစ်ခု၏ရလဒ်ကိုသင်ဖြတ်သန်းသွားသည်ဆိုလျှင်၎င်းသည်အလွန်ပျင်းရိစွာအကဲဖြတ်ထားသော [`or_else`] ကိုအသုံးပြုရန်အကြံပြုသည်။
    ///
    ///
    /// [`or_else`]: Option::or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y = None;
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x = None;
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(100));
    ///
    /// let x = Some(2);
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = None;
    /// assert_eq!(x.or(y), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or(self, optb: Option<T>) -> Option<T> {
        match self {
            Some(_) => self,
            None => optb,
        }
    }

    /// တန်ဖိုးပါ ၀ င်လျှင် option ကို return ပြန်သည်။ မဟုတ်ရင် `f` ကိုခေါ်။ ရလဒ်ကို return ပြန်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn nobody() -> Option<&'static str> { None }
    /// fn vikings() -> Option<&'static str> { Some("vikings") }
    ///
    /// assert_eq!(Some("barbarians").or_else(vikings), Some("barbarians"));
    /// assert_eq!(None.or_else(vikings), Some("vikings"));
    /// assert_eq!(None.or_else(nobody), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F: FnOnce() -> Option<T>>(self, f: F) -> Option<T> {
        match self {
            Some(_) => self,
            None => f(),
        }
    }

    /// မဟုတ်ရင် [`None`] ပြန်လည်ရောက်ရှိပြန် [`Some`] `self` ၏အတိအကျတဦးတည်းသည်မှန်လျှင်, `optb` [`Some`] ဖြစ်ပါတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x = Some(2);
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), None);
    /// ```
    #[inline]
    #[stable(feature = "option_xor", since = "1.37.0")]
    pub fn xor(self, optb: Option<T>) -> Option<T> {
        match (self, optb) {
            (Some(a), None) => Some(a),
            (None, Some(b)) => Some(b),
            _ => None,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // None ရှိပါကထည့်သွင်းပြီးရည်ညွှန်းကိုပြန်ပေးရန် Entry ကဲ့သို့သောစစ်ဆင်ရေးများ
    /////////////////////////////////////////////////////////////////////////

    /// `value` ဆိုပါက `value` ကို option ထဲသို့ထည့်ပါ၊ ထို့နောက်ပါ ၀ င်သောတန်ဖိုးကိုပြောင်းလဲနိုင်သောရည်ညွှန်းချက်ကိုပြန်ပို့ပါမည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert(5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert(&mut self, value: T) -> &mut T {
        self.get_or_insert_with(|| value)
    }

    /// ၎င်းသည် [`None`] ဖြစ်ပါက default value ကို option ထဲသို့ထည့်ပြီးနောက်ပါ ၀ င်သော value သို့ mutable reference ကို return လုပ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_get_or_insert_default)]
    ///
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_default();
    ///     assert_eq!(y, &0);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[unstable(feature = "option_get_or_insert_default", issue = "82901")]
    pub fn get_or_insert_default(&mut self) -> &mut T
    where
        T: Default,
    {
        self.get_or_insert_with(Default::default)
    }

    /// `f` ဖြစ်ပါက `f` မှတွက်ချက်ထားသောတန်ဖိုးကို [`None`] ဖြစ်ပါကပါ ၀ င်သောတန်ဖိုးသို့ပြောင်းနိုင်သောအညွှန်းကိုပြန်ပို့သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_with(|| 5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert_with<F: FnOnce() -> T>(&mut self, f: F) -> &mut T {
        if let None = *self {
            *self = Some(f());
        }

        match self {
            Some(v) => v,
            // လုံခြုံမှု-`self` အတွက် `None` မူကွဲကို `Some` ဖြင့်အစားထိုးလိမ့်မည်
            // အထက်ကုဒ်အတွက်မူကွဲ။
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Misc
    /////////////////////////////////////////////////////////////////////////

    /// တန်ဖိုးကို option ထဲကနေယူပြီး [`None`] နေရာမှာထားလိုက်ပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, Some(2));
    ///
    /// let mut x: Option<u32> = None;
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self)
    }

    /// Option အတွင်းရှိအမှန်တကယ်တန်ဖိုးကို parameter ထဲမှာပေးထားတဲ့ value အားဖြင့်အစားထိုးလိုက်တယ်။ အကယ်၍ ရှိခဲ့ရင်၊ တန်ဖိုးဟောင်းကိုပြန်ယူပြီး [`Some`] ကိုသူ့နေရာမှာ deinitializing မလုပ်ပဲထားလိုက်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let old = x.replace(5);
    /// assert_eq!(x, Some(5));
    /// assert_eq!(old, Some(2));
    ///
    /// let mut x = None;
    /// let old = x.replace(3);
    /// assert_eq!(x, Some(3));
    /// assert_eq!(old, None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "option_replace", since = "1.31.0")]
    pub fn replace(&mut self, value: T) -> Option<T> {
        mem::replace(self, Some(value))
    }

    /// အခြား `Option` နှင့်အတူ Zips `self`
    ///
    /// အကယ်၍ `self` `Some(s)` နှင့် `other` `Some(o)` ဖြစ်ပါကဤနည်းလမ်းသည် `Some((s, o))` ကိုပြန်ပို့သည်။
    /// ဒီလိုမှမဟုတ်ရင်, `None` ပြန်ရောက်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(1);
    /// let y = Some("hi");
    /// let z = None::<u8>;
    ///
    /// assert_eq!(x.zip(y), Some((1, "hi")));
    /// assert_eq!(x.zip(z), None);
    /// ```
    #[stable(feature = "option_zip_option", since = "1.46.0")]
    pub fn zip<U>(self, other: Option<U>) -> Option<(T, U)> {
        match (self, other) {
            (Some(a), Some(b)) => Some((a, b)),
            _ => None,
        }
    }

    /// Z00 `self` နှင့် function `f` ပါသောအခြား `Option` ။
    ///
    /// အကယ်၍ `self` `Some(s)` နှင့် `other` `Some(o)` ဖြစ်ပါကဤနည်းလမ်းသည် `Some(f(s, o))` ကိုပြန်ပို့သည်။
    /// ဒီလိုမှမဟုတ်ရင်, `None` ပြန်ရောက်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_zip)]
    ///
    /// #[derive(Debug, PartialEq)]
    /// struct Point {
    ///     x: f64,
    ///     y: f64,
    /// }
    ///
    /// impl Point {
    ///     fn new(x: f64, y: f64) -> Self {
    ///         Self { x, y }
    ///     }
    /// }
    ///
    /// let x = Some(17.5);
    /// let y = Some(42.7);
    ///
    /// assert_eq!(x.zip_with(y, Point::new), Some(Point { x: 17.5, y: 42.7 }));
    /// assert_eq!(x.zip_with(None, Point::new), None);
    /// ```
    #[unstable(feature = "option_zip", issue = "70086")]
    pub fn zip_with<U, F, R>(self, other: Option<U>, f: F) -> Option<R>
    where
        F: FnOnce(T, U) -> R,
    {
        Some(f(self?, other?))
    }
}

impl<T: Copy> Option<&T> {
    /// ရွေးစရာပါအကြောင်းအရာများကိုကူးယူခြင်းအားဖြင့် `Option<&T>` တစ်ခုကို `Option<T>` တစ်ခုသို့ပုံဖော်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&t| t)
    }
}

impl<T: Copy> Option<&mut T> {
    /// ရွေးစရာပါအကြောင်းအရာများကိုကူးယူခြင်းအားဖြင့် `Option<&mut T>` တစ်ခုကို `Option<T>` တစ်ခုသို့ပုံဖော်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone> Option<&T> {
    /// ထို option ရှိအကြောင်းအရာများကိုပုံတူပွားခြင်းဖြင့် `Option<&T>` တစ်ခုအား `Option<T>` တစ်ခုသို့မြေပုံထုတ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone> Option<&mut T> {
    /// ထို option ရှိအကြောင်းအရာများကိုပုံတူပွားခြင်းဖြင့် `Option<&mut T>` တစ်ခုအား `Option<T>` တစ်ခုသို့မြေပုံထုတ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(since = "1.26.0", feature = "option_ref_mut_cloned")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: fmt::Debug> Option<T> {
    /// [`None`] ကိုမျှော်လင့်ပြီးဘာမျှပြန်မပေးဘဲ `self` ကိုစားသည်။
    ///
    /// # Panics
    ///
    /// Panics သည်တန်ဖိုးတစ်ခု [`Some`] ဖြစ်ပါက၊ လွန်ခဲ့သောမက်ဆေ့ခ်ျနှင့် 0X ၏ပါဝင်သည့် Z0panic မက်ဆေ့ခ်ျပါရှိပါက Panics သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // သော့အားလုံးသည်ထူးခြားသောကြောင့်ဤသည် panic မဟုတ်ပါ။
    ///     squares.insert(i, i * i).expect_none("duplicate key");
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).expect_none("duplicate key");
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_expect_none", reason = "newly added", issue = "62633")]
    pub fn expect_none(self, msg: &str) {
        if let Some(val) = self {
            expect_none_failed(msg, &val);
        }
    }

    /// [`None`] ကိုမျှော်လင့်ပြီးဘာမျှပြန်မပေးဘဲ `self` ကိုစားသည်။
    ///
    /// # Panics
    ///
    /// Panics တန်ဖိုးသည် [`Some`] ဖြစ်ပါက၊ ```` `` တန်ဖိုးမှထောက်ပံ့ပေးသော panic သတင်းစကားနှင့်အတူ။
    ///
    ///
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // သော့အားလုံးသည်ထူးခြားသောကြောင့်ဤသည် panic မဟုတ်ပါ။
    ///     squares.insert(i, i * i).unwrap_none();
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).unwrap_none();
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_unwrap_none", reason = "newly added", issue = "62633")]
    pub fn unwrap_none(self) {
        if let Some(val) = self {
            expect_none_failed("called `Option::unwrap_none()` on a `Some` value", &val);
        }
    }
}

impl<T: Default> Option<T> {
    /// ပါရှိသော [`Some`] တန်ဖိုးကိုသို့မဟုတ်ပုံမှန်အတိုင်းပြန်သွားသည်
    ///
    /// X0 `self` အငြင်းအခုံကိုစားသည်။ အကယ်၍ [`Some`] သည်ပါ ၀ င်သောတန်ဖိုးကိုပြန်ပို့သည်၊ သို့မဟုတ်ပါက [`None`] လျှင်ထိုအမျိုးအစားအတွက် [default value] ကိုပြန်ပေးသည်။
    ///
    ///
    /// # Examples
    ///
    /// 0 (ကိန်းများအတွက် default value ကို) သို့ညံ့ဖျင်း-ဖွဲ့စည်းခဲ့ညှို့လှည့်တစ်ဦး integer ဖြစ်တဲ့အတွက်တစ်ဦး string ကိုပြောင်းပေးပါတယ်။
    /// [`parse`] အမှားပေါ် [`None`] ပြန်လာ, [`FromStr`] အကောင်အထည်ဖော်သောအခြားမည်သည့်အမျိုးအစားတစ်ခု string ကိုပြောင်းလဲ။
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().ok().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().ok().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [default value]: Default::default
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Some(x) => x,
            None => Default::default(),
        }
    }
}

impl<T: Deref> Option<T> {
    /// `Option<T>` (သို့မဟုတ် `&Option<T>`) မှ `Option<&T::Target>` သို့ပြောင်းသည်။
    ///
    /// မူရင်း Option ကိုမူလနေရာမှချန်ထားပါ၊ အသစ်တစ်ခုကိုဖန်တီးခြင်း၊ မူလအားရည်ညွှန်းသည်။ ထို့အပြင် [`Deref`] မှတစ်ဆင့်ပါဝင်သည့်အရာများကိုထပ်မံဖိအားပေးသည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref(), Some("hey"));
    ///
    /// let x: Option<String> = None;
    /// assert_eq!(x.as_deref(), None);
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref(&self) -> Option<&T::Target> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut> Option<T> {
    /// `Option<T>` (သို့မဟုတ် `&mut Option<T>`) မှ `Option<&mut T::Target>` သို့ပြောင်းသည်။
    ///
    /// မူလ `Option` အတွင်းပိုင်းအမျိုးအစား `Deref::Target` အမျိုးအစားကိုပြောင်းလဲနိုင်သောရည်ညွှန်းချက်ပါ ၀ င်သည့်အသစ်တစ်ခုကိုဖန်တီးခြင်း။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref_mut().map(|x| {
    ///     x.make_ascii_uppercase();
    ///     x
    /// }), Some("HEY".to_owned().as_mut_str()));
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref_mut(&mut self) -> Option<&mut T::Target> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Option<Result<T, E>> {
    /// [`Result`] တစ်ခု၏ `Option` တစ်ခုကို `Option` ၏ [`Result`] တစ်ခုသို့ပြောင်းသည်။
    ///
    /// [`None`] [`Ok`]`(`[`None`] `)` သို့မြေပုံဆွဲပါလိမ့်မည်။
    /// ```` ```(` ```` ```` ```` ```` ```` ```` ```` ```` ```` ```` ```` ```` ```` ```` ```` ```` ```` ````၊ ```` ```` ```၊`[`Some`] `(_))` နှင့် [`Err`]`(_)`။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x, y.transpose());
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn transpose(self) -> Result<Option<T>, E> {
        match self {
            Some(Ok(x)) => Ok(Some(x)),
            Some(Err(e)) => Err(e),
            None => Ok(None),
        }
    }
}

// ၎င်းသည် .expect() ကိုယ်တိုင်ကုဒ်အရွယ်အစားကိုလျှော့ချရန်သီးခြားလုပ်ဆောင်ချက်ဖြစ်သည်။
#[inline(never)]
#[cold]
#[track_caller]
fn expect_failed(msg: &str) -> ! {
    panic!("{}", msg)
}

// ၎င်းသည် .expect_none() ကိုယ်တိုင်ကုဒ်အရွယ်အစားကိုလျှော့ချရန်သီးခြားလုပ်ဆောင်ချက်ဖြစ်သည်။
#[inline(never)]
#[cold]
#[track_caller]
fn expect_none_failed(msg: &str, value: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, value)
}

/////////////////////////////////////////////////////////////////////////////
// Trait အကောင်အထည်ဖော်မှု
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for Option<T> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Some(x) => Some(x.clone()),
            None => None,
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Some(to), Some(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Option<T> {
    /// [`None`][Option::None] သို့ပြန်သွားသည်
    ///
    /// # Examples
    ///
    /// ```
    /// let opt: Option<u32> = Option::default();
    /// assert!(opt.is_none());
    /// ```
    #[inline]
    fn default() -> Option<T> {
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for Option<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// ဖြစ်နိုင်သည့်ပါ ၀ င်သောတန်ဖိုးများအပေါ်တွင်စားသုံးသည့်ကြားကပြန်ပို့ပေးသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("string");
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert_eq!(v, ["string"]);
    ///
    /// let x = None;
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: Item { opt: self } }
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a Option<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a mut Option<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(since = "1.12.0", feature = "option_from")]
impl<T> From<T> for Option<T> {
    /// `val` အသစ်တစ်ခုကို `Some` ထဲသို့ကူးယူပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// let o: Option<u8> = Option::from(67);
    ///
    /// assert_eq!(Some(67), o);
    /// ```
    fn from(val: T) -> Option<T> {
        Some(val)
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a Option<T>> for Option<&'a T> {
    /// `&Option<T>` မှ `Option<&T>` သို့ပြောင်းသည်။
    ///
    /// # Examples
    ///
    /// `Option <` [`String`]`>`` Option တစ်ခုကို `Option <` [`usize`]`>`သို့ေူပာင်းလဲ။ မူရင်းကိုထိန်းသိမ်းသည်။
    /// [`map`] method သည် `self` argument ကိုမူရင်းကိုစားသုံးခြင်းအားဖြင့်တန်ဖိုးအားဖြင့်ရယူသည်။ ထို့ကြောင့်ဒီနည်းပညာသည် `Option` ကိုပထမဆုံး `Option` ကိုမူလအတွင်းရှိတန်ဖိုးကိုရည်ညွှန်းရန်ယူသည်။
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let s: Option<String> = Some(String::from("Hello, Rustaceans!"));
    /// let o: Option<usize> = Option::from(&s).map(|ss: &String| ss.len());
    ///
    /// println!("Can still print s: {:?}", s);
    ///
    /// assert_eq!(o, Some(18));
    /// ```
    ///
    fn from(o: &'a Option<T>) -> Option<&'a T> {
        o.as_ref()
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a mut Option<T>> for Option<&'a mut T> {
    /// `&mut Option<T>` မှ `Option<&mut T>` သို့ပြောင်းသည်
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = Some(String::from("Hello"));
    /// let o: Option<&mut String> = Option::from(&mut s);
    ///
    /// match o {
    ///     Some(t) => *t = String::from("Hello, Rustaceans!"),
    ///     None => (),
    /// }
    ///
    /// assert_eq!(s, Some(String::from("Hello, Rustaceans!")));
    /// ```
    fn from(o: &'a mut Option<T>) -> Option<&'a mut T> {
        o.as_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// အဆိုပါရွေးချယ်စရာကြားမှာ
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
struct Item<A> {
    opt: Option<A>,
}

impl<A> Iterator for Item<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.opt.take()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        match self.opt {
            Some(_) => (1, Some(1)),
            None => (0, Some(0)),
        }
    }
}

impl<A> DoubleEndedIterator for Item<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.opt.take()
    }
}

impl<A> ExactSizeIterator for Item<A> {}
impl<A> FusedIterator for Item<A> {}
unsafe impl<A> TrustedLen for Item<A> {}

/// တစ် ဦး [`Option`] ၏ [`Some`] မူကွဲတစ်ခုရည်ညွှန်းကျော်တစ်ခုကြားမှာ။
///
/// အကယ်၍ [`Option`] သည် [`Some`] ဖြစ်လျှင်၎င်းသည်မဟုတ်ပါ။
///
/// ဤ `struct` ကို [`Option::iter`] function ဖြင့်ဖန်တီးသည်။
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct Iter<'a, A: 'a> {
    inner: Item<&'a A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for Iter<'a, A> {
    type Item = &'a A;

    #[inline]
    fn next(&mut self) -> Option<&'a A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for Iter<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for Iter<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for Iter<'_, A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Clone for Iter<'_, A> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner.clone() }
    }
}

/// တစ် ဦး [`Option`] ၏ [`Some`] မူကွဲတစ်ခု mutable ရည်ညွှန်းကျော်တစ်ခုကြားမှာ။
///
/// အကယ်၍ [`Option`] သည် [`Some`] ဖြစ်လျှင်၎င်းသည်မဟုတ်ပါ။
///
/// ဤ `struct` ကို [`Option::iter_mut`] function ဖြင့်ဖန်တီးသည်။
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, A: 'a> {
    inner: Item<&'a mut A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for IterMut<'a, A> {
    type Item = &'a mut A;

    #[inline]
    fn next(&mut self) -> Option<&'a mut A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for IterMut<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IterMut<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IterMut<'_, A> {}
#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// တစ် ဦး [`Option`] ၏ [`Some`] မူကွဲအတွက်တန်ဖိုးကိုကျော်ကြားမှာ။
///
/// အကယ်၍ [`Option`] သည် [`Some`] ဖြစ်လျှင်၎င်းသည်မဟုတ်ပါ။
///
/// ဤ `struct` ကို [`Option::into_iter`] function ဖြင့်ဖန်တီးသည်။
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<A> {
    inner: Item<A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Iterator for IntoIter<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> DoubleEndedIterator for IntoIter<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IntoIter<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IntoIter<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, V: FromIterator<A>> FromIterator<Option<A>> for Option<V> {
    /// [`Iterator`] ထဲက element တစ်ခုချင်းစီကိုယူသည်။ ၎င်းသည် [`None`][Option::None] ဖြစ်ပါကနောက်ထပ်ဒြပ်စင်များကိုယူမသွားဘဲ [`None`][Option::None] ကိုပြန်ပို့သည်။
    /// [`None`][Option::None] မပေါ်ပေါက်ပါက [`Option`] တစ်ခုချင်းစီ၏တန်ဖိုးများပါသည့်ကွန်တိန်နာတစ်ခုကိုပြန်ပို့သည်။
    ///
    /// # Examples
    ///
    /// ဤတွင် vector အတွင်းရှိကိန်းတစ်ခုစီကိုတိုးစေသောဥပမာတစ်ခုဖြစ်သည်။
    /// ကျနော်တို့တွက်ချက်မှုတစ်ခုလျှံဖြစ်ပေါ်လိမ့်မည်ဟုအခါ `None` ပြန်လာသော check လုပ်ထား `add` ၏မူကွဲကိုအသုံးပြုပါ။
    ///
    /// ```
    /// let items = vec![0_u16, 1, 2];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_add(1))
    ///     .collect();
    ///
    /// assert_eq!(res, Some(vec![1, 2, 3]));
    /// ```
    ///
    /// သင်မြင်သည်အတိုင်း, ဒီမျှော်လင့်ထား, တရားဝင်ပစ္စည်းများပြန်လာပါလိမ့်မယ်။
    ///
    /// နောက်ဥပမာတစ်ခုကအခြားတစ်ခုကိန်းတစ်ခုထဲကတစ်ခုကိုနုတ်ဖို့ကြိုးစားနေတယ်၊ ဒီတစ်ကြိမ်မှာတော့ underflow ကိုစစ်ဆေးတယ်။
    ///
    /// ```
    /// let items = vec![2_u16, 1, 0];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_sub(1))
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// ```
    ///
    /// နောက်ဆုံးဒြပ်စင်သည်သုည ဖြစ်၍၊ထို့ကြောင့်ရလဒ်တန်ဖိုးမှာ `None` ဖြစ်သည်။
    ///
    /// ဤတွင်ယခင်နမူနာအပေါ် မူတည်၍ `None` ပထမ `None` မှနောက်ထပ်ဒြပ်စင်များကိုယူမသွားကြောင်းဖော်ပြသည်။
    ///
    /// ```
    /// let items = vec![3_u16, 2, 1, 10];
    ///
    /// let mut shared = 0;
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| { shared += x; x.checked_sub(2) })
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// တတိယ element သည် underflow ဖြစ်စေသောကြောင့်နောက်ထပ် element များကိုယူခြင်းမရှိသောကြောင့် `shared` ၏နောက်ဆုံးတန်ဖိုးသည် 6 (= `3 + 2 + 1`) ဖြစ်ပြီး ၁၆ မဟုတ်ပါ။
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Option<A>>>(iter: I) -> Option<V> {
        // FIXME(#11084): ဤစွမ်းဆောင်ရည် bug ကိုပိတ်လိုက်သောအခါ၎င်းကို Iterator::scan ဖြင့်အစားထိုးနိုင်သည်။
        //

        iter.into_iter().map(|x| x.ok_or(())).collect::<Result<_, _>>().ok()
    }
}

/// try operator (`?`) အား `None` တန်ဖိုးသို့လျှောက်ထားခြင်းမှရရှိသောအမှားအမျိုးအစား။
/// သင်၏ X0 `x?`(`x` သည် `Option<T>` တစ်ခုဖြစ်သည်) သည်သင်၏အမှားအမျိုးအစားသို့ပြောင်းလဲခွင့်ပြုလိုပါက `YourErrorType` အတွက် `impl From<NoneError>` ကိုအသုံးပြုနိုင်သည်။
///
/// ထိုအခြေအနေတွင် `Result<_, YourErrorType>` ကို return ပြန်လုပ်သည့် function တစ်ခုအတွင်းရှိ `x?` သည် `None` တန်ဖိုးကို `Err` ရလဒ်တစ်ခုသို့ဘာသာပြန်ပေးလိမ့်မည်။
#[rustc_diagnostic_item = "none_error"]
#[unstable(feature = "try_trait", issue = "42327")]
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
pub struct NoneError;

#[unstable(feature = "try_trait", issue = "42327")]
impl<T> ops::Try for Option<T> {
    type Ok = T;
    type Error = NoneError;

    #[inline]
    fn into_result(self) -> Result<T, NoneError> {
        self.ok_or(NoneError)
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Some(v)
    }

    #[inline]
    fn from_error(_: NoneError) -> Self {
        None
    }
}

impl<T> Option<Option<T>> {
    /// `Option<Option<T>>` မှ `Option<T>` သို့ပြောင်းသည်
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let x: Option<Option<u32>> = Some(Some(6));
    /// assert_eq!(Some(6), x.flatten());
    ///
    /// let x: Option<Option<u32>> = Some(None);
    /// assert_eq!(None, x.flatten());
    ///
    /// let x: Option<Option<u32>> = None;
    /// assert_eq!(None, x.flatten());
    /// ```
    ///
    /// သာ Flattening တစ်ကြိမ်အသိုက်ထဲကတစ်ခုအဆင့်ကိုဖယ်ရှားပေး:
    ///
    /// ```
    /// let x: Option<Option<Option<u32>>> = Some(Some(Some(6)));
    /// assert_eq!(Some(Some(6)), x.flatten());
    /// assert_eq!(Some(6), x.flatten().flatten());
    /// ```
    #[inline]
    #[stable(feature = "option_flattening", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn flatten(self) -> Option<T> {
        match self {
            Some(inner) => inner,
            None => None,
        }
    }
}