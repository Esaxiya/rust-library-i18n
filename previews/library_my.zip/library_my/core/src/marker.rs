//! Primitive traits နှင့်အမျိုးအစားများ၏အခြေခံဂုဏ်သတ္တိများကိုကိုယ်စားပြုအမျိုးအစားများ။
//!
//! Rust အမျိုးအစားများကိုသူတို့ရဲ့ပင်ကိုယ်ဂုဏ်သတ္တိအရသိရသည်အမျိုးမျိုးသောအသုံးဝင်သောနည်းလမ်းခွဲခြားနိုင်ပါသည်။
//! ဤအမျိုးအစားများကို traits အဖြစ်ဖော်ပြသည်။
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// ချည်နယ်နိမိတ်တစ်လျှောက်ရှိလွှဲပြောင်းနိုင်အမျိုးအစားများ။
///
/// အဆိုပါ compiler ကယ့်သင့်လျော်တဲ့ဆုံးဖြတ်သည်သောအခါဤ trait ကိုအလိုအလျောက်အကောင်အထည်ဖော်နေပါတယ်။
///
/// non-`Send` type ကိုဥပမာအနေနဲ့ရည်ညွှန်း-ရေတွက် pointer [`rc::Rc`][`Rc`] ဖြစ်ပါတယ်။
/// အကယ်၍ Thread နှစ်ခုသည် [`Rc`] မှထိုရည်ညွှန်းချက်အားအတူတူရည်ညွှန်းထားသောတန်ဖိုးကိုရည်ညွှန်းရန်ကြိုးစားပါက [`Rc`] သည်အနုမြူစစ်ဆင်ရေးများကိုမသုံးသောကြောင့်တစ်ချိန်တည်းတွင် [undefined behavior][ub] ဖြစ်သော reference count ကို update လုပ်ရန်ကြိုးစားလိမ့်မည်။
///
/// ၎င်း၏ဝမ်းကွဲ [`sync::Arc`][arc] အနုမြူဗုံးစစ်ဆင်ရေး (အချို့ overhead ပေးရ) ကိုသုံးခြင်းနှင့်အရှင် `Send` ဖြစ်ပါတယ်ပါဘူး။
///
/// အသေးစိတ်အတွက် [the Nomicon](../../nomicon/send-and-sync.html) ကိုကြည့်ပါ။
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// compile လုပ်ခြင်းအချိန်တွင်လူသိများနေတဲ့စဉ်ဆက်မပြတ်အရွယ်အစားနှင့်အတူအမျိုးအစားများ။
///
/// အားလုံးအမျိုးအစား parameters တွေကို `Sized` တစ်ခုသွယ်ဝိုက်သောဘောင်းရှိသည်။အထူး syntax `?Sized` ကသင့်လျော်သောမယ့်လျှင်ခညျြနှောငျဒီကိုဖယ်ရှားရန်အသုံးပြုနိုင်ပါသည်။
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // FooUse(Foo<[i32]>) struct;//အမှား: သုံးနိုင် [i32] များအတွက်စတင်ခြင်းမရှိပါ
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// တခြွင်းချက်တစ်ခု trait ၏သွယ်ဝိုက် `Self` အမျိုးအစားဖြစ်ပါတယ်။
/// တစ်ဦးက trait ဒီ [trait အရာဝတ္ထု] နှင့်ကိုက်ညီခြင်းမရှိပါအဖြစ်သွယ်ဝိုက် `Sized` ခညျြနှောငျမရှိပါဘူးချက်နှင့်အဓိပ္ပါယ်အားဖြင့်, အ trait အားလုံးဖြစ်နိုင်သမျှ implementors နှင့်အတူအလုပ်ဖို့လိုတယ်, ဤသို့မဆိုအရွယ်အစားဖြစ်နိုင်ပါတယ်ရှိရာ, ့။
///
///
/// Rust သင်တစ်ဦး trait မှ `Sized` ခညျြနှောငျပါစေပါလိမ့်မယ်ပေမယ့်, သင်နောက်ပိုင်းတွင်တစ်ဦး trait အရာဝတ္ထုဖွဲ့စည်းရန်အသုံးပြုနိုင်လိမ့်မည်မဟုတ်ပေ:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // y ကပါစေ: &dyn ဘား &Impl =;//အမှား: အ trait `Bar` တစ်ခုအရာဝတ္ထုသို့လုပ်မရနိုငျ
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // `[T]: !Default` evaluatable ဖြစ်လိုအပ်သည်သောပုံမှန်အဘို့, ဥပမာ
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// တစ်ဦးသည် dynamically အရွယ်အမျိုးအစားမှ "unsized" ဖြစ်နိုငျသောအမျိုးအစားများ။
///
/// ဥပမာ, အရွယ်ခင်းကျင်းအမျိုးအစား `[i8; 2]` `Unsize<[i8]>` နှင့် `Unsize<dyn fmt::Debug>` အကောင်အထည်ဖော်ဆောင်ရွက်နေသော။
///
/// `Unsize` အားလုံးသည်ကလပ်စ compiler အားဖြင့်အလိုအလျှောက်ပေးနေကြသည်။
///
/// `Unsize` အဘို့အကောင်အထည်ဖော်:
///
/// - `[T; N]` `Unsize<[T]>` ဖြစ်ပါသည်
/// - `T` `Unsize<dyn Trait>` သည့်အခါ `T: Trait` ဖြစ်ပါသည်
/// - `Foo<..., T, ...>` အကယ်၍ `Unsize<Foo<..., U, ...>>` သည်
///   - `T: Unsize<U>`
///   - foo တစ် struct ဖြစ်ပါသည်
///   - `Foo` သာနောက်ဆုံးလယ်ကွင်း `T` ပါဝင်သောအမျိုးအစားရှိပါတယ်
///   - `T` အခြားမည်သည့်လယ်ကွင်းအမျိုးအစား၏အစိတ်အပိုင်းတစ်ခုမဟုတ်ပါဘူး
///   - `Bar<T>: Unsize<Bar<U>>`, `Foo` ၏နောက်ဆုံးသောလယ် `Bar<T>` ရိုက်ထည့်ရှိပါတယ်လျှင်
///
/// `Unsize` ထိုကဲ့သို့သော [`Rc`] အဖြစ် "user-defined" ကွန်တိန်နာသည် dynamically အရွယ်အမျိုးအစားများဆံ့ဖို့ခွင့်ပြု [`ops::CoerceUnsized`] နှင့်အတူအသုံးပြုသည်။
/// အသေးစိတ်များအတွက် [DST coercion RFC][RFC982] နှင့် [the nomicon entry on coercion][nomicon-coerce] ကိုကြည့်ပါ။
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// ပုံစံပွဲများတွင်အသုံးပြုရုံကလွဲပြီးအဘို့လိုအပ်ပါသည် trait ။
///
/// `PartialEq` မှဆင်းသက်လာသောမည်သည့်အမျိုးအစားမဆိုဤ trait ကိုအလိုအလျောက်အကောင်အထည်ဖော်သည်။
///
/// တစ်ဦး `const` ကို item ဒီ trait အကောင်အထည်ဖော်မပါဘူးတချို့အမျိုးအစားပါရှိသည်လျှင်, type ကို (1.) (ထိုစဉ်ဆက်မပြတ်ကုဒ်မျိုးဆက်ရရှိနိုင်ပါသည်ယူဆသောအရာနှင့်နှိုင်းယှဉ်လျှင်နည်းလမ်းပေးလိမျ့မညျမဟုဆိုလိုသည်) `PartialEq` အကောင်အထည်ဖော်ဖို့, ဒါမှမဟုတ် (2.) ပါဘူးဖြစ်စေကြောင်းကို *၎င်း၏ကိုယ်ပိုင်အကောင်အထည်ဖော်ဆောင်ရွက်နေသော*`PartialEq` ၏မူကွဲ (ဖွဲ့စည်းပုံနှင့်တန်းတူရည်တူနှိုင်းယှဉ်မှုနှင့်မကိုက်ညီပါကကျွန်ုပ်တို့ယူဆသည်)
///
///
/// ဖြစ်စေအထက်ပါနှစ်ခုကး၏မှာတော့ကျွန်တော်တစ်ဦးပုံစံပွဲစဉ်များတွင်ထိုကဲ့သို့တစ်ဦးစဉ်ဆက်မပြတ်၏အသုံးပြုမှုကိုငြင်းပယ်။
///
/// attribute-based ဒီဇိုင်းမှ trait သို့ပြောင်းရွှေ့ရန်လှုံ့ဆော်ပေးသည့် [structural match RFC][RFC1445] နှင့် [issue 63438] ကိုလည်းရှုပါ။
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// ပုံစံပွဲများတွင်အသုံးပြုရုံကလွဲပြီးအဘို့လိုအပ်ပါသည် trait ။
///
/// `Eq` မှဆင်းသက်လာသောမည်သည့်အမျိုးအစားမဆိုဤ trait * ကိုအလိုအလျောက်အကောင်အထည်ဖော်သည်၊ ၎င်း၏အမျိုးအစားသတ်မှတ်ချက်များသည် `Eq` ကိုအကောင်အထည်ဖော်ခြင်းရှိမရှိ။
///
/// ဒါဟာကျွန်တော်တို့ရဲ့ type ကိုစနစ်တစ်န့်အသတ်န်းကျင်လုပ်ကိုင်ဖို့တစ်ဦး hack ကဖြစ်ပါတယ်။
///
/// # Background
///
/// ကျနော်တို့ပုံစံပွဲများတွင်အသုံးပြု consts အမျိုးအစားများ attribute မှာ `#[derive(PartialEq, Eq)]` ရှိသည်လိုအပ်ချင်တယ်။
///
/// ပိုမိုကောင်းမွန်သောစံပြကမ္ဘာတွင်ကျွန်ုပ်တို့သည်ဤလိုအပ်ချက်ကို `StructuralPartialEq` trait *နှင့်*`Eq` trait နှစ်ခုလုံးအကောင်အထည်ဖော်ကြောင်းစစ်ဆေးခြင်းအားဖြင့်စစ်ဆေးနိုင်သည်။
/// သို့သော်သင့်တွင် *`derive(PartialEq, Eq)`* ပြုသည့် ADT များရှိနိုင်သည်၊ ကျွန်ုပ်တို့ compiler ကိုလက်ခံစေလိုသောအရာဖြစ်နိုင်သည်။ သို့သော် constant ၏အမျိုးအစားသည် `Eq` ကိုအကောင်အထည်ဖော်ရန်ပျက်ကွက်သည်။
///
/// အမည်, ဤကဲ့သို့သောအမှု:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (အထက်ပါကုဒ်အတွက်ပြဿနာ `အဘို့ < '' တစ်ဦး> fn(&'a _)` does not implement those traits.) ဘာဖြစ်လို့လဲဆိုတော့ `Wrap<fn(&())>`, `PartialEq`, မ `Eq` အကောင်အထည်ဖော်မပါဘူးဆိုတာပါပဲ
///
/// ထို့ကွောငျ့ကြှနျုပျတို့သ `StructuralPartialEq` နှင့်မျှသာ `Eq` အဘို့အနုံစစ်ဆေးမှုများအပေါ်အားကိုးလို့မရပါဘူး။
///
/// ၎င်းကိုလုပ်ဆောင်ရန် hack တစ်ခုအနေဖြင့်ကျွန်ုပ်တို့နှစ်ခုစလုံးမှ (`#[derive(PartialEq)]` နှင့် `#[derive(Eq)]`) မှထိုးသွင်းထားသောသီးခြား traits နှစ်ခုကိုအသုံးပြုသည်။ ၎င်းတို့သည်ဖွဲ့စည်းတည်ဆောက်ပုံနှင့်ကိုက်ညီမှုစစ်ဆေးခြင်း၏တစ်စိတ်တစ်ပိုင်းအနေဖြင့်ရှိနေခြင်းကိုစစ်ဆေးသည်။
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// အဘယ်သူ၏တန်ဖိုးများ-bits ကူးယူခြင်းဖြင့်ရိုးရိုးကော်ပီပွားယူနိုင်ပါတယ်အမျိုးအစားများ။
///
/// ပုံမှန်အားဖြင့် variable ကိုခညျြနှောငျ '' ဝေါဟာရအသုံးအနှုံးကိုရွှေ့။ 'ရှိတယ်တစ်နည်းပြောရရင်တော့:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` `y` သို့ပြောင်းရွှေ့ခဲ့သည်, ဒါကြောင့် အသုံးပြု. မရပါ
///
/// // println ("{: ?}" x က);//အမှား: ပြောင်းရွှေ့တန်ဖိုးကိုအသုံးပြုခြင်း
/// ```
///
/// အမျိုးအစားသုံးကိရိယာ `Copy` လျှင်မည်သို့ပင်ဆို, ကအစား '' မိတ္တူ semantic '' ရှိပါတယ်:
///
/// ```
/// // ကျနော်တို့က `Copy` အကောင်အထည်ဖော်မှုရရှိနိုငျသညျ။
/// // `Clone` ၎င်းသည် `Copy` ၏ supertrait အဖြစ်လိုအပ်သည်။
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` `x` တစ်ဦးမိတ္တူဖြစ်ပါသည်
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// ဤဥပမာနှစ်ခုကိုအတွက်တစ်ခုတည်းသောခြားနားချက်ကိုသင်တာဝနျကိုအပြီး access ကို `x` ခွင့်ရှိမရှိကြောင်းကိုမှတ်စုအရေးကြီးပါတယ်။
/// ပါးပျဉ်းအောကျတှငျမိတ္တူပှဲတစျခုနှဈသကျသခေံခွငျးသညျကှဲပွားခွားခွားမှုမြားကိုမှတ်ဉာဏ်ထဲ၌ကူးယူစေနိုင်သည်၊
///
/// ## အဘယ်သို့ငါ `Copy` အကောင်အထည်ဖော်နိုင်သလဲ
///
/// သင့်ရဲ့အမျိုးအစားပေါ် `Copy` အကောင်အထည်ဖော်ရန်နည်းလမ်းနှစ်ခုရှိပါတယ်။အရိုးရှင်းဆုံးကတော့ `derive` ကိုသုံးရန်ဖြစ်သည်။
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// `Copy` နှင့် `Clone` ကိုသင်ကိုယ်တိုင်လည်းထည့်သွင်းနိုင်သည်။
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// နှစ်ခုအကြားသေးငယ်တဲ့ခြားနားချက်ရှိပါသည်: အ `derive` မဟာဗျူဟာကိုလည်း `Copy` အမြဲဆန္ဒရှိမထား type ကို parameters တွေကိုပေါ်တွင်ချည်နှောင်လျက်နေရာချပါလိမ့်မယ်။
///
/// ## `Copy` နှင့် `Clone` အကြားကွာခြားချက်ကဘာလဲ?
///
/// မိတ္တူတစ်ခုတာဝနျကို `y = x` ၏တစ်စိတ်တစ်ပိုင်းအဖြစ်ဥပမာလုံးလုံးလြားလြားဖြစ်ပျက်။`Copy` ၏အပြုအမူ Overload မျှမက,၎င်းသည်အမြဲတမ်းရိုးရှင်းသည့်နည်းတူမိတ္တူဖြစ်သည်။
///
/// Cloning သည်ရှင်းလင်းပြတ်သားစွာလုပ်ဆောင်သော `x.clone()` ဖြစ်သည်။[`Clone`] များ၏အကောင်အထည်ဖော်မှုလုံခြုံစွာတန်ဖိုးများကိုပွားရန်လိုအပ်သောမည်သည့်အမျိုးအစား-သတ်သတ်မှတ်မှတ်အပြုအမူပေးနိုင်ပါသည်။
/// ဥပမာအားဖြင့်၊ [`String`] အတွက် [`Clone`] ၏အကောင်အထည်ဖော်မှုသည်အမှိုက်ပုံထဲမှ point-to string buffer ကိုကူးယူရန်လိုအပ်သည်။
/// ရိုးရှင်းသောနည်းနည်း [`String`] တန်ဖိုးများ၏မိတ္တူတစ်ခုသည် pointer ကိုသာကူးယူလိုက်ရုံဖြင့်အခမဲ့ဖြစ်သည်။
/// ဤအကြောင်းကြောင့်, [`String`] [`Clone`] သော်လည်းမ `Copy` ဖြစ်ပါတယ်။
///
/// [`Clone`] ဒါကြောင့် X0XX ဖြစ်သမျှအားလုံးသည် [`Clone`] ကိုအကောင်အထည်ဖော်ရမယ်။
/// အမျိုးအစား `Copy` ဖြစ်ပါတယ်လျှင်ယင်း၏ [`Clone`] အကောင်အထည်ဖော်မှုသာ `*self` (အပေါ်ကဥပမာကိုကြည့်ပါ) ပြန်လာရန်လိုအပ်ပါသည်။
///
/// ## ဘယ်အချိန်မှာအကြှနျုပျ၏အမျိုးအစား `Copy` နိုင်သနည်း
///
/// ယင်း၏အစိတ်အပိုင်းအားလုံး `Copy` အကောင်အထည်ဖေါ်လျှင်တစ်ဦးကအမျိုးအစား `Copy` အကောင်အထည်ဖော်နိုင်ပါတယ်။ဥပမာအားဖြင့်၊ ဤဖွဲ့စည်းပုံသည် `Copy` ဖြစ်နိုင်သည်။
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// ထို့ကြောင့် `Point` `Copy` ဖြစ်ခွင့်ဖြစ်ပါသည်, တစ်ဦးက struct `Copy` ဖြစ်နိုင်ပြီး, [`i32`] `Copy` ဖြစ်ပါတယ်။
/// ဆန့်ကျင်ဘက်အနေဖြင့်သုံးသပ်ကြည့်ပါ
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// [`Vec<T>`] `Copy` မဟုတ်ပါဘူးကြောင့် struct `PointList`, `Copy` အကောင်အထည်မဖော်နိုင်ပါ။ကျွန်တော်တစ်ဦး `Copy` အကောင်အထည်ဖော်မှုရယူထားခြင်းကြိုးစားလျှင်, ငါတို့သည်မှားယွင်းမှုတစ်ခုရလိမ့်မယ်:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// shared ကိုးကား (`&T`) လည်း `Copy` ဖြစ်ကြောင်း, ဒါအမျိုးအစားက * *`Copy` မဟုတ်အမျိုးအစားများ `T` ၏ shared ကိုးကားရရှိထားသူတောင်မှအခါ, `Copy` နိုင်ပါတယ်။
/// `Copy` ကိုအကောင်အထည်ဖော်နိုင်သောအောက်ဖော်ပြပါ struct ကိုစဉ်းစားပါ။ အဘယ်ကြောင့်ဆိုသော်၎င်းသည်အထက်မှကျွန်ုပ်တို့၏ `Copy` type `PointList` ကို *shared reference* တစ်ခုသာပိုင်ဆိုင်ထားသောကြောင့်ဖြစ်သည်။
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## * * ငါ့အ type ကို `Copy` မဖွစျနိုငျသောအခါအ?
///
/// အချို့အမျိုးအစားများကိုလုံခြုံစွာကူးယူ။ မရပါ။ဥပမာအားဖြင့်, `&mut T` ကူးယူထားတဲ့အခြားအမည်ပေးထားသော mutable ရည်ညွှန်းဖန်တီးလိမ့်မယ်။
/// Copy [`String`] သည် [`String`] 's ကြားခံများကိုစီမံရန်တာ ၀ န်ကိုထပ်မံပြုလုပ်မည်ဖြစ်ရာအခမဲ့ဖြစ်သည်။
///
/// ၎င်း၏ကိုယ်ပိုင် [`size_of::<T>`] bytes မှတပါးအချို့အရင်းအမြစ်စီမံခန့်ခွဲမယ့်အဘယ်ကြောင့်ဆိုသော်အဆုံးစွန်သောအမှု Generalizing, [`Drop`] အကောင်အထည်ဖော်မဆိုအမျိုးအစား, `Copy` မဖြစ်နိုင်ပါ။
///
/// `Copy` ကို `Copy` မဟုတ်သည့် data များပါဝင်သည့် struct သို့မဟုတ် enum ပေါ်တွင်အကောင်အထည်ဖော်ရန်ကြိုးစားပါက [E0204] အမှားကိုသင်ရရှိမည်ဖြစ်သည်။
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## ဘယ်အချိန်မှာ * * ငါ့အ type ကို `Copy` ဖြစ်သင့်သလဲ
///
/// ယေဘူယျအားဖြင့်ပြောရလျှင် အကယ်၍ သင်၏ _can_ အမျိုးအစားသည် `Copy` ကိုအကောင်အထည်ဖော်ပါက၎င်းကိုပြုလုပ်သင့်သည်။
/// `Copy` အကောင်အထည်ဖော်သင့်ရဲ့အမျိုးအစားအများပြည်သူ API ကို၏အစိတ်အပိုင်းတစ်ခုဖြစ်တယ်ဆိုတာသျောစိတျထဲတှငျထားပါ။
/// အမျိုးအစားဟာ future အတွက် Non-`Copy` ဖြစ်လာလိမ့်မယ်ဆိုပါကတစ်ဦးကိုချိုးဖောက် API ကိုပြောင်းလဲမှုကိုရှောင်ရှားရန်, ယခု `Copy` အကောင်အထည်ဖော်မှုချန်လှပ်ဖို့သမ္မာသတိရှိသောဖြစ်နိုင်ပါတယ်။
///
/// ## အပိုဆောင်း implementors
///
/// [implementors listed below][impls] အပြင် `Copy` ကိုလည်းအောက်ပါအမျိုးအစားများသည်အကောင်အထည်ဖော်သည်-
///
/// * function ကို item အမျိုးအစားများ (ဆိုလိုသည်မှာတစ်ဦးချင်းစီ function ကိုများအတွက်သတ်မှတ်ထားတဲ့ကွဲပြားအမျိုးအစားများ)
/// * function pointer အမျိုးအစားများ (ဥပမာ, `fn() -> i32`)
/// * အားလုံးအရွယ်အစားအဘို့အ array အမျိုးအစားများ, ပစ္စည်းအမျိုးအစားကိုလည်း `Copy` (ဥပမာ `[i32; 123456]`) အကောင်အထည်ဖော်ဆောင်ရွက်နေသောလျှင်
/// * Tuple အမျိုးအစားများ, တစ်ခုချင်းစီအစိတ်အပိုင်းလည်း `Copy` (ဥပမာ `()`, `(i32, bool)`) အကောင်အထည်ဖော်ဆောင်ရွက်နေသောလျှင်
/// * ပိတ်မိခြင်းအမျိုးအစားများ၊ ပတ်ဝန်းကျင်မှမည်သည့်တန်ဖိုးမျှမယူလျှင်သို့မဟုတ်ထိုဖမ်းမိသောတန်ဖိုးအားလုံးသည် `Copy` သူတို့ကိုယ်တိုင်အကောင်အထည်ဖော်မည်ဆိုလျှင်။
///   share ကိုးကားခြင်းဖြင့်ဖမ်းမိသော variable များသည်အမြဲတမ်း `Copy` ကိုသုံးသည်။
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) ဤသည်ကမကျေနပ်သောသက်တမ်း (`A<'static>: Copy` နှင့် `A<'_>: Clone` သာအခါကော်ပီကူးခြင်း) ဖြစ်သောကြောင့် `Copy` ကိုအကောင်အထည်မဖော်သောအမျိုးအစားကိုကူးယူရန်ခွင့်ပြုသည်။
// စံပြစာကြည့်တိုက်တွင်ရှိနှင့်ပြီးဖြစ်သော `Copy` တွင်အထူးပြုထားသောအရာအတော်များများရှိပြီးယခုအချိန်တွင်ဤအပြုအမူကိုလုံခြုံစိတ်ချစွာအသုံးပြုနိုင်ရန်နည်းလမ်းမရှိသောကြောင့်ယခုတွင်ဤ attribute ကိုဒီမှာရှိသည်။
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// အနကျအဓိပ်ပါယျနိုင်တဲ့ macro အဆိုပါ trait `Copy` တစ်ခု impl ထုတ်လုပ်။
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// ကိုးကားချက်များကိုမျှဝေရန်စိတ်ချရသောအမျိုးအစားများ။
///
/// အဆိုပါ compiler ကယ့်သင့်လျော်တဲ့ဆုံးဖြတ်သည်သောအခါဤ trait ကိုအလိုအလျောက်အကောင်အထည်ဖော်နေပါတယ်။
///
/// အတိအကျချက်နှင့်အဓိပ္ပါယ်ဖြစ်ပါသည်: အမျိုးအစား `T` လျှင် [`Sync`] သည်နှင့် `&T` [`Send`] သာလျှင်။
/// [undefined behavior][ub] မရှိဖြစ်နိုင်ခြေရှိလြှငျတစ်နည်း, (data တွေကိုလူမျိုးအပါအဝင်) ချည်အကြား `&T` ကိုးကားဖြတ်သန်းရသောအခါ။
///
/// မျှော်လင့်ထားသည့်အတိုင်း [`u8`] နှင့် [`f64`] ကဲ့သို့စရိုက်အမျိုးအစားများအားလုံးသည် [`Sync`] ဖြစ်ကြသည်။ ထို့အပြင်၎င်းတို့သည်ပါဝင်သည့်ရိုးရှင်းသောစုစုပေါင်းအမျိုးအစားများဖြစ်သည့် tuples, structs နှင့် enums စသည်တို့ဖြစ်သည်။
/// အခြေခံ [`Sync`] အမျိုးအစားများကိုပိုမိုဥပမာထိုကဲ့သို့သော [`Box<T>`][box], [`Vec<T>`][vec] နှင့်အများဆုံးကိုအခြားစုဆောင်းခြင်းအမျိုးအစားများအဖြစ် "immutable" `&T` တူသောအမျိုးအစားများနှင့်ရိုးရှင်းသောအမွေဆက်ခံ mutability နှင့်အတူသူတို့က, ပါဝင်သည်။
///
/// (Generic parameters တွေကိုသူတို့ရဲ့ကွန်တိန်နာဖြစ်ရန်အဘို့အ [`Sync`] [`Sync`] ရောက်ထားရန်လိုအပ်ပါတယ်။)
///
/// အဓိပ္ပာယ်ဖွင့်ဆိုချက်၏အံ့အားသင့်စရာအကျိုးဆက်မှာ `&mut T` သည် (`T` `Sync` ဖြစ်ပါက) `Sync` ဖြစ်သည်။ ၎င်းမှာမလှုပ်မယှက်သော mutation ကိုပေးလိမ့်မည်။
/// လှည့်ကွက်တစ်ခုမှာ shared reference (ဆိုလိုသည်မှာ `& &mut T`) နောက်ကွယ်မှ mutable reference သည် `& &T` ဖြစ်သကဲ့သို့ read-only ဖြစ်လာသည်။
/// ထို့ကြောင့်ဒေတာအပြေးပြိုင်ပွဲအဘယ်သူမျှမစွန့်စားမှုလည်းမရှိ။
///
/// `Sync` မဟုတ်သောအမျိုးအစားများမှာ "interior mutability" ရှိပြီး [`Cell`][cell] နှင့် [`RefCell`][refcell] ကဲ့သို့သောချည်ထည်မဟုတ်သည့်ပုံစံဖြစ်သည်။
/// ဤရွေ့ကားအမျိုးအစားများကိုပင်တစ်မပြောင်းလဲနိုင်သောအရာများ, shared ရည်ညွှန်းမှတဆင့်၎င်းတို့၏အကြောင်းအရာများကို၏ mutation ဘို့ခွင့်ပြုပါ။
/// ဥပမာအား [`Cell<T>`][cell] အပေါ် `set` နည်းလမ်း `&self` ကြာ, ဒါကြောင့်သာ shared ရည်ညွှန်း [`&Cell<T>`][cell] လိုအပ်သည်။
/// ဤနည်းလမ်းသည်ထပ်တူပြုခြင်းမရှိသောကြောင့် [`Cell`][cell] `Sync` မဖြစ်နိုင်ပါ။
///
/// Non-`Sync` အမျိုးအစားမဟုတ်သောအခြားဥပမာတစ်ခုမှာရည်ညွှန်းရေတွက်သည့်ညွှန်ပြသည့် [`Rc`][rc] ဖြစ်သည်။
/// မဆိုရည်ညွှန်း [`&Rc<T>`][rc] ပေးထား, သင် non-အနုမြူဗုံးလမ်းအတွက်ရည်ညွှန်းအရေအတွက်ပြင်ဆင်ခြင်း, အသစ်တခု [`Rc<T>`][rc] clone နိုင်ပါတယ်။
///
/// တဦးတည်းလိုအပ်ချက်ချည်-လုံခြုံအတွင်းပိုင်း mutability မရသောအခါရောဂါဖြစ်ပွားမှုများအတွက် Rust [`sync::Mutex`][mutex] နှင့် [`sync::RwLock`][rwlock] မှတဆင့်ရှင်းလင်းပြတ်သားစွာသော့ခတ်အဖြစ်, [atomic data types] ပေးပါသည်။
/// ဤရွေ့ကားအမျိုးအစားများကိုမဆို mutation data တွေကိုလူမျိုးအကြောင်းမရှိဤအရပ်မှအမျိုးအစားများ `Sync` များမှာမနိုင်ကြောင်းအာမခံပါသည်။
/// အလားတူပင် [`sync::Arc`][arc] [`Rc`][rc] တစ်ဦးချည်-လုံခြုံ analogue ပေးပါသည်။
///
/// အတွင်းပိုင်း mutability နှင့်အတူမည်သည့်အမျိုးအစားများလည်း shared ရည်ညွှန်းမှတဆင့် mutated နိုင်ပါတယ်သော value(s) ပတ်လည် [`cell::UnsafeCell`][unsafecell] wrapper အသုံးပြုရမည်။
/// ဤသို့ပြုပျက်ကွက် [undefined behavior][ub] ဖြစ်ပါတယ်။
/// ဥပမာအားဖြင့်, [`transmute`][transmute]-ing `&T` ထံမှ `&mut T` မှမှားနေပါသည်။
///
/// `Sync` အကြောင်းကိုပိုမိုအသေးစိတ် [the Nomicon][nomicon-send-and-sync] ကိုကြည့်ပါ။
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): `rustc_on_unimplemented` အတွက်မှတ်စုများကိုထည့်သွင်းဖို့ထောက်ခံမှု beta ကိုအတွက်မြား, ကပိတ်သိမ်းလိုအပ်ချက်ကွင်းဆက်အတွက်ဘယ်နေရာမှာမဆိုဟုတ်မဟုတ်စစ်ဆေးနိုင်ရန်တိုးချဲ့ထားပြီးတခါ, ထိုကဲ့သို့သော (#48534) အဖြစ်တိုးချဲ့:
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// သုညအရွယ်အစားအမျိုးအစား "act like" သူတို့တစ်တွေ `T` ပိုင်ဆိုင်ကြောင်းအမှတ်အသားအမှုအရာလေ့ရှိတယ်။
///
/// သင့်ရဲ့အမျိုးအစားတစ်ခု `PhantomData<T>` လယ်ကိုပေါင်းထည့်ခြင်းကယ့်ကိုမသော်လည်း, type ကို `T` ၏တန်ဖိုးသိုလှောင်သော်လည်းအဖြစ်သင့်အမျိုးအစားပြုမူသော compiler ကပြောပြသည်။
/// အချို့သောဘေးကင်းလုံခြုံမှုဂုဏ်သတ္တိများကွန်ပျူတာသောအခါဤသတင်းအချက်အလက်ကိုအသုံးပြုသည်။
///
/// `PhantomData<T>` သုံးစွဲဖို့ဘယ်လောက်တစ်ဦးထက်ပိုသော In-depth ရှင်းပြချက်အဘို့, [the Nomicon](../../nomicon/phantom-data.html) ကြည့်ရှုပါ။
///
/// # တစ်ဦးက ghastly မှတ်ချက်👻👻👻
///
/// သူတို့နှစ်ဦးစလုံးကြောက်စရာအမည်များ, `PhantomData` နဲ့ 'Phantom အမျိုးအစားများကို' 'related, ဒါပေမယ့်မရတူညီနေကြသည်ရှိသော်လည်း။တစ်ဦးက Phantom type ကို parameter သည်ရိုးရှင်းစွာအသုံးဘယ်တော့မှဖြစ်သည့်အမျိုးအစား parameter သည်ဖြစ်ပါတယ်။
/// Rust အတွက်, ဒီမကြာခဏတိုင်ကြားဖို့ compiler ကိုဖြစ်ပေါ်စေသည်, နှင့်ဖြေရှင်းချက် `PhantomData` လမ်းဖြင့်တစ်ဦး "dummy" အသုံးပြုမှုကိုထည့်သွင်းဖို့ဖြစ်ပါတယ်။
///
/// # Examples
///
/// ## အသုံးမပြုတဲ့တစ်သက်တာ parameters တွေကို
///
/// ဖြစ်ကောင်းဖြစ်နိုင် `PhantomData` များအတွက်အသုံးအများဆုံးအသုံးပြုမှုကိုအမှုပုံမှန်အားဖြင့်အချို့မလုံခြုံကုဒ်၏တစ်စိတ်တစ်ပိုင်းအဖြစ်တစ်ခုအသုံးမပြုတဲ့တစ်သက်တာ parameter သည်ရှိပါတယ်တဲ့ struct ဖြစ်ပါတယ်။
/// ဥပမာအားဖြင့်ဒီမှာ `*const T` အမျိုးအစားညွှန်ပြစက်နှစ်မျိုးပါ ၀ င်သည့် struct `Slice` တစ်ခုဖြစ်သည်။
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// အဆိုပါရည်ရွယ်ချက်ကိုနောက်ခံအချက်အလက်များကိုတစ်သက်တာ `'a` များအတွက်သာတရားဝင်သည်, ဒါ `Slice` outlive `'a` မဟုတ်သင့်သောကွောငျ့ဖွစျသညျ။
/// အဲဒီမှာတစ်သက်တာ `'a` မရှိအသုံးပြုမှုဖြစ်ကြပြီးဤအရပ်မှအဲဒါကိုသက်ဆိုင်သောအရာကို data တွေကိုရှင်းရှင်းလင်းလင်းမသိရပါဘူးကတည်းကသို့သော်ဤရည်ရွယ်ချက်, code ကိုအတွက်ထုတ်ဖော်ပြောဆိုခြင်းမရှိပါ။
/// အဆိုပါ `Slice` struct တစ်ဦးကိုကိုးကား `&'a T` ပါရှိသော *လျှင်အဖြစ်ကျနော်တို့* ပြုမူဖို့ compiler ကပြောပြသဖြင့်ဒီပြင်ပေးနိုင်သည်
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// ဤသည်ကိုလည်းအလှည့်အတွက် `T` အတွက်မဆိုရည်ညွှန်းသည့်တစ်သက်တာ `'a` ကျော်သက်တမ်းရှိဖြစ်ကြောင်းညွှန်ပြခြင်း, မှတ် `T: 'a` လိုအပ်သည်။
///
/// `Slice` တစ်ခုကိုစတင်သောအခါသင်သည် `phantom` အတွက် `PhantomData` တန်ဖိုးကိုရိုးရှင်းစွာဖြည့်သွင်းပါ။
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## အသုံးမပြုတဲ့ type ကို parameters တွေကို
///
/// တစ်ခါတစ်ရံတွင်သင်သည် "tied" မှ struct တစ်ခု၏ဒေတာအမျိုးအစားကိုညွှန်ပြသောအသုံးမပြုသောအမျိုးအစား parameters များကိုရှိသည်၊ ထိုအချက်အလက်သည် struct ၏ဖွဲ့စည်းပုံတွင်မတွေ့ရသော်လည်းဖြစ်တတ်သည်။
/// ဤတွင်ဒီ [FFI] နှင့်အတူပေါ်ပေါက်ဘယ်မှာဥပမာတစ်ခုဖြစ်ပါတယ်။
/// အဆိုပါနိုင်ငံခြား interface ကိုကွဲပြားခြားနားသောအမျိုးအစားများ Rust တန်ဖိုးများကိုရည်ညွှန်းဖို့အမျိုးအစား `*mut ()` ၏လက်ကိုင်ကိုအသုံးပြုသည်။
/// ကျနော်တို့ကလက်ကိုင်ထုပ်သော struct `ExternalResource` အပေါ်တစ်ဦး Phantom type ကို parameter သည်သုံးပြီး Rust type ကိုခြေရာခံ။
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## ပိုင်ဆိုင်မှုနှင့်တစ်စက်စစ်ဆေးမှုများ
///
/// အမျိုးအစား `PhantomData<T>` ၏လယ်ထည့်သွင်းခြင်းသင့်ရဲ့အမျိုးအစားအမျိုးအစား `T` ၏ဒေတာကိုပိုင်ဆိုင်ကြောင်းဖော်ပြသည်။ဒီအလှည့်၌သင်တို့၏အမျိုးအစားကျဆင်းသွားသောအခါကအမျိုးအစား `T` တစ်ဦးသို့မဟုတ်ထိုထက်ပိုသာဓက drop စေခြင်းငှါဆိုလို။
/// ၎င်းသည် Rust compiler ၏ [drop check] ခွဲခြမ်းစိတ်ဖြာမှုနှင့်သက်ဆိုင်သည်။
///
/// အကယ်၍ သင်၏ struct သည်အမှန်တကယ် `T` အမျိုးအစားဒေတာများကိုမပိုင်ဆိုင်ပါကပိုင်ဆိုင်မှုကိုဖော်ပြရန်မဟုတ်ပါ (ဥပမာသက်တမ်းမရှိပါက) `PhantomData<&'a T>` (ideally) သို့မဟုတ် `PhantomData<*const T>` ကဲ့သို့သောအညွှန်းအမျိုးအစားကိုအသုံးပြုခြင်းသည်ပိုကောင်းသည်။
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// compiler-ပြည်တွင်းရေး trait enum ခွဲခြားဆက်ဆံမှုအမျိုးအစားကိုညွှန်ပြလေ့ရှိတယ်။
///
/// ဤသည် trait အလိုအလျှောက်တိုင်းအမျိုးအစားများအတွက်အကောင်အထည်ဖော်နေသည်နှင့် [`mem::Discriminant`] မှမဆိုအာမခံချက်များကိုထည့်သွင်းမထားဘူး။
/// ဒါဟာ `DiscriminantKind::Discriminant` နှင့် `mem::Discriminant` အကြား transmute မှ ** ** undefined အပြုအမူဖြစ်ပါတယ်။
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// `mem::Discriminant` မှလိုအပ်သော trait bounds ကိုကျေနပ်ရောင့်ရဲစေမည့်ခွဲခြားဆက်ဆံမှုအမျိုးအစား။
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// compiler-ပြည်တွင်းရေး trait ပေမယ့်မသွယ်ဝိုက်သောအားဖွငျ့, အမျိုးအစားပြည်တွင်းရွှေ့ပြောင်းဆို `UnsafeCell` ပါရှိသည်ရှိမရှိဆုံးဖြတ်ရန်အသုံးပြုခဲ့သည်။
///
/// ဒီအကြောင်းအမျိုးအစားတစ်ခု `static` ဖတ်ရန်အတွက်သာငြိမ်မှတ်ဉာဏ်သို့မဟုတ် writable ငြိမ်မှတ်ဉာဏ်ထဲတွင်နေရာဖြစ်ပါတယ်ရှိမရှိဥပမာ, သက်ရောက်သည်။
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// လုံခြုံစွာ Taskbar မှာအရင်ကမရှိသေးတဲ့ခံရပြီးနောက်ပြောင်းရွှေ့နိုင်အမျိုးအစားများ။
///
/// Rust ကိုယ်နှိုက်တွင်ရွေ့ပြောင်းနိုင်သောအမျိုးအစားများမရှိပါ။ ရွေ့လျားခြင်း (ဥပမာ assignment သို့မဟုတ် [`mem::replace`]) မှတဆင့်ရွေ့လျားခြင်းကိုအမြဲတမ်းလုံခြုံသည်ဟုမှတ်ယူသည်။
///
/// အဆိုပါ [`Pin`][Pin] အမျိုးအစားအမျိုးအစားစနစ်ကတဆင့်ရွေ့လျားကာကွယ်တားဆီးဖို့အစားအသုံးပြုသည်။ညွှန်ပြ `P<T>` ထဲကပြောင်းရွှေ့ရနိုင်မှာမဟုတ်ဘူး wrapper အတွက် [`Pin<P<T>>`][Pin] ပတ်ရစ်။
/// တစ်လအပေါ်ပိုမိုသောအချက်အလက်များများအတွက် [`pin` module] စာရွက်စာတမ်းများကိုကြည့်ပါ။
///
/// `T` များအတွက် `Unpin` trait အကောင်အထည်ဖော်ထို့နောက်ထိုကဲ့သို့သော [`mem::replace`] အဖြစ်လုပ်ဆောင်ချက်များကိုနှင့်အတူ [`Pin<P<T>>`][Pin] ထဲက `T` ရွေ့လျားခွင့်ပြုထားတဲ့အမျိုးအစား, ချွတ်တစ်လ၏ကန့်သတ်အမိန့်ရုပ်သိမ်းပြီ။
///
///
/// `Unpin` Non-Taskbar မှာအရင်ကမရှိသေးတဲ့ဒေတာအားလုံးကိုမှာအဘယ်သူမျှမအကျိုးဆက်ရှိပါတယ်။
/// အထူးသဖြင့်, [`mem::replace`] ပျော်ရွှင်စွာ (မဖွင့်သည့်အခါ `T: Unpin` ဆို `&mut T` များအတွက်အလုပ်လုပ်တယ်) `!Unpin` data တွေကိုလှုံ့ဆော်ပေး။
/// သင် *ဒီစနစ်အလုပ်စေသည်ကားအဘယ်သို့ကြောင်းကိုအဘို့အလိုခြင်းနှင့်* အ `&mut T` မရနိုငျသောကွောငျ့သို့သော်သင်တစ်ဦး [`Pin<P<T>>`][Pin] အတွင်းအပြင်ပတ်ရစ်အချက်အလက်ပေါ် [`mem::replace`] မသုံးနိုငျသညျ။
///
/// ဒီဒီတော့ဥပမာ, သာ `Unpin` အကောင်အထည်ဖော်အမျိုးအစားများအပေါ်ပြုနိုင်သည်
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // ကျနော်တို့ `mem::replace` ခေါ်ဆိုရန် mutable ရည်ညွှန်းလိုပါတယ်။
/// // ကျနော်တို့ `Pin::deref_mut` သွန်းလောင်းပေး (implicitly) အားဖြင့်ထိုကဲ့သို့သောရည်ညွှန်းရယူနိုင်ပါသည်, သို့သော် `String` `Unpin` အကောင်အထည်ဖော်ဆောင်ရွက်နေသောဘာဖြစ်လို့လဲဆိုတော့သာဖြစ်နိုင်ပါတယ်။
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// ဤသည် trait ကိုအလိုအလျောက်နီးပါးတိုင်းအမျိုးအစားများအတွက်အကောင်အထည်ဖော်နေသည်။
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// `Unpin` အကောင်အထည်ဖော်မတစ်ဦးကအမှတ်အသားအမျိုးအစား။
///
/// အမျိုးအစားတစ်ဦး `PhantomPinned` ပါရှိသည်ပါကပုံမှန်အားဖြင့် `Unpin` အကောင်အထည်ဖော်မည်မဟုတ်။
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// စရိုက်အမျိုးအစားများအတွက် `Copy` ၏အကောင်အထည်ဖော်မှု။
///
/// Rust တွင်ဖော်ပြထားခြင်းမရှိသောလုပ်ဆောင်ချက်များသည် `rustc_trait_selection` ရှိ `traits::SelectionContext::copy_clone_conditions()` တွင်အကောင်အထည်ဖော်သည်။
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// shared ကိုးကားကူးယူပေမယ် mutable ကိုးကား * * မတတျနိုငျရနိုင်!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}