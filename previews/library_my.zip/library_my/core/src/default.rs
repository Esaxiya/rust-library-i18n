//! အဓိပ္ပါယ်ရှိသောပုံမှန်တန်ဖိုးများရှိနိုင်သောအမျိုးအစားများအတွက် `Default` trait

#![stable(feature = "rust1", since = "1.0.0")]

/// အမျိုးအစားတစ်ဦးအသုံးဝင်သောက default value ကိုပေးခြင်းများအတွက်တစ်ဦးက trait ။
///
/// တခါတရံမှာ, သင်က default value ကိုအချို့ကြင်နာပြန်လဲကျချင်နှင့်အထူးသဖြင့်ကကဘာလဲဆိုတာဂရုမစိုက်ကြဘူး။
/// ဤသည်ရွေးချယ်စရာအစုတခုသတ်မှတ်ကြောင်း `struct`s နှင့်အတူမကြာခဏတက်လာ:
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// ကျွန်ုပ်တို့သည်အချို့သောပုံမှန်တန်ဖိုးများကိုမည်သို့သတ်မှတ်နိုင်သနည်း။သင် `Default` ကိုသုံးနိုင်သည်။
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// ယခုသင်သည်ပုံမှန်တန်ဖိုးအားလုံးရရှိသည်။Rust အမျိုးမျိုးသော Primitive အမျိုးအစားများများအတွက် `Default` အကောင်အထည်ဖော်ဆောင်ရွက်နေသော။
///
/// အကယ်၍ သင်သည်ရွေးစရာတစ်ခုကို ထပ်မံ၍ override လုပ်လိုသော်လည်းအခြား defaults ကိုဆက်လက်ထားရှိလိုလျှင်-
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// အမျိုးအစားရဲ့လယ်ကွင်းအပေါငျးတို့သ `Default` အကောင်အထည်ဖေါ်လျှင်ဒီ trait `#[derive]` နှငျ့အသုံးပွုနိုငျသညျ။
/// `derive`d သောအခါ, ၎င်းသည်တစ်ခုချင်းစီကို field ရဲ့အမျိုးအစားအတွက် default value ကိုသုံးပါလိမ့်မယ်။
///
/// ## `Default` ကိုမည်သို့အကောင်အထည်ဖော်နိုင်မည်နည်း။
///
/// ကို default ဖြစ်သင့်ကြောင်းကိုသင်၏အမျိုးအစား၏တန်ဖိုးကို return ပွနျသော `default()` နည်းလမ်းတစ်ခုအကောင်အထည်ဖော်မှုသည်:
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// အမျိုးအစားတစ်ခုအတွက် "default value" ကိုပြန်ပို့သည်။
    ///
    /// default တန်ဖိုးများကိုမကြာခဏကနဦးတန်ဖိုးဝိသေသလက္ခဏာတန်ဖိုးကို, ဒါမှမဟုတ်တစ်ဦးက default အဖြစ်အသိပါစေခြင်းအလိုငှါအရာအားလုံးထက်အချို့ကိုမျိုးရှိပါတယ်။
    ///
    ///
    /// # Examples
    ///
    /// built-in ကို default တန်ဖိုးများကိုအသုံးပြုခြင်း:
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// သင့်ကိုယ်ပိုင် Making:
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// `Default` trait အရအမျိုးအစား၏ပုံမှန်တန်ဖိုးကိုပြန်ပို့ပါ။
///
/// အိမ်ပြန်ရန်အမျိုးအစားအခြေအနေတွင်ထံမှပေါ်မူတည်ပြီးလျက်ရှိ၏ဒီ `Default::default()` ညီမျှပေမယ့်အမျိုးအစားမှတိုတောင်းသည်။
///
/// ဥပမာ:
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// trait `Default` ၏အကျိုးသက်ရောက်မှုကိုထုတ်လုပ်သည့် macro ကိုရယူပါ။
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }