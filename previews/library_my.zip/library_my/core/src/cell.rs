//! mutable ကွန်တိန်နာ Shareable ။
//!
//! Rust မှတ်ဉာဏ်လုံခြုံမှုသည်ဤနည်းဥပဒေအပေါ်အခြေခံသည်။ အရာဝတ္ထု `T` တစ်ခုအရအောက်ပါတို့မှတစ်ခုသာရှိသည်။
//!
//! - (စ **aliasing အဖြစ်လူသိများ**) သည်အရာဝတ္ထုမှအတော်ကြာမပြောင်းလဲနိုင်သောအရာများကိုးကား (`&T`) ရှိခြင်း။
//! - အရာဝတ္ထုတစ်ခုအတွက် mutable ရည်ညွှန်းချက်တစ်ခု (`&mut T`)(**mutability** ဟုလည်းလူသိများသည်) ရှိခြင်း။
//!
//! ၎င်းကို Rust compiler မှပြဌာန်းထားသည်။သို့သော်၊ ဤစည်းမျဉ်းသည်ပြောင်းလွယ်ပြင်လွယ်မရှိသောအခြေအနေများရှိသည်။တခါတရံတွင်၎င်းသည်အရာဝတ္ထုတစ်ခုအားရည်ညွှန်းမှုမျိုးစုံပြုလုပ်ရန်လိုအပ်သော်လည်း၎င်းကိုပြောင်းလဲရန်လိုအပ်သည်။
//!
//! Shareable mutable ကွန်တိန်နာပင် aliasing ၏ရှေ့တော်၌, တစ်ဦးထိန်းချုပ်ထားထုံးစံ၌ mutability ခွင့်မတည်ရှိ။[`Cell<T>`] နှင့် [`RefCell<T>`] နှစ်ခုစလုံးသည်ယင်းကိုတစ်ခုတည်းသောကြိုးဖြင့်ပြုလုပ်နိုင်သည်။
//! သို့သော် `Cell<T>` မဟုတ်သလို `RefCell<T>` မချည်အန္တရာယ်ကင်း (သူတို့ [`Sync`] အကောင်အထည်ဖေါ်ကြဘူး) ဖြစ်ကြသည်။
//! သငျသညျမျိုးစုံချည်အကြား aliasing နှင့် mutation လုပ်ဖို့လိုအပ်ပါက [`Mutex<T>`], [`RwLock<T>`] သို့မဟုတ် [`atomic`] အမျိုးအစားများကိုသုံးနိုင်သည်။
//!
//! `Cell<T>` နှင့် `RefCell<T>` အမျိုးအစားများ၏တန်ဖိုးများကိုမျှဝေထားသောရည်ညွှန်းချက်များ (ဥပမာ-
//! သာမန် `&T` type) Rust အမျိုးအစားများသည်ထူးခြားသော (`&mut T`) ကိုးကားချက်များမှသာပြောင်းလဲနိုင်သည်။
//! `Cell<T>` နှင့် `RefCell<T>` တို့သည် 'အစဉ်အလာပြောင်းလဲခြင်း' ကိုပေးသည်၊ အမွေဆက်ခံထားသည့် mutability ကိုပြသသည့် Rust အမျိုးအစားများနှင့်မတူသည်
//!
//! `Cell<T>` နှင့် `RefCell<T>`: cell အမျိုးအစားများနှစ်ခုအရသာအတွက်လာ။`Cell<T>` သည် `Cell<T>` အတွင်းနှင့်အပြင်သို့တန်ဖိုးများကိုရွေ့လျားခြင်းဖြင့်အတွင်းပိုင်းပြောင်းလဲမှုများကိုပြုလုပ်သည်။
//! ကိုးကားချက်များကိုအစားတန်ဖိုးများကိုအသုံးပြုရန်အတွက် mutating မတိုင်မီ write lock ကိုရယူရန် `RefCell<T>` type ကိုအသုံးပြုရမည်။`Cell<T>` သည်လက်ရှိအတွင်းပိုင်းတန်ဖိုးကိုပြန်လည်ထုတ်ယူရန်နည်းလမ်းများကိုထောက်ပံ့ပေးသည်-
//!
//!  - [`Copy`] အကောင်အထည်ဖော်ရန်ကြောင်းအမျိုးအစားများအဘို့, [`get`](Cell::get) နည်းလမ်းလက်ရှိအတွင်းပိုင်းတန်ဖိုးကိုရယူ။
//!  - [`Default`] ကိုအကောင်အထည်ဖော်သောအမျိုးအစားများအတွက် [`take`](Cell::take) နည်းလမ်းသည်လက်ရှိအတွင်းပိုင်းတန်ဖိုးကို [`Default::default()`] ဖြင့်အစားထိုးပြီးအစားထိုးတန်ဖိုးကိုပြန်လည်ပေးသည်။
//!  - အားလုံးအမျိုးအစားများအတွက်, [`replace`](Cell::replace) နည်းလမ်းသည်လက်ရှိအတွင်းပိုင်းတန်ဖိုးကိုအစားထိုးခြင်းနှင့်အစားထိုးတန်ဖိုးကိုပြန်လည်ရောက်ရှိခြင်းနှင့် [`into_inner`](Cell::into_inner) နည်းလမ်း `Cell<T>` စားသုံးနှင့်အတွင်းပိုင်းတန်ဖိုးကိုပြန်လည်ရောက်ရှိ။
//!  ထို့အပြင် [`set`](Cell::set) နည်းလမ်းသည်အတွင်းတန်ဖိုးကိုအစားထိုးပြီးအစားထိုးတန်ဖိုးကိုကျဆင်းစေသည်။
//!
//! `RefCell<T>` တစျခုအတွင်းတန်ဖိုးယာယီ, သီးသန့်, mutable access ကိုတောင်းခံနိုင်သည်ဟုဆိုထားသည်မထွက်ရလုပ်ငန်းစဉ် '' ပြောင်းလဲနေသောငွေချေး '' အကောင်အထည်ဖော်နိုင်ရန် Rust ရဲ့ဘဝသက်တမ်းကိုအသုံးပြုသည်။
//! `RefCell အတွက်ငှားသည်<T>`s ကိုလုံးဝ compile လုပ်ခြင်းအချိန်တွင် statically ခြေရာခံနေကြရသော Rust ရဲ့ဇာတိကိုကိုးကားအမျိုးအစားများနှင့်မတူဘဲ, 'runtime မှာ' 'ခြေရာခံနေကြသည်။
//! `RefCell<T>` ချေးပြောင်းလဲနေသောကြောင့်ကြောင့်ပြီးသား mutably ချေးသောတန်ဖိုးကိုချေးဖို့ကြိုးစားဖြစ်နိုင်၏,ဒီဖြစ်ပျက်အခါကချည် panic ဖြစ်ပေါ်စေသည်။
//!
//! # အတွင်းပိုင်း mutability ရွေးချယ်ဖို့လိုက်တဲ့အခါ
//!
//! တန်ဖိုးတစ်ခုအား mutate လုပ်ရန်ထူးခြားသောလက်လှမ်းမီမှုရှိရမည်ဖြစ်သည့်ပိုမိုအသုံးများသောအမွေဆက်ခံရသော mutability သည် Rust သည် pointer aliasing အကြောင်းကို crash bug များအားတားဆီးပေးပြီးအဓိကကျသောအကြောင်းပြချက်ကိုဖွင့်ပေးသော key language element တစ်ခုဖြစ်သည်။
//! ယင်းကြောင့်အမွေဆက်ခံထားသည့် mutability သည်ပိုမိုနှစ်သက်ပြီးအတွင်းစိတ်ပြောင်းလဲခြင်းသည်နောက်ဆုံးနည်းလမ်းတစ်ခုဖြစ်သည်။
//! ဆဲလ်အမျိုးအစားများသည်၎င်းကိုမတားဆီးနိုင်သည့်နေရာတွင် mutation ကို enable လုပ်သောကြောင့်အတွင်းပိုင်းပြောင်းလဲခြင်းသည်သင့်လျော်နိုင်သည့်အခါသို့မဟုတ် * အသုံးပြုရမည့်အချိန်များလည်းရှိသည်။
//!
//! * တစ်ခုခုမပြောင်းလဲနိုင်သောအရာများ၏ mutability 'inside' မိတ်ဆက်ခြင်း
//! * ယုတ္တိဗေဒ-မပြောင်းလဲနိုင်သောအရာများနည်းလမ်းများ၏အကောင်အထည်ဖော်မှုအသေးစိတ်ကို။
//! * [`Clone`] ၏အကောင်အထည်ဖော်မှု mutating ။
//!
//! ## တစ်ခုခုမပြောင်းလဲနိုင်သောအရာများ၏ mutability 'inside' မိတ်ဆက်ခြင်း
//!
//! များစွာသောမျှဝေထားသောစမတ် pointer အမျိုးအစားများဖြစ်သော [`Rc<T>`] နှင့် [`Arc<T>`] တို့ကပါတီများအကြားမျိုးပွား။ ခွဲဝေနိုင်သည့်ကွန်တိန်နာများကိုပေးသည်။
//! အဆိုပါပါရှိသောတန်ဖိုးများများပြား-aliased စေခြင်းငှါသောကြောင့်, သူတို့သာ `&` မဟုတ်ဘဲ `&mut` နှင့်အတူငှားရမ်းနိုင်ပါသည်။
//! ဆဲလ်များမရှိလျှင်ဤစမတ်ထောက်ပြသူများ၏အတွင်းပိုင်းရှိအချက်အလက်များကိုလုံးဝပြောင်းလဲပစ်ရန်မဖြစ်နိုင်ပါ။
//!
//! ဒါဟာ reintroduce mutability ဖို့က Shared pointer အမျိုးအစားများအတွင်း၌တစ်ဦး `RefCell<T>` ထားရန်ထို့နောက်အလွန်ဘုံင်:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // အဆိုပါပြောင်းလဲနေသောချေးငှါး၏အတိုင်းအတာကန့်သတ်မယ့်အသစ်ကပိတ်ပင်တားဆီးမှု Create
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // ကျနော်တို့က cache ကို၏ယခင်ချေးငှါးနယ်ပယ်ထဲကလဲကျမသွားပါစေခဲ့မယ်ဆိုရင်ထို့နောက်နောက်ဆက်တွဲချေးငှါးတစ်ပြောင်းလဲနေသောချည် panic ဖြစ်ပေါ်စေလိမ့်မယ်လို့မှတ်ချက်။
//!     //
//!     // ၎င်းသည် `RefCell` ကိုအသုံးပြုခြင်း၏အဓိကအန္တရာယ်ဖြစ်သည်။
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! ဒီဥပမာက `Rc<T>` ကိုသုံးတာမဟုတ်ဘဲ `Arc<T>` ကိုသုံးတာပါ။`RefCell<T>`တစ်ခုတည်းသောချည်နှောင်ထားသောအခြေအနေများအတွက်ဖြစ်သည်။သင်တစ်ဦးပေါင်းစုံ-Threading အခြေအနေမှာ shared mutability လိုအပ်တယ်ဆိုရင် [`RwLock<T>`] သို့မဟုတ် [`Mutex<T>`] သုံးပြီးစဉ်းစားပါ။
//!
//! ## ယုတ္တိနည်းအ-မပြောင်းလဲနိုင်သောအရာများနည်းလမ်းအကောင်အထည်ဖော်ရေးအသေးစိတ်ကို
//!
//! ရံဖန်ရံခါတွင် "under the hood" တွင်ဖြစ်ပေါ်နေသော mutation ဖြစ်ပေါ်နေကြောင်း API တစ်ခုတွင်ဖော်ထုတ်ရန်မလိုလားပါ။
//! ယုတ္တိနည်းစစ်ဆင်ရေးမပြောင်းလဲနိုင်သောအရာများပင်ဖြစ်သည်, ဒါပေမယ့်ဥပမာ mutation ဖျော်ဖြေဖို့တပ်ဖွဲ့တွေအကောင်အထည်ဖော်မှုသိမ်းဆည်းထားသောဘာဖြစ်လို့လဲဆိုတော့ဒါကဖြစ်မည်အကြောင်း,သို့မဟုတ်ပါကမူလက `&self` ကိုယူရန် trait နည်းလမ်းကိုအကောင်အထည်ဖော်ရန်သင် mutation ကိုအသုံးပြုရမည်။
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // စျေးကြီးသောကွန်ပျူတာဒီမှာသွား
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## `Clone` ၏အကောင်အထည်ဖော်မှု mutating
//!
//! မပြောင်းလဲနိုင်သောအရာများဖြစ်ပေါ်လာကြောင်းစစ်ဆင်ရေးများအတွက်ပုန်းခို mutability: ဒီရိုးရှင်းစွာအထူးပေမယ့်ယခင်၏ဘုံ, အမှုဖြစ်ပါတယ်။
//! [`clone`](Clone::clone) နည်းလမ်းသည်အရင်းအမြစ်တန်ဖိုးကိုမပြောင်းလဲနိုင်ဟုမျှော်လင့်ရသည်၊ `&self` ကိုယူမည်မဟုတ်၊ `&mut self` ကိုယူမည်
//! ထို့ကြောင့် `clone` method တွင်ဖြစ်ပေါ်သောမည်သည့် mutation မျိုးမဆိုဆဲလ်အမျိုးအစားများကိုအသုံးပြုရမည်။
//! ဥပမာအားဖြင့် [`Rc<T>`] သည်၎င်း၏ရည်ညွှန်းအရေအတွက်ကို `Cell<T>` အတွင်းတွင်ထိန်းသိမ်းသည်။
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// တစ် ဦး ကပြောင်းလဲနေတဲ့မှတ်ဉာဏ်တည်နေရာ။
///
/// # Examples
///
/// ဒီဥပမာထဲမှာ, သငျသညျ `Cell<T>` အနေနဲ့မပြောင်းလဲနိုင်သောအရာများ struct အတွင်းပိုင်း mutation ဖွကြောင်းတွေ့နိုင်ပါသည်။
/// တစ်နည်းအားဖြင့်၎င်းသည် "interior mutability" ကိုအသုံးပြုနိုင်သည်။
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // : ERROR `my_struct` မပြောင်းလဲနိုင်သောအရာများဖြစ်ပါသည်
/// // my_struct.regular_field =new_value;
///
/// // အလုပ်များ-`my_struct` မပြောင်းလဲနိုင်သောအရာများရှိသော်လည်း `special_field` သည် `Cell` ဖြစ်သည်။
/// // အရာအမြဲ mutated နိုင်ပါသည်
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// ပိုပြီးများအတွက် [module-level documentation](self) ကိုကြည့်ပါ။
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// T. အတွက် `Default` တန်ဖိုးရှိသည့် `Cell<T>` တစ်ခုကိုဖန်တီးသည်။
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// ပေးထားသောတန်ဖိုးပါဝင်သော `Cell` အသစ်တစ်ခုကိုဖန်တီးသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// ပါ ၀ င်သည့်တန်ဖိုးကိုသတ်မှတ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// ဆဲလ်နှစ်ခု၏တန်ဖိုးများကိုလဲလှယ်ပေးသည်။
    /// `std::mem::swap` နဲ့ကွာခြားချက်ကတော့ဒီ function က `&mut` reference မလိုအပ်ပါဘူး။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // လုံခြုံမှု-သီးခြားအကြောင်းအရာများမှခေါ်ဆိုပါကအန္တရာယ်ရှိနိုင်သည်၊ သို့သော် `Cell`
        // `!Sync` ဆိုတာဒါမဟုတ်ပါဘူး။
        // `Cell` အခြားဘာမျှမကဤ `Cell`s ၏တစ်ခုခုသို့ညွှန်ပြပါလိမ့်မည်သေချာစေသည်ကတည်းကဤသည်ကိုလည်းမည်သည့်ထောက်ပြခှငျ့မပါလိမ့်မယ်။
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// `val` နှင့်အတူပါရှိသောတန်ဖိုးကိုအစားထိုးခြင်း, ဟောင်းကိုထိန်းချုပ်တန်ဖိုးကို return ပွနျ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // လုံခြုံမှု-အကယ်၍ သီးခြားချည်နှောင်ခြင်းမှခေါ်လျှင်ဒေတာပြိုင်ပွဲများဖြစ်ပေါ်စေသည်။
        // ဒါပေမယ့် `Cell` `!Sync` ဖြစ်ပါတယ်ဒါကြောင့်ဒီလိုဖြစ်လိမ့်မည်မဟုတ်ပေ။
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// တန်ဖိုး Unwraps ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// ပါ ၀ င်သည့်တန်ဖိုးမိတ္တူတစ်စောင်ကိုပြန်ပို့သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // လုံခြုံမှု-အကယ်၍ သီးခြားချည်နှောင်ခြင်းမှခေါ်လျှင်ဒေတာပြိုင်ပွဲများဖြစ်ပေါ်စေသည်။
        // ဒါပေမယ့် `Cell` `!Sync` ဖြစ်ပါတယ်ဒါကြောင့်ဒီလိုဖြစ်လိမ့်မည်မဟုတ်ပေ။
        unsafe { *self.value.get() }
    }

    /// ပါ ၀ င်သည့် value ကို function ကို သုံး၍ value အသစ်ကို return ပြန်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// ဤဆဲလ်ရှိအခြေခံဒေတာများကိုညွှန်ပြသည့်အညွှန်းတစ်ခုကိုပြန်ပို့သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// ပြန်နောက်ခံဒေတာတစ်ခု mutable ကိုကိုးကား။
    ///
    /// ဤခေါ်ဆိုမှုသည် `Cell` ကို (compileing အချိန်တွင်) အပြန်အလှန်အားဖြင့်ငှားရမ်းသည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// တစ် ဦး `&mut T` ကနေ `&Cell<T>` Returns
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // လုံခြုံမှု: `&mut` ထူးခြားတဲ့ access ကိုသေချာ။
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// ဆဲလ်၏တန်ဖိုးကိုယူ, `Default::default()` ၎င်း၏နေရာ၌ထားခဲ့ပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// တစ်ဦး `&Cell<[T]>` ကနေပြန်လာပြီးတဲ့ `&[Cell<T>]`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // လုံခြုံမှု: `Cell<T>` တွင် `T` ကဲ့သို့မှတ်ဉာဏ်အပြင်အဆင်နှင့်အတူတူဖြစ်သည်။
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// dynamically check လုပ်ထားချေးစည်းမျဉ်းများနှင့်အတူတစ် ဦး mutable မှတ်ဉာဏ်တည်နေရာ
///
/// ပိုပြီးများအတွက် [module-level documentation](self) ကိုကြည့်ပါ။
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// [`RefCell::try_borrow`] မှပြန်လာသောအမှားတစ်ခု။
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// [`RefCell::try_borrow_mut`] အားဖြင့်ပြန်လာသောအမှား။
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// positive တန်ဖိုးများကိုတက်ကြွစွာ `Ref` ၏နံပါတ်ကိုယ်စားပြုသည်။အနုတ်လက္ခဏာတန်ဖိုးများကိုတက်ကြွစွာ `RefMut` ၏နံပါတ်ကိုယ်စားပြုသည်။
// သူတို့ကွဲပြားရန်ရည်ညွှန်းလျှင်အကွိမျမြားစှာ `RefMut`s တစ်ခုသာ `RefCell` (ကအချပ်၏ဥပမာကွဲပြားခြားနားသောပ္ပံ) ၏အစိတ်အပိုင်းများကို nonoverlapping တစ်အချိန်တွင်တက်ကြွစေနိုင်သည်။
//
// `Ref` နှင့် `RefMut` နှစ်ခုလုံးသည်အရွယ်အစားနှစ်မျိုးရှိသဖြင့် `usize` အကွာအဝေး၏ထက်ဝက်ခန့်သည်ပြည့်လျှံနေသည့်အတွက် `Ref`s`နှင့်`RefMut` များလုံလုံလောက်လောက်ရှိနိုင်ဖွယ်မရှိပါ။
// ထို့ကြောင့် `BorrowFlag` သည်ဘယ်တော့မျှလျတ်လျှံကျနေမည်မဟုတ်ပါ။
// တစ်ဦးရောဂါဗေဒအစီအစဉ်ကိုထပ်တလဲလဲ mem::forget `Ref`s သို့မဟုတ်`RefMut`s ထို့နောက်ဖန်တီးနိုင်အဖြစ်သို့ရာတွင်ဤတစ်အာမခံချက်မဟုတ်ပါဘူး။
// ထို့ကြောင့်အားလုံးကုဒ်အတိအလင်း unsafety ကိုရှောင်ရှားနိုင်ရန်အတွက်လျတ်နှင့် underflow များအတွက်စစ်ဆေးရမည်, သို့မဟုတ်လျတ်သို့မဟုတ် underflow ဖြစ်ပျက်သောအဖြစ်အပျက်အတွက်မှန်ကန်စွာအနည်းဆုံးပြုမူ (ဥပမာ BorrowRef::new ကြည့်ပါ) ။
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// `value` ပါဝင်သည့် `RefCell` အသစ်တစ်ခုကိုဖန်တီးသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// အဆိုပါထုပ်တန်ဖိုးကိုပြန်လာ, `RefCell` စားသုံးသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // ဒီ function ကိုတနျဖိုးအားဖြင့် `self` (ထို `RefCell`) ကြာကတည်းက compiler statically ကြောင့်လက်ရှိချေးမဟုတ်ကြောင်းစစ်ဆေးပေးတယ်။
        //
        self.value.into_inner()
    }

    /// တစ်ခုခုကိုတဦးတည်း deinitializing မပါဘဲ, ဟောင်းတန်ဖိုးကိုပြန်အသစ်တစ်ခုတဦးတည်းနှင့်အတူပတ်ရစ်တန်ဖိုးကိုအစားထိုးထားသည်။
    ///
    ///
    /// ဤလုပ်ဆောင်ချက်သည် [`std::mem::replace`](../mem/fn.replace.html) နှင့်ကိုက်ညီသည်။
    ///
    /// # Panics
    ///
    /// တန်ဖိုးကိုလက်ရှိချေးလျှင် Panics ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// ပတ်ထားသောတန်ဖိုးကို `f` မှတွက်ချက်သောတန်ဖိုးအသစ်တစ်ခုဖြင့်အစားထိုးသည်။ တန်ဖိုးဟောင်းကို ပြန်၍ မရပါ။
    ///
    ///
    /// # Panics
    ///
    /// တန်ဖိုးကိုလက်ရှိချေးလျှင် Panics ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// တစ်ခုခုကို deinitializing မပါဘဲ, ပတ်ရစ်တန်ဖိုးကို `self` ၏ပတ်ရစ်တန်ဖိုးကိုနှင့်အတူ `self` ဖလှယ်။
    ///
    ///
    /// ဒီ function [`std::mem::swap`](../mem/fn.swap.html) ကိုက်ညီ။
    ///
    /// # Panics
    ///
    /// တစ်ခုခုကို `RefCell` အတွက်တန်ဖိုးလက်ရှိချေးလျှင် Panics ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// မပြောင်းလဲနိုင်သောအရာများသည်ပတ်ရစ်တန်ဖိုးကိုငှားရမ်း။
    ///
    /// ပြန်လာသော `Ref` နယ်ပယ်မထွက်မချင်းချေးငှားသည်။
    /// အကွိမျမြားစှာမပြောင်းလဲနိုင်သောအရာများချေးတစ်ချိန်တည်းမှာထွက်ယူနိုင်ပါသည်။
    ///
    /// # Panics
    ///
    /// တန်ဖိုးလက်ရှိ mutably ချေးလျှင် Panics ။
    /// non-စိုးရိမ်မမူကွဲအဘို့, [`try_borrow`](#method.try_borrow) ကိုအသုံးပြုပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// panic တခုရဲ့ဥပမာ:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// တန်ဖိုးသည်လက်ရှိတွင်အပြန်အလှန်အားဖြင့်အပြန်အလှန်ချေးယူလျှင်အမှားတစ်ခုပြန်လာသည်, ထုပ်ထားတန်ဖိုးကိုမြဲမြံစွာငှား။
    ///
    ///
    /// ပြန်လာသော `Ref` နယ်ပယ်မထွက်မချင်းချေးငှားသည်။
    /// အကွိမျမြားစှာမပြောင်းလဲနိုင်သောအရာများချေးတစ်ချိန်တည်းမှာထွက်ယူနိုင်ပါသည်။
    ///
    /// ဤသည် [`borrow`](#method.borrow) ၏ထိတ်လန့်စရာမဟုတ်သောမူကွဲဖြစ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // လုံခြုံမှု: `BorrowRef` သာမပြောင်းလဲနိုင်သောအရာများလက်လှမ်းရှိကွောငျးသေချာ
            // ချေးနေစဉ်တန်ဖိုးရန်။
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Mutably သည့်ပတ်ရစ်တန်ဖိုးကိုချေးငှားပါတယ်။
    ///
    /// ပြန်ချေးထားသော `RefMut` သို့မဟုတ် `RefMut`s မှထုတ်ယူသောထွက်ပေါက်အားလုံးသည်အထိငွေချေးယူနိုင်သည်။
    ///
    /// ဒီချေးငွေတက်ကြွနေစဉ်တန်ဖိုးကိုချေးလို့မရဘူး။
    ///
    /// # Panics
    ///
    /// တန်ဖိုးကိုလက်ရှိချေးလျှင် Panics ။
    /// non-စိုးရိမ်မမူကွဲအဘို့, [`try_borrow_mut`](#method.try_borrow_mut) ကိုအသုံးပြုပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// panic တခုရဲ့ဥပမာ:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// အဆိုပါထုပ်တန်ဖိုးကိုအပြန်အလှန်ငှားရမ်းခြင်း, တန်ဖိုးကိုလက်ရှိချေးယူလျှင်အမှားတစ်ခုပြန်လာ။
    ///
    ///
    /// ပြန်ချေးထားသော `RefMut` သို့မဟုတ် `RefMut`s မှထုတ်ယူသောထွက်ပေါက်အားလုံးသည်အထိငွေချေးယူနိုင်သည်။
    /// ဒီချေးငွေတက်ကြွနေစဉ်တန်ဖိုးကိုချေးလို့မရဘူး။
    ///
    /// ဤသည် [`borrow_mut`](#method.borrow_mut) ၏ထိတ်လန့်စရာမဟုတ်သောမူကွဲဖြစ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // လုံခြုံမှု: `BorrowRef` ထူးခြားတဲ့ access ကိုအာမခံ။
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// ဤဆဲလ်ရှိအခြေခံဒေတာများကိုညွှန်ပြသည့်အညွှန်းတစ်ခုကိုပြန်ပို့သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// ပြန်နောက်ခံဒေတာတစ်ခု mutable ကိုကိုးကား။
    ///
    /// ဤခေါ်ဆိုမှု (compile လုပ်ခြင်းအချိန်မှာ) mutably `RefCell` ငှါးဒါပြောင်းလဲနေသောစစ်ဆေးမှုများအဘို့မလိုအပ်လည်းမရှိ။
    ///
    /// သို့သော်သတိထားပါ-ဤနည်းလမ်းသည် `self` သည် mutable ဖြစ်သည်ဟုမျှော်လင့်သည်၊ ၎င်းသည် `RefCell` ကိုအသုံးပြုသောအခါယေဘူယျအားဖြင့်မဟုတ်ပါ။
    ///
    /// `self` mutable မပါလျှင်အစား [`borrow_mut`] နည်းလမ်းမှာကြည့်လိုက်ပါ။
    ///
    /// ဤနည်းလမ်းသည်အထူးအခြေအနေများအတွက်သာဖြစ်ပြီးသင်လိုချင်သောအရာမဟုတ်ကြောင်းသတိပြုပါ။
    /// သံသယများကိစ္စတွင်ခုနှစ်, အစား [`borrow_mut`] ကိုအသုံးပြုပါ။
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// အဆိုပါ `RefCell` ၏ချေးငှါးပြည်နယ်ပေါ်မှာပေါက်ကြားစောင့်၏အကျိုးသက်ရောက်မှု undo ။
    ///
    /// ဤခေါ်ဆိုမှုသည် [`get_mut`] နှင့်ဆင်တူသော်လည်းအထူးပြုပါသည်။
    /// ဒါဟာအဘယ်သူမျှမချေးမတည်ရှိပြီးတော့ shared ချေးခြေရာခံပြည်နယ်ရဖို့အတွက်သေချာစေရန် mutably `RefCell` ငှါး။
    /// အချို့သော `Ref` သို့မဟုတ် `RefMut` ချေးပေါက်ကြားခဲ့ကြပါလျှင်ဤသည်ကိုသက်ဆိုင်ရာဖြစ်ပါတယ်။
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// တန်ဖိုးသည်လက်ရှိတွင်အပြန်အလှန်အားဖြင့်အပြန်အလှန်ချေးယူလျှင်အမှားတစ်ခုပြန်လာသည်, ထုပ်ထားတန်ဖိုးကိုမြဲမြံစွာငှား။
    ///
    /// # Safety
    ///
    /// က `Ref` ပြန်လာမထားဘူးဘာလို့လဲဆိုတော့ `RefCell::borrow` မတူဘဲ, ဒီနည်းလမ်းကိုအရှင်နဂိုအတိုင်းချေးငှါးအလံထွက်ခွာမလုံခြုံသည်။
    /// ဤနည်းလမ်းဖြင့်ပြန်လာသောရည်ညွှန်းသည်အသက်ရှင်နေစဉ်အတွင်း `RefCell` ကိုအပြန်အလှန်ချေးယူခြင်းသည်အပြုအမူဖြစ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // လုံခြုံမှု-ဘယ်သူမှတက်တက်ကြွကြွစာမရေးတတ်ဘူးဆိုတာငါတို့စစ်ဆေးပါတယ်၊
            // ပြန်လာသောရည်ညွှန်းကိုအသုံးမ ၀ င်ခင်မည်သူမျှမရေးရန်သေချာစေရန်ခေါ်သူ၏တာဝန်ဖြစ်သည်။
            // ဒါ့အပြင် `self.value.get()` `self` ကပိုင်ဆိုင်တန်ဖိုးကိုရည်ညွှန်းသည်ဤသို့ `self` ၏တစ်သက်တာအဘို့အတရားဝင်ဖြစ်ဖို့အာမခံသည်။
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// ထုပ်ထားသောတန်ဖိုးကိုယူပြီး `Default::default()` ကိုနေရာတွင်ထားလိုက်သည်။
    ///
    /// # Panics
    ///
    /// တန်ဖိုးကိုလက်ရှိချေးလျှင် Panics ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// တန်ဖိုးလက်ရှိ mutably ချေးလျှင် Panics ။
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// တစ်ဦး `RefCell<T>` တီများအတွက် `Default` တန်ဖိုးကိုအတူဖန်တီးလိုက်တဲ့
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// တစ်ခုခုကို `RefCell` အတွက်တန်ဖိုးလက်ရှိချေးလျှင် Panics ။
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// တစ်ခုခုကို `RefCell` အတွက်တန်ဖိုးလက်ရှိချေးလျှင် Panics ။
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// တစ်ခုခုကို `RefCell` အတွက်တန်ဖိုးလက်ရှိချေးလျှင် Panics ။
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// တစ်ခုခုကို `RefCell` အတွက်တန်ဖိုးလက်ရှိချေးလျှင် Panics ။
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// တစ်ခုခုကို `RefCell` အတွက်တန်ဖိုးလက်ရှိချေးလျှင် Panics ။
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// တစ်ခုခုကို `RefCell` အတွက်တန်ဖိုးလက်ရှိချေးလျှင် Panics ။
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// တစ်ခုခုကို `RefCell` အတွက်တန်ဖိုးလက်ရှိချေးလျှင် Panics ။
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // ချေးငှါး Incrementing သည်ဤကိစ္စများတွင် non-ဖတ်နေတန်ဖိုး (<=0) ဖြစ်ပေါ်နိုင်သည်
            // 1. ကျနော်တို့ကြောင့် Rust ရဲ့ရည်ညွှန်း aliasing စည်းမျဉ်းစည်းကမ်းတွေကိုတစ်ဖတ်ချေးငှါးခွင့်ပြုလို့မရဘူးဒါကြောင့်, ဆိုလိုသည်မှာရေးသားခြင်းချေးရှိပါတယ်, <0 င်ခဲ့
            // 2.
            // ၎င်းသည် isize::MAX (အများဆုံးဖတ်ရှုသည့်ငွေပမာဏ) ဖြစ်သည်။ isize::MIN (အများဆုံးရေးသားထားသောငွေပမာဏသည်) တွင်ရှိသည်။ ထို့ကြောင့် isize သည်အလွန်များစွာသောစာတမ်းများကိုကိုယ်စားမပြုနိုင်သောကြောင့်ကျွန်ုပ်တို့အပိုဆောင်းဖတ်ရန်ချေးငွေကိုခွင့်မပြုနိုင်ပါ။ mem::forget သည်ပုံမှန်လေ့ကျင့်မှုမဟုတ်သော `Ref`s ၏အနည်းငယ်သောအဆက်မပြတ်ပမာဏဖြစ်သည်။
            //
            //
            //
            //
            None
        } else {
            // ငွေချေးခြင်းများတိုးလာခြင်းကြောင့်ဤကိစ္စများတွင်စာဖတ်ခြင်းတန်ဖိုး (> 0) ဖြစ်ပေါ်နိုင်သည်။
            // 1. ဒါဟာချေးမခံခဲ့ရ ie,=0 ဖြစ်ခဲ့သည်, ငါတို့သည်ပထမဦးဆုံးဖတ်ချေးငှါးယူနေကြသည်
            // 2. ဆိုလိုသည်မှာ> 0 နှင့် <isize::MAX ဖြစ်သည်
            // အဲဒီမှာဖတ်နေငှားငှားရမ်းခြင်းနှင့် isize နောက်ထပ်ဖတ်ချေးငှားရှိခြင်းကိုကိုယ်စားပြုဖို့လုံလောက်တဲ့ကြီးမားသည်
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // ဤ Ref တည်ရှိခြင်းကြောင့်ငွေချေးခြင်းအလံသည်စာဖတ်ခြင်းဆိုင်ရာချေးငှားခြင်းဖြစ်ကြောင်းကျွန်ုပ်တို့သိသည်။
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // ကာကွယ်ဆေးတစ်အရေးအသားချေးငှါးသို့လျှံထံမှချေးငှါးတန်ပြန်။
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// `RefCell` အကွက်တစ်ခုရှိတန်ဖိုးတစ်ခုငှားရမ်းရည်ညွှန်းထုပ်။
/// `RefCell<T>` တစ်ခုမှမပြောင်းလဲနိုင်သောအရာများပါ ၀ င်သောတန်ဖိုးတစ်ခုအတွက်ထုပ်ပိုးခြင်းအမျိုးအစား။
///
/// ပိုပြီးများအတွက် [module-level documentation](self) ကိုကြည့်ပါ။
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// မိတ္တူတစ် `Ref` ။
    ///
    /// အဆိုပါ `RefCell` ပြီးသားမပြောင်းလဲနိုင်သောအရာများချေးဖြစ်တယ်, ဒါဒီပျက်ကွက်လို့မရပါဘူး။
    ///
    /// ၎င်းသည် `Ref::clone(...)` အဖြစ်အသုံးပြုရန်လိုအပ်သည့်ဆက်စပ်မှုတစ်ခုဖြစ်သည်။
    /// တစ်ဦးက `Clone` အကောင်အထည်ဖော်မှုတစ်ခုသို့မဟုတ်နည်းလမ်းတစ် `RefCell` ရဲ့ contents clone မှ `r.borrow().clone()` ၏ကျယ်ပြန့်သုံးစွဲခြင်းနှင့်အတူဝင်ရောက်စွက်ဖက်မယ်။
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// အဆိုပါချေးအချက်အလက်များ၏အစိတ်အပိုင်းတစ်ခုအသစ်တစ်ခု `Ref` စေသည်။
    ///
    /// အဆိုပါ `RefCell` ပြီးသားမပြောင်းလဲနိုင်သောအရာများချေးဖြစ်တယ်, ဒါဒီပျက်ကွက်လို့မရပါဘူး။
    ///
    /// ၎င်းသည် `Ref::map(...)` အဖြစ်အသုံးပြုရန်လိုအပ်သည့်ဆက်စပ်မှုတစ်ခုဖြစ်သည်။
    /// `Deref` မှတစ်ဆင့်အသုံးပြုသော `RefCell` ၏မာတိကာတစ်ခုတွင်အမည်တူနည်းလမ်းများကိုနည်းလမ်းတစ်ခုကအနှောင့်အယှက်ပေးလိမ့်မည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// ငှားရမ်းထားသောအချက်အလက်များ၏အစိတ်အပိုင်းတစ်ခုအတွက် `Ref` အသစ်တစ်ခုကိုပြုလုပ်သည်။
    /// ပိတ်သိမ်းမှု `None` ပြန်လာလျှင်မူရင်းကိုယ်ရံတော်တစ်ခု `Err(..)` အဖြစ်ပြန်ရောက်သည်။
    ///
    /// အဆိုပါ `RefCell` ပြီးသားမပြောင်းလဲနိုင်သောအရာများချေးဖြစ်တယ်, ဒါဒီပျက်ကွက်လို့မရပါဘူး။
    ///
    /// ၎င်းသည် `Ref::filter_map(...)` အဖြစ်အသုံးပြုရန်လိုအပ်သည့်ဆက်စပ်မှုတစ်ခုဖြစ်သည်။
    /// `Deref` မှတစ်ဆင့်အသုံးပြုသော `RefCell` ၏မာတိကာတစ်ခုတွင်အမည်တူနည်းလမ်းများကိုနည်းလမ်းတစ်ခုကအနှောင့်အယှက်ပေးလိမ့်မည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// တစ်ဦး `Ref` အဆိုပါချေးအချက်အလက်များ၏ကွဲပြားခြားနားသောအစိတ်အပိုင်းများအဘို့အမျိုးစုံ `Ref`s သို့ကိုစူး။
    ///
    /// အဆိုပါ `RefCell` ပြီးသားမပြောင်းလဲနိုင်သောအရာများချေးဖြစ်တယ်, ဒါဒီပျက်ကွက်လို့မရပါဘူး။
    ///
    /// ၎င်းသည် `Ref::map_split(...)` အဖြစ်အသုံးပြုရန်လိုအပ်သည့်ဆက်စပ်မှုတစ်ခုဖြစ်သည်။
    /// `Deref` မှတစ်ဆင့်အသုံးပြုသော `RefCell` ၏မာတိကာတစ်ခုတွင်အမည်တူနည်းလမ်းများကိုနည်းလမ်းတစ်ခုကအနှောင့်အယှက်ပေးလိမ့်မည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// နောက်ခံဒေတာကိုတစ်ဦးကိုကိုးကားသို့ converter ။
    ///
    /// နောက်ခံ `RefCell` ကို ထပ်မံ၍ ချေး ယူ၍ မရနိုင်ပါ။
    ///
    /// စဉ်ဆက်မပြတ်ကိုးကားထားသောရည်ညွှန်းချက်များထက်ပိုပြီးယိုစိမ့်ခြင်းသည်မကောင်းသောအကြံဖြစ်သည်။
    /// စုစုပေါင်းယိုစိမ့်မှုအနည်းငယ်သာဖြစ်ပွားပါက `RefCell` ကိုထပ်မံချေးယူနိုင်ပါသည်။
    ///
    /// ဤသည် `Ref::leak(...)` အဖြစ်အသုံးပြုခံရဖို့လိုအပ်ပါတယ်တစ်ခုဆက်စပ် function ကိုဖြစ်ပါတယ်။
    /// `Deref` မှတစ်ဆင့်အသုံးပြုသော `RefCell` ၏မာတိကာတစ်ခုတွင်အမည်တူနည်းလမ်းများကိုနည်းလမ်းတစ်ခုကအနှောင့်အယှက်ပေးလိမ့်မည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // ဤ Ref ကိုမေ့ခြင်းအားဖြင့်ကျွန်ုပ်တို့သည် RefCell ရှိငွေချေးကောင်တာသည်သက်တမ်း `'b` အတွင်း UNUSED သို့ပြန်သွားနိုင်မည်မဟုတ်ကြောင်းသေချာပါသည်။
        // ရည်ညွှန်းခြေရာခံခြင်းပြည်နယ်ကိုပြန်လည်ပြင်ဆင်ခြင်းအတွက်ချေး RefCell တစ်မူထူးခြားတဲ့ရည်ညွှန်းလိုအပ်ပေလိမ့်မည်။
        // မူရင်းဆဲလ်မှနောက်ထပ်ပြောင်းလဲနိုင်သောကိုးကားချက်များကို ဖန်တီး၍ မရပါ။
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// အဆိုပါချေးဒေတာ, ဥပမာတခု enum မူကွဲ၏အစိတ်အပိုင်းတစ်ခုအဘို့အသစ်တစ်ခု `RefMut` စေသည်။
    ///
    /// `RefCell` ကိုအပြန်အလှန်ချေးယူထားပြီးဖြစ်သည်၊
    ///
    /// ၎င်းသည် `RefMut::map(...)` အဖြစ်အသုံးပြုရန်လိုအပ်သည့်ဆက်စပ်မှုတစ်ခုဖြစ်သည်။
    /// `Deref` မှတစ်ဆင့်အသုံးပြုသော `RefCell` ၏မာတိကာတစ်ခုတွင်အမည်တူနည်းလမ်းများကိုနည်းလမ်းတစ်ခုကအနှောင့်အယှက်ပေးလိမ့်မည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): ပြင်ဆင်ချက်ချေးငှါး-စစ်ဆေးမှုများ
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// ငှားရမ်းထားသောအချက်အလက်များ၏အစိတ်အပိုင်းတစ်ခုအတွက် `RefMut` အသစ်တစ်ခုကိုပြုလုပ်သည်။
    /// ပိတ်သိမ်းမှု `None` ပြန်လာလျှင်မူရင်းကိုယ်ရံတော်တစ်ခု `Err(..)` အဖြစ်ပြန်ရောက်သည်။
    ///
    /// `RefCell` ကိုအပြန်အလှန်ချေးယူထားပြီးဖြစ်သည်၊
    ///
    /// ၎င်းသည် `RefMut::filter_map(...)` အဖြစ်အသုံးပြုရန်လိုအပ်သည့်ဆက်စပ်မှုတစ်ခုဖြစ်သည်။
    /// `Deref` မှတစ်ဆင့်အသုံးပြုသော `RefCell` ၏မာတိကာတစ်ခုတွင်အမည်တူနည်းလမ်းများကိုနည်းလမ်းတစ်ခုကအနှောင့်အယှက်ပေးလိမ့်မည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): ပြင်ဆင်ချက်ချေးငှါး-စစ်ဆေးမှုများ
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // လုံခြုံမှု-လုပ်ဆောင်ချက်သည်ကြာချိန်အတွက်သီးသန့်ရည်ညွှန်းချက်တစ်ခုဖြစ်သည်
        // ယင်း၏ `orig` မှတဆင့်ဖုန်းခေါ်ဆိုမှုများနှင့် pointer function ကိုဖုန်းခေါ်ဆိုမှုသာက de-ရည်ညွှန်းအတွင်းရှိအထူးသီးသန့်ရည်ညွှန်းမှလွတ်မြောက်ရန်ခွင့်ပြုဘယ်တော့မှဖြစ်ပါတယ်များ၏။
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // လုံခြုံမှု-အထက်နှင့်အတူတူ။
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// ငှားရမ်းထားသောအချက်အလက်များ၏မတူညီသောအစိတ်အပိုင်းများအတွက် `RefMut` ကိုမျိုးစုံ `RefMut 'သို့ခွဲသည်။
    ///
    /// နှစ်ဦးစလုံးပြန်ရောက် `RefMut`s နယ်ပယ်မှထွက်သွားသည်အထိအခြေခံ `RefCell` mutably ချေးရှိနေပါဦးမည်။
    ///
    /// `RefCell` ကိုအပြန်အလှန်ချေးယူထားပြီးဖြစ်သည်၊
    ///
    /// ဤသည် `RefMut::map_split(...)` အဖြစ်အသုံးပြုခံရဖို့လိုအပ်ပါတယ်တစ်ခုဆက်စပ် function ကိုဖြစ်ပါတယ်။
    /// `Deref` မှတစ်ဆင့်အသုံးပြုသော `RefCell` ၏မာတိကာတစ်ခုတွင်အမည်တူနည်းလမ်းများကိုနည်းလမ်းတစ်ခုကအနှောင့်အယှက်ပေးလိမ့်မည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// နောက်ခံဒေတာတစ်ခု mutable ရည်ညွှန်းသို့ပြောင်းပါ။
    ///
    /// နောက်ခံ `RefCell` ကို ထပ်မံ၍ ချေး ယူ၍ မရပါ။ အပြန်အလှန်အားဖြင့်အပြန်အလှန်အားဖြင့်ချေးယူထားသည့်ပုံပေါ်နေပြီးပြန်လည်ရည်ညွှန်းကိုးကားအတွင်းပိုင်းကိုသာပြုလုပ်နိုင်သည်။
    ///
    ///
    /// ၎င်းသည် `RefMut::leak(...)` အဖြစ်အသုံးပြုရန်လိုအပ်သည့်ဆက်စပ်မှုတစ်ခုဖြစ်သည်။
    /// `Deref` မှတစ်ဆင့်အသုံးပြုသော `RefCell` ၏မာတိကာတစ်ခုတွင်အမည်တူနည်းလမ်းများကိုနည်းလမ်းတစ်ခုကအနှောင့်အယှက်ပေးလိမ့်မည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // ဒီ BorrowRefMut မေ့လျော့ခြင်းအားဖြင့်ကျွန်ုပ်တို့သည် RefCell အတွက်ချေးငှါးတန်ပြန်သည့်တစ်သက်တာ `'b` အတွင်းမသုံးရသေးပြန်မသွားနိုင်ကြောင်းအာမခံပါသည်။
        // ရည်ညွှန်းခြေရာခံခြင်းပြည်နယ်ကိုပြန်လည်ပြင်ဆင်ခြင်းအတွက်ချေး RefCell တစ်မူထူးခြားတဲ့ရည်ညွှန်းလိုအပ်ပေလိမ့်မည်။
        // လက်ရှိသက်တမ်းအတွင်းမူရင်းဆဲလ်မှမည်သည့်ထပ်မံရည်ညွှန်းကိုးကားမှုများပြုလုပ်နိုင်မည်နည်း၊
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: BorrowRefMut::clone နှင့်မတူဘဲအသစ်ကိုကန ဦး ဖန်တီးရန်ခေါ်သည်
        // mutable ရည်ညွှန်း, ဒါကြောင့်လက်ရှိမျှတည်ဆဲကိုးကားအဲဒီမှာဖြစ်ရမည်။
        // ကိုယ်ပွားဟာ mutable refcount increments စဉ်ထို့ကြောင့်, ဒီမှာကျွန်တော်အတိအလင်းသာမသုံးရသေးထံမှ 1, မသုံးရသေးသွားခွင့်ပြုပါ။
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // `BorrowRefMut` တစ်ခုကို Clones လုပ်သည်။
    //
    // တစ်ဦးချင်းစီ `BorrowRefMut` မူလအရာဝတ္ထု၏တစ်ဦးကွဲပြား, nonoverlapping အကွာအဝေးတစ်ခု mutable ရည်ညွှန်းကိုခြေရာခံရန်အသုံးပြုလျှင်ဤသည်သာတရားဝင်သည်။
    //
    // ဒီဟာက Clone impl မှာမဟုတ်ဘူး၊ ဒါကြောင့်ဒီ code ကလုံးလုံးလျားလျားမခေါ်ဘူး။
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // စီးဆင်းနေသောထံမှငွေချေးကောင်တာတားဆီး။
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// တစ်ဦး `RefCell<T>` နေ mutably ချေးတန်ဖိုးကိုတစ် wrapper အမျိုးအစား။
///
/// ပိုပြီးများအတွက် [module-level documentation](self) ကိုကြည့်ပါ။
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Rust အတွက်အတွင်းပိုင်း mutability များအတွက်စရိုက်အဆိုပါ core ကို။
///
/// သင်တစ်ဦးကိုကိုးကား `&T` ရှိပါက, ထို့နောက်ပုံမှန် Rust အတွက် `&T` မပြောင်းလဲနိုင်သောအရာများအချက်အလက်များထောက်ပြသောအသိပညာအပေါ်အခြေခံပြီး compiler က performance ပိုမိုကောင်းမွန်ရေး။တစ်ဦး alias ကိုမှတဆင့်သို့မဟုတ် `&mut T` သို့တစ်ဦး `&T` transmuting အားဖြင့်ဥပမာအား, ထိုဒေတာများကိုမျိုးရိုးဗီဇပြောင်းလဲပုံ, undefined အပြုအမူစဉ်းစားသည်။
/// `UnsafeCell<T>` opts ထွက် `&T` များအတွက်မပြောင်းလဲနိုင်သောအရာများအာမခံချက်၏: `&UnsafeCell<T>` mutated ခံကြောင်းအချက်အလက်များထောက်ပြဖြစ်နိုင်သည် a shared ကိုကိုးကား။ဒါကို "interior mutability" လို့ခေါ်တယ်။
///
/// `Cell<T>` နှင့် `RefCell<T>` ကဲ့သို့သောအတွင်းပိုင်းပြောင်းလဲမှုများကိုခွင့်ပြုသည့်အခြားအမျိုးအစားများအားလုံးသည်သူတို့၏အချက်အလက်များကိုထုပ်ပိုးရန်အတွက် `UnsafeCell` ကိုအသုံးပြုသည်။
///
/// shared ကိုးကားများအတွက်မပြောင်းလဲနိုင်သောအရာများအာမခံချက်သာ `UnsafeCell` ကြောင့်ထိခိုက်ကြောင်းသတိပြုပါ။mutable ကိုးကားများအတွက်ထူးခြားမှုအာမခံချက်ထိခိုက်ဖြစ်ပါတယ်။`&mut` aliasing ရရှိရန်တရားဝင်နည်းလမ်းမရှိပါ * `UnsafeCell<T>` နှင့်တောင်မှမရှိပါ။
///
/// အဆိုပါ `UnsafeCell` API ကိုသူ့ဟာသူနည်းပညာပိုင်းအလွန်ရိုးရှင်းတဲ့ဖြစ်ပါသည်: [`.get()`] သူ့ရဲ့အကြောင်းအရာတွေကိုဖို့သင်တစ်ဦးကုန်ကြမ်း pointer `*mut T` ပေးသည်။ဒါဟာမှန်ကန်စွာကြောင့်ကုန်ကြမ်း pointer ကိုအသုံးဖို့ abstraction ဒီဇိုင်နာအဖြစ်တက် _you_ ရန်ဖြစ်ပါသည်။
///
/// [`.get()`]: `UnsafeCell::get`
///
/// တိကျသော Rust aliasing rules များသည်အတော်အတန် flux များဖြစ်သော်လည်းအဓိကအချက်များမှာအငြင်းပွားစရာမဟုတ်ပါ။
///
/// - သငျသညျ (သင်ကပြန်ရောက်သောကွောငျ့, ဥပမာ) ဘေးကင်းလုံခြုံ code ကလက်လှမ်းကြောင်းတစ်သက်တာ `'a` (တစ်ခုခုတစ်ဦး `&T` သို့မဟုတ် `&mut T` ရည်ညွှန်း) နဲ့လုံခြုံရည်ညွှန်းဖန်တီးလျှင်, သင်ကျန်ရှိသောများအတွက်ဆန့်ကျင်ကြောင်းရည်ညွှန်းဆိုလမ်းထဲမှာဒေတာတွေကို access မပြုရ `'a` ၏။
/// ကြောင်းရည်ညွှန်းရဲ့တသက်တာကုန်ဆုံးသည်အထိဥပမာအားဖြင့်, သင်သည်တစ်ခု `UnsafeCell<T>` ထံမှ `*mut T` ယူ. တစ်ခု `&T` မှပစ်လျှင်, `T` အတွက် data တွေကိုမပြောင်းလဲနိုင်သောအရာများဆက်လက်တည်ရှိရမယ်လို့ဒီနည်းလမ်း (ဆို `UnsafeCell` ဒေတာ modulo သင်တန်း `T`, အတွင်းတွေ့ရှိခဲ့) ။
/// သငျသညျဘေးကင်းလုံခြုံကုဒ်မှဖြန့်ချိသော `&mut T` ရည်ညွှန်းဖန်တီးလျှင်ရည်ညွှန်းကုန်ဆုံးသည်အထိအလားတူပဲ, ထို့နောက်သင် `UnsafeCell` အတွင်းဒေတာရယူမပြုရပါ။
///
/// - အချိန်တိုင်းဒေတာပြိုင်ပွဲများကိုသင်ရှောင်ရမည်။အကယ်၍ Thread များစွာသည်တူညီသော `UnsafeCell` ကိုအသုံးပြုခွင့်ရှိလျှင်၊ မည်သည့်ရေးသားမှုမျိုးမဆိုအခြား accesses အားလုံး (သို့မဟုတ် atomics ကိုအသုံးပြုခြင်း) နှင့်သက်ဆိုင်သောဖြစ်ရပ်များမဖြစ်သင့်ပါ။
///
/// သင့်လျော်သောဒီဇိုင်းနှင့်အတူကူညီဖို့, အောက်ပါအခြေအနေတွေရှင်းရှင်းလင်းလင်း Single-ပေါင်းလိုက်သောကုဒ်များအတွက်ဥပဒေရေးရာကြေညာနေကြသည်:
///
/// 1. တစ်ဦးက `&T` ရည်ညွှန်းလုံခြုံကုဒ်မှဖြန့်ချိနိုင်ပါသည်ကြောင့်မဟုတ်ဘဲတစ်ဦး `&mut T` နှင့်အတူအခြား `&T` ကိုးကားနှင့်အတူရှိ-တည်ရှိပူးတွဲနိုင်ပါတယ်
///
/// 2. တစ်ဦးက `&mut T` ရည်ညွှန်းသည်အခြား `&mut T` မဟုတ်သလို `&T` က Co-တည်ရှိမပေးအပ်လုံခြုံကုဒ်မှဖြန့်ချိနိုင်ပါသည်။`&mut T` သည်အမြဲတမ်းထူးခြားနေရမည်။
///
/// (ပင်ဆဲလ် alias ကိုအခြားအ `&UnsafeCell<T>` ညွှန်းဆိုစဉ်) တစ်ဦး `&UnsafeCell<T>` ရဲ့ contents မျိုးရိုးဗီဇပြောင်းလဲပုံ (သင်အထက်ပါလျော့ပါးသွားမည်ဖြစ်သလိုအချို့သောအခြားလမ်းပြဋ္ဌာန်းရန်ပေးအပ်) ok ဖြစ်ပါတယ်နေတုန်းပြုလုပ်နေဆဲမျိုးစုံ `&mut UnsafeCell<T>` နာမည်ရှိသည်ဖို့ undefined အပြုအမူကြောင်းမှတ်ချက်။
/// ဆိုလိုသည်မှာ `UnsafeCell` သည် X0 `&UnsafeCell<_>` အညွှန်းမှတစ်ဆင့် _shared_ accesses (_i.e._ နှင့်အထူးအပြန်အလှန်ဆက်သွယ်နိုင်ရန်ဒီဇိုင်းပြုလုပ်ထားသောထုပ်တစ်ခုဖြစ်သည်။တစ်ဦး `&mut UnsafeCell<_>` မှတဆင့် _exclusive_ accesses (_e.g._) နှင့်ဆက်ဆံရာတွင်သည့်အခါသမျှမျှမှော်အဲဒီမှာဖြစ်ပါသည်: ဆဲလ်မပတ်ရစ်တန်ဖိုးကိုမကြောင်း `&mut` ချေးငှါး၏ကြာချိန်များအတွက် aliased နိုင်ပါသည်။
///
/// ၎င်းကို [`.get_mut()`] accessor များကပြသသည်။ ၎င်းသည် X0 _safe_ getter ဖြစ်သည့် `&mut T` ဖြစ်သည်။
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// ဆဲလ်ကိုကိုးကားထားသောရည်ညွှန်းချက်များစွာရှိသော်လည်း `UnsafeCell<_>` ၏ပါဝင်မှုများကိုမှန်ကန်စွာမည်သို့ mutate လုပ်နိုင်ကြောင်းဖော်ပြသည့်ဥပမာတစ်ခုဖြစ်သည်။
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // တူညီသော `x` ကိုမျိုးစုံ/တစ်ပြိုင်တည်း/မျှဝေကိုးကားချက်များကိုရယူပါ။
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // လုံခြုံမှု: ဤနယ်ပယ်အတွင်း x`ရဲ့ contents တွေကို`ရန်မနဲ့အခြားကိုးကားရှိပါတယ်,
///     // ထိထိရောက်ရောက်ထူးခြားသည်ငါတို့နိုင်အောင်။
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- ချေး-+
///     *p1_exclusive += 27; // |
/// } // <---------- ဒီအချက်ထက်ကျော်လွန်သွားလို့မရဘူး -------------------+
///
/// unsafe {
///     // လုံခြုံမှု-ဤနယ်ပယ်အတွင်း `x` ၏ပါ ၀ င်သောအရာများကိုသီးသန့်ရယူပိုင်ခွင့်မရှိပါ။
///     // တစ်ပြိုင်နက်တည်းမျိုးစုံက Shared Access ရှိနိုင်ပါသည်ကျနော်တို့ဒါ။
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// အောက်ပါဥပမာသည် `UnsafeCell<T>` တစ်ခုသို့သီးသန့် ၀ င်ရောက်ခြင်းသည်၎င်း၏ `T` သို့သီးသန့်ဝင်ရောက်ခွင့်ကိုဆိုလိုသည်ဟူသောအချက်ကိုပြသည်။
///
/// ```rust
/// #![forbid(unsafe_code)] // သီးသန့်ဝင်ရောက်ခွင့်,
///                         // `UnsafeCell` တစ်ပွင့်လင်းမ op wrapper ဖြစ်တယ်, ဒါဤနေရာတွင် `unsafe` အဘို့အဘယ်သူမျှမလိုအပ်ပါဘူး။
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // compile-time-check လုပ်ထား `x` ထူးခြားတဲ့ရည်ညွှန်းရယူပါ။
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // သီးသန့်ရည်ညွှန်းချက်ဖြင့်ကျွန်ုပ်တို့သည်အကြောင်းအရာများကိုအခမဲ့ပြောင်းလဲနိုင်သည်။
/// *p_unique.get_mut() = 0;
/// // ဒါမှမဟုတ်ညီမျှစွာ-
/// x = UnsafeCell::new(0);
///
/// // ကျနော်တို့တန်ဖိုးကိုပိုင်ဆိုင်ရတဲ့အခါကျနော်တို့အခမဲ့ရဲ့ contents extract နိုင်ပါတယ်။
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// သတ်မှတ်ထားသောတန်ဖိုးကိုထုပ်ပိုးပေးမည့် `UnsafeCell` ၏ဥပမာအသစ်တစ်ခုကိုတည်ဆောက်သည်။
    ///
    ///
    /// အတွင်းပိုင်းတန်ဖိုးကိုနည်းလမ်းများမှတဆင့်ရယူအသုံးပြုခြင်းအားလုံးသည် `unsafe` ဖြစ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// တန်ဖိုး Unwraps ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// တစ် ဦး mutable pointer ထုပ်တန်ဖိုးကိုရရှိသွားတဲ့။
    ///
    /// ဒါကမဆိုကြင်နာတဲ့ pointer မှချနိုင်ပါသည်။
    /// `&mut T` သို့ထုတ်လွှင့်သောအခါဆက်သွယ်မှုသည်ထူးခြားသည် (တက်ကြွစွာရည်ညွှန်းမှုမရှိ၊ ပြောင်းနိုင်သည်သို့မဟုတ်မရှိသည်) သည်သေချာအောင်လုပ်ပါ။ `&T` သို့ပြန်ပို့သည့်အခါတွင်ဖြစ်ပေါ်နေသော mutation သို့မဟုတ် mutable aliases မရှိပါ။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // #[repr(transparent)] ကြောင့် pointer ကို `UnsafeCell<T>` မှ `T` သို့သာပို့နိုင်သည်။
        // ဤသည် libstd ရဲ့အထူး status ကိုယူအမြတ်ထုတ်ဒီ compiler ၏ future ဗားရှင်းအတွက်အလုပ်လုပ်ပါလိမ့်မယ်က user ကုဒ်များအတွက်အာမခံချက်မရှိပါပါ!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// ပြန်နောက်ခံဒေတာတစ်ခု mutable ကိုကိုးကား။
    ///
    /// ဤခေါ်ဆိုမှုသည် `UnsafeCell` ကို (compile-time) တွင်အပြန်အလှန်အကျိုးသက်ရောက်စေသည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// တစ် ဦး mutable pointer ထုပ်တန်ဖိုးကိုရရှိသွားတဲ့။
    /// [`get`] ဖို့ကွာခြားချက်ကဒီ function ကိုယာယီကိုးကား၏ဖန်တီးမှုကိုရှောင်ကြဉ်ရန်အသုံးဝင်သည်သောကုန်ကြမ်း pointer, လက်ခံသောကြောင့်ဖြစ်သည်။
    ///
    /// အဆိုပါရလဒ်မဆိုကြင်နာတဲ့ pointer ကိုမှနှငျထုတျနိုငျသညျ။
    /// `&mut T` မှ ချ. သည့်အခါ (အဘယ်သူမျှမတက်ကြွကိုးကား, mutable သို့မဟုတ်မ) ကို access ကိုထူးခြားတဲ့ကြောင်းသေချာစေရန်နှင့်မျှဗီဇပြောင်းလဲမှုတွေသို့မဟုတ် `&T` မှ ချ. သည့်အခါအပေါ်ကိုသွား mutable နာမည်ရှိပါတယ်အာမခံပါသည်။
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// တစ်ဦး `UnsafeCell` ၏တဖြည်းဖြည်းစတင်ခြင်း `get` uninitialized ဒေတာမှတစ်ဦးကိုကိုးကားကိုလိုအပ်ပေလိမ့်မည်တောင်းဆိုအဖြစ်, `raw_get` လိုအပ်ပါတယ်:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // #[repr(transparent)] ကြောင့် pointer ကို `UnsafeCell<T>` မှ `T` သို့သာပို့နိုင်သည်။
        // ဤသည် libstd ရဲ့အထူး status ကိုယူအမြတ်ထုတ်ဒီ compiler ၏ future ဗားရှင်းအတွက်အလုပ်လုပ်ပါလိမ့်မယ်က user ကုဒ်များအတွက်အာမခံချက်မရှိပါပါ!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// T. အတွက် `Default` တန်ဖိုးရှိသည့် `UnsafeCell` တစ်ခုကိုဖန်တီးသည်။
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}