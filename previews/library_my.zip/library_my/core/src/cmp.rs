//! အမိန့်များနှင့်နှိုင်းယှဉ်မှုအတွက်လုပ်ဆောင်နိုင်စွမ်း။
//!
//! ဒီ module ထဲမှာတန်ဖိုးများကိုနှိုင်းယှဉ်ခြင်းနှင့်နှိုင်းယှဉ်ဘို့အမျိုးမျိုးသော tools များပါရှိသည်။အကျဉ်းချုပ်မှာ:
//!
//! * [`Eq`] နှင့် [`PartialEq`] သင်သည်အသီးသီးတန်ဖိုးများကို, အကြားစုစုပေါင်းနှင့်တစ်စိတ်တစ်ပိုင်းတန်းတူရေးသတ်မှတ်ခွင့်ပြုကြောင်း traits ဖြစ်ကြသည်။
//! သူတို့ကိုအကောင်အထည်ဖော်သည့် `==` နှင့် `!=` အော်ပရေတာ overloads ။
//! * [`Ord`] [`PartialOrd`] သည် traits ဖြစ်ပြီးတန်ဖိုးများအကြားစုစုပေါင်းနှင့်တစ်စိတ်တစ်ပိုင်းအစဉ်လိုက်ကိုသတ်မှတ်ပေးသည်။
//!
//! ၎င်းတို့ကိုအကောင်အထည်ဖော်ခြင်းသည် `<`, `<=`, `>` နှင့် `>=` အော်ပရေတာများကိုအလွန်အကျွံတင်သည်။
//! * [`Ordering`] [`Ord`] နှင့် [`PartialOrd`] ၏အဓိကလုပ်ငန်းဆောင်တာများကပြန်ရောက်တစ်ခု enum ဖြစ်တယ်, တစ်ဦးသာသနာကိုဖော်ပြသည်။
//! * [`Reverse`] သငျသညျကိုအလွယ်တကူအမိန့်ကိုပြောင်းပြန်ခွင့်ပြုတဲ့ struct ဖြစ်ပါတယ်။
//! * [`max`] နှင့် [`min`] ဆိုသည်မှာ [`Ord`] ၏တည်ဆောက်မှုနှင့်တန်ဖိုးအမြင့်ဆုံး (သို့) အနိမ့်ဆုံးတန်ဖိုးကိုရှာဖွေနိုင်သောလုပ်ဆောင်ချက်ဖြစ်သည်။
//!
//! အသေးစိတ်အတွက်စာရင်းရှိပစ္စည်းတစ်ခုစီ၏သက်ဆိုင်ရာစာရွက်စာတမ်းများကိုကြည့်ပါ။
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation) ဖြစ်သောတန်းတူညီမျှမှုနှိုင်းယှဉ်မှုများအတွက် Trait
///
/// ဤသည် trait အပြည့်အဝညီမျှဆက်စပ်မှုရှိသည်မဟုတ်ကြဘူးအမျိုးအစားများအဘို့, တစ်စိတ်တစ်ပိုင်းတန်းတူညီမျှမှုခွင့်ပြုပါတယ်။
/// ဥပမာအားဖြင့်၊ `NaN != NaN` floating point နံပါတ်များတွင် floating point အမျိုးအစားများသည် `PartialEq` ကိုအကောင်အထည်ဖော်သော်လည်း [`trait@Eq`] ကိုမူမလုပ်ဆောင်ပါ။
///
/// ပုံမှန်အားဖြင့်တန်းတူညီမျှမှုရှိရမည် (အမျိုးအစား `a`, `b`၊ `A`၊ `B`, `C` အမျိုးအစားအားလုံးအတွက်အားလုံးအတွက်)
///
/// - **Symmetric**: `A: PartialEq<B>` နှင့် `B: PartialEq<A>` လျှင် **`a==b`` b==a`** ကိုဆိုလိုသည်။နှင့်
///
/// - **Transitive**-`A: PartialEq<B>` နှင့် `B: PartialEq<C>` နှင့် `A တို့ဖြစ်ပါက
///   နေ<C>`, ထို့နောက် **` a==b`နှင့် `b == c` a==c`** ကိုဆိုလိုသည်။
///
/// မှတ်ချက်အဆိုပါ `B: PartialEq<A>` (symmetric) နှင့် `A: PartialEq<C>` (transitive) impls တည်ရှိရန်အတင်းအကျပ်ခိုင်းစေသော်လည်း, သူတို့သည်တည်ရှိပြုပါအခါတိုင်းဤအလိုအပ်ချက်များကိုလျှောက်ထားကြသည်မဟုတ်ကြောင်း။
///
/// ## Derivable
///
/// ဤသည် trait `#[derive]` နှငျ့အသုံးပွုနိုငျသညျ။structs ပေါ်တွင် `derive`d 'ဆိုလျှင်၊ ကွက်လပ်အားလုံးသည်တန်းတူဖြစ်ပါကသာဓက (၂) ခုသည်တူညီသည်။ဘယ်အချိန်မှာ `enums အပေါ် derive`d စီမူကွဲသူ့ဟာသူညီမျှနှင့်အခြားမျိုးကွဲညီမျှမဟုတ်ပါဘူး။
///
/// ## `PartialEq` ကိုမည်သို့အကောင်အထည်ဖော်နိုင်မည်နည်း။
///
/// `PartialEq` သာ [`eq`] နည်းလမ်းစတင်ခြင်းခံရဖို့လိုအပ်ပါတယ်;[`ne`] default အနေဖြင့်ပြုလုပ်၏စည်းကမ်းချက်များ၌သတ်မှတ်ထားသောဖြစ်ပါတယ်။[`ne`] မဆိုလက်စွဲစာအုပ်အကောင်အထည်ဖော်မှု *မဖြစ်မနေ*[`eq`] [`ne`] တစ်တင်းကျပ်ပြောင်းပြန်ကြောင်းစိုးမိုးရေးလေးစား;ဆိုလိုသည်မှာ `!(a == b)` သည် `a != b` လျှင်သာဖြစ်သည်။
///
/// `PartialEq`, [`PartialOrd`] နှင့် [`Ord`] အကောင်အထည်ဖော်ရေး *မဖြစ်မနေ* အချင်းချင်းသဘောတူသည်။ဒါဟာမတော်တဆသူတို့ကို traits အချို့ deriving နှင့်ကိုယ်တိုင်အခြားသူများကိုအကောင်အထည်ဖော်ခြင်းဖြင့်သဘောမတူစေရန်လွယ်ကူသည်။
///
/// သူတို့၏ ISBN ပွဲရှိလျှင်နှစ်ခုစာအုပ်တွေဟာကို formats ကွဲပြားလျှင်ပင်, တူညီတဲ့စာအုပ်စဉ်းစားထားတဲ့အတွက်ဒိုမိန်းဥပမာတစ်ခုအကောင်အထည်ဖော်မှု
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## ကွဲပြားသောအမျိုးအစားနှစ်မျိုးကိုမည်သို့နှိုင်းယှဉ်နိုင်မည်နည်း။
///
/// သင်နှင့်အတူနှိုင်းယှဉ်နိုင်ပါတယ်အမျိုးအစား PartialEq`ရဲ့ type ကို parameter သည်`ကထိန်းချုပ်ထားသည်။
/// ဥပမာအားဖြင့်၊ ငါတို့၏ယခင်ကုဒ်ကိုအနည်းငယ်ပြောင်းလဲရန်လိုသည်။
///
/// ```
/// // အဆိုပါအနကျအဓိပ်ပါယျသုံးကိရိယာ<BookFormat>==<BookFormat>နှိုင်းယှဉ်
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // အကောင်အထည်ဖော်ပါ<Book>==<BookFormat>နှိုင်းယှဉ်
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // implement<BookFormat>==<Book>နှိုင်းယှဉ်
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// `impl PartialEq for Book` ကို `impl PartialEq<BookFormat> for Book` ပြောင်းခြင်းအားဖြင့် `Book`s နှင့်``BookFormat`s ကိုနှိုင်းယှဉ်နိုင်သည်။
///
/// အထက်ဖွဲ့စည်းပုံနှင့်နှိုင်းယှဉ်လျှင်၎င်းသည် struct ၏အချို့နယ်ပယ်များကိုလျစ်လျူရှုခြင်းသည်အန္တရာယ်ရှိနိုင်သည်။၎င်းသည်တစ်စိတ်တစ်ပိုင်းညီမျှမှုဆိုင်ရာလိုအပ်ချက်များကိုမရည်ရွယ်ဘဲချိုးဖောက်ခြင်းကိုလွယ်ကူစွာ ဦး တည်နိုင်သည်။
/// ဥပမာအားဖြင့်၊ ကျွန်ုပ်တို့သည် `BookFormat` အတွက်အထက်ပါ `PartialEq<Book>` ၏အကောင်အထည်ဖော်မှုကိုသိမ်းဆည်းပြီး `Book` အတွက် `PartialEq<Book>` ၏အကောင်အထည်ဖော်မှုတစ်ခုကိုထည့်သွင်းပါက (`#[derive]` မှတစ်ဆင့်သော်လည်းကောင်း၊ လက်စွဲအကောင်အထည်ဖော်ခြင်းမှတစ်ဆင့်) ဥပမာရလဒ်သည်ကူးပြောင်းခြင်းကိုဖောက်ဖျက်လိမ့်မည်။
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// ဤနည်းလမ်းသည် `self` နှင့် `other` တန်ဖိုးများကိုတူညီမှုရှိမရှိစစ်ဆေးသည်၊ `==` မှအသုံးပြုသည်။
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// ဤနည်းလမ်းသည် `!=` အတွက်စမ်းသပ်သည်။
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// အနကျအဓိပ်ပါယျနိုင်တဲ့ macro အဆိုပါ trait `PartialEq` တစ်ခု impl ထုတ်လုပ်။
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation) နေသောတန်းတူရေးနှိုင်းယှဉ်မှုအတွက် Trait ။
///
/// ဆိုလိုသည်မှာ `a == b` နှင့် `a != b` သည်တင်းကျပ်သောပြောင်းပြန်များဖြစ်သည့်အပြင် (`a`, `b` နှင့် `c` အားလုံးအတွက်) တန်းတူညီမျှမှုရှိရမည်။
///
/// - reflexive: `a == a`;
/// - အချိုးကျတဲ့: `a == b` `b == a` ဆိုလို;နှင့်
/// - အကူးအပြောင်း: `a == b` နှင့် `b == c` `a == c` ကိုဆိုလိုသည်။
///
/// ဤပိုင်ဆိုင်မှုကို compiler မှစစ်ဆေး။ မရပါ၊ ထို့ကြောင့် `Eq` သည် [`PartialEq`] ကိုဆိုလိုသည်၊ အပိုနည်းလမ်းများမရှိပါ။
///
/// ## Derivable
///
/// ဤ trait ကို `#[derive]` နှင့်အသုံးပြုနိုင်သည်။
/// `Eq` မျှအပိုနည်းလမ်းများရှိပါတယ်ဘာဖြစ်လို့လဲဆိုတော့သည့်အခါ `derive`d, ကသာဒီတစ်ခုညီမျှစပ်လျဉ်းထက်တစ်တစ်စိတ်တစ်ပိုင်းညီမျှစပ်လျဉ်းသော compiler ကအသိပေးသည်။
///
/// သတိပြုရမည်မှာ `derive` မဟာဗျူဟာသည်နယ်ပယ်အားလုံးလိုအပ်သည်မှာအမြဲတမ်းလိုချင်သော `Eq` ဖြစ်သည်။
///
/// ## အဘယ်သို့ငါ `Eq` အကောင်အထည်ဖော်နိုင်သလဲ
///
/// သင် `derive` နည်းဗျူဟာကိုမသုံးနိုင်မယ်ဆိုရင်, သင့် type ကိုအဘယ်သူမျှမနည်းလမ်းများကိုသည့် `Eq`, အကောင်အထည်ဖော်ဆောင်ရွက်နေသောကြောင့်သတ်မှတ်:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // ဒီနည်းလမ်းကိုအမျိုးအစားသုံးကိရိယာ#အမှုအမျိုးမျိုးရှိသမျှအစိတ်အပိုင်းသူ့ဟာသူ [deriving] ကြောင်းအခိုင်အမာဖို့ [deriving] တစ်ခုတည်းကိုသာ#အသုံးပြုလက်ရှိအနကျအဓိပ်ပါယျအခြေခံအဆောက်အအုံနည်းလမ်းများဒီ trait အပေါ်တစ်ဦးနည်းလမ်းကိုသုံးပြီးမရှိဘဲဤအခိုင်အမာလုပ်နေတာနီးပါးမဖြစ်နိုင်ဘူး။
    //
    //
    // ဤသည်ကိုလက်ဖြင့်အကောင်အထည်ဖော်ဘယ်တော့မှသငျ့သညျ။
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// အနကျအဓိပ်ပါယျနိုင်တဲ့ macro အဆိုပါ trait `Eq` တစ်ခု impl ထုတ်လုပ်။
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: ဒီ struct တစ်ခုတည်းကိုသာ#[အနကျအဓိပ်ပါယျ] မှအသုံးပြု
// အမျိုးအစားအမှုအမျိုးမျိုးရှိသမျှအစိတ်အပိုင်း Eq အကောင်အထည်ဖော်ဆောင်ရွက်နေသောကြောင်းအခိုင်အမာ။
//
// ဤသည် struct သည်အသုံးပြုသူကုဒ်ထဲမှာပေါ်လာဘယ်တော့မှသင့်ပါတယ်။
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// တစ်ဦး `Ordering` နှစ်ခုတန်ဖိုးများအကြားတစ်ဦးနှိုင်းယှဉ်၏ရလဒ်ဖြစ်ပါသည်။
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// တစ်ဦးနှင့်နှိုင်းယှဉ်လျှင်တန်ဖိုးကအခြားထက်လျော့နည်းသည်အဘယ်မှာရှိတစ်ဦးသာသနာကို။
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// နှိုင်းယှဉ်တန်ဖိုးကိုအခြားညီမျှရှိရာတစ်ခုအမိန့်။
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// တစ်ဦးနှင့်နှိုင်းယှဉ်လျှင်တန်ဖိုးကအခြားထက် သာ. ကြီးမြတ်သည်အဘယ်မှာရှိတစ်ဦးသာသနာကို။
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// အဆိုပါသာသနာကိုပု `Equal` မူကွဲလျှင် `true` Returns ။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// အမိန့်ဟာ `Equal` မူကွဲမဟုတ်ပါဘူးလျှင် `true` ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// အမိန့်မှာ `Less` မူကွဲဖြစ်ပါက `true` သို့ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// အမိန့်မှာ `Greater` မူကွဲဖြစ်ပါက `true` သို့ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// အဆိုပါသာသနာကိုပု `Less` သို့မဟုတ် `Equal` မူကွဲဖြစ်စေလျှင် `true` Returns ။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// အဆိုပါသာသနာကို `Greater` သို့မဟုတ် `Equal` မူကွဲဖြစ်စေလျှင် `true` ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// အဆိုပါ `Ordering` ကိုပြောင်းပြန်။
    ///
    /// * `Less` `Greater` ဖြစ်လာသည်။
    /// * `Greater` `Less` ဖြစ်လာသည်။
    /// * `Equal` `Equal` ဖြစ်လာသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံပညာအပြုအမူ:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// ဒီနည်းလမ်းကိုနှိုင်းယှဉ်မှုကိုပြန်လှန်ချေပရန်သုံးနိုင်သည်။
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // အကြီးဆုံးကနေအသေးဆုံးဖို့ခင်းကျင်း sort ။
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// သံကြိုးနှစ်ခု order ။
    ///
    /// `Equal` မဟုတ်သည့်အခါ `self` ကိုပြန်ပို့သည်။ဒီလိုမှမဟုတ်ရင် `other` ပြန်လည်ရောက်ရှိ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// ချည်နှောင်ခြင်းကိုပေးထားသော function ကိုအတူသာသနာကို။
    ///
    /// `self` မဟုတ်သည့်အခါ `self` ကိုပြန်ပို့သည်။
    /// ဒီလိုမှမဟုတ်ရင် `f` ခေါ်ရလဒ်ပြန်လည်ရောက်ရှိ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// ပြောင်းပြန်သာသနာကိုများအတွက်အထောက်အ struct ။
///
/// ဤသည် struct သည် [`Vec::sort_by_key`] ကဲ့သို့သောလုပ်ဆောင်မှုများနှင့်အတူအသုံးပြုရန်ကူညီပေးသည်။ ၎င်းသည်သော့၏အစိတ်အပိုင်းတစ်ခုကိုအစဉ်လိုက်ပြောင်းရန်အသုံးပြုနိုင်သည်။
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// [total order](https://en.wikipedia.org/wiki/Total_order) ကိုဖွဲ့စည်းသောအမျိုးအစားများအတွက် Trait
///
/// အော်ဒါတစ်ခုသည် (`a`, `b` နှင့် `c` အားလုံးအတွက်) ဖြစ်ပါကစုစုပေါင်းအစီအစဉ်တစ်ခုဖြစ်သည်။
///
/// - စုစုပေါင်းနှင့်အချိုးမညီ: `a < b`, `a == b` သို့မဟုတ် `a > b` ၏တစ်ခုအတိအကျမှန်ပေ၏နှင့်
/// - အကူးအပြောင်း, `a < b` နှင့် `b < c` `a < c` ကိုဆိုလိုသည်။`==` နှင့် `>` နှစ်ခုလုံးအတွက်အတူတူထားရမည်။
///
/// ## Derivable
///
/// ဤ trait ကို `#[derive]` နှင့်အသုံးပြုနိုင်သည်။
/// `structs အပေါ် derive`d အခါ, က struct ရဲ့အဖွဲ့ဝင်တွေရဲ့ထိပ်-to-အောက်ခြေကြေငြာအမိန့်အပေါ်အခြေခံပြီးတစ်ဦး [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) သာသနာကိုထုတ်လုပ်ပါလိမ့်မယ်။
///
/// `enums အပေါ် derive`d အခါ, မျိုးကွဲသူတို့ရဲ့ Top-To-အောက်ခြေခွဲခြားဆက်ဆံမှုအမိန့်ဖြင့်အမိန့်ထုတ်နေကြသည်။
///
/// ## Lexicographical နှိုင်းယှဉ်
///
/// Lexicographical နှိုင်းယှဉ်အောက်ပါဂုဏ်သတ္တိများနှင့်အတူစစ်ဆင်ရေးတစ်ခုဖြစ်ပါသည်:
///  - နှစျခုပာဒြပ်စင်များကဒြပ်စင်နှိုင်းယှဉ်လျှင်နေကြသည်။
///  - lexicographically လျော့နည်းသို့မဟုတ် သာ. ကြီးမြတ်သည်အခြားထက်ဖြစ်သော sequence ကိုပထမဦးဆုံးအမတိုက်ဆိုင်ဒြပ်စင်ပုံစံလုပ်ရန်။
///  - တဦးတည်း sequence ကိုအခြားတစ်ဦးရှေ့ဆက်ဖြစ်ပါတယ်လျှင်, တိုတောင်း sequence ကို lexicographically လျော့နည်းအခြားထက်ဖြစ်ပါတယ်။
///  - အကယ်၍ sequence နှစ်ခုသည်တူညီသော element များရှိပြီးတူညီသော length ရှိလျှင်၊ sequences lexicographically တူညီသည်။
///  - တစ်ဦးအချည်းနှီးသော sequence ကိုမဆို Non-ဗလာ sequence ကိုထက် lexicographically လျော့နည်းသည်။
///  - နှစ်ခုအချည်းနှီးပာ lexicographically တန်းတူဖြစ်ကြသည်။
///
/// ## အဘယ်သို့ငါ `Ord` အကောင်အထည်ဖော်နိုင်သလဲ
///
/// `Ord` အမျိုးအစားလည်း [`PartialOrd`] နှင့် [`Eq`] ([`PartialEq`] လိုအပ်ပါတယ်ရာ) ဖြစ်ကြောင်းလိုအပ်သည်။
///
/// ထိုအခါသင်သည် [`cmp`] များအတွက်အကောင်အထည်ဖော်မှုသတ်မှတ်ရပေမည်။သင်၏အမျိုးအစားလယ်ကွင်းများတွင် [`cmp`] ကိုသုံးခြင်းသည်အသုံးဝင်သည်။
///
/// [`PartialEq`], [`PartialOrd`] နှင့် `Ord` အကောင်အထည်ဖော်ရေး *မဖြစ်မနေ* အချင်းချင်းသဘောတူသည်။
/// ဒါကလျှင်သာအားလုံး `a` နှင့် `b` များအတွက် `a == b` နှင့် `Some(a.cmp(b)) == a.partial_cmp(b)` သည်မှန်လျှင်, `a.cmp(b) == Ordering::Equal` ဖြစ်ပါတယ်။
/// traits အချို့ကိုရယူပြီးအခြားသူများကိုကိုယ်တိုင်အကောင်အထည်ဖော်ခြင်းအားဖြင့်၎င်းတို့ကိုမတော်တဆသဘောမတူရန်လွယ်ကူသည်။
///
/// `id` နှင့် `name` ကိုလျစ်လျူရှု။ လူများကိုအမြင့်အားဖြင့်သာစီရန်လိုသည့်ဥပမာတစ်ခုဖြစ်သည်။
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// ဤနည်းလမ်းကို `self` နှင့် `other` အကြားတစ်ဦး [`Ordering`] ပြန်လည်ရောက်ရှိ။
    ///
    /// သဘောတူစာချုပ်အရ `self.cmp(&other)` သည်မှန်လျှင် `self <operator> other` ဟူသောအသုံးအနှုန်းနှင့်ကိုက်ညီသည့်အမိန့်ကိုပြန်လည်ပေးသည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// နှိုင်းယှဉ်ခြင်းနှင့်တန်ဖိုးနှစ်ခုအများဆုံးပြန်လည်ရောက်ရှိ။
    ///
    /// နှိုင်းယှဉ်တန်းတူဖြစ်သူတို့ကိုဆုံးဖြတ်သည်လျှင်ဒုတိယအငြင်းအခုံ Returns ။
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// တန်ဖိုးအနည်းဆုံးနှစ်ခုတန်ဖိုးကိုနှိုင်းယှဉ်ပြီးပြန်ပေးသည်။
    ///
    /// အကယ်၍ နှိုင်းယှဉ်မှုက၎င်းတို့အားတန်းတူဖြစ်သည်ဟုဆုံးဖြတ်ပါကပထမဆုံး argument ကို return ပြန်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// တန်ဖိုးတစ်ခုကိုသတ်မှတ်ထားသောကြားကာလသို့ကန့်သတ်ပါ။
    ///
    /// ပြန် `max` `self` `min` ထက်လျော့နည်းပါက `self` `max` ထက် သာ. ကြီးမြတ်နှင့် `min` လျှင်။
    /// ဒီလိုမှမဟုတ်ရင်ဒီ `self` ပြန်လည်ရောက်ရှိ။
    ///
    /// # Panics
    ///
    /// `min > max` လျှင် Panics ။
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// အနကျအဓိပ်ပါယျနိုင်တဲ့ macro အဆိုပါ trait `Ord` တစ်ခု impl ထုတ်လုပ်။
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// တစ်ဦးစီယူမှုကိုအဘို့နှိုင်းယှဉ်နိုင်တန်ဖိုးများများအတွက် Trait ။
///
/// အဆိုပါနှိုင်းယှဉ်အားလုံး `a`, `b` နှင့် `c` အဘို့, ကျေနပ်ရမယ်:
///
/// - asymmetry: ထို့နောက် `a < b` `!(a > b)` အဖြစ် `a > b` `!(a < b)` ခဲ့ရသည်လျှင်,နှင့်
/// - အကူးအပြောင်း: `a < b` နှင့် `b < c` `a < c` ဆိုလိုသည်။`==` နှင့် `>` နှစ်ခုလုံးအတွက်အတူတူထားရမည်။
///
/// သတိပြုရန်မှာဤလိုအပ်ချက်များသည် trait ကိုယ်တိုင်ကိုအချိုးအစားညီစွာဖြတ်သန်းရမည်ကိုဆိုလိုသည်။ `T: PartialOrd<U>` နှင့် `U: PartialOrd<V>` လျှင် `U: PartialOrd<T>` နှင့် `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// ဤသည် trait `#[derive]` နှငျ့အသုံးပွုနိုငျသညျ။`structs အပေါ် derive`d အခါ, က struct ရဲ့အဖွဲ့ဝင်တွေရဲ့ထိပ်-to-အောက်ခြေကြေငြာအမိန့်အပေါ်အခြေခံပြီးတစ်ဦး lexicographic သာသနာကိုထုတ်လုပ်ပါလိမ့်မယ်။
/// `enums အပေါ် derive`d အခါ, မျိုးကွဲသူတို့ရဲ့ Top-To-အောက်ခြေခွဲခြားဆက်ဆံမှုအမိန့်ဖြင့်အမိန့်ထုတ်နေကြသည်။
///
/// ## အဘယ်သို့ငါ `PartialOrd` အကောင်အထည်ဖော်နိုင်သလဲ
///
/// `PartialOrd` သာ default အနေနဲ့ကလပ်စကနေထုတ်လုပ်လိုက်တဲ့အခြားသူများနှင့်တကွ, [`partial_cmp`] နည်းလမ်းကိုအကောင်အထည်ဖော်ရာတွင်လိုအပ်သည်။
///
/// သို့သော်သူကတစ်ဦးစုစုပေါင်းအမိန့်ရှိသည်မဟုတ်ကြဘူးအရာအမျိုးအစားများများအတွက်သီးခြားအခြားသူများကိုအကောင်အထည်ဖေါ်ရန်ဖြစ်နိုင်သမျှနေဆဲဖြစ်သည်။
/// ဥပမာအားဖြင့်, ရေပေါ်အမှတ်ဂဏန်းအဘို့, `NaN < 0 == false` နှင့် `NaN >= 0 == false` (cf.
/// ကို IEEE 754-2008 အပိုင်း 5.11) ။
///
/// `PartialOrd` သင်၏အမျိုးအစား [`PartialEq`] ဖြစ်ရန်လိုအပ်သည်။
///
/// [`PartialEq`], `PartialOrd` နှင့် [`Ord`] အကောင်အထည်ဖော်ရေး *မဖြစ်မနေ* အချင်းချင်းသဘောတူသည်။
/// traits အချို့ကိုရယူပြီးအခြားသူများကိုကိုယ်တိုင်အကောင်အထည်ဖော်ခြင်းအားဖြင့်၎င်းတို့ကိုမတော်တဆသဘောမတူရန်လွယ်ကူသည်။
///
/// သင့်ရဲ့အမျိုးအစား [`Ord`] ဖြစ်ပါတယ်လျှင်သင် [`cmp`] အသုံးပြု. [`partial_cmp`] အကောင်အထည်ဖော်နိုင်သည်
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// သင်တို့သည်လည်းသင့်ရဲ့အမျိုးအစားရဲ့လယ်ကွင်းအပေါ် [`partial_cmp`] သုံးစွဲဖို့ကအသုံးဝင်ရှာတွေ့လိမ့်မည်။
/// ဤတွင် `Person` အမျိုးအစားများကို floating-point `height` field ရှိသည်။ ဥပမာအားဖြင့် sorting လုပ်ရန်အသုံးပြုသည်။
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// တ ဦး တည်းရှိပါကဤနည်းလမ်းကို `self` နှင့် `other` တန်ဖိုးများအကြားအမိန့်ပြန်လာ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// နှိုင်းယှဉ်မဖြစ်နိုင်သည့်အခါ:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// ဤနည်းလမ်းသည် (`self` နှင့် `other` အတွက်) စမ်းသပ်မှုနည်းပြီး `<` အော်ပရေတာကအသုံးပြုသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// ဤနည်းလမ်းကိုစမ်းသပ်မှုထက်နည်းသို့မဟုတ်တူညီ (`self` နှင့် `other` များအတွက်) နှင့် `<=` အော်ပရေတာများကအသုံးပြုသည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// ဤနည်းလမ်းသည် (`self` နှင့် `other` အတွက်) ထက် ပို၍ ကြီးသောစမ်းသပ်မှုဖြစ်ပြီး `>` operator မှအသုံးပြုသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// ဤနည်းလမ်းသည် (`self` နှင့် `other` အတွက်) ထက်ကြီးသည်သို့မဟုတ်တူညီကြောင်းစစ်ဆေးပြီး `>=` အော်ပရေတာကအသုံးပြုသည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// trait `PartialOrd` ၏အကျိုးသက်ရောက်မှုကိုထုတ်လုပ်သည့် macro ကိုရယူပါ။
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// တန်ဖိုးအနည်းဆုံးနှစ်ခုတန်ဖိုးကိုနှိုင်းယှဉ်ပြီးပြန်ပေးသည်။
///
/// အကယ်၍ နှိုင်းယှဉ်မှုက၎င်းတို့အားတန်းတူဖြစ်သည်ဟုဆုံးဖြတ်ပါကပထမဆုံး argument ကို return ပြန်သည်။
///
/// ပြည်တွင်းရွှေ့ပြောင်း [`Ord::min`] တစ်ခု alias ကိုအသုံးပြုသည်။
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// သတ်မှတ်ထားသောနှိုင်းယှဉ် function ကိုရိုသေလေးစားမှုနှင့်အတူနှစ်ဦးကိုတန်ဖိုးနိမ့်ဆုံး Returns ။
///
/// အကယ်၍ နှိုင်းယှဉ်မှုက၎င်းတို့အားတန်းတူဖြစ်သည်ဟုဆုံးဖြတ်ပါကပထမဆုံး argument ကို return ပြန်သည်။
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// ပြန်သတ်မှတ်ထားတဲ့ function ကိုမှအနိမ့်ဆုံးတန်ဖိုးအားပေးသည်သောဒြပ်စင်။
///
/// အကယ်၍ နှိုင်းယှဉ်မှုက၎င်းတို့အားတန်းတူဖြစ်သည်ဟုဆုံးဖြတ်ပါကပထမဆုံး argument ကို return ပြန်သည်။
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// နှိုင်းယှဉ်ခြင်းနှင့်တန်ဖိုးနှစ်ခုအများဆုံးပြန်လည်ရောက်ရှိ။
///
/// နှိုင်းယှဉ်တန်းတူဖြစ်သူတို့ကိုဆုံးဖြတ်သည်လျှင်ဒုတိယအငြင်းအခုံ Returns ။
///
/// ပြည်တွင်းရွှေ့ပြောင်း [`Ord::max`] တစ်ခု alias ကိုအသုံးပြုသည်။
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// သတ်မှတ်ထားသောနှိုင်းယှဉ် function ကိုရိုသေလေးစားမှုနှင့်အတူနှစ်ဦးကိုတန်ဖိုးများကိုအများဆုံး Returns ။
///
/// နှိုင်းယှဉ်တန်းတူဖြစ်သူတို့ကိုဆုံးဖြတ်သည်လျှင်ဒုတိယအငြင်းအခုံ Returns ။
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// ပြန်သတ်မှတ်ထားတဲ့ function ကိုကနေအမြင့်ဆုံးတန်ဖိုးကိုပေးသည်သောဒြပ်စင်။
///
/// နှိုင်းယှဉ်တန်းတူဖြစ်သူတို့ကိုဆုံးဖြတ်သည်လျှင်ဒုတိယအငြင်းအခုံ Returns ။
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// စရိုက်အမျိုးအစားများများအတွက် PartialEq, Eq, PartialOrd နှင့် Ord ၏အကောင်အထည်ဖော်ရေး
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // ဒီမှာအမိန့်ကိုပိုမိုအကောင်းဆုံးစည်းဝေးပွဲကို generate ရန်အရေးကြီးပါသည်။
                    // ပိုပြီးအင်ဖိုအတွက် <https://github.com/rust-lang/rust/issues/63758> ကိုကြည့်ပါ။
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // i8 ရဲ့ Casting နှင့်ပိုပြီးအကောင်းဆုံးစည်းဝေးပွဲကိုထုတ်ပေးထားတဲ့အမိန့်ခြားနားချက်အဖြစ်ပြောင်းလဲသွားသည်။
            //
            // ပိုပြီးအင်ဖိုအတွက် <https://github.com/rust-lang/rust/issues/66780> ကိုကြည့်ပါ။
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // လုံခြုံမှု: i8 အဖြစ် bool 0 င်သို့မဟုတ် 1 ပြန်လည်ရောက်ရှိဒါကြောင့်ခြားနားချက်အရာအားလုံးထက်မဖွစျနိုငျ
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &ထောက်ပြ

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}