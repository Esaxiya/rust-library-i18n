//! generic hash ထောက်ခံမှု။
//!
//! ဒီမော်ဂျူးတန်ဖိုးများ၏ [hash] တွက်ချက်ဖို့ယေဘုယျလမ်းပေးပါသည်။
//! hash အများဆုံး [`HashMap`] နှင့် [`HashSet`] နှင့်အတူအသုံးပြုကြသည်။
//!
//! [hash]: https://en.wikipedia.org/wiki/Hash_function
//! [`HashMap`]: ../../std/collections/struct.HashMap.html
//! [`HashSet`]: ../../std/collections/struct.HashSet.html
//!
//! hashable type တစ်ခုပြုလုပ်ရန်အရိုးရှင်းဆုံးနည်းလမ်းမှာ `#[derive(Hash)]` ကိုအသုံးပြုခြင်းဖြစ်သည်။
//!
//! # Examples
//!
//! ```rust
//! use std::collections::hash_map::DefaultHasher;
//! use std::hash::{Hash, Hasher};
//!
//! #[derive(Hash)]
//! struct Person {
//!     id: u32,
//!     name: String,
//!     phone: u64,
//! }
//!
//! let person1 = Person {
//!     id: 5,
//!     name: "Janet".to_string(),
//!     phone: 555_666_7777,
//! };
//! let person2 = Person {
//!     id: 5,
//!     name: "Bob".to_string(),
//!     phone: 555_666_7777,
//! };
//!
//! assert!(calculate_hash(&person1) != calculate_hash(&person2));
//!
//! fn calculate_hash<T: Hash>(t: &T) -> u64 {
//!     let mut s = DefaultHasher::new();
//!     t.hash(&mut s);
//!     s.finish()
//! }
//! ```
//!
//! အကယ်၍ တန်ဖိုးတစ်ခုမည်သို့မည်ပုံသိမ်းဆည်းထားသည်ကိုပိုမိုထိန်းချုပ်ရန်လိုအပ်ပါက [`Hash`] trait ကိုသင်အကောင်အထည်ဖော်ရန်လိုအပ်သည်။
//!
//!
//! ```rust
//! use std::collections::hash_map::DefaultHasher;
//! use std::hash::{Hash, Hasher};
//!
//! struct Person {
//!     id: u32,
//!     # #[allow(dead_code)]
//!     name: String,
//!     phone: u64,
//! }
//!
//! impl Hash for Person {
//!     fn hash<H: Hasher>(&self, state: &mut H) {
//!         self.id.hash(state);
//!         self.phone.hash(state);
//!     }
//! }
//!
//! let person1 = Person {
//!     id: 5,
//!     name: "Janet".to_string(),
//!     phone: 555_666_7777,
//! };
//! let person2 = Person {
//!     id: 5,
//!     name: "Bob".to_string(),
//!     phone: 555_666_7777,
//! };
//!
//! assert_eq!(calculate_hash(&person1), calculate_hash(&person2));
//!
//! fn calculate_hash<T: Hash>(t: &T) -> u64 {
//!     let mut s = DefaultHasher::new();
//!     t.hash(&mut s);
//!     s.finish()
//! }
//! ```

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::marker;

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use self::sip::SipHasher;

#[unstable(feature = "hashmap_internals", issue = "none")]
#[allow(deprecated)]
#[doc(hidden)]
pub use self::sip::SipHasher13;

mod sip;

/// တစ်ဦးက hashable အမျိုးအစား။
///
/// `Hash` အကောင်အထည်ဖော်အမျိုးအစားများ [`Hasher`] တစ်ခုဥပမာအားဖြင့်အတူ [`hash`] ed ဖြစ်နိုင်စွမ်းရှိပါတယ်။
///
/// ## `Hash` ကိုအကောင်အထည်ဖော်
///
/// အားလုံးလယ်ကွင်း `Hash` အကောင်အထည်ဖေါ်လျှင်သင် `#[derive(Hash)]` နှင့်အတူ `Hash` ရရှိနိုငျသညျ။
/// ရရှိလာတဲ့ hash တစ်ဦးချင်းစီကိုလယ်ပေါ် [`hash`] တောင်းဆိုထံမှတန်ဖိုးများပေါင်းစပ်ကြလိမ့်မည်။
///
/// ```
/// #[derive(Hash)]
/// struct Rustacean {
///     name: String,
///     country: String,
/// }
/// ```
///
/// သင်တစ်ဦးတန်ဖိုးကို hashed ဘယ်လိုပိုပြီးထိန်းချုပ်ထားဖို့လိုလျှင်သင်၏သင်တန်း `Hash` trait ကိုယ့်ကိုယ်ကိုအကောင်အထည်ဖော်နိုင်သည်
///
/// ```
/// use std::hash::{Hash, Hasher};
///
/// struct Person {
///     id: u32,
///     name: String,
///     phone: u64,
/// }
///
/// impl Hash for Person {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         self.id.hash(state);
///         self.phone.hash(state);
///     }
/// }
/// ```
///
/// ## `Hash` နှင့် `Eq`
///
/// `Hash` နှင့် [`Eq`] နှစ်ဦးစလုံးအကောင်အထည်ဖော်သောအခါ, အောက်ပါပိုင်ဆိုင်မှုရရှိထားသူအရေးကြီးသည်:
///
/// ```text
/// k1 == k2 -> hash(k1) == hash(k2)
/// ```
///
/// နှစ်ခုသော့ညီမျှလျှင်တနည်းအားဖြင့်၎င်းတို့၏ hash တွေကိုလည်းတန်းတူဖြစ်ရပါမည်။
/// [`HashMap`] နှင့် [`HashSet`] နှစ်ဦးစလုံးသည်ဤအပြုအမူအပေါ်အားကိုး။
///
/// ကျေးဇူးတင်စရာကိုသင် `#[derive(PartialEq, Eq, Hash)]` နှင့်အတူ [`Eq`] နှင့် `Hash` နှစ်ဦးစလုံး deriving တဲ့အခါမှာဒီပစ္စည်းဥစ္စာပိုင်ဆိုင်မှုစှဲအကြောင်းကိုစိုးရိမ်ပူပန်ရန်မလိုအပ်ပါလိမ့်မယ်။
///
///
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
/// [`HashSet`]: ../../std/collections/struct.HashSet.html
/// [`hash`]: Hash::hash
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Hash {
    /// ပေးထားသော [`Hasher`] ထဲသို့ဤတန်ဖိုးကိုထည့်သွင်းသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::{Hash, Hasher};
    ///
    /// let mut hasher = DefaultHasher::new();
    /// 7920.hash(&mut hasher);
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn hash<H: Hasher>(&self, state: &mut H);

    /// ဤအမျိုးအစား၏အချပ်ကိုပေးထားသော [`Hasher`] ထဲသို့ကျွေးသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::{Hash, Hasher};
    ///
    /// let mut hasher = DefaultHasher::new();
    /// let numbers = [6, 28, 496, 8128];
    /// Hash::hash_slice(&numbers, &mut hasher);
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    #[stable(feature = "hash_slice", since = "1.3.0")]
    fn hash_slice<H: Hasher>(data: &[Self], state: &mut H)
    where
        Self: Sized,
    {
        for piece in data {
            piece.hash(state);
        }
    }
}

// အဆိုပါ trait `Hash` မပါဘဲ prelude ကနေနိုင်တဲ့ macro `Hash` reexport မှသီးခြား module တစ်ခု။
pub(crate) mod macros {
    /// အနကျအဓိပ်ပါယျနိုင်တဲ့ macro အဆိုပါ trait `Hash` တစ်ခု impl ထုတ်လုပ်။
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Hash($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Hash;

/// တစ် ဦး မတရားအားဖြင့် bytes စီးဆင်းမှု hashing များအတွက် trait ။
///
/// `Hasher` ၏သာဓကများသောအားဖြင့်ဒေတာများတားဆီးခြင်းစဉ်ပြောင်းလဲသွားကြောင်းပြည်နယ်ကိုယ်စားပြုသည်။
///
/// `Hasher` ([`finish`] နှင့်အတူ) ထုတ်လုပ်လိုက်တဲ့ hash ကိုပြန်လည်ရယူရန်နှင့် (စသည်တို့ကို [`write`] နှင့် [`write_u8`] နှင့်အတူ) တစ်ခုဥပမာပြောရရင်သို့ bytes ၏ချပ်သကဲ့သို့ကောင်းစွာကိန်းရေးသားခြင်းများအတွက်မျှမျှတတအခြေခံ interface ကိုပေးပါသည်။
/// အချိန်အများစုမှာ `Hasher` ဖြစ်ရပ်ဟာ [`Hash`] trait နှင့် တွဲဖက်. အသုံးပြုကြသည်။
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::Hasher;
///
/// let mut hasher = DefaultHasher::new();
///
/// hasher.write_u32(1989);
/// hasher.write_u8(11);
/// hasher.write_u8(9);
/// hasher.write(b"Huh?");
///
/// println!("Hash is {:x}!", hasher.finish());
/// ```
///
/// [`finish`]: Hasher::finish
/// [`write`]: Hasher::write
/// [`write_u8`]: Hasher::write_u8
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Hasher {
    /// ဒါကြောင့်ဝေးရေးထားသောတန်ဖိုးများများအတွက် hash တန်ဖိုးကို Returns ။
    ///
    /// ၎င်း၏အမည်ကိုနေသော်လည်းအဆိုပါနည်းလမ်း hasher ရဲ့ပြည်တွင်းရေးပြည်နယ် reset မထားဘူး။
    /// အပိုဆောင်း [`write`] s ကိုလက်ရှိတန်ဖိုးကိုထံမှဆက်လက်ပါလိမ့်မယ်။
    /// သင်တစ်ဦးလတ်ဆတ်တဲ့ hash တန်ဖိုးကိုစတင်ရန်လိုအပ်လျှင်, သင်အသစ်တစ်ခု hasher ဖန်တီးရပါလိမ့်မယ်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::Hasher;
    ///
    /// let mut hasher = DefaultHasher::new();
    /// hasher.write(b"Cool!");
    ///
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    ///
    /// [`write`]: Hasher::write
    #[stable(feature = "rust1", since = "1.0.0")]
    fn finish(&self) -> u64;

    /// ဒီ `Hasher` သို့အချို့သောဒေတာရေးသားခဲ့သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::Hasher;
    ///
    /// let mut hasher = DefaultHasher::new();
    /// let data = [0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef];
    ///
    /// hasher.write(&data);
    ///
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write(&mut self, bytes: &[u8]);

    /// ဒီ hasher သို့တစ်ခုတည်း `u8` ရေးသားခဲ့သည်။
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u8(&mut self, i: u8) {
        self.write(&[i])
    }
    /// ဒီ hasher သို့တစ်ခုတည်း `u16` ရေးသားခဲ့သည်။
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u16(&mut self, i: u16) {
        self.write(&i.to_ne_bytes())
    }
    /// ဒီ hasher သို့တစ်ခုတည်း `u32` ရေးသားခဲ့သည်။
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u32(&mut self, i: u32) {
        self.write(&i.to_ne_bytes())
    }
    /// ဒီ hasher သို့တစ်ခုတည်း `u64` ရေးသားခဲ့သည်။
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u64(&mut self, i: u64) {
        self.write(&i.to_ne_bytes())
    }
    /// ဒီ hasher သို့တစ်ခုတည်း `u128` ရေးသားခဲ့သည်။
    #[inline]
    #[stable(feature = "i128", since = "1.26.0")]
    fn write_u128(&mut self, i: u128) {
        self.write(&i.to_ne_bytes())
    }
    /// ဒီ hasher သို့တစ်ခုတည်း `usize` ရေးသားခဲ့သည်။
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_usize(&mut self, i: usize) {
        self.write(&i.to_ne_bytes())
    }

    /// ဒီ hasher သို့တစ်ခုတည်း `i8` ရေးသားခဲ့သည်။
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i8(&mut self, i: i8) {
        self.write_u8(i as u8)
    }
    /// ဒီ hasher သို့တစ်ခုတည်း `i16` ရေးသားခဲ့သည်။
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i16(&mut self, i: i16) {
        self.write_u16(i as u16)
    }
    /// ဒီ hasher သို့တစ်ခုတည်း `i32` ရေးသားခဲ့သည်။
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i32(&mut self, i: i32) {
        self.write_u32(i as u32)
    }
    /// ဒီ hasher သို့တစ်ခုတည်း `i64` ရေးသားခဲ့သည်။
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i64(&mut self, i: i64) {
        self.write_u64(i as u64)
    }
    /// ဒီ hasher သို့တစ်ခုတည်း `i128` ရေးသားခဲ့သည်။
    #[inline]
    #[stable(feature = "i128", since = "1.26.0")]
    fn write_i128(&mut self, i: i128) {
        self.write_u128(i as u128)
    }
    /// ဒီ hasher သို့တစ်ခုတည်း `isize` ရေးသားခဲ့သည်။
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_isize(&mut self, i: isize) {
        self.write_usize(i as usize)
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<H: Hasher + ?Sized> Hasher for &mut H {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

/// [`Hasher`] ၏ဖြစ်ရပ်အတွက်တစ်ဦးက trait ။
///
/// `BuildHasher` ကိုပုံမှန်အားဖြင့် (ဥပမာအားဖြင့် [`HashMap`] မှ) သော့တစ်ခုစီအတွက် [`Hasher`] များကိုဖန်တီးရန်အသုံးပြုသည်။ ထို့ကြောင့်``Hasher`] တွင်ပြည်နယ်ပါဝင်သောကြောင့်ဖြစ်သည်။
///
///
/// `BuildHasher` တစ်ခုချင်းစီဥပမာ, [`build_hasher`] အသုံးပြုနေသူများကဖန်တီးအဆိုပါ [`Hasher`] s တူညီဖြစ်သင့်သည်။
/// bytes ၏တူညီသောစီးချင်းစီ hasher သို့ကျွေးမွေးလျှင်အကြောင်း,, တူညီတဲ့ output ကိုလည်းနေထုတ်လုပ်လိုက်တဲ့ပါလိမ့်မည်ဖြစ်ပါသည်။
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::RandomState;
/// use std::hash::{BuildHasher, Hasher};
///
/// let s = RandomState::new();
/// let mut hasher_1 = s.build_hasher();
/// let mut hasher_2 = s.build_hasher();
///
/// hasher_1.write_u32(8128);
/// hasher_2.write_u32(8128);
///
/// assert_eq!(hasher_1.finish(), hasher_2.finish());
/// ```
///
/// [`build_hasher`]: BuildHasher::build_hasher
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
///
#[stable(since = "1.7.0", feature = "build_hasher")]
pub trait BuildHasher {
    /// ဖန်တီးလိမ့်မည်ဟုသော hasher အမျိုးအစား။
    #[stable(since = "1.7.0", feature = "build_hasher")]
    type Hasher: Hasher;

    /// အသစ်တစ်ခုကို hasher ဖန်တီးပေးပါတယ်။
    ///
    /// တူညီသောဥပမာအားဖြင့်အပေါ် `build_hasher` မှတစ်ခုချင်းစီကိုဖုန်းခေါ်ဆိုမှု [`Hasher`] s ကိုတူညီထုတ်လုပ်သင့်ပါတယ်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::RandomState;
    /// use std::hash::BuildHasher;
    ///
    /// let s = RandomState::new();
    /// let new_s = s.build_hasher();
    /// ```
    #[stable(since = "1.7.0", feature = "build_hasher")]
    fn build_hasher(&self) -> Self::Hasher;
}

/// [`Hasher`] နှင့် [`Default`] ကိုအကောင်အထည်ဖော်သောအမျိုးအစားများအတွက်ပုံမှန် [`BuildHasher`] ဥပမာတစ်ခုကိုဖန်တီးရန်အသုံးပြုခဲ့သည်။
///
/// `BuildHasherDefault<H>` အမျိုးအစား `H` [`Hasher`] နှင့် [`Default`] အကောင်အထည်ဖော်ဆောင်ရွက်နေသော, သင်တစ်ဦးနဲ့သက်ဆိုင်တဲ့ [`BuildHasher`] ဥပမာအားဖြင့်မလိုအပ်ပေမယ့်ဘယ်သူမျှမသတ်မှတ်သောအခါသုံးနိုင်ပါသည်။
///
///
/// မဆို `BuildHasherDefault` [zero-sized] ဖြစ်ပါတယ်။၎င်းကို [`default`][method.default] ဖြင့်ဖန်တီးနိုင်သည်။
/// [`HashMap`] သို့မဟုတ် [`HashSet`] နှင့်အတူ `BuildHasherDefault` အသုံးပြုတဲ့အခါသူတို့သင့်လျော်သော [`Default`] သာဓကသူတို့ကိုယ်သူတို့အကောင်အထည်ဖော်ကတည်းက, ဒီပြုခံရဖို့မလိုအပ်ပါဘူး။
///
/// # Examples
///
/// မိမိစိတ်ကြိုက် [`BuildHasher`] များအတွက်သတ်မှတ် `BuildHasherDefault` အသုံးပြုခြင်း
/// [`HashMap`]:
///
/// ```
/// use std::collections::HashMap;
/// use std::hash::{BuildHasherDefault, Hasher};
///
/// #[derive(Default)]
/// struct MyHasher;
///
/// impl Hasher for MyHasher {
///     fn write(&mut self, bytes: &[u8]) {
///         // သင့်ရဲ့ hash algorithm ကိုကဒီမှာသွား!
///        unimplemented!()
///     }
///
///     fn finish(&self) -> u64 {
///         // သင့်ရဲ့ hash algorithm ကိုကဒီမှာသွား!
///         unimplemented!()
///     }
/// }
///
/// type MyBuildHasher = BuildHasherDefault<MyHasher>;
///
/// let hash_map = HashMap::<u32, u32, MyBuildHasher>::default();
/// ```
///
/// [method.default]: BuildHasherDefault::default
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
/// [`HashSet`]: ../../std/collections/struct.HashSet.html
/// [zero-sized]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#zero-sized-types-zsts
///
///
///
///
#[stable(since = "1.7.0", feature = "build_hasher")]
pub struct BuildHasherDefault<H>(marker::PhantomData<H>);

#[stable(since = "1.9.0", feature = "core_impl_debug")]
impl<H> fmt::Debug for BuildHasherDefault<H> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("BuildHasherDefault")
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
impl<H: Default + Hasher> BuildHasher for BuildHasherDefault<H> {
    type Hasher = H;

    fn build_hasher(&self) -> H {
        H::default()
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
impl<H> Clone for BuildHasherDefault<H> {
    fn clone(&self) -> BuildHasherDefault<H> {
        BuildHasherDefault(marker::PhantomData)
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
impl<H> Default for BuildHasherDefault<H> {
    fn default() -> BuildHasherDefault<H> {
        BuildHasherDefault(marker::PhantomData)
    }
}

#[stable(since = "1.29.0", feature = "build_hasher_eq")]
impl<H> PartialEq for BuildHasherDefault<H> {
    fn eq(&self, _other: &BuildHasherDefault<H>) -> bool {
        true
    }
}

#[stable(since = "1.29.0", feature = "build_hasher_eq")]
impl<H> Eq for BuildHasherDefault<H> {}

mod impls {
    use crate::mem;
    use crate::slice;

    use super::*;

    macro_rules! impl_write {
        ($(($ty:ident, $meth:ident),)*) => {$(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Hash for $ty {
                #[inline]
                fn hash<H: Hasher>(&self, state: &mut H) {
                    state.$meth(*self)
                }

                #[inline]
                fn hash_slice<H: Hasher>(data: &[$ty], state: &mut H) {
                    let newlen = data.len() * mem::size_of::<$ty>();
                    let ptr = data.as_ptr() as *const u8;
                    // လုံခြုံမှု: ဤနိုင်တဲ့ macro သာအသုံးပြုသည်အဖြစ် `ptr`, ခိုင်လုံသောနှင့် aligned ဖြစ်ပါသည်
                    // အဘယ်သူမျှမ padding ကိုရှိသည်သောကိန်းဂဏန်း Primitive သည်။
                    // `data` ဖြတ်ပြီးအသစ်ချပ်သာ span ကြောင့် `isize::MAX` ကျော်မဖွစျနိုငျဒါ mutated, နှင့်၎င်း၏စုစုပေါင်းအရွယ်အစားမူရင်း `data` အဖြစ်အတူတူပင်ဖြစ်ပါသည်ဘယ်တော့မှဖြစ်ပါတယ်။
                    //
                    state.write(unsafe { slice::from_raw_parts(ptr, newlen) })
                }
            }
        )*}
    }

    impl_write! {
        (u8, write_u8),
        (u16, write_u16),
        (u32, write_u32),
        (u64, write_u64),
        (usize, write_usize),
        (i8, write_i8),
        (i16, write_i16),
        (i32, write_i32),
        (i64, write_i64),
        (isize, write_isize),
        (u128, write_u128),
        (i128, write_i128),
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for bool {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write_u8(*self as u8)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for char {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write_u32(*self as u32)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for str {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write(self.as_bytes());
            state.write_u8(0xff)
        }
    }

    #[stable(feature = "never_hash", since = "1.29.0")]
    impl Hash for ! {
        #[inline]
        fn hash<H: Hasher>(&self, _: &mut H) {
            *self
        }
    }

    macro_rules! impl_hash_tuple {
        () => (
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Hash for () {
                #[inline]
                fn hash<H: Hasher>(&self, _state: &mut H) {}
            }
        );

        ( $($name:ident)+) => (
            #[stable(feature = "rust1", since = "1.0.0")]
            impl<$($name: Hash),+> Hash for ($($name,)+) where last_type!($($name,)+): ?Sized {
                #[allow(non_snake_case)]
                #[inline]
                fn hash<S: Hasher>(&self, state: &mut S) {
                    let ($(ref $name,)+) = *self;
                    $($name.hash(state);)+
                }
            }
        );
    }

    macro_rules! last_type {
        ($a:ident,) => { $a };
        ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
    }

    impl_hash_tuple! {}
    impl_hash_tuple! { A }
    impl_hash_tuple! { A B }
    impl_hash_tuple! { A B C }
    impl_hash_tuple! { A B C D }
    impl_hash_tuple! { A B C D E }
    impl_hash_tuple! { A B C D E F }
    impl_hash_tuple! { A B C D E F G }
    impl_hash_tuple! { A B C D E F G H }
    impl_hash_tuple! { A B C D E F G H I }
    impl_hash_tuple! { A B C D E F G H I J }
    impl_hash_tuple! { A B C D E F G H I J K }
    impl_hash_tuple! { A B C D E F G H I J K L }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: Hash> Hash for [T] {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            self.len().hash(state);
            Hash::hash_slice(self, state)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized + Hash> Hash for &T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            (**self).hash(state);
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized + Hash> Hash for &mut T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            (**self).hash(state);
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Hash for *const T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            #[cfg(not(bootstrap))]
            {
                let (address, metadata) = self.to_raw_parts();
                state.write_usize(address as usize);
                metadata.hash(state);
            }
            #[cfg(bootstrap)]
            {
                if mem::size_of::<Self>() == mem::size_of::<usize>() {
                    // Thin pointer
                    state.write_usize(*self as *const () as usize);
                } else {
                    // Fat pointer SAFETY-`self` ကသိမ်းဆည်းထားတဲ့မှတ်ဥာဏ်ကိုတရားဝင်ဖြစ်ဖို့အာမခံထားတယ်။
                    // ဒါကအဆီ pointer က `rustc` အတွက်အဆီထောက်ပြ၏အကောင်အထည်ဖော်မှုနှင့်အတူထပ်တူပြုခြင်းအတွက်တင်ပို့ခြင်းနှင့်ထားရှိမည်ကြောင့် `std` အတွက်လုပ်ဖို့ဘေးကင်းလုံခြုံသော `(usize, usize)` ဖြင့်ကိုယ်စားပြုနိုင်ပါသည်ယူဆတယ်။
                    //
                    //
                    //
                    //
                    let (a, b) = unsafe { *(self as *const Self as *const (usize, usize)) };
                    state.write_usize(a);
                    state.write_usize(b);
                }
            }
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Hash for *mut T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            #[cfg(not(bootstrap))]
            {
                let (address, metadata) = self.to_raw_parts();
                state.write_usize(address as usize);
                metadata.hash(state);
            }
            #[cfg(bootstrap)]
            {
                if mem::size_of::<Self>() == mem::size_of::<usize>() {
                    // Thin pointer
                    state.write_usize(*self as *const () as usize);
                } else {
                    // Fat pointer SAFETY-`self` ကသိမ်းဆည်းထားတဲ့မှတ်ဥာဏ်ကိုတရားဝင်ဖြစ်ဖို့အာမခံထားတယ်။
                    // ဒါကအဆီ pointer က `rustc` အတွက်အဆီထောက်ပြ၏အကောင်အထည်ဖော်မှုနှင့်အတူထပ်တူပြုခြင်းအတွက်တင်ပို့ခြင်းနှင့်ထားရှိမည်ကြောင့် `std` အတွက်လုပ်ဖို့ဘေးကင်းလုံခြုံသော `(usize, usize)` ဖြင့်ကိုယ်စားပြုနိုင်ပါသည်ယူဆတယ်။
                    //
                    //
                    //
                    //
                    let (a, b) = unsafe { *(self as *const Self as *const (usize, usize)) };
                    state.write_usize(a);
                    state.write_usize(b);
                }
            }
        }
    }
}