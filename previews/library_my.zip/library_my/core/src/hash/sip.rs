//! SipHash တစ်ခုအကောင်အထည်ဖော်မှု။

#![allow(deprecated)] // ဒီ module တစ်ခုအတွက်အမျိုးအစားများကန့်ကွက်နေကြသည်

use crate::cmp;
use crate::marker::PhantomData;
use crate::mem;
use crate::ptr;

/// SipHash 1-3 တစ်ခုအကောင်အထည်ဖော်မှု။
///
/// ၎င်းသည်ပုံမှန်စာကြည့်တိုက်မှအသုံးပြုသောပုံမှန် hashing function (ဥပမာ `collections::HashMap` ကပုံမှန်အားဖြင့်အသုံးပြုသည်) ဖြစ်သည်။
///
///
/// See: <https://131002.net/siphash>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
#[doc(hidden)]
pub struct SipHasher13 {
    hasher: Hasher<Sip13Rounds>,
}

/// SipHash 2-4 တစ်ခုအကောင်အထည်ဖော်မှု။
///
/// See: <https://131002.net/siphash/>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
struct SipHasher24 {
    hasher: Hasher<Sip24Rounds>,
}

/// SipHash 2-4 တစ်ခုအကောင်အထည်ဖော်မှု။
///
/// See: <https://131002.net/siphash/>
///
/// SipHash အထွေထွေ-ရည်ရွယ်ချက် hash function ကိုတစ်ခုဖြစ်သည်: က (Spooky နှင့်စီးတီးနှင့်အတူယှဉ်ပြိုင်) တစ်ဦးကောင်းမြန်နှုန်းမှာအလုပ်လုပ်ပြီးနှင့်ခိုင်ခံ့သော _keyed_ hash ခွင့်ပြုထားသည်။
///
/// ၎င်းသည် [`rand::os::OsRng`](https://doc.rust-lang.org/rand/rand/os/struct.OsRng.html) ကဲ့သို့ခိုင်မာသည့် RNG မှသင်၏ hash ဇယားများကို key လုပ်သည်။
///
/// SipHash algorithm ကိုယေဘုယျအားဖြင့်အားကောင်းသည်ဟုယူဆသော်လည်း၎င်းသည် cryptographic ရည်ရွယ်ချက်များအတွက်ရည်ရွယ်ခြင်းမဟုတ်ပါ။
/// ထိုကဲ့သို့သောအဖြစ်, ဒီအကောင်အထည်ဖော်မှု၏ cryptographic အသုံးပြုမှုအားလုံး _strongly discouraged_ ဖြစ်ကြသည်။
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
pub struct SipHasher(SipHasher24);

#[derive(Debug)]
struct Hasher<S: Sip> {
    k0: u64,
    k1: u64,
    length: usize, // မည်မျှ bytes ကျနော်တို့လုပ်ငန်းများ၌င့်
    state: State,  // hash ပြည်နယ်
    tail: u64,     // le bytes unprocessed
    ntail: usize,  // အမြီးထဲတွင် bytes မည်မျှတရားဝင်သည်
    _marker: PhantomData<S>,
}

#[derive(Debug, Clone, Copy)]
#[repr(C)]
struct State {
    // v0, v2 နှင့် v1, v3 သည် algorithm တွင်အတွဲလိုက်ပြပြီး SipHash ၏ simd Implementations များသည် v02 နှင့် v13 ၏ vectors ကိုအသုံးပြုလိမ့်မည်။
    //
    // အဆိုပါ struct ၌ဤအမိန့်မှာသူတို့ကိုအားမရခြင်းအားဖြင့်, အ compiler ကသူ့ဟာသူပဲအနည်းငယ် simd ပိုမိုကောင်းမွန်ရေးပေါ်တက်ကောက်လို့ရပါတယ်။
    //
    v0: u64,
    v2: u64,
    v1: u64,
    v3: u64,
}

macro_rules! compress {
    ($state:expr) => {{ compress!($state.v0, $state.v1, $state.v2, $state.v3) }};
    ($v0:expr, $v1:expr, $v2:expr, $v3:expr) => {{
        $v0 = $v0.wrapping_add($v1);
        $v1 = $v1.rotate_left(13);
        $v1 ^= $v0;
        $v0 = $v0.rotate_left(32);
        $v2 = $v2.wrapping_add($v3);
        $v3 = $v3.rotate_left(16);
        $v3 ^= $v2;
        $v0 = $v0.wrapping_add($v3);
        $v3 = $v3.rotate_left(21);
        $v3 ^= $v0;
        $v2 = $v2.wrapping_add($v1);
        $v1 = $v1.rotate_left(17);
        $v1 ^= $v2;
        $v2 = $v2.rotate_left(32);
    }};
}

/// LE နိုင်ရန်အတွက် byte stream မှလိုချင်သော type ကို integer တစ်ခုအဖြစ် load လုပ်သည်။
/// အဆိုပါ compiler တစ်ဦးဖြစ်နိုင်သည် unaligned လိပ်စာကနေ load ဖို့အထိရောက်ဆုံးနည်းလမ်းတစ်ခု generate စေ `copy_nonoverlapping` အသုံးပြုသည်။
///
///
/// မလုံခြုံသောကွောငျ့: i..i+size_of(int_ty) မှာအမှတ်ကိုဖြုတ်လိုက်ပါ indexing
macro_rules! load_int_le {
    ($buf:expr, $i:expr, $int_ty:ident) => {{
        debug_assert!($i + mem::size_of::<$int_ty>() <= $buf.len());
        let mut data = 0 as $int_ty;
        ptr::copy_nonoverlapping(
            $buf.as_ptr().add($i),
            &mut data as *mut _ as *mut u8,
            mem::size_of::<$int_ty>(),
        );
        data.to_le()
    }};
}

/// 7 bytes အထိ byte slice အထိသုံးပြီး u64 တစ်ခုကို load လုပ်တယ်။
/// ၎င်းသည်ရှုပ်ထွေးမှုမရှိသော်လည်း (`load_int_le!` မှတစ်ဆင့်) ဖြစ်ပေါ်လာသော `copy_nonoverlapping` ခေါ်ဆိုမှုများ၌သတ်မှတ်ထားသောအရွယ်အစားရှိပြီးအမြန်နှုန်းအတွက်ကောင်းသော `memcpy` ကိုခေါ်ဆိုခြင်းကိုရှောင်ကြဉ်ပါ။
///
///
/// မလုံခြုံသောကွောငျ့: start..start + Len မှာအမှတ်ကိုဖြုတ်လိုက်ပါ indexing
#[inline]
unsafe fn u8to64_le(buf: &[u8], start: usize, len: usize) -> u64 {
    debug_assert!(len < 8);
    let mut i = 0; // output ကို u64 အတွက် (LSB ကနေ) လက်ရှိ byte အညွှန်းကိန်း
    let mut out = 0;
    if i + 3 < len {
        // လုံခြုံမှု: `i` `len` ထက် သာ. ကြီးမြတ်မဖွစျနိုငျ, နှင့်ခေါ်ဆိုမှုမဖြစ်မနေအာမခံချက်
        // start..start + len သည်အညွှန်းကိန်းကိုသတ်မှတ်သည်။
        out = unsafe { load_int_le!(buf, start + i, u32) } as u64;
        i += 4;
    }
    if i + 1 < len {
        // လုံခြုံမှု-အထက်နှင့်အတူတူ။
        out |= (unsafe { load_int_le!(buf, start + i, u16) } as u64) << (i * 8);
        i += 2
    }
    if i < len {
        // လုံခြုံမှု-အထက်နှင့်အတူတူ။
        out |= (unsafe { *buf.get_unchecked(start + i) } as u64) << (i * 8);
        i += 1;
    }
    debug_assert_eq!(i, len);
    out
}

impl SipHasher {
    /// 0 ဟုသတ်မှတ်ထားသည့်ကန ဦး သော့နှစ်ခုဖြင့် `SipHasher` အသစ်တစ်ခုကိုဖန်တီးသည်။
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher {
        SipHasher::new_with_keys(0, 0)
    }

    /// ပေးထားသောသော့များအားပိတ်ထားသည့် `SipHasher` တစ်ခုကိုဖန်တီးသည်။
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher {
        SipHasher(SipHasher24 { hasher: Hasher::new_with_keys(key0, key1) })
    }
}

impl SipHasher13 {
    /// 0 င်ရန်သတ်မှတ်ထားနှစ်ခုကနဦးသော့နှင့်အတူသစ်တစ်ခု `SipHasher13` ဖန်တီးပေးပါတယ်။
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher13 {
        SipHasher13::new_with_keys(0, 0)
    }

    /// ပေးထားသည့်သော့ပိတ်ထားနှိပ်ပါသော `SipHasher13` ဖန်တီးပေးပါတယ်။
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher13 {
        SipHasher13 { hasher: Hasher::new_with_keys(key0, key1) }
    }
}

impl<S: Sip> Hasher<S> {
    #[inline]
    fn new_with_keys(key0: u64, key1: u64) -> Hasher<S> {
        let mut state = Hasher {
            k0: key0,
            k1: key1,
            length: 0,
            state: State { v0: 0, v1: 0, v2: 0, v3: 0 },
            tail: 0,
            ntail: 0,
            _marker: PhantomData,
        };
        state.reset();
        state
    }

    #[inline]
    fn reset(&mut self) {
        self.length = 0;
        self.state.v0 = self.k0 ^ 0x736f6d6570736575;
        self.state.v1 = self.k1 ^ 0x646f72616e646f6d;
        self.state.v2 = self.k0 ^ 0x6c7967656e657261;
        self.state.v3 = self.k1 ^ 0x7465646279746573;
        self.ntail = 0;
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl super::Hasher for SipHasher {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.0.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.0.hasher.finish()
    }
}

#[unstable(feature = "hashmap_internals", issue = "none")]
impl super::Hasher for SipHasher13 {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.hasher.finish()
    }
}

impl<S: Sip> super::Hasher for Hasher<S> {
    // Note: အဘယ်သူမျှမကိန်း hash နည်းလမ်းများ (`write_u *`, `write_i*`) သတ်မှတ်ကြပါတယ်
    // ဤအမျိုးအစားသည်။
    // ကျွန်တော်တို့သည်သူတို့အား add librustc_data_structures/sip128.rs အတွက် `short_write` အကောင်အထည်ဖော်မှုကူးယူနှင့် `SipHasher`, `SipHasher13` နှင့် `DefaultHasher` မှ `write_u *`/`write_i*` နည်းလမ်းများ add နိုင်ပါတယ်။
    //
    // ဤသည်ကိုအလွန်အနည်းငယ်အချို့ချမှတ်ထားသောသတ်မှတ်ချက်များကိုလျစ်အပေါ် compile လုပ်ခြင်းအမြန်နှုန်းနှေးကွေး၏ကုန်ကျစရိတ်မှာထို hashers အားဖြင့်တားဆီးခြင်းကိန်းအရှိန်မြှင့်လိမ့်မယ်။
    // အသေးစိတ်ကို #69152 ကိုကြည့်ပါ။
    //
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        let length = msg.len();
        self.length += length;

        let mut needed = 0;

        if self.ntail != 0 {
            needed = 8 - self.ntail;
            // လုံခြုံမှု: `cmp::min(length, needed)` သည် `length` ထက်မပိုရန်အာမခံထားသည်
            self.tail |= unsafe { u8to64_le(msg, 0, cmp::min(length, needed)) } << (8 * self.ntail);
            if length < needed {
                self.ntail += length;
                return;
            } else {
                self.state.v3 ^= self.tail;
                S::c_rounds(&mut self.state);
                self.state.v0 ^= self.tail;
                self.ntail = 0;
            }
        }

        // Buffered အမြီးယခုသှေးရောငျလှမျး, အသစ် input ကို process ။
        let len = length - needed;
        let left = len & 0x7; // len% 8

        let mut i = needed;
        while i < len - left {
            // လုံခြုံမှု-ဘာလို့လဲဆိုတော့ `len - left` ဟာ ၈ ခုအောက်မှာအများဆုံးဖြစ်တယ်
            // `len`, `i` `needed` မှ `len` `length - needed` ရှိရာမှစတင်သောကြောင့် `i + 8` သည် `length` ထက်နည်းသည်သို့မဟုတ်ညီမျှသည်ကိုအာမခံသည်။
            //
            let mi = unsafe { load_int_le!(msg, i, u64) };

            self.state.v3 ^= mi;
            S::c_rounds(&mut self.state);
            self.state.v0 ^= mi;

            i += 8;
        }

        // လုံခြုံမှု: `i` သည်ယခု `needed + len.div_euclid(8) * 8` ဖြစ်သည်။
        // `i + left` = `needed + len` = `msg.len()` မှတူညီချက်နှင့်အဓိပ္ပါယ်အားဖြင့်ဖြစ်သော `length`, ဒါ။
        //
        self.tail = unsafe { u8to64_le(msg, i, left) };
        self.ntail = left;
    }

    #[inline]
    fn finish(&self) -> u64 {
        let mut state = self.state;

        let b: u64 = ((self.length as u64 & 0xff) << 56) | self.tail;

        state.v3 ^= b;
        S::c_rounds(&mut state);
        state.v0 ^= b;

        state.v2 ^= 0xff;
        S::d_rounds(&mut state);

        state.v0 ^ state.v1 ^ state.v2 ^ state.v3
    }
}

impl<S: Sip> Clone for Hasher<S> {
    #[inline]
    fn clone(&self) -> Hasher<S> {
        Hasher {
            k0: self.k0,
            k1: self.k1,
            length: self.length,
            state: self.state,
            tail: self.tail,
            ntail: self.ntail,
            _marker: self._marker,
        }
    }
}

impl<S: Sip> Default for Hasher<S> {
    /// 0 င်ရန်သတ်မှတ်ထားနှစ်ခုကနဦးသော့နဲ့ `Hasher<S>` ဖန်တီးပေးပါတယ်။
    #[inline]
    fn default() -> Hasher<S> {
        Hasher::new_with_keys(0, 0)
    }
}

#[doc(hidden)]
trait Sip {
    fn c_rounds(_: &mut State);
    fn d_rounds(_: &mut State);
}

#[derive(Debug, Clone, Default)]
struct Sip13Rounds;

impl Sip for Sip13Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
    }
}

#[derive(Debug, Clone, Default)]
struct Sip24Rounds;

impl Sip for Sip24Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
        compress!(state);
    }
}