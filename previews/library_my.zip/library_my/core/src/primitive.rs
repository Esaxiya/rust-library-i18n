//! ဤသည် module သည်အခြားကြေငြာအမျိုးအစားများအားဖြင့်အရိပ်မဟုတ်ကြောင်းအသုံးပြုမှုခွင့်ပြုပါရန်စရိုက်အမျိုးအစားများကိုပြန်လည်တင်ပို့။
//!
//! ဤသည်ကိုသာမန်အားဖြင့် macro ထုတ်လုပ်ပြီးကုဒ်အတွက်သာအသုံးဝင်သည်။
//!
//! ဥပမာတစ်ခုအနေဖြင့် struct အသစ်တစ်ခုနှင့်၎င်းကိုသက်ရောက်စေသောအရာသည်ထုတ်လုပ်သည့်အခါဖြစ်သည်။
//!
//! ```rust,compile_fail
//! pub struct bool;
//!
//! impl QueryId for bool {
//!     const SOME_PROPERTY: bool = true;
//! }
//!
//! # trait QueryId { const SOME_PROPERTY: core::primitive::bool; }
//! ```
//!
//! သတိပြုရမည်မှာ `SOME_PROPERTY` နှင့်ဆက်နွယ်နေသောစဉ်ဆက်မပြတ်သည်၎င်း၏မူလ X0bool0Z အမျိုးအစားထက် `bool` သည် struct ကိုရည်ညွှန်းသောကြောင့် compile လုပ်မည်မဟုတ်ကြောင်းသတိပြုပါ။
//!
//!
//! မှန်ကန်သောအကောင်အထည်ဖော်မှုနှင့်တူနိုင်သည်
//!
//! ```rust
//! # #[allow(non_camel_case_types)]
//! pub struct bool;
//!
//! impl QueryId for bool {
//!     const SOME_PROPERTY: core::primitive::bool = true;
//! }
//!
//! # trait QueryId { const SOME_PROPERTY: core::primitive::bool; }
//! ```
//!

#[stable(feature = "core_primitive", since = "1.43.0")]
pub use bool;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use char;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use f32;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use f64;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i128;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i16;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i32;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i64;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i8;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use isize;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use str;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u128;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u16;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u32;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u64;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u8;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use usize;