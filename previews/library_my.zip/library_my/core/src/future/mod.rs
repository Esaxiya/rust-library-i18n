#![stable(feature = "futures_api", since = "1.36.0")]

//! ပြတ်တောင်းပြတ်တောင်းတန်ဖိုးများ။

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// ဒီအမျိုးအစားဖြစ်သောကြောင့်လိုအပ်:
///
/// တစ်) အထွေထွေကျွန်တော်တစ်ဦးကုန်ကြမ်း pointer (<https://github.com/rust-lang/rust/issues/68923> ကိုကြည့်ပါ) သွားတော်ဖို့လိုအပ်ဒါ `for<'a, 'b> Generator<&'a mut Context<'b>>` အကောင်အထည်မဖော်နိုင်ပါ။
///
/// ခ) ရော်ထောက်ပြခြင်းနှင့် `NonNull` `Send` သို့မဟုတ် `Sync` မဟုတ်, ဒါကြောင့်လည်းတိုင်းတစ်ခုတည်း future non-Send/Sync စေမယ်လို့နှင့်ကျွန်တော်မလိုချင်ကြဘူး။
///
/// ဒါဟာအစ HIR `.await` ၏လျှော့ချရိုးရှင်းစွာ။
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// တစ်ဦး future အတွက်မီးစက်ခြုံ။
///
/// ဒီ function ကအောက်မှာ `GenFuture` ကိုပြန်ပေးတယ်။ ဒါပေမယ့် X0 `impl Trait` ထဲမှာပုန်းနေတဲ့အမှားသတင်းစကားတွေ (`GenFuture<[closure.....]>` ထက် `impl Future`) ပေးပါလိမ့်မယ်။
///
// ဒါကကျနော်တို့ `const async fn` မှထမြောက်ပြီးနောက်အပိုအမှားများကိုရှောင်ရှားရန် `const` ဖြစ်ပါသည်
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // နောက်ခံမီးစက်တွင်မိမိကိုယ်ကိုကိုးကားရန်အတွက် async/await futures သည်မရွေ့မပြောင်းနိုင်သောအချက်ကိုကျွန်ုပ်တို့မှီခိုသည်။
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // လုံခြုံမှု: ကို Safe ကျနော်တို့ !Unpin + !Drop နေ, ဤရုံလယ်စီမံကိန်းကြောင့်။
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // တစ်ဦး `NonNull` ကုန်ကြမ်း pointer သို့ `&mut Context` လှည့်ခြင်း, မီးစက်ပြန်လည်စတင်။
            // အဆိုပါ `.await` လုံခြုံစိတ်ချစွာတစ်ဦး `&mut Context` ကိုပြန်ချမည်လျှော့ချ။
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // လုံခြုံမှု: `cx.0` ခိုင်လုံသော pointer ကြောင်းခေါ်ဆိုသူ၏မဖြစ်မနေအာမခံချက်
    // တစ်ခု mutable ရည်ညွှန်းအပေါငျးတို့သလိုအပ်ချက်များကိုဖြည့်။
    unsafe { &mut *cx.0.as_ptr().cast() }
}