//! အနုမြူဗုံးအမျိုးအစားများ
//!
//! Atomic အမျိုးအစားများသည် Thread များအကြား Primitive shared-memory ဆက်သွယ်မှုကိုပေးစွမ်းပြီးအခြားတစ်ပြိုင်နက်တည်းအမျိုးအစားများ၏တည်ဆောက်မှုလုပ်ကွက်များဖြစ်သည်။
//!
//! ဤ module သည်စသည်တို့ကို [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`] စသည့်ရှေး ဦး အမျိုးအစားအမျိုးမျိုး၏အနုမြူဗုံးပုံစံများကိုသတ်မှတ်သည်။
//! အနုမြူဗုံးအမျိုးအစားများသည်မှန်ကန်စွာအသုံးပြုသောအခါချည်များအကြားမွမ်းမံမှုများအားတပြေးညီဖြစ်စေသည့်လုပ်ဆောင်မှုများကိုတင်ပြသည်
//!
//! တစ်ခုချင်းစီကိုနည်းလမ်းကြောင်းစစ်ဆင်ရေးများအတွက်မှတ်ဉာဏ်အတားအဆီး၏ခွန်အားကိုကိုယ်စားပြုသည့် [`Ordering`] ကြာပါသည်။ဤအစီအစဉ်များသည် [C++20 atomic orderings][1] နှင့်အတူတူဖြစ်သည်။ပိုမိုသိရှိလိုပါကများအတွက် [nomicon][2] ကြည့်ပါ။
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! အနုမြူ variable တွေကိုချည်အကြားဝေစုမှဘေးကင်းလုံခြုံများမှာ (သူတို့ [`Sync`] အကောင်အထည်ဖေါ်) ပေမယ့်သူတို့ကိုယ်တိုင်ခွဲဝေမှုများအတွက်ယန္တရားများကို Rust ၏ [threading model](../../../std/thread/index.html#the-threading-model) နောက်သို့မလိုက်ကြဘူး။
//!
//! အက်တမ်တစ်ခု၏ variable ကိုဝေမျှရန်အသုံးအများဆုံးနည်းလမ်းမှာ၎င်းကိုအက်တမ်-အညွှန်း-တွက်ချက်ထားသောမျှဝေသည့် pointer တစ်ခုထဲသို့ထည့်သွင်းခြင်းဖြစ်သည်။
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! အက်တမ်အမျိုးအစားများကိုငြိမ်သောကိန်းရှင်များတွင်သိမ်းဆည်းထားနိုင်သည်။အနုမြူတည်ငြိမ်မှုကိုပျင်းရိသောကမ္ဘာလုံးဆိုင်ရာစတင်ခြင်းအတွက်မကြာခဏအသုံးပြုကြသည်။
//!
//! # Portability
//!
//! ဤ module ရှိအက်တမ်အမျိုးအစားအားလုံးသည် [lock-free] ဖြစ်နိုင်သည်ဆိုပါကအာမခံနိုင်သည်။ဤသည်ကိုသူတို့ပြည်တွင်းရွှေ့ပြောင်းကမ္ဘာလုံးဆိုင်ရာ mutex ဆည်းပူးကြဘူးဆိုလိုသည်။အနုမြူဗုံးအမျိုးအစားများနှင့်လုပ်ငန်းလည်ပတ်မှုများသည်စောင့်ဆိုင်းခြင်းကင်းရန်အာမခံချက်မရှိပါ။
//! ဆိုလိုသည်မှာ `fetch_or` ကဲ့သို့သောလုပ်ဆောင်မှုများကိုနှိုင်းယှဉ်ခြင်းနှင့်လဲလှယ်ခြင်းအစီအစဉ်ဖြင့်လုပ်ဆောင်နိုင်သည်။
//!
//! အက်တမ်စစ်ဆင်ရေးများကိုအရွယ်အစားကြီးမားသည့်အက်တမ်များဖြင့်ညွှန်ကြားချက်အလွှာတွင်အကောင်အထည်ဖော်နိုင်သည်။ဥပမာအားဖြင့်အချို့ပလက်ဖောင်းများသည် `AtomicI8` ကိုအကောင်အထည်ဖော်ရန် 4-byte အက်တမ်ညွှန်ကြားချက်များကိုအသုံးပြုသည်။
//! သတိပြုရမယ့်အချက်ကတော့ဒီအတုဟာကုဒ်မှန်ကန်မှုအပေါ်သက်ရောက်မှုမရှိသင့်ဘူးဆိုတာသတိပြုပါ။
//!
//! ဒီ module အတွက်အနုမြူဗုံးအမျိုးအစားများကိုပလက်ဖောင်းအားလုံးပေါ်တွင်မရရှိနိုင်ပါလိမ့်မည်မဟုတ်ပါ။ဤနေရာတွင်အက်တမ်အမျိုးအစားများအားလုံးကျယ်ပြန့်စွာရရှိနိုင်သည်။ ယေဘုယျအားဖြင့်ရှိပြီးသားများပေါ်တွင်မူတည်သည်။အချို့သောထင်ရှားသောခြွင်းချက်များမှာ-
//!
//! * PowerPC 32-bit pointers ပါသည့် MIPS ပလက်ဖောင်းများတွင် `AtomicU64` သို့မဟုတ် `AtomicI64` အမျိုးအစားများမရှိပါ။
//! * ARM Linux အဘို့မဟုတ် `armv5te` တူသောပလက်ဖောင်းသာ `load` နှင့် `store` စစ်ဆင်ရေးများကိုပေးစွမ်းနှင့်ထိုကဲ့သို့သောစသည်တို့ကို `swap`, `fetch_add` အဖြစ်နှိုင်းယှဉ်ခြင်းနှင့်လဲလှယ်ရေး (CAS) စစ်ဆင်ရေး, ထောကျပံ့ပေးပါဘူး
//! Linux အပေါ်ထို့အပြင်ဤ CAS စစ်ဆင်ရေးတစ်ခုစွမ်းဆောင်ရည်ပြစ်ဒဏ်နှင့်အတူမဝင်စေခြင်းငှါအရာ [operating system support] မှတဆင့်အကောင်အထည်ဖော်လျက်ရှိသည်။
//! * ARM `thumbv6m` နှင့်အတူပစ်မှတ်သာ `load` နှင့် `store` စစ်ဆင်ရေးများကိုပေးစွမ်းနှင့်ထိုကဲ့သို့သောစသည်တို့ကို `swap`, `fetch_add` အဖြစ်နှိုင်းယှဉ်ခြင်းနှင့်လဲလှယ်ရေး (CAS) စစ်ဆင်ရေး, ထောကျပံ့ပေးပါဘူး
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! သတိပြုရမည်မှာ future ပလက်ဖောင်းများကိုအက်တမ်စစ်ဆင်ရေးများအတွက်လည်းအထောက်အပံ့မပေးနိုင်သည့်ပေါင်းထည့်မှုများဖြစ်နိုင်သည်။အကျယ်ချဲ့ခရီးဆောင် code ကိုအနုမြူဗုံးအမျိုးအစားများကိုအသုံးပြုကြသည်ထားတဲ့အကြောင်းကိုသတိထားဖြစ်ချင်တယ်ပါလိမ့်မယ်။
//! `AtomicUsize` နှင့် `AtomicIsize` ယေဘုယျအားဖြင့်အများဆုံးခရီးဆောင်သော်လည်း, တောင်ထိုအခါသူတို့သည်နေရာတိုင်းကိုမရရှိနိုင်ပါတယ်။
//! ရည်ညွှန်းမှုအတွက် `std` စာကြည့်တိုက်သည် `core` မလိုအပ်သော်လည်းညှို့အရွယ်အက်တမ်လိုအပ်သည်။
//!
//! လောလောဆယ်သင်သည်အက်တမ်များနှင့်စည်းမျဉ်းစည်းကမ်းများကိုစည်းကြပ်ရန်အဓိကအားဖြင့် `#[cfg(target_arch)]` ကိုအသုံးပြုရန်လိုအပ်သည်။အဆိုပါ future အတွက်တည်ငြိမ်စေခြင်းငှါအရာကောင်းစွာအဖြစ်မတည်မငြိမ် `#[cfg(target_has_atomic)]` ရှိပါသည်။
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! ရိုးရိုး spinlock:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // သော့ခတ်လွှတ်ပေးရန်အခြားချည်ကိုစောင့်ပါ
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! တစ်ကမ္ဘာလုံးအတိုင်းအတာဖြင့်တိုက်ရိုက်ချည်ထားပါ
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Thread များအကြားလုံခြုံစွာမျှဝေနိုင်သော Boolean အမျိုးအစား။
///
/// ဤအမျိုးအစားတွင် [`bool`] ကဲ့သို့ In-memory ကိုယ်စားပြုမှုရှိသည်။
///
/// **မှတ်ချက်**: ဤအမျိုးအစားသည်အက်တမ်ဝန်နှင့် `u8` ၏စတိုးဆိုင်များကိုပံ့ပိုးသောပလက်ဖောင်းများပေါ်တွင်သာရရှိနိုင်ပါသည်။
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// တစ်ဦး `AtomicBool` `false` မှနဖန်တီးပေးပါတယ်။
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Send လုံးလုံးလြားလြား AtomicBool များအတွက်အကောင်အထည်ဖော်နေသည်။
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Thread များအကြားလုံခြုံစွာမျှဝေနိုင်သောကုန်ကြမ်း pointer အမျိုးအစား။
///
/// ဤအမျိုးအစားတွင် `*mut T` ကဲ့သို့ In-memory ကိုယ်စားပြုမှုရှိသည်။
///
/// **မှတ်ချက်**: ဤအမျိုးအစားသည်အနုမြူဗုံးဝန်နှင့်ထောက်ပြသည့်စတိုးဆိုင်များကိုထောက်ပံ့သောပလက်ဖောင်းများပေါ်တွင်သာရရှိနိုင်သည်။
/// ၎င်း၏အရွယ်အစားသည်ပစ်မှတ်ညွှန်ပြသူ၏အရွယ်အစားပေါ်တွင်မူတည်သည်။
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// null `AtomicPtr<T>` ကိုဖန်တီးသည်။
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// အနုမြူမှတ်ဉာဏ် Order
///
/// မှတ်ဉာဏ် Order အနုမြူဗုံးစစ်ဆင်ရေးမှတ်ဉာဏ်တွေကိုတပြိုင်တည်းအလုပ်လုပ်လမ်းကို specify ။
/// ယင်း၏အနည်းဆုံး [`Ordering::Relaxed`] များတွင်တိုက်ရိုက်စစ်ဆင်ရေးအားဖြင့်ထိမိမှသာမှတ်ဉာဏ်ညှိနေသည်။
/// အခြားတစ်ဖက်တွင်, [`Ordering::SeqCst`] စစ်ဆင်ရေးတစ်ခု store-load pair တစုံထို့အပြင်အားလုံးချည်ဖြတ်ပြီးထိုကဲ့သို့သောစစ်ဆင်ရေး၏စုစုပေါင်းအမိန့်ကိုထိန်းသိမ်းနေစဉ်အခြားမှတ်ဉာဏ်ထပ်တူပြု။
///
///
/// Rust ၏မှတ်ဉာဏ်အစီအစဉ်သည် [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order) ဖြစ်သည်။
///
/// ပိုမိုသိရှိလိုပါက [nomicon] တွင်ကြည့်ပါ။
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// အဘယ်သူမျှမမိန့်ကန့်သတ်, သာအနုမြူဗုံးစစ်ဆင်ရေး။
    ///
    /// C ++ 20 အတွက် [`memory_order_relaxed`] မှသတင်းထောက်။
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// စတိုးဆိုင်တစ်ခုနှင့်ချိတ်ဆက်သောအခါယခင်လုပ်ဆောင်မှုအားလုံးသည် [`Acquire`] (သို့မဟုတ်ပိုမိုအားကောင်းသည့်) အမိန့်များဖြင့်ဤတန်ဖိုးမ ၀ င်မီအမှာစာဖြစ်လာသည်။
    ///
    /// အထူးသဖြင့်ယခင်ရေးသားမှုအားလုံးသည်ဤတန်ဖိုး၏ [`Acquire`] (သို့မဟုတ်ပိုမိုအားကောင်းသော) ဝန်ကိုလုပ်ဆောင်သောချည်အားလုံးတွင်မြင်နိုင်သည်။
    ///
    /// ၀ န်ဆောင်မှုများနှင့်သိုလှောင်မှုများကိုပေါင်းစပ်ထားသည့်စစ်ဆင်ရေးတစ်ခုအတွက်ဤအမိန့်ကိုအသုံးပြုခြင်းသည် [`Relaxed`] ဝန်စစ်ဆင်ရေးသို့ ဦး တည်သွားကြောင်းသတိပြုပါ။
    ///
    /// ဤမှာကြားမှုသည်စတိုးဆိုင်တစ်ခုကိုလုပ်ဆောင်နိုင်သောလုပ်ငန်းများအတွက်သာအကျုံးဝင်သည်။
    ///
    /// C ++ 20 အတွက် [`memory_order_release`] မှသတင်းထောက်။
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// load နှင့်တွဲဖက်လိုက်သောအခါ loaded value ကို [`Release`] (သို့မဟုတ်ပိုမိုအားကောင်းသော) ordering ရှိသော store operator မှရေးသားခဲ့လျှင်နောက်ဆက်တွဲလုပ်ဆောင်မှုအားလုံးကိုထို store မှအမိန့်ပေးသည်။
    /// အထူးသဖြင့်နောက်ဆက်တွဲဝန်အားလုံးသည်စတိုးဆိုင်မတိုင်မီရေးသားထားသောအချက်အလက်များကိုတွေ့လိမ့်မည်။
    ///
    /// တစ်ဦး [`Relaxed`] စတိုးဆိုင်စစ်ဆင်ရေးမှဝန်နှင့်စတိုးဆိုင်များဆောင်ပေါင်းစပ်ထားတဲ့စစ်ဆင်ရေးအဘို့ဤသာသနာကိုသုံးပြီးကြောင်းသတိပြုပါ!
    ///
    /// ဒီအမိန့်ကိုဝန်လုပ်ဆောင်နိုင်သောစစ်ဆင်ရေးများအတွက်သာသက်ဆိုင်သည်။
    ///
    /// C ++ 20 ရှိ [`memory_order_acquire`] နှင့်ကိုက်ညီသည်။
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// [`Acquire`] နှင့် [`Release`] နှစ်ခုလုံး၏အကျိုးသက်ရောက်မှုများကိုအတူတကွပိုင်ဆိုင်သည်။
    /// ဝန်များအတွက်၎င်းသည် [`Acquire`] အစီအစဉ်ကိုအသုံးပြုသည်။စတိုးဆိုင်များအတွက်၎င်းသည် [`Release`] အစီအစဉ်ကိုအသုံးပြုသည်။
    ///
    /// `compare_and_swap` ၏ဖြစ်ရပ်အတွက်ကြောင့်စစ်ဆင်ရေးကိုမဆိုစတိုးဆိုင်ဖျော်ဖြေမပေးတက်အဆုံးသတ်ဖြစ်နိုင်သည်နှင့်ဤအရပ်ကပဲ [`Acquire`] သာသနာကိုရှိကြောင်းသတိပြုပါ။
    ///
    /// သို့သော် `AcqRel` [`Relaxed`] Access လုပ်ဆောင်ဘယ်တော့မှပါလိမ့်မယ်။
    ///
    /// ဤအမှာစာသည်ဝန်များနှင့်စတိုးဆိုင်များကိုပေါင်းစပ်ထားသောလုပ်ဆောင်မှုများအတွက်သာအကျုံးဝင်သည်။
    ///
    /// C ++ 20 အတွက် [`memory_order_acq_rel`] မှသတင်းထောက်။
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// [`Acquire`]/[`Release`]/[`AcqRel`](ဝန်၊ သိုလှောင်မှုနှင့် ၀ န်ဆောင်မှုနှင့်ဆိုင်သောလုပ်ငန်းများအတွက်အသီးသီး) ကဲ့သို့ချည်အားလုံးသည်တသမတ်တည်းတသမတ်တည်းလုပ်ဆောင်မှုအားလုံးကိုတူညီစွာကြည့်ရှုနိုင်ကြောင်းထပ်ဆောင်းအာမခံချက်နှင့်အတူ ။
    ///
    ///
    /// C ++ 20 ရှိ [`memory_order_seq_cst`] နှင့်ကိုက်ညီသည်။
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// တစ်ဦး [`AtomicBool`] `false` မှန။
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// သစ်တစ်ခု `AtomicBool` ဖန်တီးပေးပါတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// နောက်ခံ [`bool`] တစ်ခု mutable ရည်ညွှန်းပြန်သွားသည်။
    ///
    /// အဘယ်ကြောင့်ဆိုသော်ပြောင်းလဲနိုင်သောရည်ညွှန်းချက်သည်အခြားမည်သည့်ချည်မျှတပြိုင်နက်တည်းအက်တမ်အချက်အလက်များကိုရယူခြင်းမရှိကြောင်းအာမခံသောကြောင့်ဖြစ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // လုံခြုံမှု-ပြောင်းလဲနိုင်သောရည်ညွှန်းသည်ထူးခြားသောပိုင်ဆိုင်မှုကိုအာမခံသည်။
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// `&mut bool` သို့အနုမြူဗုံးသုံးခွင့်ပြုပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // လုံခြုံမှု-ပြောင်းလဲနိုင်သောရည်ညွှန်းသည်ထူးခြားသောပိုင်ဆိုင်မှုကိုအာမခံသည်
        // `bool` နှင့် `Self` နှစ်ခုစလုံး၏ချိန်ညှိမှုသည် ၁ ဖြစ်သည်။
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// အက်တမ်ကိုစားသုံးပြီးပါ ၀ င်သောတန်ဖိုးကိုပြန်လည်ပေးသည်။
    ///
    /// ဘာကြောင့်လဲဆိုတော့ `self` ကို value ဖြင့်ဖြတ်သန်းခြင်းသည်အခြားမည်သည့် thread မျှတပြိုင်နက်တည်း atomic data ကိုရယူခြင်းမရှိကြောင်းအာမခံသောကြောင့်ဖြစ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// bool မှတန်ဖိုးတစ်ခုကို load လုပ်သည်။
    ///
    /// `load` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်အမိန့်ကိုဖော်ပြသည်ထားတဲ့ [`Ordering`] အငြင်းအခုံကြာပါသည်။
    /// ဖြစ်နိုင်သောတန်ဖိုးများမှာ [`SeqCst`], [`Acquire`] နှင့် [`Relaxed`] ဖြစ်သည်။
    ///
    /// # Panics
    ///
    /// `order` [`Release`] သို့မဟုတ် [`AcqRel`] ဖြစ်ပါက Panics ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // လုံခြုံမှု: မည်သည့်ဒေတာများလူမျိုးအနုမြူဗုံးအခ်ါများနှင့်ကုန်ကြမ်းများကတားဆီးလျက်ရှိသည်
        // ကျွန်တော်တစ် ဦး ကိုကိုးကားထံမှတယ်ဘာဖြစ်လို့လဲဆိုတော့အတွက်ကူး pointer တရားဝင်သည်။
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// အဆိုပါ bool သို့တန်ဖိုးကိုသိုလှောင်ပါသည်။
    ///
    /// `store` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်အမိန့်ကိုဖော်ပြသည်ထားတဲ့ [`Ordering`] အငြင်းအခုံကြာပါသည်။
    /// ဖြစ်နိုင်သောတန်ဖိုးများမှာ [`SeqCst`], [`Release`] နှင့် [`Relaxed`] ဖြစ်သည်။
    ///
    /// # Panics
    ///
    /// `order` [`Acquire`] သို့မဟုတ် [`AcqRel`] ဖြစ်ပါက Panics ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // လုံခြုံမှု: မည်သည့်ဒေတာများလူမျိုးအနုမြူဗုံးအခ်ါများနှင့်ကုန်ကြမ်းများကတားဆီးလျက်ရှိသည်
        // ကျွန်တော်တစ် ဦး ကိုကိုးကားထံမှတယ်ဘာဖြစ်လို့လဲဆိုတော့အတွက်ကူး pointer တရားဝင်သည်။
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// ယခင်တန်ဖိုးကိုပြန်, အ bool သို့တန်ဖိုးကိုသိုလှောင်ပါသည်။
    ///
    /// `swap` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်အမိန့်ကိုဖော်ပြသည်ထားတဲ့ [`Ordering`] အငြင်းအခုံကြာပါသည်။အားလုံးမှာယူသည် Modes သာဖြစ်နိုင်သည်။
    /// [`Acquire`] ကိုအသုံးပြုခြင်းသည်စတိုးဆိုင်၏အစိတ်အပိုင်းတစ်ခုဖြစ်သော [`Relaxed`] ကိုဖြစ်စေပြီး [`Release`] ကိုအသုံးပြုခြင်းသည်ဝန်ဆောင်မှုများကို [`Relaxed`] ဖြစ်စေသည်ကိုသတိပြုပါ။
    ///
    ///
    /// **Note:** ဤနည်းလမ်းကို `u8` ရှိအက်တမ်စစ်ဆင်ရေးများကိုထောက်ပံ့သောပလက်ဖောင်းများပေါ်တွင်သာရရှိနိုင်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // လုံခြုံမှု-ဒေတာပြိုင်ပွဲများကိုအနုမြူသတ္တိကြွအားဖြင့်တားဆီးသည်။
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// လက်ရှိတန်ဖိုး `current` တန်ဖိုးနှင့်တူညီပါက [`bool`] ထဲသို့တန်ဖိုးတစ်ခုသိုလှောင်ထားသည်။
    ///
    /// return value သည်အမြဲတမ်းယခင်တန်ဖိုးဖြစ်သည်။အကယ်၍ ၎င်းသည် `current` နှင့်ညီလျှင်တန်ဖိုးကိုမွမ်းမံခဲ့သည်။
    ///
    /// `compare_and_swap` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်အမိန့်ကိုဖော်ပြသည်သည့် [`Ordering`] အငြင်းအခုံကြာပါသည်။
    /// [`AcqRel`] ကိုသုံးသော်ငြားလည်း X0 `Release` semantics မရှိသောကြောင့် `Acquire` load ကိုလုပ်ဆောင်နိုင်မည်ဖြစ်သော်လည်းဤလုပ်ဆောင်ချက်သည်ပျက်ကွက်သွားနိုင်ကြောင်းသတိပြုပါ။
    /// ကဖြစ်ပျက်လျှင် [`Acquire`] အသုံးပြုခြင်းသည်ဤစစ်ဆင်ရေး [`Relaxed`] ၏စတိုးဆိုင်တစ်စိတ်တစ်ပိုင်းစေသည်နှင့် [`Release`] သုံးပြီးဝန်တစ်စိတ်တစ်ပိုင်း [`Relaxed`] စေသည်။
    ///
    /// **Note:** ဤနည်းလမ်းကို `u8` ရှိအက်တမ်စစ်ဆင်ရေးများကိုထောက်ပံ့သောပလက်ဖောင်းများပေါ်တွင်သာရရှိနိုင်သည်။
    ///
    /// # `compare_exchange` နှင့် `compare_exchange_weak` သို့ပြောင်းရွှေ့ခြင်း
    ///
    /// `compare_and_swap` `compare_exchange` နှင့်ညီမျှသည်မှာအောက်ပါမှတ်ဥာဏ်အတွက်ဖြစ်သည်။
    ///
    /// မူရင်း။အောင်မြင်မှုပျက်ကွက်
    /// -------- | ------- | -------
    /// လျှော့ပေါ့လျှော့ပေါ့စိတ်အေးလက်အေးရယူ |ရယူပါလွှတ်ပေးရန်ထုတ်ပြန် |ဖြေလျှော့ AcqRel |AcqRel |SeqCst ကိုရယူပါSeqCst |SeqCst
    ///
    /// `compare_exchange_weak` နှိုင်းယှဉ်မှုအောင်မြင်လျှင်ပင် compiler နှင့်နှိုင်းယှဉ်မှုနှင့်လဲလှယ်မှုနှုန်းသည်ကွင်းဆက်တွင်ပိုမိုကောင်းမွန်သော assembly code ကိုထုတ်ပေးရန်အတွက် spuriously ကျရှုံးရန်ဖြစ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// လက်ရှိတန်ဖိုး `current` တန်ဖိုးနှင့်တူညီပါက [`bool`] ထဲသို့တန်ဖိုးတစ်ခုသိုလှောင်ထားသည်။
    ///
    /// အဆိုပါပြန်လာတန်ဖိုးကိုရလဒ်သစ်ကိုတနျဖိုးရေးသားခဲ့ရှိမရှိကိုညွှန်းများနှင့်ယခင်တန်ဖိုးကိုင်ဖြစ်ပါတယ်။
    /// အောင်မြင်မှုပေါ်မှာဤတန်ဖိုးကို `current` ညီမျှဖြစ်အာမခံချက်ဖြစ်ပါတယ်။
    ///
    /// `compare_exchange` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်သာသနာကိုဖော်ပြရန်နှစ်ခု [`Ordering`] အငြင်းပွားမှုများကြာပါသည်။
    /// `success` `current` နှင့်အတူနှိုင်းယှဉ်အောင်မြင်လျှင်ရာအရပ်ကိုကြာသောဖတ်ပြီးသား-Modify-ရေးစစ်ဆင်ရေးများအတွက်လိုအပ်သောသာသနာကိုဖော်ပြသည်။
    /// `failure` နှိုင်းယှဉ်ပျက်ကွက်သည့်အခါရာအရပ်ကိုကြာသောဝန်စစ်ဆင်ရေးများအတွက်လိုအပ်သောသာသနာကိုဖော်ပြသည်။
    /// [`Acquire`] ကိုအောင်မြင်စွာအမှာစာအဖြစ်အသုံးပြုခြင်းသည်စတိုးဆိုင်၏အစိတ်အပိုင်းတစ်ခုဖြစ်သော [`Relaxed`] ကိုဖြစ်စေသည်။ [`Release`] ကိုအသုံးပြုခြင်းက [`Relaxed`] ကို ၀ န်ဆောင်မှုပေးသည်။
    ///
    /// ပျက်ကွက်မှုမှာယူမှုသည် [`SeqCst`], [`Acquire`] သို့မဟုတ် [`Relaxed`] သာဖြစ်နိုင်ပြီးအောင်မြင်မှုမှာယူသည်ထက်ညီသည်သို့မဟုတ်အားနည်းသည်။
    ///
    /// **Note:** ဤနည်းလမ်းကို `u8` ရှိအက်တမ်စစ်ဆင်ရေးများကိုထောက်ပံ့သောပလက်ဖောင်းများပေါ်တွင်သာရရှိနိုင်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // လုံခြုံမှု-ဒေတာပြိုင်ပွဲများကိုအနုမြူသတ္တိကြွအားဖြင့်တားဆီးသည်။
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// လက်ရှိတန်ဖိုး `current` တန်ဖိုးနှင့်တူညီပါက [`bool`] ထဲသို့တန်ဖိုးတစ်ခုသိုလှောင်ထားသည်။
    ///
    /// [`AtomicBool::compare_exchange`] နှင့်မတူဘဲ၊ နှိုင်းယှဉ်မှုအောင်မြင်ပြီးသည့်တိုင်၎င်းလုပ်ဆောင်မှုသည်အချို့သောပလက်ဖောင်းများပေါ်တွင်ပိုမိုထိရောက်သောကုဒ်ကိုဖြစ်ပေါ်စေသည့်တိုင်၎င်းလုပ်ဆောင်မှုကိုပျက်ကွက်စေရန်ခွင့်ပြုထားသည်။
    ///
    /// အဆိုပါပြန်လာတန်ဖိုးကိုရလဒ်သစ်ကိုတနျဖိုးရေးသားခဲ့ရှိမရှိကိုညွှန်းများနှင့်ယခင်တန်ဖိုးကိုင်ဖြစ်ပါတယ်။
    ///
    /// `compare_exchange_weak` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်သာသနာကိုဖော်ပြရန်နှစ်ခု [`Ordering`] အငြင်းပွားမှုများကြာပါသည်။
    /// `success` `current` နှင့်အတူနှိုင်းယှဉ်အောင်မြင်လျှင်ရာအရပ်ကိုကြာသောဖတ်ပြီးသား-Modify-ရေးစစ်ဆင်ရေးများအတွက်လိုအပ်သောသာသနာကိုဖော်ပြသည်။
    /// `failure` နှိုင်းယှဉ်ပျက်ကွက်သည့်အခါရာအရပ်ကိုကြာသောဝန်စစ်ဆင်ရေးများအတွက်လိုအပ်သောသာသနာကိုဖော်ပြသည်။
    /// [`Acquire`] ကိုအောင်မြင်စွာအမှာစာအဖြစ်အသုံးပြုခြင်းသည်စတိုးဆိုင်၏အစိတ်အပိုင်းတစ်ခုဖြစ်သော [`Relaxed`] ကိုဖြစ်စေသည်။ [`Release`] ကိုအသုံးပြုခြင်းက [`Relaxed`] ကို ၀ န်ဆောင်မှုပေးသည်။
    /// ပျက်ကွက်မှုမှာယူမှုသည် [`SeqCst`], [`Acquire`] သို့မဟုတ် [`Relaxed`] သာဖြစ်နိုင်ပြီးအောင်မြင်မှုမှာယူသည်ထက်ညီသည်သို့မဟုတ်အားနည်းသည်။
    ///
    /// **Note:** ဤနည်းလမ်းကို `u8` ရှိအက်တမ်စစ်ဆင်ရေးများကိုထောက်ပံ့သောပလက်ဖောင်းများပေါ်တွင်သာရရှိနိုင်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // လုံခြုံမှု-ဒေတာပြိုင်ပွဲများကိုအနုမြူသတ္တိကြွအားဖြင့်တားဆီးသည်။
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// boolean တန်ဖိုးနှင့်အတူ Logical "and" ။
    ///
    /// လက်ရှိတန်ဖိုးကိုနှင့်အငြင်းအခုံ `val` အပေါ် performance တစ်ခုယုတ္တိ "and" စစ်ဆင်ရေးများနှင့်ရလဒ်မှသစ်ကိုတန်ဖိုးကိုသတ်မှတ်။
    ///
    /// ယခင်တန်ဖိုးကိုပြန်သွားသည်။
    ///
    /// `fetch_and` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်အမိန့်ကိုဖော်ပြသည်ထားတဲ့ [`Ordering`] အငြင်းအခုံကြာပါသည်။အားလုံးမှာယူသည် Modes သာဖြစ်နိုင်သည်။
    /// [`Acquire`] ကိုအသုံးပြုခြင်းသည်စတိုးဆိုင်၏အစိတ်အပိုင်းတစ်ခုဖြစ်သော [`Relaxed`] ကိုဖြစ်စေပြီး [`Release`] ကိုအသုံးပြုခြင်းသည်ဝန်ဆောင်မှုများကို [`Relaxed`] ဖြစ်စေသည်ကိုသတိပြုပါ။
    ///
    ///
    /// **Note:** ဤနည်းလမ်းကို `u8` ရှိအက်တမ်စစ်ဆင်ရေးများကိုထောက်ပံ့သောပလက်ဖောင်းများပေါ်တွင်သာရရှိနိုင်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // လုံခြုံမှု-ဒေတာပြိုင်ပွဲများကိုအနုမြူသတ္တိကြွအားဖြင့်တားဆီးသည်။
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// boolean တန်ဖိုးနှင့်အတူ Logical "nand" ။
    ///
    /// လက်ရှိတန်ဖိုးနှင့်အငြင်းအခုံ `val` အပေါ်တစ် ဦး ယုတ္တိ "nand" စစ်ဆင်ရေးလုပ်ဆောင်နှင့်ရလဒ်အသစ်တန်ဖိုးကိုသတ်မှတ်။
    ///
    /// ယခင်တန်ဖိုးကိုပြန်သွားသည်။
    ///
    /// `fetch_nand` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်အမိန့်ကိုဖော်ပြသည်ထားတဲ့ [`Ordering`] အငြင်းအခုံကြာပါသည်။အားလုံးမှာယူသည် Modes သာဖြစ်နိုင်သည်။
    /// [`Acquire`] ကိုအသုံးပြုခြင်းသည်စတိုးဆိုင်၏အစိတ်အပိုင်းတစ်ခုဖြစ်သော [`Relaxed`] ကိုဖြစ်စေပြီး [`Release`] ကိုအသုံးပြုခြင်းသည်ဝန်ဆောင်မှုများကို [`Relaxed`] ဖြစ်စေသည်ကိုသတိပြုပါ။
    ///
    ///
    /// **Note:** ဤနည်းလမ်းကို `u8` ရှိအက်တမ်စစ်ဆင်ရေးများကိုထောက်ပံ့သောပလက်ဖောင်းများပေါ်တွင်သာရရှိနိုင်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // ဒါကြောင့်တစ်ဦးမှာမမှန်ကန်တန်ဖိုးကိုအတူ bool ဖြစ်ပေါ်နိုင်ပါတယ်ဘာဖြစ်လို့လဲဆိုတော့ကျနော်တို့ကဒီမှာ atomic_nand မသုံးနိုငျသညျ။
        // အဘယ်ကြောင့်ဆိုသော်အနုမြူဗုံးသည် 8-bit integer တစ်ခုနှင့် ပြုလုပ်၍ အထက် 7 bits ကိုသတ်မှတ်ပေးသောကြောင့်ဖြစ်သည်။
        //
        // fetch_xor ဒါမှမဟုတ် swap ကိုသုံးတာပါ။
        if val {
            // (က x&မှန်)== !x ကျနော်တို့ bool ပြောင်းပြန်လှန်လိုက်ပါရမည်ဖြစ်သည်။
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==true bool ကိုမှန်အောင်ထားရမည်။
            //
            self.swap(true, order)
        }
    }

    /// boolean တန်ဖိုးနှင့်အတူ Logical "or" ။
    ///
    /// လက်ရှိတန်ဖိုးနှင့်အငြင်းအခုံ `val` အပေါ်တစ် ဦး ယုတ္တိ "or" စစ်ဆင်ရေးလုပ်ဆောင်နှင့်ရလဒ်အသစ်တန်ဖိုးကိုသတ်မှတ်။
    ///
    /// ယခင်တန်ဖိုးကိုပြန်သွားသည်။
    ///
    /// `fetch_or` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်အမိန့်ကိုဖော်ပြသည်ထားတဲ့ [`Ordering`] အငြင်းအခုံကြာပါသည်။အားလုံးမှာယူသည် Modes သာဖြစ်နိုင်သည်။
    /// [`Acquire`] ကိုအသုံးပြုခြင်းသည်စတိုးဆိုင်၏အစိတ်အပိုင်းတစ်ခုဖြစ်သော [`Relaxed`] ကိုဖြစ်စေပြီး [`Release`] ကိုအသုံးပြုခြင်းသည်ဝန်ဆောင်မှုများကို [`Relaxed`] ဖြစ်စေသည်ကိုသတိပြုပါ။
    ///
    ///
    /// **Note:** ဤနည်းလမ်းကို `u8` ရှိအက်တမ်စစ်ဆင်ရေးများကိုထောက်ပံ့သောပလက်ဖောင်းများပေါ်တွင်သာရရှိနိုင်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // လုံခြုံမှု-ဒေတာပြိုင်ပွဲများကိုအနုမြူသတ္တိကြွအားဖြင့်တားဆီးသည်။
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// တစ်ဦး boolean value ကိုအတူ logical "xor" ။
    ///
    /// လက်ရှိတန်ဖိုးနှင့်အငြင်းအခုံ `val` အပေါ်တစ် ဦး ယုတ္တိ "xor" စစ်ဆင်ရေးလုပ်ဆောင်နှင့်ရလဒ်အသစ်တန်ဖိုးကိုသတ်မှတ်။
    ///
    /// ယခင်တန်ဖိုးကိုပြန်သွားသည်။
    ///
    /// `fetch_xor` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်အမိန့်ကိုဖော်ပြသည်ထားတဲ့ [`Ordering`] အငြင်းအခုံကြာပါသည်။အားလုံးမှာယူသည် Modes သာဖြစ်နိုင်သည်။
    /// [`Acquire`] ကိုအသုံးပြုခြင်းသည်စတိုးဆိုင်၏အစိတ်အပိုင်းတစ်ခုဖြစ်သော [`Relaxed`] ကိုဖြစ်စေပြီး [`Release`] ကိုအသုံးပြုခြင်းသည်ဝန်ဆောင်မှုများကို [`Relaxed`] ဖြစ်စေသည်ကိုသတိပြုပါ။
    ///
    ///
    /// **Note:** ဤနည်းလမ်းကို `u8` ရှိအက်တမ်စစ်ဆင်ရေးများကိုထောက်ပံ့သောပလက်ဖောင်းများပေါ်တွင်သာရရှိနိုင်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // လုံခြုံမှု-ဒေတာပြိုင်ပွဲများကိုအနုမြူသတ္တိကြွအားဖြင့်တားဆီးသည်။
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// နောက်ခံ [`bool`] သို့ mutable pointer တစ်ခုသို့ပြန်သွားသည်။
    ///
    /// အနုမြူဗုံးမဟုတ်သောအရာများကိုဖတ်ခြင်းနှင့်ရေးသားခြင်းသည်ကိန်းဂဏန်းများဖြစ်နိုင်သည်။
    /// ဤနည်းလမ်းသည်များသောအားဖြင့် FFI အတွက်အသုံးဝင်သည်။ function signature သည် `&AtomicBool` အစား `*mut bool` ကိုသုံးနိုင်သည်။
    ///
    /// အက်တမ်အမျိုးအစားများသည်အတွင်းပိုင်းရှင်သန်နိုင်စွမ်းနှင့်အလုပ်လုပ်သောကြောင့်၎င်းသည်အက်တမ်ကိုမျှဝေထားသောရည်ညွှန်းချက်မှ `*mut` pointer တစ်ခုကိုပြန်ပို့ခြင်းသည်လုံခြုံသည်။
    /// အနုမြူဗုံး၏ပြုပြင်မွမ်းမံမှုအားလုံးသည်တန်ဖိုးကိုမျှဝေထားခြင်းအားဖြင့်တန်ဖိုးကိုပြောင်းလဲစေပြီး၎င်းတို့သည်အနုမြူစစ်ဆင်ရေးများကိုအသုံးပြုသရွေ့လုံခြုံစွာပြုလုပ်နိုင်သည်။
    /// အဆိုပါပြန်လာသောကုန်ကြမ်း pointer ကိုမဆိုသုံးစွဲခြင်းတစ်ဦး `unsafe` ပိတ်ပင်တားဆီးမှုလိုအပ်ပြီးနေဆဲတူညီတဲ့ကန့်သတ်ထောက်ဖို့ရှိပါတယ်: ကအပေါ်စစ်ဆင်ရေးအနုမြူဗုံးဖြစ်ရမည်။
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// တန်ဖိုးကိုရယူပြီးတန်ဖိုးအသစ်တစ်ခုကိုပြန်ပေးသည့် function တစ်ခုကိုအသုံးပြုသည်။function ကို `Some(_)`, အခြား `Err(previous_value)` ပြန်ရောက်လျှင် `Ok(previous_value)` တစ် `Result` Returns ။
    ///
    /// Note: အကယ်၍ တန်ဖိုးသည်အခြားအချည်များမှပြောင်းလဲသွားလျှင်၎င်းသည် function ကို `Some(_)` သို့ပြန်ပို့ပါက၎င်းသည် function ကိုအကြိမ်ပေါင်းများစွာခေါ်ဆိုနိုင်သည်၊ သို့သော်၎င်းသည်သိမ်းဆည်းထားသောတန်ဖိုးတစ်ခုသို့သာတစ်ကြိမ်သာအသုံးပြုလိမ့်မည်။
    ///
    ///
    /// `fetch_update` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်သာသနာကိုဖော်ပြရန်နှစ်ခု [`Ordering`] အငြင်းပွားမှုများကြာပါသည်။
    /// ပထမတစ်ခုသည်လိုအပ်သော ordering ကိုဖော်ပြပြီးစစ်ဆင်ရေးသည်နောက်ဆုံးတွင်အောင်မြင်သောအခါ၊ ဒုတိယသည် load အတွက်လိုအပ်သော ordering ကိုဖော်ပြသည်။
    /// ၎င်းတို့သည် [`AtomicBool::compare_exchange`] ၏အောင်မြင်မှုနှင့်ရှုံးနိမ့်မှုအစီအစဉ်များနှင့်သက်ဆိုင်သည်။
    ///
    /// [`Acquire`] ကိုအောင်မြင်စွာအမှာစာအဖြစ်အသုံးပြုခြင်းသည်စတိုးဆိုင်၏ဤအစိတ်အပိုင်း [`Relaxed`] ကိုဖြစ်စေသည်။ [`Release`] ကိုအသုံးပြုခြင်းသည်နောက်ဆုံးအောင်မြင်သောဝန်ကို [`Relaxed`] စေသည်။
    /// (failed) load ordering သည် [`SeqCst`], [`Acquire`] သို့မဟုတ် [`Relaxed`] သာဖြစ်နိုင်ပြီးအောင်မြင်မှုမှာယူသည်ထက်ညီသည်သို့မဟုတ်အားနည်းသည်။
    ///
    /// **Note:** ဤနည်းလမ်းကို `u8` ရှိအက်တမ်စစ်ဆင်ရေးများကိုထောက်ပံ့သောပလက်ဖောင်းများပေါ်တွင်သာရရှိနိုင်သည်။
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// `AtomicPtr` အသစ်တစ်ခုကိုဖန်တီးသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// အခြေခံ pointer တစ်ခု mutable ရည်ညွှန်းပြန်သွားသည်။
    ///
    /// အဘယ်ကြောင့်ဆိုသော်ပြောင်းလဲနိုင်သောရည်ညွှန်းချက်သည်အခြားမည်သည့်ချည်မျှတပြိုင်နက်တည်းအက်တမ်အချက်အလက်များကိုရယူခြင်းမရှိကြောင်းအာမခံသောကြောင့်ဖြစ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// pointer တစ်ခုကိုအနုမြူဗုံးသုံးပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - အဆိုပါ mutable ရည်ညွှန်းထူးခြားတဲ့ပိုင်ဆိုင်မှုအာမခံပါသည်။
        //  - အထက်စစ်ဆေးအတည်ပြုအဖြစ် `*mut T` နှင့် `Self` ၏ alignment ကို, rust ကထောက်ခံပလက်ဖောင်းအားလုံးပေါ်တွင်အတူတူပင်ဖြစ်ပါသည်။
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// အက်တမ်ကိုစားသုံးပြီးပါ ၀ င်သောတန်ဖိုးကိုပြန်လည်ပေးသည်။
    ///
    /// ဘာကြောင့်လဲဆိုတော့ `self` ကို value ဖြင့်ဖြတ်သန်းခြင်းသည်အခြားမည်သည့် thread မျှတပြိုင်နက်တည်း atomic data ကိုရယူခြင်းမရှိကြောင်းအာမခံသောကြောင့်ဖြစ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// အဆိုပါ pointer ကနေတန်ဖိုး load ။
    ///
    /// `load` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်အမိန့်ကိုဖော်ပြသည်ထားတဲ့ [`Ordering`] အငြင်းအခုံကြာပါသည်။
    /// ဖြစ်နိုင်သောတန်ဖိုးများမှာ [`SeqCst`], [`Acquire`] နှင့် [`Relaxed`] ဖြစ်သည်။
    ///
    /// # Panics
    ///
    /// `order` [`Release`] သို့မဟုတ် [`AcqRel`] ဖြစ်ပါက Panics ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // လုံခြုံမှု-ဒေတာပြိုင်ပွဲများကိုအနုမြူသတ္တိကြွအားဖြင့်တားဆီးသည်။
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// တန်ဖိုးကို pointer ထဲသို့သိုလှောင်သည်။
    ///
    /// `store` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်အမိန့်ကိုဖော်ပြသည်ထားတဲ့ [`Ordering`] အငြင်းအခုံကြာပါသည်။
    /// ဖြစ်နိုင်သောတန်ဖိုးများမှာ [`SeqCst`], [`Release`] နှင့် [`Relaxed`] ဖြစ်သည်။
    ///
    /// # Panics
    ///
    /// `order` [`Acquire`] သို့မဟုတ် [`AcqRel`] ဖြစ်ပါက Panics ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // လုံခြုံမှု-ဒေတာပြိုင်ပွဲများကိုအနုမြူသတ္တိကြွအားဖြင့်တားဆီးသည်။
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// ယခင်တန်ဖိုးကိုပြန်, အညွှန်သို့တန်ဖိုးကိုသိုလှောင်ပါသည်။
    ///
    /// `swap` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်အမိန့်ကိုဖော်ပြသည်ထားတဲ့ [`Ordering`] အငြင်းအခုံကြာပါသည်။အားလုံးမှာယူသည် Modes သာဖြစ်နိုင်သည်။
    /// [`Acquire`] ကိုအသုံးပြုခြင်းသည်စတိုးဆိုင်၏အစိတ်အပိုင်းတစ်ခုဖြစ်သော [`Relaxed`] ကိုဖြစ်စေပြီး [`Release`] ကိုအသုံးပြုခြင်းသည်ဝန်ဆောင်မှုများကို [`Relaxed`] ဖြစ်စေသည်ကိုသတိပြုပါ။
    ///
    ///
    /// **Note:** ဒီနည်းလမ်းကိုညွန်ကိန်းများပေါ်တွင်အက်တမ်စစ်ဆင်ရေးများကိုထောက်ပံ့သောပလက်ဖောင်းများတွင်သာရရှိနိုင်ပါသည်
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // လုံခြုံမှု-ဒေတာပြိုင်ပွဲများကိုအနုမြူသတ္တိကြွအားဖြင့်တားဆီးသည်။
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// လက်ရှိတန်ဖိုး `current` တန်ဖိုးကိုအဖြစ်အတူတူပင်ဖြစ်ပါသည်လျှင် pointer သို့တန်ဖိုးကိုသိုလှောင်ပါသည်။
    ///
    /// return value သည်အမြဲတမ်းယခင်တန်ဖိုးဖြစ်သည်။အကယ်၍ ၎င်းသည် `current` နှင့်ညီလျှင်တန်ဖိုးကိုမွမ်းမံခဲ့သည်။
    ///
    /// `compare_and_swap` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်အမိန့်ကိုဖော်ပြသည်သည့် [`Ordering`] အငြင်းအခုံကြာပါသည်။
    /// [`AcqRel`] ကိုသုံးသော်ငြားလည်း X0 `Release` semantics မရှိသောကြောင့် `Acquire` load ကိုလုပ်ဆောင်နိုင်မည်ဖြစ်သော်လည်းဤလုပ်ဆောင်ချက်သည်ပျက်ကွက်သွားနိုင်ကြောင်းသတိပြုပါ။
    /// ကဖြစ်ပျက်လျှင် [`Acquire`] အသုံးပြုခြင်းသည်ဤစစ်ဆင်ရေး [`Relaxed`] ၏စတိုးဆိုင်တစ်စိတ်တစ်ပိုင်းစေသည်နှင့် [`Release`] သုံးပြီးဝန်တစ်စိတ်တစ်ပိုင်း [`Relaxed`] စေသည်။
    ///
    /// **Note:** ဒီနည်းလမ်းကိုညွန်ကိန်းများပေါ်တွင်အက်တမ်စစ်ဆင်ရေးများကိုထောက်ပံ့သောပလက်ဖောင်းများတွင်သာရရှိနိုင်ပါသည်
    ///
    /// # `compare_exchange` နှင့် `compare_exchange_weak` သို့ပြောင်းရွှေ့ခြင်း
    ///
    /// `compare_and_swap` `compare_exchange` နှင့်ညီမျှသည်မှာအောက်ပါမှတ်ဥာဏ်အတွက်ဖြစ်သည်။
    ///
    /// မူရင်း။အောင်မြင်မှုပျက်ကွက်
    /// -------- | ------- | -------
    /// လျှော့ပေါ့လျှော့ပေါ့စိတ်အေးလက်အေးရယူ |ရယူပါလွှတ်ပေးရန်ထုတ်ပြန် |ဖြေလျှော့ AcqRel |AcqRel |SeqCst ကိုရယူပါSeqCst |SeqCst
    ///
    /// `compare_exchange_weak` နှိုင်းယှဉ်မှုအောင်မြင်လျှင်ပင် compiler နှင့်နှိုင်းယှဉ်မှုနှင့်လဲလှယ်မှုနှုန်းသည်ကွင်းဆက်တွင်ပိုမိုကောင်းမွန်သော assembly code ကိုထုတ်ပေးရန်အတွက် spuriously ကျရှုံးရန်ဖြစ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// လက်ရှိတန်ဖိုး `current` တန်ဖိုးကိုအဖြစ်အတူတူပင်ဖြစ်ပါသည်လျှင် pointer သို့တန်ဖိုးကိုသိုလှောင်ပါသည်။
    ///
    /// အဆိုပါပြန်လာတန်ဖိုးကိုရလဒ်သစ်ကိုတနျဖိုးရေးသားခဲ့ရှိမရှိကိုညွှန်းများနှင့်ယခင်တန်ဖိုးကိုင်ဖြစ်ပါတယ်။
    /// အောင်မြင်မှုပေါ်မှာဤတန်ဖိုးကို `current` ညီမျှဖြစ်အာမခံချက်ဖြစ်ပါတယ်။
    ///
    /// `compare_exchange` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်သာသနာကိုဖော်ပြရန်နှစ်ခု [`Ordering`] အငြင်းပွားမှုများကြာပါသည်။
    /// `success` `current` နှင့်အတူနှိုင်းယှဉ်အောင်မြင်လျှင်ရာအရပ်ကိုကြာသောဖတ်ပြီးသား-Modify-ရေးစစ်ဆင်ရေးများအတွက်လိုအပ်သောသာသနာကိုဖော်ပြသည်။
    /// `failure` နှိုင်းယှဉ်ပျက်ကွက်သည့်အခါရာအရပ်ကိုကြာသောဝန်စစ်ဆင်ရေးများအတွက်လိုအပ်သောသာသနာကိုဖော်ပြသည်။
    /// [`Acquire`] ကိုအောင်မြင်စွာအမှာစာအဖြစ်အသုံးပြုခြင်းသည်စတိုးဆိုင်၏အစိတ်အပိုင်းတစ်ခုဖြစ်သော [`Relaxed`] ကိုဖြစ်စေသည်။ [`Release`] ကိုအသုံးပြုခြင်းက [`Relaxed`] ကို ၀ န်ဆောင်မှုပေးသည်။
    ///
    /// ပျက်ကွက်မှုမှာယူမှုသည် [`SeqCst`], [`Acquire`] သို့မဟုတ် [`Relaxed`] သာဖြစ်နိုင်ပြီးအောင်မြင်မှုမှာယူသည်ထက်ညီသည်သို့မဟုတ်အားနည်းသည်။
    ///
    /// **Note:** ဒီနည်းလမ်းကိုညွန်ကိန်းများပေါ်တွင်အက်တမ်စစ်ဆင်ရေးများကိုထောက်ပံ့သောပလက်ဖောင်းများတွင်သာရရှိနိုင်ပါသည်
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // လုံခြုံမှု-ဒေတာပြိုင်ပွဲများကိုအနုမြူသတ္တိကြွအားဖြင့်တားဆီးသည်။
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// လက်ရှိတန်ဖိုး `current` တန်ဖိုးကိုအဖြစ်အတူတူပင်ဖြစ်ပါသည်လျှင် pointer သို့တန်ဖိုးကိုသိုလှောင်ပါသည်။
    ///
    /// [`AtomicPtr::compare_exchange`] နှင့်မတူဘဲ၊ နှိုင်းယှဉ်မှုအောင်မြင်ပြီးသည့်တိုင်၎င်းလုပ်ဆောင်မှုသည်အချို့သောပလက်ဖောင်းများပေါ်တွင်ပိုမိုထိရောက်သောကုဒ်ကိုဖြစ်ပေါ်စေသည့်တိုင်၎င်းလုပ်ဆောင်မှုကိုပျက်ကွက်စေရန်ခွင့်ပြုထားသည်။
    ///
    /// အဆိုပါပြန်လာတန်ဖိုးကိုရလဒ်သစ်ကိုတနျဖိုးရေးသားခဲ့ရှိမရှိကိုညွှန်းများနှင့်ယခင်တန်ဖိုးကိုင်ဖြစ်ပါတယ်။
    ///
    /// `compare_exchange_weak` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်သာသနာကိုဖော်ပြရန်နှစ်ခု [`Ordering`] အငြင်းပွားမှုများကြာပါသည်။
    /// `success` `current` နှင့်အတူနှိုင်းယှဉ်အောင်မြင်လျှင်ရာအရပ်ကိုကြာသောဖတ်ပြီးသား-Modify-ရေးစစ်ဆင်ရေးများအတွက်လိုအပ်သောသာသနာကိုဖော်ပြသည်။
    /// `failure` နှိုင်းယှဉ်ပျက်ကွက်သည့်အခါရာအရပ်ကိုကြာသောဝန်စစ်ဆင်ရေးများအတွက်လိုအပ်သောသာသနာကိုဖော်ပြသည်။
    /// [`Acquire`] ကိုအောင်မြင်စွာအမှာစာအဖြစ်အသုံးပြုခြင်းသည်စတိုးဆိုင်၏အစိတ်အပိုင်းတစ်ခုဖြစ်သော [`Relaxed`] ကိုဖြစ်စေသည်။ [`Release`] ကိုအသုံးပြုခြင်းက [`Relaxed`] ကို ၀ န်ဆောင်မှုပေးသည်။
    /// ပျက်ကွက်မှုမှာယူမှုသည် [`SeqCst`], [`Acquire`] သို့မဟုတ် [`Relaxed`] သာဖြစ်နိုင်ပြီးအောင်မြင်မှုမှာယူသည်ထက်ညီသည်သို့မဟုတ်အားနည်းသည်။
    ///
    /// **Note:** ဒီနည်းလမ်းကိုညွန်ကိန်းများပေါ်တွင်အက်တမ်စစ်ဆင်ရေးများကိုထောက်ပံ့သောပလက်ဖောင်းများတွင်သာရရှိနိုင်ပါသည်
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // လုံခြုံမှု: ကကုန်ကြမ်း pointer အပေါ်လည်ပတ်ဘာဖြစ်လို့လဲဆိုတော့ဒီအခ်ါအန္တရာယ်မကင်းဖြစ်ပြီး
        // ဒါပေမယ့်ကျနော်တို့ pointer (ငါတို့ကိုးကားအားဖြင့်ရှိသည်သော `UnsafeCell` ကနေရတယ်) တရားဝင်သည်ကိုသေချာသေချာစွာသိတယ်နှင့်အနုမြူဗုံးစစ်ဆင်ရေးကိုယ်တိုင်ကကျွန်တော်တို့ကိုလုံခြုံစွာ `UnsafeCell` contents တွေကို mutate ရန်ခွင့်ပြုပါတယ်။
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// တန်ဖိုးကိုရယူပြီးတန်ဖိုးအသစ်တစ်ခုကိုပြန်ပေးသည့် function တစ်ခုကိုအသုံးပြုသည်။function ကို `Some(_)`, အခြား `Err(previous_value)` ပြန်ရောက်လျှင် `Ok(previous_value)` တစ် `Result` Returns ။
    ///
    /// Note: အကယ်၍ တန်ဖိုးသည်အခြားအချည်များမှပြောင်းလဲသွားလျှင်၎င်းသည် function ကို `Some(_)` သို့ပြန်ပို့ပါက၎င်းသည် function ကိုအကြိမ်ပေါင်းများစွာခေါ်ဆိုနိုင်သည်၊ သို့သော်၎င်းသည်သိမ်းဆည်းထားသောတန်ဖိုးတစ်ခုသို့သာတစ်ကြိမ်သာအသုံးပြုလိမ့်မည်။
    ///
    ///
    /// `fetch_update` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်သာသနာကိုဖော်ပြရန်နှစ်ခု [`Ordering`] အငြင်းပွားမှုများကြာပါသည်။
    /// ပထမတစ်ခုသည်လိုအပ်သော ordering ကိုဖော်ပြပြီးစစ်ဆင်ရေးသည်နောက်ဆုံးတွင်အောင်မြင်သောအခါ၊ ဒုတိယသည် load အတွက်လိုအပ်သော ordering ကိုဖော်ပြသည်။
    /// ၎င်းတို့သည် [`AtomicPtr::compare_exchange`] ၏အောင်မြင်မှုနှင့်ရှုံးနိမ့်မှုအစီအစဉ်များနှင့်ကိုက်ညီသည်။
    ///
    /// [`Acquire`] ကိုအောင်မြင်စွာအမှာစာအဖြစ်အသုံးပြုခြင်းသည်စတိုးဆိုင်၏ဤအစိတ်အပိုင်း [`Relaxed`] ကိုဖြစ်စေသည်။ [`Release`] ကိုအသုံးပြုခြင်းသည်နောက်ဆုံးအောင်မြင်သောဝန်ကို [`Relaxed`] စေသည်။
    /// (failed) load ordering သည် [`SeqCst`], [`Acquire`] သို့မဟုတ် [`Relaxed`] သာဖြစ်နိုင်ပြီးအောင်မြင်မှုမှာယူသည်ထက်ညီသည်သို့မဟုတ်အားနည်းသည်။
    ///
    /// **Note:** ဒီနည်းလမ်းကိုညွန်ကိန်းများပေါ်တွင်အက်တမ်စစ်ဆင်ရေးများကိုထောက်ပံ့သောပလက်ဖောင်းများတွင်သာရရှိနိုင်ပါသည်
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// တစ်ဦး `bool` တစ်ခု `AtomicBool` သို့ပြောင်းပေးပါတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // အခြို့သောဗိသုကာအပေါ်အသုံးမပြုတဲ့ဖြစ်ခြင်းတက်ဒါကနိုင်တဲ့ macro ကြီးစွန်း။
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Thread များအကြားတွင်လုံခြုံစွာမျှဝေနိုင်သော integer type တစ်ခု။
        ///
        /// ဤအမျိုးအစားတွင် `` ကိန်းဂဏန်း၏အခြေခံကိန်းနှင့် [အတူတူ] In-memory ကိုယ်စားပြုမှုရှိသည်
        ///
        #[doc = $s_int_type]
        /// `].
        /// အက်တမ်အမျိုးအစားများနှင့်အက်တမ်မဟုတ်သောအမျိုးအစားများအကြားကွဲပြားခြားနားမှုများအပြင်ဤအမျိုးအစားသယ်ဆောင်ရလွယ်ကူခြင်းအကြောင်းအချက်အလက်များအတွက် [module-level documentation] ကိုကြည့်ပါ။
        ///
        ///
        /// **Note:** ဤအမျိုးအစားသည် [`၏အက်တမ်ဝန်နှင့်စတိုးဆိုင်များကိုထောက်ပံ့သောပလက်ဖောင်းများပေါ်တွင်သာရရှိနိုင်သည်
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// `0` မှအစပြုအနုမြူဗုံးကိန်း။
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Send လုံးလုံးလြားလြားအကောင်အထည်ဖော်နေပါတယ်။
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// အသစ်တစ်ခုကိုအနုမြူဗုံးကိန်းဖန်တီးပေးသည်။
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// နောက်ခံကိန်းတစ်ခု mutable ရည်ညွှန်း Returns ။
            ///
            /// အဘယ်ကြောင့်ဆိုသော်ပြောင်းလဲနိုင်သောရည်ညွှန်းချက်သည်အခြားမည်သည့်ချည်မျှတပြိုင်နက်တည်းအက်တမ်အချက်အလက်များကိုရယူခြင်းမရှိကြောင်းအာမခံသောကြောင့်ဖြစ်သည်။
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// mut some_int=123 ကြကုန်အံ့,
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - အဆိုပါ mutable ရည်ညွှန်းထူးခြားတဲ့ပိုင်ဆိုင်မှုအာမခံပါသည်။
                //  - X0 $cfg_align နှင့်အထက်တွင်အတည်ပြုထားသည့် `$int_type` နှင့် `Self` တို့၏ alignment သည်အတူတူပင်ဖြစ်သည်။
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// အက်တမ်ကိုစားသုံးပြီးပါ ၀ င်သောတန်ဖိုးကိုပြန်လည်ပေးသည်။
            ///
            /// ဘာကြောင့်လဲဆိုတော့ `self` ကို value ဖြင့်ဖြတ်သန်းခြင်းသည်အခြားမည်သည့် thread မျှတပြိုင်နက်တည်း atomic data ကိုရယူခြင်းမရှိကြောင်းအာမခံသောကြောင့်ဖြစ်သည်။
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// ယင်းအက်တမ်ကိန်းနေတဲ့တန်ဖိုးကတင်ပေးပါတယ်။
            ///
            /// `load` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်အမိန့်ကိုဖော်ပြသည်ထားတဲ့ [`Ordering`] အငြင်းအခုံကြာပါသည်။
            /// ဖြစ်နိုင်သောတန်ဖိုးများမှာ [`SeqCst`], [`Acquire`] နှင့် [`Relaxed`] ဖြစ်သည်။
            ///
            /// # Panics
            ///
            /// `order` [`Release`] သို့မဟုတ် [`AcqRel`] ဖြစ်ပါက Panics ။
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // လုံခြုံမှု-ဒေတာပြိုင်ပွဲများကိုအနုမြူသတ္တိကြွအားဖြင့်တားဆီးသည်။
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// ယင်းအက်တမ်ကိန်းသို့တန်ဖိုးကိုသိုလှောင်ပါသည်။
            ///
            /// `store` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်အမိန့်ကိုဖော်ပြသည်ထားတဲ့ [`Ordering`] အငြင်းအခုံကြာပါသည်။
            ///  ဖြစ်နိုင်သောတန်ဖိုးများမှာ [`SeqCst`], [`Release`] နှင့် [`Relaxed`] ဖြစ်သည်။
            ///
            /// # Panics
            ///
            /// `order` [`Acquire`] သို့မဟုတ် [`AcqRel`] ဖြစ်ပါက Panics ။
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // လုံခြုံမှု-ဒေတာပြိုင်ပွဲများကိုအနုမြူသတ္တိကြွအားဖြင့်တားဆီးသည်။
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// တန်ဖိုးကို atomic integer သို့ပြောင်းပြီးအရင်တန်ဖိုးကိုပြန်ပေးသည်။
            ///
            /// `swap` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်အမိန့်ကိုဖော်ပြသည်ထားတဲ့ [`Ordering`] အငြင်းအခုံကြာပါသည်။အားလုံးမှာယူသည် Modes သာဖြစ်နိုင်သည်။
            /// [`Acquire`] ကိုအသုံးပြုခြင်းသည်စတိုးဆိုင်၏အစိတ်အပိုင်းတစ်ခုဖြစ်သော [`Relaxed`] ကိုဖြစ်စေပြီး [`Release`] ကိုအသုံးပြုခြင်းသည်ဝန်ဆောင်မှုများကို [`Relaxed`] ဖြစ်စေသည်ကိုသတိပြုပါ။
            ///
            ///
            /// **မှတ်ချက်**: ဤနည်းလမ်းကိုအက်တမ်စစ်ဆင်ရေးများကိုထောက်ပံ့သောပလက်ဖောင်းများပေါ်တွင်သာရရှိနိုင်သည်
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // လုံခြုံမှု-ဒေတာပြိုင်ပွဲများကိုအနုမြူသတ္တိကြွအားဖြင့်တားဆီးသည်။
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// လက်ရှိတန်ဖိုး `current` တန်ဖိုးကိုအဖြစ်အတူတူပင်ဖြစ်ပါသည်လျှင်အက်တမ်ကိန်းသို့တန်ဖိုးကိုသိုလှောင်ပါသည်။
            ///
            /// return value သည်အမြဲတမ်းယခင်တန်ဖိုးဖြစ်သည်။အကယ်၍ ၎င်းသည် `current` နှင့်ညီလျှင်တန်ဖိုးကိုမွမ်းမံခဲ့သည်။
            ///
            /// `compare_and_swap` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်အမိန့်ကိုဖော်ပြသည်သည့် [`Ordering`] အငြင်းအခုံကြာပါသည်။
            /// [`AcqRel`] ကိုသုံးသော်ငြားလည်း X0 `Release` semantics မရှိသောကြောင့် `Acquire` load ကိုလုပ်ဆောင်နိုင်မည်ဖြစ်သော်လည်းဤလုပ်ဆောင်ချက်သည်ပျက်ကွက်သွားနိုင်ကြောင်းသတိပြုပါ။
            ///
            /// ကဖြစ်ပျက်လျှင် [`Acquire`] အသုံးပြုခြင်းသည်ဤစစ်ဆင်ရေး [`Relaxed`] ၏စတိုးဆိုင်တစ်စိတ်တစ်ပိုင်းစေသည်နှင့် [`Release`] သုံးပြီးဝန်တစ်စိတ်တစ်ပိုင်း [`Relaxed`] စေသည်။
            ///
            /// **မှတ်ချက်**: ဤနည်းလမ်းကိုအက်တမ်စစ်ဆင်ရေးများကိုထောက်ပံ့သောပလက်ဖောင်းများပေါ်တွင်သာရရှိနိုင်သည်
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # `compare_exchange` နှင့် `compare_exchange_weak` သို့ပြောင်းရွှေ့ခြင်း
            ///
            /// `compare_and_swap` `compare_exchange` နှင့်ညီမျှသည်မှာအောက်ပါမှတ်ဥာဏ်အတွက်ဖြစ်သည်။
            ///
            /// မူရင်း။အောင်မြင်မှုပျက်ကွက်
            /// -------- | ------- | -------
            /// လျှော့ပေါ့လျှော့ပေါ့စိတ်အေးလက်အေးရယူ |ရယူပါလွှတ်ပေးရန်ထုတ်ပြန် |ဖြေလျှော့ AcqRel |AcqRel |SeqCst ကိုရယူပါSeqCst |SeqCst
            ///
            /// `compare_exchange_weak` နှိုင်းယှဉ်မှုအောင်မြင်လျှင်ပင် compiler နှင့်နှိုင်းယှဉ်မှုနှင့်လဲလှယ်မှုနှုန်းသည်ကွင်းဆက်တွင်ပိုမိုကောင်းမွန်သော assembly code ကိုထုတ်ပေးရန်အတွက် spuriously ကျရှုံးရန်ဖြစ်သည်။
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// လက်ရှိတန်ဖိုး `current` တန်ဖိုးကိုအဖြစ်အတူတူပင်ဖြစ်ပါသည်လျှင်အက်တမ်ကိန်းသို့တန်ဖိုးကိုသိုလှောင်ပါသည်။
            ///
            /// အဆိုပါပြန်လာတန်ဖိုးကိုရလဒ်သစ်ကိုတနျဖိုးရေးသားခဲ့ရှိမရှိကိုညွှန်းများနှင့်ယခင်တန်ဖိုးကိုင်ဖြစ်ပါတယ်။
            /// အောင်မြင်မှုပေါ်မှာဤတန်ဖိုးကို `current` ညီမျှဖြစ်အာမခံချက်ဖြစ်ပါတယ်။
            ///
            /// `compare_exchange` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်သာသနာကိုဖော်ပြရန်နှစ်ခု [`Ordering`] အငြင်းပွားမှုများကြာပါသည်။
            /// `success` `current` နှင့်အတူနှိုင်းယှဉ်အောင်မြင်လျှင်ရာအရပ်ကိုကြာသောဖတ်ပြီးသား-Modify-ရေးစစ်ဆင်ရေးများအတွက်လိုအပ်သောသာသနာကိုဖော်ပြသည်။
            /// `failure` နှိုင်းယှဉ်ပျက်ကွက်သည့်အခါရာအရပ်ကိုကြာသောဝန်စစ်ဆင်ရေးများအတွက်လိုအပ်သောသာသနာကိုဖော်ပြသည်။
            /// [`Acquire`] ကိုအောင်မြင်စွာအမှာစာအဖြစ်အသုံးပြုခြင်းသည်စတိုးဆိုင်၏အစိတ်အပိုင်းတစ်ခုဖြစ်သော [`Relaxed`] ကိုဖြစ်စေသည်။ [`Release`] ကိုအသုံးပြုခြင်းက [`Relaxed`] ကို ၀ န်ဆောင်မှုပေးသည်။
            ///
            /// ပျက်ကွက်မှုမှာယူမှုသည် [`SeqCst`], [`Acquire`] သို့မဟုတ် [`Relaxed`] သာဖြစ်နိုင်ပြီးအောင်မြင်မှုမှာယူသည်ထက်ညီသည်သို့မဟုတ်အားနည်းသည်။
            ///
            /// **မှတ်ချက်**: ဤနည်းလမ်းကိုအက်တမ်စစ်ဆင်ရေးများကိုထောက်ပံ့သောပလက်ဖောင်းများပေါ်တွင်သာရရှိနိုင်သည်
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // လုံခြုံမှု-ဒေတာပြိုင်ပွဲများကိုအနုမြူသတ္တိကြွအားဖြင့်တားဆီးသည်။
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// လက်ရှိတန်ဖိုး `current` တန်ဖိုးကိုအဖြစ်အတူတူပင်ဖြစ်ပါသည်လျှင်အက်တမ်ကိန်းသို့တန်ဖိုးကိုသိုလှောင်ပါသည်။
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// ဒီ function ကိုအချို့ပလက်ဖောင်းများပေါ်တွင်ပိုမိုထိရောက်သောကုဒ်ဖြစ်ပေါ်နိုင်သည့်, နှိုင်းယှဉ်အောင်မြင်လျှင်ပင် spuriously ကျရှုံးခွင့်ပြုခဲ့ခြင်းဖြစ်သည်။
            /// အဆိုပါပြန်လာတန်ဖိုးကိုရလဒ်သစ်ကိုတနျဖိုးရေးသားခဲ့ရှိမရှိကိုညွှန်းများနှင့်ယခင်တန်ဖိုးကိုင်ဖြစ်ပါတယ်။
            ///
            /// `compare_exchange_weak` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်သာသနာကိုဖော်ပြရန်နှစ်ခု [`Ordering`] အငြင်းပွားမှုများကြာပါသည်။
            /// `success` `current` နှင့်အတူနှိုင်းယှဉ်အောင်မြင်လျှင်ရာအရပ်ကိုကြာသောဖတ်ပြီးသား-Modify-ရေးစစ်ဆင်ရေးများအတွက်လိုအပ်သောသာသနာကိုဖော်ပြသည်။
            /// `failure` နှိုင်းယှဉ်ပျက်ကွက်သည့်အခါရာအရပ်ကိုကြာသောဝန်စစ်ဆင်ရေးများအတွက်လိုအပ်သောသာသနာကိုဖော်ပြသည်။
            /// [`Acquire`] ကိုအောင်မြင်စွာအမှာစာအဖြစ်အသုံးပြုခြင်းသည်စတိုးဆိုင်၏အစိတ်အပိုင်းတစ်ခုဖြစ်သော [`Relaxed`] ကိုဖြစ်စေသည်။ [`Release`] ကိုအသုံးပြုခြင်းက [`Relaxed`] ကို ၀ န်ဆောင်မှုပေးသည်။
            ///
            /// ပျက်ကွက်မှုမှာယူမှုသည် [`SeqCst`], [`Acquire`] သို့မဟုတ် [`Relaxed`] သာဖြစ်နိုင်ပြီးအောင်မြင်မှုမှာယူသည်ထက်ညီသည်သို့မဟုတ်အားနည်းသည်။
            ///
            /// **မှတ်ချက်**: ဤနည်းလမ်းကိုအက်တမ်စစ်ဆင်ရေးများကိုထောက်ပံ့သောပလက်ဖောင်းများပေါ်တွင်သာရရှိနိုင်သည်
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// mut=ဟောင်း val.load(Ordering::Relaxed);
            /// ကွင်းဆက် {သစ်ကို=ဟောင်း * 2 ကြကုန်အံ့,
            ///     val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, } ကိုက်ညီ}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // လုံခြုံမှု-ဒေတာပြိုင်ပွဲများကိုအနုမြူသတ္တိကြွအားဖြင့်တားဆီးသည်။
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// ယခင်တန်ဖိုးကိုပြန်, လက်ရှိတန်ဖိုးကထပ်ပြောသည်။
            ///
            /// ဤသည်စစ်ဆင်ရေးလျတ်အပေါ်န်းကျင်ထုပ်။
            ///
            /// `fetch_add` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်အမိန့်ကိုဖော်ပြသည်ထားတဲ့ [`Ordering`] အငြင်းအခုံကြာပါသည်။အားလုံးမှာယူသည် Modes သာဖြစ်နိုင်သည်။
            /// [`Acquire`] ကိုအသုံးပြုခြင်းသည်စတိုးဆိုင်၏အစိတ်အပိုင်းတစ်ခုဖြစ်သော [`Relaxed`] ကိုဖြစ်စေပြီး [`Release`] ကိုအသုံးပြုခြင်းသည်ဝန်ဆောင်မှုများကို [`Relaxed`] ဖြစ်စေသည်ကိုသတိပြုပါ။
            ///
            ///
            /// **မှတ်ချက်**: ဤနည်းလမ်းကိုအက်တမ်စစ်ဆင်ရေးများကိုထောက်ပံ့သောပလက်ဖောင်းများပေါ်တွင်သာရရှိနိုင်သည်
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // လုံခြုံမှု-ဒေတာပြိုင်ပွဲများကိုအနုမြူသတ္တိကြွအားဖြင့်တားဆီးသည်။
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// ယခင်တန်ဖိုးကိုပြန်ပေး, လက်ရှိတန်ဖိုးကနေနုတ်။
            ///
            /// ဤသည်စစ်ဆင်ရေးလျတ်အပေါ်န်းကျင်ထုပ်။
            ///
            /// `fetch_sub` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်အမိန့်ကိုဖော်ပြသည်ထားတဲ့ [`Ordering`] အငြင်းအခုံကြာပါသည်။အားလုံးမှာယူသည် Modes သာဖြစ်နိုင်သည်။
            /// [`Acquire`] ကိုအသုံးပြုခြင်းသည်စတိုးဆိုင်၏အစိတ်အပိုင်းတစ်ခုဖြစ်သော [`Relaxed`] ကိုဖြစ်စေပြီး [`Release`] ကိုအသုံးပြုခြင်းသည်ဝန်ဆောင်မှုများကို [`Relaxed`] ဖြစ်စေသည်ကိုသတိပြုပါ။
            ///
            ///
            /// **မှတ်ချက်**: ဤနည်းလမ်းကိုအက်တမ်စစ်ဆင်ရေးများကိုထောက်ပံ့သောပလက်ဖောင်းများပေါ်တွင်သာရရှိနိုင်သည်
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // လုံခြုံမှု-ဒေတာပြိုင်ပွဲများကိုအနုမြူသတ္တိကြွအားဖြင့်တားဆီးသည်။
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// လက်ရှိတန်ဖိုး Bitwise "and" ။
            ///
            /// Performance လက်ရှိတန်ဖိုးကိုနှင့်အငြင်းအခုံ `val` အပေါ်တစ်ဦး bitwise "and" စစ်ဆင်ရေးများနှင့်ရလဒ်မှသစ်ကိုတန်ဖိုးကိုသတ်မှတ်။
            ///
            /// ယခင်တန်ဖိုးကိုပြန်သွားသည်။
            ///
            /// `fetch_and` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်အမိန့်ကိုဖော်ပြသည်ထားတဲ့ [`Ordering`] အငြင်းအခုံကြာပါသည်။အားလုံးမှာယူသည် Modes သာဖြစ်နိုင်သည်။
            /// [`Acquire`] ကိုအသုံးပြုခြင်းသည်စတိုးဆိုင်၏အစိတ်အပိုင်းတစ်ခုဖြစ်သော [`Relaxed`] ကိုဖြစ်စေပြီး [`Release`] ကိုအသုံးပြုခြင်းသည်ဝန်ဆောင်မှုများကို [`Relaxed`] ဖြစ်စေသည်ကိုသတိပြုပါ။
            ///
            ///
            /// **မှတ်ချက်**: ဤနည်းလမ်းကိုအက်တမ်စစ်ဆင်ရေးများကိုထောက်ပံ့သောပလက်ဖောင်းများပေါ်တွင်သာရရှိနိုင်သည်
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // လုံခြုံမှု-ဒေတာပြိုင်ပွဲများကိုအနုမြူသတ္တိကြွအားဖြင့်တားဆီးသည်။
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// လက်ရှိတန်ဖိုး Bitwise "nand" ။
            ///
            /// လက်ရှိတန်ဖိုးနှင့်အငြင်းအခုံ `val` အပေါ် bitwise "nand" စစ်ဆင်ရေးကိုလုပ်ဆောင်ပြီးတန်ဖိုးအသစ်ကိုရလဒ်သို့သတ်မှတ်သည်။
            ///
            /// ယခင်တန်ဖိုးကိုပြန်သွားသည်။
            ///
            /// `fetch_nand` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်အမိန့်ကိုဖော်ပြသည်ထားတဲ့ [`Ordering`] အငြင်းအခုံကြာပါသည်။အားလုံးမှာယူသည် Modes သာဖြစ်နိုင်သည်။
            /// [`Acquire`] ကိုအသုံးပြုခြင်းသည်စတိုးဆိုင်၏အစိတ်အပိုင်းတစ်ခုဖြစ်သော [`Relaxed`] ကိုဖြစ်စေပြီး [`Release`] ကိုအသုံးပြုခြင်းသည်ဝန်ဆောင်မှုများကို [`Relaxed`] ဖြစ်စေသည်ကိုသတိပြုပါ။
            ///
            ///
            /// **မှတ်ချက်**: ဤနည်းလမ်းကိုအက်တမ်စစ်ဆင်ရေးများကိုထောက်ပံ့သောပလက်ဖောင်းများပေါ်တွင်သာရရှိနိုင်သည်
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // လုံခြုံမှု-ဒေတာပြိုင်ပွဲများကိုအနုမြူသတ္တိကြွအားဖြင့်တားဆီးသည်။
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// လက်ရှိတန်ဖိုး Bitwise "or" ။
            ///
            /// လက်ရှိတန်ဖိုးနှင့်အငြင်းအခုံ `val` ပေါ်တွင် bitwise "or" စစ်ဆင်ရေးကိုလုပ်ဆောင်ပြီးတန်ဖိုးအသစ်ကိုရလဒ်သို့သတ်မှတ်သည်။
            ///
            /// ယခင်တန်ဖိုးကိုပြန်သွားသည်။
            ///
            /// `fetch_or` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်အမိန့်ကိုဖော်ပြသည်ထားတဲ့ [`Ordering`] အငြင်းအခုံကြာပါသည်။အားလုံးမှာယူသည် Modes သာဖြစ်နိုင်သည်။
            /// [`Acquire`] ကိုအသုံးပြုခြင်းသည်စတိုးဆိုင်၏အစိတ်အပိုင်းတစ်ခုဖြစ်သော [`Relaxed`] ကိုဖြစ်စေပြီး [`Release`] ကိုအသုံးပြုခြင်းသည်ဝန်ဆောင်မှုများကို [`Relaxed`] ဖြစ်စေသည်ကိုသတိပြုပါ။
            ///
            ///
            /// **မှတ်ချက်**: ဤနည်းလမ်းကိုအက်တမ်စစ်ဆင်ရေးများကိုထောက်ပံ့သောပလက်ဖောင်းများပေါ်တွင်သာရရှိနိုင်သည်
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // လုံခြုံမှု-ဒေတာပြိုင်ပွဲများကိုအနုမြူသတ္တိကြွအားဖြင့်တားဆီးသည်။
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// လက်ရှိတန်ဖိုးနှင့် Bitwise "xor" ။
            ///
            /// လက်ရှိတန်ဖိုးနှင့်အငြင်းအခုံ `val` အပေါ် bitwise "xor" စစ်ဆင်ရေးကိုလုပ်ဆောင်ပြီးတန်ဖိုးအသစ်ကိုရလဒ်သို့သတ်မှတ်သည်။
            ///
            /// ယခင်တန်ဖိုးကိုပြန်သွားသည်။
            ///
            /// `fetch_xor` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်အမိန့်ကိုဖော်ပြသည်ထားတဲ့ [`Ordering`] အငြင်းအခုံကြာပါသည်။အားလုံးမှာယူသည် Modes သာဖြစ်နိုင်သည်။
            /// [`Acquire`] ကိုအသုံးပြုခြင်းသည်စတိုးဆိုင်၏အစိတ်အပိုင်းတစ်ခုဖြစ်သော [`Relaxed`] ကိုဖြစ်စေပြီး [`Release`] ကိုအသုံးပြုခြင်းသည်ဝန်ဆောင်မှုများကို [`Relaxed`] ဖြစ်စေသည်ကိုသတိပြုပါ။
            ///
            ///
            /// **မှတ်ချက်**: ဤနည်းလမ်းကိုအက်တမ်စစ်ဆင်ရေးများကိုထောက်ပံ့သောပလက်ဖောင်းများပေါ်တွင်သာရရှိနိုင်သည်
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // လုံခြုံမှု-ဒေတာပြိုင်ပွဲများကိုအနုမြူသတ္တိကြွအားဖြင့်တားဆီးသည်။
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// တန်ဖိုးကိုရယူပြီးတန်ဖိုးအသစ်တစ်ခုကိုပြန်ပေးသည့် function တစ်ခုကိုအသုံးပြုသည်။function ကို `Some(_)`, အခြား `Err(previous_value)` ပြန်ရောက်လျှင် `Ok(previous_value)` တစ် `Result` Returns ။
            ///
            /// Note: အကယ်၍ တန်ဖိုးသည်အခြားအချည်များမှပြောင်းလဲသွားလျှင်၎င်းသည် function ကို `Some(_)` သို့ပြန်ပို့ပါက၎င်းသည် function ကိုအကြိမ်ပေါင်းများစွာခေါ်ဆိုနိုင်သည်၊ သို့သော်၎င်းသည်သိမ်းဆည်းထားသောတန်ဖိုးတစ်ခုသို့သာတစ်ကြိမ်သာအသုံးပြုလိမ့်မည်။
            ///
            ///
            /// `fetch_update` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်သာသနာကိုဖော်ပြရန်နှစ်ခု [`Ordering`] အငြင်းပွားမှုများကြာပါသည်။
            /// ပထမတစ်ခုသည်လိုအပ်သော ordering ကိုဖော်ပြပြီးစစ်ဆင်ရေးသည်နောက်ဆုံးတွင်အောင်မြင်သောအခါ၊ ဒုတိယသည် load အတွက်လိုအပ်သော ordering ကိုဖော်ပြသည်။၏အောင်မြင်မှုနှင့်ကျရှုံး Order ဤကိုက်ညီ
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// [`Acquire`] ကိုအောင်မြင်စွာအမှာစာအဖြစ်အသုံးပြုခြင်းသည်စတိုးဆိုင်၏ဤအစိတ်အပိုင်း [`Relaxed`] ကိုဖြစ်စေသည်။ [`Release`] ကိုအသုံးပြုခြင်းသည်နောက်ဆုံးအောင်မြင်သောဝန်ကို [`Relaxed`] စေသည်။
            /// (failed) load ordering သည် [`SeqCst`], [`Acquire`] သို့မဟုတ် [`Relaxed`] သာဖြစ်နိုင်ပြီးအောင်မြင်မှုမှာယူသည်ထက်ညီသည်သို့မဟုတ်အားနည်းသည်။
            ///
            /// **မှတ်ချက်**: ဤနည်းလမ်းကိုအက်တမ်စစ်ဆင်ရေးများကိုထောက်ပံ့သောပလက်ဖောင်းများပေါ်တွင်သာရရှိနိုင်သည်
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq (x.fetch_update (Ordering: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)))! Ok(7));
            /// assert_eq (x.fetch_update (Ordering: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)))! Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// လက်ရှိတန်ဖိုးနှင့်အတူအများဆုံး။
            ///
            /// လက်ရှိတန်ဖိုးနှင့် `val` အငြင်းပွားမှုကိုအများဆုံးရှာဖွေပြီးတန်ဖိုးအသစ်ကိုရလဒ်သို့သတ်မှတ်သည်။
            ///
            /// ယခင်တန်ဖိုးကိုပြန်သွားသည်။
            ///
            /// `fetch_max` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်အမိန့်ကိုဖော်ပြသည်ထားတဲ့ [`Ordering`] အငြင်းအခုံကြာပါသည်။အားလုံးမှာယူသည် Modes သာဖြစ်နိုင်သည်။
            /// [`Acquire`] ကိုအသုံးပြုခြင်းသည်စတိုးဆိုင်၏အစိတ်အပိုင်းတစ်ခုဖြစ်သော [`Relaxed`] ကိုဖြစ်စေပြီး [`Release`] ကိုအသုံးပြုခြင်းသည်ဝန်ဆောင်မှုများကို [`Relaxed`] ဖြစ်စေသည်ကိုသတိပြုပါ။
            ///
            ///
            /// **မှတ်ချက်**: ဤနည်းလမ်းကိုအက်တမ်စစ်ဆင်ရေးများကိုထောက်ပံ့သောပလက်ဖောင်းများပေါ်တွင်သာရရှိနိုင်သည်
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// ဘား=42;
            /// ဘား (max_foo=foo.fetch_max ကြကုန်အံ့, Ordering::SeqCst).max(bar);
            /// အခိုင်အမာ (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // လုံခြုံမှု-ဒေတာပြိုင်ပွဲများကိုအနုမြူသတ္တိကြွအားဖြင့်တားဆီးသည်။
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// အနည်းဆုံးလက်ရှိတန်ဖိုးနှင့်အတူ။
            ///
            /// လက်ရှိတန်ဖိုးကိုနှင့်အငြင်းအခုံ `val` ၏နိမ့်ဆုံးကိုတွေ့သဖြင့်, ရလဒ်မှသစ်ကိုတန်ဖိုးကိုသတ်မှတ်။
            ///
            /// ယခင်တန်ဖိုးကိုပြန်သွားသည်။
            ///
            /// `fetch_min` ဒီစစ်ဆင်ရေး၏မှတ်ဉာဏ်အမိန့်ကိုဖော်ပြသည်ထားတဲ့ [`Ordering`] အငြင်းအခုံကြာပါသည်။အားလုံးမှာယူသည် Modes သာဖြစ်နိုင်သည်။
            /// [`Acquire`] ကိုအသုံးပြုခြင်းသည်စတိုးဆိုင်၏အစိတ်အပိုင်းတစ်ခုဖြစ်သော [`Relaxed`] ကိုဖြစ်စေပြီး [`Release`] ကိုအသုံးပြုခြင်းသည်ဝန်ဆောင်မှုများကို [`Relaxed`] ဖြစ်စေသည်ကိုသတိပြုပါ။
            ///
            ///
            /// **မှတ်ချက်**: ဤနည်းလမ်းကိုအက်တမ်စစ်ဆင်ရေးများကိုထောက်ပံ့သောပလက်ဖောင်းများပေါ်တွင်သာရရှိနိုင်သည်
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// ဘား=12;
            /// min_foo=foo.fetch_min (ဘား၊ Ordering::SeqCst).min(bar);
            /// assert_eq (min_foo, 12)!
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // လုံခြုံမှု-ဒေတာပြိုင်ပွဲများကိုအနုမြူသတ္တိကြွအားဖြင့်တားဆီးသည်။
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// တစ် ဦး mutable pointer အခြေခံကိန်းမှပြန်သွားသည်။
            ///
            /// အနုမြူဗုံးမဟုတ်သောအရာများကိုဖတ်ခြင်းနှင့်ရေးသားခြင်းသည်ကိန်းဂဏန်းများဖြစ်နိုင်သည်။
            /// ဤနည်းလမ်းသည် FFI အတွက် function အများအားဖြင့်အသုံးဝင်သည်
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// အက်တမ်အမျိုးအစားများသည်အတွင်းပိုင်းရှင်သန်နိုင်စွမ်းနှင့်အလုပ်လုပ်သောကြောင့်၎င်းသည်အက်တမ်ကိုမျှဝေထားသောရည်ညွှန်းချက်မှ `*mut` pointer တစ်ခုကိုပြန်ပို့ခြင်းသည်လုံခြုံသည်။
            /// အနုမြူဗုံး၏ပြုပြင်မွမ်းမံမှုအားလုံးသည်တန်ဖိုးကိုမျှဝေထားခြင်းအားဖြင့်တန်ဖိုးကိုပြောင်းလဲစေပြီး၎င်းတို့သည်အနုမြူစစ်ဆင်ရေးများကိုအသုံးပြုသရွေ့လုံခြုံစွာပြုလုပ်နိုင်သည်။
            /// အဆိုပါပြန်လာသောကုန်ကြမ်း pointer ကိုမဆိုသုံးစွဲခြင်းတစ်ဦး `unsafe` ပိတ်ပင်တားဆီးမှုလိုအပ်ပြီးနေဆဲတူညီတဲ့ကန့်သတ်ထောက်ဖို့ရှိပါတယ်: ကအပေါ်စစ်ဆင်ရေးအနုမြူဗုံးဖြစ်ရမည်။
            ///
            ///
            /// # Examples
            ///
            /// `` (extern-declaration) လျစ်လျူရှု
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// ပြင်ပ "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // လုံခြုံမှု: ကို Safe နေသမျှကာလပတ်လုံး `my_atomic_op` အနုမြူဗုံးဖြစ်သကဲ့သို့။
            /// unsafe {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `atomic_store` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `atomic_load` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `atomic_swap` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// (__sync_fetch_and_add ကဲ့သို့) ယခင်တန်ဖိုးကိုပြန်ပို့သည်။
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `atomic_add` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// (__sync_fetch_and_sub ကဲ့သို့) ယခင်တန်ဖိုးကိုပြန်ပို့သည်။
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `atomic_sub` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `atomic_compare_exchange` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `atomic_compare_exchange_weak` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // လုံခြုံမှု: အခေါ်ဆိုမှု `atomic_and` များအတွက်လုံခြုံမှုစာချုပ်ထောက်ရမယ်
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `atomic_nand` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // လုံခြုံမှု: အခေါ်ဆိုမှု `atomic_or` များအတွက်လုံခြုံမှုစာချုပ်ထောက်ရမယ်
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // လုံခြုံမှု: အခေါ်ဆိုမှု `atomic_xor` များအတွက်လုံခြုံမှုစာချုပ်ထောက်ရမယ်
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// max တန်ဖိုးကို (လက်မှတ်ထိုးနှိုင်းယှဉ်) ပြန်လာ
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // လုံခြုံမှု: အခေါ်ဆိုမှု `atomic_max` များအတွက်လုံခြုံမှုစာချုပ်ထောက်ရမယ်
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// min တန်ဖိုး (လက်မှတ်ထိုးနှိုင်းယှဉ်) ကိုပြန်လာသည်
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // လုံခြုံမှု: အခေါ်ဆိုမှု `atomic_min` များအတွက်လုံခြုံမှုစာချုပ်ထောက်ရမယ်
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// max တန်ဖိုးကိုပြန်ပို့ပေးသည်။
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `atomic_umax` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// ပြန်သည့်မိနစ်တန်ဖိုး (လက်မှတ်မထိုးနှိုင်းယှဉ်)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `atomic_umin` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// အက်တမ်ခြံစည်းရိုး။
///
/// သတ်မှတ်ထားသောအမှာစာပေါ် မူတည်၍ ခြံစည်းရိုးသည် compiler နှင့် CPU တို့ကို၎င်းပတ် ၀ န်းကျင်ရှိလည်ပတ်မှုဆိုင်ရာအချို့အမျိုးအစားများကိုပြန်လည်စီစဉ်ရန်တားဆီးသည်။
/// ၎င်းသည်၎င်းနှင့်အက်တမ်လုပ်ငန်းများသို့မဟုတ်ခြံစည်းရိုးများအကြားဆက်နွယ်မှုကိုဖန်တီးသည်။
///
/// (အနည်းဆုံး) [`Release`] သာသနာကို semantic, (အနည်းဆုံး) [`Acquire`] semantic နှင့်အတူတစ်ဦးခြံစည်းရိုး 'B' နှင့်အတူ synchronous နှင့်စစ်ဆင်ရေးအဲဒီမှာတည်ရှိသာလျှင် X နဲ့ Y, တစ်ဦးကမတိုင်မီ sequenced ကြောင်း 'M' ထိုကဲ့သို့သောအချို့အနုမြူဗုံးအရာဝတ္ထုအပေါ်နှစ်ဦးစလုံးဟာ operating လျှင်ရှိပြီးဖြစ်သောတစ်ဦးကခြံစည်းရိုး 'A' X, Y သည် B မတိုင်မီထပ်တူကျပြီး Y သည်အမ်ပြောင်းခြင်းကိုသတိပြုမိသည်။
/// ၎င်းသည် A နှင့် B အကြားဖြစ်ပျက်မှုမတိုင်မီမှီခိုမှုတစ်ခုဖြစ်သည်။
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// [`Release`] သို့မဟုတ် [`Acquire`] semantic နှင့်အက်တမ်စစ်ဆင်ရေးများသည်ခြံစည်းရိုးနှင့်ထပ်တူပြုနိုင်သည်။
///
/// [`Acquire`] နှင့် [`Release`] semantics နှစ်မျိုးလုံးအပြင်၊ [`SeqCst`] မှာထားသည့်ခြံစည်းရိုးသည်အခြား [`SeqCst`] စစ်ဆင်ရေးများနှင့်/သို့မဟုတ်ခြံစည်းရိုးများ၏ကမ္ဘာလုံးဆိုင်ရာအစီအစဉ်အမိန့်တွင်ပါ ၀ င်သည်။
///
/// [`Acquire`], [`Release`], [`AcqRel`] နှင့် [`SeqCst`] အစီအစဉ်များကိုလက်ခံသည်။
///
/// # Panics
///
/// `order` လျှင် Panics [`Relaxed`] ဖြစ်ပါတယ်။
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // spinlock အပေါ်အခြေခံပြီးတစ် ဦး ကနှစ် ဦး နှစ်ဖက်အပြန်အလှန်ဖယ်စရိုက်။
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // အဟောင်းတန်ဖိုး `false` သည်အထိစောင့်ပါ။
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // ဤသည်ခြံစည်းရိုး synchronizes-နှင့်အတူစတိုးဆိုင် `unlock` ၌တည်၏။
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // လုံခြုံမှု-အနုမြူခြံစည်းရိုးကိုအသုံးပြုခြင်းသည်အန္တရာယ်ကင်းသည်။
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// တစ် ဦး က compiler ကမှတ်ဉာဏ်ခြံစည်းရိုး။
///
/// `compiler_fence` မည်သည့်စက်ကုဒ်မှမထုတ်ပေးပါ၊ သို့သော် compiler လုပ်ရန်ခွင့်ပြုထားသည့်ပြန်လည်မှတ်သားထားသည့်မှတ်ဉာဏ်အမျိုးအစားများကိုကန့်သတ်ထားသည်။အထူးသ, ပေးထားသော [`Ordering`] semantic အပေါ်မူတည်။ compiler `compiler_fence` ဖို့ခေါ်ဆိုမှု၏အခြားဘက်ခြမ်းမှခေါ်ဆိုမှုမီသို့မဟုတ်အပြီးကနေဖတ်သို့မဟုတ်ရေးသားမှုရွေ့လျားမှုမှပိတ်ပင်ထားနိုင်ပါသည်။သတိပြုရန်မှာ-*ဟာ့ဒ်ဝဲ* အားဤကဲ့သို့ပြန်လည်စီစဉ်မှုမပြုလုပ်ရန်သတိပြုပါ။
///
/// ၎င်းသည် single-threaded၊ execute အခြေအနေတွင်ပြaနာမဟုတ်ပါ။ သို့သော်အခြားချည်များသည်တစ်ချိန်တည်းတွင်မှတ်ဉာဏ်ကိုပြုပြင်နိုင်သည့်အခါ [`fence`] ကဲ့သို့ပိုမိုအားကောင်းသောထပ်တူပြုခြင်း Primitive များလိုအပ်သည်။
///
/// မတူညီသောသာသနာ့ ၀ န်ဆောင်မှုများမှတားဆီးထားသောပြန်လည်စီစဉ်ခြင်းမှာ-
///
///  - [`SeqCst`] နှင့်အတူဤအချက်ကို ဖြတ်၍ ပြန်လည်ဖတ်ခြင်းနှင့်ရေးသားခြင်းများကိုပြန်လည်စီစဉ်ခြင်းမရှိပါ။
///  - [`Release`] နှင့်အတူယခင်ဖတ်ခြင်းနှင့်ရေးသားခြင်းသည်နောက်ဆက်တွဲရေးသားမှုများမှရွေ့လျား။ မရပါ။
///  - [`Acquire`] အတူနောက်ဆက်တွဲဖတ်ရေးရှေ့ဆက်ဖတ်ရှေ့အများပြောင်းရွေ့မရပါ။
///  - [`AcqRel`] နှင့်အတူ, အထက်ပါစည်းမျဉ်းနှစ်ခုလုံးပြဌာန်းနေကြသည်။
///
/// `compiler_fence` *ကိုယ်နှိုက်နှင့်အတူ* ပြိုင်ကားကနေချည်တားဆီးဘို့ကိုသာအသုံးဝင်ယေဘုယျအားဖြင့်ဖြစ်ပါသည်။ဆိုလိုသည်မှာပေးထားသောချည်သည်ကုဒ်တစ်ကြောင်းကိုလုပ်ဆောင်ပြီးနောက်၎င်းကိုရပ်တန့်ပြီးအခြားနေရာ၌ရှိသောကုဒ်ကိုစတင်လုပ်ဆောင်လျှင် (တူညီသောအချည်တွင်ရှိနေစဉ်နှင့်အယူအဆတစ်ခုတည်းတွင်ပင်အတူတူပင်ရှိလျှင်) ဖြစ်သည်။ရိုးရာအစီအစဉ်များတွင်၊ signal handler ကိုမှတ်ပုံတင်ပြီးမှသာဤအရာသည်ဖြစ်ပွားနိုင်သည်။
/// ပိုမိုနိမ့်နိမ့် code များတွင်ထိုကဲ့သို့သောအခြေအနေများသည် interrupts များကိုကိုင်တွယ်သောအခါ၊ pre-emption ဖြင့်အစိမ်းရောင်ချည်များကိုအကောင်အထည်ဖော်ခြင်းစသည့်အခြေအနေများပေါ်ပေါက်နိုင်သည်
/// စပ်စုသောစာဖတ်သူများအား Linux kernel ၏ [memory barriers] အကြောင်းဆွေးနွေးမှုကိုဖတ်ရန်တိုက်တွန်းပါသည်။
///
/// # Panics
///
/// `order` လျှင် Panics [`Relaxed`] ဖြစ်ပါတယ်။
///
/// # Examples
///
/// `compiler_fence` မရှိပါကအောက်ပါကုဒ်ပါ `assert_eq!` သည်ချည်မျှင်တစ်ခုတည်း၌ဖြစ်ပျက်နေသော်လည်းအောင်မြင်ရန်အာမခံချက်မရှိပါ။
/// ဘာကြောင့်လဲဆိုတာသိချင်ရင် compiler က `IMPORTANT_VARIABLE` နဲ့ `IS_READ` သိုလှောင်စတိုးဆိုင်များကို `Ordering::Relaxed` နှစ်မျိုးလုံးကိုလဲလှယ်နိုင်မှာကိုသတိရပါ။ကမ, နှင့် signal ကို handler ကိုညာဘက် `IS_READY` ပြီးနောက်မဖြစ်၏ဖြစ်ပါတယ် updated လျှင်, ထို signal ကို handler ကို `IS_READY=1`, ဒါပေမယ့် `IMPORTANT_VARIABLE=0` မြင်လိမ့်မည်။
/// ဤအခြေအနေကို `compiler_fence` ကုစားနည်းကိုသုံးခြင်း။
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // ဒီအမှတ်ထက်ကျော်လွန်ပြောင်းရွှေ့ခံရခြင်းမှအစောပိုင်းကရေးတားဆီး
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // လုံခြုံမှု-အနုမြူခြံစည်းရိုးကိုအသုံးပြုခြင်းသည်အန္တရာယ်ကင်းသည်။
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Processor ကို၎င်းသည်အလုပ်ရှုပ်နေသောစောင့်ဆိုင်းနေသောလည်ပတ်ကွင်း ("spin lock") အတွင်း၌ရှိသည်ဟူသောအချက်ပြသည်။
///
/// ဒီ function ကို [`hint::spin_loop`] ၏မျက်နှာသာအတွက်ကန့်ကွက်သည်။
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}