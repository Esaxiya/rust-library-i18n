#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// `char` နှင့် `str` နည်းလမ်းများ၏ယူနီကုဒ်အစိတ်အပိုင်းများအပေါ်အခြေခံပြီးဖြစ်ကြောင်း [Unicode](http://www.unicode.org/) ၏ဗားရှင်း။
///
/// Unicode ဗားရှင်းအသစ်များကိုပုံမှန်ဖြန့်ချိပြီးနောက်တွင်ယူနီကုဒ်ပေါ် မူတည်၍ စံစာကြည့်တိုက်ရှိနည်းလမ်းအားလုံးကိုအဆင့်မြှင့်တင်သည်။
/// ထို့ကြောင့်အချို့ `char` နှင့် `str` နည်းလမ်းများ၏အပြုအမူနှင့်ဤစဉ်ဆက်မပြတ်၏တန်ဖိုးအချိန်နှင့်အမျှပြောင်းလဲစေပါသည်။
/// ဤသည်ကို * ချိုးဖောက်နေသောပြောင်းလဲမှုဟုမယူမှတ်ပါ။
///
/// ဗားရှင်းနံပါတ်အစီအစဉ်ကို [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) တွင်ရှင်းပြထားသည်။
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// liball ကိုအသုံးပြုရန်အတွက် libstd သို့ပြန်လည်တင်ပို့ခြင်းမဟုတ်ပါ။
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;