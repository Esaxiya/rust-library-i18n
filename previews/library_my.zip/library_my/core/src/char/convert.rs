//! အက္ခရာပြောင်းလဲခြင်း။

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// `u32` ကို `char` အဖြစ်ပြောင်းပေးသည်။
///
/// [`char`] s အားလုံးသည်မှန်ကန်သော [`u32`] s များဖြစ်သည်နှင့်အတူတစ်ခုနှင့်တစ်ခုချနိုင်သည်
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// သို့သော်ပြောင်းပြန်မမှန်ပါဘူး: အားလုံးမဟုတ်တရားဝင် [`u32`] s ကို [`char`] s ကိုတရားဝင်ဖြစ်ကြသည်။
/// `from_u32()` အဆိုပါ input ကိုတစ်ဦး [`char`] များအတွက်တရားဝင်တန်ဖိုးကိုမပါလျှင် `None` ပြန်လာပါလိမ့်မယ်။
///
/// ဤစစ်ဆေးမှုများကိုလျစ်လျူရှုသောလုံခြုံမှုမရှိသောဤလုပ်ဆောင်ချက်အတွက် [`from_u32_unchecked`] တွင်ကြည့်ပါ။
///
///
/// # Examples
///
/// အခြေခံအသုံးပြုမှု-
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// အဆိုပါ input ကိုခိုင်လုံသော [`char`] မပါသောအခါ `None` ပြန်လာ:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// တရားဝင်မှုကိုလျစ်လျူရှုပြီး `u32` ကို `char` တစ်ခုသို့ပြောင်းသည်။
///
/// [`char`] s အားလုံးသည်မှန်ကန်သော [`u32`] s များဖြစ်သည်နှင့်အတူတစ်ခုနှင့်တစ်ခုချနိုင်သည်
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// သို့သော်ပြောင်းပြန်မမှန်ပါဘူး: အားလုံးမဟုတ်တရားဝင် [`u32`] s ကို [`char`] s ကိုတရားဝင်ဖြစ်ကြသည်။
/// `from_u32_unchecked()` ၎င်းကိုလျစ်လျူရှုပြီးမမှန်မကန်ပြုလုပ်နိုင်သည့်အရာကို [`char`] သို့မျက်စိကန်းစွာချပစ်လိမ့်မည်။
///
///
/// # Safety
///
/// ဒါဟာမမှန်ကန်တဲ့ `char` တန်ဖိုးများကိုတည်ဆောက်စေခြင်းငှါအဖြစ်ဒီ function, မလုံခြုံသည်။
///
/// ဒီ function ကိုတစ်လုံခြုံဗားရှင်းအဘို့, [`from_u32`] function ကိုကြည့်ပါ။
///
/// # Examples
///
/// အခြေခံအသုံးပြုမှု-
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // လုံခြုံမှု-ဖုန်းပြောသူသည် `i` သည်မှန်ကန်သော char တန်ဖိုးဖြစ်ကြောင်းအာမခံရမည်။
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// တစ်ဦး [`char`] တစ် [`u32`] သို့ပြောင်းပေးပါတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// [`char`] ကို [`u64`] အဖြစ်ပြောင်းပေးသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // char သည် code point ၏တန်ဖိုးသို့ချပစ်သည်။
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] ကိုကြည့်ပါ
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// တစ်ဦး [`char`] တစ် [`u128`] သို့ပြောင်းပေးပါတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // အဆိုပါ char 128 bit နဲ့မှသုည-တိုးချဲ့ဖြစ်လျှင်, ကုဒ်ပွိုင့်၏တန်ဖိုးမှ casted ဖြစ်ပါတယ်။
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] ကိုကြည့်ပါ
        c as u128
    }
}

/// Maps ကိုအဘယ်သူ၏ကုဒ်ပွိုင့် U + သည် 0000 ..=U + သည် 00FF အတွက်တူညီသောတန်ဖိုးကိုရှိပါတယ်တဲ့ `char` မှ 0x00 ..=0xFF တစ်ဦးက byte ။
///
/// Unicode ကိုဒီဇိုင်းပြုလုပ်ထားခြင်းကြောင့် IANA သည် ISO-8859-1 ဟုခေါ်သော character encoding ဖြင့် bytes များကိုထိရောက်စွာ decode လုပ်သည်။
/// ဤသည် encoding က ASCII နှင့်သဟဇာတဖြစ်ပါတယ်။
///
/// ဤသည် ISO/IEC 8859-1 ခေါ်နှင့်ကွဲပြားကြောင်းသတိပြုပါ
/// မည်သည့်ဇာတ်ကောင်ကိုမှမသတ်မှတ်ထားသည့် "blanks" အချို့သော byte တန်ဖိုးများကိုကျန်စေသည့် ISO 8859-1 (တုံးတိုတစ်မျိုးတည်းဖြင့်) ။
/// က ISO-8859-1 (ထို IANA တဦးတည်း) အ C0 နှင့် C1 ထိန်းချုပ်မှု codes တွေကိုသူတို့ကိုသတ်မှတ်ပေးထားတဲ့။
///
/// ဒီခေါ် *လည်း* Windows ကို-1252 ကနေမတူညီတဲ့ကြောင်းကိုမှတ်စု
/// ပုဒ်ဖြတ်ခြင်းနှင့်အမျိုးမျိုးသောလက်တင်ဇာတ်ကောင်အချို့ (အားလုံးမဟုတ်!) ကွက်လပ်သတ်မှတ်ပေးထားတဲ့တဲ့ superset ISO/IEC 8859-1 ဖြစ်သည့်ကုဒ်စာမျက်နှာ 1252 ။
///
/// ပိုမိုရှုပ်ထွေးစေရန် [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` နှင့် `windows-1252` အားလုံးသည် Windows-1252 ၏ superset တစ်ခုအတွက်ကျန်ရှိသောကွက်လပ်များကိုသက်ဆိုင်ရာ C0 နှင့် C1 control codes တွေနဲ့ပြည့်စေသည်။
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// [`u8`] ကို [`char`] အဖြစ်ပြောင်းပေးသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// char parsing လုပ်သည့်အခါပြန်လာနိုင်သည့်အမှားတစ်ခု။
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // လုံခြုံမှု-၎င်းသည်တရားဝင်ယူနီကုဒ်တန်ဖိုးဖြစ်ကြောင်းစစ်ဆေးခဲ့သည်
            Ok(unsafe { transmute(i) })
        }
    }
}

/// char မှ u32 ကနေပြောင်းလဲခြင်းပျက်ကွက်သောအခါအမှား type ကိုပြန်သွားကြ၏။
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// ပေးထားသော radix ရှိဂဏန်းတစ်ခုကို `char` သို့ပြောင်းပေးသည်။
///
/// တစ်ဦးက 'radix' ကဒီမှာတစ်ခါတစ်ရံလည်း 'base' ဟုခေါ်သည်။
/// နှစ်ခု၏ radix သည်တူညီသောတန်ဖိုးများကိုပေးနိုင်ရန် binary number တစ်ခု၊ radix ဆယ်ခု၊ ဒdecimalမတစ်ခုနှင့် hexadecimal ခြောက်ဆယ်မြောက် radix ကိုဖော်ပြသည်။
///
/// မတရားအစွန်းရောက်ထောက်ခံနေကြသည်။
///
/// `from_digit()` အဆိုပါ input ကိုပေးထားသော radix တစ်ဂဏန်းမပါလျှင် `None` ပြန်လာပါလိမ့်မယ်။
///
/// # Panics
///
/// 36 ထက်ပိုကြီးတဲ့ radix ပေးထားလျှင် Panics ။
///
/// # Examples
///
/// အခြေခံအသုံးပြုမှု-
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Decimal 11 သည် base 16 တွင်ရှိသောတစ်ခုတည်းသောဂဏန်းဖြစ်သည်
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// အဆိုပါ input ကိုတစ်ဂဏန်းမပါသောအခါ `None` ပြန်လာ:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// တစ်ဦး panic ဖြစ်ပေါ်စေမယ့်ကြီးမားတဲ့ radix ဖြတ်သန်း:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}