//! char {} ဆိုလိုသည်

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// `char` တွင်ရှိနိုင်သောအမြင့်ဆုံးတရားဝင်ကုဒ်အမှတ်ဖြစ်သည်။
    ///
    /// တစ်ဦးက `char` က [Code Point] ကြောင်းကိုဆိုလိုတယ်, ဒါပေမယ့်လူတယောက်အကွာအဝေးအတွင်းသာသူမြားသော [Unicode Scalar Value] ဖြစ်ပါသည်။
    /// `MAX` တရားဝင် [Unicode Scalar Value] ရဲ့အမြင့်ဆုံးတရားဝင်ကုဒ်မှတ်ဖြစ်ပါတယ်။
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () တစ်ဦးအားကုဒ်ဖြုတ်အမှားကိုယ်စားပြုယူနီကုဒ်အတွက်အသုံးပြုသည်။
    ///
    /// ဥပမာ-UTF-8 အားမကောင်းသောပုံစံ UTF-8 bytes များပေးသောအခါတွင်ဖြစ်နိုင်သည်။
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// `char` နှင့် `str` နည်းလမ်းများ၏ယူနီကုဒ်အစိတ်အပိုင်းများအပေါ်အခြေခံပြီးဖြစ်ကြောင်း [Unicode](http://www.unicode.org/) ၏ဗားရှင်း။
    ///
    /// Unicode ဗားရှင်းအသစ်များကိုပုံမှန်ဖြန့်ချိပြီးနောက်တွင်ယူနီကုဒ်ပေါ် မူတည်၍ စံစာကြည့်တိုက်ရှိနည်းလမ်းအားလုံးကိုအဆင့်မြှင့်တင်သည်။
    /// ထို့ကြောင့်အချို့ `char` နှင့် `str` နည်းလမ်းများ၏အပြုအမူနှင့်ဤစဉ်ဆက်မပြတ်၏တန်ဖိုးအချိန်နှင့်အမျှပြောင်းလဲစေပါသည်။
    /// ဤသည်ကို * ချိုးဖောက်နေသောပြောင်းလဲမှုဟုမယူမှတ်ပါ။
    ///
    /// ဗားရှင်းနံပါတ်အစီအစဉ်ကို [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) တွင်ရှင်းပြထားသည်။
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// `iter` ရှိ UTF-16 encoded code points အပေါ်တွင်ကြားခံတစ်ခုကိုဖန်တီးသည်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// `Err` ရလဒ်များကိုအစားထိုးအက္ခရာဖြင့်အစားထိုးခြင်းဖြင့် lossy decoder ကိုရနိုင်သည်။
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// `u32` ကို `char` အဖြစ်ပြောင်းပေးသည်။
    ///
    /// ```` ```` ```` ```` ```` ```` ```` ``၊
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// သို့သော်ပြောင်းပြန်မမှန်ပါဘူး: အားလုံးမဟုတ်တရားဝင် [`u32`] s ကိုတရားဝင်`char`s ဖြစ်ကြသည်။
    /// `from_u32()` အဆိုပါ input ကိုတစ်ဦး `char` များအတွက်တရားဝင်တန်ဖိုးကိုမပါလျှင် `None` ပြန်လာပါလိမ့်မယ်။
    ///
    /// ဤစစ်ဆေးမှုများကိုလျစ်လျူရှုသောလုံခြုံမှုမရှိသောဤလုပ်ဆောင်ချက်အတွက် [`from_u32_unchecked`] တွင်ကြည့်ပါ။
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// ထည့်သွင်းမှုသည်တရားဝင် `char` မဟုတ်ပါက `None` ကိုပြန်ပို့သည်
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// တရားဝင်မှုကိုလျစ်လျူရှုပြီး `u32` ကို `char` တစ်ခုသို့ပြောင်းသည်။
    ///
    /// ```` ```` ```` ```` ```` ```` ```` ``၊
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// သို့သော်ပြောင်းပြန်မမှန်ပါဘူး: အားလုံးမဟုတ်တရားဝင် [`u32`] s ကိုတရားဝင်`char`s ဖြစ်ကြသည်။
    /// `from_u32_unchecked()` ဒီလျစ်လျူရှုနှင့်ဆင်ကန်းတောတိုး `char` မှပစ်ဖြစ်နိုင်သည်အနေနဲ့မမှန်ကန်တဲ့တစ်ခုဖန်တီးပါလိမ့်မယ်။
    ///
    ///
    /// # Safety
    ///
    /// ဒါဟာမမှန်ကန်တဲ့ `char` တန်ဖိုးများကိုတည်ဆောက်စေခြင်းငှါအဖြစ်ဒီ function, မလုံခြုံသည်။
    ///
    /// ဒီ function ကိုတစ်လုံခြုံဗားရှင်းအဘို့, [`from_u32`] function ကိုကြည့်ပါ။
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // လုံခြုံမှု: လုံခြုံရေးစာချုပ်အဆိုပါခေါ်ဆိုမှုများကထောကျခံခဲ့ရမည်ဖြစ်သည်။
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// ပေးထားသော radix ရှိဂဏန်းတစ်ခုကို `char` သို့ပြောင်းပေးသည်။
    ///
    /// တစ်ဦးက 'radix' ကဒီမှာတစ်ခါတစ်ရံလည်း 'base' ဟုခေါ်သည်။
    /// နှစ်ခု၏ radix သည်တူညီသောတန်ဖိုးများကိုပေးနိုင်ရန် binary number တစ်ခု၊ radix ဆယ်ခု၊ ဒdecimalမတစ်ခုနှင့် hexadecimal ခြောက်ဆယ်မြောက် radix ကိုဖော်ပြသည်။
    ///
    /// မတရားအစွန်းရောက်ထောက်ခံနေကြသည်။
    ///
    /// `from_digit()` အဆိုပါ input ကိုပေးထားသော radix တစ်ဂဏန်းမပါလျှင် `None` ပြန်လာပါလိမ့်မယ်။
    ///
    /// # Panics
    ///
    /// 36 ထက်ပိုကြီးတဲ့ radix ပေးထားလျှင် Panics ။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Decimal 11 သည် base 16 တွင်ရှိသောတစ်ခုတည်းသောဂဏန်းဖြစ်သည်
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// အဆိုပါ input ကိုတစ်ဂဏန်းမပါသောအခါ `None` ပြန်လာ:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// တစ်ဦး panic ဖြစ်ပေါ်စေမယ့်ကြီးမားတဲ့ radix ဖြတ်သန်း:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// `char` သည်ပေးထားသော radix တွင်ဂဏန်းတစ်ခုဟုတ်မဟုတ်စစ်ဆေးသည်။
    ///
    /// တစ်ဦးက 'radix' ကဒီမှာတစ်ခါတစ်ရံလည်း 'base' ဟုခေါ်သည်။
    /// နှစ်ခု၏ radix သည်တူညီသောတန်ဖိုးများကိုပေးနိုင်ရန် binary number တစ်ခု၊ radix ဆယ်ခု၊ ဒdecimalမတစ်ခုနှင့် hexadecimal ခြောက်ဆယ်မြောက် radix ကိုဖော်ပြသည်။
    ///
    /// မတရားအစွန်းရောက်ထောက်ခံနေကြသည်။
    ///
    /// [`is_numeric()`] နှင့်နှိုင်းယှဉ်ပါကဤလုပ်ဆောင်မှုသည် `0-9`, `a-z` နှင့် `A-Z` အက္ခရာများကိုသာအသိအမှတ်ပြုသည်။
    ///
    /// 'Digit' အောက်ပါအက္ခရာများသာဖြစ်ရန်သတ်မှတ်ထားသည်။
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// 'digit' တစ်ဦးထက်ပိုသောပြည့်စုံသောနားလည်မှုအဘို့, [`is_numeric()`] ကြည့်ပါ။
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// 36 ထက်ပိုကြီးတဲ့ radix ပေးထားလျှင် Panics ။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// တစ်ဦး panic ဖြစ်ပေါ်စေမယ့်ကြီးမားတဲ့ radix ဖြတ်သန်း:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// `char` သည်ပေးထားသော radix ရှိဂဏန်းတစ်ခုသို့ပြောင်းလဲနိုင်သည်။
    ///
    /// တစ်ဦးက 'radix' ကဒီမှာတစ်ခါတစ်ရံလည်း 'base' ဟုခေါ်သည်။
    /// နှစ်ခု၏ radix သည်တူညီသောတန်ဖိုးများကိုပေးနိုင်ရန် binary number တစ်ခု၊ radix ဆယ်ခု၊ ဒdecimalမတစ်ခုနှင့် hexadecimal ခြောက်ဆယ်မြောက် radix ကိုဖော်ပြသည်။
    ///
    /// မတရားအစွန်းရောက်ထောက်ခံနေကြသည်။
    ///
    /// 'Digit' အောက်ပါအက္ခရာများသာဖြစ်ရန်သတ်မှတ်ထားသည်။
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// `char` သည်ပေးထားသော radix ရှိဂဏန်းတစ်ခုကိုရည်ညွှန်းခြင်းမရှိပါက `None` သို့ပြန်သွားသည်။
    ///
    /// # Panics
    ///
    /// 36 ထက်ပိုကြီးတဲ့ radix ပေးထားလျှင် Panics ။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// ကျရှုံးခြင်းအတွက် non-ဂဏန်းရလဒ်များကိုဖြတ်သန်း:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// တစ်ဦး panic ဖြစ်ပေါ်စေမယ့်ကြီးမားတဲ့ radix ဖြတ်သန်း:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // code က `radix` အဆက်မပြတ်နှင့် 10 သို့မဟုတ်သေးငယ်သည်အဘယ်မှာရှိဖြစ်ပွားမှုများအတွက်ကွပ်မျက်မြန်နှုန်းတိုးတက်လာဖို့ကဒီမှာတက်ကွဲနေသည်
        //
        let val = if likely(radix <= 10) {
            // အကယ်၍ ဂဏန်းတစ်ခုမဟုတ်ပါက radix ထက်သာလွန်သောနံပါတ်ကိုဖန်တီးလိမ့်မည်။
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// `char`s အနေဖြင့်အက္ခရာ၏ hexadecimal Unicode ထွက်ပေါက်ကိုပေးသောကြားဖြတ်တစ်ခုကိုပြန်ပို့သည်။
    ///
    /// ဤသည် `NNNNNN` တစ် hexadecimal ကိုယ်စားပြုမှုသည်အဘယ်မှာရှိပုံစံ `\u{NNNNNN}` ၏ Rust syntax နှင့်အတူဇာတ်ကောင်လွတ်မြောက်ရန်ပါလိမ့်မယ်။
    ///
    ///
    /// # Examples
    ///
    /// ကြားဖြတ်အဖြစ်
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` ကိုတိုက်ရိုက်အသုံးပြုခြင်း
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// နှစ် ဦး စလုံးညီမျှသည်:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// `to_string` ကိုအသုံးပြုသည်။
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // တဦးတည်းဂဏန်း (အတူတူပင်ဖြစ်ပါသည်) ကိုပုံနှိပ်ခြင်းနှင့်သင့်ကြောင်းက c==0 code ကို computing များအတွက် (31, 32) underflow ရှောင်ကြောင်းသို့မဟုတ်-ing 1 လုပ်ဆောင်
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // အထင်ရှားဆုံး hex ဂဏန်း၏အညွှန်းကိန်း
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// တိုးချဲ့ထားသော Grapheme codepoints မှလွတ်မြောက်ရန်ခွင့်ပြုသည့်တိုးချဲ့ထားသော `escape_debug` ဗားရှင်း။
    /// ဤသည်ကကျွန်ုပ်တို့သည် string တစ်ခု၏အစတွင်၎င်းတို့သည်အကွာအဝေးမရှိသောအမှတ်အသားများကဲ့သို့သောအက္ခရာများကိုပိုမိုကောင်းမွန်စွာ format လုပ်စေသည်။
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// character တစ်ခု၏ ```` ```` `` `ကြားခံတစ်ခု (return) ကိုပြန်ပို့သည်။
    ///
    /// ၎င်းသည် `str` သို့မဟုတ် `char` ၏ `Debug` အကောင်အထည်ဖော်မှုများနှင့်ဆင်တူသောအက္ခရာများမှလွတ်မြောက်လိမ့်မည်။
    ///
    ///
    /// # Examples
    ///
    /// ကြားဖြတ်အဖြစ်
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` ကိုတိုက်ရိုက်အသုံးပြုခြင်း
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// နှစ် ဦး စလုံးညီမျှသည်:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// `to_string` ကိုအသုံးပြုသည်။
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// character တစ်ခု၏ ```` ```` `` `ကြားခံတစ်ခု (return) ကိုပြန်ပို့သည်။
    ///
    /// ပုံမှန်အားဖြင့် C++ 11 နှင့်အလားတူ C-family ဘာသာစကားများအပါအ ၀ င်ဘာသာစကားအမျိုးမျိုးဖြင့်တရားဝင်ဖြစ်သော literals များထုတ်လုပ်ရန်ဘက်လိုက်မှုဖြင့်ရွေးချယ်သည်။
    /// တိကျသောစည်းမျဉ်းများမှာ
    ///
    /// * Tab သည် `\t` အဖြစ်ထွက်ပြေးသည်။
    /// * သယ်ယူပို့ဆောင်ရေးပြန်လာ `\r` အဖြစ်ထွက်ပြေးလွတ်မြောက်သည်။
    /// * Line feed သည် `\n` ကဲ့သို့လွတ်သွားသည်။
    /// * လူပျိုကိုးကား `\'` လွတ်သကဲ့သို့ဖြစ်ပါတယ်။
    /// * နှစ်ချက်ကိုးကား `\"` လွတ်သကဲ့သို့ဖြစ်ပါတယ်။
    /// * Backslash သည် `\\` ကဲ့သို့လွတ်သွားသည်။
    /// * 'Printable ASCII' အကွာအဝေးမှ `0x20` .. `0x7e` ပါ ၀ င်သောမည်သည့်အက္ခရာမှမလွတ်မြောက်ပါ။
    /// * အခြားအက္ခရာများအားလုံးအား hexadecimal Unicode escapes;[`escape_unicode`] ကိုကြည့်ပါ။
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// ကြားဖြတ်အဖြစ်
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` ကိုတိုက်ရိုက်အသုံးပြုခြင်း
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// နှစ် ဦး စလုံးညီမျှသည်:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// `to_string` ကိုအသုံးပြုသည်။
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// UTF-8 တွင် encoded လုပ်ပါကဤ `char` လိုအပ်သော bytes အရေအတွက်ကို return ပြန်ပေးသည်။
    ///
    /// ထို bytes အရေအတွက်သည် ၁ မှ ၄ အထိအကြားဖြစ်သည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// အဆိုပါ `&str` type ကိုအာမခံချက်သူ့ရဲ့အကြောင်းအရာတွေကို UTF-8 ဖြစ်ကြောင်း, ကြှနျုပျတို့တစ်ဦးချင်းစီကုဒ်အမှတ် `&str` သူ့ဟာသူအတွက် vs တစ်ဦး `char` အဖြစ်ကိုယ်စားပြုခဲ့လျှင်ယူမယ်လို့အရှည်နှိုင်းယှဉ်နိုင်အောင်:
    ///
    ///
    /// ```
    /// // chars အဖြစ်
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // နှစ် ဦး စလုံးသုံး bytes အဖြစ်ကိုယ်စားပြုနိုင်ပါတယ်
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // တစ်ဦး &str အဖြစ်ဤနှစ်ခု UTF-8 အတွက် encoded နေကြတယ်
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // ကျနော်တို့ကိုသူတို့ကစုစုပေါင်း bytes ခြောက်လယူကြောင်းတွေ့မြင်နိုင်သည် ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... ရုံ &str လိုပဲ
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// UTF-16 အတွက် encoded လျှင်ဤ `char` လို 16-bit နဲ့ code ကိုအစီးရေအရေအတွက် Returns ။
    ///
    ///
    /// ဒီ concept ကိုပိုမိုရှင်းပြချက်အဘို့အ [`len_utf8()`] များအတွက်မှတ်တမ်းတင်ကြည့်ရှုပါ။
    /// ဒီလုပ်ဆောင်ချက်ကမှန်ပေမယ့် UTF-16 အစား UTF-16 အတွက်။
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// ဒီဇာတ်ကောင်ကိုပေးထားသည့်က byte ကြားခံသို့ UTF-8 အဖြစ် Encodes, အဲဒီနောက်ကုဒ်သွင်းဇာတ်ကောင်ပါရှိသည်သောကြားခံ၏ subslice ပြန်လည်ရောက်ရှိ။
    ///
    ///
    /// # Panics
    ///
    /// ကြားခံအလုံအလောက်မကြီးဘူးဆိုရင် Panics ။
    /// အရှည်လေးတစ်ကြားခံကိုမဆို `char` ဝှက်ဖို့ကြီးမားသောလုံလောက်ပါတယ်။
    ///
    /// # Examples
    ///
    /// ဤဥပမာနှစ်ခုစလုံးမှာတော့ 'ß' အန်ကုက်လုပ်နှစ်ခု bytes ကြာပါသည်။
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// သေးလွန်းသောကြားခံ:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // လုံခြုံမှု: `char` တစ်ဦးအငှားမဟုတ်ပါဘူး, ဒါကြောင့်ဒီခိုင်လုံသော UTF-8 ဖြစ်ပါတယ်။
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// ဒီဇာတ်ကောင်ပေးထားသည့် `u16` ကြားခံသို့ UTF-16 အဖြစ် Encodes, အဲဒီနောက်ကုဒ်သွင်းဇာတ်ကောင်ပါရှိသည်သောကြားခံ၏ subslice ပြန်လည်ရောက်ရှိ။
    ///
    ///
    /// # Panics
    ///
    /// ကြားခံအလုံအလောက်မကြီးဘူးဆိုရင် Panics ။
    /// အရှည် ၂ ၏ကြားခံတစ်ခုသည်မည်သည့် `char` ကိုမဆို encode လုပ်ရန်ကြီးမားသည်။
    ///
    /// # Examples
    ///
    /// ဤဥပမာနှစ်ခုစလုံးမှာတော့ '𝕊' အန်ကုက်လုပ်နှစ်ခု `u16`s ကြာပါသည်။
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// သေးလွန်းသောကြားခံ:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// ဤ `char` တွင် `Alphabetic` ပိုင်ဆိုင်မှုရှိပါက `true` ကိုပြန်ပို့သည်။
    ///
    /// `Alphabetic` အဆိုပါ [Unicode Standard] ၏အခန်း 4 (က Character Properties ကို) တွင်ဖော်ပြထားနှင့် [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] အတွက်သတ်မှတ်ထားသောဖြစ်ပါတယ်။
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // ချစ်ခြင်းမေတ္တာအရာများစွာကိုဖြစ်ပါသည်, သို့သော်အက်ခရာစဉျမဟုတျပါဘူး
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// ဤ `char` တွင် `Lowercase` ပိုင်ဆိုင်မှုရှိပါက `true` ကိုပြန်ပို့သည်။
    ///
    /// `Lowercase` အဆိုပါ [Unicode Standard] ၏အခန်း 4 (က Character Properties ကို) တွင်ဖော်ပြထားနှင့် [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] အတွက်သတ်မှတ်ထားသောဖြစ်ပါတယ်။
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // တရုတ်စာမူအမျိုးမျိုးနှင့်ပုဒ်ဖြတ်ပုဒ်ရပ်များသည်အမှုကိစ္စမရှိပါ။
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// ဤ `char` တွင် `Uppercase` ပိုင်ဆိုင်မှုရှိပါက `true` ကိုပြန်ပို့သည်။
    ///
    /// `Uppercase` အဆိုပါ [Unicode Standard] ၏အခန်း 4 (က Character Properties ကို) တွင်ဖော်ပြထားနှင့် [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] အတွက်သတ်မှတ်ထားသောဖြစ်ပါတယ်။
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // တရုတ်စာမူအမျိုးမျိုးနှင့်ပုဒ်ဖြတ်ပုဒ်ရပ်များသည်အမှုကိစ္စမရှိပါ။
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// ဤ `char` တွင် `White_Space` ပိုင်ဆိုင်မှုရှိပါက `true` သို့ပြန်သွားသည်။
    ///
    /// `White_Space` အဆိုပါ [Unicode Character Database][ucd] [`PropList.txt`] အတွက်သတ်မှတ်ထားသောဖြစ်ပါတယ်။
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // non-ကိုချိုးဖောက်အာကာသ
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// ဒီ `char` ညျဝါ [`is_alphabetic()`] သို့မဟုတ် [`is_numeric()`] ဖြစ်စေလျှင် `true` Returns ။
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// အကယ်၍ ဤ `char` တွင်ထိန်းချုပ်မှုကုဒ်များအတွက်ယေဘူယျအမျိုးအစားရှိပါက `true` ကိုပြန်ပို့သည်။
    ///
    /// ထိန်းချုပ်မှုကုဒ်များ (`Cc` ၏အထွေထွေအမျိုးအစားနှင့်အတူကုဒ်အချက်များ) ကို [Unicode Standard] ၏အခန်း 4 (Character Properties) တွင်ဖော်ပြထားသည်နှင့် [Unicode Character Database][ucd] [`UnicodeData.txt`] တွင်ဖော်ပြထားသည်။
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// // ဦး + 009C, STRING Terminator
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// ဒီ `char` အဆိုပါ `Grapheme_Extend` ပိုင်ဆိုင်မှုရှိပါတယ်လျှင် `true` Returns ။
    ///
    /// `Grapheme_Extend` [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] တွင်ဖော်ပြထားပြီး [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] တွင်ဖော်ပြထားသည်။
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// အကယ်၍ `char` တွင်နံပါတ်များအတွက်အထွေထွေအမျိုးအစားတစ်ခုရှိပါက `true` သို့ပြန်သွားသည်။
    ///
    /// နံပါတ်များအတွက်အထွေထွေအမျိုးအစားများ (ဒdecimalမဂဏန်းများအတွက် `Nd`၊ အက္ခရာကဲ့သို့သောကိန်းဂဏန်းများအတွက် `Nl` နှင့်အခြားဂဏန်းသင်္ကေတများအတွက် `No`) ကို [Unicode Character Database][ucd] [`UnicodeData.txt`] တွင်သတ်မှတ်သည်။
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// ပြန်တစျခုသို့မဟုတ်ထိုထက်ပိုအတိုင်းဤ `char` ၏အသေးမြေပုံဖြစ်ထွန်းတစ်ခုကြားမှာ
    /// `char`s.
    ///
    /// အကယ်၍ ဤ `char` တွင်စာလုံးအသေးမြေပုံမပါရှိလျှင်၊
    ///
    /// အကယ်၍ ဤ `char` တွင် [Unicode Character Database][ucd] [`UnicodeData.txt`] မှပေးသောတစ်ခုနှင့်တစ်ခုအသေးစာလုံးငယ်မြေပုံပါရှိလျှင်၎င်းသည် ထပ်မံ၍ `char` ကိုထုတ်ပေးသည်။
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// ဒီ `char` အထူးထည့်သွင်းစဉ်းစား (ဥပမာမျိုးစုံ `char`s) လိုအပ်ပါတယ်လျှင်ကြားမှာ [`SpecialCasing.txt`] ကပေးတဲ့`char` (s) ကိုတွေ့ရကြ၏။
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// ဤသည်စစ်ဆင်ရေးစက်ချုပ်မပါဘဲတစ်ဦးခြွင်းချက်မရှိမြေပုံလုပ်ဆောင်တယ်။အဲဒီပြောင်းလဲခြင်းအခြေအနေတွင်နှင့်ဘာသာစကား၏လွတ်လပ်သောဖြစ်ပါသည်, ဖြစ်ပါတယ်။
    ///
    /// [Unicode Standard] တွင်အခန်း ၄ (Character Properties) သည်ယေဘူယျအားဖြင့် case မြေပုံကိုဆွေးနွေးထားပြီးအခန်း 3 (Conformance) သည်အမှုပြောင်းလဲခြင်းအတွက်ပုံမှန် algorithm ကိုဆွေးနွေးထားသည်။
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// ကြားဖြတ်အဖြစ်
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` ကိုတိုက်ရိုက်အသုံးပြုခြင်း
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// နှစ် ဦး စလုံးညီမျှသည်:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// `to_string` ကိုအသုံးပြုသည်။
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // တခါတလေရလဒ်တစ်ခုထက် ပို. ဇာတ်ကောင်ဖြစ်ပါသည်:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // စာလုံးအကြီးနှင့်အသေးနှစ်မျိုးလုံးမရှိသောအက္ခရာများသည်သူတို့ကိုယ်သူတို့အဖြစ်ပြောင်းလဲကြသည်။
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// ဒီ `char` ရဲ့စာလုံးကြီးမြေပုံကိုတစ်ခု (သို့) တစ်ခုထက်ပိုတဲ့အဖြေတစ်ခုပေးတဲ့ကြားမှာ
    /// `char`s.
    ///
    /// ဒီ `char` တစ်ကြီးမြေပုံရှိသည်ပါဘူးလျှင်, ကြားမှာတူညီတဲ့ `char` ဖြစ်ထွန်း။
    ///
    /// အကယ်၍ ဤ `char` တွင် [Unicode Character Database][ucd] [`UnicodeData.txt`] မှပေးသောတစ်ခုနှင့်တစ်ခုအကြီးစာလုံးကြီးမြေပုံပါရှိလျှင်၎င်းသည်ထပ်တူပြုသူသည် `char` ကိုထုတ်ပေးသည်။
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// ဒီ `char` အထူးထည့်သွင်းစဉ်းစား (ဥပမာမျိုးစုံ `char`s) လိုအပ်ပါတယ်လျှင်ကြားမှာ [`SpecialCasing.txt`] ကပေးတဲ့`char` (s) ကိုတွေ့ရကြ၏။
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// ဤသည်စစ်ဆင်ရေးစက်ချုပ်မပါဘဲတစ်ဦးခြွင်းချက်မရှိမြေပုံလုပ်ဆောင်တယ်။အဲဒီပြောင်းလဲခြင်းအခြေအနေတွင်နှင့်ဘာသာစကား၏လွတ်လပ်သောဖြစ်ပါသည်, ဖြစ်ပါတယ်။
    ///
    /// [Unicode Standard] တွင်အခန်း ၄ (Character Properties) သည်ယေဘူယျအားဖြင့် case မြေပုံကိုဆွေးနွေးထားပြီးအခန်း 3 (Conformance) သည်အမှုပြောင်းလဲခြင်းအတွက်ပုံမှန် algorithm ကိုဆွေးနွေးထားသည်။
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// ကြားဖြတ်အဖြစ်
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` ကိုတိုက်ရိုက်အသုံးပြုခြင်း
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// နှစ် ဦး စလုံးညီမျှသည်:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// `to_string` ကိုအသုံးပြုသည်။
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // တခါတလေရလဒ်တစ်ခုထက် ပို. ဇာတ်ကောင်ဖြစ်ပါသည်:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // စာလုံးအကြီးနှင့်အသေးနှစ်မျိုးလုံးမရှိသောအက္ခရာများသည်သူတို့ကိုယ်သူတို့အဖြစ်ပြောင်းလဲကြသည်။
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # ဒေသအပေါ်မှတ်ချက်
    ///
    /// တူရကီတွင်လက်တင်စကားဖြင့် 'i' နှင့်ညီမျှသည်နှစ်ခုအစားပုံစံငါးမျိုးရှိသည်။
    ///
    /// * 'Dotless': ငါ/i, တစ်ခါတစ်ရံတိကျမ်းစာ၌လာသည်လူတွေက
    /// * 'Dotted': /i
    ///
    /// သတိပြုပါမှာ 'i' စာလုံးအသေးသည်လက်တင်နှင့်တူညီသည်။ထို့ကြောင့်:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// ဤနေရာတွင် `upper_i` ၏တန်ဖိုးစာသား၏ဘာသာစကားကိုအပေါ်မှီခို: ငါတို့သည် `en-US` နေလျှင်, `"I"` ဖြစ်သင့်ပေမယ့်ကျနော်တို့ `tr_TR` နေလျှင်, `"İ"` ဖြစ်သင့်သည်။
    /// `to_uppercase()` အကောင့်သို့ဤ ယူ. , ဒါမပါဘူး:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// ဘာသာစကားများကိုဖြတ်ပြီးကိုင်။
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// စစ်ဆေးမှုများအတွက်တန်ဖိုး ASCII အကွာအဝေးအတွင်းပါလျှင်။
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// ယင်း၏ ASCII အထက်အမှုနှင့်ညီမျှအတွက်တန်ဖိုးများ၏မိတ္တူကိုမှန်ကန်စေသည်။
    ///
    /// ASCII အက္ခရာများ 'a' မှ 'z' အက္ခရာများကို 'A' သို့ 'Z' သို့ဆက်စပ်ထားသည်၊ သို့သော် ASCII မဟုတ်သောအက္ခရာများမှာမပြောင်းလဲပါ။
    ///
    /// တန်ဖိုးကို in-place, အဘို့, [`make_ascii_uppercase()`] ကိုအသုံးပြုပါ။
    ///
    /// ASCII စာလုံးအကြီးများကို ASCII မဟုတ်သောစာလုံးအကြီးများအတွက် [`to_uppercase()`] ကိုသာသုံးပါ။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// ယင်း၏ ASCII နိမ့်အမှုနှင့်ညီမျှအတွက်တန်ဖိုးများ၏မိတ္တူကိုမှန်ကန်စေသည်။
    ///
    /// ASCII အက္ခရာများ 'A' မှ 'Z' အက္ခရာများကို 'a' နှင့် 'z' သို့ဆက်စပ်ထားသည်။ သို့သော် ASCII မဟုတ်သောအက္ခရာများမှာမပြောင်းလဲပါ။
    ///
    /// In-ရာအရပျတနျဖိုးကို lowercase စေရန်, [`make_ascii_lowercase()`] ကိုအသုံးပြုပါ။
    ///
    /// Non-ASCII ဇာတ်ကောင်အပြင်စာလုံးအသေး ASCII ဇာတ်ကောင်စေရန်, [`to_lowercase()`] ကိုအသုံးပြုပါ။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// တန်ဖိုးနှစ်ခုသည် ASCII case-insensitive match ဖြစ်ကြောင်းစစ်ဆေးသည်။
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` နှင့်ညီမျှသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// ဤအမျိုးအစားကို ASCII စာလုံးအကြီးနှင့်ညီမျှသောနေရာတွင်ပြောင်းသည်။
    ///
    /// ASCII အက္ခရာများ 'a' မှ 'z' အက္ခရာများကို 'A' သို့ 'Z' သို့ဆက်စပ်ထားသည်၊ သို့သော် ASCII မဟုတ်သောအက္ခရာများမှာမပြောင်းလဲပါ။
    ///
    /// လက်ရှိတန်ဖိုးကိုပြုပြင်မွမ်းမံခြင်းမပြုဘဲ uppercased value အသစ်တစ်ခုကို return ပြန်ရန် [`to_ascii_uppercase()`] ကိုသုံးပါ။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// ဒီအမျိုးအစားကိုသူ့ရဲ့ ASCII စာလုံးအသေးညီမျှမှုရှိရာနေရာကိုပြောင်းသည်။
    ///
    /// ASCII အက္ခရာများ 'A' မှ 'Z' အက္ခရာများကို 'a' နှင့် 'z' သို့ဆက်စပ်ထားသည်။ သို့သော် ASCII မဟုတ်သောအက္ခရာများမှာမပြောင်းလဲပါ။
    ///
    /// လက်ရှိတဦးတည်းပြုပြင်မွမ်းမံခြင်းမရှိဘဲအသစ်တခုအသေးတန်ဖိုးကိုပြန်သွား [`to_ascii_lowercase()`] ကိုအသုံးပြုပါ။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// စစ်ဆေးမှုများတန်ဖိုးတစ်ခု ASCII အက်ခရာစဉျအကျင့်စာရိတ္တပါလျှင်:
    ///
    /// - ဦး + 0041 'A' ..=ဦး + 005A 'Z', ဒါမှမဟုတ်
    /// - U + သည် 0061 'a' ..=U + သည် 007A 'z' ။
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// စစ်ဆေးမှုများတန်ဖိုးကိုဇာတ်ကောင်ကြီးတစ်ခု ASCII လျှင်:
    /// U + သည် 0041 'A' ..=U + သည် 005A 'Z' ။
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// စစ်ဆေးမှုများတန်ဖိုးတစ်ခု ASCII စာလုံးအသေးဇာတ်ကောင်လျှင်:
    /// U + သည် 0061 'a' ..=U + သည် 007A 'z' ။
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// စစ်ဆေးမှုများတန်ဖိုးတစ်ခု ASCII အက္ခရာနံပါတ်ပါတဲ့ဇာတ်ကောင်ပါလျှင်:
    ///
    /// - ဦး + 0041 'A' ..=ဦး + 005A 'Z', ဒါမှမဟုတ်
    /// - ဦး + 0061 'a' ..=ဦး + 007A 'z', ဒါမှမဟုတ်
    /// - ဦး + 0030 '0' ..=ဦး + 0039 '9' ။
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// စစ်ဆေးမှုများတန်ဖိုးတစ်ခု ASCII ဒဿမဂဏန်းလျှင်:
    /// ဦး + 0030 '0' ..=ဦး + 0039 '9' ။
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// စစ်ဆေးမှုများတန်ဖိုးတစ်ခု ASCII hexadecimal ဂဏန်းလျှင်:
    ///
    /// - ဦး + 0030 '0' ..=ဦး + 0039 '9'၊ ဒါမှမဟုတ်
    /// - + 0041 'A' ..=U + သည် 0046 'F' ဦး, ဒါမှမဟုတ်
    /// - U + သည် 0061 'a' ..=U + သည် 0066 'f' ။
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// စစ်ဆေးမှုများတန်ဖိုးတစ်ခု ASCII ပုဒ်ဖြတ်ပုဒ်ရပ်ဇာတ်ကောင်လျှင်:
    ///
    /// - ဦး + 0021 ..=ဦး + 002F `! " # $ % & ' ( ) * + , - . /`, ဒါမှမဟုတ်
    /// - ဦး + 003A ..=ဦး + 0040 `: ; < = > ? @`, ဒါမှမဟုတ်
    /// - ဦး + 005B ..=ဦး + 0060 ``[\] ^ _``, ဒါမှမဟုတ်
    /// - U + သည် 007B ..=U + သည် 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// စစ်ဆေးမှုများတန်ဖိုးတစ်ခု ASCII ဂရပ်ဖစ်ဇာတ်ကောင်လျှင်:
    /// U + သည် 0021 '!' ..=U + သည် 007E '~' ။
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// စစ်ဆေးမှုများတန်ဖိုးကိုကြားနေရာလွတ်ဇာတ်ကောင်တစ်ဦး ASCII လျှင်:
    /// U + 0020 SPACE, U + 0009 IZIZONIZIZTT, U T T T TAB TAB TABABABABAB U U U U U U U U U U U U U U U U + U + 000C LINE FEED များ၊ U + 000C FORMEED FEED၊ သို့မဟုတ် U + 000D သယ်ယူပို့ဆောင်ရေးပြန်လာခြင်း။
    ///
    /// Rust အဆိုပါ WhatWG Infra နျ Standard ရဲ့ [definition of ASCII whitespace][infra-aw] အသုံးပြုသည်။ကျယ်ပြန့်စွာအသုံးပြုရန်အတွက်အခြားအဓိပ္ပာယ်များစွာရှိသည်။
    /// ဥပမာ [the POSIX locale][pct] တွင် U + 000B VERTICAL TAB အပြင်အထက်ပါအက္ခရာများပါ ၀ င်သော်လည်းအသေးစိတ်အချက်အလက်များမှ [Bourne shell ရှိ "field splitting" အတွက်မူရင်းစည်းမျဉ်း][bfs]* ** ** SPACE, HORIZONTAL TAB နှင့်ထည့်သွင်းစဉ်းစားထားသည်။ ကြားနေရာလွတ်အဖြစ် LINE FEED ။
    ///
    ///
    /// အကယ်၍ သင်သည်ရှိပြီးသားဖိုင်အမျိုးအစားကိုလုပ်ဆောင်မည့်ပရိုဂရမ်တစ်ခုကိုရေးနေလျှင်ဤ function ကိုအသုံးမပြုခင်ထိုပုံစံ၏ whitespace ၏အဓိပ္ပာယ်ကိုစစ်ဆေးပါ။
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// ဒီတန်ဖိုးဟာ ASCII control character ဟုတ်မဟုတ်စစ်ဆေးသည်။
    /// ဦး + 0000 NUL ..=ဦး + 001F UNIT SEPARATOR, ဒါမှမဟုတ် ဦး + 007F ဖျက်ပစ်ခြင်း။
    /// အများဆုံး ASCII ကြားနေရာလွတ်ဇာတ်ကောင်ကိုထိန်းချုပ်ဇာတ်ကောင်သော်လည်း, SPACE မဟုတ်ကြောင်းမှတ်ချက်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// ပေးထားသော byte ကြားခံထဲသို့ UTF-8 အဖြစ် raw u32 တန်ဖိုးကို encode လုပ်ပြီး encoded character ပါ ၀ င်သည့် buffer ၏ subslice ကို return လုပ်သည်။
///
///
/// `char::encode_utf8` မတူဘဲ, ဒီနည်းလမ်းကိုကိုလည်းအငှားအကွာအဝေးအတွင်း codepoints ကိုင်တွယ်။
/// (ထိုအငှားအကွာအဝေးအတွင်း `char` Creating UB ဖြစ်ပါသည်။) အဆိုပါရလဒ်တရားဝင် [generalized UTF-8] ပေမယ့်မမှန်ကန်ဘူး UTF-8 ဖြစ်ပါတယ်။
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// ကြားခံအလုံအလောက်မကြီးဘူးဆိုရင် Panics ။
/// အရှည်လေးတစ်ကြားခံကိုမဆို `char` ဝှက်ဖို့ကြီးမားသောလုံလောက်ပါတယ်။
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// ပေးထားသော `u16` ကြားခံထဲသို့ UTF-16 အဖြစ်ကုန်ကြမ်း u32 တန်ဖိုးတစ်ခုကိုထည့်သွင်းပြီး၎င်းသည် encoded character ပါဝင်သော buffer ၏ subslice ကိုပြန်လည်ပေးသည်။
///
///
/// `char::encode_utf16` မတူဘဲ, ဒီနည်းလမ်းကိုကိုလည်းအငှားအကွာအဝေးအတွင်း codepoints ကိုင်တွယ်။
/// (`char` ကိုအငှားစားအကွာအဝေးတွင်ဖန်တီးခြင်းသည် UB ဖြစ်သည်။)
///
/// # Panics
///
/// ကြားခံအလုံအလောက်မကြီးဘူးဆိုရင် Panics ။
/// အရှည် ၂ ၏ကြားခံတစ်ခုသည်မည်သည့် `char` ကိုမဆို encode လုပ်ရန်ကြီးမားသည်။
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // လုံခြုံမှု-လက်တစ်ဖက်စီက ၀ င်ဖို့အတွက်လုံလောက်တဲ့ပမာဏရှိမရှိစစ်ဆေးပါတယ်
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // အဆိုပါ, BMP မှတဆင့်ကျရောက်
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // နောက်ဆက်တွဲလေယာဉ်များသည်အငှားအဖြစ်သို့ပြောင်းလဲသွားသည်။
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}