#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! (FFI) ခညျြနှောငျ interface ကိုနိုင်ငံခြား function ကိုဆက်စပ်သောအသုံးအဆောင်များ။

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// တစ်ဦး [pointer] အဖြစ်အသုံးပြုသည့်အခါ C ရဲ့ `void` type ကိုညီမျှ။
///
/// အနှစ်သာရမှာတော့ `*const c_void` C ရဲ့ `const void*` ညီမျှသည်နှင့် `*mut c_void` C ရဲ့ `void*` မှညီမျှသည်။
/// ဒီ * * Rust ရဲ့ `()` အမျိုးအစားဖြစ်သော C ရဲ့ `void` ပြန်လာအမျိုးအစားကဲ့သို့တူညီသောမဟုတ်ပါဘူးဟုဆိုလေ၏။
///
/// XFX တည်ငြိမ်သည်အထိ FFI တွင်မပါမဖြစ်အမျိုးအစားများကိုညွန်ပြရန်ပုံစံပြုရန်, အချည်းနှီးသော byte ခင်းကျင်းပတ်ပတ်လည်တွင် newtype wrapper ကိုအသုံးပြုရန်အကြံပြုသည်။
///
/// အသေးစိတ် [Nomicon] ကိုကြည့်ပါ။
///
/// Rust compiler အဟောင်းကို 1.1.0 အထိထောက်ပံ့ချင်ရင် `std::os::raw::c_void` ကိုသုံးနိုင်သည်။
/// Rust 1.30.0 ပြီးနောက်, ဤအဓိပ်ပါယျအားဖွငျ့ Re-တင်ပို့ခဲ့ပါတယ်။
/// ပိုမိုသိရှိလိုပါက [RFC 2521] ကိုဖတ်ပါ။
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB, LLVM ဟာပျက်ပြယ် pointer type ကိုအသိအမှတ်ပြုရန်နှင့် malloc() တူသော extension ကိုလုပ်ဆောင်ချက်များကိုအားဖြင့်ကျနော်တို့ LLVM bitcode အတွက် * က i8 အဖြစ်ကိုယ်စားပြုရှိသည်ဖို့လိုအပ်ပါတယ်။
// ဒီနေရာမှာအသုံးပြုတဲ့ enum ဒီသေချာနှင့်တားဆီးမှသာပုဂ္ဂလိကမျိုးကွဲရှိခြင်းအားဖြင့် "raw" အမျိုးအစားအလွဲသုံးစား။
// အဆိုပါ compiler မဟုတ်ရင်အဆိုပါ repr attribute ကိုအကြောင်းကိုညညျးညူသောကြောင့်, ငါတို့သည်နှစ်ခုမျိုးကွဲလိုအပ်ပါတယ်နှင့်မဟုတ်ရင်အဆိုပါ enum uninhabited မည်ဖြစ်ကြောင်းနှင့်အနည်းဆုံးထိုကဲ့သို့သောထောက်ပြ dereferencing UB ပါလိမ့်မယ်အဖြစ်ကျနော်တို့အနည်းဆုံးတဦးတည်းမူကွဲလိုအပ်ပါတယ်။
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// `va_list` ၏အခြေခံအကောင်အထည်ဖော်မှု။
// နာမတော်ကိုအမှီ ပြု. ယခု `VaListImpl` သုံးပြီး WIP ဖြစ်ပါတယ်။
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // `'f` ကျော်လျော့ပါးသွားမည်ဖြစ်သလို, ဒါကြောင့်တစ်ဦးချင်းစီ `VaListImpl<'f>` အရာဝတ္ထုတစ်ခုကိုအတွက်သတ်မှတ်ထားသောရဲ့ function ကို၏ဒေသတွင်းမှချည်ထားသောဖြစ်ပါတယ်
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 တစ်ဦး `va_list` ၏ ABI အကောင်အထည်ဖော်မှု။
/// အသေးစိတ်အတွက် [AArch64 Procedure Call Standard] ကိုကြည့်ပါ။
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC တစ်ဦး `va_list` ၏ ABI အကောင်အထည်ဖော်မှု။
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 တစ်ဦး `va_list` ၏ ABI အကောင်အထည်ဖော်မှု။
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// တစ်ဦး `va_list` များအတွက်တစ်ဦးက wrapper
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// `VaListImpl` ကို C's `va_list` နှင့် binary-သဟဇာတဖြစ်သော `VaList` တစ်ခုအဖြစ်ပြောင်းပါ။
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// `VaListImpl` ကို C's `va_list` နှင့် binary-သဟဇာတဖြစ်သော `VaList` တစ်ခုအဖြစ်ပြောင်းပါ။
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// VaArgSafe trait ကိုအများပြည်သူဆက်သွယ်မှုမျက်နှာပြင်များတွင်အသုံးပြုရန်လိုအပ်သည်၊ သို့သော်ဤ module အပြင်ဘက်တွင်အသုံးပြုရန် trait ကိုခွင့်မပြုရ။
// အသုံးပြုသူများသည် (အားဖြင့်သစ်တစ်ခုအမျိုးအစားပေါ်အသုံးပြုနိုင်ဖို့အတွက် va_arg အခ်ါခွင့်ပြု) အသစ်တခုအမျိုးအစားများအတွက် trait အကောင်အထည်ဖေါ်ခွင့်ပြုဖွယ်ရှိ undefined အပြုအမူကိုဖြစ်ပေါ်စေရန်ဖြစ်ပါသည်။
//
// FIXME(dlrobertson): အများပြည်သူ interface ကိုအတွက် VaArgSafe trait ကိုသုံးပါပေမယ့်လည်းသူကတခြားနေရာကိုအသုံးပြုရနိုင်မှာမဟုတ်ဘူးသေချာစေရန်အလို့ငှာခုနှစ်, trait ပုဂ္ဂလိက module တစ်ခုအတွင်းအများပြည်သူဖြစ်ရန်လိုအပ်ပါသည်။
// RFC 2145 ပြီးတာနဲ့ဒီတိုးတက်အောင်သို့ကြည့်အကောင်အထည်ဖော်ခဲ့တာဖြစ်ပါတယ်။
//
//
//
//
mod sealed_trait {
    /// [super::VaListImpl::arg] နှင့်အတူအသုံးပြုရရန်အခွင့်ပြုခဲ့အမျိုးအစားများကိုခွင့်ပြုထားသည့် Trait ။
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// လာမယ့် arg မှကြိုတင်ငွေ။
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `va_arg` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
        unsafe { va_arg(self) }
    }

    /// လက်ရှိတည်နေရာမှာမိတ္တူ `va_list` ။
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // လုံခြုံမှု: အခေါ်ဆိုမှု `va_end` များအတွက်လုံခြုံမှုစာချုပ်ထောက်ရမည်ဖြစ်သည်။
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // လုံခြုံမှု: ငါတို့သည်ထိုသို့နသည်ထို `MaybeUninit` စာရေးနှင့် `assume_init` ဥပဒေရေးရာဖြစ်ပါသည်
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: ဒီ `va_end` မခေါ်သင့်တယ်, ဒါပေမယ့်ရန်မသန့်ရှင်းတဲ့လမ်းရှိတယ်
        // `drop` သည်အမြဲတမ်း ၄ င်း၏ခေါ်ဆိုသူသို့အစဉ်လိုက်မျဉ်းကြောင်းအာမခံသည်၊ ထို့ကြောင့် `va_end` ကိုသက်ဆိုင်ရာ `va_copy` ကဲ့သို့ function တစ်ခုတည်းမှတိုက်ရိုက်ခေါ်ဆိုလိမ့်မည်။
        // `man va_end` LLVM သည် C semantics ကိုအခြေခံသည်။ ထို့ကြောင့် `va_end` ကို `va_copy` ကဲ့သို့တူညီသော function မှအမြဲတမ်းခေါ်ဆိုကြောင်းသေချာစေရန်လိုအပ်သည်။
        //
        // အသေးစိတ်အတွက် see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // `va_end` အားလုံးလက်ရှိ LLVM ပစ်မှတ်အပေါ်တစ်ဦးမျှမ-op ဖြစ်ပါတယ်ကတည်းကဤသည်ကိုယခုအဘို့အအလုပ်လုပ်ပါတယ်။
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// `va_start` သို့မဟုတ် `va_copy` နှင့်အတူစတင်ခြင်းပြီးနောက် arglist `ap` ကိုဖွိုဖကျြ။
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// arglist `src` ၏လက်ရှိတည်နေရာကို arglist `dst` သို့ကူးပါ။
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// ဝန်အဆိုပါ `va_list` `ap` ကနေအမျိုးအစား `T` တစ်ဦးငြင်းခုံခြင်းနှင့် `ap` ထောက်ပြသည်ဟာငြင်းခုံတိုး။
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}