use crate::iter::FromIterator;

/// တစ်ခုကြားမှာတစ်ခုကြားမှာကနေအားလုံးယူနစ်ပစ္စည်းများပြိုကျသည်။
///
/// ပိုမိုမြင့်မားသောအဆင့် abstraction နှင့်အတူပေါင်းစပ်သောအခါဤသင်သာအမှားများကိုဂရုစိုက်တဲ့ `Result<(), E>` မှစုဆောင်းကဲ့သို့ပိုမိုအသုံးဝင်သည်:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}