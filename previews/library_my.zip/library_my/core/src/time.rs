#![stable(feature = "duration_core", since = "1.25.0")]

//! ယာယီအရေအတွက်။
//!
//! Example:
//!
//! ```
//! use std::time::Duration;
//!
//! let five_seconds = Duration::new(5, 0);
//! // နှစ် ဦး စလုံးကြေညာချက်များညီမျှကြသည်
//! assert_eq!(Duration::new(5, 0), Duration::from_secs(5));
//! ```

use crate::fmt;
use crate::iter::Sum;
use crate::ops::{Add, AddAssign, Div, DivAssign, Mul, MulAssign, Sub, SubAssign};

const NANOS_PER_SEC: u32 = 1_000_000_000;
const NANOS_PER_MILLI: u32 = 1_000_000;
const NANOS_PER_MICRO: u32 = 1_000;
const MILLIS_PER_SEC: u64 = 1_000;
const MICROS_PER_SEC: u64 = 1_000_000;

/// ပုံမှန်အားဖြင့် system timeouts အတွက်အသုံးပြုသောအချိန်အတိုင်းအတာတစ်ခုကိုကိုယ်စားပြုရန် `Duration` type ။
///
/// တစ်ခုချင်းစီကို `Duration` ကိုစက္ကန့်ပိုင်းတစ်ခုလုံးနှင့် nanoseconds တွင်ပုံဖော်ထားသည့်အပိုင်းအစများဖြင့်ဖွဲ့စည်းထားသည်။
/// နောက်ခံစနစ် nanosecond-level တိကျမှုကိုမထောက်ခံပါက system timeout ကိုပေါင်းစပ်ထားသော API များသည်ပုံမှန်အားဖြင့် nanoseconds အရေအတွက်ကိုမြှင့်တင်ပေးလိမ့်မည်။
///
/// [`Duration`] သည်များစွာသောဘုံ traits, [`Add`], [`Sub`] နှင့်အခြား [`ops`] traits အပါအဝင်များစွာသောဘုံ traits ကိုအကောင်အထည်ဖော်သည်။[`Default`] ကိုသုညအရှည် `Duration` ကိုပြန်ပေးတယ်။
///
/// [`ops`]: crate::ops
///
/// # Examples
///
/// ```
/// use std::time::Duration;
///
/// let five_seconds = Duration::new(5, 0);
/// let five_seconds_and_five_nanos = five_seconds + Duration::new(0, 5);
///
/// assert_eq!(five_seconds_and_five_nanos.as_secs(), 5);
/// assert_eq!(five_seconds_and_five_nanos.subsec_nanos(), 5);
///
/// let ten_millis = Duration::from_millis(10);
/// ```
///
/// # `Duration` တန်ဖိုးများကို format လုပ်ခြင်း
///
/// `Duration` လူ့ဖတ်နိုင်တဲ့အဘို့အချိန် format နဲ့ span ဖို့နည်းလမ်းတွေအမျိုးမျိုးရှိပါတယ်အဖြစ်ရည်ရွယ်ချက်ရှိရှိတစ် `Display` impl မရှိပါ။
/// `Duration` တန်ဖိုးကိုအပြည့်အဝတိကျစွာပြသတဲ့ `Debug` impl ပေးပါသည်။
///
/// အဆိုပါ `Debug` output ကို microseconds များအတွက် non-ASCII "µs" နောက်ဆက်အသုံးပြုသည်။
/// သင့်ရဲ့ program ကို output ကိုအပြည့်အဝယူနီကုဒ်လိုက်ဖက်တဲ့အပေါ်အားကိုးလို့မရပါဘူးကြောင်းအခင်းအကျင်းအတွက်ထင်ရှားစေခြင်းငှါလျှင်, သင် `Duration` ကိုယ့်ကိုကိုယ် objects သို့မဟုတ်အဲဒီလိုလုပ်ဖို့တစ် crate ကိုအသုံးပြုဖို့ကို format လိုပေမည်။
///
///
///
///
///
///
///
#[stable(feature = "duration", since = "1.3.0")]
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Default)]
pub struct Duration {
    secs: u64,
    nanos: u32, // အမြဲတမ်း 0 <=nanos <NANOS_PER_SEC
}

impl Duration {
    /// တစ်စက္ကန့်များ၏ကြာချိန်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::SECOND, Duration::from_secs(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const SECOND: Duration = Duration::from_secs(1);

    /// တစ်မီလီစက္ကန်ကြာချိန်
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MILLISECOND, Duration::from_millis(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MILLISECOND: Duration = Duration::from_millis(1);

    /// တဦးတည်း microsecond ၏ကြာချိန်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MICROSECOND, Duration::from_micros(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MICROSECOND: Duration = Duration::from_micros(1);

    /// တ ဦး တည်း nanosecond ၏ကြာချိန်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::NANOSECOND, Duration::from_nanos(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const NANOSECOND: Duration = Duration::from_nanos(1);

    /// သုညအချိန်၏ကြာချိန်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// let duration = Duration::ZERO;
    /// assert!(duration.is_zero());
    /// assert_eq!(duration.as_nanos(), 0);
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    pub const ZERO: Duration = Duration::from_nanos(0);

    /// အများဆုံးကြာချိန်
    ///
    /// ၎င်းသည်အကြမ်းအားဖြင့်နှစ်ပေါင်း ၅၈၄,၉၄၂,၄၁၇၅၅ နှစ်နှင့်ညီမျှသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MAX, Duration::new(u64::MAX, 1_000_000_000 - 1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MAX: Duration = Duration::new(u64::MAX, NANOS_PER_SEC - 1);

    /// တစ်ဖွဲ့လုံးစက္ကန့်ရဲ့သတ်မှတ်ထားတဲ့အရေအတွက်ကိုကနေအသစ်အ `Duration` နှင့်အပိုဆောင်း nanoseconds ဖန်တီးပေးပါတယ်။
    ///
    /// အကယ်၍ nanoseconds အရေအတွက်သည် ၁ ဘီလီယံထက်ပိုမိုလျှင် (စက္ကန့်အတွင်း nanoseconds အရေအတွက်) သည်၎င်းသည်ရရှိသောစက္ကန့်အတွင်းသို့ကူးပြောင်းလိမ့်မည်။
    ///
    ///
    /// # Panics
    ///
    /// အကယ်၍ nanoseconds များမှသယ်ဆောင်လာသောစက္ကန့်ကောင်တာသည်လျှံထွက်လျှင်ဤလုပ်ငန်းခွင်သည် panic ဖြစ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let five_seconds = Duration::new(5, 0);
    /// ```
    ///
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn new(secs: u64, nanos: u32) -> Duration {
        let secs = match secs.checked_add((nanos / NANOS_PER_SEC) as u64) {
            Some(secs) => secs,
            None => panic!("overflow in Duration::new"),
        };
        let nanos = nanos % NANOS_PER_SEC;
        Duration { secs, nanos }
    }

    /// သတ်မှတ်ထားသောစက္ကန့်အနည်းငယ်အတွင်း `Duration` အသစ်တစ်ခုကိုပြုလုပ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_secs(5);
    ///
    /// assert_eq!(5, duration.as_secs());
    /// assert_eq!(0, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_secs(secs: u64) -> Duration {
        Duration { secs, nanos: 0 }
    }

    /// မီလီစက္ကန်၏သတ်မှတ်ထားတဲ့အရေအတွက်ကိုကနေအသစ်တခု `Duration` ဖန်တီးပေးပါတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(2569);
    ///
    /// assert_eq!(2, duration.as_secs());
    /// assert_eq!(569_000_000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_millis(millis: u64) -> Duration {
        Duration {
            secs: millis / MILLIS_PER_SEC,
            nanos: ((millis % MILLIS_PER_SEC) as u32) * NANOS_PER_MILLI,
        }
    }

    /// သတ်မှတ်ထားသော microseconds အရေအတွက်မှ `Duration` အသစ်တစ်ခုကိုဖန်တီးသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_000_002);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(2000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_from_micros", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_micros(micros: u64) -> Duration {
        Duration {
            secs: micros / MICROS_PER_SEC,
            nanos: ((micros % MICROS_PER_SEC) as u32) * NANOS_PER_MICRO,
        }
    }

    /// သတ်မှတ်ထားသော nanoseconds အရေအတွက်မှ `Duration` အသစ်တစ်ခုကိုဖန်တီးသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_nanos(1_000_000_123);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(123, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_nanos(nanos: u64) -> Duration {
        Duration {
            secs: nanos / (NANOS_PER_SEC as u64),
            nanos: (nanos % (NANOS_PER_SEC as u64)) as u32,
        }
    }

    /// ဒီ `Duration` မျှအချိန်အထိချဲ့လျှင်စစ်မှန်တဲ့ Returns ။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert!(Duration::ZERO.is_zero());
    /// assert!(Duration::new(0, 0).is_zero());
    /// assert!(Duration::from_nanos(0).is_zero());
    /// assert!(Duration::from_secs(0).is_zero());
    ///
    /// assert!(!Duration::new(1, 1).is_zero());
    /// assert!(!Duration::from_nanos(1).is_zero());
    /// assert!(!Duration::from_secs(1).is_zero());
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    #[inline]
    pub const fn is_zero(&self) -> bool {
        self.secs == 0 && self.nanos == 0
    }

    /// ဒီ `Duration` တွင်ပါ ၀ င်သော _whole_ စက္ကန့်အရေအတွက်ကိုပြန်ပို့သည်။
    ///
    /// အဆိုပါပြန်လာသောတန်ဖိုးကို [`subsec_nanos`] သုံးပြီးရယူနိုင်သည့်ကြာချိန်၏ဒဿမကိန်း (nanosecond) အစိတ်အပိုင်းတစ်ခုမပါဝင်ပါ။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_secs(), 5);
    /// ```
    ///
    /// `Duration` ကကိုယ်စားပြုသောစက္ကန့်အရေအတွက်ကိုဆုံးဖြတ်ရန် X0 `as_secs` နှင့်ပေါင်းပြီး [`subsec_nanos`]
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    ///
    /// assert_eq!(5.730023852,
    ///            duration.as_secs() as f64
    ///            + duration.subsec_nanos() as f64 * 1e-9);
    /// ```
    ///
    /// [`subsec_nanos`]: Duration::subsec_nanos
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn as_secs(&self) -> u64 {
        self.secs
    }

    /// ဒီ `Duration` ၏ဒဿမကိန်းအစိတ်အပိုင်းတစ်ခုတပြင်လုံးကိုမီလီစက္ကန်အတွက် Returns ။
    ///
    /// milliseconds များဖြင့်ကိုယ်စားပြုသောဤနည်းလမ်းသည် ** **** သည်ကြာချိန်၏အရှည်ကိုမပေးနိုင်ပါ။
    /// ပြန်လာသောကိန်းဂဏန်းသည်စက္ကန့်၏အစိတ်အပိုင်းကိုကိုယ်စားပြုသည် (ဆိုလိုသည်မှာတစ်ထောင်မပြည့်သော) ။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5432);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_millis(), 432);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_millis(&self) -> u32 {
        self.nanos / NANOS_PER_MILLI
    }

    /// microseconds တစ်ခုလုံး၌ဤ `Duration` ၏အပိုင်းအစအစိတ်အပိုင်းကိုပြန်သွားသည်။
    ///
    /// ဤနည်းလမ်းသည်မိုက်ကရိုစက္ကန့်များကိုကိုယ်စားပြုသောအခါကြာချိန်၏အရှည်ကိုပြန်မပေးပါ။
    /// အဆိုပါပြန်လာသောအရေအတွက်ကအမြဲ (ဆိုလိုသည်မှာ, ကထက်နည်းတစ်သန်းဖြစ်ပါတယ်) တစ်စက္ကန့်တစ်ဒဿမကိန်းသောအဘို့ကိုကိုယ်စားပြုတယ်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_234_567);
    /// assert_eq!(duration.as_secs(), 1);
    /// assert_eq!(duration.subsec_micros(), 234_567);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_micros(&self) -> u32 {
        self.nanos / NANOS_PER_MICRO
    }

    /// nanoseconds ၌ဤ `Duration` ၏အပိုင်းအစအစိတ်အပိုင်းကိုပြန်သွားသည်။
    ///
    /// nanoseconds များကကိုယ်စားပြုသောအခါဤနည်းလမ်းသည် ** ** ကြာချိန်၏အရှည်ကိုမပေးနိုင်ပါ။
    /// ပြန်လာသောကိန်းဂဏန်းသည်စက္ကန့်၏အစိတ်အပိုင်းတစ်ခုမျှသာ (ဆိုလိုသည်မှာတစ်ဘီလီယံအောက်) ဖြစ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5010);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_nanos(), 10_000_000);
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn subsec_nanos(&self) -> u32 {
        self.nanos
    }

    /// ဒီ `Duration` အားဖြင့်ပါရှိသောတပြင်လုံးကိုမီလီစက္ကန်၏စုစုပေါင်းအရေအတွက်ကပြန်ပို့ပေးသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_millis(), 5730);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_millis(&self) -> u128 {
        self.secs as u128 * MILLIS_PER_SEC as u128 + (self.nanos / NANOS_PER_MILLI) as u128
    }

    /// ဤ `Duration` တွင်ပါရှိသော microseconds စုစုပေါင်းကိုပြန်ပို့သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_micros(), 5730023);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_micros(&self) -> u128 {
        self.secs as u128 * MICROS_PER_SEC as u128 + (self.nanos / NANOS_PER_MICRO) as u128
    }

    /// ဒီ `Duration` မှာပါတဲ့ nanoseconds စုစုပေါင်းကို return ပြန်ပေးတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_nanos(), 5730023852);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_nanos(&self) -> u128 {
        self.secs as u128 * NANOS_PER_SEC as u128 + self.nanos as u128
    }

    /// `Duration` ထို့အပြင် Checked ။
    /// လျှံဖြစ်ပွားခဲ့သည်လျှင် [`None`] ပြန်လာ, `self + other` တွက်ချက်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).checked_add(Duration::new(0, 1)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(1, 0).checked_add(Duration::new(u64::MAX, 0)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_add(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_add(rhs.secs) {
            let mut nanos = self.nanos + rhs.nanos;
            if nanos >= NANOS_PER_SEC {
                nanos -= NANOS_PER_SEC;
                if let Some(new_secs) = secs.checked_add(1) {
                    secs = new_secs;
                } else {
                    return None;
                }
            }
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// Saturation `Duration` အပြင်။
    /// ကွန်ပျူတာက `self + other`, လျတ်ဖြစ်ပွားခဲ့သည်လျှင် [`Duration::MAX`] ပြန်လာ။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).saturating_add(Duration::new(0, 1)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(1, 0).saturating_add(Duration::new(u64::MAX, 0)), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_add(self, rhs: Duration) -> Duration {
        match self.checked_add(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// `Duration` အနုတ် Checked ။
    /// ရလဒ်အနုတ်ဖြစ်လျှင်သို့မဟုတ်လျှံဖြစ်ပွားခဲ့သည်လျှင် [`None`] ပြန်လာ `self - other` တွက်ချက်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).checked_sub(Duration::new(0, 0)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(0, 0).checked_sub(Duration::new(0, 1)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_sub(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_sub(rhs.secs) {
            let nanos = if self.nanos >= rhs.nanos {
                self.nanos - rhs.nanos
            } else {
                if let Some(sub_secs) = secs.checked_sub(1) {
                    secs = sub_secs;
                    self.nanos + NANOS_PER_SEC - rhs.nanos
                } else {
                    return None;
                }
            };
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// Saturation `Duration` အနုတ်။
    /// ရလဒ်အနုတ်ဖြစ်လျှင်သို့မဟုတ်လျှံဖြစ်ပွားခဲ့သည်လျှင် [`Duration::ZERO`] ပြန်လာ `self - other` တွက်ချက်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).saturating_sub(Duration::new(0, 0)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(0, 0).saturating_sub(Duration::new(0, 1)), Duration::ZERO);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_sub(self, rhs: Duration) -> Duration {
        match self.checked_sub(rhs) {
            Some(res) => res,
            None => Duration::ZERO,
        }
    }

    /// `Duration` မြှောက် Checked ။
    /// လျှံဖြစ်ပွားခဲ့သည်လျှင် [`None`] ပြန်လာ, `self * other` တွက်ချက်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).checked_mul(2), Some(Duration::new(1, 2)));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).checked_mul(2), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_mul(self, rhs: u32) -> Option<Duration> {
        // ဒါကြောင့်လမ်းကြောင်းလျတ်မပြုနိုင်သောကွောငျ့များပြား, u64 အဖြစ် nanoseconds ။
        let total_nanos = self.nanos as u64 * rhs as u64;
        let extra_secs = total_nanos / (NANOS_PER_SEC as u64);
        let nanos = (total_nanos % (NANOS_PER_SEC as u64)) as u32;
        if let Some(s) = self.secs.checked_mul(rhs as u64) {
            if let Some(secs) = s.checked_add(extra_secs) {
                debug_assert!(nanos < NANOS_PER_SEC);
                return Some(Duration { secs, nanos });
            }
        }
        None
    }

    /// Saturation `Duration` မြှောက်ခြင်း။
    /// ကွန်ပျူတာက `self * other`, လျတ်ဖြစ်ပွားခဲ့သည်လျှင် [`Duration::MAX`] ပြန်လာ။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).saturating_mul(2), Duration::new(1, 2));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).saturating_mul(2), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_mul(self, rhs: u32) -> Duration {
        match self.checked_mul(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// `Duration` ဌာနခွဲ Checked ။
    /// `other == 0` လျှင် [`None`] ပြန်လာ, `self / other` တွက်ချက်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(2, 0).checked_div(2), Some(Duration::new(1, 0)));
    /// assert_eq!(Duration::new(1, 0).checked_div(2), Some(Duration::new(0, 500_000_000)));
    /// assert_eq!(Duration::new(2, 0).checked_div(0), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_div(self, rhs: u32) -> Option<Duration> {
        if rhs != 0 {
            let secs = self.secs / (rhs as u64);
            let carry = self.secs - secs * (rhs as u64);
            let extra_nanos = carry * (NANOS_PER_SEC as u64) / (rhs as u64);
            let nanos = self.nanos / rhs + (extra_nanos as u32);
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// ဤ `Duration` တွင်ပါသောစက္ကန့်အရေအတွက်ကို `f64` အဖြစ်ပြန်ပို့သည်။
    /// ပြန်လာသောတန်ဖိုးသည်အချိန်အပိုင်းအခြားခွဲ (nanosecond) ပါဝင်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f64(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f64(&self) -> f64 {
        (self.secs as f64) + (self.nanos as f64) / (NANOS_PER_SEC as f64)
    }

    /// ဤ `Duration` တွင်ပါသောစက္ကန့်အရေအတွက်ကို `f32` အဖြစ်ပြန်ပို့သည်။
    /// ပြန်လာသောတန်ဖိုးသည်အချိန်အပိုင်းအခြားခွဲ (nanosecond) ပါဝင်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f32(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f32(&self) -> f32 {
        (self.secs as f32) + (self.nanos as f32) / (NANOS_PER_SEC as f32)
    }

    /// စက္ကန့်ရဲ့သတ်မှတ်ထားတဲ့အရေအတွက်ကိုကနေအသစ်တခု `Duration` `f64` အဖြစ်ကိုယ်စားပြုဖန်တီးပေးပါတယ်။
    ///
    /// # Panics
    /// `secs` သည်အကန့်အသတ်မရှိ၊ အနှုတ် ရှိ၍ သို့မဟုတ် `Duration` ထပ်လျှံပါကတည်ဆောက်သူသည် panic ဖြစ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f64(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f64(secs: f64) -> Duration {
        const MAX_NANOS_F64: f64 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f64;
        let nanos = secs * (NANOS_PER_SEC as f64);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F64 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// `f32` အဖြစ်ကိုယ်စားပြုသောသတ်မှတ်ထားသောစက္ကန့်အနည်းငယ်မှ `Duration` အသစ်တစ်ခုကိုဖန်တီးသည်။
    ///
    /// # Panics
    /// `secs` သည်အကန့်အသတ်မရှိ၊ အနှုတ် ရှိ၍ သို့မဟုတ် `Duration` ထပ်လျှံပါကတည်ဆောက်သူသည် panic ဖြစ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f32(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f32(secs: f32) -> Duration {
        const MAX_NANOS_F32: f32 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f32;
        let nanos = secs * (NANOS_PER_SEC as f32);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F32 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// `f64` အားဖြင့် `Duration` ကိုမြှောက်ပါ။
    /// # Panics
    /// ရလဒ်သည်အကန့်အသတ်မရှိ၊ အနှုတ် ရှိ၍ သို့မဟုတ် `Duration` ထက်ပိုလျှံပါကဤနည်းလမ်းသည် panic ဖြစ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.mul_f64(3.14), Duration::new(8, 478_000_000));
    /// assert_eq!(dur.mul_f64(3.14e5), Duration::new(847_800, 0));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(rhs * self.as_secs_f64())
    }

    /// `f32` အားဖြင့် `Duration` ကိုမြှောက်ပါ။
    /// # Panics
    /// ရလဒ်သည်အကန့်အသတ်မရှိ၊ အနှုတ် ရှိ၍ သို့မဟုတ် `Duration` ထက်ပိုလျှံပါကဤနည်းလမ်းသည် panic ဖြစ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // အမှားအယွင်းများရလဒ်ရှာနိုင်ပါတယ်ကြောင့် 8.478 နှင့် 847800.0 ကနေအနည်းငယ်ကွဲပြားခြားနားကြောင်းကိုမှတ်စု
    /////
    /// assert_eq!(dur.mul_f32(3.14), Duration::new(8, 478_000_640));
    /// assert_eq!(dur.mul_f32(3.14e5), Duration::new(847799, 969_120_256));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(rhs * self.as_secs_f32())
    }

    /// `Duration` အားဖြင့် `Duration` ကိုဝေ။
    /// # Panics
    /// ရလဒ်သည်အကန့်အသတ်မရှိ၊ အနှုတ် ရှိ၍ သို့မဟုတ် `Duration` ထက်ပိုလျှံပါကဤနည်းလမ်းသည် panic ဖြစ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.div_f64(3.14), Duration::new(0, 859_872_611));
    /// // ခြင်းကိုအသုံးပြုသည်သတိပြုပါ, rounding မဟုတ်
    /// assert_eq!(dur.div_f64(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(self.as_secs_f64() / rhs)
    }

    /// `Duration` အားဖြင့် `Duration` ကိုဝေ။
    /// # Panics
    /// ရလဒ်သည်အကန့်အသတ်မရှိ၊ အနှုတ် ရှိ၍ သို့မဟုတ် `Duration` ထက်ပိုလျှံပါကဤနည်းလမ်းသည် panic ဖြစ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // အမှားအယွင်းများရလဒ်ရှာနိုင်ပါတယ်ကြောင့် 0.859_872_611 ကနေအနည်းငယ်ကွဲပြားခြားနားကြောင်းကိုမှတ်စု
    /////
    /// assert_eq!(dur.div_f32(3.14), Duration::new(0, 859_872_576));
    /// // ခြင်းကိုအသုံးပြုသည်သတိပြုပါ, rounding မဟုတ်
    /// assert_eq!(dur.div_f32(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(self.as_secs_f32() / rhs)
    }

    /// `Duration` အားဖြင့် `Duration` Divide နှင့် `f64` ပြန်သွားပါ။
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f64(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f64(self, rhs: Duration) -> f64 {
        self.as_secs_f64() / rhs.as_secs_f64()
    }

    /// `Duration` အား `Duration` ကိုဝေပြီး `f32` ကိုပြန်လာပါ။
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f32(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f32(self, rhs: Duration) -> f32 {
        self.as_secs_f32() / rhs.as_secs_f32()
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Add for Duration {
    type Output = Duration;

    fn add(self, rhs: Duration) -> Duration {
        self.checked_add(rhs).expect("overflow when adding durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl AddAssign for Duration {
    fn add_assign(&mut self, rhs: Duration) {
        *self = *self + rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Sub for Duration {
    type Output = Duration;

    fn sub(self, rhs: Duration) -> Duration {
        self.checked_sub(rhs).expect("overflow when subtracting durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl SubAssign for Duration {
    fn sub_assign(&mut self, rhs: Duration) {
        *self = *self - rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Mul<u32> for Duration {
    type Output = Duration;

    fn mul(self, rhs: u32) -> Duration {
        self.checked_mul(rhs).expect("overflow when multiplying duration by scalar")
    }
}

#[stable(feature = "symmetric_u32_duration_mul", since = "1.31.0")]
impl Mul<Duration> for u32 {
    type Output = Duration;

    fn mul(self, rhs: Duration) -> Duration {
        rhs * self
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl MulAssign<u32> for Duration {
    fn mul_assign(&mut self, rhs: u32) {
        *self = *self * rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Div<u32> for Duration {
    type Output = Duration;

    fn div(self, rhs: u32) -> Duration {
        self.checked_div(rhs).expect("divide by zero error when dividing duration by scalar")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl DivAssign<u32> for Duration {
    fn div_assign(&mut self, rhs: u32) {
        *self = *self / rhs;
    }
}

macro_rules! sum_durations {
    ($iter:expr) => {{
        let mut total_secs: u64 = 0;
        let mut total_nanos: u64 = 0;

        for entry in $iter {
            total_secs =
                total_secs.checked_add(entry.secs).expect("overflow in iter::sum over durations");
            total_nanos = match total_nanos.checked_add(entry.nanos as u64) {
                Some(n) => n,
                None => {
                    total_secs = total_secs
                        .checked_add(total_nanos / NANOS_PER_SEC as u64)
                        .expect("overflow in iter::sum over durations");
                    (total_nanos % NANOS_PER_SEC as u64) + entry.nanos as u64
                }
            };
        }
        total_secs = total_secs
            .checked_add(total_nanos / NANOS_PER_SEC as u64)
            .expect("overflow in iter::sum over durations");
        total_nanos = total_nanos % NANOS_PER_SEC as u64;
        Duration { secs: total_secs, nanos: total_nanos as u32 }
    }};
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl Sum for Duration {
    fn sum<I: Iterator<Item = Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl<'a> Sum<&'a Duration> for Duration {
    fn sum<I: Iterator<Item = &'a Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_debug_impl", since = "1.27.0")]
impl fmt::Debug for Duration {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        /// ဒဿမသင်္ကေတတစ်ခု floating အမှတ်အရေအတွက်သည် Formats ။
        ///
        /// ဒီနံပါတ်ကို `integer_part` နှင့်အပိုင်းကိန်းအဖြစ်ပေးထားသည်။
        /// အပိုင်းအစ၏တန်ဖိုးမှာ `fractional_part / divisor` ဖြစ်သည်။
        /// ဒီတော့ `integer_part` =3, `fractional_part` =12 နဲ့ `divisor` =100 ကအရေအတွက် `3.012` ကိုကိုယ်စားပြုတယ်။
        /// ကပ်တွယ်နေသောသုညများကိုချန်လှပ်ထားသည်။
        ///
        /// `divisor` 100_000_000 အထက်ဖြစ်ရပါ။
        /// ၎င်းသည်စွမ်းအား ၁၀ ခုဖြစ်သင့်သည်။
        /// `fractional_part` `10 * divisor` ထက်လျော့နည်းရမယ်။
        fn fmt_decimal(
            f: &mut fmt::Formatter<'_>,
            mut integer_part: u64,
            mut fractional_part: u32,
            mut divisor: u32,
        ) -> fmt::Result {
            // ဒtheမကိန်းအစိတ်အပိုင်းကိုယာယီကြားခံအဖြစ်ကုဒ်သွင်းပါ။
            // `fractional_part` ^ 9 10 ထက်သေးငယ်ဖြစ်ဖို့ရှိပါတယ်အကြောင်းမှာအဆိုပါကြားခံသာ, 9 element တွေကိုကိုင်ထားဖို့လိုပါတယ်။
            //
            // အဆိုပါကြားခံအောက်က code ကိုရိုးရှင်းဖို့ '0' ဂဏန်းနှင့်အတူ prefilled ဖြစ်ပါတယ်။
            let mut buf = [b'0'; 9];

            // နောက်ဂဏန်းကိုဒီအနေအထားမှာရေးထားတယ်
            let mut pos = 0;

            // ကျနော်တို့ left ကျနော်တို့သေးအလုံအလောက်ဂဏန်းသာကျမ်းစာ၌ရေးထားသည်မဟုတ်ကြ Non-သုညဂဏန်းရှိပါတယ်နေစဉ်ကြားခံသို့ဂဏန်းရေးသားခြင်းစောင့်ရှောက်လော့။
            //
            while fractional_part > 0 && pos < f.precision().unwrap_or(9) {
                // ကြားခံထဲသို့ဂဏန်းအသစ်ကိုရေးပါ
                buf[pos] = b'0' + (fractional_part / divisor) as u8;

                fractional_part %= divisor;
                divisor /= 10;
                pos += 1;
            }

            // အကယ်၍ တိကျသော <9 ကိုသတ်မှတ်ထားပါက၎င်းသည်ကြားခံထဲသို့မရေးသောဂဏန်းမဟုတ်သောအခြားဂဏန်းအချို့ကျန်ရှိနိုင်သည်။
            // ထိုအခြေအနေမျိုးတွင်ကျွန်ုပ်တို့သည်ပုံမှန် floating point နံပါတ်များကိုပုံနှိပ်ခြင်း၏ semantic နှင့်ကိုက်ညီရန် rounding လုပ်ရန်လိုအပ်သည်။
            // ဒါပေမယ့်ကျနော်တို့ကတက်ဝိုင်းတဲ့အခါမှာသာလုပ်ဖို့လိုအပ်ပါတယ်။
            // ကျန်ရှိသောသူမြား၏ပထမဦးဆုံးဂဏန်း>=5 လျှင်ဤသည်ဖြစ်ပျက်။
            //
            //
            if fractional_part > 0 && fractional_part >= divisor * 5 {
                // အရေအတွက်ကတက်ပတ်လည်ကြားခံတွင်ပါရှိသော။
                // ကျနော်တို့အတူသယ်မည့်အိတ်များ၏ကြားခံနောက်ပြန်နဲ့ Keep လမ်းကြောင်းမှတဆင့်သွားပါ။
                let mut rev_pos = pos;
                let mut carry = true;
                while carry && rev_pos > 0 {
                    rev_pos -= 1;

                    // ကြားခံရှိဂဏန်းသည် '9' မဟုတ်ပါက၎င်းကိုတိုး။ တိုး။ ရပ်တန့်နိုင်သည် (ကျွန်ုပ်တို့တွင်သယ်ဆောင်စရာမလိုတော့ပါ) ။
                    // ဒီလိုမှမဟုတ်ရင်ကျနော်တို့ '0' (overflow) ကသတ်မှတ်ထားခြင်းနှင့်ဆက်လက်။
                    //
                    //
                    if buf[rev_pos] < b'9' {
                        buf[rev_pos] += 1;
                        carry = false;
                    } else {
                        buf[rev_pos] = b'0';
                    }
                }

                // ကျွန်ုပ်တို့တွင် carry bit set ရှိနေသေးလျှင်ဆိုလိုသည်မှာကျွန်ုပ်တို့သည် buffer တစ်ခုလုံးကို '0s' ဟုသတ်မှတ်ပြီးကိန်းပြည့်ကိုတိုးရန်လိုအပ်သည်။
                //
                //
                if carry {
                    integer_part += 1;
                }
            }

            // အဆိုပါကြားခံ၏အဆုံးကိုဆုံးဖြတ်ရန်: တိကျစွာသတ်မှတ်လျှင်, အရုံ (9 မှအဖြစ်သို့) ကိုကြားခံအနေဖြင့်အများအပြားဂဏန်းအဖြစ်အသုံးပြုပါ။
            // ၎င်းကိုသတ်မှတ်မထားပါကကျွန်ုပ်တို့သည်နောက်ဆုံးသုညမဟုတ်သည့်ဂဏန်းအထိဂဏန်းအားလုံးကိုအသုံးပြုသည်။
            //
            let end = f.precision().map(|p| crate::cmp::min(p, 9)).unwrap_or(pos);

            // ကျနော်တို့တစ်ခုတည်းဒဿမကိန်းဂဏန်းထုတ်လွှတ်ကြပြီမဟုတ်နှင့်တိကျစွာ non-သုညတန်ဖိုးမသတ်မှတ်မခံခဲ့ရပါလျှင်, ငါတို့သည်ဒဿမအမှတ် print ထုတ်ကြဘူး။
            //
            if end == 0 {
                write!(f, "{}", integer_part)
            } else {
                // လုံခြုံမှု-ASCII ဂဏန်းများကိုသာကြားခံထဲသို့သာရေးသည်
                // '0's ဖြင့်စတင်ပါ၊ ထို့ကြောင့်၎င်းတွင်တရားဝင် UTF8 ပါ ၀ င်ပါသည်။
                let s = unsafe { crate::str::from_utf8_unchecked(&buf[..end]) };

                // အသုံးပြုသူတောင်းဆိုချက်တိကျစွာ> 9, ငါတို့ pad ပါ '' အဆုံးမှာ 0 င်မယ့်ပါ။
                let w = f.precision().unwrap_or(pos);
                write!(f, "{}.{:0<width$}", integer_part, s, width = w)
            }
        }

        // မေတ္တာရပ်ခံလျှင် '+' နိမိတ်လက္ခဏာကိုဦးဆောင် Print
        if f.sign_plus() {
            write!(f, "+")?;
        }

        if self.secs > 0 {
            fmt_decimal(f, self.secs, self.nanos, NANOS_PER_SEC / 10)?;
            f.write_str("s")
        } else if self.nanos >= NANOS_PER_MILLI {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MILLI) as u64,
                self.nanos % NANOS_PER_MILLI,
                NANOS_PER_MILLI / 10,
            )?;
            f.write_str("ms")
        } else if self.nanos >= NANOS_PER_MICRO {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MICRO) as u64,
                self.nanos % NANOS_PER_MICRO,
                NANOS_PER_MICRO / 10,
            )?;
            f.write_str("µs")
        } else {
            fmt_decimal(f, self.nanos as u64, 0, 1)?;
            f.write_str("ns")
        }
    }
}