//! `str` အတွက် Trait အကောင်အထည်ဖော်မှုများ။

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// ညှို့၏မိန့်အကောင်အထည်ဖော်မှု။
///
/// strings သူတို့ရဲ့က byte တန်ဖိုးများအားဖြင့် [lexicographically](Ord#lexicographical-comparison) အမိန့်ထုတ်နေကြသည်။
/// ၎င်းသည်ကုဒ်ဇယားများရှိ၎င်းတို့၏ရာထူးများအပေါ် အခြေခံ၍ ယူနီကုတ်ကုဒ်အချက်များကိုမှာယူသည်။
/// ၎င်းသည်ဘာသာစကားနှင့်ဒေသအရကွဲပြားသော "alphabetical" အမိန့်နှင့်မတူပါ။
/// ယဉ်ကျေးမှုအရလက်ခံထားသောစံနှုန်းများနှင့်အညီညှို့များကိုစီရန် `str` အမျိုးအစားပြင်ပရှိဒေတာလိုအပ်သည်။
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// ညှို့အပေါ်အကောင်အထည်ဖော်မှုနှိုင်းယှဉ်စစ်ဆင်ရေး။
///
/// strings သူတို့ရဲ့က byte တန်ဖိုးများအားဖြင့် [lexicographically](Ord#lexicographical-comparison) နှိုင်းယှဉ်နေကြသည်။
/// ၎င်းသည်ကုဒ်ဇယားများရှိ၎င်းတို့၏ရာထူးများအပေါ် အခြေခံ၍ ယူနီကုတ်ကုဒ်များကိုနှိုင်းယှဉ်သည်။
/// ၎င်းသည်ဘာသာစကားနှင့်ဒေသအရကွဲပြားသော "alphabetical" အမိန့်နှင့်မတူပါ။
/// ယဉ်ကျေးမှုအရလက်ခံထားသောစံနှုန်းများနှင့်အညီညှို့များကိုနှိုင်းယှဉ်ရန်မှာ `str` အမျိုးအစားပြင်ပရှိဒေတာလိုအပ်သည်။
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// syntax `&self[..]` သို့မဟုတ် `&mut self[..]` နှင့်အတူ substring ဖြတ်ခြင်းကိုအကောင်အထည်ဖော်။
///
/// string တစ်ခုလုံးရဲ့ slice တစ်ခုကို return ပြန်ပေးတယ်။ ဆိုလိုတာက `&self` or `&mut self` ။`&self မှညီမျှသည် [၀ ..
/// Len] `သို့မဟုတ်`&mut မိမိကိုယ်ကို [0 ..
/// len]`.
/// အခြားအ indexing စစ်ဆင်ရေးမတူဘဲ, ဒီဘယ်တော့မှလုပ်နိုင် panic ။
///
/// ဒီစစ်ဆင်ရေး *အို*(1) ဖြစ်ပါတယ်။
///
/// 1.20.0 မတိုင်မီကဤ indexing စစ်ဆင်ရေးများကို `Index` နှင့် `IndexMut` ကိုတိုက်ရိုက်အကောင်အထည်ဖော်ခြင်းဖြင့်ထောက်ပံ့ခဲ့သည်။
///
/// `&self[0 .. len]` သို့မဟုတ် `&mut self[0 .. len]` ညီမျှ။
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// syntax `&self[begin .. end]` သို့မဟုတ် `&mut self[begin .. end]` နှင့်အတူ substring ဖြတ်ခြင်းကိုအကောင်အထည်ဖော်။
///
/// က byte အကွာအဝေးကနေပေးထားသော string ကို [`begin`, `end`) ၏အချပ် Returns ။
///
/// ဒီစစ်ဆင်ရေး *အို*(1) ဖြစ်ပါတယ်။
///
/// 1.20.0 မတိုင်မီကဤ indexing စစ်ဆင်ရေးများကို `Index` နှင့် `IndexMut` ကိုတိုက်ရိုက်အကောင်အထည်ဖော်ခြင်းဖြင့်ထောက်ပံ့ခဲ့သည်။
///
/// # Panics
///
/// Panics သည် `begin` (သို့) `end` သည် (`is_char_boundary` အားဖြင့်သတ်မှတ်ထားသည့်အတိုင်း) ဇာတ်ကောင်တစ်ခု၏စတင်သော byte offset ကိုညွှန်ပြခြင်းမရှိပါက၊ `begin > end` သို့မဟုတ် `end > len` ဆိုပါက။
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // ဒါတွေက panic ပါလိမ့်မယ်။
/// // `ö` အတွင်း 2 မုသာစကားက byte:
/// // &s [2 ..3];
///
/// // byte 8 သည် `老`&s အတွင်းတွင်တည်ရှိသည် [1 ..
/// // 8];
///
/// // byte 100 သည် string နှင့် s အပြင်ဘက်တွင်ရှိသည်။
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // လုံခြုံမှု: ရုံ, `start` နှင့် `end` တစ် char နယ်နိမိတ်ပေါ်တွင်ဖြစ်ကြောင်း check လုပ်ထား
            // လုံခြုံစိတ်ချရသောရည်ညွှန်းချက်ကိုကျွန်ုပ်တို့ဖြတ်သန်းသွားသောကြောင့်ပြန်လာသောတန်ဖိုးသည်လည်းတစ်ခုဖြစ်လိမ့်မည်။
            // char နယ်နိမိတ်များကိုလည်းစစ်ဆေးပြီးဖြစ်သောကြောင့် UTF-8 သည်မှန်ကန်သည်။
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // လုံခြုံမှု-`start` နှင့် `end` ကို char နယ်နိမိတ်ပေါ်တွင်သာတွေ့ရသည်။
            // pointer သည်ထူးခြားသည်ကိုကျွန်ုပ်တို့သိပြီးဖြစ်သောကြောင့် `slice` မှရရှိသည်။
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // လုံခြုံမှု-ဖုန်းခေါ်သူမှ `self` သည် `slice` ၏အကန့်အသတ်ရှိသည်ဟုအာမခံသည်
        // အရာ `add` အပေါငျးတို့သအခြေအနေများကျေနပ်။
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // လုံခြုံမှု: `get_unchecked` များအတွက်မှတ်ချက်များကိုကြည့်ပါ။
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary ကဒီအညွှန်းကိန်း [0] ရှိမရှိကိုစစ်ဆေးသည်။ NLL ပြNLနာကြောင့် .len()] သည်အထက်တွင်ဖော်ပြထားသည့်အတိုင်း `get` ကို ပြန်၍ မသုံးနိုင်ပါ။
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // လုံခြုံမှု: ရုံ, `start` နှင့် `end` တစ် char နယ်နိမိတ်ပေါ်တွင်ဖြစ်ကြောင်း check လုပ်ထား
            // လုံခြုံစိတ်ချရသောရည်ညွှန်းချက်ကိုကျွန်ုပ်တို့ဖြတ်သန်းသွားသောကြောင့်ပြန်လာသောတန်ဖိုးသည်လည်းတစ်ခုဖြစ်လိမ့်မည်။
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// syntax `&self[.. end]` သို့မဟုတ် `&mut self[.. end]` နှင့်အတူ substring ဖြတ်ခြင်းကိုအကောင်အထည်ဖော်။
///
/// ပေးထားသော string ကို byte range မှ [`0`, `end`) မှအချပ်တစ်ခုကိုပြန်ပို့သည်။
/// `&self[0 .. end]` သို့မဟုတ် `&mut self[0 .. end]` နှင့်ညီမျှသည်။
///
/// ဒီစစ်ဆင်ရေး *အို*(1) ဖြစ်ပါတယ်။
///
/// 1.20.0 မတိုင်မီကဤ indexing စစ်ဆင်ရေးများကို `Index` နှင့် `IndexMut` ကိုတိုက်ရိုက်အကောင်အထည်ဖော်ခြင်းဖြင့်ထောက်ပံ့ခဲ့သည်။
///
/// # Panics
///
/// `end` လျှင် Panics တစ်အက္ခရာ (`is_char_boundary` နေဖြင့်သတ်မှတ်ကဲ့သို့), ဒါမှမဟုတ် `end > len` လျှင်၏ offset အတွက်စတင်က byte ထောက်ပြမထားဘူး။
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // လုံခြုံမှု-`end` ဟာ char နယ်နိမိတ်ပေါ်မှာရှိနေတယ်ဆိုတာကိုပဲစစ်ဆေးခဲ့တယ်။
            // လုံခြုံစိတ်ချရသောရည်ညွှန်းချက်ကိုကျွန်ုပ်တို့ဖြတ်သန်းသွားသောကြောင့်ပြန်လာသောတန်ဖိုးသည်လည်းတစ်ခုဖြစ်လိမ့်မည်။
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // လုံခြုံမှု-`end` ဟာ char နယ်နိမိတ်ပေါ်မှာရှိနေတယ်ဆိုတာကိုပဲစစ်ဆေးခဲ့တယ်။
            // လုံခြုံစိတ်ချရသောရည်ညွှန်းချက်ကိုကျွန်ုပ်တို့ဖြတ်သန်းသွားသောကြောင့်ပြန်လာသောတန်ဖိုးသည်လည်းတစ်ခုဖြစ်လိမ့်မည်။
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // လုံခြုံမှု-`end` ဟာ char နယ်နိမိတ်ပေါ်မှာရှိနေတယ်ဆိုတာကိုပဲစစ်ဆေးခဲ့တယ်။
            // လုံခြုံစိတ်ချရသောရည်ညွှန်းချက်ကိုကျွန်ုပ်တို့ဖြတ်သန်းသွားသောကြောင့်ပြန်လာသောတန်ဖိုးသည်လည်းတစ်ခုဖြစ်လိမ့်မည်။
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// syntax `&self[begin ..]` သို့မဟုတ် `&mut self[begin ..]` နှင့်အတူ substring ဖြတ်ခြင်းကိုအကောင်အထည်ဖော်။
///
/// က byte အကွာအဝေးကနေပေးထားသော string ကို [`begin`, `len`) ၏အချပ် Returns ။`&self 'နဲ့ညီမျှတယ်။
/// len] `သို့မဟုတ်`&mut မိမိကိုယ်ကို [စတင် ..
/// len]`.
///
/// ဒီစစ်ဆင်ရေး *အို*(1) ဖြစ်ပါတယ်။
///
/// 1.20.0 မတိုင်မီကဤ indexing စစ်ဆင်ရေးများကို `Index` နှင့် `IndexMut` ကိုတိုက်ရိုက်အကောင်အထည်ဖော်ခြင်းဖြင့်ထောက်ပံ့ခဲ့သည်။
///
/// # Panics
///
/// `begin` လျှင် Panics တစ်အက္ခရာ (`is_char_boundary` နေဖြင့်သတ်မှတ်ကဲ့သို့), ဒါမှမဟုတ် `begin > len` လျှင်၏ offset အတွက်စတင်က byte ထောက်ပြမထားဘူး။
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // လုံခြုံမှု: ရုံ `start` တစ် char နယ်နိမိတ်အပေါ်ကြောင်းကို check လုပ်ထား,
            // လုံခြုံစိတ်ချရသောရည်ညွှန်းချက်ကိုကျွန်ုပ်တို့ဖြတ်သန်းသွားသောကြောင့်ပြန်လာသောတန်ဖိုးသည်လည်းတစ်ခုဖြစ်လိမ့်မည်။
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // လုံခြုံမှု: ရုံ `start` တစ် char နယ်နိမိတ်အပေါ်ကြောင်းကို check လုပ်ထား,
            // လုံခြုံစိတ်ချရသောရည်ညွှန်းချက်ကိုကျွန်ုပ်တို့ဖြတ်သန်းသွားသောကြောင့်ပြန်လာသောတန်ဖိုးသည်လည်းတစ်ခုဖြစ်လိမ့်မည်။
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // လုံခြုံမှု-ဖုန်းခေါ်သူမှ `self` သည် `slice` ၏အကန့်အသတ်ရှိသည်ဟုအာမခံသည်
        // အရာ `add` အပေါငျးတို့သအခြေအနေများကျေနပ်။
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // လုံခြုံမှု-`get_unchecked` နှင့်တူညီသည်။
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // လုံခြုံမှု: ရုံ `start` တစ် char နယ်နိမိတ်အပေါ်ကြောင်းကို check လုပ်ထား,
            // လုံခြုံစိတ်ချရသောရည်ညွှန်းချက်ကိုကျွန်ုပ်တို့ဖြတ်သန်းသွားသောကြောင့်ပြန်လာသောတန်ဖိုးသည်လည်းတစ်ခုဖြစ်လိမ့်မည်။
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// syntax `&self[begin ..= end]` သို့မဟုတ် `&mut self[begin ..= end]` နှင့်အတူချပ်အောက်သို့ဦးတည်ထားအကောင်အထည်ဖော်မှု။
///
/// ပေးထားသော string ၏အချပ်ကို [`begin`, `end`] မှပြန်ပေးသည်။`end` `usize` များအတွက်အများဆုံးတန်ဖိုးကိုရှိပါတယ်လျှင် မှလွဲ. `&self [begin .. end + 1]` သို့မဟုတ် `&mut self[begin .. end + 1]` ညီမျှ။
///
/// ဒီစစ်ဆင်ရေး *အို*(1) ဖြစ်ပါတယ်။
///
/// # Panics
///
/// Panics သည် `begin` သည် (`is_char_boundary` အားဖြင့်အဓိပ္ပါယ်ဖွင့်ဆိုထားသည့်အတိုင်း) စာလုံးတစ်ခု၏စတင် byte offset ကိုညွှန်ပြခြင်းမရှိပါက `end` သည် X0 `begin > end` သည်အက္ခရာတစ်ခု၏အဆုံးသတ် byte offset ကိုညွှန်ပြခြင်းမရှိပါက (`end + 1` သည်စတင် byte offset သို့မဟုတ် `len` နှင့်ညီသည်ဖြစ်စေ) ဖြစ်သည်။ သို့မဟုတ် `end >= len` လျှင်။
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `get_unchecked` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `get_unchecked_mut` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// syntax `&self[..= end]` သို့မဟုတ် `&mut self[..= end]` နှင့်အတူ substring ဖြတ်ခြင်းကိုအကောင်အထည်ဖော်။
///
/// ပေးထားသော string ၏အချပ်ကို [0, `end`] မှ byt range သို့ပြန်သွားသည်။
/// `end` သည် `usize` အတွက်အများဆုံးတန်ဖိုးရှိပါက မှလွဲ၍ `&self [0 .. end + 1]` နှင့်ညီသည်။
///
/// ဒီစစ်ဆင်ရေး *အို*(1) ဖြစ်ပါတယ်။
///
/// # Panics
///
/// `end` လျှင် Panics တစ်ဇာတ်ကောင်များ၏ offset အတွက်အဆုံးသတ်က byte ထောက်ပြ (`end + 1` `is_char_boundary` နေဖြင့်သတ်မှတ်အဖြစ် offset တစ်ခုစတင်က byte ဖြစ်စေဖြစ်ပါသည်, သို့မဟုတ် `len` မှတူညီ), သို့မဟုတ် `end >= len` လျှင်မထားဘူး။
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `get_unchecked` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `get_unchecked_mut` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// string ကိုကနေတန်ဖိုးကိုခွဲခြမ်းစိတ်ဖြာ
///
/// `FromStr` ၏ [`from_str`] နည်းလမ်းကို [`str`] [`parse`] နည်းလမ်းမှတဆင့်လုံးလုံးလြားလြားအသုံးပြုသည်။
/// ဥပမာများအတွက် [`parse`] 's စာရွက်စာတမ်းများကိုကြည့်ပါ။
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` တစ်သက်တာ parameter သည်ရှိသည်, သငျသညျမိမိတို့ကိုယ်ကို parameter သည်တစ်သက်တာဆံ့မသာဤဖွဲ့စည်းတည်ဆောက်မှုပုံစံအမျိုးအစားများကိုတတ်နိုင်သမျှဒါမထားဘူး။
///
/// တစ်နည်းပြောရလျှင်သင်သည် `i32` ကို `FromStr` နှင့်ဆန်းစစ်နိုင်သည်၊ သို့သော် `&i32` တစ်ခုမဟုတ်။
/// သင်တစ်ဦး `&i32` ပါရှိသည်တစ်ခုအနေနဲ့ `i32` ပါရှိသည်တဲ့ struct ခွဲခြားစိတ်ဖြာမှု, ဒါပေမယ့်မရဘူး။
///
/// # Examples
///
/// `Point` အမျိုးအစားတစ်ခု၏ `FromStr` ၏အခြေခံအကောင်အထည်ဖော်မှု-
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// ခွဲခြမ်းစိတ်ဖြာခြင်းမှပြန်လာနိုင်သည့်ဆက်စပ်အမှား။
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// ဒီအမျိုးအစားရဲ့တန်ဖိုးကိုပြန်သွားဖို့ string `s` ကိုခွဲခြမ်းစိတ်ဖြာ။
    ///
    /// ဆန်းစစ်မှုအောင်မြင်လျှင်, string ကိုအတွင်းပိုင်း [`Err`] မှနေမကောင်း-ချပ်ပြန်လာမှားယွင်းမှုတစ်ခုသတ်သတ်မှတ်မှတ်ဖြစ်ပါတယ်မဟုတ်ရင်အခါ, [`Ok`] အတွင်းပိုင်းတန်ဖိုးကိုပြန်သွားပါ။
    /// အမှားအမျိုးအစား trait ၏အကောင်အထည်ဖော်မှုမှတိကျတဲ့ဖြစ်ပါတယ်။
    ///
    /// # Examples
    ///
    /// `FromStr` ကိုသုံးသည့် `FromStr` ကိုအခြေခံသုံးခြင်း။
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// တစ် ဦး string ကိုကနေ `bool` ခွဲခြမ်းစိတ်ဖြာ။
    ///
    /// `s` သည်အမှန်တကယ်ခွဲစိပ်စစ်ဆေး။ မရနိုင်သောကြောင့်ဖြစ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// သတိပြုပါ၊ များစွာသောကိစ္စများတွင်၊ `str` ရှိ `.parse()` နည်းလမ်းသည် ပို၍ သင့်လျော်သည်။
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}