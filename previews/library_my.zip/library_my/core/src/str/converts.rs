//! bytes slice မှ `str` တစ်ခုကိုဖန်တီးရန်နည်းလမ်းများ။

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// byte တစ်ထပ်ကို string slice တစ်ခုသို့ပြောင်းသည်။
///
/// တစ်ဦးက string ကိုအချပ် ([`&str`]) ([`u8`]) bytes ၏ဖန်ဆင်းသည်, တစ်ဦးက byte အချပ် ([`&[u8]`][byteslice]) bytes ၏လုပ်, ဒါကြောင့်နှစ်ခုအကြားကဒီ function ကိုပြောင်းလဲနေသည်။
/// သို့သော် byte slices အားလုံးသည်မှန်ကန်သော string slices များမဟုတ်ပါ။ [`&str`] သည် UTF-8 ကိုလိုအပ်သည်။
/// `from_utf8()` bytes များသည်တရားဝင် UTF-8 ဟုတ်မဟုတ်သေချာစေရန်စစ်ဆေးပြီးနောက်ပြောင်းလဲခြင်းကိုပြုလုပ်သည်။
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// အကယ်၍ byte slice သည် UTF-8 သည်မှန်ကန်ကြောင်းနှင့်သင်စစ်ဆေးမှု၏ overhead ကိုမခံယူလိုပါလျှင်ဤ function ၏လုံခြုံမှုမရှိသောဗားရှင်း-[`from_utf8_unchecked`] ရှိသည်။ ၎င်းသည်အတူတူပင်ပြုမူသော်လည်းထိုစစ်ဆေးမှုကိုကျော်သွားသည်။
///
///
/// သင် `&str` အစား `String` တစ်ခုလိုအပ်ပါက [`String::from_utf8`][string] ကိုစဉ်းစားပါ။
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// သင်တစ်ဦး `[u8; N]` ခွဲဝေချထားပေးရန်-သီးနှံများကိုပုံနိုင်ပြီး, သင်ကတစ် [`&[u8]`][byteslice] ယူနိုငျသောကွောငျ့, ဒီ function ကိုတစ်ဦး stack-ခွဲဝေ string ကိုရှိသည်ဖို့တလမ်းတည်းဖြင့်ဖြစ်ပါသည်။အောက်တွင်ဖော်ပြထားသောဥပမာကဏ္section၌ဤဥပမာကိုဖော်ပြထားသည်။
///
/// [byteslice]: slice
///
/// # Errors
///
/// ပေးထားသောအချပ်သည် UTF-8 မဟုတ်သည့်အတွက်ဖော်ပြချက်တစ်ခုသည် UTF-8 မဟုတ်ပါက `Err` ကိုပြန်ပို့သည်။
///
/// # Examples
///
/// အခြေခံအသုံးပြုမှု-
///
/// ```
/// use std::str;
///
/// // တစ် ဦး vector အတွက်အချို့သော bytes
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // ဤ bytes များသည်မှန်ကန်ကြောင်းကျွန်ုပ်တို့သိသည်။ ထို့ကြောင့် `unwrap()` ကိုသာသုံးပါ။
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// မမှန်ကန်ကြောင်းက bytes:
///
/// ```
/// use std::str;
///
/// // vector ထဲတွင်မမှန်ကန်တဲ့ bytes အချို့
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// ပြန်ရောက်နိုင်အမှားအယွင်းများ၏အမျိုးမျိုးအပေါ်ပိုပြီးအသေးစိတ် [`Utf8Error`] များအတွက်စာရွက်စာတမ်းများကိုကြည့်ပါ။
///
/// "stack allocated string":
///
/// ```
/// use std::str;
///
/// // အချို့သော bytes များ၊
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // ဤ bytes များသည်မှန်ကန်ကြောင်းကျွန်ုပ်တို့သိသည်။ ထို့ကြောင့် `unwrap()` ကိုသာသုံးပါ။
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // လုံခြုံမှု-တရားဝင်အတည်ပြုချက်ကိုပဲရခဲ့တယ်။
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// mutable slice oftes တစ်ခုကို mutable string slice တစ်ခုသို့ပြောင်းသည်။
///
/// # Examples
///
/// အခြေခံအသုံးပြုမှု-
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" တစ် ဦး mutable vector အဖြစ်
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // ဤ bytes များသည်မှန်ကန်ကြောင်းကျွန်ုပ်တို့သိသဖြင့် `unwrap()` ကိုသုံးနိုင်သည်
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// မမှန်ကန်ကြောင်းက bytes:
///
/// ```
/// use std::str;
///
/// // ပြောင်းလဲနိုင်သော vector ရှိအချို့သောမမှန်ကန်တဲ့ bytes များ
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// ပြန်ရောက်နိုင်အမှားအယွင်းများ၏အမျိုးမျိုးအပေါ်ပိုပြီးအသေးစိတ် [`Utf8Error`] များအတွက်စာရွက်စာတမ်းများကိုကြည့်ပါ။
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // လုံခြုံမှု-တရားဝင်အတည်ပြုချက်ကိုပဲရခဲ့တယ်။
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// byte တစ် slice ကို string slice တစ်ခုသို့ပြောင်းလဲပြီး string မှာ valid UTF-8 ပါမပါ။
///
/// ပိုမိုသိရှိလိုပါကအဘို့, လုံခြုံဗားရှင်း [`from_utf8`] ကိုကြည့်ပါ။
///
/// # Safety
///
/// ၄ င်း function သည်လုံခြုံမှုမရှိဘူး၊ ဘာလို့လဲဆိုတော့သူက bytes များမှန်ကန်စွာ UTF-8 ဟုတ်မဟုတ်ဆိုတာကိုမစစ်ဆေးသောကြောင့်ဖြစ်သည်။
/// အကယ်၍ ဤအကန့်အသတ်ကိုချိုးဖောက်ပါက Rust ၏ကျန်များသည် [`&str`] သည်မှန်ကန်သော UTF-8 ဖြစ်သည်ဟုမသတ်မှတ်ထားသောအပြုအမူရလဒ်များရှိသည်။
///
///
/// [`&str`]: str
///
/// # Examples
///
/// အခြေခံအသုံးပြုမှု-
///
/// ```
/// use std::str;
///
/// // တစ် ဦး vector အတွက်အချို့သော bytes
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // လုံခြုံမှု-ခေါ်ဆိုသူသည် bytes `v` သည်မှန်ကန်သော UTF-8 ဖြစ်ကြောင်းအာမခံရမည်။
    // `&str` နှင့် `&[u8]` တို့သည်အတူတူ layout ရှိခြင်းအပေါ်တွင်မှီခိုသည်။
    unsafe { mem::transmute(v) }
}

/// string ကိုတရားဝင် UTF-8 ပါဝင်သောစစ်ဆေးနေခြင်းမရှိဘဲတစ်ဦး string ကိုအချပ်ဖို့ bytes တစ်ဦးအချပ်ပြောင်းပေး;mutable ဗားရှင်း။
///
///
/// ပိုမိုသိရှိလိုပါကမပြောင်းလဲနိုင်သောအရာများပါသော [`from_utf8_unchecked()`] ကိုကြည့်ပါ။
///
/// # Examples
///
/// အခြေခံအသုံးပြုမှု-
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // လုံခြုံမှု: ခေါ်ဆိုသူသည် bytes `v` ကိုအာမခံရမည်
    // UTF-8 သည်မှန်ကန်သည်၊ ထို့ကြောင့် `*mut str` သို့သွန်းခြင်းသည်လုံခြုံသည်။
    // ထို့အပြင် pointer dereference သည်လုံခြုံမှုရှိသည်။ အဘယ်ကြောင့်ဆိုသော်ထိုညွှန်းသည်ရည်ညွှန်းချက်တစ်ခုမှလာပြီးရေးသားရန်အတွက်ခိုင်လုံသောအာမခံချက်ဖြစ်သည်။
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}