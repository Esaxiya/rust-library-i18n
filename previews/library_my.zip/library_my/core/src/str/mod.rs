//! String ကိုင်တွယ်။
//!
//! အသေးစိတ်သိလိုပါက [`std::str`] module ကိုကြည့်ပါ။
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. အပြင်ကထွက်
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. စတင် <=အဆုံး
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. ဇာတ်ကောင်နယ်နိမိတ်
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // ဇာတ်ကောင်ကိုရှာပါ
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` len နှင့် char နယ်နိမိတ်ထက်လျော့နည်းဖြစ်ရမည်
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// `self` အရှည်ကိုပြန်ပို့သည်။
    ///
    /// ဤသည်အရှည်, bytes မ [`char`] s ကိုသို့မဟုတ် Grapheme ။
    /// တနည်းအားဖြင့်လူသားတစ် ဦး သည်ကြိုး၏အရှည်ကိုစဉ်းစားသောအရာမဟုတ်ပါ။
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // ဖန်စီ f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// အကယ်၍ `self` သည်သုည bytes အရှည်ရှိပါက `true` သို့ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// index`-ကြိမ်မြောက်က byte တစ် UTF-8 ကုဒ်ပွိုင့် sequence ကိုဒါမှမဟုတ် string ကို၏အဆုံး၌ပထမဦးဆုံးက byte ဖြစ်ပါသည်`ကြောင်းစစ်ဆေးမှုများ။
    ///
    ///
    /// string ၏အစနှင့်အဆုံး (`index== self.len()`) ကိုနယ်နိမိတ်အဖြစ်သတ်မှတ်ကြသောအခါ) ။
    ///
    /// `index` `self.len()` ထက်ကြီးလျှင် `false` သို့ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // `老` ၏စတင်
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // `ö` ၏ဒုတိယ byte
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // `老` ၏တတိယ byte
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 နှင့် len အမြဲ ok ဖြစ်ကြသည်။
        // 0 ကိုရှင်းရှင်းလင်းလင်းစစ်ဆေးပါ၊ သို့မှသာစစ်ဆေးမှုကိုလွယ်ကူစွာပြုလုပ်နိုင်ပြီးထိုကိစ္စအတွက် string data များကိုဖတ်ရှုနိုင်သည်။
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // ဤသည်နှင့်ညီမျှ bit နဲ့မှော်ဖြစ်ပါသည်: ခ <128 ||ခ>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// string slice ကို byte slice အဖြစ်ပြောင်းသည်။
    /// byte slice ကို string slice တစ်ခုအဖြစ်ပြန်ပြောင်းချင်ရင် [`from_utf8`] function ကိုသုံးပါ။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // လုံခြုံမှု: တည်ဆောက်မှုသံသည်ပုံစံတစ်မျိုးတည်းဖြင့်အမျိုးအစားနှစ်မျိုးကိုပို့ဆောင်သောကြောင့်ဖြစ်သည်
        unsafe { mem::transmute(self) }
    }

    /// တစ် ဦး mutable string ကိုအချပ်တစ်ခု mutable byte slice ကိုပြောင်းလဲ။
    ///
    /// # Safety
    ///
    /// ခေါ်ဆိုသူသည်အချပ်၏ပါ ၀ င်မှုသည်ချေးယူမှုမပြီးဆုံးမှီနောက်ခံ `str` ကိုမသုံးမီအချပ်၏ပါ ၀ င်မှုသည် UTF-8 ဖြစ်သည်။
    ///
    ///
    /// UTF-8 တွင်ပါဝင်သောအကြောင်းအရာများသည်မမှန်ကန်သော UTF-8 ကိုအသုံးပြုခြင်းသည်သတ်မှတ်ထားသောအပြုအမူဖြစ်သည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // လုံခြုံမှု-`&str` မှ `&[u8]` သို့သွန်းခြင်းသည် `str` မှစ၍ လုံခြုံသည်
        // (သာ libstd ဒီအာမခံချက်ကိုဖြစ်စေနိုင်ပါတယ်) `&[u8]` ကဲ့သို့တူညီသော layout ကိုရှိပါတယ်။
        // ၎င်းသည်ရေးသားခြင်းအတွက်မှန်ကန်ကြောင်းသေချာစေရန်အာမခံနိုင်သော mutable reference မှလာခြင်းကြောင့် pointer dereference သည်လုံခြုံသည်။
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// string slice ကို point pointer အဖြစ်ပြောင်းသည်။
    ///
    /// string slices များသည် bytes အတိုတစ်ခုဖြစ်သဖြင့် raw point သည် [`u8`] ကိုညွှန်ပြသည်။
    /// ဒီ pointer သည် string slice ၏ပထမဆုံး byte ကိုညွှန်ပြလိမ့်မည်။
    ///
    /// ခေါ်ဆိုသူသည်ပြန်လာသော pointer အားမည်သည့်အခါမျှရေးသားခြင်းမပြုရန်သေချာစေရမည်။
    /// အကယ်၍ string slice ရဲ့ contents ကို mutate လုပ်ဖို့လိုအပ်လျှင် [`as_mut_ptr`] ကိုသုံးပါ။
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// တစ်ကုန်ကြမ်း pointer ကိုတစ်ဦး mutable string ကိုအချပ်ပြောင်းပေးပါတယ်။
    ///
    /// string slices များသည် bytes အတိုတစ်ခုဖြစ်သဖြင့် raw point သည် [`u8`] ကိုညွှန်ပြသည်။
    /// ဒီ pointer သည် string slice ၏ပထမဆုံး byte ကိုညွှန်ပြလိမ့်မည်။
    ///
    /// သင်၏လျှို့ဝှက်နံပါတ်သည် UTF-8 ကိုသာဆက်လက်တည်ရှိနေအောင်ပြုပြင်မွမ်းမံရန်သင့်တာဝန်ဖြစ်သည်။
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// `str` ၏ subslice တစ်ခုပြန်ပို့သည်။
    ///
    /// ၎င်းသည် `str` ကိုရည်ညွှန်းခြင်းမဟုတ်သောထိတ်လန့်တုန်လှုပ်စရာနည်းလမ်းဖြစ်သည်။
    /// ညီမျှ indexing စစ်ဆင်ရေး panic လိုအခါတိုင်း [`None`] ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // ညွှန်းကိန်းမဟုတ် UTF-8 sequence ကိုနယ်နိမိတ်ပေါ်မှာ
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // အပြင်ကထွက်
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// `str` ၏ mutable subslice တစ်ခုကိုပြန်ပို့သည်။
    ///
    /// ၎င်းသည် `str` ကိုရည်ညွှန်းခြင်းမဟုတ်သောထိတ်လန့်တုန်လှုပ်စရာနည်းလမ်းဖြစ်သည်။
    /// ညီမျှ indexing စစ်ဆင်ရေး panic လိုအခါတိုင်း [`None`] ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // မှန်ကန်သောအရှည်
    /// assert!(v.get_mut(0..5).is_some());
    /// // အပြင်ကထွက်
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// `str` တစ်ဦးအမှတ်ကိုဖြုတ်လိုက်ပါ subslice Returns ။
    ///
    /// ၎င်းသည် `str` ကိုရည်ညွှန်းခြင်းမပြုရသေးသောအခြားရွေးချယ်စရာတစ်ခုဖြစ်သည်။
    ///
    /// # Safety
    ///
    /// ဤလုပ်ဆောင်မှုကိုခေါ်ဆိုသူများသည်ဤကြိုတင်စည်းကမ်းချက်များကိုကျေနပ်သည်ဟုတာဝန်ရှိသည်။
    ///
    /// * စတင်အညွှန်းကိန်းသည်အဆုံးသတ်အညွှန်းကိန်းထက်မပိုစေရ။
    /// * အညွှန်းကိန်းမူရင်းအချပ်၏ဘောင်အတွင်းဖြစ်ရမည်;
    /// * အညွှန်းများသည် UTF-8 sequence နယ်နိမိတ်အတွင်းတွင်ရှိရမည်။
    ///
    /// ၎င်းကိုမအောင်မြင်ပါကပြန်လာသော string သည်အချပ်သည်မမှန်ကန်တဲ့မှတ်ဉာဏ်ကိုရည်ညွှန်းနိုင်သည်သို့မဟုတ် `str` အမျိုးအစားမှဆက်သွယ်ထားသောလျော့ပါးသွားမည်ဖြစ်သလိုချိုးဖောက်နိုင်သည်
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `get_unchecked` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
        // `self` သည်လုံခြုံသောရည်ညွှန်းသောကြောင့်အချပ်သည် dereferencable ဖြစ်သည်။
        // `SliceIndex` ၏ impls ကြောင့်ကြောင်းအာမခံရန်ရှိသည်ကြောင့်ပြန်လာသော pointer ကိုဘေးကင်းလုံခြုံသည်။
        unsafe { &*i.get_unchecked(self) }
    }

    /// mutable, unchecked subselice ပြန်သွားသည်။
    ///
    /// ၎င်းသည် `str` ကိုရည်ညွှန်းခြင်းမပြုရသေးသောအခြားရွေးချယ်စရာတစ်ခုဖြစ်သည်။
    ///
    /// # Safety
    ///
    /// ဤလုပ်ဆောင်မှုကိုခေါ်ဆိုသူများသည်ဤကြိုတင်စည်းကမ်းချက်များကိုကျေနပ်သည်ဟုတာဝန်ရှိသည်။
    ///
    /// * စတင်အညွှန်းကိန်းသည်အဆုံးသတ်အညွှန်းကိန်းထက်မပိုစေရ။
    /// * အညွှန်းကိန်းမူရင်းအချပ်၏ဘောင်အတွင်းဖြစ်ရမည်;
    /// * အညွှန်းများသည် UTF-8 sequence နယ်နိမိတ်အတွင်းတွင်ရှိရမည်။
    ///
    /// ၎င်းကိုမအောင်မြင်ပါကပြန်လာသော string သည်အချပ်သည်မမှန်ကန်တဲ့မှတ်ဉာဏ်ကိုရည်ညွှန်းနိုင်သည်သို့မဟုတ် `str` အမျိုးအစားမှဆက်သွယ်ထားသောလျော့ပါးသွားမည်ဖြစ်သလိုချိုးဖောက်နိုင်သည်
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `get_unchecked_mut` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
        // `self` သည်လုံခြုံသောရည်ညွှန်းသောကြောင့်အချပ်သည် dereferencable ဖြစ်သည်။
        // `SliceIndex` ၏ impls ကြောင့်ကြောင်းအာမခံရန်ရှိသည်ကြောင့်ပြန်လာသော pointer ကိုဘေးကင်းလုံခြုံသည်။
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// ဘေးကင်းလုံခြုံမှုစစ်ဆေးမှုများကိုကျော်လွှား, အခြား string ကိုအချပ်ကနေ string ကိုအချပ်ဖန်တီးသည်။
    ///
    /// ဤသည်ယေဘုယျအားဖြင့်အကြံပြုသည်မဟုတ်, သတိဖြင့်အသုံးပြု!လုံခြုံသောရွေးချယ်စရာတစ်ခုအတွက် [`str`] နှင့် [`Index`] ကိုကြည့်ပါ။
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// ဤအချပ်အသစ်သည် `begin` မှ `end` သို့သွားသည်၊ `begin` အပါအဝင် `end` ကိုဖယ်ထုတ်သည်။
    ///
    /// ၎င်းအစား mutable string slice တစ်ခုကိုရရှိရန် [`slice_mut_unchecked`] method ကိုကြည့်ပါ။
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// ဤလုပ်ဆောင်ချက်ကိုခေါ်ဆိုသူများသည်ကြိုတင်စည်းကမ်းချက်များ (၃) ခုကိုကျေနပ်ကြောင်းတာဝန်ရှိသည်။
    ///
    /// * `begin` `end` ထက်မပိုစေရ။
    /// * `begin` နှင့် `end` string ကိုအချပ်အတွင်းက byte ရာထူးဖြစ်ရပါမည်။
    /// * `begin` နှင့် `end` UTF-8 sequence ကိုနယ်နိမိတ်ပေါ်မှာအိပ်ရရမည်ဖြစ်သည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `get_unchecked` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
        // `self` သည်လုံခြုံသောရည်ညွှန်းသောကြောင့်အချပ်သည် dereferencable ဖြစ်သည်။
        // `SliceIndex` ၏ impls ကြောင့်ကြောင်းအာမခံရန်ရှိသည်ကြောင့်ပြန်လာသော pointer ကိုဘေးကင်းလုံခြုံသည်။
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// ဘေးကင်းလုံခြုံမှုစစ်ဆေးမှုများကိုကျော်လွှား, အခြား string ကိုအချပ်ကနေ string ကိုအချပ်ဖန်တီးသည်။
    /// ဤသည်ယေဘုယျအားဖြင့်, သတိနဲ့သုံးစွဲခြင်းအကြံပြုသည်မဟုတ်!လုံခြုံသောရွေးချယ်စရာတစ်ခုအတွက် [`str`] နှင့် [`IndexMut`] ကိုကြည့်ပါ။
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// ဤအချပ်အသစ်သည် `begin` မှ `end` သို့သွားသည်၊ `begin` အပါအဝင် `end` ကိုဖယ်ထုတ်သည်။
    ///
    /// မပြောင်းလဲနိုင်သောအရာတစ်ခုကိုအစားထိုးရန် [`slice_unchecked`] နည်းလမ်းကိုကြည့်ပါ။
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// ဤလုပ်ဆောင်ချက်ကိုခေါ်ဆိုသူများသည်ကြိုတင်စည်းကမ်းချက်များ (၃) ခုကိုကျေနပ်ကြောင်းတာဝန်ရှိသည်။
    ///
    /// * `begin` `end` ထက်မပိုစေရ။
    /// * `begin` နှင့် `end` string ကိုအချပ်အတွင်းက byte ရာထူးဖြစ်ရပါမည်။
    /// * `begin` နှင့် `end` UTF-8 sequence ကိုနယ်နိမိတ်ပေါ်မှာအိပ်ရရမည်ဖြစ်သည်။
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `get_unchecked_mut` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
        // `self` သည်လုံခြုံသောရည်ညွှန်းသောကြောင့်အချပ်သည် dereferencable ဖြစ်သည်။
        // `SliceIndex` ၏ impls ကြောင့်ကြောင်းအာမခံရန်ရှိသည်ကြောင့်ပြန်လာသော pointer ကိုဘေးကင်းလုံခြုံသည်။
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// တစ်ခုအကွောင်းတစ်ခုအညွှန်းကိန်းမှာနှစ်ခုသို့ပိုင်းခြား။
    ///
    /// အဆိုပါအငြင်းအခုံ, `mid`, string ကိုရဲ့ start ကနေ byte offset ဖြစ်သင့်သည်။
    /// ၎င်းသည် UTF-8 ကုဒ်အမှတ်၏နယ်နိမိတ်တွင်လည်းရှိရမည်။
    ///
    /// ပြန်လာသည့်အချပ်နှစ်ခုသည် string slice ၏အစမှ `mid` သို့၎င်း၊ `mid` မှ string slice ၏အဆုံးသို့သွားသည်။
    ///
    /// အစား mutable string ကိုအချပ်ရရန်, [`split_at_mut`] နည်းလမ်းကိုကြည့်ပါ။
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics `mid` တစ် UTF-8 ကုဒ်ပွိုင့်နယ်နိမိတ်အပေါ်မပါလျှင်, သို့မဟုတ်ပါကအတိတ် string ကိုအချပ်၏နောက်ဆုံးကုဒ်ပွိုင့်၏အဆုံးပါ။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary သည်ညွှန်းကိန်းကို [0၊ .len()]
        if self.is_char_boundary(mid) {
            // လုံခြုံမှု-`mid` သည် char နယ်နိမိတ်ပေါ်တွင်ရှိသည်ကိုစစ်ဆေးခဲ့သည်။
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// တစ်ဦးအညွှန်းကိန်းမှာအနှစျခုသို့တဦးတည်း mutable string ကိုအချပ် Divide ။
    ///
    /// အဆိုပါအငြင်းအခုံ, `mid`, string ကိုရဲ့ start ကနေ byte offset ဖြစ်သင့်သည်။
    /// ၎င်းသည် UTF-8 ကုဒ်အမှတ်၏နယ်နိမိတ်တွင်လည်းရှိရမည်။
    ///
    /// ပြန်လာသည့်အချပ်နှစ်ခုသည် string slice ၏အစမှ `mid` သို့၎င်း၊ `mid` မှ string slice ၏အဆုံးသို့သွားသည်။
    ///
    /// အစားမပြောင်းလဲနိုင်သောအရာများပါဝင်သော string slices များကိုရရှိရန် [`split_at`] method ကိုကြည့်ပါ။
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics `mid` တစ် UTF-8 ကုဒ်ပွိုင့်နယ်နိမိတ်အပေါ်မပါလျှင်, သို့မဟုတ်ပါကအတိတ် string ကိုအချပ်၏နောက်ဆုံးကုဒ်ပွိုင့်၏အဆုံးပါ။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary သည်ညွှန်းကိန်းကို [0၊ .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // လုံခြုံမှု-`mid` သည် char နယ်နိမိတ်ပေါ်တွင်ရှိသည်ကိုစစ်ဆေးခဲ့သည်။
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// ပြန်သည့် [`char`] ကျော်တစ်ဦးကြားမှာတစ်ဦး string ကိုအချပ်၏့။
    ///
    /// string slice မှာ UTF-8 ပါ ၀ င်တဲ့အတွက် string slice ကို [`char`] ကနေတဆင့်ကူးပြောင်းနိုင်ပါတယ်။
    /// ဤနည်းလမ်းသည်ထိုကဲ့သို့သောကြားမှာပြန်လည်ရောက်ရှိ။
    ///
    /// [`char`] က Unicode Scalar Value ကိုကိုယ်စားပြုတယ်ဆိုတာသတိရဖို့အရေးကြီးတယ်။ 'character' ဆိုတာဘာလဲ။
    ///
    /// grapheme clusters တွေကိုကြားဖြတ်ခြင်းသင်အမှန်တကယ်လိုချင်တာဖြစ်နိုင်တယ်။
    /// ဤလုပ်ဆောင်ချက်သည်အစား Rust ရဲ့စံနှုန်းစာကြည့်တိုက်, စစ်ဆေးမှုများ crates.io ပေးမထားပါ။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// သတိရပါ၊ [`char`] များသည်သင်၏အက္ခရာများနှင့် ပတ်သက်၍ သင်၏ပင်ကိုယ်သိစိတ်နှင့်မကိုက်ညီပါ
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // 'y̆' မဟုတ်ပါဘူး
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// အဆိုပါ [`char`] တစ်ဦး string ကိုအချပ်၏့, သူတို့ရဲ့ရာထူးကျော်ပြန်တစ်ဦးကြားမှာ။
    ///
    /// string slice မှာ UTF-8 ပါ ၀ င်တဲ့အတွက် string slice ကို [`char`] ကနေတဆင့်ကူးပြောင်းနိုင်ပါတယ်။
    /// ဤနည်းလမ်းသည်၎င်း [`char`] နှစ်မျိုးလုံး၏ကြားဖြတ်အဖြစ်နှင့်သူတို့၏ byte position များကိုပြန်လည်ရောက်ရှိစေသည်။
    ///
    /// ကြားမှာ tuples ဖြစ်ထွန်း။အနေအထားကပထမ၊ [`char`] ကဒုတိယပါ။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// သတိရပါ၊ [`char`] များသည်သင်၏အက္ခရာများနှင့် ပတ်သက်၍ သင်၏ပင်ကိုယ်သိစိတ်နှင့်မကိုက်ညီပါ
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // မဟုတ် (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // ဒီမှာ 3 ကိုသတိပြုပါ။ နောက်ဆုံးဇာတ်ကောင်က bytes နှစ်ခုကိုယူတယ်
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// string slice ရဲ့ bytes တွေကြားမှာကြားမှာ။
    ///
    /// string slice က bytes တစ်ခုစီပါဝင်တဲ့အတွက် string slice ကို byte bytate လုပ်နိုင်ပါတယ်။
    /// ဤနည်းလမ်းသည်ထိုကဲ့သို့သောကြားမှာပြန်လည်ရောက်ရှိ။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// whitespace အားဖြင့် string slice တစ်ခုကိုခွဲထုတ်သည်။
    ///
    /// return iterator သည် string slices ၏ sub-slices ဖြစ်သော whicespace ကိုမည်သည့်ပမာဏနှင့်မဆိုပြန်သွားပါမည်။
    ///
    ///
    /// 'Whitespace' Unicode Derived Core Property `White_Space` ၏စည်းကမ်းချက်များအရသတ်မှတ်သည်။
    /// ASCII whitespace ကိုသာအစားထိုးချင်ရင် [`split_ascii_whitespace`] ကိုသုံးပါ။
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// ကြားနေရာလွတ်အမျိုးမျိုးတို့ကိုထည့်သွင်းစဉ်းစားနေကြသည်:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// ASCII whitespace က string slice ကိုခွဲထုတ်သည်။
    ///
    /// return iterator သည် string slices ၏ sub slices များဖြစ်သော return ပြန်လိမ့်မည်။ ၎င်းသည် ASCII whitespace မည်သည့်ပမာဏနှင့်မဆိုကွဲကွာစေသည်။
    ///
    ///
    /// Unicode `Whitespace` အားဖြင့်အစားထိုးရန်အတွက် [`split_whitespace`] ကိုသုံးပါ။
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// ASCII အမျိုးမျိုးတို့ကိုထည့်သွင်းစဉ်းစားနေကြသည်ကြားနေရာလွတ်:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// string ကိုချပ်အဖြစ် string ကို၏လိုင်းများကျော်တစ်ဦးကြားမှာ။
    ///
    /// မျဉ်းကြောင်းအသစ်များကို (`\n`) သို့မဟုတ် (`\r\n`) လိုင်းဖြင့်သယ်ဆောင်သည့်ပြန်ပို့ခြင်းဖြင့်အဆုံးသတ်သည်။
    ///
    /// နောက်ဆုံးလိုင်းအဆုံးသတ် optional ကိုဖြစ်ပါတယ်။
    /// နောက်ဆုံးစာကြောင်းအဆုံးသတ်ခြင်းဖြင့်အဆုံးသတ်သော string သည်နောက်ဆုံးလိုင်းအဆုံးသတ်ခြင်းမရှိပဲအခြားတူညီသောစာကြောင်းများကဲ့သို့တူညီသောလိုင်းများကိုပြန်ပေးလိမ့်မည်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// နောက်ဆုံးလိုင်းအဆုံးသတ်ရန်မလိုအပ်ပါ။
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// တစ် ဦး string ကို၏လိုင်းများကျော်ကြားမှာ။
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// UTF-16 အဖြစ် encoded string ကိုကျော် `u16` တစ်ခုကြားမှာ Returns ။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// ပေးထားသောပုံစံကဒီ string ကိုအချပ်၏ Sub-Slice ကိုက်ညီလျှင် `true` ပြန်သွားသည်။
    ///
    /// မပါလျှင် `false` သို့ပြန်သွားသည်။
    ///
    /// [pattern] သည် `&str`, [`char`]၊ [`char`] s ၏အချပ်တစ်ခုသို့မဟုတ်ဇာတ်ကောင်ကိုက်ညီမှုရှိမရှိကိုဆုံးဖြတ်သည့် function သို့မဟုတ် closure ဖြစ်နိုင်သည်။
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// ပေးထားသောပုံစံသည်ဤ string slice ၏ရှေ့ဆက်နှင့်ကိုက်ညီပါက `true` သို့ပြန်သွားသည်။
    ///
    /// မပါလျှင် `false` သို့ပြန်သွားသည်။
    ///
    /// [pattern] သည် `&str`, [`char`]၊ [`char`] s ၏အချပ်တစ်ခုသို့မဟုတ်ဇာတ်ကောင်ကိုက်ညီမှုရှိမရှိကိုဆုံးဖြတ်သည့် function သို့မဟုတ် closure ဖြစ်နိုင်သည်။
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// ပေးထားသောပုံစံသည်ဤ string slice ၏နောက်ဆက်နှင့်ကိုက်ညီပါက `true` ကိုပြန်သွားသည်။
    ///
    /// မပါလျှင် `false` သို့ပြန်သွားသည်။
    ///
    /// [pattern] သည် `&str`, [`char`]၊ [`char`] s ၏အချပ်တစ်ခုသို့မဟုတ်ဇာတ်ကောင်ကိုက်ညီမှုရှိမရှိကိုဆုံးဖြတ်သည့် function သို့မဟုတ် closure ဖြစ်နိုင်သည်။
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// ပုံစံနှင့်ကိုက်ညီသော string string ၏ပထမအက္ခရာ၏ byte index ကို return လုပ်သည်။
    ///
    /// ပုံစံမကိုက်ညီပါက [`None`] သို့ပြန်သွားသည်။
    ///
    /// [pattern] သည် `&str`, [`char`]၊ [`char`] s ၏အချပ်တစ်ခုသို့မဟုတ်ဇာတ်ကောင်ကိုက်ညီမှုရှိမရှိကိုဆုံးဖြတ်သည့် function သို့မဟုတ် closure ဖြစ်နိုင်သည်။
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ရိုးရှင်းသောပုံစံများ-
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Point-free style နှင့် closures ကို အသုံးပြု၍ ပိုမိုရှုပ်ထွေးသောပုံစံများ-
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// ပုံစံကိုရှာမရ
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// ဒီ string ကိုအချပ်အတွက်ပုံစံ၏ rightmost ပွဲစဉ်၏ပထမ ဦး ဆုံးဇာတ်ကောင်များအတွက် byte အညွှန်းကိန်းပြန်သွားသည်။
    ///
    /// ပုံစံမကိုက်ညီပါက [`None`] သို့ပြန်သွားသည်။
    ///
    /// [pattern] သည် `&str`, [`char`]၊ [`char`] s ၏အချပ်တစ်ခုသို့မဟုတ်ဇာတ်ကောင်ကိုက်ညီမှုရှိမရှိကိုဆုံးဖြတ်သည့် function သို့မဟုတ် closure ဖြစ်နိုင်သည်။
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ရိုးရှင်းသောပုံစံများ-
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// ပိုမိုရှုပ်ထွေးသောပုံစံများဖြင့်ပိတ်ပစ်နိုင်သည်။
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// ပုံစံကိုရှာမရ
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// ဒီ string slice ရဲ့ substrings ကိုကျော်ပြီးကြားခံတစ်ခု။
    ///
    /// [pattern] သည် `&str`, [`char`]၊ [`char`] s ၏အချပ်တစ်ခုသို့မဟုတ်ဇာတ်ကောင်ကိုက်ညီမှုရှိမရှိကိုဆုံးဖြတ်သည့် function သို့မဟုတ် closure ဖြစ်နိုင်သည်။
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ကြားမှာအပြုအမူ
    ///
    /// အကယ်၍ ပုံစံသည်နောက်ပြန်ရှာဖွေမှုကိုခွင့်ပြုပြီး forward/reverse ရှာဖွေမှုသည်တူညီသောဒြပ်စင်များဖြစ်ထွန်းလျှင်ပြန်လာသောကြားမှာ [`DoubleEndedIterator`] ဖြစ်လိမ့်မည်။
    /// ဥပမာ [`char`] အတွက်မဟုတ်ပေမယ့် `&str` အတွက်တော့မဟုတ်ပါဘူး။
    ///
    /// ပုံစံကတော့ပြောင်းပြန်ရှာဖွေရေးခွင့်ပြုပေမယ့်သူ့ရဲ့ရလဒ်တွေကိုတစ်ဦးရှေ့ကိုရှာဖွေရေးကှာခွားစေခြင်းငှါ, လျှင်, [`rsplit`] နည်းလမ်းကိုသုံးနိုင်ပါတယ်။
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// ရိုးရှင်းသောပုံစံများ-
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// အကယ်၍ ပုံစံသည်အက္ခရာအချပ်တစ်ခုဖြစ်ပါကအက္ခရာတစ်စုံတစ်ရာ၏အဖြစ်အပျက်တစ်ခုစီကိုခွဲပါ။
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// ပိုမိုရှုပ်ထွေးသောပုံစံ၊
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// အကယ်၍ string တစ်ခုတွင်တဆက်တည်းသီးခြားစီပေါင်းများစွာပါ ၀ င်ပါက၊
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// တဆက်တည်း Separator အချည်းနှီးသော string ကိုအားဖြင့်ကွဲကွာနေကြသည်။
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// string တစ်ခု၏အစသို့မဟုတ်အဆုံးတွင် Separator များသည်အချည်းနှီးသောကြိုးများဖြင့်အိမ်နီးချင်းများဖြစ်သည်။
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// အချည်းနှီးသော string ကို separator အနေဖြင့်အသုံးပြုသောအခါ၎င်းသည် string ၏အစနှင့်အဆုံးနှင့်အတူ string အတွင်းရှိစာလုံးတိုင်းကိုခွဲထုတ်သည်။
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// whitespace ကို separator အဖြစ်အသုံးပြုသည့်အခါတစ်ဆက်တည်း Separator များသည်အံ့အားသင့်ဖွယ်ကောင်းသောအပြုအမူများကိုဖြစ်ပေါ်စေသည်။ဒီ code မှန်ကန်သောဖြစ်ပါသည်:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// _not_ ကသင့်ကိုပေးသည်-
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// ဒီအပြုအမူအတွက် [`split_whitespace`] ကိုသုံးပါ။
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// ဒီ string slice ရဲ့ substrings ကိုကျော်ပြီးကြားခံတစ်ခု။
    /// `split` မှထုတ်လုပ်သည့်ကြားမှာကွဲပြားမှုကြောင့် `split_inclusive` သည်လိုက်ဖက်သောအပိုင်းကို substring ၏ Terminator အဖြစ်ထားခဲ့သည်။
    ///
    ///
    /// [pattern] သည် `&str`, [`char`]၊ [`char`] s ၏အချပ်တစ်ခုသို့မဟုတ်ဇာတ်ကောင်ကိုက်ညီမှုရှိမရှိကိုဆုံးဖြတ်သည့် function သို့မဟုတ် closure ဖြစ်နိုင်သည်။
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// အကယ်၍ string ၏နောက်ဆုံး element ကိုလိုက်ဖက်ပါက၎င်း element သည်ရှေ့ substring ၏ terminator အဖြစ်သတ်မှတ်လိမ့်မည်။
    /// ၎င်း substring သည်ကြားမှာမှပြန်လာတဲ့နောက်ဆုံးပစ္စည်းဖြစ်သည်။
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// ပေးထားသော string slice ရဲ့ substrings ကိုကျော်ပြီးကြားမှာတစ်ခု၊ ပုံစံနှင့်လိုက်ဖက်ပြီးအပြန်အလှန်လိုက်လျောညီထွေဖြစ်အောင်စာလုံးများဖြင့်ခွဲခြားထားတယ်။
    ///
    /// [pattern] သည် `&str`, [`char`]၊ [`char`] s ၏အချပ်တစ်ခုသို့မဟုတ်ဇာတ်ကောင်ကိုက်ညီမှုရှိမရှိကိုဆုံးဖြတ်သည့် function သို့မဟုတ် closure ဖြစ်နိုင်သည်။
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ကြားမှာအပြုအမူ
    ///
    /// ပြန်လာသောကြားမှာပုံစံသည်နောက်ပြန်ရှာဖွေမှုကိုထောက်ခံရန်လိုအပ်ပြီး၊ အကယ်၍ forward/reverse ရှာဖွေမှုသည်တူညီသောဒြပ်စင်များထုတ်ပေးလျှင် [`DoubleEndedIterator`] ဖြစ်လိမ့်မည်။
    ///
    ///
    /// ရှေ့မှောက်ကြားခြင်းအတွက် [`split`] နည်းလမ်းကိုအသုံးပြုနိုင်သည်။
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// ရိုးရှင်းသောပုံစံများ-
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// ပိုမိုရှုပ်ထွေးသောပုံစံ၊
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// ပေးထားသော string slice ရဲ့ substrings ကိုကျော်ပြီးကြားခံတစ်ခု၊ ပုံစံတစ်ခုနဲ့လိုက်ဖက်တဲ့အက္ခရာများနဲ့ကွဲကွာ။
    ///
    /// [pattern] သည် `&str`, [`char`]၊ [`char`] s ၏အချပ်တစ်ခုသို့မဟုတ်ဇာတ်ကောင်ကိုက်ညီမှုရှိမရှိကိုဆုံးဖြတ်သည့် function သို့မဟုတ် closure ဖြစ်နိုင်သည်။
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// [`split`] နှင့်ညီမျှသည်။ ကျန်သည့် substring သည်ဗလာလျှင်ကျော်သွားသည် မှလွဲ၍ ဖြစ်သည်။
    ///
    /// [`split`]: str::split
    ///
    /// ဤနည်းလမ်းကိုတစ်ပုံစံအားဖြင့်မဟုတ်ဘဲ _separated_ ထက် _terminated_ ကြောင်း string ကိုဒေတာအတွက်သုံးနိုင်တယ်။
    ///
    /// # ကြားမှာအပြုအမူ
    ///
    /// အကယ်၍ ပုံစံသည်နောက်ပြန်ရှာဖွေမှုကိုခွင့်ပြုပြီး forward/reverse ရှာဖွေမှုသည်တူညီသောဒြပ်စင်များဖြစ်ထွန်းလျှင်ပြန်လာသောကြားမှာ [`DoubleEndedIterator`] ဖြစ်လိမ့်မည်။
    /// ဥပမာ [`char`] အတွက်မဟုတ်ပေမယ့် `&str` အတွက်တော့မဟုတ်ပါဘူး။
    ///
    /// အကယ်၍ ပုံစံသည်ပြောင်းပြန်ရှာဖွေမှုကိုခွင့်ပြုသော်လည်းရလဒ်များသည်ရှေ့ရှာဖွေမှုနှင့်ကွဲပြားနိုင်သည်ဆိုလျှင် [`rsplit_terminator`] နည်းလမ်းကိုအသုံးပြုနိုင်သည်။
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// `self` ၏ substrings ကျော်ကြားမှာတစ်ခု၊ ပုံစံနှင့်လိုက်ဖက်ပြီးအပြန်အလှန်အားဖြင့်လိုက်လျောညီထွေဖြစ်အောင်အက္ခရာများဖြင့်ခွဲခြားထားသည်။
    ///
    /// [pattern] သည် `&str`, [`char`]၊ [`char`] s ၏အချပ်တစ်ခုသို့မဟုတ်ဇာတ်ကောင်ကိုက်ညီမှုရှိမရှိကိုဆုံးဖြတ်သည့် function သို့မဟုတ် closure ဖြစ်နိုင်သည်။
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// [`split`] နှင့်ညီမျှသည်။ ကျန်သည့် substring သည်ဗလာလျှင်ကျော်သွားသည် မှလွဲ၍ ဖြစ်သည်။
    ///
    /// [`split`]: str::split
    ///
    /// ဤနည်းလမ်းကိုတစ်ပုံစံအားဖြင့်မဟုတ်ဘဲ _separated_ ထက် _terminated_ ကြောင်း string ကိုဒေတာအတွက်သုံးနိုင်တယ်။
    ///
    /// # ကြားမှာအပြုအမူ
    ///
    /// ပြန်လာသော Iterator သည်ပုံစံကိုပြောင်းပြန်ရှာဖွေရန်လိုအပ်သည်။ အကယ်၍ forward/reverse ရှာဖွေမှုသည်တူညီသောဒြပ်စင်များထွက်ပေါ်လာပါကနှစ်ဆတိုးလိမ့်မည်။
    ///
    ///
    /// ရှေ့မှောက်ကြားခြင်းအတွက် [`split_terminator`] နည်းလမ်းကိုအသုံးပြုနိုင်သည်။
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// ပေးထားသော string slice ရဲ့ substrings ကိုကျော်ပြီးကြားမှာတစ်ခုသည်ပုံစံတစ်ခုနဲ့ကွဲပြီး `n` items တွေကိုပြန်သွားဖို့ကန့်သတ်ထားတယ်။
    ///
    /// အကယ်၍ `n` substrings ကိုပြန်ရောက်လျှင်၊ နောက်ဆုံး substring (``n`th substring) '၏ကျန်ရှိသော string တွင်ပါဝင်လိမ့်မည်။
    ///
    /// [pattern] သည် `&str`, [`char`]၊ [`char`] s ၏အချပ်တစ်ခုသို့မဟုတ်ဇာတ်ကောင်ကိုက်ညီမှုရှိမရှိကိုဆုံးဖြတ်သည့် function သို့မဟုတ် closure ဖြစ်နိုင်သည်။
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ကြားမှာအပြုအမူ
    ///
    /// ပြန်လာသော Iterator သည်နှစ်ဆတိုးမည်မဟုတ်ပါ၊ အဘယ်ကြောင့်ဆိုသော်၎င်းသည် support လုပ်ရန်မတတ်နိုင်သောကြောင့်ဖြစ်သည်။
    ///
    /// ပုံစံသည်ပြောင်းပြန်ရှာဖွေမှုကိုခွင့်ပြုပါက [`rsplitn`] နည်းလမ်းကိုအသုံးပြုနိုင်သည်။
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// ရိုးရှင်းသောပုံစံများ-
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// ပိုမိုရှုပ်ထွေးသောပုံစံ၊
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// ဒီ string slice ရဲ့ substrings ကိုကျော်ပြီးကြားခံတစ်ခုဖြစ်ပါတယ်။ string ရဲ့အဆုံးကနေစပြီးပုံစံတစ်ခုနဲ့ကွဲကွာသွားတယ်။ `n` items အများစုမှာ return ပြန်လုပ်တာကိုကန့်သတ်တယ်။
    ///
    ///
    /// အကယ်၍ `n` substrings ကိုပြန်ရောက်လျှင်၊ နောက်ဆုံး substring (``n`th substring) '၏ကျန်ရှိသော string တွင်ပါဝင်လိမ့်မည်။
    ///
    /// [pattern] သည် `&str`, [`char`]၊ [`char`] s ၏အချပ်တစ်ခုသို့မဟုတ်ဇာတ်ကောင်ကိုက်ညီမှုရှိမရှိကိုဆုံးဖြတ်သည့် function သို့မဟုတ် closure ဖြစ်နိုင်သည်။
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ကြားမှာအပြုအမူ
    ///
    /// ပြန်လာသော Iterator သည်နှစ်ဆတိုးမည်မဟုတ်ပါ၊ အဘယ်ကြောင့်ဆိုသော်၎င်းသည် support လုပ်ရန်မတတ်နိုင်သောကြောင့်ဖြစ်သည်။
    ///
    /// ရှေ့မှကွဲရန် [`splitn`] နည်းလမ်းကိုအသုံးပြုနိုင်သည်။
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// ရိုးရှင်းသောပုံစံများ-
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// ပိုမိုရှုပ်ထွေးသောပုံစံ၊
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// သတ်မှတ်ထားသော delimiter ၏ပထမဆုံးဖြစ်ပျက်မှုအပေါ် string ကိုခွဲခြားပြီး delimiter မတိုင်မီ delimiter နှင့် suffix မတိုင်မီ prefix ကို return လုပ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// အဆိုပါသတ်မှတ်ထားတဲ့အနားသတ်မျဉ်း၏နောက်ဆုံးဖြစ်ပျက်မှုအပေါ် string ကိုကိုစူးနှင့်ပြန်အနားသတ်မျဉ်းပြီးနောက်အနားသတ်မျဉ်းများနှင့်နောက်ဆက်မတိုင်မီ prefix ။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// ပေးထားသော string ကိုအချပ်အတွင်းပုံစံ၏ disjoint ပွဲစဉ်ကျော်တစ်ခုကြားမှာ။
    ///
    /// [pattern] သည် `&str`, [`char`]၊ [`char`] s ၏အချပ်တစ်ခုသို့မဟုတ်ဇာတ်ကောင်ကိုက်ညီမှုရှိမရှိကိုဆုံးဖြတ်သည့် function သို့မဟုတ် closure ဖြစ်နိုင်သည်။
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ကြားမှာအပြုအမူ
    ///
    /// အကယ်၍ ပုံစံသည်နောက်ပြန်ရှာဖွေမှုကိုခွင့်ပြုပြီး forward/reverse ရှာဖွေမှုသည်တူညီသောဒြပ်စင်များဖြစ်ထွန်းလျှင်ပြန်လာသောကြားမှာ [`DoubleEndedIterator`] ဖြစ်လိမ့်မည်။
    /// ဥပမာ [`char`] အတွက်မဟုတ်ပေမယ့် `&str` အတွက်တော့မဟုတ်ပါဘူး။
    ///
    /// အကယ်၍ ပုံစံသည်ပြောင်းပြန်ရှာဖွေမှုကိုခွင့်ပြုသော်လည်းရလဒ်များသည်ရှေ့ရှာဖွေမှုနှင့်ကွဲပြားနိုင်သည်ဆိုလျှင် [`rmatches`] နည်းလမ်းကိုအသုံးပြုနိုင်သည်။
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// ပြောင်းပြန်နိုင်ရန်အတွက်လြှော့ဒီ string ကိုအချပ်အတွင်းပုံစံ၏ disjoint ပွဲစဉ်ကျော်တစ်ခုကြားမှာ။
    ///
    /// [pattern] သည် `&str`, [`char`]၊ [`char`] s ၏အချပ်တစ်ခုသို့မဟုတ်ဇာတ်ကောင်ကိုက်ညီမှုရှိမရှိကိုဆုံးဖြတ်သည့် function သို့မဟုတ် closure ဖြစ်နိုင်သည်။
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ကြားမှာအပြုအမူ
    ///
    /// ပြန်လာသောကြားမှာပုံစံသည်နောက်ပြန်ရှာဖွေမှုကိုထောက်ခံရန်လိုအပ်ပြီး၊ အကယ်၍ forward/reverse ရှာဖွေမှုသည်တူညီသောဒြပ်စင်များထုတ်ပေးလျှင် [`DoubleEndedIterator`] ဖြစ်လိမ့်မည်။
    ///
    ///
    /// ရှေ့မှောက်ကြားခြင်းအတွက် [`matches`] နည်းလမ်းကိုအသုံးပြုနိုင်သည်။
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// ဒီ string ကိုအချပ်အတွင်းပုံစံတစ်ခု၏ disjoint ကိုက်ညီမှုနှင့်ပွဲစဉ်မှစတင်သောအညွှန်းကိန်းကိုကျော်ကြားမှာ။
    ///
    /// ထိုထပ်တူကျသည့် `self` အတွင်းရှိ `pat` ၏ပွဲစဉ်များအတွက်၊ ပထမပွဲနှင့်သက်ဆိုင်သည့်ညွှန်းကိန်းများသာပြန်လာသည်။
    ///
    /// [pattern] သည် `&str`, [`char`]၊ [`char`] s ၏အချပ်တစ်ခုသို့မဟုတ်ဇာတ်ကောင်ကိုက်ညီမှုရှိမရှိကိုဆုံးဖြတ်သည့် function သို့မဟုတ် closure ဖြစ်နိုင်သည်။
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ကြားမှာအပြုအမူ
    ///
    /// အကယ်၍ ပုံစံသည်နောက်ပြန်ရှာဖွေမှုကိုခွင့်ပြုပြီး forward/reverse ရှာဖွေမှုသည်တူညီသောဒြပ်စင်များဖြစ်ထွန်းလျှင်ပြန်လာသောကြားမှာ [`DoubleEndedIterator`] ဖြစ်လိမ့်မည်။
    /// ဥပမာ [`char`] အတွက်မဟုတ်ပေမယ့် `&str` အတွက်တော့မဟုတ်ပါဘူး။
    ///
    /// အကယ်၍ ပုံစံသည်ပြောင်းပြန်ရှာဖွေမှုကိုခွင့်ပြုသော်လည်းရလဒ်များသည်ရှေ့ရှာဖွေမှုနှင့်ကွဲပြားနိုင်သည်ဆိုလျှင် [`rmatch_indices`] နည်းလမ်းကိုအသုံးပြုနိုင်သည်။
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // ပထမ ဦး ဆုံး `aba` သာ
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// `self` အတွင်းရှိပုံစံ၏ disjoint match ကျော်ကြားမှာ, ပွဲစဉ်၏အညွှန်းကိန်းနှင့်အတူပြောင်းပြန်နိုင်ရန်အတွက်လြှော့။
    ///
    /// အဆိုပါထပ်တူဖြစ်သော `self` အတွင်းရှိ `pat` ၏ပွဲစဉ်များအတွက်၊ နောက်ဆုံးပွဲနှင့်သက်ဆိုင်သည့်ညွှန်းကိန်းများသာပြန်လာသည်။
    ///
    /// [pattern] သည် `&str`, [`char`]၊ [`char`] s ၏အချပ်တစ်ခုသို့မဟုတ်ဇာတ်ကောင်ကိုက်ညီမှုရှိမရှိကိုဆုံးဖြတ်သည့် function သို့မဟုတ် closure ဖြစ်နိုင်သည်။
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ကြားမှာအပြုအမူ
    ///
    /// ပြန်လာသောကြားမှာပုံစံသည်နောက်ပြန်ရှာဖွေမှုကိုထောက်ခံရန်လိုအပ်ပြီး၊ အကယ်၍ forward/reverse ရှာဖွေမှုသည်တူညီသောဒြပ်စင်များထုတ်ပေးလျှင် [`DoubleEndedIterator`] ဖြစ်လိမ့်မည်။
    ///
    ///
    /// အိမ်ရှေ့ကနေ iterating အဘို့, [`match_indices`] နည်းလမ်းကိုသုံးနိုင်ပါတယ်။
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // သာနောက်ဆုံး `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// whitspace ကိုဖယ်ထုတ်ပြီး ဦး ဆောင်ကြိုးကိုင်ပြီး string slice ကိုပြန်သွားသည်။
    ///
    /// 'Whitespace' Unicode Derived Core Property `White_Space` ၏စည်းကမ်းချက်များအရသတ်မှတ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// ဦး ဆောင် whitespace ဖယ်ရှားနှင့်အတူ string ကိုအချပ်ပြန်သွားသည်။
    ///
    /// 'Whitespace' Unicode Derived Core Property `White_Space` ၏စည်းကမ်းချက်များအရသတ်မှတ်သည်။
    ///
    /// # စာသား ဦး တည်ချက်
    ///
    /// string တစ်ခုက bytes ဆက်တိုက်ဖြစ်တယ်။
    /// `start` ဒီအခြေအနေတွင်ကြောင်း byte string ကို၏ပထမ ဦး ဆုံးအနေအထားကိုဆိုလိုသည်;အင်္ဂလိပ် (သို့) ရုရှားလိုဘယ်ဘက်မှညာဘက်သုံးဘာသာစကားအတွက်၊ ဒီဟာဘယ်ဘက်ခြမ်းပါလိမ့်မယ်၊ အာရဗီ (သို့) ဟီဘရူးလိုညာဘက်ဘယ်ဘက်ဘာသာစကားအတွက်၊ ဒီဟာကမှန်တယ်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// whitespace ကိုဖယ်ထုတ်ပြီး string slice ကိုပြန်သွားသည်။
    ///
    /// 'Whitespace' Unicode Derived Core Property `White_Space` ၏စည်းကမ်းချက်များအရသတ်မှတ်သည်။
    ///
    /// # စာသား ဦး တည်ချက်
    ///
    /// string တစ်ခုက bytes ဆက်တိုက်ဖြစ်တယ်။
    /// `end` ဒီအခြေအနေတွင်ကြောင်း byte string ကို၏နောက်ဆုံးအနေအထားကိုဆိုလိုသည်;အင်္ဂလိပ် (သို့) ရုရှားလိုလက်ဝဲမှလက်ယာဘာသာစကားအတွက်၊ ဒါကညာဘက်၊ အာရဗ်သို့မဟုတ်ဟီဘရူးလိုညာဘက်ဘယ်ဘက်ဘာသာစကားအတွက်၊ ဒီဘယ်ဘက်ခြမ်းပါ။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// ဦး ဆောင် whitespace ဖယ်ရှားနှင့်အတူ string ကိုအချပ်ပြန်သွားသည်။
    ///
    /// 'Whitespace' Unicode Derived Core Property `White_Space` ၏စည်းကမ်းချက်များအရသတ်မှတ်သည်။
    ///
    /// # စာသား ဦး တည်ချက်
    ///
    /// string တစ်ခုက bytes ဆက်တိုက်ဖြစ်တယ်။
    /// 'Left' ဒီအခြေအနေတွင်ကြောင်း byte string ကို၏ပထမ ဦး ဆုံးအနေအထားကိုဆိုလိုသည်;'left to right' ထက် 'right to left' ဖြစ်သောအာရဗီသို့မဟုတ်ဟီဘရူးလိုဘာသာစကားအတွက်၎င်းသည်ဘယ်ဘက်မဟုတ်ဘဲ _right_ ဘက်ဖြစ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// whitespace ကိုဖယ်ထုတ်ပြီး string slice ကိုပြန်သွားသည်။
    ///
    /// 'Whitespace' Unicode Derived Core Property `White_Space` ၏စည်းကမ်းချက်များအရသတ်မှတ်သည်။
    ///
    /// # စာသား ဦး တည်ချက်
    ///
    /// string တစ်ခုက bytes ဆက်တိုက်ဖြစ်တယ်။
    /// 'Right' ဒီအခြေအနေတွင်ကြောင်း byte string ကို၏နောက်ဆုံးအနေအထားကိုဆိုလိုသည်;အာရပ်သို့မဟုတ်ဟီဘရူးဘာသာစကားသည် 'left to right' ထက် 'left to right' မဟုတ်သော 'left to right' သည်၎င်းသည် _left_ ဘက်ဖြစ်သော်လည်းညာဘက်မဟုတ်ပါ။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// ထပ်ခါတလဲလဲဖယ်ရှားထားသောပုံစံနှင့်ကိုက်ညီသည့်ရှေ့ဆက်များနှင့်နောက်ဆက်များအားလုံးနှင့်အတူ string slice ကိုပြန်သွားသည်။
    ///
    /// [pattern] သည် [`char`]၊ [`char`] ၏အချပ်တစ်ခုသို့မဟုတ်ဇာတ်ကောင်တစ်ခုနှင့်ကိုက်ညီမှုရှိမရှိကိုဆုံးဖြတ်သည့် function တစ်ခုသို့မဟုတ်ပိတ်ပစ်မှုများဖြစ်နိုင်သည်။
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ရိုးရှင်းသောပုံစံများ-
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// ပိုမိုရှုပ်ထွေးသောပုံစံ၊
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // အစောဆုံးလူသိများသည့်ပွဲစဉ်ကိုသတိရပါ
            // နောက်ဆုံးပွဲဟာမတူပါဘူး
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // လုံခြုံမှု-`Searcher` သည်မှန်ကန်သောညွှန်းကိန်းများပြန်လာသည်ဟုလူသိများသည်။
        unsafe { self.get_unchecked(i..j) }
    }

    /// ထပ်ခါတလဲလဲဖယ်ရှားထားသောပုံစံနှင့်ကိုက်ညီသောရှေ့ဆက်အားလုံးနှင့် string string ကိုပြန်သွားသည်။
    ///
    /// [pattern] သည် `&str`, [`char`]၊ [`char`] s ၏အချပ်တစ်ခုသို့မဟုတ်ဇာတ်ကောင်ကိုက်ညီမှုရှိမရှိကိုဆုံးဖြတ်သည့် function သို့မဟုတ် closure ဖြစ်နိုင်သည်။
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # စာသား ဦး တည်ချက်
    ///
    /// string တစ်ခုက bytes ဆက်တိုက်ဖြစ်တယ်။
    /// `start` ဒီအခြေအနေတွင်ကြောင်း byte string ကို၏ပထမ ဦး ဆုံးအနေအထားကိုဆိုလိုသည်;အင်္ဂလိပ် (သို့) ရုရှားလိုဘယ်ဘက်မှညာဘက်သုံးဘာသာစကားအတွက်၊ ဒီဟာဘယ်ဘက်ခြမ်းပါလိမ့်မယ်၊ အာရဗီ (သို့) ဟီဘရူးလိုညာဘက်ဘယ်ဘက်ဘာသာစကားအတွက်၊ ဒီဟာကမှန်တယ်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // လုံခြုံမှု-`Searcher` သည်မှန်ကန်သောညွှန်းကိန်းများပြန်လာသည်ဟုလူသိများသည်။
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// ရှေ့ဆက်ကိုဖယ်ထားသော string အချပ်ကိုပြန်သွားသည်။
    ///
    /// အကယ်၍ string သည် `prefix` ပုံစံနှင့်စတင်သည်ဆိုလျှင်၊ `Some` နှင့်ပတ်ရစ်သည့်ရှေ့ဆက်နောက်တွင် substring ကိုပြန်လည်ပေးပို့မည်။
    /// `trim_start_matches` မတူဘဲ, ဒီနည်းလမ်းကိုတိတိကျကျတစ်ချိန်ကရှေ့ဆက်ဖယ်ရှားပေးပါသည်။
    ///
    /// အကယ်၍ string သည် `prefix` နှင့်မစပါက `None` ကိုပြန်ပို့သည်။
    ///
    /// [pattern] သည် `&str`, [`char`]၊ [`char`] s ၏အချပ်တစ်ခုသို့မဟုတ်ဇာတ်ကောင်ကိုက်ညီမှုရှိမရှိကိုဆုံးဖြတ်သည့် function သို့မဟုတ် closure ဖြစ်နိုင်သည်။
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// ဖယ်ထားသောနောက်ဆက်နှင့်အတူ string အချပ်ကိုပြန်သွားသည်။
    ///
    /// အကယ်၍ string သည် `suffix` ပုံစံနှင့်အဆုံးသတ်သွားလျှင်၊ `Some` နှင့်ပတ်ရစ်သည့်နောက်ဆက်နောက်ဆက်မတိုင်မီ substring ကိုပြန်ပို့သည်။
    /// `trim_end_matches` နှင့်မတူဘဲဤနည်းလမ်းသည်နောက်ဆက်အားအတိအကျဖယ်ရှားသည်။
    ///
    /// string ကို `suffix` နှင့်အတူအဆုံးသတ်မထားဘူးဆိုရင်, `None` ပြန်လာ။
    ///
    /// [pattern] သည် `&str`, [`char`]၊ [`char`] s ၏အချပ်တစ်ခုသို့မဟုတ်ဇာတ်ကောင်ကိုက်ညီမှုရှိမရှိကိုဆုံးဖြတ်သည့် function သို့မဟုတ် closure ဖြစ်နိုင်သည်။
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// ထပ်ခါတလဲလဲဖယ်ရှားထားသောပုံစံနှင့်လိုက်ဖက်သည့်နောက်ဆက်များအားလုံးနှင့် string slice ကိုပြန်ပို့သည်။
    ///
    /// [pattern] သည် `&str`, [`char`]၊ [`char`] s ၏အချပ်တစ်ခုသို့မဟုတ်ဇာတ်ကောင်ကိုက်ညီမှုရှိမရှိကိုဆုံးဖြတ်သည့် function သို့မဟုတ် closure ဖြစ်နိုင်သည်။
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # စာသား ဦး တည်ချက်
    ///
    /// string တစ်ခုက bytes ဆက်တိုက်ဖြစ်တယ်။
    /// `end` ဒီအခြေအနေတွင်ကြောင်း byte string ကို၏နောက်ဆုံးအနေအထားကိုဆိုလိုသည်;အင်္ဂလိပ် (သို့) ရုရှားလိုလက်ဝဲမှလက်ယာဘာသာစကားအတွက်၊ ဒါကညာဘက်၊ အာရဗ်သို့မဟုတ်ဟီဘရူးလိုညာဘက်ဘယ်ဘက်ဘာသာစကားအတွက်၊ ဒီဘယ်ဘက်ခြမ်းပါ။
    ///
    ///
    /// # Examples
    ///
    /// ရိုးရှင်းသောပုံစံများ-
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// ပိုမိုရှုပ်ထွေးသောပုံစံ၊
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // လုံခြုံမှု-`Searcher` သည်မှန်ကန်သောညွှန်းကိန်းများပြန်လာသည်ဟုလူသိများသည်။
        unsafe { self.get_unchecked(0..j) }
    }

    /// ထပ်ခါတလဲလဲဖယ်ရှားထားသောပုံစံနှင့်ကိုက်ညီသောရှေ့ဆက်အားလုံးနှင့် string string ကိုပြန်သွားသည်။
    ///
    /// [pattern] သည် `&str`, [`char`]၊ [`char`] s ၏အချပ်တစ်ခုသို့မဟုတ်ဇာတ်ကောင်ကိုက်ညီမှုရှိမရှိကိုဆုံးဖြတ်သည့် function သို့မဟုတ် closure ဖြစ်နိုင်သည်။
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # စာသား ဦး တည်ချက်
    ///
    /// string တစ်ခုက bytes ဆက်တိုက်ဖြစ်တယ်။
    /// 'Left' ဒီအခြေအနေတွင်ကြောင်း byte string ကို၏ပထမ ဦး ဆုံးအနေအထားကိုဆိုလိုသည်;'left to right' ထက် 'right to left' ဖြစ်သောအာရဗီသို့မဟုတ်ဟီဘရူးလိုဘာသာစကားအတွက်၎င်းသည်ဘယ်ဘက်မဟုတ်ဘဲ _right_ ဘက်ဖြစ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// ထပ်ခါတလဲလဲဖယ်ရှားထားသောပုံစံနှင့်လိုက်ဖက်သည့်နောက်ဆက်များအားလုံးနှင့် string slice ကိုပြန်ပို့သည်။
    ///
    /// [pattern] သည် `&str`, [`char`]၊ [`char`] s ၏အချပ်တစ်ခုသို့မဟုတ်ဇာတ်ကောင်ကိုက်ညီမှုရှိမရှိကိုဆုံးဖြတ်သည့် function သို့မဟုတ် closure ဖြစ်နိုင်သည်။
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # စာသား ဦး တည်ချက်
    ///
    /// string တစ်ခုက bytes ဆက်တိုက်ဖြစ်တယ်။
    /// 'Right' ဒီအခြေအနေတွင်ကြောင်း byte string ကို၏နောက်ဆုံးအနေအထားကိုဆိုလိုသည်;အာရပ်သို့မဟုတ်ဟီဘရူးဘာသာစကားသည် 'left to right' ထက် 'left to right' မဟုတ်သော 'left to right' သည်၎င်းသည် _left_ ဘက်ဖြစ်သော်လည်းညာဘက်မဟုတ်ပါ။
    ///
    ///
    /// # Examples
    ///
    /// ရိုးရှင်းသောပုံစံများ-
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// ပိုမိုရှုပ်ထွေးသောပုံစံ၊
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// ဒီ string ကိုအချပ်ကိုအခြားအမျိုးအစားသို့ခွဲခြမ်း။
    ///
    /// အဘယ်ကြောင့်ဆိုသော် `parse` သည်အလွန်ယေဘူယျဖြစ်သောကြောင့်၎င်းသည် type inference နှင့်ပြproblemsနာဖြစ်စေနိုင်သည်။
    /// ထို့ကြောင့် `parse` သည် 'turbofish' ဟုလူသိများသော syntax ကိုသင်တွေ့ရမည့်အကြိမ်အနည်းငယ်ထဲကတစ်ခုဖြစ်သည်။ `::<>`.
    ///
    /// ၎င်းသည်သင်ရှာဖွေရန်ကြိုးစားနေသည့်အမျိုးအစားကိုတိကျစွာနားလည်ရန်ကူညီပေးသည်။
    ///
    /// `parse` [`FromStr`] trait ကိုအကောင်အထည်ဖော်သည့်မည်သည့်အမျိုးအစားကိုမဆိုဆန်းစစ်နိုင်သည်။
    ///

    /// # Errors
    ///
    /// အကယ်၍ ဤ string slice ကိုလိုချင်သောအမျိုးအစားသို့ ခွဲ၍ မရပါက [`Err`] ကိုပြန်ပို့ပါမည်။
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// `four` ကိုမှတ်ချက်ပေးခြင်းအစား 'turbofish' ကိုအသုံးပြုခြင်း
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// ဆန်းစစ်ရန်ပျက်ကွက်သည်
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// ဒီ string ထဲမှာပါတဲ့အက္ခရာအားလုံးဟာ ASCII အကွာအဝေးမှာရှိမရှိစစ်ဆေးသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // ဤနေရာတွင် byte တစ်ခုချင်းစီကိုဤနေရာတွင် character အဖြစ်သတ်မှတ်နိုင်သည်။ multibyte အက္ခရာများအားလုံးသည် ascii အကွာအဝေးတွင်မရှိသော byte တစ်ခုဖြင့်စတင်သည်။
        //
        //
        self.as_bytes().is_ascii()
    }

    /// ကြိုးနှစ်ချောင်းဟာ ASCII case-insensitive match တစ်ခုဖြစ်ကြောင်းစစ်ဆေးသည်။
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` နှင့်အတူတူပင်၊ သို့သော်ယာယီအားခွဲဝေချခြင်းနှင့်ကူးယူခြင်းမပြုလုပ်ရန်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// ၎င်း string ကို ASCII စာလုံးအကြီးနှင့်ညီမျှသောနေရာတွင်ပြောင်းသည်။
    ///
    /// ASCII အက္ခရာများ 'a' မှ 'z' အက္ခရာများကို 'A' သို့ 'Z' သို့ဆက်စပ်ထားသည်၊ သို့သော် ASCII မဟုတ်သောအက္ခရာများမှာမပြောင်းလဲပါ။
    ///
    /// လက်ရှိတန်ဖိုးကိုပြုပြင်မွမ်းမံခြင်းမပြုဘဲ uppercased value အသစ်တစ်ခုကို return ပြန်ရန် [`to_ascii_uppercase()`] ကိုသုံးပါ။
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // လုံခြုံစိတ်ချမှု-လုံခြုံစိတ်ချရမှုအနေဖြင့်ကျွန်ုပ်တို့သည်ပုံစံတစ်မျိုးတည်းဖြင့်အမျိုးအစားနှစ်မျိုးကိုကူးပြောင်းနိုင်သောကြောင့်ဖြစ်သည်။
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// ဒီ string ကိုသူ့ရဲ့ ASCII စာလုံးအသေးညီမျှမှုကို In-place ပြောင်းပေးသည်။
    ///
    /// ASCII အက္ခရာများ 'A' မှ 'Z' အက္ခရာများကို 'a' နှင့် 'z' သို့ဆက်စပ်ထားသည်။ သို့သော် ASCII မဟုတ်သောအက္ခရာများမှာမပြောင်းလဲပါ။
    ///
    /// လက်ရှိတဦးတည်းပြုပြင်မွမ်းမံခြင်းမရှိဘဲအသစ်တခုအသေးတန်ဖိုးကိုပြန်သွား [`to_ascii_lowercase()`] ကိုအသုံးပြုပါ။
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // လုံခြုံစိတ်ချမှု-လုံခြုံစိတ်ချရမှုအနေဖြင့်ကျွန်ုပ်တို့သည်ပုံစံတစ်မျိုးတည်းဖြင့်အမျိုးအစားနှစ်မျိုးကိုကူးပြောင်းနိုင်သောကြောင့်ဖြစ်သည်။
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// `self` ရှိ char တစ်ခုစီမှလွတ်မြောက်စေသည့်ကြားဖြတ်မှုကိုပြန်ပို့ပါ။
    ///
    ///
    /// Note: string ကိုစတင်ဖို့သာတိုးချဲ့ Grapheme codepoints ထွက်ပြေးလွတ်မြောက်လိမ့်မည်။
    ///
    /// # Examples
    ///
    /// ကြားဖြတ်အဖြစ်
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` ကိုတိုက်ရိုက်အသုံးပြုခြင်း
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// နှစ် ဦး စလုံးညီမျှသည်:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// `to_string` ကိုအသုံးပြုသည်။
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// `self` ရှိ char တစ်ခုစီမှလွတ်မြောက်စေသည့်ကြားဖြတ်မှုကိုပြန်ပို့ပါ။
    ///
    ///
    /// # Examples
    ///
    /// ကြားဖြတ်အဖြစ်
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` ကိုတိုက်ရိုက်အသုံးပြုခြင်း
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// နှစ် ဦး စလုံးညီမျှသည်:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// `to_string` ကိုအသုံးပြုသည်။
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// `self` ရှိ char တစ်ခုစီမှလွတ်မြောက်စေသည့်ကြားဖြတ်မှုကိုပြန်ပို့ပါ။
    ///
    ///
    /// # Examples
    ///
    /// ကြားဖြတ်အဖြစ်
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` ကိုတိုက်ရိုက်အသုံးပြုခြင်း
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// နှစ် ဦး စလုံးညီမျှသည်:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// `to_string` ကိုအသုံးပြုသည်။
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// တစ် ဦး အချည်းနှီးသော str ဖန်တီး
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// တစ်ဦးအချည်းနှီးသော mutable str ဖန်တီး
    #[inline]
    fn default() -> Self {
        // လုံခြုံမှု: အဆိုပါဗလာ string ကိုတရားဝင် UTF-8 ဖြစ်ပါတယ်။
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// အမည်၊ cloneable FN အမျိုးအစား
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // လုံခြုံမှု-လုံခြုံမှုမရှိဘူး
        unsafe { from_utf8_unchecked(bytes) }
    };
}