//! UTF-8 validation ကိုဆက်စပ်သောလုပ်ငန်းများ။

use crate::mem;

use super::Utf8Error;

/// ပထမဦးဆုံးက byte များအတွက်ကနဦး codepoint စုဆောင်းခြင်း Returns ။
/// ပထမ byte သည်အထူးဖြစ်သည်။ အကျယ် ၂ အတွက်အောက်ခြေ ၅ ဘစ်၊ အကျယ် ၃ အတွက် ၄ ခု၊ အကျယ် ၄ အတွက် ၃ ဘစ်သာလိုသည်။
///
#[inline]
fn utf8_first_byte(byte: u8, width: u32) -> u32 {
    (byte & (0x7F >> width)) as u32
}

/// `byte` က byte ဆက်လက်အတူ updated `ch` ၏တန်ဖိုး Returns ။
#[inline]
fn utf8_acc_cont_byte(ch: u32, byte: u8) -> u32 {
    (ch << 6) | (byte & CONT_MASK) as u32
}

/// byte သည် UTF-8 ဆက်တိုက် byte ဟုတ်မဟုတ်စစ်ဆေးသည် (ဆိုလိုသည်မှာ၊ b01 `10` မှစတင်သည်) ။
///
#[inline]
pub(super) fn utf8_is_cont_byte(byte: u8) -> bool {
    (byte & !CONT_MASK) == TAG_CONT_U8
}

#[inline]
fn unwrap_or_0(opt: Option<&u8>) -> u8 {
    match opt {
        Some(&byte) => byte,
        None => 0,
    }
}

/// (by UTF-8 ကဲ့သို့သော encoding တစ်ခုဖြင့်ယူဆသည်) byte iterator မှနောက်ကုဒ်အမှတ်တစ်ခုကိုဖတ်သည်။
///
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn next_code_point<'a, I: Iterator<Item = &'a u8>>(bytes: &mut I) -> Option<u32> {
    // UTF-8 ဝှက်ပါ
    let x = *bytes.next()?;
    if x < 128 {
        return Some(x as u32);
    }

    // Multibyte ကိစ္စတွင်ထဲကတစ်ဦးက byte ပေါင်းစပ်ရာမှဒီကုဒ်ဒါအောက်ပါအတိုင်း: [[[x y] z] w]
    //
    // NOTE: စွမ်းဆောင်ရည်ဤနေရာတွင်အတိအကျရေးဆွဲရေးမှအထိခိုက်မခံဖြစ်ပါတယ်
    let init = utf8_first_byte(x, 2);
    let y = unwrap_or_0(bytes.next());
    let mut ch = utf8_acc_cont_byte(init, y);
    if x >= 0xE0 {
        // [[x y z] w] ကိစ္စ
        // 0xE0 .. 0xEF အတွက် 5th bit နဲ့အမြဲရှင်းပါတယ်ဒါကြောင့် `init` နေဆဲတရားဝင်သည်
        let z = unwrap_or_0(bytes.next());
        let y_z = utf8_acc_cont_byte((y & CONT_MASK) as u32, z);
        ch = init << 12 | y_z;
        if x >= 0xF0 {
            // [x y z w] အမှု `init` ၏အနိမ့် 3-bits သာအသုံးပြုပါ
            //
            let w = unwrap_or_0(bytes.next());
            ch = (init & 7) << 18 | utf8_acc_cont_byte(y_z, w);
        }
    }

    Some(ch)
}

/// (က UTF-8-တူသောကုဒ်သွင်းယူဆ) တစ်ဦးက byte ကြားမှာထဲကနောက်ဆုံးကုဒ်ပွိုင့်ဖတ်တယ်။
///
#[inline]
pub(super) fn next_code_point_reverse<'a, I>(bytes: &mut I) -> Option<u32>
where
    I: DoubleEndedIterator<Item = &'a u8>,
{
    // UTF-8 ဝှက်ပါ
    let w = match *bytes.next_back()? {
        next_byte if next_byte < 128 => return Some(next_byte as u32),
        back_byte => back_byte,
    };

    // Multibyte Case သည်အောက်ပါများမှ byte ပေါင်းစပ်မှုတစ်ခုမှ Decode ကိုအောက်ပါအတိုင်းဖြစ်သည်။ [x [y [z w]]]
    //
    let mut ch;
    let z = unwrap_or_0(bytes.next_back());
    ch = utf8_first_byte(z, 2);
    if utf8_is_cont_byte(z) {
        let y = unwrap_or_0(bytes.next_back());
        ch = utf8_first_byte(y, 3);
        if utf8_is_cont_byte(y) {
            let x = unwrap_or_0(bytes.next_back());
            ch = utf8_first_byte(x, 4);
            ch = utf8_acc_cont_byte(ch, y);
        }
        ch = utf8_acc_cont_byte(ch, z);
    }
    ch = utf8_acc_cont_byte(ch, w);

    Some(ch)
}

// usize သို့ u64 fit မှအသုံးပြုမှုခြင်းကို
const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;

/// ပြန် `true` `x` (>=128) nonascii ဖြစ်ပါတယ်နှုတ်ကပတ်တော်အတိုင်းဆိုက byte လျှင်။
#[inline]
fn contains_nonascii(x: usize) -> bool {
    (x & NONASCII_MASK) != 0
}

/// `v` မှတဆင့်လမ်းလျှောက်သည်။ ၎င်းသည်မှန်ကန်သော UTF-8 sequence ကိုစစ်ဆေးပြီး၊ `Ok(())` ကိုပြန်ပို့သည်သို့မဟုတ်၎င်းသည်မမှန်ကန်ပါက၊ `Err(err)`.
///
#[inline(always)]
pub(super) fn run_utf8_validation(v: &[u8]) -> Result<(), Utf8Error> {
    let mut index = 0;
    let len = v.len();

    let usize_bytes = mem::size_of::<usize>();
    let ascii_block_size = 2 * usize_bytes;
    let blocks_end = if len >= ascii_block_size { len - ascii_block_size + 1 } else { 0 };
    let align = v.as_ptr().align_offset(usize_bytes);

    while index < len {
        let old_offset = index;
        macro_rules! err {
            ($error_len: expr) => {
                return Err(Utf8Error { valid_up_to: old_offset, error_len: $error_len })
            };
        }

        macro_rules! next {
            () => {{
                index += 1;
                // ကျနော်တို့ဒေတာလိုအပ်ပေမယ့်ဘယ်သူမျှမရှိ၏အမှား!
                if index >= len {
                    err!(None)
                }
                v[index]
            }};
        }

        let first = v[index];
        if first >= 128 {
            let w = UTF8_CHAR_WIDTH[first as usize];
            // 2-byte encoding သည် codepoints များအတွက်\u {0080} ပထမ ဦး ဆုံး C2 80 DF BF သို့\u {07ff} သို့\t
            // 3-byte encoding သည် codepoints\u {0800} အတွက်\u {ffff} ပထမ ဦး ဆုံး E0 A0 80 ရဲ့အငွေ့အစားထိုး codepoints\u {d800} မှ EDF BF သို့\U {dfff} ED A0 80 ကိုဖယ်ထုတ်ပေးဖို့အတွက်ဖြစ်ပါတယ်။
            // 4-byte encoding သည် codepoints များအတွက်\u {1000} 0 မှ\u {10ff} ပထမ F0 90 80 80 နောက်ဆုံး F4 8F BF BF အတွက်ဖြစ်ပါတယ်။
            //
            // RFC မှ UTF-8 syntax ကိုသုံးပါ
            //
            // https://tools.ietf.org/html/rfc3629
            // UTF8-1=% x00-7F UTF8-2=% xC2-DF UTF8-tail UTF8-3= %xE0% xA0-BF UTF8-tail/% xE1-EC 2( UTF8-tail )/%xED% x80-9F UTF8-tail/% xEE-EF 2( UTF8-tail ) UTF8-4= %xF0% x90-BF 2( UTF8-tail )/% xF1-F3 3( UTF8-tail )/%xF4% x80-8F 2( UTF8-tail )
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            match w {
                2 => {
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(1))
                    }
                }
                3 => {
                    match (first, next!()) {
                        (0xE0, 0xA0..=0xBF)
                        | (0xE1..=0xEC, 0x80..=0xBF)
                        | (0xED, 0x80..=0x9F)
                        | (0xEE..=0xEF, 0x80..=0xBF) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                }
                4 => {
                    match (first, next!()) {
                        (0xF0, 0x90..=0xBF) | (0xF1..=0xF3, 0x80..=0xBF) | (0xF4, 0x80..=0x8F) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(3))
                    }
                }
                _ => err!(Some(1)),
            }
            index += 1;
        } else {
            // Ascii ကိစ္စ၊ မြန်မြန်ဆန်ဆန်ကျော်သွားရန်ကြိုးစားပါ။
            // ညွန်ကိန်းကိုချိန်ကိုက်ပါက၊ ascii byte ပါသည့်စာလုံးတစ်လုံးကိုမတွေ့မချင်းတစ်ကြိမ်တွင်အချက်အလက်နှစ်လုံးပါသောစကားလုံးများကိုဖတ်ပါ။
            //
            if align != usize::MAX && align.wrapping_sub(index) % usize_bytes == 0 {
                let ptr = v.as_ptr();
                while index < blocks_end {
                    // လုံခြုံမှု-`align - index` နှင့် `ascii_block_size` တို့ကတည်းကဖြစ်သည်
                    // Multiple `usize_bytes`, `block = ptr.add(index)` ကို `usize` နဲ့အမြဲတမ်းတွဲသုံးထားတာဖြစ်လို့ `block` နဲ့ `block.offset(1)` နှစ်ခုလုံးကိုလုံခြုံမှုကင်းစွာထားနိုင်ပါတယ်။
                    //
                    //
                    unsafe {
                        let block = ptr.add(index) as *const usize;
                        // တစ်ဦး nonascii က byte ရှိလျှင်ကိုချိုးဖျက်
                        let zu = contains_nonascii(*block);
                        let zv = contains_nonascii(*block.offset(1));
                        if zu | zv {
                            break;
                        }
                    }
                    index += ascii_block_size;
                }
                // အဆိုပါ wordwise ကွင်းဆက်ရပ်တန့်ရှိရာအမှတ်ကနေခြေလှမ်း
                while index < len && v[index] < 128 {
                    index += 1;
                }
            } else {
                index += 1;
            }
        }
    }

    Ok(())
}

// https://tools.ietf.org/html/rfc3629
static UTF8_CHAR_WIDTH: [u8; 256] = [
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x1F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x3F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x5F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x7F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0x9F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0xBF
    0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, // 0xDF
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, // 0xEF
    4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 0xFF
];

/// ပထမ ဦး ဆုံး byte ပေးထားသောကြောင့် UTF-8 character တွင်မည်မျှ bytes ရှိသည်ကိုဆုံးဖြတ်သည်။
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn utf8_char_width(b: u8) -> usize {
    UTF8_CHAR_WIDTH[b as usize] as usize
}

/// တစ်ဆက်က byte ၏တန်ဖိုး-bits ၏ mask ။
const CONT_MASK: u8 = 0b0011_1111;
/// တစ်ဆက်က byte ၏ tag ကို bits သည်၏တန်ဖိုး (tag ကိုမျက်နှာဖုံး !CONT_MASK ဖြစ်ပါတယ်) ။
const TAG_CONT_U8: u8 = 0b1000_0000;

// အမြင့်ဆုံး `max` နှင့်ညီမျှသောအရှည်ကိုဖြတ်ရန် `&str` က `true` ကို၎င်း၊
//
pub(super) fn truncate_to_char_boundary(s: &str, mut max: usize) -> (bool, &str) {
    if max >= s.len() {
        (false, s)
    } else {
        while !s.is_char_boundary(max) {
            max -= 1;
        }
        (true, &s[..max])
    }
}