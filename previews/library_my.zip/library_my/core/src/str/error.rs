//! utf8 အမှားအမျိုးအစားကိုသတ်မှတ်ပါတယ်။

use crate::fmt;

/// [`u8`] တစ်ခု sequence ကို string တစ်ခုအဖြစ်ဘာသာပြန်ရန်ကြိုးစားသည့်အခါဖြစ်ပေါ်နိုင်သည့်အမှားများ။
///
/// ဥပမာအားဖြင့် [`String`] s နှင့် [`&str`] နှစ်မျိုးလုံးအတွက် `from_utf8` မိသားစု၏လုပ်ဆောင်ချက်များနှင့်နည်းလမ်းများသည်ဤအမှားအားအသုံးပြုသည်။
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// ဤအမှားအမျိုးအစား၏နည်းလမ်းများကိုအမှိုက်ပုံမှတ်ပုံတင်ခြင်းမရှိပဲ `String::from_utf8_lossy` နှင့်ဆင်တူသောလုပ်ဆောင်နိုင်စွမ်းကိုဖန်တီးရန်အသုံးပြုနိုင်သည်။
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// ခိုင်လုံသော UTF-8 မှန်ကန်ကြောင်းအတည်ပြုခဲ့သောမှပေးထားသော string ကိုတက်အတွက်အညွှန်းကိန်း Returns ။
    ///
    /// ဒါဟာ `from_utf8(&input[..index])` `Ok(_)` ပြန်လာနိုင်ထိုကဲ့သို့သောအများဆုံးအညွှန်းကိန်းဖြစ်ပါတယ်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::str;
    ///
    /// // vector ထဲတွင်မမှန်ကန်တဲ့ bytes အချို့
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 Utf8Error ကိုပြန်ပို့သည်
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // ဒုတိယ byte ကဒီမှာမမှန်ကန်ပါ
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// ပျက်ကွက်ခြင်းနှင့်ပတ်သက်သောသတင်းအချက်အလက်များကိုပေးသည်။
    ///
    /// * `None`: input ကို၏အဆုံးမမျှော်လင့်ဘဲရောက်ရှိခဲ့သည်။
    ///   `self.valid_up_to()` input ရဲ့အဆုံးကနေ 1 မှ 3 bytes ဖြစ်ပါတယ်။
    ///   အကယ်၍ byte stream တစ်ခု (ဥပမာဖိုင်တစ်ခုသို့မဟုတ် network socket ကဲ့သို့) ကိုထပ်တလဲလဲ decoded လုပ်နေသည်ဆိုလျှင်၎င်းသည် UTF-8 byte sequence သည် Chunks အများအပြားကိုဖြတ်သန်းနေသောတရားဝင် `char` ဖြစ်နိုင်သည်။
    ///
    ///
    /// * `Some(len)`: တစ် ဦး မမျှော်လင့်ဘဲ byte ကြုံတွေ့ခဲ့သည်။
    ///   ပေးထားသောအရှည်သည် `valid_up_to()` ပေးသောအညွှန်းမှစတင်သောမမှန်ကန်တဲ့ byte sequence ၏အရှည်ဖြစ်သည်။
    ///   lossy decoding လုပ်တဲ့အခါမှာ ([`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] ကိုထည့်ပြီးတဲ့နောက်) အဲဒီ sequence နဲ့အတူ decoding ကိုပြန်လည်တည်ဆောက်သင့်ပါတယ်။
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// [`from_str`] သုံး၍ `bool` ကိုခွဲခြမ်းစိတ်ဖြာမှုမအောင်မြင်သောအခါအမှားတစ်ခုပြန်ပေါ်လာသည်
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}