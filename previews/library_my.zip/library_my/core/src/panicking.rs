//! libcore အတွက် Panic ထောက်ခံမှု
//!
//! အဓိကစာကြည့်တိုက်သည်ထိတ်လန့်တုန်လှုပ်မှုကိုအဓိပ္ပါယ်ဖွင့် ဆို၍ မရပါ၊ သို့သော်၎င်းသည် * ထိတ်လန့်တုန်လှုပ်မှုကိုကြေငြာသည်။
//! ဆိုလိုသည်မှာ libcore အတွင်းရှိလုပ်ဆောင်ချက်များကို panic အားခွင့်ပြုသည်။ သို့သော်အသုံးဝင်ရန်အတွက် crate ၏အထက်ပိုင်းတွင်အသုံးပြုရန်အတွက် libcore ကိုအသုံးပြုရန်အတွက် panicking ကိုသတ်မှတ်ရမည်။
//! ထိတ်လန့်တုန်လှုပ်မှုအတွက်လက်ရှိ interface မှာ-
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! ဤအဓိပ္ပာယ်ဖွင့်ဆိုချက်သည်မည်သည့်ယေဘုယျမက်ဆေ့ခ်ျကိုမဆိုထိတ်လန့်စရာဖြစ်စေသည်၊ သို့သော်၎င်းသည် `Box<Any>` တန်ဖိုးနှင့်ကျရှုံးခြင်းကိုခွင့်မပြုပါ။
//! (`PanicInfo` တွင် `&(dyn Any + Send)` ပါရှိသည်။ ၎င်းသည် `PanicInfo: : internal_constructor` 'တွင်ရှိသောတန်ဖိုးရှိသည့်တန်ဖိုးကိုဖြည့်စွက်သည်။) ၎င်းအတွက်အကြောင်းပြချက်မှာ libcore ကိုခွဲဝေချထားပေးရန်ခွင့်မပြုသောကြောင့်ဖြစ်သည်။
//!
//!
//! ဒီ module ထဲမှာအခြားအထိတ်တလန့်လုပ်ဆောင်မှုအနည်းငယ်ပါ ၀ င်ပေမယ့်ဒီဟာတွေဟာ compiler အတွက်လိုအပ်တဲ့ lang ပစ္စည်းများပဲဖြစ်သည်။panics အားလုံးကိုဤလုပ်ဆောင်မှုတစ်ခုမှတဆင့်လည်ပတ်စေသည်။
//! အမှန်တကယ်သင်္ကေတကို `#[panic_handler]` attribute မှတစ်ဆင့်ကြေငြာသည်။
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Formcatting မသုံးသည့်အခါ libcore ၏ `panic!` macro ၏အခြေခံအကောင်အထည်ဖော်မှု။
#[cold]
// panic_immediate_abort သည်ခေါ်ဆိုမှုဆိုဒ်များတွင်တတ်နိုင်သမျှအမြန်ဆုံးရှောင်ရှားရန် မှလွဲ၍ ဘယ်သောအခါမျှမဝင်ရ
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // လျတ်နှင့်အခြား `Assert` MIR Terminator အပေါ် panic များအတွက် codegen နေဖြင့်လိုအပ်ခဲ့ပါတယ်
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // အရွယ်အစား overhead ကိုလျှော့ချရန် format_args! ("{}", expr) အစား Arguments::new_v1 ကိုသုံးပါ။
    // အဆိုပါ format_args!macro သည် str's Display trait ကို expr ရေးသားရန်အသုံးပြုသည်။ ၎င်းသည် Formatter::pad ဟုခေါ်သည်။ ၎င်းမှာ string truncation and padding (ဤတွင်အဘယ်သူမျှမသုံးသော်လည်း) ထည့်သွင်းထားရမည်။
    //
    // Arguments::new_v1 ကိုအသုံးပြုခြင်းအားဖြင့် compiler မှအနည်းငယ်သောကီလိုဘိုက်အထိချွေတာနိုင်သည့် output binary မှ Formatter::pad ကိုချန်လှပ်ရန်ခွင့်ပြုလိမ့်မည်။
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // const-အကဲဖြတ် panics ဘို့လိုအပ်ခဲ့ပါတယ်
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // OOB array/slice လက်လှမ်းမီမှုအတွက် panic အတွက် codegen မှလိုအပ်သည်
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Formcatting ကိုသုံးသောအခါ libcore ၏ `panic!` macro ၏အခြေခံအကောင်အထည်ဖော်မှု။
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // မှတ်ချက်ဒီ function ဟာ FFI နယ်နိမိတ်ဖြတ်သန်းသွားသည်ကိုဘယ်တော့မှ;၎င်းသည် `#[panic_handler]` function သို့ဖြေရှင်းသွားသော Rust-to-Rust ခေါ်ဆိုမှုဖြစ်သည်။
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // လုံခြုံမှု: `panic_impl` ကို Rust ကုဒ်နံပါတ်ဖြင့် သတ်မှတ်၍ ခေါ်ဆိုနိုင်သည်။
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// `assert_eq!` နှင့် `assert_ne!` macros များအတွက်လုပ်ဆောင်ချက်
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}