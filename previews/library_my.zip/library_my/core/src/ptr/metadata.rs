#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// မည်သည့် point-to type မဆို၏ pointer metadata အမျိုးအစားကိုပေးသည်။
///
/// # pointer metadata ကို
///
/// Rust ရှိညွန်ကိန်းအမျိုးအစားများနှင့်ရည်ညွှန်းကိုးကားအမျိုးအစားများကိုနှစ်ပိုင်းခွဲခြားနိုင်သည်။
/// တန်ဖိုး၏မှတ်ဉာဏ်လိပ်စာနှင့်အချို့သော metadata ကိုပါရှိသောဒေတာ pointer ။
///
/// statically အရွယ်အစား (`Sized` traits ကိုအကောင်အထည်ဖော်သော) အတွက်သာမက `extern` အမျိုးအစားများအတွက်ညွှန်ကိန်းများသည်`ပါးလွှာသည်` ဟုဆိုကြသည်။ metadata သည်သုညအရွယ်ရှိပြီး၎င်း၏အမျိုးအစားမှာ `()` ။
///
///
/// [dynamically-sized types][dst] ကိုညွန်ပြသည်မှာ`wide` (သို့)`fat` ဖြစ်သည်။ သူတို့သည်သုညမဟုတ်သည့် metadata များရှိသည်။
///
/// * အဘယ်သူ၏နောက်ဆုံးလယ်က DST ဖြစ်သည့် structs အတွက် metadata သည်နောက်ဆုံး field အတွက် metadata ဖြစ်သည်
/// * `str` အမျိုးအစားအတွက် metadata သည် bytes ရှိ `usize` အရှည်ဖြစ်သည်
/// * `[T]` တူသောအချပ်အမျိုးအစားများအဘို့, metadata ကို `usize` အဖြစ်ပစ္စည်းများအတွက်အရှည်ဖြစ်ပါသည်
/// * `dyn SomeTrait` ကဲ့သို့ trait အရာဝတ္ထုများအတွက် metadata သည် [`DynMetadata<Self>`][DynMetadata] (ဥပမာ `DynMetadata<dyn SomeTrait>`) ဖြစ်သည်
///
/// future တွင် Rust ဘာသာစကားသည်ကွဲပြားခြားနားသော pointer metadata ရှိသောအမျိုးအစားများကိုရရှိနိုင်သည်။
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # အဆိုပါ `Pointee` trait
///
/// ဒီ trait ၏အချက်အထက်တွင်ဖော်ပြထားသကဲ့သို့ `()` သို့မဟုတ် `usize` သို့မဟုတ် `DynMetadata<_>` ဖြစ်သောယင်း၏ `Metadata` ဆက်စပ်အမျိုးအစားဖြစ်ပါသည်။
/// ၎င်းသည်အမျိုးအစားတိုင်းအတွက်အလိုအလျောက်အကောင်အထည်ဖော်သည်။
/// ၎င်းကိုသက်ဆိုင်ရာခလုတ်မနှိပ်ဘဲယေဘုယျအခြေအနေတွင်အကောင်အထည်ဖော်သည်ဟုယူဆနိုင်သည်။
///
/// # Usage
///
/// data point နှင့် metadata components များကိုသူတို့ရဲ့ [`to_raw_parts`] method နဲ့ပြိုကွဲပျက်စီးနိုင်ပါတယ်။
///
/// တနည်းအားဖြင့် [`metadata`] function ဖြင့် metadata တစ်ခုတည်းကိုထုတ်ယူနိုင်သည်။
/// တစ်ဦးကရည်ညွှန်း [`metadata`] မှလွန်ခြင်းနှင့်လုံးလုံးလြားလြားအတင်းအကျပ်နိုင်ပါသည်။
///
/// (possibly-wide) pointer သည်၎င်း၏လိပ်စာနှင့် metadata များမှ [`from_raw_parts`] သို့မဟုတ် [`from_raw_parts_mut`] နှင့်အတူတကွပြန်ထားနိုင်သည်။
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// ညွှန်ပြချက်များနှင့် metacata များအတွက် `Self` ကိုညွှန်းသည်။
    #[lang = "metadata_type"]
    // NOTE: `static_assert_expected_bounds_for_metadata` တွင် trait bounds ကိုသိမ်းထားပါ
    //
    // `library/core/src/ptr/metadata.rs` တွင်ဤနေရာရှိသူများနှင့်ထပ်တူပြုခြင်း-
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// ဤ trait alias ကိုအကောင်အထည်ဖော်သောအမျိုးအစားများကိုညွှန်ပြသည်မှာ` ပါးလွှာသည်။
///
/// ဤသည်လိုမျိုး statically-`Sized` အမျိုးအစားများနှင့် `extern` အမျိုးအစားများပါဝင်သည်။
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: trait aliases များသည်ဘာသာစကားတွင်တည်ငြိမ်မှုမရှိမှီဤအချက်ကိုတည်ငြိမ်အောင်လုပ်နိုင်ပါသလား
pub trait Thin = Pointee<Metadata = ()>;

/// တစ် ဦး pointer ၏ metadata ကိုအစိတ်အပိုင်းထုတ်ယူပါ။
///
/// `*mut T`, `&T` သို့မဟုတ် `&mut T` အမျိုးအစားတန်ဖိုးများကို `* const T` သို့အတိအလင်းအတင်းအကျပ်တောင်းခံသည့်အခါဤလုပ်ဆောင်မှုကိုတိုက်ရိုက်လွှဲပြောင်းနိုင်သည်။
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // လုံခြုံမှု-`PtrRepr` Union မှတန်ဖိုးကိုရယူသုံးစွဲခြင်း * const T သည်ကတည်းကလုံခြုံသည်
    // နှင့် PtrComponents<T>အတူတူမှတ်ဉာဏ်အပြင်အဆင်ရှိသည်။
    // std သာလျှင်ဤအာမခံချက်ကိုပေးနိုင်သည်။
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// ဒေတာလိပ်စာနှင့် metadata မှ (possibly-wide) raw pointer ကိုဖွဲ့စည်းသည်။
///
/// ဒီ function ကလုံခြုံတယ်၊ ဒါပေမယ့် return ပြန်လာတဲ့ pointer ဟာ dereference အတွက်လုံခြုံမှုမရှိဘူး။
/// ချပ်များအတွက်လုံခြုံရေးလိုအပ်ချက်များအတွက် [`slice::from_raw_parts`] ၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
/// trait အရာဝတ္ထုများအတွက် metadata သည်ညွန်ကိန်းမှတူညီသောနောက်ခံ ereased type သို့ရောက်ရမည်။
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // လုံခြုံမှု-`PtrRepr` Union မှတန်ဖိုးကိုရယူသုံးစွဲခြင်း * const T သည်ကတည်းကလုံခြုံသည်
    // နှင့် PtrComponents<T>အတူတူမှတ်ဉာဏ်အပြင်အဆင်ရှိသည်။
    // std သာလျှင်ဤအာမခံချက်ကိုပေးနိုင်သည်။
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// တစ် ဦး X0 `*const` pointer ဆန့်ကျင်အဖြစ်ကုန်ကြမ်း `* mut` pointer ကိုပြန်လာသောကြောင်းမှလွဲ။ [`from_raw_parts`] ကဲ့သို့တူညီသောလုပ်ဆောင်နိုင်စွမ်းကိုလုပ်ဆောင်တယ်။
///
///
/// အသေးစိတ်အတွက် [`from_raw_parts`] ၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // လုံခြုံမှု-`PtrRepr` Union မှတန်ဖိုးကိုရယူသုံးစွဲခြင်း * const T သည်ကတည်းကလုံခြုံသည်
    // နှင့် PtrComponents<T>အတူတူမှတ်ဉာဏ်အပြင်အဆင်ရှိသည်။
    // std သာလျှင်ဤအာမခံချက်ကိုပေးနိုင်သည်။
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// `T: Copy` ရှောင်ရှားရန်လိုအပ်လက်စွဲစာအုပ် impl ခညျြနှောငျ။
impl<T: ?Sized> Copy for PtrComponents<T> {}

// `T: Clone` ရှောင်ရှားရန်လိုအပ်လက်စွဲစာအုပ် impl ခညျြနှောငျ။
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// `Dyn = dyn SomeTrait` trait အရာဝတ္ထုအမျိုးအစားအတွက် metadata ။
///
/// ၎င်းသည် trait အရာဝတ္ထုအတွင်းသိမ်းဆည်းထားသောကွန်ကရစ်အမျိုးအစားကိုကိုင်တွယ်ရန်လိုအပ်သောအချက်အလက်အားလုံးကိုကိုယ်စားပြုသည့် vtable (virtual call table) ကိုညွှန်ပြသည်။
/// အထူးသဖြင့် vtable တွင်ပါဝင်သည်။
///
/// * အမျိုးအစားအရွယ်အစား
/// * အမျိုးအစား alignment ကို
/// * အမျိုးအစား၏ `drop_in_place` impl ကိုညွှန်ပြသည် (လွင်ပြင်ဒေတာအတွက်အတားအဆီးမရှိဖြစ်နိုင်သည်)
/// * trait အမျိုးအစား၏အကောင်အထည်ဖော်မှုအတွက်နည်းလမ်းအားလုံးကိုညွှန်ပြသည်
///
/// trait အရာဝတ္ထုများကိုမည်သည့်နေရာတွင်မျှခွဲဝေချထားရန်လိုအပ်သည်၊ ပထမသုံးခုသည်အထူးဖြစ်ကြောင်းသတိပြုပါ။
///
/// ဒီ struct ကို `dyn` trait အရာဝတ္ထု (ဥပမာ `DynMetadata<u64>`) မဟုတ်ပေမယ့် struct ၏အဓိပ္ပါယ်ရှိသောတန်ဖိုးကိုရယူရန်မဟုတ်သော type parameter တစ်ခုကို အသုံးပြု၍ ဖော်ပြနိုင်သည်။
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// အားလုံး vtables ၏ဘုံရှေ့ဆက်။၎င်းသည် trait နည်းလမ်းများအတွက် function pointers ဖြင့်လိုက်သည်။
///
/// `DynMetadata::size_of` ၏ပုဂ္ဂလိကအကောင်အထည်ဖော်မှုအသေးစိတ်စသည်တို့
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// ဤ VTable နှင့်ဆက်စပ်သောအမျိုးအစား၏အရွယ်အစားကိုပြန်ပို့သည်။
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// ဒီ VTable နှင့်ဆက်စပ်အမျိုးအစားများ၏ alignment ကိုပြန်သွားသည်။
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// `Layout` တစ်ခုအနေဖြင့်အရွယ်အစားနှင့် alignment ကိုအတူတကွပြန်ပို့သည်
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // လုံခြုံမှု: compiler ကကွန်ကရစ် Rust အမျိုးအစားအတွက်ဒီ vtable ကိုထုတ်လွှတ်သည်
        // တရားဝင် layout ကိုရှိသည်ဟုလူသိများသည်။`Layout::for_value` ၌ရှိသကဲ့သို့တူညီသောကျိုးကြောင်းဆင်ခြင်။
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// `Dyn: $Trait` သတ်မှတ်ချက်ကိုရှောင်ကြဉ်ရန်လိုအပ်သော Manual impls များ။

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}