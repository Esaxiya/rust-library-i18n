use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// ဒီ null ကိုပိုင်ဆိုင်သူက referent ကိုပိုင်ဆိုင်တယ်ဆိုတာကိုပြတဲ့ null null null null `*mut T` တစ်ခုပတ်ပတ်လည်က wrapper ။
/// `Box<T>`, `Vec<T>`, `String` နှင့် `HashMap<K, V>` စသည့် abstraction များကိုတည်ဆောက်ရာတွင်အသုံးဝင်သည်။
///
/// `*mut T` နှင့်မတူဘဲ `Unique<T>` သည် "as if" ကိုပြုသည်မှာ၎င်းသည် `T` ၏ဥပမာတစ်ခုဖြစ်သည်။
/// `T` `Send`/`Sync` ဖြစ်ပါက၎င်းသည် `Send`/`Sync` ကိုအကောင်အထည်ဖော်သည်။
/// `T` ၏ဥပမာတစ်ခုကမျှော်လင့်ထားသည့်ခိုင်မာသည့် aliasing အမျိုးအစားများကိုလည်းဆိုလိုသည်။
/// ၎င်းကိုပိုင်ဆိုင်ထားသည့်ထူးခြားသောလမ်းကြောင်းမပါဘဲညွှန်ပြသူ၏ရည်ညွှန်းချက်ကိုပြုပြင်မွမ်းမံသင့်သည်။
///
/// သင်၏ရည်ရွယ်ချက်များအတွက် `Unique` ကိုအသုံးပြုခြင်းသည်မမှန်သည်ကိုသင်မသိလျှင်၊ အားနည်းသော semantics ရှိသော `NonNull` ကိုအသုံးပြုရန်စဉ်းစားပါ။
///
///
/// `*mut T` မတူဘဲ, ထို pointer ကိုအမြဲတမ်း pointer dereferenced ဘယ်တော့မှရင်တောင်, Non-တရားမဝင်သောဖြစ်ရမည်။
/// enums များသည်ဒီတားမြစ်ထားသောတန်ဖိုးကိုခွဲခြားဆက်ဆံမှုတစ်ခုအဖြစ်အသုံးပြုနိုင်ရန်ဖြစ်သည်။ `Option<Unique<T>>` သည်အရွယ်အစား `Unique<T>` နှင့်အတူတူဖြစ်သည်။
/// မည်သို့ဆိုစေ deferferenced မပြုလုပ်ပါက pointer သည်ချိတ်နေဆဲပင်။
///
/// `*mut T` နှင့်မတူဘဲ `Unique<T>` သည် `T` ကျော်သည် covariant ဖြစ်သည်။
/// Unique ၏ aliasing လိုအပ်ချက်များကိုထိန်းသိမ်းသောမည်သည့်အမျိုးအစားအတွက်မဆိုအမြဲတမ်းမှန်ကန်သင့်သည်။
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: ဒီအမှတ်အသားကှဲလှဲအဘို့အဘယ်သူမျှမအကျိုးဆက်များရှိပါတယ်ဒါပေမယ့်လိုအပ်သောဖြစ်ပါတယ်
    // dropck အဘို့ငါတို့ယုတ္တိနည်း `T` ပိုင်ဆိုင်ကြောင်းကိုနားလည်ရန်။
    //
    // အသေးစိတ်အတွက်တွေ့မြင်:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` သူတို့ကိုးကားတဲ့ဒေတာ unaliased ကြောင့် `T` `Send` လျှင်ညွှန်ပြ `Send` ဖြစ်ကြသည်။
/// ဒီ aliasing လျော့ပါးသွားမည်ဖြစ်သလိုအမျိုးအစားစနစ်အားဖြင့် unenforced ကြောင်းကိုသတိပြုပါ;အဆိုပါ `Unique` သုံးပြီး abstraction ကပြenfor္ဌာန်းရပေမည်။
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` သူတို့ကိုးကားတဲ့ဒေတာ unaliased ကြောင့် `T` `Sync` လျှင်ညွှန်ပြ `Sync` ဖြစ်ကြသည်။
/// ဒီ aliasing လျော့ပါးသွားမည်ဖြစ်သလိုအမျိုးအစားစနစ်အားဖြင့် unenforced ကြောင်းကိုသတိပြုပါ;အဆိုပါ `Unique` သုံးပြီး abstraction ကပြenfor္ဌာန်းရပေမည်။
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// dangling, ဒါပေမယ့်ကောင်းစွာ-ကိုက်ညီသောအသစ်တစ်ခုကို `Unique` ဖန်တီးသည်။
    ///
    /// ဤသည်မှာ `Vec::new` ကဲ့သို့အလွန်ပျင်းရိစွာခွဲဝေချထားပေးသောအမျိုးအစားများကိုစတင်ခြင်းအတွက်အသုံးဝင်သည်။
    ///
    /// သတိပြုရမည်မှာ pointer value သည် `T` ၏မှန်ကန်သော pointer တစ်ခုဖြစ်နိုင်ကြောင်းဆိုလိုသည်။ ဆိုလိုသည်မှာ၎င်းသည် "not yet initialized" sentinel တန်ဖိုးတစ်ခုအဖြစ်အသုံးမပြုရ။
    /// လေးတွဲ့စွာခွဲဝေချထားပေးရန်ကြောင်းအမျိုးအစားများတခြားနည်းလမ်းဖြင့်စတင်ခြင်းကိုခြေရာခံရပေမည်။
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // လုံခြုံမှု: mem::align_of() ခိုင်လုံသော non-တရားမဝင်သော pointer ကိုပြန်လည်ရောက်ရှိ။The
        // new_unchecked() သို့ခေါ်ဆိုရန်အခြေအနေများအားလေးစားလိုက်နာကြသည်။
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// `Unique` အသစ်တစ်ခုကိုဖန်တီးသည်။
    ///
    /// # Safety
    ///
    /// `ptr` Non-တရားမဝင်သောဖြစ်ရပါမည်။
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // လုံခြုံမှု: `ptr` Non-တရားမဝင်သောကြောင်းခေါ်ဆိုသူ၏မဖြစ်မနေအာမခံ။
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// `ptr` သည် null မဟုတ်ပါက `Unique` အသစ်တစ်ခုကိုဖန်တီးသည်။
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // လုံခြုံမှု-ညွှန်ပြသူကိုစစ်ဆေးပြီးဖြစ်ပြီး null မဟုတ်ပါ။
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// အခြေခံ `*mut` pointer ကိုရရှိသည်။
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// အကြောင်းအရာ Dereferences ။
    ///
    /// ရရှိလာတဲ့သက်တမ်းဟာကိုယ့်ဘာသာကိုယ်ချည်နှောင်ထားတာဖြစ်လို့ဒါက "as if" ကိုပြုမူတာကတကယ်တမ်းကျတော့ချေးထားတဲ့ T ရဲ့ဥပမာတစ်ခုပါ။
    /// (unbound) သက်တမ်းပိုရှည်ရန်လိုအပ်ပါက `&*my_ptr.as_ptr()` ကိုသုံးပါ။
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // လုံခြုံမှု-ဖုန်းပြောသူသည် `self` အားလုံးနှင့်ကိုက်ညီရန်အာမခံရမည်
        // တစ် ဦး ကိုကိုးကားများအတွက်လိုအပ်ချက်များ။
        unsafe { &*self.as_ptr() }
    }

    /// အကြောင်းအရာအပြန်အလှန် dereferences ။
    ///
    /// ရရှိလာတဲ့သက်တမ်းဟာကိုယ့်ဘာသာကိုယ်ချည်နှောင်ထားတာဖြစ်လို့ဒါက "as if" ကိုပြုမူတာကတကယ်တမ်းကျတော့ချေးထားတဲ့ T ရဲ့ဥပမာတစ်ခုပါ။
    /// (unbound) သက်တမ်းပိုရှည်ရန်လိုအပ်ပါက `&mut *my_ptr.as_ptr()` ကိုသုံးပါ။
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // လုံခြုံမှု-ဖုန်းပြောသူသည် `self` အားလုံးနှင့်ကိုက်ညီရန်အာမခံရမည်
        // တစ် ဦး mutable ရည်ညွှန်းမှုအတွက်လိုအပ်ချက်များကို။
        unsafe { &mut *self.as_ptr() }
    }

    /// အခြားအမျိုးအစားတစ် pointer မှ Casts ။
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // လုံခြုံမှု-Unique::new_unchecked() သည်ထူးခြားမှုအသစ်နှင့်လိုအပ်ချက်အသစ်များကိုဖန်တီးသည်
        // တရားမဝင်သောဖြစ်ဖို့ပေးထားသော pointer ။
        // ကျွန်တော်တို့ဟာကိုယ့်ကိုယ်ကို pointer တစ်ခုအဖြစ်ဖြတ်သန်းနေတဲ့အတွက်သူဟာ null မဖြစ်နိုင်ပါဘူး။
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // လုံခြုံမှု-ပြောင်းလဲနိုင်သောရည်ညွှန်းသည် null မဖြစ်နိုင်ပါ
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}