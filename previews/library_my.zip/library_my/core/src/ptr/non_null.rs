use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` ဒါပေမယ့်သုညနှင့် covariant ။
///
/// ၎င်းသည် data structure များတည်ဆောက်သည့်အခါများသောအားဖြင့်မှန်ကန်သောအညွှန်းများဖြစ်ပြီးကုန်ကြမ်းညွှန်းများ အသုံးပြု၍ နောက်ဆုံးတွင်၎င်း၏အပိုဂုဏ်သတ္တိများကြောင့်အသုံးပြုရန် ပို၍ အန္တရာယ်ရှိသည်။သငျသညျ `NonNull<T>` အသုံးပွုသငျ့လျှင်သင်သေချာမသိရှိပါကရုံ `*mut T` ကိုသုံးပါ!
///
/// `*mut T` နှင့်မတူဘဲ pointer သည် dereferenced ဘယ်တော့မှဖြစ်လင့်ကစား pointer သည် null မဟုတ်သောအမြဲဖြစ်ရမည်။enums များသည်ဤတားမြစ်ထားသောတန်ဖိုးကိုခွဲခြားဆက်ဆံသူအဖြစ်အသုံးပြုရန်ဖြစ်သည်-`Option<NonNull<T>>` သည်အရွယ်အစား `* mut T` နှင့်အတူတူဖြစ်သည်။
/// မည်သို့ဆိုစေ deferferenced မပြုလုပ်ပါက pointer သည်ချိတ်နေဆဲပင်။
///
/// `*mut T` နှင့်မတူဘဲ `NonNull<T>` ကို `T` ထက်ပိုမို covariant ဖြစ်ရန်ရွေးချယ်ခဲ့သည်။၎င်းသည် covariant အမျိုးအစားများတည်ဆောက်ရာတွင် `NonNull<T>` ကိုသုံးရန်ဖြစ်နိုင်သည်။ သို့သော် covariant အမျိုးအစားမဖြစ်သင့်သော type တစ်ခုတွင်အသုံးပြုပါက unsoundness ၏အန္တရာယ်ကိုဖော်ပြသည်။
/// (`*mut T` အတွက်ဆန့်ကျင်ဘက်ရွေးချယ်မှုကိုနည်းပညာပိုင်းအရမလုံခြုံသောလုပ်ဆောင်မှုများကိုခေါ်ခြင်းဖြင့်သာဖြစ်ပေါ်နိုင်သည်။)
///
/// Covariance သည် `Box`, `Rc`, `Arc`, `Vec` နှင့် `LinkedList` ကဲ့သို့သောလုံခြုံစိတ်ချရသောရွေ့လျားမှုအများစုအတွက်မှန်ကန်သည်။အဘယ်ကြောင့်ဆိုသော်သူတို့သည် Rust ၏ပုံမှန် shared XOR mutable rules များကိုလိုက်နာသော public API ကိုပေးသောကြောင့်ဖြစ်သည်။
///
/// သင်၏အမျိုးအစားသည်အန္တရာယ်ကင်းစွာ covariant မဖြစ်နိုင်ပါက၎င်းတွင်လျော့ပါးသွားစေခြင်းအတွက်ထပ်မံဖြည့်စွက်ထားသောအကွက်များပါရှိရမည်။မကြာခဏဤကွက်လပ် `PhantomData<Cell<T>>` သို့မဟုတ် `PhantomData<&'a mut T>` ကဲ့သို့ [`PhantomData`] အမျိုးအစားဖြစ်လိမ့်မည်။
///
/// `NonNull<T>` တွင် X0XX ဥပမာတစ်ခုရှိကြောင်းသတိပြုပါ။သို့သော်ဤအချက်သည် (ရည်ညွှန်းချက်မှဆင်းသက်လာသည့် pointer) မှတဆင့် mutating သည် [`UnsafeCell<T>`] အတွင်း၌ဖြစ်ပျက်ခြင်းမရှိပါကသတ်မှတ်ထားသောအပြုအမူဖြစ်သည်ဟူသောအချက်ကိုမပြောင်းလဲပါ။အတူတူပင်ရည်ညွှန်းထားသောရည်ညွှန်းချက်တစ်ခုမှပြောင်းလဲခြင်းရည်ညွှန်းကိုးကားရန်ဖန်တီးသည်။
///
/// ဤ `From` ဥပမာအား `UnsafeCell<T>` မပါပဲအသုံးပြုပါက `as_mut` ကိုဘယ်သောအခါမျှခေါ်မသွားရန်နှင့် `as_ptr` ကို mutation အတွက်ဘယ်တော့မျှအသုံးမပြုရန်သင်၏တာဝန်ဖြစ်သည်။
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` သူတို့ရည်ညွှန်းသည့်ဒေတာ aliased စေခြင်းငှါဖြစ်သောကြောင့်ထောက်ပြ `Send` မရှိကြပေ။
// NB၊ ဤအချက်သည်မလိုအပ်ပါ၊
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` သူတို့ရည်ညွှန်းသည့်ဒေတာ aliased စေခြင်းငှါဖြစ်သောကြောင့်ထောက်ပြ `Sync` မရှိကြပေ။
// NB၊ ဤအချက်သည်မလိုအပ်ပါ၊
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// dangling, ဒါပေမယ့်ကောင်းစွာ-ကိုက်ညီသောအသစ်တစ်ခုကို `NonNull` ဖန်တီးသည်။
    ///
    /// ဤသည်မှာ `Vec::new` ကဲ့သို့အလွန်ပျင်းရိစွာခွဲဝေချထားပေးသောအမျိုးအစားများကိုစတင်ခြင်းအတွက်အသုံးဝင်သည်။
    ///
    /// သတိပြုရမည်မှာ pointer value သည် `T` ၏မှန်ကန်သော pointer တစ်ခုဖြစ်နိုင်ကြောင်းဆိုလိုသည်။ ဆိုလိုသည်မှာ၎င်းသည် "not yet initialized" sentinel တန်ဖိုးတစ်ခုအဖြစ်အသုံးမပြုရ။
    /// လေးတွဲ့စွာခွဲဝေချထားပေးရန်ကြောင်းအမျိုးအစားများတခြားနည်းလမ်းဖြင့်စတင်ခြင်းကိုခြေရာခံရပေမည်။
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // လုံခြုံမှု-mem::align_of() သည်သုညမဟုတ်သောအသုံးအနှုန်းကိုပြန်လည်ထုတ်ပေးသည်
        // တစ် ဦး * mut တီရန်
        // ထို့ကြောင့် `ptr` သည် null မဟုတ်ပါ။ new_unchecked() ကိုခေါ်ဆိုရန်အခြေအနေများကိုလေးစားလိုက်နာသည်။
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// တန်ဖိုးတစ်ခု shared ကိုးကား Returns ။[`as_ref`] နှင့်မတူဘဲ၎င်းသည်တန်ဖိုးကိုစတင်ရန်လိုအပ်သည်မဟုတ်ပါ။
    ///
    /// mutable counterpart အတွက် [`as_uninit_mut`] ကိုကြည့်ပါ။
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// ဤနည်းလမ်းကိုခေါ်ဆိုသောအခါအောက်ပါအချက်များအားလုံးမှန်ကန်ကြောင်းသေချာစေရန်လိုအပ်သည်။
    ///
    /// * အဆိုပါ pointer ကိုစနစ်တကျ alignment ကိုရမည်ဖြစ်သည်။
    ///
    /// * ၎င်းသည် [the module documentation] တွင်အဓိပ္ပာယ်ဖွင့်ဆိုချက်အရ "dereferencable" ဖြစ်ရမည်။
    ///
    /// * Rust ၏ aliasing rules များကိုသင်ပြenfor္ဌာန်းရပါမည်။
    ///
    ///   အထူးသဖြင့်၊ ဒီတစ်သက်တာကြာချိန်အတွက်ညွှန်ပြသည့်မှတ်ဉာဏ်သည် (`UnsafeCell` အတွင်းမှ လွဲ၍) ပြောင်းလဲခြင်းမပြုရ။
    ///
    /// ဤနည်းလမ်း၏ရလဒ်ကိုအသုံးမပြုလျှင်ပင်ဤအချက်သည်သက်ဆိုင်ပါသည်။
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // လုံခြုံမှု-ဖုန်းပြောသူသည် `self` အားလုံးနှင့်ကိုက်ညီရန်အာမခံရမည်
        // တစ် ဦး ကိုကိုးကားများအတွက်လိုအပ်ချက်များ။
        unsafe { &*self.cast().as_ptr() }
    }

    /// တန်ဖိုးတစ်ခုထူးခြားသောကိုးကားပြန်သွားသည်။[`as_mut`] နှင့်မတူဘဲ၎င်းသည်တန်ဖိုးကိုစတင်ရန်လိုအပ်သည်မဟုတ်ပါ။
    ///
    /// အဆိုပါ shared အဆွေတော်အဘို့အ [`as_uninit_ref`] ကြည့်ပါ။
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// ဤနည်းလမ်းကိုခေါ်ဆိုသောအခါအောက်ပါအချက်များအားလုံးမှန်ကန်ကြောင်းသေချာစေရန်လိုအပ်သည်။
    ///
    /// * အဆိုပါ pointer ကိုစနစ်တကျ alignment ကိုရမည်ဖြစ်သည်။
    ///
    /// * ၎င်းသည် [the module documentation] တွင်အဓိပ္ပာယ်ဖွင့်ဆိုချက်အရ "dereferencable" ဖြစ်ရမည်။
    ///
    /// * Rust ၏ aliasing rules များကိုသင်ပြenfor္ဌာန်းရပါမည်။
    ///
    ///   အထူးသဖြင့်၊ ဒီတစ်သက်တာအတွက် pointer မှမှတ်ထားသောမှတ်ဉာဏ်သည်မည်သည့်အခြား pointer မှမရရယူနိုင်ရမည် (ဖတ်ရန်သို့မဟုတ်ရေးသားခြင်း) ဖြစ်သည်။
    ///
    /// ဤနည်းလမ်း၏ရလဒ်ကိုအသုံးမပြုလျှင်ပင်ဤအချက်သည်သက်ဆိုင်ပါသည်။
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // လုံခြုံမှု-ဖုန်းပြောသူသည် `self` အားလုံးနှင့်ကိုက်ညီရန်အာမခံရမည်
        // တစ် ဦး ကိုကိုးကားများအတွက်လိုအပ်ချက်များ။
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// `NonNull` အသစ်တစ်ခုကိုဖန်တီးသည်။
    ///
    /// # Safety
    ///
    /// `ptr` Non-တရားမဝင်သောဖြစ်ရပါမည်။
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // လုံခြုံမှု: `ptr` Non-တရားမဝင်သောကြောင်းခေါ်ဆိုသူ၏မဖြစ်မနေအာမခံ။
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// `ptr` သည် null မဟုတ်ပါက `NonNull` အသစ်တစ်ခုကိုဖန်တီးသည်။
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // လုံခြုံမှု-ဒီညွှန်းကိုစစ်ဆေးပြီးသားဖြစ်ပြီး null မဟုတ်ဘူး
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// တစ် ဦး [`std::ptr::from_raw_parts`] pointer ဆန့်ကျင်အဖြစ်တစ် ဦး `NonNull` pointer ကိုပြန်လာသောကြောင်းမှလွဲ။ [`std::ptr::from_raw_parts`] ကဲ့သို့တူညီသောလုပ်ဆောင်နိုင်စွမ်းကိုလုပ်ဆောင်တယ်။
    ///
    ///
    /// အသေးစိတ်အတွက် [`std::ptr::from_raw_parts`] ၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // လုံခြုံမှု-`data_address` ၏ရလဒ်သည် `ptr::from::raw_parts_mut` ၏ရလဒ်သည် non-null ဖြစ်သည်။
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// လိပ်စာနှင့် metadata အစိတ်အပိုင်းများကို (ဖြစ်နိုင်သည်ကျယ်ပြန့်သော) pointer ထဲသို့ပြိုကွဲသည်။
    ///
    /// pointer ကိုနောက်ပိုင်းတွင် [`NonNull::from_raw_parts`] ဖြင့်ပြန်လည်တည်ဆောက်နိုင်သည်။
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// အခြေခံ `*mut` pointer ကိုရရှိသည်။
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// တန်ဖိုးတစ်ခု shared ရည်ညွှန်း Returns ။အကယ်၍ တန်ဖိုးကို uninitialized လုပ်နိုင်လျှင် [`as_uninit_ref`] ကိုအစားထိုးသုံးပါ။
    ///
    /// mutable counterpart အတွက် [`as_mut`] ကိုကြည့်ပါ။
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// ဤနည်းလမ်းကိုခေါ်ဆိုသောအခါအောက်ပါအချက်များအားလုံးမှန်ကန်ကြောင်းသေချာစေရန်လိုအပ်သည်။
    ///
    /// * အဆိုပါ pointer ကိုစနစ်တကျ alignment ကိုရမည်ဖြစ်သည်။
    ///
    /// * ၎င်းသည် [the module documentation] တွင်အဓိပ္ပာယ်ဖွင့်ဆိုချက်အရ "dereferencable" ဖြစ်ရမည်။
    ///
    /// * pointer သည် `T` ၏အစပြုဥပမာအားညွှန်ပြရမည်။
    ///
    /// * Rust ၏ aliasing rules များကိုသင်ပြenfor္ဌာန်းရပါမည်။
    ///
    ///   အထူးသဖြင့်၊ ဒီတစ်သက်တာကြာချိန်အတွက်ညွှန်ပြသည့်မှတ်ဉာဏ်သည် (`UnsafeCell` အတွင်းမှ လွဲ၍) ပြောင်းလဲခြင်းမပြုရ။
    ///
    /// ဤနည်းလမ်း၏ရလဒ်ကိုအသုံးမပြုလျှင်ပင်ဤအချက်သည်သက်ဆိုင်ပါသည်။
    /// (စတင်ခြင်းနှင့်ပတ်သက်သောအပိုင်းကိုအပြည့်အဝမဆုံးဖြတ်ရသေးသော်လည်း၎င်းသည်အမှန်တကယ်စတင်ခြင်းဖြစ်ကြောင်းသေချာစေရန်အတွက်သာဖြစ်သည်။)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // လုံခြုံမှု-ဖုန်းပြောသူသည် `self` အားလုံးနှင့်ကိုက်ညီရန်အာမခံရမည်
        // တစ် ဦး ကိုကိုးကားများအတွက်လိုအပ်ချက်များ။
        unsafe { &*self.as_ptr() }
    }

    /// တန်ဖိုးတစ်ခုထူးခြားသောရည်ညွှန်းပြန်သွားသည်။အကယ်၍ တန်ဖိုးကို uninitialized လုပ်နိုင်လျှင် [`as_uninit_mut`] ကိုအစားထိုးသုံးပါ။
    ///
    /// မျှတသော counterpart အတွက် [`as_ref`] ကိုကြည့်ပါ။
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// ဤနည်းလမ်းကိုခေါ်ဆိုသောအခါအောက်ပါအချက်များအားလုံးမှန်ကန်ကြောင်းသေချာစေရန်လိုအပ်သည်။
    ///
    /// * အဆိုပါ pointer ကိုစနစ်တကျ alignment ကိုရမည်ဖြစ်သည်။
    ///
    /// * ၎င်းသည် [the module documentation] တွင်အဓိပ္ပာယ်ဖွင့်ဆိုချက်အရ "dereferencable" ဖြစ်ရမည်။
    ///
    /// * pointer သည် `T` ၏အစပြုဥပမာအားညွှန်ပြရမည်။
    ///
    /// * Rust ၏ aliasing rules များကိုသင်ပြenfor္ဌာန်းရပါမည်။
    ///
    ///   အထူးသဖြင့်၊ ဒီတစ်သက်တာအတွက် pointer မှမှတ်ထားသောမှတ်ဉာဏ်သည်မည်သည့်အခြား pointer မှမရရယူနိုင်ရမည် (ဖတ်ရန်သို့မဟုတ်ရေးသားခြင်း) ဖြစ်သည်။
    ///
    /// ဤနည်းလမ်း၏ရလဒ်ကိုအသုံးမပြုလျှင်ပင်ဤအချက်သည်သက်ဆိုင်ပါသည်။
    /// (စတင်ခြင်းနှင့်ပတ်သက်သောအပိုင်းကိုအပြည့်အဝမဆုံးဖြတ်ရသေးသော်လည်း၎င်းသည်အမှန်တကယ်စတင်ခြင်းဖြစ်ကြောင်းသေချာစေရန်အတွက်သာဖြစ်သည်။)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // လုံခြုံမှု-ဖုန်းပြောသူသည် `self` အားလုံးနှင့်ကိုက်ညီရန်အာမခံရမည်
        // တစ် ဦး mutable ရည်ညွှန်းမှုအတွက်လိုအပ်ချက်များကို။
        unsafe { &mut *self.as_ptr() }
    }

    /// အခြားအမျိုးအစားတစ် pointer မှ Casts ။
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // လုံခြုံမှု: `self` ဆိုသည်မှာ null မဟုတ်သော `NonNull` pointer တစ်ခုဖြစ်သည်
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// ပါးလွှာသော pointer နှင့် length တစ်ခုမှ null null raw slice ကိုဖန်တီးသည်။
    ///
    /// `len` argument သည် **element များ၏နံပါတ်** မဟုတ်ဘဲ bytes အရေအတွက်ဖြစ်သည်။
    ///
    /// ဒီ function ကလုံခြုံတယ်၊ ဒါပေမယ့် return value ကို dereferencing လုပ်တာကအန္တရာယ်ကင်းတယ်။
    /// အချပ်ဘေးကင်းလုံခြုံမှုလိုအပ်ချက်များအတွက် [`slice::from_raw_parts`] ၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // ပထမ ဦး ဆုံးဒြပ်စင်တစ်ခု pointer နှင့်အတူစတင်သောအခါ slice pointer ကိုဖန်တီးပါ
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// ဒီဥပမာသူတွေဟာဒီနည်းလမ်းကိုတစ်အသုံးပြုမှုကိုပြသကြောင်း (မှတ်ချက်, ဒါပေမယ့် `ပါစေအချပ်= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // လုံခြုံမှု: `data` ဆိုသည်မှာ null မဟုတ်သော `NonNull` pointer တစ်ခုဖြစ်သည်
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// non-null ကုန်ကြမ်းအချပ်၏အရှည် returns ။
    ///
    /// return ပြန်လာတဲ့တန်ဖိုးကတော့ ** element တွေရဲ့နံပါတ်ပဲ၊ bytes အရေအတွက်မဟုတ်ဘူး။
    ///
    /// ဒီ function ဟာ pointer များသည်တရားဝင်လိပ်စာမရှိပါဘူးဘာဖြစ်လို့လဲဆိုတော့ non-တရားမဝင်သောကုန်ကြမ်းအချပ်တစ်ချပ်မှ dereferenced မရနိုင်လျှင်ပင်အန္တရာယ်ကင်းဖြစ်ပါတယ်။
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// non-null pointer ကို slice ၏ buffer သို့ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // လုံခြုံမှု-`self` ဟာတရားမဝင်ဘူးဆိုတာကိုငါတို့သိတယ်။
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// pointer တစ်မျိုးသည် slice ၏ကြားခံသို့ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// ဖြစ်နိုင်သည် uninitialized တန်ဖိုးများ၏အချပ်တစ်ခု shared ရည်ညွှန်းပြန်သွားသည်။[`as_ref`] နှင့်မတူဘဲ၎င်းသည်တန်ဖိုးကိုစတင်ရန်လိုအပ်သည်မဟုတ်ပါ။
    ///
    /// mutable counterpart အတွက် [`as_uninit_slice_mut`] ကိုကြည့်ပါ။
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// ဤနည်းလမ်းကိုခေါ်ဆိုသောအခါအောက်ပါအချက်များအားလုံးမှန်ကန်ကြောင်းသေချာစေရန်လိုအပ်သည်။
    ///
    /// * `ptr.len() * mem::size_of::<T>()` အမြောက်အများကိုဖတ်ရန်အတွက် pointer သည် [valid] ဖြစ်ရမည်။ ၎င်းကိုစနစ်တကျချိန်ညှိရမည်။အထူးသဖြင့်ဆိုလိုသည်
    ///
    ///     * ဒီအချပ်၏မှတ်ဉာဏ်အကွာအဝေးတစ်ခုလုံးကိုခွဲဝေထားသည့်အရာဝတ္ထုတစ်ခုအတွင်းပါရမည်။
    ///       ချပ်သည်မျိုးစုံခွဲဝေထားသောအရာဝတ္ထုများကိုဘယ်တော့မှ ဖြတ်၍ မရနိုင်ပါ။
    ///
    ///     * သုညအရှည်ချပ်များအတွက်ပင် pointer ကိုချိန်ညှိရမည်။
    ///     ထိုသို့ဖြစ်ရခြင်းမှာအကြောင်းရင်းတစ်ခုမှာ enum layout optimization သည် alignment (မည်သည့်အရှည်ရှိသည့်အချပ်များအပါအ ၀ င်) များအားဆက်စပ်နေပြီးအခြား data များနှင့်ခွဲခြားရန် null မဟုတ်သောကိုးကားချက်များအပေါ်မှီခိုနိုင်သည်။
    ///
    ///     [`NonNull::dangling()`] ကို အသုံးပြု၍ သုညအချပ်များအတွက် `data` အဖြစ်သုံးနိုင်သော pointer ကိုသင်ရနိုင်သည်။
    ///
    /// * အချပ်၏စုစုပေါင်းအရွယ်အစား `ptr.len() * mem::size_of::<T>()` သည် `isize::MAX` ထက်မပိုစေရ။
    ///   [`pointer::offset`] ၏လုံခြုံရေးစာရွက်စာတမ်းများကိုကြည့်ပါ။
    ///
    /// * Rust ၏ aliasing rules များကိုသင်ပြenfor္ဌာန်းရပါမည်။
    ///   အထူးသဖြင့်၊ ဒီတစ်သက်တာကြာချိန်အတွက်ညွှန်ပြသည့်မှတ်ဉာဏ်သည် (`UnsafeCell` အတွင်းမှ လွဲ၍) ပြောင်းလဲခြင်းမပြုရ။
    ///
    /// ဤနည်းလမ်း၏ရလဒ်ကိုအသုံးမပြုလျှင်ပင်ဤအချက်သည်သက်ဆိုင်ပါသည်။
    ///
    /// [`slice::from_raw_parts`] ကိုလည်းရှုပါ။
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `as_uninit_slice` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// ဖြစ်နိုင်သည် uninitialized တန်ဖိုးများ၏အချပ်တစ်ခုထူးခြားသောရည်ညွှန်းပြန်သွားသည်။[`as_mut`] နှင့်မတူဘဲ၎င်းသည်တန်ဖိုးကိုစတင်ရန်လိုအပ်သည်မဟုတ်ပါ။
    ///
    /// မျှတသော counterpart အတွက် [`as_uninit_slice`] ကိုကြည့်ပါ။
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// ဤနည်းလမ်းကိုခေါ်ဆိုသောအခါအောက်ပါအချက်များအားလုံးမှန်ကန်ကြောင်းသေချာစေရန်လိုအပ်သည်။
    ///
    /// * ဖတ်ရန်နှင့် `ptr.len() * mem::size_of::<T>()` အတွက်များစွာသော bytes အတွက်ရေးရန် pointer သည် [valid] ဖြစ်ရမည်။ ၎င်းကိုစနစ်တကျချိန်ညှိရမည်။အထူးသဖြင့်ဆိုလိုသည်မှာ
    ///
    ///     * ဒီအချပ်၏မှတ်ဉာဏ်အကွာအဝေးတစ်ခုလုံးကိုခွဲဝေထားသည့်အရာဝတ္ထုတစ်ခုအတွင်းပါရမည်။
    ///       ချပ်သည်မျိုးစုံခွဲဝေထားသောအရာဝတ္ထုများကိုဘယ်တော့မှ ဖြတ်၍ မရနိုင်ပါ။
    ///
    ///     * သုညအရှည်ချပ်များအတွက်ပင် pointer ကိုချိန်ညှိရမည်။
    ///     ထိုသို့ဖြစ်ရခြင်းမှာအကြောင်းရင်းတစ်ခုမှာ enum layout optimization သည် alignment (မည်သည့်အရှည်ရှိသည့်အချပ်များအပါအ ၀ င်) များအားဆက်စပ်နေပြီးအခြား data များနှင့်ခွဲခြားရန် null မဟုတ်သောကိုးကားချက်များအပေါ်မှီခိုနိုင်သည်။
    ///
    ///     [`NonNull::dangling()`] ကို အသုံးပြု၍ သုညအချပ်များအတွက် `data` အဖြစ်သုံးနိုင်သော pointer ကိုသင်ရနိုင်သည်။
    ///
    /// * အချပ်၏စုစုပေါင်းအရွယ်အစား `ptr.len() * mem::size_of::<T>()` သည် `isize::MAX` ထက်မပိုစေရ။
    ///   [`pointer::offset`] ၏လုံခြုံရေးစာရွက်စာတမ်းများကိုကြည့်ပါ။
    ///
    /// * Rust ၏ aliasing rules များကိုသင်ပြenfor္ဌာန်းရပါမည်။
    ///   အထူးသဖြင့်၊ ဒီတစ်သက်တာအတွက် pointer မှမှတ်ထားသောမှတ်ဉာဏ်သည်မည်သည့်အခြား pointer မှမရရယူနိုင်ရမည် (ဖတ်ရန်သို့မဟုတ်ရေးသားခြင်း) ဖြစ်သည်။
    ///
    /// ဤနည်းလမ်း၏ရလဒ်ကိုအသုံးမပြုလျှင်ပင်ဤအချက်သည်သက်ဆိုင်ပါသည်။
    ///
    /// [`slice::from_raw_parts_mut`] ကိုလည်းရှုပါ။
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // `memory` ဖတ်နှင့် `memory.len()` အများအပြား bytes အဘို့အရေးသားခဲ့သည်များအတွက်တရားဝင်သည်အတိုင်းဤဘေးကင်းလုံခြုံသည်။
    /// // သတိပြုရမည်မှာ `memory.as_mut()` ကိုခေါ်ဆိုမှုကိုဤအရာသည်အကြောင်းအရာအားအသိမပေးသောကြောင့်ဤနေရာတွင်ခွင့်မပြုပါ။
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `as_uninit_slice_mut` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// စစ်ဆေးနေဘောငျလုပ်နေတာဘဲ, Element တစ်ခုရဲ့သို့မဟုတ် subslice တစ်ကုန်ကြမ်း pointer ကိုပြန်ပို့ပေးသည်။
    ///
    /// ဤနည်းလမ်းကို Out-of-bounds index နှင့်သို့မဟုတ် `self` dereferencable မပါလျှင်ခေါ်ဆိုမှုသည်ရလဒ်ညွှန်ပြကိုအသုံးမပြုလျှင်ပင် *[undefined behavior]* ဖြစ်သည်။
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // လုံခြုံမှု-ဖုန်းပြောသူက `self` က dereferencable ဖြစ်မယ်၊ `index` က in-bounds ဖြစ်တယ်။
        // အကျိုးဆက်အနေဖြင့်ရလဒ်ညွှန်ပြသူသည် NULL မဖြစ်နိုင်ပါ။
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // လုံခြုံမှု-ထူးခြားသောညွှန်ပြသူသည် null မဖြစ်နိုင်သဖြင့်အခြေအနေများ
        // new_unchecked() လေးစားကြသည်။
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // လုံခြုံမှု-ပြောင်းလဲနိုင်သောရည်ညွှန်းသည် null မဖြစ်နိုင်ပါ။
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // လုံခြုံမှု-ရည်ညွှန်းသည် null မဖြစ်နိုင်သဖြင့်အခြေအနေများ
        // new_unchecked() လေးစားကြသည်။
        unsafe { NonNull { pointer: reference as *const T } }
    }
}