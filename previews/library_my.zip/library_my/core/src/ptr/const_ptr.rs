use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::mem;
use crate::slice::{self, SliceIndex};

#[lang = "const_ptr"]
impl<T: ?Sized> *const T {
    /// အဆိုပါ pointer ကို null လျှင် `true` Returns ။
    ///
    /// သတိမပြုရသေးသောအမျိုးအစားများတွင်ဖြစ်နိုင်သော null pointers များစွာရှိသည်၊ သတိပြုရန်မှာကုန်ကြမ်းဒေတာအညွှန်းကိုသာစဉ်းစားသည်၊ သူတို့၏အရှည်၊ vtable စသည်
    /// ထို့ကြောင့်, null ဖြစ်ကြောင်းထောက်ပြနှစ်ခုနေဆဲအချင်းချင်းညီမျှနှိုင်းယှဉ်မည်မဟုတ်ပါ။
    ///
    /// ## const အကဲဖြတ်နေစဉ်အတွင်းအပြုအမူ
    ///
    /// ဒီလုပ်ဆောင်ချက်ကို const evaluation မှာအသုံးပြုတဲ့အခါ runtime မှာ null ဖြစ်သွားတဲ့ pointers များအတွက် `false` ကို return ပြန်လိမ့်မယ်။
    /// အချို့သောမှတ်ဉာဏ်တစ် pointer ရလဒ် pointer တရားမဝင်သောကြောင်းထိုကဲ့သို့သောလမ်းအတွက်ယင်း၏ဘောငျကျော်လွန် offset အခါအထူးသသည်, function ကိုနေဆဲ `false` ပြန်လာပါလိမ့်မယ်။
    ///
    /// CTFE သည်ထိုမှတ်ဉာဏ်၏ပကတိအနေအထားကိုသိရန်မည်သည့်နည်းလမ်းမျှမရှိသောကြောင့်ညွှန်ကိန်းသည် null ဟုတ်မဟုတ်မပြောနိုင်ပါ။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // သရုပ်ဆောင်များမှတစ်ဆင့်ပါးလွှာသော pointer နှင့်နှိုင်းယှဉ်ပါကအဆီ pointers များသည်သူတို့၏ "data" အစိတ်အပိုင်းကို null-ness အတွက်သာစဉ်းစားနေကြသည်။
        //
        (self as *const u8).guaranteed_eq(null())
    }

    /// အခြားအမျိုးအစားတစ် pointer မှ Casts ။
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// လိပ်စာနှင့် metadata အစိတ်အပိုင်းများကို (ဖြစ်နိုင်သည်ကျယ်ပြန့်သော) pointer ထဲသို့ပြိုကွဲသည်။
    ///
    /// pointer ကိုနောက်ပိုင်းတွင် [`from_raw_parts`] ဖြင့်ပြန်လည်တည်ဆောက်နိုင်သည်။
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// pointer သည် null ဖြစ်လျှင် `None` သို့ပြန်သွားသည်။ သို့မဟုတ်ပါက `Some` တွင်ပါ ၀ င်သောတန်ဖိုးကို shared ရည်ညွှန်းသည်။အကယ်၍ တန်ဖိုးကို uninitialized လုပ်နိုင်လျှင် [`as_uninit_ref`] ကိုအစားထိုးအသုံးပြုပါ။
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// ဤနည်းလမ်းကိုခေါ်ဆိုရာတွင် *ဖြစ်စေ* pointer သည် NULL ဖြစ်ကြောင်းသေချာစေရန် (သို့) အောက်ပါအချက်များအားလုံးမှန်ကန်ကြောင်းသေချာစေရန်-
    ///
    /// * အဆိုပါ pointer ကိုစနစ်တကျ alignment ကိုရမည်ဖြစ်သည်။
    ///
    /// * ၎င်းသည် [the module documentation] တွင်အဓိပ္ပာယ်ဖွင့်ဆိုချက်အရ "dereferencable" ဖြစ်ရမည်။
    ///
    /// * pointer သည် `T` ၏အစပြုဥပမာအားညွှန်ပြရမည်။
    ///
    /// * Rust ၏ aliasing rules များကိုသင်ပြenfor္ဌာန်းရပါမည်။
    ///   အထူးသဖြင့်၊ ဒီတစ်သက်တာကြာချိန်အတွက်ညွှန်ပြသည့်မှတ်ဉာဏ်သည် (`UnsafeCell` အတွင်းမှ လွဲ၍) ပြောင်းလဲခြင်းမပြုရ။
    ///
    /// ဤနည်းလမ်း၏ရလဒ်ကိုအသုံးမပြုလျှင်ပင်ဤအချက်သည်သက်ဆိုင်ပါသည်။
    /// (စတင်ခြင်းနှင့်ပတ်သက်သောအပိုင်းကိုအပြည့်အဝမဆုံးဖြတ်ရသေးသော်လည်း၎င်းသည်အမှန်တကယ်စတင်ခြင်းဖြစ်ကြောင်းသေချာစေရန်အတွက်သာဖြစ်သည်။)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # တရားမဝင်သောဗားရှင်း
    ///
    /// အကယ်၍ ညွှန်ပြသည်ဘယ်တော့မှမဖြစ်နိုင်ပါ၊ `Option<&T>` အစား `&T` ကိုပြန်ပေးသော `as_ref_unchecked` အချို့ကိုရှာဖွေနေသည်ဆိုပါစို့၊ သင် pointer ကိုတိုက်ရိုက် dereference နိုင်ကြောင်းသိထားပါ။
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူမှ `self` မှန်ကန်သည်ဟုအာမခံရမည်
        // တစ်ဦးကိုကိုးကားနိုင်ရန်ကြောင့် null မပါလျှင်။
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// အဆိုပါ pointer ကို null ဖြစ်လျှင်, သို့မဟုတ်အခြား `Some` အတွက်ပတ်ရစ်တန်ဖိုးတစ်ခု shared ရည်ညွှန်းပြန်လာလျှင် `None` ပြန်သွားသည်။
    /// [`as_ref`] နှင့်မတူဘဲ၎င်းသည်တန်ဖိုးကိုစတင်ရန်လိုအပ်သည်မဟုတ်ပါ။
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// ဤနည်းလမ်းကိုခေါ်ဆိုရာတွင် *ဖြစ်စေ* pointer သည် NULL ဖြစ်ကြောင်းသေချာစေရန် (သို့) အောက်ပါအချက်များအားလုံးမှန်ကန်ကြောင်းသေချာစေရန်-
    ///
    /// * အဆိုပါ pointer ကိုစနစ်တကျ alignment ကိုရမည်ဖြစ်သည်။
    ///
    /// * ၎င်းသည် [the module documentation] တွင်အဓိပ္ပာယ်ဖွင့်ဆိုချက်အရ "dereferencable" ဖြစ်ရမည်။
    ///
    /// * Rust ၏ aliasing rules များကိုသင်ပြenfor္ဌာန်းရပါမည်။
    ///
    ///   အထူးသဖြင့်၊ ဒီတစ်သက်တာကြာချိန်အတွက်ညွှန်ပြသည့်မှတ်ဉာဏ်သည် (`UnsafeCell` အတွင်းမှ လွဲ၍) ပြောင်းလဲခြင်းမပြုရ။
    ///
    /// ဤနည်းလမ်း၏ရလဒ်ကိုအသုံးမပြုလျှင်ပင်ဤအချက်သည်သက်ဆိုင်ပါသည်။
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // လုံခြုံမှု-ဖုန်းပြောသူသည် `self` အားလုံးနှင့်ကိုက်ညီရန်အာမခံရမည်
        // တစ် ဦး ကိုကိုးကားများအတွက်လိုအပ်ချက်များ။
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// အဆိုပါတစ် pointer ကနေ offset တွက်ချက်။
    ///
    /// `count` T ၏ယူနစ်၌ရှိ၏ဥပမာ-`count` of 3 သည် `3 * size_of::<T>()` bytes ၏ offset ကိုညွန်ပြသည်။
    ///
    /// # Safety
    ///
    /// အောက်ပါအခြေအနေတစ်ခုခုကိုချိုးဖောက်ပါကရလဒ်မှာသတ်မှတ်ထားသောအပြုအမူဖြစ်သည်။
    ///
    /// * စတင်ခြင်းနှင့်ရရှိလာတဲ့ pointer နှစ်ခုစလုံးသည်သတ်မှတ်ထားသောအရာဝတ္ထုတစ်ခု၏အဆုံးတွင် bounds သို့မဟုတ် byte တစ်ခုရှိရပါမည်။
    /// သတိပြုပါမှာ Rust တိုင်း (stack-allocated) variable ကိုသီးခြားခွဲထားသောအရာဝတ္ထုတစ်ခုအဖြစ်သတ်မှတ်သည်။
    ///
    /// * တွက်ချက်ထားသော offset **bytes** များရှိပါက `isize` ကိုမလျှံနိုင်ပါ။
    ///
    /// * အကန့်အသတ်ဖြင့်ရှိနေသော offset သည် "wrapping around" address address ကိုမမှီနိုင်ပါ။ဆိုလိုသည်မှာအဆုံးမဲ့-တိကျစွာပေါင်းလဒ်သည် ** bytes ဖြင့်ဖြစ်သည်။
    ///
    /// compiler နှင့် standard library များသည်ယေဘုယျအားဖြင့် allokations သည် offset နှင့်သက်ဆိုင်သောအရွယ်အစားသို့ဘယ်သောအခါမျှရောက်ရှိမည်ကိုသေချာစေရန်ကြိုးစားသည်။
    /// ဥပမာအားဖြင့် `Vec` နှင့် `Box` တို့သည် `isize::MAX` bytes ထက်ပိုပြီးခွဲဝေချထားပေးခြင်းမရှိသောကြောင့် `vec.as_ptr().add(vec.len())` သည်အမြဲတမ်းလုံခြုံသည်။
    ///
    /// ပလက်ဖောင်းအများစုသည်အခြေခံအားဖြင့်ထိုကဲ့သို့ခွဲဝေချထားပေးခြင်းများကိုပင် ပြုလုပ်၍ မရပါ
    /// ဥပမာအားဖြင့်အဘယ်သူမျှမလူသိများ 64-bit နဲ့ပလက်ဖောင်းအစဉ်အဆက် 2 <sup>63</sup> အဘို့အတောင်းဆိုမှုထမ်းဆောင်နိုင်စာမျက်နှာ-စားပွဲပေါ်မှာန့်အသတ်သို့မဟုတ်ပိုင်းခြားလိပ်စာအာကာသကြောင့် bytes ။
    /// သို့သော်အချို့သော 32-bit နှင့် 16-bit platform များသည် Physical Address Extension ကဲ့သို့သောအရာများနှင့်အတူ `isize::MAX` bytes ထက်ပိုမိုသောတောင်းဆိုမှုကိုအောင်မြင်စွာဆောင်ရွက်နိုင်သည်။
    ///
    /// ထိုကဲ့သို့သောကဲ့သို့, allocators သို့မဟုတ်မှတ်ဉာဏ်မြေပုံဖိုင်တွေကနေတိုက်ရိုက်ဝယ်ယူမှတ်ဉာဏ် * ဒီ function နှင့်အတူကိုင်တွယ်ရန်ကြီးမားလွန်းဖြစ်နိုင်သည်။
    ///
    /// ဤအကန့်သတ်ချက်များကျေနပ်လောက်ရန်ခက်ခဲပါကအစား [`wrapping_offset`] ကိုအသုံးပြုရန်စဉ်းစားပါ။
    /// ဤနည်းလမ်း၏တစ်ခုတည်းသောအားသာချက်မှာ ပိုမို၍ ရန်လိုသော compiler optimization များကိုပြုလုပ်နိုင်ခြင်းဖြစ်သည်။
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `offset` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
        unsafe { intrinsics::offset(self, count) }
    }

    /// wrapping arithmetic ကိုသုံးပြီး pointer တစ်ခုမှ offset ကိုတွက်ချက်သည်။
    ///
    /// `count` T ၏ယူနစ်၌ရှိ၏ဥပမာ-`count` of 3 သည် `3 * size_of::<T>()` bytes ၏ offset ကိုညွန်ပြသည်။
    ///
    /// # Safety
    ///
    /// ဒီစစ်ဆင်ရေးကိုယ်နှိုက်ကအမြဲတမ်းလုံခြုံတယ်၊
    ///
    /// `self` ထောက်ပြသည်သောတူညီခွဲဝေအရာဝတ္ထုမှပူးတွဲပါရရှိလာတဲ့ pointer ကိုအကြွင်းအကျန်။
    /// ၎င်းသည်မတူညီသောခွဲဝေထားသည့်အရာဝတ္ထုတစ်ခုကိုအသုံးပြုရန်အသုံးမပြုပါ။သတိပြုပါမှာ Rust တိုင်း (stack-allocated) variable ကိုသီးခြားခွဲထားသောအရာဝတ္ထုတစ်ခုအဖြစ်သတ်မှတ်သည်။
    ///
    /// တစ်နည်းပြောရလျှင် `let z = x.wrapping_offset((y as isize) - (x as isize))` သည် `z` ကို `y` နှင့် `T` အရွယ်အစား `1` အရွယ်အစားရှိသော်လည်းထပ်တိုးမှုမရှိဟုယူဆလျှင်တောင်မှ `z` နှင့်ထပ်တူမဖြစ်စေပါ။ `x` နှင့် `x` ပူးတွဲထားသောအရာဝတ္ထုနှင့်ချိတ်ဆက်နေဆဲဖြစ်ပြီး၊ တူညီသောခွဲဝေအရာဝတ္ထုသို့ `y` အမှတ်။
    ///
    /// [`offset`] နှင့်နှိုင်းယှဉ်ပါကဤနည်းလမ်းသည်အခြေခံအားဖြင့်တူညီသောခွဲဝေထားသည့်အရာဝတ္ထုအတွင်း၌နေရန်လိုအပ်ချက်ကိုနှောင့်နှေးစေသည်။ [`offset`] သည်အရာဝတ္ထုနယ်နိမိတ်ကိုဖြတ်ကျော်သောအခါချက်ချင်းသတ်မှတ်ထားသောအပြုအမူဖြစ်သည်။`wrapping_offset` သည် pointer တစ်ခုကိုထုတ်လုပ်သည်။ သို့သော်၎င်းသည်တွဲနေသောအရာဝတ္ထု၏အပြင်ဘက်တွင်ရှိပါကညွှန်ကိန်းကိုဖယ်ထုတ်ထားခြင်းမရှိလျှင်သတ်မှတ်ထားသောအပြုအမူကို ဦး တည်စေသည်။
    /// [`offset`] ပိုကောင်းအောင်လုပ်နိုင်ပြီးစွမ်းဆောင်ရည်အထိခိုက်မခံတဲ့ကုဒ်မှာပိုကောင်းတယ်။
    ///
    /// အဆိုပါနှောင့်နှေးစစ်ဆေးမှုများသာ dereferenced သော pointer မဟုတ်ဘဲနောက်ဆုံးရလဒ်များ၏တွက်ချက်မှုစဉ်အတွင်းအသုံးပြုသောအလယ်အလတ်တန်ဖိုးများ၏တန်ဖိုးသတ်မှတ်ထားသည်။
    /// ဥပမာအားဖြင့် `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` သည် `x` နှင့်အမြဲတမ်းတူညီသည်။တနည်းအားဖြင့်ခွဲဝေထားသည့်အရာဝတ္ထုကိုစွန့်ခွာပြီးနောက်ပြန်လည်ထည့်သွင်းခြင်းကိုခွင့်ပြုသည်။
    ///
    /// သငျသညျလက်ဝါးကပ်တိုင်အရာဝတ္ထုနယ်နိမိတ်ဖို့လိုအပ်ခဲ့လျှင်တစ်ခုကိန်းဖို့ pointer ကိုနှင်ထုတ်ခြင်းနှင့်ထိုအရပ်၌ဂဏန်းသင်္ချာလုပ်ပါ။
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// // ဒြပ်စင်နှစ်ခု၏နှစ်ဆတိုး။ ညွှန်ပြသည့်ကုန်ကြမ်းအမှတ်အသားကိုသုံးသည်
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // ဤသည်ကွင်းဆက် "1, 3, 5, " ထုတ်
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // လုံခြုံမှု-`arith_offset` ၏ပင်ကိုစရိုက်ကိုခေါ်ရန်လိုအပ်ချက်မရှိပါ။
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// နှစ်ခုထောက်ပြအကြားအကွာအဝေးတွက်ချက်သည်။return value သည် T ၏ unit များဖြစ်သည်။ bytes ရှိအကွာအဝေးကို `mem::size_of::<T>()` ဖြင့်ခွဲထားသည်။
    ///
    /// ဤသည် function ကို [`offset`] ၏ပြောင်းပြန်ဖြစ်ပါတယ်။
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// အောက်ပါအခြေအနေတစ်ခုခုကိုချိုးဖောက်ပါကရလဒ်မှာသတ်မှတ်ထားသောအပြုအမူဖြစ်သည်။
    ///
    /// * စတင်နှင့်အခြား pointer ကိုနှစ်ဦးစလုံးဘောငျသို့မဟုတ်တူညီသောခွဲဝေအရာဝတ္ထု၏အဆုံးအတိတ်တဦးတည်းက byte အတွက်ဖြစ်စေဖြစ်ရမည်။
    /// သတိပြုပါမှာ Rust တိုင်း (stack-allocated) variable ကိုသီးခြားခွဲထားသောအရာဝတ္ထုတစ်ခုအဖြစ်သတ်မှတ်သည်။
    ///
    /// * pointers နှစ်ခုလုံးကိုတူညီတဲ့ object ကို pointer ကနေဆင်းသက်လာရမယ်။
    ///   (ဥပမာတစ်ခုအတွက်အောက်တွင်ကြည့်ပါ။)
    ///
    /// * ညွှန်ကွားများအကြားအကွာအဝေးသည် bytes ဖြင့် `T` အရွယ်အစားအတိအကျဖြစ်ရမည်။
    ///
    /// * ညွှန်ကွားများအကြားရှိ ** ** bytes ** အတွင်းရှိ `isize` သည်မကျော်နိုင်ပါ။
    ///
    /// * နယ်နိမိတ်အတွင်းရှိအကွာအဝေးသည် "wrapping around" လိပ်စာနေရာကိုမမှီနိုင်ပါ။
    ///
    /// Rust အမျိုးအစားများသည် `isize::MAX` ထက်ဘယ်သောအခါမျှမကြီးပါ။ Rust ခွဲဝေသတ်မှတ်မှုများသည်လိပ်စာနေရာလွတ်ပတ် ၀ န်းကျင်တွင်ဘယ်တော့မျှမ ၀ တ်နိုင်ပါ။ ထို့ကြောင့်မည်သည့် Rust အမျိုးအစား `T` ၏တန်ဖိုးအချို့မှနောက်ဆုံးအခြေအနေနှစ်ခုကိုအမြဲကျေနပ်စေမည်နည်း။
    ///
    /// စံပြစာကြည့်တိုက်သည်ယေဘုယျအားဖြင့်ခွဲဝေချထားမှုသည် offset နှင့်သက်ဆိုင်သောအရွယ်အစားသို့ဘယ်သောအခါမျှရောက်ရှိမည်မဟုတ်ကြောင်းသေချာစေသည်။
    /// ဥပမာအားဖြင့် `Vec` နှင့် `Box` က၎င်းတို့သည် `isize::MAX` bytes ထက်ပိုပြီးခွဲဝေချထားပေးနိုင်ခြင်းမရှိစေရန်သေချာစေသဖြင့် `ptr_into_vec.offset_from(vec.as_ptr())` သည်နောက်ဆုံးအခြေအနေနှစ်ခုကိုအမြဲကျေနပ်စေပါသည်။
    ///
    /// ပလက်ဖောင်းအများစုသည်အခြေခံအားဖြင့်ထိုကဲ့သို့ကြီးမားသောခွဲဝေချထားပေးမှုများကိုပင်ပြုလုပ်နိုင်သည်မဟုတ်ပါ
    /// ဥပမာအားဖြင့်အဘယ်သူမျှမလူသိများ 64-bit နဲ့ပလက်ဖောင်းအစဉ်အဆက် 2 <sup>63</sup> အဘို့အတောင်းဆိုမှုထမ်းဆောင်နိုင်စာမျက်နှာ-စားပွဲပေါ်မှာန့်အသတ်သို့မဟုတ်ပိုင်းခြားလိပ်စာအာကာသကြောင့် bytes ။
    /// သို့သော်အချို့သော 32-bit နှင့် 16-bit platform များသည် Physical Address Extension ကဲ့သို့သောအရာများနှင့်အတူ `isize::MAX` bytes ထက်ပိုမိုသောတောင်းဆိုမှုကိုအောင်မြင်စွာဆောင်ရွက်နိုင်သည်။
    /// ထိုကဲ့သို့သောကဲ့သို့, allocators သို့မဟုတ်မှတ်ဉာဏ်မြေပုံဖိုင်တွေကနေတိုက်ရိုက်ဝယ်ယူမှတ်ဉာဏ် * ဒီ function နှင့်အတူကိုင်တွယ်ရန်ကြီးမားလွန်းဖြစ်နိုင်သည်။
    /// ([`offset`] နှင့် [`add`] တို့တွင်လည်းအလားတူကန့်သတ်ချက်များရှိနေခြင်းကြောင့်ကြီးမားသောခွဲဝေချထားမှုများတွင်လည်းအသုံးမပြုနိုင်ကြောင်းသတိပြုပါ။)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// `T` သည်သုညအရွယ်အစား ("ZST") ဖြစ်ပါကဤလုပ်ဆောင်မှုသည် panics ဖြစ်သည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// အသုံးပြုမှု * မမှန်ကန်ပါ။
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // ptr2_other ကို ptr2 ၏ "alias" တစ်ခုပြုလုပ်ပါ၊ သို့သော် ptr1 မှဆင်းသက်လာသည်။
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // ptr2_other နှင့် ptr2 ကို pointers မှကွဲပြားသော object များသို့ဆင်းသက်လာသောကြောင့်သူတို့ offset သည် address တူညီတဲ့ address သို့ညွှန်ပြသော်လည်း undefined behavior!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // သတ်မှတ်ထားသောအပြုအမူ
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `ptr_offset_from` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// နှစ်ခုထောက်ပြတန်းတူဖြစ်ဖို့အာမခံရှိမရှိပြန်သွားပါ။
    ///
    /// runtime မှာဤ function သည် `self == other` ကဲ့သို့ပြုမူသည်။
    /// သို့သော်အချို့သောအခြေအနေများ (ဥပမာ-compile-time evaluation) တွင် point နှစ်ခု၏တန်းတူညီမျှမှုကိုဆုံးဖြတ်ရန်အမြဲတမ်းမဖြစ်နိုင်ပါ။ ထို့ကြောင့်ဤ function သည်နောက်ပိုင်းတွင်အမှန်တကယ်တန်းတူညီမျှဖြစ်သွားသော pointers များအတွက် `false` ကို return ပြန်ပေးလိမ့်မည်။
    ///
    /// ဒါပေမယ့် `true` ကိုပြန်လာတဲ့အခါ၊
    ///
    /// ဤလုပ်ဆောင်ချက်သည် [`guaranteed_ne`] ၏မှန်ဖြစ်ပြီး၎င်းသည်ပြောင်းပြန်မဟုတ်ပါ။နှစ်ခုစလုံးလုပ်ဆောင်ချက်များကို `false` ပြန်လာသောအဘို့အ pointer နှိုင်းယှဉ်ရှိပါတယ်။
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// compiler ဗားရှင်းပေါ် မူတည်၍ return value သည်ပြောင်းလဲနိုင်သည်။ လုံခြုံမှုမရှိသော code သည်ဤလုပ်ဆောင်မှု၏ရလဒ်အပေါ်တွင်မမှီခိုပါ။
    /// ၎င်းလုပ်ဆောင်ချက်အား spurious `false` return တန်ဖိုးများသည်ရလဒ်ကိုအကျိုးသက်ရောက်စေရုံသာမကစွမ်းဆောင်ရည်ကိုပါထိခိုက်မှုမရှိသောစွမ်းဆောင်ရည်ပိုမိုကောင်းမွန်စေရန်ဤ function ကိုသာအသုံးပြုရန်အကြံပြုသည်။
    /// runtime နှင့် compile-time code ကွဲပြားစွာပြုမူရန်ဤနည်းလမ်းကိုအသုံးပြုခြင်း၏အကျိုးဆက်များကိုလေ့လာခြင်းမရှိသေးပါ။
    /// ဤနည်းလမ်းကိုထိုကဲ့သို့သောကွဲပြားခြားနားမှုများကိုမိတ်ဆက်ရန်မသုံးသင့်ပါ၊ ထို့အပြင်ကျွန်ုပ်တို့သည်ဤပြissueနာကိုပိုမိုနားလည်သဘောပေါက်ခြင်းမပြုမီတည်ငြိမ်မှုမရှိစေရပါ။
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self, other)
    }

    /// နှစ်ခုထောက်ပြမညီမျှမှုဖြစ်အာမခံနေကြသည်ရှိမရှိပြန်သွားသည်။
    ///
    /// runtime မှာဤ function သည် `self != other` ကဲ့သို့ပြုမူသည်။
    /// သို့သော်အချို့သောအခြေအနေများ (ဥပမာ-compile-time evaluation) တွင် point နှစ်ခု၏မညီမျှမှုကိုဆုံးဖြတ်ရန်အမြဲတမ်းမဖြစ်နိုင်ပါ။ ထို့ကြောင့်ဤ function သည်နောက်ပိုင်းတွင်အမှန်တကယ်မတူညီသောဖြစ်လာမည့် pointers များအတွက် `false` ကို return ပြန်ပေးလိမ့်မည်။
    ///
    /// ဒါပေမယ့် `true` ကိုပြန်လာတဲ့အခါ၊
    ///
    /// ဒီ function ဟာ [`guaranteed_eq`] ၏မှန်ပေမယ့်မပေးက၎င်း၏ပြောင်းပြန်ဖြစ်ပါတယ်။နှစ်ခုစလုံးလုပ်ဆောင်ချက်များကို `false` ပြန်လာသောအဘို့အ pointer နှိုင်းယှဉ်ရှိပါတယ်။
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// compiler ဗားရှင်းပေါ် မူတည်၍ return value သည်ပြောင်းလဲနိုင်သည်။ လုံခြုံမှုမရှိသော code သည်ဤလုပ်ဆောင်မှု၏ရလဒ်အပေါ်တွင်မမှီခိုပါ။
    /// ၎င်းလုပ်ဆောင်ချက်အား spurious `false` return တန်ဖိုးများသည်ရလဒ်ကိုအကျိုးသက်ရောက်စေရုံသာမကစွမ်းဆောင်ရည်ကိုပါထိခိုက်မှုမရှိသောစွမ်းဆောင်ရည်ပိုမိုကောင်းမွန်စေရန်ဤ function ကိုသာအသုံးပြုရန်အကြံပြုသည်။
    /// runtime နှင့် compile-time code ကွဲပြားစွာပြုမူရန်ဤနည်းလမ်းကိုအသုံးပြုခြင်း၏အကျိုးဆက်များကိုလေ့လာခြင်းမရှိသေးပါ။
    /// ဤနည်းလမ်းကိုထိုကဲ့သို့သောကွဲပြားခြားနားမှုများကိုမိတ်ဆက်ရန်မသုံးသင့်ပါ၊ ထို့အပြင်ကျွန်ုပ်တို့သည်ဤပြissueနာကိုပိုမိုနားလည်သဘောပေါက်ခြင်းမပြုမီတည်ငြိမ်မှုမရှိစေရပါ။
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self, other)
    }

    /// pointer မှတွက်ချက်သည် (`.offset(count as isize)`) အတွက်အဆင်ပြေသည်) ။
    ///
    /// `count` T ၏ယူနစ်၌ရှိ၏ဥပမာ-`count` of 3 သည် `3 * size_of::<T>()` bytes ၏ offset ကိုညွန်ပြသည်။
    ///
    /// # Safety
    ///
    /// အောက်ပါအခြေအနေတစ်ခုခုကိုချိုးဖောက်ပါကရလဒ်မှာသတ်မှတ်ထားသောအပြုအမူဖြစ်သည်။
    ///
    /// * စတင်ခြင်းနှင့်ရရှိလာတဲ့ pointer နှစ်ခုစလုံးသည်သတ်မှတ်ထားသောအရာဝတ္ထုတစ်ခု၏အဆုံးတွင် bounds သို့မဟုတ် byte တစ်ခုရှိရပါမည်။
    /// သတိပြုပါမှာ Rust တိုင်း (stack-allocated) variable ကိုသီးခြားခွဲထားသောအရာဝတ္ထုတစ်ခုအဖြစ်သတ်မှတ်သည်။
    ///
    /// * တွက်ချက်ထားသော offset **bytes** များရှိပါက `isize` ကိုမလျှံနိုင်ပါ။
    ///
    /// * အကန့်အသတ်ရှိရှိနေခြင်းသည် offset သည် "wrapping around" ၏လိပ်စာနေရာကိုမမှီနိုင်ပါ။ဆိုလိုသည်မှာအဆုံးမဲ့တိကျသောပေါင်းလဒ်သည် `usize` နှင့်ကိုက်ညီရမည်။
    ///
    /// compiler နှင့် standard library များသည်ယေဘုယျအားဖြင့် allokations သည် offset နှင့်သက်ဆိုင်သောအရွယ်အစားသို့ဘယ်သောအခါမျှရောက်ရှိမည်ကိုသေချာစေရန်ကြိုးစားသည်။
    /// ဥပမာအားဖြင့် `Vec` နှင့် `Box` တို့သည် `isize::MAX` bytes ထက်ပိုပြီးခွဲဝေချထားပေးခြင်းမရှိသောကြောင့် `vec.as_ptr().add(vec.len())` သည်အမြဲတမ်းလုံခြုံသည်။
    ///
    /// ပလက်ဖောင်းအများစုသည်အခြေခံအားဖြင့်ထိုကဲ့သို့ခွဲဝေချထားပေးခြင်းများကိုပင် ပြုလုပ်၍ မရပါ
    /// ဥပမာအားဖြင့်အဘယ်သူမျှမလူသိများ 64-bit နဲ့ပလက်ဖောင်းအစဉ်အဆက် 2 <sup>63</sup> အဘို့အတောင်းဆိုမှုထမ်းဆောင်နိုင်စာမျက်နှာ-စားပွဲပေါ်မှာန့်အသတ်သို့မဟုတ်ပိုင်းခြားလိပ်စာအာကာသကြောင့် bytes ။
    /// သို့သော်အချို့သော 32-bit နှင့် 16-bit platform များသည် Physical Address Extension ကဲ့သို့သောအရာများနှင့်အတူ `isize::MAX` bytes ထက်ပိုမိုသောတောင်းဆိုမှုကိုအောင်မြင်စွာဆောင်ရွက်နိုင်သည်။
    ///
    /// ထိုကဲ့သို့သောကဲ့သို့, allocators သို့မဟုတ်မှတ်ဉာဏ်မြေပုံဖိုင်တွေကနေတိုက်ရိုက်ဝယ်ယူမှတ်ဉာဏ် * ဒီ function နှင့်အတူကိုင်တွယ်ရန်ကြီးမားလွန်းဖြစ်နိုင်သည်။
    ///
    /// ဤအကန့်သတ်ချက်များကျေနပ်လောက်ရန်ခက်ခဲပါကအစား [`wrapping_add`] ကိုအသုံးပြုရန်စဉ်းစားပါ။
    /// ဤနည်းလမ်း၏တစ်ခုတည်းသောအားသာချက်မှာ ပိုမို၍ ရန်လိုသော compiler optimization များကိုပြုလုပ်နိုင်ခြင်းဖြစ်သည်။
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `offset` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
        unsafe { self.offset(count as isize) }
    }

    /// pointer မှတွက်ချက်မှုကိုတွက်ချက်သည် (`.offset အတွက်အဆင်ပြေသည် ((isize).wrapping_neg())`) ဟုရေတွက်ပါ)) ။
    ///
    /// `count` T ၏ယူနစ်၌ရှိ၏ဥပမာ-`count` of 3 သည် `3 * size_of::<T>()` bytes ၏ offset ကိုညွန်ပြသည်။
    ///
    /// # Safety
    ///
    /// အောက်ပါအခြေအနေတစ်ခုခုကိုချိုးဖောက်ပါကရလဒ်မှာသတ်မှတ်ထားသောအပြုအမူဖြစ်သည်။
    ///
    /// * စတင်ခြင်းနှင့်ရရှိလာတဲ့ pointer နှစ်ခုစလုံးသည်သတ်မှတ်ထားသောအရာဝတ္ထုတစ်ခု၏အဆုံးတွင် bounds သို့မဟုတ် byte တစ်ခုရှိရပါမည်။
    /// သတိပြုပါမှာ Rust တိုင်း (stack-allocated) variable ကိုသီးခြားခွဲထားသောအရာဝတ္ထုတစ်ခုအဖြစ်သတ်မှတ်သည်။
    ///
    /// * တွက်ချက်ထားသည့် offset သည် `isize::MAX` ** bytes ထက်မကျော်လွန်နိုင်ပါ။
    ///
    /// * အကန့်အသတ်ဖြင့်ရှိနေသော offset သည် "wrapping around" address address ကိုမမှီနိုင်ပါ။ဆိုလိုသည်မှာအဆုံးမဲ့တိကျသောပေါင်းလဒ်သည် usize နှင့်ပေါင်းရမည်။
    ///
    /// compiler နှင့် standard library များသည်ယေဘုယျအားဖြင့် allokations သည် offset နှင့်သက်ဆိုင်သောအရွယ်အစားသို့ဘယ်သောအခါမျှရောက်ရှိမည်ကိုသေချာစေရန်ကြိုးစားသည်။
    /// ဥပမာအားဖြင့် `Vec` နှင့် `Box` တို့သည် `isize::MAX` bytes ထက်ပိုပြီးခွဲဝေချထားပေးခြင်းမရှိသောကြောင့် `vec.as_ptr().add(vec.len()).sub(vec.len())` သည်အမြဲတမ်းလုံခြုံသည်။
    ///
    /// ပလက်ဖောင်းအများစုသည်အခြေခံအားဖြင့်ထိုကဲ့သို့ခွဲဝေချထားပေးခြင်းများကိုပင် ပြုလုပ်၍ မရပါ
    /// ဥပမာအားဖြင့်အဘယ်သူမျှမလူသိများ 64-bit နဲ့ပလက်ဖောင်းအစဉ်အဆက် 2 <sup>63</sup> အဘို့အတောင်းဆိုမှုထမ်းဆောင်နိုင်စာမျက်နှာ-စားပွဲပေါ်မှာန့်အသတ်သို့မဟုတ်ပိုင်းခြားလိပ်စာအာကာသကြောင့် bytes ။
    /// သို့သော်အချို့သော 32-bit နှင့် 16-bit platform များသည် Physical Address Extension ကဲ့သို့သောအရာများနှင့်အတူ `isize::MAX` bytes ထက်ပိုမိုသောတောင်းဆိုမှုကိုအောင်မြင်စွာဆောင်ရွက်နိုင်သည်။
    ///
    /// ထိုကဲ့သို့သောကဲ့သို့, allocators သို့မဟုတ်မှတ်ဉာဏ်မြေပုံဖိုင်တွေကနေတိုက်ရိုက်ဝယ်ယူမှတ်ဉာဏ် * ဒီ function နှင့်အတူကိုင်တွယ်ရန်ကြီးမားလွန်းဖြစ်နိုင်သည်။
    ///
    /// ဤအကန့်သတ်ချက်များကျေနပ်လောက်ရန်ခက်ခဲပါကအစား [`wrapping_sub`] ကိုအသုံးပြုရန်စဉ်းစားပါ။
    /// ဤနည်းလမ်း၏တစ်ခုတည်းသောအားသာချက်မှာ ပိုမို၍ ရန်လိုသော compiler optimization များကိုပြုလုပ်နိုင်ခြင်းဖြစ်သည်။
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `offset` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// wrapping arithmetic ကိုသုံးပြီး pointer တစ်ခုမှ offset ကိုတွက်ချက်သည်။
    /// (`.wrapping_offset(count as isize)`) အတွက်အဆင်ပြေပါတယ်
    ///
    /// `count` T ၏ယူနစ်၌ရှိ၏ဥပမာ-`count` of 3 သည် `3 * size_of::<T>()` bytes ၏ offset ကိုညွန်ပြသည်။
    ///
    /// # Safety
    ///
    /// ဒီစစ်ဆင်ရေးကိုယ်နှိုက်ကအမြဲတမ်းလုံခြုံတယ်၊
    ///
    /// `self` ထောက်ပြသည်သောတူညီခွဲဝေအရာဝတ္ထုမှပူးတွဲပါရရှိလာတဲ့ pointer ကိုအကြွင်းအကျန်။
    /// ၎င်းသည်မတူညီသောခွဲဝေထားသည့်အရာဝတ္ထုတစ်ခုကိုအသုံးပြုရန်အသုံးမပြုပါ။သတိပြုပါမှာ Rust တိုင်း (stack-allocated) variable ကိုသီးခြားခွဲထားသောအရာဝတ္ထုတစ်ခုအဖြစ်သတ်မှတ်သည်။
    ///
    /// တစ်နည်းပြောရလျှင် `let z = x.wrapping_add((y as usize) - (x as usize))` သည် `z` ကို `y` နှင့် `T` အရွယ်အစား `1` အရွယ်အစားရှိသော်လည်းထပ်တိုးမှုမရှိဟုယူဆလျှင်တောင်မှ `z` နှင့်ထပ်တူမဖြစ်စေပါ။ `x` နှင့် `x` ပူးတွဲထားသောအရာဝတ္ထုနှင့်ချိတ်ဆက်နေဆဲဖြစ်ပြီး၊ တူညီသောခွဲဝေအရာဝတ္ထုသို့ `y` အမှတ်။
    ///
    /// [`add`] နှင့်နှိုင်းယှဉ်ပါကဤနည်းလမ်းသည်အခြေခံအားဖြင့်တူညီသောခွဲဝေထားသည့်အရာဝတ္ထုအတွင်း၌နေရန်လိုအပ်ချက်ကိုနှောင့်နှေးစေသည်။ [`add`] သည်အရာဝတ္ထုနယ်နိမိတ်ကိုဖြတ်ကျော်သောအခါချက်ချင်းသတ်မှတ်ထားသောအပြုအမူဖြစ်သည်။`wrapping_add` သည် pointer တစ်ခုကိုထုတ်လုပ်သည်။ သို့သော်၎င်းသည်တွဲဖက်ထားသည့်အရာဝတ္ထု၏အပြင်ဘက်တွင်ရှိပါကညွှန်ကိန်းကိုဖယ်ထုတ်ထားခြင်းမရှိလျှင်သတ်မှတ်ထားသောအပြုအမူကို ဦး တည်စေသည်။
    /// [`add`] ပိုကောင်းအောင်လုပ်နိုင်ပြီးစွမ်းဆောင်ရည်အထိခိုက်မခံတဲ့ကုဒ်မှာပိုကောင်းတယ်။
    ///
    /// အဆိုပါနှောင့်နှေးစစ်ဆေးမှုများသာ dereferenced သော pointer မဟုတ်ဘဲနောက်ဆုံးရလဒ်များ၏တွက်ချက်မှုစဉ်အတွင်းအသုံးပြုသောအလယ်အလတ်တန်ဖိုးများ၏တန်ဖိုးသတ်မှတ်ထားသည်။
    /// ဥပမာအားဖြင့် `x.wrapping_add(o).wrapping_sub(o)` သည် `x` နှင့်အမြဲတမ်းတူညီသည်။တနည်းအားဖြင့်ခွဲဝေထားသည့်အရာဝတ္ထုကိုစွန့်ခွာပြီးနောက်ပြန်လည်ထည့်သွင်းခြင်းကိုခွင့်ပြုသည်။
    ///
    /// သငျသညျလက်ဝါးကပ်တိုင်အရာဝတ္ထုနယ်နိမိတ်ဖို့လိုအပ်ခဲ့လျှင်တစ်ခုကိန်းဖို့ pointer ကိုနှင်ထုတ်ခြင်းနှင့်ထိုအရပ်၌ဂဏန်းသင်္ချာလုပ်ပါ။
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// // ဒြပ်စင်နှစ်ခု၏နှစ်ဆတိုး။ ညွှန်ပြသည့်ကုန်ကြမ်းအမှတ်အသားကိုသုံးသည်
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // ဤသည်ကွင်းဆက် "1, 3, 5, " ထုတ်
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// wrapping arithmetic ကိုသုံးပြီး pointer တစ်ခုမှ offset ကိုတွက်ချက်သည်။
    /// (`.wrapping_offset အတွက်အဆင်ပြေသည် ((isize).wrapping_neg())`) ဟုရေတွက်သည်)
    ///
    /// `count` T ၏ယူနစ်၌ရှိ၏ဥပမာ-`count` of 3 သည် `3 * size_of::<T>()` bytes ၏ offset ကိုညွန်ပြသည်။
    ///
    /// # Safety
    ///
    /// ဒီစစ်ဆင်ရေးကိုယ်နှိုက်ကအမြဲတမ်းလုံခြုံတယ်၊
    ///
    /// `self` ထောက်ပြသည်သောတူညီခွဲဝေအရာဝတ္ထုမှပူးတွဲပါရရှိလာတဲ့ pointer ကိုအကြွင်းအကျန်။
    /// ၎င်းသည်မတူညီသောခွဲဝေထားသည့်အရာဝတ္ထုတစ်ခုကိုအသုံးပြုရန်အသုံးမပြုပါ။သတိပြုပါမှာ Rust တိုင်း (stack-allocated) variable ကိုသီးခြားခွဲထားသောအရာဝတ္ထုတစ်ခုအဖြစ်သတ်မှတ်သည်။
    ///
    /// တစ်နည်းအားဖြင့် `let z = x.wrapping_sub((x as usize) - (y as usize))` သည် `z` ကို `y` နှင့် `T` အရွယ်အစား `1` အရွယ်အစားရှိသော်လည်းထပ်တိုးမှုမရှိဟုယူဆလျှင်တောင်မှ `z` နှင့်ထပ်တူမဖြစ်စေပါ။ တူညီသောခွဲဝေအရာဝတ္ထုသို့ `y` အမှတ်။
    ///
    /// [`sub`] နှင့်နှိုင်းယှဉ်ပါကဤနည်းလမ်းသည်အခြေခံအားဖြင့်တူညီသောခွဲဝေထားသည့်အရာဝတ္ထုအတွင်း၌နေရန်လိုအပ်ချက်ကိုနှောင့်နှေးစေသည်။ [`sub`] သည်အရာဝတ္ထုနယ်နိမိတ်ကိုဖြတ်ကျော်သောအခါချက်ချင်းသတ်မှတ်ထားသောအပြုအမူဖြစ်သည်။`wrapping_sub` သည် pointer တစ်ခုကိုထုတ်လုပ်သည်။ သို့သော်၎င်းသည်တွဲနေသောအရာဝတ္ထု၏အပြင်ဘက်တွင်ရှိပါကညွှန်ကိန်းကိုဖယ်ထုတ်ထားခြင်းမရှိလျှင်သတ်မှတ်ထားသောအပြုအမူကို ဦး တည်စေသည်။
    /// [`sub`] ပိုကောင်းအောင်လုပ်နိုင်ပြီးစွမ်းဆောင်ရည်အထိခိုက်မခံတဲ့ကုဒ်မှာပိုကောင်းတယ်။
    ///
    /// အဆိုပါနှောင့်နှေးစစ်ဆေးမှုများသာ dereferenced သော pointer မဟုတ်ဘဲနောက်ဆုံးရလဒ်များ၏တွက်ချက်မှုစဉ်အတွင်းအသုံးပြုသောအလယ်အလတ်တန်ဖိုးများ၏တန်ဖိုးသတ်မှတ်ထားသည်။
    /// ဥပမာအားဖြင့် `x.wrapping_add(o).wrapping_sub(o)` သည် `x` နှင့်အမြဲတမ်းတူညီသည်။တနည်းအားဖြင့်ခွဲဝေထားသည့်အရာဝတ္ထုကိုစွန့်ခွာပြီးနောက်ပြန်လည်ထည့်သွင်းခြင်းကိုခွင့်ပြုသည်။
    ///
    /// သငျသညျလက်ဝါးကပ်တိုင်အရာဝတ္ထုနယ်နိမိတ်ဖို့လိုအပ်ခဲ့လျှင်တစ်ခုကိန်းဖို့ pointer ကိုနှင်ထုတ်ခြင်းနှင့်ထိုအရပ်၌ဂဏန်းသင်္ချာလုပ်ပါ။
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// // element နှစ်ခုကို (backwards) ၏နှစ်ဆတိုးမြှင့်ရာတွင် pointer raw ဖြင့်အသုံးပြုသည်
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // ဤသည်ကွင်းဆက် "5, 3, 1, " ထုတ်
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// pointer တန်ဖိုးကို `ptr` အဖြစ်သတ်မှတ်သည်။
    ///
    /// အမှု၌ `self` သည် unsized type တစ်ခုအတွက် (fat) pointer တစ်ခုဖြစ်ပါကဤလုပ်ဆောင်မှုသည် pointer အစိတ်အပိုင်းကိုသာထိခိုက်လိမ့်မည်။ (thin) pointers အရွယ်အစားအမျိုးအစားများအတွက်မူ၊ ၎င်းသည်ရိုးရိုးတာ ၀ န်ယူမှုနှင့်တူညီသည်။
    ///
    /// ရရှိလာသော pointer သည် `val` ၏သက်သေပြမှုဖြစ်လိမ့်မည်။ ဆိုလိုသည်မှာ fat pointer တစ်ခုအတွက်ဤစစ်ဆင်ရေးသည် data pointer value `val` ၏အညွှန်းအသစ်တစ်ခုနှင့် `self` ၏ metadata များနှင့်အတူတူဖြစ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ဒီ function ဟာ byte-winter pointer arithmetic ကိုအဆီရည်ညွှန်းတွေအတွက်ခွင့်ပြုဖို့အဓိကအားဖြင့်အသုံးဝင်သည်။
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &arr[0] as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // "3" print ထုတ်ပါလိမ့်မယ်
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *const u8) -> Self {
        let thin = &mut self as *mut *const T as *mut *const u8;
        // လုံခြုံမှု-ပါးနပ်သော pointer တစ်ခု၏အခြေအနေတွင်ဤစစ်ဆင်ရေးများသည်အတူတူပင်ဖြစ်သည်
        // ရိုးရှင်းတဲ့တာဝန်ကျတဲ့နေရာ။
        // fat pointer ၏လက်ရှိအဆီ pointer layout အကောင်အထည်ဖော်မှုနှင့်အတူထိုကဲ့သို့သော pointer ၏ပထမ ဦး ဆုံးနယ်ပယ်မှာအမြဲတမ်း data pointer ဖြစ်သည်။
        //
        unsafe { *thin = val };
        self
    }

    /// ၎င်းကိုမရွှေ့ဘဲ `self` မှတန်ဖိုးကိုဖတ်တယ်။
    /// ဤသည် `self` အတွက်မှတ်ဉာဏ်ကိုမပြောင်းလဲစေဘဲ။
    ///
    /// လုံခြုံရေးဆိုင်ရာစိုးရိမ်မှုများနှင့်နမူနာများအတွက် [`ptr::read`] ကိုကြည့်ပါ။
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `read` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
        unsafe { read(self) }
    }

    /// ၎င်းကိုမရွေ့စေဘဲ `self` မှတည်ငြိမ်သောဖတ်ခြင်းကိုလုပ်ဆောင်သည်။ဤသည် `self` အတွက်မှတ်ဉာဏ်မပြောင်းလဲချန်ထားမည်။
    ///
    /// မတည်ငြိမ်သောလုပ်ဆောင်မှုများသည် I/O memory ပေါ်တွင်လုပ်ဆောင်ရန်ရည်ရွယ်ထားပြီးအခြားမတည်ငြိမ်သောလုပ်ဆောင်မှုများတွင် compiler မှ elided သို့မဟုတ် reordered မပြုလုပ်နိုင်ပါ။
    ///
    ///
    /// လုံခြုံရေးဆိုင်ရာစိုးရိမ်မှုများနှင့်နမူနာများအတွက် [`ptr::read_volatile`] ကိုကြည့်ပါ။
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `read_volatile` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
        unsafe { read_volatile(self) }
    }

    /// ၎င်းကိုမရွှေ့ဘဲ `self` မှတန်ဖိုးကိုဖတ်တယ်။
    /// ဤသည် `self` အတွက်မှတ်ဉာဏ်ကိုမပြောင်းလဲစေဘဲ။
    ///
    /// `read` နဲ့မတူတာက pointer ဟာ unaligned ဖြစ်နိုင်ပါတယ်။
    ///
    /// လုံခြုံမှုဆိုင်ရာစိုးရိမ်မှုများနှင့်နမူနာများအတွက် [`ptr::read_unaligned`] ကိုကြည့်ပါ။
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `read_unaligned` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
        unsafe { read_unaligned(self) }
    }

    /// `self` မှ `dest` သို့ `count * size_of<T>` bytes များကိုကူးယူပါ။
    /// အရင်းအမြစ်နှင့် ဦး တည်ရာထပ်လိမ့်မည်။
    ///
    /// NOTE: ဒီ [`ptr::copy`] ကဲ့သို့ *တူညီသော* အငြင်းအခုံအမိန့်ရှိပါတယ်။
    ///
    /// လုံခြုံရေးဆိုင်ရာစိုးရိမ်မှုများနှင့်နမူနာများအတွက် [`ptr::copy`] ကိုကြည့်ပါ။
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `copy` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
        unsafe { copy(self, dest, count) }
    }

    /// `self` မှ `dest` သို့ `count * size_of<T>` bytes များကိုကူးယူပါ။
    /// အရင်းအမြစ်နှင့် ဦး တည်ရာသည် * ထပ်နေမည်မဟုတ်ပါ။
    ///
    /// NOTE: ဒီ [`ptr::copy_nonoverlapping`] ကဲ့သို့ *တူညီသော* အငြင်းအခုံအမိန့်ရှိပါတယ်။
    ///
    /// လုံခြုံရေးဆိုင်ရာစိုးရိမ်မှုများနှင့်နမူနာများအတွက် [`ptr::copy_nonoverlapping`] ကိုကြည့်ပါ။
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `copy_nonoverlapping` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// `align` နှင့်တည့်အောင်လုပ်ရန်အတွက် pointer ကိုအသုံးပြုရန်လိုအပ်သော offset ကိုတွက်ချက်သည်။
    ///
    /// pointer ကို align လုပ်ရန်မဖြစ်နိုင်ပါက implementation သည် `usize::MAX` ကို return ပြန်ပေးသည်။
    /// အကောင်အထည်ဖော်မှုအတွက် `usize::MAX` ကိုအမြဲတမ်းပြန်ပို့ရန်ခွင့်ပြုသည်။
    /// သင်၏ algorithm ၏စွမ်းဆောင်ရည်သည်သာမှန်ကန်မှုကိုမဟုတ်ဘဲအသုံးဝင်သော offset ရရှိရန်ပေါ်တွင်မူတည်သည်။
    ///
    /// offset သည် `T` element များ၏နံပါတ်များမဟုတ်ဘဲ bytes များဖြစ်သည်။ပြန်လာသောတန်ဖိုးကို `wrapping_add` နည်းလမ်းဖြင့်အသုံးပြုနိုင်သည်။
    ///
    /// pointer ကို offset ပြုလုပ်ခြင်းသည် overflow မည်မဟုတ်ပါသို့မဟုတ် pointer သို့ညွှန်ပြသောခွဲဝေမှုထက်ကျော်လွန်သွားလိမ့်မည် ဟူ၍ မည်သည့်အာမခံချက်မျှမရှိပါ။
    ///
    /// ပြန်ချိန်ညှိမှုသည် alignment အပြင်အခြားအသုံးအနှုန်းများအားလုံးတွင်မှန်ကန်မှုရှိမရှိသေချာစေရန်ဖုန်းခေါ်ဆိုသူသည်ဆုံးဖြတ်သည်။
    ///
    /// # Panics
    ///
    /// `align` သည်စွမ်းအင်နှစ်မျိုးမဟုတ်ပါကလုပ်ဆောင်ချက် panics ။
    ///
    /// # Examples
    ///
    /// `u16` အဖြစ်ကပ်လျက် `u8` ကိုအသုံးပြုခြင်း
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // pointer ကို `offset` မှတဆင့်ချိန်ညှိနိုင်သော်လည်း၎င်းသည်ခွဲဝေမှုပြင်ပကိုညွှန်ပြလိမ့်မည်
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // လုံခြုံမှု-`align` ကိုအထက်တွင်ဖော်ပြထားသောစွမ်းအား ၂ ကိုစစ်ဆေးသည်
        unsafe { align_offset(self, align) }
    }
}

#[lang = "const_slice_ptr"]
impl<T> *const [T] {
    /// ကုန်ကြမ်းအချပ်၏အရှည်ကိုပြန်သွားသည်။
    ///
    /// return ပြန်လာတဲ့တန်ဖိုးကတော့ ** element တွေရဲ့နံပါတ်ပဲ၊ bytes အရေအတွက်မဟုတ်ဘူး။
    ///
    /// pointer သည် null သို့မဟုတ် unaligned ဖြစ်သောကြောင့်ကုန်ကြမ်းအချပ်သည် slice reference သို့မပို့နိုင်လျှင်ပင်ဤလုပ်ဆောင်မှုသည်လုံခြုံသည်။
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // လုံခြုံမှု: `*const [T]` နှင့် `FatPtr<T>` အတူတူ layout ကိုရှိသည်ကြောင့်ဒီလုံခြုံဖြစ်ပါတယ်။
            // ဒီအာမခံချက်ကို `std` ကသာလုပ်နိုင်ပါတယ်။
            unsafe { Repr { rust: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// pointer တစ်မျိုးသည် slice ၏ကြားခံသို့ပြန်သွားသည်။
    ///
    /// ၎င်းသည် `self` ကို `*const T` သို့ပုံတူခြင်းနှင့်ညီသည်၊ သို့သော်ပိုမိုလုံခြုံသည်။
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), 0 as *const i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// စစ်ဆေးနေဘောငျလုပ်နေတာဘဲ, Element တစ်ခုရဲ့သို့မဟုတ် subslice တစ်ကုန်ကြမ်း pointer ကိုပြန်ပို့ပေးသည်။
    ///
    /// ဤနည်းလမ်းကို Out-of-bounds index နှင့်သို့မဟုတ် `self` dereferencable မပါလျှင်ခေါ်ဆိုမှုသည်ရလဒ်ညွှန်ပြကိုအသုံးမပြုလျှင်ပင် *[undefined behavior]* ဖြစ်သည်။
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: SliceIndex<[T]>,
    {
        // လုံခြုံမှု-ဖုန်းပြောသူက `self` က dereferencable ဖြစ်မယ်၊ `index` က in-bounds ဖြစ်တယ်။
        unsafe { index.get_unchecked(self) }
    }

    /// pointer သည် null ဖြစ်လျှင် `None` သို့ပြန်သွားသည်။ သို့မဟုတ်ပါက shared slice ကို `Some` တွင်ထည့်ထားသောတန်ဖိုးသို့ပြန်သွားသည်။
    /// [`as_ref`] နှင့်မတူဘဲ၎င်းသည်တန်ဖိုးကိုစတင်ရန်လိုအပ်သည်မဟုတ်ပါ။
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// ဤနည်းလမ်းကိုခေါ်ဆိုရာတွင် *ဖြစ်စေ* pointer သည် NULL ဖြစ်ကြောင်းသေချာစေရန် (သို့) အောက်ပါအချက်များအားလုံးမှန်ကန်ကြောင်းသေချာစေရန်-
    ///
    /// * `ptr.len() * mem::size_of::<T>()` အမြောက်အများကိုဖတ်ရန်အတွက် pointer သည် [valid] ဖြစ်ရမည်။ ၎င်းကိုစနစ်တကျချိန်ညှိရမည်။အထူးသဖြင့်ဆိုလိုသည်
    ///
    ///     * ဒီအချပ်၏မှတ်ဉာဏ်အကွာအဝေးတစ်ခုလုံးကိုခွဲဝေထားသည့်အရာဝတ္ထုတစ်ခုအတွင်းပါရမည်။
    ///       ချပ်သည်မျိုးစုံခွဲဝေထားသောအရာဝတ္ထုများကိုဘယ်တော့မှ ဖြတ်၍ မရနိုင်ပါ။
    ///
    ///     * သုညအရှည်ချပ်များအတွက်ပင် pointer ကိုချိန်ညှိရမည်။
    ///     ထိုသို့ဖြစ်ရခြင်းမှာအကြောင်းရင်းတစ်ခုမှာ enum layout optimization သည် alignment (မည်သည့်အရှည်ရှိသည့်အချပ်များအပါအ ၀ င်) များအားဆက်စပ်နေပြီးအခြား data များနှင့်ခွဲခြားရန် null မဟုတ်သောကိုးကားချက်များအပေါ်မှီခိုနိုင်သည်။
    ///
    ///     [`NonNull::dangling()`] ကို အသုံးပြု၍ သုညအချပ်များအတွက် `data` အဖြစ်သုံးနိုင်သော pointer ကိုသင်ရနိုင်သည်။
    ///
    /// * အချပ်၏စုစုပေါင်းအရွယ်အစား `ptr.len() * mem::size_of::<T>()` သည် `isize::MAX` ထက်မပိုစေရ။
    ///   [`pointer::offset`] ၏လုံခြုံရေးစာရွက်စာတမ်းများကိုကြည့်ပါ။
    ///
    /// * Rust ၏ aliasing rules များကိုသင်ပြenfor္ဌာန်းရပါမည်။
    ///   အထူးသဖြင့်၊ ဒီတစ်သက်တာကြာချိန်အတွက်ညွှန်ပြသည့်မှတ်ဉာဏ်သည် (`UnsafeCell` အတွင်းမှ လွဲ၍) ပြောင်းလဲခြင်းမပြုရ။
    ///
    /// ဤနည်းလမ်း၏ရလဒ်ကိုအသုံးမပြုလျှင်ပင်ဤအချက်သည်သက်ဆိုင်ပါသည်။
    ///
    /// [`slice::from_raw_parts`][] ကိုလည်းရှုပါ။
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူသည် `as_uninit_slice` အတွက်လုံခြုံမှုစာချုပ်ကိုထိန်းသိမ်းရမည်။
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// ထောက်ပြသူများအတွက်တန်းတူညီမျှမှု
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// ထောက်ပြများအတွက်နှိုင်းယှဉ်
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}