use crate::iter;
use crate::num::Wrapping;

/// ကြားမှာတက်ဖွဲ့ခြင်းဖြင့်ဖန်တီးနိုင်သောအမျိုးအစားများကိုကိုယ်စားပြုရန် Trait ။
///
/// ဤ trait သည်ကြားဖြတ်များ၌ [`sum()`] နည်းလမ်းကိုအကောင်အထည်ဖော်ရန်အသုံးပြုသည်။
/// အဆိုပါ trait အကောင်အထည်ဖော်ဖို့ရာမျိုးကို [`sum()`] နည်းလမ်းအားဖြင့်ထုတ်ပေးနိုင်ပါသည်။
/// [`FromIterator`] ကဲ့သို့ပင်ဤ trait ကိုတိုက်ရိုက်ခေါ်ဆိုရန်ခဲယဉ်းပြီး၎င်းအစား [`Iterator::sum()`] မှတစ်ဆင့်ဆက်သွယ်မှုပြုသည်။
///
///
/// [`sum()`]: Sum::sum
/// [`FromIterator`]: iter::FromIterator
#[stable(feature = "iter_arith_traits", since = "1.12.0")]
pub trait Sum<A = Self>: Sized {
    /// တစ်ခုကြားမှာကြာနှင့် "summing up" အားဖြင့်ဒြပ်စင်ပစ္စည်းများမှ `Self` ထုတ်ပေးထားတဲ့နည်းလမ်း။
    ///
    #[stable(feature = "iter_arith_traits", since = "1.12.0")]
    fn sum<I: Iterator<Item = A>>(iter: I) -> Self;
}

/// တစ်ဦးကြားမှာ၏ဒြပ်စင်ပွားအသုံးပြုနေသူများကဖန်တီးနိုင်အမျိုးအစားများကိုကိုယ်စားပြု Trait ။
///
/// ဤ trait သည်ကြားဖြတ်များ၌ [`product()`] နည်းလမ်းကိုအကောင်အထည်ဖော်ရန်အသုံးပြုသည်။
/// အဆိုပါ trait အကောင်အထည်ဖော်ဖို့ရာမျိုးကို [`product()`] နည်းလမ်းအားဖြင့်ထုတ်ပေးနိုင်ပါသည်။
/// [`FromIterator`] လိုပဲဒီ trait ခဲတိုက်ရိုက်အစား [`Iterator::product()`] မှတဆင့်အတူအပြန်အလှန်ဟုခေါ်ဝေါ်ခြင်းကိုခံရသင့်ပါတယ်။
///
///
/// [`product()`]: Product::product
/// [`FromIterator`]: iter::FromIterator
///
#[stable(feature = "iter_arith_traits", since = "1.12.0")]
pub trait Product<A = Self>: Sized {
    /// တစ်ခုကြားမှာကြာနှင့်ပစ္စည်းများကိုမပွားများအားဖြင့်ဒြပ်စင်ထံမှ `Self` ထုတ်ပေးထားတဲ့နည်းလမ်း။
    ///
    #[stable(feature = "iter_arith_traits", since = "1.12.0")]
    fn product<I: Iterator<Item = A>>(iter: I) -> Self;
}

macro_rules! integer_sum_product {
    (@impls $zero:expr, $one:expr, #[$attr:meta], $($a:ty)*) => ($(
        #[$attr]
        impl Sum for $a {
            fn sum<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    $zero,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[$attr]
        impl Product for $a {
            fn product<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    $one,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }

        #[$attr]
        impl<'a> Sum<&'a $a> for $a {
            fn sum<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    $zero,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[$attr]
        impl<'a> Product<&'a $a> for $a {
            fn product<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    $one,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }
    )*);
    ($($a:ty)*) => (
        integer_sum_product!(@impls 0, 1,
                #[stable(feature = "iter_arith_traits", since = "1.12.0")],
                $($a)*);
        integer_sum_product!(@impls Wrapping(0), Wrapping(1),
                #[stable(feature = "wrapping_iter_arith", since = "1.14.0")],
                $(Wrapping<$a>)*);
    );
}

macro_rules! float_sum_product {
    ($($a:ident)*) => ($(
        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl Sum for $a {
            fn sum<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    0.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl Product for $a {
            fn product<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    1.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl<'a> Sum<&'a $a> for $a {
            fn sum<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    0.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl<'a> Product<&'a $a> for $a {
            fn product<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    1.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }
    )*)
}

integer_sum_product! { i8 i16 i32 i64 i128 isize u8 u16 u32 u64 u128 usize }
float_sum_product! { f32 f64 }

#[stable(feature = "iter_arith_traits_result", since = "1.16.0")]
impl<T, U, E> Sum<Result<U, E>> for Result<T, E>
where
    T: Sum<U>,
{
    /// အဆိုပါ [`Iterator`] အတွက်တစ်ဦးချင်းစီဒြပ်စင်ကြာ: ကတစ်ဦး [`Err`] လျှင်အဘယ်သူမျှမကနောက်ထပ် element တွေကိုခေါ်ဆောင်သွားကြသည်ကို၎င်း, [`Err`] ပြန်ရောက်နေပါတယ်။
    /// [`Err`] မဖြစ်ပေါ်ပါက element အားလုံး၏ပေါင်းလဒ်ကိုပြန်လည်ရရှိမည်။
    ///
    /// # Examples
    ///
    /// ဤသည်သည် vector ရှိကိန်းတစ်ခုစီကိုအကျဉ်းချုပ်။ အနုတ်လက္ခဏာရှိသောဒြပ်စင်တစ်ခုတွေ့ရှိပါကပေါင်းလဒ်ကိုပယ်ချခြင်းဖြစ်သည်။
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let res: Result<i32, &'static str> = v.iter().map(|&x: &i32|
    ///     if x < 0 { Err("Negative element found") }
    ///     else { Ok(x) }
    /// ).sum();
    /// assert_eq!(res, Ok(3));
    /// ```
    ///
    ///
    fn sum<I>(iter: I) -> Result<T, E>
    where
        I: Iterator<Item = Result<U, E>>,
    {
        iter::process_results(iter, |i| i.sum())
    }
}

#[stable(feature = "iter_arith_traits_result", since = "1.16.0")]
impl<T, U, E> Product<Result<U, E>> for Result<T, E>
where
    T: Product<U>,
{
    /// အဆိုပါ [`Iterator`] အတွက်တစ်ဦးချင်းစီဒြပ်စင်ကြာ: ကတစ်ဦး [`Err`] လျှင်အဘယ်သူမျှမကနောက်ထပ် element တွေကိုခေါ်ဆောင်သွားကြသည်ကို၎င်း, [`Err`] ပြန်ရောက်နေပါတယ်။
    /// အဘယ်သူမျှမ [`Err`] ပေါ်ပေါက်သင့်ပါတယ်, အားလုံးဒြပ်စင်များ၏ထုတ်ကုန်ပြန်ရောက်နေပါတယ်။
    ///
    fn product<I>(iter: I) -> Result<T, E>
    where
        I: Iterator<Item = Result<U, E>>,
    {
        iter::process_results(iter, |i| i.product())
    }
}

#[stable(feature = "iter_arith_traits_option", since = "1.37.0")]
impl<T, U> Sum<Option<U>> for Option<T>
where
    T: Sum<U>,
{
    /// အဆိုပါ [`Iterator`] အတွက်တစ်ဦးချင်းစီဒြပ်စင်ကြာ: ကတစ် [`None`] လျှင်အဘယ်သူမျှမကနောက်ထပ် element တွေကိုခေါ်ဆောင်သွားကြသည်ကို၎င်း, [`None`] ပြန်ရောက်နေပါတယ်။
    /// အဘယ်သူမျှမ [`None`] ပေါ်ပေါက်သင့်ပါတယ်, အားလုံးဒြပ်စင်များ၏ပေါင်းလဒ်ပြန်ရောက်နေပါတယ်။
    ///
    /// # Examples
    ///
    /// အကယ်၍ စကားလုံးတစ်လုံးတွင် 'a' အက္ခရာမပါရှိပါကဤလုပ်ဆောင်မှုသည် `None` ကို return ပြန်ပေးသည်မှာ strings of vector ရှိ 'a' ၏အနေအထားဖြစ်သည်။
    ///
    ///
    /// ```
    /// let words = vec!["have", "a", "great", "day"];
    /// let total: Option<usize> = words.iter().map(|w| w.find('a')).sum();
    /// assert_eq!(total, Some(5));
    /// ```
    ///
    fn sum<I>(iter: I) -> Option<T>
    where
        I: Iterator<Item = Option<U>>,
    {
        iter.map(|x| x.ok_or(())).sum::<Result<_, _>>().ok()
    }
}

#[stable(feature = "iter_arith_traits_option", since = "1.37.0")]
impl<T, U> Product<Option<U>> for Option<T>
where
    T: Product<U>,
{
    /// အဆိုပါ [`Iterator`] အတွက်တစ်ဦးချင်းစီဒြပ်စင်ကြာ: ကတစ် [`None`] လျှင်အဘယ်သူမျှမကနောက်ထပ် element တွေကိုခေါ်ဆောင်သွားကြသည်ကို၎င်း, [`None`] ပြန်ရောက်နေပါတယ်။
    /// [`None`] မဖြစ်ပေါ်ပါက element အားလုံး၏ထုတ်ကုန်ကိုပြန်ပို့သည်။
    ///
    fn product<I>(iter: I) -> Option<T>
    where
        I: Iterator<Item = Option<U>>,
    {
        iter.map(|x| x.ok_or(())).product::<Result<_, _>>().ok()
    }
}