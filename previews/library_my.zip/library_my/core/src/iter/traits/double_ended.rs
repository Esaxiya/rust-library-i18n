use crate::ops::{ControlFlow, Try};

/// နှစ်ဦးစလုံးစွန်းမှဒြပ်စင်လိုက်လျောပေးနိုင်တစ်ခုကြားမှာ။
///
/// ထို့အပြင်ကျောကနေ `Item`s ယူနိုင်စွမ်းအဖြစ်ရှေ့: သုံးကိရိယာ `DoubleEndedIterator` သုံးကိရိယာ [`Iterator`] ကြောင်းအရာတစ်ခုခုအပေါ်မှာတယောက်အပိုလုပ်နိုင်စွမ်းရှိကြောင်းတစ်ခုခု။
///
///
/// ဒါဟာတူညီတဲ့အကွာအဝေးပေါ်ပြန်နှင့်ထွက်အလုပ်နှစ်ခုလုံးကြောင့်မှတ်စုအရေးကြီးသောဖြစ်ပြီး, လက်ဝါးကပ်တိုင်ကိုမကျင့်: သူတို့အလယ်၌တွေ့ဆုံရန်လာသောအခါကြားမှာကျော်ဖြစ်ပါတယ်။
///
/// အဆိုပါ [`Iterator`] protocol ကိုမှအလားတူဖက်ရှင်အတွက်တစ်ဦး `DoubleEndedIterator` တစ်ဖန် may သို့မဟုတ်အစဉ်အဆက်ကိုထပ် [`Some`] မပြန်စေခြင်းငှါကတောင်းဆိုတစ် [`next_back()`] ထံမှ [`None`] ပြန်လည်ရောက်ရှိ။
/// [`next()`] နှင့် [`next_back()`] ဒီရည်ရွယ်ချက်အတွက်လဲလှယ်ဖြစ်ကြသည်။
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// အခြေခံအသုံးပြုမှု-
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// အဆိုပါကြားမှာ၏အဆုံးမှဖယ်ထုတ်ခြင်းနှင့်ပြန် Element တစ်ခုရဲ့။
    ///
    /// `None` မပိုဒြပ်စင်ရှိပါတယ်သည့်အခါ Returns ။
    ///
    /// အဆိုပါ [trait-level] စာရွက်စာတမ်းများအသေးစိတ်ဆံ့။
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// : အဆိုပါဒြပ်စင် [`Iterator`] 's နည်းလမ်းများအားဖြင့်လြှော့မြားကှာခွားစခွေငျးငှါ DoubleEndedIterator`ရဲ့နည်းလမ်းများ` အားဖြင့်လြှော့
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// `n` ဒြပ်စင်များကနောက်ကျောကနေကြားမှာလာပြီ။
    ///
    /// `advance_back_by` [`advance_by`] များ၏ပြောင်းပြန်ဗားရှင်းဖြစ်ပါတယ်။ဤနည်းလမ်းကိုစိတ်အားထက်သန်စွာ [`None`] ကြုံတွေ့သည်အထိ `n` ကြိမ်မှ [`next_back`] တက်ခေါ်ဆိုခြင်းဖြင့်နောက်ကျောကနေစတင် `n` ဒြပ်စင်ကိုကျော်သွားပါလိမ့်မယ်။
    ///
    /// `advance_back_by(n)` `k` ဒြပ်စင်များ၏အရေအတွက်ကြားမှာဒြပ်စင်ထဲက running မတိုင်မီအားဖြင့် advanced သည်အဘယ်မှာရှိ [`None`], ကြုံတွေ့လျက်ရှိသည်လျှင်ကြားမှာအောင်မြင်စွာ `n` element များသို့မဟုတ် [`Err(k)`] အားဖြင့်တိုးတက်လာလျှင်ဆိုလိုသည်မှာ ([`Ok(())`] ပြန်လာပါလိမ့်မယ်
    /// အဆိုပါကြားမှာ၏အရှည်) ။
    /// `k` အမြဲလျော့နည်း `n` ထက်ကြောင်းသတိပြုပါ။
    ///
    /// `advance_back_by(0)` Calling မဆိုဒြပ်စင်လောင်ခြင်းနှင့်အစဉ်အမြဲ [`Ok(())`] ပြန်လာမထားဘူး။
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // သာ `&3` skip ခဲ့သည်
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// အဆိုပါကြားမှာ၏အဆုံးကနေ `n`th ဒြပ်စင် Returns ။
    ///
    /// ဒါဟာမရှိမဖြစ်လိုအပ်တဲ့ [`Iterator::nth()`] များ၏ပြောင်းပြန်ဗားရှင်းဖြစ်ပါတယ်။
    /// အများဆုံး indexing စစ်ဆင်ရေးများကဲ့သို့ဖြစ်သော်လည်း `nth_back(0)`, အဆုံးကနေပထမဦးဆုံးတန်ဖိုးကို return ပွနျ `nth_back(1)` ဒုတိယ, ဒါကြောင့်အပေါ်သို့မှသာယင်းအရေအတွက်, သုညကနေစတင်ပါသည်။
    ///
    ///
    /// အဆုံးနှင့်ပြန်လာသည့် element အကြားရှိ element အားလုံးသည် return ပြန်ရောက်သည့် element အပါအဝင်အပါအ ၀ င်ဖြစ်သည်။
    /// ဤသည်ကိုလည်းအတူတူပင်ကြားမှာအပေါ်အကြိမ်ပေါင်းများစွာ `nth_back(0)` တောင်းဆိုကွဲပြားခြားနားသောဒြပ်စင်ပြန်လာလိမ့်မည်ဟုဆိုလိုသည်။
    ///
    /// `nth_back()` အကယ်၍ `n` သည် iterator ၏အရှည်ထက်ကြီးမြင့်သို့မဟုတ်ညီမျှလျှင် [`None`] ကိုပြန်လာလိမ့်မည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// `nth_back()` အကြိမ်ပေါင်းများစွာ Calling အဆိုပါကြားမှာပြန်မရစ်ပါဘူး:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// `n + 1` ဒြပ်စင်ထက်နည်းလျှင် `None` ကိုပြန်ပို့သည်-
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// ဤသည် [`Iterator::try_fold()`] များ၏ပြောင်းပြန်ဗားရှင်းဖြစ်ပါသည်: ကကြားမှာ၏နောက်ကျောကနေစတင်ဒြပ်စင်ကြာပါသည်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // ၎င်းသည် short-circuute ဖြစ်သောကြောင့်ကျန်ရှိသော element များအား iterator မှတစ်ဆင့်ရရှိနိုင်သည်။
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// နောက်ကျောကနေစတင်တစ်ခုတည်း, နောက်ဆုံးတန်ဖိုးကိုဖို့ကြားမှာရဲ့ element တွေကိုပါလျော့ကျစေပါတယ်တစ်ခုကြားမှာနည်းလမ်း။
    ///
    /// ၎င်းသည် [`Iterator::fold()`] ၏ပြောင်းပြန်ပုံစံဖြစ်သည်။ ၎င်းသည်ကြားမှာ၏နောက်ကျောမှ စတင်၍ element များကိုယူသည်။
    ///
    /// `rfold()` အငြင်းပွားမှုနှစ်ခုကိုပြုလုပ်သည်။ ကန ဦး တန်ဖိုးတစ်ခုနှင့်အငြင်းပွားမှုနှစ်ခုပါသောပိတ်သိမ်းမှုတစ်ခု-'accumulator' နှင့် element တစ်ခုဖြစ်သည်
    /// အဆိုပါပိတ်သိမ်းစုစည်းနေခြင်းကိုနောက်ကြားမှာအဘို့ရှိသင့်ကြောင်းတန်ဖိုးကို return ပွနျ။
    ///
    /// ကနဦးတန်ဖိုးစုဆောင်းခြင်းကိုပထမဦးဆုံးခေါ်ဆိုခအပေါ်ရပါလိမ့်မယ်တန်ဖိုးဖြစ်ပါတယ်။
    ///
    /// အဆိုပါကြားမှာအမှုအမျိုးမျိုးရှိသမျှဒြပ်စင်ရန်ဤပိတ်သိမ်းလျှောက်ထားပြီးနောက် `rfold()` စုစည်းနေခြင်းပြန်လည်ရောက်ရှိ။
    ///
    /// ဤသည်စစ်ဆင်ရေးတခါတရံ 'reduce' သို့မဟုတ် 'inject' ဟုခေါ်သည်။
    ///
    /// သငျသညျအရာတစ်ခုခုတစ်ဦးစုဆောင်းမှုရှိသည်, ကနေတစ်ခုတည်းတန်ဖိုးကိုထုတ်လုပ်ရန်လိုသောအခါတိုင်းခေါက်အသုံးဝင်သည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // တစ် ဦး ၏ဒြပ်စင်အပေါငျးတို့သ၏ပေါင်းလဒ်
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// ဒီဥပမာကနဦးတန်ဖိုးကိုနှင့်အတူစတင်များနှင့်နောက်ကျောကနေရှေ့သည်အထိတစ်ဦးချင်းစီဒြပ်စင်နှင့်အတူဆက်လက်တစ်ဦး string ကိုတည်ဆောက်:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// ကျေနပ်နေတဲ့ predicate နောက်ကျောကနေတစ်ခုကြားမှာတစ်ဦးဒြပ်စင်အဘို့ရှာဖွေမှု။
    ///
    /// `rfind()` `true` သို့မဟုတ် `false` ပြန်လည်ရောက်ရှိကြောင်းပိတ်သိမ်းကြာပါသည်။
    /// ဒါဟာအဆုံးမှာစတင်, ထိုကြားမှာအသီးအသီးဒြပ်စင်ရန်ဤပိတ်သိမ်းသက်ဆိုင်, သူတို့မဆို `true` သို့ပြန်လာလျှင်, ထို့နောက် `rfind()` [`Some(element)`] ပြန်လည်ရောက်ရှိ။
    /// ထိုသူအပေါင်းတို့ `false` ပြန်လာပါက [`None`] ပြန်လည်ရောက်ရှိ။
    ///
    /// `rfind()` Short-circuiting ဖြစ်၏တစ်နည်းဆိုရလျှင်၎င်းသည် `true` ကိုပြန်လည်ရောက်ရှိသည်နှင့်ချက်ချင်းလုပ်ဆောင်ခြင်းကိုရပ်တန့်သွားလိမ့်မည်။
    ///
    /// အဘယ်ကြောင့်ဆိုသော် `rfind()` သည်ရည်ညွှန်းမှုယူပြီး၊ ကြားဖြတ်များအများအပြားသည်ညွှန်းဆိုချက်များအပေါ်တွင်ထပ်ခါတလဲလဲပြုလုပ်သောကြောင့်၎င်းသည်အငြင်းပွားမှုသည်ရည်ညွှန်းချက်နှစ်ဆရှိသောရှုပ်ထွေးဖွယ်အခြေအနေကိုဖြစ်ပေါ်စေသည်။
    ///
    /// သငျသညျ `&&x` နှင့်အတူအောက်ပါဥပမာမှာဒီအကျိုးသက်ရောက်မှုကိုတွေ့မြင်နိုင်ပါတယ်။
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// ပထမဦးဆုံး `true` မှာရပ်တန့်:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // ဒြပ်စင်တွေပိုများနေလို့ကျွန်တော်တို့ `iter` ကိုသုံးနိုင်သေးတယ်။
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}