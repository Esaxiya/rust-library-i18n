/// တစ်ဦး [`Iterator`] ထံမှကူးပြောင်းခြင်း။
///
/// အမျိုးအစားအဘို့အ `FromIterator` အကောင်အထည်ဖော်ခြင်းအားဖြင့်, သင်ကတစ်ခုကြားမှာအနေဖြင့်ဖန်တီးပါလိမ့်မည်ကိုမည်သို့သတ်မှတ်။
/// ဒါဟာအချို့မျိုးတစ်ဦးစုဆောင်းမှုကိုဖော်ပြရန်ထားတဲ့အမျိုးအစားများများအတွက်ဘုံဖြစ်ပါတယ်။
///
/// [`FromIterator::from_iter()`] ခဲအတိအလင်းဟုခေါ်သည်နှင့်အစား [`Iterator::collect()`] နည်းလမ်းမှတစ်ဆင့်အသုံးပြုသည်။
///
/// နောက်ထပ်ဥပမာများအတွက် [`Iterator::collect()`]'s စာရွက်စာတမ်းများကိုကြည့်ပါ။
///
/// ကြည့်ရှုပါ- [`IntoIterator`].
///
/// # Examples
///
/// အခြေခံအသုံးပြုမှု-
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// လုံးလုံးလြားလြား `FromIterator` သုံးစွဲဖို့ [`Iterator::collect()`] အသုံးပြုခြင်း:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// သင်၏အမျိုးအစားအတွက် `FromIterator` ကိုအကောင်အထည်ဖော်ခြင်း-
///
/// ```
/// use std::iter::FromIterator;
///
/// // Vec ကာကွယ်ဆေးကိုရေကူးရုံ wrapper ရဲ့တစ်ဦးကနမူနာစုဆောင်းခြင်း,<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // ဒါကိုနည်းစနစ်တွေပေးပြီးဒါတစ်ခုဖန်တီးပြီးအရာတွေကိုထပ်ထည့်နိုင်တယ်။
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ကျနော်တို့အကောင်အထည်ဖော်လိမ့်မယ် FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // ယခုငါတို့အသစ်တခုကြားမှာဖြစ်စေနိုင်ပါတယ် ...
/// let iter = (0..5).into_iter();
///
/// // ... ဒါကြောင့်ထဲက MyCollection အောင်
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // Collections လွန်းအလုပ်လုပ်တယ်!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// တစ်ဦးကြားမှာနေတဲ့တန်ဖိုးကဖန်တီးပေးပါတယ်။
    ///
    /// ပိုပြီးများအတွက် [module-level documentation] ကိုကြည့်ပါ။
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// တစ် ဦး [`Iterator`] သို့ကူးပြောင်း။
///
/// အမျိုးအစားအဘို့အ `IntoIterator` အကောင်အထည်ဖော်ခြင်းအားဖြင့်, သင်ကတစ်ဦးကြားမှာပြောင်းလဲကြလိမ့်မည်ကိုမည်သို့သတ်မှတ်။
/// ဒါဟာအချို့မျိုးတစ်ဦးစုဆောင်းမှုကိုဖော်ပြရန်ထားတဲ့အမျိုးအစားများများအတွက်ဘုံဖြစ်ပါတယ်။
///
/// `IntoIterator` အကောင်အထည်ဖော်တစ်ခုမှာအကျိုးအတွက်သင့်ရဲ့အမျိုးအစား [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator) လိမ့်မည်ဖြစ်ပါသည်။
///
///
/// ကြည့်ရှုပါ- [`FromIterator`].
///
/// # Examples
///
/// အခြေခံအသုံးပြုမှု-
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// သင့်ရဲ့အမျိုးအစားအဘို့အ `IntoIterator` အကောင်အထည်ဖော်:
///
/// ```
/// // Vec ကာကွယ်ဆေးကိုရေကူးရုံ wrapper ရဲ့တစ်ဦးကနမူနာစုဆောင်းခြင်း,<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // ဒါကိုနည်းစနစ်တွေပေးပြီးဒါတစ်ခုဖန်တီးပြီးအရာတွေကိုထပ်ထည့်နိုင်တယ်။
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ကျနော်တို့အကောင်အထည်ဖော်လိမ့်မယ် IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // ယခုငါတို့အသစ်တစ်ခုကိုစုစည်းစေနိုင်သည် ...
/// let mut c = MyCollection::new();
///
/// // ... ဒါကြောင့်တချို့ပစ္စည်းပစ္စယ add ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... ပြီးတော့တစ်ခုကြားမှာသို့လှည့်:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// ဒါဟာ trait bound အဖြစ် `IntoIterator` သုံးစွဲဖို့ဘုံဖြစ်ပါတယ်။ဤသည်ဤမျှကာလပတ်လုံးနေဆဲတစ်ခုကြားမှာသည်အတိုင်း, ပြောင်းလဲမှုဖို့ input ကိုစုစည်း type ကိုခွင့်ပြုပါတယ်။
/// အပိုဆောင်းဘောငျအပေါ်ကန့်သတ်ခြင်းဖြင့်သတ်မှတ်ထားသောနိုင်ပါသည်
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// ကျော်လွှတ်မည်ကိုတော့ထုတ်ဖော်ပြောကြားသွားခြင်းခံရဒြပ်စင်အမျိုးအစား။
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// မည်သည့်ကြားဖြတ်အမျိုးအစားကိုကျွန်ုပ်တို့သို့ပြောင်းလဲစေသနည်း။
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// တန်ဖိုးအနေဖြင့်တစ်ဦးကြားမှာဖန်တီးပေးပါတယ်။
    ///
    /// ပိုပြီးများအတွက် [module-level documentation] ကိုကြည့်ပါ။
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// တစ်ဦးကြားမှာရဲ့ contents နှင့်အတူတစ်ဦးစုဆောင်းမှုကိုတိုးချဲ့။
///
/// Iterator များသည်တန်ဖိုးများကိုထုတ်လုပ်သည်။ collection များကိုတန်ဖိုးများအဖြစ်သတ်မှတ်နိုင်သည်။
/// အဆိုပါ `Extend` trait သင်ကြားမှာရဲ့ contents အပါအဝင်တစ်ဦးစုဆောင်းမှုကိုတိုးချဲ့ခွင့်ပြု, ဒီကွာဟမှုဆိုထားသည်။
/// တစ်ခုပြီးသားရှိပြီးသား Key ကိုအတူတစ်ဦးစုဆောင်းမှုတိုးချဲ့သည့်အခါ, ထို entry ကိုတန်းတူသော့နှင့်အတူမျိုးစုံ entries တွေကိုခွင့်ပြုကြောင်း collection များကို၏ဖြစ်ရပ်အတွက်ကြောင့် entry ကိုဖြည့်စွက်သည် updated သို့မဟုတ်ဖြစ်ပါတယ်။
///
///
/// # Examples
///
/// အခြေခံအသုံးပြုမှု-
///
/// ```
/// // သငျသညျအခြို့သော char နဲ့ String ကိုတိုးချဲ့နိုင်သည်
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// `Extend` ကိုအကောင်အထည်ဖော်သည်-
///
/// ```
/// // Vec ကာကွယ်ဆေးကိုရေကူးရုံ wrapper ရဲ့တစ်ဦးကနမူနာစုဆောင်းခြင်း,<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // ဒါကိုနည်းစနစ်တွေပေးပြီးဒါတစ်ခုဖန်တီးပြီးအရာတွေကိုထပ်ထည့်နိုင်တယ်။
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // MyCollection i32s များစာရင်းကိုရှိပါတယ်ကတည်းကကျနော်တို့ i32 များအတွက် Extend အကောင်အထည်ဖော်ရန်
/// impl Extend<i32> for MyCollection {
///
///     // ဒါကကွန်ကရစ်အမျိုးအစားလက်မှတ်နှင့်အတူနည်းနည်းရိုးရှင်းတဲ့ဖြစ်ပါသည်: ကျွန်တော် i32s ကျွန်တော်တို့ကိုပေးသောတစ်ခုကြားမှာသို့လှည့်နိုင်သည့်အရာကိုမဆိုအပေါ်တိုးချဲ့ခေါ်နိုင်ပါတယ်။
///     // ကျနော်တို့ MyCollection ထဲသို့သွင်းထားရန် i32s လိုအပ်လို့ပဲ။
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // အကောင်အထည်ဖော်မှုသည်အလွန်လွယ်ကူသည်-iterator မှတဆင့်ကွင်းဆက်နှင့် element တစ်ခုချင်းစီကို add() ကိုမိမိကိုယ်တိုင်လုပ်ရန်။
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // ကျွန်တော်တို့ရဲ့စုဆောင်းမှုကိုနောက်ထပ်နံပါတ်သုံးခုတိုးချဲ့ရအောင်
/// c.extend(vec![1, 2, 3]);
///
/// // ကျနော်တို့ကဒီ element တွေကိုအဆုံးပေါ်ထည့်သွင်းပြီးပါပြီ
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// စုဆောင်းမှုတစ်ခုကြားမှာ၏ contents နှင့်အတူတိုးချဲ့။
    ///
    /// ဤ trait များအတွက်သာလိုအပ်သောနည်းလမ်းဖြစ်ပါတယ်သကဲ့သို့, [trait-level] စာရွက်စာတမ်းများအသေးစိတ်ဆံ့။
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// // သငျသညျအခြို့သော char နဲ့ String ကိုတိုးချဲ့နိုင်သည်
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// တစ်ခုအတိအကျဒြပ်စင်နှင့်အတူတစ်ဦးစုဆောင်းမှုကိုတိုးချဲ့။
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// အပိုဆောင်းဒြပ်စင်များ၏ပေးထားသောအရေအတွက်အဘို့အစုဆောင်းမှုအတွက်စွမ်းရည်သိုလှောင်။
    ///
    /// ကို default အကောင်အထည်ဖော်မှုဘာမျှမပါဘူး။
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}