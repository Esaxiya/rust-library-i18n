// လျစ်လျူရှု-သပ်ရပ်-filelength ဤဖိုင်နီးပါးသီးသန့် `Iterator` ၏အဓိပ္ပါယ်ပါဝင်ပါသည်။
// ကျနော်တို့မျိုးစုံဖိုင်တွေသို့ကြောင့်ခွဲထွက်လို့မရပါဘူး။
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// ကြားမှာနှင့်ဆက်ဆံရာတွင်တစ်ခု interface ကို။
///
/// ၎င်းသည် trait ၏အဓိကကြားခံဖြစ်သည်။
/// ယေဘုယျအားဖြင့်ကြားမှာ၏အယူအဆနှင့် ပတ်သက်. ပိုမိုအဘို့, [module-level documentation] ကြည့်ရှုပါ။
/// အထူးသဖြင့်, သင်မည်ကဲ့သို့ [implement `Iterator`][impl] မှသိလိုပေမည်။
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// ကျော်လွှတ်မည်ကိုတော့ထုတ်ဖော်ပြောကြားသွားခြင်းခံရဒြပ်စင်အမျိုးအစား။
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// အဆိုပါကြားမှာတိုးတက်လာခြင်းနှင့်နောင်လာမည့်တန်ဖိုးကို return ပွနျ။
    ///
    /// ကြားမှာပြီးဆုံးသောအခါ [`None`] Returns ။
    /// တစ်ဦးချင်းကြားမှာ Implementation ကိုကြားမှာပြန်လည်စတင်ဖို့ရွေးချယ်စေခြင်းငှါ, နောက်တဖန် `next()` တောင်းဆိုဒီတော့သို့မဟုတ်နောက်ဆုံးမှာတစ်ချိန်ချိန်နောက်တဖန် [`Some(Item)`] ပြန်စတင်ရန်မပြုစေခြင်းငှါဖြစ်နိုင်သည်။
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // next() မှတစ်ဦးကခေါ်ဆိုခလာမည့်တန်ဖိုးကို return ပွနျ ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... ပြီးတော့သူကကျော်တစ်ချိန်ကအဘယ်သူမျှမ။
    /// assert_eq!(None, iter.next());
    ///
    /// // ပိုများသောဖုန်းခေါ်ဆိုမှုသို့မဟုတ် `None` မပြန်စေခြင်းငှါဖြစ်နိုင်သည်။ဤတွင်သူတို့သည်အမြဲဖြစ်လိမ့်မည်။
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// ကျန်တည့်တည့်၏အရှည်ပေါ်ရှိအကန့်အသတ်များကိုပြန်ပေးတယ်။
    ///
    /// အတိအကျပြောရလျှင် `size_hint()` သည်ပထမဆုံး element သည်အနိမ့်ဘောင်းဖြစ်ပြီးဒုတိယ element သည်အပေါ်ဆုံးဖြစ်သည်။
    ///
    /// ပြန်ရောက်သော tuple ၏ဒုတိယထက်ဝက် `တစ်ဦး [` Option`]`<`[`usize`]`> ဖြစ်ပါတယ်။
    /// ဤနေရာတွင် [`None`] ဆိုသည်မှာမည်သည့်အထက်အကန့်မှမရှိ၊ သို့မဟုတ်အထက်ဘောင်းမှာ [`usize`] ထက်ကြီးသည်ဟုဆိုလိုသည်။
    ///
    /// # အကောင်အထည်ဖော်မှုမှတ်စုများ
    ///
    /// ဒါဟာတစ်ဦးကြားမှာအကောင်အထည်ဖော်မှုဒြပ်စင်များ၏ကြေငြာအရေအတွက်ကိုဖြစ်ထွန်းကြောင်းပြဌာန်းသည်မဟုတ်။တစ်ဦးကယုန်ကလေးကြားမှာလျော့နည်းအောက်ပိုင်းခညျြနှောငျသို့မဟုတ်အထက်ဒြပ်စင်၏ခညျြနှောငျထက်ပိုမိုထက်လိုက်လျောလိမ့်မည်။
    ///
    /// `size_hint()` အဓိကအားဖြင့်၎င်းကိုကြားဖြတ်၏ဒြပ်စင်များနေရာချန်လှပ်ခြင်းကဲ့သို့သောပိုမိုကောင်းမွန်သောနေရာများတွင်အသုံးပြုရန်ရည်ရွယ်သည်။ သို့သော်ယုံကြည်စိတ်ချရမည်မဟုတ်ပါ၊
    /// `size_hint()` တစ်ခုမမှန်ကန်ကြောင်းအကောင်အထည်ဖော်မှုမှတ်ဉာဏ်ဘေးကင်းလုံခြုံမှုချိုးဖောက်မှုများဦးတည်သွားစေသင့်ပါဘူး။
    ///
    /// ဒါကမဟုတ်ရင်က trait ရဲ့ protocol ၏တစ်ဦးကိုချိုးဖောက်ပါလိမ့်မယ်ဘာဖြစ်လို့လဲဆိုတော့အကောင်အထည်ဖော်မှုတစ်မှန်ကန်သောခန့်မှန်းချက်ပေးသင့်တယ်ဟုပြောသည်။
    ///
    /// ပုံသေအကောင်အထည်ဖော်မှုသည် `(0,` [`None`]`)`ကို return ပြန်သည်။
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// တစ်ဦးကပိုမိုရှုပ်ထွေးဥပမာ:
    ///
    /// ```
    /// // သုညကနေတစ်ဆယ်အထိ။
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // ကျနော်တို့တဆယ်ကြိမ်မှသုညကနေ iterate ပေလိမ့်မည်။
    /// // filter() ကိုမသုံးပဲငါးခုဆိုတာအတိအကျသိနိုင်မှာမဟုတ်ဘူး။
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // ရဲ့ chain() နှင့်အတူငါးကိုပိုမိုနံပါတ်များကိုထပ်ထည့်ပါစို့
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // ယခုနှစ်ဦးစလုံးဘောငျငါးခုတိုးနေကြတယ်
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// တစ်ဦးအပေါ်ပိုင်းဆီးတားဘို့ `None` ပြန်လာ:
    ///
    /// ```
    /// // အဆုံးမဲ့ကြားမှာအမြင့်ဆုံးနှင့်အနိမ့်ဆုံးအနိမ့်အမြင့်မရှိပါ
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// ကြားမှာအရေအတွက်ကိုရေတွက်ပြီးပြန်ပို့သည်။
    ///
    /// [`None`] ကြုံတွေ့သည်အထိဤနည်းလမ်းကိုပြုလုပ် [`Some`] ကိုမြင်လျှင်အကြိမ်အရေအတွက်ကပြန်လာ, ထပ်တလဲလဲ [`next`] မခေါ်ပါလိမ့်မယ်။
    /// သတိပြုရမည်မှာ [`next`] တွင်ကြားဖြတ်ဒြပ်စင်မရှိသော်ငြားအနည်းဆုံးတစ်ကြိမ်ခေါ်ရန်လိုအပ်သည်။
    ///
    /// [`next`]: Iterator::next
    ///
    /// # လျတ်အပြုအမူ
    ///
    /// အဆိုပါနည်းလမ်းကိုဖြစ်စေပိုပြီး [`usize::MAX`] ဒြပ်စင်ထက်နှင့်အတူတစ်ဦးကြားမှာဤမျှရေတွက်ဒြပ်စင်လျှံဆန့်ကျင်ခြင်းမရှိ Guard မမှားရလဒ်သို့မဟုတ် panics ထုတ်လုပ်သည်။
    ///
    /// ဒီဘာဂ်အခိုင်အမာ enabled နေတယ်ဆိုရင်တစ် panic အာမခံချက်ဖြစ်ပါတယ်။
    ///
    /// # Panics
    ///
    /// ဒီ function တန်ခိုးကြီးသည့်ကြားမှာပိုပြီး [`usize::MAX`] ဒြပ်စင်ထက်ရှိပါတယ်လျှင် panic ။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// ပြီးခဲ့သည့်ဒြပ်စင်ပြန်လာသည့်ကြားမှာစားသုံး။
    ///
    /// က [`None`] ပြန်လည်ရောက်ရှိသည်အထိဤနည်းလမ်းကြားမှာအကဲဖြတ်ပါလိမ့်မယ်။
    /// ထိုသို့လုပ်ဆောင်နေစဉ်၎င်းသည်လက်ရှိ element ကိုခြေရာခံသည်။
    /// [`None`] ပြန်ရောက်ပြီးနောက်, `last()` ထို့နောက်မြင်ပြီးခဲ့သည့်ဒြပ်စင်ပြန်လာပါလိမ့်မယ်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// `n` ဒြပ်စင်အားဖြင့်ကြားမှာလာပြီ။
    ///
    /// ဤနည်းလမ်းကိုစိတ်အားထက်သန်စွာ [`None`] ကြုံတွေ့သည်အထိ `n` ကြိမ်မှ [`next`] တက်ခေါ်ဆိုခြင်းဖြင့် `n` ဒြပ်စင်ကိုကျော်သွားပါလိမ့်မယ်။
    ///
    /// `advance_by(n)` အကယ်၍ ကြားမှာ `n` ဒြပ်စင်များအောင်မြင်စွာတိုးတက်လာလျှင် X0 [`Ok(())`][Ok] သို့ပြန်သွားပါလိမ့်မယ်။ ဒါမှမဟုတ် [`None`] ကိုတွေ့ရင် [`Err(k)`][Err] ကိုပြန်သွားပါလိမ့်မယ်။ `k` ဒြပ်စင်အလှည့်ကျမတိုင်မီပြုလုပ်သောကြားမှာတိုးမြှင့်ထားသောဒြပ်စင်အရေအတွက်ဖြစ်ပါသည်။
    /// အဆိုပါကြားမှာ၏အရှည်) ။
    /// `k` အမြဲလျော့နည်း `n` ထက်ကြောင်းသတိပြုပါ။
    ///
    /// `advance_by(0)` Calling မဆိုဒြပ်စင်လောင်ခြင်းနှင့်အစဉ်အမြဲ [`Ok(())`][Ok] ပြန်လာမထားဘူး။
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // `&4` ကိုသာခုန်ကျော်ခဲ့သည်
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// ကြားမှာ၏ `n`th element ကိုပြန်သွားသည်။
    ///
    /// အများဆုံး indexing စစ်ဆင်ရေးလိုပဲရေတွက် `nth(0)` ပထမဦးဆုံးတန်ဖိုး `nth(1)` ဒုတိယပြန်လာနိုင်အောင်, သုညကနေစတင်ပါသည်နှင့်ဒါပေါ်မှာ။
    ///
    /// အားလုံးရှေ့ဒြပ်စင်အဖြစ်ပြန်ရောက်ဒြပ်စင်သည်ကြားမှာထံမှကိုလောင်လိမ့်မည်ဟုမှတ်ချက်။
    /// ရှေ့ element တွေကိုတူညီတဲ့ကြားမှာအပေါ် `nth(0)` အကြိမ်ပေါင်းများစွာတောင်းဆိုကွဲပြားခြားနားသောဒြပ်စင်ပြန်လာလိမ့်မည်ဟုလည်းစွန့်ပစ်နှင့်မည်နည်းလမ်းများဖြစ်သည်။
    ///
    ///
    /// `nth()` အကယ်၍ `n` သည် iterator ၏အရှည်ထက်ကြီးမြင့်သို့မဟုတ်ညီမျှလျှင် [`None`] ကိုပြန်လာလိမ့်မည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// `nth()` အကြိမ်ပေါင်းများစွာ Calling အဆိုပါကြားမှာပြန်မရစ်ပါဘူး:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// `n + 1` ဒြပ်စင်ထက်နည်းလျှင် `None` ကိုပြန်ပို့သည်-
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// တူညီသောအချက်မှာစတင်တခုကြားမှာဖန်တီးပေမယ့်တစ်ဦးချင်းစီကြားမှာမှာပေးထားသောငွေပမာဏအားဖြင့်နင်း။
    ///
    /// မှတ်ချက် 1: ကြားမှာ၏ပထမဦးဆုံးဒြပ်စင်အစဉ်အမြဲမသက်ဆိုင်ပေးသောခြေလှမ်း၏, ပြန်ရောက်လိမ့်မည်။
    ///
    /// မှတ်ချက် 2: လျစ်လျူရှု element တွေကိုဆွဲထုတ်ထားတဲ့မှာအချိန် fixed မပေးပါ။
    /// `StepBy` အဆိုပါ sequence ကို `next(), nth(step-1), nth(step-1),…` တူသောပြုမူနေ, ဒါပေမယ့်လည်း sequence ကိုလိုပဲအလုပ်လုပ်တယ်အခမဲ့ဖြစ်ပါသည်
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// ဘယ်လမ်းစွမ်းဆောင်ရည်အကြောင်းပြချက်တချို့ကြားမှာများအတွက်မေလပြောင်းလဲမှုကိုအသုံးပြုသည်။
    /// ဒုတိယလမ်းအဆိုပါနှစ်ထက်လည်းစောသောကြားမှာတိုးမည်ကိုပိုမိုပစ္စည်းများလောင်လိမ့်မည်။
    ///
    /// `advance_n_and_return_first` ညီမျှသည်
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// အဆိုပါနည်းလမ်းကိုအလိုတော် panic ပေးထားသောခြေလှမ်း `0` လျှင်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// နှစ်ခုကြားမှာကြာနှင့် sequence ကိုအတွက်နှစ်ဦးစလုံးကျော်သစ်တစ်ခုကြားမှာဖန်တီးပေးပါတယ်။
    ///
    /// `chain()` ပထမဦးဆုံးဒုတိယကြားမှာထံမှတန်ဖိုးများကိုကျော်ပြီးတော့ပထမဦးဆုံးကြားမှာကနေတန်ဖိုးများကိုကျော် iterate နှင့်တံ့သောသစ်တစ်ခုကြားမှာပြန်လာပါလိမ့်မယ်။
    ///
    /// တနည်းအားဖြင့်ဒါဟာကွင်းဆက်အတွက်အတူတကွနှစ်ခုကြားမှာချိတ်ဆက်ထားပါတယ်။🔗
    ///
    /// [`once`] လေ့ကြားမှာတခြားမျိုး၏ကွင်းဆက်သို့တစ်ခုတည်းတန်ဖိုးကိုလိုက်လျောညီထွေဖြစ်အောင်အသုံးပြုသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `chain()` ဖို့အငြင်းအခုံ [`IntoIterator`] ကိုအသုံးပြုချိန် မှစ. ငါတို့သည်မယ့်တစ်ဦး [`Iterator`] သူ့ဟာသူတစ်ခု [`Iterator`] သို့ကူးပြောင်းနိုင်ဘာမှလွန်သွားနိုင်ပါတယ်။
    /// ဥပမာအားဖြင့် (`&[T]`) အချပ်များသည် [`IntoIterator`] ကိုအကောင်အထည်ဖော်ပြီး `chain()` သို့တိုက်ရိုက်လွှဲပြောင်းနိုင်သည်
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// သငျသညျ Windows API ဖြင့်အလုပ်လုပ်လျှင်သင် `Vec<u16>` မှ [`OsStr`] ပြောင်းလဲပေးဖို့လိုလိမ့်မယ်:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// အားလုံးတစ်တစ်ခုတည်းကြားမှာသို့နှစ်ခုကြားမှာ '' တက် Zips '' ။
    ///
    /// `zip()` ပြန်ကိုပထမဦးဆုံးဒြပ်စင်ကိုပထမဦးဆုံးကြားမှာထံမှလာ, ဒုတိယ element ကဒုတိယကြားမှာမှလာဘယ်မှာ tuple ပြန်လာနှစ်ခုသည်အခြားကြားမှာကျော် iterate လိမ့်မည်ဟုအသစ်တခုကြားမှာ။
    ///
    ///
    /// တနည်းအားဖြင့်ဒါဟာတစ်ခုတည်းသောတစ်ဦးသို့အတူတကွနှစ်ခုကြားမှာ zips ။
    ///
    /// ကြားမှာပုဇစ်ဖိုင်အဖြစ်ကြားမှာထံမှ [`None`], [`next`] ပြန်လည်ရောက်ရှိဖြစ်စေလိုလျှင် [`None`] ပြန်လာပါလိမ့်မယ်။
    /// ပထမဦးဆုံးကြားမှာ [`None`] ပြန်လည်ရောက်ရှိပါက, `zip` Short-တိုက်နယ်နဲ့ `next` ဒုတိယကြားမှာအပေါ်ဟုခေါ်ဝေါ်ခြင်းကိုခံရလိမ့်မည်မဟုတ်ပေပါလိမ့်မယ်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` ဖို့အငြင်းအခုံ [`IntoIterator`] ကိုအသုံးပြုချိန် မှစ. ငါတို့သည်မယ့်တစ်ဦး [`Iterator`] သူ့ဟာသူတစ်ခု [`Iterator`] သို့ကူးပြောင်းနိုင်ဘာမှလွန်သွားနိုင်ပါတယ်။
    /// ဥပမာအားဖြင့် (`&[T]`) အချပ်များသည် [`IntoIterator`] ကိုအကောင်အထည်ဖော်ပြီး `zip()` သို့တိုက်ရိုက်လွှဲပြောင်းနိုင်သည်
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` မကြာခဏကနျ့တစျခုမှတစ်ဦးအဆုံးမဲ့ကြားမှာ Zip ကိုအသုံးပြုသည်။
    /// အဆိုပါကနျ့ကြားမှာနောက်ဆုံးမှာဇစ်အဆုံးသတ်ရေး, [`None`] ပြန်လာပါလိမ့်မယ်ဘာဖြစ်လို့လဲဆိုတော့ဒါကအလုပ်လုပ်ပါတယ်။`(0..)` နှင့်အတူဇီပ်လုပ်မျု [`enumerate`] တူသောတွေအများကြီးကိုကြည့်နိုင်သည်
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// မူရင်းကြားမှာ၏ကပ်လျက်ပစ္စည်းများအကြား `separator` တစ်ဦးမိတ္တူနေရာဖြစ်သောသစ်တစ်ခုကြားမှာဖန်တီးပေးပါတယ်။
    ///
    /// ကိစ္စတွင် `separator` [`intersperse_with`] အသုံးပြုအခါတိုင်းတွက်ချက်ခံရဖို့ [`Clone`] သို့မဟုတ်လိုအပ်ချက်များကိုအကောင်အထည်မဖော်ပါဘူး။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // `a` ကနေပထမဦးဆုံးဒြပ်စင်။
    /// assert_eq!(a.next(), Some(&100)); // လွတ်လပ်သော။
    /// assert_eq!(a.next(), Some(&1));   // `a` ကနေလာမယ့် element က။
    /// assert_eq!(a.next(), Some(&100)); // လွတ်လပ်သော။
    /// assert_eq!(a.next(), Some(&2));   // `a` ကနေနောက်ဆုံးဒြပ်စင်။
    /// assert_eq!(a.next(), None);       // ကြားဖြတ်ပြီးဆုံးသည်။
    /// ```
    ///
    /// `intersperse` ဘုံဒြပ်စင်ကိုအသုံးပြုပြီးတစ်ဦးကြားမှာရဲ့ပစ္စည်းများကို join ဖို့အလွန်အသုံးဝင်သောဖြစ်နိုင်သည်
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// မူရင်းကြားမှာ၏ကပ်လျက်ပစ္စည်းများအကြား `separator` အားဖြင့်ထုတ်ပေးထားတဲ့ပစ္စည်းကိုနေရာအရာသစ်တစ်ခုကြားမှာဖန်တီးပေးပါတယ်။
    ///
    /// တစ်ခုချင်းစီကိုအချိန်တစ်ရပ်ကို item နောက်ခံကြားမှာထံမှနှစ်ခုကပ်လျက်ပစ္စည်းများအကြားထားရှိခြင်းဖြစ်သည်တစ်ချိန်ကပိတ်သိမ်းအတိအကျဟုခေါ်ဝေါ်ခြင်းကိုခံရကြလိမ့်မည်
    /// ဒီထက်နှစ်ခုပစ္စည်းများထက်သူ, နောက်ဆုံးသောပစ္စည်းကိုလြှော့ပြီးနောက်နောက်ခံကြားမှာအထွက်နှုန်းလျှင်အထူးသ, ပိတ်ပစ်ဟုခေါ်တွင်သည်မဟုတ်။
    ///
    ///
    /// အဆိုပါကြားမှာရဲ့ပစ္စည်းကို [`Clone`] အကောင်အထည်ဖော်ဆောင်ရွက်နေသောဆိုပါက [`intersperse`] သုံးစွဲဖို့ပိုမိုလွယ်ကူပါလိမ့်မယ်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // `v` မှပထမဆုံးဒြပ်စင်။
    /// assert_eq!(it.next(), Some(NotClone(99))); // လွတ်လပ်သော။
    /// assert_eq!(it.next(), Some(NotClone(1)));  // `v` မှလာမည့်ဒြပ်စင်။
    /// assert_eq!(it.next(), Some(NotClone(99))); // လွတ်လပ်သော။
    /// assert_eq!(it.next(), Some(NotClone(2)));  // `v` ကနေကနေနောက်ဆုံးဒြပ်စင်။
    /// assert_eq!(it.next(), None);               // ကြားဖြတ်ပြီးဆုံးသည်။
    /// ```
    ///
    /// `intersperse_with` separator အားတွက်ချက်ရန်လိုအပ်သည့်အခြေအနေများတွင်အသုံးပြုနိုင်သည်။
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // အဆိုပါပိတ်သိမ်း mutably တစ်ဦးကို item generate ရန်၎င်း၏အခြေအနေတွင်ငှါး။
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// တစ်ဦးပိတ်သိမ်းကြာနှင့်တစ်ဦးချင်းစီဒြပ်စင်ပေါ်တွင်ကြောင့်ပိတ်သိမ်းခေါ်ဆိုသည့်ကြားမှာဖန်တီးပေးပါတယ်။
    ///
    /// `map()` ကြားဖြတ်တစ်ခုအနေဖြင့်ကြားဖြတ်တစ်ခုအားအခြားတစ်ခုကိုပြောင်းလဲစေသည်။
    /// [`FnMut`] အကောင်အထည်ဖော်ဆောင်ရွက်နေသောကြောင်းအရာတစ်ခုခု။ဒါဟာမူရင်းကြားမှာအသီးအသီးဒြပ်စင်ပေါ်မှာဤပိတ်သိမ်းခေါ်ဆိုရာသစ်တစ်ခုကြားမှာထုတ်လုပ်သည်။
    ///
    /// သငျသညျအမျိုးအစားများအတွက်စဉ်းစားတွေးခေါ်မှာကောင်းသောမှန်လျှင်, သင်သည်ဤတူသော `map()` စဉ်းစားနိုင်သည်
    /// သင့်တွင် `A` အမျိုးအစားအချို့ကိုပေးသောကြားမှာရှိလျှင်သင်အခြား `B` အချို့ကြားမှာရှိလိုလျှင်သင်သည် `map()` ကိုသုံးနိုင်သည်။ ၎င်းသည် `A` ကိုယူပြီး `B` ကိုပြန်ပေးသည့်ပိတ်မှုတစ်ခုကိုဖြတ်သန်းနိုင်သည်။
    ///
    ///
    /// `map()` အယူအဆတစ်ခု [`for`] ကွင်းဆက်ဆင်တူသည်။`map()` ပျင်းရိဖြစ်သကဲ့သို့သငျသညျပြီးသားကိုအခြားကြားမှာအတူလုပ်ကိုင်နေသည့်အခါသို့သော်တစ်ခုကိုအကောင်းဆုံးအသုံးပြုသည်။
    /// သင်တစ်ဦးဘေးထွက်ဆိုးကျိုးအဘို့အထပ်ခါတလဲလဲအချို့ကိုမျိုးလုပ်နေလုပ်နေပါက `map()` ထက် [`for`] သုံးစွဲဖို့ပိုပြီး idiomatic ထည့်သွင်းစဉ်းစားပါတယ်။
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// သငျသညျဘေးထွက်ဆိုးကျိုးအချို့ကိုမျိုးလုပ်နေတာဆိုရင်တော့ `map()` မှ [`for`] ကြိုက်တတ်တဲ့:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // ဒါကိုမလုပ်ပါနဲ့:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // ဒါကြောင့်ပင်ပျင်းရိသည်အတိုင်း, ပင် execute လိမ့်မည်မဟုတ်ပါ။Rust ဤအကြောင်းကိုသငျသညျသတိပေးပါလိမ့်မယ်။
    ///
    /// // အဲဒီအစားအသုံးပြု:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// တစ်ခုကြားမှာအသီးအသီးဒြပ်စင်အပေါ်တစ်ဦးပိတ်သိမ်းရန်တောင်းဆိုလိုက်သည်။
    ///
    /// `break` နှင့် `continue` တစ်ပိတ်သိမ်းကနေဖြစ်နိုင်သမျှမဟုတ်ပေမယ့်ဤသည်, ထိုကြားမှာအပေါ်တစ်ဦး [`for`] ကွင်းဆက်ကို အသုံးပြု. ရန်ညီမျှသည်။
    /// ဒါဟာ `for` ကွင်းဆက်သုံးစွဲဖို့ယေဘုယျအားဖြင့်ပိုပြီး idiomatic ရဲ့, ဒါပေမယ့်ကြာကြာကြားမှာချည်နှောင်ရဲ့အဆုံးမှာပစ္စည်းများ processing သည့်အခါ `for_each` ပိုပြီးရှင်းလင်းပြသားသောဖြစ်နိုင်ပါသည်။
    ///
    /// အချို့ကိစ္စများတွင် `for_each` သည် loop ထက်ပိုမိုမြန်ဆန်နိုင်သည်။ အဘယ်ကြောင့်ဆိုသော်၎င်းသည် `Chain` ကဲ့သို့ adapters များတွင် internal iteration ဖြစ်သည်။
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// ထိုကဲ့သို့သောသေးငယ်တဲ့ဥပမာ, `for` ကွင်းဆက်သန့်စင်စေခြင်းငှါ, ဒါပေမယ့် `for_each` ရှည်ကြားမှာအတူအလုပ်လုပ်တဲ့စတိုင်ကိုစောင့်ရှောက်ရန်ဦးစားပေးမည်ဖြစ်လိမ့်မယ်:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Element တစ်ခုရဲ့လြှော့ထားရမည်ဆိုပါကဆုံးဖြတ်ရန်တစ်ပိတ်သိမ်းကိုအသုံးပြုသည့်ကြားမှာဖန်တီးပေးပါတယ်။
    ///
    /// Element တစ်ခုရဲ့ပေးသောပိတ်သိမ်း `true` သို့မဟုတ် `false` ပြန်လာရမည်ဖြစ်သည်။အဆိုပါကြားမှာပိတ်ပစ်စစ်မှန်တဲ့ပြန်လည်ရောက်ရှိရာအဘို့ကိုသာ element တွေကိုလိုက်လျောပါလိမ့်မယ်ပြန်လေ၏။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// အဘယ်ကြောင့်ဆိုသော် `filter()` သို့ကူးပြောင်းလိုက်သောအရာသည်ရည်ညွှန်းချက်ယူပြီး၊ များစွာသောကြားဖြတ်များကကိုးကားချက်များအကြားထပ်တလဲလဲပြုလုပ်သောကြောင့်၎င်းသည်ရှုပ်ထွေးဖွယ်အခြေအနေကိုဖြစ်ပေါ်စေသည်။
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // လိုအပ်ချက်နှစ်ခု * s ကို!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// တ ဦး တည်းဖယ်ရှားပစ်ရန်အငြင်းအခုံအပေါ်ဖျက်ဆီးခြင်းကိုအသုံးပြုခြင်းသည်ထုံးစံဖြစ်သည်။
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // နှစ် ဦး စလုံးနှင့် *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// သို့မဟုတ်နှစ်ဦးစလုံး:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // နှစ်ခု &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ထိုအလွှာ၏။
    ///
    /// `iter.filter(f).next()` `iter.find(f)` ညီမျှကြောင်းသတိပြုပါ။
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// တစ်ဦးကြားမှာ filter များနှင့်မြေပုံနှစ်ဦးစလုံးကြောင့်ဖန်တီးပေးပါတယ်။
    ///
    /// အဆိုပါကြားမှာပု supply ပိတ်သိမ်း `Some(value)` ပြန်လည်ရောက်ရှိရာအဘို့ကိုသာ `value`s ဖြစ်ထွန်းပြန်လာ၏။
    ///
    /// `filter_map` [`filter`] နှင့် [`map`] ပိုပြီးစုံစုံ၏ချည်နှောင်ခြင်းကိုအောင်ဖို့အသုံးပြုနိုင်ပါသည်။
    /// အောက်ပါဥပမာသည် `map().filter().map()` ကို `filter_map` သို့ခေါ်ဆိုမှုတစ်ခုသို့အတိုချုပ်နိုင်ပုံကိုပြသည်။
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ဤတွင်တူဥပမာပေမယ် [`filter`] နှင့် [`map`] အတူင်:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// လက်ရှိကြားမှာရေတွက်အဖြစ်လာမယ့်တန်ဖိုးကပေးသောတစ်ခုကြားမှာဖန်တီးပေးပါတယ်။
    ///
    /// အဆိုပါကြားမှာ `i` ကြားမှာ၏လက်ရှိအညွှန်းကိန်းသည်နှင့် `val` အဆိုပါကြားမှာအားဖြင့်ပြန်လာသောတန်ဖိုးသည်အဘယ်မှာရှိအထွက်နှုန်းအားလုံးအတွက် `(i, val)`, ပြန်လာ၏။
    ///
    ///
    /// `enumerate()` တစ် ဦး [`usize`] အဖြစ်က၎င်း၏ရေတွက်စောင့်ရှောက်။
    /// သင်တစ်ဦးကွဲပြားခြားနားသောအရွယ်ကိန်းအားဖြင့်ရေတွက်ချင်လျှင်, [`zip`] function ကိုအလားတူလုပ်ဆောင်နိုင်စွမ်းကိုပေးစွမ်းသည်။
    ///
    /// # လျတ်အပြုအမူ
    ///
    /// အဆိုပါနည်းလမ်းကိုဖြစ်စေဒါ enumerating ပိုပြီး [`usize::MAX`] ဒြပ်စင်ထက်, လွှမ်းမိုးသောဆန့်ကျင်ခြင်းမရှိ Guard မမှားရလဒ်သို့မဟုတ် panics ထုတ်လုပ်သည်။
    /// ဒီဘာဂ်အခိုင်အမာ enabled နေတယ်ဆိုရင်တစ် panic အာမခံချက်ဖြစ်ပါတယ်။
    ///
    /// # Panics
    ///
    /// The-ဖြစ်-ပြန်လာသောညွှန်းကိန်းတစ်ခု [`usize`] လျှံမယ်လို့လျှင်ကြားမှာငှါ panic ပြန်လာ၏။
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// [`peek`] ကို သုံး၍ ၎င်းကိုနောက်တစ်ကြိမ်ထပ်မံမသုံးဘဲကြည့်မည်ဆိုပါကကြားဖြတ်ကိုဖန်တီးသည်။
    ///
    /// တစ်ခုကြားမှာတစ် [`peek`] နည်းလမ်းကထပ်ပြောသည်။ပိုမိုသိရှိလိုပါက၎င်း၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
    ///
    /// [`peek`] ပထမဦးဆုံးအကြိမ်အဘို့ဟုခေါ်သည့်အခါကြားမှာအခြေခံနေဆဲချီတက်ကြောင်းမှတ်ချက်: လာမယ့် element ကို retrieve ရန်အလို့ငှာ, [`next`] နောက်ခံကြားမှာအပေါ်ဟုခေါ်သည်, ဤအရပ်မှမဆိုဘေးထွက်ဆိုးကျိုး (ဆိုလိုသည်မှာ
    ///
    /// [`next`] နည်းလမ်း၏နောက်တန်ဖိုးကိုထပ်မံထုတ်ယူခြင်းထက်အခြားအရာတစ်ခုပေါ်ပေါက်လာလိမ့်မည်။
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() ကျွန်တော်တို့ကို future ကိုကြည့်ခွင့်ပေးတယ်
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // ကျနော်တို့ peek() အကြိမ်ပေါင်းများစွာနိုင်, ထိုကြားမှာကြိုတင်မ
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // အဆိုပါကြားမှာပြီးဆုံးပြီးနောက်, ဒါ peek() ဖြစ်ပါသည်
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// တစ်ခုကြားမှာတစ်ဦး predicate အပေါ်အခြေခံပြီး [`skip`] s ကိုဒြပ်စင်တစ်ခုကိုဖန်တီးပေးပါတယ်။
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` အငြင်းအခုံအဖြစ်ပိတ်သိမ်းကြာပါသည်။ဒါဟာကြားမှာအသီးအသီးဒြပ်စင်ပေါ်မှာဤပိတ်သိမ်းမခေါ်, ထိုသို့ `false` ပြန်လည်ရောက်ရှိသည်အထိ element တွေကိုလျစ်လျူရှုပါလိမ့်မယ်။
    ///
    /// `false` ကိုပြန်ပို့ပြီးနောက် `skip_while()`'s အလုပ်ပြီးဆုံးသွားပြီးကျန်အပိုင်းများကိုလိုက်လျောပေးသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `skip_while()` မှလွန်ပိတ်ပစ်တစ်ဦးကိုကိုးကားကြာနှင့်များစွာသောကြားမှာကိုးကားကျော် iterate, ပိတ်ပစ်အငြင်းအခုံအမျိုးအစားကိုနှစ်ဆရည်ညွှန်းသည်အဘယ်မှာရှိတစ်ဦးဖြစ်နိုင်သည်ရှုတ်ထွေးအခြေအနေဤဆောင်သောကြောင့်:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // လိုအပ်ချက်နှစ်ခု * s ကို!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ကန ဦး `false` ပြီးနောက်ရပ်တန့်ခြင်း:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // ဒီအယူမှားဖြစ်ရပြီလိုနေချိန်မှာကျနော်တို့ပြီးသားမိစ္ဆာတယ်ကတည်းက, skip_while() ဆိုပိုပြီးအသုံးမနေသည်
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// ကြိုတင်ဟောကိန်းကိုအခြေခံပြီး element တွေကိုထုတ်ပေးတဲ့ကြားမှာဖန်တီးသည်။
    ///
    /// `take_while()` အငြင်းအခုံအဖြစ်ပိတ်သိမ်းကြာပါသည်။ဒါဟာကြားမှာအသီးအသီးဒြပ်စင်ပေါ်မှာဤပိတ်သိမ်းမခေါ်, ထိုသို့ `true` ပြန်လာစဉ် element တွေကိုလိုက်လျောပါလိမ့်မယ်။
    ///
    /// `false` ကိုပြန်ပို့ပြီးနောက် `take_while()`'s အလုပ်ပြီးဆုံးပြီးကျန်အပိုင်းများကိုလျစ်လျူရှုထားသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// အဘယ်ကြောင့်ဆိုသော် `take_while()` သို့ကူးပြောင်းလိုက်သောအရာသည်ရည်ညွှန်းချက်ယူပြီး၊ များစွာသောကြားဖြတ်များကကိုးကားချက်များအကြားထပ်တလဲလဲပြုလုပ်သောကြောင့်၎င်းသည်ရှုပ်ထွေးဖွယ်အခြေအနေကိုဖြစ်ပေါ်စေသည်။
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // လိုအပ်ချက်နှစ်ခု * s ကို!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ကန ဦး `false` ပြီးနောက်ရပ်တန့်ခြင်း:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // ကျနော်တို့လျော့နည်းသုညထက်ပိုဒြပ်စင်ရှိသည်, ဒါပေမယ့်ကျနော်တို့ပြီးသားမိစ္ဆာတယ်ကတည်းက take_while() ဆိုပိုပြီးအသုံးမနေသည်
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take_while()` ကြားမှာကဖယ်ရှားခံရကြောင်းမြင်ရပါလိမ့်မည်စားသုံးပါကထည့်သွင်းသို့မဟုတ်မထားရမည်ဆိုပါကကြည့်ရှုနိုင်ရန်အတွက်တန်ဖိုးကိုကြည့်ဖို့လိုအပ်ပါတယ်သောကြောင့်:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` ဟာအဲဒီမှာမရှိတော့ပါဘူး၊ ဘာလို့လဲဆိုတော့ကြားမှာရပ်တန့်သင့်မသင့်ဆိုတာကိုကြည့်ရှုဖို့အတွက်လောင်ကျွမ်းခဲ့တာပါ၊
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// element တစ်ခုချင်းစီကို predicate နဲ့ map တွေအပေါ်အခြေခံပြီးထွက်လာတဲ့ကြားမှာဖန်တီးသည်။
    ///
    /// `map_while()` အငြင်းအခုံအဖြစ်ပိတ်သိမ်းကြာပါသည်။
    /// ဒါဟာကြားမှာအသီးအသီးဒြပ်စင်ပေါ်မှာဤပိတ်သိမ်းမခေါ်, ထိုသို့ [`Some(_)`][`Some`] ပြန်လာစဉ် element တွေကိုလိုက်လျောပါလိမ့်မယ်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ဤတွင်တူဥပမာပေမယ် [`take_while`] နှင့် [`map`] အတူင်:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ကနဦး [`None`] ပြီးနောက်ရပ်တန့်:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // ကျနော်တို့ u32 (4, 5) တွင် fit နိုင်သည့်ထက်ပိုသောဒြပ်စင်များရှိသော်လည်း, (ထို `predicate` `None` ပြန်လာသောကဲ့သို့) `map_while` `-3` များအတွက် `None` ပြန်လာသောနှင့် `collect` ကြုံတွေ့ပထမဦးဆုံး `None` မှာရပ်လိုက်နိုင်သည်။
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// အဘယ်ကြောင့်ဆိုသော် `map_while()` တွင်ထည့်သွင်းသင့်၊ မသင့်ကိုသိနိုင်ရန်အတွက်တန်ဖိုးကိုကြည့်ရန်လိုအပ်သောကြောင့်စားသုံးသူအကြိမ်ကြိမ်စားသုံးသူသည်၎င်းကိုဖယ်ရှားကြောင်းတွေ့ရလိမ့်မည်။
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// အဆိုပါ `-3` ကကြားမှာရပ်တန့်သင့်လျှင်ကြည့်ရှုနိုင်ရန်အတွက်စားသုံးခဲ့လို့ရှိမရှိတော့ဖြစ်ပါတယ်, ဒါပေမယ့်ပြန်ကြားမှာသို့ထားရှိမခံခဲ့ရပါဘူး။
    ///
    /// [`take_while`] နှင့်မတူဘဲဤကြားမှာ ** ** fuse မထားကြောင်းသတိပြုပါ။
    /// [`None`] ပထမအကြိမ်ပြန်ရောက်ပြီးနောက်ဤကြားမှာအဘယ်အရာပြန်လာသည်ကိုလည်းမသတ်မှတ်ပါ။
    /// သငျသညျ fused ကြားမှာလိုအပ်ခဲ့လျှင်, [`fuse`] ကိုအသုံးပြုပါ။
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// ပထမဦးဆုံး `n` ဒြပ်စင် skips တစ်ခုကြားမှာဖန်တီးပေးပါတယ်။
    ///
    /// သူတို့စားသုံးခဲ့ကြပြီးနောက်, ဒြပ်စင်၏ကျန်လြှော့နေကြသည်။
    /// အဲဒီအစားတိုက်ရိုက်ဒီနည်းလမ်းကို၎င်းအားထက်အစား `nth` နည်းလမ်း override ။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// သူ့ရဲ့ပထမဦးဆုံး `n` ဒြပ်စင်ဖြစ်ထွန်းတစ်ခုကြားမှာဖန်တီးပေးပါတယ်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` မကြာခဏကကနျ့စေရန်တစ်ဦးအဆုံးမဲ့ကြားမှာနှင့်အတူအသုံးပြုသည်:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ဒီထက် `n` element တွေကိုရရှိနိုင်ပါထက်လြှငျ, `take` နောက်ခံကြားမှာ၏အရွယ်အစားဖို့သူ့ဟာသူကန့်သတ်ပါလိမ့်မယ်:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// ပြည်တွင်းရေးပြည်နယ်ရရှိထားသူအသစ်တစ်ခုကြားမှာထုတ်လုပ် [`fold`] ဆင်တူတစ်ခုကြားမှာ adapter ။
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` အငြင်းပွားမှုနှစ်ခုကိုယူသည်။ ကန ဦး တန်ဖိုးသည်အတွင်းပိုင်းအခြေအနေကိုအစပျိုးပေးသည်။ အငြင်းပွားမှုနှစ်ခုဖြင့်ပိတ်လိုက်ခြင်းဖြစ်သည်။ ပထမတစ်ခုမှာအပြောင်းအလဲဖြစ်သည်အတွင်းပိုင်းပြည်နယ်နှင့်ဒုတိယသည်ကြားဖြတ်ဒြပ်စင်ဖြစ်သည်။
    ///
    /// အဆိုပါပိတ်သိမ်းကြားမှာအကြားဝေစုပြည်နယ်မှအတွင်းပိုင်းပြည်နယ်မှသတ်မှတ်နိုင်သည်။
    ///
    /// ကြားမှာတွင်ပိတ်သိမ်းပိတ်ပစ်ထံမှကြားမှာအသီးအသီးဒြပ်စင်များနှင့်ပြန်လာတန်ဖိုးလျှောက်ထားပါလိမ့်မည်, တစ်ဦး [`Option`], ထိုကြားမှာအားဖြင့်လြှော့ဖြစ်ပါတယ်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // တစ်ဦးချင်းစီကြားမှာကျနော်တို့ဒြပ်စင်အားဖြင့်ပြည်နယ်များပြားလိမ့်မယ်
    ///     *state = *state * x;
    ///
    ///     // ထို့နောက်ကျနော်တို့ပြည်နယ်၏ negation လိုက်လျောပါလိမ့်မယ်
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// မြေပုံနဲ့တူအလုပ်လုပ်တယ်တစ်ခုကြားမှာဖန်တီးပေမယ့်အသိုက်ဖွဲ့စည်းပုံမှာ flattens ။
    ///
    /// [`map`] adapter ကအရမ်းအသုံးဝင်ပါတယ်၊ ဒါပေမယ့် closure argument ကတန်ဖိုးတွေထုတ်ပေးမှသာ။
    /// ဒါကြောင့်အစားတစ်ခုကြားမှာထုတ်လုပ်ပါက, သွယ်ဝိုက်တစ်ဦးအပိုဆောင်းအလွှာရှိပါတယ်။
    /// `flat_map()` ၎င်း၏ကိုယ်ပိုင်ပေါ်မှာဤအပိုအလွှာကိုဖယ်ရှားပါလိမ့်မယ်။
    ///
    /// သငျသညျ [`map`] ping ရဲ့များ၏ semantic ညီမျှအဖြစ် `flat_map(f)` စဉ်းစား, ပြီးတော့ [`flatten`] `map(f).flatten()` ၌ရှိသကဲ့သို့ ing နိုင်ပါတယ်။
    ///
    /// `flat_map()` စဉ်းစား၏နောက်ထပ်လမ်း: [`map`] 's တစ်ခုချင်းစီကိုဒြပ်စင်အဘို့ပိတ်သိမ်းပြန်တဦးတည်းကို item နှင့် `flat_map()`'s ပိတ်သိမ်းတစ်ဦးချင်းစီဒြပ်စင်တစ်ခုကြားမှာပြန်လည်ရောက်ရှိ။
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() တစ်ခုကြားမှာပြန်လာသည်
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// အသိုက်ဖွဲ့စည်းပုံကို flattens ထားတဲ့ကြားမှာဖန်တီးပေးပါတယ်။
    ///
    /// သင်ကြားမှာတစ်ခုကြားမှာသို့မဟုတ်ကြားမှာသို့လှည့်နိုင်သည့်အရာများ၏ကြားမှာရှိတဲ့အခါသင် indirection တ ဦး တည်းအဆင့်ကိုဖယ်ရှားပစ်သည့်အခါဤသည်အသုံးဝင်သည်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// ပုံဖော်ပြီးတော့ flattening:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() တစ်ခုကြားမှာပြန်လာသည်
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// သင်တို့သည်လည်းပိုမိုရှင်းလင်းစွာရည်ရွယ်ချက်သဘောဆောငျကတည်းကဤကိစ္စတွင်အတွက်ဦးစားပေးမည်ဖြစ်သော [`flat_map()`] ၏အသုံးအနှုန်းများ၌ဤပြန်ရေးနိုင်သည်
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() တစ်ခုကြားမှာပြန်လာသည်
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// သာ Flattening တစ်ကြိမ်အသိုက်ထဲကတစ်ခုအဆင့်ကိုဖယ်ရှားပေး:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// ဤတွင် `flatten()` သည် "deep" ပြားကိုမလုပ်ဆောင်ကြောင်းကျွန်ုပ်တို့တွေ့ရသည်။
    /// အဲဒီအစား, တစ်ခုသာအဆင့်ကိုအသိုက်ဖယ်ရှားပစ်သည်။သငျသညျ `flatten()` သုံးရှုထောင်ခင်းကျင်းလျှင်ကြောင်း, ရလဒ်တဦးတည်းရှုထောင် Two-ရှုထောင်နှင့်မဖြစ်လိမ့်မည်။
    /// တစ်ဦးတည်းရှုထောင်ဖွဲ့စည်းပုံအရ, သင်သည်နောက်တဖန် `flatten()` ရန်ရှိသည်။
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// ပထမဦးဆုံး [`None`] ပြီးနောက်အဆုံးသတ်တစ်ခုကြားမှာဖန်တီးပေးပါတယ်။
    ///
    /// ကြားခံတစ်ခုသည် [`None`] သို့ပြန်သွားပြီးနောက် future ခေါ်ဆိုမှုများသည် [`Some(T)`] ကိုထပ်မံလိုက်လျောမည်မဟုတ်ပါ။
    /// `fuse()` တစ်ဦး [`None`] ပေးထားပြီးနောက်, ကအမြဲအစဉ်အမြဲ [`None`] ပြန်လာလိမ့်မည်ဟုသေချာတစ်ခုကြားမှာ adapts ။
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// // အချို့နှင့်အဘယ်သူမျှမအကြား alternates ထားတဲ့ကြားမှာ
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // ဒါကြောင့်ပင်, Some(i32), အခြားအဘယ်သူမျှမဖွင့်လျှင်
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // ငါတို့သည်ငါတို့၏ကြားမှာနောက်ကျောနှင့်ထွက်တွေ့နိုင်ပါသည်
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // သို့သော်ကျနော်တို့ကဖျူးတစ်ချိန်က ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // ပထမ ဦး ဆုံးအကြိမ်အနေဖြင့် `None` ကိုအမြဲတမ်းပြန်ပို့ပေးမည်။
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// အပေါ်တန်ဖိုးဖြတ်သန်းတစ်ခုကြားမှာအသီးအသီးဒြပ်စင်နှင့်အတူတစ်စုံတစ်ခုပါဘူး။
    ///
    /// ကြားမှာသုံးပြီးတဲ့အခါ, သင်မကြာခဏအတူတူသူတို့ထဲကအတော်များများချုပ်ထားလိမ့်မယ်။
    /// ထိုကဲ့သို့သောကုဒ်ကိုလုပ်ဆောင်နေစဉ်သင်ပိုက်လိုင်း၏အစိတ်အပိုင်းများစွာတွင်ဖြစ်ပျက်နေသောအရာများကိုစစ်ဆေးရန်လိုပေမည်။ထိုသို့ပြုလုပ်ရန် `inspect()` သို့ဖုန်းခေါ်ပါ။
    ///
    /// `inspect()` တစ် debugging tool ကိုအဖြစ်အသုံးပြုခံရဖို့အဘို့သင့်နောက်ဆုံးကုဒ်ထဲမှာတည်ရှိဖို့ထက်ပိုပြီးအဖြစ်များပေမယ်အမှားများကိုစွန့်ပစ်မခံရမီ logged ခံရဖို့မလိုအပ်သည့်အခါ applications များအချို့သောအခြေအနေများတွင်ကအသုံးဝင်ရှာတွေ့လိမ့်မည်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // ဒီကြားမှာ sequence ကိုရှုပ်ထွေးသည်။
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // ရဲ့ဖြစ်ပျက်နေတာတွေစုံစမ်းစစ်ဆေးရန်အချို့ inspect() ဖုန်းခေါ်ဆိုမှု add ပါစေ
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// ဤသည် print ထုတ်ပါလိမ့်မယ်:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// သူတို့ကိုပယ်မတိုင်မီအမှားအယွင်းများ logging:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// ဤသည် print ထုတ်ပါလိမ့်မယ်:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// ၎င်းကိုစားသုံးခြင်းထက်ကြားဖြတ်ငှားရမ်းခြင်းဖြစ်သည်။
    ///
    /// ၎င်းသည်မူလကြားမှာ၏ပိုင်ဆိုင်မှုကိုဆက်လက်ထိန်းသိမ်းထားစဉ် iterator adapters များကိုအသုံးပြုရန်ခွင့်ပြုသည်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // နောက်တဖန် iter ကိုသုံးရန်ကြိုးစားပါကအလုပ်မလုပ်ပါ။
    /// // အောက်ပါလိုင်း "အမှားပေးသည်: ပြောင်းရွှေ့တန်ဖိုးကိုအသုံးပြုမှု: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // စေမယ့်ပါနောက်တဖန်ကြောင်း
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // အစား, ကျွန်တော်တစ်ဦး .by_ref() အတွက် add
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // ယခုဖွင့်ဒဏ်ငွေဖြစ်ပါသည်:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// တစ်ဦးစုဆောင်းမှုသို့တစ်ဦးကြားမှာပြောင်းလဲ။
    ///
    /// `collect()` ကြားမှာဘာမှကို ယူ. , တစ်ဦးကိုသက်ဆိုင်ရာစုဆောင်းမှုသို့လှည့်နိုင်ပါတယ်။
    /// ၎င်းသည်စံပြစာကြည့်တိုက်တွင်ပိုမိုအားကောင်းသည့်နည်းလမ်းများအနက်မှတစ်ခုဖြစ်သည်။
    ///
    /// `collect()` ကိုအသုံးပြုထားတဲ့အတွက်အခြေခံအကျဆုံးပုံစံသည်အခြားသို့တဦးတည်းစုဆောင်းခြင်းကိုဖွင့်ဖို့ဖြစ်ပါတယ်။
    /// သငျသညျအဆုံးမှာတစ်ဦးစုဆောင်းမှုကို ယူ. , ပေါ်မှာ [`iter`] ခေါ်အသွင်ပြောင်းတစည်းလုပ်ပေး, ပြီးတော့ `collect()` ။
    ///
    /// `collect()` ဒါ့အပြင်ပုံမှန် collection များကိုမစပ်ဆိုင်ကြောင်းကိုအမျိုးအစားများသာဓကဖန်တီးနိုင်ပါတယ်။
    /// ဥပမာအားဖြင့်၊ [`String`] ကို [`char`] မှတည်ဆောက်ပြီး၊ [`Result<T, E>`][`Result`] ပစ္စည်းများ၏ကြားမှာ `Result<Collection<T>, E>` သို့စုဆောင်းနိုင်သည်။
    ///
    /// ပိုပြီးအဘို့အောက်ကဥပမာကိုကြည့်ပါ။
    ///
    /// အဘယ်ကြောင့်ဆိုသော် `collect()` သည်အလွန်ယေဘူယျဖြစ်သောကြောင့်၎င်းသည် type inference နှင့်ပြproblemsနာဖြစ်စေနိုင်သည်။
    /// ထိုကဲ့သို့သောအဖြစ်, `collect()` သငျသညျခစျြစနိုးဟာ 'turbofish' အဖြစ်လူသိများသည့် syntax ကိုမြင်ရပါလိမ့်မယ်ယင်းအကြိမ်အနည်းငယ်ထဲကတစ်ခုဖြစ်ပါသည်: `::<>`.
    /// ဒါကအခြ algorithm ကိုသငျသညျသို့စုဆောင်းရန်ကြိုးစားနေသည့်စုဆောင်းခြင်းအထူးနားလည်ကူညီပေးသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// ကျွန်တော်တို့ဘယ်ဘက်မှာ `: Vec<i32>` လိုတယ်ဆိုတာသတိပြုပါ။ကျနော်တို့အစားဥပမာ, သို့ [`VecDeque<T>`] စုဆောင်းနိုင်ခဲ့လို့ဖြစ်ပါတယ်:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// အဆိုပါ 'turbofish' အသုံးပြုခြင်းအစား `doubled` annotating:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// `collect()` ကသင်စုဆောင်းနေသောအရာများကိုသာဂရုစိုက်သောကြောင့်သင်သည် turbofish ဖြင့်တစ်စိတ်တစ်ပိုင်း type hint `_` ကိုသုံးနိုင်သည်။
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// တစ်ဦး [`String`] စေရန် `collect()` အသုံးပြုခြင်း:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// သငျသညျ [`ရလဒ်များ၏စာရင်းကိုရှိပါက<T, E>`][`Result`] s ကို, သင်ကသူတို့ကိုမဆိုပျက်ကွက်လျှင်ကြည့်ဖို့ `collect()` အသုံးပွုနိုငျ:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // ကျွန်တော်တို့ကိုပထမဦးဆုံးအမှားပေးသည်
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // ကျွန်တော်တို့ကိုအဖြေများစာရင်းပေးသည်
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// ကနေနှစ်ခု collection များကိုဖန်တီးကာကြားမှာစားသုံး။
    ///
    /// `partition()` မှလွန်အဆိုပါ predicate `true`, ဒါမှမဟုတ် `false` ပြန်လာနိုင်ပါတယ်။
    /// `partition()` pair တစုံ, သူက `true` ပြန်လာသောအဘို့အ element တွေကိုအားလုံးနှင့်သူက `false` ပြန်လာသောသောအရာအားလုံးသည်ပြန်လာသည်။
    ///
    ///
    /// [`is_partitioned()`] နှင့် [`partition_in_place()`] ကိုလည်းရှုပါ။
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// In-ရာအရပ်ကိုပြန်စီဒီကြားမှာ၏ဒြပ်စင် * * ပေးထားသော predicate သည်နှင့်အညီ, ထိုကဲ့သို့သောပြန်လာ `true` သူအပေါငျးတို့ပြန်လာ `false` ကြောင်းအရင်အဦးနေရာသမျှသောသူတို့အားသော။
    ///
    /// `true` ဒြပ်စင်၏နံပါတ်တွေ့ရှိခဲ့ Returns ။
    ///
    /// ခွဲထားသောပစ္စည်းများ၏ဆွေမျိုးအမိန့်ကိုထိန်းသိမ်းထားသည်မဟုတ်။
    ///
    /// [`is_partitioned()`] နှင့် [`partition()`] ကိုလည်းရှုပါ။
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Evens နှင့် odds အကြား In-place partition ကို
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: ငါတို့သည်အရေတွက်လွှမ်းမိုးသောစိုးရိမ်သင့်သလဲထက် ပို. ရှိသည်ဖို့တစ်ခုတည်းသောနည်းလမ်း
        // `usize::MAX` mutable ကိုးကား partition ကိုမှအသုံးမဝင်သည့် ZSTs နှင့်အတူဖြစ်ပါတယ် ...

        // ဤရွေ့ကားပိတ်သိမ်း "factory" လုပ်ဆောင်ချက်များကို `Self` အတွက်ယေဘုယျအားဖြင့်ရှောင်ကြဉ်ရန်မတည်ရှိ။

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // ထပ်တလဲလဲပထမဦးဆုံး `false` ရှာတွေ့သူ, နောက်ဆုံး `true` အတူကဖလှယ်။
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// ဒီကြားမှာ၏ဒြပ်စင်ပေးထားသောကြိုတင်အရသိရသည် partitioned လျှင်စစ်ဆေးသည်, `true` ပြန်သွားသောသူအပေါင်းတို့သည် `false` ပြန်လာသောသူအပေါငျးတို့ရှေ့မှာ, ထိုကဲ့သို့သော
    ///
    ///
    /// [`partition()`] နှင့် [`partition_in_place()`] ကိုလည်းရှုပါ။
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // ပစ္စည်းများအားလုံးစမ်းသပ် `true`, ဒါမှမဟုတ်ပထမဦးဆုံးအပိုဒ် `false` မှာရပ်များနှင့်ကျွန်တော်မပို `true` ပစ္စည်းများသောနောက်ရှိပါတယ်စစ်ဆေးပါ။ သော်လည်းကောင်း
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// ရှည်လျားသောကြောင့်တစ်ခုတည်း, နောက်ဆုံးတန်ဖိုးကိုထုတ်လုပ်အောင်မြင်စွာပြန်လည်ရောက်ရှိသကဲ့သို့တစ်ဦး function ကိုသက်ဆိုင်သည့်ကြားမှာနည်းလမ်း။
    ///
    /// `try_fold()` အငြင်းပွားမှုနှစ်ခုကိုပြုလုပ်သည်။ ကန ဦး တန်ဖိုးတစ်ခုနှင့်အငြင်းပွားမှုနှစ်ခုပါသောပိတ်သိမ်းမှုတစ်ခု-'accumulator' နှင့် element တစ်ခုဖြစ်သည်
    /// စုစည်းနေခြင်းကိုနောက်ကြားမှာအဘို့ရှိသင့်, ဒါမှမဟုတ်ကခေါ်ဆိုသူ၏ချက်ချင်း (short-circuiting) ပြန် propagate လုပ်ကြောင်းမှားယွင်းမှုတစ်ခုတန်ဖိုးကိုအတူကျရှုံးခြင်းကို ပြန်. တန်ဖိုးနှင့်အတူအောင်မြင်စွာပိတ်သိမ်းပြန်, ဖြစ်စေ။
    ///
    ///
    /// ကနဦးတန်ဖိုးစုဆောင်းခြင်းကိုပထမဦးဆုံးခေါ်ဆိုခအပေါ်ရပါလိမ့်မယ်တန်ဖိုးဖြစ်ပါတယ်။closure ကိုအသုံးပြုခြင်းသည်ကြားမှာရှိသည့်အရာတိုင်းကိုအောင်မြင်ခဲ့လျှင် `try_fold()` သည်နောက်ဆုံးစုဆောင်းသူကိုအောင်မြင်မှုအဖြစ်ပြန်လည်အပ်နှံသည်။
    ///
    /// သငျသညျအရာတစ်ခုခုတစ်ဦးစုဆောင်းမှုရှိသည်, ကနေတစ်ခုတည်းတန်ဖိုးကိုထုတ်လုပ်ရန်လိုသောအခါတိုင်းခေါက်အသုံးဝင်သည်။
    ///
    /// # မှတ်ချက် Implementors မှ
    ///
    /// အခြား (forward) နည်းလမ်းအများအပြားဒါကြောင့်ပိုကောင်းကို default `for` ကွင်းဆက်အကောင်အထည်ဖော်မှုထက်တစ်ခုခုလုပ်နိုင်မယ်ဆိုရင်အတိအလင်းဒီအကောင်အထည်ဖေါ်ဖို့ကြိုးစား, ဒီတစျဦး၏စည်းကမ်းချက်များ၌ default အနေနဲ့ကလပ်စရှိသည်။
    ///
    /// အထူးသဖြင့်, ဒီကြားမှာရေးစပ်သောအနေဖြင့်ပြည်တွင်းအစိတ်အပိုင်းများပေါ်မှာဤခေါ်ဆိုခ `try_fold()` ရှိသည်ဖို့ကြိုးစားကြည့်ပါ။
    /// မျိုးစုံဖုန်းခေါ်ဆိုမှုလိုအပ်နေပါသည်လျှင်, `?` အော်ပရေတာတစ်လျှောက်တွင်စုစည်းနေခြင်းတန်ဖိုးကို chaining များအတွက်အဆင်ပြေဖြစ်ပေမယ့်လိုအပ်အဲဒီအစောပိုင်းပြန်မရောက်မီထောကျခံခဲ့ခံရဖို့ဆိုလျော့ပါးသွားမည်ဖြစ်သလိုသတိနှင့်ကြဉ်ရှောင်စေနိုင်သည်။
    /// ဤသည်မှာ `&mut self` နည်းလမ်းဖြစ်သည်။ ထို့ကြောင့်ဤနေရာတွင်အမှားတစ်ခုကျူးလွန်ပြီးနောက်ကြားဖြတ်ပြန်လည်စတင်ရန်လိုအပ်သည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // အဆိုပါခင်းကျင်း၏ဒြပ်စင်အပေါငျးတို့သ၏ check လုပ်ထားပေါင်းလဒ်
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // ဒြပ်စင် ၁၀၀ ကိုပေါင်းထည့်သောအခါဤပေါင်းလဒ်သည်ပိုလျှံသည်
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // ၎င်းသည် short-circuute ဖြစ်သောကြောင့်ကျန်ရှိသော element များအား iterator မှတစ်ဆင့်ရရှိနိုင်သည်။
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// ကြားမှာရှိအရာတစ်ခုစီအတွက် fallible function တစ်ခုသက်ရောက်စေသော iterator method သည်ပထမအမှားကိုရပ်ပြီးထိုအမှားကိုပြန်ပို့သည်။
    ///
    ///
    /// ၎င်းကိုမှားယွင်းစွာလုပ်နိုင်သော [`for_each()`] ပုံစံသို့မဟုတ်နိုင်ငံမဲ့မဲ့ [`try_fold()`] ဗားရှင်းဟုယူဆနိုင်သည်။
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // ဒါဟာတိုတောင်းတဲ့ circuited, ဒါကြောင့်ကျန်ရှိသောပစ္စည်းများကြားမှာအတွက်နေဆဲ:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// နောက်ဆုံးရလဒ်ပြန်လာတစ်ခုစစ်ဆင်ရေးလျှောက်ထားခြင်းအားဖြင့်တစ်ဦးစုဆောင်းခြင်းသို့တိုင်းဒြပ်စင်ခြံ။
    ///
    /// `fold()` အငြင်းပွားမှုနှစ်ခုကိုပြုလုပ်သည်။ ကန ဦး တန်ဖိုးတစ်ခုနှင့်အငြင်းပွားမှုနှစ်ခုပါသောပိတ်သိမ်းမှုတစ်ခု-'accumulator' နှင့် element တစ်ခုဖြစ်သည်
    /// အဆိုပါပိတ်သိမ်းစုစည်းနေခြင်းကိုနောက်ကြားမှာအဘို့ရှိသင့်ကြောင်းတန်ဖိုးကို return ပွနျ။
    ///
    /// ကနဦးတန်ဖိုးစုဆောင်းခြင်းကိုပထမဦးဆုံးခေါ်ဆိုခအပေါ်ရပါလိမ့်မယ်တန်ဖိုးဖြစ်ပါတယ်။
    ///
    /// ဒီပိတ်သိမ်းမှုကိုကြားဖြတ်၏ဒြပ်စင်တိုင်းတွင်အသုံးပြုပြီးနောက် `fold()` သည်စုဆောင်းသူကိုပြန်ပို့သည်။
    ///
    /// ဤသည်စစ်ဆင်ရေးတခါတရံ 'reduce' သို့မဟုတ် 'inject' ဟုခေါ်သည်။
    ///
    /// သငျသညျအရာတစ်ခုခုတစ်ဦးစုဆောင်းမှုရှိသည်, ကနေတစ်ခုတည်းတန်ဖိုးကိုထုတ်လုပ်ရန်လိုသောအခါတိုင်းခေါက်အသုံးဝင်သည်။
    ///
    /// Note: `fold()` နှင့်တစ်ခုလုံးကိုကြားမှာဖြတ်သန်းကြောင်းအလားတူနည်းလမ်းများ, ရလဒ်ကနျ့အခြိနျမှာပြဌာန်းခွင့်ဖြစ်သောအဘို့အပင် traits ပေါ်အဆုံးမဲ့ကြားမှာအဘို့အအဆုံးသတ်ခြင်းမည်မဟုတ်ပါ။
    ///
    /// Note: စုဆောင်းခြင်းအမျိုးအစားနှင့်ပစ္စည်းအမျိုးအစားအတူတူပင်လျှင် [`reduce()`], ကန ဦး တန်ဖိုးအဖြစ်ပထမ ဦး ဆုံးဒြပ်စင်ကိုသုံးနိုင်သည်။
    ///
    /// # မှတ်ချက် Implementors မှ
    ///
    /// အခြား (forward) နည်းလမ်းအများအပြားဒါကြောင့်ပိုကောင်းကို default `for` ကွင်းဆက်အကောင်အထည်ဖော်မှုထက်တစ်ခုခုလုပ်နိုင်မယ်ဆိုရင်အတိအလင်းဒီအကောင်အထည်ဖေါ်ဖို့ကြိုးစား, ဒီတစျဦး၏စည်းကမ်းချက်များ၌ default အနေနဲ့ကလပ်စရှိသည်။
    ///
    ///
    /// အထူးသဖြင့်, ဒီကြားမှာရေးစပ်ရာကနေပြည်တွင်းရေးအစိတ်အပိုင်းများပေါ်တွင်ဤဖုန်းခေါ် `fold()` ရှိသည်ဖို့ကြိုးစားပါ။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // အဆိုပါစစ်ခင်းကျင်း၏ဒြပ်စင်အားလုံး၏ပေါင်းလဒ်
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// ဒီမှာကြားမှာအဆင့်တစ်ခုစီကိုလျှောက်ကြည့်ရအောင်။
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// ဒီတော့ကျွန်တော်တို့ရဲ့နောက်ဆုံးရလဒ်, `6`.
    ///
    /// ရလဒ်ညျဆောကျအမှုအရာများစာရင်းကိုအတူ `for` ကွင်းဆက်သုံးစွဲဖို့အများကြီးကြားမှာအသုံးမကြသူလူများအတွက်တကယ့်ဘုံ။သူများသည် `fold()`s သို့လှည့်နိုင်ပါတယ်:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // ကွင်းဆက်အဘို့:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // သူတို့အတူတူနေ
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// ထပ်တလဲလဲတစ်လျှော့ချစစ်ဆင်ရေးလျှောက်ထားခြင်းအားဖြင့်, တစ်ခုတည်းတဦးတည်းဖို့ element တွေကိုပါလျော့ကျစေပါတယ်။
    ///
    /// ကြားမှာအချည်းနှီးဖြစ်လျှင်, [`None`] ပြန်လာ;မဟုတ်ရင်လျှော့ချခြင်း၏ရလဒ်ကိုပြန်လည်ရောက်ရှိ။
    ///
    /// အနည်းဆုံး element တစ်ခုရှိ iterators အတွက်၎င်းသည် Xerx နှင့်အတူတူပင်ဖြစ်သည်။ ၎င်းသည်ကိန်းဂဏန်း၏ပထမ element နှင့်ကန ဦး တန်ဖိုးကဲ့သို့နောက်ဆက်တွဲ element အားလုံးကိုခေါက်သည်။
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// အများဆုံးတန်ဖိုးရှာပါ
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// စမ်းသပ်မှုဟာကြားမှာအမှုအမျိုးမျိုးရှိသမျှဒြပ်စင်တစ်ခု predicate ကိုက်ညီလျှင်။
    ///
    /// `all()` `true` သို့မဟုတ် `false` ပြန်လည်ရောက်ရှိတဲ့ပိတ်သိမ်းကြာပါသည်။ဒါဟာကြားမှာအသီးအသီးဒြပ်စင်ရန်ဤပိတ်သိမ်းသက်ဆိုင်, ထိုသူအပေါင်းတို့သည် `true` သို့ပြန်လာလျှင်, ထို့နောက်ဒါ `all()` ပါဘူး။
    /// သူတို့ကိုမဆို `false` ပြန်လာပါက `false` ပြန်လည်ရောက်ရှိ။
    ///
    /// `all()` Short-circuiting ဖြစ်၏တစ်နည်းဆိုရသော်၎င်းသည် `false` ကိုရှာသည်နှင့်တပြိုင်နက်လုပ်ဆောင်မှုကိုရပ်တန့်သွားလိမ့်မည်။ ဘာပဲဖြစ်ဖြစ်ဘာပဲဖြစ်ဖြစ်ဘာပဲဖြစ်ဖြစ်ရလဒ်ကတော့ `false` ဖြစ်သည်။
    ///
    ///
    /// တစ်ဦးအချည်းနှီးသောကြားမှာ `true` ပြန်လည်ရောက်ရှိ။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// ပထမဦးဆုံး `false` မှာရပ်တန့်:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // ဒြပ်စင်တွေပိုများနေလို့ကျွန်တော်တို့ `iter` ကိုသုံးနိုင်သေးတယ်။
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// စမ်းသပ်မှုဟာကြားမှာမဆိုဒြပ်စင်တစ်ခု predicate ကိုက်ညီလျှင်။
    ///
    /// `any()` `true` သို့မဟုတ် `false` ပြန်လည်ရောက်ရှိကြောင်းပိတ်သိမ်းကြာပါသည်။ဒါဟာကြားမှာအသီးအသီးဒြပ်စင်ရန်ဤပိတ်သိမ်းသက်ဆိုင်, သူတို့မဆို `true` သို့ပြန်လာလျှင်, ထို့နောက်ဒါ `any()` ပါဘူး။
    /// ထိုသူအပေါင်းတို့ `false` ပြန်လာပါက `false` ပြန်လည်ရောက်ရှိ။
    ///
    /// `any()` တိုတောင်းသော circuiting ဖြစ်၏တစ်နည်းအတွက်ကြောင့်မကြာမီပြုလုပ်သောအရာကိုအခြားအဘယ်သူမျှမကိစ္စဖြစ်ပျက်ကြောင်းပေးထားတစ် `true` တွေ့အဖြစ် processing ကိုရပ်တန့်ပါလိမ့်မယ်, ရလဒ်ကိုလည်း `true` ဖြစ်လိမ့်မည်။
    ///
    ///
    /// တစ်ဦးအချည်းနှီးသောကြားမှာ `false` ပြန်လည်ရောက်ရှိ။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// ပထမဦးဆုံး `true` မှာရပ်တန့်:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // ဒြပ်စင်တွေပိုများနေလို့ကျွန်တော်တို့ `iter` ကိုသုံးနိုင်သေးတယ်။
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// ကျေနပ်နေတဲ့ predicate တစ်ခုကြားမှာတစ်ဦးဒြပ်စင်အဘို့ရှာဖွေမှု။
    ///
    /// `find()` `true` သို့မဟုတ် `false` ပြန်လည်ရောက်ရှိကြောင်းပိတ်သိမ်းကြာပါသည်။
    /// ဒါဟာကြားမှာအသီးအသီးဒြပ်စင်ရန်ဤပိတ်သိမ်းသက်ဆိုင်, သူတို့မဆို `true` သို့ပြန်လာလျှင်, ထို့နောက် `find()` [`Some(element)`] ပြန်လည်ရောက်ရှိ။
    /// ထိုသူအပေါင်းတို့ `false` ပြန်လာပါက [`None`] ပြန်လည်ရောက်ရှိ။
    ///
    /// `find()` Short-circuiting ဖြစ်၏တစ်နည်းဆိုရလျှင်၎င်းသည် `true` ကိုပြန်လည်ရောက်ရှိသည်နှင့်ချက်ချင်းလုပ်ဆောင်ခြင်းကိုရပ်တန့်သွားလိမ့်မည်။
    ///
    /// `find()` တစ်ဦးကိုကိုးကားကြာနှင့်များစွာသောကြားမှာကိုးကားကျော် iterate, ထိုအငြင်းအခုံနှစ်ဆရည်ညွှန်းသည်အဘယ်မှာရှိတစ်ဦးဖြစ်နိုင်သည်ရှုတ်ထွေးအခြေအနေကဒီဆောင်ကြောင့်ဖြစ်သည်။
    ///
    /// သငျသညျ `&&x` နှင့်အတူအောက်ပါဥပမာမှာဒီအကျိုးသက်ရောက်မှုကိုတွေ့မြင်နိုင်ပါတယ်။
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// ပထမဦးဆုံး `true` မှာရပ်တန့်:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // ဒြပ်စင်တွေပိုများနေလို့ကျွန်တော်တို့ `iter` ကိုသုံးနိုင်သေးတယ်။
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// `iter.find(f)` `iter.filter(f).next()` ညီမျှကြောင်းသတိပြုပါ။
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// function ကို iterator ရဲ့ element တွေမှာသုံးပြီးပထမဆုံး non-none ရလဒ်ကို return ပြန်ပေးတယ်။
    ///
    ///
    /// `iter.find_map(f)` `iter.filter_map(f).next()` ညီမျှသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// function ကို iterator ရဲ့ element တွေမှာသုံးပြီးပထမဆုံးစစ်မှန်တဲ့ရလဒ် (သို့) ပထမအမှားကို return လုပ်တယ်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// ယင်း၏ညွှန်းကိန်းပြန်လာတစ်ခုကြားမှာတစ်ဒြပ်စင်အဘို့ရှာဖွေမှု။
    ///
    /// `position()` `true` သို့မဟုတ် `false` ပြန်လည်ရောက်ရှိကြောင်းပိတ်သိမ်းကြာပါသည်။
    /// ၎င်းသည်၎င်းပိတ်သိမ်းမှုကိုကြားဖြတ်၏ဒြပ်စင်တစ်ခုစီနှင့်သက်ဆိုင်ပြီး၎င်းတို့ထဲမှတစ်ခုသည် `true` ကိုပြန်ပို့ပါက `position()` က [`Some(index)`] ကိုပြန်ပေးသည်။
    /// သူတို့အားလုံးက `false` ကိုပြန်လာရင် [`None`] ကိုပြန်ပေးတယ်။
    ///
    /// `position()` တိုတောင်းသော circuiting ဖြစ်၏က `true` တွေ့ကဲ့သို့သောအခြားစကားကြောင့်မကြာမီအဖြစ် processing ကိုရပ်တန့်ပါလိမ့်မယ်။
    ///
    /// # လျတ်အပြုအမူ
    ///
    /// အဆိုပါနည်းလမ်းကပို [`usize::MAX`] Non-တိုက်ဆိုင်သည့်ဒြပ်စင်ထက်ရှိပါတယ်လျှင်ဒါကြောင့်ဖြစ်စေမှားရလဒ်သို့မဟုတ် panics ထုတ်လုပ်, လွှမ်းမိုးသောဆန့်ကျင်ခြင်းမရှိ Guard ပါဘူး။
    ///
    /// ဒီဘာဂ်အခိုင်အမာ enabled နေတယ်ဆိုရင်တစ် panic အာမခံချက်ဖြစ်ပါတယ်။
    ///
    /// # Panics
    ///
    /// အဆိုပါကြားမှာပိုပြီး `usize::MAX` Non-တိုက်ဆိုင်သည့်ဒြပ်စင်ထက်ရှိပါတယ်လျှင်ဒီ function တန်ခိုး panic ။
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// ပထမဦးဆုံး `true` မှာရပ်တန့်:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // ဒြပ်စင်တွေပိုများနေလို့ကျွန်တော်တို့ `iter` ကိုသုံးနိုင်သေးတယ်။
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // ပြန်အညွှန်းကိန်းကြားမှာပြည်နယ်ပေါ်တွင်မူတည်သည်
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// ညာဘက်ကနေကြားမှာတစ်ခု element တစ်ခုအဘို့အ၎င်း၏အညွှန်းကိန်းပြန်လာရှာဖွေပါ။
    ///
    /// `rposition()` `true` သို့မဟုတ် `false` ပြန်လည်ရောက်ရှိကြောင်းပိတ်သိမ်းကြာပါသည်။
    /// ထို့နောက် `rposition()` [`Some(index)`] ပြန်လည်ရောက်ရှိပါကအဆုံးကနေစတင်, ထိုကြားမှာအသီးအသီးဒြပ်စင်ရန်ဤပိတ်သိမ်းသက်ဆိုင်နှင့်သူတို့ထဲကတဦးတည်း `true` ပြန်လာလျှင်။
    ///
    /// သူတို့အားလုံးက `false` ကိုပြန်လာရင် [`None`] ကိုပြန်ပေးတယ်။
    ///
    /// `rposition()` တိုတောင်းသော circuiting ဖြစ်၏က `true` တွေ့ကဲ့သို့သောအခြားစကားကြောင့်မကြာမီအဖြစ် processing ကိုရပ်တန့်ပါလိမ့်မယ်။
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// ပထမဦးဆုံး `true` မှာရပ်တန့်:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // ဒြပ်စင်တွေပိုများနေလို့ကျွန်တော်တို့ `iter` ကိုသုံးနိုင်သေးတယ်။
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // ဒီနေရာမှာတစ်ခုလျတ်စစ်ဆေးမှုများအဘို့လိုအပ်ဘယ်သူမျှမက, `ExactSizeIterator` ဒြပ်စင်၏နံပါတ်တစ် `usize` သို့ကိုက်ညီသောအဓိပ္ပာယ်သက်ရောက်သောကွောငျ့။
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// တစ်ဦးကြားမှာအများဆုံးဒြပ်စင် Returns ။
    ///
    /// အတော်ကြာ element တွေကိုအညီအမျှအများဆုံးဖြစ်တယ်ဆိုရင်, နောက်ဆုံးသောဒြပ်စင်ပြန်ရောက်နေပါတယ်။
    /// အဆိုပါကြားမှာဗလာဖြစ်နေသည်ဆိုလျှင်, [`None`] ပြန်ရောက်နေပါတယ်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// တစ်ဦးကြားမှာ၏နိမ့်ဆုံးဒြပ်စင် Returns ။
    ///
    /// အတော်ကြာ element တွေကိုအညီအမျှနိမ့်ဆုံးရောက်နေတယ်ဆိုရင်, ပထမဦးဆုံးဒြပ်စင်ပြန်ရောက်နေပါတယ်။
    /// အဆိုပါကြားမှာဗလာဖြစ်နေသည်ဆိုလျှင်, [`None`] ပြန်ရောက်နေပါတယ်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// ပြန်သတ်မှတ်ထားတဲ့ function ကိုကနေအမြင့်ဆုံးတန်ဖိုးကိုပေးသည်သောဒြပ်စင်။
    ///
    ///
    /// အတော်ကြာ element တွေကိုအညီအမျှအများဆုံးဖြစ်တယ်ဆိုရင်, နောက်ဆုံးသောဒြပ်စင်ပြန်ရောက်နေပါတယ်။
    /// အဆိုပါကြားမှာဗလာဖြစ်နေသည်ဆိုလျှင်, [`None`] ပြန်ရောက်နေပါတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// ပြန်သတ်မှတ်ထားတဲ့နှိုင်းယှဉ် function ကိုရိုသေလေးစားမှုနှင့်အတူအမြင့်ဆုံးတန်ဖိုးကိုပေးသည်သောဒြပ်စင်။
    ///
    ///
    /// အတော်ကြာ element တွေကိုအညီအမျှအများဆုံးဖြစ်တယ်ဆိုရင်, နောက်ဆုံးသောဒြပ်စင်ပြန်ရောက်နေပါတယ်။
    /// အဆိုပါကြားမှာဗလာဖြစ်နေသည်ဆိုလျှင်, [`None`] ပြန်ရောက်နေပါတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// ပြန်သတ်မှတ်ထားတဲ့ function ကိုမှအနိမ့်ဆုံးတန်ဖိုးအားပေးသည်သောဒြပ်စင်။
    ///
    ///
    /// အတော်ကြာ element တွေကိုအညီအမျှနိမ့်ဆုံးရောက်နေတယ်ဆိုရင်, ပထမဦးဆုံးဒြပ်စင်ပြန်ရောက်နေပါတယ်။
    /// အဆိုပါကြားမှာဗလာဖြစ်နေသည်ဆိုလျှင်, [`None`] ပြန်ရောက်နေပါတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// သတ်မှတ်ထားသောနှိုင်းယှဉ် function ကိုမှလေးစားမှုနှင့်အတူနိမ့်ဆုံးတန်ဖိုးကိုပေးသောဒြပ်စင်ပြန်သွားသည်။
    ///
    ///
    /// အတော်ကြာ element တွေကိုအညီအမျှနိမ့်ဆုံးရောက်နေတယ်ဆိုရင်, ပထမဦးဆုံးဒြပ်စင်ပြန်ရောက်နေပါတယ်။
    /// အဆိုပါကြားမှာဗလာဖြစ်နေသည်ဆိုလျှင်, [`None`] ပြန်ရောက်နေပါတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// တစ်ဦးကြားမှာရဲ့လမျးညှနျနောက်ကြောင်းပြန်။
    ///
    /// အများအားဖြင့်, ကြားမှာ left ကနေညာဘက်ကို iterate ။
    /// `rev()` တစ်ခုကြားမှာလက်ျာဘက်ကနေဘယ်ဘက်ကိုပါလိမ့်မယ်အစားကြားမှာသုံးပြီးပြီးနောက်။
    ///
    /// ကြားမှာအဆုံးရှိတယ်ဆိုရင်ဒါကဖြစ်နိုင်တယ်၊ ဒါကြောင့် `rev()` [`DoubleEndedIterator`] များပေါ်တွင်သာအလုပ်လုပ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// ကွန်တိန်နာတရံသို့အားလုံးအတွက်တစ်ခုကြားမှာပြောင်းပေးပါတယ်။
    ///
    /// `unzip()` အဆိုပါအားလုံးအတွက်၏လက်ဝဲဒြပ်စင်အနေဖြင့်တဦးတည်း, လက်ျာဒြပ်စင်အနေဖြင့်တဦးတည်းနှစ်ခု collection များကိုထုတ်လုပ်အားလုံးအတွက်တစ်ခုတစ်ခုလုံးကိုကြားမှာစားသုံး။
    ///
    ///
    /// ဒီ function အချို့သဘော, [`zip`] ၏ဆန့်ကျင်ဘက်ဖြစ်ပါတယ်။
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// ၎င်းဒြပ်စင်များအားလုံးကိုကော်ပီကူးသည့်ကြားဖြတ်တစ်ခုကိုဖန်တီးသည်။
    ///
    /// သငျသညျ `&T` ကျော်တစ်ဦးကြားမှာရှိတဲ့အခါဒီအသုံးဝင်သည်, သင်မူကား `T` ကျော်တစ်ဦးကြားမှာလိုအပ်ပါတယ်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // .map(|&x| x) အဖြစ်အတူတူပင်ဖြစ်ပါသည်ကူးယူ
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// ၎င်း၏ဒြပ်စင်အပေါငျးတို့သည့်အရာ [`clone`] တစ်ဦးကြားမှာဖန်တီးပေးပါတယ်။
    ///
    /// သငျသညျ `&T` ကျော်တစ်ဦးကြားမှာရှိတဲ့အခါဒီအသုံးဝင်သည်, သင်မူကား `T` ကျော်တစ်ဦးကြားမှာလိုအပ်ပါတယ်။
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // .map(|&x| x) ကဲ့သို့တူညီသောကိန်းများအတွက်ဖြစ်ပါသည်ပုံတူမျိုးပွား
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// အတောမသတ်တစ်ခုကြားမှာထပ်တလဲလဲပြုရန်။
    ///
    /// အဲဒီအစား [`None`] မှာရပ်တန့်၏, ထိုကြားမှာအစားရှေ့ဦးစွာ မှစ. , တဖန်စတင်လာလိမ့်မည်။နောက်တဖန် iterating ပြီးနောက်ကြောင့်နောက်တဖန်အစအဦးမှာစတင်ပါလိမ့်မည်။တဖန်။
    /// တဖန်တုံ။
    /// Forever.
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// တစ်ဦးကြားမှာ၏ဒြပ်စင်သေးပါဘူး။
    ///
    /// တစ်ဦးချင်းစီဒြပ်စင်ကြာအတူတူသူတို့ကိုဖြည့်စွက်ခြင်း, ရလဒ်ပြန်လည်ရောက်ရှိ။
    ///
    /// တစ်ဦးအချည်းနှီးသောကြားမှာအမျိုးအစားများ၏သုညတန်ဖိုးကို return ပွနျ။
    ///
    /// # Panics
    ///
    /// `sum()` ကိုခေါ်ဆိုခြင်းနှင့် Primitive integer type ကိုပြန်ပို့သောအခါ computation overflow နှင့် debug assertions ကို enable လုပ်ထားမယ်ဆိုရင်ဒီ method သည် panic ဖြစ်ပါလိမ့်မယ်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// လူအပေါင်းတို့သည်ဒြပ်စင်ပွားတစ်ခုလုံးကိုကြားမှာကျော်ကြားမှာ,
    ///
    /// တစ် ဦး အချည်းနှီးသောကြားမှာအမျိုးအစားတစ်ခုတန်ဖိုးကိုပြန်လာ။
    ///
    /// # Panics
    ///
    /// `product()` ကိုခေါ်ဆိုခြင်းနှင့် Primitive integer type ကိုပြန်ပို့သောအခါတွက်ချက်မှုများထပ်လောင်း။ debug အခိုင်အမာပြောဆိုမှုများကိုလုပ်ဆောင်ပါက method သည် panic ဖြစ်ပါလိမ့်မည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) အခြားသူတို့နှင့်အတူဤ [`Iterator`] ၏ဒြပ်စင်နှိုင်းယှဉ်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) အဆိုပါသတ်မှတ်ထားတဲ့နှိုင်းယှဉ် function ကိုရိုသေလေးစားမှုနှင့်အတူအခြားသူတို့နှင့်အတူဤ [`Iterator`] ၏ဒြပ်စင်နှိုင်းယှဉ်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) အခြားသူတို့နှင့်အတူဤ [`Iterator`] ၏ဒြပ်စင်နှိုင်းယှဉ်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) အဆိုပါသတ်မှတ်ထားတဲ့နှိုင်းယှဉ် function ကိုရိုသေလေးစားမှုနှင့်အတူအခြားသူတို့နှင့်အတူဤ [`Iterator`] ၏ဒြပ်စင်နှိုင်းယှဉ်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// ဒီ [`Iterator`] ၏ဒြပ်စင်ကိုအခြားသူတို့နဲ့တန်းတူဖြစ်ကြပါလျှင်ဆုံးဖြတ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// ဒီ [`Iterator`] ၏ element များသည်သတ်မှတ်ထားသောတန်းတူညီမျှမှု function ကိုလေးစားမှုရှိသူအခြားသူများနှင့်တန်းတူလျှင်ဆုံးဖြတ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// ဒီ [`Iterator`] ၏ဒြပ်စင်များသည်အခြားအရာများနှင့်မတူညီပါကဆုံးဖြတ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// ဒီ [`Iterator`] ၏ဒြပ်စင် [lexicographically](Ord#lexicographical-comparison) လျော့နည်းအခြားသူတို့ထက်လျှင်ဆုံးဖြတ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// ဒီ [`Iterator`] ၏ဒြပ်စင် [lexicographically](Ord#lexicographical-comparison) များမှာလျော့နည်းသို့မဟုတ်အခြားသူတို့မှတူညီပါလျှင်ဆုံးဖြတ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// ဒီ [`Iterator`] ၏ဒြပ်စင်များသည်အခြားအရာများထက် [lexicographically](Ord#lexicographical-comparison) ပိုကြီးသည်ကိုဆုံးဖြတ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// ဒီ [`Iterator`] ၏ဒြပ်စင်ထက် [lexicographically](Ord#lexicographical-comparison) သာ. ကြီးမြတ်ဖြစ်ကြသည်သို့မဟုတ်အခြားသူတို့မှတူညီပါလျှင်ဆုံးဖြတ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// ဒီကြားမှာ၏ဒြပ်စင် sorted လျှင်စစ်ဆေးသည်။
    ///
    /// တစ်ဦးချင်းစီဒြပ်စင် `a` နှင့်၎င်း၏အောက်ပါဒြပ်စင် `b` အဘို့, `a <= b` ဒါကကိုင်ထားရမယ်ဖြစ်ပါတယ်။အဆိုပါကြားမှာအထွက်နှုန်းအတိအကျသုညသို့မဟုတ်တဦးတည်းဒြပ်စင်လြှငျ, `true` ပြန်ရောက်နေပါတယ်။
    ///
    /// `Self::Item` သာ `PartialOrd` ဖြစ်တယ်, ဒါပေမဲ့မပေး `Ord` လျှင်မှတ်ချက်, အထက်ပါချက်နှင့်အဓိပ္ပါယ်မဆိုနှစ်ခုဆက်တိုက်ပစ္စည်းများနှိုင်းယှဉ်မရလျှင်ဒီ function ကို `false` ပြန်လည်ရောက်ရှိကြောင်းအဓိပ္ပာယ်သက်ရောက်ကြောင်း။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// စစ်ဆေးမှုများဒီကြားမှာ၏ဒြပ်စင်လျှင်ပေးထားသောနှိုင်းယှဉ် function ကိုသုံးပြီးခွဲခြားပေးသည်။
    ///
    /// အဲဒီအစား `PartialOrd::partial_cmp` အသုံးပြုခြင်း၏, ဒီ function ကိုနှစ်ခုဒြပ်စင်များ၏သာသနာကိုဆုံးဖြတ်ရန်ပေးထားသော `compare` function ကိုအသုံးပြုသည်။
    /// အပြင်ကနေ, က [`is_sorted`] ညီမျှင်;ပိုမိုသိရှိလိုပါက၎င်း၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// ဒီကြားမှာ၏ဒြပ်စင်ပေးထားသော key ကိုထုတ်ယူ function ကိုသုံးပြီးခွဲခြားပေးသည်လျှင်စစ်ဆေးမှုများ။
    ///
    /// အဲဒီအစားတိုက်ရိုက်ကြားမှာရဲ့ element တွေကိုနှိုင်းယှဉ်၏ `f` ကဆုံးဖြတ်အဖြစ်, ဒီ function ကို, ထိုဒြပ်စင်၏သော့နှိုင်းယှဉ်။
    /// အပြင်ကနေ, က [`is_sorted`] ညီမျှင်;ပိုမိုသိရှိလိုပါက၎င်း၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// [TrustedRandomAccess] ကိုကြည့်ပါ
    // အဆိုပါပုံမှန်မဟုတ်သောနာမကိုအမှီ #76479 တွေ့မြင်နည်းလမ်း resolution ကို in နာမည်ဝင်တိုက်ခြင်းမှရှောင်ရှားရန်ဖြစ်ပါသည်။
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}