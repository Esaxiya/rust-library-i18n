/// ယင်း၏အတိအကျအရှည်ကိုသိသောကြားမှာ။
///
/// [`Iterator`] s ကိုအတော်များများကသူတို့ iterate ပါလိမ့်မယ်ဘယ်လိုအကြိမ်ပေါင်းများစွာမသိရပါဘူး, ဒါပေမယ့်အချို့လုပ်ပါ။
/// တစ်ဦးကြားမှာကြောင့် iterate နိုငျပုံကိုအကြိမ်ပေါင်းများစွာသိတယ်လြှငျ, သတင်းအချက်အလက်မှဝင်ရောက်ခွင့်ပေးအသုံးဝင်သောနိုင်ပါတယ်။
/// သငျသညျကြားမှာနောက်ပြန်ချင်လျှင်ဥပမာ, ကောင်းတစ်ဦးက start ဆုံးသည်အဘယ်မှာသိရန်ဖြစ်ပါသည်။
///
/// `ExactSizeIterator` တစ်ခုကိုအကောင်အထည်ဖော်သည့်အခါသင်သည်လည်း [`Iterator`] ကိုအသုံးပြုရမည်။
/// ဒီတော့လုပ်နေသည့်အခါ [`Iterator::size_hint`] များ၏အကောင်အထည်ဖော်မှု *မဖြစ်မနေ* ပုကြားမှာ၏အတိအကျအရွယ်အစားပြန်သွားပါ။
///
/// အဆိုပါ [`len`] နည်းလမ်းတစ်ဦးက default အကောင်အထည်ဖော်ရေးရှိပါတယ်, ဒါကြောင့်သင်များသောအားဖြင့်ကအကောင်အထည်မဖော်သင့်ပါတယ်။
/// သို့သျောလညျးသငျသညျကို default ထက်ပိုပြီးစွမ်းဆောင်ရည်အကောင်အထည်ဖော်မှုပေးနိုင်မည်အကြောင်း, ဒါကြောင့်ဤကိစ္စတွင်၌၎င်းအားသဘာဝကျပါတယ်။
///
///
/// ဒီ trait လုံခြုံ trait ဖြစ်ပြီးထိုကဲ့သို့သောပါဘူး *မဟုတ်* နှင့် *အပြန်လာသောအရှည်မှန်ကန်စေသည်* အာမခံချက်မပေးနိုင်ကြောင်းမှတ်ချက်။
/// `unsafe` ကုဒ် ** **[`Iterator::size_hint`] ၏မှန်ကန်မှုအပေါ်မှီခိုမနေရပါသောဤနည်းလမ်းများ။
/// မတည်မငြိမ်နှင့်အန္တရာယ်မကင်းသော [`TrustedLen`](super::marker::TrustedLen) trait ကဤအပိုဆောင်းအာမခံချက်ကိုပေးသည်။
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// အခြေခံအသုံးပြုမှု-
///
/// ```
/// // တစ်ဦးကနျ့အကွာအဝေးက iterate လိမ့်မယ်အတိအကျဘယ်လိုအကြိမ်ပေါင်းများစွာသိတယ်
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// အဆိုပါ [module-level docs] တှငျကြှနျုပျတို့တစ်ခု [`Iterator`] အကောင်အထည်ဖော်, `Counter`.
/// ရဲ့အဖြစ်ကောင်းစွာထိုသို့ `ExactSizeIterator` အကောင်အထည်ဖော်ကြစို့:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // ကျနော်တို့ကိုအလွယ်တကူကြားမှာ၏ကျန်ရှိသောအရေအတွက်ကိုတွက်ချက်နိုင်ပါတယ်။
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // ယခုမှာအကြှနျုပျတို့အသုံးပွုနိုငျပါသညျ!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// အဆိုပါကြားမှာ၏အတိအကျကိုအရှည် Returns ။
    ///
    /// အဆိုပါကြားမှာ [`None`] ပြန်မီတစ် [`Some(T)`] တန်ဖိုးကို `len()` အတိအကျကိုပိုမိုကြိမ်ပြန်လာလိမ့်မည်ဟုအဆိုပါအကောင်အထည်ဖော်ရေးလုပ်ဆောင်။
    ///
    /// ဤနည်းလမ်းကိုတစ်ဦးက default အကောင်အထည်ဖော်ရေးရှိပါတယ်, ဒါကြောင့်သင်များသောအားဖြင့်တိုက်ရိုက်အကောင်အထည်မဖော်သင့်ပါတယ်။
    /// သင်တစ်ဦးပိုမိုထိရောက်သောအကောင်အထည်ဖော်မှုပေးနိုငျပါလျှင်မည်သို့ပင်ဆို, သင်တို့သည်ဤမျှလုပ်နိုင်ပါတယ်။
    /// ဥပမာတစ်ခုများအတွက် [trait-level] စာရွက်စာတမ်းများကိုကြည့်ပါ။
    ///
    /// ဒီ function ဟာ [`Iterator::size_hint`] function ကိုကဲ့သို့တူညီသောဘေးကင်းလုံခြုံမှုအာမခံချက်ရှိပါတယ်။
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// // တစ်ဦးကနျ့အကွာအဝေးက iterate လိမ့်မယ်အတိအကျဘယ်လိုအကြိမ်ပေါင်းများစွာသိတယ်
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: ဤသည်အခိုင်အမာအလွန်အမင်းခုခံကာကွယ်ဖြစ်တယ်, ဒါပေမဲ့ကလျော့ပါးသွားမည်ဖြစ်သလိုစစ်ဆေးနေ
        // trait မှအာမခံသည်။
        // ဒီ trait rust-ပြည်တွင်းရေးခဲ့ကြသည်လျှင်, ငါတို့သည် debug_assert အသုံးပွုနိုငျ !;assert_eq!အရမ်းအားလုံး Rust အသုံးပြုသူ Implementation ကိုစစ်ဆေးပါလိမ့်မယ်။
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// အဆိုပါကြားမှာဗလာဖြစ်နေလျှင် `true` Returns ။
    ///
    /// ဤနည်းလမ်းကို [`ExactSizeIterator::len()`] သုံးပြီး default အအကောင်အထည်ဖော်ရေးရှိပါတယ်, သင်ကကိုယ့်ကိုကိုယ်အကောင်အထည်ဖော်ရန်လိုအပ်ပါဘူးဒါကြောင့်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}