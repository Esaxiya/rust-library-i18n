use crate::{iter::FusedIterator, ops::Try};

/// အတောမသတ်ကို repeat တစ်ခုကြားမှာ။
///
/// ဤသည် `struct` [`Iterator`] အပေါ် [`cycle`] နည်းလမ်းကိုအသုံးပြုနေသူများကဖန်တီးထားသည်။
/// ပိုမိုသိရှိလိုပါက၎င်း၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // သံသရာကြားမှာဖြစ်စေအချည်းနှီးသောသို့မဟုတ်အဆုံးမဲ့ဖြစ်ပါသည်
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // အပြည့်အဝဟာလက်ရှိကြားမှာ iterate ။
        // `self.orig` မဟုတ်ပါဘူးလျှင်ပင် `self.iter` သွန်စေခြင်းငှါဤအကြောင်းကြောင့်လိုအပ်သောဖြစ်ပါသည်
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // အဆိုပါကြားမှာဗလာသို့မဟုတ်မစက်လီးစီးခြင်းရှိမရှိခြေရာခံစောင့်ရှောက်ခြင်း, အပြည့်အဝသံသရာဖြည့်စွက်။
        // ကျနော်တို့အနေနဲ့အဆုံးမဲ့ loop ကိုကာကွယ်တားဆီးဖို့အစောပိုင်းတစ်ဦးအချည်းနှီးသောကြားမှာ၏အမှု၌ပြန်လာရန်လိုအပ်ပါတယ်
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // အဘယ်သူမျှမ `fold` အပေါ်မှထပ်, `fold` `Cycle` ဘို့အများကြီးအဓိပ္ပာယ်လုပ်မထားဘူး, ကြှနျုပျတို့ပိုကောင်းကို default ထက်ဘာမှမပွုနိုငျသောကွောငျ့။
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}