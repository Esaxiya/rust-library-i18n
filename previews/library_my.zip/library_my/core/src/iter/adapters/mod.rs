use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// ဤသည် trait သောအခြေအနေများအောက်တွင်တစ်ဦး Inter-Adapter ကိုပိုက်လိုင်းအတွက်အရင်းအမြစ်-ဇာတ်စင်မှ Transit access ကိုပေးသည်
/// * အဆိုပါကြားမှာအရင်းအမြစ် `S` သူ့ဟာသူ `SourceIter<Source = S>` အကောင်အထည်ဖော်ဆောင်ရွက်နေသော
/// * အရင်းအမြစ်နှင့်ပိုက်လိုင်းစားသုံးသူများအကြားပိုက်လိုင်းစီ adapter အဘို့ဤ trait တစ်ဦးလွှဲအပ်အကောင်အထည်ဖော်ရေးလည်းမရှိ။
///
/// အရင်းအမြစ် (လေ့ `IntoIter` ခေါ်) တစ်ခုပိုင်ဆိုင်ကြားမှာ struct အခါဖြစ်လျှင်ဤ [`FromIterator`] Implementation ကိုအထူးပြုသို့မဟုတ်တစ်ခုကြားမှာတစ်စိတ်တစ်ပိုင်းမောခဲ့ပြီးနောက်ကျန်ရှိသော element တွေကိုပြန်လည်အသုံးဝင်စေနိုင်ပါတယ်။
///
///
/// ကလပ်စသေချာပေါက်တစ်ဦးပိုက်လိုင်း၏အတွင်းဆုံးအရင်းအမြစ်မှဝင်ရောက်ခွင့်ပေးရန်မလိုပါကြောင်းမှတ်ချက်။ပြည်နယ်အလယ်အလတ် adapter စိတ်အားထက်သန်စွာပိုက်လိုင်း၏အစိတ်အပိုင်းတစ်ခုအကဲဖြတ်ရန်နှင့်အရင်းအမြစ်အဖြစ်က၎င်း၏ပြည်တွင်းရေးသိုလှောင်မှုဖော်ထုတ်ပါလိမ့်မယ်။
///
/// အကောင်အထည်ဖေါ်နောက်ထပ်ဘေးကင်းလုံခြုံမှုဂုဏ်သတ္တိများထောက်ရမယ်ဘာလို့လဲဆိုတော့အဆိုပါ trait မလုံခြုံသည်။
/// အသေးစိတ်အတွက် [`as_inner`] ကိုကြည့်ပါ။
///
/// # Examples
///
/// တစ်ဦးတစ်စိတ်တစ်ပိုင်းကိုလောင်အရင်းအမြစ်ရယူခြင်း:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// တစ်ဦးကြားမှာပိုက်လိုင်းတစ်အရင်းအမြစ်ဇာတ်စင်။
    type Source: Iterator;

    /// ကြားမှာပိုက်လိုင်း၏အရင်းအမြစ်ကိုပြန်လည်ရယူပါ။
    ///
    /// # Safety
    ///
    /// အကောင်အထည်ဖော်မှုများသည်ခေါ်ဆိုသူ၏နံပါတ်ကိုအစားထိုးခြင်းမရှိပါက၎င်းတို့၏သက်တမ်းအတွက်တူညီသောပြောင်းလဲနိုင်သောရည်ညွှန်းချက်ကိုပြန်ပို့ရမည်။
    /// ခေါ်ဆိုသူများသာသူတို့ကြားမှာရပ်တန့်သည့်အခါရည်ညွှန်းအစားထိုးရန်နှင့်အရင်းအမြစ်ထုတ်ယူပြီးနောက်ကြားမှာပိုက်လိုင်း drop လိမ့်မည်။
    ///
    /// ဒါကနည်းလမ်း Adapter ကကြားမှာနေစဉ်အတွင်းပြောင်းလဲနေတဲ့မအရင်းအမြစ်အပေါ်အားကိုးနိုင်ပါတယ်ဒါပေမဲ့သူတို့ကသူတို့ Drop ကလပ်စ၌အပေါ်အားကိုးလို့မရပါဘူး iterator ။
    ///
    /// ဒီနည်းလမ်းကိုနည်းလမ်းများ Adapter ကအကောင်အထည်ဖော်သူတို့ရဲ့အရင်းအမြစ်မှပုဂ္ဂလိက-သာ access ကိုလက်လွှတ်သာအာမခံချက်အပေါ်နည်းလမ်းကိုလက်ခံအမျိုးအစားများအပေါ်အခြေခံပြီးလုပ်အားကိုးနိုင်ပါတယ်။
    /// အကန့်အသတ်ဖြင့်သာဝင်ရောက်ခြင်းမရှိခြင်းသည် adapters များသည် ၄ င်း၏အတွင်းပိုင်းကို ၀ င်ရောက်နိုင်သည့်တိုင်အရင်းအမြစ်၏အများဆိုင် API ကိုထိန်းသိမ်းရန်လိုအပ်သည်။
    ///
    /// အလှည့်အတွက်ခေါ်ဆိုကြောင်းနှင့်အရင်းအမြစ်အကြားထိုင်လျက် Adapter ကအတူတူပင်အသုံးပြုခွင့်ရှိသည်ကတည်းကအရင်းအမြစ်က၎င်း၏အများပြည်သူ API ဖြင့်တသမတ်တည်းဖြစ်တယ်ဆိုတာမဆိုပြည်နယ်အတွက်ဖြစ်မျှော်လင့်ရပါမည်။
    /// အထူးသဖြင့်တစ်ဦး adapter တင်းကြပ်စွာလိုအပ်သောထက်ပိုဒြပ်စင်ကျွမ်းလောင်ကြပေမည်။
    ///
    /// ဤလိုအပ်ချက်များ၏အဓိကရည်မှန်းချက်မှာပိုက်လိုင်းအားသုံးစွဲသူများအားအသုံးပြုခွင့်ပေးရန်ဖြစ်သည်
    /// * ကြားမှာရပ်တန့်လိုက်ပါတယ်ပြီးနောက်အရင်းအမြစ်တွင်ကျန်ရှိနေသမျှ
    /// * တစ်စားသုံးကြားမှာတိုးတက်နေဖြင့်အသုံးမပြုတဲ့ဖြစ်လာသည်သောမှတ်ဥာဏ်
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// ရှည်လျားသောနောက်ခံကြားမှာ `Result::Ok` တန်ဖိုးများကိုထုတ်လုပ်သကဲ့သို့ output ကိုထုတ်လုပ်ထားတဲ့ကြားမှာ adapter ။
///
///
/// မှားယွင်းမှုတစ်ခုကြုံတွေ့လျှင်, ကြားမှာရပ်နှင့်အမှားသိမ်းဆည်းထားခြင်းဖြစ်သည်။
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// ဒါကြောင့်အစား `Result<T, _>` တစ် `T` လြှော့လျှင်အဖြစ်ပေးထားသောကြားမှာ process ။
/// မည်သည့်အမှားမဆိုအတွင်းပိုင်းကြားဖြတ်ကိုရပ်တန့်စေပြီးရလဒ်အားလုံးမှားသွားလိမ့်မည်။
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}