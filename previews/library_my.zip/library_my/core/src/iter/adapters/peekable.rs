use crate::iter::{adapters::SourceIter, FusedIterator, InPlaceIterable, TrustedLen};
use crate::ops::Try;

/// လာမယ့်ဒြပ်စင်တစ်ခု optional ကိုရည်ညွှန်းပြန်လည်ရောက်ရှိကြောင်း `peek()` နှင့်အတူတစ်ဦးကြားမှာ။
///
///
/// ဤသည် `struct` [`Iterator`] အပေါ် [`peekable`] နည်းလမ်းကိုအသုံးပြုနေသူများကဖန်တီးထားသည်။
/// ပိုမိုသိရှိလိုပါက၎င်း၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
///
/// [`peekable`]: Iterator::peekable
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Peekable<I: Iterator> {
    iter: I,
    /// ဒါကြောင့်အဘယ်သူမျှမခဲ့လျှင်ပင်တစ် peek တန်ဖိုးကိုသတိရပါ။
    peeked: Option<Option<I::Item>>,
}

impl<I: Iterator> Peekable<I> {
    pub(in crate::iter) fn new(iter: I) -> Peekable<I> {
        Peekable { iter, peeked: None }
    }
}

// တစ်ဦးမျှအဆိုပါ `.peek()` နည်းလမ်းတွင်တွေ့မြင်ထားပြီးလျှင် Peekable သတိရရမည်ဖြစ်သည်။
// ၎င်းသည် `.peek() ကိုသေချာစေသည်။.peek();` သို့မဟုတ် `.peek();.next();` သည်နောက်ခံအကြောင်းအရင်းကိုအများဆုံးတစ်ကြိမ်သာတိုးတက်စေသည်။
// ဒါကကိုယ်နှိုက်ခြင်းအားဖြင့်ကြားမှာ fused လုပ်မထားဘူး။
//
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> Iterator for Peekable<I> {
    type Item = I::Item;

    #[inline]
    fn next(&mut self) -> Option<I::Item> {
        match self.peeked.take() {
            Some(v) => v,
            None => self.iter.next(),
        }
    }

    #[inline]
    #[rustc_inherit_overflow_checks]
    fn count(mut self) -> usize {
        match self.peeked.take() {
            Some(None) => 0,
            Some(Some(_)) => 1 + self.iter.count(),
            None => self.iter.count(),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        match self.peeked.take() {
            Some(None) => None,
            Some(v @ Some(_)) if n == 0 => v,
            Some(Some(_)) => self.iter.nth(n - 1),
            None => self.iter.nth(n),
        }
    }

    #[inline]
    fn last(mut self) -> Option<I::Item> {
        let peek_opt = match self.peeked.take() {
            Some(None) => return None,
            Some(v) => v,
            None => None,
        };
        self.iter.last().or(peek_opt)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let peek_len = match self.peeked {
            Some(None) => return (0, Some(0)),
            Some(Some(_)) => 1,
            None => 0,
        };
        let (lo, hi) = self.iter.size_hint();
        let lo = lo.saturating_add(peek_len);
        let hi = match hi {
            Some(x) => x.checked_add(peek_len),
            None => None,
        };
        (lo, hi)
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let acc = match self.peeked.take() {
            Some(None) => return try { init },
            Some(Some(v)) => f(init, v)?,
            None => init,
        };
        self.iter.try_fold(acc, f)
    }

    #[inline]
    fn fold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        let acc = match self.peeked {
            Some(None) => return init,
            Some(Some(v)) => fold(init, v),
            None => init,
        };
        self.iter.fold(acc, fold)
    }
}

#[stable(feature = "double_ended_peek_iterator", since = "1.38.0")]
impl<I> DoubleEndedIterator for Peekable<I>
where
    I: DoubleEndedIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> {
        match self.peeked.as_mut() {
            Some(v @ Some(_)) => self.iter.next_back().or_else(|| v.take()),
            Some(None) => None,
            None => self.iter.next_back(),
        }
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        match self.peeked.take() {
            Some(None) => try { init },
            Some(Some(v)) => match self.iter.try_rfold(init, &mut f).into_result() {
                Ok(acc) => f(acc, v),
                Err(e) => {
                    self.peeked = Some(Some(v));
                    Try::from_error(e)
                }
            },
            None => self.iter.try_rfold(init, f),
        }
    }

    #[inline]
    fn rfold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        match self.peeked {
            Some(None) => init,
            Some(Some(v)) => {
                let acc = self.iter.rfold(init, &mut fold);
                fold(acc, v)
            }
            None => self.iter.rfold(init, fold),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator> ExactSizeIterator for Peekable<I> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator> FusedIterator for Peekable<I> {}

impl<I: Iterator> Peekable<I> {
    /// အဆိုပါကြားမှာတိုးတက်မရှိဘဲ next() တန်ဖိုးကိုတစ်ဦးကိုကိုးကား Returns ။
    ///
    /// တန်ဖိုးလည်းမရှိလျှင် [`next`] ကဲ့သို့ပင်, တက `Some(T)` ပတ်ရစ်လျက်ရှိသည်။
    /// အဆိုပါကြားမှာကျော်ဖြစ်ပါတယ်လျှင်မူကား, `None` ပြန်ရောက်နေပါတယ်။
    ///
    /// [`next`]: Iterator::next
    ///
    /// အဘယ်ကြောင့်ဆိုသော် `peek()` သည်ရည်ညွှန်းမှုတစ်ခုကိုပြန်ပို့ပေးပြီး၊ များစွာသောကြားဖြတ်များကကိုးကားချက်များအကြားထပ်ခါထပ်ခါပြုလုပ်သောကြောင့်ပြန်လာသောတန်ဖိုးသည်နှစ်ဆရည်ညွှန်းသောရှုပ်ထွေးဖွယ်အခြေအနေဖြစ်နိုင်သည်။
    /// သငျသညျအောက်ကဥပမာမှာဒီအကျိုးသက်ရောက်မှုကိုတွေ့မြင်နိုင်ပါတယ်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() ကျွန်တော်တို့ကို future ကိုကြည့်ခွင့်ပေးတယ်
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // ကျနော်တို့ `peek` အကြိမ်ပေါင်းများစွာလျှင်ကြားမှာပင်တိုးမထားဘူး
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // ကြားမှာပြီးတာနဲ့ `peek()` ပြီးသွားပြီ
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&mut self) -> Option<&I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_ref()
    }

    /// အဆိုပါကြားမှာတိုးတက်မရှိဘဲ next() တန်ဖိုးကိုတစ် mutable ရည်ညွှန်း Returns ။
    ///
    /// တန်ဖိုးလည်းမရှိလျှင် [`next`] ကဲ့သို့ပင်, တက `Some(T)` ပတ်ရစ်လျက်ရှိသည်။
    /// အဆိုပါကြားမှာကျော်ဖြစ်ပါတယ်လျှင်မူကား, `None` ပြန်ရောက်နေပါတယ်။
    ///
    /// `peek_mut()` တစ်ဦးကိုကိုးကားပြန်လည်ရောက်ရှိနှင့်များစွာသောကြားမှာကိုးကားကျော် iterate သောကြောင့်, ပြန်လာတန်ဖိုးကိုနှစ်ဆရည်ညွှန်းသည်အဘယ်မှာရှိတစ်ဦးဖြစ်နိုင်သည်ရှုတ်ထွေးအခွအေနရှိစေနိုင်ပါတယ်။
    /// သငျသညျအောက်ကဥပမာမှာဒီအကျိုးသက်ရောက်မှုကိုတွေ့မြင်နိုင်ပါတယ်။
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// #![feature(peekable_peek_mut)]
    /// let mut iter = [1, 2, 3].iter().peekable();
    ///
    /// // `peek()` နှင့်အတူလိုပဲကျနော်တို့ကြားမှာတိုးတက်မရှိဘဲ future သို့တွေ့မြင်နိုင်သည်။
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // အဆိုပါကြားမှာနှင့်ထားသို့ peek အဆိုပါ mutable ရည်ညွှန်းနောက်ကွယ်မှတန်ဖိုး။
    /// if let Some(p) = iter.peek_mut() {
    ///     assert_eq!(*p, &2);
    ///     *p = &5;
    /// }
    ///
    /// // အဆိုပါကြားမှာဆက်ပြီးအဖြစ်ကျွန်တော်ပြန်ပေါ်လာအတွက်ထားတန်ဖိုးကို။
    /// assert_eq!(iter.collect::<Vec<_>>(), vec![&5, &3]);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "peekable_peek_mut", issue = "78302")]
    pub fn peek_mut(&mut self) -> Option<&mut I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_mut()
    }

    /// တစ်ခွအေနအေမှန်လျှင်ဒီကြားမှာ၏နောကျတနျဖိုးလောင်ခြင်းနှင့်ပြန်သွားပါ။
    /// `func` ဒီကြားမှာ၏နောကျတနျဖိုးအဘို့အ `true` ပြန်လည်ရောက်ရှိပါကလောင်နှင့်ပြန်သွားပါ။
    /// ဒီလိုမှမဟုတ်ရင် `None` ပြန်သွားပါ။
    /// # Examples
    /// 0 နှင့်ညီလျှင်နံပါတ်တစ်ခုကိုစားပါ။
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // အဆိုပါကြားမှာ၏ပထမဦးဆုံးကို item 0 င်ဖြစ်၏ဒါကြောင့်စားသုံးကြသည်။
    /// assert_eq!(iter.next_if(|&x| x == 0), Some(0));
    /// // ပြန်ရောက်လာမယ့်ပစ္စည်းကိုယခု 1 ဖြစ်တယ်, ဒါ `consume` `false` ပြန်လာပါလိမ့်မယ်။
    /// assert_eq!(iter.next_if(|&x| x == 0), None);
    /// // `next_if` က `expected` ညီမျှမဟုတ်ခဲ့လျှင်နောက်တစ်နေ့ကို item ၏တန်ဖိုးကယ်တင်တော်မူ၏။
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    ///
    /// လျော့နည်း 10 ထက်မဆိုအရေအတွက်အားကိုစားသုံးကြသည်။
    ///
    /// ```
    /// let mut iter = (1..20).peekable();
    /// // 10 ထက်နည်းသောနံပါတ်များကိုစားသုံးပါ
    /// while iter.next_if(|&x| x < 10).is_some() {}
    /// // ပြန်ရောက်လာမယ့်တန်ဖိုးက 10 ပါလိမ့်မည်
    /// assert_eq!(iter.next(), Some(10));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if(&mut self, func: impl FnOnce(&I::Item) -> bool) -> Option<I::Item> {
        match self.next() {
            Some(matched) if func(&matched) => Some(matched),
            other => {
                // ကျနော်တို့ `self.next()` ကိုခေါ်ကတည်းကကျနော်တို့ `self.peeked` လောင်လေ၏။
                assert!(self.peeked.is_none());
                self.peeked = Some(other);
                None
            }
        }
    }

    /// က `expected` ညီမျှလျှင်နောက်တစ်နေ့ကို item လောင်ခြင်းနှင့်ပြန်သွားပါ။
    /// # Example
    /// 0 နှင့်ညီလျှင်နံပါတ်တစ်ခုကိုစားပါ။
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // အဆိုပါကြားမှာ၏ပထမဦးဆုံးကို item 0 င်ဖြစ်၏ဒါကြောင့်စားသုံးကြသည်။
    /// assert_eq!(iter.next_if_eq(&0), Some(0));
    /// // ပြန်ရောက်လာမယ့်ပစ္စည်းကိုယခု 1 ဖြစ်တယ်, ဒါ `consume` `false` ပြန်လာပါလိမ့်မယ်။
    /// assert_eq!(iter.next_if_eq(&0), None);
    /// // `next_if_eq` က `expected` ညီမျှမဟုတ်ခဲ့လျှင်နောက်တစ်နေ့ကို item ၏တန်ဖိုးကယ်တင်တော်မူ၏။
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if_eq<T>(&mut self, expected: &T) -> Option<I::Item>
    where
        T: ?Sized,
        I::Item: PartialEq<T>,
    {
        self.next_if(|next| next == expected)
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I> TrustedLen for Peekable<I> where I: TrustedLen {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S: Iterator, I: Iterator> SourceIter for Peekable<I>
where
    I: SourceIter<Source = S>,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // လုံခြုံမှု-လုံခြုံမှုမရှိသောလုပ်ဆောင်မှုသို့ထပ်မံလိုအပ်ချက်များနှင့်အတူလုံခြုံမှုမရှိသောလုပ်ဆောင်မှုသို့လွှဲပြောင်းခြင်း
        unsafe { SourceIter::as_inner(&mut self.iter) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I: InPlaceIterable> InPlaceIterable for Peekable<I> {}