use crate::iter::{FusedIterator, TrustedLen};

/// အတောမသတ်တစ်ခုတည်းဒြပ်စင်ကို repeat အသစ်တစ်ခုကြားမှာဖန်တီးပေးပါတယ်။
///
/// အဆိုပါ `repeat()` function ကိုထပ်ခါထပ်ခါတစ်ခုတည်းတန်ဖိုးကို repeat ။
///
/// `repeat()` တူသောအဆုံးမဲ့ကြားမှာမကြာခဏသူတို့ကို finite စေရန်အလို့ငှာ, [`Iterator::take()`] တူသော Adapter ကနှင့်အတူအသုံးပြုကြသည်။
///
/// သင်လိုအပ်သည့်ကြားမှာ၏ဒြပ်စင်အမျိုးအစား `Clone` အကောင်အထည်ဖော်မပါဘူးဆိုရင်, ဒါမှမဟုတ်သင်မှတ်ဉာဏ်ထဲမှာထပ်ခါတလဲလဲဒြပ်စင်ကိုစောင့်ရှောက်ရန်မလိုချင်ကြပါလျှင်, သင်အစား [`repeat_with()`] function ကိုသုံးနိုင်သည်။
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// အခြေခံအသုံးပြုမှု-
///
/// ```
/// use std::iter;
///
/// // အရေအတွက်ကလေးယောက် 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // yup ဆဲလေး
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// [`Iterator::take()`] နှင့်အတူကနျ့ Going:
///
/// ```
/// use std::iter;
///
/// // နောက်ဆုံးဥပမာများလွန်းလေးခဲ့တာ။လေးလေးသာရှိမယ်။
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... ယခုငါတို့ပြီးပြီ
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// အတောမသတ်ထားတဲ့ဒြပ်စင်ကို repeat တစ်ခုကြားမှာ။
///
/// ဤသည် `struct` အဆိုပါ [`repeat()`] function ကိုအသုံးပြုနေသူများကဖန်တီးထားသည်။ပိုပြီး၎င်း၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}