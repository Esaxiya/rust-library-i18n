use crate::iter::{FusedIterator, TrustedLen};

/// အတိအကျတစ်ချိန်က Element တစ်ခုရဲ့ဖြစ်ထွန်းတစ်ခုကြားမှာဖန်တီးပေးပါတယ်။
///
/// ဒီအလေ့ကြားမှာတခြားမျိုးတစ် [`chain()`] သို့တစ်ခုတည်းတန်ဖိုးကိုလိုက်လျောညီထွေဖြစ်အောင်အသုံးပြုသည်။
/// သင့်တွင်အရာအားလုံးနီးပါးပါသောကြားဖြတ်တစ်ခုရှိကောင်းရှိနိုင်သည်၊ သို့သော်သင်၌အထူးအမှုတစ်ခုလိုအပ်သည်။
/// ဒီတစ်ခါလည်းသင်ကြားမှာအလုပ်လုပ်သော function ကိုရှိသည်, သင်မူကားတစ်ဦးတည်းသာတန်ဖိုးကိုလုပ်ဆောင်ပေးရန်လိုအပ်ပါတယ်။
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// အခြေခံအသုံးပြုမှု-
///
/// ```
/// use std::iter;
///
/// // တ loneliest အရေအတွက်ဖြစ်ပါတယ်
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // ကိုယ့်တဦးတည်း, ငါတို့ get အားလုံးရဲ့
/// assert_eq!(None, one.next());
/// ```
///
/// အခြားကြားမှာနှင့်အတူကွင်းဆက်။
/// ကျနော်တို့က `.foo` directory ၏တစ်ဦးချင်းစီဖိုင်, ဒါပေမယ့်လည်း configuration file ကိုကျော် iterate ချင်သောစေမယ့်ပြော,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // DirEntry-s ကြားကနေ PathBufs ကြားမှာပြောင်းဖို့လိုတယ်။ ဒါကြောင့်မြေပုံကိုသုံးတယ်။
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // ယခုကျွန်ုပ်တို့ config file အတွက်ကျွန်ုပ်တို့၏ iterator ကိုလုပ်လိုက်ပါ
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // တဦးတည်းကြီးတွေကြားမှာသို့အတူတကွနှစ်ခုကြားမှာချုပ်ထား
/// let files = dirs.chain(config);
///
/// // ဒီကျွန်တော်တို့ကို .foo အတွက်ဖိုင်များကိုအားလုံးအဖြစ် .foorc ငါပေးမည်
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Element တစ်ခုကိုတစ်ကြိမ်အတိအကျပေးသောကြားမှာ။
///
/// ဤသည် `struct` အဆိုပါ [`once()`] function ကိုအသုံးပြုနေသူများကဖန်တီးထားသည်။ပိုပြီး၎င်း၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}