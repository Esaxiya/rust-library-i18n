use crate::{fmt, iter::FusedIterator};

/// ရှေ့နောက်တစ်ခုပေါ် မူတည်၍ တစ်ခုစီအားဆက်တိုက်တွက်ချက်သောကြားဖြတ်အသစ်ဖန်တီးသည်။
///
/// အဆိုပါကြားမှာပေးထားသောပထမဦးဆုံးကို item (ရှိပါက) နှင့်အတူစတင်သည်နှင့်တစ်ဦးချင်းစီကို item ကိုဆက်ခံတွက်ချက်ရန်ပေးထားသော `FnMut(&T) -> Option<T>` ပိတ်သိမ်းရန်တောင်းဆိုလိုက်သည်။
///
///
/// ```
/// use std::iter::successors;
///
/// let powers_of_10 = successors(Some(1_u16), |n| n.checked_mul(10));
/// assert_eq!(powers_of_10.collect::<Vec<_>>(), &[1, 10, 100, 1_000, 10_000]);
/// ```
#[stable(feature = "iter_successors", since = "1.34.0")]
pub fn successors<T, F>(first: Option<T>, succ: F) -> Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    // ဒီ function ကို `impl Iterator<Item=T>` ပြန်ရောက်လျှင် `unfold` အပေါ်အခြေခံပြီးနှင့်တစ်ဦးဆက်ကပ်အပ်နှံထားအမျိုးအစားမလိုအပ်နိုင်ပါတယ်။
    //
    // သို့သော်အမည်ပေးထားသော `Successors<T, F>` အမျိုးအစားတစ်ခုသည် `T` နှင့် `F` တို့ဖြစ်သည့်အခါ `Clone` ဖြစ်ရန်ခွင့်ပြုသည်။
    Successors { next: first, succ }
}

/// တစ်ဦးချင်းစီအဆက်ဆက်သည်ကို item ရှေ့တဦးတည်းအပေါ်အခြေခံပြီးတွက်ချက်သည်အဘယ်မှာရှိတစ်ဦးအသစ်များကိုကြားမှာ။
///
/// ဤ `struct` ကို [`iter::successors()`] function ဖြင့်ဖန်တီးသည်။
/// ပိုမိုသိရှိလိုပါက၎င်း၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
///
/// [`iter::successors()`]: successors
#[derive(Clone)]
#[stable(feature = "iter_successors", since = "1.34.0")]
pub struct Successors<T, F> {
    next: Option<T>,
    succ: F,
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> Iterator for Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        let item = self.next.take()?;
        self.next = (self.succ)(&item);
        Some(item)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.next.is_some() { (1, None) } else { (0, Some(0)) }
    }
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> FusedIterator for Successors<T, F> where F: FnMut(&T) -> Option<T> {}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T: fmt::Debug, F> fmt::Debug for Successors<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Successors").field("next", &self.next).finish()
    }
}