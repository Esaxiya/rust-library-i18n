use crate::fmt;

/// တစ်ဦးချင်းစီကြားမှာပေးထားသည့်ပိတ်သိမ်း `F: FnMut() -> Option<T>` ခေါ်ဆိုဘယ်မှာအသစ်တခုကြားမှာဖန်တီးပေးပါတယ်။
///
/// ဒါကဆက်ကပ်အပ်နှံ type ကိုဖန်တီးပြုလုပ်များအတွက် [`Iterator`] trait အကောင်အထည်ဖော်၏ပိုပြီး verbose syntax မသုံးဘဲမဆိုအပြုအမူနဲ့ထုံးစံကြားမှာကိုခွင့်ပြုပါတယ်။
///
/// အဆိုပါ `FromFn` ကြားမှာပိတ်ပစ်၏အပြုအမူနှင့် ပတ်သက်. ယူဆချက်လုပ်မထားဘူး, ဒါကြောင့်ရှေးရိုးစွဲ [`FusedIterator`] အကောင်အထည်ဖော်ဖို့, သို့မဟုတ်၎င်း၏ default အ `(0, None)` ထံမှ [`Iterator::size_hint()`] override တော်မမူကြောင်းမှတ်ချက်။
///
///
/// ပိတ်မှုသည်အခြေအနေကိုခြေရာခံ။ ဖမ်းယူနိုင်ခြင်းနှင့်၎င်း၏ပတ်ဝန်းကျင်ကိုသုံးနိုင်သည်။အဆိုပါကြားမှာအသုံးပြုသည်ကိုမည်သို့ပေါ် မူတည်. ဒီပိတ်သိမ်းအပေါ် [`move`] keyword ကိုသတ်မှတ်ခြင်းလိုအပ်နိုင်ပါသည်။
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// စေရဲ့ [module-level documentation] ကနေတန်ပြန်ကြားမှာပြန်လည်အကောင်အထည်ဖော်ရန်:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // ငါတို့ရေတွက်။ကျွန်တော်တို့ဟာသုညမှာစတင်အဘယ်ကြောင့်ဒီအဖြစ်ပါတယ်။
///     count += 1;
///
///     // ရေတွက်ပြီးပြီလားဆိုတာစစ်ဆေးပါ။
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// တစ်ဦးချင်းစီကြားမှာပေးထားသည့်ပိတ်သိမ်း `F: FnMut() -> Option<T>` ခေါ်ဆိုရှိရာတစ်ဦးကြားမှာ။
///
/// ဤသည် `struct` အဆိုပါ [`iter::from_fn()`] function ကိုအသုံးပြုနေသူများကဖန်တီးထားသည်။
/// ပိုမိုသိရှိလိုပါက၎င်း၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}