use crate::iter::{FusedIterator, TrustedLen};

/// ပေးထားသည့်ပိတ်သိမ်းခြင်း, repeater လျှောက်ထားခြင်းအားဖြင့်ကြောင်း type ကို `A` ၏ပြန်လုပ်ဒြပ်စင်အတောမသတ်သစ်တစ်ခုကြားမှာဖန်တီး, `F: FnMut() -> A`.
///
/// အဆိုပါ `repeat_with()` function ကိုထပ်ခါထပ်ခါပြန် repeater တောင်းဆိုထားသည်။
///
/// `repeat_with()` တူသောအဆုံးမဲ့ကြားမှာမကြာခဏသူတို့ကို finite စေရန်အလို့ငှာ, [`Iterator::take()`] တူသော Adapter ကနှင့်အတူအသုံးပြုကြသည်။
///
/// သင်လိုအပ်သောကြားမှာ၏ element type [`Clone`] ကိုသုံးပြီး၎င်းသည် source element ကို memory ထဲ၌သိမ်းထားလျှင် OK အစား [`repeat()`] function ကိုသုံးသင့်သည်။
///
///
/// `repeat_with()` မှထုတ်လုပ်သည့်ကြားဖြတ်သည် [`DoubleEndedIterator`] မဟုတ်ပါ။
/// သင်တစ်ဦး [`DoubleEndedIterator`] ပြန်သွားဖို့ `repeat_with()` လိုအပ်လာလျှင်သင်၏အသုံးပြုမှုကိစ္စတွင်ရှင်းပြတဲ့ GitHub ကိစ္စကိုဖွင့်ပါ။
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// အခြေခံအသုံးပြုမှု-
///
/// ```
/// use std::iter;
///
/// // ကျွန်တော်တို့မှာ `Clone` မဟုတ်တဲ့တန်ဖိုးတစ်ခုရှိမယ်ဒါမှမဟုတ်တန်ဖိုးကြီးတဲ့အတွက်မှတ်ဉာဏ်မသုံးချင်တော့ဘူးဆိုပါစို့။
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // အစဉ်အမြဲနေတဲ့အထူးသတန်ဖိုးကို:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// mutation အသုံးပြုခြင်းနှင့်ကနျ့မယ်:
///
/// ```rust
/// use std::iter;
///
/// // အဆိုပါ zeroth မှစ. နှစ်ခု၏တတိယအာဏာ:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... ယခုငါတို့ပြီးပြီ
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// ပေးထားသည့်ပိတ်သိမ်း `F: FnMut() -> A` လျှောက်ထားခြင်းအားဖြင့်အတောမသတ်အမျိုးအစား `A` ၏ဒြပ်စင်ကို repeat တစ်ခုကြားမှာ။
///
///
/// ဤသည် `struct` အဆိုပါ [`repeat_with()`] function ကိုအသုံးပြုနေသူများကဖန်တီးထားသည်။
/// ပိုမိုသိရှိလိုပါက၎င်း၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}