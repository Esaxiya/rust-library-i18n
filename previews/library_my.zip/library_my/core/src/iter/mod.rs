//! တေးရေးဆရာပြင်ပကြားမှာ။
//!
//! သငျသညျအခြို့သောကြင်နာတဲ့အစုအဝေးနှင့်အတူကိုယ့်ကိုယ်ကိုတှေ့ဟုစုဆောင်းမှု၏ဒြပ်စင်တခုတခုအပေါ်မှာစစ်ဆင်ရေးဖျော်ဖြေဖို့လိုအပ်ပါတယ်လျှင်သင်သည်အလျင်အမြန် 'iterators' သို့ပြေးပါလိမ့်မယ်။
//! ဒါကြောင့်ဖွင့်ရကျိုးနပ်သူတို့နှငျ့အတူအကျွမ်းတဝင်ဖြစ်လာနိုင်အောင်ကြားမှာအကြီးအကျယ်, idiomatic Rust ကုဒ်အတွက်အသုံးပြုကြသည်။
//!
//! ပိုမိုရှင်းပြခြင်းမပြုမီဤ module ကိုမည်သို့ဖွဲ့စည်းထားကြောင်းဆွေးနွေးကြပါစို့။
//!
//! # Organization
//!
//! ဒီမော်ဂျူးအကြီးအကျယ်အမျိုးအစားကစီစဉ်တာဖြစ်ပါတယ်:
//!
//! * [Traits] အဓိကအဘို့ကိုနေသောခေါင်းစဉ်: ဤအ traits ကြင်နာကြားမှာ၏တည်ရှိခြင်းနှင့်သင်သည်ထိုသူတို့နှင့်အတူအဘယျသို့ပွုနိုငျသောအရာကိုသတ်မှတ်။ဤအ traits ၏နည်းလမ်းများသို့အချို့သောအပိုလေ့လာမှုအချိန်ချပြီးတန်ဖိုးရှိဖြစ်ကြသည်။
//! * [Functions] အချို့သောအခြေခံကြားမှာဖန်တီးရန်အတွက်အထောက်အကူဖြစ်စေမည့်နည်းလမ်းများပေးပါ။
//! * [Structs] ဒီ module ရဲ့ traits ပေါ်တွင်အမျိုးမျိုးသောနည်းလမ်းများ၏ပြန်လာအမျိုးအစားများကိုမကြာခဏဖြစ်ကြသည်။သငျသညျအများအားဖြင့်အစား `struct` သူ့ဟာသူထက်, `struct` ဖန်တီးသောနည်းလမ်းမှာကြည့်ရှုချင်ပါလိမ့်မယ်။
//! '[အကောင်အထည်ဖော်ရေးကြားမှာ](#အကောင်အထည်ဖော်-ကြားမှာ)' ကိုတွေ့မြင်ဘာဖြစ်လို့အကြောင်းကိုပိုမိုအသေးစိတ်သည်။
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! ဒါပဲ!ကြားမှာသို့ရဲ့အတူးကွပါစို့။
//!
//! # Iterator
//!
//! ဒီ module ၏စိတ်နှလုံးနှင့်စိတ်ဝိညာဉ်သည် [`Iterator`] trait ဖြစ်ပါတယ်။[`Iterator`] ၏အဓိကဒီတူ:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! ကြားမှာလုပ်တဲ့သူမှာ [`next`] ဆိုတဲ့ method ရှိတယ်။ သူခေါ်လိုက်တဲ့အခါ [`Option`] ကိုပြန်ပို့တယ်<Item>`။
//! [`next`] ရှည်လျားသောဒြပ်စင်ရှိပါတယ်သကဲ့သို့ [`Some(Item)`] ပြန်လာ, ထိုသူအပေါင်းတို့သည်မောခဲ့တော့တခါ, ကြားမှာပြီးဆုံးကြောင်းညွှန်ပြရန် `None` ပြန်လာကြလိမ့်မည်။
//! တစ်ဦးချင်းကြားမှာ (ဥပမာ, [`TryIter`] ကိုကြည့်ပါ) ကြားမှာပြန်လည်စတင်ဖို့ရွေးချယ်စေခြင်းငှါ, နောက်တဖန် [`next`] တောင်းဆိုဒီတော့သို့မဟုတ်နောက်ဆုံးမှာတစ်ချိန်ချိန်နောက်တဖန် [`Some(Item)`] ပြန်စတင်ရန်မပြုစေခြင်းငှါဖြစ်နိုင်သည်။
//!
//!
//! [`Iterator`] ၏အဓိပ္ပာယ်အပြည့်အစုံတွင်အခြားနည်းလမ်းများလည်းပါ ၀ င်သော်လည်း၎င်းတို့သည်ပုံမှန်နည်းလမ်းများဖြစ်ပြီး [`next`] ၏ထိပ်တွင်တည်ဆောက်ထားသောကြောင့်၎င်းတို့ကိုအခမဲ့ရနိုင်သည်။
//!
//! ကြားမှာအပြောင်းအလဲနဲ့ပိုမိုရှုပ်ထွေးပုံစံများကိုလုပ်ဖို့အတူတူကွင်းဆက်သူတို့ကိုလည်းတေးရေးဆရာဖြစ်ကြသည်ကို၎င်း, ပြုလုပ်မယ့်ဘုံ။အသေးစိတ်ကိုအောက်က [Adapters](#adapters) အပိုင်းကိုကြည့်ပါ။
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # ကြားမှာ၏သုံးပုံစံများ
//!
//! တစ်ဦးစုဆောင်းမှုထဲမှကြားမှာဖန်တီးနိုင်သည့်သုံးဘုံနည်းလမ်းများရှိပါသည်:
//!
//! * `iter()`, အရာ `&T` ကျော်ကြားမှာ။
//! * `iter_mut()`, အရာ `&mut T` ကျော် iterates ။
//! * `into_iter()`, အရာ `T` ကျော် iterates ။
//!
//! စံစာကြည့်တိုက်အတွက်အမျိုးမျိုးသောအမှုအရာသငျ့လျြောရှိရာသုံး, တစ်ဦးသို့မဟုတ်ထိုထက်ပိုအကောင်အထည်ဖော်လိမ့်မည်။
//!
//! # အကောင်အထည်ဖော်ရေးကြားမှာ
//!
//! အဆိုပါကြားမှာရဲ့ပြည်နယ်ကိုင်ဖို့ `struct` ဖန်တီးပြီးတော့ကြောင့် `struct` များအတွက် [`Iterator`] အကောင်အထည်ဖော်: သင်၏ကိုယ်ပိုင်တစ်ခုကြားမှာ Creating နှစ်ခုခြေလှမ်းများပါဝငျသညျ။
//! ဒီ module အတွက်ဤမျှလောက်များစွာသော `struct`s ရှိပါတယ်ဘယ်ကြောင့်ဒီအသည်: တစ်ဦးချင်းစီကြားမှာနှင့်ကြားမှာကြားခံကိရိယာတစ်ခုရှိသေး၏။
//!
//! ရဲ့ `5` မှ `1` ကနေရေတွက်ထားတဲ့ `Counter` အမည်ရှိတစ်ခုကြားမှာလုပ်ပါစို့:
//!
//! ```
//! // ပထမဦးစွာ struct:
//!
//! /// တစ်ကြိမ်မှငါးခုအထိရေတွက်သည်
//! struct Counter {
//!     count: usize,
//! }
//!
//! // ငါတို့သည်ငါတို့၏ count ကတဦးတည်းမှာစတင်ချင်ဒါ၏အကူအညီကိုတစ်ဦး new() နည်းလမ်း add ကြကုန်အံ့။
//! // ဤသည်တင်းကြပ်စွာမလိုအပ်ပါဘူး, ဒါပေမယ့်အဆင်ပြေပါတယ်။
//! // မှတ်ချက်ကျွန်တော်တို့ဟာသုညမှာ `count` start, ငါတို့သည်အဘယ်ကြောင့်အောက်တွင်ဖော်ပြထားသော `next()`'s အကောင်အထည်ဖော်ရေးအတွက်တွေ့မြင်ပါလိမ့်မယ်။
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // ထို့နောက်ကျွန်ုပ်တို့ `Counter` များအတွက် `Iterator` အကောင်အထည်ဖော်ရန်:
//!
//! impl Iterator for Counter {
//!     // ကျနော်တို့ usize နှင့်အတူရေတွက်ပါလိမ့်မည်
//!     type Item = usize;
//!
//!     // next() တစ်ခုတည်းသောလိုအပ်သောနည်းလမ်းဖြစ်ပါသည်
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // ငါတို့ရေတွက်။ကျွန်တော်တို့ဟာသုညမှာစတင်အဘယ်ကြောင့်ဒီအဖြစ်ပါတယ်။
//!         self.count += 1;
//!
//!         // ရေတွက်ပြီးပြီလားဆိုတာစစ်ဆေးပါ။
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // ယခုမှာအကြှနျုပျတို့အသုံးပွုနိုငျပါသညျ!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! [`next`] Calling ဤနည်းထပ်တလဲလဲရရှိသွားတဲ့။Rust က `None` ရောက်ရှိသည်အထိ, သင့်ကြားမှာအပေါ် [`next`] မခေါ်နိုင်သည့်ဆောက်လုပ်ရေးရှိပါတယ်။ရဲ့လာမယ့်ကြောင်းကူးကြကုန်အံ့။
//!
//! `Iterator` သည် `nth` နှင့် `fold` ကဲ့သို့သောနည်းလမ်းများကိုပုံမှန်အကောင်အထည်ဖော်မှုကိုထောက်ပံ့ပေးကြောင်းသတိပြုပါ။
//! တစ်ဦးကြားမှာ `next` ခေါ်ဆိုခြင်းမရှိဘဲပိုမိုထိရောက်စွာသူတို့ကိုတွက်ချက်နိုင်လျှင်သို့ရာတွင်ထိုသို့ `nth` နှင့် `fold` တူသောနည်းလမ်းများတစ်ထုံးစံအကောင်အထည်ဖော်မှုရေးသားဖို့လည်းဖြစ်နိုင်သည်။
//!
//! # `for` ကွင်းနှင့် `IntoIterator`
//!
//! Rust ရဲ့ `for` ကွင်းဆက် syntax အမှန်တကယ်ကြားမှာအဘို့သကြားဖြစ်ပါတယ်။ဤတွင် `for` ၏အခြေခံဥပမာင်:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! ၎င်းသည်နံပါတ်များမှတစ်လုံးသို့ (၅) အထိပုံနှိပ်ထုတ်ဝေနိုင်သည်။ဒါပေမယ့်သင်ဒီမှာတစ်ခုခုသတိပြုမိပါလိမ့်မယ်: ငါတို့သည်တစ်ခုကြားမှာထုတ်လုပ်ရန်ကျွန်တော်တို့ရဲ့ vector အပေါ်ဘာမှကိုခေါ်ဘူး။အဘယ်အရာကိုပေးသနည်း။
//!
//! တစ်ဦး trait တစ်ခုကြားမှာသို့တစ်ခုခုပြောင်းလဲများအတွက်စံစာကြည့်တိုက်ထဲမှာရှိပါတယ်: [`IntoIterator`].
//! ဤ trait တွင် [`into_iter`] နည်းလမ်းတစ်ခုရှိပြီး [`IntoIterator`] ကိုအကောင်အထည်ဖော်သည့်အရာအားလုံးကိုကြားဖြတ်သို့ပြောင်းလဲပေးသည်။
//! အဲဒီ `for` loop ကိုနောက်တစ်ခေါက်ပြန်ကြည့်ရအောင်။ compiler ကအဲဒါကိုဘယ်လိုပြောင်းလဲ။
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust သို့ဤ de-sugars:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! ပထမ ဦး စွာတန်ဖိုးကို `into_iter()` ဟုခေါ်သည်။ထို့နောက် [`next`] ကို `None` ကိုမတွေ့မချင်းအကြိမ်ကြိမ်ခေါ်။ ပြန်လာသည့်ကြားမှာလိုက်ဖက်သည်။
//! ဒီအချိန်မှာတော့ကျွန်တော် `break` သည် loop ထဲကကျနော်တို့နေပြီးပြီကြားမှာ။
//!
//! ဤနေရာတွင်သိမ်မွေ့သောနည်းနည်းသာရှိသည်-စံစာကြည့်တိုက်တွင် [`IntoIterator`] ၏စိတ်ဝင်စားဖွယ်ကောင်းသောအကောင်အထည်ဖော်မှုပါရှိသည်-
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! တစ်နည်းအားဖြင့်ဆိုသော် [`Iterator`] အားလုံးသည်မိမိတို့ကိုယ်ကိုပြန်လာရုံဖြင့် [`IntoIterator`] ကိုအကောင်အထည်ဖော်ကြသည်။ဆိုလိုသည်မှာအချက်နှစ်ချက်ကိုဆိုလိုသည်။
//!
//! 1. သင်တစ်ဦး [`Iterator`] ရေးသားခြင်းနေလျှင်, သင်တစ်ဦး `for` ကွင်းဆက်နှင့်အတူကကိုသုံးနိုင်သည်။
//! 2. သင်စုဆောင်းမှုတစ်ခုပြုလုပ်နေပါက၎င်းအတွက် [`IntoIterator`] ကိုအသုံးပြုခြင်းသည်သင်၏စုဆောင်းမှုကို `for` ကွင်းဆက်ဖြင့်အသုံးပြုရန်ခွင့်ပြုလိမ့်မည်။
//!
//! # ရည်ညွှန်းခြင်းဖြင့်ကြားဖြတ်
//!
//! [`into_iter()`] ကတည်းကတစ်ဦးစုဆောင်းမှု Consumer ကြောင်းစုဆောင်းခြင်းကျော် iterate တစ် `for` ကွင်းဆက်သုံးပြီးတန်ဖိုး `self` ကြာပါသည်။မကြာခဏ, သင်ကစားသုံးခြင်းမရှိဘဲတစ်ဦးစုဆောင်းမှုကျော် iterate ချင်ပေမည်။
//! အတော်များများသော collection များသည်ပုံမှန်အားဖြင့် `iter()` နှင့် `iter_mut()` ဟုခေါ်သောအကိုးအကားများဖြင့်ကြားဖြတ်များပေးသောနည်းလမ်းများကိုပေးသည်။
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` ဒီ function ကိုကပိုင်ဆိုင်သည်။
//! ```
//!
//! `C` အမျိုးအစားစုဆောင်းမှုတစ်ခုသည် `iter()` ကိုထောက်ပံ့ပါက `&C` အတွက် `IntoIterator` ကိုအသုံးပြုလေ့ရှိပြီး `iter()` ဟုခေါ်သောအကောင်အထည်ဖော်မှုတစ်ခုလည်းရှိသည်။
//! အလားတူပင် `iter_mut()` ကိုထောက်ပံ့ပေးမယ့်အစုအဝေး `C` ယေဘုယျအား `iter_mut()` မှလွှဲအပ်ခြင်းဖြင့် `&mut C` များအတွက် `IntoIterator` အကောင်အထည်ဖော်ဆောင်ရွက်နေသော။ဒါကအဆင်ပြေအတိုကောက်ဖွ:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // `values.iter_mut()` အဖြစ်အတူတူပင်
//!     *x += 1;
//! }
//! for x in &values { // `values.iter()` အဖြစ်အတူတူပင်
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! အများအပြား collection များကို `iter()` ပူဇော်နေစဉ်, အားလုံး `iter_mut()` ပူဇော်မဟုတ်ပါဘူး။
//! ဥပမာ, [`HashSet<T>`] သို့မဟုတ် [`HashMap<K, V>`] ၏သော့မျိုးရိုးဗီဇပြောင်းလဲပုံသော့ချက် hash တွေကိုပြောင်းလဲမှုလျှင်တစ်ဦးကိုက်ညီမှုပြည်နယ်သို့စုဆောင်းခြင်းထား, ဒါကြောင့်ထိုအ collection များကိုသာ `iter()` ပူဇော်နိုင်ပါတယ်။
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! [`Iterator`] ကိုယူပြီးအခြား [`Iterator`] ကိုပြန်ပေးသည့်လုပ်ဆောင်ချက်များကို 'iterator adapters' ဟုခေါ်ကြပြီး၎င်းသည် 'adapter' ပုံစံတစ်ခုဖြစ်သည်။
//! pattern'.
//!
//! ဘုံကြားမှာ Adapter က [`map`], [`take`] နှင့် [`filter`] ပါဝင်သည်။
//! ပိုမိုသိရှိလိုပါက၎င်းတို့၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
//!
//! panics adapter တစ်ခုကြားမှာလျှင်, ကြားမှာတစ်ခုသတ်မှတ် (သို့သော်မှတ်ဉာဏ်အန္တရာယ်ကင်း) ပြည်နယ်ရှိလိမ့်မည်။
//! သငျသညျအရမ်းထိတ်လန့သည့်ကြားမှာအားဖြင့်ပြန်လာသောအတိအကျတန်ဖိုးများကိုမှီခိုကိုရှောင်ရှားသင့်ပါတယ်ဒါကြောင့်ဒါဟာပြည်နယ်ကိုလည်း Rust ဗားရှင်းကိုဖြတ်ပြီးအတူတူနေဖို့အာမခံချက်မပေးပါ။
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iterators (နှင့် iterator [adapters](#adapters)) * သည်ပျင်းရိသည်။ ဆိုလိုသည်မှာ iterator ကိုဖန်တီးရုံသာ _do_ တစ်ခုလုံးကိုမဖြစ်စေနိုင်ပါ။ [`next`] ကိုသင်မခေါ်မချင်းဘာမှမဖြစ်နိုင်။
//! တစ်ခုတည်းကိုသာ၎င်း၏ဘေးထွက်ဆိုးကျိုးတစ်ခုကြားမှာဖန်တီးသောအခါဤသည်တစ်ခါတစ်ရံတွင်ရှုပ်ထွေးနေတဲ့အရင်းအမြစ်ဖြစ်ပါတယ်။
//! ဥပမာ, [`map`] နည်းလမ်းကကျော် iterates တစ်ဦးချင်းစီဒြပ်စင်အပေါ်တစ်ဦးပိတ်သိမ်းခေါ်ဆို:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! သာတစ်ဦးကြားမှာ created အဖြစ်ဤသည်မဟုတ်ဘဲအသုံးပြုထက်, မည်သည့်တန်ဖိုးများကို print ထုတ်လိမ့်မည်မဟုတ်ပါ။အဆိုပါ compiler အပြုအမူဒီလိုမျိုးအကြောင်းကျွန်တော်တို့ကိုသတိပေးပါလိမ့်မယ်:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! ၎င်း၏ဘေးထွက်ဆိုးကျိုးတစ်ခု [`map`] ရေးသားဖို့အဆိုပါ idiomatic လမ်းတစ် `for` ကွင်းဆက်ကိုအသုံးပြုဖို့ပါသို့မဟုတ် [`for_each`] နည်းလမ်းကိုခေါ်ခြင်းဖြစ်ပါသည်:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! တစ်ခုကြားမှာအကဲဖြတ်ဖို့နောက်ထပ်ဘုံလမ်းအသစ်တခုစုစည်းထုတ်လုပ်နိုင်ရန် [`collect`] နည်းလမ်းကိုသုံးစွဲဖို့ဖြစ်ပါတယ်။
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! ကြားဖြတ်အကန့်အသတ်ရှိစရာမလိုပါ။ဥပမာတစ်ခုအဖြစ်တစ်ဦးဖွင့်အကွာအဝေးတစ်ခုအဆုံးမဲ့ကြားမှာဖြစ်ပါသည်:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! ဒါဟာကနျ့တစျခုသို့တစ်ခုအဆုံးမဲ့ကြားမှာဖွင့်ဖို့ [`take`] ကြားမှာကြားခံကိရိယာကိုအသုံးပြုရန်ဘုံဖြစ်ပါသည်:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! ဤ `4` မှတဆင့်၎င်းတို့၏ကိုယ်ပိုင်လိုင်းပေါ်တစ်ဦးချင်းစီနံပါတ်များ `0` print ထုတ်ပါလိမ့်မယ်။
//!
//! စိတျထဲမှာဝက်ဝံရလဒ်ကနျ့အခြိနျမှာသင်္ချာဆုံးဖြတ်သည်နိုင်ပါသည်ပင်သူတို့အားပေးသောအဘို့အအဆုံးမဲ့ကြားမှာပေါ်နည်းလမ်းများသောအဆုံးသတ်ခြင်းမည်မဟုတ်ပါ။
//! အထူးသဖြင့်ယေဘူယျအားဖြင့်ကြားဖြတ်ရှိဒြပ်စင်တိုင်းကိုဖြတ်ကျော်ရန်လိုသည့် [`min`] ကဲ့သို့သောနည်းလမ်းများသည်အဆုံးမဲ့ကြားဖြတ်များအတွက်အောင်မြင်စွာပြန်သွားနိုင်ဖွယ်မရှိချေ။
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // မဟုတ်ပါ။အဆုံးမဲ့ကွင်းဆက်!
//! // `ones.min()` တစ်ဦးအဆုံးမဲ့ loop ကိုဖြစ်ပေါ်စေသည်, ဒါကြောင့်ကျနော်တို့ကဒီအချက်မရောက်ရှိမည်!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;