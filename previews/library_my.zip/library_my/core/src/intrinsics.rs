//! compiler အခ်ါ။
//!
//! သက်ဆိုင်ရာအဓိပ္ပာယ် `compiler/rustc_codegen_llvm/src/intrinsic.rs` ၌ရှိကြ၏။
//! သက်ဆိုင်ရာ const Implementation ကို `compiler/rustc_mir/src/interpret/intrinsics.rs` ၌ရှိကြ၏
//!
//! # Const အခ်ါ
//!
//! Note: အခ်ါဒ constness မှမဆိုအပြောင်းအလဲများဘာသာစကားကိုအသင်းနှင့်ဆွေးနွေးရပါမည်။
//! ဒါက constness ၏တည်ငြိမ်မှုပြောင်းလဲမှုများပါဝင်သည်။
//!
//! compile-time တွင်အခ်ါအသုံးဝင်သောအရာတစ်ခုဖြစ်ရန်အတွက် <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> မှ `compiler/rustc_mir/src/interpret/intrinsics.rs` သို့ implement ကိုကူးယူပြီး `#[rustc_const_unstable(feature = "foo", issue = "01234")]` ကို intrinsic သို့ပေါင်းထည့်ရန်လိုအပ်သည်။
//!
//!
//! အကယ်၍ အခ်ါတစ်ခုကို `const fn` မှ `rustc_const_stable` attribute တစ်ခုဖြင့်အသုံးပြုမည်ဆိုပါက၎င်းအတွင်းခံ၏ attribute သည် `rustc_const_stable` လည်းဖြစ်ရမည်။
//! က compiler ကထောက်ခံမှုမရှိဘဲအသုံးပြုသူကုဒ်ပုံတူမဖြစ်တော့ဘူးမရနိုငျသောဘာသာစကားသို့အင်္ဂါရပ် bakes ဘာဖြစ်လို့လဲဆိုတော့ထိုသို့သောပြောင်းလဲမှုကို T-lang တိုင်ပင်ခြင်းမရှိဘဲပြုသောအမှုမဖြစ်သင့်။
//!
//! # Volatiles
//!
//! မတည်ငြိမ်သောအခ်ါစစ်ဆင်ရေးသည်အခြားမတည်ငြိမ်သောအခ်ါဖြတ်ပြီး compiler များက reordered မရရန်အာမခံချက်ထားတဲ့ I/O မှတ်ဉာဏ်အပေါ်ပြုမူရန်ရည်ရွယ်သည်။[[volatile]] ရှိ LLVM စာရွက်စာတမ်းများကိုကြည့်ပါ။
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! အဆိုပါအနုမြူဗုံးအခ်ါမျိုးစုံဖြစ်နိုင်သမျှမှတ်ဉာဏ် Order အတူစက်စကားလုံးများအပေါ်ဘုံအနုမြူဗုံးစစ်ဆင်ရေးသည်။သူတို့ဟာ C++ 11 ကဲ့သို့တူညီသော semantic စကားကိုနားထောင်ကြလော့။[[atomics]] ရှိ LLVM စာရွက်စာတမ်းများကိုကြည့်ပါ။
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! မှတ်ဉာဏ်မှာကြားမှုကိုမြန်ဆန်စွာမွမ်းမံခြင်း-
//!
//! * ရယူတစ်သော့ခတ်လေးလည်းများအတွက်အတားအဆီး။နောက်ဆက်တွဲဖတ်နှင့်အတားအဆီးပြီးနောက်ရာအရပ်ကိုယူရေးသားခဲ့သည်။
//! * လွှတ်ပါသော့ခတ်လွှတ်ပေးရန်အတားအဆီး။စာမရေးမီကြိုတင်ဖတ်ရှုခြင်းနှင့်ရေးသားခြင်းသည်အတားအဆီးမတိုင်မီဖြစ်ပျက်သည်။
//! * အဆက်မပြတ်တသမတ်တည်း, တဆင့်တသမတ်တည်းတသမတ်တည်းစစ်ဆင်ရေးနိုင်ရန်အတွက်ဖြစ်ပျက်မှအာမခံပါသည်။ဤသည်အနုမြူဗုံးအမျိုးအစားများကိုအတူလုပ်ကိုင်များအတွက်စံ mode ကိုသည်နှင့် Java ရဲ့ `volatile` မှညီမျှသည်။
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// ဤရွေ့ကားတင်သွင်းမှုအချင်းချင်းအပြန်အလှန် doc လင့်များ simplifying များအတွက်အသုံးပြုကြသည်
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // လုံခြုံမှု: `ptr::drop_in_place` တွေ့မြင်
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // သူတို့ `&` သို့မဟုတ် `&mut` ဖြစ်စေဘို့တရားဝင်မဟုတ်သောအရာအခြားအမည်ပေးထားသောမှတ်ဉာဏ်, ဗီဇပြောင်းစေနိုင်ပြီးဘာဖြစ်လို့လဲဆိုတော့ NB ဤအခ်ါကုန်ကြမ်းထောက်ပြယူပါ။
    //

    /// လက်ရှိတန်ဖိုး `old` တန်ဖိုးကိုအဖြစ်အတူတူပင်ဖြစ်ပါသည်လျှင်တန်ဖိုးသိုလှောင်ပါသည်။
    ///
    /// ဒီအချိုးကျတည်ငြိမ်တဲ့ဗားရှင်းကို [`atomic`] အမျိုးအစားများမှာ `compare_exchange` method ကနေတစ်ဆင့် `success` နဲ့ `failure` parameters တွေကိုနှစ် ဦး စလုံးအနေဖြင့်ရရှိနိုင်ပါသည်။
    ///
    /// ဥပမာ, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// လက်ရှိတန်ဖိုး `old` တန်ဖိုးကိုအဖြစ်အတူတူပင်ဖြစ်ပါသည်လျှင်တန်ဖိုးသိုလှောင်ပါသည်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `success` နှင့် `failure` parameters တွေကိုနှစ်ဦးစလုံးအဖြစ် [`Ordering::Acquire`] ဖြတ်သန်းနေဖြင့် `compare_exchange` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    ///
    /// ဥပမာ, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// လက်ရှိတန်ဖိုး `old` တန်ဖိုးကိုအဖြစ်အတူတူပင်ဖြစ်ပါသည်လျှင်တန်ဖိုးသိုလှောင်ပါသည်။
    ///
    /// ဒီအချိုးကျတည်ငြိမ်တဲ့ဗားရှင်းကို [`atomic`] အမျိုးအစားများမှာ `compare_exchange` method ကနေတစ်ဆင့် [`Ordering::Release`] အဖြစ် `success` အဖြစ်နဲ့ [`Ordering::Relaxed`] parameters တွေကို `failure` parameters အဖြစ်ဖြတ်သန်းသွားသည်။
    /// ဥပမာ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// လက်ရှိတန်ဖိုး `old` တန်ဖိုးကိုအဖြစ်အတူတူပင်ဖြစ်ပါသည်လျှင်တန်ဖိုးသိုလှောင်ပါသည်။
    ///
    /// ဒီအချိုးကျတည်ငြိမ်တဲ့ဗားရှင်းကို [`atomic`] အမျိုးအစားများမှာ `compare_exchange` method ကနေတစ်ဆင့် [`Ordering::AcqRel`] အဖြစ် `success` အဖြစ်နဲ့ [`Ordering::Acquire`] parameters တွေကို `failure` parameters အဖြစ်ဖြတ်သန်းသွားသည်။
    /// ဥပမာ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// လက်ရှိတန်ဖိုး `old` တန်ဖိုးကိုအဖြစ်အတူတူပင်ဖြစ်ပါသည်လျှင်တန်ဖိုးသိုလှောင်ပါသည်။
    ///
    /// ဒီအချိုးကျတည်ငြိမ်တဲ့ဗားရှင်းကို [`atomic`] အမျိုးအစားများမှာ `compare_exchange` method ကနေတစ်ဆင့် `success` နဲ့ `failure` parameters တွေကိုနှစ် ဦး စလုံးအနေဖြင့်ရရှိနိုင်ပါသည်။
    ///
    /// ဥပမာ, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// လက်ရှိတန်ဖိုး `old` တန်ဖိုးကိုအဖြစ်အတူတူပင်ဖြစ်ပါသည်လျှင်တန်ဖိုးသိုလှောင်ပါသည်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `failure` parameters များကိုအဖြစ် `success` နှင့် [`Ordering::Relaxed`] အဖြစ် [`Ordering::SeqCst`] ဖြတ်သန်းနေဖြင့် `compare_exchange` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// လက်ရှိတန်ဖိုး `old` တန်ဖိုးကိုအဖြစ်အတူတူပင်ဖြစ်ပါသည်လျှင်တန်ဖိုးသိုလှောင်ပါသည်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `failure` parameters များကိုအဖြစ် `success` နှင့် [`Ordering::Acquire`] အဖြစ် [`Ordering::SeqCst`] ဖြတ်သန်းနေဖြင့် `compare_exchange` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// လက်ရှိတန်ဖိုး `old` တန်ဖိုးကိုအဖြစ်အတူတူပင်ဖြစ်ပါသည်လျှင်တန်ဖိုးသိုလှောင်ပါသည်။
    ///
    /// ဒီအချိုးကျတည်ငြိမ်တဲ့ဗားရှင်းကို [`atomic`] အမျိုးအစားများမှာ `compare_exchange` method ကနေတစ်ဆင့် [`Ordering::Acquire`] အဖြစ် `success` အဖြစ်နဲ့ [`Ordering::Relaxed`] parameters တွေကို `failure` parameters အဖြစ်ဖြတ်သန်းသွားသည်။
    /// ဥပမာ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// လက်ရှိတန်ဖိုး `old` တန်ဖိုးကိုအဖြစ်အတူတူပင်ဖြစ်ပါသည်လျှင်တန်ဖိုးသိုလှောင်ပါသည်။
    ///
    /// ဒီအချိုးကျတည်ငြိမ်တဲ့ဗားရှင်းကို [`atomic`] အမျိုးအစားများမှာ `compare_exchange` method ကနေတစ်ဆင့် [`Ordering::AcqRel`] အဖြစ် `success` အဖြစ်နဲ့ [`Ordering::Relaxed`] parameters တွေကို `failure` parameters အဖြစ်ဖြတ်သန်းသွားသည်။
    /// ဥပမာ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// လက်ရှိတန်ဖိုး `old` တန်ဖိုးကိုအဖြစ်အတူတူပင်ဖြစ်ပါသည်လျှင်တန်ဖိုးသိုလှောင်ပါသည်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `success` နှင့် `failure` parameters တွေကိုနှစ်ဦးစလုံးအဖြစ် [`Ordering::SeqCst`] ဖြတ်သန်းနေဖြင့် `compare_exchange_weak` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    ///
    /// ဥပမာ, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// လက်ရှိတန်ဖိုး `old` တန်ဖိုးကိုအဖြစ်အတူတူပင်ဖြစ်ပါသည်လျှင်တန်ဖိုးသိုလှောင်ပါသည်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `success` နှင့် `failure` parameters တွေကိုနှစ်ဦးစလုံးအဖြစ် [`Ordering::Acquire`] ဖြတ်သန်းနေဖြင့် `compare_exchange_weak` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    ///
    /// ဥပမာ, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// လက်ရှိတန်ဖိုး `old` တန်ဖိုးကိုအဖြစ်အတူတူပင်ဖြစ်ပါသည်လျှင်တန်ဖိုးသိုလှောင်ပါသည်။
    ///
    /// ဒီအချိုးကျတည်ငြိမ်တဲ့ဗားရှင်းကို [`atomic`] အမျိုးအစားများမှာ `compare_exchange_weak` method ကနေတစ်ဆင့် [`Ordering::Release`] အဖြစ် `success` အဖြစ်နဲ့ [`Ordering::Relaxed`] parameters တွေကို `failure` parameters အဖြစ်ဖြတ်သန်းသွားသည်။
    /// ဥပမာ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// လက်ရှိတန်ဖိုး `old` တန်ဖိုးကိုအဖြစ်အတူတူပင်ဖြစ်ပါသည်လျှင်တန်ဖိုးသိုလှောင်ပါသည်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `failure` parameters များကိုအဖြစ် `success` နှင့် [`Ordering::Acquire`] အဖြစ် [`Ordering::AcqRel`] ဖြတ်သန်းနေဖြင့် `compare_exchange_weak` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// လက်ရှိတန်ဖိုး `old` တန်ဖိုးကိုအဖြစ်အတူတူပင်ဖြစ်ပါသည်လျှင်တန်ဖိုးသိုလှောင်ပါသည်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `success` နှင့် `failure` parameters တွေကိုနှစ်ဦးစလုံးအဖြစ် [`Ordering::Relaxed`] ဖြတ်သန်းနေဖြင့် `compare_exchange_weak` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    ///
    /// ဥပမာ, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// လက်ရှိတန်ဖိုး `old` တန်ဖိုးကိုအဖြစ်အတူတူပင်ဖြစ်ပါသည်လျှင်တန်ဖိုးသိုလှောင်ပါသည်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `failure` parameters များကိုအဖြစ် `success` နှင့် [`Ordering::Relaxed`] အဖြစ် [`Ordering::SeqCst`] ဖြတ်သန်းနေဖြင့် `compare_exchange_weak` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// လက်ရှိတန်ဖိုး `old` တန်ဖိုးကိုအဖြစ်အတူတူပင်ဖြစ်ပါသည်လျှင်တန်ဖိုးသိုလှောင်ပါသည်။
    ///
    /// ဒီအချိုးကျတည်ငြိမ်တဲ့ဗားရှင်းကို [`atomic`] အမျိုးအစားများမှာ `compare_exchange_weak` method ကနေတစ်ဆင့် [`Ordering::SeqCst`] အဖြစ် `success` အဖြစ်နဲ့ [`Ordering::Acquire`] parameters တွေကို `failure` parameters အဖြစ်ဖြတ်သန်းသွားသည်။
    /// ဥပမာ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// လက်ရှိတန်ဖိုး `old` တန်ဖိုးကိုအဖြစ်အတူတူပင်ဖြစ်ပါသည်လျှင်တန်ဖိုးသိုလှောင်ပါသည်။
    ///
    /// ဒီအချိုးကျတည်ငြိမ်တဲ့ဗားရှင်းကို [`atomic`] အမျိုးအစားများမှာ `compare_exchange_weak` method ကနေတစ်ဆင့် [`Ordering::Acquire`] အဖြစ် `success` အဖြစ်နဲ့ [`Ordering::Relaxed`] parameters တွေကို `failure` parameters အဖြစ်ဖြတ်သန်းသွားသည်။
    /// ဥပမာ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// လက်ရှိတန်ဖိုး `old` တန်ဖိုးကိုအဖြစ်အတူတူပင်ဖြစ်ပါသည်လျှင်တန်ဖိုးသိုလှောင်ပါသည်။
    ///
    /// ဒီအချိုးကျတည်ငြိမ်တဲ့ဗားရှင်းကို [`atomic`] အမျိုးအစားများမှာ `compare_exchange_weak` method ကနေတစ်ဆင့် [`Ordering::AcqRel`] အဖြစ် `success` အဖြစ်နဲ့ [`Ordering::Relaxed`] parameters တွေကို `failure` parameters အဖြစ်ဖြတ်သန်းသွားသည်။
    /// ဥပမာ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// အဆိုပါ pointer ၏လက်ရှိတန်ဖိုးကတင်ပေးပါတယ်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::SeqCst`] ဖြတ်သန်းနေဖြင့် `load` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// အဆိုပါ pointer ၏လက်ရှိတန်ဖိုးကတင်ပေးပါတယ်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::Acquire`] ဖြတ်သန်းနေဖြင့် `load` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// အဆိုပါ pointer ၏လက်ရှိတန်ဖိုးကတင်ပေးပါတယ်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::Relaxed`] ဖြတ်သန်းနေဖြင့် `load` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// သတ်မှတ်ထားသောမှတ်ဉာဏ်တည်နေရာမှာတန်ဖိုးကိုသိုလှောင်ပါသည်။
    ///
    /// တည်ငြိမ်သောဤမူရင်းဗားရှင်းကို [`atomic`] အမျိုးအစားများတွင် `store` နည်းလမ်းမှတဆင့် [`Ordering::SeqCst`] ကို `order` အဖြစ်ဖြတ်သန်းနိုင်သည်။
    /// ဥပမာ, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// သတ်မှတ်ထားသောမှတ်ဉာဏ်တည်နေရာမှာတန်ဖိုးကိုသိုလှောင်ပါသည်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::Release`] ဖြတ်သန်းနေဖြင့် `store` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// သတ်မှတ်ထားသောမှတ်ဉာဏ်တည်နေရာမှာတန်ဖိုးကိုသိုလှောင်ပါသည်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::Relaxed`] ဖြတ်သန်းနေဖြင့် `store` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// အဟောင်းကိုတန်ဖိုးကိုပြန်, သတ်မှတ်ထားသောမှတ်ဉာဏ်တည်နေရာမှာတန်ဖိုးကိုသိုလှောင်ပါသည်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::SeqCst`] ဖြတ်သန်းနေဖြင့် `swap` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// အဟောင်းကိုတန်ဖိုးကိုပြန်, သတ်မှတ်ထားသောမှတ်ဉာဏ်တည်နေရာမှာတန်ဖိုးကိုသိုလှောင်ပါသည်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::Acquire`] ဖြတ်သန်းနေဖြင့် `swap` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// အဟောင်းကိုတန်ဖိုးကိုပြန်, သတ်မှတ်ထားသောမှတ်ဉာဏ်တည်နေရာမှာတန်ဖိုးကိုသိုလှောင်ပါသည်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::Release`] ဖြတ်သန်းနေဖြင့် `swap` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// အဟောင်းကိုတန်ဖိုးကိုပြန်, သတ်မှတ်ထားသောမှတ်ဉာဏ်တည်နေရာမှာတန်ဖိုးကိုသိုလှောင်ပါသည်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::AcqRel`] ဖြတ်သန်းနေဖြင့် `swap` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// အဟောင်းကိုတန်ဖိုးကိုပြန်, သတ်မှတ်ထားသောမှတ်ဉာဏ်တည်နေရာမှာတန်ဖိုးကိုသိုလှောင်ပါသည်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::Relaxed`] ဖြတ်သန်းနေဖြင့် `swap` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ယခင်တန်ဖိုးကိုပြန်, လက်ရှိတန်ဖိုးကထပ်ပြောသည်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::SeqCst`] ဖြတ်သန်းနေဖြင့် `fetch_add` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// ယခင်တန်ဖိုးကိုပြန်, လက်ရှိတန်ဖိုးကထပ်ပြောသည်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::Acquire`] ဖြတ်သန်းနေဖြင့် `fetch_add` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ယခင်တန်ဖိုးကိုပြန်, လက်ရှိတန်ဖိုးကထပ်ပြောသည်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::Release`] ဖြတ်သန်းနေဖြင့် `fetch_add` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ယခင်တန်ဖိုးကိုပြန်, လက်ရှိတန်ဖိုးကထပ်ပြောသည်။
    ///
    /// တည်ငြိမ်သောဤမူရင်းဗားရှင်းကို [`atomic`] အမျိုးအစားများတွင် `fetch_add` နည်းလမ်းမှတဆင့် [`Ordering::AcqRel`] ကို `order` အဖြစ်ဖြတ်သန်းနိုင်သည်။
    /// ဥပမာ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ယခင်တန်ဖိုးကိုပြန်, လက်ရှိတန်ဖိုးကထပ်ပြောသည်။
    ///
    /// ဒီအချိုးကျတည်ငြိမ်တဲ့ဗားရှင်းကို [`atomic`] အမျိုးအစားများမှာ `fetch_add` method ကနေတစ်ဆင့် X0 [`Ordering::Relaxed`] ကို `order` အဖြစ်ဖြတ်သန်းနိုင်ပါတယ်။
    /// ဥပမာ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ယခင်တန်ဖိုးကိုပြန်, လက်ရှိတန်ဖိုးကိုထံမှနုတ်။
    ///
    /// တည်ငြိမ်သောဤမူရင်းဗားရှင်းကို [`atomic`] အမျိုးအစားများတွင် `fetch_sub` နည်းလမ်းမှတဆင့် [`Ordering::SeqCst`] ကို `order` အဖြစ်ဖြတ်သန်းနိုင်သည်။
    /// ဥပမာ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// ယခင်တန်ဖိုးကိုပြန်, လက်ရှိတန်ဖိုးကိုထံမှနုတ်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::Acquire`] ဖြတ်သန်းနေဖြင့် `fetch_sub` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ယခင်တန်ဖိုးကိုပြန်, လက်ရှိတန်ဖိုးကိုထံမှနုတ်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::Release`] ဖြတ်သန်းနေဖြင့် `fetch_sub` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ယခင်တန်ဖိုးကိုပြန်, လက်ရှိတန်ဖိုးကိုထံမှနုတ်။
    ///
    /// တည်ငြိမ်သောဤမူရင်းဗားရှင်းကို [`atomic`] အမျိုးအစားများတွင် `fetch_sub` နည်းလမ်းမှတဆင့် [`Ordering::AcqRel`] ကို `order` အဖြစ်ဖြတ်သန်းနိုင်သည်။
    /// ဥပမာ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ယခင်တန်ဖိုးကိုပြန်, လက်ရှိတန်ဖိုးကိုထံမှနုတ်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::Relaxed`] ဖြတ်သန်းနေဖြင့် `fetch_sub` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise နှင့်လက်ရှိတန်ဖိုးကိုအတူယခင်တန်ဖိုးကိုပြန်။
    ///
    /// တည်ငြိမ်သောဤမူရင်းဗားရှင်းကို [`atomic`] အမျိုးအစားများတွင် `fetch_and` နည်းလမ်းမှတဆင့် [`Ordering::SeqCst`] ကို `order` အဖြစ်ဖြတ်သန်းနိုင်သည်။
    /// ဥပမာ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise နှင့်လက်ရှိတန်ဖိုးကိုအတူယခင်တန်ဖိုးကိုပြန်။
    ///
    /// တည်ငြိမ်သောဤမူရင်းဗားရှင်းကို [`atomic`] အမျိုးအစားများတွင် `fetch_and` နည်းလမ်းမှတဆင့် [`Ordering::Acquire`] ကို `order` အဖြစ်ဖြတ်သန်းနိုင်သည်။
    /// ဥပမာ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise နှင့်လက်ရှိတန်ဖိုးကိုအတူယခင်တန်ဖိုးကိုပြန်။
    ///
    /// တည်ငြိမ်သောဤမူရင်းဗားရှင်းကို [`atomic`] အမျိုးအစားများတွင် `fetch_and` နည်းလမ်းမှတဆင့် [`Ordering::Release`] ကို `order` အဖြစ်ဖြတ်သန်းနိုင်သည်။
    /// ဥပမာ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise နှင့်လက်ရှိတန်ဖိုးကိုအတူယခင်တန်ဖိုးကိုပြန်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::AcqRel`] ဖြတ်သန်းနေဖြင့် `fetch_and` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise နှင့်လက်ရှိတန်ဖိုးကိုအတူယခင်တန်ဖိုးကိုပြန်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::Relaxed`] ဖြတ်သန်းနေဖြင့် `fetch_and` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// လက်ရှိတန်ဖိုး Bitwise Nande, ယခင်တန်ဖိုးကိုပြန်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::SeqCst`] ဖြတ်သန်းနေဖြင့် `fetch_nand` နည်းလမ်းမှတဆင့် [`AtomicBool`] အမျိုးအစားပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// လက်ရှိတန်ဖိုး Bitwise Nande, ယခင်တန်ဖိုးကိုပြန်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::Acquire`] ဖြတ်သန်းနေဖြင့် `fetch_nand` နည်းလမ်းမှတဆင့် [`AtomicBool`] အမျိုးအစားပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// လက်ရှိတန်ဖိုး Bitwise Nande, ယခင်တန်ဖိုးကိုပြန်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::Release`] ဖြတ်သန်းနေဖြင့် `fetch_nand` နည်းလမ်းမှတဆင့် [`AtomicBool`] အမျိုးအစားပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// လက်ရှိတန်ဖိုး Bitwise Nande, ယခင်တန်ဖိုးကိုပြန်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::AcqRel`] ဖြတ်သန်းနေဖြင့် `fetch_nand` နည်းလမ်းမှတဆင့် [`AtomicBool`] အမျိုးအစားပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// လက်ရှိတန်ဖိုး Bitwise Nande, ယခင်တန်ဖိုးကိုပြန်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::Relaxed`] ဖြတ်သန်းနေဖြင့် `fetch_nand` နည်းလမ်းမှတဆင့် [`AtomicBool`] အမျိုးအစားပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise သို့မဟုတ်လက်ရှိတန်ဖိုးကိုအတူယခင်တန်ဖိုးကိုပြန်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::SeqCst`] ဖြတ်သန်းနေဖြင့် `fetch_or` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise သို့မဟုတ်လက်ရှိတန်ဖိုးကိုအတူယခင်တန်ဖိုးကိုပြန်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::Acquire`] ဖြတ်သန်းနေဖြင့် `fetch_or` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise သို့မဟုတ်လက်ရှိတန်ဖိုးကိုအတူယခင်တန်ဖိုးကိုပြန်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::Release`] ဖြတ်သန်းနေဖြင့် `fetch_or` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise သို့မဟုတ်လက်ရှိတန်ဖိုးကိုအတူယခင်တန်ဖိုးကိုပြန်။
    ///
    /// ဒီအချိုးကျတည်ငြိမ်တဲ့ဗားရှင်းကို [`atomic`] အမျိုးအစားများမှာ `fetch_or` method ကနေတစ်ဆင့် X0 [`Ordering::AcqRel`] ကို `order` အဖြစ်ဖြတ်သန်းနိုင်ပါတယ်။
    /// ဥပမာ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise သို့မဟုတ်လက်ရှိတန်ဖိုးကိုအတူယခင်တန်ဖိုးကိုပြန်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::Relaxed`] ဖြတ်သန်းနေဖြင့် `fetch_or` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// လက်ရှိတန်ဖိုး Bitwise xor, ယခင်တန်ဖိုးကိုပြန်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::SeqCst`] ဖြတ်သန်းနေဖြင့် `fetch_xor` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// လက်ရှိတန်ဖိုး Bitwise xor, ယခင်တန်ဖိုးကိုပြန်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::Acquire`] ဖြတ်သန်းနေဖြင့် `fetch_xor` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// လက်ရှိတန်ဖိုး Bitwise xor, ယခင်တန်ဖိုးကိုပြန်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::Release`] ဖြတ်သန်းနေဖြင့် `fetch_xor` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// လက်ရှိတန်ဖိုး Bitwise xor, ယခင်တန်ဖိုးကိုပြန်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::AcqRel`] ဖြတ်သန်းနေဖြင့် `fetch_xor` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// လက်ရှိတန်ဖိုး Bitwise xor, ယခင်တန်ဖိုးကိုပြန်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::Relaxed`] ဖြတ်သန်းနေဖြင့် `fetch_xor` နည်းလမ်းမှတဆင့် [`atomic`] အမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// တစ်ဦးလက်မှတ်ရေးထိုးနှိုင်းယှဉ် အသုံးပြု. လက်ရှိတန်ဖိုးအများဆုံး။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::SeqCst`] ဖြတ်သန်းနေဖြင့် `fetch_max` နည်းလမ်းတစ်ခုမှတဆင့် integer ဖြစ်တဲ့အတွက်အမျိုးအစားများကိုလက်မှတ်ရေးထိုးခဲ့သည့် [`atomic`] အပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// တစ်ဦးလက်မှတ်ရေးထိုးနှိုင်းယှဉ် အသုံးပြု. လက်ရှိတန်ဖိုးအများဆုံး။
    ///
    /// ဒီအချိုးကျတည်ငြိမ်တဲ့ဗားရှင်းကို [`atomic`] မှာ `fetch_max` method ကနေတစ်ဆင့် X0XX ကိုဖြတ်ပြီးကိန်းဂဏန်းစုစုပေါင်းကိုရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// တစ်ဦးလက်မှတ်ရေးထိုးနှိုင်းယှဉ် အသုံးပြု. လက်ရှိတန်ဖိုးအများဆုံး။
    ///
    /// ဒီအချိုးကျတည်ငြိမ်တဲ့ဗားရှင်းကို [`atomic`] မှာ `fetch_max` method ကနေတစ်ဆင့် X0XX ကိုဖြတ်ပြီးကိန်းဂဏန်းစုစုပေါင်းကိုရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// တစ်ဦးလက်မှတ်ရေးထိုးနှိုင်းယှဉ် အသုံးပြု. လက်ရှိတန်ဖိုးအများဆုံး။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::AcqRel`] ဖြတ်သန်းနေဖြင့် `fetch_max` နည်းလမ်းတစ်ခုမှတဆင့် integer ဖြစ်တဲ့အတွက်အမျိုးအစားများကိုလက်မှတ်ရေးထိုးခဲ့သည့် [`atomic`] အပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// လက်ရှိတန်ဖိုးနှင့်အတူအများဆုံး။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::Relaxed`] ဖြတ်သန်းနေဖြင့် `fetch_max` နည်းလမ်းတစ်ခုမှတဆင့် integer ဖြစ်တဲ့အတွက်အမျိုးအစားများကိုလက်မှတ်ရေးထိုးခဲ့သည့် [`atomic`] အပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// တစ်ဦးလက်မှတ်ရေးထိုးနှိုင်းယှဉ် အသုံးပြု. လက်ရှိတန်ဖိုးနိမ့်ဆုံး။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::SeqCst`] ဖြတ်သန်းနေဖြင့် `fetch_min` နည်းလမ်းတစ်ခုမှတဆင့် integer ဖြစ်တဲ့အတွက်အမျိုးအစားများကိုလက်မှတ်ရေးထိုးခဲ့သည့် [`atomic`] အပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// တစ်ဦးလက်မှတ်ရေးထိုးနှိုင်းယှဉ် အသုံးပြု. လက်ရှိတန်ဖိုးနိမ့်ဆုံး။
    ///
    /// ဒီအချိုးကျတည်ငြိမ်တဲ့ဗားရှင်းကို [`atomic`] မှာ `fetch_min` method ကနေတဆင့် X0XX ကိုဖြတ်ပြီးကိန်းပြည့်ကိန်းအမျိုးအစားများမှာရနိုင်သည်။
    /// ဥပမာ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// တစ်ဦးလက်မှတ်ရေးထိုးနှိုင်းယှဉ် အသုံးပြု. လက်ရှိတန်ဖိုးနိမ့်ဆုံး။
    ///
    /// ဒီအချိုးကျတည်ငြိမ်တဲ့ဗားရှင်းကို [`atomic`] မှာ `fetch_min` method ကနေတစ်ဆင့် X0XX ကိုဖြတ်ပြီးကိန်းဂဏန်းစုစုပေါင်းကိုရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// တစ်ဦးလက်မှတ်ရေးထိုးနှိုင်းယှဉ် အသုံးပြု. လက်ရှိတန်ဖိုးနိမ့်ဆုံး။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::AcqRel`] ဖြတ်သန်းနေဖြင့် `fetch_min` နည်းလမ်းတစ်ခုမှတဆင့် integer ဖြစ်တဲ့အတွက်အမျိုးအစားများကိုလက်မှတ်ရေးထိုးခဲ့သည့် [`atomic`] အပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// တစ်ဦးလက်မှတ်ရေးထိုးနှိုင်းယှဉ် အသုံးပြု. လက်ရှိတန်ဖိုးနိမ့်ဆုံး။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::Relaxed`] ဖြတ်သန်းနေဖြင့် `fetch_min` နည်းလမ်းတစ်ခုမှတဆင့် integer ဖြစ်တဲ့အတွက်အမျိုးအစားများကိုလက်မှတ်ရေးထိုးခဲ့သည့် [`atomic`] အပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// တစ်ဦးလက်မှတ်မထိုးနှိုင်းယှဉ် အသုံးပြု. လက်ရှိတန်ဖိုးနိမ့်ဆုံး။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::SeqCst`] ဖြတ်သန်းနေဖြင့် `fetch_min` နည်းလမ်းမှတဆင့် [`atomic`] လက်မှတ်မထိုးကိန်းအမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// တစ်ဦးလက်မှတ်မထိုးနှိုင်းယှဉ် အသုံးပြု. လက်ရှိတန်ဖိုးနိမ့်ဆုံး။
    ///
    /// ဤအခ်ါ၏တည်ငြိမ်သောဗားရှင်းကို [`atomic`] ပုံစံမပါသောကိန်းပြည့်များပေါ်တွင် `fetch_min` နည်းလမ်းမှတဆင့် [`Ordering::Acquire`] ကို `order` အဖြစ်ဖြတ်သန်းနိုင်သည်။
    /// ဥပမာ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// တစ်ဦးလက်မှတ်မထိုးနှိုင်းယှဉ် အသုံးပြု. လက်ရှိတန်ဖိုးနိမ့်ဆုံး။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::Release`] ဖြတ်သန်းနေဖြင့် `fetch_min` နည်းလမ်းမှတဆင့် [`atomic`] လက်မှတ်မထိုးကိန်းအမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// တစ်ဦးလက်မှတ်မထိုးနှိုင်းယှဉ် အသုံးပြု. လက်ရှိတန်ဖိုးနိမ့်ဆုံး။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::AcqRel`] ဖြတ်သန်းနေဖြင့် `fetch_min` နည်းလမ်းမှတဆင့် [`atomic`] လက်မှတ်မထိုးကိန်းအမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// တစ်ဦးလက်မှတ်မထိုးနှိုင်းယှဉ် အသုံးပြု. လက်ရှိတန်ဖိုးနိမ့်ဆုံး။
    ///
    /// ဤအခ်ါ၏တည်ငြိမ်သောဗားရှင်းကို [`atomic`] ပုံစံမပါသောကိန်းပြည့်များပေါ်တွင် `fetch_min` နည်းလမ်းမှတဆင့် [`Ordering::Relaxed`] ကို `order` အဖြစ်ဖြတ်သန်းနိုင်သည်။
    /// ဥပမာ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// တစ်ဦးလက်မှတ်မထိုးနှိုင်းယှဉ် အသုံးပြု. လက်ရှိတန်ဖိုးအများဆုံး။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::SeqCst`] ဖြတ်သန်းနေဖြင့် `fetch_max` နည်းလမ်းမှတဆင့် [`atomic`] လက်မှတ်မထိုးကိန်းအမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// တစ်ဦးလက်မှတ်မထိုးနှိုင်းယှဉ် အသုံးပြု. လက်ရှိတန်ဖိုးအများဆုံး။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::Acquire`] ဖြတ်သန်းနေဖြင့် `fetch_max` နည်းလမ်းမှတဆင့် [`atomic`] လက်မှတ်မထိုးကိန်းအမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// တစ်ဦးလက်မှတ်မထိုးနှိုင်းယှဉ် အသုံးပြု. လက်ရှိတန်ဖိုးအများဆုံး။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::Release`] ဖြတ်သန်းနေဖြင့် `fetch_max` နည်းလမ်းမှတဆင့် [`atomic`] လက်မှတ်မထိုးကိန်းအမျိုးအစားများအပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// တစ်ဦးလက်မှတ်မထိုးနှိုင်းယှဉ် အသုံးပြု. လက်ရှိတန်ဖိုးအများဆုံး။
    ///
    /// ဤအခ်ါ၏တည်ငြိမ်သောဗားရှင်းကို [`atomic`] ပုံစံမပါသောကိန်းပြည့်များပေါ်တွင် `fetch_max` နည်းလမ်းမှတဆင့် [`Ordering::AcqRel`] ကို `order` အဖြစ်ဖြတ်သန်းနိုင်သည်။
    /// ဥပမာ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// တစ်ဦးလက်မှတ်မထိုးနှိုင်းယှဉ် အသုံးပြု. လက်ရှိတန်ဖိုးအများဆုံး။
    ///
    /// ဤအခ်ါ၏တည်ငြိမ်သောဗားရှင်းကို [`atomic`] ပုံစံမပါသောကိန်းပြည့်များပေါ်တွင် `fetch_max` နည်းလမ်းမှတဆင့် [`Ordering::Relaxed`] ကို `order` အဖြစ်ဖြတ်သန်းနိုင်သည်။
    /// ဥပမာ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// အဆိုပါ `prefetch` အခ်ါထောက်ခံလျှင်ကြိုတင်ယူထားပြီးညွှန်ကြားချက်ထည့်သွင်းဖို့ကုဒ်မီးစက်ဖို့အရိပ်အယောင်ဖြစ်၏မဟုတ်ရင်ကမ op ဖြစ်ပါတယ်။
    /// ကြိုတင်ယူထားပြီးယင်းအစီအစဉ်၏အပြုအမူအပေါ်အဘယ်သူမျှမသက်ရောက်ပေမယ့်သူ့ရဲ့စွမ်းဆောင်ရည်ဝိသေသလက္ခဏာများပြောင်းလဲနိုင်သည်။
    ///
    /// `locality` အငြင်းအခုံသည်စဉ်ဆက်မပြတ်ကိန်းတစ်ခုဖြစ်ရမည်၊ (0) မှမည်သည့်နေရာ၊ (3) အထိ၊ ဒေသတွင်းသိမ်းဆည်းထားသည့်ယာယီသတ်မှတ်ချက်တစ်ခုဖြစ်သည်။
    ///
    ///
    /// ဒါဟာအခ်ါတည်ငြိမ်သောရှိသော counterpart မရှိပါ။
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// အဆိုပါ `prefetch` အခ်ါထောက်ခံလျှင်ကြိုတင်ယူထားပြီးညွှန်ကြားချက်ထည့်သွင်းဖို့ကုဒ်မီးစက်ဖို့အရိပ်အယောင်ဖြစ်၏မဟုတ်ရင်ကမ op ဖြစ်ပါတယ်။
    /// ကြိုတင်ယူထားပြီးယင်းအစီအစဉ်၏အပြုအမူအပေါ်အဘယ်သူမျှမသက်ရောက်ပေမယ့်သူ့ရဲ့စွမ်းဆောင်ရည်ဝိသေသလက္ခဏာများပြောင်းလဲနိုင်သည်။
    ///
    /// `locality` အငြင်းအခုံသည်စဉ်ဆက်မပြတ်ကိန်းတစ်ခုဖြစ်ရမည်၊ (0) မှမည်သည့်နေရာ၊ (3) အထိ၊ ဒေသတွင်းသိမ်းဆည်းထားသည့်ယာယီသတ်မှတ်ချက်တစ်ခုဖြစ်သည်။
    ///
    ///
    /// ဒါဟာအခ်ါတည်ငြိမ်သောရှိသော counterpart မရှိပါ။
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// အဆိုပါ `prefetch` အခ်ါထောက်ခံလျှင်ကြိုတင်ယူထားပြီးညွှန်ကြားချက်ထည့်သွင်းဖို့ကုဒ်မီးစက်ဖို့အရိပ်အယောင်ဖြစ်၏မဟုတ်ရင်ကမ op ဖြစ်ပါတယ်။
    /// ကြိုတင်ယူထားပြီးယင်းအစီအစဉ်၏အပြုအမူအပေါ်အဘယ်သူမျှမသက်ရောက်ပေမယ့်သူ့ရဲ့စွမ်းဆောင်ရည်ဝိသေသလက္ခဏာများပြောင်းလဲနိုင်သည်။
    ///
    /// `locality` အငြင်းအခုံသည်စဉ်ဆက်မပြတ်ကိန်းတစ်ခုဖြစ်ရမည်၊ (0) မှမည်သည့်နေရာ၊ (3) အထိ၊ ဒေသတွင်းသိမ်းဆည်းထားသည့်ယာယီသတ်မှတ်ချက်တစ်ခုဖြစ်သည်။
    ///
    ///
    /// ဒါဟာအခ်ါတည်ငြိမ်သောရှိသော counterpart မရှိပါ။
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// အဆိုပါ `prefetch` အခ်ါထောက်ခံလျှင်ကြိုတင်ယူထားပြီးညွှန်ကြားချက်ထည့်သွင်းဖို့ကုဒ်မီးစက်ဖို့အရိပ်အယောင်ဖြစ်၏မဟုတ်ရင်ကမ op ဖြစ်ပါတယ်။
    /// ကြိုတင်ယူထားပြီးယင်းအစီအစဉ်၏အပြုအမူအပေါ်အဘယ်သူမျှမသက်ရောက်ပေမယ့်သူ့ရဲ့စွမ်းဆောင်ရည်ဝိသေသလက္ခဏာများပြောင်းလဲနိုင်သည်။
    ///
    /// `locality` အငြင်းအခုံသည်စဉ်ဆက်မပြတ်ကိန်းတစ်ခုဖြစ်ရမည်၊ (0) မှမည်သည့်နေရာ၊ (3) အထိ၊ ဒေသတွင်းသိမ်းဆည်းထားသည့်ယာယီသတ်မှတ်ချက်တစ်ခုဖြစ်သည်။
    ///
    ///
    /// ဒါဟာအခ်ါတည်ငြိမ်သောရှိသော counterpart မရှိပါ။
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// အက်တမ်ခြံစည်းရိုး။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::SeqCst`] ဖြတ်သန်းနေဖြင့် [`atomic::fence`] အတွက်ရရှိနိုင်ပါသည်။
    ///
    ///
    pub fn atomic_fence();
    /// အက်တမ်ခြံစည်းရိုး။
    ///
    /// တည်ငြိမ်သောဤဗားရှင်းကို [`atomic::fence`] တွင် [`Ordering::Acquire`] ကို `order` အဖြစ်ဖြတ်သန်းနိုင်သည်။
    ///
    ///
    pub fn atomic_fence_acq();
    /// အက်တမ်ခြံစည်းရိုး။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::Release`] ဖြတ်သန်းနေဖြင့် [`atomic::fence`] အတွက်ရရှိနိုင်ပါသည်။
    ///
    ///
    pub fn atomic_fence_rel();
    /// အက်တမ်ခြံစည်းရိုး။
    ///
    /// တည်ငြိမ်သောဤဗားရှင်းကို [`atomic::fence`] တွင် [`Ordering::AcqRel`] ကို `order` အဖြစ်ဖြတ်သန်းနိုင်သည်။
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// တစ်ဦးက compiler သာမှတ်ဉာဏ်အတားအဆီး။
    ///
    /// memory access ကိုပု compiler ဖွငျ့ဤအတားအဆီးကိုဖြတ်ပြီး reordered ခြင်းကိုဘယ်တော့မှလိမ့်မယ်, ဒါပေမယ့်ဘယ်သူမျှမညွှန်ကြားချက်သည်ထုတ်လွှတ်ပါလိမ့်မည်။
    /// ဤအချက်သည် signal ကိုကိုင်တွယ်သူနှင့်အပြန်အလှန်ဆက်သွယ်သည့်အခါ preempted ဖြစ်နိုင်သောတူညီသောချည်မျှင်လည်ပတ်မှုအတွက်သင့်လျော်သည်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::SeqCst`] ဖြတ်သန်းနေဖြင့် [`atomic::compiler_fence`] အတွက်ရရှိနိုင်ပါသည်။
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// တစ်ဦးက compiler သာမှတ်ဉာဏ်အတားအဆီး။
    ///
    /// memory access ကိုပု compiler ဖွငျ့ဤအတားအဆီးကိုဖြတ်ပြီး reordered ခြင်းကိုဘယ်တော့မှလိမ့်မယ်, ဒါပေမယ့်ဘယ်သူမျှမညွှန်ကြားချက်သည်ထုတ်လွှတ်ပါလိမ့်မည်။
    /// ဤအချက်သည် signal ကိုကိုင်တွယ်သူနှင့်အပြန်အလှန်ဆက်သွယ်သည့်အခါ preempted ဖြစ်နိုင်သောတူညီသောချည်မျှင်လည်ပတ်မှုအတွက်သင့်လျော်သည်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::Acquire`] ဖြတ်သန်းနေဖြင့် [`atomic::compiler_fence`] အတွက်ရရှိနိုင်ပါသည်။
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// တစ်ဦးက compiler သာမှတ်ဉာဏ်အတားအဆီး။
    ///
    /// memory access ကိုပု compiler ဖွငျ့ဤအတားအဆီးကိုဖြတ်ပြီး reordered ခြင်းကိုဘယ်တော့မှလိမ့်မယ်, ဒါပေမယ့်ဘယ်သူမျှမညွှန်ကြားချက်သည်ထုတ်လွှတ်ပါလိမ့်မည်။
    /// ဤအချက်သည် signal ကိုကိုင်တွယ်သူနှင့်အပြန်အလှန်ဆက်သွယ်သည့်အခါ preempted ဖြစ်နိုင်သောတူညီသောချည်မျှင်လည်ပတ်မှုအတွက်သင့်လျော်သည်။
    ///
    /// တည်ငြိမ်သောဤဗားရှင်းကို [`atomic::compiler_fence`] တွင် [`Ordering::Release`] ကို `order` အဖြစ်ဖြတ်သန်းနိုင်သည်။
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// တစ်ဦးက compiler သာမှတ်ဉာဏ်အတားအဆီး။
    ///
    /// memory access ကိုပု compiler ဖွငျ့ဤအတားအဆီးကိုဖြတ်ပြီး reordered ခြင်းကိုဘယ်တော့မှလိမ့်မယ်, ဒါပေမယ့်ဘယ်သူမျှမညွှန်ကြားချက်သည်ထုတ်လွှတ်ပါလိမ့်မည်။
    /// ဤအချက်သည် signal ကိုကိုင်တွယ်သူနှင့်အပြန်အလှန်ဆက်သွယ်သည့်အခါ preempted ဖြစ်နိုင်သောတူညီသောချည်မျှင်လည်ပတ်မှုအတွက်သင့်လျော်သည်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `order` အဖြစ် [`Ordering::AcqRel`] ဖြတ်သန်းနေဖြင့် [`atomic::compiler_fence`] အတွက်ရရှိနိုင်ပါသည်။
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// function ကိုတွဲ attribute တွေကနေသူ့ရဲ့အဓိပ္ပာယ်ကိုဆင်းသက်လာကြောင်းကို Magic အခ်ါ။
    ///
    /// ဥပမာအားဖြင့်၊ ဒေတာစီးဆင်းမှုသည်၎င်းကိုတည်ငြိမ်သောအခိုင်အမာထည့်သွင်းရန်အသုံးပြုသည်။ သို့မှသာ `rustc_peek(potentially_uninitialized)` သည်ဒေတာစီးဆင်းမှုသည်ထိန်းချုပ်မှုစီးဆင်းမှု၏ထိုအချိန်ကအသိအမှတ်မပြုခြင်းဖြစ်သည်ဟုတွက်ချက်သည်ကိုအမှန်တကယ်နှစ်ကြိမ်စစ်ဆေးခဲ့သည်။
    ///
    ///
    /// ဒါဟာအခ်ါအဆိုပါ compiler ၏အသုံးပြင်ပတွင်ဖြစ်သင့်ပါဘူး။
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// လုပ်ငန်းစဉ်၏ကွပ်မျက်ဖျက်သိမ်း။
    ///
    /// တစ်ဦးကပိုပြီးအသုံးပြုသူ-friendly နှင့်ဤစစ်ဆင်ရေး၏တည်ငြိမ်သောဗားရှင်း [`std::process::abort`](../../std/process/fn.abort.html) ဖြစ်ပါတယ်။
    ///
    pub fn abort() -> !;

    /// code ကို၌ဤအချက်လက်လှမ်းမမှီပါသော Optimizer နောက်ထပ်ပိုမိုကောင်းမွန်ရေးအားဖွင့်, အကြောင်းကြား။
    ///
    /// NB ဤ `unreachable!()` နိုင်တဲ့ macro ထံမှအလွန်ကွဲပြားခြားနားသည်: ကကွပ်မျက်ခံရသောအခါ panics ကြောင့်ဒီ function ကိုအတူမှတ်သားကုဒ်ရောက်ရှိဖို့ * * undefined အပြုအမူဖြစ်သောနိုင်တဲ့ macro, မတူဘဲ။
    ///
    ///
    /// ဤအခ်ါ၏တည်ငြိမ်သောဗားရှင်းမှာ [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked) ဖြစ်သည်။
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// တစ်ခွအေနအေအမြဲမှန်ကြောင်း Optimizer အကြောင်းကြား။
    /// အခြေအနေကမှားနေလျှင်, အပြုအမူ undefined ဖြစ်ပါတယ်။
    ///
    /// ကုဒ်ကဒီအခ်ါအဘို့အထုတ်လုပ်ပြီးဖြစ်ပါတယ်, သို့သော် Optimizer ပတျဝနျးကငျြမှာ code optimization နှင့်အတူဝင်ရောက်စွက်ဖက်ခြင်းနှင့်စွမ်းဆောင်ရည်လျှော့ချရသော 'passes အကြားက (နှင့်၎င်း၏အခွအေနေ) ကိုထိန်းသိမ်းဖို့ကြိုးစားပါလိမ့်မယ်မရှိပါ။
    /// အဆိုပါလျော့ပါးသွားမည်ဖြစ်သလို၎င်း၏ကိုယ်ပိုင်အပေါ် Optimizer များကရှာဖွေတွေ့ရှိနိုင်ပါတယ်လျှင်မသုံးသင့်ပေ, သို့မဟုတ်ပါကမည်သည့်သိသာထင်ရှားသောပိုမိုကောင်းမွန်ရေးကို enable မပါဘူးဆိုရင်။
    ///
    /// ဒါဟာအခ်ါတည်ငြိမ်သောရှိသော counterpart မရှိပါ။
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// branch အခွအေနေစစ်မှန်တဲ့ဖြစ်ဖွယ်ရှိသော compiler မှအရိပ်အမြွက်။
    /// အဲဒါကိုလွန်တန်ဖိုးကို Returns ။
    ///
    /// `if` ထုတ်ပြန်ချက်များနှင့်အတူထက်အခြားမည်သည့်အသုံးပြုမှုဖြစ်ကောင်းတစ်ခုအကျိုးသက်ရောက်မှုရှိလိမ့်မည်မဟုတ်ပေ။
    ///
    /// ဒါဟာအခ်ါတည်ငြိမ်သောရှိသော counterpart မရှိပါ။
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// branch အခြေအနေသည်မှားယွင်းနိုင်သည်ဟု compiler ကအရိပ်အမြွက်ပြောကြားသည်။
    /// အဲဒါကိုလွန်တန်ဖိုးကို Returns ။
    ///
    /// `if` ထုတ်ပြန်ချက်များနှင့်အတူထက်အခြားမည်သည့်အသုံးပြုမှုဖြစ်ကောင်းတစ်ခုအကျိုးသက်ရောက်မှုရှိလိမ့်မည်မဟုတ်ပေ။
    ///
    /// ဒါဟာအခ်ါတည်ငြိမ်သောရှိသော counterpart မရှိပါ။
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// တစ်ဦး debugger အားဖြင့်စစ်ဆေးခြင်းများအတွက်တစ်ဦး breakpoints အားထောင်ချောက်ကွပ်မျက်ခံရ။
    ///
    /// ဒါဟာအခ်ါတည်ငြိမ်သောရှိသော counterpart မရှိပါ။
    pub fn breakpoint();

    /// bytes ဖြင့်အမျိုးအစား၏အရွယ်အစား။
    ///
    /// ပို၍ တိကျစွာပြောရလျှင်၎င်းသည် alignment padding အပါအဝင်တူညီသောအမျိုးအစားတစ်ခု၏အဆက်မပြတ်ပစ္စည်းများကြားရှိ bytes များအတွက် offset ဖြစ်သည်။
    ///
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း [`core::mem::size_of`](crate::mem::size_of) ဖြစ်ပါတယ်။
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// အမျိုးအစားတစ်ခု၏နိမ့်ဆုံး alignment ကို။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း [`core::mem::align_of`](crate::mem::align_of) ဖြစ်ပါတယ်။
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// အမျိုးအစားတစ်ခု၏ ဦး စားပေး alignment ကို။
    ///
    /// ဒါဟာအခ်ါတည်ငြိမ်သောရှိသော counterpart မရှိပါ။
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// bytes အတွက်ရည်ညွှန်းတန်ဖိုးကို၏အရွယ်အစား။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း [`mem::size_of_val`] ဖြစ်ပါတယ်။
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// အဆိုပါကိုးကားတန်ဖိုးလိုအပ်သော alignment ကို။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း [`core::mem::align_of_val`](crate::mem::align_of_val) ဖြစ်ပါတယ်။
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// အမျိုးအစားတစ်ခု၏အမည်ပါဝင်သောတည်ငြိမ်သောကြိုးချပ်ကိုရရှိသည်။
    ///
    /// ဤအခ်ါ၏တည်ငြိမ်သောဗားရှင်းမှာ [`core::any::type_name`](crate::any::type_name) ဖြစ်သည်။
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// အဆိုပါသတ်မှတ်ထားတဲ့ type ကိုမှတကမ္ဘာလုံးထူးခြားတဲ့အရာတခုအမှတ်အသားရရှိသွားတဲ့။
    /// crate သည်မည်သည့်နေရာတွင်မဆိုဤပုံစံသည်မည်သည့်အခြေအနေတွင်ရှိပါစေအမျိုးအစားတစ်ခုတည်းအတွက်အလားတူတန်ဖိုးကိုပြန်ပေးလိမ့်မည်။
    ///
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း [`core::any::TypeId::of`](crate::any::TypeId::of) ဖြစ်ပါတယ်။
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// `T` လူနေထိုင်မှုမရှိလျှင်အစဉ်အဆက်ကွပ်မျက်ခံရမရနိုင်သည်ကိုမလုံခြုံတဲ့ functions များအတွက်ကိုယ်ရံတော်:
    /// ဤသည်မှာလိမ့်မည် statically panic, ဒါမှမဟုတ်ဘာမျှမလုပ်ပေးဖြစ်စေ။
    ///
    /// ဒါဟာအခ်ါတည်ငြိမ်သောရှိသော counterpart မရှိပါ။
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// ဒီလိုမျိုး statically panic, ဒါမှမဟုတ်တစ်ခုခုဘာမျှမပြုကြလိမ့်မည်: `T` သုည-စတင်ခြင်းခွင့်မပြုလျှင်အစဉ်အဆက်ကွပ်မျက်ခံရမရနိုင်သည်ကိုမလုံခြုံတဲ့ functions များအတွက်ကိုယ်ရံတော်။
    ///
    ///
    /// ဒါဟာအခ်ါတည်ငြိမ်သောရှိသော counterpart မရှိပါ။
    pub fn assert_zero_valid<T>();

    /// ဒီလိုမျိုး statically ဖြစ်စေ panic လိမ့်မည်, ဒါမှမဟုတ်ဘာမျှမလုပ်ပေး: `T` မမှန်ကန်တဲ့နည်းနည်းပုံစံများရှိပါတယ်လျှင်ကာလအစဉ်အမြဲကွပ်မျက်ခံရမရနိုင်သည်ကိုမလုံခြုံတဲ့ functions များအတွက်ကိုယ်ရံတော်။
    ///
    ///
    /// ဒါဟာအခ်ါတည်ငြိမ်သောရှိသော counterpart မရှိပါ။
    pub fn assert_uninit_valid<T>();

    /// ဒါကြောင့်ကိုခေါ်ခဲ့သည်ရှိရာညွှန်ပြနေတဲ့အငြိမ် `Location` တစ်ဦးကိုကိုးကားရရှိသွားတဲ့။
    ///
    /// အစား [`core::panic::Location::caller`](crate::panic::Location::caller) သုံးပြီးစဉ်းစားပါ။
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// တစ်စက်ကော် running မပါဘဲနယ်ပယ်ထဲကတန်ဖိုးလှုံ့ဆော်ပေး။
    ///
    /// ဤသည် [`mem::forget_unsized`] ဘို့တစ်ခုတည်းကိုသာတည်ရှိ;ပုံမှန် `forget` အစား `ManuallyDrop` ကိုအသုံးပြုသည်။
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// အခြားအမျိုးအစားအဖြစ်တဦးတည်းအမျိုးအစားတန်ဖိုးများ၏-bits Reinterprets ။
    ///
    /// နှစ်ဦးစလုံးအမျိုးအစားများတူညီအရွယ်အစားရှိရမည်။
    /// မူရင်းမရလဒ်ကိုလည်းမတစ်ဦး [invalid value](../../nomicon/what-unsafe-does.html) ဖြစ်နိုင်သည်။
    ///
    /// `transmute` semantically သည်တစ်မျိုး၏တစ်နည်းနည်းဖြင့်အခြားသို့ပြောင်းခြင်းနှင့်ညီမျှသည်။၎င်းသည် source value မှ bits များကို destination value သို့ကူးယူပြီးနောက်မူရင်းကိုမေ့သွားသည်။
    /// ဒါဟာ `transmute_copy` ကဲ့သို့ပုပါးပျဉ်းအောက်တွင် C ရဲ့ `memcpy` ညီမျှပါတယ်။
    ///
    /// `transmute` တစ်ဦးက value ကိုစစ်ဆင်ရေးတစ်ခုဖြစ်သည်သောကြောင့်,*transmuted တန်ဖိုးများသူတို့ကိုယ်သူတို့၏ alignment ကို* တစ်ဦးစိုးရိမျစရာတော့မဟုတ်ပါဘူး။
    /// အခြားမည်သည့် function ကိုအတူသကဲ့သို့, compiler ပြီးသား `T` နှင့် `U` နှစ်ဦးစလုံးစနစ်တကျ aligned နေကြပါတယ်သေချာ။
    /// တခြားနေရာ *အမှတ်*(ထိုကဲ့သို့သောထောက်ပြ, ကိုးကား, သေတ္တာများ ... အဖြစ်) ထိုတန်ဖိုးများကို transmuting ရသောအခါမည်သို့ပင်ဖြစ်စေသည်, ခေါ်ဆိုမှုအတွက် Point-to တန်ဖိုးသင့်လျော် alignment ကိုသေချာစေရန်ရှိပါတယ်။
    ///
    /// `transmute` **မယုံနိုင်လောက်အောင်အန္တရာယ်မကင်း** ဖြစ်ပါတယ်။ဒီ function ကိုအတူ [undefined behavior][ub] ဖြစ်ပေါ်စေမယ့်နည်းလမ်းတွေတစ်ခုကျယ်ပြန့်အရေအတွက်အားရှိပါတယ်။`transmute` အဆိုပါအကြွင်းမဲ့အာဏာနောက်ဆုံးအပန်းဖြေစခန်းဖြစ်သင့်သည်။
    ///
    /// [nomicon](../../nomicon/transmutes.html) တွင်နောက်ထပ်စာရွက်စာတမ်းများရှိသည်။
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// `transmute` များအတွက်တကယ်အသုံးဝင်ကြောင်းကိုအနည်းငယ်သောအရာတို့ကိုရှိပါသည်။
    ///
    /// တစ်ဦး function ကို pointer သို့ pointer ကိုဖွင့်။ဤသည် * * function ကိုထောက်ပြနှင့်အချက်အလက်ထောက်ပြကွဲပြားခြားနားသောအရွယ်အစားရှိသည်ဘယ်မှာစက်မှခရီးဆောင်မဟုတ်ပါဘူး။
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// တစ်သက်တာကိုတိုးချဲ့ခြင်း၊ဤသည်အဆင့်မြင့်အလွန်အန္တရာယ်ကင်း Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// စိတ်ပျက်သွားမနေပါနဲ့: `transmute` အများအပြားအသုံးပြုမှုကအခြားနည်းလမ်းများမှတဆင့်အောင်မြင်နိုင်ပါသည်။
    /// အောက်တွင်ပိုမိုလုံခြုံ Construction ဖြင့်အစားထိုးနိုင်သည့် `transmute` ၏ဘုံ applications များဖြစ်ကြသည်။
    ///
    /// စသည်တို့ကို `u32`, `f64` မှကုန်ကြမ်း bytes(`&[u8]`) ဖွင့် .:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // အစား `u32::from_ne_bytes` ကိုသုံးပါ
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // ဒါမှမဟုတ် endianness သတ်မှတ် `u32::from_le_bytes` သို့မဟုတ် `u32::from_be_bytes` ကိုသုံးပါ
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// တစ်ဦး `usize` သို့ pointer ကိုဖွင့်:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // တစ်ဦး `as` အစားလှဲချကိုသုံးပါ
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// တစ်ဦး `&mut T` သို့ `*mut T` ဖွင့်:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // အစား reborrow ကိုသုံးပါ
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// တစ်ဦး `&mut U` သို့တစ်ဦး `&mut T` ဖွင့်:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // အခုတော့အတူတကွ `as` နှင့် reborrowing ထား. , `as` `as` ၏ကွင်းဆက်အကူးအပြောင်းသည်မဟုတ်မှတ်ထားပါ
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// တစ်ဦး `&[u8]` သို့တစ်ဦး `&str` ဖွင့်:
    ///
    /// ```
    /// // ဤလုပ်ဖို့အကောင်းတစ်လမ်းမဟုတ်ပါဘူး။
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // သင် `str::as_bytes` ကိုသုံးနိုင်သည်
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // သင် string ကိုထိန်းချုပ်ရှိပါကသို့မဟုတ်ပဲ, တစ်ဦးက byte string ကိုအသုံးပြုနိုင်သည်ပကတိ
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// တစ်ဦး `Vec<Option<&T>>` သို့ `Vec<&T>` ဖွင့်။
    ///
    /// တစ်ဦးကွန်တိန်နာရဲ့ contents များ၏အတွင်းစိတ်အမျိုးအစား transmute စေရန်, သင်ကွန်တိန်နာရဲ့လျော့ပါးသွားမည်ဖြစ်သလိုမဆိုချိုးဖောက်မသေချာအောင်ရမည်ဖြစ်သည်။
    /// `Vec` အဘို့, ဒီနည်းလမ်းအတွင်းအမျိုးအစားများ၏အရွယ်အစား *နှင့် alignment ကို* နှစ်ဦးစလုံးကိုက်ညီမှရှိသည်။
    /// အခွားသောကွန်တိန်နာအမှု transmuting ကွန်တိန်နာလျော့ပါးသွားမည်ဖြစ်သလိုချိုးဖောက်မရှိဘဲအားလုံးမှာဖြစ်နိုင်မှာမဟုတ်ဘူးလို့ထားတဲ့အတွက်အမျိုးအစား၏အရွယ်အစား, alignment ကို, ဒါမှမဟုတ်ပင် `TypeId` အပေါ်အားကိုးလိမ့်မယ်။
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // ကျနော်တို့နောက်မှသူတို့ပြန်သုံးပါလိမ့်မယ်အဖြစ် vector ပုံတူပွား
    /// let v_clone = v_orig.clone();
    ///
    /// // Using transmute ကိုအသုံးပြုခြင်း။ ဤအရာသည်မှားယွင်းသောအတွေးအခေါ်ဖြစ်သော Undefined Behavior ကိုဖြစ်ပေါ်စေနိုင်သည့် `Vec` ၏မသတ်မှတ်ထားသော data layout ပေါ်တွင်မူတည်သည်။
    /////
    /// // သို့ရာတွင်ထိုသို့မမိတ္တူဖြစ်ပါတယ်။
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // ဒါကအကြံပြု, လုံခြုံနည်းလမ်းဖြစ်ပါတယ်။
    /// // ဒါဟာအသစ်တခုခင်းကျင်းသို့သျောတစျခုလုံးကို vector copy ပါဘူး။
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // ဒါက data တွေကိုအပြင်အဆင်အပေါ်မှီခိုခြင်းမရှိဘဲ, "transmuting" တစ် `Vec` ၏သငျ့လျြောသောအဘယ်သူမျှမ-မိတ္တူ, မလုံခြုံနည်းလမ်းဖြစ်ပါတယ်။
    /// // အဲဒီအစားစာသား `transmute` တောင်းဆို၏, ကျွန်တော်တစ်ဦး pointer ကိုသွန်းလုပ်ဆောင်ပေမယ့်အသစ်ကတဦးတည်း (`Option<&i32>`) မှမူလအတွင်းစိတ်အမျိုးအစား (`&i32`) converting ၏စည်းကမ်းချက်များ၌, ဒီအားလုံးအတူတူပင်အတွက်အသိပေးချက်ရှိပါတယ်။
    /////
    /// // အထက်ပေးသတင်းအချက်အလက်များအပြင်ကိုလည်း [`from_raw_parts`] စာရွက်စာတမ်းများနှင့်တိုင်ပင်ပါ။
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME vec_into_raw_parts တည်ငြိမ်သောအခါဤအရာကို Update လုပ်ပါ။
    ///     // မူရင်း vector ကျဆင်းသွားသည်မဟုတ်သေချာစေရန်။
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// `split_at_mut` အကောင်အထည်ဖော်:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // ဒီလိုလုပ်ဖို့မျိုးစုံနည်းလမ်းတွေရှိပါတယ်, အောက်ပါ (transmute) လမ်းနှင့်အတူမျိုးစုံပြဿနာတွေရှိပါတယ်။
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // ပထမဦးဆုံး: transmute လုံခြုံရိုက်ထည့်မျှမက,ဒါကြောင့်အားလုံးစစ်ဆေးသော T နှင့်ဖြစ်ပါတယ်
    ///         // ဦးအတူတူပင်အရွယ်အစားရှိပါတယ်။
    ///         // ဒုတိယအချက်မှာ၊ သင့်မှာမှတ်ဉာဏ်တစ်ခုတည်းကိုညွှန်ပြနေတဲ့ mutable ကိုးကားချက်ရှိတယ်။
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // ဤသည်အမျိုးအစားကိုဘေးကင်းလုံခြုံရေးပြဿနာများဖယ်ရှားပစ်ဖို့ရရှိသွားတဲ့;`&mut *`* သာ *တစ် `&mut T` သို့မဟုတ် `* mut T` ထံမှသင်တစ်ဦး `&mut T` ကိုငါပေးမည်။
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // သို့သော်သင်ဆဲအတူတူပင်မှတ်ဉာဏ်မှညွှန်ပြနှစ်ခု mutable ကိုးကားရှိသည်။
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // ဒါဟာစံစာကြည့်တိုက်ကမဘယ်လောက်ဖြစ်ပါတယ်။
    /// // သင်ဤကဲ့သို့သောတစ်ခုခုလုပ်ရန်လိုအပ်ပါက၎င်းသည်အကောင်းဆုံးနည်းလမ်းဖြစ်သည်
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // ယခုဤတူညီသောမှတ်ဉာဏ်မှာညွှန်ပြသုံး mutable ကိုးကားထားပါတယ်။`slice`, အ rvalue ret.0, နှင့် rvalue ret.1 ။
    ///         // `slice` `let ptr = ...` ပြီးနောက်အသုံးပြုဘယ်တော့မှဖြစ်ပါတယ်, ဒါကြောင့်တဦးတည်း "dead" အဖြစ်ဆက်ဆံနိုင်ပြီး, ထို့ကွောငျ့, သငျသညျနှစ်ခုသာအစစ်အမှန် mutable ချပ်ရှိသည်။
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: ဒီအခ်ါ const တည်ငြိမ်စေသည်နေချိန်မှာကျနော်တို့ const Fn အချို့ထုံးစံကုဒ်ရှိ
    // `const fn` အတွင်းက၎င်း၏အသုံးပြုမှုတားဆီးကြောင်းစစ်ဆေးမှုများ။
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// `T` အဖြစ်ပေးထားသောအမှန်တကယ်အမျိုးအစားကော်ကော်လိုအပ်သည်ဆိုပါက `true` သို့ပြန်သွားသည်။ပြန် `false` `T` သုံးကိရိယာ `Copy` သည်အမှန်တကယ်အမျိုးအစားပါ။
    ///
    ///
    /// အမှန်တကယ် type ကိုတစ်စက်ကော်မဟုတ်သလိုသုံးကိရိယာ `Copy` လိုအပ်ပါတယ်မဟုတ်ခဲ့လျှင်, သို့ဖြစ်လျှင်ဤ function ကို၏ပြန်လာတန်ဖိုးကိုသတ်မှတ်ဖြစ်ပါတယ်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း [`mem::needs_drop`](crate::mem::needs_drop) ဖြစ်ပါတယ်။
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// အဆိုပါတစ် pointer ကနေ offset တွက်ချက်။
    ///
    /// ပြောင်းလဲခြင်းသတင်းအချက်အလက် aliasing ပစ်မယ်လို့ကတည်းကဒီတစ်ခုကိန်းနှင့်ကနေ converting ရှောင်ရှားရန်တစ်ဦးအခ်ါအဖြစ်အကောင်အထည်ဖော်နေသည်။
    ///
    /// # Safety
    ///
    /// နှစ်ဦးစလုံးအတွက်စတင်နှင့်ရရှိလာတဲ့ pointer ကိုမှတ်သားသို့မဟုတ်တစ်ခုခွဲဝေအရာဝတ္ထု၏အဆုံးအတိတ်တဦးတည်းက byte အတွက်ဖြစ်စေဖြစ်ရမည်။
    /// တစ်ခုခုကိုညွှန်ဘောငျသို့မဟုတ်ဂဏန်းသင်္ချာလျတ်ထဲကဖြစ်တယ်ဆိုရင်ဖြစ်ပေါ်ပြီးနောက်ပြန်ရောက်တန်ဖိုးကိုမဆိုထပ်မံအသုံးပြုမှု undefined အပြုအမူကိုဖြစ်ပေါ်စေမည်။
    ///
    ///
    /// ဤအခ်ါ၏တည်ငြိမ်သောဗားရှင်းမှာ [`pointer::offset`] ဖြစ်သည်။
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// အဆိုပါတစ် pointer, အလားအလာထုပ်ထဲကနေ offset တွက်ချက်။
    ///
    /// ဤသည်ပြောင်းလဲခြင်းတားစီးအချို့သောပိုမိုကောင်းမွန်ရေးကတည်းကတစ်ခုကိန်းနှင့်ကနေ converting ရှောင်ရှားရန်တစ်ဦးအခ်ါအဖြစ်အကောင်အထည်ဖော်နေသည်။
    ///
    /// # Safety
    ///
    /// `offset` အခ်ါနှင့်မတူဘဲ၎င်းအချိုးအစားသည်ခွဲဝေထားသည့်အရာဝတ္ထု၏အဆုံးတွင်အတိတ်သို့မဟုတ်တစ်ဘိုက်တစ်ခုအားညွှန်ပြရန်ကန့်သတ်မထားပါ။ ၎င်းသည်နှစ်ခု၏အပိုဆောင်းဂဏန်းသင်္ချာဖြင့်အဆုံးသတ်သည်။
    /// ရရှိလာတဲ့တန်ဖိုးဟာမှတ်ဥာဏ်ကိုအမှန်တကယ်ရယူဖို့အတွက်အသုံးပြုဖို့မသင့်တော်ပါဘူး။
    ///
    /// ဤအခ်ါ၏တည်ငြိမ်သောဗားရှင်းမှာ [`pointer::wrapping_offset`] ဖြစ်သည်။
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// သင့်လျော်သော `llvm.memcpy.p0i8.0i8.*` အခ်ါနှင့်အရွယ်အစား၊ အရွယ်အစား `count`*`size_of::<T>()` နှင့်တစ်ခု၏ချိန်ညှိမှုနှင့်အတူ
    ///
    /// `min_align_of::<T>()`
    ///
    /// မတည်ငြိမ်သော parameter သည် `true` ဟုသတ်မှတ်သည်, ဒါကြောင့်အရွယ်အစားကိုသုညနဲ့ညီမျှမဟုတ်လျှင်ထုတ် optimized မည်မဟုတ်ပါ။
    ///
    /// ဒါဟာအခ်ါတည်ငြိမ်သောရှိသော counterpart မရှိပါ။
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// `count *size_of::<T>()` တစ်အရွယ်အစားနှင့်တစ်ဦး alignment ကိုအတူသင့်လျော်သော `llvm.memmove.p0i8.0i8.*` အခ်ါညီမျှ
    ///
    /// `min_align_of::<T>()`
    ///
    /// မတည်ငြိမ်သော parameter သည် `true` ဟုသတ်မှတ်သည်, ဒါကြောင့်အရွယ်အစားကိုသုညနဲ့ညီမျှမဟုတ်လျှင်ထုတ် optimized မည်မဟုတ်ပါ။
    ///
    /// ဒါဟာအခ်ါတည်ငြိမ်သောရှိသော counterpart မရှိပါ။
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// သင့်လျော်သော `llvm.memset.p0i8.*` အခ်ါနှင့်အရွယ်အစား၊ အရွယ်အစား `count* size_of::<T>()` နှင့် `min_align_of::<T>()` ၏ alignment တစ်ခုနှင့်ညီမျှသည်။
    ///
    ///
    /// မတည်ငြိမ်သော parameter သည် `true` ဟုသတ်မှတ်သည်, ဒါကြောင့်အရွယ်အစားကိုသုညနဲ့ညီမျှမဟုတ်လျှင်ထုတ် optimized မည်မဟုတ်ပါ။
    ///
    /// ဒါဟာအခ်ါတည်ငြိမ်သောရှိသော counterpart မရှိပါ။
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// အဆိုပါ `src` pointer ကနေမတည်ငြိမ်သောဝန်လုပ်ဆောင်တယ်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း [`core::ptr::read_volatile`](crate::ptr::read_volatile) ဖြစ်ပါတယ်။
    pub fn volatile_load<T>(src: *const T) -> T;
    /// အဆိုပါ `dst` pointer ကိုတစ်ဦးမတည်ငြိမ်သောစတိုးဆိုင်ကိုလုပ်ဆောင်တယ်။
    ///
    /// ဤအခ်ါ၏တည်ငြိမ်သောဗားရှင်းမှာ [`core::ptr::write_volatile`](crate::ptr::write_volatile) ဖြစ်သည်။
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// အဆိုပါညွှန် aligned ခံရဖို့မလိုအပ်ပါသည် `src` pointer ကနေစွမ်းဆောင်ရည်တစ်ဦးမတည်ငြိမ်သောဝန်။
    ///
    ///
    /// ဒါဟာအခ်ါတည်ငြိမ်သောရှိသော counterpart မရှိပါ။
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// အဆိုပါ `dst` pointer ကိုတစ်ဦးမတည်ငြိမ်သောစတိုးဆိုင်ကိုလုပ်ဆောင်တယ်။
    /// အဆိုပါညွှန် aligned ခံရဖို့မလိုအပ်ပါ။
    ///
    /// ဒါဟာအခ်ါတည်ငြိမ်သောရှိသော counterpart မရှိပါ။
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// တစ်ဦး `f32` ၏စတုရန်းအမြစ် Returns
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// တစ်ဦး `f64` ၏စတုရန်းအမြစ် Returns
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// တစ်ဦး `f32` အနေနဲ့ integer ဖြစ်တဲ့အတွက်အာဏာပေါ်ပေါက်။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// တစ်ဦး `f64` အနေနဲ့ integer ဖြစ်တဲ့အတွက်အာဏာပေါ်ပေါက်။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// တစ်ဦး `f32` ၏ sine Returns ။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// တစ်ဦး `f64` ၏ sine Returns ။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// တစ် ဦး `f32` ၏ cosine ပြန်သွားသည်။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// တစ်ဦး `f64` ၏ဆိုင်း Returns ။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// `f32` တစ်ခုအား `f32` ပါဝါသို့မြှင့်သည်။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// တစ်ဦး `f64` တစ်ခု `f64` အာဏာပေါ်ပေါက်။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// တစ်ဦး `f32` ၏အဆ Returns ။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// တစ်ဦး `f64` ၏အဆ Returns ။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// တစ်ဦး `f32` ၏တန်ခိုးမှထမြောက်တော်မူပြန် 2 ။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// တစ်ဦး `f64` ၏တန်ခိုးမှထမြောက်တော်မူပြန် 2 ။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// တစ်ဦး `f32` ၏သဘာဝလော်ဂရစ်သမ် Returns ။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// တစ်ဦး `f64` ၏သဘာဝလော်ဂရစ်သမ် Returns ။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// တစ် ဦး `f32` ၏အခြေစိုက်စခန်း 10 လော်ဂရစ်သမ်ပြန်သွားသည်။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// တစ်ဦး `f64` ၏အခြေစိုက်စခန်း 10 ခုလော်ဂရစ်သမ် Returns ။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// တစ် ဦး `f32` ၏အခြေစိုက်စခန်း 2 လော်ဂရစ်သမ်ပြန်သွားသည်။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// တစ်ဦး `f64` ၏အခြေစိုက်စခန်း 2 လော်ဂရစ်သမ် Returns ။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// `a * b + c` `f32` တန်ဖိုးများများအတွက် Returns ။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// `f64` တန်ဖိုးများအတွက် `a * b + c` ကိုပြန်ပို့သည်။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// တစ်ဦး `f32` ရဲ့ absolute value Returns ။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// တစ်ဦး `f64` ရဲ့ absolute value Returns ။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// နှစ်ခု `f32` တန်ဖိုးနိမ့်ဆုံး Returns ။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// နှစ်ခု `f64` တန်ဖိုးနိမ့်ဆုံး Returns ။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// အများဆုံး `f32` တန်ဖိုးအများဆုံးကိုပြန်ပို့သည်။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// အများဆုံး `f64` တန်ဖိုးအများဆုံးကိုပြန်ပို့သည်။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// မိတ္တူ `f32` တန်ဖိုးများများအတွက် `y` ထံမှ `x` ဖို့နိမိတ်လက္ခဏာ။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// `f64` တန်ဖိုးများအတွက် `y` မှ `x` သို့နိမိတ်လက္ခဏာကိုကူးယူပါ။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// `f32` ထက်ကြီးသောသို့မဟုတ်ညီမျှသောအကြီးဆုံး integer ကိုပြန်ပို့သည်။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// `f64` ထက်ကြီးသောသို့မဟုတ်ညီမျှသောအကြီးဆုံး integer ကိုပြန်ပို့သည်။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// ပြန်အသေးဆုံးကိန်းထက် သာ. ကြီးမြတ်သို့မဟုတ် `f32` ညီမျှ။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// ပြန်အသေးဆုံးကိန်းထက် သာ. ကြီးမြတ်သို့မဟုတ် `f64` ညီမျှ။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// တစ်ဦး `f32` ၏ကိန်းတစ်စိတ်တစ်ပိုင်း Returns ။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// တစ်ခုက `f64` ၏ကိန်းအစိတ်အပိုင်းတစ်ခုပြန်သွားသည်။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// အနီးဆုံးကိန်းတစ်ခုကို `f32` သို့ပြန်သွားသည်။
    /// အငြင်းအခုံသည်ကိန်းတစ်ခုမဟုတ်ပါကတိကျစွာ floating-point ချွင်းချက်တစ်ခုမြှင့်နိုင်သည်။
    pub fn rintf32(x: f32) -> f32;
    /// အနီးဆုံးကိန်းတစ်ခုကို `f64` သို့ပြန်သွားသည်။
    /// အငြင်းအခုံသည်ကိန်းတစ်ခုမဟုတ်ပါကတိကျစွာ floating-point ချွင်းချက်တစ်ခုမြှင့်နိုင်သည်။
    pub fn rintf64(x: f64) -> f64;

    /// အနီးဆုံးကိန်းတစ်ခုကို `f32` သို့ပြန်သွားသည်။
    ///
    /// ဒါဟာအခ်ါတည်ငြိမ်သောရှိသော counterpart မရှိပါ။
    pub fn nearbyintf32(x: f32) -> f32;
    /// အနီးဆုံးကိန်းတစ်ခုကို `f64` သို့ပြန်သွားသည်။
    ///
    /// ဒါဟာအခ်ါတည်ငြိမ်သောရှိသော counterpart မရှိပါ။
    pub fn nearbyintf64(x: f64) -> f64;

    /// တစ်ဦး `f32` မှအနီးဆုံးကိန်း Returns ။ကျည်ကွယ်ပျောက်သုညကနေဝက်လမ်းအမှုပေါင်း။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// တစ်ဦး `f64` မှအနီးဆုံးကိန်း Returns ။ကျည်ကွယ်ပျောက်သုညကနေဝက်လမ်းအမှုပေါင်း။
    ///
    /// ဒီအခ်ါသည်၏တည်ငြိမ်ဗားရှင်း
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// algebra စည်းမျဉ်းစည်းကမ်းတွေအပေါ်အခြေခံပြီးပိုမိုကောင်းမွန်ရေးခွင့်ပြု float များအပြင်။
    /// သွင်းအားစုကနျ့ဖြစ်ကြသည်ယူဆနိုင်ပါတယ်။
    ///
    /// ဒါဟာအခ်ါတည်ငြိမ်သောရှိသော counterpart မရှိပါ။
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// အက္ခရာသင်္ချာစည်းမျဉ်းစည်းကမ်းတွေကိုအခြေခံပြီးပိုကောင်းအောင်လုပ်ပေးတဲ့ Float အနုတ်။
    /// သွင်းအားစုကနျ့ဖြစ်ကြသည်ယူဆနိုင်ပါတယ်။
    ///
    /// ဒါဟာအခ်ါတည်ငြိမ်သောရှိသော counterpart မရှိပါ။
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// algebra စည်းမျဉ်းစည်းကမ်းတွေအပေါ်အခြေခံပြီးပိုမိုကောင်းမွန်ရေးခွင့်ပြု float မြှောက်။
    /// သွင်းအားစုကနျ့ဖြစ်ကြသည်ယူဆနိုင်ပါတယ်။
    ///
    /// ဒါဟာအခ်ါတည်ငြိမ်သောရှိသော counterpart မရှိပါ။
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// algebra စည်းမျဉ်းစည်းကမ်းတွေအပေါ်အခြေခံပြီးပိုမိုကောင်းမွန်ရေးခွင့်ပြု float ဌာနခွဲ။
    /// သွင်းအားစုကနျ့ဖြစ်ကြသည်ယူဆနိုင်ပါတယ်။
    ///
    /// ဒါဟာအခ်ါတည်ငြိမ်သောရှိသော counterpart မရှိပါ။
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// အက္ခရာသင်္ချာစည်းမျဉ်းစည်းကမ်းတွေကိုအခြေခံပြီးပိုကောင်းအောင်လုပ်ပေးတဲ့ Float ကျန်ရှိနေသေးတယ်။
    /// သွင်းအားစုကနျ့ဖြစ်ကြသည်ယူဆနိုင်ပါတယ်။
    ///
    /// ဒါဟာအခ်ါတည်ငြိမ်သောရှိသော counterpart မရှိပါ။
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// အကွာအဝေးထဲကတန်ဖိုးတွေကိုအဘို့အ undefeated ပြန်လာရသော LLVM ရဲ့ fptoui/fptosi အတူ converter
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// [`f32::to_int_unchecked`] နှင့် [`f64::to_int_unchecked`] အဖြစ်တည်ငြိမ်။
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// ပြန်ကာကိန်းအမျိုးအစား `T` အတွက်သတ်မှတ်ထား-bits များ၏အရေအတွက်
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `count_ones` နည်းလမ်းမှတဆင့် integer ဖြစ်တဲ့အတွက် Primitive အပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// တစ်ခုကိန်းအမျိုးအစား `T` အတွက်ဦးဆောင်အားမသတ်မှတ်ထား-bits (zeroes) ၏နံပါတ်ပြန်ပို့ပေးသည်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `leading_zeros` နည်းလမ်းမှတဆင့် integer ဖြစ်တဲ့အတွက် Primitive အပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// တန်ဖိုးအား `0` နဲ့ `x` `T` ၏နည်းနည်းအကျယ်ပြန်လာပါလိမ့်မယ်။
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// တန်ဖိုးအား `0` နဲ့ `x` ပေးသောအခါ `undef` ပြန်လည်ရောက်ရှိအဖြစ် `ctlz` လိုပဲ, ဒါပေမယ့်အပို-မလုံခြုံ။
    ///
    ///
    /// ဒါဟာအခ်ါတည်ငြိမ်သောရှိသော counterpart မရှိပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// `T` တစ်ခုလုံးအတွက်မသတ်မှတ်ရသေးသော bits (zeroes) ၏နံပါတ်ကိုပြန်ပို့သည်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `trailing_zeros` နည်းလမ်းမှတဆင့် integer ဖြစ်တဲ့အတွက် Primitive အပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// တန်ဖိုးအား `0` နဲ့ `x` `T` ၏နည်းနည်းအကျယ်ပြန်လာပါလိမ့်မယ်:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// တန်ဖိုးအား `0` နဲ့ `x` ပေးသောအခါ `undef` ပြန်လည်ရောက်ရှိအဖြစ် `cttz` လိုပဲ, ဒါပေမယ့်အပို-မလုံခြုံ။
    ///
    ///
    /// ဒါဟာအခ်ါတည်ငြိမ်သောရှိသော counterpart မရှိပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// ကိန်းတစ်ခုအား `T` အတွင်းရှိ bytes များကိုပြောင်းပြန်လုပ်သည်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `swap_bytes` နည်းလမ်းမှတဆင့် integer ဖြစ်တဲ့အတွက် Primitive အပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// တစ်ခုကိန်းအမျိုးအစား `T` အတွက် bits သည်နောက်ကြောင်းပြန်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `reverse_bits` နည်းလမ်းမှတဆင့် integer ဖြစ်တဲ့အတွက် Primitive အပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// စွမ်းဆောင်ရည်များအပြင်ကိန်းစစ်တယ်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `overflowing_add` နည်းလမ်းမှတဆင့် integer ဖြစ်တဲ့အတွက် Primitive အပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Performance အနုတ်ကိန်း check လုပ်ထား
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `overflowing_sub` နည်းလမ်းမှတဆင့် integer ဖြစ်တဲ့အတွက် Primitive အပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// check လုပ်ထားကိန်းမြှောက်လုပ်ဆောင်တယ်
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `overflowing_mul` နည်းလမ်းမှတဆင့် integer ဖြစ်တဲ့အတွက် Primitive အပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// `x % y != 0` သို့မဟုတ် `y == 0` သို့မဟုတ် `x == T::MIN && y == -1` ရှိမရှိသတ်မှတ်ထားသောအပြုအမူများဖြစ်ပေါ်စေသည်
    ///
    ///
    /// ဒါဟာအခ်ါတည်ငြိမ်သောရှိသော counterpart မရှိပါ။
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// undefined အပြုအမူဘယ်မှာ `y == 0` သို့မဟုတ် `x == T::MIN && y == -1` အတွက်ရရှိလာတဲ့ performance တစ်ခုအမှတ်ကိုဖြုတ်လိုက်ပါဌာနခွဲ,
    ///
    ///
    /// ဒီအခ်ါအဘို့ဘေးကင်းလုံခြုံထုပ်အဆိုပါ `checked_div` နည်းလမ်းမှတဆင့် integer ဖြစ်တဲ့အတွက် Primitive အပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// လာသောအခါ `y == 0` သို့မဟုတ် `x == T::MIN && y == -1` undefined အပြုအမူအတွက်ရရှိလာတဲ့တစ်ဦးအမှတ်ကိုဖြုတ်လိုက်ပါကွဲပြားခြင်း၏ကျန်ရှိသော Returns
    ///
    ///
    /// ဒီအခ်ါအဘို့ဘေးကင်းလုံခြုံထုပ်အဆိုပါ `checked_rem` နည်းလမ်းမှတဆင့် integer ဖြစ်တဲ့အတွက် Primitive အပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// N ကို-bits အတွက် T-ရဲ့ width သည်အဘယ်မှာရှိ undefined အပြုအမူသည့်အခါ `y < 0` သို့မဟုတ် `y >= N` အတွက်ရရှိလာတဲ့ performance တစ်ခုအမှတ်ကိုဖြုတ်လိုက်ပါလက်ဝဲပြောင်းကုန်ပြီ။
    ///
    ///
    /// ဒီအခ်ါအဘို့ဘေးကင်းလုံခြုံထုပ်အဆိုပါ `checked_shl` နည်းလမ်းမှတဆင့် integer ဖြစ်တဲ့အတွက် Primitive အပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// N ကို-bits အတွက် T-ရဲ့ width သည်အဘယ်မှာရှိ undefined အပြုအမူသည့်အခါ `y < 0` သို့မဟုတ် `y >= N` အတွက်ရရှိလာတဲ့ performance တစ်ခုအမှတ်ကိုဖြုတ်လိုက်ပါညာဘက်ပြောင်းကုန်ပြီ။
    ///
    ///
    /// ဒီအခ်ါအဘို့ဘေးကင်းလုံခြုံထုပ်အဆိုပါ `checked_shr` နည်းလမ်းမှတဆင့် integer ဖြစ်တဲ့အတွက် Primitive အပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// `x + y > T::MAX` သို့မဟုတ် `x + y < T::MIN` တို့မသတ်မှတ်ရသေးသောအပြုအမူများကိုရရှိခြင်းမရှိသောဖြည့်စွက်ခြင်း၏ရလဒ်ကိုပြန်ပို့သည်။
    ///
    ///
    /// ဒါဟာအခ်ါတည်ငြိမ်သောရှိသော counterpart မရှိပါ။
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// လာသောအခါ `x - y > T::MAX` သို့မဟုတ် `x - y < T::MIN` undefined အပြုအမူအတွက်ရရှိလာတဲ့တစ်ဦးအမှတ်ကိုဖြုတ်လိုက်ပါအနုတ်၏ရလဒ် Returns ။
    ///
    ///
    /// ဒါဟာအခ်ါတည်ငြိမ်သောရှိသော counterpart မရှိပါ။
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// လာသောအခါ `x *y > T::MAX` သို့မဟုတ် `x* y < T::MIN` undefined အပြုအမူအတွက်ရရှိလာတဲ့တစ်ဦးအမှတ်ကိုဖြုတ်လိုက်ပါမြှောက်၏ရလဒ် Returns ။
    ///
    ///
    /// ဒါဟာအခ်ါတည်ငြိမ်သောရှိသော counterpart မရှိပါ။
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Performance လက်ဝဲလှည့်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `rotate_left` နည်းလမ်းမှတဆင့် integer ဖြစ်တဲ့အတွက် Primitive အပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// ညာဘက်လှည့်လုပ်ဆောင်တယ်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `rotate_right` နည်းလမ်းမှတဆင့် integer ဖြစ်တဲ့အတွက် Primitive အပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// ပြန် (က + ခ) N ကို-bits အတွက် T-ရဲ့ width ရှိရာ 2 <sup>N ကို,</sup> Mod ။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `wrapping_add` နည်းလမ်းမှတဆင့် integer ဖြစ်တဲ့အတွက် Primitive အပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// ပြန် (က, ခ) N ကို-bits အတွက် T-ရဲ့ width ရှိရာ 2 <sup>N ကို,</sup> Mod ။
    ///
    /// တည်ငြိမ်သောတည်ငြိမ်သောမူကွဲများကို `wrapping_sub` နည်းလမ်းမှတဆင့်ကိန်းဂဏန်းများအပြည့်ရရှိနိုင်သည်။
    /// ဥပမာ,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// ပြန် (က * ခ) N ကို-bits အတွက် T-ရဲ့ width ရှိရာ 2 <sup>N ကို,</sup> Mod ။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `wrapping_mul` နည်းလမ်းမှတဆင့် integer ဖြစ်တဲ့အတွက် Primitive အပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// ဂဏန်းဘောငျမှာ saturating computing `a + b` ။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `saturating_add` နည်းလမ်းမှတဆင့် integer ဖြစ်တဲ့အတွက် Primitive အပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// ဂဏန်းဘောငျမှာပြည့်နှက် `a - b` တွက်ချက်။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း `saturating_sub` နည်းလမ်းမှတဆင့် integer ဖြစ်တဲ့အတွက် Primitive အပေါ်ရရှိနိုင်ပါသည်။
    /// ဥပမာ,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// 'v' အတွက်မူကွဲများအတွက်ခွဲခြားဆက်ဆံမှု၏တန်ဖိုး Returns;
    /// `T` အဘယ်သူမျှမခွဲခြားဆက်ဆံမှုမရှိပါလျှင်, `0` ပြန်လည်ရောက်ရှိ။
    ///
    /// ဒီအခ်ါဒတည်ငြိမ်ဗားရှင်း [`core::mem::discriminant`](crate::mem::discriminant) ဖြစ်ပါတယ်။
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// `T` တစ် `usize` မှကာစ်အမျိုးအစားမျိုးကွဲများ၏အရေအတွက် Returns;
    /// `T` မျှမျိုးကွဲရှိပါတယ်လျှင်, `0` ပြန်လည်ရောက်ရှိ။လူနေထိုင်မှုမရှိမျိုးကွဲရေတွက်ပါလိမ့်မည်။
    ///
    /// ဒီအချိုးအစားအရဖြစ်တည်ငြိမ်စေတဲ့ဗားရှင်းကတော့ [`mem::variant_count`] ပါ။
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// ဒေတာ pointer `data` နှင့်အတူ `try_fn` pointer function ကိုအမှီ ပြု. ဖြစ်သော Rust ရဲ့ "try catch" Construction ။
    ///
    /// တတိယအငြင်းအခုံ panic ဖြစ်ပေါ်လျှင် function တစ်ခုဖြစ်သည်။
    /// ဒီ function ဒေတာ pointer နှင့်ဖမ်းမိခဲ့ပစ်မှတ်-တိကျတဲ့ခြွင်းချက်အရာဝတ္ထုတစ်ခု pointer ကြာပါသည်။
    ///
    /// ပိုမိုသိရှိလိုပါကများအတွက် compiler ရဲ့အရင်းအမြစ်အဖြစ် std ရဲ့ဖမ်းအကောင်အထည်ဖော်မှုကိုကြည့်ပါ။
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// (သူတို့ရဲ့စာရွက်စာတမ်းများကိုကြည့်ပါ) LLVM သည်နှင့်အညီတစ်ဦး `!nontemporal` စတိုးဆိုင်ကိုထုတ်လွှတ်ပေးပါ။
    /// ဖြစ်ကောင်းတည်ငြိမ်ဖြစ်လာဘယ်တော့မှပါလိမ့်မယ်။
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// အသေးစိတ်ကို `<*const T>::offset_from` ၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// အသေးစိတ်ကို `<*const T>::guaranteed_eq` ၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// အသေးစိတ်အတွက် `<*const T>::guaranteed_ne` ၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// compile လုပ်သည့်အချိန်တွင်ခွဲဝေချထားပါ။runtime မှာမခေါ်သင့်ပါ။
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// သူတို့မတော်တဆတည်ငြိမ်ပေါ်မှာဤ module အတွက်ရရှိနိုင်ဖန်ဆင်းတယ်ဘာလို့လဲဆိုတော့တချို့ကလုပ်ဆောင်ချက်များကိုဤနေရာတွင်သတ်မှတ်ကြပါတယ်။
// <https://github.com/rust-lang/rust/issues/15702> ကိုကြည့်ပါ။
// (`transmute` လည်းဤအမြိုးအစားသို့ကျရောက်ပေမယ့် `T` နှင့် `U` အတူတူပင်အရွယ်အစားရှိသည်သောစစ်ဆေးမှုများကြောင့်ပတ်ရစ်မနိုင်ပါ။)
//

/// `ptr` စနစ်တကျ `align_of::<T>()` မှလေးစားမှုနှင့်အတူ aligned ဖြစ်ပါတယ်ရှိမရှိစစ်ဆေးမှုများ။
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// မိတ္တူ `count *size_of::<T>()` `src` ထံမှ `dst` မှ bytes ။အဆိုပါအရင်းအမြစ်နှင့်ဦးတည်ရာကိုမဖြစ်မနေ* မဟုတ် * ထပ်။
///
/// ထပ်စေခြင်းငှါ, ရာမှတ်ဉာဏ်၏ဒေသများတွင်အဘို့, အစား [`copy`] ကိုအသုံးပြုပါ။
///
/// `copy_nonoverlapping` semantically သည် C's [`memcpy`] နှင့်ညီမျှသည်။ သို့သော် argument order ကိုလဲလှယ်သည်။
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// အောက်ပါအခြေအနေများမဆိုချိုးဖောက်လျှင်အပြုအမူ undefined သည်:
///
/// * `src` `count * size_of::<T>()` bytes ၏ဖတ်ဘို့ [valid] ဖြစ်ရမည်။
///
/// * `dst` `count * size_of::<T>()` bytes ရေးအတှကျအ [valid] ဖြစ်ရမည်။
///
/// * `src` နှင့် `dst` နှစ်ဦးစလုံးစနစ်တကျ aligned ရပါမည်။
///
/// * count က `တစ်ဦးရဲ့အရွယ်အစားနှင့်အတူ `src` မှာမှတ်ဉာဏ်အစအဦး၏ဒေသ *
///   size_of: :<T>() `တူညီတဲ့အရွယ်အစားနှင့်အတူ `dst` မှာမှတ်ဉာဏ်အစအဦး၏ဒေသနှင့်အတူမဖြစ်မနေ *မဟုတ်* ထပ်တူ bytes ။
///
/// [`read`] ကဲ့သို့ပင် `copy_nonoverlapping` မသက်ဆိုင် `T` [`Copy`] ရှိမရှိ၏, `T` တစ် bitwise မိတ္တူဖန်တီးပေးပါတယ်။
/// အကယ်၍ `T` [`Copy`] မဟုတ်ပါက *နှစ်မျိုးလုံး* ကို အသုံးပြု၍ `*src` မှစတင်သောဒေသနှင့် `* dst` မှစတင်သောဒေသသည် [violate memory safety][read-ownership] နိုင်သည်။
///
///
/// ပင်ထိထိရောက်ရောက်ကူးယူအရွယ်အစားလျှင် (`* size_of ရေတွက်ကြောင်းမှတ်ချက်: :<T>()`) သည် `0` ဖြစ်သည်။ ညွှန်ပြသည် non-null ဖြစ်ရမည်။
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// ကိုယ်တိုင် [`Vec::append`] အကောင်အထည်ဖော်ရန်:
///
/// ```
/// use std::ptr;
///
/// /// `src` သွန်ထွက်ခွာ `dst` သို့ `src` အပေါငျးတို့သ element တွေကိုလှုံ့ဆော်ပေး။
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // `dst` `src` အပေါငျးတို့သကိုင်ထားဖို့လုံလောက်တဲ့စွမ်းရည်ရှိကြောင်းသေချာစစ်ဆေးပါ။
///     dst.reserve(src_len);
///
///     unsafe {
///         // `Vec` `isize::MAX` bytes ထက်ပိုမိုခွဲဝေချထားပေးရန်ဘယ်တော့မှလိမ့်မယ်ဘာဖြစ်လို့လဲဆိုတော့ offset မှခေါ်ဆိုမှုအမြဲလုံခြုံဖြစ်ပါတယ်။
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // သူ့ရဲ့အကြောင်းအရာတွေကိုကျဆင်းနေခြင်းမရှိဘဲခြင်းကို `src` ။
///         // ကျနော်တို့နောက်ထပ် panics ချကိစ္စတွင်တစ်ခုခုအတွက်ပြဿနာများကိုရှောင်ရှားရန်, ဒီပထမဦးဆုံးလုပ်ပါ။
///         src.set_len(0);
///
///         // mutable ကိုးကား alias ကိုမကျင့်, နှစ်ခုကွဲပြားခြားနားသော vectors အတူတူပင်မှတ်ဉာဏ်မပိုင်ဆိုင်နိုင်သောကြောင့်နှစ်ဦးဒေသများထပ်လို့မရပါဘူး။
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // ယခု `src` ၏မာတိကာကိုသိမ်းထားပြီ `dst` ကိုအသိပေးပါ။
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: သာပြေးအချိန်တွင်ဤအစစ်ဆေးမှုများလုပ်ဆောင်
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // သေးငယ် codegen သက်ရောက်မှုကိုစောင့်ရှောက်ရန်စိုးရိမ်မမ။
        abort();
    }*/

    // လုံခြုံမှု: `copy_nonoverlapping` များအတွက်လုံခြုံမှုစာချုပ်ဖြစ်ရပါမည်
    // အဆိုပါခေါ်ဆိုမှုများကထောကျခံခဲ့။
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// မိတ္တူ `count * size_of::<T>()` `src` ထံမှ `dst` မှ bytes ။အဆိုပါအရင်းအမြစ်နှင့်ဦးတည်ရာကိုထပ်ဖြစ်နိုင်တယ်။
///
/// အရင်းအမြစ်နှင့် ဦး တည်ရာသည် * ဘယ်တော့မျှထပ်နေသည်မဟုတ်ပါက၎င်းအစား [`copy_nonoverlapping`] ကိုသုံးနိုင်သည်။
///
/// `copy` C ရဲ့ [`memmove`] မှဝေါဟာရအသုံးအနှုံးနှင့်ညီမျှဖြစ်တယ်, ဒါပေမဲ့ဖလှယ်မှုဟာငြင်းခုံနိုင်ရန်နှင့်အတူ။
/// အဆိုပါ bytes ယာယီခင်းကျင်းဖို့ `src` ကနေကူးယူပြီးတော့ `dst` ဖို့ခင်းကျင်းထဲကနေကူးယူခဲ့ကြသည်လျှင်အဖြစ်ကူးယူခြင်းရာအရပျကြာပါသည်။
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// အောက်ပါအခြေအနေများမဆိုချိုးဖောက်လျှင်အပြုအမူ undefined သည်:
///
/// * `src` `count * size_of::<T>()` bytes ၏ဖတ်ဘို့ [valid] ဖြစ်ရမည်။
///
/// * `dst` `count * size_of::<T>()` bytes ရေးအတှကျအ [valid] ဖြစ်ရမည်။
///
/// * `src` နှင့် `dst` နှစ်ဦးစလုံးစနစ်တကျ aligned ရပါမည်။
///
/// [`read`] ကဲ့သို့ပင် `copy` မသက်ဆိုင် `T` [`Copy`] ရှိမရှိ၏, `T` တစ် bitwise မိတ္တူဖန်တီးပေးပါတယ်။
/// `T` `*dst` လုပ်နိုင်တဲ့ [violate memory safety][read-ownership] မှာစတင် `* src` နှင့်ဒေသတွင်းမှာစတင်ဒေသတွင်း၌နှစ်ဦးစလုံးတန်ဖိုးများကိုသုံးပြီး [`Copy`] မပါလျှင်။
///
///
/// ပင်ထိထိရောက်ရောက်ကူးယူအရွယ်အစားလျှင် (`* size_of ရေတွက်ကြောင်းမှတ်ချက်: :<T>()`) သည် `0` ဖြစ်သည်။ ညွှန်ပြသည် non-null ဖြစ်ရမည်။
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// မလုံခြုံသောကြားခံမှ Rust vector ကိုထိရောက်စွာဖန်တီးပါ။
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` မှန်ကန်စွာယင်း၏အမျိုးအစားနှင့် Non-သုညအဘို့အ aligned ရပါမည်။
/// /// * `ptr` အမျိုးအစား `T` ၏ `elts` တဆက်တည်းဒြပ်စင်၏ဖတ်များအတွက်တရားဝင်ဖြစ်ရပါမည်။
/// /// * သူများသည် element များကို `T: Copy` မဟုတ်လျှင်ဒီ function ကိုခေါ်ပြီးနောက်အသုံးမပြုရ။
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // လုံခြုံမှု: ကျွန်ုပ်တို့၏မရှိမဖြစ်လိုအပ်ချက်အရင်းအမြစ် aligned နှင့်တရားဝင်ဖြစ်ပါတယ်သေချာ,
///     // နှင့် `Vec::with_capacity` ငါတို့သည်သူတို့ရေးသားဖို့အသုံးဝင်အာကာသရှိသည်သေချာ။
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // လုံခြုံမှု: ကျနော်တို့အစောပိုင်းကဒီအများကြီးစွမ်းရည်နှင့်အတူကဖန်တီး,
///     // နှင့်ယခင် `copy` သည်ဤဒြပ်စင်နသိရသည်။
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: သာပြေးအချိန်တွင်ဤအစစ်ဆေးမှုများလုပ်ဆောင်
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // သေးငယ် codegen သက်ရောက်မှုကိုစောင့်ရှောက်ရန်စိုးရိမ်မမ။
        abort();
    }*/

    // လုံခြုံမှု: `copy` များအတွက်လုံခြုံမှုစာချုပ်အဆိုပါခေါ်ဆိုမှုများကထောကျခံခဲ့ရမည်ဖြစ်သည်။
    unsafe { copy(src, dst, count) }
}

/// `count * size_of::<T>()` `val` မှ `dst` မှာစတင်မှတ်ဉာဏ်၏ bytes ကိုသတ်မှတ်ပေးသည်။
///
/// `write_bytes` C's [`memset`] နှင့်ဆင်တူသော်လည်း `count * size_of::<T>()` bytes ကို `val` ဟုသတ်မှတ်သည်။
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// အောက်ပါအခြေအနေများမဆိုချိုးဖောက်လျှင်အပြုအမူ undefined သည်:
///
/// * `dst` `count * size_of::<T>()` bytes ရေးအတှကျအ [valid] ဖြစ်ရမည်။
///
/// * `dst` စနစ်တကျ aligned ရပါမည်။
///
/// ထို့အပြင်အဆိုပါခေါ်ဆိုမှု `count * size_of::<T>()` ရေးသားခြင်း `T` ၏ခိုင်လုံသောတန်ဖိုးမှတ်ဉာဏ်ရလဒ်များပေးထားသောဒေသမှ bytes သေချာရပေမည်။
/// `T` ၏မမှန်ကန်တဲ့တန်ဖိုးများပါ ၀ င်သည့် `T` အဖြစ်ရိုက်ထည့်သည့်မှတ်ဉာဏ်undရိယာတစ်ခုကိုအသုံးပြုခြင်းသည်အပြုအမူဖြစ်သည်။
///
/// ပင်ထိထိရောက်ရောက်ကူးယူအရွယ်အစားလျှင် (`* size_of ရေတွက်ကြောင်းမှတ်ချက်: :<T>()`) `0` ဖြစ်ပါသည်, ထို pointer ကို Non-null နဲ့စနစ်တကျ aligned ဖြစ်ရမည်။
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// အခြေခံအသုံးပြုမှု-
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// တစ်မမှန်ကန်တဲ့တန်ဖိုးကို Creating:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // တရားမဝင်သော pointer အတူ `Box<T>` overwrite လုပ်နိုင်တဲ့အားဖြင့်ယခင်ကကျင်းပတန်ဖိုးကို leaks ။
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // ဤအချက်မှာ `v` သုံးပြီးသို့မဟုတ်ကျဆင်းနေ undefined အပြုအမူအတွက်ရလဒ်များ။
/// // drop(v); // ERROR
///
/// // `v` "uses" ကိုယိုစိမ့်အောင်တောင်မှဒီအရာသည်သတ်မှတ်ထားသောအပြုအမူဖြစ်သည်။
/// // mem::forget(v); // ERROR
///
/// // တကယ်တော့ `v` သည်အခြေခံအမျိုးအစား layout invariants အရမမှန်ကန်ပါ။ ထို့ကြောင့်ထိမိသည့်မည်သည့်လုပ်ဆောင်မှုသည်မသတ်မှတ်ထားသောအပြုအမူဖြစ်သည်။
/////
/// // ကုန်အံ့ v2 =v;//အမှား
///
/// unsafe {
///     // ခိုင်လုံသောတန်ဖိုးထည့်သွင်းကြပါစို့
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // အခု box ကအဆင်ပြေပါတယ်
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // လုံခြုံမှု: `write_bytes` များအတွက်လုံခြုံမှုစာချုပ်အဆိုပါခေါ်ဆိုမှုများကထောကျခံခဲ့ရမည်ဖြစ်သည်။
    unsafe { write_bytes(dst, val, count) }
}