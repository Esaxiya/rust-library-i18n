//! panics ၏အကောင်အထည်ဖော်ရေး (အချို့ပုံစံအတွက်) libgcc/libunwind ကျောထောက်နောက်ခံ။
//!
//! ခြွင်းချက်ကိုင်တွယ်နှင့် stack unwinding အပေါ်နောက်ခံများအတွက် "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) နှင့်ကနေဆက်နွယ်နေစာရွက်စာတမ်းများကိုကြည့်ပါ။
//! ဤရွေ့ကားကိုလည်းကောင်းသောဖတ်ဖြစ်ကြသည်:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## အကျဉ်းချုပ်
//!
//! ခြွင်းချက်ကိုင်တွယ်ခြင်းကိုအဆင့်နှစ်ဆင့်: ရှာဖွေရေးအဆင့်နှင့်သန့်ရှင်းရေးအဆင့်များဖြစ်သည်။
//!
//! နှစ်ဦးစလုံးအဆင့်အတွက် unwinder လက်ရှိဖြစ်စဉ်ကိုရဲ့ module တွေ၏ stack ဘောင် unwind ကဏ္ဍများအနေဖြင့်သတင်းအချက်အလက်သုံးပြီးအောက်ခြေထိပ်မှ stack ဘောင်လမ်းလျှောက် (ဤနေရာတွင် "module" ဆိုလိုသည်မှာတစ်ဦးက executable တစ်ခုသို့မဟုတ်ပြောင်းလဲနေသောစာကြည့်တိုက်တစ်ခု OS ကို module တစ်ခုကိုရည်ညွှန်းသည်) ။
//!
//!
//! stack frame တစ်ခုစီအတွက်သက်ဆိုင်တဲ့ "personality routine" ကိုအသုံးပြုပြီး၎င်းရဲ့လိပ်စာကို unwind info section မှာလည်းသိမ်းထားသည်။
//!
//! ရှာဖွေရေးအဆင့်မှာတော့တစ်ဦးကိုယ်ရည်ကိုယ်သွေးလုပ်ရိုးလုပ်စဉ်များ၏အလုပ်အကိုင်အပစ်ချခံရခြွင်းချက်အရာဝတ္ထုဆနျးစစျဖို့, က stack ဘောင်မှာဖမ်းမိထားရမည်ရှိမရှိဆုံးဖြတ်ဖို့ဖြစ်ပါတယ်။အဆိုပါ handler ကိုဘောင်ဖော်ထုတ်လျက်ရှိသည်ပြီးတာနဲ့ cleanup အဆင့်ကစတင်ခဲ့သည်။
//!
//! သန့်ရှင်းစင်ကြယ်မှုအဆင့်တွင်၊
//! ဤတစ်ကြိမ်တွင်လက်ရှိ stack frame အတွက်မည်သည့် (ရှိခဲ့လျှင်) cleanup ကုဒ်ကို run ရန်ဆုံးဖြတ်သည်။သို့ဆိုလျှင်ထိန်းချုပ်မှုသည်လုပ်ဆောင်မှုကိုယ်ထည်ရှိအထူး branch သို့ပို့ဆောင်ပေးသည်။ "landing pad" သည်ဖျက်ဆီးသူများကိုခေါ်သည်၊ မှတ်ဉာဏ်လွတ်စေသည်။
//! ဆင်းသက် pad ၏အဆုံးမှာထိန်းချုပ်မှုပြန် unwinder နှင့် unwinding ပြန်လည်စတင်သို့လွှဲပြောင်းပေးသည်။
//!
//! stack အဆိုပါ handler ကိုဘောင်အဆင့်အထိ unwound ဆင်းခဲ့ပြီးတာနဲ့ unwinding မှတ်တိုင်များနှင့်နောက်ဆုံးကိုယ်ရည်ကိုယ်သွေးလုပ်ရိုးလုပ်စဉ်လွှဲပြောင်းအဆိုပါဖမ်းလုပ်ကွက်မှထိန်းချုပ်ထားသည်။
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Rust ၏ချွင်းချက်လူတန်းစားအမှတ်အသား။
// ၎င်းကိုကိုယ်လက်အင်္ဂါလုပ်ရိုးလုပ်စဉ်များကအသုံးပြုသည်။
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 သံချေး-ရောင်းချသူ၊ ဘာသာစကား
    0x4d4f5a_00_52555354
}

// ဗိသုကာတစ်ခုစီအတွက် LLVM ၏ TargetLowering::getExceptionPointerRegister() နှင့် TargetLowering::getExceptionSelectorRegister() မှမှတ်ပုံတင်နံပါတ်များကိုရုပ်သိမ်းခဲ့ပြီးနောက်မှတ်ပုံတင်သတ်မှတ်ချက်ဇယားများမှတဆင့် DWARF မှတ်ပုံတင်နံပါတ်များကိုဆက်စပ်ခဲ့သည်။<arch>RegisterInfo.td, "DwarfRegNum" များအတွက်ရှာဖွေရေး) ။
//
// http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register ကိုလည်းရှုပါ။
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// အောက်ပါကုဒ်သည် GCC ၏ C နှင့် C++ ကိုယ်ရည်ကိုယ်သွေးလုပ်ရိုးလုပ်စဉ်များကိုအခြေခံသည်။ကိုးကားတွေ့:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM EHABI ကိုယ်ရည်ကိုယ်သွေးလုပ်ရိုးလုပ်စဉ်။
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS က unwinding SjLj ကိုအသုံးပြုစဉ်ကတည်းကအစားကို default လုပ်ရိုးလုပ်စဉ်များကိုအသုံးပြုသည်။
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // ARM ရှိ backtraces များသည်ကိုယ်ကိုယ်တိုင်လုပ်ရိုးလုပ်စဉ်ကို state နှင့်==_US_VIRTUAL_UNWIND_FRAME ဖြင့်ခေါ်လိမ့်မည်။_US_FORCE_UNWIND ။
                // ထိုအခြေအနေမျိုးတွင်ကျွန်ုပ်တို့သည် stack ကိုပြန်ဖွင့်လိုသည်။ သို့မဟုတ်ပါကကျွန်ုပ်တို့၏ backtraces အားလုံးသည် __rust_try တွင်အဆုံးသတ်လိမ့်မည်
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // အဆိုပါထောင်ပြီး unwinder က ARM EHABI ချွင်းချက်အရာဝတ္ထုသို့သူတို့ကိုငါနေရာသို့သော် _Unwind_Context, ထို function ကိုနဲ့တူသောအရာတို့ကိုနှင့် LSDA ထောက်ပြရရှိထားသူသည်ယူဆတယ်။
            // context pointer ကိုသာယူသော _Unwind_GetLanguageSpecificData() ကဲ့သို့သောလုပ်ဆောင်ချက်များ၏ signatures ကိုထိန်းသိမ်းရန် GCC ကိုယ်ရည်ကိုယ်သွေးလုပ်ရိုးလုပ်စဉ်များသည် ARM ၏ "scratch register" (r12) အတွက်သိုလှောင်ထားသည့်နေရာကို အသုံးပြု၍ context_object မှ pointer ကိုပိတ်ထားသည်။
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... တစ်ဦးထက်ပိုသော principled ချဉ်းကပ်ကျွန်တော်တို့ရဲ့ libunwind ခညျြနှောငျအတွက် ARM ရဲ့ _Unwind_Context အပြည့်အဝနှင့်အဓိပ္ပါယ်များကိုထောင်ပြီး Compatibility ကိုလုပ်ဆောင်ချက်များကိုကျော်လွှားတိုက်ရိုက်ထိုအရပ်မှလိုအပ်သောဒေတာများကိုဆွဲယူဖို့ဖြစ်ပါလိမ့်မည်။
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI သည် SP object ကို SP တန်ဖိုးအားအတားအဆီးရှိအရာဝတ္ထု၏အတားအဆီးတွင် update လုပ်ရန်လိုအပ်သည်။
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // က ARM EHABI တွင်ကိုယ်ရည်ကိုယ်သွေးလုပ်ရိုးလုပ်စဉ်ကတကယ်တော့ (က ARM EHABI အတွင်းရေးမှူးပြန်မီတစ်ခုတည်း stack ဘောင် unwinding များအတွက်တာဝန်ရှိသည်။
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // libgcc မှာသတ်မှတ်ပါတယ်
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // SEH မှတဆင့် Windows x86_64 တွင်တိုက်ရိုက်ပစ်မှတ်ထားပြီးသွယ်ဝိုက်သောပုံမှန်ကိုယ်ရည်ကိုယ်သွေးပုံမှန်လုပ်ရိုးလုပ်စဉ်။
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // x86_64 MinGW ပစ်မှတ်တွင် unwinding ယန္တရား SEH သို့သော် (LSDA ခေါ်) ကို unwind handler ကိုဒေတာ GCC-သဟဇာတ encoding ကကိုအသုံးပြုသည်။
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // ကျွန်ုပ်တို့၏ပစ်မှတ်အများစုအတွက်ကိုယ်ရည်ကိုယ်သွေးလုပ်ရိုးလုပ်စဉ်။
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // ပြန်လာသည့်လိပ်စာသည် LSDA အကွာအဝေးဇယားရှိနောက်ထပ် IP အကွာအဝေးတွင်ရှိသောဖြစ်နိုင်သည့်ခေါ်ဆိုမှုညွှန်ကြားချက်ကိုကျော်လွန်ပြီး 1 byte ဖြစ်သည်။
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// အချက်အလက်ကိုမှတ်ပုံတင် unwind Frame
//
// တစ်ခုချင်းစီကိုမော်ကျူးရဲ့ပုံရိပ်တစ်ဦးသည် frame unwind အချက်အလက်အပိုင်း (များသောအားဖြင့် ".eh_frame") ပါရှိသည်။module တစ်ခုသည်လုပ်ငန်းစဉ်အတွင်းသို့ loaded/unloaded ဖြစ်သည့်အခါမှတ်ဉာဏ်ထဲရှိဤအပိုင်း၏တည်နေရာနှင့် ပတ်သက်၍ unwinder ကိုအကြောင်းကြားရမည်။ကြောင်းရရှိ၏နည်းလမ်းများပလက်ဖောင်းအားဖြင့်ကွဲပြားခြားနား။
// အချို့ (ဥပမာ Linux) တွင် unwinder သည် dynamically လက်ရှိတွင် dl_iterate_phdr() API and finding their ".eh_frame" sections) ကနေတဆင့်တင် module တွေ enumerating အားဖြင့် (၎င်း၏ကိုယ်ပိုင်အပေါ် unwind အင်ဖိုကဏ္ဍများကိုရှာဖွေတွေ့ရှိနိုင်ပါတယ်; အခြားသူများ, Windows လိုပဲတက်တက်ကြွကြွ unwinder API မှတစ်ဆင့်သူတို့ရဲ့ unwind အင်ဖိုကဏ္ဍများမှတ်ပုံတင်ရန် module တွေလိုအပ်သည်။
//
//
// ဤ module သည်ကျွန်ုပ်တို့၏အချက်အလက်များကို GCC runtime runtime တွင်မှတ်ပုံတင်ရန်ရည်ညွှန်းပြီး rsbegin.rs မှခေါ်သောသင်္ကေတနှစ်ခုဖြစ်သည်။
// stack unwinding ၏အကောင်အထည်ဖော်မှုသည်ယခုအချိန်တွင် libgcc_eh သို့ရွှေ့ဆိုင်းလိုက်သော်လည်း Rust crates သည်မည်သည့် GCC runtime နှင့်မဆိုဖြစ်ပွားနိုင်သည့်ပashesိပက္ခများကိုရှောင်ရှားရန် Rust-specific entry point များကိုအသုံးပြုသည်။
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}