//! *emscripten* ပစ်မှတ်များအတွက်ဖြည်။
//!
//! တိုက်ရိုက် libunwind APIs များကိုသို့ Unix ပလက်ဖောင်းခေါ်ဆိုမှုများအတွက် Rust ရဲ့ပုံမှန်အတိုင်း unwinding အကောင်အထည်ဖော်မှုသွားရမည်အကြောင်း, Emscripten အပေါ်ကျနော်တို့အစား C++ unwinding APIs များကိုသို့ခေါ်ဆိုပါ။
//! Emscripten ၏ runtime runtime များသည် API များကိုအမြဲတမ်း သုံး၍ libunwind ကိုမအကောင်အထည်ဖော်သောကြောင့်၎င်းသည်အသုံးဝင်သည်။
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// ဤသည်မှာ C++ ရှိ std::type_info ၏အပြင်အဆင်နှင့်ကိုက်ညီသည်
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // ဤနေရာတွင် ဦး ဆောင်နေသော `\x01` byte သည် LLVM အတွက်မှော်ဆန်သောအချက်ပြတစ်ခုဖြစ်သည်။
    //
    //
    // ဤသင်္ကေတသည် C++ ၏ `std::type_info` အသုံးပြုသော vtable ဖြစ်သည်။
    // `std::type_info` အမျိုးအစား၊ descriptors အမျိုးအစားများတွင်ဤဇယားတွင် pointer တစ်ခုရှိသည်။
    // အမျိုးအစားဖော်ပြချက်ကိုအထက်တွင်ဖော်ပြထားသော C++ EH ပုံစံများနှင့်ရည်ညွှန်းပြီးကျွန်ုပ်တို့ဆောက်လုပ်သည်။
    //
    // အစစ်အမှန်အရွယ်အစား 3 usize ထက်ပိုကြီးတဲ့, ဒါပေမဲ့ကျွန်တော်သာအမှတ်တတိယဒြပ်စင်ဖို့ကျွန်တော်တို့ရဲ့ vtable လိုအပျကွောငျးမှတ်ချက်။
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info တစ်ဦး rust_panic လူတန်းစားများအတွက်
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // ပုံမှန်အားဖြင့်ကျွန်ုပ်တို့သည် .as_ptr().add(2) ကိုသုံးမည်ဖြစ်သော်လည်း၎င်းသည် const အခြေအနေတွင်အလုပ်မလုပ်ပါ။
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // C ++ သည် Rust panics ကိုထုတ်လုပ်ခြင်းသို့မဟုတ်ဖမ်းဆီးခြင်းကိုအလိုမရှိသောကြောင့်၎င်းသည်ရည်ရွယ်ချက်ရှိရှိပုံမှန်အမည် mangling အစီအစဉ်ကိုအသုံးမပြုပါ။
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // အဘယ်ကြောင့်ဆိုသော် C++ ကုဒ်သည်ကျွန်ုပ်တို့၏ execption ကို std::exception_ptr ဖြင့်သိမ်းဆည်းပြီး၎င်းကိုအခြားချည်တစ်ခုတွင်ပင်အကြိမ်ပေါင်းများစွာပြန်လည်တည်ဆောက်ပေးသောကြောင့်ဖြစ်သည်။
    //
    //
    caught: AtomicBool,

    // ဘာလို့လဲဆိုတော့ object ရဲ့သက်တမ်းဟာ C++ semantics အတိုင်းပဲဖြစ်တယ်။ catch_unwind က Box ကို Exception ကနေရွှေ့လိုက်တဲ့အချိန်မှာ၊ အဲ့ဒီ့ object ကို valid state မှာထားခဲ့ရမယ်။ ဘာလို့လဲဆိုတော့သူ့ရဲ့ destructor ကို __cxa_end_catch ကခေါ်တော့မယ့်။
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try တကယ်တော့ကျွန်တော်တို့ကိုဒီဖွဲ့စည်းပုံကိုညွှန်ပြပေးတယ်။
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // cleanup() ကို panic အားခွင့်မပြုသောကြောင့်ကျွန်ုပ်တို့ဖျက်သိမ်းလိုက်သည်။
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}