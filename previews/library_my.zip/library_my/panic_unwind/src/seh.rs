//! Windows SEH
//!
//! Windows (လက်ရှိ MSVC တွင်သာ) တွင်၊ ပုံမှန်ချွင်းချက်ကိုင်တွယ်သည့်ယန္တရားမှာဖွဲ့စည်းထားသည့်ချွင်းချက်ကိုင်တွယ်ခြင်း (SEH) ဖြစ်သည်။
//! ၎င်းသည် Dwarf အခြေပြုခြွင်းချက်ကိုင်တွယ်ခြင်း (ဥပမာ၊ အခြား unix ပလက်ဖောင်းများအသုံးပြုသော) compiler internals နှင့်ကွဲပြားခြားနားသည်။ ထို့ကြောင့် LLVM သည် SEH အတွက်အပိုအထောက်အပံ့များစွာလိုအပ်သည်။
//!
//! တစ်မ့်မှုတွေကြုံတွေ့ရတှငျအဘယျကဒီမှာဖြစ်ပျက်ဖြစ်ပါသည်:
//!
//! 1. အဆိုပါ unwinding ဖြစ်စဉ်ကိုထွက်လာပါတယ်, ခြွင်းချက်နဲ့တူ-အ `panic` function ကိုတစ်ဦးက C++ ပစ်ခြင်းငှါစံ Windows function ကို `_CxxThrowException` တောင်းဆိုထားသည်။
//! 2.
//! Windows အတွက် compiler အသုံးပြုမှုကိုယ်ရည်ကိုယ်သွေး function ကို `__CxxFrameHandler3` သည် CRT အတွက် function ကို, နှင့် unwinding code ကနေထုတ်လုပ်လိုက်တဲ့အားလုံးဆင်းသက် pads အဆိုပါ stack ပေါ်မှာရှိသမျှ cleanup code တွေနဲ့စီမံရန်ဤကိုယ်ရည်ကိုယ်သွေး function ကိုသုံးပါလိမ့်မယ်။
//!
//! 3. `invoke` အားလုံးကို compiler-generated ဖုန်းခေါ်ဆိုမှုအတွက် cleanup လုပ်ရိုးလုပ်စဉ်များစတင်ညွှန်ပြသည့် `cleanuppad` LLVM နည်းဥပဒေအဖြစ်ဆင်းသက် pad ပါအစုံရှိသည်။
//! ကိုယ်ရည်ကိုယ်သွေး (CRT တွင်သတ်မှတ်ထားသောအဆင့် ၂ တွင်) သန့်ရှင်းရေးလုပ်ထုံးလုပ်နည်းများကိုတာဝန်ယူရန်ဖြစ်သည်။
//! 4. နောက်ဆုံးတော့ (အ compiler ကနေထုတ်လုပ်လိုက်တဲ့) ကို `try` အခ်ါအတွက် "catch" ကုဒ်ကွပ်မျက်ခံရနှင့်ထိန်းချုပ်မှု Rust မှပြန်လာသင့်တယ်ဆိုတာကိုပြသနေသည်။
//! ၎င်းကို LLVM IR အသုံးအနှုန်းများတွင် `catchswitch` ပေါင်း `catchpad` ညွှန်ကြားချက်မှတဆင့်လုပ်ဆောင်ပြီးနောက်ဆုံးတွင် `catchret` ညွှန်ကြားချက်ဖြင့်ပုံမှန်ထိန်းချုပ်မှုကိုပြန်ပို့သည်။
//!
//! gcc-based ခြွင်းချက်ကိုင်တွယ်မှုနှင့်ကွဲပြားခြားနားသောအချက်များမှာ-
//!
//! * Rust မျှထုံးစံကိုယ်ရည်ကိုယ်သွေး function ကိုရှိပါတယ်, ဒါကြောင့် *အစဉ်အမြဲအစား*`__CxxFrameHandler3` ဖြစ်ပါတယ်။ထို့အပြင်အပို filtering လုပ်ခြင်းကိုမပြုလုပ်သောကြောင့်ကျွန်ုပ်တို့လွှင့်နေသောအမျိုးအစားနှင့်တူသော C++ ခြွင်းချက်များကိုဖမ်းယူနိုင်သည်။
//! သတိပြုရန်မှာခြွင်းချက်တစ်ခုအား Rust ထဲသို့လွှင့်ပစ်ခြင်းသည်မည်သို့ပင်ဖြစ်စေမသတ်မှတ်ထားသောအပြုအမူဖြစ်သည်၊ ထို့ကြောင့်၎င်းသည်ကောင်းမွန်သင့်သည်။
//! * ကျနော်တို့ unwinding နယ်နိမိတ်, အထူးသတဲ့ `Box<dyn Any + Send>` ဖြတ်ပြီးထုတ်လွှင့်အချို့ဒေတာရရှိပါသည်။Dwarf ခြွင်းချက်များကဲ့သို့ပင်ဤညွှန်ပြချက်နှစ်ခုသည်ချွင်းချက်ကိုယ်နှိုက်တွင် payload အဖြစ်သိမ်းဆည်းထားသည်။
//! MSVC တွင်၊ သို့သော်၊ လုပ်ဆောင်မှုလုပ်ဆောင်နေစဉ် call stack ကိုထိန်းသိမ်းထားသောကြောင့်အပိုပုံကြီးချဲ့ရန်မလိုအပ်ပါ။
//! အဆိုပါထောက်ပြထို့နောက် `try` အခ်ါဒ stack frame ကိုရေးသားခံရဖို့အတွက် filter function ကိုအတွက်ပြန်လည်ကောင်းမွန်ထားတဲ့ `_CxxThrowException` တိုက်ရိုက်လွန်နေကြသည်သောဤနည်းလမ်းများ။
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // ဒါဟာလိုအပ်ချက်ကျနော်တို့ကိုကိုးကားအားဖြင့်ခြွင်းချက်ဖမ်းနှင့်၎င်း၏ destructor ဟာ C++ runtime ကကွပ်မျက်ကြောင့်တစ်ဦး Option ကိုဖြစ်။
    // Box ကို Exception မှထုတ်ယူသောအခါ Box ကို Double-Drop မပါဘဲ run ရန်သူ၏ဖျက်ဆီးခြင်းကိုခိုင်လုံသောအခြေအနေတွင်ထားရန်လိုအပ်သည်။
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// ပထမ ဦး စွာအမျိုးအစားသတ်မှတ်ချက်တစ်ခုလုံး။ဤနေရာတွင်ပလက်ဖောင်းနှင့်သက်ဆိုင်သောထူးခြားချက်အချို့ရှိပြီး LLVM မှပြောင်ပြောင်တင်းတင်းကူးယူထားသည့်အရာများစွာရှိသည်။ဤအမှုအလုံးစုံ၏ရည်ရွယ်ချက်မှာ `_CxxThrowException` မှဖုန်းခေါ်မှတဆင့်အောက်က `panic` function ကိုအကောင်အထည်ဖေါ်ရန်ဖြစ်ပါသည်။
//
// ဒီ function နှစ်ခုအငြင်းပွားမှုများကြာပါသည်။ပထမတစ်ခုမှာကျွန်ုပ်တို့ပို့နေသောအချက်အလက်များကိုညွှန်ပြသည်။ ဤကိစ္စတွင် trait object ဖြစ်သည်။ရှာဖွေရန်တော်တော်လွယ်ကူပါတယ်!နောက်တစ်နေ့သို့သော်ပိုမိုရှုပ်ထွေးသည်။
// ၎င်းသည် `_ThrowInfo` ဖွဲ့စည်းပုံကိုညွှန်ပြသည်၊ ယေဘုယျအားဖြင့်၎င်းကိုချန်လှပ်ထားသည့်ခြွင်းချက်ကိုသာဖော်ပြရန်ရည်ရွယ်သည်။
//
// လောလောဆယ်ဒီ type [1] ၏အဓိပ္ပါယ်အနည်းငယ်အမွေးဖြစ်ပြီး, အဓိက oddity (နှင့်အွန်လိုင်းဆောင်းပါးကနေကွာခြားချက်) အပေါ် 32-bit အတွက်ထောက်ပြထောက်ပြကြသည်ဒါပေမယ့် 64-bit နဲ့အပေါ်ထောက်ပြမှ 32-bit နဲ့ offset အဖြစ်ထုတ်ဖော်ပြောဆိုနေကြပါတယ်ကြောင်း `__ImageBase` သင်္ကေတ။
//
// အောက်ဖော်ပြပါ modules များရှိ `ptr_t` နှင့် `ptr!` macro ကိုယင်းကိုဖော်ပြရန်အသုံးပြုသည်။
//
// အမျိုးအစားအဓိပ္ပာယ်ဖွင့်ဆိုချက်သည်ဤအမျိုးအစားအတွက် LLVM မှထုတ်လွှတ်သောအရာများကိုအနီးကပ်လိုက်နာသည်။ဥပမာသင်သည် CV ကုဒ်ကို MSVC ပေါ်တွင် စုစည်း၍ LLVM IR ထုတ်လွှတ်ပါက:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          x[2] uint64_t;};
//
//      ပျက်ပြယ် foo() { rust_panic a = {0, 1};
//          ပစ်;}
//
// ဒါကကျနော်တို့ emulator ဖို့ကြိုးစားနေပါတယ်အဘယျသို့မရှိမဖြစ်လိုအပ်တဲ့ပါပဲ။အောက်ဖော်ပြပါစဉ်ဆက်မပြတ်တန်ဖိုးအများစုကို LLVM မှကူးယူပြီးဖြစ်သည်။
//
// မည်သည့်အခြေအနေမျိုးတွင်မဆိုဤအဆောက်အအုံများကိုတူညီသောပုံစံဖြင့်ဆောက်လုပ်ထားပြီး၎င်းသည်ကျွန်ုပ်တို့အတွက်အနည်းငယ်မျှသာဖြစ်သည်။
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// ဤနေရာတွင် name mangling rules များကိုရည်ရွယ်ချက်ရှိရှိလျစ်လျူရှုထားကြောင်းသတိပြုပါ။`struct rust_panic` ကိုကြေငြာခြင်းအားဖြင့် C++ သည် Rust panics ကိုဖမ်းနိုင်မည်မဟုတ်ပါ။
//
//
// ပြုပြင်မွမ်းမံတဲ့အခါ, အမျိုးအစားအမည်အား string ကိုအတိအကျ `compiler/rustc_codegen_llvm/src/intrinsic.rs` များတွင်အသုံးပြုတကိုက်ညီသေချာကြောင်းပါစေ။
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // ဤနေရာတွင် ဦး ဆောင်နေသော `\x01` byte သည် LLVM အတွက်မှော်ဆန်သောအချက်ပြတစ်ခုဖြစ်သည်။
    //
    //
    // ဤသင်္ကေတသည် C++ ၏ `std::type_info` အသုံးပြုသော vtable ဖြစ်သည်။
    // `std::type_info` အမျိုးအစား၊ descriptors အမျိုးအစားများတွင်ဤဇယားတွင် pointer တစ်ခုရှိသည်။
    // အမျိုးအစားဖော်ပြချက်ကိုအထက်တွင်ဖော်ပြထားသော C++ EH ပုံစံများနှင့်ရည်ညွှန်းပြီးကျွန်ုပ်တို့ဆောက်လုပ်သည်။
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// ဤအမျိုးအစားဖော်ပြချက်သည်ချွင်းချက်တစ်ခုချသည့်အခါတွင်သာအသုံးပြုသည်။
// အဆိုပါဖမ်းတစ်စိတ်တစ်ပိုင်းကိုယ်ပိုင် TypeDescriptor ထုတ်ပေးသောပါအခ်ါကကိုင်တွယ်သည်။
//
// MSVC runtime သည် type name ကို pointer equity ထက် TypeDescriptors နှင့်တူညီရန် string နှိုင်းယှဉ်ခြင်းကိုသုံးသောကြောင့်ဤအရာသည်အဆင်ပြေပါသည်။
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// အဆိုပါ C++ code ကိုချွင်းချက်ဖမ်းယူကဝါဒဖြန့်ခြင်းမရှိဘဲက drop ရန်ဆုံးဖြတ်သည်လျှင် Destructor ကိုအသုံးပြုခဲ့သည်။
// try intrinsic ၏ catch တစ်စိတ်တစ်ပိုင်းသည်အဖျက်စွမ်းအား၏ပထမဆုံးစကားလုံးကို 0 ဖြစ်သွားစေကာ၎င်းကိုဖျက်ဆီးသူမှလွတ်သွားသည်။
//
// သတိပြုရန်မှာ x86 Windows သည်ပုံမှန်အားဖြင့် "C" ခေါ်ဆိုမှုစည်းဝေးခြင်းအစား C++ အဖွဲ့ဝင်လုပ်ဆောင်ချက်များအတွက် "thiscall" ခေါ်ဆိုမှုစည်းဝေးခြင်းကိုအသုံးပြုသည်။
//
// ဒီနေရာမှာ exception_copy function ကနည်းနည်းထူးခြားတယ်။ try/catch block အောက်မှာ MSVC runtime က invoke လုပ်တယ်။ ဒီမှာငါတို့ထုတ်လုပ်တဲ့ panic ကိုချွင်းချက်မိတ္တူ၏ရလဒ်အနေနှင့်အသုံးပြုလိမ့်မည်။
//
// ဒါကကျနော်တို့ Box ကိုဘာဖြစ်လို့လဲဆိုတော့ support မနိုင်သည့် std::exception_ptr နှင့်အတူခြွင်းချက်ဖမ်းယူထောက်ခံမှုပေးရန် C++ runtime, အသုံးပြု<dyn Any>clonable မဟုတ်ပါဘူး။
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // လုံးဝဒီ stack ဘောင်ပေါ် _CxxThrowException executes, ဒါမဟုတ်ရင်သည့်အမှိုက်ပုံမှ `data` လွှဲပြောင်းရန်မလိုအပ်ရှိပါတယ်။
    // ကျနော်တို့ဒီ function ကိုမှ stack pointer ကိုရှောက်။
    //
    // unwinding လုပ်သောအခါ Exception အားကျစေလိုခြင်းမရှိသောကြောင့်ဤနေရာတွင် ManuallyDrop လိုအပ်သည်။
    // ယင်းအစား၎င်းသည် C++ runtime မှတောင်းဆိုသော exception_cleanup အားဖြင့်ဖယ်ထုတ်လိမ့်မည်။
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // ဤသည် ... အံ့သြစရာများနှင့်တရားမျှတဒီတော့ဖြစ်နိုင်သည်။32-bit နဲ့ MSVC တွင်သောဤဖွဲ့စည်းပုံအကြားထောက်ပြရုံထောက်ပြသောဖြစ်ကြသည်။
    // သို့သော် 64-bit MSVC တွင်структурများအကြားညွှန်ပြချက်များကို `__ImageBase` မှ 32-bit offsets အဖြစ်ဖော်ပြသည်။
    //
    // အကျိုးဆက် 32-bit နဲ့ MSVC အပေါ်ကျနော်တို့အထက် `static`s အတွက်ဤအရာအလုံးစုံထောက်ပြကြေညာနိုင်ပါတယ်။
    // 64-bit MSVC တွင်၊ Rust သည်လက်ရှိတွင်ခွင့်မပြုသော statics တွင်ညွန်ကိန်းများ၏အနုတ်ကိုဖော်ပြရန်လိုသည်။
    //
    // နောက်တစ်နေ့အကောင်းဆုံးအရာ, ထို့နောက် (ထိတ်လဘာပဲဖြစ်ဖြစ်ထားပြီး "slow path" ဖြစ်ပါတယ်) runtime ကဤအဆောက်အဦများအတွက်ဖြည့်စွက်ရန်ဖြစ်ပါသည်။
    // ဒီတော့ဒီနေရာမှာဒီ pointer fields အားလုံးကို 32-bit integer အဖြစ်ပြန်ပြောင်းပြီးတော့သက်ဆိုင်ရာတန်ဖိုးကိုအဲ့ဒီထဲကိုသိုလှောင်သိမ်းဆည်းပါ။ (atomically, တစ်ပြိုင်နက်တည်း panics ဖြစ်ပျက်နေသလိုမျိုး) ။
    //
    // နည်းပညာပိုင်းအရ runtime သည်ဤနယ်ပယ်များကို nonatomic read လုပ်လိမ့်မည်ဖြစ်သော်လည်းသီအိုရီအရသူတို့သည် * မှားသောတန်ဖိုးကိုဘယ်တော့မှမဖတ်ခဲ့ကြသောကြောင့်၎င်းသည်အလွန်ဆိုးရွားခြင်းမရှိသင့်ပါ။
    //
    // မည်သည့်ကိစ္စတွင်ခုနှစ်, ကျနော်တို့အခြေခံအားဖြင့်ကျနော်တို့ static ပိုမိုစစ်ဆင်ရေးဖျောပွနိုငျ (နှင့်ကျွန်တော်နိုင်တော့မည်ဘယ်တော့မှဖြစ်နိုင်သည်) သည်အထိဤကဲ့သို့သောအရာတစ်ခုခုလုပ်ဖို့လိုအပ်ပါတယ်။
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // ဒီနေရာမှာတစ်ဦးက null payload ကျနော်တို့ __rust_try ၏ဖမ်း (...) ထံမှဤနေရာတွင်တယ်ဆိုလိုသည်။
    // non-Rust နိုင်ငံခြားချွင်းချက်ကိုဖမ်းမိသောအခါဤသို့ဖြစ်လိမ့်မည်။
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// ဤသည် (ဥပမာ, တက lang ကို item င်) တည်ရှိရန် compiler အားဖြင့်လိုအပ်ပါသည်, ဒါပေမယ့် __C_specific_handler သို့မဟုတ် _except_handler3 အမြဲအသုံးပြုသည်သောကိုယ်ရည်ကိုယ်သွေး function ကိုသောကြောင့်ထိုသို့အမှန်တကယ် compiler ဖြင့်သင့်ကိုခေါ်ဘယ်တော့မှရဲ့။
//
// ထို့ကြောင့်၎င်းသည်ဖျက်သိမ်းခြင်းသာဖြစ်သည်။
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}