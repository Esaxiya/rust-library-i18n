//! - Miri များအတွက် panics Unwinding ။
use alloc::boxed::Box;
use core::any::Any;

// ကျွန်တော်တို့အတွက် unwinding မှတဆင့် Miri အင်ဂျင်ပြန့်ပွားသော payload အမျိုးအစား။
// pointer-size ဖြစ်ရမည်။
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// စတင်ဖွင့်ရန် Miri မှထောက်ပံ့ပေးသောပြင်ပလုပ်ဆောင်ချက်။
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // `miri_start_panic` သို့ကျွန်ုပ်တို့ပို့သော payload သည်အောက်တွင်ဖော်ပြထားသော `cleanup` တွင်ရရှိသောအငြင်းပွားမှုဖြစ်လိမ့်မည်။
    // ရုံ pointer-size တစ်ခုခုရဖို့ရန်, တစ်ချိန်က up ပြုလုပ်သေတ္တာကျနော်တို့ဒါ။
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // နောက်ခံ `Box` ကိုပြန်လည်ရယူပါ။
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}