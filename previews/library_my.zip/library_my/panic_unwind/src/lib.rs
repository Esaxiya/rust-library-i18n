//! stack unwinding မှတဆင့် panics ၏အကောင်အထည်ဖော်မှု
//!
//! ဤသည် crate သည်ဤအတွက်ပြုစုထားသည့်ပလက်ဖောင်း၏ "most native" stack unwinding ယန္တရားကို အသုံးပြု၍ Rust တွင် panics ၏အကောင်အထည်ဖော်မှုဖြစ်သည်။
//! ဒါဟာမရှိမဖြစ်လိုအပ်တဲ့လက်ရှိသုံးပုံးသို့ခွဲခြားရရှိ:
//!
//! 1. MSVC ၏ပစ်မှတ်သည် SEH ကို `seh.rs` ဖိုင်တွင်အသုံးပြုသည်။
//! 2. Emscripten သည် X++ X ဖိုင်ရှိ C++ ခြွင်းချက်များကိုအသုံးပြုသည်။
//! 3. အခြားပစ်မှတ်အားလုံးသည် `gcc.rs` ဖိုင်တွင် libunwind/libgcc ကိုအသုံးပြုသည်။
//!
//! တစ်ဦးချင်းစီအကောင်အထည်ဖော်မှုနှင့် ပတ်သက်. ပိုမိုစာရွက်စာတမ်းများသက်ဆိုင်ရာ module မှာတွေ့ရှိနိုင်ပါတယ်။
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` Miri ကိုအသုံးမပြုတဲ့အတွက်သတိပေးချက်များကိုတိတ်ဆိတ်စွာနေပါ။
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Rust runtime ရဲ့ startup တ္ထုဒီတော့သူတို့ကိုလူထုစေ, ဤသင်္ကေတများပေါ်မူတည်သည်။
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // unwinding ကိုထောကျပံ့မပစ်မှတ်။
        // - arch=wasm32
        // - os=အဘယ်သူမျှမ ("bare metal" ပစ်မှတ်)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // အဆိုပါ-Miri runtime ကိုသုံးပါ။
        // rustc မှအချို့သော lang ပစ္စည်းများအားသတ်မှတ်ရန်မျှော်လင့်ထားသကဲ့သို့၊ အထက်တွင်ဖော်ပြထားသောပုံမှန် runtime ကိုလည်းကျွန်ုပ်တို့လိုအပ်သည်။
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // အစစ်အမှန် runtime ကိုသုံးပါ။
        use real_imp as imp;
    }
}

extern "C" {
    /// တစ်ဦး panic အရာဝတ္ထု `catch_unwind` ပြင်ပကျဆင်းသွားသောအခါ libstd အတွက် handler တောင်းဆိုခဲ့သည်။
    ///
    fn __rust_drop_panic() -> !;

    /// နိုင်ငံခြားခြွင်းချက်ဖမ်းမိသောအခါ libstd အတွက် handler တောင်းဆိုခဲ့သည်။
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// ချွင်းချက်တစ်ခုမြှင့်တင်ရန်အချက်အလတ်၊
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}