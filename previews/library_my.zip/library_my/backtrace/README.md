# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Rust များအတွက် runtime မှာ backtraces လေးလည်းများအတွက်တစ်ဦးကစာကြည့်တိုက်။
ဤစာကြည့်တိုက်သည်ပုံမှန်စာကြည့်တိုက်၏အထောက်အပံ့ကိုတိုးမြှင့်ပေးရန်ရည်ရွယ်သည်။ သူကအလုပ်လုပ်ရန်ပရိုဂရမ်မာ interface ကိုထောက်ပံ့ပေးသည်။ သို့သော် libstd's panics ကဲ့သို့သောလက်ရှိ backtrace ကိုအလွယ်တကူပုံနှိပ်နိုင်သည်။

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

backtrace တစ်ခုကိုရိုးရိုးရှင်းရှင်းရိုက်ယူပြီးနောက်မှ ပြန်၍ ကိုင်တွယ်ရန်ဆိုင်းငံ့ရန်, သင်သည်ထိပ်တန်း `Backtrace` အမျိုးအစားကိုသုံးနိုင်သည်။

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

အကယ်၍ အမှန်တကယ် tracing လုပ်ဆောင်နိုင်စွမ်းကိုပိုမိုရယူလိုလျှင်သင် `trace` နှင့် `resolve` လုပ်ဆောင်မှုများကိုတိုက်ရိုက်သုံးနိုင်သည်။

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // ဒီညွှန်ကိန်းကိုသင်္ကေတအမည်ဖြင့်ဖြေရှင်းပါ
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // လာမယ့်ဘောင်သွားစောင့်ရှောက်လော့
    });
}
```

# License

ဤစီမံကိန်းတစ်ခုခုအောက်မှာ၏လိုင်စင်ဖြစ်ပါသည်

 * Apache လိုင်စင်၊ မူကွဲ 2.0, ([LICENSE-APACHE](LICENSE-APACHE) သို့မဟုတ် http://www.apache.org/licenses/LICENSE-2.0)
 * MIT လိုင်စင် ([LICENSE-MIT](LICENSE-MIT) သို့မဟုတ် http://opensource.org/licenses/MIT)

သင့်ရွေးချယ်မှုမှာ

### Contribution

သင်အတိအလင်းဖော်ပြမထားပါက Apache-2.0 လိုင်စင်တွင်သတ်မှတ်ထားသည့်အတိုင်း backtrace-rs များတွင်ပါ ၀ င်ရန်ရည်ရွယ်ချက်ရှိရှိတင်သွင်းသောမည်သည့်အလှူငွေကိုမဆိုထပ်မံစည်းကမ်းချက်များသို့မဟုတ်အခြေအနေများမရှိဘဲ၊







