use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// ပိုင်ဆိုင်ခြင်းနှင့်ကိုယ်ပိုင်ပါ ၀ င်မှုနောက်ပြန်ရှိခြင်းကိုကိုယ်စားပြုခြင်း။
///
/// ဒီတည်ဆောက်ပုံကိုပရိုဂရမ်တစ်ခုရဲ့နေရာအမျိုးမျိုးမှာ backtrace ကိုဖမ်းယူဖို့သုံးပြီးနောက်ပိုင်းမှာအဲဒီ backtrace ဆိုတာကိုစစ်ဆေးဖို့သုံးနိုင်ပါတယ်။
///
///
/// `Backtrace` `Debug` အကောင်အထည်ဖော်မှုမှတစ်ဆင့် backtraces များ၏တော်တော်လေးပုံနှိပ်ခြင်းကိုထောက်ပံ့သည်။
///
/// # လိုအပ်သောအင်္ဂါရပ်များ
///
/// ဤလုပ်ဆောင်မှုသည် `backtrace` crate ၏ `std` အင်္ဂါရပ်ကိုဖွင့်ရန်လိုအပ်ပြီး `std` အင်္ဂါရပ်ကိုမူလအတိုင်းဖွင့်ထားသည်။
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // ဤနေရာတွင် frames ကနေ Top-To-အောက်ခြေမှာ stack ၏စာရင်းနေကြတယ်
    frames: Vec<BacktraceFrame>,
    // ကျွန်ုပ်တို့ယုံကြည်သောအညွှန်းကိန်းသည် backtrace ၏အမှန်တကယ်အစဖြစ်ပြီး `Backtrace::new` နှင့် `backtrace::trace` ကဲ့သို့သော frames များကိုချန်လှပ်ထားသည်။
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// backtrace ထဲရှိ frame ၏ version ကိုဖမ်းယူထားသည်။
///
/// ဤအမျိုးအစားကို `Backtrace::frames` မှစာရင်းတစ်ခုအဖြစ်ပြန်ယူပြီး၊ backtrace တွင် stack frame တစ်ခုကိုကိုယ်စားပြုသည်။
///
/// # လိုအပ်သောအင်္ဂါရပ်များ
///
/// ဤလုပ်ဆောင်မှုသည် `backtrace` crate ၏ `std` အင်္ဂါရပ်ကိုဖွင့်ရန်လိုအပ်ပြီး `std` အင်္ဂါရပ်ကိုမူလအတိုင်းဖွင့်ထားသည်။
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// backtrace တွင်သင်္ကေတ၏ကူးယူထားသောဗားရှင်း။
///
/// ဤအမျိုးအစားကို `BacktraceFrame::symbols` မှစာရင်းတစ်ခုအဖြစ်ပြန်ယူပြီး backtrace ရှိအမှတ်အသားအတွက် metadata ကိုကိုယ်စားပြုသည်။
///
/// # လိုအပ်သောအင်္ဂါရပ်များ
///
/// ဤလုပ်ဆောင်မှုသည် `backtrace` crate ၏ `std` အင်္ဂါရပ်ကိုဖွင့်ရန်လိုအပ်ပြီး `std` အင်္ဂါရပ်ကိုမူလအတိုင်းဖွင့်ထားသည်။
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// တစ်ဦးပိုင်ဆိုင်သည့်ကိုယ်စားပြုမှုပြန်လာ, ဒီ function ကို၏ callsite မှာ backtrace ဖမ်းယူ။
    ///
    /// ဤ function သည် Rust တွင် backtrace ကိုကိုယ်စားပြုရန်အသုံးဝင်သည်။ဤသည်ပြန်လာသောတန်ဖိုးကိုချည်ကိုဖြတ်ပြီးလှေတျတျောမူနှင့်အခြားနေရာများတွင်ပုံနှိပ်, ဤတန်ဖိုးကို၏ရည်ရွယ်ချက်လုံးဝမိမိကိုယ်ကိုပါရှိသောခံရဖို့ဖြစ်ပါတယ်နိုင်ပါသည်။
    ///
    /// အချို့ပလက်ဖောင်းများပေါ်တွင်အပြည့်အဝ backtrace လေးလည်းကြောင့်အလွန်အမင်းစျေးကြီးနိုင်ပါတယ်ဖြေရှင်းသတိပြုပါ။
    /// အကယ်၍ သင်၏ application အတွက်ကုန်ကျစရိတ်များလွန်းပါက (ပုံမှန်အားဖြင့်အရှည်ဆုံးသော) သင်္ကေတ resolution resolution ကိုရှောင်ကြဉ်ပြီး၎င်းအားနောင်ရက်စွဲသို့ရွှေ့ဆိုင်းရန် `Backtrace::new_unresolved()` ကိုအသုံးပြုရန်အကြံပြုသည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # လိုအပ်သောအင်္ဂါရပ်များ
    ///
    /// ဤလုပ်ဆောင်မှုသည် `backtrace` crate ၏ `std` အင်္ဂါရပ်ကိုဖွင့်ရန်လိုအပ်ပြီး `std` အင်္ဂါရပ်ကိုမူလအတိုင်းဖွင့်ထားသည်။
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // ဖယ်ရှားပစ်ရန်ဒီနေရာမှာဘောင်ရှိတယ်သေချာအောင်ချင်တယ်
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// `new` နှင့်ဆင်တူသည်မှာ၎င်းသည်မည်သည့်သင်္ကေတကိုမှမပြေလည်စေဘဲ၎င်းသည် backtrace ကိုလိပ်စာများစာရင်းအဖြစ်သိမ်းဆည်းထားသည်။
    ///
    /// နောက်ပိုင်းတွင် `resolve` function ကိုဤ backtrace ၏သင်္ကေတများအားဖတ်ရှုနိုင်သောအမည်များဖြင့်ဖြေရှင်းရန်ခေါ်နိုင်သည်။
    /// ဤလုပ်ဆောင်ချက်သည်တည်ရှိနေသည်မှာအဘယ်ကြောင့်ဆိုသော် resolution ရှိသောလုပ်ငန်းစဉ်သည်တစ်ခါတစ်ရံတွင်အချိန်များစွာကြာနိုင်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // သင်္ကေတအမည်မရှိပါ
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // ယခုလက်ရှိသင်္ကေတအမည်
    /// ```
    ///
    /// # လိုအပ်သောအင်္ဂါရပ်များ
    ///
    /// ဤလုပ်ဆောင်မှုသည် `backtrace` crate ၏ `std` အင်္ဂါရပ်ကိုဖွင့်ရန်လိုအပ်ပြီး `std` အင်္ဂါရပ်ကိုမူလအတိုင်းဖွင့်ထားသည်။
    ///
    ///
    ///
    #[inline(never)] // ဖယ်ရှားပစ်ရန်ဒီနေရာမှာဘောင်ရှိတယ်သေချာအောင်ချင်တယ်
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// ဒီ backtrace ဖမ်းမိသောအခါကနေ frames များကိုပြန်သွားသည်။
    ///
    /// ဒီအချပ်၏ပထမဦးဆုံး entry ကိုဖွယ်ရှိ function ကို `Backtrace::new` ဖြစ်ပြီး, ပြီးခဲ့သည့်ဘောင်ကဒီချည်ဒါမှမဟုတ်အဓိက function ကိုစတင်ခဲ့ဘယ်လိုတစ်ခုခုဖွယ်ရှိသည်။
    ///
    ///
    /// # လိုအပ်သောအင်္ဂါရပ်များ
    ///
    /// ဤလုပ်ဆောင်မှုသည် `backtrace` crate ၏ `std` အင်္ဂါရပ်ကိုဖွင့်ရန်လိုအပ်ပြီး `std` အင်္ဂါရပ်ကိုမူလအတိုင်းဖွင့်ထားသည်။
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// အကယ်၍ ဤ backtrace ကို `new_unresolved` မှဖန်တီးခဲ့ပါကထို function သည် backtrace ရှိလိပ်စာအားလုံးကို၎င်းတို့၏သင်္ကေတအမည်များကိုဖြေရှင်းလိမ့်မည်။
    ///
    ///
    /// အကယ်၍ ဤ backtrace သည်ယခင်ကဖြေရှင်းခဲ့ပြီးဖြစ်သော `new` မှတဆင့်ဖန်တီးခဲ့ပါက၊
    ///
    /// # လိုအပ်သောအင်္ဂါရပ်များ
    ///
    /// ဤလုပ်ဆောင်မှုသည် `backtrace` crate ၏ `std` အင်္ဂါရပ်ကိုဖွင့်ရန်လိုအပ်ပြီး `std` အင်္ဂါရပ်ကိုမူလအတိုင်းဖွင့်ထားသည်။
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// `Frame::ip` အဖြစ်အတူတူပင်
    ///
    /// # လိုအပ်သောအင်္ဂါရပ်များ
    ///
    /// ဤလုပ်ဆောင်မှုသည် `backtrace` crate ၏ `std` အင်္ဂါရပ်ကိုဖွင့်ရန်လိုအပ်ပြီး `std` အင်္ဂါရပ်ကိုမူလအတိုင်းဖွင့်ထားသည်။
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// `Frame::symbol_address` အဖြစ်အတူတူပင်
    ///
    /// # လိုအပ်သောအင်္ဂါရပ်များ
    ///
    /// ဤလုပ်ဆောင်မှုသည် `backtrace` crate ၏ `std` အင်္ဂါရပ်ကိုဖွင့်ရန်လိုအပ်ပြီး `std` အင်္ဂါရပ်ကိုမူလအတိုင်းဖွင့်ထားသည်။
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// `Frame::module_base_address` အဖြစ်အတူတူပင်
    ///
    /// # လိုအပ်သောအင်္ဂါရပ်များ
    ///
    /// ဤလုပ်ဆောင်မှုသည် `backtrace` crate ၏ `std` အင်္ဂါရပ်ကိုဖွင့်ရန်လိုအပ်ပြီး `std` အင်္ဂါရပ်ကိုမူလအတိုင်းဖွင့်ထားသည်။
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// ဤဘောင်နှင့်ကိုက်ညီသောသင်္ကေတများစာရင်းကိုပြန်ပို့သည်။
    ///
    /// ပုံမှန်အားဖြင့်ဘောင်နှုန်းတစ်ဦးတည်းသာသင်္ကေတလည်းမရှိ, ဒါပေမယ့်လုပ်ဆောင်ချက်များကိုတစ်နံပါတ်တစ်ဘောင်သို့ inlined လျှင်တစ်ခါတစ်ရံထို့နောက်မျိုးစုံသင်္ကေတများပြန်ရောက်ပါလိမ့်မည်။
    /// စာရင်း၏ပထမဆုံးသင်္ကေတမှာ "innermost function" ဖြစ်ပြီးနောက်ဆုံးသင်္ကေတမှာအဝေးဆုံး (နောက်ဆုံးခေါ်ဆိုသူ) ဖြစ်သည်။
    ///
    /// အကယ်၍ ဤ frame သည်မဖြေရှင်းနိုင်သော backtrace မှလာလျှင်၎င်းသည် list အလွတ်တစ်ခုပြန်လာလိမ့်မည်ကိုသတိပြုပါ။
    ///
    /// # လိုအပ်သောအင်္ဂါရပ်များ
    ///
    /// ဤလုပ်ဆောင်မှုသည် `backtrace` crate ၏ `std` အင်္ဂါရပ်ကိုဖွင့်ရန်လိုအပ်ပြီး `std` အင်္ဂါရပ်ကိုမူလအတိုင်းဖွင့်ထားသည်။
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// `Symbol::name` နဲ့အတူတူပါပဲ
    ///
    /// # လိုအပ်သောအင်္ဂါရပ်များ
    ///
    /// ဤလုပ်ဆောင်မှုသည် `backtrace` crate ၏ `std` အင်္ဂါရပ်ကိုဖွင့်ရန်လိုအပ်ပြီး `std` အင်္ဂါရပ်ကိုမူလအတိုင်းဖွင့်ထားသည်။
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// `Symbol::addr` နဲ့အတူတူပါပဲ
    ///
    /// # လိုအပ်သောအင်္ဂါရပ်များ
    ///
    /// ဤလုပ်ဆောင်မှုသည် `backtrace` crate ၏ `std` အင်္ဂါရပ်ကိုဖွင့်ရန်လိုအပ်ပြီး `std` အင်္ဂါရပ်ကိုမူလအတိုင်းဖွင့်ထားသည်။
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// `Symbol::filename` အဖြစ်အတူတူပင်
    ///
    /// # လိုအပ်သောအင်္ဂါရပ်များ
    ///
    /// ဤလုပ်ဆောင်မှုသည် `backtrace` crate ၏ `std` အင်္ဂါရပ်ကိုဖွင့်ရန်လိုအပ်ပြီး `std` အင်္ဂါရပ်ကိုမူလအတိုင်းဖွင့်ထားသည်။
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// `Symbol::lineno` နဲ့အတူတူပါပဲ
    ///
    /// # လိုအပ်သောအင်္ဂါရပ်များ
    ///
    /// ဤလုပ်ဆောင်မှုသည် `backtrace` crate ၏ `std` အင်္ဂါရပ်ကိုဖွင့်ရန်လိုအပ်ပြီး `std` အင်္ဂါရပ်ကိုမူလအတိုင်းဖွင့်ထားသည်။
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// `Symbol::colno` နဲ့အတူတူပါပဲ
    ///
    /// # လိုအပ်သောအင်္ဂါရပ်များ
    ///
    /// ဤလုပ်ဆောင်မှုသည် `backtrace` crate ၏ `std` အင်္ဂါရပ်ကိုဖွင့်ရန်လိုအပ်ပြီး `std` အင်္ဂါရပ်ကိုမူလအတိုင်းဖွင့်ထားသည်။
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // လမ်းကြောင်းများပုံနှိပ်သောအခါ cwd ရှိလျှင်၎င်းကိုဖယ်ထုတ်ရန်ကြိုးပမ်းသည်။
        // သတိပြုရမည်မှာကျွန်ုပ်တို့သည်တိုတောင်းသောပုံစံအတွက်သာပြုလုပ်ကြခြင်းဖြစ်သည်။ အဘယ့်ကြောင့်ဆိုသော်၎င်းသည်ပြည့်နေလျှင်ကျွန်ုပ်တို့သည်အရာအားလုံးကိုပုံနှိပ်ချင်သည်။
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}