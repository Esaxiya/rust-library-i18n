// အခုအချိန်မှာ Linux မှာသာသုံးနိုင်ပြီ၊ ဒါကြောင့်တခြားကုဒ်နံပါတ်တွေကိုခွင့်ပြုပါ
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// byte ကြားခံအတွက်ရိုးရှင်းသောနယ်ပယ်ခွဲဝေချထားပေးခြင်း။
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// ခွဲဝေတစ်ဦးကြားခံသတ်မှတ်ထားတဲ့အရွယ်အစားနှင့်ပြန်ကဖို့ mutable ရည်ညွှန်း၏။
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // လုံခြုံစိတ်ချမှု-ဤအရာသည်ပြောင်းလဲနိုင်သောအရာများကိုတည်ဆောက်ပေးသောတစ်ခုတည်းသောလုပ်ဆောင်ချက်ဖြစ်သည်
        // `self.buffers` မှရည်ညွှန်း။
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // လုံခြုံမှု-ကျွန်ုပ်တို့သည် `self.buffers` မှ element များကိုဘယ်တော့မှမဖယ်ရှားပါ။ ထို့ကြောင့်ရည်ညွှန်းချက်ဖြစ်သည်
        // မည်သည့်ကြားခံအတွင်းရှိဒေတာများကိုနေသမျှကာလပတ်လုံး `self` လုပ်ပေးလိမ့်မည်။
        &mut buffers[i]
    }
}