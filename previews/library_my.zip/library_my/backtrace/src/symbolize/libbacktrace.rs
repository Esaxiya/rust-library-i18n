//! libbacktrace အတွက် DWARF-parsing ကုဒ်ကိုအသုံးပြု။ သင်္ကေတမဟာဗျူဟာ။
//!
//! ပုံမှန်အားဖြင့် gcc ဖြင့်ဖြန့်ဝေထားသော libbacktrace C စာကြည့်တိုက်သည် backtrace (ကျွန်ုပ်တို့အမှန်တကယ်မသုံးသော) ကိုထုတ်ပေးရုံသာမက backtrace ကိုသင်္ကေတပြုခြင်းနှင့်အတွင်းနက်ဘောင်များနှင့်အဘယ်သို့စသည်တို့နှင့်ပတ်သက်သောထောင်ပြီး debug အချက်အလက်များကိုကိုင်တွယ်သည်ကိုထောက်ပံ့ပေးသည်။
//!
//!
//! ဤနေရာတွင်အမျိုးမျိုးသောစိုးရိမ်မှုများစွာကြောင့်ဤသည်အတော်လေးရှုပ်ထွေးသော်လည်းအခြေခံအယူအဆမှာ-
//!
//! * ပထမ ဦး စွာ `backtrace_syminfo` ဟုခေါ်သည်ကျနော်တို့လုပ်နိုင်မယ်ဆိုရင်ဒါဟာပြောင်းလဲနေသောသင်္ကေတစားပွဲကနေသင်္ကေတသတင်းအချက်အလက်ရရှိသွားတဲ့။
//! * ထို့နောက် `backtrace_pcinfo` ဟုခေါ်သည်။ဤသည်ကိုသူတို့ဖွင့်မရရှိနိုင်လျှင်စားပွဲ debuginfo ခွဲခြားစိတ်ဖြာမှုနှင့်ကျွန်တော်တို့ကို inline ပျဉ်ပြား, filename လိုင်းနံပါတ်များ, စတာတွေအကြောင်းသတင်းအချက်အလက်ပြန်လည်ဖေါ်ထုတ်ရန်ခွင့်ပြုပါလိမ့်မယ်
//!
//! Libbacktrace ထဲသို့ထောင်ပြီးစားပွဲများကို ၀ င်ရောက်ခြင်းသည်ပရိယာယ်များစွာရှိသော်လည်း၎င်းသည်ကမ္ဘာ၏နိဂုံးမဟုတ်ဘဲအောက်တွင်ဖတ်ရှုသည့်အခါလုံလောက်မှုရှိသည်။
//!
//! ဤသည် Non-MSVC နှင့် Non-OSX ပလက်ဖောင်းများအတွက် default အသင်္ကေတမဟာဗျူဟာဖြစ်ပါတယ်။ဒီ OSX များအတွက် default အနေနဲ့မဟာဗျူဟာသော်လည်း libstd ၌တည်၏။
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // ဖြစ်နိုင်လျှင် debuginfo မှလာပြီးဥပမာအားဖြင့် inline frames များအတွက် ပို၍ တိကျနိုင်သည့် `function` name ကိုပိုနှစ်သက်သည်။
                // အကယ်၍ ထိုအရာမရှိပါက `symname` တွင်ဖော်ပြထားသော symbol table name သို့ပြန်သွားပါ။
                //
                // သတိပြုရမည်မှာ `function` သည်တိကျမှုနည်းပါးသည်ဟုခံစားရနိုင်သည်။ ဥပမာ `std::panicking::try::do_call` ၏ `try<i32,closure>` isntead ဖြစ်သည်။
                //
                // ဘာကြောင့်လဲဆိုတော့ရှင်းရှင်းလင်းလင်းမသိရသေးပေမယ့် `function` နာမည်ကပိုပြီးတိကျပုံရတယ်။
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // အခုတော့ဘာမှမလုပ်ဘူး
}

/// အဆိုပါ `data` pointer အမျိုးအစား `syminfo_cb` သို့လွန်
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // ကျွန်ုပ်တို့စတင်ဖြေရှင်းသည့်အခါဤ callback ကို `backtrace_syminfo` မှအသုံးပြုသည်နှင့်တစ်ပြိုင်နက် `backtrace_pcinfo` ကို ဆက်၍ ဖုန်းဆက်သည်။
    // `backtrace_pcinfo` function သည် debug အချက်အလက်နှင့်တိုင်ပင်ပြီး file/line သတင်းအချက်အလက်အပြင် inline frames များကိုလုပ်ရန်ကြိုးစားလိမ့်မည်။
    // သတိပြုရန်မှာ `backtrace_pcinfo` သည် debug အချက်အလက်မရှိပါကများစွာမအောင်မြင်နိုင်သော်လည်းမအောင်မြင်နိုင်ပါ။ အကယ်၍ ထိုသို့ဖြစ်ခဲ့ပါကကျွန်ုပ်တို့သည် callback ကို `syminfo_cb` မှအနည်းဆုံးသင်္ကေတတစ်ခုနှင့်ခေါ်ရန်သေချာသည်။
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// `pcinfo_cb` သို့ကူးသွားသော `data` pointer အမျိုးအစား
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// libbacktrace API သည်ပြည်နယ်တစ်ခုကိုတည်ဆောက်ခြင်းကိုထောက်ပံ့သည်၊ သို့သော်၎င်းသည်ပြည်နယ်တစ်ခုကိုဖျက်ဆီးခြင်းကိုမထောက်ပံ့ပါ။
// ငါကိုယ်တိုင်ဒီအချက်ကိုယူပြီးပြည်နယ်တစ်ခုကိုဖန်တီးပြီးထာဝရရှင်သန်ဖို့ရည်ရွယ်ထားတယ်လို့ဆိုလိုတာပါ။
//
// ဒီအခြေအနေကိုရှင်းပေးတဲ့ at_exit() handler ကိုမှတ်ပုံတင်ချင်ပါတယ်၊ ဒါပေမယ့် libbacktrace ကအဲဒီလိုလုပ်ဖို့လမ်းမရှိပါဘူး။
//
// ဤအကန့်သတ်ချက်များနှင့်အတူ၊ ဤလုပ်ဆောင်မှုသည်တောင်းဆိုရန်ပထမ ဦး ဆုံးအကြိမ်တွက်ချက်သော statically cached state ရှိသည်။
//
// အားလုံးနောက်ကြောင်းပြန်လှည့်သည်အမှတ်စဉ် (ကမ္ဘာလုံးဆိုင်ရာသော့ခတ်တစ်ခု) ဖြစ်ပျက်ကြောင်းသတိရပါ။
//
// ဤနေရာတွင်ထပ်တူထပ်မျှမရှိခြင်းကိုသတိပြုပါမှာ `resolve` သည်ပြင်ပတွင်ထပ်တူပြုရန်လိုအပ်သည်။
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // libbacktrace ၏ threadsafe စွမ်းရည်များကိုအသုံးမပြုပါနှင့်။ ၎င်းကိုအမြဲတမ်းထပ်တူပြုသည့်ပုံစံဖြင့်ခေါ်ဆိုသည်။
        //
        0,
        error_cb,
        ptr::null_mut(), // အပိုဒေတာမရှိပါ
    );

    return STATE;

    // libbacktrace မှာအားလုံးအလုပ်လုပ်ဖို့အတွက်လက်ရှိ executable အတွက် DWARF debug info ကိုရှာဖို့လိုတယ်။၎င်းသည်လုပ်ထုံးလုပ်နည်းများစွာမှတစ်ဆင့်ပြုလုပ်သည်၊
    //
    // * /proc/self/exe ထောက်ခံပလက်ဖောင်းပေါ်မှာ
    // * ပြည်နယ်ဖန်တီးသောအခါပြည့်စုံရှင်းလင်းစွာလွန်အဆိုပါဖိုင်အမည်
    //
    // Libbacktrace စာကြည့်တိုက်သည် C code ၏ကြီးမားသော wad တစ်ခုဖြစ်သည်။၎င်းသည်ပုံမှန်အားဖြင့်ပုံပျက်နေသော debuginfo ကိုကိုင်တွယ်သည့်အခါ၎င်းတွင်မှတ်ဉာဏ်လုံခြုံမှုအားနည်းခြင်းများရှိသည်ဟုဆိုလိုသည်။
    // Libstd သမိုင်းကြောင်းအရဤအရာများစွာသို့ပြေးခဲ့သည်။
    //
    // အကယ်၍ /proc/self/exe ကိုသုံးပါက libbacktrace သည် "mostly correct" ဖြစ်ပြီး "attempted to be correct" dwarf debug info နှင့်ထူးဆန်းသောအရာများမဟုတ်ဟုကျွန်ုပ်တို့ယူဆသောကြောင့်ကျွန်ုပ်တို့သည်ပုံမှန်အားဖြင့်၎င်းကိုလျစ်လျူရှုနိုင်သည်။
    //
    //
    // သို့သော်ကျွန်ုပ်တို့သည်ဖိုင်အမည်တစ်ခုထည့်လိုက်လျှင်မကောင်းသောသရုပ်ဆောင်သူတစ် ဦး သည်ထိုနေရာတွင်မတရားဖိုင်တစ်ခုကိုနေရာချနိုင်သည့်အချို့သောပလက်ဖောင်းများ (BSD ကဲ့သို့) ဖြစ်နိုင်သည်။
    // ဆိုလိုသည်မှာကျွန်ုပ်တို့သည် libbacktrace ဖိုင်အမည်အားကျွန်ုပ်တို့ပြောပါက၎င်းသည် segfaults ကိုဖြစ်ပေါ်စေနိုင်သည်၊
    // libbacktrace ကိုကျွန်တော်တို့ဘာမှမပြောရင် /proc/self/exe လိုလမ်းကြောင်းတွေကိုမထောက်ပံ့တဲ့ပလက်ဖောင်းတွေမှာဘာမှလုပ်မှာမဟုတ်ဘူး။
    //
    // ကျနော်တို့ * * တစ်ဖိုင်အမည်အတွက်မလွန်ဖို့ဖြစ်နိုင်ကဲ့သို့မာနျကွိုးစားသျောလညျးကြှနျုပျတို့အားလုံးမှာ /proc/self/exe ကိုထောကျပံ့မပလက်ဖောင်းပေါ်ရပါမည်သောသူအပေါင်းတို့အားပေး။
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // အကောင်းဆုံးဆိုရလျှင် `std::env::current_exe` ကိုသုံးမည်ဖြစ်သော်လည်းဤနေရာတွင် `std` မလိုအပ်ပါ။
            //
            // `_NSGetExecutablePath` ကို သုံး၍ လက်ရှိ executable လမ်းကြောင်းကို static area (load လုပ်ရန်အလွန်သေးငယ်လွန်းလျှင်) အရှုံးပေါ်လိမ့်မည်။
            //
            //
            // သတိပြုရန်မှာကျွန်ုပ်တို့သည်ဤနေရာတွင် libbacktrace ကိုအယုံအကြည်ကင်းသော executable များပေါ်တွင်သေဆုံးရန်မလိုပါ။
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows ဖွင့်လှစ်ပြီးနောက်ဖျက်ပစ်လို့မရပါဘူးဖိုင်များကိုဖွင့်လှစ်တဲ့ mode ကိုရှိသည်။
            // ယေဘုယျအားဖြင့်၎င်းသည်ဤနေရာတွင်ကျွန်ုပ်တို့လိုချင်သောအရာဖြစ်သည်။ အဘယ်ကြောင့်ဆိုသော်ကျွန်ုပ်တို့သည်ကျွန်ုပ်တို့၏ executable သည် libbacktrace သို့လွှဲပြောင်းပြီးသည့်နောက်ကျွန်ုပ်တို့၏အောက်တွင်ရှိသောအရာများပြောင်းလဲခြင်းမရှိစေရန်သေချာစေရန်လိုသည်။
            //
            //
            // ငါတို့သည်ကိုယ်ပုံရိပ်ကိုအပေါ်သော့ခတ်တစ်မျိုးရဖို့ကြိုးစားရန်ဒီမှာကခုန်၏နည်းနည်းပြုပေးထားသော:
            //
            // * လက်ရှိဖြစ်စဉ်ကိုလက်ကိုင်တစ်ခုယူပြီး၎င်းဖိုင်အမည်ကိုဖွင့်ပါ။
            // * ညာဘက်အလံနဲ့ဖိုင်အမည်ဖို့ဖိုင်တစ်ခုဖွင့်လိုက်ပါ။
            // * လက်ရှိဖြစ်စဉ်၏ဖိုင်အမည်ကိုပြန်ဖွင့်ပါ
            //
            // အားလုံးသီအိုရီအတွက်ကျနော်တို့ဖြတ်သန်းကြောင်းဆိုပါကအမှန်တကယ်ကျွန်တော်တို့ရဲ့လုပ်ငန်းစဉ်ကိုရဲ့ file ကိုဖွင့်လှစ်ခဲ့ကြပြီးကျနော်တို့ကပြောင်းလဲပစ်မည်မဟုတ်အာမခံပါတယ်။FWIW ဒီတစည်းသမိုင်းကြောင်းအ libstd ကနေကူးယူဒါကြောင့်ဒီအဖြစ်ပျက်ခဲ့ရာငါ၏အကောင်းဆုံးအနက်ဖြစ်ပါတယ်။
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // ဒါက static memory ထဲမှာနေတယ်၊
                static mut BUF: [i8; N] = [0; N];
                // ကယာယီဖွင့်ကတည်းက ... ဒီ stack ပေါ်မှာအသက်ရှင်တော်မူသည်
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // ရည်ရွယ်ချက်ရှိရှိပွင့်လင်းဒီဖိုင်နာမကိုအမှီပေါ်မှာငါတို့သော့ခတ်ကိုထိန်းသိမ်းသင့်ကြောင်းရှိခြင်းကြောင့်အကဒီမှာ `handle` ပေါက်ကြား။
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // ကျနော်တို့ nul-terminated အချပ်ပြန်ချင်, ဒါကြောင့်အရာအားလုံးဖြည့်ပါကစုစုပေါင်းအရှည်ညီမျှလျှင်၎င်းသည်ရှုံးနိမ့်ညီမျှလျှင်။
                //
                //
                // မဟုတ်ရင်အောင်မြင်မှုပြန်လာတဲ့အခါ nul byte ကိုအချပ်မှာသေချာအောင်လုပ်ပါ။
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // backtrace အမှားများကိုလက်ရှိကော်ဇောအောက်မှာမျောနေကြသည်
    let state = init_state();
    if state.is_null() {
        return;
    }

    // အတိအကျတစ်ချိန်က `syminfo_cb` ကိုပဌနာ (သို့မဟုတ်ယူဆရမှားယွင်းမှုတစ်ခုနှင့်အတူကျရှုံး) သင့်သော (code ကိုဖတ်ရှုခြင်းမှ) ယင်း `backtrace_syminfo` API ကိုခေါ်ပါ။
    // ကျနော်တို့ထို့နောက် `syminfo_cb` အတွင်းပိုပြီးကိုင်တွယ်။
    //
    // `syminfo` အဆိုပါ binary မဒီဘာဂ်သတင်းအချက်အလက်ရှိပါတယ်လျှင်ပင်သင်္ကေတအမည်များကိုရှာဖွေတာ, သင်္ကေတစားပွဲတိုင်ပင်ဆွေးနွေးပါလိမ့်မယ်ကတည်းကကျနော်တို့ကဒီကျင့်သောမှတ်ချက်။
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}