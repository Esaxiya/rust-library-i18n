//! crates.io အပေါ် `gimli` crate အသုံးပြု. သင်္ကေတဘို့ပံ့ပိုးမှု
//!
//! ၎င်းသည် Rust အတွက်ပုံသေသင်္ကေတအကောင်အထည်ဖော်မှုဖြစ်သည်။

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'တည်ငြိမ်သောသက်တမ်းသည်မိမိကိုယ်ကိုရည်ညွှန်းသည့်ဖွဲ့စည်းပုံအတွက်အထောက်အပံ့မရှိခြင်းကိုကျော်လွှားရန်မုသာဖြစ်သည်။
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // 'static သက်တမ်း' သို့ပြောင်းပါ။ အဘယ်ကြောင့်ဆိုသော်သင်္ကေတများသည် `map` နှင့် `stash` ကိုသာငှားရမ်းသင့်ပြီး၎င်းတို့ကိုကျွန်ုပ်တို့အောက်တွင်ထိန်းသိမ်းထားသည်။
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Windows တွင်ဇာတိစာကြည့်တိုက်များတင်ရန်အတွက်ဤနေရာရှိမဟာဗျူဟာအမျိုးမျိုးအတွက် rust-lang/rust#71060 နှင့် ပတ်သက်၍ ဆွေးနွေးမှုအချို့ကိုကြည့်ပါ။
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW စာကြည့်တိုက်သည်လက်ရှိတွင် ASLR (rust-lang/rust#16514) ထောကျပံ့ပေးပါဘူး, ဒါပေမယ့် DLLs နေဆဲလိပ်စာအာကာသအတွင်းလှည့်ပတ်ပြောင်းရွှေ့နိုင်မည်ဖြစ်သည်။
            // debug info ရှိလိပ်စာများအားလုံးသည်ဤစာကြည့်တိုက်သည်၎င်း၏ COFF ဖိုင်ခေါင်းစဉ်များရှိလယ်ကွင်းဖြစ်သော "image base" တွင်၎င်းစာကြည့်တိုက်ကိုဖွင့်ထားသည်ဟုထင်ရသည်။
            // debuginfo ကစာရင်းပြုစုပုံရသောကြောင့်ဤစာတမ်းသည် "image base" တွင်စာကြည့်တိုက်ကိုဖွင့်သကဲ့သို့သင်္ကေတဇယားနှင့်လိပ်စာများကိုခွဲခြမ်းစိတ်ဖြာသည်။
            //
            // စာကြည့်တိုက်ကို "image base" တွင်မဖွင့်နိုင်ပါ။
            // အဆိုပါ `bias` လယ်ကိုကစားသို့ကြွလာ, ငါတို့ကဒီမှာ `bias` ၏တန်ဖိုးကိုတွက်ဖို့လိုပါတယ်ရှိရာ (ယူဆရသည်အခြားအရာတစ်ခုခု? အဲဒီမှာ loaded စေခြင်းငှါ) ဤဖြစ်ပါတယ်။ကံမကောင်းစွာဖြင့်၎င်းသည် loaded module တစ်ခုမှမည်သို့ရယူနိုင်သည်ကိုမရှင်းလင်းပေ။
            // ငါတို့သည်အဘယ်သို့ပြုမည်အရာကိုသို့သော်အမှန်တကယ်ဝန်လိပ်စာ (`modBaseAddr`) ဖြစ်ပါတယ်။
            //
            // ယခုအချိန်တွင်ကျွန်ုပ်တို့ရဲ့အမှားအယွင်းတစ်ခုအနေဖြင့်ဖိုင်ကို mmap, file header information ကိုဖတ်ပြီး mmap ကိုချလိုက်သည်။mmap နောက်ပိုင်းတွင်ပြန်ဖွင့်ကောင်းဖြစ်လိမ့်မည်ဖြစ်သောကြောင့်၎င်းသည်ဖြုန်းတီးခြင်းဖြစ်သည်၊ သို့သော်ယခုအချိန်တွင်၎င်းသည်ကောင်းစွာအလုပ်လုပ်သင့်သည်။
            //
            // ကျွန်ုပ်တို့တွင် `image_base` (လိုချင်သော load location) နှင့် `base_addr` (အမှန်တကယ်ဝန်နေရာ) ရှိပါက `bias` (အမှန်တကယ်နှင့်လိုချင်သောအကြားခြားနားချက်) ကိုဖြည့်စွက်နိုင်ပြီးဖိုင်တစ်ခုချင်းစီ၏ဖော်ပြထားသောလိပ်စာမှာ `image_base` ဖြစ်သည်။
            //
            //
            // ယခုအချိန်တွင် ELF/MachO နှင့်မတူဘဲကျွန်ုပ်တို့သည်စာကြည့်တိုက်တစ်ခု၏အစိတ်အပိုင်းတစ်ခုနှင့်လုပ်နိုင်သည်၊ အရွယ်အစားတစ်ခုလုံးအဖြစ် `modBaseSize` ကိုသုံးနိုင်သည်။
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS Mach-O ဖိုင်အမျိုးအစားကိုအသုံးပြုပြီး application ၏တစ်စိတ်တစ်ပိုင်းဖြစ်သောဇာတိစာကြည့်တိုက်များစာရင်းကိုဖွင့်ရန် DYLD-specific APIs များကိုအသုံးပြုသည်။
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // ဤစာကြည့်တိုက်၏အမည်ကို၎င်းကိုမည်သည့်နေရာတွင်ဖွင့်ရမည်နည်းနှင့်ကိုက်ညီပါစေ။
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // ကျနော်တို့ကဒီမှာပါဝင်ပတ်သက်သူအပေါင်းတို့ကို segments များထွက်တွက်ဆနိုင်အောင်အပေါငျးတို့သဝန်ပညတ်တော်တို့ကိုခွဲခြားစိတ်ဖြာမှုမှ `object` ဤစာကြည့်တိုက်များနှင့်ကိုယ်စားလှယ်များ၏ပုံရိပ်ကို header ကို load ။
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // segments များကျော်ကြားခံနှင့်ငါတို့ရှာသော segments များအဘို့အသိရဒေသများမှတ်ပုံတင်။
            // နောက်ပိုင်းမှာ processing များအတွက်စာသားကို segments များရင်ဆိုင်တွေ့ဆုံခြင်းထို့အပြင်စံချိန်တင်သတင်းအချက်အလက်များအောက်တွင်မှတ်ချက်များကိုကြည့်ပါ။
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // ဒီစာကြည့်တိုက်အတွက် "slide" ကိုမှတ်သားပါ။ မှတ်ဥာဏ်အရာဝတ္ထုများမည်သည့်နေရာတွင်ရှိသည်ကိုတွက်ရန်ကျွန်ုပ်တို့အသုံးပြုသောဘက်လိုက်မှုဖြစ်သွားသည်။
            // ၎င်းသည်ထူးဆန်းသောတွက်ချက်မှုတစ်ခုဖြစ်ပြီးတော၌အနည်းငယ်သောအရာများကိုကြိုးစားရှာဖွေခြင်းနှင့်အဘယျအရာကိုမြင်ခြင်း၏ရလဒ်ဖြစ်သည်။
            //
            // ယေဘူယျယူဆချက်မှာ `bias` + segment ၏ `stated_virtual_memory_address` သည်အမှန်တကယ်လိပ်စာနေရာ၌ရှိနေသောနေရာဖြစ်သည်။
            // ကျွန်ုပ်တို့မှီခိုအားထားရသည့်နောက်တစ်ခုမှာ `bias` အနုတ်လက္ခဏာအစစ်အမှန်လိပ်စာမှာသင်္ကေတဇယားနှင့် debuginfo တွင်ရှာဖွေရန်အညွှန်းဖြစ်သည်။
            //
            // သို့သော် system loaded libraries များအတွက်တွက်ချက်မှုသည်မမှန်ကန်ကြောင်းတွေ့ရှိရသည်။မူရင်း executable များအတွက်မူ၎င်းသည်မှန်ကန်ပုံရသည်။
            // LLDB ၏အရင်းအမြစ်မှယုတ္တိဗေဒအချို့ကိုရုပ်သိမ်းပြီး၎င်းတွင် file offset 0 မှ nonzero အရွယ်ရှိပထမဆုံး x00X section အတွက်အထူး casing တစ်ခုရှိသည်။
            // ဤပစ္စုပ္ပန်အခါဘာပဲအကြောင်းပြချက်ကသင်္ကေတဇယားသည်စာကြည့်တိုက်များအတွက်ရုံ vmaddr ဆလိုက်မှဆွေမျိုးကြောင်းဆိုလိုပုံရပါတယ်။
            // အကယ်၍ * မရှိလျှင်၎င်းသင်္ကေတဇယားသည် vmaddr slide နှင့် segment ၏ဖော်ပြထားသည့်လိပ်စာနှင့်နှိုင်းယှဉ်သည်။
            //
            // file offset သုညမှာရှာမတွေ့ဘူးဆိုရင်ဒီအခြေအနေကိုကိုင်တွယ်မယ်ဆိုရင်ပထမဆုံးစာသားရဲ့ဖော်ပြထားတဲ့လိပ်စာနဲ့ဘက်လိုက်မှုတိုးလာပြီးဖော်ပြထားတဲ့လိပ်စာတွေအားလုံးကိုအဲဒီပမာဏအတိုင်းအတာလျော့နည်းသွားစေတယ်။
            //
            // ဤနည်းအားဖြင့်စာကြည့်တိုက်၏ဘက်လိုက်မှုပမာဏနှင့်နှိုင်းယှဉ်ပါကဇယားကွက်သည်အမြဲတမ်းပေါ်နေသည်။
            // ဤသည်သင်္ကေတဇယားမှတဆင့်သင်္ကေတများအတွက်မှန်ကန်သောရလဒ်များရှိသည်ဖို့ပုံရသည်။
            //
            // ရိုးရိုးသားသားပြောရရင်ဒါကမှန်လား၊ ဒါမှမဟုတ်ဘယ်လိုလုပ်ရမယ်ဆိုတာညွှန်ပြသင့်တဲ့တခြားအရာတစ်ခုခုရှိမလားဆိုတာလုံးဝမသိဘူး။
            // ယခုအချိန်တွင်ဤသည် (?) သည်ကောင်းစွာအလုပ်လုပ်ပုံရသော်လည်းလိုအပ်ပါကအချိန်အတိုင်းအတာတစ်ခုအထိညှိယူနိုင်သင့်သည်။
            //
            // ပိုမိုသိရှိလိုပါက #318 တွင်ကြည့်ပါ
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // အခြားအ Unix (ဥပမာ
        // Linux) ပလက်ဖောင်းများသည် ELF ကို object file format တစ်ခုအဖြစ်အသုံးပြုပြီးမူလစာကြည့်တိုက်များဖွင့်ရန် `dl_iterate_phdr` ဟုခေါ်သော API ကိုအသုံးပြုသည်။
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` ခိုင်လုံသောထောက်ပြဖြစ်သင့်သည်။
        // `vec` တစ် ဦး `std::Vec` မှတရားဝင် pointer ဖြစ်သင့်သည်။
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 ပြုလုပ်ရန်ဒီဘာဂ်အင်ဖိုထောကျပံ့ပေးမထားဘူးသော်လည်း, တည်ဆောက်စနစ်လမ်းကြောင်းကို `romfs:/debug_info.elf` မှာဒီဘာဂ်အင်ဖိုနေရာပါလိမ့်မယ်။
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // အခြားအရာအားလုံးက ELF ကိုသုံးသင့်တယ်၊ ဒါပေမယ့်ဇာတိစာကြည့်တိုက်တွေကိုဘယ်လိုဖွင့်ရမယ်ဆိုတာမသိဘူး။
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// loaded ခဲ့ကြသောသူအပေါင်းတို့သည်သိကြ shared စာကြည့်တိုက်။
    libraries: Vec<Library>,

    /// မြေပုံများကိုသိုလှောင်ထားသောမြေပုံဆိုင်ရာအချက်အလက်များကိုကျွန်ုပ်တို့သိမ်းဆည်းထားသည်။
    ///
    /// ဒီစာရင်းကဘယ်တော့မှမတိုးဘူးတဲ့သူ့ရဲ့ liftime တစ်ခုလုံးအတွက်သတ်မှတ်ထားတဲ့စွမ်းရည်ရှိပါတယ်။
    /// တစ်ဦးချင်းစီ pair တစုံ၏ `usize` ဒြပ်စင် `usize::max_value()` လက်ရှိဟာ executable ကိုယ်စားပြုရှိရာအထက် `libraries` သို့ထားတဲ့အညွှန်းကိန်းဖြစ်ပါတယ်။
    ///
    /// `Mapping` သည်ခွဲခြားထားသည့်ထောင်ပြီးသတင်းအချက်အလက်နှင့်သက်ဆိုင်သည်။
    ///
    /// သတိပြုရန်မှာ၎င်းသည်အခြေခံအားဖြင့် LRU cache ဖြစ်ပြီးလိပ်စာများကိုသင်္ကေတအဖြစ်ကျွန်ုပ်တို့သည်အရာဝတ္ထုများကိုဤနေရာတွင်ပြောင်းရွှေ့လိမ့်မည်။
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// ဒီစာကြည့်တိုက်ရဲ့အပိုင်းတွေကမှတ်ဉာဏ်ထဲကိုရောက်သွားတယ်၊
    segments: Vec<LibrarySegment>,
    /// ဒီစာကြည့်တိုက်၏ "bias", ပုံမှန်အားဖြင့်သူကမှတ်ဉာဏ်သို့တင်ဆောင်ဘယ်မှာ။
    /// ဤသည်တန်ဖိုးအစိတ်အပိုင်းသို့တင်ဆောင်ကြောင်းအမှန်တကယ်ကို virtual memory ကိုလိပ်စာရဖို့အသီးအသီးအစိတ်အပိုင်းရဲ့ဖော်ပြထားသောလိပ်စာထည့်သွင်းထားသည်။
    /// ဒါ့အပြင်ဒီဘက်လိုက်မှုဟာအစစ်အမှန် virtual memory လိပ်စာများမှ debuginfo နှင့် symbol table သို့ index အဖြစ်နုတ်သည်။
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// အရာဝတ္ထုဖိုင်ထဲမှာကဒီအစိတ်အပိုင်းများ၏ဖော်ပြထားလိပ်စာ။
    /// ဤသည်သည် segment ကို load လုပ်သောနေရာမဟုတ်ပါ။ သို့သော်လိပ်စာနှင့်ပါရှိသော library library ၏ `bias` သည်မည်သည့်နေရာတွင်ရှာရမည်နည်း။
    ///
    stated_virtual_memory_address: usize,
    /// မှတ်ဉာဏ်ထဲမှာ ths အစိတ်အပိုင်း၏အရွယ်အစား။
    len: usize,
}

// ဤသည်ပြင်ပတွင်ထပ်တူပြုရန်လိုအပ်သောကြောင့်လုံခြုံမှုမရှိပါ
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // ဤသည်ပြင်ပတွင်ထပ်တူပြုရန်လိုအပ်သောကြောင့်လုံခြုံမှုမရှိပါ
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // debug info မြေပုံများအတွက်အလွန်သေးငယ်။ အလွန်ရိုးရှင်းသော LRU cache ဖြစ်သည်။
        //
        // ပုံမှန် stack အများအပြားက Shared စာကြည့်တိုက်များအကြားကူးပါဘူးကတည်းကထိခိုက်နှုန်းအလွန်မြင့်မားဖြစ်သင့်သည်။
        //
        // `addr2line::Context` တည်ဆောက်ပုံများသည်အလွန်စျေးကြီးသည်။
        // ကောင်းသော addup2line: : Context`s ကိုတည်ဆောက်ရာတွင်တည်ဆောက်ထားသောတည်ဆောက်ပုံများကိုမြှင့်တင်ပေးသည့်နောက်ဆက်တွဲ `locate` မေးမြန်းချက်များကြောင့်၎င်း၏ကုန်ကျစရိတ်ကိုပြန်လည်စုဆောင်းနိုင်သည်ဟုမျှော်လင့်ရသည်။
        //
        // ကျွန်ုပ်တို့တွင်ဤ cache မရှိပါကထိုငွေပမာဏသည်ဘယ်တော့မျှဖြစ်လာမည်မဟုတ်ပါ။ backtraces များကိုသင်္ကေတအဖြစ်ဖော်ပြခြင်းသည် ssssllllooooowwww ဖြစ်သည်။
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // ပထမ ဦး စွာဤ `lib` တွင် `addr` (ပြောင်းရွှေ့နေရာချထားမှု) ပါ ၀ င်သည့်အစိတ်အပိုင်းရှိမရှိစစ်ဆေးပါ။ဒီစစ်ဆေးမှုများဖြတ်သန်းလျှင်ကျနော်တို့ကိုအောက်တွင်ဆက်လက်အမှန်တကယ်လိပ်စာဘာသာပြန်ဆိုနိုင်ပါ။
                //
                // ကျနော်တို့လျတ်စစ်ဆေးမှုများကိုရှောင်ကြဉ်ရန်ဒီနေရာကို `wrapping_add` အသုံးပြုနေကြောင်းမှတ်ချက်။တောရိုင်းတွင် SVMA + ဘက်လိုက်မှုတွက်ချက်မှုသည်အလွန်များပြားနေသည်ကိုတွေ့ရသည်။
                // ၎င်းသည်ဖြစ်နိူင်သည်မှာထူးဆန်းနေပုံရသော်လည်းအာကာသထဲသို့ညွှန်ပြနေခြင်းကြောင့်၎င်းအပိုင်းများကိုလျစ်လျူရှုခြင်းထက်အခြားအရာများကိုကျွန်ုပ်တို့ပြုလုပ်နိုင်သည့်ပမာဏများစွာမရှိပါ။
                //
                // ဒါကမူလက rust-lang/backtrace-rs#329 မှာပေါ်လာတယ်။
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // ယခုတွင် `lib` တွင် `addr` ပါ ၀ င်သည်ကိုသိရှိပြီးပါကဖော်ပြထားသောဗိုင်းရပ်စ်နှိမ်နင်းရေးလိပ်စာကိုရှာဖွေရန်ဘက်လိုက်မှုဖြင့်ချိန်ညှိနိုင်သည်။
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // လျော့ပါးသွားမည်ဖြစ်သလို: ဒီခြွင်းချက်အစောပိုင်းပြန်လာခြင်းမရှိဘဲပြီးဆုံးပြီးနောက်
        // အမှားတစ်ခုမှဤလမ်းကြောင်းအတွက် cache entry သည် index 0 ဖြစ်သည်။

        if let Some(idx) = idx {
            // အဆိုပါမြေပုံအဆိုပါ cache ထဲတွင်ပြီးသားဖြစ်တဲ့အခါ, မျက်နှာစာမှရွှေ့။
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // မြေပုံထုတ်ခြင်းသည် cache ထဲတွင်မရှိပါကမြေပုံအသစ်တစ်ခုကိုဖန်တီးပါ၊ ၎င်းကို cache ၏အရှေ့ဘက်သို့ထည့်ပြီးလိုအပ်ပါကအသက်အကြီးဆုံး cache entry ကိုဖယ်ရှားပါ။
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // သေချာကပဲကိုယျ့ကိုယျကိုမှနယ်ပယ်သတ်မှတ်ထားသောရဲ့ဖြစ်စေလျက်, `'static` တစ်သက်တာပေါက်ကြားပါဘူး
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // ကျွန်ုပ်တို့ကံမကောင်းအကြောင်းမလှစွာလိုအပ်နေသောကြောင့် `sym` ၏သက်တမ်းကို `'static` သို့တိုးချဲ့ပါ၊ သို့သော်၎င်းသည်အစဉ်အမြဲရည်ညွှန်းချက်အနေဖြင့်ထွက်ပေါ်နေသောကြောင့်၎င်းကိုမည်သည့်ရည်ညွှန်းချက်ကဤဘောင်ထက် ကျော်လွန်၍ မထားသင့်ပါ။
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // နောက်ဆုံးအနေဖြင့် cached မြေပုံဆွဲခြင်းသို့မဟုတ်ဤဖိုင်အတွက်မြေပုံအသစ်တစ်ခုဖန်တီးခြင်းနှင့်ဤလိပ်စာအတွက် file/line/name ကိုရှာရန် DWARF အချက်အလက်ကိုအကဲဖြတ်ပါ။
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// ကျနော်တို့ addr2line`ရဲ့ frame ကိုပြည်တွင်းရွှေ့ပြောင်းအပေါငျးတို့သ nitty gritty အသေးစိတ်ကိုရှိပါတယ်`ဒီသင်္ကေတဘို့ဘောင်သတင်းအချက်အလက်နေရာချထားပေးနိုင်ခဲ့ကြသည်, ။
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// ဒီဘာဂ်အချက်အလက်ကိုရှာမရပါ၊ သို့သော်၎င်းကို elf executable ၏သင်္ကေတဇယားတွင်ကျွန်ုပ်တို့တွေ့ရှိရသည်။
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}