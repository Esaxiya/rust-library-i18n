use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// အဆိုပါသတ်မှတ်ထားတဲ့ပိတ်သိမ်းဖို့သင်္ကေတဖြတ်သန်းတစ်ဦးသင်္ကေတတစ်ခုလိပ်စာဖြေရှင်းရန်။
///
/// လိုက်လျောညီထွေဖြစ်ရန်အထိမ်းအမှတ်များကိုရှာဖွေရန်ဤလုပ်ဆောင်မှုသည်ပေးထားသောလိပ်စာကိုဒေသဆိုင်ရာသင်္ကေတဇယား၊ တက်ကြွသောသင်္ကေတဇယား၊ သို့မဟုတ် (လှုပ်ရှားမှုအကောင်အထည်ဖော်မှုပေါ် မူတည်၍) DWARF debug info စသည့်နယ်ပယ်များတွင်ရှာဖွေလိမ့်မည်။
///
///
/// resolution ကိုဖျော်ဖြေမရနိုင်ခြင်းနှင့်လည်းပိုပြီး Inline လုပ်ဆောင်ချက်များကို၏အမှု၌တစ်ကြိမ်ထက်ကိုခေါ်စေခြင်းငှါလျှင်ပိတ်ပစ်ဟုခေါ်ဝေါ်ခြင်းကိုခံရမည်မဟုတ်ပါ။
///
/// သင်္ကေတကြောင်းလိပ်စာ (ရရှိနိုင်ပါလျှင်) အဘို့အ file/line အားလုံးပြန်လာ, သတ်မှတ်ထားသော `addr` မှာကွပ်မျက်ကိုယ်စားပြုလြှော့။
///
/// သင်၌ `Frame` တစ်ခုရှိပါက `resolve_frame` function ကိုအစားထိုးအသုံးပြုရန်အကြံပြုသည်။
///
/// # လိုအပ်သောအင်္ဂါရပ်များ
///
/// ဤလုပ်ဆောင်မှုသည် `backtrace` crate ၏ `std` အင်္ဂါရပ်ကိုဖွင့်ရန်လိုအပ်ပြီး `std` အင်္ဂါရပ်ကိုမူလအတိုင်းဖွင့်ထားသည်။
///
/// # Panics
///
/// ဒီ function က panic ကိုဘယ်တော့မှမကြိုးစားပါဘူး။ ဒါပေမယ့် `cb` က panics ကိုထောက်ပံ့မယ်ဆိုရင်အချို့သောပလက်ဖောင်းများသည် panic ကိုနှစ်ဆတိုးမြှင့်စေလိမ့်မည်။
/// အချို့သောပလက်ဖောင်းများမှ C စာကြည့်တိုက်ကို သုံး၍ မဖွင့်နိုင်သည့်ပြန်လည်ခေါ်ဆိုမှုများကိုအသုံးပြုသည်။ ထို့ကြောင့် `cb` မှစိုးရိမ်ထိတ်လန့်မှုသည်လုပ်ငန်းစဉ်ကိုရပ်တန့်စေနိုင်သည်။
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // ထိပ်ဘောင်ကိုသာကြည့်ပါ
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// ယခင်ကဖမ်းယူထားသည့် frame ကို symbol တစ်ခုသို့ပြပြီး၊ သတ်မှတ်ထားသော closure ကိုပြပါ။
///
/// ဤ functin သည် `resolve` ကဲ့သို့တူညီသောလုပ်ဆောင်မှုကိုလုပ်ဆောင်သည် မှလွဲ၍ `Frame` ကိုလိပ်စာတစ်ခုအနေနှင့်အငြင်းအခုံအဖြစ်ယူသည်။
/// ၎င်းသည် backtracing ၏အချို့သောပလက်ဖောင်းအကောင်အထည်ဖော်မှုများသည်ပိုမိုတိကျသောသင်္ကေတအချက်အလက်များသို့မဟုတ်ဥပမာ inline frames အကြောင်းသတင်းအချက်အလက်များကိုပေးသည်။
///
/// ဖြစ်နိုင်လျှင်၎င်းကိုအသုံးပြုရန်အကြံပြုပါသည်။
///
/// # လိုအပ်သောအင်္ဂါရပ်များ
///
/// ဤလုပ်ဆောင်မှုသည် `backtrace` crate ၏ `std` အင်္ဂါရပ်ကိုဖွင့်ရန်လိုအပ်ပြီး `std` အင်္ဂါရပ်ကိုမူလအတိုင်းဖွင့်ထားသည်။
///
/// # Panics
///
/// ဒီ function က panic ကိုဘယ်တော့မှမကြိုးစားပါဘူး။ ဒါပေမယ့် `cb` က panics ကိုထောက်ပံ့မယ်ဆိုရင်အချို့သောပလက်ဖောင်းများသည် panic ကိုနှစ်ဆတိုးမြှင့်စေလိမ့်မည်။
/// အချို့သောပလက်ဖောင်းများမှ C စာကြည့်တိုက်ကို သုံး၍ မဖွင့်နိုင်သည့်ပြန်လည်ခေါ်ဆိုမှုများကိုအသုံးပြုသည်။ ထို့ကြောင့် `cb` မှစိုးရိမ်ထိတ်လန့်မှုသည်လုပ်ငန်းစဉ်ကိုရပ်တန့်စေနိုင်သည်။
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // ထိပ်ဘောင်ကိုသာကြည့်ပါ
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// stack ဘောင်ကနေ IP ကိုတန်ဖိုးများကိုအမှန်တကယ် stack သဲလွန်စရဲ့ခေါ်ဆိုမှု *ပြီးနောက်* ပုံမှန်အားသွန်သင် (always?) ဖြစ်ကြသည်။
// ဒီအပေါ်သင်္ကေတပြုလုပ်ခြင်းသည် filename/line နံပါတ်သည်လုပ်ဆောင်မှု၏အဆုံးနီးနေလျှင်၎င်းသည်ရှေ့တွင်တစ်ခုဖြစ်နိုင်သည်။
//
// ၎င်းသည်ပလက်ဖောင်းအားလုံးတွင်အခြေခံအားဖြင့်အမြဲတမ်းဖြစ်လေ့ရှိသည်။ ထို့ကြောင့်ကျွန်ုပ်တို့သည်ပြန်လာသောညွှန်ကြားချက်အစားယခင်ခေါ်ဆိုမှုညွှန်ကြားချက်သို့ဖြေရှင်းရန်ပြတ်ပြတ်သားသားအိုင်ပီတစ်ခုမှအမြဲတမ်းနုတ်ပစ်လိုက်သည်။
//
//
// အကောင်းဆုံးကတော့ဒါကိုကျွန်တော်တို့လုပ်မှာမဟုတ်ဘူး။
// အကောင်းဆုံးကတော့ကျနော်တို့ကိုယ်တိုင် -1 သူတို့သည် *ယခင်* ညွှန်ကြားချက်မဟုတ်ဘဲလက်ရှိတည်နေရာသတင်းအချက်အလက်ချင်သောအကောင့်လုပ်ဖို့ဒီမှာ `resolve` APIs များကိုများ၏ခေါ်ဆိုသူများလိုအပ်ပေလိမ့်မည်။
// အကယ်၍ ကျွန်ုပ်တို့သည်နောက်လာမည့်ညွှန်ကြားချက်သို့မဟုတ်လက်ရှိလိပ်စာအမှန်ဖြစ်ပါက `Frame` ကိုဖော်ထုတ်သင့်သည်။
//
// ယခုအချိန်တွင်၎င်းသည်တော်တော်လေးသောနယ်ပယ်တစ်ခုဖြစ်သော်ငြားလည်းကျွန်ုပ်တို့သည်ပြည်တွင်း၌သာ၎င်းကိုအမြဲနုတ်ပစ်လိုက်သည်။
// စားသုံးသူတွေဟာဆက်လုပ်သင့်ပြီးရလဒ်ကောင်းတွေရသင့်တယ်။
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// က unsynchronized ရဲ့အဖြစ် `resolve` အဖြစ်အတူတူသာ unsafe ။
///
/// ဤလုပ်ဆောင်မှုတွင်ထပ်တူပြုခြင်းအတွက်အာမခံချက်များမရှိသော်လည်းဤ crate ၏ `std` အင်္ဂါရပ်ကိုမဖြည့်ပါကရရှိနိုင်သည်။
/// ပိုပြီးစာရွက်စာတမ်းများနှင့်ဥပမာများအတွက် `resolve` function ကိုကြည့်ရှုပါ။
///
/// # Panics
///
/// `cb` အထိတ်တလန့်ဖြစ်ခြင်းအတွက်သတိပေးချက်များအတွက် `resolve` ၏သတင်းအချက်အလက်ကိုကြည့်ပါ။
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// `resolve_frame` နှင့်အတူတူပင်၊ သူသည်မကူးစက်နိုင်သည့်အန္တရာယ်မရှိပဲသာဖြစ်သည်။
///
/// ဤလုပ်ဆောင်မှုတွင်ထပ်တူပြုခြင်းအတွက်အာမခံချက်များမရှိသော်လည်းဤ crate ၏ `std` အင်္ဂါရပ်ကိုမဖြည့်ပါကရရှိနိုင်သည်။
/// နောက်ထပ်စာရွက်စာတမ်းများနှင့်ဥပမာများအတွက် `resolve_frame` function ကိုကြည့်ပါ။
///
/// # Panics
///
/// `cb` အထိတ်တလန့်ဖြစ်ခြင်းအတွက်သတိပေးချက်များအတွက် `resolve_frame` ၏သတင်းအချက်အလက်ကိုကြည့်ပါ။
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// ဖိုင်တစ်ဖိုင်ထဲမှာသင်္ကေတ၏ဆုံးဖြတ်ချက်ကိုယ်စားပြုတစ်ဦးက trait ။
///
/// ဤ trait သည် trait အရာဝတ္ထုတစ်ခုဖြစ်သည်။ `backtrace::resolve` function ကိုပေးသော closure တွင်အရာဝတ္ထုတစ်ခုအဖြစ်ထွက်ပေါ်လာသည်။ ၎င်းသည်မည်သည့်အကောင်အထည်ဖော်မှုနောက်ကွယ်တွင်ရှိသည်ကိုမသိရသေးသဖြင့်၎င်းကိုလွှတ်လိုက်သည်။
///
///
/// တစ်ဦးကသင်္ကေတဥပမာအမည်, ဖိုင်အမည်လိုင်းအရေအတွက်အတိအကျကိုလိပ်စာ, etc, အ function ကိုအကြောင်းကိုဆက်စပ်သတင်းအချက်အလက်ပေးနိုင်ပါသည်
/// သို့သော်အချက်အလက်အားလုံးသည်သင်္ကေတတစ်ခုတွင်အမြဲတမ်းမရရှိနိုင်သည့်အတွက်နည်းလမ်းအားလုံးသည် `Option` ကိုပြန်ပို့သည်။
///
///
pub struct Symbol {
    // TODO: ဒီတစ်သက်တာဆက်စပ်မှုကိုနောက်ဆုံးမှာ `Symbol` ကိုဆက်လက်ထားရှိရန်လိုအပ်သည်။
    // သို့သော်လက်ရှိကြေကွဲအပြောင်းအလဲပါပဲ။
    // `Symbol` သာအစဉ်အဆက်ကိုကိုးကားခြင်းဖြင့်အထဲကပေးအပ်သည်နှင့်ပုံတူမျိုးပွားမရနိုငျကတည်းကယခုအဘို့ဤဘေးကင်းလုံခြုံသည်။
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// ဒီ function ၏နာမကိုအမှီပြန်ပို့ပေးသည်။
    ///
    /// ပြန်ရောက်ဖွဲ့စည်းပုံသင်္ကေတအမည်နှင့်ပတ်သက်။ အမျိုးမျိုးသောဂုဏ်သတ္တိများမေးမြန်းဖို့အသုံးပြုနိုင်ပါသည်:
    ///
    ///
    /// * `Display` အကောင်အထည်ဖော်မှုသည်ဖျက်သိမ်းခံရသောသင်္ကေတကိုထုတ်ဝေလိမ့်မည်။
    /// * (ကခိုင်လုံသော utf-8 င်လျှင်) သင်္ကေတများ၏ကုန်ကြမ်း `str` တန်ဖိုးကိုဝင်ရောက်နိုင်ပါတယ်။
    /// * အမှတ်အသားအမည်အတွက်ကုန်ကြမ်းက bytes ဝင်ရောက်နိုင်ပါတယ်။
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// ဒီ function ၏စတင်သောလိပ်စာကိုပြန်ပို့ပေးသည်။
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// ဖိုင်အမည်ကိုအချပ်တစ်ခုအဖြစ်ပြန်ပို့သည်။
    /// ၎င်းသည် `no_std` ပတ် ၀ န်းကျင်အတွက်အဓိကအသုံးဝင်သည်။
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// ဤသင်္ကေတသည်လက်ရှိလုပ်ဆောင်နေသည့်နေရာအတွက်ကော်လံနံပါတ်ကိုပြန်ပို့ပေးသည်။
    ///
    /// သာ gimli လက်ရှိ `filename` `Some` ပြန်လည်ရောက်ရှိမှသာလျှင်ဤနေရာတွင်ပင်တန်ဖိုးပေးပါသည်, ထိုသို့အကျိုးဆက်ထို့နောက်အလားတူအတွက်အသိပေးချက်မှဘာသာရပ်တစ်ခုဖြစ်သည်ဒါ။
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// ဒီသင်္ကေတကိုလက်ရှိကွပ်မျက်သည်အဘယ်မှာရှိများအတွက်လိုင်းအရေအတွက်ကပြန်ပို့ပေးသည်။
    ///
    /// `filename` `Some` ပြန်လည်ရောက်ရှိနှင့်အကျိုးဆက်အလားတူအတွက်အသိပေးချက်မှဘာသာရပ်တစ်ခုဖြစ်သည်လျှင်ဒီပြန်လာတန်ဖိုးကိုပုံမှန်အား `Some` ဖြစ်ပါတယ်။
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// ဒီ function ကိုသတ်မှတ်ခံခဲ့ရသည်ရှိရာဖိုင် name ကိုပြန်ပို့ပေးသည်။
    ///
    /// ဤသည်ကို libbacktrace သို့မဟုတ် gimli အသုံးပြုသည့်အချိန်တွင်သာရရှိနိုင်သည် (ဥပမာ
    /// unix တခြားပလက်ဖောင်း) နှင့်တစ်ဦး binary debuginfo နှင့်အတူပြုစုသောအခါ။
    /// ဤအခြေအနေများမတွေ့ဆုံခဲ့ပြီးလျှင်ဖြစ်လျှင်ဤဖွယ်ရှိ `None` ပြန်လာပါလိမ့်မယ်။
    ///
    /// # လိုအပ်သောအင်္ဂါရပ်များ
    ///
    /// ဤလုပ်ဆောင်မှုသည် `backtrace` crate ၏ `std` အင်္ဂါရပ်ကိုဖွင့်ရန်လိုအပ်ပြီး `std` အင်္ဂါရပ်ကိုမူလအတိုင်းဖွင့်ထားသည်။
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // ဒီတစ်ခါလည်းတစ် Rust ပျက်ကွက်အဖြစ်အစိတ်အပိုင်းများသင်္ကေတ parsing လျှင်, C++ သင်္ကေတသရုပျခှဲ။
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // ဒီသုညအရွယ်ထားရန်သေချာအောင်လုပ်ပါ၊ ဒါဆို `cpp_demangle` အင်္ဂါရပ်မသန်စွမ်းသည့်အခါကုန်ကျစရိတ်မရှိပါ။
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// စတာတွေဟာ demangled နာမတော် Ergonomics accessor, ထိုကုန်ကြမ်း bytes, ထိုကုန်ကြမ်း string ကိုပေးမယ့်သင်္ကေတအမည်ဖြင့်လှည့်ပတ်တစ်ဦးက wrapper
///
// `cpp_demangle` အင်္ဂါရပ်ကိုမဖွင့်သည့်အခါသေပြီကုဒ်ကိုခွင့်ပြုပါ။
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// နောက်ခံ bytes များမှအမှတ်အသားအသစ်တစ်ခုကိုဖန်တီးသည်။
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// သင်္ကေတခိုင်လုံသော utf-8 လျှင်တစ်ဦး `str` အဖြစ်ကုန်ကြမ်း (mangled) သင်္ကေတအမည်ဖြင့် Returns ။
    ///
    /// သငျသညျပျက်စီးနေသောဗားရှင်းချင်လျှင် `Display` အကောင်အထည်ဖော်မှုကိုသုံးပါ။
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// bytes များစာရင်းကိုအဖြစ်ပြန်စိုသင်္ကေတအမည်ဖြင့်
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // ဖျက်သိမ်းခံရသောသင်္ကေတသည်အမှန်တကယ်မမှန်ကန်ပါကပုံနှိပ်နိုင်သည်။ ထို့ကြောင့်ပြင်ပ၌မဖြန့်ဝေခြင်းဖြင့်အမှားကိုလျောက်ပတ်စွာကိုင်တွယ်ပါ။
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// လိပ်စာများကိုသင်္ကေတအသုံးပြုသောထို cache memory ကိုပြန်လည်ရယူရန်ကြိုးစားသည်။
///
/// ဤနည်းလမ်းသည်မဟုတ်လျှင်ကမ္ဘာအနှံ့သိုမဟုတ်သိုမဟုတ်သော DWARF သတင်းအချက်အလက်သို့မဟုတ်အလားတူကိုယ်စားပြုသည့်ချည်မျှင်သို့မဟုတ်သိုလှောင်ထားသည့်မည်သည့်ကမ္ဘာလုံးဆိုင်ရာဒေတာဖွဲ့စည်းပုံကိုမဆိုလွှတ်ရန်ကြိုးစားလိမ့်မည်။
///
///
/// # Caveats
///
/// ဒီ function ကိုအမြဲတမ်းရရှိနိုင်ပေမယ့်လက်တွေ့အကောင်အထည်ဖော်မှုအများစုမှာဘာမှမလုပ်ဘူး။
/// dbghelp သို့မဟုတ် libbacktrace တူသော libraries deallocate ပြည်နယ်မှအဆောက်အဦးများကိုနှင့်ခွဲဝေ memory manage ပါဘူး။
/// ယခုဤ crate ၏ `gimli-symbolize` အင်္ဂါရပ်သည်ဤလုပ်ဆောင်ချက်သည်မည်သည့်အကျိုးသက်ရောက်မှုရှိသနည်း။
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}