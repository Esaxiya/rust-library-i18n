//! Windows ပေါ်တွင် dbghelp bindings ကိုစီမံရာတွင်ကူညီရန် module တစ်ခု
//!
//! Windows (အနည်းဆုံး MSVC အတွက်) ရှိ backtraces များသည် `dbghelp.dll` နှင့်၎င်းတွင်ပါ ၀ င်သည့်လုပ်ဆောင်ချက်အမျိုးမျိုးမှတစ်ဆင့်အားသွင်းသည်။
//! ဤလုပ်ဆောင်ချက်များကို `dbghelp.dll` နှင့်အဆက်အစပ်ချိတ်ဆက်ထားခြင်းထက်လက်ရှိအနေဖြင့်၊
//! ၎င်းကိုပုံမှန်စာကြည့်တိုက်မှပြုလုပ်သည် (သီအိုရီအရလိုအပ်သည်)၊ သို့သော်စာကြည့်တိုက်၏ dll မှီခိုမှုများကိုလျှော့ချရန်ကြိုးပမ်းမှုတစ်ခုဖြစ်သည်။
//!
//! ဒါကဖြစ်လျက်ရှိ `dbghelp.dll` အောင်မြင်စွာနီးပါးအမြဲ Windows အပေါ်ဝန်ကပြောပါတယ်။
//!
//! သတိပြုရမည်မှာကျွန်ုပ်တို့သည်ဤအထောက်အပံ့များအားလုံးကို dynamically တင်နေပြီးဖြစ်သောကြောင့်ကျွန်ုပ်တို့သည် `winapi` ရှိ raw definitions ကိုအမှန်တကယ် သုံး၍ မရနိုင်ပါ၊ သို့သော် function pointer အမျိုးအစားများကိုမိမိဘာသာသတ်မှတ်ပြီး၎င်းကိုသုံးရန်လိုသည်။
//! Winapi ပွားခြင်း၏လုပ်ငန်းတွင်ကျွန်ုပ်တို့အမှန်တကယ်ပါဝင်လိုခြင်းမရှိသောကြောင့်ကျွန်ုပ်တို့တွင် Cargo feature တစ်ခုရှိသည် `verify-winapi` ရှိပြီးချည်နှောင်မှုအားလုံးသည် winapi ရှိသူများနှင့်တူညီသည်ဟု CI တွင်ဖော်ပြထားသည်။
//!
//! နောက်ဆုံးအနေနဲ့ `dbghelp.dll` အတွက် dll ဟာဘယ်တော့မှမတင်ဘူးဆိုတာသတိပြုပါ။
//! စဉ်းစားတွေးခေါ်သည်မှာကျွန်ုပ်တို့သည်တကမ္ဘာလုံးတွင်၎င်းကိုသိမ်းဆည်း။ စျေးနှုန်းချိုသာသော loads/unloads ကိုရှောင်ရှားရန် API သို့ခေါ်ဆိုမှုများအကြားသုံးနိုင်သည်။
//! ၎င်းသည်ယိုစိမ့်သောရှာဖွေစက်များအတွက်ပြproblemနာတစ်ခုဖြစ်ပါကကျွန်ုပ်တို့ထိုသို့ရောက်သည့်အခါတံတားကိုဖြတ်ကျော်နိုင်သည်။
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// winapi ကိုယ်နှိုက်တွင်မရှိခြင်းအားဖြင့် `SymGetOptions` နှင့် `SymSetOptions` ပတ်ပတ်လည်တွင်အလုပ်လုပ်ပါ။
// မဟုတ်ရင်ဒီ winapi ကိုနှစ်ခါစစ်ဆေးပြီးမှသာသုံးမှာပါ။
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // winapi မှာမသတ်မှတ်ရသေးဘူး
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // ၎င်းကို winapi တွင်သတ်မှတ်သော်လည်းမမှန်ပါ (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // winapi မှာမသတ်မှတ်ရသေးဘူး
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// ဤ macro သည် `Dbghelp` ဖွဲ့စည်းပုံကိုသတ်မှတ်ရန်အတွက်အသုံးပြုသည်။ ၄ င်းသည်အတွင်းပိုင်းတွင်ကျွန်ုပ်တို့ load လုပ်မည့် function pointers အားလုံးပါဝင်သည်။
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// `dbghelp.dll` အတွက်တင်ထားသော DLL
            dll: HMODULE,

            // ကျနော်တို့ကိုသုံးပါလိမ့်မယ်တစ်ခုချင်းစီကို function ကိုအသီးအသီး function ကို pointer
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // အစပိုင်းတွင် DLL ကိုကျွန်ုပ်တို့မဖွင့်ပါ
            dll: 0 as *mut _,
            // Initiall ၏လုပ်ဆောင်ချက်အားလုံးသည်၎င်းတို့အား dynamically load လုပ်ရန်လိုအပ်သည်ဟု zero ဟုသတ်မှတ်ထားသည်။
            //
            $($name: 0,)*
        };

        // တစ်ခုချင်းစီကို function ကိုအမျိုးအစားများအတွက်အဆင်ပြေ typedef ။
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// `dbghelp.dll` ဖွင့်ရန်ကြိုးစားသည်။
            /// `LoadLibraryW` မအောင်မြင်လျှင်အလုပ်ဖြစ်လျှင်သို့မဟုတ်အမှားလုပ်လျှင်အောင်မြင်မှုကိုပြန်ပို့သည်။
            ///
            /// စာကြည့်တိုက်ရှိပြီးသားလျှင် Panics
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // ကျွန်တော်တို့အသုံးပြုချင်တဲ့နည်းလမ်းတစ်ခုစီအတွက် function ။
            // ၎င်းကိုခေါ်သောအခါ cache function pointer ကိုဖတ်ပါလိမ့်မည်သို့မဟုတ် load လုပ်ကာ loaded value ကိုပြန်ပေးလိမ့်မည်။
            // ဝန်ကိုအောင်မြင်ရန်အခိုင်အမာနေကြသည်။
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // dbghelp လုပ်ဆောင်ချက်များကိုရည်ညွှန်းရန်သန့်ရှင်းသော့ခလောက်များသုံးရန်အဆင်ပြေသော proxy သည်။
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// ဤ crate မှ `dbghelp` API လုပ်ဆောင်ချက်များကိုရယူရန်လိုအပ်သည့်အထောက်အပံ့အားလုံးကိုအစပြုပါ။
///
///
/// ဤလုပ်ဆောင်မှုသည် ** လုံခြုံမှုရှိကြောင်းသတိပြုပါ၊ ၎င်းတွင်ကိုယ်ပိုင်ထပ်တူပြုခြင်းရှိသည်။
/// ဒီ function ကိုအကြိမ်ပေါင်းများစွာအကြိမ်ကြိမ်ခေါ်ခြင်းဟာဘေးကင်းကြောင်းသတိပြုပါ။
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // ကျနော်တို့လုပ်ဖို့လိုအပ်ပါတယ်ပထမဦးဆုံးအရာကဒီ function ကိုတွေကိုတပြိုင်တည်းအလုပ်လုပ်ဖို့ဖြစ်ပါတယ်။၎င်းကိုအခြားချည်များမှတစ်ပြိုင်တည်းသို့မဟုတ်တစ်ချိန်တည်းတွင်ပြန်လည်ခေါ်ယူနိုင်သည်။
        // သတိပြုရန်မှာ၎င်းသည်ထိုထက် ပို၍ မှားသည်။ ဘာလို့လဲဆိုတော့ငါတို့ဒီမှာသုံးနေတဲ့ `dbghelp`* * ဟာဒီလုပ်ငန်းစဉ်မှာရှိတဲ့အခြားခေါ်ဆိုသူအားလုံးနှင့်အတူတူဖြစ်ရန်လိုအပ်သည်။
        //
        // ပုံမှန်အားဖြင့်တူညီသောလုပ်ငန်းစဉ်တစ်ခုအတွင်း `dbghelp` သို့များစွာသောဖုန်းခေါ်ဆိုမှုများသိပ်မရှိလှပါ။ ၎င်းသည်ကျွန်ုပ်တို့က၎င်းကိုသာ ၀ င်ရောက်နေနိုင်သည်ဟုစိတ်ချစွာယူဆနိုင်သည်။
        // သို့သော်ကျွန်ုပ်တို့မူလကအခြားအသုံးပြုသူတစ် ဦး ရှိသည်မှာကျွန်ုပ်တို့ကိုယ်တိုင်စိတ်ပူစရာမလိုတော့ဘဲပုံမှန်စာကြည့်တိုက်တွင်ရှိသည်။
        // Rust စံစာကြည့်တိုက်သည် backtrace အထောက်အပံ့အတွက်ဤ crate ပေါ်တွင်မူတည်သည်။ ဤ crate သည်လည်း crates.io တွင်ရှိသည်။
        // ဆိုလိုသည်မှာ အကယ်၍ standard library သည် panic backtrace ကိုပုံနှိပ်ထုတ်ဝေလျှင် crate သည် crates.io မှလာသည်နှင့် segfaults ကိုဖြစ်ပေါ်စေနိုင်သည်။
        //
        // ဤထပ်တူပြုခြင်းပြproblemနာကိုဖြေရှင်းရန်ကျွန်ုပ်တို့သည် Windows ၏တိကျသောလှည့်ကွက်တစ်ခုကိုဤနေရာတွင်အသုံးပြုသည်။
        // ဤခေါ်ဆိုမှုကိုကာကွယ်ရန်ကျွန်ုပ်တို့သည် *session-local* အမည်ရှိ mutex ကိုဖန်တီးသည်။
        // ဒီမှာရည်ရွယ်ချက်ကိုစံစာကြည့်တိုက်နှင့်ဤ crate ကဒီမှာတွေကိုတပြိုင်တည်းအလုပ်လုပ်မှ Rust-Level APIs များကိုဝေမျှဖို့ရှိသည်ပေမယ်နောက်ကွယ်မှအစားအလုပ်အချင်းချင်းတယောက်ကိုတယောက်နှင့်အတူသေချာသူတို့နေတဲ့ synchronous အောင်လုပ်နိုင်ကြဘူးဆိုတာပါပဲ။
        //
        // ဒီ function ကို standard library မှသို့မဟုတ် crates.io ကတဆင့်ခေါ်တဲ့အခါမှာတော့ mutex ကိုအတူတူဝယ်ယူလိုက်တာသေချာပါတယ်။
        //
        // ဒါတွေအားလုံးပြောရမယ်ဆိုရင်ပထမဆုံးဒီမှာလုပ်ရတာက Windows မှာ mutex လို့ခေါ်တဲ့ `HANDLE` တစ်ခုကို atomically ဖန်တီးလိုက်တာပါပဲ။
        // ဤ function ကိုမျှဝေထားသောအခြားချည်များနှင့်အနည်းငယ်နည်းနည်းထပ်တူပြုသည်။ ဤလုပ်ဆောင်မှုအတွက်လက်ကိုင်တစ်ခုတည်းကိုသာဖန်တီးနိုင်သည်။
        // ကမ္ဘာလုံးဆိုင်ရာသိမ်းဆည်းထားသည့်အခါလက်ကိုင်ဘယ်တော့မှမပိတ်ကြောင်းသတိပြုပါ။
        //
        // သော့ခတ်သွားပြီးသည့်နောက်တွင်ကျွန်ုပ်တို့သည်ရိုးရိုးရှင်းရှင်းသာဝယ်ယူလိုက်ပြီး၊ ကျွန်ုပ်တို့လက်ဖြန့်ချိသော `Init` ကိုင်တွယ်မှုသည်နောက်ဆုံးတွင်၎င်းကိုဖယ်ရှားရန်တာ ၀ န်ရှိသည်။
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // အိုကေ!ယခုကျွန်ုပ်တို့အားလုံးလုံခြုံစွာထပ်တူပြုခြင်းပြုလုပ်ပြီးပါက၊ အရာအားလုံးကိုစတင်လုပ်ဆောင်ကြပါစို့။
        // ပထမ ဦး စွာ `dbghelp.dll` ကိုဤဖြစ်စဉ်တွင်အမှန်တကယ်တင်ထားကြောင်းသေချာစေရန်လိုအပ်သည်။
        // ကျွန်ုပ်တို့သည်ငြိမ်မှီခိုမှုကိုရှောင်ရှားရန်ကျွန်ုပ်တို့သည်ဤနည်းအားဖြင့်တက်ကြွစွာလုပ်ဆောင်သည်။
        // ၎င်းသည်ထူးဆန်းသောချိတ်ဆက်မှုပြaroundနာများနှင့် ပတ်သတ်၍ သမိုင်းကြောင်းအရပြုခဲ့ပြီး၎င်းသည်များသောအားဖြင့် debugging utility ဖြစ်သောကြောင့် binaries များကိုပိုမိုသယ်ဆောင်နိုင်စေရန်ရည်ရွယ်သည်။
        //
        //
        // `dbghelp.dll` ကိုဖွင့်လိုက်တာနဲ့ initialization functions အချို့ကိုခေါ်ရန်လိုသည်။
        // သို့သော်ဤအရာကိုတစ်ကြိမ်တည်းသာပြုလုပ်သောကြောင့်ကျွန်ုပ်တို့ပြီးမြောက်သည်၊ မပြီးသည်ကိုကမ္ဘာလုံးဆိုင်ရာ Boolean ရရှိထားသည်။
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // `SYMOPT_DEFERRED_LOADS` အလံကိုသေချာစွာစစ်ဆေးပါ။ ဘာလို့လဲဆိုတော့ MSVC ရဲ့ကိုယ်ပိုင်မှတ်တမ်းများ-"This is the fastest, most efficient way to use the symbol handler." အရဆိုပါစို့။
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // တကယ်တော့ MSVC နှင့်အတူသင်္ကေတများစတင်။သတိပြုရမည်မှာ၊ ၎င်းသည်ကျရှုံးနိုင်သည်၊ သို့သော်ကျွန်ုပ်တို့သည်လျစ်လျူရှုထားသည်။
        // အဲဒီမှာဒီဟာကိုကြိုတင်စီစဉ်ထားတဲ့ပန်းချီကားတစ်ချပ်လောက်တော့မရှိပါဘူး။ ဒါပေမယ့် LLVM ကပြည်တွင်းမှာဒီကနေပြန်လာတဲ့တန်ဖိုးကိုလျစ်လျူရှုထားပုံရတယ်။ LLVM ရှိသန့်ရှင်းရေးဆေးစာကြည့်တိုက်တစ်ခုကဒီဟာမအောင်မြင်ပေမယ့်ရေရှည်မှာအခြေခံအားဖြင့်လျစ်လျူရှုမယ်ဆိုရင်ကြောက်စရာကောင်းတဲ့သတိပေးချက်ထုတ်ပေးပါတယ်။
        //
        //
        // ဖြစ်ရပ်တစ်ခုမှာ Rust အတွက်အလွန်များပြားသောအရာတစ်ခုမှာ standard library နှင့် crates.io ရှိ crate နှစ်ခုလုံးသည် `SymInitializeW` အတွက်ယှဉ်ပြိုင်လိုကြသည်။
        // စံပြစာကြည့်တိုက်သည်သမိုင်းကြောင်းအရအများစုကိုရှင်းလင်းပြီးနောက်အချိန်အများစုကိုရှင်းလင်းခဲ့သည်။ သို့သော်ယခု၎င်း crate ကိုအသုံးပြုနေသည်ဆိုလျှင်တစ်စုံတစ် ဦး က ဦး စွာစတင်ခြင်းကိုဆိုလိုသည်။
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}