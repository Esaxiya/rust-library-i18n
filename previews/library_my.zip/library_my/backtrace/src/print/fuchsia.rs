use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr သည်လုပ်ငန်းစဉ်နှင့်ဆက်စပ်လျက်ရှိသော DSO တိုင်းအတွက် dl_phdr_info pointer ကိုလက်ခံရရှိလိမ့်မည်။
    // dl_iterate_phdr သည် dynamic linker ကိုအစမှအဆုံးကြားတွင်သော့ခတ်ထားကြောင်းသေချာစေသည်။
    // အဆိုပါပြန်ခေါ် non-သုညပြန်လည်ရောက်ရှိ အကယ်. တန်ဖိုးကြားမှာအစောပိုင်းရပ်စဲသည်။
    // 'data' တစ် ဦး ချင်းစီခေါ်ဆိုမှုအပေါ်ပြန်ခေါ်မှတတိယအငြင်းအခုံအဖြစ်လွန်လိမ့်မည်။
    // 'size' အဆိုပါ dl_phdr_info ၏အရွယ်အစားကိုပေးသည်။
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// ကျနော်တို့တည်ဆောက် ID နှင့်ကျွန်တော်ကောင်းစွာအဖြစ် elf spec ထံမှပစ္စည်းပစ္စယအနည်းငယ်လိုအပ်ပါတယ်သောနည်းလမ်းများအချို့သောအခြေခံအစီအစဉ်ကို header ကိုဒေတာထုတ်ဆန်းစစ်ရန်လိုအပ်သည်။
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// ယခုငါတို့, fuchsia ရဲ့လက်ရှိပြောင်းလဲနေသော linker အသုံးပြုတဲ့ dl_phdr_info အမျိုးအစားများ၏ဖွဲ့စည်းတည်ဆောက်ပုံနည်းနည်းအဘို့ bit နဲ့ပုံတူပွားဖို့ရှိသည်။
// ခရိုမီယမ်တွင်ဤ ABI နယ်နိမိတ်အပြင် crashpad လည်းရှိသည်။
// နောက်ဆုံးတွင်ကျွန်ုပ်တို့သည်ဤအမှုများအား elf-search အသုံးပြုရန်ရွှေ့ပြောင်းလိုသော်လည်း SDK တွင်၎င်းကိုပြုလုပ်ရန်မလိုအပ်သေးပေ။
//
// ထို့ကြောင့်ကျွန်ုပ်တို့ (နှင့်သူတို့) သည် fuchsia libc နှင့်တင်းကျပ်စွာဆက်နွယ်မှုကိုဖြစ်ပေါ်စေသောဤနည်းလမ်းကိုအသုံးပြုရန်လိုအပ်နေသည်။
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // e_phoff နှင့် e_phnum မှန်မမှန်စစ်ဆေးရန်ကျွန်ုပ်တို့မသိသေးပါ။
    // libc ကဒါကိုသေချာအောင်လုပ်သင့်တယ်၊
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr သည် 64-bit ELF program header ကိုကိုယ်စားပြုသည်။
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr ခိုင်လုံသော elf အစီအစဉ်ကိုခေါင်းစဉ်နှင့်၎င်း၏ contents တွေကိုကိုယ်စားပြုပါတယ်။
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // p_addr သို့မဟုတ် p_memsz ဟုတ်မဟုတ်စစ်ဆေးရန်ကျွန်ုပ်တို့တွင်နည်းလမ်းမရှိသေးပါ။
    // Fuchsia ၏ libc သည်မှတ်စုများကိုပထမ ဦး ဆုံးခွဲခြမ်းစိတ်ဖြာထားသည်။ ထို့ကြောင့်ဤနေရာတွင်ရောက်ရှိနေခြင်းကြောင့်ဤခေါင်းစီးများသည်မှန်ကန်ရမည်။
    //
    // NoteIter သည်အခြေခံအချက်အလက်များကိုတရားဝင်ဖြစ်ရန်မလိုအပ်သော်လည်း၎င်းသည်ခိုင်လုံသောသတ်မှတ်ချက်များကိုလိုအပ်သည်။
    // libc ကဒီကိစ္စနဲ့ပတ်သက်ပြီးဒီကိစ္စကိုသေချာအောင်လုပ်ဖို့ကျွန်တော်တို့ယုံကြည်တယ်။
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// တည်ဆောက်ရန် ID များအတွက်မှတ်စုအမျိုးအစား။
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr သည် target ၏အဆုံးသတ်တွင် ELF note header ကိုကိုယ်စားပြုသည်။
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Note သည် ELF note (header + contents) ကိုကိုယ်စားပြုတယ်။
// ဘာလို့လဲဆိုတော့အမြဲတမ်း null အဆုံးသတ်ခြင်းမဟုတ်ဘဲ rust က bytes များသည်မည်သည့်အရာနှင့်မဆိုကိုက်ညီမှုရှိစေရန်လွယ်ကူစေလို့အမည်ကို u8 အချပ်တစ်ခုအဖြစ်ကျန်ရစ်ခဲ့တယ်။
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter သင်သည်လုံခြုံစွာနေတဲ့မှတ်စု segment ကိုကျော် iterate ပေးနိုင်ပါတယ်။
// အမှားတစ်ခုဖြစ်ပေါ်လာသည်သို့မဟုတ်မှတ်စုများမရှိတော့ပါ။
// အကယ်၍ မှန်ကန်သောအချက်အလက်များကိုသင်ထပ်တလဲလဲပြုလုပ်ပါကမှတ်စုများကိုရှာမတွေ့သကဲ့သို့၎င်းသည်အလုပ်လုပ်လိမ့်မည်။
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // ဒါဟာ pointer နဲ့အရွယ်အစားအားလုံးကိုဖတ်နိုင် bytes ၏ denote ခိုင်လုံသောအကွာအဝေးပေးထားသောကြောင့် function ကိုတစ်ဦးလျော့ပါးသွားမည်ဖြစ်သလိုဖြစ်ပါတယ်။
    // ဤ bytes များ၏ပါဝင်မှုများသည်မည်သည့်အရာမဆိုဖြစ်နိုင်သည်။
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to သည် 'x' ကို 'to'-byte alignment' သို့ 'to' သည်စွမ်းအားသည် ၂ ၏စွမ်းအားဖြစ်သည်။
// ဤသည်မှာ (x + to, 1)&-to ကိုအသုံးပြုသော C/C ++ ELF parsing ကုဒ်ရှိစံပုံစံတစ်ခုဖြစ်သည်။
// Rust သည်အသုံးပြုမှုအားသင်အားခွင့်မပြုပါ။ ထို့ကြောင့်ကျွန်ုပ်အသုံးပြုသည်
// ကြောင်းထပ်ဖွ 2's-အဖြည့်ပြောင်းလဲခြင်း။
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 သည် (ကရှိလျှင်) အချပ်မှ num bytes ကိုစားသုံးပြီးနောက်ဆုံးအချပ်ကိုမှန်ကန်စွာကိုက်ညီမှုရှိစေရန်သေချာစေသည်။
// တောင်းဆိုသော bytes အရေအတွက်သည်များလွန်းနေပါက၊ ကျန်ရှိနေသော bytes များမလုံလောက်ခြင်းကြောင့် slice ကိုပြန်လည် ပြင်ဆင်၍ မရပါကအဘယ်သူမျှမပြန်လာဘဲထို slice ကိုပြုပြင်မထားပါ။
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// ဒီ function ဟာခေါ်ဆိုသူ၏ 'bytes' စွမ်းဆောင်ရည် (နှင့်အချို့ဗိသုကာမှန်ကန်မှုအပေါ်) အတွက် aligned သင့်ကြောင်းဖြစ်ကောင်းထက်အခြားထောက်ရမယ်မျှစစ်မှန်သောလျော့ပါးသွားမည်ဖြစ်သလိုရှိပါတယ်။
// Elf_Nhdr နယ်ပယ်ရှိတန်ဖိုးများသည်အနတ္တဖြစ်ကောင်းဖြစ်မည်။
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // ဒါဟာတာရှည်ရှိအလုံအလောက်အာကာသဖြစ်ပါတယ်ကျနော်တို့ကဒီအန္တရာယ်မကင်းမဖြစ်သင့်ဒီတော့အထက်ဆိုပါကကြေညာချက်တွင်အတည်ပြုသကဲ့သို့လုံခြုံစိတ်ချရသောဖြစ်ပါတယ်။
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // သတိပြုပါ။ sice_of: :<Elf_Nhdr>() အစဉ်အမြဲ 4-byte aligned ဖြစ်ပါတယ်။
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // အဆုံးရောက်ပြီလားဆိုတာစစ်ဆေးပါ။
        if self.base.len() == 0 || self.error {
            return None;
        }
        // ကျွန်ုပ်တို့သည် nhdr တစ်ခုကိုထုတ်လွှင့်သော်လည်း၎င်းသည်ရရှိလာသော struct ကိုသေချာစွာစဉ်းစားသည်။
        // ကျနော်တို့ namesz သို့မဟုတ် descsz မယုံကြည်ကြဘူးကျနော်တို့အမျိုးအစားပေါ်အခြေခံပြီးမျှမလုံခြုံဆုံးဖြတ်ချက်များပါစေ။
        //
        // ဒါကြောင့်ကျွန်တော်တို့အမှိုက်သရိုက်အပြည့်အ ၀ ထွက်လာရင်တောင်လုံခြုံမှုရှိရမယ်။
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// segment တစ်ခုသည် executable ဖြစ်သည်ကိုညွှန်ပြသည်။
const PERM_X: u32 = 0b00000001;
/// တစ်အစိတ်အပိုင်း writable ကြောင်းဖော်ပြသည်။
const PERM_W: u32 = 0b00000010;
/// အစိတ်အပိုင်းတစ်ခုဖတ်လို့ရအောင်ဖော်ပြသည်။
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// runtime တွင် ELF segment တစ်ခုကိုကိုယ်စားပြုသည်။
struct Segment {
    /// ဤအပိုင်း၏ contents ၏ runtime virtual address ကိုပေးသည်။
    addr: usize,
    /// ဒီအပိုင်းရဲ့ contents ရဲ့မှတ်ဉာဏ်အရွယ်ကိုပေးသည်။
    size: usize,
    /// ဤအပိုင်း၏ module address ကို ELF ဖိုင်ဖြင့်ပေးသည်။
    mod_rel_addr: usize,
    /// ELF ဖိုင်တွင်တွေ့ရှိသောခွင့်ပြုချက်ကိုပေးသည်။
    /// သို့သော်ဤခွင့်ပြုချက်များသည် runtime တွင်ရောက်ရှိနေသောခွင့်ပြုချက်များမဟုတ်ပါ။
    flags: Perm,
}

/// တစ်ဦး DSO ကနေအပိုင်းကျော်တဦးတည်းကြားမှာပေးနိုင်ပါတယ်။
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// ELF DSO (Dynamic Shared Object) ကိုကိုယ်စားပြုသည်။
/// ဤအမျိုးအစားသည်၎င်း၏ကိုယ်ပိုင်မိတ္တူကူးယူခြင်းထက်အမှန်တကယ် DSO တွင်သိမ်းထားသောဒေတာများကိုရည်ညွှန်းသည်။
struct Dso<'a> {
    /// dynamic linker ကအမြဲတမ်းနာမည်တစ်ခုပေးတယ်၊
    /// အဓိက executable ၏အမှု၌ဤနာမကိုအမှီဖြစ်လိမ့်မည်။
    /// တစ်ဦး shared အရာဝတ္ထု၏ဖြစ်ရပ်အတွက် (DT_SONAME ကြည့်ပါ) soname ဖြစ်လိမ့်မည်။
    name: &'a str,
    /// Fuchsia တွင် binaries အားလုံးနီးပါးမှာ ID တွေတည်ဆောက်ထားကြတာဖြစ်ပေမယ့်ဒါကမလုံလောက်ပါဘူး။
    /// DSO အချက်အလက်များကို build_id မရှိပါကနောက်ဆက်တွဲစစ်မှန်သော ELF ဖိုင်နှင့်ကိုက်ညီရန်နည်းလမ်းမရှိပါ။ ထို့ကြောင့် DSO တိုင်းတွင်ဤနေရာရှိရန်လိုအပ်သည်။
    ///
    /// build_id မပါသော DSO များသည်လျစ်လျူရှုခံရသည်။
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// ဤ DSO ရှိအပိုင်းများမှကြားဖြတ်တစ်ခုကိုပြန်ပို့သည်။
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// ဤအမှားများသည် DSO တစ်ခုချင်းစီ၏သတင်းအချက်အလက်များကိုခွဲခြမ်းစိတ်ဖြာနေစဉ်ပေါ်ပေါက်လာသောပြissuesနာများကို encode လုပ်သည်
///
enum Error {
    /// တစ်ဦး rust string ကိုသို့ကို C စတိုင် string ကိုပြောင်းလဲနေချိန်တွင်မှားယွင်းမှုတစ်ခုဖြစ်ပွားခဲ့သည်ကြောင်း NameError နည်းလမ်းများ။
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError ဆိုသည်မှာကျွန်ုပ်တို့သည်တည်ဆောက်မှု ID ကိုမတွေ့ပါဟုဆိုလိုသည်။
    /// DSO တွင် build ID မရှိပါသို့မဟုတ် build ID ပါဝင်သော segment သည်ပုံပျက်သောကြောင့်ဖြစ်နိုင်သည်။
    ///
    BuildIDError,
}

/// တစ်ခုချင်းစီကို DSO အဘို့ဖုန်းခေါ်ဆိုမှု 'dso' သို့မဟုတ် 'error' ဖြစ်စေသည့်ပြောင်းလဲနေသော linker နေဖြင့်လုပ်ငန်းစဉ်သို့နှင့်ဆက်စပ်။
///
///
/// # Arguments
///
/// * `visitor` - DSO foreach ကိုခေါ်စားနည်းလမ်းများ၏တဦးတည်းရှိလိမ့်မည်ဟုတစ်ဦးက DsoPrinter ။
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr က info.name သည်မှန်ကန်သောတည်နေရာကိုညွှန်ပြလိမ့်မည်။
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// ဤလုပ်ဆောင်ချက်သည် DSO တွင်ပါ ၀ င်သောအချက်အလက်အားလုံးအတွက် Fuchsia ၏အမှတ်အသားပြုသည့်အမှတ်အသားကိုပုံနှိပ်သည်။
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}