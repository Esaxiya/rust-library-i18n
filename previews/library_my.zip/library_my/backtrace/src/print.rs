#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// backtraces များအတွက်တစ်ဦးက formatter ။
///
/// ဒီအမျိုးအစားမခွဲခြားဘဲအဆိုပါ backtrace ကိုယ်တိုင်ကမှလာသည့်နေရာတွင်တစ် backtrace print ထုတ်ဖို့အသုံးပြုနိုင်ပါသည်။
/// သင့်တွင် `Backtrace` အမျိုးအစားရှိပါက၎င်း၏ `Debug` အကောင်အထည်ဖော်မှုသည်ဤပုံနှိပ်ခြင်းပုံစံကိုအသုံးပြုပြီးဖြစ်သည်။
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// ကျနော်တို့ပုံနှိပ်နိုင်သည်သောပုံနှိပ်ခြင်း၏စတိုင်များ
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// သက်ဆိုင်သောသတင်းအချက်အလက်များကိုသာထည့်သွင်းထားသည့် terser backtrace ကိုပုံနှိပ်သည်
    Short,
    /// ဖြစ်နိုင်သမျှသတင်းအချက်အလက်အားလုံးပါရှိသော backtrace ကိုပုံနှိပ်ထားသည်
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// ပေးထားသည့် `fmt` မှ output ကိုရေးထားမည်သည့်သစ်တစ်ခု `BacktraceFmt` ဖန်တီးပါ။
    ///
    /// `format` argument သည် backtrace ပုံနှိပ်သောပုံစံကိုထိန်းချုပ်လိမ့်မည်။ `print_path` argument သည် filenames ၏ `BytesOrWideString` instances ကို print ထုတ်ရန်အသုံးပြုသည်။
    /// ဒီအမျိုးအစားကိုယ်နှိုက်ကမည်သည့်ဖိုင်နာမည်ကိုမှပုံနှိပ်ခြင်းမပြုပါဘူး၊ သို့သော်ပြန်လည်ခေါ်ဆိုရန်လိုအပ်ပါသည်။
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// ပုံနှိပ်ခံရဖို့ ပတ်သက်. backtrace များအတွက်နိဒါန်းပရင့်ထုတ်ရန်။
    ///
    /// ဤသည်ကိုအပြည့်အနောက်ပိုင်းမှာ symbolicated ခံရဖို့နှင့်မဟုတ်ရင်ဒီရုံသင်တစ်ဦး `BacktraceFmt` ဖန်တီးပြီးတဲ့အခါသူ့ရဲ့ကိုပဌနာကိုပထမဦးဆုံးနည်းလမ်းဖြစ်သင့် backtraces တချို့ပလက်ဖောင်းများပေါ်တွင်လိုအပ်ပါသည်။
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// backtrace output သို့ frame တစ်ခုကိုထပ်ထည့်သည်။
    ///
    /// ဒါဟာပြန်အမှန်တကယ်တစ်ဦးသည် frame print ထုတ်ဖို့အသုံးပြုနိုင်ပြီးနှင့်အဗဒ္ဒုန်ပေါ်မှာ frame ကိုတန်ပြန်တိုးတံ့သောတစ်ဦး `BacktraceFrameFmt` တစ်ခု RAII ဥပမာအားဖြင့်ကျူးလွန်။
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// အဆိုပါ backtrace output ကိုပြီးဆုံး။
    ///
    /// ဤသည်ကိုလက်ရှိတွင်အဘယ်သူမျှမ op ပေမယ့် backtrace ပုံစံများနှင့် future လိုက်ဖက်တဲ့များအတွက်ထည့်သွင်းထားသည်။
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // လက်ရှိ fookure ဖြည့်စွက်မှုများအတွက်ခွင့်ပြုရန်ဤ hook အပါအ ၀ င်လက်ရှိတွင် no-op-- ဖြစ်သည်။
        Ok(())
    }
}

/// backtrace တစ်ခု၏ frame တစ်ခုအတွက် formatter ။
///
/// ဤအမျိုးအစားကို `BacktraceFmt::frame` function ဖြင့်ဖန်တီးသည်။
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// ဒီ frame formatter နှင့်အတူ `BacktraceFrame` ပုံနှိပ်။
    ///
    /// ဤသည်မှာ `BacktraceSymbol` အတွင်းရှိ `BacktraceSymbol` instances အားလုံးကိုပြန်လည်ပုံနှိပ်ပေးလိမ့်မည်။
    ///
    /// # လိုအပ်သောအင်္ဂါရပ်များ
    ///
    /// ဤလုပ်ဆောင်မှုသည် `backtrace` crate ၏ `std` အင်္ဂါရပ်ကိုဖွင့်ရန်လိုအပ်ပြီး `std` အင်္ဂါရပ်ကိုမူလအတိုင်းဖွင့်ထားသည်။
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// `BacktraceFrame` တစ်ခုအတွင်း `BacktraceSymbol` တစ်ခုကိုပုံနှိပ်ထုတ်ဝေသည်။
    ///
    /// # လိုအပ်သောအင်္ဂါရပ်များ
    ///
    /// ဤလုပ်ဆောင်မှုသည် `backtrace` crate ၏ `std` အင်္ဂါရပ်ကိုဖွင့်ရန်လိုအပ်ပြီး `std` အင်္ဂါရပ်ကိုမူလအတိုင်းဖွင့်ထားသည်။
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: ဒီဟာကဘာမှပုံနှိပ်ထုတ်ဝေတာကိုမရပ်တန့်နိုင်တာသိပ်မကောင်းဘူး
            // Non-utf8 ဖိုင်အမည်များနှင့်အတူ။
            // ကျေးဇူးတင်စရာကအရာရာတိုင်းဟာ utf8 ပါ။ ဒီတော့ဒါအရမ်းမများသင့်ပါဘူး။
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// တစ်ကုန်ကြမ်းပုံမှန်အားဖြင့်ဒီ crate များ၏ကုန်ကြမ်းပြန်ခေါ်အတွင်းကနေ `Frame` နှင့် `Symbol` ခြေရာခံအားပရင့်ထုတ်ရန်။
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// backtrace output သို့ raw frame တစ်ခုကိုထပ်ထည့်သည်။
    ///
    /// ဤနည်းလမ်းသည်ယခင်နှင့်မတူဘဲ၎င်းတို့သည်နေရာအမျိုးမျိုးမှအရင်းအမြစ်ဖြစ်လျှင်အငြင်းပွားမှုများကိုဖြေရှင်းသည်။
    /// ဒီတစ်ခုဘောင်များအတွက်အကြိမ်ပေါင်းများစွာခေါ်တော်မူစေခြင်းငှါမှတ်ချက်။
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// ကော်လံသတင်းအချက်အလက်အပါအဝင် backtrace output ကိုတစ်ကုန်ကြမ်းဘောင်, ကထပ်ပြောသည်။
    ///
    /// ဤနည်းလမ်းသည်ယခင်ကဲ့သို့ပင်ကွဲပြားခြားနားသောနေရာများမှအရင်းအမြစ်ဖြစ်လျှင်အငြင်းပွားမှုများကိုဖြေရှင်းသည်။
    /// ဒီတစ်ခုဘောင်များအတွက်အကြိမ်ပေါင်းများစွာခေါ်တော်မူစေခြင်းငှါမှတ်ချက်။
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia ကြောင့်နောက်ပိုင်းမှာသင်္ကေတကိုအသုံးပြုနိုင်သည့်အထူး format နဲ့ရှိပါတယ်ဒါလုပ်ငန်းစဉ်အတွင်းသင်္ကေတနိုင်ခြင်းဖြစ်ပါတယ်။
        // လိပ်စာများကိုဤနေရာတွင်ကိုယ်ပိုင်ပုံစံဖြင့်ပုံနှိပ်မည့်အစားပုံနှိပ်ပါ။
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // "null" frames များကိုပုံနှိပ်ရန်မလိုအပ်ပါ။ အခြေခံအားဖြင့် system backtrace သည်အလွန်ဝေးကွာသောလမ်းကြောင်းကိုပြန်လည်ရှာဖွေရန်စိတ်အားထက်သန်နေသည်။
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Sgx enclave တွင် TCB အရွယ်အစားကိုလျော့ချရန်ကျွန်ုပ်တို့သည် symbol resolution လုပ်ဆောင်ချက်ကိုအကောင်အထည်ဖော်ရန်မလိုပါ။
        // အဲဒီအစားကျနော်တို့ဒီမှာ function ကိုပြင်ပေးရန်နောက်ပိုင်းတွင်တစ်ခုသို့ဆက်စပ်နိုင်သည့်လိပ်စာ၏ offset print ထုတ်နိုင်ပါတယ်။
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // frame ရဲ့အညွှန်းကိန်းအဖြစ် frame ရဲ့ optional ကိုညွှန်ကြားချက် pointer ကို print ထုတ်။
        // အကယ်၍ ကျွန်ုပ်တို့သည်ဤ frame ၏ပထမဆုံးသင်္ကေတထက်ကျော်လွန်ပါကသင့်လျော်သော whitespace ကိုသာပုံနှိပ်နိုင်သည်။
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // ကျွန်တော်တစ်ဦးအပြည့်အဝ backtrace ဆိုရင်နောက်ထပ်သတင်းအချက်အလက်များအဘို့ကို format အခြားသုံးပြီးသင်္ကေတအမည်ဖြင့်ထုတ်ရေးတက်ယင်းနောက်။
        // ဒီမှာတော့နာမည်မရှိတဲ့သင်္ကေတများကိုလည်းကိုင်တွယ်တယ်။
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // နောက်ဆုံးအနေနဲ့ filename/line number ကိုရရှိရင်ထုတ်ထုတ်ပါ။
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line ဒီတော့ညာဘက်-align ကိုယျ့ကိုယျကို၏မျိုးအချို့သင့်လျော်သောကြားနေရာလွတ် print ထုတ်, သင်္ကေတအမည်အောက်တွင်လိုင်းများပေါ်တွင်ပုံနှိပ်နေကြသည်။
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // အဆိုပါဖိုင်အမည် print ထုတ်ပြီးတော့လိုင်းအရေအတွက်ကထွက် print ထုတ်နိုင်ဖို့ကျွန်တော်တို့ရဲ့ပြည်တွင်းရေးပြန်ခေါ်ရန်လွှဲအပ်။
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // ရရှိနိုင်လျှင်, ကော်လံအရေအတွက်ကိုထည့်ပါ။
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // ကျွန်ုပ်တို့သည် frame ၏ပထမဆုံးသင်္ကေတကိုသာအလေးထားသည်
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}