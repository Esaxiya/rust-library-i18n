use core::ffi::c_void;
use core::fmt;

/// လက်ရှိ call-stack ကိုစစ်ဆေးသည်၊ တက်ကြွသော frame များအားလုံးကို stack သဲလွန်စကိုတွက်ချက်ရန်အတွက်ပေးသည့် closure ထဲသို့ဖြတ်သွားသည်။
///
/// ဤလုပ်ဆောင်ချက်သည်ပရိုဂရမ်တစ်ခုအတွက် stack သဲလွန်စများကိုတွက်ချက်ရာတွင်ဤစာကြည့်တိုက်၏လုပ်ငန်းခွင်တွင်းဖြစ်သည်။ပေးထားသော closure `cb` သည် stack ရှိခေါ်ဆိုမှုဘောင်အကြောင်းသတင်းအချက်အလက်ကိုကိုယ်စားပြုသော `Frame` ၏သာဓကများဖြစ်သည်။
/// ပိတ်ခြင်းကိုအပေါ်မှအောက်ဖက်ပုံစံဖြင့်ထုတ်လုပ်ထားသည် (မကြာသေးမီကလုပ်ဆောင်ချက်များကိုပထမဆုံးခေါ်သည်) ။
///
/// closure ၏ return value သည် backtrace ဆက်လက်လုပ်ဆောင်သင့်မသင့်ကိုပြသသည်။`false` ၏ return value တစ်ခုသည် backtrace ကိုအဆုံးသတ်ပြီးချက်ချင်းပြန်ရောက်လိမ့်မည်။
///
/// `Frame` တစ်ခုကိုဝယ်ယူပြီးလျှင် `ip` (ညွှန်ကြားချက်ညွှန်း) သို့မဟုတ်သင်္ကေတလိပ်စာလိပ်စာကို `Symbol` သို့ပြောင်းရန် `backtrace::resolve` ကိုသင်ခေါ်ကောင်းလိုလိမ့်မည်။ ၎င်းမှတစ်ဆင့်အမည်နှင့်/သို့မဟုတ်ဖိုင်အမည်/လိုင်းနံပါတ်ကိုသင်ယူနိုင်သည်။
///
///
/// ၎င်းသည်အဆင့်နိမ့်သောလုပ်ဆောင်မှုတစ်ခုဖြစ်သည်ကိုသတိပြုပါ။ ဥပမာအားဖြင့်သင်နောက်မှစစ်ဆေးရန်နောက်ကြောင်းပြန်တစ်ခုကိုဖမ်းယူလိုပါက `Backtrace` အမျိုးအစားသည် ပို၍ သင့်တော်လိမ့်မည်။
///
/// # လိုအပ်သောအင်္ဂါရပ်များ
///
/// ဤလုပ်ဆောင်မှုသည် `backtrace` crate ၏ `std` အင်္ဂါရပ်ကိုဖွင့်ရန်လိုအပ်ပြီး `std` အင်္ဂါရပ်ကိုမူလအတိုင်းဖွင့်ထားသည်။
///
/// # Panics
///
/// ဒီ function က panic ကိုဘယ်တော့မှမကြိုးစားပါဘူး။ ဒါပေမယ့် `cb` က panics ကိုထောက်ပံ့မယ်ဆိုရင်အချို့သောပလက်ဖောင်းများသည် panic ကိုနှစ်ဆတိုးမြှင့်စေလိမ့်မည်။
/// အချို့သောပလက်ဖောင်းများမှ C စာကြည့်တိုက်ကို သုံး၍ မဖွင့်နိုင်သည့်ပြန်လည်ခေါ်ဆိုမှုများကိုအသုံးပြုသည်။ ထို့ကြောင့် `cb` မှစိုးရိမ်ထိတ်လန့်မှုသည်လုပ်ငန်းစဉ်ကိုရပ်တန့်စေနိုင်သည်။
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // အဆိုပါ backtrace ဆက်လက်
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// က unsynchronized ရဲ့အဖြစ် `trace` အဖြစ်အတူတူသာ unsafe ။
///
/// ဤလုပ်ဆောင်မှုတွင်ထပ်တူပြုခြင်းအတွက်အာမခံချက်များမရှိသော်လည်းဤ crate ၏ `std` အင်္ဂါရပ်ကိုမဖြည့်ပါကရရှိနိုင်သည်။
/// နောက်ထပ်စာရွက်စာတမ်းများနှင့်ဥပမာများအတွက် `trace` function ကိုကြည့်ပါ။
///
/// # Panics
///
/// `cb` အထိတ်တလန့်ဖြစ်ခြင်းအတွက်သတိပေးချက်များအတွက် `trace` ၏သတင်းအချက်အလက်ကိုကြည့်ပါ။
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// ဒီ crate ၏ `trace` function ကိုမှလြှော့တစ် backtrace တဦးသည် frame, ကိုယ်စားပြုတစ်ဦးက trait ။
///
/// Tracing function ၏ closure သည် frames များကိုထုတ်ပေးလိမ့်မည်။ runtime မရောက်မှီနောက်ခံအကောင်အထည်ဖော်မှုကိုမသိသေးသောကြောင့် frame ကို send လုပ္ထားတယ်။
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// ဒီဘောင်၏လက်ရှိညွှန်ကြားချက် pointer ကိုပြန်သွားသည်။
    ///
    /// ဤသည်ပုံမှန်အားဖြင့် frame ကိုအတွက် execute ဖို့လာမယ့်ညွှန်ကြားချက်ဖြစ်တယ်, ဒါပေမဲ့အားလုံးမဟုတ် Implementation ကို 100% တိကျမှန်ကန်မှုနှင့်အတူဤစာရင်းပြုစု (သို့သော်ကြောင့်ယေဘုယျအားဖြင့်တော်တော်လေးနီးစပ်ရဲ့) ။
    ///
    ///
    /// ၎င်းတန်ဖိုးကိုသင်္ကေတအမည်တစ်ခုအဖြစ်ပြောင်းလဲရန် `backtrace::resolve` သို့ပို့ရန်အကြံပြုသည်။
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// ဒီ frame ၏လက်ရှိ stack pointer ကိုပြန်သွားသည်။
    ///
    /// backend သည်ဤ frame အတွက် stack pointer ကိုပြန်လည်ရယူနိုင်ခြင်းမရှိပါက null pointer ကိုပြန်ပို့သည်။
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// ဒီ function ရဲ့ frame ရဲ့စတင်တဲ့သင်္ကေတလိပ်စာကိုပြန်ပို့ပေးတယ်။
    ///
    /// ၎င်းသည် `ip` မှပြန်လာသည့်ညွှန်ပြညွှန်ကြားချက်ကို function ၏အစသို့ပြန်ပို့ပေးပြီး၎င်းတန်ဖိုးကိုပြန်ပေးသည်။
    ///
    /// သို့သော်အချို့ကိစ္စများတွင် backends များသည်ဤလုပ်ဆောင်မှုမှ `ip` ကိုသာပြန်ပေးလိမ့်မည်။
    ///
    /// အထက်တွင်ဖော်ပြထားသော `ip` တွင် `backtrace::resolve` မအောင်မြင်ပါကပြန်လာသောတန်ဖိုးကိုတစ်ခါတစ်ရံတွင်အသုံးပြုနိုင်သည်။
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// frame ကိုပိုငျဆိုငျသညျ့ဖို့ module တစ်ခု၏အခြေစိုက်စခန်းလိပ်စာ Returns ။
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Host ပလက်ဖောင်းထက် ဦး စားပေးဆောင်ရွက်ရန်သေချာစေရန်၎င်းသည်ပထမ ဦး ဆုံးလိုအပ်သည်
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // သာ dbghelp သင်္ကေတအတွက်အသုံးပြုခဲ့သည်
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}