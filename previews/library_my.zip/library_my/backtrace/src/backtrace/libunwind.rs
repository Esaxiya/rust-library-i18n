//! libunwind/gcc_s/etc APIs သုံး၍ Backtrace အထောက်အပံ့။
//!
//! ဤ module တွင် libunwind-style APIs ကို သုံး၍ stack ကိုဖြည်နိုင်သည့်စွမ်းရည်ပါရှိသည်။
//! libunwind ကဲ့သို့ API ကိုအပြည့်အ ၀ အကောင်အထည်ဖော်နိုင်ခြင်းကိုသတိပြုပါ။ ၎င်းသည် picky ဖြစ်မယ့်အစားသူတို့အများစုနှင့်သဟဇာတဖြစ်ရန်ကြိုးစားနေသည်။
//!
//!
//! libunwind API သည် `_Unwind_Backtrace` မှစွမ်းအားရှိပြီး backtrace တစ်ခုကိုထုတ်လုပ်ရာတွင်လက်တွေ့တွင်အလွန်စိတ်ချရသည်။
//! ၎င်းသည်မည်သို့လုပ်ဆောင်သည်ကိုရှင်းရှင်းလင်းလင်းမသိရသေးပါ (frame pointers? eh_frame info? နှစ်ခုလုံး?) သို့သော်အလုပ်လုပ်ပုံရသည်။
//!
//! ဒီ module တစ်ခု၏ရှုပ်ထွေးမှုအများစုမှာ libunwind Implementation ကိုဖြတ်ပြီးအမျိုးမျိုးသောပလက်ဖောင်းကွဲပြားခြားနားမှုကိုင်တွယ်နေပါတယ်။
//! မဟုတ်လျှင်၎င်းသည် libunwind APIs နှင့်အလွန်ရိုးရှင်းလွယ်ကူသော Rust ဖြစ်သည်။
//!
//! ဤသည်မှာလက်ရှိ Non-Windows ပလက်ဖောင်းအားလုံးအတွက် default unwinding API ဖြစ်သည်။
//!
//!
//!

use super::super::Bomb;
use core::ffi::c_void;

pub enum Frame {
    Raw(*mut uw::_Unwind_Context),
    Cloned {
        ip: *mut c_void,
        sp: *mut c_void,
        symbol_address: *mut c_void,
    },
}

// libunwind pointer တစ်မျိုးဖြင့်၎င်းသည် readafely threadafe ပုံစံဖြင့်သာ ၀ င်ရောက်သင့်ပြီး၎င်းသည် `Sync` ဖြစ်သည်။
// `Clone` မှတဆင့်အခြားအချည်ဖို့မပို့သည့်အခါကျွန်တော်တို့ဟာအမြဲတမ်းကျွန်တော်ကောင်းစွာအဖြစ် `Send` ဖြစ်သင့်ဒါအတွင်းပိုင်းထောက်ပြထိန်းသိမ်းထားပါဘူးတဲ့ဗားရှင်းသို့ပြောင်းပါ။
//
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        let ctx = match *self {
            Frame::Raw(ctx) => ctx,
            Frame::Cloned { ip, .. } => return ip,
        };
        unsafe { uw::_Unwind_GetIP(ctx) as *mut c_void }
    }

    pub fn sp(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ctx) => unsafe { uw::get_sp(ctx) as *mut c_void },
            Frame::Cloned { sp, .. } => sp,
        }
    }

    pub fn symbol_address(&self) -> *mut c_void {
        if let Frame::Cloned { symbol_address, .. } = *self {
            return symbol_address;
        }

        // OSX `_Unwind_FindEnclosingFunction` တွင်မရှင်းရသေးသောအရာတစ်ခုခုအတွက် pointer တစ်ခုကိုပြန်ပို့သည်ပုံရသည်။
        // မည်သည့်အကြောင်းပြချက်ဖြင့်မဆို၎င်းသည်အမြဲတမ်းပူးတွဲလုပ်ဆောင်ချက်မဟုတ်ပါ။
        // ဒီမှာဘာတွေဖြစ်နေလဲဆိုတာကျွန်တော်ရှင်းရှင်းလင်းလင်းမသိရပါဘူး။ ဒါကြောင့်ဒီဟာကိုအခုချိန်ထိအကောင်းမြင်ပြီးအိုင်ပီကိုအမြဲတမ်းပြန်ပို့ပါ။
        //
        // သတိပြုပါမှာဤစာပိုဒ်ကြောင့် `skip_inner_frames.rs` စစ်ဆေးမှုသည် OSX တွင်ကျော်သွားသည်၊ အကယ်၍ ၎င်းကိုသတ်မှတ်ထားပါကသီအိုရီအရစမ်းသပ်မှုကို OSX တွင်အသုံးပြုနိုင်သည်။
        //
        //
        //
        if cfg!(target_os = "macos") || cfg!(target_os = "ios") {
            self.ip()
        } else {
            unsafe { uw::_Unwind_FindEnclosingFunction(self.ip()) }
        }
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        None
    }
}

impl Clone for Frame {
    fn clone(&self) -> Frame {
        Frame::Cloned {
            ip: self.ip(),
            sp: self.sp(),
            symbol_address: self.symbol_address(),
        }
    }
}

#[inline(always)]
pub unsafe fn trace(mut cb: &mut dyn FnMut(&super::Frame) -> bool) {
    uw::_Unwind_Backtrace(trace_fn, &mut cb as *mut _ as *mut _);

    extern "C" fn trace_fn(
        ctx: *mut uw::_Unwind_Context,
        arg: *mut c_void,
    ) -> uw::_Unwind_Reason_Code {
        let cb = unsafe { &mut *(arg as *mut &mut dyn FnMut(&super::Frame) -> bool) };
        let cx = super::Frame {
            inner: Frame::Raw(ctx),
        };

        let mut bomb = Bomb { enabled: true };
        let keep_going = cb(&cx);
        bomb.enabled = false;

        if keep_going {
            uw::_URC_NO_REASON
        } else {
            uw::_URC_FAILURE
        }
    }
}

/// backtraces များအတွက်အသုံးပြုသောစာကြည့်တိုက် interface ကိုဖြုတ်ပါ
///
/// ဒီနေရာမှာ iOS ကိုချည်နှောင်ထားတာကြောင့် code ကုဒ်ကိုခွင့်ပြုတာကိုသူတို့သတိပြုရမှာက iOS မှာသူတို့အားလုံးကိုသုံးတာမဟုတ်ပေမယ့် platform-specific configs ထပ်ပေါင်းတာက code ကိုအရမ်းညစ်ညမ်းစေတယ်
///
///
#[allow(non_camel_case_types)]
#[allow(non_snake_case)]
#[allow(dead_code)]
mod uw {
    pub use self::_Unwind_Reason_Code::*;

    use core::ffi::c_void;

    #[repr(C)]
    pub enum _Unwind_Reason_Code {
        _URC_NO_REASON = 0,
        _URC_FOREIGN_EXCEPTION_CAUGHT = 1,
        _URC_FATAL_PHASE2_ERROR = 2,
        _URC_FATAL_PHASE1_ERROR = 3,
        _URC_NORMAL_STOP = 4,
        _URC_END_OF_STACK = 5,
        _URC_HANDLER_FOUND = 6,
        _URC_INSTALL_CONTEXT = 7,
        _URC_CONTINUE_UNWIND = 8,
        _URC_FAILURE = 9, // သာ ARM EABI အသုံးပြုခဲ့သည်
    }

    pub enum _Unwind_Context {}

    pub type _Unwind_Trace_Fn =
        extern "C" fn(ctx: *mut _Unwind_Context, arg: *mut c_void) -> _Unwind_Reason_Code;

    extern "C" {
        // iOS တွင်ဇာတိ _Unwind_Backtrace မရှိပါ
        #[cfg(not(all(target_os = "ios", target_arch = "arm")))]
        pub fn _Unwind_Backtrace(
            trace: _Unwind_Trace_Fn,
            trace_argument: *mut c_void,
        ) -> _Unwind_Reason_Code;

        // GCC 4.2.0 မှစ၍ ရရှိနိုင်သောကျွန်ုပ်တို့၏ရည်ရွယ်ချက်များအတွက်ကောင်းမွန်သင့်သည်
        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "s390x"))
        ))]
        // ဤလုပ်ဆောင်ချက်သည်လွဲမှားသောလုပ်ရပ်တစ်ခုဖြစ်သည်။ ဤသည် frame ၏ Canonical Frame Address (ခေါ်သူခေါ်ဘောင်၏ SP ခေါ်) ကိုရယူမည့်အစား၎င်းသည် frame ၏ SP ကိုပြန်ပေးသည်။
        //
        //
        // https://github.com/libunwind/libunwind/blob/d32956507cf29d9b1a98a8bce53c78623908f4fe/src/unwind/GetCFA.c#L28-L35
        //
        #[link_name = "_Unwind_GetCFA"]
        pub fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t;
    }

    // s390x biased CFA တန်ဖိုးကိုအသုံးပြုသည်။ ထို့ကြောင့် _Unwind_GetCFA ကိုမှီခိုမည့်အစား stack pointer register (%r15) ကိုရယူရန် _Unwind_GetGR ကိုအသုံးပြုရန်လိုအပ်သည်။
    //
    //
    #[cfg(all(target_os = "linux", target_arch = "s390x"))]
    pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
        extern "C" {
            pub fn _Unwind_GetGR(ctx: *mut _Unwind_Context, index: libc::c_int) -> libc::uintptr_t;
        }
        _Unwind_GetGR(ctx, 15)
    }

    // ကျွန်ုပ်တို့သည်ဘာလို့လဲဆိုတော့ Micro စနစ်နဲ့အခြားသော၏ချဲ့ထွင်င်လုပ်ငန်းဆောင်တာသတ်မှတ်နိုင်အောင် android နှင့်လက်မောင်းတွင် function ကို `_Unwind_GetIP` နှင့်အခြားသူများတစည်း, ဘာလို့လဲဆိုတော့ Micro စနစ်နဲ့အခြားသောဖြစ်ကြသည်။
    //
    //
    // TODO: အကယ်လို့သင်ရှာနိုင်ရင်အဲဒီ macros တွေကိုသတ်မှတ်ပေးတဲ့ header file ကိုလင့်ခ်လုပ်ပါ။
    // (ငါ, fitzgen, ဤ macro ချဲ့ထွင်အချို့ကိုမူလကနေချေးယူခဲ့သော header file ကိုရှာမတွေ့ပါ။)
    //
    //
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    pub use self::arm::*;
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    mod arm {
        pub use super::*;
        #[repr(C)]
        enum _Unwind_VRS_Result {
            _UVRSR_OK = 0,
            _UVRSR_NOT_IMPLEMENTED = 1,
            _UVRSR_FAILED = 2,
        }
        #[repr(C)]
        enum _Unwind_VRS_RegClass {
            _UVRSC_CORE = 0,
            _UVRSC_VFP = 1,
            _UVRSC_FPA = 2,
            _UVRSC_WMMXD = 3,
            _UVRSC_WMMXC = 4,
        }
        #[repr(C)]
        enum _Unwind_VRS_DataRepresentation {
            _UVRSD_UINT32 = 0,
            _UVRSD_VFPX = 1,
            _UVRSD_FPAX = 2,
            _UVRSD_UINT64 = 3,
            _UVRSD_FLOAT = 4,
            _UVRSD_DOUBLE = 5,
        }

        type _Unwind_Word = libc::c_uint;
        extern "C" {
            fn _Unwind_VRS_Get(
                ctx: *mut _Unwind_Context,
                klass: _Unwind_VRS_RegClass,
                word: _Unwind_Word,
                repr: _Unwind_VRS_DataRepresentation,
                data: *mut c_void,
            ) -> _Unwind_VRS_Result;
        }

        pub unsafe fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                15,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            (val & !1) as libc::uintptr_t
        }

        // R13 လက်မောင်းပေါ် stack pointer ဖြစ်ပါတယ်။
        const SP: _Unwind_Word = 13;

        pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                SP,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            val as libc::uintptr_t
        }

        // ဤလုပ်ဆောင်မှုသည် Android သို့မဟုတ် ARM/Linux တွင်လည်းမရှိသောကြောင့်၎င်းကိုအသုံးမပြုပါနှင့်။
        //
        pub unsafe fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void {
            pc
        }
    }
}