use backtrace::Backtrace;

// ဤစမ်းသပ်မှုသည်သင်္ကေတ၏ပထမဆုံးလိပ်စာကိုအစီရင်ခံသော frames များအတွက်အလုပ်လုပ်နေသော `symbol_address` function ရှိသော platform များပေါ်တွင်သာအလုပ်လုပ်သည်။
// ရလဒ်အဖြစ်သာအနည်းငယ်ပလက်ဖောင်းများပေါ်တွင် enabled ရဲ့။
//
const ENABLED: bool = cfg!(all(
    // Windows တကယ်စမ်းသပ်ပြီးနိုင်ခြင်းမရှိသေးပေနှင့် OSX တစ်ခု enclosing frame ကိုရှာဖွေရာတွင်အမှန်တကယ်ဒါကို disable ဒီထောကျပံ့ပေးမထားဘူး
    //
    target_os = "linux",
    // ARM တွင် enclosing function သည်ရှာဖွေခြင်းသည် ip ကိုပြန်ပို့ခြင်းသာဖြစ်သည်။
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}