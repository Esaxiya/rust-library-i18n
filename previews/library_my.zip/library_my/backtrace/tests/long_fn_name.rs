use backtrace::Backtrace;

// 50-ဇာတ်ကောင် module တစ်ခုအမည်
mod _234567890_234567890_234567890_234567890_234567890 {
    // 50-ဇာတ်ကောင် struct name ကို
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// ရှည်လျားသော function name များကို (MAX_SYM_NAME, ၁) အက္ခရာများကိုဖြတ်ရမည်။
// ဒီစမ်းသပ်မှုကို msvc အတွက်သာ run ပါ။ gnu သည် frame အားလုံးအတွက် "<no info>" ကို print လုပ်သောကြောင့်ဖြစ်သည်။
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // struct name ၏ 10 အထပ်ထပ်, ဒါကြောင့်အပြည့်အဝအရည်အချင်းပြည့် function ကိုနာမကိုအမှီ atleast 10 *(50 + 50)* 2=2000 ဇာတ်ကောင်ရှည်လျားသည်။
    //
    // `::`, `<>` နှင့်လက်ရှိ module ၏နာမည်တို့ပါ ၀ င်သည်
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}