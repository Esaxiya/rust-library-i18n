//! မှတ်ဉာဏ်ခွဲဝေခြင်း API များ

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // ဤရွေ့ကားကမ္ဘာလုံးဆိုင်ရာခွဲဝေချထားပေးရန်ခေါ်မှော်သင်္ကေတများဖြစ်ကြသည်။rustc သည်၎င်းတို့ကို `__rg_alloc` ဟုခေါ်သည်။
    // `#[global_allocator]` attribute တစ်ခုရှိလျှင် (၎င်း attribute macro တိုးချဲ့နေသောကုဒ်သည်ထိုလုပ်ဆောင်ချက်များကိုထုတ်ပေးသည်) သို့မဟုတ် libstd (`__rdl_alloc` စသည်ဖြင့်) တွင်ပုံမှန်အကောင်အထည်ဖော်မှုကိုခေါ်ရန်။
    //
    // မဟုတ်ရင် `library/std/src/alloc.rs` ၌တည်၏။
    // LLVM ၏ rustc fork သည်ဤလုပ်ဆောင်မှုအမည်များကိုအထူးသဖြင့် `malloc`, `realloc` နှင့် `free` စသည်တို့ကိုပိုမိုကောင်းမွန်အောင်ပြုလုပ်နိုင်သည်။
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// ကမ္ဘာလုံးဆိုင်ရာမှတ်ဉာဏ်ခွဲဝေချထားပေးသူ။
///
/// ဤအမျိုးအစားသည် [`Allocator`] trait ကိုတစ်ခုရှိလျှင် `#[global_allocator]` attribute တွင်မှတ်ပုံတင်ထားသော allocator သို့ဖုန်းခေါ်ခြင်းသို့မဟုတ် `std` crate ၏ပုံမှန်အားဖြင့် [`Allocator`] trait ကိုအကောင်အထည်ဖော်သည်။
///
///
/// Note: ဤအမျိုးအစားသည်မတည်မငြိမ်ဖြစ်သော်လည်း၎င်းကိုပြုလုပ်ထားသောလုပ်ဆောင်နိုင်မှုကို [free functions in `alloc`](self#functions) မှတဆင့်ရယူနိုင်သည်။
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// ကမ္ဘာလုံးဆိုင်ရာခွဲဝေချထားပေးသူနှင့်အတူမှတ်ဉာဏ်ခွဲဝေချထားပေးရန်။
///
/// ဤလုပ်ဆောင်မှုသည် `#[global_allocator]` attribute တွင်မှတ်ပုံတင်ထားသည့်ခွဲဝေချထားပေးသူ၏ [`GlobalAlloc::alloc`] နည်းလမ်းသို့ဖုန်းခေါ်သည်သို့မဟုတ် `std` crate ၏ပုံမှန်ဖြစ်သည်။
///
///
/// [`Global`] type နှင့် [`Allocator`] trait တည်ငြိမ်လာသောအခါဤလုပ်ဆောင်ချက်သည် [`Global`] နည်းလမ်း၏မျက်နှာသာအတွက်ကန့်ကွက်လိမ့်မည်။
///
/// # Safety
///
/// [`GlobalAlloc::alloc`] ကိုကြည့်ပါ။
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// ကမ္ဘာလုံးဆိုင်ရာခွဲဝေချထားပေးရန်နှင့်အတူမှတ်ဉာဏ် deallocate ။
///
/// ဤလုပ်ဆောင်မှုသည် `#[global_allocator]` attribute တွင်မှတ်ပုံတင်ထားသည့်ခွဲဝေချထားပေးသူ၏ [`GlobalAlloc::dealloc`] နည်းလမ်းသို့ဖုန်းခေါ်သည်သို့မဟုတ် `std` crate ၏ပုံမှန်ဖြစ်သည်။
///
///
/// [`Global`] type နှင့် [`Allocator`] trait တည်ငြိမ်လာသောအခါဤလုပ်ဆောင်ချက်သည် [`Global`] နည်းလမ်း၏မျက်နှာသာအတွက်ကန့်ကွက်လိမ့်မည်။
///
/// # Safety
///
/// [`GlobalAlloc::dealloc`] ကိုကြည့်ပါ။
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// ကမ္ဘာလုံးဆိုင်ရာခွဲဝေချထားပေးရန်နှင့်အတူမှတ်ဉာဏ်ပြန်လည်။
///
/// ဤလုပ်ဆောင်မှုသည် `#[global_allocator]` attribute တွင်မှတ်ပုံတင်ထားသည့်ခွဲဝေချထားပေးသူ၏ [`GlobalAlloc::realloc`] နည်းလမ်းသို့ဖုန်းခေါ်သည်သို့မဟုတ် `std` crate ၏ပုံမှန်ဖြစ်သည်။
///
///
/// [`Global`] type နှင့် [`Allocator`] trait တည်ငြိမ်လာသောအခါဤလုပ်ဆောင်ချက်သည် [`Global`] နည်းလမ်း၏မျက်နှာသာအတွက်ကန့်ကွက်လိမ့်မည်။
///
/// # Safety
///
/// [`GlobalAlloc::realloc`] ကိုကြည့်ပါ။
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// ကမ္ဘာလုံးဆိုင်ရာခွဲဝေချထားပေးသူနှင့်အတူသုည-အစပျိုးမှတ်ဉာဏ်ချထားပါ။
///
/// ဤလုပ်ဆောင်မှုသည် `#[global_allocator]` attribute တွင်မှတ်ပုံတင်ထားသည့်ခွဲဝေချထားပေးသူ၏ [`GlobalAlloc::alloc_zeroed`] နည်းလမ်းသို့ဖုန်းခေါ်သည်သို့မဟုတ် `std` crate ၏ပုံမှန်ဖြစ်သည်။
///
///
/// [`Global`] type နှင့် [`Allocator`] trait တည်ငြိမ်လာသောအခါဤလုပ်ဆောင်ချက်သည် [`Global`] နည်းလမ်း၏မျက်နှာသာအတွက်ကန့်ကွက်လိမ့်မည်။
///
/// # Safety
///
/// [`GlobalAlloc::alloc_zeroed`] ကိုကြည့်ပါ။
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // လုံခြုံမှု-`layout` သည်သုညမဟုတ်သောအရွယ်အစား၊
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // လုံခြုံမှု-`Allocator::grow` နှင့်အတူတူပင်
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // လုံခြုံမှု: `new_size` သည် X0 `old_size` သည် `new_size` ထက်ကြီးခြင်းသို့မဟုတ်ညီမျှခြင်းကြောင့်သုညမဟုတ်သောအရာများဖြစ်သည်
            // ဘေးကင်းလုံခြုံမှုအခြေအနေများအားဖြင့်လိုအပ်အဖြစ်။အခြားအခြေအနေများကိုခေါ်ဆိုသူမှထောက်ခံရမည်
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` ဖြစ်ကောင်း `new_size >= old_layout.size()` သို့မဟုတ်အလားတူတစ်ခုခုစစ်ဆေးသည်။
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // လုံခြုံမှု-`new_layout.size()` ဟာ `old_size` ထက်ကြီးရင်ဖြစ်ရမယ်၊
            // အဟောင်းနှင့်အသစ်မှတ်ဉာဏ်ခွဲဝေမှုနှစ်ခုလုံးသည်ဖတ်ရှုခြင်းနှင့် `old_size` bytes အတွက်ရေးခြင်းများအတွက်မှန်ကန်သည်။
            // ထို့အပြင်အဟောင်းခွဲဝေချထားပေးခြင်းကိုမရသေးသောကြောင့်, သူက `new_ptr` ထပ်လို့မရပါဘူး။
            // ထို့ကြောင့် `copy_nonoverlapping` သို့ခေါ်ဆိုမှုသည်လုံခြုံသည်။
            // `dealloc` အတွက်လုံခြုံမှုစာချုပ်ကိုဖုန်းခေါ်ဆိုသူမှထောက်ခံရမည်။
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // လုံခြုံမှု-`layout` သည်သုညမဟုတ်သောအရွယ်အစား၊
            // အခြားအခြေအနေများကိုခေါ်ဆိုသူမှထောက်ခံရမည်
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူမှအခြေအနေအားလုံးကိုစောင့်ရှောက်ရမည်
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူမှအခြေအနေအားလုံးကိုစောင့်ရှောက်ရမည်
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // လုံခြုံမှု-ဖုန်းခေါ်ဆိုသူမှအခြေအနေများကိုထိန်းသိမ်းထားရမည်
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // လုံခြုံမှု: `new_size` သည်သုညမဟုတ်ပါ။အခြားအခြေအနေများကိုခေါ်ဆိုသူမှထောက်ခံရမည်
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` ဖြစ်ကောင်း `new_size <= old_layout.size()` သို့မဟုတ်အလားတူတစ်ခုခုစစ်ဆေးသည်။
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // လုံခြုံမှု-ဘာလို့လဲဆိုတော့ `new_size` ဟာ `old_layout.size()` ထက်သေးငယ်ပြီးဖြစ်ရမယ်။
            // အဟောင်းနှင့်အသစ်မှတ်ဉာဏ်ခွဲဝေမှုနှစ်ခုလုံးသည်ဖတ်ရှုခြင်းနှင့် `new_size` bytes အတွက်ရေးခြင်းများအတွက်မှန်ကန်သည်။
            // ထို့အပြင်အဟောင်းခွဲဝေချထားပေးခြင်းကိုမရသေးသောကြောင့်, သူက `new_ptr` ထပ်လို့မရပါဘူး။
            // ထို့ကြောင့် `copy_nonoverlapping` သို့ခေါ်ဆိုမှုသည်လုံခြုံသည်။
            // `dealloc` အတွက်လုံခြုံမှုစာချုပ်ကိုဖုန်းခေါ်ဆိုသူမှထောက်ခံရမည်။
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// ထူးခြားတဲ့ထောက်ပြများအတွက်ခွဲဝေ။
// ဒီ function က unwind မပြုရပါ။ထိုသို့ပြုလုပ်ပါက MIR codegen ပျက်သွားလိမ့်မည်။
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// ဤလက်မှတ်သည် `Box` နှင့်တူညီရမည်၊ မဟုတ်လျှင် ICE တစ်ခုပေါ်လာလိမ့်မည်။
// `Box` (အပိုဆောင်း `A: Allocator`) ကဲ့သို့သောထပ်ဆောင်း parameter တစ်ခုထပ်ထည့်သောအခါ၊ ၎င်းကိုဤနေရာတွင်လည်းထည့်ရန်လိုအပ်သည်။
// ဥပမာ `Box` ကို `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)` သို့ပြောင်းပါကဤလုပ်ဆောင်ချက်ကို `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` အဖြစ်ပြောင်းလဲရမည်။
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # ခွဲဝေချို့ယွင်းချက် handler ကို

extern "Rust" {
    // ၎င်းသည် global alloc error handler ကိုခေါ်ရန်မှော်သင်္ကေတဖြစ်သည်။
    // rustc သည်၎င်းကို `__rg_oom` ဟုခေါ်ပါက `__rg_oom` ကိုခေါ်ရန်သို့မဟုတ်မဟုတ်လျှင် (`__rdl_oom`) အောက်ရှိမူလအကောင်အထည်ဖော်မှုကိုခေါ်ရန်ဖြစ်သည်။
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// မှတ်ဉာဏ်ခွဲဝေချို့ယွင်းချက်သို့မဟုတ်ပျက်ကွက်အပေါ်ဖျက်သိမ်း။
///
/// ခွဲဝေချို့ယွင်းချက်အမှားတစ်ခုကိုတုံ့ပြန်သည့်အနေဖြင့်တွက်ချက်မှုကိုရပ်တန့်လိုသည့်မှတ်ဥာဏ်ချထားပေးသော APIs များကိုခေါ်ဆိုသူများသည်ဤလုပ်ဆောင်မှုကိုခေါ်ရန်တိုက်တွန်းသည်။
///
///
/// ဤလုပ်ဆောင်ချက်၏ပုံမှန်အပြုအမူသည်ပုံမှန်အမှားတစ်ခုသို့မက်ဆေ့ခ်ျတစ်ခုကိုပုံနှိပ်ထုတ်ပြီးလုပ်ငန်းစဉ်ကိုရပ်ဆိုင်းရန်ဖြစ်သည်။
/// ၎င်းကို [`set_alloc_error_hook`] နှင့် [`take_alloc_error_hook`] ဖြင့်အစားထိုးနိုင်သည်။
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// alloc test အတွက် `std::alloc::handle_alloc_error` ကိုတိုက်ရိုက်သုံးနိုင်သည်။
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // ထုတ်လုပ်ပြီး `__rust_alloc_error_handler` ကနေတဆင့်ခေါ်

    // အဘယ်သူမျှမ `#[alloc_error_handler]` ရှိလျှင်
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // တစ် ဦး `#[alloc_error_handler]` ရှိလျှင်
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Clones ကိုကြိုတင်ခွဲဝေ ထား၍ မရသောမှတ်ဉာဏ်အဖြစ်အထူးပြုပါ။
/// `Box::clone` နှင့် `Rc`/`Arc::make_mut` အသုံးပြုသည်။
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // * ပထမ ဦး ဆုံးခွဲဝေချထားပြီးပါကပိုကောင်းအောင်ပြုလုပ်သူသည်ပုံတူပွားတန်ဖိုးကိုပြည်တွင်း၌ကျော်ပြီးရွှေ့။ ရနိုင်သည်။
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // ကျွန်ုပ်တို့သည်ဒေသခံတန်ဖိုးတစ်ခုနှင့်မျှမပါ ၀ င်သောနေရာတွင်ကော်ပီကူးနိုင်သည်။
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}