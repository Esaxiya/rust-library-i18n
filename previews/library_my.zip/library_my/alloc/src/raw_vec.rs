#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// အသစ်သောမှတ်ဉာဏ်ရဲ့ contents uninitialized နေကြသည်။
    Uninitialized,
    /// မှတ်ဉာဏ်အသစ်သည်သုညဖြစ်မည်ဟုအာမခံထားသည်။
    Zeroed,
}

/// ပါ ၀ င်သည့်ထောင့်အမှုများအားလုံးကိုစိတ်ပူစရာမလိုဘဲသိုလှောင်မှုတွင်မှတ်ဉာဏ်တစ်ခုကြားခံတစ်ခုကိုပိုမို Ergonomics ခွဲဝေချထားပေးခြင်းနှင့်ဖယ်ရှားခြင်းအတွက်အဆင့်နိမ့်သော utility ဖြစ်သည်။
///
/// ဤအမျိုးအစားသည်သင်၏ကိုယ်ပိုင်ဒေတာတည်ဆောက်ပုံတည်ဆောက်ခြင်းအတွက်အလွန်ကောင်းမွန်သည်။ Vec နှင့် VecDeque
/// အထူးသဖြင့်:
///
/// * `Unique::dangling()` ကိုသုညအရွယ်အမျိုးအစားများထုတ်လုပ်သည်။
/// * သုည-အရှည်ခွဲဝေမှုအပေါ် `Unique::dangling()` ထုတ်လုပ်သည်။
/// * `Unique::dangling()` ကိုလွှတ်ခြင်းမှရှောင်ရှားသည်။
/// * စွမ်းရည်တွက်ချက်မှုများအတွင်းလျှံများအားလုံးကိုဖမ်းယူသည် ("capacity overflow" panics သို့တိုးမြှင့်သည်) ။
/// * isize::MAX bytes ထက်ပိုပြီးခွဲဝေချထားပေးသော 32-bit systems များကိုကာကွယ်ရန်အစောင့်များ။
/// * သင့်ရဲ့အရှည်လျှံဆန့်ကျင်အစောင့်။
/// * မှားယွင်းစွာလုပ်နိုင်သောခွဲတမ်းများအတွက် `handle_alloc_error` ကိုခေါ်ဆိုသည်။
/// * `ptr::Unique` တစ်ခုပါဝင်ပြီးအသုံးပြုသူအားသက်ဆိုင်ရာအကျိုးခံစားခွင့်အားလုံးကိုပေးသည်။
/// * အများဆုံးရရှိနိုင်သောစွမ်းရည်ကိုအသုံးပြုရန်ခွဲဝေချထားပေးသူမှပြန်လာသောပိုလျှံမှုကိုအသုံးပြုသည်။
///
/// ဒီအမျိုးအစားကသူစီမံခန့်ခွဲတဲ့မှတ်ဉာဏ်ကိုဘာပဲဖြစ်ဖြစ်စစ်ဆေးမထားဘူး။လွှင့်ပစ်လိုက်သောအခါ၎င်းသည်၎င်း၏မှတ်ဉာဏ်ကိုလွတ်ပေးလိမ့်မည်၊ သို့သော်၎င်းသည်ပါ ၀ င်သောအရာများကိုဖယ်ရှားရန်မကြိုးစားပါ။
/// `RawVec` ၏အသုံးပြုသူများသည် `RawVec` အတွင်းရှိသိမ်းဆည်းထားသောအမှန်တကယ်အရာများကိုကိုင်တွယ်သည်။
///
/// သုညအရွယ်အစားပိုလျှံမှုသည်အမြဲတမ်းအဆုံးမဲ့ဖြစ်သည်ကိုသတိပြုပါ၊ ထို့ကြောင့် `capacity()` သည် `usize::MAX` ကိုအမြဲတမ်းပြန်ပို့သည်။
/// ဆိုလိုသည်မှာ `capacity()` သည်ဤအမျိုးအစားကိုလှည့်ပတ်ရာတွင် `capacity()` သည်အရှည်ကိုမပေးသောကြောင့်သင်သတိထားရန်လိုအပ်သည်။
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): ဘာလို့လဲဆိုတော့ `#[unstable]` `const fn`s သည် `min_const_fn` နှင့်မကိုက်ညီသောကြောင့်၎င်းတို့ကို`min_const_fn`s တွင်မခေါ်နိုင်သောကြောင့်ဖြစ်သည်။
    ///
    /// အကယ်၍ သင် `RawVec<T>::new` သို့မဟုတ်မှီခိုမှုများကိုပြောင်းလဲပါက `min_const_fn` ကိုအမှန်တကယ်ချိုးဖောက်မည့်အရာတစ်ခုခုကိုမိတ်ဆက်ပေးရန်ဂရုပြုပါ။
    ///
    /// NOTE: ကျွန်ုပ်တို့သည်ဤ hack ကိုရှောင်ရှားနိုင်ပြီး `min_const_fn` နှင့်ကိုက်ညီမှုရှိရန်လိုအပ်သော်လည်း `stable(...) const fn`/user code တွင် `#[rustc_const_unstable(feature = "foo", issue = "01234")]` ရှိနေသည့်အခါ `foo` ကိုမဖွင့်နိုင်သည့် `#[rustc_force_min_const_fn]` attribute အချို့နှင့်ကိုက်ညီမှုကိုစစ်ဆေးနိုင်သည်။
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// ခွဲဝေခြင်းမရှိဘဲ (system ကိုအမှိုက်ပုံပေါ်တွင်) အကြီးဆုံးဖြစ်နိုင်သော `RawVec` ကိုဖန်တီးသည်။
    /// အကယ်၍ `T` တွင်အပေါင်းအရွယ်အစားရှိပါက၎င်းသည်စွမ်းဆောင်ရည် `0` ပါ ၀ င်သည့် `RawVec` ကိုပြုလုပ်သည်။
    /// အကယ်၍ `T` သည်သုညအရွယ်ဖြစ်ပါကစွမ်းဆောင်ရည် `usize::MAX` ပါသော `RawVec` ကိုပြုလုပ်သည်။
    /// နှောင့်နှေးခွဲဝေအကောင်အထည်ဖော်ရန်အတွက်အသုံးဝင်သော။
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// `[T; capacity]` အတွက်စွမ်းဆောင်ရည်နှင့်ညှိနှိုင်းမှုလိုအပ်ချက်များနှင့်အတူ (system အမှိုက်ပုံတွင်) `RawVec` တစ်ခုကိုဖန်တီးသည်။
    /// ဤသည် `capacity` `0` သို့မဟုတ် `T` သုညအရွယ်ရှိသည့်အခါ `RawVec::new` ကိုခေါ်ဆိုခြင်းနှင့်တူသည်။
    /// အကယ်၍ `T` သည်သုညအရွယ်ရှိလျှင်ဆိုလိုသည်မှာသင်သည် * စွမ်းဆောင်ရည်ရှိသော `RawVec` ကိုသင်ရရှိမည်မဟုတ်ပါ။
    ///
    /// # Panics
    ///
    /// တောင်းဆိုထားသောစွမ်းရည် `isize::MAX` bytes ထက်ကျော်လွန်လျှင် Panics ။
    ///
    /// # Aborts
    ///
    /// OOM ကိုဖျက်သိမ်းသည်
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// `with_capacity` လိုပဲဒါပေမယ့် buffer ကို zero လုပ်မယ်လို့အာမခံတယ်။
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// pointer နှင့်စွမ်းဆောင်နိုင်မှုမှ `RawVec` ကိုပြန်လည်တည်ဆောက်သည်။
    ///
    /// # Safety
    ///
    /// `ptr` ကို (စနစ်အမှိုက်ပုံတွင်) ခွဲထားရမည်။
    /// `capacity` သည်အရွယ်အစားအမျိုးအစားများအတွက် `isize::MAX` ထက်မကျော်လွန်နိုင်ပါ။(32-bit စနစ်များအတွက်သာစိုးရိမ်ပူပန်မှုတစ်ခု)
    /// ZST vectors သည်စွမ်းဆောင်ရည် `usize::MAX` အထိရှိနိုင်သည်။
    /// အဆိုပါ `ptr` နှင့် `capacity` တစ် `RawVec` ကလာနေလျှင်, သို့ဖြစ်လျှင်ဤအာမခံချက်ဖြစ်ပါတယ်။
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // အလွန်သေးငယ်သော Vecs စကားမပြောနိုင်သောဖြစ်ကြသည်။Skip to:
    // - အကယ်၍ element အရွယ်အစားသည် 1 ဖြစ်လျှင် heap allocators များသည် 8 bytes ထက်နည်းသောတောင်းဆိုချက်ကိုအနည်းဆုံး 8 bytes ဖြင့်အပြည့်အ ၀ ဝိုင်း ၀ ယ်နိုင်သည်။
    //
    // - ဒြပ်စင်အလယ်အလတ်အရွယ် (<=1 KiB) လျှင်။
    // - 1 မဟုတ်လျှင်အလွန်တိုတောင်းသော Vecs အတွက်နေရာများစွာဖြုန်းတီးခြင်းကိုရှောင်ရှားရန်။
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// `new` လိုပဲ, ဒါပေမယ့်ပြန်လာသော `RawVec` များအတွက်ခွဲဝေ၏ရွေးချယ်မှုကျော် parameterized ။
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` "unallocated" ကိုဆိုလိုသည်။သုညအရွယ်အမျိုးအစားများကိုလျစ်လျူရှုထားသည်။
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// `with_capacity` လိုပဲ, ဒါပေမယ့်ပြန်လာသော `RawVec` များအတွက်ခွဲဝေ၏ရွေးချယ်မှုကျော် parameterized ။
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// `with_capacity_zeroed` လိုပဲ, ဒါပေမယ့်ပြန်လာသော `RawVec` များအတွက်ခွဲဝေ၏ရွေးချယ်မှုကျော် parameterized ။
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// `Box<[T]>` ကို `RawVec<T>` အဖြစ်ပြောင်းပေးသည်။
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// ကြားခံတစ်ခုလုံးကိုသတ်မှတ်ထားသော `len` နှင့်အတူ `Box<[MaybeUninit<T>]>` သို့ပြောင်းသည်။
    ///
    /// ၎င်းသည် `cap` အပြောင်းအလဲများကိုမှန်ကန်စွာပြန်လည်လုပ်ဆောင်နိုင်မည်ကိုသတိပြုပါ။(အသေးစိတ်အတွက်အမျိုးအစားဖော်ပြချက်ကိုကြည့်ပါ။)
    ///
    /// # Safety
    ///
    /// * `len` သို့မဟုတ်လတ်တလောတောင်းဆိုထားသောစွမ်းရည်ထက်ကြီးရမည်၊
    /// * `len` `self.capacity()` ထက်နည်းရမည်။
    ///
    /// သတိပြုရန်မှာ အကယ်၍ ခွဲဝေချထားပေးသူတစ် ဦး အနေဖြင့်တောင်းဆိုထားသည်ထက်ပိုမိုကြီးမားသောမှတ်ဉာဏ်ပိတ်ဆို့မှုကိုပြန်ပေးပြီးပြန်လာနိုင်သောကြောင့်တောင်းဆိုထားသောစွမ်းရည်နှင့် `self.capacity()` တို့ကွာခြားနိုင်သည်။
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // စိတ်ကျန်းမာရေး-လုံခြုံရေးလိုအပ်ချက်၏တစ်ဝက် (ကျွန်တော်အခြားတစ်ဝက်ကိုမစစ်ဆေးနိုင်) ။
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // ဤနေရာတွင် `unwrap_or_else` ကိုကျွန်ုပ်တို့ရှောင်ကြဉ်သည်။ အဘယ်ကြောင့်ဆိုသော်၎င်းသည်ထုတ်လုပ်လိုက်သော LLVM IR ပမာဏကိုမှုတ်ထုတ်ခြင်းကြောင့်ဖြစ်သည်။
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// pointer, capacity and allocator ကနေ `RawVec` ကိုပြန်လည်တည်ဆောက်သည်။
    ///
    /// # Safety
    ///
    /// အဆိုပါ `ptr` (ပေးထားသော allocator `alloc` မှတဆင့်) နှင့်ပေးထားသော `capacity` နှင့်အတူခွဲဝေရမည်ဖြစ်သည်။
    /// `capacity` သည်အရွယ်အစားအမျိုးအစားများအတွက် `isize::MAX` ထက်မကျော်လွန်နိုင်ပါ။
    /// (32-bit စနစ်များအတွက်သာစိုးရိမ်ပူပန်မှုတစ်ခု)
    /// ZST vectors သည်စွမ်းဆောင်ရည် `usize::MAX` အထိရှိနိုင်သည်။
    /// အကယ်၍ `ptr` နှင့် `capacity` `alloc` မှတစ်ဆင့်ဖန်တီးထားသော `RawVec` မှလာလျှင်၎င်းသည်အာမခံသည်။
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// ခွဲဝေချခြင်း၏အစသို့ကုန်ကြမ်း pointer ရရှိသည်။
    /// `capacity == 0` သို့မဟုတ် `T` သုညအရွယ်ရှိလျှင်ဤသည် `Unique::dangling()` ဖြစ်ကြောင်းသတိပြုပါ။
    /// ယခင်အမှု၌, သင်သတိထားရပေမည်။
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// ခွဲဝေ၏စွမ်းရည်ကိုရရှိသည်။
    ///
    /// `T` သုညအရွယ်ရှိလျှင်ဤသည်မှာ `usize::MAX` ဖြစ်လိမ့်မည်။
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// ဒီ `RawVec` ကိုထောက်ပံ့သောချထားပေးသူတစ် ဦး မျှဝေရည်ညွှန်း Returns ။
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // ကျွန်ုပ်တို့တွင်သတ်မှတ်ထားသည့်မှတ်ဥာဏ်ပမာဏရှိသည်၊ ထို့ကြောင့်ကျွန်ုပ်တို့၏လက်ရှိအပြင်အဆင်ကိုရရှိရန် runtime စစ်ဆေးမှုများကိုကျော်လွှားနိုင်သည်။
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// ကြားခံတွင်အနည်းဆုံး `len + additional` element များကိုသိမ်းထားရန်လုံလောက်သောနေရာရှိရန်သေချာသည်။
    /// အကယ်၍ ၎င်းတွင်စွမ်းဆောင်ရည်အလုံအလောက်မရှိသေးလျှင်၊*O*(1) အပြုအမူကိုရရှိရန်အတွက်နေရာလွတ်နှင့်သက်သောင့်သက်သာရှိသည့်နေရာလွတ်ကိုပြန်လည်ခွဲဝေပေးလိမ့်မည်။
    ///
    /// အကယ်၍ ၎င်းသည်မလိုအပ်ဘဲ panic ကိုဖြစ်ပေါ်စေပါကဤအပြုအမူကိုကန့်သတ်လိမ့်မည်။
    ///
    /// အကယ်၍ `len` သည် `self.capacity()` ထက်ကျော်လွန်ပါက၎င်းသည်တောင်းဆိုသောနေရာအားအမှန်တကယ်ခွဲဝေချထားပေးရန်ပျက်ကွက်နိုင်သည်။
    /// ၎င်းသည်အန္တရာယ်ကင်းစွာမဟုတ်ပါ၊ သို့သော်ဤလုပ်ဆောင်မှု၏အပြုအမူပေါ် မူတည်၍ သင်ရေးသားသောမလုံခြုံသောကုဒ်သည်ချိုးဖောက်နိုင်သည်။
    ///
    /// ဤသည် `extend` ကဲ့သို့သောအမြောက်အများကိုတွန်းအားပေးသောလုပ်ဆောင်မှုကိုအကောင်အထည်ဖော်ရန်အတွက်အကောင်းဆုံးဖြစ်သည်။
    ///
    /// # Panics
    ///
    /// အသစ်ကစွမ်းရည် `isize::MAX` bytes ထက်ကျော်လွန်လျှင် Panics ။
    ///
    /// # Aborts
    ///
    /// OOM ကိုဖျက်သိမ်းသည်
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // အကယ်၍ len သည် `isize::MAX` ထက်ကျော်လွန်ပါကအရံချန်ထားခြင်း (သို့) ထိတ်လန့်တုန်လှုပ်စရာဖြစ်လိမ့်မည်၊
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// `reserve` နှင့်အတူတူပါပဲသို့သော်ထိတ်လန့်ခြင်း၊
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// ကြားခံတွင်အနည်းဆုံး `len + additional` element များကိုသိမ်းထားရန်လုံလောက်သောနေရာရှိရန်သေချာသည်။
    /// အကယ်၍ ၎င်းသည်မရှိသေးပါကအနည်းဆုံးလိုအပ်သော memory ပမာဏကိုပြန်လည်ခွဲဝေပေးသည်။
    /// ယေဘုယျအားဖြင့်၎င်းသည်လိုအပ်သည့် memory ပမာဏအတိအကျဖြစ်လိမ့်မည်။ သို့သော်အခြေခံအားဖြင့်ခွဲဝေချပေးသူသည်ကျွန်ုပ်တို့တောင်းသည်ထက်ပိုပြီးပြန်ပေးနိုင်သည်။
    ///
    ///
    /// အကယ်၍ `len` သည် `self.capacity()` ထက်ကျော်လွန်ပါက၎င်းသည်တောင်းဆိုသောနေရာအားအမှန်တကယ်ခွဲဝေချထားပေးရန်ပျက်ကွက်နိုင်သည်။
    /// ၎င်းသည်အန္တရာယ်ကင်းစွာမဟုတ်ပါ၊ သို့သော်ဤလုပ်ဆောင်မှု၏အပြုအမူပေါ် မူတည်၍ သင်ရေးသားသောမလုံခြုံသောကုဒ်သည်ချိုးဖောက်နိုင်သည်။
    ///
    /// # Panics
    ///
    /// အသစ်ကစွမ်းရည် `isize::MAX` bytes ထက်ကျော်လွန်လျှင် Panics ။
    ///
    /// # Aborts
    ///
    /// OOM ကိုဖျက်သိမ်းသည်
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// `reserve_exact` နှင့်အတူတူပါပဲသို့သော်ထိတ်လန့်ခြင်း၊
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// သတ်မှတ်ထားသည့်ပမာဏအထိခွဲဝေချုံ့သည်။
    /// ပေးထားသောငွေပမာဏ 0 ဖြစ်လျှင်, အမှန်တကယ်လုံးဝ deallocates ။
    ///
    /// # Panics
    ///
    /// ပေးထားသောငွေပမာဏသည်လက်ရှိစွမ်းရည်ထက် *ပိုကြီး* လျှင် Panics ။
    ///
    /// # Aborts
    ///
    /// OOM ကိုဖျက်သိမ်းသည်
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// လိုအပ်သောအပိုစွမ်းရည်ကိုဖြည့်ဆည်းရန်ကြားခံသည်ကြီးထွားရန်လိုအပ်ပါကပြန်ပို့သည်။
    /// အဓိကအားဖြင့် `grow` ကိုမပိတ်ဘဲအရံဖုန်းခေါ်ဆိုမှုများကိုဖြစ်နိုင်သည်။
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // ဤနည်းလမ်းကိုများသောအားဖြင့်အကြိမ်ပေါင်းများစွာ instantiated ဖြစ်ပါတယ်။ထို့ကြောင့်ကျွန်ုပ်တို့သည်၎င်းကိုဖြစ်နိုင်သမျှအနည်းဆုံးဖြစ်စေရန် compile time တိုးတက်စေရန်လိုသည်။
    // သို့သော်ကျွန်ုပ်တို့သည်၎င်းတွင်ပါ ၀ င်သောအကြောင်းအရာများသည်ထုတ်လုပ်နိုင်သည့်ကုဒ်ပိုမိုမြန်ဆန်စွာလည်ပတ်နိုင်ရန်၊
    // ထို့ကြောင့်ဤနည်းလမ်းကို `T` အပေါ်တွင်မူတည်သောကုဒ်အားလုံးသည်အတွင်းထဲ၌ပါ ၀ င်စေရန်ဂရုတစိုက်ရေးသားထားပြီး `T` ကိုမမှီခိုသောကုဒ်အများစုသည် `T` ထက်ယေဘူယျအားဖြင့်မဟုတ်သောလုပ်ဆောင်မှုများတွင်ရှိသည်။
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // ဤသည်ခေါ်ဆိုမှုအခင်းအကျင်းများကသေချာသည်။
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // ကျွန်တော် `elem_size` အခါ `usize::MAX` တစ်စွမ်းရည်ပြန်လာကတည်းက
            // 0, ဒီမှာလာသေချာပေါက် `RawVec` အလွန်အကျွံဖြစ်ပါတယ်ဆိုလိုသည်။
            return Err(CapacityOverflow);
        }

        // ဝမ်းနည်းစရာ, ဤစစ်ဆေးမှုများနှင့်ပတ်သက်။ ငါတို့တကယ်လုပ်နိုင်ဘာမျှ။
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // ဤသည်အဆတိုးတက်မှုနှုန်းအာမခံပါသည်။
        // `cap <= isize::MAX` နှင့် `cap` အမျိုးအစား `usize` ဖြစ်သောကြောင့်နှစ်ဆတိုးခြင်းသည်မလွယ်ကူပါ။
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` ယေဘူယျအားဖြင့်တော့ `T` မဟုတ်ပါ။
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // ဤနည်းလမ်းပေါ်ရှိကန့်သတ်ချက်များသည် `grow_amortized` ရှိအခက်အခဲများနှင့်များစွာဆင်တူသော်လည်းဤနည်းလမ်းသည်များသောအားဖြင့်အနည်းငယ်သာ instantiated ဖြစ်ပြီးမကြာခဏဝေဖန်မှုနည်းသည်။
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // အမျိုးအစားအရွယ်အစားဖြစ်သည့်အခါကျွန်ုပ်တို့သည် `usize::MAX` ၏စွမ်းဆောင်ရည်ကိုပြန်ပို့ပြီးကတည်းက
            // 0, ဒီမှာလာသေချာပေါက် `RawVec` အလွန်အကျွံဖြစ်ပါတယ်ဆိုလိုသည်။
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` ယေဘူယျအားဖြင့်တော့ `T` မဟုတ်ပါ။
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// compile ကြိမ်လျော့ချရန်ဤ function ကို `RawVec` အပြင်ဘက်တွင်ရှိသည်။အသေးစိတ်အတွက် `RawVec::grow_amortized` အထက်ပါမှတ်ချက်ကိုကြည့်ပါ။
// (အလေ့အကျင့်တွင်တွေ့မြင်ကွဲပြားခြားနားသော `A` အမျိုးအစားအရေအတွက်က `T` အမျိုးအစားအရေအတွက်ကထက်အများကြီးသေးငယ်သောကွောငျ့ထို `A` parameter သည်, သိသာမဟုတ်ပါဘူး။)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // `RawVec::grow_*` ၏အရွယ်အစားကိုအနည်းဆုံးဖြစ်စေရန်ဤနေရာတွင်အမှားအယွင်းကိုစစ်ဆေးပါ။
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // ခွဲဝေချထားပေးသူသည်တန်းတူညီမျှမှုရှိမရှိစစ်ဆေးသည်
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// `RawVec` * မှသိမ်းဆည်းထားသောအရာများကို၎င်းအားမဖယ်ရှားဘဲမလွှတ်ဘဲလွတ်စေသည်။
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// အရံအမှားကိုင်တွယ်ဘို့ဗဟို function ကို။
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// အောက်ပါတို့ကိုအာမခံရမည်-
// * `> isize::MAX` byte-size object များကိုကျွန်ုပ်တို့ခွဲဝေချထားပေးမည်မဟုတ်ပါ။
// * ကျွန်ုပ်တို့က `usize::MAX` ကိုပြည့်လျှံမနေဘဲအမှန်တကယ်အနည်းငယ်သာခွဲဝေချထားပေးသည်။
//
// 64-bit တွင် `> isize::MAX` bytes ကိုခွဲဝေချထားခြင်းသည်မအောင်မြင်သောကြောင့် overflow ကိုစစ်ဆေးရန်လိုအပ်သည်။
// 32-bit နှင့် 16-bit တွင်ကျွန်ုပ်တို့အနေဖြင့်အသုံးပြုသူနေရာ 4GB ကိုသုံးနိုင်သောပလက်ဖောင်းပေါ်တွင်အသုံးပြုလျှင်ဥပမာအနေဖြင့် PAE သို့မဟုတ် x32 ကိုအသုံးပြုရန်အတွက်အပိုအကာအကွယ်တစ်ခုထည့်ရန်လိုအပ်သည်။
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// သတင်းပို့နိုင်မှုစွမ်းရည်ပြည့်ဝမှုအတွက်တာဝန်ယူရမည့်ဗဟိုတာဝန်တစ်ခု။
// ဤသည်သည် panics နှင့်သက်ဆိုင်သော code ထုတ်လုပ်မှုသည်အနည်းဆုံးဖြစ်ရန်သေချာစေလိမ့်မည်၊ အကြောင်းမှာ module တစ်ခုလုံးတွင် Zunchic အစား panics တည်နေရာတစ်ခုသာရှိသည်။
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}