/// အငြင်းပွားမှုများင်တစ် ဦး [`Vec`] ဖန်တီး။
///
/// `vec!` `Vec`s ကို array expression များကဲ့သို့တူညီသော syntax နှင့်သတ်မှတ်ရန်ခွင့်ပြုသည်။
/// ဒီ macro ပုံစံနှစ်မျိုးရှိတယ်။
///
/// - ပေးထားသောဒြပ်စင်များပါ ၀ င်သည့် [`Vec`] တစ်ခုကိုဖန်တီးပါ။
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - ပေးထားသောဒြပ်စင်တစ်ခုနှင့်အရွယ်အစားမှ [`Vec`] တစ်ခုဖန်တီးပါ။
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// သတိပြုရန်မှာ array expression များနှင့်မတူသည်မှာဤ syntax သည် [`Clone`] ကိုအကောင်အထည်ဖော်နေသော element များအားလုံးကိုထောက်ပံ့ပေးပြီး element အရေအတွက်သည်စဉ်ဆက်မပြတ်ဖြစ်ရန်မလိုပါ။
///
/// ၎င်းသည်စကားရပ်ကိုပုံတူပွားရန် `clone` ကိုအသုံးပြုလိမ့်မည်။ ထို့ကြောင့်ပုံမှန်မဟုတ်သော `Clone` အကောင်အထည်ဖော်မှုအမျိုးအစားများကို အသုံးပြု၍ သတိထားသင့်သည်။
/// ဥပမာအားဖြင့်, `vec![Rc::new(1);5] `vector တစ်ခုသည် boxed integer တန်ဖိုးနှင့်တူညီသောကိုးကားထားသောကိုးကားမဟုတ်ဘဲလွတ်လပ်စွာ boxed integer ကိုညွှန်းသည်။
///
///
/// ထို့အပြင် `vec![expr; 0]` ကိုခွင့်ပြုပြီး vector အချည်းနှီးထုတ်လုပ်သည်ကိုသတိပြုပါ။
/// သို့သော်၎င်းသည် `expr` ကိုအကဲဖြတ်နေဆဲဖြစ်ပြီးရလဒ်ကိုချက်ချင်းကျဆင်းသွားစေကာဘေးထွက်ဆိုးကျိုးများကိုသတိရပါ။
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): ဒီ macro definition အတွက်လိုအပ်သောပင်မ `[T]::into_vec` နည်းလမ်းကို cfg(test) နှင့်အတူမရရှိနိုင်ပါ။
// cfg(test) NB နှင့်သာရရှိနိုင်သည့် `slice::into_vec` function ကိုသုံးပါ။ နောက်ထပ်အချက်အလက်များအတွက် slice.rs ရှိ slice::hack module ကိုကြည့်ပါ။
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// runtime အသုံးအနှုန်းများကို Interpolation လုပ်၍ `String` တစ်ခုဖန်တီးသည်။
///
/// `format!` လက်ခံရရှိသည့်ပထမဆုံး argument သည် format string ဖြစ်သည်။ဒါက string ပကတိဖြစ်ရပါမည်။Formatting string ၏စွမ်းအားသည် `{}` s ဖြစ်သည်။
///
/// `format!` သို့ပေးပို့သောအပိုဆောင်း parameters များကိုအမည်သို့မဟုတ် positional parameters များကိုအသုံးပြုမဟုတ်လျှင်ပေးထားသောနိုင်ရန်အတွက် `{}` s ကိုအစားထိုး;ပိုမိုသိရှိလိုပါကများအတွက် [`std::fmt`] ကိုကြည့်ပါ။
///
///
/// `format!` အတွက်အသုံးများသောအရာမှာညှပ်များစုစည်းခြင်းနှင့် Interpolation ဖြစ်သည်။
/// တူညီသောစည်းဝေးကြီးများကို string ၏ရည်ရွယ်သောနေရာပေါ် မူတည်၍ [`print!`] နှင့် [`write!`] macros များနှင့်အသုံးပြုသည်။
///
/// တန်ဖိုးတစ်ခုတည်းကို string တစ်ခုအဖြစ်ပြောင်းရန် [`to_string`] method ကိုသုံးပါ။ဤသည်မှာ [`Display`] ပုံစံချ trait ကိုအသုံးပြုလိမ့်မည်။
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics သည် trait ပုံစံချခြင်းအကောင်အထည်ဖော်မှုသည်အမှားတစ်ခုပြန်ရောက်ပါက
/// ဤအချက်သည် `fmt::Write for String` သည်အမှားကိုယ်နှိုက်ဘယ်တော့မှမပြန်သောကြောင့်မှားယွင်းသောအကောင်အထည်ဖော်မှုကိုဖော်ပြသည်။
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// ပုံစံအနေအထားအတွက်ရောဂါရှာဖွေတိုးတက်လာဖို့စကားရပ်မှအတင်း AST node ကို။
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}