//! `String`s ကိုပုံစံချခြင်းနှင့်ပုံနှိပ်ခြင်းအတွက်အသုံးချမှုများ။
//!
//! ဤ module တွင် [`format!`] syntax extension အတွက် runtime support ပါဝင်သည်။
//! runtime တွင် argument များကို format လုပ်ရန်ဤ module သို့ခေါ်ဆိုမှုများကိုထုတ်လွှတ်ရန်ဤ macro ကို compiler တွင်အကောင်အထည်ဖော်သည်။
//!
//! # Usage
//!
//! [`format!`] macro သည် C ၏ `printf`/`fprintf` လုပ်ဆောင်ချက်များသို့မဟုတ် Python ၏ `str.format` function မှလာသူများနှင့်အကျွမ်းတဝင်ဖြစ်ရန်ရည်ရွယ်သည်။
//!
//! [`format!`] extension ၏ဥပမာအချို့မှာ-
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" ဦး ဆောင်သုညနှင့်အတူ
//! ```
//!
//! ၎င်းတို့မှပထမ argument သည် format string တစ်ခုဖြစ်သည်ကိုသင်တွေ့နိုင်သည်။compiler က string literal ဖြစ်ရန်လိုအပ်သည်။၎င်းသည် (တရားဝင်မှုစစ်ဆေးခြင်းကိုလုပ်ဆောင်ရန်အတွက်) တွင်လွန်ခဲ့သော variable တစ်ခုမဖြစ်နိုင်ပါ။
//! ထို့နောက် compiler က format string ကိုခွဲခြမ်းစိတ်ဖြာပြီးပေးသောအငြင်းပွားမှုများစာရင်းသည်ဤ format string သို့သွားရန်သင့်မသင့်ကိုဆုံးဖြတ်လိမ့်မည်။
//!
//! တန်ဖိုးတစ်ခုတည်းကို string တစ်ခုအဖြစ်ပြောင်းရန် [`to_string`] method ကိုသုံးပါ။ဤသည်မှာ [`Display`] ပုံစံချ trait ကိုအသုံးပြုလိမ့်မည်။
//!
//! ## အပြုသဘောဆောင်တဲ့ parameters တွေကို
//!
//! Formatting argument တစ်ခုချင်းစီသည်မည်သည့် value argumentating ရည်ညွှန်းသည်ကိုဖော်ပြရန်ခွင့်ပြုသည်။ အကယ်၍ ချန်လှပ်ထားပါက "the next argument" ဟုယူဆနိုင်သည်။
//! ဥပမာအားဖြင့် `{} {} {}` အမျိုးအစား string သည် parameters (၃) ခုကိုယူမည်ဖြစ်ပြီး၎င်းတို့အားပေးထားသည့်အတိုင်းအတူတူပင် format လုပ်လိမ့်မည်။
//! `{2} {1} {0}` အမျိုးအစား string သည်အငြင်းပွားမှုများကိုပြောင်းပြန်ပုံစံဖြင့် format လုပ်လိမ့်မည်။
//!
//! အနေအထားသတ်မှတ်ချက်နှစ်မျိုးကိုသင်စတင်ပေါင်းသင်းသည်ဆိုပါကအမှုအရာအနည်းငယ်ရှုပ်ထွေးသွားနိုင်သည်။"next argument" သတ်မှတ်ချက်သည်ငြင်းခုံမှုထက် ကျော်လွန်၍ ကြားခံအဖြစ်မှတ်ယူနိုင်သည်။
//! "next argument" ၏အသေးစိတ်ဖော်ပြချက်တစ်ခုစီကိုမြင်တိုင်းကြားရသည်။ဤသည်ကဤသို့သောအပြုအမူကိုဖြစ်ပေါ်စေသည်။
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! ပထမ ဦး ဆုံး `{}` ကိုတွေ့ရသည့်အချိန်တွင်အငြင်းအခုံကိုကျော်။ ကြားခံကြားခံတစ်ခုထပ်မံမတိုးချဲ့နိုင်တော့ပါကပထမဆုံးအငြင်းအခုံကိုပုံနှိပ်နိုင်သည်။ထို့နောက်ဒုတိယ `{}` သို့ရောက်သောအခါကြားဖြတ်သည်ဒုတိယအငြင်းပွားမှုကိုရှေ့သို့တိုးလိုက်သည်။
//! အမှန်ကတော့သူတို့ရဲ့ argument ကိုအတိအလင်းဖော်ပြသော parameters များသည် position argumentifiers ၏စည်းကမ်းချက်များအရ argument တစ်ခုကိုမဖော်ပြသော parameters များကိုမထိခိုက်စေပါ။
//!
//! format string တစ်ခုသည် ၄ င်း၏ argument များအားလုံးကိုအသုံးပြုရန်လိုအပ်သည်၊ မဟုတ်လျှင်၎င်းသည် compile-time error ဖြစ်သည်။format string ထဲမှာတစ်ကြိမ်ထက်မကထပ်တူအကြောင်းပြချက်မျိုးကိုသင်ရည်ညွှန်းနိုင်တယ်။
//!
//! ## သတ်မှတ်ထားသော parameters
//!
//! Rust ကိုယ်တိုင်တွင် Python ကဲ့သို့သောသတ်မှတ်ထားသောသတ်မှတ်ချက်နှင့်တူသောလုပ်ဆောင်ချက်တစ်ခုမရှိပါ။ သို့သော် [`format!`] macro သည် syntax extension တစ်ခုဖြစ်ပြီး၎င်းကိုသတ်မှတ်ထားသော parameters များကိုအသုံးပြုရန်ခွင့်ပြုသည်။
//! Named parameters တွေကို argument list ရဲ့အဆုံးမှာစာရင်းပြုစုထားပြီး syntax ရှိတယ်။
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! ဥပမာအားဖြင့်၊ အောက်ပါ [`format!`] အသုံးအနှုန်းများသည် argument အမည်ကိုအသုံးပြုသည်။
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! အမည်များရှိသည့်အငြင်းပွားမှုများပြီးနောက်တည်နေရာသတ်မှတ်ချက်များ (အမည်မပါသောသူများ) ကိုထားခြင်းသည်မသင့်လျော်ပါ။positional parameters များကဲ့သို့ပင် format string မှအသုံးမပြုပါသောအမည်ပေးထားသော parameters များကိုပေးရန်မမှန်ကန်ပါ။
//!
//! # Formatting Parameters
//!
//! Formatting လုပ်ခြင်းအငြင်းပွားမှုတစ်ခုချင်းစီကို format အမျိုးအစားများ ([the syntax](#syntax)) ရှိ `format_spec` နှင့်ကိုက်ညီသည်) ဖြင့်ပြောင်းလဲနိုင်သည်။ ထိုသတ်မှတ်ချက်များသည် format လုပ်သောအရာ၏ string ကိုယ်စားပြုမှုကိုအကျိုးသက်ရောက်သည်။
//!
//! ## Width
//!
//! ```
//! // ဤအမှုအလုံးစုံတို့ကိုပုံနှိပ် "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! ဤသည် format ကိုတက်ယူသင့်ကြောင်း "minimum width" များအတွက် parameter သည်ဖြစ်ပါတယ်။
//! အကယ်၍ တန်ဖိုး၏ string သည်ဤအက္ခရာများစွာကိုမဖြည့်ပါက fill/alignment မှသတ်မှတ်ထားသော padding ကိုလိုအပ်သောနေရာကိုယူရန်အသုံးပြုလိမ့်မည် (အောက်တွင်ကြည့်ပါ) ။
//!
//! width အတွက်တန်ဖိုးကို post တစ်ခုဖြစ်သော `$` ကိုထည့်ခြင်းဖြင့် parameter ၏ list ထဲတွင် [`usize`] အနေနှင့်လည်းထောက်ပံ့နိုင်သည်။ ဒုတိယ argument သည် width ကိုသတ်မှတ်သည့် [`usize`] ဖြစ်သည်။
//!
//! Dollar syntax နှင့်စကားပြေကိုကိုးကားခြင်းသည် "next argument" ကောင်တာကိုမသက်ရောက်ပါ။ ထို့ကြောင့်များသောအားဖြင့် position အားဖြင့် argument များကိုရည်ညွှန်းခြင်းသို့မဟုတ်အမည်ရှိ argument များကိုအသုံးပြုခြင်းသည်ကောင်းပါသည်။
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! အဆိုပါ optional ကိုဝစွာဇာတ်ကောင်များနှင့် alignment ကို [`width`](#width) parameter သည်နှင့်တွဲဖက်။ ပုံမှန်အားဖြင့်ထောက်ပံ့ပေးလျက်ရှိသည်။၎င်းကို `width` မတိုင်မီ၊ `:` ပြီးနောက်သတ်မှတ်ပေးရမည်။
//! ဤအချက်သည် format ချသည့်တန်ဖိုးသည် `width` ထက်သေးငယ်ပါက၎င်းကိုပတ်လည်တွင်အပိုစာလုံးများပုံနှိပ်လိမ့်မည်။
//! ဖြည့်သည်ကွဲပြားခြားနားသော align များအတွက်အောက်ပါမျိုးကွဲများလာ:
//!
//! * `[fill]<` - အဆိုပါအငြင်းအခုံ `width` ကော်လံအတွက် left-aligned ဖြစ်ပါတယ်
//! * `[fill]^` - အဆိုပါအငြင်းအခုံ `width` ကော်လံအတွက်ဗဟို-alignment ကိုဖြစ်ပါတယ်
//! * `[fill]>` - အဆိုပါအငြင်းအခုံ `width` ကော်လံအတွက် Right-aligned ဖြစ်ပါတယ်
//!
//! Non-numerics အတွက် default [fill/alignment](#fillalignment) သည် space နှင့် left-alignment ဖြစ်သည်။numeric formatters များအတွက်ပုံသေသည် space space သာမက right-alignment လည်းဖြစ်သည်။
//! အကယ်၍ `0` အလံ (အောက်တွင်ကြည့်ပါ) ကိုကိန်းဂဏန်းများအတွက်သတ်မှတ်ပါကသွယ်ဝိုက်ဖြည့်စွက်အက္ခရာမှာ `0` ဖြစ်သည်။
//!
//! alignment ကိုအချို့အမျိုးအစားများအားဖြင့်အကောင်အထည်ဖော်မည်မဟုတ်ပါသတိပြုပါ။အထူးသဖြင့်၎င်းသည်ယေဘုယျအားဖြင့် `Debug` trait အတွက်အကောင်အထည်ဖော်ခြင်းမရှိပါ။
//! padding ကိုသေချာအောင်လုပ်ဖို့နည်းလမ်းကောင်းတစ်ခုကတော့ input ကို format လုပ်ပြီး output ကိုရရှိဖို့အတွက်ရရှိလာတဲ့ string ကို pad ပါ။
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "မင်္ဂလာပါ Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! ဤရွေ့ကားအားလုံး formatter ၏အပြုအမူကိုပြောင်းလဲအလံဖြစ်ကြသည်။
//!
//! * `+` - ဤသည်မှာဂဏန်းအမျိုးအစားများအတွက်ရည်ရွယ်ထားခြင်းဖြစ်ပြီး၎င်းအမှတ်အသားကိုအမြဲပုံနှိပ်သင့်ကြောင်းဖော်ပြသည်။အပြုသဘောဆောင်သောသင်္ကေတများကိုမည်သည့်အခါကမှပုံနှိပ်ခြင်းမပြုပါ။ အနုတ်လက္ခဏာအမှတ်အသားကိုမူ `Signed` trait အတွက်သာပုံနှိပ်ထားသည်။
//! ဤအလံကမှန်ကန်သောနိမိတ် (`+` သို့မဟုတ် `-`) ကိုအမြဲပုံနှိပ်သင့်ကြောင်းဖော်ပြသည်။
//! * `-` - လောလောဆယ်အသုံးမပြုပါ
//! * `#` - ဤအလံသည် "alternate" ပုံနှိပ်ခြင်းပုံစံကိုအသုံးပြုသင့်ကြောင်းဖော်ပြသည်။အခြားပုံစံများမှာ
//!     * `#?` - [`Debug`] format ကိုတော်တော်လေးရိုက်ပါ
//!     * `#x` - တစ် ဦး `0x` နှင့်အတူအငြင်းအခုံအရင်
//!     * `#X` - တစ် ဦး `0x` နှင့်အတူအငြင်းအခုံအရင်
//!     * `#b` - တစ် ဦး `0b` နှင့်အတူအငြင်းအခုံအရင်
//!     * `#o` - တစ် ဦး `0o` နှင့်အတူအငြင်းအခုံအရင်
//! * `0` - ဤသည်ကို `width` သို့ padding နှစ်ခုလုံးကို `0` အက္ခရာဖြင့်လုပ်ဆောင်သင့်ပြီးနိမိတ်လက္ခဏာကိုသတိပြုရန် integer formats အတွက်ညွှန်ပြသည်။
//! `{:08}` ကဲ့သို့သောပုံစံသည် `1` ကိန်းအတွက် `00000001` ကိုထုတ်ပေးသည်။ တူညီသောပုံစံသည် `-1` ကိန်းအတွက် `-0000001` ကိုထုတ်ပေးသည်။
//! အနုတ်လက္ခဏာဗားရှင်းတွင်အပေါင်းလက္ခဏာသုညထက်နည်းသောသုညရှိကြောင်းသတိပြုပါ။
//!         padding သုညများကိုသင်္ကေတပြီးနောက် (ရှိခဲ့လျှင်) နှင့်ဂဏန်းများရှေ့တွင်အမြဲထားရှိသည်ကိုသတိပြုပါ။`#` အလံနှင့်အတူတကွအသုံးပြုသောအခါအလားတူစည်းမျဉ်းကိုကျင့်သုံးသည်။ ရှေ့ဆက်နောက်မှသော်လည်းဂဏန်းများမတိုင်မီ padding သုညများကိုထည့်သည်။
//!         ရှေ့ဆက်ကတော့အကျယ်အကျယ်ပါဝင်သည်။
//!
//! ## Precision
//!
//! ဂဏန်းမဟုတ်သောအမျိုးအစားများအတွက်၎င်းကို "maximum width" ဟုသတ်မှတ်နိုင်သည်။
//! အကယ်၍ ရလဒ် string သည်ဤ width ထက်ပိုရှည်ပါက၎င်းသည်ဤများစွာသောအက္ခရာများအရညှို့ယူသည်။ အကယ်၍ သူတို့အား parameters များကိုသတ်မှတ်ပါကသင့်လျော်သော `fill`, `alignment` နှင့် `width` နှင့်အတူထုတ်လွှတ်လိုက်သည်။
//!
//! အရေးပါသောအမျိုးအစားများအတွက်၎င်းကိုလျစ်လျူရှုထားသည်။
//!
//! floating-point အမျိုးအစားများအတွက်၊ ဒီကိန်းဂဏန်းပြီးနောက်ဂဏန်းဘယ်လောက်ပုံနှိပ်သင့်တယ်ဆိုတာကိုပြတယ်။
//!
//! လိုချင်သော `precision` ကိုသတ်မှတ်ရန်နည်းလမ်း ၃ ခုရှိသည်။
//!
//! 1. `.N` တစ်ခုလုံး:
//!
//!    integer `N` ကိုယ်နှိုက်ကတိကျတယ်။
//!
//! 2. ကိန်းဂဏန်း `.N$` နောက်ကိန်းတစ်ခုသို့မဟုတ်နာမည်ကိုထည့်ပါ
//!
//!    တိကျစွာအဖြစ် (*`usize` ဖြစ်ရမည်) format ကို* အငြင်းအခုံ * `N` ။
//!
//! 3. ကြယ်တစ်ပွင့် `.*`:
//!
//!    `.*` ဆိုလိုသည်မှာဒီ `{...}` သည် *နှစ်ခု* ပုံစံသွင်းမှုတစ်ခုနှင့်မဟုတ်ဘဲပထမတစ်ခုဖြစ်သည် `usize` တိကျမှုနှင့်ဒုတိယသည်ပုံနှိပ်ရန်တန်ဖိုးကိုဆိုလိုသည်။
//!    ဤကိစ္စတွင် အကယ်၍ တစ်ခုသည် format string `{<arg>:<spec>.*}` ကိုအသုံးပြုပါက `<arg>` အစိတ်အပိုင်းသည်ပုံနှိပ်ရန်* တန်ဖိုး * ကိုရည်ညွှန်းသည်။ `precision` သည် `<arg>` ရှေ့တွင်ထည့်သွင်းရမည်။
//!
//! ဥပမာအားဖြင့်၊ အောက်ပါခေါ်ဆိုမှုအားလုံးသည် `Hello x is 0.01000` အတူတူပင်ဖြစ်သည်။
//!
//! ```
//! // မင်္ဂလာပါ {arg 0 ("x")} သည် {arg 1 (0.01) with precision specified inline (5)} ဖြစ်သည်
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // မင်္ဂလာပါ {arg 1 ("x")} သည် {arg 2 (0.01) with precision specified in arg 0 (5)} ဖြစ်သည်
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // မင်္ဂလာပါ {arg 0 ("x")} သည် {arg 2 (0.01) with precision specified in arg 1 (5)} ဖြစ်သည်
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // မင်္ဂလာပါ {next arg ("x")} သည် {second of next two args (0.01) with precision specified in first of next two args (5)} ဖြစ်သည်
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // မင်္ဂလာပါ {next arg ("x")} သည် {arg 2 (0.01) with precision specified in its predecessor (5)} ဖြစ်သည်
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // မင်္ဂလာပါ {next arg ("x")} သည် {arg "number" (0.01) with precision specified in arg "prec" (5)} ဖြစ်သည်
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! ဤအနေဖြင့်:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! သိသိသာသာကွဲပြားခြားနားသောအရာသုံးခုပုံနှိပ်:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! အချို့သောပရိုဂရမ်းမင်းဘာသာစကားများတွင် string formatting လုပ်ဆောင်မှုများသည် operating system ၏ locale setting ပေါ်တွင်မူတည်သည်။
//! Rust ၏စံပြစာကြည့်တိုက်မှပေးထားသောပုံစံလုပ်ဆောင်ချက်များသည်မည်သည့်မျဉ်းကြောင်းမျှမရှိပါ။ အသုံးပြုသူ၏ဖွဲ့စည်းပုံမည်သို့ပင်ရှိစေကာမူစနစ်အားလုံးတွင်တူညီသောရလဒ်များကိုထုတ်ပေးလိမ့်မည်။
//!
//! ဥပမာအားဖြင့်၊ အောက်ပါကုဒ်သည် `1.5` ကိုအမြဲတမ်းပုံနှိပ်ထုတ်ပေးလိမ့်မည်။
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! ပကတိအက္ခရာများဖြစ်သော `{` နှင့် `}` တို့ကို၎င်းတို့အားတူညီသောအက္ခရာများနှင့်ရှေ့တွင်ထည့်ခြင်းဖြင့် string တွင်ထည့်နိုင်သည်။ဥပမာအားဖြင့်၊ `{` ဇာတ်ကောင် `{{` နှင့်ထွက်ပြေးလွတ်မြောက်ပြီး `}` ဇာတ်ကောင် `}}` ဖြင့်ထွက်ပြေးသည်။
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! အနှစ်ချုပ်ဖို့, ဒီမှာသင် format နဲ့ညှို့၏သဒ္ဒါအပြည့်အဝကိုရှာတွေ့နိုင်ပါသည်။
//! အသုံးပြုသည့်ပုံစံချသည့်ဘာသာစကားအတွက် syntax သည်အခြားဘာသာစကားများမှရေးဆွဲထားခြင်းဖြစ်ပြီး၎င်းသည်အလွန်အမင်းဂြိုလ်သားမဖြစ်ရ။အငြင်းပွားမှုများကို Python ကဲ့သို့သော syntax ဖြင့် format လုပ်သည်။ ဆိုလိုသည်မှာ C-like `%` အစားအငြင်းပွားမှုများကို `{}` ကဝိုင်းထားသည်။
//! Formatting syntax အတွက်အမှန်တကယ်သဒ္ဒါမှာ-
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! အထက်ပါသဒ္ဒါတွင် `text` ၌ `'{'` သို့မဟုတ် `'}'` အက္ခရာများမပါရှိနိုင်။
//!
//! # traits ကို format လုပ်ခြင်း
//!
//! အငြင်းပွားမှုကိုသတ်သတ်မှတ်မှတ်အမျိုးအစားတစ်ခုဖြင့်ပုံစံချရန်တောင်းဆိုသည့်အခါသင်အငြင်းပွားမှုသည် trait တစ်ခု၏ဆက်စပ်မှုကိုတောင်းဆိုနေသည်။
//! ၎င်းသည်အမှန်တကယ်အမျိုးအစားများစွာကို `{:x}` ([`i8`] နှင့် [`isize`] ကဲ့သို့) မှတဆင့် format လုပ်နိုင်စေသည်။လက်ရှိအမျိုးအစားများ traits သို့မြေပုံဆွဲသည်-
//!
//! * *ဘာမျှမ* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` lower [`Debug`]-စာလုံးငယ် hexadecimal ကိန်းများနှင့်အတူ
//! * `X?` - [`Debug`]-upper-case hexadecimal ကိန်း
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! ဆိုလိုသည်မှာ [`fmt::Binary`][`Binary`] trait ကိုအကောင်အထည်ဖော်သည့်အငြင်းပွားမှုအမျိုးအစားအားလုံးကို `{:b}` ဖြင့်ပုံစံချနိုင်သည်။စံစာကြည့်တိုက်မှလည်းအချို့သောအမျိုးအစားများအတွက် traits အတွက်အကောင်အထည်ဖော်မှုများကိုပြုလုပ်သည်။
//!
//! အဘယ်သူမျှမ format ကို (`{}` သို့မဟုတ် `{:6}` ကဲ့သို့) သတ်မှတ်ထားသောလျှင်, trait အသုံးပြုသောအမျိုးအစား [`Display`] trait ဖြစ်ပါတယ်။
//!
//! သင်၏ကိုယ်ပိုင်အမျိုးအစားအတွက် trait ပုံစံတစ်ခုကိုအကောင်အထည်ဖော်သောအခါ၊ သင်သည်လက်မှတ်၏နည်းလမ်းတစ်ခုကိုအသုံးပြုရမည်။
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // ကျွန်တော်တို့ရဲ့ထုံးစံအမျိုးအစား
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! သင်၏အမျိုးအစားအား X-`self` အနေဖြင့် by-reference အဖြစ်ကူးယူပြီး၎င်းသည် `f.buf` စီးထဲသို့ output ကိုထုတ်လွှတ်သင့်သည်။trait ပုံစံတစ်ခုချင်းစီသည်တောင်းဆိုထားသော format သတ်မှတ်ချက်ကိုမှန်ကန်စွာလိုက်နာရန်ဖြစ်သည်။
//! ဤအ parameters တွေကို၏တန်ဖိုးများကို [`Formatter`] struct ၏လယ်ပြင်၌စာရင်းဝင်ပါလိမ့်မည်။ဤအရာကိုကူညီနိုင်ရန်အတွက် [`Formatter`] struct သည်အထောက်အကူပြုနည်းစနစ်များကိုလည်းထောက်ပံ့ပေးသည်။
//!
//! ထို့အပြင်ဤ function ၏ return value သည် [`Result`]`<(),`[`std: : fmt::Error`] `>` အမျိုးအစား alias ဖြစ်သော [`fmt::Result`] ဖြစ်သည်။
//! Formatting implementations သည် [`Formatter`] (ဥပမာ၊ [`write!`] ကိုခေါ်သည့်အခါ) မှအမှားများပြန့်ပွားစေရန်သေချာစေသင့်သည်။
//! သို့သော်၊ သူတို့သည်အမှားအယွင်းများကိုဘယ်တော့မှ ပြန်၍ မပေးသင့်ပါ။
//! ဆိုလိုသည်မှာပုံစံချရေးဆွဲမှုအကောင်အထည်ဖော်မှုသည်လွန်ခဲ့သော [`Formatter`] အမှားတစ်ခုပြန်ရောက်လာပါကအမှားတစ်ခုကိုသာပြန်ပေးလိမ့်မည်။
//! ဘာဖြစ်လို့လဲဆိုတော့ function signature ကဆန့်ကျင်တဲ့အရာ၊ string formatting ကိုမှားယွင်းတဲ့လုပ်ဆောင်မှုတစ်ခုဖြစ်လို့ပဲ။
//! အဘယ်ကြောင့်ဆိုသော်နောက်ခံစီးသို့စာပြန်ခြင်းသည်အလုပ်မလုပ်သောကြောင့်ရလဒ်ကိုသာပြန်ပို့ပေးသည်။ ၎င်းသည် stack ကို back up လုပ်သောအမှားတစ်ခုဖြစ်ပေါ်စေသည်ဟူသောအချက်ကိုပြန့်ပွားစေရန်နည်းလမ်းတစ်ခုကိုပေးရမည်။
//!
//! traits ပုံစံချခြင်းကိုအကောင်အထည်ဖော်ရန်ဥပမာတစ်ခုမှာ-
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // `f` တန်ဖိုးသည် `Write` trait ကိုအသုံးပြုသည်။မက္ကရိုမျှော်လင့်နေသည်။
//!         // သတိပြုရန်မှာဤပုံစံချခြင်းသည် string အမျိုးအစားများအတွက်ထောက်ပံ့ပေးသောအမျိုးမျိုးသော flags များကိုလျစ်လျူရှုထားခြင်းဖြစ်သည်။
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // ကွဲပြားသော traits သည်အမျိုးအစားတစ်ခု၏အမျိုးမျိုးသော output အမျိုးအစားများကိုခွင့်ပြုသည်။
//! // ဤပုံစံ၏အဓိပ္ပါယ်သည် vector ၏ပမာဏကိုပုံနှိပ်ရန်ဖြစ်သည်။
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Formatter အရာဝတ္ထုပေါ်ရှိအကူအညီနည်းလမ်း `pad_integral` ကိုအသုံးပြုခြင်းအားဖြင့် format အလံများကိုလေးစားပါ။
//!         // အသေးစိတ်အတွက်နည်းလမ်းစာရွက်စာတမ်းများကိုကြည့်ပါ။ `pad` function ကိုကြိုးကြိုးချည်များတွင်အသုံးပြုနိုင်သည်။
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! ဤပုံစံ traits နှစ်ခုသည်ကွဲပြားသောရည်ရွယ်ချက်များရှိသည်။
//!
//! - [`fmt::Display`][`Display`] အကောင်အထည်ဖော်မှုများသည်အမျိုးအစားကိုအချိန်တိုင်းသစ္စာရှိရှိ UTF-8 string တစ်ခုအဖြစ်ကိုယ်စားပြုနိုင်သည်ဟုအခိုင်အမာပြောဆိုသည်။** အမျိုးအစားအားလုံးသည် [`Display`] trait ကိုအကောင်အထည်ဖော်လိမ့်မည်ဟုမျှော်လင့်မထားပါ။
//! - [`fmt::Debug`][`Debug`] ** **** **** **** ****|**** **** **** **** အားလုံးအများသုံးအမျိုးအစားများအတွက်အကောင်အထည်ဖော်မှုကိုအကောင်အထည်ဖော်သင့်သည်။
//!   ရလဒ်သည်ပုံမှန်အားဖြင့်ပြည်တွင်းအခြေအနေကိုဖြစ်နိုင်သမျှမှန်ကန်စွာကိုယ်စားပြုလိမ့်မည်။
//!   [`Debug`] trait ၏ရည်ရွယ်ချက်မှာ Rust ကုဒ်ကို debugging လွယ်ကူစေရန်ဖြစ်သည်။များသောအားဖြင့် `#[derive(Debug)]` ကိုအသုံးပြုခြင်းသည်လုံလောက်ပါသည်။
//!
//! traits နှစ်ခုလုံးမှထွက်ရှိမှု၏ဥပမာအချို့:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # ဆက်စပ် macros များ
//!
//! [`format!`] မိသားစုတွင်သက်ဆိုင်သော macros များစွာရှိသည်။လက်ရှိအကောင်အထည်ဖော်နေသောများမှာ
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! ဤနှင့် [`writeln!`] သည်သတ်မှတ်ထားသောစီးဆင်းမှုသို့ format string ကိုထုတ်လွှတ်ရန်အသုံးပြုသည့် macros နှစ်ခုဖြစ်သည်။၎င်းသည် format strings များအလယ်အလတ်ခွဲဝေချထားခြင်းများကိုကာကွယ်ရန်နှင့် output ကိုတိုက်ရိုက်ရေးသားရန်အတွက်အသုံးပြုသည်။
//! ပါးပျဉ်းအောကျတှငျ, ဒီ function ကိုအမှန်တကယ် [`std::io::Write`] trait အပေါ်သတ်မှတ်ထားသော [`write_fmt`] function ကိုမှီငြမ်းနေသည်။
//! အသုံးပြုမှုဥပမာမှာ-
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! ဤနှင့် [`println!`] သည်သူတို့၏ output ကို stdout သို့ထုတ်လွှတ်သည်။[`write!`] macro နှင့်ဆင်တူသည်မှာဤ macros များ၏ရည်မှန်းချက်သည် output ကိုပုံနှိပ်သောအခါအလယ်အလတ်ခွဲဝေမှုကိုရှောင်ရှားရန်ဖြစ်သည်။အသုံးပြုမှုဥပမာမှာ-
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! [`eprint!`] နှင့် [`eprintln!`] macros များသည် output ကို stderr သို့ထုတ်လွှတ်ခြင်း မှလွဲ၍ [`print!`] နှင့် [`println!`] နှင့်တူညီသည်။
//!
//! ### `format_args!`
//!
//! ၎င်းသည် format string ကိုဖော်ပြသည့်ရှင်းလင်းပြတ်သားသောအရာဝတ္ထုတစ်ဝိုက်ကိုဘေးကင်းလုံခြုံစွာဖြတ်သန်းရန်အသုံးပြုသောသိလိုသော macro ဖြစ်သည်။ဒီအရာဝတ္ထုကိုဖန်တီးရန်အမှိုက်ပုံခွဲဝေချထားမှုမလိုအပ်ပါ၊ ၎င်းသည် stack မှအချက်အလက်များကိုသာရည်ညွှန်းသည်။
//! ပါးပျဉ်းအောကျတှငျ, ဆက်စပ် macros များအားလုံးဒီစည်းကမ်းချက်များ၌အကောင်အထည်ဖော်နေကြသည်။
//! ပထမ ဦး စွာဥပမာပြရမည့်ဥပမာမှာ-
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! [`format_args!`] macro ၏ရလဒ်သည် type [`fmt::Arguments`] ၏တန်ဖိုးဖြစ်သည်။
//! ဤဖွဲ့စည်းပုံကို Format string ကိုလုပ်ဆောင်ရန်အတွက်ဤ module အတွင်းရှိ [`write`] နှင့် [`format`] လုပ်ဆောင်ချက်များကိုလွှဲပြောင်းနိုင်သည်။
//! ဤ macro ၏ရည်ရွယ်ချက်မှာ formatting strings များနှင့်ဆက်ဆံရာတွင်အလယ်အလတ်ခွဲဝေမှုကိုထပ်မံတားဆီးရန်ဖြစ်သည်။
//!
//! ဥပမာအားဖြင့်၊ logging library သည် standard format format ကိုအသုံးပြုနိုင်တယ်၊ ဒါပေမယ့် output သည်ဘယ်မှာသွားသင့်သည်ကိုမဆုံးဖြတ်မချင်း ၄ င်းသည် internal structure ကိုဖြတ်သန်းသွားလိမ့်မယ်။
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// အဆိုပါ `format` function ကိုတစ် ဦး [`Arguments`] struct ကိုယူနှင့်ရရှိလာတဲ့ format ချ string ကိုပြန်လည်ရောက်ရှိ။
///
///
/// [`Arguments`] ဥပမာအား [`format_args!`] macro နှင့်ဖန်တီးနိုင်သည်။
///
/// # Examples
///
/// အခြေခံအသုံးပြုမှု-
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format!`] ကိုအသုံးပြုခြင်းသည်ပိုကောင်းသည်ကိုသတိပြုပါ။
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}