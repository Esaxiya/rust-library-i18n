//! # အဆိုပါ Rust core ကိုခွဲဝေနှင့် collection များကိုစာကြည့်တိုက်
//!
//! ဤစာကြည့်တိုက်သည်အမှိုက်ပုံခွဲဝေထားသည့်တန်ဖိုးများကိုစီမံခန့်ခွဲရန်အတွက် smart pointers နှင့် collection များကိုပေးသည်။
//!
//! ဤစာကြည့်တိုက်သည် libcore ကဲ့သို့ပုံမှန်အားဖြင့်အသုံးပြုရန်မလိုအပ်ပါ။ ၎င်း၏အကြောင်းအရာများကို [`std` crate](../std/index.html) တွင်ပြန်လည်တင်ပို့သည်။
//! သို့သော် `#![no_std]` attribute ကိုအသုံးပြုသော Crates သည်ပုံမှန်အားဖြင့် `std` ပေါ်တွင်မူမတည်ပါ။ ထို့ကြောင့် crate ကိုအစားထိုးမည်။
//!
//! ## Boxed တန်ဖိုးများ
//!
//! [`Box`] type ဟာ smart pointer type တစ်ခုဖြစ်သည်။[`Box`] ၏ပိုင်ရှင်တစ် ဦး တည်းသာရှိနိုင်ပြီးအမှိုက်ပုံပေါ်တွင်နေထိုင်သောအကြောင်းအရာများကိုပိုင်ရှင်မှဆုံးဖြတ်နိုင်သည်။
//!
//! ဤအမျိုးအစားကို `Box` တန်ဖိုးအရွယ်အစားသည် pointer ၏အရွယ်အစားနှင့်တူညီသောကြောင့်ချည်ကြားတွင်ထိရောက်စွာပို့နိုင်သည်။
//! သစ်ပင်ကဲ့သို့ဒေတာဖွဲ့စည်းပုံကိုမကြာခဏသေတ္တာများဖြင့်တည်ဆောက်ကြသည်။ အကြောင်းမှာ node တစ်ခုစီတွင်ပိုင်ရှင်တစ် ဦး တည်းသာရှိသည်။
//!
//! ## ကိုးကားထောက်ပြရေတွက်
//!
//! [`Rc`] type သည် thread တစ်ခုအတွင်းရှိ memory ကိုမျှဝေရန်ရည်ရွယ်ထားသော non-threadsafe reference-counted pointer အမျိုးအစားဖြစ်သည်။
//! [`Rc`] pointer သည် `T` အမျိုးအစားတစ်ခုကိုထုပ်ပြီး၊ မျှဝေထားသောရည်ညွှန်းချက် `&T` ကိုသာခွင့်ပြုသည်။
//!
//! (ဥပမာ [`Box`] ကိုအသုံးပြုခြင်းကဲ့သို့) အမွေဆက်ခံထားသည့် mutability သည် application အတွက်အလွန်အမင်းတင်းတင်းကျပ်နေပြီး mutation ကိုခွင့်ပြုရန် [`Cell`] သို့မဟုတ် [`RefCell`] အမျိုးအစားများနှင့်တွဲစပ်ထားသည့်အခါဤအမျိုးအစားသည်အသုံးဝင်သည်။
//!
//!
//! ## Atomically ကိုကိုးကားထောက်ပြရေတွက်
//!
//! [`Arc`] အမျိုးအစားသည်0Safe [`Rc`] အမျိုးအစားနှင့်တူသည်။၎င်းတွင်ပါ ၀ င်သည့် `T` အမျိုးအစားကိုမျှဝေရန်လိုအပ်သည် မှလွဲ၍ [`Rc`] ၏လုပ်ဆောင်မှုအားလုံးအတူတူဖြစ်သည်။
//! ထို့အပြင် [`Arc<T>`][`Arc`] သည် [`Rc<T>`][`Rc`] မဟုတ်သောအချိန်တွင်ပို့လွှတ်နိုင်သည်။
//!
//! ဤအမျိုးအစားသည်ပါ ၀ င်သည့်ဒေတာများကိုမျှဝေသုံးစွဲခွင့်ကိုခွင့်ပြုပေးပြီးထပ်တူရင်းမြစ်များ mutation ကိုခွင့်ပြုရန် mutexes ကဲ့သို့သောထပ်တူပြုခြင်း Primitives နှင့်တွဲဖက်လေ့ရှိသည်။
//!
//! ## Collections
//!
//! အသုံးအများဆုံးယေဘူယျရည်ရွယ်ချက်ဒေတာဖွဲ့စည်းပုံ၏အကောင်အထည်ဖော်မှုကိုဤစာကြည့်တိုက်တွင်သတ်မှတ်ထားသည်။၎င်းတို့ကို [standard collections library](../std/collections/index.html) မှတဆင့်ပြန်လည်တင်ပို့သည်။
//!
//! ## အမှိုက်ပုံ interfaces
//!
//! [`alloc`](alloc/index.html) module သည်အဆင့်နိမ့်သော interface ကိုပုံမှန်ကမ္ဘာလုံးဆိုင်ရာခွဲဝေချထားပေးသူအဖြစ်သတ်မှတ်သည်။၎င်းသည် libc allocator API နှင့်မကိုက်ညီပါ။
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// နည်းပညာအရ၊ ဤသည် rustdoc ၏အမှားတစ်ခုဖြစ်သည်။ rustdoc သည် `#[lang = slice_alloc]` လုပ်ကွက်များ၏မှတ်တမ်းသည် `&[T]` အတွက်ဖြစ်သည်၊ `core` တွင်ဤအင်္ဂါရပ်ကို သုံး၍ စာရွက်စာတမ်းများရှိသည့်အပြင် feature-gate ကို enable မလုပ်နိုင်ခြင်းကြောင့်ရူးသွပ်သွားသည်။
// အကောင်းဆုံးမှာ၊ ၎င်းသည်အခြား crates မှမှတ်တမ်းများအတွက် feature gate ကိုစစ်ဆေးလိမ့်မည်မဟုတ်သော်လည်း၎င်းသည် lang ပစ္စည်းများအတွက်သာပေါ်ပေါက်နိုင်သဖြင့်ပြင်ရန်မသင့်တော်ပါ။
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// ဒီစာကြည့်တိုက်ကိုစမ်းသပ်ခွင့်ပြုသည်

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// အခြား modules များအသုံးပြုသည့် internal macros များပါ ၀ င်သည့် module (အခြား module များမတိုင်မီထည့်သွင်းရန်လိုအပ်သည်) ။
#[macro_use]
mod macros;

// အနိမ့်အဆင့်ခွဲဝေမဟာဗျူဟာများအတွက်ထောက်ပံ့အမှိုက်ပုံ

pub mod alloc;

// အထက်တွင်ရှိသောအမှိုက်ပုံကို သုံး၍ အခြေခံအမျိုးအစားများ

// စမ်းသပ်မှု cfg တွင်တည်ဆောက်စဉ် lang-items များကိုပုံတူပွားခြင်းမှရှောင်ရှားရန် `boxed.rs` မှ mod ကိုသတ်မှတ်ပေးရမည်။ဒါပေမယ့်လည်း code ကို `use boxed::Box;` ကြေငြာချက်များခွင့်ပြုရန်လိုအပ်သည်။
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}