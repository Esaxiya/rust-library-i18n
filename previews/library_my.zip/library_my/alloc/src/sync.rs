#![stable(feature = "rust1", since = "1.0.0")]

//! Thread-ဘေးကင်းလုံခြုံရည်ညွှန်းရေတွက်ထောက်ပြ။
//!
//! အသေးစိတ်အတွက် [`Arc<T>`][Arc] စာရွက်စာတမ်းများကိုကြည့်ပါ။

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// `Arc` သို့လုပ်ရန်ရည်ညွှန်းမှုပမာဏအပေါ်ပျော့ပျောင်းသောကန့်သတ်ချက်။
///
/// ဤကန့်သတ်ချက်ထက်ကျော်လွန်ပါက _exactly_ `MAX_REFCOUNT + 1` ကိုးကားချက်များအရသင်၏ပရိုဂရမ်ကိုဖျက်သိမ်းလိမ့်မည်။
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer သည်မှတ်ဉာဏ်ခြံစည်းရိုးများကိုမပံ့ပိုးပါ။
// Arc/Weak အကောင်အထည်ဖော်မှုတွင်မှားယွင်းသောအပြုသဘောဆောင်သောအစီရင်ခံစာများကိုရှောင်ရှားရန်အစားထပ်မံညှိနှိုင်းရန်အတွက်အက်တမ်ဝန်များကိုအသုံးပြုပါ။
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// တစ် ဦး ကချည်-လုံခြုံရည်ညွှန်း-ရေတွက် pointer ။'Arc' သည် Atomically Reference Counted ဟုဆိုလိုသည်။
///
/// `Arc<T>` အမျိုးအစားသည်အမှိုက်ပုံတွင်ခွဲဝေထားသော `T` အမျိုးအစား၏ပိုင်ဆိုင်မှုကိုပေးသည်။`Arc` တွင် [`clone`][clone] ကိုအသုံးပြုခြင်းသည် `Arc` ဥပမာအသစ်ကိုထုတ်လုပ်သည်။ ၎င်းသည်ရည်ညွှန်းအရေအတွက်တိုးမြှင့်နေစဉ်အရင်းအမြစ် `Arc` ကဲ့သို့အမှိုက်ပုံပေါ်တွင်တူညီသောခွဲဝေမှုကိုညွှန်ပြသည်။
/// ပေးထားသောခွဲဝေခြင်းအတွက်နောက်ဆုံး `Arc` ညွှန်ကိန်းဖျက်ဆီးခံရသောအခါ၎င်းခွဲဝေတွင်သိမ်းဆည်းထားသောတန်ဖိုး (များသောအားဖြင့် "inner value" ဟုရည်ညွှန်း) လည်းကျဆင်းသွားသည်။
///
/// Rust ရှိမျှဝေထားသောကိုးကားချက်များသည်ပုံမှန်အားဖြင့် mutation ကိုတားမြစ်ထားပြီး `Arc` သည်ခြွင်းချက်မဟုတ်ပါ။ သင်သည်ယေဘုယျအားဖြင့် `Arc` အတွင်းရှိတစ်ခုခုအတွက် mutable reference ကိုမရနိုင်ပါ။အကယ်၍ သင်သည် `Arc` တစ်ခုမှတဆင့် mutate လုပ်ရန်လိုအပ်ပါက [`Mutex`][mutex], [`RwLock`][rwlock] သို့မဟုတ် [`Atomic`][atomic] အမျိုးအစားတစ်ခုကိုသုံးပါ။
///
/// ## ဘေးကင်းလုံခြုံမှု Thread
///
/// [`Rc<T>`] နှင့်မတူဘဲ `Arc<T>` သည်၎င်း၏ရည်ညွှန်းရေတွက်ရန်အတွက်အက်တမ်စစ်ဆင်ရေးကိုအသုံးပြုသည်။ဆိုလိုသည်မှာ၎င်းသည်ချည်မျှင်ဖြစ်သည်။အားနည်းချက်မှာအနုမြူဗုံးလုပ်ဆောင်မှုသည်သာမန်မှတ်ဉာဏ်သုံးခြင်းထက်စျေးကြီးသည်။သငျသညျချည်အကြားရည်ညွှန်းရေတွက်ခွဲဝေမှုမျှဝေကြသည်မဟုတ်လျှင်, အနိမ့် overhead များအတွက် [`Rc<T>`] ကိုအသုံးပြု။ စဉ်းစားပါ။
/// [`Rc<T>`] ဘာလို့လဲဆိုတော့ compiler က Thread များအကြား [`Rc<T>`] ပို့ရန်မည်သည့်ကြိုးပမ်းမှုကိုမဆိုဖမ်းယူလိမ့်မယ်။
/// သို့သော်စာကြည့်တိုက်စားသုံးသူများကိုပိုမိုပြောင်းလွယ်ပြင်လွယ်မှုပေးနိုင်ရန်အတွက်စာကြည့်တိုက်တစ်ခုသည် `Arc<T>` ကိုရွေးချယ်နိုင်သည်။
///
/// `Arc<T>` နေသမျှကာလပတ်လုံး `T` [`Send`] နှင့် [`Sync`] အကောင်အထည်ဖော်နေသမျှကာလပတ်လုံး [`Send`] နှင့် [`Sync`] ကိုအကောင်အထည်ဖော်မည်။
/// Thread-safe ဖြစ်ရန်ဘာကြောင့် non-thread-safe type `T` ကို `Arc<T>` ထဲသို့ထည့်သွင်း။ မရသနည်း။၎င်းသည်ပထမ ဦး ဆုံးအနေနှင့်အနည်းငယ်မျှသာသိရှိနိုင်သည်-ပြီးနောက်၊ `Arc<T>` ချည်မျှင်ဘေးကင်းလုံခြုံမှုသည်အဓိကမဟုတ်ပါလား။အဓိကသော့ချက်မှာ `Arc<T>` ကအချက်အလက်များကိုအတူတူပိုင်ဆိုင်ခွင့်ကိုလုံခြုံစွာချည်နှောင်စေသည်။ သို့သော်၎င်း၏အချက်အလက်များကိုချည်မျှင်လုံခြုံမှုကိုမထည့်ထားပါ။
///
/// စဉ်းစားကြည့်ပါ `Arc <` [`RefCell<T>`]`>`။
/// [`RefCell<T>`] [`Sync`] မဟုတ်ပါ၊ `Arc<T>` သည်အမြဲတမ်း [`Send`] ဖြစ်ပါက `Arc <` [`RefCell<T>`]`>`အဖြစ်ကောင်းစွာပါလိမ့်မယ်။
/// ထိုအခါမူကား, ငါတို့ပြaနာတစ်ခုရှိလိမ့်မယ်
/// [`RefCell<T>`] ချည်မျှင်မဟုတ်ပါ;၎င်းသည်အက်တမ်မဟုတ်သောလုပ်ဆောင်မှုများကို အသုံးပြု၍ ချေးယူသည့်အရေအတွက်ကိုခြေရာခံသည်။
///
/// အဆုံး၌၊ `Arc<T>` ကိုပုံမှန်အားဖြင့် X0 [`std::sync`] အမျိုးအစားနှင့်ပုံမှန်အားဖြင့် [`Mutex<T>`][mutex] နှင့်တွဲရန်လိုအပ်သည်ဟုဆိုလိုသည်။
///
/// ## `Weak` နှင့်အတူသံသရာကိုချိုးဖောက်
///
/// [`downgrade`][downgrade] နည်းလမ်းသည်ပိုင်ဆိုင်မှုမရှိသော [`Weak`] pointer ကိုဖန်တီးရန်အသုံးပြုနိုင်သည်။[`Weak`] pointer သည် [`upgrade`][upgrade] d ကို `Arc` သို့ပြောင်းနိုင်သည်။ သို့သော် အကယ်၍ ခွဲဝေထားသည့်သိုလှောင်ထားသောတန်ဖိုးကိုကျဆင်းသွားပါက၎င်းသည် [`None`] ကိုပြန်ပေးလိမ့်မည်။
/// တနည်းအားဖြင့် `Weak` ထောက်ပြသူများသည်ခွဲဝေချထားမှုအတွင်းရှိတန်ဖိုးကိုအသက်မရှင်နိုင်ကြပါ။သို့သော်၎င်းတို့သည်ခွဲဝေခြင်း (တန်ဖိုးအတွက်ကျောထောက်နောက်ခံပြုထားသောစတိုးဆိုင်) ကိုရှင်သန်နေစေသည်။
///
/// `Arc` ထောက်ပြသူများအကြားသံသရာတစ်ခုကိုဘယ်တော့မှဖယ်ရှား။ မရပါ။
/// ဤအကြောင်းကြောင့်, [`Weak`] သံသရာကိုချိုးဖျက်ဖို့အသုံးပြုသည်။ဥပမာအားဖြင့်သစ်ပင်တစ်ပင်တွင်မိဘဆုံမှတ်များမှကလေးများအထိခိုင်မာသည့် `Arc` ညွှန်ပြချက်များရှိနိုင်သည်။ ကလေးများမှ [`Weak`] အမှတ်အသားများသည်မိဘများထံပြန်လာနိုင်သည်။
///
/// # ကိုးကားပွားခြင်း
///
/// ရှိပြီးသားရည်ညွှန်းရေတွက် pointer မှရည်ညွှန်းချက်အသစ်တစ်ခုကိုဖန်တီးရန် X0 [`Arc<T>`][Arc] နှင့် [`Weak<T>`][Weak] အတွက်အကောင်အထည်ဖော်ခဲ့သော `Clone` trait ကိုအသုံးပြုသည်။
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // အောက်က syntaxes နှစ်ခုဟာညီမျှတယ်။
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b နှင့် foo အားလုံးသည်တူညီသောမှတ်ဉာဏ်တည်နေရာကိုညွှန်ပြသော Arcs များဖြစ်သည်
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` `T` ([`Deref`][deref] trait မှတဆင့်) ကိုအလိုအလျောက် dereferences, သင်သည် `Arc<T>` အမျိုးအစားတန်ဖိုးရှိ `T` ၏နည်းလမ်းများကိုခေါ်နိုင်သည်။`T` နည်းလမ်းများနှင့်အမည်တိုက်မှုဖြစ်ပွားခြင်းမှကာကွယ်ရန် `Arc<T>` ၏နည်းလမ်းများသည်ဆက်နွယ်သောလုပ်ဆောင်မှုများဖြစ်သည်။ ၎င်းကို [fully qualified syntax] ကိုသုံးသည်။
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>`Clone` ကဲ့သို့`traits ၏အကောင်အထည်ဖော်မှုများကိုအပြည့်အဝအရည်အချင်းပြည့်မီသော syntax သုံး၍ ခေါ်နိုင်သည်။
/// အချို့လူများကအပြည့်အဝအရည်အချင်းပြည့်မီသော syntax ကိုသုံးရန်ပိုနှစ်သက်ကြပြီးအချို့ကမူ method-call syntax ကိုပိုနှစ်သက်ကြသည်။
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Method ကို-ခေါ်ဆိုခ syntax
/// let arc2 = arc.clone();
/// // အပြည့်အဝအရည်အချင်းပြည့် syntax
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] အတွင်းတန်ဖိုးကိုပြီးသားကျဆင်းသွားခဲ့ကြပေမည်ဖြစ်သောကြောင့်, `T` မှ auto-dereference မထားဘူး။
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// မပြောင်းလဲနိုင်သောအရာများကိုချည်များအကြားမျှဝေခြင်း
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// သတိပြုရမည်မှာကျွန်ုပ်တို့ ** သည်ဤစမ်းသပ်မှုများကိုဤနေရာတွင်မလုပ်သည်ကိုသတိပြုပါ။
// windows တည်ဆောက်သူများသည်ချည်သည်အဓိကချည်ထက်ကျော်လွန်ပြီးတစ်ချိန်တည်း (ပိတ်ဆို့မှုများ) မှထွက်သွားပါကအလွန်စိတ်မကောင်းဖြစ်မည်ဖြစ်သောကြောင့်ကျွန်ုပ်တို့သည်ဤစမ်းသပ်မှုများကိုမလုပ်ဆောင်ခြင်းအားဖြင့်ဤအရာကိုလုံး ၀ ရှောင်ရှားနိုင်သည်။
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// mutable [`AtomicUsize`] ကိုမျှဝေခြင်း
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// ယေဘုယျအားဖြင့်ရည်ညွှန်းရေတွက်ခြင်းနမူနာများကို [`rc` documentation][rc_examples] တွင်ကြည့်ပါ။
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` [`Arc`] ၏ဗားရှင်းသည်ပိုင်ဆိုင်မှုမရှိသောရည်ညွှန်းမှုအားစီမံခန့်ခွဲထားသောခွဲဝေမှုကိုရည်ညွှန်းသည်။
/// ခွဲဝေချထားပေးခြင်းကို `Weak` pointer ပေါ်ရှိ [`upgrade`] ကိုခေါ်ဆိုခြင်းအားဖြင့်၎င်း ```` ```` ```` ```` ```` ```` ```` ```` ```` ```` ```` ```သို့ပြန်သွားသည်။<T>>`။
///
/// `Weak` ရည်ညွှန်းမှုသည်ပိုင်ဆိုင်မှုနှင့်သက်ဆိုင်ခြင်းမရှိသောကြောင့်၎င်းသည်ခွဲဝေထားခြင်းတွင်သိမ်းဆည်းထားသောတန်ဖိုးကိုကျဆင်းခြင်းမှတားဆီးမည်မဟုတ်ပါ၊ `Weak` ကိုယ်တိုင်ရှိနေဆဲတန်ဖိုးနှင့် ပတ်သက်၍ အာမခံချက်မရှိပါ။
///
/// ထို့ကြောင့် [`upgrade`] when [`None`] သို့ပြန်လာနိုင်သည်။
/// သို့သော်သတိပြုပါက `Weak` ရည်ညွှန်းချက် * ခွဲဝေခြင်း (backing store) အားခွဲဝေချထားခြင်းကိုမတားဆီးကြောင်းသတိပြုပါ။
///
/// `Weak` pointer သည်၎င်းအတွင်းပိုင်းတန်ဖိုးကိုကျဆင်းခြင်းမှကာကွယ်ရန်မလိုဘဲ [`Arc`] မှစီမံခန့်ခွဲထားသောခွဲဝေမှုကိုယာယီရည်ညွှန်းထားခြင်းအတွက်အသုံးဝင်သည်။
/// နှစ် ဦး နှစ်ဖက်အပြန်အလှန်ပိုင်ဆိုင်သည့်ကိုးကားမှုများသည် [`Arc`] ကိုကျဆင်းစေရန်ဘယ်တော့မျှခွင့်ပြုမည်မဟုတ်သောကြောင့် [`Arc`] pointers များအကြား circular reference များကိုလည်းကာကွယ်ရန်အသုံးပြုသည်။
/// ဥပမာအားဖြင့်သစ်ပင်တစ်ပင်တွင်မိဘဆုံမှတ်များမှကလေးများအထိခိုင်မာသည့် [`Arc`] ညွှန်ပြချက်များနှင့်ကလေးများမှ `Weak` အမှတ်အသားများရှိနိုင်သည်။
///
/// `Weak` pointer ရရှိရန်ပုံမှန်နည်းလမ်းမှာ [`Arc::downgrade`] ကိုခေါ်ခြင်းဖြစ်သည်။
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // enums တွင်ဤအမျိုးအစား၏အရွယ်အစားကိုအကောင်းဆုံးခွင့်ပြုရန်ဤသည်မှာ `NonNull` ဖြစ်သည်။ သို့သော်၎င်းသည်ခိုင်လုံသော pointer မဟုတ်ပါ။
    //
    // `Weak::new` အမှိုက်ပုံပေါ်တွင်နေရာချစရာမလိုခြင်းကြောင့်၎င်းကို `usize::MAX` ဟုသတ်မှတ်သည်။
    // RcBox မှာအနည်းဆုံး ၂ နေရာသတ်မှတ်ထားလို့ဘာကြောင့်လဲဆိုတော့ဒါကတကယ့် pointer မှာရနိုင်မယ့်တန်ဖိုးမဟုတ်ဘူး။
    // `T: Sized` သာဤအရာသည်ဖြစ်နိုင်သည်;unsized `T` dangle ဘယ်တော့မှ။
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// ဤသည် repr(C) မှ future-proof ဖြစ်၍ ဖြစ်နိုင်သည့် field-reordering ကိုဆန့်ကျင်။ transmutable အတွင်းပိုင်းအမျိုးအစားများ၏ဘေးကင်းလုံခြုံသည့် [into|from]_raw() ကို ၀ င်ရောက်စွက်ဖက်နိုင်သည်။
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // တန်ဖိုး usize::MAX သည်ယာယီ "locking" အတွက်အားနည်းသောထောက်ပြသူများကိုအဆင့်မြှင့်တင်နိုင်ခြင်းသို့မဟုတ်အားကောင်းသောသူများကိုအဆင့်မြှင့်တင်ခြင်းအတွက်ကင်းစောင့်အဖြစ်ဆောင်ရွက်သည်။၎င်းသည် `make_mut` နှင့် `get_mut` ရှိလူမျိုးများကိုရှောင်ရှားရန်အသုံးပြုသည်။
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// အသစ်တစ်ခုကို `Arc<T>` တည်ဆောက်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // အားနည်းသော pointer count 1 ကိုစတင်ပါ။ အားကောင်းသော pointers အားလုံးကိုကိုင်ထားသည့်အားနည်းသော pointer ဖြစ်သည် (kinda) ကိုကြည့်ပါ။ std/rc.rs တွင်ကြည့်ပါ။
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// သူ့ဟာသူအားနည်းရည်ညွှန်းသုံးပြီး `Arc<T>` အသစ်တစ်ခုကိုတည်ဆောက်သည်။
    /// အားနည်းသောရည်ညွှန်းကိုဤ function ပြန်မရောက်မီအဆင့်မြှင့်တင်ရန်ကြိုးစားခြင်းသည် `None` တန်ဖိုးရရှိလိမ့်မည်။
    /// သို့သော်အားနည်းသောရည်ညွှန်းချက်ကိုလွတ်လပ်စွာပုံတူကူးယူပြီးနောက်ပိုင်းတွင်အသုံးပြုရန်သိမ်းဆည်းထားနိုင်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // အတွင်းပိုင်းတစ်ခုအားအားနည်းသောရည်ညွှန်းမှုတစ်ခုဖြင့်တည်ဆောက်ပါ။
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // အားနည်းသော pointer ၏ပိုင်ဆိုင်မှုကိုကျွန်ုပ်တို့မစွန့်လွှတ်ရန်အရေးကြီးသည်၊ သို့မဟုတ်ပါက `data_fn` ပြန်လာသည့်အချိန်တွင်ပင်မှတ်ဉာဏ်အားလွတ်မြောက်စေနိုင်သည်။
        // အကယ်၍ ကျွန်ုပ်တို့သည်ပိုင်ဆိုင်မှုကိုအမှန်တကယ်ပိုင်ဆိုင်လိုပါကမိမိကိုယ်ကိုအပိုဆောင်းအားနည်းသောညွှန်ကိန်းတစ်ခုဖန်တီးနိုင်သည်၊ သို့သော်၎င်းသည်အားနည်းနေသောရည်ညွှန်းအရေအတွက်အတွက်နောက်ထပ်မွမ်းမံမှုများဖြစ်ပေါ်စေလိမ့်မည်၊
        //
        //
        //
        //
        let data = data_fn(&weak);

        // ယခုကျွန်ုပ်တို့သည်အတွင်းပိုင်းတန်ဖိုးကိုစနစ်တကျအစပြုနိုင်ပြီးအားနည်းသောရည်ညွှန်းမှုကိုအားကောင်းသောရည်ညွှန်းချက်အဖြစ်သို့ပြောင်းလဲနိုင်သည်။
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // အထက်ဖော်ပြပါ data field သို့ရေးရန်အချက်အလက်သည်သုညမဟုတ်သည့်သုညအရေအတွက်ကိုစစ်ဆေးသောမည်သည့်ချည်မျှတွင်မမြင်နိုင်ပါ။
            // ထို့ကြောင့် `Weak::upgrade` ရှိ `compare_exchange_weak` နှင့်ထပ်တူပြုနိုင်ရန်အနည်းဆုံး "Release" မှာရန်လိုအပ်သည်။
            //
            // "Acquire" အမိန့်မလိုအပ်ပါ။
            // `data_fn` ၏ဖြစ်နိုင်ချေရှိသောအပြုအမူများကိုစဉ်းစားသောအခါကျွန်ုပ်တို့သည်အဆင့်မြှင့် တင်၍ မရသော `Weak` ကိုကိုးကားခြင်းဖြင့်၎င်းသည်ဘာလုပ်နိုင်သည်ကိုသာကြည့်ရှုရန်လိုအပ်သည်။
            //
            // - ၎င်းသည် `Weak` ကိုပွားနိုင်သည်၊ အားနည်းသောရည်ညွှန်းအရေအတွက်ကိုတိုးပွားစေသည်။
            // - ၎င်းသည် Clone များကိုဖယ်ရှားနိုင်သည်။ အားနည်းသောရည်ညွှန်းအရေအတွက်ကိုလျှော့ချနိုင်သည်။
            //
            // ဤဘေးထွက်ဆိုးကျိုးများသည်ကျွန်ုပ်တို့အားမည်သည့်နည်းနှင့်မျှမထိခိုက်စေပါ။ လုံခြုံသောကုဒ်တစ်ခုတည်းဖြင့်သာအခြားဘေးထွက်ဆိုးကျိုးများမဖြစ်နိုင်ပါ။
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // အားကောင်းသောရည်ညွှန်းချက်များသည်စုပေါင်းအားနည်းသောကိုးကားထားသောရည်ညွှန်းချက်တစ်ခုတည်းကိုပိုင်ဆိုင်သင့်သည်။ ထို့ကြောင့်ကျွန်ုပ်တို့၏အားနည်းသောရည်ညွှန်းမှုဟောင်းအတွက်ဖျက်ဆီးခြင်းကိုမ run ပါနှင့်
        //
        mem::forget(weak);
        strong
    }

    /// uninitialized contents တွေကိုနှင့်အတူအသစ်တစ်ခုကို `Arc` တည်ဆောက်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // ရွှေ့ဆိုင်းခြင်းစတင်ခြင်း
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// မှတ်ဉာဏ်သည် `0` bytes နှင့်ပြည့်နှက်လျက် Xinx အသစ်တစ်ခုကို uninitialized contents များဖြင့်တည်ဆောက်သည်။
    ///
    ///
    /// ဤနည်းလမ်း၏မှန်ကန်သောနှင့်မမှန်ကန်သောအသုံးပြုမှုဥပမာများအတွက် [`MaybeUninit::zeroed`][zeroed] ကိုကြည့်ပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// အသစ်တစ်ခုကို `Pin<Arc<T>>` တည်ဆောက်။
    /// အကယ်၍ `T` က `Unpin` ကိုအကောင်အထည်မဖော်ပါက၊ `data` သည်မှတ်ဉာဏ်ထဲ၌ရှိနေပြီးရွေ့ပြောင်း။ မရပါ။
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// ခွဲဝေမှုပျက်ကွက်လျှင်အမှားတစ်ခုပြန်လာ `Arc<T>` အသစ်တစ်ခုကိုတည်ဆောက်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // အားနည်းသော pointer count 1 ကိုစတင်ပါ။ အားကောင်းသော pointers အားလုံးကိုကိုင်ထားသည့်အားနည်းသော pointer ဖြစ်သည် (kinda) ကိုကြည့်ပါ။ std/rc.rs တွင်ကြည့်ပါ။
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// ခွဲဝေမှုပျက်ကွက်လျှင်အမှားတစ်ခုပြန်လာ, uninitialized အကြောင်းအရာများနှင့်အတူအသစ်တစ်ခုကို `Arc` တည်ဆောက်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // ရွှေ့ဆိုင်းခြင်းစတင်ခြင်း
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// ခွဲဝေမှုပျက်ကွက်လျှင်အမှားပြန်လာ, မှတ်ဉာဏ်ကို `0` bytes နှင့်ပြည့်နှက်လျက်ရှိသည်နှင့်အတူ, uninitialized အကြောင်းအရာများနှင့်အတူအသစ်တစ်ခုကို `Arc` တည်ဆောက်သည်။
    ///
    ///
    /// ဤနည်းလမ်း၏မှန်ကန်သောနှင့်မမှန်ကန်သောအသုံးပြုမှုဥပမာများအတွက် [`MaybeUninit::zeroed`][zeroed] ကိုကြည့်ပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// အကယ်၍ `Arc` တွင်အားကောင်းသောရည်ညွှန်းချက်တစ်ခုရှိခဲ့လျှင်အတွင်းတန်ဖိုးကိုပြန်သွားသည်။
    ///
    /// ဒီလိုမှမဟုတ်ရင် [`Err`] ကိုပြန်ပို့လိုက်တဲ့ `Arc` အတူတူပဲ။
    ///
    ///
    /// ညံ့ဖျင်းသောအားနည်းသောရည်ညွှန်းချက်များရှိသည့်တိုင်၎င်းသည်အောင်မြင်လိမ့်မည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // အဆိုပါသွယ်ဝိုက်အားကောင်း-အားနည်းရည်ညွှန်း clean up လုပ်ဖို့အားနည်း pointer လုပ်ပါ
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// uninitialized အကြောင်းအရာများနှင့်အတူအသစ်တစ်ခုကိုအနုမြူဗုံးရည်ညွှန်းရေတွက်အချပ်တည်ဆောက်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // ရွှေ့ဆိုင်းခြင်းစတင်ခြင်း
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// မှတ်ဉာဏ်သည် `0` bytes ဖြင့်ပြည့်နှက်နေပြီးအမည်မပါသောပါဝင်သည့်အရာများဖြင့်အက်တမ်အညွှန်းဖြင့်တွက်ချက်ထားသောအချပ်အသစ်တစ်ခုကိုတည်ဆောက်သည်။
    ///
    ///
    /// ဤနည်းလမ်း၏မှန်ကန်သောနှင့်မမှန်ကန်သောအသုံးပြုမှုဥပမာများအတွက် [`MaybeUninit::zeroed`][zeroed] ကိုကြည့်ပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// `Arc<T>` သို့ပြောင်းသည်
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] ကဲ့သို့ပင်အတွင်းတန်ဖိုးသည်ပကတိအခြေအနေ၌ရှိကြောင်းအာမခံရန်ခေါ်ဆိုသူအပေါ်မူတည်သည်။
    ///
    /// အကြောင်းအရာကိုအပြည့်အဝအစပြုခြင်းမရှိသေးသောအချိန်တွင်ဤအရာကိုခေါ်ဆိုခြင်းအားချက်ချင်းသတ်မှတ်ထားသောအပြုအမူကိုဖြစ်ပေါ်စေသည်။
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // ရွှေ့ဆိုင်းခြင်းစတင်ခြင်း
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// `Arc<[T]>` သို့ပြောင်းသည်
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] ကဲ့သို့ပင်အတွင်းတန်ဖိုးသည်ပကတိအခြေအနေ၌ရှိကြောင်းအာမခံရန်ခေါ်ဆိုသူအပေါ်မူတည်သည်။
    ///
    /// အကြောင်းအရာကိုအပြည့်အဝအစပြုခြင်းမရှိသေးသောအချိန်တွင်ဤအရာကိုခေါ်ဆိုခြင်းအားချက်ချင်းသတ်မှတ်ထားသောအပြုအမူကိုဖြစ်ပေါ်စေသည်။
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // ရွှေ့ဆိုင်းခြင်းစတင်ခြင်း
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// `Arc` ကိုအသုံးပြုသည်။
    ///
    /// မှတ်ဥာဏ်ယိုစိမ့်မှုမဖြစ်စေရန် pointer ကို [`Arc::from_raw`] သုံး၍ `Arc` သို့ပြန်ပြောင်းရမည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// ဒေတာတစ်ခု raw pointer ပေးသည်။
    ///
    /// ရေတွက်ခြင်းကိုမည်သည့်နည်းနှင့်မျှမထိခိုက်ပါ၊ `Arc` ကိုမစားပါ။
    /// `Arc` တွင်ခိုင်မာသောအရေအတွက်ရှိသရွေ့ pointer သည်တရားဝင်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // လုံခြုံမှု-ဤသည်မှာ Deref::deref သို့မဟုတ် RcBoxPtr::inner ကို ဖြတ်၍ မသွားနိုင်ပါ
        // ဤကဲ့သို့သောဥပမာသည် raw/mut သက်သေပြမှုကိုထိန်းသိမ်းရန်လိုအပ်သည်
        // `get_mut` အဆိုပါ Rc `from_raw` မှတဆင့်ပြန်လည်ကောင်းမွန်ပြီးနောက် pointer မှတဆင့်ရေးသားနိုင်ပါတယ်။
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// တစ်ဦး `Arc<T>` တစ်ကုန်ကြမ်း pointer ကနေ Constructs ။
    ///
    /// `U` သည် `T` ကဲ့သို့တူညီသောအရွယ်အစားနှင့်ညှိနှိုင်းမှုရှိရမည်။
    /// `U` `T` ဖြစ်ပါကဤအချက်သည်အသေးအဖွဲဖြစ်သည်။
    /// အကယ်၍ `U` သည် `T` မဟုတ်သော်လည်းအရွယ်အစားနှင့်တူညီစွာရှိလျှင်၎င်းသည်အခြေခံအားဖြင့်မတူကွဲပြားသောအမျိုးအစားများကိုကိုးကားခြင်းနှင့်တူသည်ကိုသတိပြုပါ။
    /// ဤကိစ္စတွင်မည်သည့်ကန့်သတ်ချက်များနှင့်သက်ဆိုင်သည်ကိုပိုမိုသိရှိလိုပါက [`mem::transmute`][transmute] တွင်ကြည့်ပါ။
    ///
    /// `from_raw` ၏အသုံးပြုသူသည် `T` ၏သတ်သတ်မှတ်မှတ်တန်ဖိုးတစ်ချိန်ကကျဆင်းသွားသည်ကိုသေချာအောင်ပြုလုပ်ရမည်။
    ///
    /// အဘယ်ကြောင့်ဆိုသော်မသင့်လျော်သောအသုံးပြုမှုသည်ပြန်လာသော `Arc<T>` သည်ဘယ်သောအခါမျှ ၀ င်ရောက်ခြင်းမရှိသော်လည်း၊
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // ယိုစိမ့်မှုကိုကာကွယ်ရန် `Arc` သို့ပြန်ပြောင်းပါ။
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Arc::from_raw(x_ptr)` သို့နောက်ထပ်ဖုန်းခေါ်ဆိုမှုများသည်မှတ်ဉာဏ်မကင်းပါ။
    /// }
    ///
    /// // အထက်တွင်ဖော်ပြထားသောအတိုင်း `x` ထွက်သွားသည့်အခါမှတ်ဥာဏ်သည်လွတ်မြောက်သွားပြီဖြစ်ရာယခုအခါ `x_ptr` သည် dangling!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // မူလ ArcInner ကိုရှာရန် offset ကိုပြောင်းပါ။
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// ဒီခွဲဝေမှုမှအသစ်တစ်ခုကို [`Weak`] pointer ကိုဖန်တီးပေးပါတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // အောက်တွင်ဖော်ပြထားသော CAS ၌ကျွန်ုပ်တို့တန်ဖိုးကိုစစ်ဆေးသောကြောင့်ဤ Relaxed သည် OK ဖြစ်သည်။
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // အားနည်းကောင်တာလက်ရှိ "locked" ဟုတ်မဟုတ်စစ်ဆေးပါ;ရှိလျှင်လည်ပါ။
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: ယခုကုဒ်သည်လျတ်ဖြစ်နိုင်ခြေကိုလျစ်လျူရှုထားသည်
            // usize::MAX သို့;ယေဘုယျအားဖြင့် Rc နှင့် Arc နှစ်ခုလုံးသည် overflow ကိုဖြေရှင်းရန်ချိန်ညှိရန်လိုအပ်သည်။
            //

            // Clone() နှင့်မတူသည်မှာ၎င်းသည် `is_unique` မှလာသည့်အရေးအသားနှင့်တစ်ပြိုင်တည်းဖြစ်အောင် Acquire ဖတ်ရန်လိုအပ်သည်။ သို့မှသာထိုမတိုင်မီဖြစ်ရပ်များသည်ဤမဖတ်မီဖြစ်ပျက်လိမ့်မည်။
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // ကျွန်တော်တို့ဟာ dangling အားနည်းချက်ကိုမဖန်တီးဘူးသေချာအောင်လုပ်ပါ
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// ဒီခွဲဝေမှုမှ [`Weak`] ထောက်ပြ၏နံပါတ်ရရှိသည်။
    ///
    /// # Safety
    ///
    /// ဤနည်းလမ်းသည်သူ့ဟာသူလုံခြုံသည်၊ သို့သော်မှန်ကန်စွာအသုံးပြုရန်မှာအပိုဂရုစိုက်ရန်လိုအပ်သည်။
    /// နောက်ထပ်ချည်တစ်မျိုးသည်မည်သည့်အချိန်တွင်မဆိုဤနည်းကိုခေါ်ဆိုခြင်းနှင့်ရလဒ်အပေါ်ပြုခြင်းတို့အပါအဝင်အားနည်းချက်ကိုပြောင်းလဲနိုင်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // ကျွန်ုပ်တို့သည် `Arc` သို့မဟုတ် `Weak` ကို Thread များအကြားမျှဝေခြင်းမရှိသောကြောင့်ဤအခိုင်အမာဆုံးဖြတ်ချက်သည်မှန်ကန်သည်။
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // အားနည်းသောအရေအတွက်ကိုလက်ရှိသော့ခတ်ထားလျှင်၊ ရေတွက်ခြင်း၏တန်ဖိုးသည်သော့ခတ်ခြင်းမပြုမီလေးတွင်ရှိသည်။
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// ဒီခွဲဝေရန်ခိုင်မာတဲ့ (`Arc`) ထောက်ပြ၏နံပါတ်ရရှိသည်။
    ///
    /// # Safety
    ///
    /// ဤနည်းလမ်းသည်သူ့ဟာသူလုံခြုံသည်၊ သို့သော်မှန်ကန်စွာအသုံးပြုရန်မှာအပိုဂရုစိုက်ရန်လိုအပ်သည်။
    /// အခြားချည်တစ်မျိုးသည်ဤနည်းလမ်းကိုခေါ်ဆိုခြင်းနှင့်ရလဒ်အပေါ်လုပ်ဆောင်ခြင်းတို့အပါအ ၀ င်မည်သည့်အချိန်တွင်မဆိုအားကြီးသောအရေအတွက်ကိုပြောင်းလဲနိုင်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // `Arc` ကို Thread များအကြားမျှဝေခြင်းမရှိသောကြောင့်ဤအခိုင်အမာဆုံးဖြတ်ချက်သည်ဆုံးဖြတ်ချက်ဖြစ်သည်။
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// တ ဦး တည်းအားဖြင့်ထောက်ပံ့ pointer နှင့်ဆက်စပ်သည့် `Arc<T>` အပေါ်ခိုင်မာတဲ့ရည်ညွှန်းအရေအတွက်တိုးပွားစေပါသည်။
    ///
    /// # Safety
    ///
    /// pointer သည် `Arc::into_raw` မှရရှိပြီးဖြစ်လိမ့်မည်။ ၎င်းနှင့်ဆက်စပ်သော `Arc` ဥပမာသည်မှန်ကန်ရမည်
    /// ခိုင်မာတဲ့အရေအတွက်ကဒီနည်းလမ်း၏ကြာချိန်များအတွက်အနည်းဆုံး 1 ဖြစ်ရပါမည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // `Arc` ကို Thread များအကြားမျှဝေခြင်းမရှိသောကြောင့်ဤအခိုင်အမာဆုံးဖြတ်ချက်သည်ဆုံးဖြတ်ချက်ဖြစ်သည်။
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Arc ကိုထိန်းသိမ်းပါ၊ ဒါပေမယ့် ManuallyDrop ထဲမှာ wrapping ဖြင့် refcount မထိပါနဲ့
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // refcount ကိုတိုးမြှင့်ပါ
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// တ ဦး တည်းအားဖြင့်ထောက်ပံ့ pointer နှင့်ဆက်စပ်သော `Arc<T>` အပေါ်ခိုင်မာတဲ့ရည်ညွှန်းရေတွက်လျှော့ချ။
    ///
    /// # Safety
    ///
    /// pointer သည် `Arc::into_raw` မှရရှိပြီးဖြစ်လိမ့်မည်။ ၎င်းနှင့်ဆက်စပ်သော `Arc` ဥပမာသည်မှန်ကန်ရမည်
    /// ဒီနည်းလမ်းကိုသွန်းလောင်းသည့်အခါအားကောင်းတဲ့ရေတွက်အနည်းဆုံး 1) ဖြစ်ရမည်။
    /// ဤနည်းလမ်းကိုနောက်ဆုံး `Arc` နှင့်ကျောထောက်နောက်ခံသိုလှောင်မှုကိုလွှတ်ပေးရန်အသုံးပြုနိုင်သည်။ သို့သော် **`Arc` ကိုလွှတ်ပြီးနောက်တွင်**** ခေါ်ဆိုခြင်းကိုမပြုလုပ်သင့်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // ကျွန်ုပ်တို့သည် `Arc` ကို Thread များအကြားမျှဝေခြင်းမရှိသောကြောင့်ထိုအခိုင်အမာပြောဆိုချက်များသည်အဆုံးအဖြတ်ပေးသည်။
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // ဒီ arc သည်အသက်ရှင်နေစဉ်အတွင်းပိုင်း pointer သည်မှန်ကန်ကြောင်းအာမခံသည်။
        // ထို့အပြင် `ArcInner` ဖွဲ့စည်းပုံကိုယ်နှိုက်က `Sync` ဖြစ်သည်ကိုကျွန်ုပ်တို့သိသည်၊ အဘယ်ကြောင့်ဆိုသော်အတွင်းပိုင်းဒေတာမှာ `Sync` ဖြစ်သဖြင့်၎င်းအကြောင်းအရာများကိုမပြောင်းလဲနိုင်သောအချက်တစ်ခုဖြစ်သည်။
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // `drop` ၏ non-inlined တစ်စိတ်တစ်ပိုင်း။
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // ကျွန်ုပ်တို့သည် box ခွဲဝေချထားမှုကိုသူ့ဟာသူလွတ်လွတ်လပ်လပ်မလုပ်နိုင်သော်လည်းဤအချိန်တွင်ဒေတာများကိုဖျက်ဆီးပါ (ပတ်ပတ်လည်တွင်အားနည်းနေသည့်ထောက်ပြသူများရှိနေနိုင်သည်) ။
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // အားလုံးအားကောင်းတဲ့ကိုးကားခြင်းအားဖြင့်ကျင်းပအားနည်းနေ ref drop
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Arc `နှစ်ခုသည်တစ်ခုနှင့်တစ်ခုထပ်ခွဲဝေမှုကိုညွှန်ပြနေလျှင် `true` ကိုပြန်သွားသည် ([`ptr::eq`] နှင့်ဆင်တူသည့်သွေးပြန်ကြောတွင်) ။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// `ArcInner<T>` တစ်ခုသည်တန်ဖိုးကိုသတ်မှတ်ထားသည့်အတွင်းတန်ဖိုးအတွက်နေရာအလုံအလောက်ရှိရန်နေရာချသည်။
    ///
    /// `mem_to_arcinner` function ကို data pointer ဖြင့်ခေါ်။ `ArcInner<T>` အတွက် (ဖြစ်နိုင်ခြေရှိသောအဆီ)-pointer ကိုပြန်ပေးရမည်။
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // ပေးထားတဲ့ value layout ကိုအသုံးပြုပြီး layout ကိုတွက်ချက်ပါ။
        // ယခင်က layout ကို `&*(ptr as* const ArcInner<T>)` ဟူသောအသုံးအနှုနျးအတိုငျးတွက်ခဲ့တယျ၊
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// `ArcInner<T>` တစ်ခုသည်တန်ဖိုးတစ်ခုစီမထားသည့်အတွင်းတန်ဖိုးအတွက်လုံလောက်သောနေရာရှိရန်နေရာချထားသည်။ ၎င်းသည်တန်ဖိုးအရစီစဉ်ထားသည့်နေရာရှိသည်၊ ခွဲဝေမှုမအောင်မြင်ပါကအမှားတစ်ခုကိုပြန်ပေးသည်။
    ///
    ///
    /// `mem_to_arcinner` function ကို data pointer ဖြင့်ခေါ်။ `ArcInner<T>` အတွက် (ဖြစ်နိုင်ခြေရှိသောအဆီ)-pointer ကိုပြန်ပေးရမည်။
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // ပေးထားတဲ့ value layout ကိုအသုံးပြုပြီး layout ကိုတွက်ချက်ပါ။
        // ယခင်က layout ကို `&*(ptr as* const ArcInner<T>)` ဟူသောအသုံးအနှုနျးအတိုငျးတွက်ခဲ့တယျ၊
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // ArcInner ကိုအစပြုပါ
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// တစ် ဦး unsized အတွင်းစိတ်တန်ဖိုးကိုများအတွက်လုံလောက်သောအာကာသနှင့်အတူတစ် ဦး `ArcInner<T>` ချထားသည်။
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // ပေးထားသောတန်ဖိုးကို အသုံးပြု၍ `ArcInner<T>` အတွက်ခွဲဝေချထားပါ။
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // တန်ဖိုးကို bytes အဖြစ်ကူးယူပါ
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // ၎င်း၏ contents တွေကိုကျဆင်းနေစရာမလိုဘဲခွဲဝေချထားပေးရန်
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// ပေးထားသောအရှည်နှင့်အတူ `ArcInner<[T]>` ခွဲဝေချထားပေးရန်။
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// အသစ်ချထားလိုက်သော Arc သို့အချပ်မှ element များကိုကူးယူပါ
    ///
    /// အန္တရာယ်မကင်းသောကြောင့်ခေါ်ဆိုသူ၏ပိုင်ဆိုင်မှုကိုယူရမည်သို့မဟုတ် `T: Copy` ကိုချည်ရမည်။
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// အချို့သောအရွယ်အစားဟုလူသိများသောကြားမှာမှ `Arc<[T]>` တစ်ခုတည်ဆောက်သည်။
    ///
    /// အရွယ်အစားမှားယွင်းပါကအပြုအမူအားသတ်မှတ်ခြင်းမပြုပါ။
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // T ကိုဒြပ်စင်ပုံတူပွားစဉ် Panic ကိုယ်ရံတော်။
        // panic တစ်ခုဖြစ်ပေါ်ပါက ArcInner အသစ်ထဲသို့ရေးထည့်လိုက်သောဒြပ်စင်များကိုဖယ်ထုတ်ပြီးမှတ်ဉာဏ်လွတ်လိမ့်မည်။
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // ပထမ ဦး ဆုံးဒြပ်စင်မှညွှန်ပြ
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // အားလုံးရှင်းတယ်။ကိုယ်ရံတော်ကိုမေ့လိုက်တော့ ArcInner အသစ်ကိုမလွတ်ပေးတော့ဘူး။
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` အတွက်အထူးပြု trait အထူးပြု။
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// `Arc` pointer ၏ကိုယ်ပွားကိုပြုလုပ်သည်။
    ///
    /// ၎င်းသည်ရည်ညွှန်းမှုအရေအတွက်အားတိုးမြှင့်ခြင်းအားဖြင့်တူညီသောခွဲဝေမှုအတွက်အခြားသောညွန်ကိန်းကိုဖန်တီးပေးသည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // အများအားဖြင့်သက်တောင့်သက်သာရှိသောအစီအစဉ်များကိုအသုံးပြုခြင်းသည်ဤနေရာတွင်အဆင်ပြေပါသည်။ မူလရည်ညွှန်းချက်နှင့်ပတ်သက်သောအသိပညာသည်အခြားအရာ ၀ တ္ထုအားအရာဝတ္ထုကိုဖျက်ပစ်ခြင်းမှကာကွယ်ပေးသည်။
        //
        // [Boost documentation][1] တွင်ရှင်းပြထားသည့်အတိုင်း၊ ရည်ညွှန်းကောင်တာကိုတိုးမြှင့်ခြင်းသည် memory_order_relaxed နှင့်အမြဲတမ်းလုပ်ဆောင်နိုင်သည်။ အရာဝတ္ထုတစ်ခုအတွက်ရည်ညွှန်းမှုအသစ်များကိုရှိပြီးသားရည်ညွှန်းချက်မှသာဖွဲ့စည်းနိုင်သည်၊ ရှိပြီးသားရည်ညွှန်းချက်တစ်ခုအားအခြားတစ်ခုသို့အခြားတစ်ခုသို့ကူးပြောင်းခြင်းသည်လိုအပ်သောထပ်တူပြုမှုကိုပေးရမည်။
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // သို့သော်တစ်စုံတစ် ဦး က `mem: : forget`ing Arcs ဖြစ်ခဲ့လျှင်အကြီးအကျယ်ပြန်လည်ရေတွက်ခြင်းမှကျွန်ုပ်တို့သတိထားရမည်။
        // ကျွန်ုပ်တို့ဤသို့မပြုလုပ်ပါကအရေအတွက်သည်အလွန်များပြားပြီးသုံးစွဲသူများသည်အခမဲ့သုံးစွဲပြီးနောက်အသုံးပြုနိုင်မည်ဖြစ်သည်။
        // ရည်ညွှန်းအရေအတွက်ကိုတစ်ပြိုင်နက်တိုးပွားစေသည့် ~2 ဘီလီယံမျှမျှမရှိသည်ဟူသောယူဆချက်ကိုကျွန်ုပ်တို့သည် `isize::MAX` ကိုအလွန်အမင်းစိတ်ကျေနပ်စေသည်။
        //
        // ဤ branch သည်မည်သည့်လက်တွေ့အစီအစဉ်တွင်မဆိုဘယ်တော့မှပါလိမ့်မည်မဟုတ်ပါ။
        //
        // ထိုကဲ့သို့သော program တစ်ခုမယုံနိုင်လောက်အောင်သမ္မတကတော်ကြောင့်ကျနော်တို့ abort နှင့်ကျွန်တော်ကိုထောကျပံ့ဖို့ဂရုမစိုက်ပါဘူး။
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// ပေးထားသော `Arc` သို့ mutable ရည်ညွှန်းသည်။
    ///
    /// အကယ်၍ အခြား `Arc` သို့မဟုတ် [`Weak`] အမှတ်အသားများသည်တူညီသောခွဲဝေထားမှုရှိပါက `make_mut` သည်ခွဲဝေမှုအသစ်တစ်ခုကိုဖန်တီးပြီးအတွင်းတန်ဖိုးမှ [`clone`][clone] ကိုထူးခြားသောပိုင်ဆိုင်မှုသေချာစေရန်ပြုလုပ်လိမ့်မည်။
    /// ၎င်းကို Clone-on-write အဖြစ်ရည်ညွှန်းသည်။
    ///
    /// ဤသည် `Weak` ၏ကျန်ရှိနေသေးသောမည်သည့် `Weak` ထောက်ပြမှုနှင့်မဆိုကွဲပြားသည်။
    ///
    /// [`get_mut`][get_mut] ကိုလည်းရှုပါ။
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // ဘာမှမကူးတော့ပါ
    /// let mut other_data = Arc::clone(&data); // အတွင်းပိုင်းဒေတာကိုပုံတူပွား။ မရပါ
    /// *Arc::make_mut(&mut data) += 1;         // အတွင်းပိုင်းဒေတာ Clone
    /// *Arc::make_mut(&mut data) += 1;         // ဘာမှမကူးတော့ပါ
    /// *Arc::make_mut(&mut other_data) *= 2;   // ဘာမှမကူးတော့ပါ
    ///
    /// // ယခု `data` နှင့် `other_data` သည်ကွဲပြားသောခွဲဝေချထားမှုများကိုညွှန်ပြသည်။
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // ကျနော်တို့အားကောင်းတဲ့ရည်ညွှန်းနှင့်အားနည်းရည်ညွှန်းနှစ် ဦး စလုံးကိုင်ထားသတိပြုပါ။
        // ထို့ကြောင့်ကျွန်ုပ်တို့၏ခိုင်မာသောရည်ညွှန်းချက်ကိုသာထုတ်ပြန်ခြင်းသည်မှတ်ဉာဏ်ကိုဖယ်ရှားပစ်မည်မဟုတ်ပါ။
        //
        // `weak` သို့မလွှတ်မီရေးသားမှု (ဆိုလိုသည်မှာအထွ)်အထိပ်) မတိုင်မီဖြစ်ပျက်ခဲ့သော `weak` သို့မည်သည့်ရေးသားမှုမျိုးကိုမဆိုတွေ့မြင်ရန် Acquire ကိုအသုံးပြုပါ။
        // ကျွန်တော်တို့အားနည်းနေတဲ့အတွက် ArcInner ကိုယ်တိုင်ဖယ်ရှားပစ်ဖို့အခွင့်အရေးမရှိပါဘူး။
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // နောက်ထပ်အားကောင်းသောညွှန်းကိန်းရှိသည်။
            // ပုံတူပွားထားသည့်တန်ဖိုးကိုတိုက်ရိုက်ရေးသားရန်အတွက်မှတ်ဉာဏ်ကိုကြိုတင်ခွဲထားပါ။
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // ဤအချက်သည်အခြေခံကျကျအကောင်းဆုံးဖြစ်သောကြောင့်ကျွန်ုပ်တို့အနေဖြင့်အားနည်းချက်များကိုထောက်ပြခြင်းနှင့်အမြဲယှဉ်ပြိုင်နေသည်။
            // အဆိုးဆုံးကတော့ကျွန်တော်တို့ Arc ကိုမလိုအပ်ဘဲခွဲဝေချထားပေးလိုက်ပါတယ်။
            //

            // ကျနော်တို့နောက်ဆုံးအားကောင်း ref ကိုဖယ်ရှား, ဒါပေမယ့်နောက်ထပ်အားနည်း refs ကျန်ရှိသောရှိပါတယ်။
            // ကျနော်တို့ contents တွေကိုအသစ်တစ်ခုကို Arc သို့ရွှေ့နှင့်အခြားအားနည်း refs invalidate ပါလိမ့်မယ်။
            //

            // သတိပြုရန်မှာ `weak` ၏ဖတ်ခြင်းသည် usize::MAX (ဆိုလိုသည်မှာသော့ခတ်ထားခြင်း) ကိုလိုက်လျောရန်မဖြစ်နိုင်ပါ။ အကြောင်းမှာအားနည်းသောအရေအတွက်ကိုအားကောင်းသောရည်ညွှန်းထားသောချည်ဖြင့်သာသော့ခတ်နိုင်ခြင်းကြောင့်ဖြစ်သည်။
            //
            //

            // ကျွန်ုပ်တို့၏ကိုယ်ပိုင်သွယ်ဝိုက်အားနည်းသော pointer ကိုလက်တွေ့အကောင်အထည်ဖော်ပါ။ သို့မှသာ ArcInner ကိုလိုအပ်သလိုသန့်ရှင်းနိုင်သည်။
            //
            let _weak = Weak { ptr: this.ptr };

            // အချက်အလက်များကိုခိုးယူရုံသာမက၊
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // ကျနော်တို့တစ်ခုခုကိုတစ် ဦး တည်းသောရည်ညွှန်းကြ၏ခိုင်ခံ့ ref ရေတွက်တက်ထု။
            //
            this.inner().strong.store(1, Release);
        }

        // `get_mut()` နှင့်အတူသကဲ့သို့, unsafety ကျွန်တော်တို့ရဲ့ရည်ညွှန်းနှင့်အတူစတင်ဖြစ်စေထူးခြားသောကြောင့် ok ဖြစ်ပါသည်, ဒါမှမဟုတ် contents တွေကိုပုံတူပွားခြင်းအပေါ်မှာတယောက်ဖြစ်လာခဲ့သည်။
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// တူညီသောခွဲဝေရန်မပါအခြား `Arc` သို့မဟုတ် [`Weak`] ထောက်ပြသူများမရှိပါကပေးထားသော `Arc` သို့ပြောင်းလဲနိုင်သောရည်ညွှန်းချက်ကိုပြန်ပို့သည်။
    ///
    ///
    /// မဟုတ်ရင် [`None`] ကို return ပြန်ပေးတယ်။
    ///
    /// [`make_mut`][make_mut] ကိုလည်းကြည့်ပါ။ ၎င်းသည်အခြားအညွှန်းများရှိပါကအတွင်းတန်ဖိုးကို [`clone`][clone] ဖြစ်လိမ့်မည်။
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // ဤလုံခြုံမှုမရှိခြင်းသည်အဆင်ပြေပါသည်။ အဘယ်ကြောင့်ဆိုသော်ကျွန်ုပ်တို့ပြန်လာသည့် pointer သည် T. သို့ပြန်သွားပါမည်။
            // ကျွန်ုပ်တို့၏ရည်ညွှန်းအရေအတွက်သည်ယခုအချိန်တွင် ၁ ဖြစ်ကြောင်းအာမခံနိုင်ပြီး Arc ကိုယ်တိုင်သည် `mut` ဖြစ်ရန်လိုအပ်သည်၊ ထို့ကြောင့်ကျွန်ုပ်တို့သည်အတွင်းပိုင်းဒေတာသို့တစ်ခုတည်းသောဖြစ်နိုင်သည့်ရည်ညွှန်းမှုကိုပြန်ပို့နေခြင်းဖြစ်သည်။
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// မည်သည့်စစ်ဆေးမှုမှမပါဘဲပေးထားသော `Arc` သို့ပြောင်းလဲနိုင်သောရည်ညွှန်းချက်ကိုပြန်ပို့သည်။
    ///
    /// [`get_mut`] ကိုလည်းရှုပါ။
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// တူညီသောခွဲဝေဖို့အခြားမည်သည့် `Arc` သို့မဟုတ် [`Weak`] ထောက်ပြပြန်လာသောချေး၏ကြာချိန်အဘို့အ dereferenced မပြုရပါ။
    ///
    /// ဥပမာ-`Arc::new` ပြီးနောက်ချက်ချင်းဆိုလျှင်ထိုကဲ့သို့သောညွှန်ကြားချက်များမရှိပါကဤအချက်သည်အသေးအဖွဲကိစ္စဖြစ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // ကျနော်တို့ကိုကိုးကားရေတွက်ဖို့တစ်ပြိုင်တည်းပါ access ကို (ဥပမာနှင့်အတူဤလို alias ကိုအဖြစ်,* * အ "count" လယ်ကွင်းဖုံးအုပ်တစ်ဦးကိုကိုးကားဖန်တီးမသတိပြု
        // `Weak` အားဖြင့်) ။
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// ၎င်းသည်အခြေခံအချက်အလက်များ၏ (အားနည်းသော refs များအပါအ ၀ င်) ထူးခြားသောရည်ညွှန်းမှုဟုတ်မဟုတ်ဆုံးဖြတ်ပါ။
    ///
    ///
    /// ဒီအားနည်း ref ref ကိုသော့ခတ်ရန်လိုအပ်သည်သတိပြုပါ။
    fn is_unique(&mut self) -> bool {
        // ကျွန်တော်တစ် ဦး တည်းသောအားနည်း pointer ကိုင်ဆောင်သူဖြစ်ပေါ်လာလျှင်အားနည်း pointer count ကသော့ခတ်။
        //
        // ဤနေရာတွင်သိမ်းဆည်းထားသောတံဆိပ်သည် `strong` (အထူးသဖြင့် `Weak::upgrade`) တွင်မည်သည့်ရေးသားချက်များနှင့်မဆိုဆက်သွယ်မှုကိုသေချာစေရန် (`Weak::drop` မှတစ်ဆင့်ထုတ်ပေးသော) `weak` အရေအတွက်လျှော့ချနိုင်သည်။
        // အဆင့်မြှင့်တင်ထားသောအားနည်းသော ref ကိုဘယ်တော့မှမစွန့်ပါကဤနေရာတွင် CAS ကျရှုံးလိမ့်မည်။ ထို့ကြောင့်ကျွန်ုပ်တို့သည်ထပ်တူပြုရန်ဂရုမစိုက်ပါ။
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // ဤသည်မှာ X0 `drop` ရှိ `strong` ကောင်တာ၏နိမ့်ကျမှုနှင့်အတူတစ်ပြိုင်တည်းချိန်ကိုက်ရန် `Acquire` တစ်ခုဖြစ်ရန်လိုအပ်သည်။
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // ဤနေရာတွင်ထုတ်ပြန်မှုရေးသားခြင်းသည် `downgrade` မှဖတ်ခြင်းနှင့်ထပ်တူပြုခြင်း၊ အထက်ပါ `strong` ၏ဖတ်ပြီးနောက်ရေးသားမှုပြီးဆုံးခြင်းကိုထိရောက်စွာတားဆီးနိုင်သည်။
            //
            //
            self.inner().weak.store(1, Release); // သော့ခတ်လွှတ်လိုက်ပါ
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// အဆိုပါ `Arc` drop ။
    ///
    /// ဤသည်အားကြီးသောရည်ညွှန်းအရေအတွက်လျှော့ချပါလိမ့်မယ်။
    /// အကယ်၍ အားကောင်းသောရည်ညွှန်းအရေအတွက်သည်သုညသို့ရောက်ရှိပါကအခြားသောရည်ညွှန်းချက်များ (ရှိခဲ့ပါက) သည် [`Weak`] ဖြစ်သည်၊ ထို့ကြောင့်ကျွန်ုပ်တို့သည်အတွင်းတန်ဖိုးကို `drop` ဖြစ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // ဘာမှမပုံနှိပ်ပါဘူး
    /// drop(foo2);   // "dropped!" ထုတ်
    /// ```
    #[inline]
    fn drop(&mut self) {
        // ဘာလို့လဲဆိုတော့ `fetch_sub` က atomic ဖြစ်နေပြီဆိုတော့ object ကို delete မလုပ်မချင်းအခြားချည်များနှင့်ထပ်တူထပ်ညှိရန်မလိုအပ်ပါ။
        // ဤသည်အတူတူပင်ယုတ္တိဗေဒ `weak` အရေအတွက်ကအောက်ပါ `fetch_sub` သက်ဆိုင်သည်။
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // ဒေတာအသုံးပြုမှုကိုပြန်လည်စီစဉ်ခြင်းနှင့်အချက်အလက်များ၏ဖျက်ခြင်းကိုကာကွယ်ရန်ဤခြံစည်းရိုးလိုအပ်သည်။
        // အဘယ်ကြောင့်ဆိုသော်၎င်းကို `Release` ဟုမှတ်သားထားခြင်းကြောင့်ရည်ညွှန်းမှုအရေအတွက်ကျဆင်းခြင်းသည်ဤ `Acquire` ခြံစည်းရိုးနှင့်ထပ်တူကျစေသည်။
        // ဆိုလိုသည်မှာအချက်အလက်များအသုံးပြုခြင်းသည်ရည်ညွှန်းရေတွက်ခြင်းကိုမလျှော့ချမီဖြစ်မည်၊ ဆိုလိုသည်မှာဤခြံစည်းရိုးမတိုင်မီဖြစ်ပျက်မည်၊
        //
        // [Boost documentation][1] မှာရှင်းပြထားတဲ့အတိုင်း
        //
        // > အရာဝတ္ထုတစ်ခုထဲရှိမည်သည့်ဖြစ်နိုင်ချေ ၀ င်ခွင့်ကိုမဆိုပြဌာန်းရန်အရေးကြီးသည်
        // > *(လက်ရှိရည်ညွှန်းမှတဆင့်)* မဖျက်ခင် * ဖြစ်ပျက်ရန်
        // > တစ် ဦး ကွဲပြားခြားနားချည်အတွက်အရာဝတ္ထု။၎င်းကို "release" ဖြင့်ရရှိသည်
        // > ရည်ညွှန်း (အရာဝတ္ထုမှမဆိုဝင်ရောက်ခွင့်ကျဆင်းနေပြီးနောက်စစ်ဆင်ရေး
        // > ဒီရည်ညွှန်းမှတဆင့်သိသာမတိုင်မီဖြစ်ပျက်ရမယ်နှင့်တစ် ဦး
        // > "acquire" အရာဝတ္ထုကိုဖျက်ပစ်မီစစ်ဆင်ရေး။
        //
        // အထူးသဖြင့် Arc ၏ပါဝင်သောအရာများသည်များသောအားဖြင့်မပြောင်းလဲနိုင်သောအရာများဖြစ်သော်လည်းအတွင်းပိုင်းမှတစ်ဆင့် Mutex ကဲ့သို့သောအရာများရှိနိုင်သည်<T>။
        // ဖျက်လိုက်သည့်အခါ Mutex မဝယ်ယူနိုင်သောကြောင့် Thread in အတွင်းရှိ A ကိုရေးခြင်းပြုလုပ်ရန် Thread ခတွင်လည်ပတ်နေသည့်ဖျက်ဆီးသူကိုမြင်နိုင်စေရန်၎င်း၏ထပ်တူပြုခြင်းယုတ္တိဗေဒကိုအားကိုး။ မရပါ။
        //
        //
        // ဤနေရာတွင် Acquire ခြံစည်းရိုးကိုမြင့်မားစွာရင်ဆိုင်ရသောအခြေအနေများတွင်စွမ်းဆောင်ရည်ကိုတိုးတက်စေနိုင်သည့် Acquire load ဖြင့်အစားထိုးနိုင်သည်ကိုသတိပြုပါ။[2] ကိုကြည့်ပါ။
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Arc<dyn Any + Send + Sync>` ကိုကွန်ကရစ်အမျိုးအစားသို့လျှော့ချရန်ကြိုးစားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// မည်သည့်မှတ်ဉာဏ်ကိုမျှခွဲဝေခြင်းမပြုဘဲ `Weak<T>` အသစ်တစ်ခုကိုတည်ဆောက်သည်။
    /// [`upgrade`] ကိုပြန်ပို့သည့်တန်ဖိုးမှာအမြဲတမ်း [`None`] ကိုပေးသည်။
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// အချက်အလက်နယ်ပယ်နှင့်ပတ်သက်ပြီးအခိုင်အမာပြောဆိုခြင်းမပြုဘဲရည်ညွှန်းရေတွက်ခြင်းကိုကြည့်ရှုရန်ခွင့်ပြုသည့်အကူအညီအမျိုးအစား။
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// ဤ `Weak<T>` မှညွှန်းထားသော `T` အရာဝတ္ထုသို့ raw pointer တစ်ခု return ပြန်သည်။
    ///
    /// ခိုင်မာသောကိုးကားချက်များရှိမှသာ pointer သည်မှန်ကန်သည်။
    /// အဆိုပါ pointer မဟုတ်ရင် XangX dangling, unaligned သို့မဟုတ်ပင်ဖြစ်နိုင်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // နှစ် ဦး စလုံးတူညီသောအရာဝတ္ထုကိုညွှန်ပြ
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // ဒီမှာအားကောင်းတဲ့သူကရှင်သန်နေစေတယ်၊ ဒါကြောင့်အရာဝတ္ထုကိုကြည့်လို့ရသေးတယ်။
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // သို့သော်မပိုတော့ပါ။
    /// // weak.as_ptr() ကိုကျွန်ုပ်တို့လုပ်နိုင်သည်၊ သို့သော် pointer ကိုအသုံးပြုခြင်းသည်အပြုအမူကိုဖြစ်ပေါ်စေသည်။
    /// // assert_eq ("မင်္ဂလာပါ"၊ unsafe {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // အကယ်၍ ညွှန်ပြသည် dangling ဖြစ်နေပါက sentinel ကိုပြန်ပို့ပါမည်။
            // ဤသည်သည်မှန်ကန်သော payload လိပ်စာမဖြစ်နိုင်ပါ၊ အကြောင်းမှာ payInload သည်အနည်းဆုံး ArcInner (usize) နှင့်တန်းတူဖြစ်သည်။
            ptr as *const T
        } else {
            // လုံခြုံမှု-အကယ်၍ is_dangling သည် false ကို return ပြန်လျှင် pointer သည် dereferencable ဖြစ်သည်။
            // payload ကိုယခုအချိန်တွင်ကျဆင်းသွားနိုင်ပြီးကျွန်ုပ်တို့သည်သက်သေပြမှုကိုဆက်လက်ထိန်းသိမ်းထားရန်လိုသည်။ ထို့ကြောင့် raw pointer manipulation ကိုသုံးပါ။
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// `Weak<T>` ကိုသုံးပြီးအဲဒါကို pointer raw တစ်ခုအဖြစ်ပြောင်းလဲလိုက်သည်။
    ///
    /// ၎င်းသည်အားနည်းသောညွှန်ပြသူအဖြစ်သို့ပြောင်းလဲသွားပြီးအားနည်းသောရည်ညွှန်းချက်တစ်ခု၏ပိုင်ဆိုင်မှုကိုဆက်လက်ထိန်းသိမ်းထားဆဲဖြစ်သည်။ အားနည်းသောအရေအတွက်ကိုဤစစ်ဆင်ရေးမှပြုပြင်မထားပါ။
    /// ၎င်းကို [`from_raw`] နှင့်အတူ `Weak<T>` သို့ပြန်လှည့်နိုင်သည်။
    ///
    /// [`as_ptr`] ကဲ့သို့ pointer ၏ target ကိုရယူရန်ကန့်သတ်ချက်များသည်အတူတူပင်ဖြစ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// ယခင်က [`into_raw`] မှဖန်တီးခဲ့သော pointer raw `Weak<T>` သို့ပြောင်းသည်။
    ///
    /// ၎င်းသည်ခိုင်မာသောရည်ညွှန်းချက် (နောက်ပိုင်းတွင် [`upgrade`] သို့ခေါ်ဆိုခြင်း) ကိုရရှိရန် (သို့) `Weak<T>` ကိုကျဆင်းခြင်းအားဖြင့်အားနည်းသောအရေအတွက်ကိုဖယ်ရှားရန်အတွက်အသုံးပြုနိုင်သည်။
    ///
    /// ၎င်းသည်အားနည်းသောရည်ညွှန်းချက်တစ်ခု၏ပိုင်ဆိုင်မှုကိုရယူသည် ([`new`] မှပြုလုပ်သော pointers များ မှလွဲ၍ ၎င်းတို့သည်မည်သည့်အရာမှပိုင်ဆိုင်ခြင်းမရှိသောကြောင့်ဖြစ်သည်။
    ///
    /// # Safety
    ///
    /// pointer သည် [`into_raw`] မှဆင်းသက်လာပြီးဖြစ်နိုင်သောအားနည်းသောရည်ညွှန်းချက်ကိုပိုင်ဆိုင်ထားရမည်။
    ///
    /// ၎င်းခေါ်ဆိုသည့်အချိန်တွင်အားကောင်းသောအရေအတွက်ကို ၀ ဖြစ်ခွင့်ပြုသည်။
    /// မည်သို့ပင်ဆိုစေကာမူ၊ ၎င်းသည်လက်ရှိအားဖြင့်ကုန်ကြမ်း pointer အဖြစ်ကိုယ်စားပြုသောအားနည်းသောရည်ညွှန်းချက်တစ်ခုကိုပိုင်ဆိုင်သည် (အားနည်းချက်ကိုဒီလုပ်ဆောင်မှုမှပြုပြင်မထားပါ) ထို့ကြောင့်၎င်းသည်ယခင် [`into_raw`] သို့ခေါ်ဆိုမှုနှင့်တွဲဖက်ရမည်ဖြစ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // နောက်ဆုံးအားနည်းအရေအတွက်လျော့။
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // input pointer မည်သို့ဆင်းသက်လာသည်ကိုအခြေအနေတွင် Weak::as_ptr တွင်ကြည့်ပါ။

        let ptr = if is_dangling(ptr as *mut T) {
            // ဒါ dangling အားနည်းချက်ပဲ။
            ptr as *mut ArcInner<T>
        } else {
            // ဒီလိုမှမဟုတ်ရင်ကျနော်တို့ကညွှန်ပြနေတဲ့အားနည်းတဲ့အားနည်းချက်ကနေလာတာသေချာတယ်။
            // လုံခြုံမှု: ptr သည်အမှန်တကယ် (ဖြစ်နိုင်ခြေကျဆင်းသွားသည်) ကိုရည်ညွှန်းသောကြောင့် data_offset သည်လုံခြုံစွာခေါ်ဆိုနိုင်သည်။
            let offset = unsafe { data_offset(ptr) };
            // ထို့ကြောင့်ကျွန်ုပ်တို့သည် RcBox တစ်ခုလုံးရရန် offset ကိုပြောင်းလိုက်သည်။
            // လုံခြုံမှု-ညွှန်ပြသူသည်အားနည်းချက်မှဆင်းသက်လာသောကြောင့်ဤချိန်ညှိမှုသည်လုံခြုံသည်။
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // လုံခြုံမှု-ယခုကျွန်ုပ်တို့အားနည်းသော pointer ကိုပြန်လည်ရရှိပြီးဖြစ်သောကြောင့်အားနည်းမှုကိုဖန်တီးနိုင်သည်။
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// `Weak` pointer ကို [`Arc`] သို့မြှင့်တင်ရန်ကြိုးပမ်းသည်။
    ///
    ///
    /// အတွင်းပိုင်းတန်ဖိုးကိုကတည်းကကျဆင်းသွားခဲ့ပြီးလျှင် [`None`] ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // အားကြီးသောထောက်ပြသူအားလုံးကိုဖျက်ဆီးပစ်ပါ။
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // fetch_add အစားခိုင်မာသည့်အရေအတွက်ကိုတိုးမြှင့်ရန် CAS CAS ကိုအသုံးပြုသည်။ အဘယ်ကြောင့်ဆိုသော်ဤလုပ်ဆောင်ချက်သည်ရည်ညွှန်းရေတွက်ခြင်းကိုသုညမှတစ်ခုသို့ဘယ်တော့မျှမယူသင့်ပါ။
        //
        //
        let inner = self.inner()?;

        // ဘာလို့လဲဆိုတော့ကျွန်ုပ်တို့တွေ့မြင်နိုင်သည့် 0 ရေးသည့်မည်သည့်အရေးအသားမဆိုလယ်ပြင်သည်အမြဲတမ်းသုညအနေအထားမှထွက်ခွာသွားသောကြောင့် (0 ၀ မှ ၀ င်သော "stale" ဖတ်ပြီးသည်)၊ အခြားမည်သည့်တန်ဖိုးကိုမဆိုအောက်တွင်ဖော်ပြထားသော CAS မှအတည်ပြုသည်။
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // ကျွန်ုပ်တို့သည် (`mem::forget` အတွက်) ကျွန်ုပ်တို့အဘယ်ကြောင့်ဤသို့ပြုလုပ်ရကြောင်း `Arc::clone` ရှိမှတ်ချက်များကိုကြည့်ပါ။
            if n > MAX_REFCOUNT {
                abort();
            }

            // ငါတို့ပြည်နယ်အသစ်နှင့်ပတ်သက်။ မည်သည့်မျှော်လင့်ချက်ရှိသည်မဟုတ်ကြသောကြောင့်, ဖြေလျော့ပေးခြင်းသည်ပျက်ကွက်မှုကိစ္စအတွက်အဆင်ပြေပါသည်။
            // အောင်မြင်မှုအမှုအား `Weak` နှင့်ထပ်တူပြုရန်အတွက် Acquire သည်လိုအပ်သည်။ `Weak` ကိုးကားမှုများကိုဖန်တီးပြီးနောက်တွင်အတွင်းတန်ဖိုးကိုစတင်နိုင်သည်။
            // ဤကိစ္စတွင်ကျွန်ုပ်တို့သည်အပြည့်အဝစတင်တန်ဖိုးကိုလေ့လာရန်မျှော်လင့်သည်။
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null အထက်တွင် check လုပ်ထား
                Err(old) => n = old,
            }
        }
    }

    /// ဒီခွဲဝေမှုကိုညွှန်ပြခိုင်မာတဲ့ (`Arc`) ထောက်ပြများ၏နံပါတ်ရရှိသည်။
    ///
    /// `self` ကို [`Weak::new`] သုံး၍ ဖန်တီးခဲ့လျှင်၎င်းသည် 0 သို့ပြန်သွားလိမ့်မည်။
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// ဒီခွဲဝေချထားပေးရန်ညွှန်ပြ `Weak` ထောက်ပြ၏နံပါတ်တစ်ခုအကြမ်းဖျင်းရရှိသည်။
    ///
    /// `self` ကို [`Weak::new`] သုံး၍ ဖန်တီးခဲ့ပါက၊ သို့မဟုတ်ခိုင်မာသောအချက်များမရှိပါက၎င်းသည် 0 ၀ သို့ပြန်သွားပါမည်။
    ///
    /// # Accuracy
    ///
    /// အကောင်အထည်ဖော်မှုအသေးစိတ်အချက်အလက်များကြောင့်အခြားချည်များက `Arc`s`သို့မဟုတ်`Weak`s the တူညီသောခွဲဝေမှုကိုညွှန်ပြနေသည့်အခါမည်သည့်လမ်းကြောင်းကိုမဆို 1 သို့ပြန်သွားနိုင်သည်။
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // အားနည်းသော count ကိုဖတ်ပြီးနောက်အနည်းဆုံးအားကြီးသောညွှန်ကိန်းရှိခဲ့သည်ကိုကျွန်ုပ်တို့လေ့လာတွေ့ရှိခဲ့ပြီးဖြစ်သောကြောင့်အားနည်းသောအရေအတွက်ကိုလေ့လာသည့်အခါသွယ်ဝိုက်အားနည်းရည်ညွှန်းချက် (မည်သည့်ခိုင်မာသောရည်ညွှန်းချက်များရှင်သန်နေသောအချိန်တွင်ရှိနေသည်) ကျွန်ုပ်တို့အားနည်းနေသောအရေအတွက်ကိုလေ့လာသည့်အခါတဝိုက်တွင်ရှိနေဆဲဖြစ်သောကြောင့်၎င်းကိုလုံခြုံစွာနုတ်နိုင်သည်။
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// pointer သည်ချိတ်ထားသောအခါ `None` ကို return ပြန်သည်။ `ArcInner` မရှိပါ။ (ဆိုလိုသည်မှာ `Weak` မှ `Weak::new` ဖန်တီးသောအခါ) ။
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // ကျွန်ုပ်တို့သည် "data" field ကိုဖုံးအုပ်ထားသောရည်ညွှန်းကိုးကားခြင်းကိုမဖန်တီးရန်သတိထားသည်။ ဥပမာအားဖြင့်၊ နောက်ဆုံး `Arc` ကျဆင်းသွားပါကဒေတာနယ်ပယ်တွင်ကျဆင်းသွားလိမ့်မည်။
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// `Weak`s နှစ်ခုသည် ([`ptr::eq`] နှင့်ဆင်တူသည်) တူညီသောခွဲဝေမှုကိုရည်ညွှန်းပါက၊ သို့မဟုတ်နှစ်မျိုးလုံးသည် `Weak::new()`) ဖြင့်ဖန်တီးထားခြင်းကြောင့်မည်သည့်ခွဲဝေမှုကိုမညွှန်ပြလျှင် `true` ကိုပြန်ပို့သည်။
    ///
    ///
    /// # Notes
    ///
    /// ၎င်းသည် pointers များနှင့်နှိုင်းယှဉ်လျှင် `Weak::new()` သည်မည်သည့်ခွဲဝေသတ်မှတ်ချက်ကိုမျှညွှန်ပြခြင်းမရှိသော်လည်း၊
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` ကိုနှိုင်းယှဉ်။
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// တူညီသောခွဲဝေမှုကိုညွှန်ပြသော `Weak` pointer ၏ကိုယ်ပွားကိုပြုလုပ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // ဤအရာသည်အဘယ်ကြောင့်ဖြေလျော့ပေးခြင်းခံရသည်ကို Arc::clone() ရှိမှတ်ချက်များကိုကြည့်ပါ။
        // ၎င်းသည် fetch_add (သော့ကိုလျစ်လျူရှုခြင်း) ကိုအသုံးပြုနိုင်သည်။ အဘယ်ကြောင့်ဆိုသော်အားနည်းသောအရေအတွက်သည်သာအခြားမည်သည့် * အားနည်းသောနေရာတွင်ရှိသနည်း။
        //
        // (ဒါကြောင့်ဒီကိစ္စမှာကျွန်တော်တို့ဒီကုဒ်ကိုသုံးလို့မရဘူး) ။
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // ကျွန်ုပ်တို့သည် (mem::forget အတွက်) ကျွန်ုပ်တို့အဘယ်ကြောင့်ဤသို့ပြုလုပ်ရကြောင်း Arc::clone() ရှိမှတ်ချက်များကိုကြည့်ပါ။
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// မှတ်ဉာဏ်ခွဲဝေခြင်းမရှိဘဲ `Weak<T>` အသစ်တစ်ခုကိုတည်ဆောက်သည်။
    /// [`upgrade`] ကိုပြန်ပို့သည့်တန်ဖိုးမှာအမြဲတမ်း [`None`] ကိုပေးသည်။
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// အဆိုပါ `Weak` pointer ကို drop ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // ဘာမှမပုံနှိပ်ပါဘူး
    /// drop(foo);        // "dropped!" ထုတ်
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // ကျွန်ုပ်တို့သည်နောက်ဆုံးအားနည်းသောညွှန်ပြသူဖြစ်ကြောင်းတွေ့ရှိပါက၎င်းသည်ဒေတာများကိုလုံး ၀ ဖယ်ရှားပစ်ရမည့်အချိန်ဖြစ်သည်။Arc::drop() မှဆွေးနွေးမှုကိုကြည့်ရှုပါ
        //
        // ဤနေရာတွင်သော့ခတ်ထားသောအခြေအနေကိုစစ်ဆေးရန်မလိုအပ်ပါ။ အဘယ်ကြောင့်ဆိုသော်အားနည်းသောအရေအတွက်အားတိကျစွာအားနည်းချက်တစ်ခုသာရှိပါကကန့်သတ်နိုင်မှုကိုဆိုလိုသည်။ ဆိုလိုသည်မှာကျဆင်းမှုသည်ကျန်ရှိနေသေးသောအားနည်းနေသော ref ကိုသာ ON တွင်သာ run နိုင်သည်၊ သော့ခတ်လွှတ်ပြီးမှသာဖြစ်နိုင်သည်။
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// ဒီမှာ `&T` ကိုယေဘူယျအားဖြင့်ပိုမိုကောင်းမွန်အောင်လုပ်ခြင်းမဟုတ်ဘဲဒီအထူးပြုကိုလုပ်နေခြင်းဖြစ်သည်။ ဘာဖြစ်လို့လဲဆိုတော့ refs အပေါ်တန်းတူညီမျှမှုစစ်ဆေးခြင်းအတွက်ကုန်ကျစရိတ်ကိုထပ်ပေါင်းပေးလို့ပဲ။
/// Arc`s ကိုကြီးမားသောတန်ဖိုးများကိုသိုလှောင်ရန်အသုံးပြုသည်၊ ၎င်းသည်ပုံတူပွားရန်နှေးကွေးသော်လည်း၊ တန်းတူညီမျှမှုရှိမရှိစစ်ဆေးရန်အလွန်လေးသောကြောင့်၎င်းကုန်ကျစရိတ်ကိုပိုမိုလွယ်ကူစွာပေးဆပ်နိုင်သည်။
///
/// ထို့အပြင် `&T`s နှစ်ခုထက်ပိုမိုသော `Arc` Clone နှစ်ခုရှိသည်။
///
/// `PartialEq` တစ်ခုအနေဖြင့် `T: Eq` သည်တမင်တကာတုံ့ပြန်မှုမရှိသောအခါကျွန်ုပ်တို့ဤသို့ပြုလုပ်နိုင်သည်။
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// နှစ်ခု `Arc`s တန်းတူရေး။
    ///
    /// Arc`s နှစ်ခုသည်သူတို့၏အတွင်းပိုင်းတန်ဖိုးများကိုညီမျှလျှင် ၄ င်းကိုကွဲပြားခြားနားသောခွဲဝေထားသည့်ပမာဏနှင့်အတူတူပင်ဖြစ်သည်။
    ///
    /// အကယ်၍ `T` သည် `Eq` (ညီမျှခြင်း၏ရောင်ပြန်ဟပ်မှုကိုဆိုလိုခြင်း) ကိုအသုံးပြုပါက `Arc`s နှစ်ခုသည်တူညီသောခွဲဝေမှုကိုညွှန်ပြသည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// နှစ်ခု `Arc`s အတွက်မညီမျှမှု။
    ///
    /// Arc`s နှစ်ခုသည်သူတို့၏အတွင်းတန်ဖိုးများမညီမျှပါကမတူညီပါ။
    ///
    /// အကယ်၍ `T` သည် `Eq` (ညီမျှခြင်း၏ရောင်ပြန်ဟပ်မှုကိုဖော်ပြခြင်း) ကိုအကောင်အထည်ဖော်ပါက ```` ```` ```` ```` ```` ```` ```` နှစ်ခုအဘယ်ကြောင့်နည်း
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// နှစ်ခု `Arc`s များအတွက်တစ်စိတ်တစ်ပိုင်းနှိုင်းယှဉ်။
    ///
    /// နှစ်ခုကိုသူတို့၏အတွင်းတန်ဖိုးများကို `partial_cmp()` ဖြင့်ခေါ်ခြင်းဖြင့်နှိုင်းယှဉ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Arc`s နှစ်ခုအတွက်နှိုင်းယှဉ်မှုနည်းသည်။
    ///
    /// နှစ်ခုကိုသူတို့၏အတွင်းတန်ဖိုးများကို `<` ဖြင့်ခေါ်ခြင်းဖြင့်နှိုင်းယှဉ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// '' ထက်နည်းသောသို့မဟုတ်တူညီသော '' နှစ်ခု `Arc`s ဘို့နှိုင်းယှဉ်။
    ///
    /// နှစ်ခုကိုသူတို့၏အတွင်းတန်ဖိုးများကို `<=` ဖြင့်ခေါ်ခြင်းဖြင့်နှိုင်းယှဉ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Arc`s နှစ်ခုနှင့်နှိုင်းယှဉ်လျှင် ပို၍ ကြီးသည်။
    ///
    /// နှစ်ခုကိုသူတို့၏အတွင်းတန်ဖိုးများကို `>` ဖြင့်ခေါ်ခြင်းဖြင့်နှိုင်းယှဉ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Arc`s နှစ်ခုအတွက်နှိုင်းယှဉ်မှုထက်ကြီးသည်သို့မဟုတ်ညီမျှသည်။
    ///
    /// နှစ်ခုကိုသူတို့၏အတွင်းတန်ဖိုးများကို `>=` ဖြင့်ခေါ်ခြင်းဖြင့်နှိုင်းယှဉ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// နှစ်ခု `Arc`s အတွက်နှိုင်းယှဉ်။
    ///
    /// နှစ်ခုကိုသူတို့၏အတွင်းတန်ဖိုးများကို `cmp()` ဖြင့်ခေါ်ခြင်းဖြင့်နှိုင်းယှဉ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// `T` အတွက် `Default` တန်ဖိုးရှိသည့် `Arc<T>` အသစ်တစ်ခုကိုဖန်တီးသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// ရည်ညွှန်းထားသောအချပ်ကိုခွဲဝေချပြီး `v` ၏ပစ္စည်းများကိုပုံတူပွားပါ။
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// ရည်ညွှန်းရေတွက်ထားသော `str` ကိုခွဲဝေချပြီး `v` ကိုကူးယူပါ။
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// ရည်ညွှန်းရေတွက်ထားသော `str` ကိုခွဲဝေချပြီး `v` ကိုကူးယူပါ။
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// ကိုးကားထားသောစာရင်းအသစ်တစ်ခုသို့ boxed object တစ်ခုကိုရွှေ့ပါ။
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// ရည်ညွှန်းထားသောအချပ်ကိုခွဲဝေချပြီး `v` ၏ပစ္စည်းများကို၎င်းသို့ရွှေ့ပါ။
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Vec အား၎င်း၏မှတ်ဥာဏ်ကိုလွှတ်ပေးရန်ခွင့်ပြုပါ
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// element တစ်ခုချင်းစီကို `Iterator` တွင်ယူပြီး၎င်းကို `Arc<[T]>` သို့စုဆောင်းသည်။
    ///
    /// # စွမ်းဆောင်ရည်ဝိသေသလက္ခဏာများ
    ///
    /// ## ယေဘူယျကိစ္စ
    ///
    /// ယေဘူယျအားဖြင့် `Arc<[T]>` သို့စုဆောင်းခြင်းကို `Vec<T>` ထဲသို့ပထမဆုံးစုဆောင်းခြင်းအားဖြင့်ပြုလုပ်သည်။ဆိုလိုသည်မှာ၊
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ဒါကိုငါတို့ရေးခဲ့တာနဲ့တူတယ်
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // ခွဲဝေချခြင်း၏ပထမအစုသည်ဤနေရာတွင်ဖြစ်ပျက်သည်။
    ///     .into(); // `Arc<[T]>` အတွက်ဒုတိယမြောက်ခွဲဝေချထားမှုသည်ဤနေရာတွင်ဖြစ်ပျက်သည်။
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ၎င်းသည် `Vec<T>` ကိုတည်ဆောက်ရန်လိုအပ်သကဲ့သို့အကြိမ်ပေါင်းများစွာခွဲဝေချထားပေးပြီး `Vec<T>` ကို `Arc<[T]>` သို့ပြောင်းလဲရန်တစ်ကြိမ်ခွဲဝေပေးလိမ့်မည်။
    ///
    ///
    /// ## လူသိများအရှည်၏ကြားမှာ
    ///
    /// သင်၏ `Iterator` `TrustedLen` ကိုအကောင်အထည်ဖော်ပြီးအရွယ်အစားအတိအကျဖြစ်သည့်အခါ `Arc<[T]>` အတွက်ခွဲဝေတစ်ခုတည်းပြုလုပ်လိမ့်မည်။ဥပမာ:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // တစ်ခုတည်းသောခွဲဝေရုံကဒီမှာဖြစ်ပျက်။
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// အထူးပြု trait သည် `Arc<[T]>` သို့စုဆောင်းရန်အသုံးပြုသည်။
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // ဤသည်မှာ `TrustedLen` ကြားဖြတ်အတွက်ဖြစ်သည်။
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // လုံခြုံမှု-ကြားမှာတိကျတဲ့အရှည်ရှိပြီးကျွန်ုပ်တို့မှာရှိဖို့လိုတယ်။
                Arc::from_iter_exact(self, low)
            }
        } else {
            // နောက်ကျောပုံမှန်အကောင်အထည်ဖော်မှုသို့ကျလိမ့်မည်။
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// pointer တစ်ခု၏နောက်ကွယ်ရှိ payload အတွက် `ArcInner` အတွင်း offset ကိုရယူပါ။
///
/// # Safety
///
/// ညွှန်ပြသူသည်ယခင်ကခိုင်လုံသော T ၏ဥပမာ (နှင့်မှန်ကန်သော metadata များရှိရမည်) ကိုညွှန်ပြရမည်၊ သို့သော် T ကိုကျဆင်းနိုင်သည်။
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // အဆိုပါ unsized တန်ဖိုးကို ArcInner ၏အဆုံးမှ align ။
    // RcBox သည် repr(C) ဖြစ်သောကြောင့်၎င်းသည်အမြဲတမ်းမှတ်ဉာဏ်တွင်နောက်ဆုံးနေရာဖြစ်လိမ့်မည်။
    // လုံခြုံမှု-မဖြစ်နိုင်သည့်တစ်ခုတည်းသောအမျိုးအစားများသည်ချပ်များ ဖြစ်၍ trait တ္ထုများ၊
    // နှင့်ပြင်ပအမျိုးအစားများ, input ကိုဘေးကင်းလုံခြုံမှုလိုအပ်ချက် align_of_val_raw ၏လိုအပ်ချက်များကိုကျေနပ်အောင်လက်ရှိအလုံအလောက်;ဤသည်သည် std ပြင်ပ၌မှီခိုအားထားနိုင်သည့်ဘာသာစကား၏အကောင်အထည်ဖော်မှုအသေးစိတ်ဖြစ်သည်။
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}