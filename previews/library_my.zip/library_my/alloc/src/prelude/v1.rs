//! `alloc` crate ၏ prelude ၏ပထမဆုံးဗားရှင်း။
//!
//! ပိုပြီးများအတွက် [module-level documentation](../index.html) ကိုကြည့်ပါ။

#![unstable(feature = "alloc_prelude", issue = "58935")]

#[unstable(feature = "alloc_prelude", issue = "58935")]
pub use crate::borrow::ToOwned;
#[unstable(feature = "alloc_prelude", issue = "58935")]
pub use crate::boxed::Box;
#[unstable(feature = "alloc_prelude", issue = "58935")]
pub use crate::string::{String, ToString};
#[unstable(feature = "alloc_prelude", issue = "58935")]
pub use crate::vec::Vec;