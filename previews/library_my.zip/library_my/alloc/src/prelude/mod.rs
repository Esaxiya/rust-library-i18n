//! အဆိုပါ alloc Prelude
//!
//! ဤ module ၏ရည်ရွယ်ချက်မှာ `alloc` crate ၏အသုံးများသောပစ္စည်းများတင်သွင်းမှုကို modules ၏ထိပ်သို့ glob တင်သွင်းခြင်းကိုလျှော့ချရန်ဖြစ်သည်။
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;