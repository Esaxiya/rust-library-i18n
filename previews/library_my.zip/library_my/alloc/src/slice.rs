//! တစ်ဆက်တည်းဆက်စပ်မှုသို့ dynamically အရွယ်အမြင်။ `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! အချပ်များသည် pointer နှင့် length အဖြစ်ကိုယ်စားပြုသော memory တစ်ခုထဲသို့မြင်ကွင်းတစ်ခုဖြစ်သည်။
//!
//! ```
//! // တစ် ဦး Vec ဖြတ်
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // တစ် ဦး အချပ်တစ်ခုခင်းကျင်း coercing
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! ချပ် mutable သို့မဟုတ် shared ဖြစ်စေဖြစ်ကြသည်။
//! shared slice type သည် `&[T]` ဖြစ်ပြီး mutable slice type သည် `&mut [T]` ဖြစ်ပြီး `T` သည် element type ကိုကိုယ်စားပြုသည်။
//! ဥပမာအားဖြင့်၊ သင် mutable slice ကညွှန်ပြသော memory block ကို mutate နိုင်သည်။
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! ဒီ module ထဲမှာပါသောအရာအချို့ကိုဒီမှာ:
//!
//! ## Structs
//!
//! slices အတွက်အသုံးဝင်သော structs များစွာရှိပါသည်။ ဥပမာ [`Iter`] သည် slice ကျော်ကြားဖြတ်တွက်ချက်မှုကိုကိုယ်စားပြုသည်။
//!
//! ## Trait အကောင်အထည်ဖော်မှု
//!
//! ချပ်များအတွက်ဘုံ traits ၏အများအပြားအကောင်အထည်ဖော်မှုရှိပါသည်။ဥပမာအချို့မှာ-
//!
//! * [`Clone`]
//! * [`Eq`], X0X, element ရဲ့အမျိုးအစား [`Eq`] or [`Ord`] ချပ်တွေအတွက်။
//! * [`Hash`] - အဘယ်သူ၏ဒြပ်စင်အမျိုးအစား [`Hash`] သောချပ်သည်။
//!
//! ## Iteration
//!
//! အချပ် `IntoIterator` အကောင်အထည်ဖော်။ကြားမှာအချပ်ဒြပ်စင်ကိုကိုးကားသည်။
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! အဆိုပါ mutable အချပ်ဒြပ်စင်မှ mutable ကိုးကားဖြစ်ပေါ်စေသည်:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! ဒီ iterator က slice ရဲ့ element တွေကို mutable reference လုပ်တယ်။ ဒါကြောင့် slice ရဲ့ element type `i32` ဖြစ်ပေမယ့် iterator ရဲ့ element type ကတော့ `&mut i32` ။
//!
//!
//! * [`.iter`] နှင့် [`.iter_mut`] ကပုံမှန်ကြားမှာပြန်ပို့တဲ့အတိအလင်းနည်းလမ်းများဖြစ်သည်။
//! * ထပ်တလဲလဲပြန်လုပ်သည့်နည်းလမ်းများမှာ [`.split`], [`.splitn`], [`.chunks`], [`.windows`] နှင့်အခြားအရာများဖြစ်သည်။
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// ဒီ module ထဲမှာအသုံးပြုမှုအတော်များများသာစမ်းသပ် configuration ကိုအတွက်အသုံးပြုကြသည်။
// unused_imports သတိပေးချက်ကိုပိတ်လိုက်ရုံကသူတို့အတွက်ပြင်တာထက်သန့်ရှင်းသည်။
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// အခြေခံအချပ် extension ကိုနည်းလမ်းများ
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) NB ကိုစမ်းသပ်နေစဉ်အတွင်း `vec!` macro ၏အကောင်အထည်ဖော်မှုအတွက်လိုအပ်သောအချက်အလက်များအတွက်ဤဖိုင်ရှိ `hack` module ကိုကြည့်ပါ။
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) NB စမ်းသပ်ကာလအတွင်း `Vec::clone` ၏အကောင်အထည်ဖော်ရန်လိုအပ်, အသေးစိတ်အဘို့ဤဖိုင်ထဲမှာ `hack` module ကိုကြည့်ပါ။
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): cfg(test) `impl [T]` မရရှိနိုင်ပါ။ ဤလုပ်ဆောင်ချက်သုံးခုသည် `impl [T]` တွင်ရှိသောနည်းလမ်းများဖြစ်သည်၊ သို့သော် `core::slice::SliceExt` တွင်မရှိပါ။ ကျွန်ုပ်တို့သည်ဤလုပ်ဆောင်မှုများကို `test_permutations` test အတွက်ထောက်ပံ့ရန်လိုအပ်သည်။
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // ၎င်းကို Inline attribute ကိုမထည့်သင့်ပါ။ ၎င်းကို `vec!` macro ၌အများအားဖြင့်အသုံးပြုပြီး perfression ကိုဖြစ်ပေါ်စေသည်။
    // ဆွေးနွေးမှုနှင့်ပြီးပြည့်စုံသောရလဒ်များအတွက် #71204 ကိုကြည့်ပါ။
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // ပစ္စည်းများကိုအောက်တွင်ဖော်ပြထားသောကွင်းဆက်အတွက်အစပျိုးမှတ်သားခဲ့ကြသည်
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) LLVM သည် bounds check များကိုဖယ်ရှားရန်နှင့် zip ထက်ပိုကောင်းသော codegen ရှိရန်လိုအပ်သည်။
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // အဆိုပါ vec အနည်းဆုံးဒီအရှည်အထက်ခွဲဝေနှင့်အထက်စတင်ခဲ့သည်။
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // `s` ၏စွမ်းရည်နှင့်အတူအထက်ခွဲဝေနှင့်အောက်တွင်ဖော်ပြထားသော ptr::copy_to_non_overlapping အတွက် `s.len()` မှအစပြု။
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// အချပ် sorts ။
    ///
    /// ဒီအမျိုးအစားတည်ငြိမ်သည် (ဆိုလိုသည်မှာ၊ တူညီသောဒြပ်စင်များကိုပြန်လည်မသတ်မှတ်သည်) နှင့် *O*(*n*\*log(* n*)) အဆိုးဆုံး-အခြေအနေ)
    ///
    /// သက်ဆိုင်သောအခါတည်ငြိမ်သော sorting ထက်ယေဘုယျအားဖြင့်ပိုမိုမြန်ဆန်သောကြောင့်အရန်မှတ်ဉာဏ်ကိုမခွဲဝေပေးသောကြောင့်တည်ငြိမ်သော sorting ကိုပိုမိုနှစ်သက်သည်။
    /// [`sort_unstable`](slice::sort_unstable) ကိုကြည့်ပါ။
    ///
    /// # လက်ရှိအကောင်အထည်ဖော်မှု
    ///
    /// လက်ရှိ algorithm သည် [timsort](https://en.wikipedia.org/wiki/Timsort) အားဖြင့်မှုတ်သွင်းလိုက်လျောညီထွေဖြစ်အောင်, ကြားမှာပေါင်းစည်းမျိုးဖြစ်ပါတယ်။
    /// ၎င်းသည်အချပ်ကိုစီပြီးလုနီးပါးဖြစ်သည့်သို့မဟုတ်နှစ်ခုသို့မဟုတ်နှစ်ခုထက်ပိုသောစီထားသည့်အစဉ်လိုက်တစ်ခုနှင့်တစ်ခုပြီးတစ်ခုဆက်စပ်သည့်ကိစ္စများတွင်အလွန်မြန်စေရန်ဖြစ်သည်။
    ///
    ///
    /// ဒါ့အပြင်၎င်းသည်ယာယီသိုလှောင်မှုကို `self` ၏အရွယ်အစား၏ထက်ဝက်ကိုခွဲဝေချထားပေးသည်၊ သို့သော်အတိုချပ်များအတွက်အစားအစားထိုးထည့်သွင်းမှုအမျိုးအစားကိုအသုံးပြုသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// တစ် ဦး နှိုင်းယှဉ် function ကိုအတူအချပ် sort ။
    ///
    /// ဒီအမျိုးအစားတည်ငြိမ်သည် (ဆိုလိုသည်မှာ၊ တူညီသောဒြပ်စင်များကိုပြန်လည်မသတ်မှတ်သည်) နှင့် *O*(*n*\*log(* n*)) အဆိုးဆုံး-အခြေအနေ)
    ///
    /// အဆိုပါနှိုင်းယှဉ် function ကိုအချပ်အတွက်ဒြပ်စင်များအတွက်စုစုပေါင်းအမိန့်သတ်မှတ်ရပေမည်။အော်ဒါမှာယူမှုစုစုပေါင်းမဟုတ်ပါက၊ ဒြပ်စင်များ၏အစီအစဉ်သည်မသတ်မှတ်ပါ။
    /// အော်ဒါတစ်ခုသည် (`a`, `b` နှင့် `c` အားလုံးအတွက်) ဖြစ်ပါကစုစုပေါင်းအစီအစဉ်တစ်ခုဖြစ်သည်။
    ///
    /// * စုစုပေါင်းနှင့် antisymmetric: `a < b`, `a == b` သို့မဟုတ် `a > b` ၏အတိအကျတစ်ခုသည်မှန်ကန်သည်
    /// * အကူးအပြောင်း, `a < b` နှင့် `b < c` `a < c` ကိုဆိုလိုသည်။`==` နှင့် `>` နှစ်ခုလုံးအတွက်အတူတူထားရမည်။
    ///
    /// ဥပမာအားဖြင့်၊ [`f64`] [`Ord`] ကို `NaN` မသုံးသောကြောင့် X0XX ကိုအသုံးပြုသည်။ သို့သော် X0XX မပါ ၀ င်သည်ကိုသိသောအခါ `partial_cmp` ကို sort function အဖြစ်သုံးနိုင်သည်။
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// သက်ဆိုင်သောအခါတည်ငြိမ်သော sorting ထက်ယေဘုယျအားဖြင့်ပိုမိုမြန်ဆန်သောကြောင့်အရန်မှတ်ဉာဏ်ကိုမခွဲဝေပေးသောကြောင့်တည်ငြိမ်သော sorting ကိုပိုမိုနှစ်သက်သည်။
    /// [`sort_unstable_by`](slice::sort_unstable_by) ကိုကြည့်ပါ။
    ///
    /// # လက်ရှိအကောင်အထည်ဖော်မှု
    ///
    /// လက်ရှိ algorithm သည် [timsort](https://en.wikipedia.org/wiki/Timsort) အားဖြင့်မှုတ်သွင်းလိုက်လျောညီထွေဖြစ်အောင်, ကြားမှာပေါင်းစည်းမျိုးဖြစ်ပါတယ်။
    /// ၎င်းသည်အချပ်ကိုစီပြီးလုနီးပါးဖြစ်သည့်သို့မဟုတ်နှစ်ခုသို့မဟုတ်နှစ်ခုထက်ပိုသောစီထားသည့်အစဉ်လိုက်တစ်ခုနှင့်တစ်ခုပြီးတစ်ခုဆက်စပ်သည့်ကိစ္စများတွင်အလွန်မြန်စေရန်ဖြစ်သည်။
    ///
    /// ဒါ့အပြင်၎င်းသည်ယာယီသိုလှောင်မှုကို `self` ၏အရွယ်အစား၏ထက်ဝက်ကိုခွဲဝေချထားပေးသည်၊ သို့သော်အတိုချပ်များအတွက်အစားအစားထိုးထည့်သွင်းမှုအမျိုးအစားကိုအသုံးပြုသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // reverse sorting
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// သော့ချက်ထုတ်ယူ function ကိုအတူအချပ် sort ။
    ///
    /// ဤအမျိုးအစားသည်တူညီသောဒြပ်စင်များကိုပြန်လည်မသတ်မှတ်ထားခြင်းနှင့်တည်ငြိမ်မှုရှိခြင်းနှင့် *အို*(*m*\* * n *\* log(*n*)) အဆိုးရွားဆုံး-သော့ function သည်အိုအို * ** ** *) ။
    ///
    /// စျေးကြီးသောသော့လုပ်ငန်းဆောင်တာများအတွက် (ဥပမာ
    /// ရိုးရှင်းသောပိုင်ဆိုင်မှုလက်လှမ်းမီမှုသို့မဟုတ်အခြေခံလည်ပတ်မှုမဟုတ်သောလုပ်ဆောင်ချက်များ) [`sort_by_cached_key`](slice::sort_by_cached_key) သည် element keys ကိုပြန်လည်တွက်ချက်ခြင်းမရှိသောကြောင့်သိသိသာသာပိုမိုမြန်ဆန်ဖွယ်ရှိသည်။
    ///
    ///
    /// သက်ဆိုင်သောအခါတည်ငြိမ်သော sorting ထက်ယေဘုယျအားဖြင့်ပိုမိုမြန်ဆန်သောကြောင့်အရန်မှတ်ဉာဏ်ကိုမခွဲဝေပေးသောကြောင့်တည်ငြိမ်သော sorting ကိုပိုမိုနှစ်သက်သည်။
    /// [`sort_unstable_by_key`](slice::sort_unstable_by_key) ကိုကြည့်ပါ။
    ///
    /// # လက်ရှိအကောင်အထည်ဖော်မှု
    ///
    /// လက်ရှိ algorithm သည် [timsort](https://en.wikipedia.org/wiki/Timsort) အားဖြင့်မှုတ်သွင်းလိုက်လျောညီထွေဖြစ်အောင်, ကြားမှာပေါင်းစည်းမျိုးဖြစ်ပါတယ်။
    /// ၎င်းသည်အချပ်ကိုစီပြီးလုနီးပါးဖြစ်သည့်သို့မဟုတ်နှစ်ခုသို့မဟုတ်နှစ်ခုထက်ပိုသောစီထားသည့်အစဉ်လိုက်တစ်ခုနှင့်တစ်ခုပြီးတစ်ခုဆက်စပ်သည့်ကိစ္စများတွင်အလွန်မြန်စေရန်ဖြစ်သည်။
    ///
    /// ဒါ့အပြင်၎င်းသည်ယာယီသိုလှောင်မှုကို `self` ၏အရွယ်အစား၏ထက်ဝက်ကိုခွဲဝေချထားပေးသည်၊ သို့သော်အတိုချပ်များအတွက်အစားအစားထိုးထည့်သွင်းမှုအမျိုးအစားကိုအသုံးပြုသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// သော့ချက်ထုတ်ယူ function ကိုအတူအချပ် sort ။
    ///
    /// sorting လုပ်နေစဉ်အတွင်း key function ကို element တစ်ခုစီသို့တစ်ကြိမ်သာခေါ်သည်။
    ///
    /// ဤအမျိုးအစားသည်တူညီသည် (ဆိုလိုသည်မှာတူညီသောဒြပ်စင်များကိုပြန်လည်မသတ်မှတ်သည်) တည်ငြိမ်ပြီး၊ အိုအို *(* m *\**n* + *n*\*log(* n *)) အဆိုးရွားဆုံး-သော့ function* O *(* m *)) ။
    ///
    /// ရိုးရှင်းသောသော့ချက်လုပ်ဆောင်ချက် (ဥပမာ-ပိုင်ဆိုင်မှုလက်လှမ်းမီမှုသို့မဟုတ်အခြေခံစစ်ဆင်ရေးများဖြစ်သောလုပ်ဆောင်ချက်များကို) အတွက် [`sort_by_key`](slice::sort_by_key) သည်ပိုမိုမြန်ဆန်နိုင်သည်။
    ///
    /// # လက်ရှိအကောင်အထည်ဖော်မှု
    ///
    /// လက်ရှိ algorithm သည် Orson Peters မှ [pattern-defeating quicksort][pdqsort] ကိုအခြေခံသည်။ အမြန်အလျင်အမြန်ကျပန်းအလျင်အမြန်ကောက်ယူသည့်အလျင်နှင့် heapsort ၏အဆိုးရွားဆုံးအမှုနှင့်ပေါင်းစပ်ပြီးအချို့သောပုံစံများနှင့်အချပ်များအတွက် linear အချိန်ရရှိသည်။
    /// deenerate ဖြစ်ပွားမှုများကိုရှောင်ရှားရန်၎င်းသည် randomization ကိုအသုံးပြုသည်။ သို့သော်သတ်မှတ်ထားသော seed ဖြင့်အမြဲတမ်းဆုံးဖြတ်ချက်အတိုင်းပြုမူသည်။
    ///
    /// အဆိုးဆုံးအခြေအနေမှာ algorithm သည် `Vec<(K, usize)>` ထဲမှာ slice ရဲ့အရှည်ကိုယာယီသိုလှောင်ပေးတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // ခွဲဝေမှုကိုလျှော့ချရန်ကျွန်ုပ်တို့၏ vector ကိုအနည်းဆုံးဖြစ်နိုင်သည့်အမျိုးအစားဖြင့်ရည်ညွှန်းရန်အတွက်အထောက်အကူပြု macro ။
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // `indices` ၏ဒြပ်စင်များသည်၎င်းတို့ကိုရည်ညွှန်းထားသည့်အတိုင်းထူးခြားသည်။ ထို့ကြောင့်မူရင်းအချပ်နှင့် ပတ်သက်၍ မည်သည့်အမျိုးအစားမဆိုတည်ငြိမ်လိမ့်မည်။
                // ဒီနေရာမှာ `sort_unstable` ကိုသုံးတယ်။ ဘာဖြစ်လို့လဲဆိုတော့ဒါက memory memory နည်းတယ်။
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// `self` အသစ်တစ်ခုကို `Vec` ထဲသို့ကူးယူပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // ဤတွင် `s` နှင့် `x` ကိုအမှီအခိုကင်းစွာပြုပြင်နိုင်သည်။
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// `self` တစ်ခုခွဲဝေချထားပေးရန်နှင့်အတူအသစ်တစ်ခုကို `Vec` သို့ကူးယူပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // ဤတွင် `s` နှင့် `x` ကိုအမှီအခိုကင်းစွာပြုပြင်နိုင်သည်။
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB၊ အသေးစိတ်အတွက်ဤဖိုင်ရှိ `hack` module ကိုကြည့်ပါ။
        hack::to_vec(self, alloc)
    }

    /// `self` ကို Clone နှင့်ခွဲဝေစရာမလိုပဲ vector အဖြစ်ပြောင်းပေးသည်။
    ///
    /// ရရှိလာသော vector ကို `Vec 'မှတဆင့်အကွက်ထဲသို့ပြန်ပြောင်းနိုင်သည်<T>`'s `into_boxed_slice` နည်းလမ်း။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` ဒါကြောင့် `x` သို့ကူးပြောင်းသောကြောင့်တော့ဘူးသုံးလို့မရပါဘူး။
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB၊ အသေးစိတ်အတွက်ဤဖိုင်ရှိ `hack` module ကိုကြည့်ပါ။
        hack::into_vec(self)
    }

    /// `n` တစ်ခေါက်ထပ်ခါတလဲလဲလုပ်ခြင်းအားဖြင့် vector ကိုဖန်တီးသည်။
    ///
    /// # Panics
    ///
    /// စွမ်းဆောင်ရည်လျှံမယ်ဆိုရင်ဒီ function panic ။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// လျတ်အပေါ်သို့ panic:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // အကယ်၍ `n` သည်သုညထက်ကြီးလျှင်၎င်းကို `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)` အဖြစ်ခွဲနိုင်သည်။
        // `2^expn` `n` ၏ဘယ်ဘက် '1' bit နှင့်ကိုယ်စားပြုသည့်နံပါတ်ဖြစ်ပြီး `rem` သည်ကျန် `n` ၏အစိတ်အပိုင်းဖြစ်သည်။
        //
        //

        // `Vec` ကိုအသုံးပြုရန် `Vec` ကိုအသုံးပြုခြင်း။
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` အထပ်ထပ် `buf` `expn`-ကြိမ်နှစ်ဆခြင်းဖြင့်ပြုသောအမှုဖြစ်ပါတယ်။
        buf.extend(self);
        {
            let mut m = n >> 1;
            // `m > 0` ဖြစ်ပါကဘယ်ဘက်အစွန်ဆုံး '1' အထိ bits ကျန်ရှိနေသည်။
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` `self.len() * n` ၏စွမ်းရည်ရှိပါတယ်။
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) အထပ်ထပ် `buf` သူ့ဟာသူမှပထမဆုံး `rem` ထပ်ခါတလဲလဲကူးယူခြင်းဖြင့်ပြုသောအမှုဖြစ်ပါတယ်။
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // ဤသည်မှာ `2^expn > rem` မှထပ်တူကျခြင်းမဟုတ်ပါ။
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` `buf.capacity()` (`= self.len() * n`)) နဲ့ညီမျှတယ်။
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// `T` ၏အချပ်ကိုတန်ဖိုးတစ်ခုတည်းသို့ `Self::Output` အဖြစ်သို့ပြောင်းသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// တစ်ခုချင်းစီအကြားပေးထားသော separator အားမရ, တစ်ခုတည်းတန်ဖိုးကို `Self::Output` သို့ `T` တစ် ဦး အချပ်ပြား။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// တစ်ခုချင်းစီအကြားပေးထားသော separator အားမရ, တစ်ခုတည်းတန်ဖိုးကို `Self::Output` သို့ `T` တစ် ဦး အချပ်ပြား။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// byte တစ်ခုချင်းစီသည်၎င်း၏ ASCII အထက်အကြီးနှင့်ညီမျှသောဤအချပ်မိတ္တူပါရှိသော vector တစ်ခုကိုပြန်ပို့သည်။
    ///
    ///
    /// ASCII အက္ခရာများ 'a' မှ 'z' အက္ခရာများကို 'A' သို့ 'Z' သို့ဆက်စပ်ထားသည်၊ သို့သော် ASCII မဟုတ်သောအက္ခရာများမှာမပြောင်းလဲပါ။
    ///
    /// တန်ဖိုးကို in-place, အဘို့, [`make_ascii_uppercase`] ကိုအသုံးပြုပါ။
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// byte တစ်ခုချင်းစီသည်၎င်း၏ ASCII စာလုံးအသေးနှင့်ဆက်စပ်သည့်ဤအချပ်မိတ္တူပါရှိသော vector တစ်ခုကို return လုပ်သည်။
    ///
    ///
    /// ASCII အက္ခရာများ 'A' မှ 'Z' အက္ခရာများကို 'a' နှင့် 'z' သို့ဆက်စပ်ထားသည်။ သို့သော် ASCII မဟုတ်သောအက္ခရာများမှာမပြောင်းလဲပါ။
    ///
    /// In-place တန်ဖိုးကိုလျှော့ချရန် [`make_ascii_lowercase`] ကိုသုံးပါ။
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// တိကျသောဒေတာအမျိုးအစားများကျော်ချပ်များအတွက် extension traits
////////////////////////////////////////////////////////////////////////////////

/// [`[T]: : concat`](အချပ်::concat) အတွက် helper trait
///
/// Note: `Item` type parameter သည်ဤ trait တွင်မသုံးသော်လည်း၎င်းသည်ပိုမိုယေဘူယျဖြစ်ရန်ခွင့်ပြုသည်။
/// အဲဒါမရှိရင်၊ ဒီအမှားကိုကျွန်ုပ်တို့ရတယ်။
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// အဘယ်ကြောင့်ဆိုသော် `Borrow<[_]>` ၏သက်ရောက်မှုများစွာရှိသော `V` အမျိုးအစားများရှိနိုင်သဖြင့်၎င်းသည် `T` အမျိုးအစားများကိုအသုံးချနိုင်သည်။
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// concatenation ပြီးနောက်ရရှိလာတဲ့အမျိုးအစား
    type Output;

    /// အကောင်အထည်ဖော်ခြင်း [`[T]: : concat`](slice::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// [`[T]: : join`] အတွက် (helice::join) အတွက် helper trait
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// concatenation ပြီးနောက်ရရှိလာတဲ့အမျိုးအစား
    type Output;

    /// [`[T]: : join`](slice::join) ၏အကောင်အထည်ဖော်မှု
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// ချပ်များအတွက်စံ trait အကောင်အထည်ဖော်မှု
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // ပြန်လည်ရေးသားခြင်းမပြုရသေးသောပစ်မှတ်တစ်ခုတွင်ပစ်ချပါ
        target.truncate(self.len());

        // target.len <= self.len သည်အထက်ပါ truncate ကြောင့်ဖြစ်သဖြင့်ဒီမှာအချပ်များသည်အမြဲတမ်းအကန့်အသတ်ရှိနေသည်။
        //
        let (init, tail) = self.split_at(target.len());

        // ပါရှိသောတန်ဖိုးများကို '0000 ပြန်သုံး။
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// `v[0]` ကိုကြိုတင်စီထားသော sequence `v[1..]` ထဲသို့ထည့်ပါ၊ ထို့ကြောင့် `v[..]` တစ်ခုလုံးကိုစီပါလိမ့်မည်။
///
/// ဤသည်သွင်းမျိုး၏အရေးပါသော subroutine ဖြစ်ပါတယ်။
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // သွင်းခြင်းအားအကောင်အထည်ဖော်ရန်နည်းလမ်း ၃ ခုရှိသည်။
            //
            // 1. ကပ်လျက် element များကိုပထမ ဦး ဆုံးသွားမည့်တိုင်အောင် swap လုပ်ပါ။
            //    သို့သော်ဤနည်းဖြင့်ကျွန်ုပ်တို့သည်အချက်အလက်များကိုလိုအပ်သည်ထက်ပိုမိုကူးယူထားသည်။
            //    Element များသည်ကြီးမားသောတည်ဆောက်ပုံများ (ကူးယူရန်အကုန်အကျများ) ဖြစ်ပါကဤနည်းလမ်းသည်နှေးကွေးလိမ့်မည်။
            //
            // 2. ပထမဆုံးဒြပ်စင်အတွက်မှန်ကန်သောနေရာကိုမတွေ့မချင်းဆက်တိုက်လုပ်ပါ။
            // ထို့နောက်၎င်းကိုဆက်ခံသောဒြပ်စင်များကို၎င်းနေရာအတွက်နေရာရွှေ့ပြီးနောက်ဆုံးကျန်ရှိသောအပေါက်ထဲသို့ထည့်ပါ။
            // ဒါကနည်းလမ်းကောင်းတစ်ခုပါ။
            //
            // 3. ပထမ element ကိုယာယီ variable ထဲသို့ကူးယူပါ။၎င်းအတွက်မှန်ကန်သောနေရာကိုမရောက်မချင်းပြန်လုပ်ပါ။
            // ကျွန်ုပ်တို့ဖြတ်သန်းသွားသည်နှင့်တပြိုင်နက်ဖြတ်သန်းသွားသော element အားလုံးကို၎င်းကိုရှေ့ရှိ slot ထဲသို့ကူးထည့်ပါ။
            // နောက်ဆုံးအနေဖြင့်ယာယီ variable ထဲမှအချက်အလက်များကိုကျန်ရှိသောတွင်းထဲသို့ကူးယူပါ။
            // ဒီနည်းလမ်းကအရမ်းကောင်းတယ်။
            // Benchmarks သည်ဒုတိယနည်းလမ်းထက်အနည်းငယ်ကောင်းသောစွမ်းဆောင်ရည်ကိုသရုပ်ပြသည်။
            //
            // နည်းလမ်းအားလုံးကိုစံသတ်မှတ်ပြီးတတိယကအကောင်းဆုံးရလဒ်များကိုပြသည်။ဒါဆိုငါတို့ရွေးလိုက်တယ်။
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // သွင်းသွင်းခြင်းလုပ်ငန်းစဉ်၏အလယ်အလတ်အဆင့်ကို `hole` မှအမြဲတမ်းခြေရာခံသည်။
            // 1. `is_less` ရှိ panics မှ `v` ၏သမာဓိကိုကာကွယ်သည်။
            // 2. ကျန်ရှိသောအပေါက်ကို `v` တွင်အဆုံးတွင်ဖြည့်သည်။
            //
            // Panic လုံခြုံမှု:
            //
            // အကယ်၍ `is_less` panics သည်လုပ်ငန်းစဉ်အတွင်းမည်သည့်အချိန်တွင်မဆို `hole` သည် `v` တွင်းရှိအပေါက်ကို `tmp` ဖြင့်ဖြည့်သွင်းပြီး `v` သည်ကန ဦး တစ်ချိန်ကအတိအကျကျင်းပခဲ့သောအရာဝတ္ထုအားလုံးကိုသိမ်းထားနိုင်အောင်သေချာစေသည်။
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` ကျဆင်းသွားခြင်းနှင့်ထို့ကြောင့် `v` အတွက်ကျန်ရှိသောအပေါက်ထဲသို့ `tmp` ကော်ပီကူး။
        }
    }

    // ကျဆင်းသွားသည့်အခါ, `src` ကနေ `dest` သို့မိတ္တူ။
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// လျှော့ချခြင်းမရှိသောပေါင်းစပ်မှုများသည် `v[..mid]` နှင့် `v[mid..]` ကို `buf` ကိုယာယီသိုလှောင်မှုအဖြစ်သုံးကာရလဒ်ကို `v[..]` သို့သိမ်းသည်။
///
/// # Safety
///
/// နှစ်ခုအချပ် non-ဗလာနှင့် `mid` ဘောငျ၌ရှိရပါမည်။
/// တိုတောင်းသောအချပ်မိတ္တူကိုကိုင်ရန် Buffer `buf` သည်ရှည်လျားသောကာလဖြစ်ရမည်။
/// ဒါ့အပြင် `T` ဟာသုညအရွယ်မဖြစ်ရဘူး။
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // ပေါင်းစည်းခြင်းလုပ်ငန်းစဉ်သည်တိုတောင်းသောပြေးလမ်းကို `buf` သို့ပထမဆုံးကော်ပီကူးသည်။
    // ထို့နောက်၎င်းသည်အသစ်ကူးယူထားသောပြေးနှင့်ကြာရှည်သည့်ရှေ့သို့ (သို့မဟုတ်နောက်သို့) ခြေရာခံသည်၊ သူတို့၏မစဉ်းစားထားသောဒြပ်စင်များနှင့်နှိုင်းယှဉ်။ အငယ် (သို့မဟုတ်ပိုကြီးသော) ကို `v` သို့ကူးယူသည်။
    //
    // တိုတောင်းသောပြေးသည်အပြည့်အဝစားသုံးသည်နှင့်တပြိုင်နက်လုပ်ငန်းစဉ်ပြီးဆုံးသွားသည်။အကယ်၍ ရေရှည်သည်ပထမကိုလောင်ပါက၊ `v` ရှိကျန်ရှိသောအပေါက်ထဲသို့တိုတောင်းသောပြေးသွားသောအရာမှန်သမျှကိုကျွန်ုပ်တို့ကော်ပီကူးရမည်။
    //
    // ဖြစ်စဉ်နှစ်ခု၏အလယ်အလတ်အခြေအနေကို `hole` ကအမြဲတမ်းခြေရာခံသည်။
    // 1. `is_less` ရှိ panics မှ `v` ၏သမာဓိကိုကာကွယ်သည်။
    // 2. ကျန်ရှိသောအပေါက်ကို ဦး စွာစားပါကကျန်ရှိသောအပေါက်ကိုဖြည့်ပါ။
    //
    // Panic လုံခြုံမှု:
    //
    // အကယ်၍ `is_less` panics သည်လုပ်ငန်းစဉ်အတွင်းမည်သည့်အချိန်တွင်မဆို `hole` သည်ကျသွားပြီး `v` တွင်းရှိအပေါက်ကို `buf` တွင်မစဉ်းစားထားသောအကွာအဝေးဖြင့်ဖြည့်ပါလိမ့်မည်။
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // ဘယ်ဘက်ပြေးသည်ပိုတိုသည်
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // အစပိုင်းမှာတော့ဒီ pointers တွေဟာသူတို့ရဲ့ arrays တွေရဲ့အစပိုင်းကိုညွှန်ပြတယ်။
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // အငယျဆုံးသောအခြို့ကိုလောင်ပါ။
            // တန်းတူညီမျှပါကတည်ငြိမ်မှုကိုထိန်းသိမ်းရန်ဘယ်သန်ကိုပိုနှစ်သက်ပါ။
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // လမ်းကြောင်းမှန်ပေါ်တိုသည်
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // အစပိုင်းမှာတော့ဒီ pointers တွေဟာသူတို့ရဲ့ arrays တွေရဲ့အစွန်းကိုဖြတ်သွားတယ်။
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // သာ။ ကြီးသောဘက်စားသုံးပါ။
            // တန်းတူညီမျှလျှင်, တည်ငြိမ်မှုကိုဆက်လက်ထိန်းသိမ်းထားဖို့ညာဘက်ပြေးကြိုက်တတ်တဲ့။
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // နောက်ဆုံးတွင် `hole` သည်ကျဆင်းသွားသည်။
    // အကယ်၍ တိုတောင်းသောပြေးခြင်းကိုအပြည့်အ ၀ မသုံးစွဲပါကကျန်ရှိသောကျန်ရှိသောအရာများကိုယခု `v` ရှိတွင်းထဲသို့ကူးယူလိမ့်မည်။

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // ကျဆင်းသွားသည့်အခါ `start..end` အကွာအဝေးကို `dest..` သို့ကူးယူပါ။
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` ၎င်း၏အရွယ်အစားအားဖြင့်ကိုဝေမှအဆင်ပြေမယ့်ဒါတစ်သုညအရွယ်အစားအမျိုးအစားမဟုတ်ပါဘူး။
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// ဤပေါင်းစည်းမှုအမျိုးအစားသည် [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt) တွင်ဖော်ပြထားသော TimSort မှအကြံဥာဏ်အချို့ (သို့သော်အားလုံးမဟုတ်) ငှားရမ်းသည်။
///
///
/// အဆိုပါ algorithm ကိုသဘာဝပြေးများဟုခေါ်ကြသည်သောတင်းကြပ်စွာဆင်းနှင့် Non-ဆုတ်နောက်ဆက်တွဲ, သတ်မှတ်။ဆိုင်းငံ့ထားဆဲပြေးတစ် stack ရှိပါသည်သေးပေါင်းစည်းခံရဖို့ရှိပါတယ်။
/// အသစ်တွေ့ရှိသောပြေးတစ်ခုစီကို stack ပေါ်သို့တွန်းပို့လိုက်ပြီး၊ နှစ်ခု invariants ကျေနပ်သည်အထိကပ်လျက်ပြေးသောအချို့အတွဲများကိုပေါင်းစည်းလိုက်သည်။
///
/// 1. `1..runs.len()` ရှိ `i` တိုင်းအတွက်: `runs[i - 1].len > runs[i].len`
/// 2. `2..runs.len()` ရှိ `i` တိုင်းအတွက်: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// အဆိုပါလျော့ပါးသွားမည်ဖြစ်သလိုစုစုပေါင်းပြေးအချိန်စုစုပေါင်း *အို*(*n*\*log(* n*)) အဆိုးဆုံး-ကြောင်းသေချာပါသည်။
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // ဒီအရှည်အထိအချပ် insertion မျိုးကိုအသုံးပြု။ ခွဲခြားရ။
    const MAX_INSERTION: usize = 20;
    // အလွန်တိုတောင်းသောပြေးခြင်းကိုအနည်းဆုံးဒီအများအပြားဒြပ်စင် span ဖို့ insertion မျိုးကိုအသုံးပြု။ တိုးချဲ့လျက်ရှိသည်။
    const MIN_RUN: usize = 10;

    // Sorting သည်သုညအရွယ်အမျိုးအစားများတွင်အဓိပ္ပါယ်မရှိသောအပြုအမူများမရှိပါ။
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // ခွဲတမ်းချခြင်းများကိုရှောင်ကြဉ်ရန်အတွက်တိုတောင်းသော Array များကို insertion sort မှတစ်ဆင့်ခွဲခြားသည်။
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // scratch memory အဖြစ်အသုံးပြုရန်ကြားခံတစ်ခုကိုခွဲဝေချထားပါ။`is_less` panics ဆိုပါကမိတ္တူများပေါ်တွင်အလုပ်လုပ်သော dtors ကိုမစွန့်စားဘဲ `v` ၏မာကျောသောမိတ္တူများကိုသိမ်းဆည်းထားနိုင်မည်။
    //
    // Sorted Run နှစ်ခုကိုပေါင်းလိုက်သောအခါဤ buffer သည် `len / 2` အရှည်ဆုံးအရှည်ရှိသည့်တိုတောင်းသောပြေးမိတ္တူကိုသိမ်းထားသည်။
    //
    let mut buf = Vec::with_capacity(len / 2);

    // `v` ရှိသဘာဝပြေးများကိုခွဲခြားသတ်မှတ်နိုင်ရန်ကျွန်ုပ်တို့သည်၎င်းကိုနောက်ကြောင်းပြန်လှည့်သည်။
    // ၎င်းသည်ထူးဆန်းသောဆုံးဖြတ်ချက်တစ်ခုဟုထင်ရနိုင်သည်။ သို့သော် (forwards) နှင့်ဆန့်ကျင်ဘက်လမ်းကြောင်းသို့ပေါင်းလိုက်သောပေါင်းစပ်မှုကိုစဉ်းစားပါ။
    // အခြေခံစံနှုန်းများအရရှေ့သို့ပေါင်းစည်းခြင်းသည်နောက်ပြန်ပေါင်းစည်းခြင်းထက်အနည်းငယ်ပိုမြန်သည်။
    // နိဂုံးချုပ်ရန်, နောက်ပြန်ဖြတ်သန်းခြင်းဖြင့်ပြေးဖော်ထုတ်စွမ်းဆောင်ရည်ပိုကောင်းစေတယ်။
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // နောက်သဘာဝပြေးလမ်းကိုရှာပါ၊ ၎င်းသည်တင်းကျပ်စွာဆင်းလာပါကပြန်ပြောင်းပါ။
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // ၎င်းသည်တိုလွန်းပါကအချို့သောဒြပ်စင်များကိုပြေးထဲသို့ထည့်ပါ။
        // Insertion sort သည်တိုတောင်းသောအစီအစဉ်များတွင် sort ကိုပေါင်းခြင်းထက်ပိုမြန်သောကြောင့်၎င်းသည်စွမ်းဆောင်ရည်ကိုသိသိသာသာတိုးတက်စေသည်။
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // ဒီပြေးကို stack ပေါ်သို့ Push ။
        runs.push(Run { start, len: end - start });
        end = start;

        // လျော့ပါးသွားမည်ဖြစ်သလိုကျေနပ်စေရန်အချို့ကပ်လျက်ပြေးအချို့အားလုံးအတွက်ပေါင်းစည်း။
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // နောက်ဆုံးအနေဖြင့်၊
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Run ၏ stack ကိုဆန်းစစ်ပြီးနောက်ထပ်ပေါင်းစပ်ရန်အတွက် run သော pair တစုံကိုသတ်မှတ်သည်။
    // အထူးသဖြင့် `Some(r)` ကိုပြန်ရောက်လျှင် `runs[r]` နှင့် `runs[r + 1]` ကိုထပ်မံပေါင်းစည်းရမည်။
    // အကယ်၍ algorithm သည် run အသစ်တစ်ခုကိုဆက်လက်တည်ဆောက်သင့်ပါက `None` ကိုပြန်ပို့သည်။
    //
    // ဤနေရာတွင်ဖော်ပြထားသည့်အတိုင်း TimSort သည်၎င်း၏ကြီးမားသောအကောင်အထည်ဖော်မှုအတွက်နာမည်ဆိုးဖြင့်ကျော်ကြားသည်။
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // ဇာတ်လမ်း၏အနှစ်သာရမှာ-ကျွန်ုပ်တို့သည် stack ရှိထိပ်ဆုံးပြေး ၄ ခုတွင်လျော့ပါးသွားမည်ဖြစ်သည့်လူများကိုပြဌာန်းရမည်။
    // ထိပ်တန်းသုံးခု၌သာသူတို့ကိုအတင်းအကျပ်ခိုင်းစေခြင်းသည်လျော့ချမည့်သူများအား *all* stack ထဲတွင်ပြေးနေဆဲကိုသေချာစေရန်မလုံလောက်ပါ။
    //
    // ဒီ function ကထိပ်ဆုံးပြေးလေးခုအတွက်လျော့ပါးသွားမည်ဖြစ်သလိုစစ်ဆေး။
    // ထို့အပြင်ထိပ်ပြေးသည်အညွှန်း 0 မှစတင်ပါကအမျိုးအစားကိုအပြီးသတ်နိုင်ရန်အတွက် stack အပြည့်အဝပြတ်တောက်သည်အထိအမြဲတမ်းပေါင်းစည်းမှုကိုတောင်းဆိုလိမ့်မည်။
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}