//! Unicode string ကိုချပ်။
//!
//! *[See also the `str` primitive type](str).*
//!
//! `&str` အမျိုးအစားသည်အဓိကကြိုးနှစ်မျိုးအနက်တစ်ခုဖြစ်ပြီးနောက်တစ်ခုမှာ `String` ဖြစ်သည်။
//! `String` counterpart နှင့်မတူဘဲ၎င်းရဲ့ contents တွေကိုချေးယူသည်။
//!
//! # အခြေခံအသုံးပြုမှု
//!
//! `&str` အမျိုးအစား၏အခြေခံ string ကြေငြာချက်:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! ဤတွင်ကျွန်ုပ်တို့သည် string slice ဟုလူသိများသော string literal တစ်ခုကိုကြေငြာခဲ့သည်။
//! String literals များသည် static သက်တမ်းရှိသည်။ ဆိုလိုသည်မှာ `hello_world` string သည် program တစ်ခုလုံး၏သက်တမ်းအတွက်သေချာသည်ဟုဆိုလိုသည်။
//!
//! `hello_world` ၏သက်တမ်းကိုကျွန်ုပ်တို့အတိအလင်းဖော်ပြနိုင်သည်။
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// ဒီ module ထဲမှာအသုံးပြုမှုအတော်များများသာစမ်းသပ် configuration ကိုအတွက်အသုံးပြုကြသည်။
// unused_imports သတိပေးချက်ကိုပိတ်လိုက်ရုံကသူတို့အတွက်ပြင်တာထက်သန့်ရှင်းသည်။
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `Concat<str>` ရှိ `str` သည်ဤနေရာတွင်အဓိပ္ပါယ်မရှိပါ။
/// trait ၏ဤအမျိုးအစား parameter သည်အခြား impl တစ်ခုသာ enable လုပ်ရန်ရှိသည်။
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // အရွယ်အစားတိုသောကွင်းများသည်ပိုမိုမြန်ဆန်စွာလည်ပတ်စေသည်။ အမှုန်များကိုသေးငယ်သော Separator အရှည်များအထူးပြုသည်
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // မတရား Non-သုညအရွယ်အစား fallback
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Vec နှစ် ဦး စလုံးအတွက်အလုပ်လုပ်သော Optimized join implementation<T>(T: Copy) နှင့် String ၏အတွင်းပိုင်း vec လောလောဆယ်တွင် (2018-05-13) တွင်အမျိုးအစားအခြခံယူခြင်းနှင့်အထူးပြုခြင်းတို့ပါဝင်သော bug တစ်ခုရှိသည် (ပြissueနာ #36262 ကိုကြည့်ပါ) ဤအကြောင်းကြောင့် SliceConcat<T>T: Copy နှင့် SliceConcat အတွက်အထူးမထားပါ<str>ဒီ function ၏တစ်ခုတည်းသောအသုံးပြုသူဖြစ်ပါတယ်။
// အဲဒါကိုသတ်မှတ်ထားတဲ့အချိန်အတွက်နေရာချန်ထားတယ်။
//
// String-join အတွက်ကန့်သတ်ချက်များမှာ S: Borrow ဖြစ်သည်<str>နှင့် Vec-join Borrow <[T]> [T] နှင့်အချို့သော T များအတွက် implR AsRef <[T]> နှစ်ခုလုံးကို str ။
// => s.borrow().as_ref() ငါတို့အမြဲတမ်းအချပ်တွေရှိတယ်
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // ပထမ ဦး ဆုံးအချပ်ကရှေ့ရှေ့တွင်သီးခြားမရှိဘဲတစ် ဦး တည်းသာဖြစ်ပါတယ်
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // `len` တွက်ချက်မှုများများများလျှံလာပါကပေါင်းထည့်လိုက်သော Vec ၏စုစုပေါင်းအရှည်ကိုတွက်ချက်ပါ။ ကျွန်ုပ်တို့သည် panic ဖြစ်ပါလိမ့်မည်။ ကျွန်ုပ်တို့သည်မှတ်ဥာဏ်ကုန်သွားပါလိမ့်မည်။ ကျန်လုပ်ဆောင်ချက်တစ်ခုသည်လုံခြုံမှုအတွက်ကြိုတင်သတ်မှတ်ထားသော Vec တစ်ခုလုံးလိုအပ်သည်။
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // တစ် ဦး uninitialized ကြားခံပြင်ဆင်ပါ
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // copy separator နှင့် bound မ်ားမပါဘဲ slices မ်ားအား check လုပ်ခြင်းသည်သေးငယ်သော separator များအတွက် hardcoded offsets များနှင့်ကြီးမားသောတိုးတက်မှုများကိုကွင်းဆက်များစစ်ဆေးသည် (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // ထူးဆန်းသောချေးငွေအကောင်အထည်ဖော်မှုသည်တွက်ချက်မှုအလျားနှင့်အမှန်တကယ်မိတ္တူအတွက်အချပ်အမျိုးမျိုးကိုပြန်ပေးနိုင်သည်။
        //
        // ကျွန်ုပ်တို့သည် uninitialized bytes များကိုခေါ်ဆိုသူထံမဖော်ထုတ်ရန်သေချာပါစေ။
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// string ကိုအချပ်များအတွက်နည်းလမ်းများ။
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// ကူးယူခြင်းသို့မဟုတ်ခွဲဝေခြင်းမပြုဘဲ `Box<str>` ကို `Box<[u8]>` တစ်ခုအဖြစ်ပြောင်းလဲနိုင်သည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// ပုံစံတစ်ခု၏ကိုက်ညီမှုများအားအခြား string တစ်ခုဖြင့်အစားထိုးသည်။
    ///
    /// `replace` [`String`] အသစ်တစ်ခုကိုဖန်တီးပြီး၎င်းသည် string string ၏ဒေတာကို၎င်းထဲသို့ကူးယူပေးသည်။
    /// အဲဒီလိုလုပ်နေချိန်မှာသူကပုံစံ၏ကိုက်ညီမှုကိုရှာဖွေရန်ကြိုးစားသည်။
    /// အကယ်၍ ၎င်းသည်တွေ့ရှိပါက၎င်းတို့ကိုအစားထိုး string slice ဖြင့်အစားထိုးသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// ပုံစံမကိုက်ညီပါက:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// ပုံစံတစ်ခု၏ပထမ N တိုက်စစ်ကိုအခြား string တစ်ခုဖြင့်အစားထိုးသည်။
    ///
    /// `replacen` [`String`] အသစ်တစ်ခုကိုဖန်တီးပြီး၎င်းသည် string string ၏ဒေတာကို၎င်းထဲသို့ကူးယူပေးသည်။
    /// အဲဒီလိုလုပ်နေချိန်မှာသူကပုံစံ၏ကိုက်ညီမှုကိုရှာဖွေရန်ကြိုးစားသည်။
    /// အကယ်၍ ၎င်းသည်တွေ့ရှိပါက `count` အကြိမ်အများဆုံးအစားထိုး string slice ဖြင့်အစားထိုးသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// ပုံစံမကိုက်ညီပါက:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // ပြန်လည်ခွဲဝေချထားပေးသည့်အချိန်ကိုလျှော့ချရန်မျှော်လင့်ပါသည်
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// အသစ်တစ်ခု [`String`] အဖြစ်, ဒီ string ကိုအချပ်၏အသေးညီမျှပြန်သွားသည်။
    ///
    /// 'Lowercase' Unicode Derived Core Property `Lowercase` ၏စည်းကမ်းချက်များအရသတ်မှတ်သည်။
    ///
    /// အမှုပြောင်းလဲသောအခါစာလုံးအချို့သည်အက္ခရာအမြောက်အမြားသို့ချဲ့ထွင်နိုင်သဖြင့်ဤလုပ်ဆောင်မှုသည် parameter ကို in-place ပြုပြင်မွမ်းမံခြင်းအစား [`String`] ကိုပြန်ပေးသည်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// sigma နဲ့လှည့်စားသောဥပမာ၊
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // ဒါပေမယ့်စကားလုံးရဲ့အဆုံးမှာ, မဟုတ်ပါς:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// အမှုမဲ့သောဘာသာစကားများကိုမပြောင်းလဲပါ။
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // maps သို့ to မြေပုံပြသည့်စကားလုံးတစ်လုံး၏အဆုံးတွင်မှလွဲလျှင်Σမြေပုံများ။
                // ဤသည်မှာ `SpecialCasing.txt` တွင်တစ်ခုတည်းသောခြွင်းချက်ဖြစ်သော (contextual) ပေမယ်ဘာသာစကားမမှီသောမြေပုံတစ်ခုဖြစ်သည်။ ထို့ကြောင့်ယေဘုယျ "condition" ယန္တရားရှိသည်ထက်ခက်ခဲသည်။
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // `Final_Sigma` ၏အဓိပ္ပါယ်သည်။
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// အသစ်တစ်ခု [`String`] အဖြစ်, ဒီ string ကိုအချပ်၏ uppercase ညီမျှပြန်သွားသည်။
    ///
    /// 'Uppercase' Unicode Derived Core Property `Uppercase` ၏စည်းကမ်းချက်များအရသတ်မှတ်သည်။
    ///
    /// အမှုပြောင်းလဲသောအခါစာလုံးအချို့သည်အက္ခရာအမြောက်အမြားသို့ချဲ့ထွင်နိုင်သဖြင့်ဤလုပ်ဆောင်မှုသည် parameter ကို in-place ပြုပြင်မွမ်းမံခြင်းအစား [`String`] ကိုပြန်ပေးသည်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// အမှုမပါဘဲ script များမပြောင်းပါ
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// အက္ခရာတစ်ခုသည်အမျိုးမျိုးဖြစ်နိုင်သည်။
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// ကူးယူခြင်းသို့မဟုတ်ခွဲဝေခြင်းမပြုဘဲ [`Box<str>`] ကို [`String`] တစ်ခုအဖြစ်ပြောင်းလဲနိုင်သည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// `n` ကြိမ်အသစ်တစ်ခုကိုထပ်လုပ်ခြင်းဖြင့် [`String`] အသစ်တစ်ခုကိုဖန်တီးသည်။
    ///
    /// # Panics
    ///
    /// စွမ်းဆောင်ရည်လျှံမယ်ဆိုရင်ဒီ function panic ။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// လျတ်အပေါ်သို့ panic:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// ဇာတ်ကောင်တစ် ဦး ချင်းစီသည်၎င်း၏ ASCII စာလုံးအကြီးနှင့်ညီမျှသည်။
    ///
    ///
    /// ASCII အက္ခရာများ 'a' မှ 'z' အက္ခရာများကို 'A' သို့ 'Z' သို့ဆက်စပ်ထားသည်၊ သို့သော် ASCII မဟုတ်သောအက္ခရာများမှာမပြောင်းလဲပါ။
    ///
    /// တန်ဖိုးကို in-place, အဘို့, [`make_ascii_uppercase`] ကိုအသုံးပြုပါ။
    ///
    /// ASCII စာလုံးအကြီးများကို ASCII မဟုတ်သောစာလုံးအကြီးများအတွက် [`to_uppercase`] ကိုသာသုံးပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() အဆိုပါ UTF-8 လျော့ပါးသွားမည်ဖြစ်သလိုထိန်းသိမ်း။
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// ဇာတ်ကောင်တစ် ဦး ချင်းစီသည်၎င်း၏ ASCII စာလုံးအသေးနှင့်ဆက်စပ်သောဤ string ၏မိတ္တူတစ်ခုကိုပြန်ပို့သည်။
    ///
    ///
    /// ASCII အက္ခရာများ 'A' မှ 'Z' အက္ခရာများကို 'a' နှင့် 'z' သို့ဆက်စပ်ထားသည်။ သို့သော် ASCII မဟုတ်သောအက္ခရာများမှာမပြောင်းလဲပါ။
    ///
    /// In-place တန်ဖိုးကိုလျှော့ချရန် [`make_ascii_lowercase`] ကိုသုံးပါ။
    ///
    /// ASCII စာလုံးအသေး ASCII စာလုံးအသေးအသေးအတွက် [`to_lowercase`] ကိုသုံးပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() အဆိုပါ UTF-8 လျော့ပါးသွားမည်ဖြစ်သလိုထိန်းသိမ်း။
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// boxed bytes အချပ်တစ်ခုကို box တစ်ခုရဲ့ string slice အဖြစ်သို့ပြောင်းလဲခြင်းမှာ string မှာ valid UTF-8 ပါ ၀ င်သည်ကိုပြောင်းလဲခြင်းဖြစ်သည်။
///
///
/// # Examples
///
/// အခြေခံအသုံးပြုမှု-
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}