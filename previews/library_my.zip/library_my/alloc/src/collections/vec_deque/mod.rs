//! ကြီးထွားလာသော ring ring buffer ဖြင့်နှစ်ထပ်တန်းစီခဲ့သည်။
//!
//! ဤလူတန်းတွင်ကွန်တိန်နာ၏နှစ်ဖက်စလုံးမှ *အို*(၁) amortized ထည့်သွင်းခြင်းနှင့်ဖယ်ရှားခြင်းများရှိသည်။
//! ၎င်းတွင် ZOvector0Z ကဲ့သို့ *O*(1) indexing လည်းရှိသည်။
//! ပါ ၀ င်သောအရာများသည်ကူးယူရန်မလိုအပ်ပါ။ ပါ ၀ င်သောအမျိုးအစားများကိုပေးပို့နိုင်ပါကတန်းစီလျှင်ပို့ပေးလိမ့်မည်။
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // နှစ်ခု၏အကြီးမားဆုံးဖြစ်နိုင်သောပါဝါ

/// ကြီးထွားလာသော ring ring buffer ဖြင့်နှစ်ထပ်တန်းစီခဲ့သည်။
///
/// ဤအမျိုးအစား၏ "default" အသုံးပြုမှုသည်တန်းစီထဲသို့ထည့်ရန် [`push_back`] ကိုအသုံးပြုရန်ဖြစ်ပြီး၊ တန်းစီမှဖယ်ရှားရန် [`pop_front`] ကိုအသုံးပြုရန်ဖြစ်သည်။
///
/// [`extend`] နှင့် [`append`] ကဤနည်းဖြင့်ကျောဘက်သို့တွန်းပို့လိုက်ပြီး `VecDeque` ကိုကျော်ထပ်ကာထပ်ကာရှေ့သို့သွားသည်။
///
/// `VecDeque` သည် ring buffer ဖြစ်သောကြောင့်၎င်းတွင်ပါဝင်သောအရာများသည်မှတ်ဉာဏ်ထဲ၌မလွယ်ကူပါ။
/// သငျသညျထိုကဲ့သို့သောထိရောက်သော sorting အဘို့ကဲ့သို့သောတစ်ခုတည်းအချပ်အဖြစ် element တွေကိုဝင်ရောက်ချင်လျှင်, သင် [`make_contiguous`] ကိုသုံးနိုင်သည်။
/// ၎င်းသည် E00X ကိုလှည့်ပြီး၎င်းသည်၎င်း၏ဒြပ်ထုများသည်ထုပ်ပိုး။ မပြောင်းနိုင်သည့်အချပ်ကိုယခု-တဆက်တည်းဒြပ်စင်အစီအစဉ်သို့ပြန်ပို့သည်။
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // အမြီးနှင့် ဦး ခေါင်းကြားခံသို့ထောက်ပြဖြစ်ကြသည်။
    // အမြီးသည်ဖတ်နိုင်သောပထမ ဦး ဆုံးအချက်ကိုညွှန်ပြသည်။ ခေါင်းသည်ဒေတာကိုမည်သည့်နေရာတွင်ရေးသင့်သည်ကိုအမြဲညွှန်ပြသည်။
    //
    // အမြီး==ဦး ခေါင်းလျှင်ကြားခံဗလာ။ringbuffer ရဲ့အရှည်ကိုဒီနှစ်ခုကြားရှိအကွာအဝေးအဖြစ်သတ်မှတ်ပါတယ်။
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// (ပုံမှန်အားဖြင့်သို့မဟုတ် unwinding နေစဉ်အတွင်း) သူကကျဆင်းသွားသည့်အခါအချပ်ရှိပစ္စည်းများအားလုံးကိုများအတွက် destructor ပြေး။
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // [T] များအတွက်တစ်စက်အသုံးပြုပါ
            ptr::drop_in_place(front);
        }
        // RawVec သည်ဖျက်သိမ်းခြင်းကိုကိုင်တွယ်သည်
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// တစ် ဦး အချည်းနှီးသော `VecDeque<T>` ဖန်တီး။
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// Marginally ပိုပြီးအဆင်ပြေပါတယ်
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// Marginally ပိုပြီးအဆင်ပြေပါတယ်
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // သုညအရွယ်အမျိုးအစားများအတွက်ကျွန်ုပ်တို့သည်အမြဲတမ်းစွမ်းဆောင်နိုင်စွမ်းရှိသည်
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// ptr တစ် ဦး အချပ်သို့လှည့်
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// ptr တစ် mut အချပ်သို့လှည့်
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// Element တစ်ခုကိုကြားခံထဲကနေရွှေ့ပေးတယ်
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// element တစ်ခုကို buffer ထဲကိုရွှေ့လိုက်ပြီးပြောင်းလိုက်တယ်။
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// ကြားခံအပြည့်အဝစွမ်းရည်မှာလျှင် `true` သို့ပြန်သွားသည်။
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// ပေးထားသောယုတ္တိဒြပ်စင်အညွှန်းအတွက်အခြေခံကြားခံအညွှန်းကိုပြန်ပို့သည်။
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// ပေးထားသော logical element index + addend အတွက်နောက်ခံ buffer ရှိ index ကို return လုပ်တယ်။
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// ပေးထားသော logical element index, subtrahend အတွက်အခြေခံ buffer ထဲမှာ index ကို return လုပ်တယ်။
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// src မှ dst အထိရှည်လျားသောမှတ်ဥာဏ်ပမာဏကိုတစ်ပြိုင်တည်းကူးယူသည်
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// src မှ dst အထိရှည်လျားသောမှတ်ဥာဏ်ပမာဏကိုတစ်ပြိုင်တည်းကူးယူသည်
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// src မှ dest သို့ကြာရှည်စွာသိမ်းဆည်းထားနိုင်သောမှတ်ဥာဏ်ပမာဏကိုမိတ္တူကူးရန်။
    /// (abs(dst - src) + len) သည် cap() ထက်မကြီးရမည် (src နှင့် dest အကြားအဆက်မပြတ်ထပ်နေသည့်ဒေသတစ်ခုရှိရမည်)
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src သည်မပတ်ပါ၊
                //
                //        S။။
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _]: D ။
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // src မတိုင်မီ dst, src သည်မပတ်ပါ၊ dst ထုပ်သည်
                //
                //
                //    S။။
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. : D ။
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // dst မတိုင်မီ src၊ src သည်ပတ်သတ်ခြင်းမရှိပါ၊
                //
                //
                //              S။။
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. : D ။
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // src မတိုင်မီ dst, src ထုပ်ပိုးပြီး dst သည်မဖုံးပါ
                //
                //
                //    .. S
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C]: D ။။။
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // dst မတိုင်မီ src၊ src ပတ်ရစ်သည်
                //
                //
                //    .. S
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C]: D ။။။
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // src မတိုင်မီ dst, src ထုပ်၊ DST ထုပ်
                //
                //
                //    ။.. S
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. : D ။။
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // dst မတိုင်မီ src, src ထုပ်၊ DST ထုပ်
                //
                //
                //    .. S။
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G] ။.. D
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// ကျနော်တို့ပြန်လည်ခွဲဝေသတ်မှတ်ထားသည်ဟူသောအချက်ကိုကိုင်တွယ်ရန်ခေါင်းနှင့်အမြီးအပိုင်းများကိုလှည့်ပတ်ထားသည်။
    /// မလုံခြုံသောကြောင့် old_capacity ကိုယုံကြည်သောကြောင့်ဖြစ်သည်။
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // TH လက်စွပ်ကြားခံ၏အတိုဆုံးတဆက်တည်းအပိုင်းရွှေ့ပါ
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [။။။ooooooo ။။။။။။
        //          ] HT
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // Nop
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// တစ် ဦး အချည်းနှီးသော `VecDeque` ဖန်တီး။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// အနည်းဆုံး `capacity` ဒြပ်စင်များအတွက်အာကာသပါသည့်အချည်းနှီးသော `VecDeque` ကိုဖန်တီးသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1 ဘာလို့လဲဆိုတော့ ringbuffer ဟာ space တစ်ခုအမြဲတမ်းအမြဲတမ်းရှိနေတယ်
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// ပေးထားသောအညွှန်းကိန်းမှာဒြပ်စင်တစ်ခုရည်ညွှန်းပေးသည်။
    ///
    /// index 0 မှာရှိတဲ့ Element ဟာ Queue ရဲ့အရှေ့ဘက်ပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// ပေးထားသောအညွှန်းကိန်းမှာဒြပ်စင်တစ်ခု mutable ရည်ညွှန်းသည်။
    ///
    /// index 0 မှာရှိတဲ့ Element ဟာ Queue ရဲ့အရှေ့ဘက်ပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// ဒြပ်စင်ညွှန်းကိန်း `i` နှင့် `j` မှာဖလှယ်။
    ///
    /// `i` နှင့် `j` တန်းတူဖြစ်နိုင်သည်။
    ///
    /// index 0 မှာရှိတဲ့ Element ဟာ Queue ရဲ့အရှေ့ဘက်ပါ။
    ///
    /// # Panics
    ///
    /// တစ်ခုခုကိုညွှန်းကိန်းဘောငျထဲကဖြစ်ပါတယ်လျှင် Panics ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// `VecDeque` သည်ခွဲဝေချထားခြင်းမရှိဘဲသိမ်းထားနိုင်သောဒြပ်စင်အရေအတွက်ကိုပြန်ပို့သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// ပေးထားသော `VecDeque` တွင်ထည့်သွင်းရမည့်ဒြပ်စင်များအတိအကျ `additional` အတွက်အနည်းဆုံးစွမ်းရည်ကိုထိန်းသိမ်းသည်။
    /// စွမ်းရည်ပြီးသားလျှင်ဘာမျှမလုပ်။
    ///
    /// ခွဲဝေချထားပေးသူသည်စုဆောင်းမှုကိုသူတောင်းလိုသောနေရာထက်ပိုပေးနိုင်ကြောင်းသတိပြုပါ။
    /// ထို့ကြောင့်စွမ်းရည်ကိုအတိအကျအနည်းဆုံးဖြစ်ရန်မမှီခိုနိုင်ပါ။
    /// future ထည့်သွင်းမှုများပြုလုပ်ရန်မျှော်လင့်ပါက [`reserve`] ကို ဦး စားပေးမည်။
    ///
    /// # Panics
    ///
    /// အသစ်ကစွမ်းရည် `usize` လျံလျှင် Panics ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// ပေးထားသော `VecDeque` တွင်အနည်းဆုံး `additional` ပိုသောဒြပ်စင်များအတွက်သိုလှောင်နိုင်စွမ်း။
    /// မကြာခဏပြန်လည်ခွဲဝေခြင်းများကိုရှောင်ရှားရန်စုဆောင်းခြင်းသည်နေရာပိုယူနိုင်သည်။
    ///
    /// # Panics
    ///
    /// အသစ်ကစွမ်းရည် `usize` လျံလျှင် Panics ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// ပေးထားသော `VecDeque<T>` တွင်ထည့်သွင်းရန်ပိုသော `additional` ဒြပ်စင်အတိအကျအတွက်အနည်းဆုံးစွမ်းရည်ကိုကြိုတင်ယူထားရန်ကြိုးစားသည်။
    ///
    /// `try_reserve_exact` ကိုခေါ်ပြီးနောက်စွမ်းရည်သည် `self.len() + additional` ထက်ကြီးသည်သို့မဟုတ်ညီမျှသည်။
    /// စွမ်းရည်ပြီးသားလျှင်ဘာမျှမလုပ်။
    ///
    /// ခွဲဝေချထားပေးသူသည်စုဆောင်းမှုကိုသူတောင်းလိုသောနေရာထက်ပိုပေးနိုင်ကြောင်းသတိပြုပါ။
    /// ထို့ကြောင့်စွမ်းရည်သည်အတိအကျအနည်းဆုံးဖြစ်ရန်မမှီခိုနိုင်ပါ။
    /// future ထည့်သွင်းမှုများပြုလုပ်ရန်မျှော်လင့်ပါက `reserve` ကို ဦး စားပေးမည်။
    ///
    /// # Errors
    ///
    /// အကယ်၍ စွမ်းဆောင်ရည်သည် `usize` ထက်ပိုလျှံနေလျှင်၊ သို့မဟုတ်ခွဲဝေချထားသူတစ် ဦး ကပျက်ကွက်ကြောင်းသတင်းပို့လျှင်၊ အမှားတစ်ခုကိုပြန်ပို့သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // မှတ်ဥာဏ်ကိုကြိုတင်စာရင်းသွင်းပါ
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // ယခုကျွန်ုပ်တို့ရှုပ်ထွေးသောအလုပ်များအလယ်တွင် OOM(Out-Of-Memory) သည်ဤအရာကိုမစွမ်းဆောင်နိုင်ကြောင်းကျွန်ုပ်တို့သိပြီ
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // အလွန်ရှုပ်ထွေး
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// ပေးထားသော `VecDeque<T>` တွင်ထည့်သွင်းရန်အနည်းဆုံး `additional` ထက်ပိုသောဒြပ်စင်များအတွက်စွမ်းရည်ကိုသိုလှောင်ရန်ကြိုးစားသည်။
    /// မကြာခဏပြန်လည်ခွဲဝေခြင်းများကိုရှောင်ရှားရန်စုဆောင်းခြင်းသည်နေရာပိုယူနိုင်သည်။
    /// `try_reserve` ကိုခေါ်ပြီးနောက်စွမ်းရည်သည် `self.len() + additional` ထက်ကြီးသည်သို့မဟုတ်ညီမျှသည်။
    /// စွမ်းရည်လုံလောက်ပြီးသားလျှင်ဘာမျှမလုပ်။
    ///
    /// # Errors
    ///
    /// အကယ်၍ စွမ်းဆောင်ရည်သည် `usize` ထက်ပိုလျှံနေလျှင်၊ သို့မဟုတ်ခွဲဝေချထားသူတစ် ဦး ကပျက်ကွက်ကြောင်းသတင်းပို့လျှင်၊ အမှားတစ်ခုကိုပြန်ပို့သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // မှတ်ဥာဏ်ကိုကြိုတင်စာရင်းသွင်းပါ
    ///     output.try_reserve(data.len())?;
    ///
    ///     // ယခုကျွန်ုပ်တို့ OOM သည်ကျွန်ုပ်တို့၏ရှုပ်ထွေးသောအလုပ်၏အလယ်တွင်မဖြစ်နိုင်ပါ
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // အလွန်ရှုပ်ထွေး
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// `VecDeque` ၏စွမ်းဆောင်ရည်ကိုတတ်နိုင်သမျှလျော့ကျစေသည်။
    ///
    /// ၎င်းသည်အရှည်ဖြစ်နိုင်သမျှနီးကပ်စွာကျဆင်းသွားမည်ဖြစ်သော်လည်း ထပ်မံ၍ အနည်းငယ်သောဒြပ်စင်များအတွက်နေရာရှိကြောင်းခွဲဝေချထားပေးသူသည် `VecDeque` သို့အကြောင်းကြားလိမ့်မည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// `VecDeque` ၏စွမ်းဆောင်ရည်နိမ့်ကျခြင်းနှင့်ချုံ့ခြင်း။
    ///
    /// စွမ်းဆောင်ရည်သည်အနည်းဆုံးအရှည်နှင့်ထောက်ပံ့ထားသောတန်ဖိုးနှစ်ခုလုံးအတိုင်းအတာအထိကြီးမားသည်။
    ///
    ///
    /// လက်ရှိစွမ်းရည်နိမ့်ဆုံးကန့်သတ်ထက်လျော့နည်းသည်ဆိုပါကဤသည်ကိုမ op ဖြစ်ပါတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // `self.len()` နှင့် `self.capacity()` တို့မှာ `usize::MAX` မဖြစ်နိုင်သဖြင့်အလွန်အကျွံစီးဆင်းနေခြင်းကိုကျွန်ုပ်တို့စိတ်ပူစရာမလိုပါ။
        // +1 သည် ringbuffer သည်တစ်နေရာတည်းတွင်အမြဲတမ်းနေရာလွတ်ဖြစ်နေသည်။
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // အကျိုးစီးပွားသုံးခုရှိပါတယ်:
            //   အားလုံးသောဒြပ်စင်များသည်တပ်မက်လိုချင်သောအကန့်အသတ်မရှိဖြစ်သည်။
            //
            //
            // အခြားအချိန်များ၌ element ရာထူးများကိုထိခိုက်ခြင်းမရှိပါ။
            //
            // ခေါင်းပေါ်က element တွေကိုရွှေ့သင့်တယ်ဆိုတာကိုပြတယ်။
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // element များကိုလိုချင်သောအကန့်အဝေးမှရွှေ့ပါ။
            if self.tail >= target_cap && head_outside {
                // TH
                //   [. . . . . . . . o o o o o o o . ]
                //    TH
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // TH
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// `VecDeque` ကိုအတိုကောက်၊ ပထမ ဦး ဆုံး `len` ဒြပ်စင်ကိုစောင့်ရှောက်။ ကျန်အရာများကိုကျဆင်းစေသည်။
    ///
    ///
    /// အကယ်၍ `len` သည် `VecDeque` ၏လက်ရှိအရှည်ထက်ကြီးလျှင်၎င်းသည်အကျိုးသက်ရောက်မှုမရှိပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// (ပုံမှန်အားဖြင့်သို့မဟုတ် unwinding နေစဉ်အတွင်း) သူကကျဆင်းသွားသည့်အခါအချပ်ရှိပစ္စည်းများအားလုံးကိုများအတွက် destructor ပြေး။
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // စိတ်ချရသောကြောင့်
        //
        // * `drop_in_place` သို့ဖြတ်သွားမဆိုအချပ်တရားဝင်သည်,ဒုတိယကိစ္စတွင် `len <= front.len()` ရှိပြီး `len > self.len()` တွင်ပြန်လာလျှင်ပထမဆုံးကိစ္စတွင် `begin <= back.len()` ကိုသေချာစေသည်
        //
        // * `drop_in_place` ကိုမခေါ်မီ VecDeque ၏ ဦး ခေါင်းကိုရွှေ့သည်၊ `drop_in_place` panics
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // ပထမ ဦး ဆုံး panics တွင်ဖျက်ဆီးသူဖြစ်သည့်တိုင်ဒုတိယထက်ဝက်ကျဆင်းသွားသည်ကိုသေချာပါစေ။
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// Front-to-back ကြားမှာ Iterator ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// mutable ကိုးကားချက်များကိုပြန်ပို့ပေးသော front-to-back ကြားဖြတ်ကိုပြန်ပို့သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // လုံခြုံမှု-အတွင်းပိုင်း `IterMut` လုံခြုံရေးလျော့ပါးသွားမည်
        // `ring` ငါတို့ဖန်တီးသည်တစ်သက်တာအတွက် dereferencable အချပ်ဖြစ်သည်။
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// `VecDeque` ရဲ့ပါ ၀ င်တဲ့အချပ်တစ်စုံကို return ပြန်ပေးတယ်။
    ///
    /// အကယ်၍ [`make_contiguous`] ကိုယခင်ကခေါ်ခဲ့ပါက `VecDeque` ၏ဒြပ်စင်အားလုံးသည်ပထမ ဦး ဆုံးအချပ်တွင်ရှိပြီးဒုတိယအပိုင်းသည်ဗလာဖြစ်သည်။
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// `VecDeque` ရဲ့ပါ ၀ င်တဲ့အချပ်တစ်စုံကို return ပြန်ပေးတယ်။
    ///
    /// အကယ်၍ [`make_contiguous`] ကိုယခင်ကခေါ်ခဲ့ပါက `VecDeque` ၏ဒြပ်စင်အားလုံးသည်ပထမ ဦး ဆုံးအချပ်တွင်ရှိပြီးဒုတိယအပိုင်းသည်ဗလာဖြစ်သည်။
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// `VecDeque` ထဲက element တွေရဲ့နံပါတ်ကို return ပြန်ပေးတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// အဆိုပါ `VecDeque` ဗလာလျှင် `true` ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// `VecDeque` တွင်သတ်မှတ်ထားသောအကွာအဝေးကိုဖုံးလွှမ်းထားသည့်ကြားဖြတ်တစ်ခုကိုဖန်တီးသည်။
    ///
    /// # Panics
    ///
    /// Panics သည်စမှတ်သည်အဆုံးမှတ်ထက်သာလွန်ပါကအဆုံးမှတ်သည် vector ၏အရှည်ထက်သာလွန်ပါက။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // အပြည့်အဝအကွာအဝေးအားလုံး contents တွေကိုဖုံးလွှမ်း
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // &self တွင်ကျွန်ုပ်တို့သုံးထားသောရည်ညွှန်းချက်သည် '_ Iter' တွင်တည်ရှိသည်။
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// `VecDeque` တွင်သတ်မှတ်ထားသောပြောင်းလဲနိုင်သောအကွာအဝေးကိုဖုံးအုပ်ထားသည့်ကြားဖြတ်တစ်ခုကိုဖန်တီးသည်။
    ///
    /// # Panics
    ///
    /// Panics သည်စမှတ်သည်အဆုံးမှတ်ထက်သာလွန်ပါကအဆုံးမှတ်သည် vector ၏အရှည်ထက်သာလွန်ပါက။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // အပြည့်အဝအကွာအဝေးအားလုံး contents တွေကိုဖုံးလွှမ်း
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // လုံခြုံမှု-အတွင်းပိုင်း `IterMut` လုံခြုံရေးလျော့ပါးသွားမည်
        // `ring` ငါတို့ဖန်တီးသည်တစ်သက်တာအတွက် dereferencable အချပ်ဖြစ်သည်။
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// `VecDeque` အတွင်းရှိသတ်မှတ်ထားသောအကွာအဝေးကိုဖယ်ရှားပြီးဖယ်ရှားပစ်လိုက်သောပစ္စည်းများအားထုတ်ပေးသည့်ရေယိုစီးမှုကိုပြန်လည်ဖန်တီးပေးသည်။
    ///
    /// မှတ်ချက် ၁။ ကြားဖြတ်အဆုံးမကုန်မှီတိုင်အောင် element element ကိုဖယ်ထုတ်သည်။
    ///
    /// မှတ်ချက် ၂။ `Drain` တန်ဖိုးကျဆင်းခြင်းမဟုတ်ပါ၊ သို့သော်သူပိုင်ဆိုင်သောချေးငွေသည်သက်တမ်းကုန်ဆုံးမည် (ဥပမာ `mem::forget` ကြောင့်) သည် deque မှမည်မျှသောဒြပ်စင်များအားဖယ်ရှားသည်ကိုအတိအကျမသိရသေးပါ။
    ///
    ///
    /// # Panics
    ///
    /// Panics သည်စမှတ်သည်အဆုံးမှတ်ထက်သာလွန်ပါကအဆုံးမှတ်သည် vector ၏အရှည်ထက်သာလွန်ပါက။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // အပြည့်အဝအကွာအဝေးအားလုံးကို contents တွေကိုရှင်းလင်း
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // မှတ်ဉာဏ်လုံခြုံမှု
        //
        // Drain ကိုပထမဆုံးအကြိမ်ပြုလုပ်သောအခါ Drain ၏ဖျက်ဆီးခြင်းသည်ဘယ်သောအခါမျှ run မည်ဆိုလျှင်မည်သည့်အချက်မှမသိရှိရသေးသောသို့မဟုတ်ရွှေ့ပြောင်းသွားသောအရာများလုံးဝမရောက်ရှိစေရန် source deque ကိုအတိုကောက်ဖြစ်သည်။
        //
        //
        // ဖယ်ရှားရန်တန်ဖိုးများကို Drain က ptr::read ထုတ်လိမ့်မည်။
        // ပြီးဆုံးသောအခါကျန်ရှိသောအချက်အလက်များကိုအပေါက်ကိုဖုံးရန်ပြန်ကူးပါလိမ့်မည်။ head/tail တန်ဖိုးများကိုမှန်မှန်ကန်ကန်ပြန်လည်ထားရှိမည်။
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // Deque ၏ဒြပ်စင်များကိုအပိုင်းသုံးပိုင်းခွဲထားသည်။
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // T က= self.tail;H= self.head;t=drain_tail;ဇ=drain_head
        //
        // drain_tail ကို self.head, drain_head နှင့် self.head ကို Drain တွင် after_tail နှင့် after_head အဖြစ်သိမ်းထားသည်။
        // Drain ပေါက်ကြားလျှင် drain စတင်ပြီးနောက်တန်ဖိုးရှိသောရွေ့လျားတန်ဖိုးများကိုမေ့သွားသည်ထိထိရောက်သောခင်းကျင်းမှုကိုလည်းဤအချက်ကဖြတ်စေသည်။
        //
        //
        //        H ကြိမ်မြောက်
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" အဆိုပါ drain ပြီးပြည့်စုံသည်နှင့် Drain ဖျက်ဆီးခြင်းပြေးပြီးနောက်သည်အထိ drain ၏ start ပြီးနောက်တန်ဖိုးများအကြောင်းကို။
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // အရေးကြီးသည်မှာကျွန်ုပ်တို့သည် `self` မှမျှဝေထားသောရည်ညွှန်းချက်များကိုသာဤနေရာတွင်ဖန်တီးပြီးဖတ်ရှုခြင်းဖြစ်သည်။
                // ကျွန်ုပ်တို့သည် `self` သို့မရေးပါ၊
                // ထို့ကြောင့် `deque` အတွက်အထက်တွင်ကျွန်ုပ်တို့ဖန်တီးခဲ့သော raw pointer သည်ခိုင်မာနေဆဲဖြစ်သည်။
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// တန်ဖိုးအားလုံးကိုဖယ်ရှား။ `VecDeque` ကိုရှင်းလင်းသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// အကယ်၍ `VecDeque` တွင်ပေးထားသောတန်ဖိုးနှင့်တူညီသော element တစ်ခုပါ ၀ င်ပါက `true` ကိုပြန်သွားသည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// `VecDeque` ဗလာလျှင်ရှေ့ element သို့ရည်ညွှန်းသည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// `VecDeque` သည်ဗလာလျှင်ရှေ့ element သို့ပြောင်းနိုင်သောရည်ညွှန်းချက်သို့မဟုတ် `None` ကိုထောက်ပံ့ပေးသည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// `VecDeque` ဗလာဖြစ်လျှင် back element သို့မဟုတ် `None` ကိုရည်ညွှန်းသည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// `VecDeque` ဗလာဖြစ်လျှင် back element သို့ပြောင်းသွားသည့်ရည်ညွှန်းချက်သို့မဟုတ် `None` ကိုပေးသည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// ပထမ element ကိုဖယ်ထုတ်ပြီး `VecDeque` သည်ဗလာလျှင် `None` သို့ပြန်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// `VecDeque` မှနောက်ဆုံး element ကိုဖယ်ထုတ်ပြီး၎င်းသည်ဗလာလျှင် `None` သို့ပြန်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// `VecDeque` အတွက် element တစ်ခုကိုပြင်ဆင်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// `VecDeque` ရဲ့နောက်ဘက်မှာ Element တစ်ခုထည့်သွင်းထားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: `head == 0` ကိုဆိုလိုတာလား
        // ကြောင်း `self` တဆက်တည်းဖြစ်သနည်း
        self.tail <= self.head
    }

    /// element တစ်ခုကို `VecDeque` ၏ဘယ်နေရာမှမဆိုဖယ်ရှားပြီးပထမဆုံး element နဲ့အစားထိုးလိုက်သည်။
    ///
    ///
    /// ဤသည်သာသနာကိုထိန်းသိမ်းထားသည်မဟုတ်,*အို*(1) ဖြစ်ပါတယ်။
    ///
    /// `index` သည်သတ်မှတ်ချက်များမရှိလျှင် `None` ကိုပြန်ပို့သည်။
    ///
    /// index 0 မှာရှိတဲ့ Element ဟာ Queue ရဲ့အရှေ့ဘက်ပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// element တစ်ခုကို `VecDeque` ၏မည်သည့်နေရာမှမဆိုဖယ်ရှားပြီးနောက်ဆုံး element ဖြင့်အစားထိုးလိုက်သည်။
    ///
    ///
    /// ဤသည်သာသနာကိုထိန်းသိမ်းထားသည်မဟုတ်,*အို*(1) ဖြစ်ပါတယ်။
    ///
    /// `index` သည်သတ်မှတ်ချက်များမရှိလျှင် `None` ကိုပြန်ပို့သည်။
    ///
    /// index 0 မှာရှိတဲ့ Element ဟာ Queue ရဲ့အရှေ့ဘက်ပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// element တစ်ခုလုံးကို `index` အတွင်းရှိ `index` တွင်ထည့်သည်။ `index` ထက်ကြီးသောသို့မဟုတ်ညီမျှသောအညွှန်းများကိုနောက်ဖက်သို့ ဦး တည်လိုက်သည်။
    ///
    ///
    /// index 0 မှာရှိတဲ့ Element ဟာ Queue ရဲ့အရှေ့ဘက်ပါ။
    ///
    /// # Panics
    ///
    /// `index` VecDeque` ၏အရှည်ထက်ကြီးလျှင် Panics
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // ring buffer ထဲမှအနည်းဆုံး element တွေကိုရွှေ့ပြီးပေးထားတဲ့ object ကိုထည့်ပါ
        //
        // len/2 အများစုတွင် element ၁ ခုကိုရွေ့လိမ့်မည်။ O(min(n, n-i))
        //
        // အဓိကရောဂါသုံးမျိုးရှိပါသည်။
        //  ဒြပ်စင်များတဆက်တည်းဖြစ်ကြသည်
        //      - အထူး ၀ င်ရိုးစွန်း 0 ဖြစ်ချိန်တွင် Element များပြတ်တောက်ပြီး၊ ထည့်သွင်းမှုသည် tail section တွင်ဖြစ်သည်။ Element များသည် discontiguous ဖြစ်ပြီးထည့်သွင်းမှုသည် head section တွင်ဖြစ်သည်။
        //
        //
        // သူတို့အသီးအသီးအဘို့နောက်ထပ်နှစ်ခုဖြစ်ပွားမှုရှိပါတယ်:
        //  Insert သည်အမြီးနှင့်နီးသည်။ Insert သည်ခေါင်းနှင့်နီးသည်
        //
        // Key ကို: H ကို, self.head
        //      T, self.tail o, Valid element I, Insertion element A, Insertion point M ပြီးနောက်ဖြစ်သင့်သော element သည် element ရွေ့သွားသည်ကိုဖော်ပြသည်
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [တစ် ဦး က oooooo ။။။။။။။
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // တဆက်တည်း, အမြီးမှပိုမိုနီးကပ်စွာထည့်ပါ
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           TH
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // တဆက်တည်း, အမြီးနှင့်အမြီးမှပိုမိုနီးကပ်စွာထည့်သွင်း 0:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       MM

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // အမြီးကိုပြောင်းထားပြီးဖြစ်သောကြောင့်ကျွန်ုပ်တို့သည် `index - 1` element များကိုသာကူးယူသည်။
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // တဆက်တည်း, ဦး ခေါင်းမှပိုမိုနီးကပ်စွာထည့်သွင်း:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o I A o o . . . . .]
                    //                       MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // အဆက်အသွယ်ပြတ်သည်အမြီးနှင့်နီးစပ်သောအမြီးအပိုင်း၊
                    //
                    //                   HTI
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // discontiguous, ခေါင်းနှင့်ပိုမိုနီးကပ်စွာထည့်ပါ၊ အမြီးအပိုင်း-
                    //
                    //           HTI
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       MMMM

                    // အသစ်သော ဦး ခေါင်းမှ element တွေကိုကူးယူပါ
                    self.copy(1, 0, self.head);

                    // နောက်ဆုံး element ကိုကြားခံ၏အောက်ခြေတွင်အချည်းနှီးသောအစက်အပြောက်သို့ကူးယူပါ
                    self.copy(0, self.cap() - 1, 1);

                    // ^ element အပါအဝင်မဟုတ်ရှေ့ဆက်အဆုံးသတ်မှ idx ကနေ element တွေကိုရွှေ့ပါ
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // discontiguous, insert သည်အမြီး၊ ခေါင်းအပိုင်းနှင့်ပိုမိုနီးကပ်သည်။
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               MMM

                    // ဒြပ်စင်အသစ်များကိုအမြီးအထိကူးယူပါ
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // နောက်ဆုံး element ကိုကြားခံ၏အောက်ခြေတွင်အချည်းနှီးသောအစက်အပြောက်သို့ကူးယူပါ
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // အလိုအလျောက်ဖြစ်ခြင်း, အမြီးနှင့်နီးစပ်သောထည့်သွင်း, ဦး ခေါင်းအပိုင်း:
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       MMMMMM

                    // ဒြပ်စင်အသစ်များကိုအမြီးအထိကူးယူပါ
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // နောက်ဆုံး element ကိုကြားခံ၏အောက်ခြေတွင်အချည်းနှီးသောအစက်အပြောက်သို့ကူးယူပါ
                    self.copy(self.cap() - 1, 0, 1);

                    // ^ element အပါအဝင်မရှေ့ဆက်အဆုံးသတ် idx-1 ကနေ element တွေကိုရွှေ့ပါ
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // discontiguous, ခေါင်းကိုပိုမိုနီးကပ်စွာထည့်သွင်း ဦး ခေါင်းအပိုင်း:
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // အမြီးကိုအပြောင်းအလဲရှိကောင်းရှိလိမ့်မယ်
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// `VecDeque` မှ element ကိုဖယ်ရှားပြီးပြန်လည်ပေးသည်။
    /// မည်သည့်အဆုံးသည်ဖယ်ရှားရေးအမှတ်နှင့်ပိုမိုနီးကပ်သည်ဖြစ်စေအခန်းကိုပြောင်းရွှေ့လိမ့်မည်။
    ///
    /// `index` သည်သတ်မှတ်ချက်များမရှိလျှင် `None` ကိုပြန်ပို့သည်။
    ///
    /// index 0 မှာရှိတဲ့ Element ဟာ Queue ရဲ့အရှေ့ဘက်ပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // အဓိကရောဂါသုံးမျိုးရှိပါသည်။
        //  Element များသည်တသမတ်တည်းဖြစ် Element များသည်မတည့်ခြင်းနှင့်ဖယ်ရှားခြင်းအား tail section တွင်တွေ့ရှိနိုင်သည်။ Element များသည် discontiguous ဖြစ်ပြီးဖယ်ရှားခြင်းသည် head section တွင်ဖြစ်သည်။
        //
        //      - Element များနည်းပညာပိုင်းတဆက်တည်းဖြစ်တဲ့အခါအထူးအမှု, ဒါပေမယ့် self.head =0
        //
        // သူတို့အသီးအသီးအဘို့နောက်ထပ်နှစ်ခုဖြစ်ပွားမှုရှိပါတယ်:
        //  Insert သည်အမြီးနှင့်နီးသည်။ Insert သည်ခေါင်းနှင့်နီးသည်
        //
        // Key ကို: H ကို, self.head
        //      T, self.tail o, Valid element x, R ကိုဖယ်ရှားရန်အတွက်မှတ်သားထားသော Element, M ကိုဖယ်ရှားနေသည့် element ကိုညွှန်ပြ, element ကိုပြောင်းရွှေ့ခဲ့သည်ကိုညွှန်ပြ
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // တဆက်တည်း, အမြီးမှပိုမိုနီးကပ်စွာဖယ်ရှားပါ:
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               TH
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // တဆက်တည်း ဦး ခေါင်းမှပိုမိုနီးကပ်စွာဖယ်ရှားပါ:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // အဆက်ပြတ်, အမြီးနှင့်ပိုမိုနီးကပ်စွာဖယ်ရှားအမြီးအပိုင်း:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // discontiguous, ခေါင်းကိုပိုမိုနီးကပ်စွာဖယ်ရှား ဦး ခေါင်းအပိုင်း:
                    //
                    //               RHT
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // အငြင်းပွားမှုဖြစ်ခြင်း၊ ခေါင်းနှင့်ပိုမိုနီးကပ်စွာအမြီးအပိုင်းကိုဖယ်ရှားပါ။
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       MMMM
                    //
                    // သို့မဟုတ်အမည်ခံပြတ်ပြတ်သားသား, အမြီးအပိုင်း, နောက်ဘေးဖယ်ဖယ်:
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         TH
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // အမြီးအပိုင်းအတွက်ဒြပ်စင်အတွက်ဆွဲပါ
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // underflow ကာကွယ်ပေးသည်။
                    if self.head != 0 {
                        // ပထမဆုံး element ကိုဗားရှင်းအလွတ်သို့ကူးယူပါ
                        self.copy(self.cap() - 1, 0, 1);

                        // နောက်ပြန် ဦး ခေါင်းအပိုင်းအတွက်ဒြပ်စင်ရွှေ့ပါ
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // အငြင်းပွားဖွယ်, အမြီးပိုမိုနီးကပ်စွာဖယ်ရှား ဦး ခေါင်းအပိုင်း:
                    //
                    //           RHT
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       MMMMM

                    // element တွေကို idx အထိဆွဲပါ
                    self.copy(1, 0, idx);

                    // နောက်ဆုံးဒြပ်စင်အချည်းနှီးသောအစက်အပြောက်သို့ကူးယူပါ
                    self.copy(0, self.cap() - 1, 1);

                    // ဒြပ်စင်များကိုအမြီးမှအဆုံးသို့ရွှေ့သည်
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// ပေးထားသောအညွှန်းကိန်းမှာ `VecDeque` ကိုနှစ်ခုခွဲလိုက်တယ်။
    ///
    /// အသစ်တစ်ခုကိုခွဲဝေ `VecDeque` ပြန်သွားသည်။
    /// `self` ဒြပ်စင် `[0, at)` ပါရှိသည်, နှင့်ပြန်လာသော `VecDeque` ဒြပ်စင် `[at, len)` ပါရှိသည်။
    ///
    /// သတိပြုရမည်မှာ `self` ၏စွမ်းရည်သည်မပြောင်းလဲပါ။
    ///
    /// index 0 မှာရှိတဲ့ Element ဟာ Queue ရဲ့အရှေ့ဘက်ပါ။
    ///
    /// # Panics
    ///
    /// `at > len` လျှင် Panics ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` ပထမနှစ်ဝက်တွင်တည်ရှိသည်။
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // ကိုယ့်ဒုတိယတစ်ဝက်အပေါငျးတို့သယူပါ။
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` ဒုတိယတစ်ဝက်တွင်ရှိသည်၊ ကျွန်ုပ်တို့ပထမတစ်ဝက်တွင်ကျော်သွားသည့်ဒြပ်စင်များကိုထည့်သွင်းရန်လိုအပ်သည်။
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // ကြားခံ၏အဆုံးရှိရာသန့်ရှင်းရေး
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// `other` ၏ element အားလုံးကို `self` သို့ရွှေ့ပြီး `other` ဗလာဖြစ်နေသည်။
    ///
    /// # Panics
    ///
    /// ကိုယ့်ကိုယ်ကိုအတွက်ဒြပ်စင်အသစ်အရေအတွက် `usize` လျတ်လျှင် Panics ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // နိဗ္ဗာန်
        self.extend(other.drain(..));
    }

    /// အဆိုပါ predicate အားဖြင့်သတ်မှတ်ထားသောသာဒြပ်စင်ဆက်လက်ထိန်းသိမ်းထားသည်။
    ///
    /// တနည်းအားဖြင့် `e` element အားလုံးကိုဖယ်ထုတ်လိုက်ပါ။
    /// ဤနည်းသည်မူလနေရာတွင်တစ်နေရာစီသို့တစ်ကြိမ်တည်းသွားခြင်း၊ နေရာတစ်ခုသို့လည်ပတ်ခြင်းနှင့်ထိန်းသိမ်းထားသောဒြပ်စင်များ၏အစီအစဉ်ကိုထိန်းသိမ်းခြင်းဖြစ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// အမိန့်အတိအကျသည်အညွှန်းတစ်ခုကဲ့သို့ပြင်ပအခြေအနေကိုခြေရာခံရန်အသုံးဝင်သည်။
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // ဤသည် panic သို့မဟုတ်ဖျက်သိမ်းလိမ့်မည်
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // ကြားခံအရွယ်အစားကိုနှစ်ဆ။
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// `len()` သည် `new_len` နှင့်ညီမျှစေရန်အတွက်နေရာတွင် `VecDeque` ကိုပြုပြင်သည်။ ပိုသော element များကိုကျောဘက်မှဖယ်ထုတ်ခြင်းဖြင့်လည်းကောင်း၊ `generator` ကိုနောက်သို့ခေါ်ခြင်းဖြင့်ထုတ်ပေးသော element များကိုပေါင်းခြင်းဖြင့်လည်းကောင်းဖြစ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// ဒီ deque ၏အတွင်းပိုင်းသိုလှောင်မှုကိုပြန်လည်စီစဉ်သည်ဒါကြောင့်တ ဦး တည်းတဆက်တည်းအချပ်, ထို့နောက်ပြန်လာသော။
    ///
    /// ဤနည်းလမ်းသည်ခွဲဝေထားခြင်းမရှိပါ၊ ဖြည့်ထားသောဒြပ်စင်များ၏အစီအစဉ်ကိုမပြောင်းလဲပါ။၎င်းသည် mutable slice တစ်ခုကို return ပြန်သောအခါ၎င်းသည် deque တစ်ခုကို sort လုပ်ရန်အသုံးပြုနိုင်သည်။
    ///
    /// Internal Storage သည်တပြိုင်နက်တည်းဖြစ်သွားသည်နှင့်တပြိုင်နက် [`as_slices`] နှင့် [`as_mut_slices`] နည်းလမ်းများသည် `VecDeque` ၏ပါဝင်မှုတစ်ခုလုံးကိုအချပ်တစ်ခုတည်းသို့ပြန်ပို့လိမ့်မည်။
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// တစ် ဦး deque ၏အကြောင်းအရာ sorting ။
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // အဆိုပါ deque sorting
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // ပြောင်းပြန်နိုင်ရန်အတွက် sorting
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// အဆိုပါတဆက်တည်းအချပ်မှမပြောင်းလဲနိုင်သောအရာများဝင်ရောက်ခွင့်ရယူခြင်း။
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // ယခုတွင် `slice` တွင် `buf` ကိုမပြောင်းလဲနိုင်သောအရာများရှိနေစဉ် Deque ၏ဒြပ်စင်အားလုံးပါ ၀ င်သည်ကိုကျွန်ုပ်တို့သေချာစွာသိနိုင်ပါသည်။
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // အမြီးကိုတစ်ချက်တည်းဖြင့်ကူးယူရန်နေရာအလုံအလောက်ရှိသည်။ ဆိုလိုသည်မှာကျွန်ုပ်တို့သည် ဦး ခေါင်းကို ဦး စွာနောက်သို့ရွှေ့လိုက်ပြီးအမြီးကိုမှန်ကန်သောအနေအထားသို့ကူးယူခြင်းဖြစ်သည်။
            //
            //
            // မှ: DEFGH .... ABC ရုပ်သံ
            // ရန်: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: ကျနော်တို့လက်ရှိစဉ်းစားကြဘူး .... ABCDEFGH
            // `head` ဤကိစ္စတွင်အတွက် `0` ဖြစ်လိမ့်မည်ဖြစ်သောကြောင့်တဆက်တည်းဖြစ်။
            // ကျွန်ုပ်တို့ဤအရာကိုပြောင်းလဲချင်သော်လည်း `is_contiguous` က `buf[tail..head]` ကိုသုံးပြီးဖြတ်နိုင်သည်ဟုအနည်းငယ်သောနေရာများကမျှော်လင့်နေသောကြောင့်အသေးအဖွဲမဟုတ်ပါ။
            //
            //

            // ဦး ခေါင်းကိုတစ်ချက်တည်းဖြင့်ကူးယူရန်နေရာအလုံအလောက်ရှိသည်။ ဆိုလိုသည်မှာကျွန်ုပ်တို့သည် ဦး စွာအမြီးကိုရှေ့သို့ရွှေ့ပြီးနောက် ဦး ခေါင်းကိုမှန်ကန်သောအနေအထားသို့ကူးယူခြင်းဖြစ်သည်။
            //
            //
            // မှ: FGH .... ABCDE
            // ရန်: ... ABCDEFGH ။
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // အခမဲ့သည် ဦး ခေါင်းနှင့်အမြီးနှစ်ခုလုံးထက်သေးငယ်သည်၊ ဆိုလိုသည်မှာကျွန်ုပ်တို့သည်အမြီးနှင့် ဦး ခေါင်းကိုဖြည်းဖြည်းချင်း "swap" ရမည်ဖြစ်သည်။
            //
            //
            // မှ: EFGHI ... ABCD သို့မဟုတ် HIJK.ABCDEFG
            // ရန်: ABCDEFGHI ... သို့မဟုတ် ABCDEFGHIJK ။
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // အထွေထွေပြproblemနာသည်ဤ GHIJKLM ... ABCDEF နှင့်တူသည်။ ABCDEFM ... GHIJKL လဲလှယ်မှုမပြုလုပ်မီ၊ ၁ ချက်အပြောင်းအလဲလုပ်ပြီးနောက် ABCDEFGHIJM ... KL၊ ဘယ်လက် edge သည် temp စတိုးသို့ရောက်သည်အထိလဲလှယ်သည်။
                //                  - ထို့နောက် (smaller) store အသစ်နှင့်အတူ algorithm ကို restart လုပ်ပါ။ တစ်ခါတစ်ရံတွင် edge သည်ကြားခံ၏အဆုံးတွင်ရှိသည့် temp store ကိုရောက်သည်။ ဆိုလိုသည်မှာကျွန်ုပ်တို့သည်လဲမှုနည်းပါးသော swap များဖြင့်မှန်ကန်သောအမိန့်ကိုထိတွေ့လိုက်ပြီဖြစ်သည်။
                //
                // E.g
                // EF..ABCD ABCDEF .. လေးချက်သာလဲလှယ်ပြီးပါပြီ
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// နှစ်ဆတန်းစီ `mid` နေရာများကိုဘယ်ဘက်သို့လှည့်သည်။
    ///
    /// Equivalently,
    /// - item ကို `mid` ပထမ ဦး ဆုံးအနေအထားသို့လှည့်။
    /// - ပထမဆုံး `mid` ပစ္စည်းများပေါ်လာပြီးသူတို့ကိုအဆုံးသို့တွန်းပို့သည်။
    /// - `len() - mid` ကိုညာဘက်နေရာများလှည့်။
    ///
    /// # Panics
    ///
    /// `mid` `len()` ထက်သာ။ ကြီးမြတ်လျှင်။
    /// `mid == len()` _not_ panic ကိုလုပ်ပြီး op-rotation လုပ်သည်ကိုသတိပြုပါ။
    ///
    /// # Complexity
    ///
    /// `*O*(min(mid, len() - mid))` အချိန်နှင့်အပိုနေရာမရှိပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// နှစ်ဆတန်းစီ `k` နေရာများကိုညာဘက်သို့လှည့်သည်။
    ///
    /// Equivalently,
    /// - ပထမ ဦး ဆုံးကိုအနေအထား `k` သို့လှည့်။
    /// - နောက်ဆုံး `k` ပစ္စည်းများပေါ်လာပြီးသူတို့ကိုရှေ့သို့တွန်းပို့သည်။
    /// - ဘယ်ဘက်သို့ `len() - k` သောနေရာများလှည့်။
    ///
    /// # Panics
    ///
    /// `k` `len()` ထက်သာ။ ကြီးမြတ်လျှင်။
    /// `k == len()` _not_ panic ကိုလုပ်ပြီး op-rotation လုပ်သည်ကိုသတိပြုပါ။
    ///
    /// # Complexity
    ///
    /// `*O*(min(k, len() - k))` အချိန်နှင့်အပိုနေရာမရှိပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // လုံခြုံမှု-အောက်ပါနည်းနှစ်နည်းဖြင့်လည်ပတ်ရန်လိုအပ်သည်
    // အဆိုပါ deque ၏ထက်ဝက်ကျော်အရှည်ဖြစ်လိမ့်မည်။
    //
    // `wrap_copy` `min(x, cap() - x) + copy_len <= cap()` ကိုလိုအပ်တယ်၊ ဒါပေမယ့် `min` ထက် x ဘယ်လောက်ပဲစွမ်းဆောင်ရည်ထက်ဝက်ကျော်မပိုဘူး။ ဒါကြောင့်ဒီနေရာမှာခေါ်ဆိုသင့်တယ်၊ ဘာလို့လဲဆိုတော့ကျွန်တော်တို့ကအရှည်တစ်ဝက်ထက်နည်းသောအရာနှင့်ခေါ်ဆိုခြင်းဖြစ်သည်၊
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// Binary သည်ဤအမျိုးအစားအလိုက် `VecDeque` ကိုရှာသည်။
    ///
    /// အကယ်၍ တန်ဖိုးကိုတွေ့ရှိပါက [`Result::Ok`] သည်သက်ဆိုင်ရာ element ၏ index ပါဝင်သော return ပြန်လာလိမ့်မည်။
    /// အကယ်၍ ပွဲများစွာရှိပါကမည်သည့်ပွဲကိုမဆိုပြန်ပေးနိုင်သည်။
    /// အကယ်၍ တန်ဖိုးကိုရှာမတွေ့ပါက၊ [`Result::Err`] သည်ပြန်လည်စီလိုက်ပြီးကိုက်ညီသောဒြပ်ထုကိုထည့်သွင်းနိုင်ပြီးအစဉ်လိုက်စီစဉ်ထားသည်။
    ///
    ///
    /// # Examples
    ///
    /// ဒြပ်စင်လေးခုဆက်တိုက်ကြည့်သည်။
    /// ပထမတစ်ခုမှာထူးခြားစွာဆုံးဖြတ်ထားသည့်အနေအထားဖြင့်ဖြစ်သည်။ဒုတိယနှင့်တတိယတွေ့ရှိမခံရ;စတုတ္ထ `[1, 4]` အတွက်မဆိုအနေအထားကိုက်ညီနိုင်ဘူး။
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// သင် sort order ကိုထိန်းသိမ်းနေစဉ် sorted `VecDeque` သို့ item တစ်ခုထည့်သွင်းလိုလျှင်:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// Binary သည်ဒီ sorted `VecDeque` ကို comparator function တစ်ခုဖြင့်ရှာဖွေသည်။
    ///
    /// နှိုင်းယှဉ်လုပ်ဆောင်ချက်သည်နောက်ခံရှိ `VecDeque` ၏အမျိုးအစားအစဉ်လိုက်နှင့်ကိုက်ညီသည့်အမိန့်ကိုအကောင်အထည်ဖော်သင့်သည်။ ၎င်းသည်အငြင်းအခုံသည်လိုချင်သောပစ်မှတ်ထက် `Less`, `Equal` သို့မဟုတ် `Greater` ဟုတ်မဟုတ်ညွှန်ပြသည့်အမိန့်ကုဒ်တစ်ခုကိုပြန်ပို့သည်။
    ///
    ///
    /// အကယ်၍ တန်ဖိုးကိုတွေ့ရှိပါက [`Result::Ok`] သည်သက်ဆိုင်ရာ element ၏ index ပါဝင်သော return ပြန်လာလိမ့်မည်။အကယ်၍ ပွဲများစွာရှိပါကမည်သည့်ပွဲကိုမဆိုပြန်ပေးနိုင်သည်။
    /// အကယ်၍ တန်ဖိုးကိုရှာမတွေ့ပါက၊ [`Result::Err`] သည်ပြန်လည်စီလိုက်ပြီးကိုက်ညီသောဒြပ်ထုကိုထည့်သွင်းနိုင်ပြီးအစဉ်လိုက်စီစဉ်ထားသည်။
    ///
    /// # Examples
    ///
    /// ဒြပ်စင်လေးခုဆက်တိုက်ကြည့်သည်။ပထမတစ်ခုမှာထူးခြားစွာဆုံးဖြတ်ထားသည့်အနေအထားဖြင့်ဖြစ်သည်။ဒုတိယနှင့်တတိယတွေ့ရှိမခံရ;စတုတ္ထ `[1, 4]` အတွက်မဆိုအနေအထားကိုက်ညီနိုင်ဘူး။
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// Binary သည်ဤစီထားသော `VecDeque` ကိုသော့ထုတ်ယူသောသော့တစ်ခုဖြင့်ရှာဖွေသည်။
    ///
    /// `VecDeque` သည်သော့ဖြင့်စီထားခြင်းဖြစ်သည်ဟုယူဆသည်၊ ဥပမာ [`make_contiguous().sort_by_key()`](#method.make_contiguous) နှင့်အတူတူပင်သော့ထုတ်ယူခြင်းလုပ်ငန်းကိုအသုံးပြုသည်။
    ///
    ///
    /// အကယ်၍ တန်ဖိုးကိုတွေ့ရှိပါက [`Result::Ok`] သည်သက်ဆိုင်ရာ element ၏ index ပါဝင်သော return ပြန်လာလိမ့်မည်။
    /// အကယ်၍ ပွဲများစွာရှိပါကမည်သည့်ပွဲကိုမဆိုပြန်ပေးနိုင်သည်။
    /// အကယ်၍ တန်ဖိုးကိုရှာမတွေ့ပါက၊ [`Result::Err`] သည်ပြန်လည်စီလိုက်ပြီးကိုက်ညီသောဒြပ်ထုကိုထည့်သွင်းနိုင်ပြီးအစဉ်လိုက်စီစဉ်ထားသည်။
    ///
    /// # Examples
    ///
    /// သူတို့ရဲ့ဒုတိယဒြပ်စင်များက sorted အားလုံးအတွက်တစ် ဦး အချပ်အတွက်လေးခုဒြပ်စင်တစ်ခုစီးရီးကိုတက်ကြည့်ရှုသည်။
    /// ပထမတစ်ခုမှာထူးခြားစွာဆုံးဖြတ်ထားသည့်အနေအထားဖြင့်ဖြစ်သည်။ဒုတိယနှင့်တတိယတွေ့ရှိမခံရ;စတုတ္ထ `[1, 4]` အတွက်မဆိုအနေအထားကိုက်ညီနိုင်ဘူး။
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// `len()` ကို in-place ပြုပြင်သည် `len()` သည် new_len နှင့်တူညီရန်နောက်ကျောမှပိုလျှံသော element များကိုဖယ်ရှားခြင်းအားဖြင့်ဖြစ်စေ၊
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// ပေးထားသောယုတ္တိဒြပ်စင်အညွှန်းအတွက်အခြေခံကြားခံအညွှန်းကိုပြန်ပို့သည်။
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // အရွယ်အစားကအမြဲတမ်း ၂ ပါဝါ
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// ကြားခံတွင်ဖတ်ရန်ကျန်ရှိသောဒြပ်စင်အရေအတွက်ကိုတွက်ချက်ပါ
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // အရွယ်အစားကအမြဲတမ်း ၂ ပါဝါ
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // အမြဲတမ်းသုံးပိုင်းခွဲခြားနိုင်သည်။ ဥပမာ: self: [a b c|d e f] other: [0 1 2 3|4 5] front=3, mid=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // as_slices method ဖြင့်ပြန်လာသောချပ်များပေါ်တွင် Hash::hash_slice ကိုအသုံးပြုရန်မဖြစ်နိုင်ပါ။ အဘယ်ကြောင့်ဆိုသော်သူတို့၏အရှည်သည်တူညီသောကွာခြားချက်များကွဲပြားနိုင်သည်။
        //
        //
        // Hasher သည်၎င်း၏ method များနှင့်တူညီသောဖုန်းခေါ်ဆိုမှုများအတွက်တူညီမှုကိုသာအာမခံသည်။
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// element များကိုတန်ဖိုးအားဖြင့်အလျှော့ပေးလိုက်လျောသော front-to-back ကြားဖြတ်သို့ `VecDeque` ကိုအသုံးပြုသည်။
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // ဤလုပ်ဆောင်ချက်သည်ကိုယ်ကျင့်တရားနှင့်ညီညွတ်သင့်သည်။
        //
        //      iter.into_iter() အတွက် item အတွက်
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// [`Vec<T>`] ကို [`VecDeque<T>`] တစ်ခုအဖြစ်ပြောင်းပါ။
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// ၎င်းသည်ဖြစ်နိုင်သည့်နေရာများတွင်ပြန်လည်ခွဲဝေခြင်းကိုရှောင်ရှားသည်။ သို့သော်၎င်းအတွက်အခြေအနေများမှာတင်းကျပ်ပြီးပြောင်းလဲမှုနှင့်သက်ဆိုင်သည်။ `Vec<T>` `From<VecDeque<T>>` မှလာပြီးပြန်လည်ခွဲဝေသတ်မှတ်ခြင်းမရှိလျှင်၎င်းကိုအားမကိုးသင့်ပါ။
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // စွမ်းဆောင်ရည်နှင့် ပတ်သက်၍ စိုးရိမ်ရန် ZST များအတွက်အမှန်တကယ်ခွဲဝေချထားမှုမရှိသော်လည်း `VecDeque` သည် `Vec` ကဲ့သို့အရှည်ကိုမကိုင်တွယ်နိုင်ပါ။
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // အကယ်၍ စွမ်းရည်သည် ၂ ခုစွမ်းအားမဟုတ်ပါ၊ သေးငယ်လွန်းလျှင်သို့မဟုတ်အနည်းဆုံးလွတ်လပ်သောနေရာမရှိလျှင်ကျွန်ုပ်တို့အရွယ်အစားပြောင်းလဲရန်လိုသည်။
            // `Vec` ထဲမှာရှိနေတုန်းပါ။ ဒါဆိုရင်ပစ္စည်းတွေ panic မှာကျသွားလိမ့်မယ်။
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// [`VecDeque<T>`] ကို [`Vec<T>`] တစ်ခုအဖြစ်ပြောင်းပါ။
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// ဤသည်ကိုပြန်လည်ခွဲဝေရန်မလိုအပ်ပါ။ သို့သော် အကယ်၍ circular buffer သည်အစအ ဦး ၌ရှိနေခြင်းမရှိပါက *O*(*n*) data movement ကိုလုပ်ရန်လိုအပ်ပါသည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // ဒီတစ်ခု *အို*(1) ဖြစ်ပါတယ်။
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // ဒီတစ်ခုဒေတာပြန်လည်စီစဉ်လိုအပ်သည်။
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}