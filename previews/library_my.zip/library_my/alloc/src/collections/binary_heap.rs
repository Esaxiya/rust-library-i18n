//! တစ် ဦး က binary အမှိုက်ပုံနှင့်အတူအကောင်အထည်ဖော်တစ် ဦး က ဦး စားပေးတန်းစီ။
//!
//! အကြီးမားဆုံးဒြပ်စင်ကိုထည့်သွင်းခြင်းနှင့် popping လုပ်ခြင်းသည် *O*(log(*n*)) အချိန်ရှုပ်ထွေးမှုရှိသည်။
//! အကြီးဆုံးဒြပ်စင်ကိုစစ်ဆေးခြင်းသည် *အို*(၁) ဖြစ်သည်။vector တစ်ခုကို binary heap တစ်ခုသို့ပြောင်းလဲခြင်းသည် in-place လုပ်နိုင်ပြီးရှုပ်ထွေးသော *O*(*n*) ရှိသည်။
//! Binary အမှိုက်ပုံကိုလည်း in-place တစ်ခုစီထားသော vector သို့ပြောင်းလဲနိုင်သည်။ ၎င်းကို *O*(*n*\*log(* n*)) In-place heapsort) အတွက်အသုံးပြုနိုင်သည်။
//!
//! # Examples
//!
//! ဒါက X0 [directed graph][dir_graph] မှာ [shortest path problem][sssp] ကိုဖြေရှင်းဖို့ [Dijkstra's algorithm][dijkstra] ကိုအကောင်အထည်ဖော်တဲ့ပိုကြီးတဲ့ဥပမာတစ်ခု။
//!
//! ၎င်းသည် [`BinaryHeap`] ကိုစိတ်ကြိုက်အမျိုးအစားများနှင့်မည်သို့အသုံးပြုရမည်ကိုပြသည်။
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // ဦး စားပေးတန်းစီ `Ord` ပေါ်တွင်မူတည်သည်။
//! // trait ကိုတိတိကျကျအကောင်အထည်ဖော်ပါ၊ ထို့ကြောင့် queue သည် max-heap အစား min-heap ဖြစ်လာသည်။
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // ကျနော်တို့ကကုန်ကျစရိတ်အပေါ်အမိန့်လှန်သတိပြုပါ။
//!         // ကျနော်တို့ရာထူးနှိုင်းယှဉ်နေတဲ့လည်စည်း၏အမှု၌, ဒီအဆင့်ကို `PartialEq` နှင့် `Ord` ၏အကောင်အထည်ဖော်မှုတသမတ်တည်းဖြစ်စေရန်လိုအပ်သည်။
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` အကောင်အထည်ဖော်ရန်လိုအပ်သည်။
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // တိုတောင်းသောအကောင်အထည်ဖော်မှုအတွက် node တစ်ခုစီကို `usize` တစ်ခုအဖြစ်ဖော်ပြသည်။
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Dijkstra ရဲ့အတိုဆုံးလမ်းကြောင်း algorithm ။
//!
//! // `start` မှ စတင်၍ `dist` ကို အသုံးပြု၍ node တစ်ခုချင်းစီအတွက်လက်ရှိအတိုဆုံးအကွာအဝေးကိုခြေရာခံရန်။ဤအကောင်အထည်ဖော်မှုသည်မှတ်ဥာဏ်ကိုအကျိုးရှိစွာအသုံးမပြုပါ၊
//! //
//! // ရိုးရှင်းသောအကောင်အထည်ဖော်မှုအတွက်၎င်းသည် `usize::MAX` ကို sentinel value အဖြစ်အသုံးပြုသည်။
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [node]= `start` မှ `node` သို့လက်ရှိအတိုဆုံးအကွာအဝေး
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // ကျနော်တို့က `start` မှာရှိတယ်၊ လုံးဝကုန်ကျမှာမဟုတ်ဘူး
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // (min-heap) ကုန်ကျစရိတ်နိမ့်သော node များနှင့်နယ်စပ်ကိုစစ်ဆေးပါ
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // တနည်းအားဖြင့်ကျနော်တို့တိုတောင်းသောလမ်းကြောင်းများအားလုံးကိုဆက်လက်ရှာနိုင်ဘူး
//!         if position == goal { return Some(cost); }
//!
//!         // ကျွန်ုပ်တို့ပိုမိုကောင်းမွန်သောလမ်းကိုတွေ့ရှိပြီးဖြစ်မည်
//!         if cost > dist[position] { continue; }
//!
//!         // node တစ်ခုစီအတွက်ကျွန်ုပ်တို့ရောက်ရှိနိူင်သည်၊ ဤ node ကိုဖြတ်သန်းသွားသောကုန်ကျစရိတ်သက်သာစွာဖြင့်နည်းလမ်းတစ်ခုရှာတွေ့နိုင်မလားစမ်းကြည့်ပါ
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // ရှိပါက၎င်းကိုနယ်စပ်သို့ထည့်ပြီးဆက်လုပ်ပါ
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // အပန်းဖြေမှု၊ အခုပိုကောင်းတဲ့နည်းလမ်းကိုကျွန်တော်တို့ရှာတွေ့ပြီ
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // ရည်မှန်းချက်ကိုလက်လှမ်းမမီပါ
//!     None
//! }
//!
//! fn main() {
//!     // ဒါကငါတို့သုံးမယ့်ညွှန်ကြားထားတဲ့ဂရပ်ဖြစ်တယ်။
//!     // node နံပါတ်များသည်မတူညီသောပြည်နယ်များနှင့်ကိုက်ညီပြီး edge အလေးများသည် node တစ်ခုမှတစ်ခုသို့ပြောင်းရန်ကုန်ကျစရိတ်ကိုဖော်ပြသည်။
//!     //
//!     // အနားတစ်လမ်းတည်းဖြစ်ကြောင်းသတိပြုပါ။
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |၂
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // အဆိုပါဂရပ်ကိုအညွှန်းတစ်ခုချင်းစီသည် node တန်ဖိုးနှင့်သက်ဆိုင်သောအထွက်အနားများစာရင်းရှိသည့်ကပ်လျက်စာရင်းတစ်ခုဖြစ်သည်။
//!     // ၎င်း၏ထိရောက်မှုများအတွက်ရွေးချယ်ခဲ့သည်။
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // node 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Node 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // node 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // node 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Node 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// တစ် ဦး က binary အမှိုက်ပုံနှင့်အတူအကောင်အထည်ဖော်တစ် ဦး က ဦး စားပေးတန်းစီ။
///
/// ဒါကအမြင့်ဆုံးအမှိုက်ပုံဖြစ်လိမ့်မည်။
///
/// `Ord` trait မှဆုံးဖြတ်သည့်အတိုင်းအရာဝတ္ထုတစ်ခုအားအခြားမည်သည့်အရာများနှင့်မဆိုနှိုင်းယှဉ်နိုင်ရန်အတွက်ပြောင်းလဲမှုပြုလုပ်ရန်အတွက်ယုတ္တိဗေဒအမှားဖြစ်သည်။
///
/// ပုံမှန်အားဖြင့်၎င်းသည် `Cell`, `RefCell`, global state, I/O သို့မဟုတ် unsafe code များမှသာဖြစ်နိုင်သည်။
/// ထိုကဲ့သို့သောယုတ္တိဗေဒအမှားမှထွက်ပေါ်လာသည့်အပြုအမူကိုသတ်မှတ်မထားသော်လည်းသတ်မှတ်ထားသောအပြုအမူကိုဖြစ်ပေါ်လိမ့်မည်မဟုတ်ပါ။
/// ၎င်းတွင် panics၊ မှားယွင်းသောရလဒ်များ၊ aborts၊ မှတ်ဥာဏ်ယိုစိမ့်မှုနှင့်ရပ်စဲခြင်းတို့ပါဝင်သည်။
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Type inference သည်ရှင်းလင်းသော type signature ကိုချန်လှပ်ပေးနိုင်သည် (ဥပမာ-`BinaryHeap<i32>` ဖြစ်သည်။)
/////
/// let mut heap = BinaryHeap::new();
///
/// // အမှိုက်ပုံကို အသုံးပြု၍ အမှိုက်ပုံရှိနောက်တစ်ခုကိုကြည့်နိုင်သည်။
/// // ဒီနေရာမှာပစ္စည်းမရှိသေးဘူး၊ ငါတို့မရှိဘူး။
/// assert_eq!(heap.peek(), None);
///
/// // အမှတ်အချို့ထပ်ထည့်ရအောင် ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // ယခု peek အမှိုက်ပုံထဲမှာအရေးအပါဆုံးကို item ပြသထားတယ်။
/// assert_eq!(heap.peek(), Some(&5));
///
/// // အမှိုက်ပုံ၏အရှည်ကိုကျွန်ုပ်တို့စစ်ဆေးနိုင်သည်။
/// assert_eq!(heap.len(), 3);
///
/// // အမှိုက်ပုံဖြင့်ပြန်ပို့သော်လည်းအမှိုက်ပုံရှိပစ္စည်းများကိုကျွန်ုပ်တို့ကြားဖြတ်နိုင်သည်။
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // အကယ်၍ ငါတို့သာဤရမှတ်များပေါ်လာပါက၎င်းတို့သည်အစီအစဉ်အတိုင်းပြန်လာသင့်သည်။
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // ကျန်ရှိသောပစ္စည်းများ၏အမှိုက်ပုံကိုရှင်းနိုင်သည်။
/// heap.clear();
///
/// // အဆိုပါအမှိုက်ပုံယခုအချည်းနှီးဖြစ်သင့်သည်။
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// `std::cmp::Reverse` (သို့) ဓလေ့ထုံးတမ်းဆိုင်ရာ `Ord` အကောင်အထည်ဖော်မှုနှစ်ခုစလုံးကို `BinaryHeap` ကို min-heap ဖြစ်စေရန်အသုံးပြုနိုင်သည်။
/// ဤသည်က `heap.pop()` သည်အကြီးမြတ်ဆုံးအစားအသေးငယ်ဆုံးတန်ဖိုးကိုပြန်ပေးသည်။
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // တန်ဖိုးများကို `Reverse` တွင်ထုပ်ပါ
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // အကယ်၍ ဒီရမှတ်များကိုယခုကျွန်ုပ်တို့ပေါ်လာပါက၎င်းတို့သည်ပြောင်းပြန်အစီအစဉ်အတိုင်းပြန်လာသင့်သည်။
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # အချိန်ရှုပ်ထွေး
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// `push` အတွက်တန်ဖိုးကမျှော်မှန်းထားတဲ့ကုန်ကျစရိတ်ဖြစ်တယ်။နည်းလမ်းစာရွက်စာတမ်းများကိုပိုမိုအသေးစိတ်ခွဲခြမ်းစိတ်ဖြာပေးသည်။
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// `BinaryHeap` ၏အကြီးမားဆုံးသောအရာတစ်ခုကိုပြောင်းလဲရန်ရည်ညွှန်းထားသည့်ဖွဲ့စည်းပုံ။
///
///
/// ဤ `struct` ကို [`BinaryHeap`] ပေါ်ရှိ [`peek_mut`] နည်းလမ်းဖြင့်ဖန်တီးထားသည်။
/// ပိုမိုသိရှိလိုပါက၎င်း၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // လုံခြုံမှု-PeekMut သည်ဗလာမဟုတ်သောအမှိုက်ပုံများအတွက်သာဖြစ်သည်။
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // SAFE-PeekMut သည်ဗလာမဟုတ်သောအမှိုက်ပုံများအတွက်သာဖြစ်သည်
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // SAFE-PeekMut သည်ဗလာမဟုတ်သောအမှိုက်ပုံများအတွက်သာဖြစ်သည်
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// အဆိုပါ peeked တန်ဖိုးကိုအမှိုက်ပုံကနေဖယ်ရှားခြင်းနှင့်ပြန်လာ။
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// တစ် ဦး အချည်းနှီးသော `BinaryHeap<T>` ဖန်တီး။
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// max-heap တစ်ခုအနေဖြင့်အချည်းနှီးသော `BinaryHeap` ကိုဖန်တီးသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// သတ်သတ်မှတ်မှတ်စွမ်းရည်ရှိသောဗလာ `BinaryHeap` တစ်ခုကိုဖန်တီးသည်။
    /// ၎င်းသည် `capacity` ဒြပ်စင်များအတွက်မှတ်ဥာဏ်အလုံအလောက်ကိုကြိုတင်သတ်မှတ်ထားပြီး၎င်းသည်အနည်းဆုံးတန်ဖိုးများစွာပါ ၀ င်သည်အထိ `BinaryHeap` ကိုပြန်လည်ခွဲဝေရန်မလိုအပ်ပါ။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// အကယ်၍ ၎င်းသည်ဗလာမရှိပါက binary heap (သို့မဟုတ်) `None` အတွင်းရှိအကြီးမြတ်ဆုံးသောအရာတစ်ခုကို mutable reference ကို return ပြန်ပေးသည်။
    ///
    /// Note: အကယ်၍ `PeekMut` တန်ဖိုးယိုစိမ့်သွားလျှင်၊ အမှိုက်ပုံသည်ကိုက်ညီမှုမရှိသောအခြေအနေတွင်ရှိနိုင်သည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # အချိန်ရှုပ်ထွေး
    ///
    /// အကယ်၍ ပစ္စည်းကိုပြုပြင်မွမ်းမံလျှင်အဆိုးဆုံးအချိန်ရှုပ်ထွေးမှုမှာ *O*(log(*n*)) ဖြစ်သည်။ မဟုတ်ပါက *O*(1) ဖြစ်သည်။
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// binary heap မှအမြင့်ဆုံးသောအရာများကိုဖယ်ရှားပြီး၎င်းသည်ဗလာမရှိပါက `None` ကိုပြန်လည်ပေးသည်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # အချိန်ရှုပ်ထွေး
    ///
    /// *n* element များပါရှိသည့်အမှိုက်ပုံတွင် `pop` ၏အဆိုးဆုံးအကုန်ကျစရိတ်မှာ *O*(log(*n*)) ဖြစ်သည်။
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // လုံခြုံမှု-!self.is_empty() ဆိုသည်မှာ self.len()> 0 ဟုဆိုလိုသည်
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// ဒြပ်ထုအမှိုက်ပုံတစ်ခုသို့ပစ္စည်းတစ်ခုတင်သည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # အချိန်ရှုပ်ထွေး
    ///
    /// `push` ၏မျှော်မှန်းကုန်ကျစရိတ်သည်တွန်းထုတ်နေသောဒြပ်စင်အမိန့်များအားလုံးအပေါ်ပျမ်းမျှနှင့်တွန်းအားပေးရန်လုံလောက်သောပမာဏကို *O*(1) ဖြစ်သည်။
    ///
    /// မည်သည့်အမျိုးအစားမဆိုပုံစံနှင့်မတူသောဒြပ်စင်များကိုတွန်းထုတ်သောအခါ၎င်းသည်တန်ဖိုးအရှိဆုံးမက်ထရစ်ဖြစ်သည်။
    ///
    /// ဒြပ်စင်အများစုကိုတက်သည်နိုင်ရန်အတွက်တွန်းလျှင်အချိန်ရှုပ်ထွေးယုတ်ညံ့။
    /// အဆိုးဆုံးကိစ္စတွင် element များကို sort sort order ဖြင့်တွန်းအားပေးသည်။ push n ၏ amortized cost သည် X nX element များပါသည့်အမှိုက်ပုံနှင့်ဆန့်သည်။
    ///
    /// `push` သို့ *တစ်ခုတည်းခေါ်ဆိုမှု၏အဆိုးဆုံးကိစ္စမှာ* O *(* n *) ဖြစ်သည်။အဆိုးဆုံးအခြေအနေမှာစွမ်းရည်ကုန်ပြီးအရွယ်အစားပြောင်းရန်လိုအပ်သောအခါဖြစ်သည်။
    /// အရွယ်အစားပြောင်းလဲမှုကုန်ကျစရိတ်ကိုယခင်ကိန်းဂဏန်းများတွင်ထည့်သွင်းထားသည်။
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // လုံခြုံမှု-ပစ္စည်းအသစ်ကိုတွန်းပြီးကတည်းကအဲဒါကိုဆိုလိုတယ်
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// `BinaryHeap` ကိုစားပြီး vector ကို sort (ascending) အစဉ်အတိုင်းပြန်ပေးတယ်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // လုံခြုံမှု-`end` သည် `self.len() - 1` မှ ၁ သို့ (နှစ်ခုလုံးပါ ၀ င်သည်)၊
            //  ဒါကြောင့်အမြဲတမ်း access လုပ်ဖို့ခိုင်လုံတဲ့အညွှန်းကိန်းပါပဲ။
            //  အညွှန်း 0 (ဆိုလိုသည်မှာ `ptr`) ကိုကြည့်နိုင်သည်
            //  1 <=end <self.len(), ဆိုလိုတာက self.len()>=2 ။
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // လုံခြုံမှု-`end` သည် `self.len() - 1` မှ ၁ သို့ (နှစ်ခုလုံးပါ ၀ င်သည်) သို့သွားသည်။
            //  0 <1 <=အဆုံး <= self.len(), 0 <end and end <self.len() ကိုဆိုလိုတာက 1 <self.len() ။
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // sift_up နှင့် sift_down ၏အကောင်အထည်ဖော်မှုများသည် element တစ်ခုအား vector မှထွက်ရန် (အပေါက်တစ်ခုကျန်သည်) အခြားသူများနှင့်အတူရွေ့လျားပြီးဖယ်ထုတ်ထားသော element ကိုအပေါက်၏နောက်ဆုံးတည်နေရာသို့ vector သို့ပြန်ရွှေ့နိုင်ရန်အတွက်လုံခြုံမှုမရှိသောလုပ်ကွက်များကိုအသုံးပြုသည်။
    //
    // `Hole` type ကိုဤအရာကိုကိုယ်စားပြုပြီး panic ပေါ်မှာတောင်မှအပေါက်သည်၎င်း၏နယ်နိမိတ်အဆုံးတွင်ပြန်လည်ဖြည့်ရန်သေချာစေရန်အသုံးပြုသည်။
    // အပေါက်တစ်ပေါက်အသုံးပြုခြင်းသည်လဲလှယ်ရေးအစီအစဉ်များအသုံးပြုခြင်းနှင့်နှိုင်းယှဉ်လျှင်အဆက်မပြတ်သောအချက်ကိုလျော့နည်းစေသည်။
    //
    //
    //
    //

    /// # Safety
    ///
    /// ခေါ်ဆိုသူသည် `pos < self.len()` ကိုအာမခံရမည်။
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // `pos` တန်ဖိုးကိုထုတ်ပြီးအပေါက်တစ်ခုဖန်တီးပါ။
        // လုံခြုံမှု: ဖုန်းခေါ်ဆိုသူမှ <self.len() ကိုအာမခံနိုင်သည်
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // လုံခြုံမှု: hole.pos()> စတင်>=0၊ ဆိုလိုသည်မှာ hole.pos()> 0
            //  ဒါကြောင့် hole.pos(), 1 underflow လို့မရပါဘူး။
            //  ၎င်းသည်မိဘ <hole.pos() ကိုသေချာစေသည်၊ ၎င်းသည်မှန်ကန်သောအညွှန်းဖြစ်သည်၊ ၎င်းသည်!= hole.pos() ။
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // လုံခြုံမှု-အထက်နှင့်အတူတူပဲ
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// `pos` ရှိဒြပ်စင်တစ်ခုကိုယူပြီး၎င်းကိုကလေးများပိုကြီးသည့်အချိန်တွင်အမှိုက်ပုံသို့ရွှေ့ပါ။
    ///
    ///
    /// # Safety
    ///
    /// ခေါ်ဆိုသူသည် `pos < end <= self.len()` ကိုအာမခံရမည်။
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // လုံခြုံမှု: ခေါ်ဆိုသူသည် pos <end <= self.len() ကိုအာမခံနိုင်သည်။
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Loop လျော့ပါးသွားမည်ဖြစ်သလို: ကလေး==2 * hole.pos() + 1 ။
        while child <= end.saturating_sub(2) {
            // လုံခြုံမှုရှိသည့်ကလေးနှစ်ယောက်နှင့်နှိုင်းယှဉ်ပါ။ ကလေး <end, 1 <self.len() နှင့်ကလေး + 1 <အဆုံး <= self.len() ", ဒါကြောင့်သူတို့ကမှန်ကန်သောအညွှန်းကိန်းများဖြစ်သည်။
            //
            //  ကလေးက==2 *hole.pos() + 1!= hole.pos() နှင့်ကလေး + 1==2* hole.pos() + 2!= hole.pos() ။
            // FIXME: T က ZST ဖြစ်လျှင် 2 *hole.pos() + 1 သို့မဟုတ် 2* hole.pos() + 2 လျှံနိုင်သည်
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // ကျွန်ုပ်တို့အစီအစဉ်ရှိပြီးသားဖြစ်ပါကရပ်တန့်ပါ။
            // လုံခြုံစိတ်ချမှု-ယခုကလေးသည်အဟောင်းသို့မဟုတ်ကလေးအကြီးဖြစ်ဖြစ် + 1 ဖြစ်သည်
            //  ကျနော်တို့ပြီးသားသက်သေပြပြီးသား <self.len() နှင့်!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // လုံခြုံမှု-အထက်နှင့်အတူတူ။
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // လုံခြုံမှု-&&Short circuit၊ ဆိုလိုသည်မှာ၎င်းတွင်ဖြစ်သည်
        //  ဒုတိယအခွအေနေက==အဆုံး, 1 <self.len() ကြောင်းပြီးသားစစ်မှန်တဲ့ပါပဲ။
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // လုံခြုံမှု-ကလေးသည်တရားဝင်ညွှန်းကိန်းဖြစ်ကြောင်းသက်သေပြပြီးဖြစ်သည်
            //  ကလေးက==2 * hole.pos() + 1!= hole.pos() ။
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// ခေါ်ဆိုသူသည် `pos < self.len()` ကိုအာမခံရမည်။
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // လုံခြုံမှု: pos <len ကိုဖုန်းခေါ်ဆိုသူမှအာမခံထားသည်
        //  သိသာ Len= self.len() <= self.len() ။
        unsafe { self.sift_down_range(pos, len) };
    }

    /// `pos` မှဒြပ်စင်တစ်ခုကိုယူပြီးအမှိုက်ပုံကိုလမ်းတစ်လျှောက်လုံးရွှေ့လိုက်ပြီး၎င်းကို၎င်း၏အနေအထားအထိထားလိုက်ပါ။
    ///
    ///
    /// Note: element ကကြီးတယ်ဆိုတာကိုသိတဲ့အခါမှာပိုမြန်တယ်၊ အောက်ခြေနဲ့ပိုနီးတယ်။
    ///
    /// # Safety
    ///
    /// ခေါ်ဆိုသူသည် `pos < self.len()` ကိုအာမခံရမည်။
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // လုံခြုံမှု: ဖုန်းခေါ်ဆိုသူမှ <self.len() ကိုအာမခံနိုင်သည်။
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Loop လျော့ပါးသွားမည်ဖြစ်သလို: ကလေး==2 * hole.pos() + 1 ။
        while child <= end.saturating_sub(2) {
            // လုံခြုံမှု: ကလေး <အဆုံး, 1 <self.len() နှင့်
            //  child + 1 <end <= self.len(), ဒါကြောင့်သူတို့ကမှန်ကန်သောအညွှန်းကိန်းများဖြစ်သည်။
            //  ကလေးက==2 *hole.pos() + 1!= hole.pos() နှင့်ကလေး + 1==2* hole.pos() + 2!= hole.pos() ။
            //
            // FIXME: T က ZST ဖြစ်လျှင် 2 *hole.pos() + 1 သို့မဟုတ် 2* hole.pos() + 2 လျှံနိုင်သည်
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // လုံခြုံမှု-အထက်နှင့်အတူတူပဲ
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // လုံခြုံမှု-ကလေး==အဆုံး၊ ၁ <self.len()၊ ဒါကြောင့်ဒါကတရားဝင်အညွှန်းကိန်းဖြစ်သည်
            //  နှင့်ကလေး==2 * hole.pos() + 1!= hole.pos() ။
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // လုံခြုံမှု-pos သည်တွင်းထဲရှိနေရာဖြစ်ပြီးသက်သေပြပြီးဖြစ်သည်
        //  ခိုင်လုံသောအညွှန်းကိန်းဖြစ်။
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // လုံခြုံမှု: n သည် self.len()/2 မှ စတင်၍ ၀ သို့သွားသည်။
            //  (! n <self.len()) သည် self.len() ==0 ဖြစ်လျှင်တစ်ခုတည်းသောဖြစ်ရပ်ဖြစ်သော်လည်း၎င်းသည် loop အခြေအနေမှပယ်ဖျက်သည်) ။
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// `other` ၏ element အားလုံးကို `self` သို့ရွှေ့ပြီး `other` ဗလာဖြစ်နေသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` `extend` O(len2 *log(len1)) စစ်ဆင်ရေးများနှင့်အဆိုးဆုံးကိစ္စတွင် 1* len2 *log_2(len1) နှိုင်းယှဉ်မှုများပြုလုပ်စဉ် O(len1 + len2) စစ်ဆင်ရေးများနှင့်အဆိုးဆုံးကိစ္စတွင် ၂*(len1 + len2) နှိုင်းယှဉ်မှုများပြုလုပ်ပြီး len1>= len2 ယူဆသည်။
        // ပိုကြီးတဲ့အမှိုက်ပုံအဘို့, crossover အမှတ်ဒီဆင်ခြင်ခြင်းကိုလိုက်နာမရှိတော့နှင့်ပင်ကိုယ်မူလဆုံးဖြတ်ခဲ့သည်။
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// element များကိုအမှိုက်ပုံဖြင့်ပြန်လည်ရယူသည့်ကြားဖြတ်တစ်ခုကိုပြန်ပို့သည်။
    /// ထုတ်ယူထားသောဒြပ်စင်များကိုမူလအမှိုက်ပုံမှဖယ်ရှားပစ်သည်။
    /// ကျန်ရှိနေသေးသောဒြပ်စင်များကိုအမှိုက်ပုံအစီအစဉ်အတိုင်းပြန်လည်ဖယ်ရှားပေးလိမ့်မည်။
    ///
    /// Note:
    /// * `.drain_sorted()` *O*(*n*\*log(* n*)); `.drain()` ထက်အများကြီးပိုနှေးသည်) ။
    ///   သငျသညျအမြားဆုံးကိစ္စရပ်များအတွက်အဆုံးစွန်ကိုအသုံးပြုသင့်ပါတယ်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // အမှိုက်ပုံနိုင်ရန်အတွက် element အားလုံးကိုဖယ်ရှားပေးသည်
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// အဆိုပါ predicate အားဖြင့်သတ်မှတ်ထားသောသာဒြပ်စင်ဆက်လက်ထိန်းသိမ်းထားသည်။
    ///
    /// တစ်နည်းအားဖြင့် `e` element အားလုံးအားဖယ်ရှားပါ၊ `f(&e)` `false` ကိုပြန်ပေးမည်။
    /// element များကို unsorted (နှင့် unspecified) အမိန့်ဖြင့်သွားရောက်ကြည့်ရှုသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // ဂဏန်းတွေတောင်သိမ်းထားပါ
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// နောက်ခံ vector ရှိတန်ဖိုးအားလုံးကိုကြည့်ရှုသည့်ကြားဖြတ်တွင်၊
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // ၁၊ ၂၊ ၃၊ ၄ ကိုမတရားပုံစံဖြင့်ပုံနှိပ်ပါ
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// element များကိုအမှိုက်ပုံဖြင့်ပြန်လည်ရယူသည့်ကြားဖြတ်တစ်ခုကိုပြန်ပို့သည်။
    /// ဤနည်းလမ်းသည်မူလအမှိုက်ပုံကိုလောင်ကျွမ်းသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// အကယ်၍ ၎င်းသည်ဗလာမရှိပါက binary heap (သို့မဟုတ်) `None` ထဲရှိအမြင့်ဆုံးတန်ဖိုးကို return ပြန်ပေးတယ်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # အချိန်ရှုပ်ထွေး
    ///
    /// ကုန်ကျစရိတ် *O*(1) အဆိုးဆုံးကိစ္စတွင်ဖြစ်ပါတယ်။
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// binary heap သည်ပြန်လည်ခွဲဝေခြင်းမပြုနိုင်သည့်ဒြပ်စင်အရေအတွက်ကိုပြန်ပို့သည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// ပေးထားသော `BinaryHeap` တွင်ထည့်သွင်းရမည့်ဒြပ်စင်များအတိအကျ `additional` အတွက်အနည်းဆုံးစွမ်းရည်ကိုထိန်းသိမ်းသည်။
    /// စွမ်းရည်ပြီးသားလျှင်ဘာမျှမလုပ်။
    ///
    /// ခွဲဝေချထားပေးသူသည်စုဆောင်းမှုကိုသူတောင်းလိုသောနေရာထက်ပိုပေးနိုင်ကြောင်းသတိပြုပါ။
    /// ထို့ကြောင့်စွမ်းရည်ကိုအတိအကျအနည်းဆုံးဖြစ်ရန်မမှီခိုနိုင်ပါ။
    /// future ထည့်သွင်းမှုများပြုလုပ်ရန်မျှော်လင့်ပါက [`reserve`] ကို ဦး စားပေးမည်။
    ///
    /// # Panics
    ///
    /// အသစ်ကစွမ်းရည် `usize` လျံလျှင် Panics ။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// `BinaryHeap` တွင်ထည့်သွင်းရန်အနည်းဆုံး `additional` ထက်ပိုသောဒြပ်စင်များအတွက်သိုလှောင်နိုင်စွမ်း။
    /// မကြာခဏပြန်လည်ခွဲဝေခြင်းများကိုရှောင်ရှားရန်စုဆောင်းခြင်းသည်နေရာပိုယူနိုင်သည်။
    ///
    /// # Panics
    ///
    /// အသစ်ကစွမ်းရည် `usize` လျံလျှင် Panics ။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// တတ်နိုင်သမျှအပိုဆောင်းစွမ်းရည်ဖယ်ရှားပစ်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// အောက်ပိုင်းနှင့်အတူစွမ်းရည်ကိုပယ်။
    ///
    /// စွမ်းဆောင်ရည်သည်အနည်းဆုံးအရှည်နှင့်ထောက်ပံ့ထားသောတန်ဖိုးနှစ်ခုလုံးအတိုင်းအတာအထိကြီးမားသည်။
    ///
    ///
    /// လက်ရှိစွမ်းရည်နိမ့်ဆုံးကန့်သတ်ထက်လျော့နည်းသည်ဆိုပါကဤသည်ကိုမ op ဖြစ်ပါတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// `BinaryHeap` ကိုစားသုံးပြီးနောက်ခံ vector ကိုအလိုအလျောက်ပြန်ပို့သည်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // အချို့သောနိုင်ရန်အတွက်ပုံနှိပ်ပါလိမ့်မယ်
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// အဆိုပါ binary အမှိုက်ပုံ၏အရှည်ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// အဆိုပါဒွိအမှိုက်ပုံဗလာလျှင်စစ်ဆေးသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// ဖယ်ရှားထားသောဒြပ်စင်ကျော်ကြားမှာပြန်လာ, binary အမှိုက်ပုံရှင်းလင်းရေး။
    ///
    /// အဆိုပါ element တွေကိုမတရားနိုင်ရန်အတွက်ဖယ်ရှားပစ်ပါသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// ဒြပ်ထုအမှိုက်ပုံမှပစ္စည်းများအားလုံးကိုဖယ်ရှားပေးသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Hole ဆိုတာက slice ထဲမှာရှိတဲ့အပေါက်ကိုဆိုလိုတယ်။ ဆိုလိုတာကခိုင်လုံတဲ့တန်ဖိုးမရှိတဲ့ index တစ်ခုဖြစ်တယ်။
///
/// drop in, `Hole` သည်မူလနေရာဖယ်ထားသောတန်ဖိုးနှင့်အပေါက်အနေအထားကိုဖြည့်ခြင်းဖြင့်အချပ်ကိုပြန်ပေးလိမ့်မည်။
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// အညွှန်းကိန်း `pos` တွင် `Hole` အသစ်တစ်ခုကိုဖန်တီးပါ။
    ///
    /// လုံခြုံမှုမရှိသောကြောင့် pos သည်ဒေတာအချပ်အတွင်းတွင်ရှိရမည်။
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // အန္တရာယ်ကင်း: pos ကိုအချပ်အတွင်း၌ဖြစ်သင့်သည်
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// ဖယ်ရှားဒြပ်စင်တစ်ခုရည်ညွှန်း Returns ။
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// `index` ရှိ element သို့ရည်ညွှန်းသည်။
    ///
    /// မလုံခြုံသောကြောင့် index သည် data slice အတွင်းဖြစ်သင့်ပြီး pos နှင့်မတူပါ။
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// နေရာအသစ်သို့အပေါက်ရွှေ့ပါ
    ///
    /// မလုံခြုံသောကြောင့် index သည် data slice အတွင်းဖြစ်သင့်ပြီး pos နှင့်မတူပါ။
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // နောက်တဖန်အပေါက်ဖြည့်ပါ
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// တစ် ဦး `BinaryHeap` ၏ဒြပ်စင်ကျော်ကြားမှာ။
///
/// ဤ `struct` ကို [`BinaryHeap::iter()`] မှဖန်တီးသည်။
/// ပိုမိုသိရှိလိုပါက၎င်း၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) `#[derive(Clone)]` ၏မျက်နှာသာအတွက်ဖယ်ရှားပါ
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// `BinaryHeap` ၏ဒြပ်စင်များအပေါ်ပိုင်ဆိုင်သောကြားမှာ။
///
/// ဤ `struct` ကို [`BinaryHeap::into_iter()`] (`IntoIterator` trait မှထောက်ပံ့သည်) ကဖန်တီးသည်။
/// ပိုမိုသိရှိလိုပါက၎င်း၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// တစ် ဦး က `BinaryHeap` ၏ဒြပ်စင်ကျော်ဖျန်ကြားမှာ။
///
/// ဤ `struct` ကို [`BinaryHeap::drain()`] မှဖန်တီးသည်။
/// ပိုမိုသိရှိလိုပါက၎င်း၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// တစ် ဦး က `BinaryHeap` ၏ဒြပ်စင်ကျော်ဖျန်ကြားမှာ။
///
/// ဤ `struct` ကို [`BinaryHeap::drain_sorted()`] မှဖန်တီးသည်။
/// ပိုမိုသိရှိလိုပါက၎င်း၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// အမှိုက်ပုံဒြပ်စင်များကိုအမှိုက်ပုံထဲမှဖယ်ထုတ်သည်။
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// `Vec<T>` ကို `BinaryHeap<T>` အဖြစ်ပြောင်းပေးသည်။
    ///
    /// ဒီပြောင်းလဲခြင်း In-place ဖြစ်ပျက်နှင့် *O*(*n*) အချိန်ရှုပ်ထွေးရှိပါတယ်။
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// `BinaryHeap<T>` ကို `Vec<T>` အဖြစ်ပြောင်းပေးသည်။
    ///
    /// ဤပြောင်းလဲမှုသည်ဒေတာလှုပ်ရှားမှုသို့မဟုတ်ခွဲဝေချထားမှုမလိုအပ်ပါ။ အမြဲတမ်းအချိန်ရှုပ်ထွေးပါသည်။
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// တန်ဖိုးတစ်ခုချင်းစီကိုမတရားပုံစံဖြင့်ရွေ့လျားစေသောစားသုံးသူကြားခံတစ်ခုကိုဖန်တီးသည်။
    /// ဒီ binary အမှိုက်ကိုဤခေါ်ဆိုပြီးနောက်သုံးမရပါ။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // ၁၊ ၂၊ ၃၊ ၄ ကိုမတရားပုံစံဖြင့်ပုံနှိပ်ပါ
    /// for x in heap.into_iter() {
    ///     // x တွင် i32 အမျိုးအစားမဟုတ်ဘဲ &i32 ရှိသည်
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}