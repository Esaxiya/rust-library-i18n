use core::borrow::Borrow;
use core::cmp::Ordering;
use core::fmt::{self, Debug};
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, RangeBounds};
use core::ptr;

use super::borrow::DormantMutRef;
use super::navigate::LeafRange;
use super::node::{self, marker, ForceResult::*, Handle, NodeRef, Root};
use super::search::SearchResult::*;

mod entry;
pub use entry::{Entry, OccupiedEntry, OccupiedError, VacantEntry};
use Entry::*;

/// အမြစ်များမဟုတ်သော node များမှအနည်းဆုံး element များ။
/// နည်းစနစ်များအတွင်းကျွန်ုပ်တို့တွင်ယာယီဒြပ်စင်နည်းပါးနိုင်သည်။
pub(super) const MIN_LEN: usize = node::MIN_LEN_AFTER_SPLIT;

// `BTreeMap` ရှိအပင်တစ်ပင်သည် `node` module အတွင်းရှိအပင်တစ်ပင်ဖြစ်သည်။
// - သော့များသည် (key ၏အမျိုးအစားအရ) တက်သည်။
// - အကယ်၍ root node သည် internal ဖြစ်လျှင်၎င်းတွင်အနည်းဆုံး element တစ်ခုရှိရမည်။
// - Non-root node တိုင်းတွင်အနည်းဆုံး MIN_LEN element များပါရှိသည်။
//
// အချည်းနှီးသောမြေပုံတစ်ခုသည် root node မရှိခြင်း (သို့) အရွက်အချည်းနှီးဖြစ်သော root node တစ်ခုမှကိုယ်စားပြုနိုင်သည်။
//

/// [B-Tree] အပေါ်အခြေခံပြီးမြေပုံ။
///
/// B-Trees သည် cache-эфектыўမှုနှင့်ရှာဖွေမှုတစ်ခုတွင်လုပ်ဆောင်ခဲ့သောအလုပ်ပမာဏကိုအနိမ့်ဆုံးအကြားအခြေခံအပေးအယူဖြစ်သည်။သီအိုရီအရ (BST) binary search tree သည် sorted map အတွက်အကောင်းဆုံးရွေးချယ်မှုတစ်ခုဖြစ်သည်။ BST သည် BX element တစ်ခုအား (log<sub>2</sub>n) ကိုရှာရန်လိုအပ်သောနှိုင်းယှဉ်မှုအနည်းဆုံးပမာဏကိုလုပ်ဆောင်သည်။
/// သို့သော်လက်တွေ့တွင်ဤသို့ပြုခြင်းသည်မျက်မှောက်ခေတ်ကွန်ပျူတာဗိသုကာများအတွက်အလွန်မတတ်နိုင်သောကြောင့်ဖြစ်သည်။
/// အထူးသဖြင့်၊ element တိုင်းသည်၎င်း၏ကိုယ်ပိုင် heap-allokated node တွင်သိမ်းဆည်းထားသည်။
/// ဆိုလိုသည်မှာ insertion တစ်ခုစီသည် heap-allokation ကိုအစပျိုးသည်။ နှိုင်းယှဉ်မှုတိုင်းသည် cache-miss ဖြစ်သင့်သည်။
/// ဤအရာများသည်လက်တွေ့တွင်လုပ်ဆောင်ရန်အထူးသဖြင့်စျေးကြီးသောအရာများဖြစ်သဖြင့်ကျွန်ုပ်တို့သည်အနည်းဆုံး BST မဟာဗျူဟာကိုပြန်လည်စဉ်းစားရန်ဖိအားပေးခံရသည်။
///
/// တစ် ဦး က B-Tree အစား node တစ်ခုချင်းစီကိုတစ်ဆက်တည်းခင်းကျင်းအတွက် B-1 မှ 2B-1 element တွေကိုဆံ့စေသည်။ဤသို့ပြုလုပ်ခြင်းဖြင့်ကျွန်ုပ်တို့သည် B ၏အချက်တစ်ခုအရခွဲဝေချထားမှုအရေအတွက်ကိုလျှော့ချပြီးရှာဖွေမှုများတွင် cache ၏ထိရောက်မှုကိုတိုးတက်စေသည်။သို့သော်၎င်းသည်ရှာဖွေမှုများသည်ပျမ်းမျှအားဖြင့်ပိုမိုနှိုင်းယှဉ်မှုများပြုလုပ်ရမည်ဟုဆိုလိုသည်။
/// အတိအကျနှိုင်းယှဉ်နှိုင်းယှဉ်အရေအတွက်သည်အသုံးပြုသော node ရှာဖွေရေးနည်းဗျူဟာပေါ်တွင်မူတည်သည်။အကောင်းဆုံး cache ထိရောက်မှုအတွက် node များကို line line ရှာဖွေနိုင်သည်။အကောင်းဆုံးနှိုင်းယှဉ်မှုများအတွက် binary search ကို အသုံးပြု၍ node ကိုရှာဖွေနိုင်သည်။တစ်ဦးအပေးအယူအဖြစ်, <sup>တဦးတည်းလည်းအစပိုင်းတွင်သာစစ်ဆေးမှုများပြုလုပ်ဈအချို့ရွေးချယ်မှုသည်ဈကြိမ်မြောက်ဒြပ်စင်တစ်ခု</sup> linear ရှာဖွေရေးလုပ်ဆောင်နိုင်မည်ဖြစ်သည်။
///
/// လက်ရှိတွင်ကျွန်ုပ်တို့၏အကောင်အထည်ဖော်မှုသည်ရိုးရှင်းစွာရှာဖွေခြင်းကိုရိုးရှင်းစွာလုပ်ဆောင်သည်။၎င်းသည်အလွန်သေးငယ်သောဒြပ်စင်များ *နှင့်နှိုင်းယှဉ်လျှင်စျေးပေါသောစွမ်းဆောင်ရည်ကိုကောင်းမွန်စေသည်။သို့သော် future တွင်ကျွန်ုပ်တို့သည် B ရွေးချယ်မှုအပေါ် အခြေခံ၍ အကောင်းဆုံးရှာဖွေရေးနည်းဗျူဟာနှင့်အခြားအချက်များကိုရွေးချယ်ခြင်းအားထပ်မံလေ့လာလိုသည်။linear ရှာဖွေခြင်းကို အသုံးပြု၍ random element တစ်ခုကိုရှာဖွေခြင်းသည်ယေဘုယျအားဖြင့် BST ထက်ပိုမိုဆိုးရွားသည့် O(B* log(n)) နှိုင်းယှဉ်မှုများကိုပြုလုပ်လိမ့်မည်ဟုမျှော်လင့်ရသည်။
///
/// သို့သော်လက်တွေ့တွင်စွမ်းဆောင်ရည်သည်အလွန်ကောင်းမွန်သည်။
///
/// ၎င်းသည် [`Ord`] trait ၏ဆုံးဖြတ်ချက်အရအခြားသော့နှင့်အခြားသော့များနှင့်ဆက်စပ်နေသည့် key ၏အမိန့်သည်ပြောင်းလဲမှုကိုမြေပုံတွင်ရှိနေစဉ်ပြောင်းလဲရန်အတွက်သော့၏ယုတ္တိဗေဒအမှားဖြစ်သည်။ပုံမှန်အားဖြင့်၎င်းသည် [`Cell`], [`RefCell`], global state, I/O သို့မဟုတ် unsafe code များမှသာဖြစ်နိုင်သည်။
/// ထိုကဲ့သို့သောယုတ္တိဗေဒအမှားမှထွက်ပေါ်လာသည့်အပြုအမူကိုသတ်မှတ်မထားသော်လည်းသတ်မှတ်ထားသောအပြုအမူကိုဖြစ်ပေါ်လိမ့်မည်မဟုတ်ပါ။၎င်းတွင် panics၊ မှားယွင်းသောရလဒ်များ၊ aborts၊ မှတ်ဥာဏ်ယိုစိမ့်မှုနှင့်ရပ်စဲခြင်းတို့ပါဝင်သည်။
///
/// [B-Tree]: https://en.wikipedia.org/wiki/B-tree
/// [`Cell`]: core::cell::Cell
/// [`RefCell`]: core::cell::RefCell
///
/// # Examples
///
/// ```
/// use std::collections::BTreeMap;
///
/// // type inference သည်ရှင်းလင်းသော type signature ကိုချန်လှပ်ပေးနိုင်သည် (ဥပမာ-`BTreeMap<&str, &str>` ဖြစ်သည်။)
/////
/// let mut movie_reviews = BTreeMap::new();
///
/// // ရုပ်ရှင်အချို့ပြန်လည်သုံးသပ်ရန်
/// movie_reviews.insert("Office Space",       "Deals with real issues in the workplace.");
/// movie_reviews.insert("Pulp Fiction",       "Masterpiece.");
/// movie_reviews.insert("The Godfather",      "Very enjoyable.");
/// movie_reviews.insert("The Blues Brothers", "Eye lyked it a lot.");
///
/// // တိကျတဲ့တစ်ခုအဘို့အစစ်ဆေးပါ။
/// if !movie_reviews.contains_key("Les Misérables") {
///     println!("We've got {} reviews, but Les Misérables ain't one.",
///              movie_reviews.len());
/// }
///
/// // အိုး၊ ဒီသုံးသပ်ချက်မှာစာလုံးပေါင်းအမှားအယွင်းတွေအများကြီးရှိတယ်၊ ဖျက်ပစ်ကြစို့။
/// movie_reviews.remove("The Blues Brothers");
///
/// // အချို့သော့များနှင့်ဆက်စပ်သောတန်ဖိုးများကိုရှာဖွေပါ။
/// let to_find = ["Up!", "Office Space"];
/// for movie in &to_find {
///     match movie_reviews.get(movie) {
///        Some(review) => println!("{}: {}", movie, review),
///        None => println!("{} is unreviewed.", movie)
///     }
/// }
///
/// // သော့တစ်ခု၏တန်ဖိုးကိုရှာပါ (သော့မတွေ့ပါက panic သည်)
/// println!("Movie review: {}", movie_reviews["Office Space"]);
///
/// // အရာအားလုံးကျော်ကြားမှာ။
/// for (movie, review) in &movie_reviews {
///     println!("{}: \"{}\"", movie, review);
/// }
/// ```
///
/// `BTreeMap` ထို့အပြင်သော့များနှင့်၎င်းတို့၏တန်ဖိုးများကိုရယူခြင်း၊ ပြင်ဆင်ခြင်း၊ အသစ်ပြောင်းခြင်းနှင့်ဖယ်ရှားခြင်းတို့အတွက်ပိုမိုရှုပ်ထွေးသောနည်းလမ်းများအတွက်ခွင့်ပြုသည့် [`Entry API`] ကိုလည်းအကောင်အထည်ဖော်သည်။
///
/// [`Entry API`]: BTreeMap::entry
///
/// ```
/// use std::collections::BTreeMap;
///
/// // type inference သည်ရှင်းလင်းသော type signature ကိုချန်လှပ်ပေးနိုင်သည် (ဥပမာ-`BTreeMap<&str, u8>` ဖြစ်သည်။)
/////
/// let mut player_stats = BTreeMap::new();
///
/// fn random_stat_buff() -> u8 {
///     // တကယ်တော့ဒီမှာကျပန်းတန်ဖိုးအချို့ကိုပြန်ပေးနိုင်ပြီ၊ ပုံသေတန်ဖိုးအချို့ကိုယခုပြန်ပေးပါ
/////
///     42
/// }
///
/// // ရှိပြီးသားမရှိသေးမှသာသော့ကိုထည့်ပါ
/// player_stats.entry("health").or_insert(100);
///
/// // ၎င်းကိုမရှိသေးပါကတန်ဖိုးအသစ်တစ်ခုပေးသည့် function ကို အသုံးပြု၍ သော့ကိုထည့်ပါ
/////
/// player_stats.entry("defence").or_insert_with(random_stat_buff);
///
/// // key ကိုမွမ်းမံပါ၊ ခလုတ်ကိုသတ်မှတ်ထားခြင်းမပြုရန်သတိပြုပါ
/// let stat = player_stats.entry("attack").or_insert(100);
/// *stat += random_stat_buff();
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BTreeMap")]
pub struct BTreeMap<K, V> {
    root: Option<Root<K, V>>,
    length: usize,
}

#[stable(feature = "btree_drop", since = "1.7.0")]
unsafe impl<#[may_dangle] K, #[may_dangle] V> Drop for BTreeMap<K, V> {
    fn drop(&mut self) {
        if let Some(root) = self.root.take() {
            Dropper { front: root.into_dying().first_leaf_edge(), remaining_length: self.length };
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Clone, V: Clone> Clone for BTreeMap<K, V> {
    fn clone(&self) -> BTreeMap<K, V> {
        fn clone_subtree<'a, K: Clone, V: Clone>(
            node: NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal>,
        ) -> BTreeMap<K, V>
        where
            K: 'a,
            V: 'a,
        {
            match node.force() {
                Leaf(leaf) => {
                    let mut out_tree = BTreeMap { root: Some(Root::new()), length: 0 };

                    {
                        let root = out_tree.root.as_mut().unwrap(); // ကျနော်တို့ရုံပတ်ရစ်သောကြောင့် unwrap အောင်မြင်
                        let mut out_node = match root.borrow_mut().force() {
                            Leaf(leaf) => leaf,
                            Internal(_) => unreachable!(),
                        };

                        let mut in_edge = leaf.first_edge();
                        while let Ok(kv) = in_edge.right_kv() {
                            let (k, v) = kv.into_kv();
                            in_edge = kv.right_edge();

                            out_node.push(k.clone(), v.clone());
                            out_tree.length += 1;
                        }
                    }

                    out_tree
                }
                Internal(internal) => {
                    let mut out_tree = clone_subtree(internal.first_edge().descend());

                    {
                        let out_root = BTreeMap::ensure_is_owned(&mut out_tree.root);
                        let mut out_node = out_root.push_internal_level();
                        let mut in_edge = internal.first_edge();
                        while let Ok(kv) = in_edge.right_kv() {
                            let (k, v) = kv.into_kv();
                            in_edge = kv.right_edge();

                            let k = (*k).clone();
                            let v = (*v).clone();
                            let subtree = clone_subtree(in_edge.descend());

                            // BTreeMap သည် Drop ကိုအကောင်အထည်ဖော်နေသောကြောင့်ကျွန်ုပ်တို့သည် subtree ကိုတိုက်ရိုက် ဖွဲ့စည်း၍ မရပါ
                            //
                            let (subroot, sublength) = unsafe {
                                let subtree = ManuallyDrop::new(subtree);
                                let root = ptr::read(&subtree.root);
                                let length = subtree.length;
                                (root, length)
                            };

                            out_node.push(k, v, subroot.unwrap_or_else(Root::new));
                            out_tree.length += 1 + sublength;
                        }
                    }

                    out_tree
                }
            }
        }

        if self.is_empty() {
            // အကောင်းဆုံးကတော့ဒီမှာ `BTreeMap::new` လို့ခေါ်တယ်။ ဒါပေမယ့် `K 'ရှိတယ်။
            // ဒီနည်းလမ်းကင်းမဲ့သည့် Ord` သတ်။
            BTreeMap { root: None, length: 0 }
        } else {
            clone_subtree(self.root.as_ref().unwrap().reborrow()) // ဗလာမဟုတ်သောကြောင့် unwrap အောင်မြင်
        }
    }
}

impl<K, Q: ?Sized> super::Recover<Q> for BTreeMap<K, ()>
where
    K: Borrow<Q> + Ord,
    Q: Ord,
{
    type Key = K;

    fn get(&self, key: &Q) -> Option<&K> {
        let root_node = self.root.as_ref()?.reborrow();
        match root_node.search_tree(key) {
            Found(handle) => Some(handle.into_kv().0),
            GoDown(_) => None,
        }
    }

    fn take(&mut self, key: &Q) -> Option<K> {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = map.root.as_mut()?.borrow_mut();
        match root_node.search_tree(key) {
            Found(handle) => {
                Some(OccupiedEntry { handle, dormant_map, _marker: PhantomData }.remove_kv().0)
            }
            GoDown(_) => None,
        }
    }

    fn replace(&mut self, key: K) -> Option<K> {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = Self::ensure_is_owned(&mut map.root).borrow_mut();
        match root_node.search_tree::<K>(&key) {
            Found(mut kv) => Some(mem::replace(kv.key_mut(), key)),
            GoDown(handle) => {
                VacantEntry { key, handle, dormant_map, _marker: PhantomData }.insert(());
                None
            }
        }
    }
}

/// တစ် ဦး `BTreeMap` ၏ entries တွေကိုကျော်တစ် ဦး ကြားမှာ။
///
/// ဤ `struct` ကို [`BTreeMap`] ပေါ်ရှိ [`iter`] နည်းလမ်းဖြင့်ဖန်တီးထားသည်။
/// ပိုမိုသိရှိလိုပါက၎င်း၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
///
/// [`iter`]: BTreeMap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, K: 'a, V: 'a> {
    range: Range<'a, K, V>,
    length: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V: fmt::Debug> fmt::Debug for Iter<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.clone()).finish()
    }
}

/// `BTreeMap` ၏ entries တွေကိုကျော်တစ် ဦး mutable ကြားမှာ။
///
/// ဤ `struct` ကို [`BTreeMap`] ပေါ်ရှိ [`iter_mut`] နည်းလမ်းဖြင့်ဖန်တီးထားသည်။
/// ပိုမိုသိရှိလိုပါက၎င်း၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
///
/// [`iter_mut`]: BTreeMap::iter_mut
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, K: 'a, V: 'a> {
    range: RangeMut<'a, K, V>,
    length: usize,
}

/// တစ် ဦး `BTreeMap` ၏ entries တွေကိုကျော်ပိုင်ကြားမှာ။
///
/// ဤ `struct` ကို [`BTreeMap`] (`IntoIterator` trait မှထောက်ပံ့သော) ပေါ်ရှိ [`into_iter`] နည်းလမ်းဖြင့်ဖန်တီးထားသည်။
/// ပိုမိုသိရှိလိုပါက၎င်း၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
///
/// [`into_iter`]: IntoIterator::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<K, V> {
    range: LeafRange<marker::Dying, K, V>,
    length: usize,
}

impl<K, V> IntoIter<K, V> {
    /// ကျန်ရှိသောပစ္စည်းများအပေါ်ကိုးကားတဲ့ကြားမှာပြန်သွားသည်။
    #[inline]
    pub(super) fn iter(&self) -> Iter<'_, K, V> {
        let range = Range { inner: self.range.reborrow() };
        Iter { range: range, length: self.length }
    }
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V: fmt::Debug> fmt::Debug for IntoIter<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

/// နှစ်ဆအဆုံးသတ်မဟုတ်သောရည်ရွယ်ချက်တစ်ခုတည်းရှိသောရိုးရှင်းသော `IntoIter` ဗားရှင်း-ကျန်ရှိသော `IntoIter` ကိုဖယ်ရှားရန်။
/// ထို့ကြောင့်၎င်းသည် `back` ရွက် edge ကိုပထမ ဦး ဆုံးရှာရန်မလိုဘဲသစ်ပင်တစ်ခုလုံးကိုလည်းပစ်ချနိုင်သည်။
///
struct Dropper<K, V> {
    front: Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge>,
    remaining_length: usize,
}

/// တစ် ဦး `BTreeMap` ၏သော့ကိုကျော်ကြားမှာ။
///
/// ဤ `struct` ကို [`BTreeMap`] ပေါ်ရှိ [`keys`] နည်းလမ်းဖြင့်ဖန်တီးထားသည်။
/// ပိုမိုသိရှိလိုပါက၎င်း၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
///
/// [`keys`]: BTreeMap::keys
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Keys<'a, K: 'a, V: 'a> {
    inner: Iter<'a, K, V>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V> fmt::Debug for Keys<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.clone()).finish()
    }
}

/// တစ် ဦး `BTreeMap` ၏တန်ဖိုးများကိုကျော်ကြားမှာ။
///
/// ဤ `struct` ကို [`BTreeMap`] ပေါ်ရှိ [`values`] နည်းလမ်းဖြင့်ဖန်တီးထားသည်။
/// ပိုမိုသိရှိလိုပါက၎င်း၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
///
/// [`values`]: BTreeMap::values
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Values<'a, K: 'a, V: 'a> {
    inner: Iter<'a, K, V>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K, V: fmt::Debug> fmt::Debug for Values<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.clone()).finish()
    }
}

/// တစ် ဦး `BTreeMap` ၏တန်ဖိုးများကိုကျော်တစ် ဦး mutable ကြားမှာ။
///
/// ဤ `struct` ကို [`BTreeMap`] ပေါ်ရှိ [`values_mut`] နည်းလမ်းဖြင့်ဖန်တီးထားသည်။
/// ပိုမိုသိရှိလိုပါက၎င်း၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
///
/// [`values_mut`]: BTreeMap::values_mut
#[stable(feature = "map_values_mut", since = "1.10.0")]
pub struct ValuesMut<'a, K: 'a, V: 'a> {
    inner: IterMut<'a, K, V>,
}

#[stable(feature = "map_values_mut", since = "1.10.0")]
impl<K, V: fmt::Debug> fmt::Debug for ValuesMut<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.inner.iter().map(|(_, val)| val)).finish()
    }
}

/// တစ် ဦး `BTreeMap` ၏သော့ကျော်ပိုင်ဆိုင်ကြားမှာ။
///
/// ဤ `struct` ကို [`BTreeMap`] ပေါ်ရှိ [`into_keys`] နည်းလမ်းဖြင့်ဖန်တီးထားသည်။
/// ပိုမိုသိရှိလိုပါက၎င်း၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
///
/// [`into_keys`]: BTreeMap::into_keys
#[unstable(feature = "map_into_keys_values", issue = "75294")]
pub struct IntoKeys<K, V> {
    inner: IntoIter<K, V>,
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K: fmt::Debug, V> fmt::Debug for IntoKeys<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.inner.iter().map(|(key, _)| key)).finish()
    }
}

/// တစ် ဦး `BTreeMap` ၏တန်ဖိုးများကိုကျော်ပိုင်ဆိုင်ကြားမှာ။
///
/// ဤ `struct` ကို [`BTreeMap`] ပေါ်ရှိ [`into_values`] နည်းလမ်းဖြင့်ဖန်တီးထားသည်။
/// ပိုမိုသိရှိလိုပါက၎င်း၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
///
/// [`into_values`]: BTreeMap::into_values
#[unstable(feature = "map_into_keys_values", issue = "75294")]
pub struct IntoValues<K, V> {
    inner: IntoIter<K, V>,
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V: fmt::Debug> fmt::Debug for IntoValues<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.inner.iter().map(|(_, val)| val)).finish()
    }
}

/// `BTreeMap` တွင်ထည့်သွင်းထားသည့်ကဏ္subခွဲခွဲများမှကြားဖြတ်တစ်ခု။
///
/// ဤ `struct` ကို [`BTreeMap`] ပေါ်ရှိ [`range`] နည်းလမ်းဖြင့်ဖန်တီးထားသည်။
/// ပိုမိုသိရှိလိုပါက၎င်း၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
///
/// [`range`]: BTreeMap::range
#[stable(feature = "btree_range", since = "1.17.0")]
pub struct Range<'a, K: 'a, V: 'a> {
    inner: LeafRange<marker::Immut<'a>, K, V>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V: fmt::Debug> fmt::Debug for Range<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.clone()).finish()
    }
}

/// `BTreeMap` တွင်ထည့်သွင်းထားသည့်ကဏ္subခွဲခွဲများမှတစ်ဆင့်ပြောင်းလဲခြင်းဖြစ်သည်။
///
/// ဤ `struct` ကို [`BTreeMap`] ပေါ်ရှိ [`range_mut`] နည်းလမ်းဖြင့်ဖန်တီးထားသည်။
/// ပိုမိုသိရှိလိုပါက၎င်း၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
///
/// [`range_mut`]: BTreeMap::range_mut
#[stable(feature = "btree_range", since = "1.17.0")]
pub struct RangeMut<'a, K: 'a, V: 'a> {
    inner: LeafRange<marker::ValMut<'a>, K, V>,

    // `K` နှင့် `V` တွင်လျော့ပါးသွားမည်ဖြစ်မည်မဟုတ်
    _marker: PhantomData<&'a mut (K, V)>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V: fmt::Debug> fmt::Debug for RangeMut<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let range = Range { inner: self.inner.reborrow() };
        f.debug_list().entries(range).finish()
    }
}

impl<K, V> BTreeMap<K, V> {
    /// အသစ်တစ်ခုဖြစ်သောဗလာ `BTreeMap` ကိုပြုလုပ်သည်။
    ///
    /// သူ့ဟာသူဘာမှခွဲဝေချထားပေးရန်မထားဘူး
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    ///
    /// // entries တွေကိုယခုအချည်းနှီးသောမြေပုံထဲသို့ထည့်သွင်းနိုင်ပါတယ်
    /// map.insert(1, "a");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_btree_new", issue = "71835")]
    pub const fn new() -> BTreeMap<K, V>
    where
        K: Ord,
    {
        BTreeMap { root: None, length: 0 }
    }

    /// ဒြပ်စင်အားလုံးဖယ်ရှားခြင်း, မြေပုံရှင်းလင်းသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "a");
    /// a.clear();
    /// assert!(a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = BTreeMap { root: None, length: 0 };
    }

    /// သော့နှင့်သက်ဆိုင်သောတန်ဖိုးကိုရည်ညွှန်းသည်။
    ///
    /// သော့သည်မြေပုံ၏သော့ပုံစံအမျိုးအစားတစ်ခု၏မည်သည့်ချေးငှားပုံစံမဆိုဖြစ်နိုင်သည်၊ သို့သော်ချေးထားသောပုံစံပေါ်တွင် * မှာယူခြင်းသည်သော့အမျိုးအစားပေါ်ရှိအမှာစာနှင့်ကိုက်ညီရမည်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.get(&1), Some(&"a"));
    /// assert_eq!(map.get(&2), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get<Q: ?Sized>(&self, key: &Q) -> Option<&V>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        let root_node = self.root.as_ref()?.reborrow();
        match root_node.search_tree(key) {
            Found(handle) => Some(handle.into_kv().1),
            GoDown(_) => None,
        }
    }

    /// ပေးထားသော key နှင့်သက်ဆိုင်သော key value value ကို return ပြန်ပေးသည်။
    ///
    /// ပေးထားသောသော့သည်မြေပုံ၏သော့အမျိုးအစားအမျိုးအစားတစ်ခုဖြစ်နိုင်သော်လည်းချေးထားသောပုံစံပေါ်တွင် * မှာယူခြင်းသည်သော့အမျိုးအစားပေါ်ရှိအမှာစာနှင့်ကိုက်ညီရမည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.get_key_value(&1), Some((&1, &"a")));
    /// assert_eq!(map.get_key_value(&2), None);
    /// ```
    #[stable(feature = "map_get_key_value", since = "1.40.0")]
    pub fn get_key_value<Q: ?Sized>(&self, k: &Q) -> Option<(&K, &V)>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        let root_node = self.root.as_ref()?.reborrow();
        match root_node.search_tree(k) {
            Found(handle) => Some(handle.into_kv()),
            GoDown(_) => None,
        }
    }

    /// မြေပုံထဲရှိပထမဆုံးသောတန်ဖိုးတန်ဖိုးစုံကိုပြန်ပို့သည်။
    /// ဒီစုံတွဲထဲရှိသော့သည်မြေပုံထဲရှိအနိမ့်ဆုံးသော့ဖြစ်သည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// assert_eq!(map.first_key_value(), None);
    /// map.insert(1, "b");
    /// map.insert(2, "a");
    /// assert_eq!(map.first_key_value(), Some((&1, &"b")));
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn first_key_value(&self) -> Option<(&K, &V)>
    where
        K: Ord,
    {
        let root_node = self.root.as_ref()?.reborrow();
        root_node.first_leaf_edge().right_kv().ok().map(Handle::into_kv)
    }

    /// In-post ကိုကိုင်တွယ်များအတွက်မြေပုံအတွက်ပထမ ဦး ဆုံး entry ကိုပြန်သွားသည်။
    /// ဒီထည့်သွင်းမှု၏သော့သည်မြေပုံတွင်အနည်းဆုံးသော့ဖြစ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// map.insert(2, "b");
    /// if let Some(mut entry) = map.first_entry() {
    ///     if *entry.key() > 0 {
    ///         entry.insert("first");
    ///     }
    /// }
    /// assert_eq!(*map.get(&1).unwrap(), "first");
    /// assert_eq!(*map.get(&2).unwrap(), "b");
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn first_entry(&mut self) -> Option<OccupiedEntry<'_, K, V>>
    where
        K: Ord,
    {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = map.root.as_mut()?.borrow_mut();
        let kv = root_node.first_leaf_edge().right_kv().ok()?;
        Some(OccupiedEntry { handle: kv.forget_node_type(), dormant_map, _marker: PhantomData })
    }

    /// မြေပုံထဲရှိပထမဆုံးဒြပ်စင်အားဖယ်ထုတ်ပြီးပြန်လည်ပေးသည်။
    /// ဤဒြပ်စင်၏သော့သည်မြေပုံတွင်ရှိသောနိမ့်ဆုံးသော့ဖြစ်သည်။
    ///
    /// # Examples
    ///
    /// ကြားခံတစ်ခုစီအတွက်အသုံးဝင်သောမြေပုံတစ်ခုထားရှိစဉ်ကုန်းအားဖြင့်ဒြပ်စင်များကိုဖျန်ရန်။
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// map.insert(2, "b");
    /// while let Some((key, _val)) = map.pop_first() {
    ///     assert!(map.iter().all(|(k, _v)| *k > key));
    /// }
    /// assert!(map.is_empty());
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn pop_first(&mut self) -> Option<(K, V)>
    where
        K: Ord,
    {
        self.first_entry().map(|entry| entry.remove_entry())
    }

    /// မြေပုံထဲရှိနောက်ဆုံးသော့ချက်တန်ဖိုးအတွဲကိုပြန်ပို့ပေးသည်။
    /// ဒီစုံတွဲထဲရှိသော့သည်မြေပုံရှိအမြင့်ဆုံးသော့ဖြစ်သည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "b");
    /// map.insert(2, "a");
    /// assert_eq!(map.last_key_value(), Some((&2, &"a")));
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn last_key_value(&self) -> Option<(&K, &V)>
    where
        K: Ord,
    {
        let root_node = self.root.as_ref()?.reborrow();
        root_node.last_leaf_edge().left_kv().ok().map(Handle::into_kv)
    }

    /// In-နေရာကိုင်တွယ်များအတွက်မြေပုံအတွက်နောက်ဆုံး entry ကိုပြန်သွားသည်။
    /// ဤ entry ၏သော့သည်မြေပုံရှိအမြင့်ဆုံးသော့ဖြစ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// map.insert(2, "b");
    /// if let Some(mut entry) = map.last_entry() {
    ///     if *entry.key() > 0 {
    ///         entry.insert("last");
    ///     }
    /// }
    /// assert_eq!(*map.get(&1).unwrap(), "a");
    /// assert_eq!(*map.get(&2).unwrap(), "last");
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn last_entry(&mut self) -> Option<OccupiedEntry<'_, K, V>>
    where
        K: Ord,
    {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = map.root.as_mut()?.borrow_mut();
        let kv = root_node.last_leaf_edge().left_kv().ok()?;
        Some(OccupiedEntry { handle: kv.forget_node_type(), dormant_map, _marker: PhantomData })
    }

    /// မြေပုံ၏နောက်ဆုံးဒြပ်စင်ကိုဖယ်ထုတ်ပြီးပြန်လည်ပေးသည်။
    /// ဒီဒြပ်စင်၏သော့သည်မြေပုံတွင်ရှိသောအမြင့်ဆုံးသော့ဖြစ်သည်။
    ///
    /// # Examples
    ///
    /// ကြားခံတစ်ခုစီအတွက်အသုံးဝင်သောမြေပုံတစ်ခုထားရှိစဉ်အစဉ်လိုက်အစဉ်လိုက်ဒြပ်စင်များကိုဖျန်။
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// map.insert(2, "b");
    /// while let Some((key, _val)) = map.pop_last() {
    ///     assert!(map.iter().all(|(k, _v)| *k < key));
    /// }
    /// assert!(map.is_empty());
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn pop_last(&mut self) -> Option<(K, V)>
    where
        K: Ord,
    {
        self.last_entry().map(|entry| entry.remove_entry())
    }

    /// အကယ်၍ မြေပုံသည်သတ်မှတ်ထားသောသော့အတွက်တန်ဖိုးပါ ၀ င်ပါက `true` သို့ပြန်သွားသည်။
    ///
    /// သော့သည်မြေပုံ၏သော့ပုံစံအမျိုးအစားတစ်ခု၏မည်သည့်ချေးငှားပုံစံမဆိုဖြစ်နိုင်သည်၊ သို့သော်ချေးထားသောပုံစံပေါ်တွင် * မှာယူခြင်းသည်သော့အမျိုးအစားပေါ်ရှိအမှာစာနှင့်ကိုက်ညီရမည်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.contains_key(&1), true);
    /// assert_eq!(map.contains_key(&2), false);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn contains_key<Q: ?Sized>(&self, key: &Q) -> bool
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        self.get(key).is_some()
    }

    /// သော့ကိုသက်ဆိုင်ရာတန်ဖိုးတစ်ခု mutable ရည်ညွှန်းပြန်သွားသည်။
    ///
    /// သော့သည်မြေပုံ၏သော့ပုံစံအမျိုးအစားတစ်ခု၏မည်သည့်ချေးငှားပုံစံမဆိုဖြစ်နိုင်သည်၊ သို့သော်ချေးထားသောပုံစံပေါ်တွင် * မှာယူခြင်းသည်သော့အမျိုးအစားပေါ်ရှိအမှာစာနှင့်ကိုက်ညီရမည်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// if let Some(x) = map.get_mut(&1) {
    ///     *x = "b";
    /// }
    /// assert_eq!(map[&1], "b");
    /// ```
    // အကောင်အထည်ဖော်မှုမှတ်စုများအတွက် `get` ကိုကြည့်ပါ။ ၎င်းသည် mut ၏ထည့်သွင်းထားသောကော်ပီကူးခြင်းဖြစ်သည်
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut<Q: ?Sized>(&mut self, key: &Q) -> Option<&mut V>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        let root_node = self.root.as_mut()?.borrow_mut();
        match root_node.search_tree(key) {
            Found(handle) => Some(handle.into_val_mut()),
            GoDown(_) => None,
        }
    }

    /// key-value pair ကိုမြေပုံထဲသို့ထည့်သည်။
    ///
    /// မြေပုံတွင်ဤသော့ချက်ပစ္စုပ္ပန်မရှိပါက `None` ကိုပြန်ပို့ပေးသည်။
    ///
    /// မြေပုံ၌ဤသော့ပစ္စုပ္ပန်ရှိပါကတန်ဖိုးကိုအသစ်ပြောင်းပြီးတန်ဖိုးဟောင်းကိုပြန်ပို့သည်။
    /// သော့ကိုသော်လည်း update လုပ်မထားဘူး,တူညီဖြစ်ခြင်းမရှိဘဲ `==` ဖြစ်နိုင်သည့်အမျိုးအစားများအတွက်အရေးကြီးသည်။
    ///
    /// ပိုပြီးများအတွက် [module-level documentation] ကိုကြည့်ပါ။
    ///
    /// [module-level documentation]: index.html#insert-and-complex-keys
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// assert_eq!(map.insert(37, "a"), None);
    /// assert_eq!(map.is_empty(), false);
    ///
    /// map.insert(37, "b");
    /// assert_eq!(map.insert(37, "c"), Some("b"));
    /// assert_eq!(map[&37], "c");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, key: K, value: V) -> Option<V>
    where
        K: Ord,
    {
        match self.entry(key) {
            Occupied(mut entry) => Some(entry.insert(value)),
            Vacant(entry) => {
                entry.insert(value);
                None
            }
        }
    }

    /// key-value pair ကိုမြေပုံထဲသို့ထည့်ရန်နှင့် entration ထဲရှိတန်ဖိုးကိုပြောင်းလဲနိုင်သောရည်ညွှန်းချက်ကိုပြန်ပို့သည်။
    ///
    /// မြေပုံတွင်ဤသော့ပစ္စုပ္ပန်ရှိပါကဘာမျှမွမ်းမံပြင်ဆင်ပြီးသိမ်းပိုက်ထားသည့် ၀ င်ရောက်မှုတန်ဖိုးနှင့်တန်ဖိုးကိုပြန်လည်ပေးအပ်မည်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// #![feature(map_try_insert)]
    ///
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// assert_eq!(map.try_insert(37, "a").unwrap(), &"a");
    ///
    /// let err = map.try_insert(37, "b").unwrap_err();
    /// assert_eq!(err.entry.key(), &37);
    /// assert_eq!(err.entry.get(), &"a");
    /// assert_eq!(err.value, "b");
    /// ```
    ///
    #[unstable(feature = "map_try_insert", issue = "82766")]
    pub fn try_insert(&mut self, key: K, value: V) -> Result<&mut V, OccupiedError<'_, K, V>>
    where
        K: Ord,
    {
        match self.entry(key) {
            Occupied(entry) => Err(OccupiedError { entry, value }),
            Vacant(entry) => Ok(entry.insert(value)),
        }
    }

    /// မြေပုံထဲမှသော့တစ်ခုကိုဖယ်ထုတ်ပြီး၊ အကယ်၍ သော့သည်မြေပုံတွင်ရှိခဲ့လျှင်သော့တွင်တန်ဖိုးကိုပြန်ပို့သည်။
    ///
    /// သော့သည်မြေပုံ၏သော့ပုံစံအမျိုးအစားတစ်ခု၏မည်သည့်ချေးငှားပုံစံမဆိုဖြစ်နိုင်သည်၊ သို့သော်ချေးထားသောပုံစံပေါ်တွင် * မှာယူခြင်းသည်သော့အမျိုးအစားပေါ်ရှိအမှာစာနှင့်ကိုက်ညီရမည်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.remove(&1), Some("a"));
    /// assert_eq!(map.remove(&1), None);
    /// ```
    ///
    #[doc(alias = "delete")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove<Q: ?Sized>(&mut self, key: &Q) -> Option<V>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        self.remove_entry(key).map(|(_, v)| v)
    }

    /// မြေပုံထဲမှသော့တစ်ချောင်းကိုဖယ်ထုတ်ပြီး၊ အကယ်၍ သော့သည်ယခင်မြေပုံတွင်ရှိခဲ့လျှင်သိုလှောင်ထားသောသော့နှင့်တန်ဖိုးကိုပြန်ပို့သည်။
    ///
    /// သော့သည်မြေပုံ၏သော့ပုံစံအမျိုးအစားတစ်ခု၏မည်သည့်ချေးငှားပုံစံမဆိုဖြစ်နိုင်သည်၊ သို့သော်ချေးထားသောပုံစံပေါ်တွင် * မှာယူခြင်းသည်သော့အမျိုးအစားပေါ်ရှိအမှာစာနှင့်ကိုက်ညီရမည်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.remove_entry(&1), Some((1, "a")));
    /// assert_eq!(map.remove_entry(&1), None);
    /// ```
    ///
    #[stable(feature = "btreemap_remove_entry", since = "1.45.0")]
    pub fn remove_entry<Q: ?Sized>(&mut self, key: &Q) -> Option<(K, V)>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = map.root.as_mut()?.borrow_mut();
        match root_node.search_tree(key) {
            Found(handle) => {
                Some(OccupiedEntry { handle, dormant_map, _marker: PhantomData }.remove_entry())
            }
            GoDown(_) => None,
        }
    }

    /// အဆိုပါ predicate အားဖြင့်သတ်မှတ်ထားသောသာဒြပ်စင်ဆက်လက်ထိန်းသိမ်းထားသည်။
    ///
    /// တစ်နည်းအားဖြင့်ဆိုရလျှင် `(k, v)` အားလုံးအား `f(&k, &mut v)` က `false` ကိုပြန်ပေးသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(btree_retain)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<i32, i32> = (0..8).map(|x| (x, x*10)).collect();
    /// // ပင်နံပါတ်များသော့နှင့်အတူဒြပ်စင်သာထားပါ။
    /// map.retain(|&k, _| k % 2 == 0);
    /// assert!(map.into_iter().eq(vec![(0, 0), (2, 20), (4, 40), (6, 60)]));
    /// ```
    #[inline]
    #[unstable(feature = "btree_retain", issue = "79025")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        K: Ord,
        F: FnMut(&K, &mut V) -> bool,
    {
        self.drain_filter(|k, v| !f(k, v));
    }

    /// `other` မှ element အားလုံးကို `Self` သို့ရွှေ့ပြီး `other` ဗလာဖြစ်နေသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "a");
    /// a.insert(2, "b");
    /// a.insert(3, "c");
    ///
    /// let mut b = BTreeMap::new();
    /// b.insert(3, "d");
    /// b.insert(4, "e");
    /// b.insert(5, "f");
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.len(), 5);
    /// assert_eq!(b.len(), 0);
    ///
    /// assert_eq!(a[&1], "a");
    /// assert_eq!(a[&2], "b");
    /// assert_eq!(a[&3], "d");
    /// assert_eq!(a[&4], "e");
    /// assert_eq!(a[&5], "f");
    /// ```
    #[stable(feature = "btree_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self)
    where
        K: Ord,
    {
        // ငါတို့တစ်စုံတစ်ရာကိုဖြည့်စွက်ရန်လိုသလား။
        if other.is_empty() {
            return;
        }

        // `self` ဗလာဖြစ်လျှင် `self` နှင့် `other` ကိုလဲလှယ်နိုင်သည်။
        if self.is_empty() {
            mem::swap(self, other);
            return;
        }

        let self_iter = mem::take(self).into_iter();
        let other_iter = mem::take(other).into_iter();
        let root = BTreeMap::ensure_is_owned(&mut self.root);
        root.append_from_sorted_iters(self_iter, other_iter, &mut self.length)
    }

    /// မြေပုံရှိဒြပ်စင်အမျိုးစုံအပေါ်နှစ်ထပ်ကြားကာ ထပ်မံ၍ တည်ဆောက်သည်။
    /// အရိုးရှင်းဆုံးနည်းလမ်းမှာ range syntax `min..max` ကိုအသုံးပြုရန်ဖြစ်သည်။ ထို့ကြောင့် `range(min..max)` က min (inclusive) မှ max (exclusive) သို့ element များကိုထုတ်ပေးလိမ့်မည်။
    /// အကွာအဝေးကို `(Bound<T>, Bound<T>)` ဟုလည်းခေါ်နိုင်သည်။ ဥပမာ `range((Excluded(4), Included(10)))` သည်လက်ဝဲသီးသန့်ရှိပြီးလက်ျာဘက်ပါ ၀ င်သောအကွာအဝေးကို ၄ မှ ၁၀ အထိရရှိလိမ့်မည်။
    ///
    ///
    /// # Panics
    ///
    /// အကွာအဝေး `start > end` လျှင် Panics ။
    /// အကွာအဝေး `start == end` နှင့်နှစ် ဦး စလုံးဘောငျ `Excluded` လျှင် Panics ။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BTreeMap;
    /// use std::ops::Bound::Included;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(3, "a");
    /// map.insert(5, "b");
    /// map.insert(8, "c");
    /// for (&key, &value) in map.range((Included(&4), Included(&8))) {
    ///     println!("{}: {}", key, value);
    /// }
    /// assert_eq!(Some((&5, &"b")), map.range(4..).next());
    /// ```
    ///
    ///
    #[stable(feature = "btree_range", since = "1.17.0")]
    pub fn range<T: ?Sized, R>(&self, range: R) -> Range<'_, K, V>
    where
        T: Ord,
        K: Borrow<T> + Ord,
        R: RangeBounds<T>,
    {
        if let Some(root) = &self.root {
            Range { inner: root.reborrow().range_search(range) }
        } else {
            Range { inner: LeafRange::none() }
        }
    }

    /// မြေပုံရှိဒြပ်စင်အမျိုးစုံအပေါ် mutable နှစ်ဆထပ်ကာထပ်ကာထပ်မံတည်ဆောက်သည်။
    /// အရိုးရှင်းဆုံးနည်းလမ်းမှာ range syntax `min..max` ကိုအသုံးပြုရန်ဖြစ်သည်။ ထို့ကြောင့် `range(min..max)` က min (inclusive) မှ max (exclusive) သို့ element များကိုထုတ်ပေးလိမ့်မည်။
    /// အကွာအဝေးကို `(Bound<T>, Bound<T>)` ဟုလည်းခေါ်နိုင်သည်။ ဥပမာ `range((Excluded(4), Included(10)))` သည်လက်ဝဲသီးသန့်ရှိပြီးလက်ျာဘက်ပါ ၀ င်သောအကွာအဝေးကို ၄ မှ ၁၀ အထိရရှိလိမ့်မည်။
    ///
    ///
    /// # Panics
    ///
    /// အကွာအဝေး `start > end` လျှင် Panics ။
    /// အကွာအဝေး `start == end` နှင့်နှစ် ဦး စလုံးဘောငျ `Excluded` လျှင် Panics ။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<&str, i32> = ["Alice", "Bob", "Carol", "Cheryl"]
    ///     .iter()
    ///     .map(|&s| (s, 0))
    ///     .collect();
    /// for (_, balance) in map.range_mut("B".."Cheryl") {
    ///     *balance += 100;
    /// }
    /// for (name, balance) in &map {
    ///     println!("{} => {}", name, balance);
    /// }
    /// ```
    ///
    ///
    #[stable(feature = "btree_range", since = "1.17.0")]
    pub fn range_mut<T: ?Sized, R>(&mut self, range: R) -> RangeMut<'_, K, V>
    where
        T: Ord,
        K: Borrow<T> + Ord,
        R: RangeBounds<T>,
    {
        if let Some(root) = &mut self.root {
            RangeMut { inner: root.borrow_valmut().range_search(range), _marker: PhantomData }
        } else {
            RangeMut { inner: LeafRange::none(), _marker: PhantomData }
        }
    }

    /// ပေးထားသောသော့၏သက်ဆိုင်သောနေရာကိုမြေပုံပေါ်တွင်ကိုင်တွယ်ခြင်း။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut count: BTreeMap<&str, usize> = BTreeMap::new();
    ///
    /// // vec အတွင်းရှိစာလုံးအရေအတွက်ကိုရေတွက်ပါ
    /// for x in vec!["a", "b", "a", "c", "a", "b"] {
    ///     *count.entry(x).or_insert(0) += 1;
    /// }
    ///
    /// assert_eq!(count["a"], 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn entry(&mut self, key: K) -> Entry<'_, K, V>
    where
        K: Ord,
    {
        // FIXME(@porglezomp) ကျွန်ုပ်တို့သည်ထည့်သွင်းခြင်းမပြုပါကခွဲဝေချထားခြင်းကိုရှောင်ပါ
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = Self::ensure_is_owned(&mut map.root).borrow_mut();
        match root_node.search_tree(&key) {
            Found(handle) => Occupied(OccupiedEntry { handle, dormant_map, _marker: PhantomData }),
            GoDown(handle) => {
                Vacant(VacantEntry { key, handle, dormant_map, _marker: PhantomData })
            }
        }
    }

    /// စုဆောင်းမှုကိုပေးထားသောသော့တွင်နှစ်ပိုင်းခွဲထားသည်။
    /// key အပါအ ၀ င်ပေးထားတဲ့ key ပြီးနောက်အရာအားလုံးကို return လုပ်တယ်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "a");
    /// a.insert(2, "b");
    /// a.insert(3, "c");
    /// a.insert(17, "d");
    /// a.insert(41, "e");
    ///
    /// let b = a.split_off(&3);
    ///
    /// assert_eq!(a.len(), 2);
    /// assert_eq!(b.len(), 3);
    ///
    /// assert_eq!(a[&1], "a");
    /// assert_eq!(a[&2], "b");
    ///
    /// assert_eq!(b[&3], "c");
    /// assert_eq!(b[&17], "d");
    /// assert_eq!(b[&41], "e");
    /// ```
    #[stable(feature = "btree_split_off", since = "1.11.0")]
    pub fn split_off<Q: ?Sized + Ord>(&mut self, key: &Q) -> Self
    where
        K: Borrow<Q> + Ord,
    {
        if self.is_empty() {
            return Self::new();
        }

        let total_num = self.len();
        let left_root = self.root.as_mut().unwrap(); // ဗလာမဟုတ်သောကြောင့် unwrap အောင်မြင်

        let right_root = left_root.split_off(key);

        let (new_left_len, right_len) = Root::calc_split_length(total_num, &left_root, &right_root);
        self.length = new_left_len;

        BTreeMap { root: Some(right_root), length: right_len }
    }

    /// တက်သော key order အားဖြင့် element များအားလုံး (key-value pair) သို့လည်ပတ်သည့်ကြားခံတစ်ခုကိုဖန်တီးပြီး element တစ်ခုအားဖယ်ရှားသင့်မသင့်ဆုံးဖြတ်ရန် closure ကိုအသုံးပြုသည်။
    /// အကယ်၍ ပိတ်သိမ်းခြင်းသည် `true` ကိုပြန်လည်ရောက်ရှိပါက၎င်းဒြပ်စင်သည်မြေပုံမှဖယ်ရှားပြီးလိုက်လျောညီထွေဖြစ်မည်။
    /// အကယ်၍ ပိတ်သိမ်းခြင်းသည် `false` သို့မဟုတ် panics ကိုပြန်ရောက်ပါက၎င်းဒြပ်စင်သည်မြေပုံတွင်ရှိနေသော်လည်းအလျှင်းမပြုနိုင်ပါ။
    ///
    /// သင်ထပ်တလဲလဲလုပ်ထားတာကသင်ဟာသိမ်းဆည်းခြင်းသို့မဟုတ်ဖယ်ရှားခြင်းအတွက်ရွေးချယ်သည်ဖြစ်စေမည်သို့ပင်ရှိစေကာမူပိတ်သိမ်းခြင်းတွင်ပါဝင်သောအရာတစ်ခုစီ၏တန်ဖိုးကိုသင့်အား mutate လုပ်ရန်ခွင့်ပြုသည်။
    ///
    /// အကယ်၍ ကြားဖြတ်သည်တစ်စိတ်တစ်ပိုင်းကိုသာစားသုံးခြင်းသို့မဟုတ်လုံးဝမသုံးစွဲပါကကျန်ရှိနေသေးသောဒြပ်စင်တစ်ခုစီသည်၎င်း၏တန်ဖိုးကိုပြောင်းလဲနိုင်ပြီး `true` ကိုပြန်ခြင်းအားဖြင့်၎င်းဒြပ်စင်ကိုဖယ်ရှား။ ကျဆင်းစေနိုင်သည်။
    ///
    ///
    /// panic သည်ပိတ်ခြင်းတွင်ဖြစ်ပေါ်ပါကသို့မဟုတ် element တစ်ခုကျဆင်းနေချိန်တွင် panic ဖြစ်ပေါ်ခြင်းသို့မဟုတ် `DrainFilter` တန်ဖိုးပေါက်ကြားခြင်းရှိပါကမည်သည့်ဒြပ်စင်မည်မျှထပ်မံပိတ်သိမ်းမည်ကိုအတိအကျမသိရသေးပါ။
    ///
    /// # Examples
    ///
    /// မူလမြေပုံကိုပြန်လည်အသုံးပြုခြင်းအားဖြင့်၊
    ///
    /// ```
    /// #![feature(btree_drain_filter)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<i32, i32> = (0..8).map(|x| (x, x)).collect();
    /// let evens: BTreeMap<_, _> = map.drain_filter(|k, _v| k % 2 == 0).collect();
    /// let odds = map;
    /// assert_eq!(evens.keys().copied().collect::<Vec<_>>(), vec![0, 2, 4, 6]);
    /// assert_eq!(odds.keys().copied().collect::<Vec<_>>(), vec![1, 3, 5, 7]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "btree_drain_filter", issue = "70530")]
    pub fn drain_filter<F>(&mut self, pred: F) -> DrainFilter<'_, K, V, F>
    where
        K: Ord,
        F: FnMut(&K, &mut V) -> bool,
    {
        DrainFilter { pred, inner: self.drain_filter_inner() }
    }

    pub(super) fn drain_filter_inner(&mut self) -> DrainFilterInner<'_, K, V>
    where
        K: Ord,
    {
        if let Some(root) = self.root.as_mut() {
            let (root, dormant_root) = DormantMutRef::new(root);
            let front = root.borrow_mut().first_leaf_edge();
            DrainFilterInner {
                length: &mut self.length,
                dormant_root: Some(dormant_root),
                cur_leaf_edge: Some(front),
            }
        } else {
            DrainFilterInner { length: &mut self.length, dormant_root: None, cur_leaf_edge: None }
        }
    }

    /// သော့များအားလုံးကိုအလည်အပတ်သွားသည့်စားသုံးသူကြားဖြတ်ကိုဖန်တီးလိုက်သည်။
    /// ဤဖုန်းခေါ်ဆိုပါကမြေပုံကို သုံး၍ မရပါ။
    /// ကြားမှာ element အမျိုးအစား `K` ဖြစ်ပါတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_into_keys_values)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(2, "b");
    /// a.insert(1, "a");
    ///
    /// let keys: Vec<i32> = a.into_keys().collect();
    /// assert_eq!(keys, [1, 2]);
    /// ```
    #[inline]
    #[unstable(feature = "map_into_keys_values", issue = "75294")]
    pub fn into_keys(self) -> IntoKeys<K, V> {
        IntoKeys { inner: self.into_iter() }
    }

    /// သော့များအားဖြင့်နိုင်ရန်အတွက်တန်ဖိုးအားလုံးသို့လည်ပတ်နေသည့်စားသုံးသူကြားမှာဖန်တီးသည်။
    /// ဤဖုန်းခေါ်ဆိုပါကမြေပုံကို သုံး၍ မရပါ။
    /// ကြားမှာ element အမျိုးအစား `V` ဖြစ်ပါတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_into_keys_values)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "hello");
    /// a.insert(2, "goodbye");
    ///
    /// let values: Vec<&str> = a.into_values().collect();
    /// assert_eq!(values, ["hello", "goodbye"]);
    /// ```
    #[inline]
    #[unstable(feature = "map_into_keys_values", issue = "75294")]
    pub fn into_values(self) -> IntoValues<K, V> {
        IntoValues { inner: self.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> IntoIterator for &'a BTreeMap<K, V> {
    type Item = (&'a K, &'a V);
    type IntoIter = Iter<'a, K, V>;

    fn into_iter(self) -> Iter<'a, K, V> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K: 'a, V: 'a> Iterator for Iter<'a, K, V> {
    type Item = (&'a K, &'a V);

    fn next(&mut self) -> Option<(&'a K, &'a V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.next_unchecked() })
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.length, Some(self.length))
    }

    fn last(mut self) -> Option<(&'a K, &'a V)> {
        self.next_back()
    }

    fn min(mut self) -> Option<(&'a K, &'a V)> {
        self.next()
    }

    fn max(mut self) -> Option<(&'a K, &'a V)> {
        self.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for Iter<'_, K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K: 'a, V: 'a> DoubleEndedIterator for Iter<'a, K, V> {
    fn next_back(&mut self) -> Option<(&'a K, &'a V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.next_back_unchecked() })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for Iter<'_, K, V> {
    fn len(&self) -> usize {
        self.length
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> Clone for Iter<'_, K, V> {
    fn clone(&self) -> Self {
        Iter { range: self.range.clone(), length: self.length }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> IntoIterator for &'a mut BTreeMap<K, V> {
    type Item = (&'a K, &'a mut V);
    type IntoIter = IterMut<'a, K, V>;

    fn into_iter(self) -> IterMut<'a, K, V> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K: 'a, V: 'a> Iterator for IterMut<'a, K, V> {
    type Item = (&'a K, &'a mut V);

    fn next(&mut self) -> Option<(&'a K, &'a mut V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.next_unchecked() })
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.length, Some(self.length))
    }

    fn last(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next_back()
    }

    fn min(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next()
    }

    fn max(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K: 'a, V: 'a> DoubleEndedIterator for IterMut<'a, K, V> {
    fn next_back(&mut self) -> Option<(&'a K, &'a mut V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.next_back_unchecked() })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for IterMut<'_, K, V> {
    fn len(&self) -> usize {
        self.length
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for IterMut<'_, K, V> {}

impl<'a, K, V> IterMut<'a, K, V> {
    /// ကျန်ရှိသောပစ္စည်းများအပေါ်ကိုးကားတဲ့ကြားမှာပြန်သွားသည်။
    #[inline]
    pub(super) fn iter(&self) -> Iter<'_, K, V> {
        Iter { range: self.range.iter(), length: self.length }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> IntoIterator for BTreeMap<K, V> {
    type Item = (K, V);
    type IntoIter = IntoIter<K, V>;

    fn into_iter(self) -> IntoIter<K, V> {
        let mut me = ManuallyDrop::new(self);
        if let Some(root) = me.root.take() {
            let full_range = root.into_dying().full_range();

            IntoIter { range: full_range, length: me.length }
        } else {
            IntoIter { range: LeafRange::none(), length: 0 }
        }
    }
}

impl<K, V> Drop for Dropper<K, V> {
    fn drop(&mut self) {
        // non-ဖျူးကြားမှာတိုးနှင့်ဆင်တူ။
        fn next_or_end<K, V>(this: &mut Dropper<K, V>) -> Option<(K, V)> {
            if this.remaining_length == 0 {
                unsafe { ptr::read(&this.front).deallocating_end() }
                None
            } else {
                this.remaining_length -= 1;
                Some(unsafe { this.front.deallocating_next_unchecked() })
            }
        }

        struct DropGuard<'a, K, V>(&'a mut Dropper<K, V>);

        impl<'a, K, V> Drop for DropGuard<'a, K, V> {
            fn drop(&mut self) {
                // ကျနော်တို့အောက်ကလုပ်ဆောင်တူညီကွင်းဆက်ကိုဆက်လက်။
                // ဤသည်ကိုဖွင့်သည့်အခါ၌သာအလုပ်လုပ်သည်၊ ထို့ကြောင့်ကျွန်ုပ်တို့သည်ဤအချိန်တွင် panics ကိုဂရုစိုက်စရာမလိုပါ (ဖျက်သိမ်းလိမ့်မည်) ။
                while let Some(_pair) = next_or_end(&mut self.0) {}
            }
        }

        while let Some(pair) = next_or_end(self) {
            let guard = DropGuard(self);
            drop(pair);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "btree_drop", since = "1.7.0")]
impl<K, V> Drop for IntoIter<K, V> {
    fn drop(&mut self) {
        if let Some(front) = self.range.front.take() {
            Dropper { front, remaining_length: self.length };
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> Iterator for IntoIter<K, V> {
    type Item = (K, V);

    fn next(&mut self) -> Option<(K, V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.front.as_mut().unwrap().deallocating_next_unchecked() })
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.length, Some(self.length))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> DoubleEndedIterator for IntoIter<K, V> {
    fn next_back(&mut self) -> Option<(K, V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.back.as_mut().unwrap().deallocating_next_back_unchecked() })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for IntoIter<K, V> {
    fn len(&self) -> usize {
        self.length
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for IntoIter<K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> Iterator for Keys<'a, K, V> {
    type Item = &'a K;

    fn next(&mut self) -> Option<&'a K> {
        self.inner.next().map(|(k, _)| k)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<&'a K> {
        self.next_back()
    }

    fn min(mut self) -> Option<&'a K> {
        self.next()
    }

    fn max(mut self) -> Option<&'a K> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> DoubleEndedIterator for Keys<'a, K, V> {
    fn next_back(&mut self) -> Option<&'a K> {
        self.inner.next_back().map(|(k, _)| k)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for Keys<'_, K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for Keys<'_, K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> Clone for Keys<'_, K, V> {
    fn clone(&self) -> Self {
        Keys { inner: self.inner.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> Iterator for Values<'a, K, V> {
    type Item = &'a V;

    fn next(&mut self) -> Option<&'a V> {
        self.inner.next().map(|(_, v)| v)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<&'a V> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> DoubleEndedIterator for Values<'a, K, V> {
    fn next_back(&mut self) -> Option<&'a V> {
        self.inner.next_back().map(|(_, v)| v)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for Values<'_, K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for Values<'_, K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> Clone for Values<'_, K, V> {
    fn clone(&self) -> Self {
        Values { inner: self.inner.clone() }
    }
}

/// BTreeMap ပေါ်တွင် `drain_filter` ကိုခေါ်ဆိုခြင်းဖြင့်ထုတ်လုပ်သည်။
#[unstable(feature = "btree_drain_filter", issue = "70530")]
pub struct DrainFilter<'a, K, V, F>
where
    K: 'a,
    V: 'a,
    F: 'a + FnMut(&K, &mut V) -> bool,
{
    pred: F,
    inner: DrainFilterInner<'a, K, V>,
}
/// DrainFilter ၏အကောင်အထည်ဖော်မှုအများစုသည် predicate အမျိုးအစားထက်ယေဘုယျအားဖြင့် BTreeSet::DrainFilter အတွက်လည်းအစေခံပါသည်။
///
pub(super) struct DrainFilterInner<'a, K: 'a, V: 'a> {
    /// ငှားရမ်းထားသောမြေပုံရှိသက်တမ်းအကွက်ကိုရည်ညွှန်းသည်၊
    length: &'a mut usize,
    /// ငှားရမ်းထားသောမြေပုံရှိရင်းမြစ်ကိုရည်ညွှန်းသည်။
    /// drop handler ကို `take` ခွင့်ပြုရန် `Option` တွင်ပတ်ရစ်သည်။
    dormant_root: Option<DormantMutRef<'a, Root<K, V>>>,
    /// နောက်တစ်ခုသို့ပြန်သွားရမည့်ဒြပ်စင်သို့မဟုတ် edge အရွက်ရှေ့တွင် edge အရွက်ပါရှိသည်။
    /// မြေပုံသည် root မရှိလျှင်၊ နောက်ဆုံး edge စာရွက်ကျော်လွန်သွားလျှင်သို့မဟုတ် predicate တွင် panic ဖြစ်ပွားပါကကွက်လပ်ဖြည့်ပါ။
    ///
    cur_leaf_edge: Option<Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>>,
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<K, V, F> Drop for DrainFilter<'_, K, V, F>
where
    F: FnMut(&K, &mut V) -> bool,
{
    fn drop(&mut self) {
        self.for_each(drop);
    }
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<K, V, F> fmt::Debug for DrainFilter<'_, K, V, F>
where
    K: fmt::Debug,
    V: fmt::Debug,
    F: FnMut(&K, &mut V) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.inner.peek()).finish()
    }
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<K, V, F> Iterator for DrainFilter<'_, K, V, F>
where
    F: FnMut(&K, &mut V) -> bool,
{
    type Item = (K, V);

    fn next(&mut self) -> Option<(K, V)> {
        self.inner.next(&mut self.pred)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

impl<'a, K: 'a, V: 'a> DrainFilterInner<'a, K, V> {
    /// Debug Implementations များကိုလာမည့် element ကိုခန့်မှန်းရန်ခွင့်ပြုပါ။
    pub(super) fn peek(&self) -> Option<(&K, &V)> {
        let edge = self.cur_leaf_edge.as_ref()?;
        edge.reborrow().next_kv().ok().map(Handle::into_kv)
    }

    /// အဆိုပါ predicate ပေးထားသောပုံမှန် `DrainFilter::next` နည်းလမ်း၏အကောင်အထည်ဖော်မှု။
    pub(super) fn next<F>(&mut self, pred: &mut F) -> Option<(K, V)>
    where
        F: FnMut(&K, &mut V) -> bool,
    {
        while let Ok(mut kv) = self.cur_leaf_edge.take()?.next_kv() {
            let (k, v) = kv.kv_mut();
            if pred(k, v) {
                *self.length -= 1;
                let (kv, pos) = kv.remove_kv_tracking(|| {
                    // ဘေးကင်းလုံခြုံမှု-အမြစ်ကိုမထိသောနည်းလမ်းဖြင့်တို့ထိလိမ့်မည်
                    // ပြန်လာသောအနေအထားကို invalidate ။
                    let root = unsafe { self.dormant_root.take().unwrap().awaken() };
                    root.pop_internal_level();
                    self.dormant_root = Some(DormantMutRef::new(root).1);
                });
                self.cur_leaf_edge = Some(pos);
                return Some(kv);
            }
            self.cur_leaf_edge = Some(kv.next_leaf_edge());
        }
        None
    }

    /// ပုံမှန် `DrainFilter::size_hint` နည်းလမ်းအကောင်အထည်ဖော်မှု။
    pub(super) fn size_hint(&self) -> (usize, Option<usize>) {
        // btree ကြားမှာအများအားဖြင့် `self.length` ဟာမကြည့်ရသေးသော element အရေအတွက်ဖြစ်သည်။
        // ဤတွင်၎င်းတွင်သွားရောက်ကြည့်ရှုခဲ့သည့်ဒြပ်စင်များပါ ၀ င်ပြီးကြိုတင်ခန့်မှန်းမှုများသည် drain သို့မသွားရန်ဆုံးဖြတ်ခဲ့သည်။
        // ဒီအပေါ်ကန့်သတ်ချက်ကိုပိုပြီးတိတိကျကျလုပ်ဖို့အပိုနေရာတစ်ခုလိုအပ်တယ်၊
        //
        (0, Some(*self.length))
    }
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<K, V, F> FusedIterator for DrainFilter<'_, K, V, F> where F: FnMut(&K, &mut V) -> bool {}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, K, V> Iterator for Range<'a, K, V> {
    type Item = (&'a K, &'a V);

    fn next(&mut self) -> Option<(&'a K, &'a V)> {
        if self.inner.is_empty() { None } else { Some(unsafe { self.next_unchecked() }) }
    }

    fn last(mut self) -> Option<(&'a K, &'a V)> {
        self.next_back()
    }

    fn min(mut self) -> Option<(&'a K, &'a V)> {
        self.next()
    }

    fn max(mut self) -> Option<(&'a K, &'a V)> {
        self.next_back()
    }
}

#[stable(feature = "map_values_mut", since = "1.10.0")]
impl<'a, K, V> Iterator for ValuesMut<'a, K, V> {
    type Item = &'a mut V;

    fn next(&mut self) -> Option<&'a mut V> {
        self.inner.next().map(|(_, v)| v)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<&'a mut V> {
        self.next_back()
    }
}

#[stable(feature = "map_values_mut", since = "1.10.0")]
impl<'a, K, V> DoubleEndedIterator for ValuesMut<'a, K, V> {
    fn next_back(&mut self) -> Option<&'a mut V> {
        self.inner.next_back().map(|(_, v)| v)
    }
}

#[stable(feature = "map_values_mut", since = "1.10.0")]
impl<K, V> ExactSizeIterator for ValuesMut<'_, K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for ValuesMut<'_, K, V> {}

impl<'a, K, V> Range<'a, K, V> {
    unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        unsafe { self.inner.front.as_mut().unwrap_unchecked().next_unchecked() }
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> Iterator for IntoKeys<K, V> {
    type Item = K;

    fn next(&mut self) -> Option<K> {
        self.inner.next().map(|(k, _)| k)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<K> {
        self.next_back()
    }

    fn min(mut self) -> Option<K> {
        self.next()
    }

    fn max(mut self) -> Option<K> {
        self.next_back()
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> DoubleEndedIterator for IntoKeys<K, V> {
    fn next_back(&mut self) -> Option<K> {
        self.inner.next_back().map(|(k, _)| k)
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> ExactSizeIterator for IntoKeys<K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> FusedIterator for IntoKeys<K, V> {}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> Iterator for IntoValues<K, V> {
    type Item = V;

    fn next(&mut self) -> Option<V> {
        self.inner.next().map(|(_, v)| v)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<V> {
        self.next_back()
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> DoubleEndedIterator for IntoValues<K, V> {
    fn next_back(&mut self) -> Option<V> {
        self.inner.next_back().map(|(_, v)| v)
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> ExactSizeIterator for IntoValues<K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> FusedIterator for IntoValues<K, V> {}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, K, V> DoubleEndedIterator for Range<'a, K, V> {
    fn next_back(&mut self) -> Option<(&'a K, &'a V)> {
        if self.inner.is_empty() { None } else { Some(unsafe { self.next_back_unchecked() }) }
    }
}

impl<'a, K, V> Range<'a, K, V> {
    unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        unsafe { self.inner.back.as_mut().unwrap_unchecked().next_back_unchecked() }
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for Range<'_, K, V> {}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<K, V> Clone for Range<'_, K, V> {
    fn clone(&self) -> Self {
        Range { inner: LeafRange { front: self.inner.front, back: self.inner.back } }
    }
}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, K, V> Iterator for RangeMut<'a, K, V> {
    type Item = (&'a K, &'a mut V);

    fn next(&mut self) -> Option<(&'a K, &'a mut V)> {
        if self.inner.is_empty() { None } else { Some(unsafe { self.next_unchecked() }) }
    }

    fn last(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next_back()
    }

    fn min(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next()
    }

    fn max(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next_back()
    }
}

impl<'a, K, V> RangeMut<'a, K, V> {
    unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        unsafe { self.inner.front.as_mut().unwrap_unchecked().next_unchecked() }
    }

    /// ကျန်ရှိသောပစ္စည်းများအပေါ်ကိုးကားတဲ့ကြားမှာပြန်သွားသည်။
    #[inline]
    pub(super) fn iter(&self) -> Range<'_, K, V> {
        Range { inner: self.inner.reborrow() }
    }
}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, K, V> DoubleEndedIterator for RangeMut<'a, K, V> {
    fn next_back(&mut self) -> Option<(&'a K, &'a mut V)> {
        if self.inner.is_empty() { None } else { Some(unsafe { self.next_back_unchecked() }) }
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for RangeMut<'_, K, V> {}

impl<'a, K, V> RangeMut<'a, K, V> {
    unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        unsafe { self.inner.back.as_mut().unwrap_unchecked().next_back_unchecked() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Ord, V> FromIterator<(K, V)> for BTreeMap<K, V> {
    fn from_iter<T: IntoIterator<Item = (K, V)>>(iter: T) -> BTreeMap<K, V> {
        let mut map = BTreeMap::new();
        map.extend(iter);
        map
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Ord, V> Extend<(K, V)> for BTreeMap<K, V> {
    #[inline]
    fn extend<T: IntoIterator<Item = (K, V)>>(&mut self, iter: T) {
        iter.into_iter().for_each(move |(k, v)| {
            self.insert(k, v);
        });
    }

    #[inline]
    fn extend_one(&mut self, (k, v): (K, V)) {
        self.insert(k, v);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, K: Ord + Copy, V: Copy> Extend<(&'a K, &'a V)> for BTreeMap<K, V> {
    fn extend<I: IntoIterator<Item = (&'a K, &'a V)>>(&mut self, iter: I) {
        self.extend(iter.into_iter().map(|(&key, &value)| (key, value)));
    }

    #[inline]
    fn extend_one(&mut self, (&k, &v): (&'a K, &'a V)) {
        self.insert(k, v);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Hash, V: Hash> Hash for BTreeMap<K, V> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        for elt in self {
            elt.hash(state);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Ord, V> Default for BTreeMap<K, V> {
    /// တစ် ဦး အချည်းနှီးသော `BTreeMap` ဖန်တီး။
    fn default() -> BTreeMap<K, V> {
        BTreeMap::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: PartialEq, V: PartialEq> PartialEq for BTreeMap<K, V> {
    fn eq(&self, other: &BTreeMap<K, V>) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a == b)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Eq, V: Eq> Eq for BTreeMap<K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: PartialOrd, V: PartialOrd> PartialOrd for BTreeMap<K, V> {
    #[inline]
    fn partial_cmp(&self, other: &BTreeMap<K, V>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Ord, V: Ord> Ord for BTreeMap<K, V> {
    #[inline]
    fn cmp(&self, other: &BTreeMap<K, V>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Debug, V: Debug> Debug for BTreeMap<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_map().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, Q: ?Sized, V> Index<&Q> for BTreeMap<K, V>
where
    K: Borrow<Q> + Ord,
    Q: Ord,
{
    type Output = V;

    /// ပေးထားသော key နှင့်သက်ဆိုင်သောတန်ဖိုးကိုရည်ညွှန်းသည်။
    ///
    /// # Panics
    ///
    /// Panics အကယ်၍ သော့သည် `BTreeMap` တွင်မရှိပါ။
    #[inline]
    fn index(&self, key: &Q) -> &V {
        self.get(key).expect("no entry found for key")
    }
}

impl<K, V> BTreeMap<K, V> {
    /// သော့ဖြင့်စီထားသည့်မြေပုံ၏နံပါတ်များကိုကြားဖြတ်တစ်ခုရရှိသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(3, "c");
    /// map.insert(2, "b");
    /// map.insert(1, "a");
    ///
    /// for (key, value) in map.iter() {
    ///     println!("{}: {}", key, value);
    /// }
    ///
    /// let (first_key, first_value) = map.iter().next().unwrap();
    /// assert_eq!((*first_key, *first_value), (1, "a"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, K, V> {
        if let Some(root) = &self.root {
            let full_range = root.reborrow().full_range();

            Iter { range: Range { inner: full_range }, length: self.length }
        } else {
            Iter { range: Range { inner: LeafRange::none() }, length: 0 }
        }
    }

    /// သော့ဖြင့်စီထားသောမြေပုံ၏နံပါတ်များကိုပြောင်း။ ပြောင်းသွားသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert("a", 1);
    /// map.insert("b", 2);
    /// map.insert("c", 3);
    ///
    /// // key ကို "a" မပါလျှင်တန်ဖိုး 10 ကိုထည့်ပါ
    /// for (key, value) in map.iter_mut() {
    ///     if key != &"a" {
    ///         *value += 10;
    ///     }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, K, V> {
        if let Some(root) = &mut self.root {
            let full_range = root.borrow_valmut().full_range();

            IterMut {
                range: RangeMut { inner: full_range, _marker: PhantomData },
                length: self.length,
            }
        } else {
            IterMut {
                range: RangeMut { inner: LeafRange::none(), _marker: PhantomData },
                length: 0,
            }
        }
    }

    /// မြေပုံ၏သော့များမှတဆင့်ကြားဖြတ်ရယူသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(2, "b");
    /// a.insert(1, "a");
    ///
    /// let keys: Vec<_> = a.keys().cloned().collect();
    /// assert_eq!(keys, [1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn keys(&self) -> Keys<'_, K, V> {
        Keys { inner: self.iter() }
    }

    /// သော့ဖြင့်နိုင်ရန်အတွက်မြေပုံ၏တန်ဖိုးများကိုကြားဖြတ်တစ်ခုရရှိသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "hello");
    /// a.insert(2, "goodbye");
    ///
    /// let values: Vec<&str> = a.values().cloned().collect();
    /// assert_eq!(values, ["hello", "goodbye"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn values(&self) -> Values<'_, K, V> {
        Values { inner: self.iter() }
    }

    /// သော့ဖြင့်နိုင်ရန်အတွက်မြေပုံ၏တန်ဖိုးများကိုပြောင်းလဲနိုင်သောကြားခံတစ်ခုကိုရရှိသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, String::from("hello"));
    /// a.insert(2, String::from("goodbye"));
    ///
    /// for value in a.values_mut() {
    ///     value.push_str("!");
    /// }
    ///
    /// let values: Vec<String> = a.values().cloned().collect();
    /// assert_eq!(values, [String::from("hello!"),
    ///                     String::from("goodbye!")]);
    /// ```
    #[stable(feature = "map_values_mut", since = "1.10.0")]
    pub fn values_mut(&mut self) -> ValuesMut<'_, K, V> {
        ValuesMut { inner: self.iter_mut() }
    }

    /// မြေပုံရှိဒြပ်စင်အရေအတွက်ကိုပြန်ပို့သည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// assert_eq!(a.len(), 0);
    /// a.insert(1, "a");
    /// assert_eq!(a.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_btree_new", issue = "71835")]
    pub const fn len(&self) -> usize {
        self.length
    }

    /// `true` သည်မြေပုံတွင်မည်သည့်ဒြပ်မျှမပါရှိပါကပြန်ပို့ပေးသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// assert!(a.is_empty());
    /// a.insert(1, "a");
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_btree_new", issue = "71835")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// root node သည် (non-allocated) root node တစ်ခုဖြစ်ပါကကျွန်ုပ်တို့၏ကိုယ်ပိုင် node ကိုခွဲဝေချထားပါ။
    /// BTreeMap တစ်ခုလုံးကိုငှားရမ်းခြင်းမှရှောင်ကြဉ်ရန်ဆက်စပ်လုပ်ဆောင်မှုတစ်ခုဖြစ်သည်။
    fn ensure_is_owned(root: &mut Option<Root<K, V>>) -> &mut Root<K, V> {
        root.get_or_insert_with(Root::new)
    }
}

#[cfg(test)]
mod tests;