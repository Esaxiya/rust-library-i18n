use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef, Root};

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// မွေးချင်းတစ် ဦး ထံမှပေါင်းခြင်းသို့မဟုတ်ခိုးခြင်းအားဖြင့်နိမ့်ကျနေသော node တစ်ခုကိုသိုလှောင်ထားသည်။
    /// အောင်မြင်လျှင်သို့သော်မိဘ node ကိုကျုံ့ခြင်း၏တန်ဖိုးဖြင့်၎င်းကျုံ့သွားသော parent node ကိုပြန်ပို့သည်။
    /// အကယ်၍ node သည်လွတ်နေသော root ဖြစ်ပါက `Err` တစ်ခုကို return ပြန်သည်။
    ///
    fn fix_node_through_parent(
        self,
    ) -> Result<Option<NodeRef<marker::Mut<'a>, K, V, marker::Internal>>, Self> {
        let len = self.len();
        if len >= MIN_LEN {
            Ok(None)
        } else {
            match self.choose_parent_kv() {
                Ok(Left(mut left_parent_kv)) => {
                    if left_parent_kv.can_merge() {
                        let parent = left_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        left_parent_kv.bulk_steal_left(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Ok(Right(mut right_parent_kv)) => {
                    if right_parent_kv.can_merge() {
                        let parent = right_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        right_parent_kv.bulk_steal_right(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Err(root) => {
                    if len > 0 {
                        Ok(None)
                    } else {
                        Err(root)
                    }
                }
            }
        }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// ဖြစ်နိုင်ခြေနိမ့်သော node တစ်ခုကိုသိုလှောင်ထားနိုင်ပြီး၎င်းသည်၎င်း၏ node node ကိုကျုံ့သွားစေလျှင်၎င်းသည်မိဘကိုပြန်လည်စုဆောင်းသည်။
    /// အကယ်၍ ၎င်းသည်သစ်ပင်ကို fix လိုက်လျှင် `true` ကိုပြန်ပို့နိုင်သည်။
    ///
    /// ဤနည်းလမ်းသည်ဘိုးဘေးများအချည်းနှီးသောဘိုးဘေးတစ်ကောင်နှင့်တွေ့ပါက ၀ င်ရောက်ခြင်းနှင့် panics အပေါ်တွင်နိမ့်ကျနေလိမ့်မည်ဟုမမျှော်လင့်ပါ။
    ///
    ///
    ///
    pub fn fix_node_and_affected_ancestors(mut self) -> bool {
        loop {
            match self.fix_node_through_parent() {
                Ok(Some(parent)) => self = parent.forget_type(),
                Ok(None) => return true,
                Err(_) => return false,
            }
        }
    }
}

impl<K, V> Root<K, V> {
    /// ထိပ်ပေါ်ရှိအချည်းနှီးသောအဆင့်များကိုဖယ်ရှားပေးသည်၊ သို့သော်သစ်ပင်တစ်ခုလုံးဗလာဖြစ်နေသည်ဆိုပါကအရွက်အလွတ်တစ်ခုထားရှိမည်
    pub fn fix_top(&mut self) {
        while self.height() > 0 && self.len() == 0 {
            self.pop_internal_level();
        }
    }

    /// သစ်ပင်၏ညာဘက်ခြမ်းရှိမပြည့်စုံသောဆုံမှတ်များကိုတက်သို့မဟုတ်သိုလှောင်သည်။
    /// အခြား node များ-root မဟုတ်သလိုညာဖက် edge မဟုတ်သော-အနည်းဆုံး MIN_LEN element များရှိရမည်။
    ///
    pub fn fix_right_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().last_kv().fix_right_border_of_right_edge();
            self.fix_top();
        }
    }

    /// `fix_right_border` ၏အချိုးကျကိုယ်ပွား။
    pub fn fix_left_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().first_kv().fix_left_border_of_left_edge();
            self.fix_top();
        }
    }

    /// သစ်ပင်၏ညာဘက်ခြမ်းရှိ underfull node များသိုလှောင်ထားပါ။
    /// အခြား node များ-အမြစ်မဟုတ်သလိုညာဘက် edge မဟုတ်သောသူများ-MIN_LEN ဒြပ်စင်များခိုးယူရန်ပြင်ဆင်ထားရမည်။
    ///
    pub fn fix_right_border_of_plentiful(&mut self) {
        let mut cur_node = self.borrow_mut();
        while let Internal(internal) = cur_node.force() {
            // လက်ျာဆုံးကလေးကမပြည့်စုံမှုရှိမရှိစစ်ဆေးပါ။
            let mut last_kv = internal.last_kv().consider_for_balancing();
            debug_assert!(last_kv.left_child_len() >= MIN_LEN * 2);
            let right_child_len = last_kv.right_child_len();
            if right_child_len < MIN_LEN {
                // ငါတို့ခိုးဖို့လိုတယ်
                last_kv.bulk_steal_left(MIN_LEN - right_child_len);
            }

            // နောက်ထပ်ဆင်းသွားပါ။
            cur_node = last_kv.into_right_child();
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    fn fix_left_border_of_left_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_left_child().first_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }

    fn fix_right_border_of_right_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_right_child().last_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// လက်ဝဲကလေးကိုသိုလှောင်ထားသည့်အတွက်လက်ျာကလေးဟုယူဆခြင်းသည်မပြည့်စုံသေးပါ၊ ၎င်းသည်ကလေးများအားမပြည့်စုံသေးဘဲပေါင်းစည်းရန်ခွင့်ပြုသည့်အပိုဒြပ်စင်တစ်ခုဖြစ်သည်။
    ///
    /// လက်ဝဲကလေးပြန်သွားသည်
    ///
    fn fix_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let left_len = internal_kv.left_child_len();
        debug_assert!(internal_kv.right_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` ပေါင်းစည်းလာမယ့်အဆင့်တွင်ဖြစ်ပျက်လျှင် readjust ရှောင်ရှားရန်။
            let count = (MIN_LEN + 1).saturating_sub(left_len);
            if count > 0 {
                internal_kv.bulk_steal_right(count);
            }
            internal_kv.into_left_child()
        }
    }

    /// လက်ဝဲကလေးကိုမခန့်မှန်းနိုင်ခြင်းကမှန်ကန်သောကလေးကိုသိုလှောင်ထားသည်။ မပြည့်စုံသေးပါက ၄ င်း၏ကလေးများကိုအပြန်အလှန်ပေါင်းစည်းရန်ခွင့်ပြုသည်။
    ///
    /// လက်ျာကလေးတက်အဆုံးသတ်နေရာတိုင်းမှာပြန်သွားသည်။
    ///
    fn fix_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let right_len = internal_kv.right_child_len();
        debug_assert!(internal_kv.left_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` ပေါင်းစည်းလာမယ့်အဆင့်တွင်ဖြစ်ပျက်လျှင် readjust ရှောင်ရှားရန်။
            let count = (MIN_LEN + 1).saturating_sub(right_len);
            if count > 0 {
                internal_kv.bulk_steal_left(count);
            }
            internal_kv.into_right_child()
        }
    }
}