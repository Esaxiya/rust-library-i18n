use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// ဖြစ်ရပ်များကိုစောင့်ကြည့်သော crash test dummy ဖြစ်ရပ်များအတွက်အသေးစိတ်ပုံစံ။
/// အချို့သောဖြစ်ရပ်များကိုတစ်ချိန်ချိန်တွင် panic ကိုပြုပြင်နိုင်သည်။
/// ဖြစ်ရပ်များမှာ `clone`, `drop` သို့မဟုတ်အမည်မသိ `query` ဖြစ်သည်။
///
/// Crash test Dummy တွေကို ID ကသတ်မှတ်ပြီးအမိန့်ပေးတယ်၊ ဒါကြောင့်သူတို့ကို BTreeMap ထဲမှာသော့အဖြစ်အသုံးပြုနိုင်တယ်။
/// ရည်ရွယ်ချက်ရှိရှိအသုံးပြုထားသောအကောင်အထည်ဖော်မှုသည် `Debug` trait မှလွဲ၍ crate တွင်သတ်မှတ်ထားသောမည်သည့်အရာပေါ်တွင်မမှီခိုပါ။
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// crash test dummy ဒီဇိုင်းကိုဖန်တီးသည်။`id` သည်သာဓကနှင့်အစီအစဉ်တူညီမှုကိုဆုံးဖြတ်သည်။
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// crash test dummy တစ်ခုကိုဥပမာတစ်ခုပြုလုပ်ပြီးမည်သည့်အဖြစ်အပျက်များကြုံတွေ့ရသည်နှင့် panics ကိုမှတ်တမ်းတင်နိုင်သည်။
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// အဆိုပါ Dummy ၏သာဓကပုံတူမျိုးပွားခဲ့ကြသည်ဘယ်နှစ်ယောက်ပြန်သွားသည်။
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// အဆိုပါ Dummy ၏သာဓကကျဆင်းသွားဘယ်လောက်အကြိမ်ပြန်သွားသည်။
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// သူတို့ရဲ့ `query` အင်္ဂါကိုအတုအယောင်ဖြစ်ရပ်များအကြိမ်ပေါင်းမည်မျှကျူးလွန်ခဲ့သည်ပြန်သည်။
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// အမည်မသိစုံစမ်းမှုအချို့၊ ရလဒ်၏ပြီးသားဖြစ်သည်။
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}