use core::intrinsics;
use core::mem;
use core::ptr;

/// ၎င်းသည်သက်ဆိုင်ရာ function ကိုခေါ်ဆိုခြင်းဖြင့် `v` ၏ထူးခြားသောရည်ညွှန်းချက်နောက်ကွယ်ရှိတန်ဖိုးကိုအစားထိုးသည်။
///
///
/// အကယ်၍ panic သည် `change` ပိတ်ချိန်တွင်ဖြစ်ပေါ်ပါကလုပ်ငန်းစဉ်တစ်ခုလုံးကိုဖျက်သိမ်းလိမ့်မည်။
#[allow(dead_code)] // ပုံဥပမာအဖြစ် ထား၍ future အသုံးပြုရန်
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// ၎င်းသည် `v` ၏ထူးခြားသောရည်ညွှန်းမှုနောက်ကွယ်ရှိတန်ဖိုးကိုသက်ဆိုင်ရာ function ကိုခေါ်ဆိုခြင်းဖြင့်အစားထိုးပြီးလမ်းတစ်လျှောက်ရရှိသောရလဒ်ကိုပြန်လည်ပေးသည်။
///
///
/// အကယ်၍ panic သည် `change` ပိတ်ချိန်တွင်ဖြစ်ပေါ်ပါကလုပ်ငန်းစဉ်တစ်ခုလုံးကိုဖျက်သိမ်းလိမ့်မည်။
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}