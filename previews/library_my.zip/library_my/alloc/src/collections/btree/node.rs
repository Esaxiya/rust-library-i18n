// ဤသည်စံပြအောက်ပါအကောင်အထည်ဖော်မှုတစ်ခုကြိုးပမ်းမှုဖြစ်ပါတယ်
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Rust တွင်အမှန်တကယ်မှီခိုသောအမျိုးအစားများနှင့် polymorphic recursion မရှိသောကြောင့်ကျွန်ုပ်တို့သည်လုံခြုံမှုမရှိခြင်းများစွာကိုပြုလုပ်သည်။
//

// ဤ module ၏အဓိကရည်မှန်းချက်မှာသစ်ပင်ကိုယေဘုယျ (ထူးဆန်းစွာပုံဖော်ထားသည့်) ကွန်တိန်နာအဖြစ်ဆက်ဆံခြင်းနှင့် B-Tree လျော့ပါးသွားမည်ဖြစ်ခြင်းအများစုနှင့်ဆက်ဆံခြင်းကိုရှောင်ရှားခြင်းဖြင့်ရှုပ်ထွေးမှုကိုရှောင်ရှားရန်ဖြစ်သည်။
//
// ထို့ကြောင့်ဤ module သည် entries မ်ားကိုအမျိုးအစားခွဲခြင်း၊ မည်သည့် node များသည် underfull ဖြစ်စေ၊ underfull ၏ဆိုလိုရင်းကိုပင်ဂရုမစိုက်ပါ။သို့သျောလညျးကြှနျုပျတို့အနည်းငယ်လျော့ပါးသွားမည်ဖြစ်သလိုမှီခိုကြဘူး:
//
// - သစ်ပင်များတွင်ယူနီဖောင်း depth/height ရှိရမည်။ဆိုလိုသည်မှာပေးထားသော node တစ်ခုမှသစ်ရွက်သို့သွားသောလမ်းကြောင်းတိုင်းသည်တူညီသောအရှည်ရှိသည်ဟုဆိုလိုသည်။
// - `n` အရှည်ရှိ node တစ်ခုတွင် `n` သော့၊ `n` တန်ဖိုးများနှင့် `n + 1` အနားများရှိသည်။
//   ၎င်းတွင် node အချည်းနှီးပင်လျှင်အနည်းဆုံး edge တစ်ခုရှိသည်ဟုဆိုလိုသည်။
//   leaf node အတွက် "having an edge" သည် node အတွင်းရှိအနေအထားကိုသာခွဲခြားသတ်မှတ်နိုင်သည်။
// အတွင်းပိုင်း node တစ်ခုတွင် edge သည်အနေအထားကိုသတ်မှတ်ပြီးကလေး node တစ်ခုသို့ညွှန်ပြသည်။
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// အရွက် node များနှင့်အတွင်းပိုင်း node များ၏ကိုယ်စားပြုမှု၏တစ်စိတ်တစ်ပိုင်းကိုယ်စားပြုမှု။
struct LeafNode<K, V> {
    /// ကျနော်တို့ `K` နှင့် `V` အတွက် covariant ဖြစ်ချင်တယ်။
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// parent node ၏ `edges` array ထဲသို့ဤ node ၏အညွှန်းကိန်း။
    /// `*node.parent.edges[node.parent_idx]` `node` ကဲ့သို့တူညီသောအရာဖြစ်သင့်သည်
    /// ဤသည်မှာ `parent` သည် null မဟုတ်သောအခါတွင်စတင်လုပ်ဆောင်ရန်အာမခံထားသည်။
    parent_idx: MaybeUninit<u16>,

    /// ဒီ node သိုလှောင်သောသော့နှင့်တန်ဖိုးအရေအတွက်။
    len: u16,

    /// အဆိုပါ node ကို၏အမှန်တကယ်ဒေတာသိုလှောင်အဆိုပါ Array ကို။
    /// တစ်ခုချင်းစီကိုခင်းကျင်းခြင်း၏ပထမ ဦး ဆုံး `len` ဒြပ်စင်သာအစပျိုးခြင်းနှင့်တရားဝင်ဖြစ်ကြသည်။
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// အသစ်တစ်ခုကို-`LeafNode` Initializes ။
    unsafe fn init(this: *mut Self) {
        // အထွေထွေမူဝါဒအနေဖြင့်ကျွန်ုပ်တို့သည် Valgrind တွင်ခြေရာခံလျှင်ပိုမိုမြန်ဆန်ပြီးပိုမိုလွယ်ကူသင့်သည်။
        //
        unsafe {
            // parent_idx, keys နှင့် vals အားလုံးသည် MaybeUninit ဖြစ်သည်
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// အသစ်တစ်ခုကို boxed `LeafNode` ဖန်တီးသည်။
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// ပြည်တွင်းရေး node များ၏နောက်ခံကိုယ်စားပြုမှု။`LeafNode`s ကဲ့သို့ 'uninitialized သော့နှင့်တန်ဖိုးများကျဆင်းခြင်းကိုကာကွယ်ရန် BoxedNode ၏နောက်ကွယ်တွင်ဝှက်ထားသင့်သည်။
/// `InternalNode` တစ်ခုသို့ညွှန်ပြသူမည်သည့်ညွှန်ကိန်းကိုညွှန်ပြနေသည်ကိုပင်စစ်ဆေးရန်မလိုဘဲယေဘူယျအားဖြင့်အရွက်များနှင့်အတွင်းပိုင်းဆုံမှတ်များကိုလုပ်ဆောင်ရန်ခွင့်ပြုသည့် node ၏နောက်ခံ `LeafNode` အပိုင်းကိုညွှန်ပြရန်တိုက်ရိုက်ချနိုင်သည်။
///
/// ဤပိုင်ဆိုင်မှုကို `repr(C)` အသုံးပြုခြင်းဖြင့်အသုံးပြုနိုင်သည်။
///
#[repr(C)]
// gdb_providers.py စရိုက်အတွက်ဤအမျိုးအစားအမည်ကိုအသုံးပြုသည်။
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// ဒီ node ကို၏သားသမီးများမှထောက်ပြ။
    /// `len + 1` သစ်ပင်များကိုချေးယူထားသောအမျိုးအစား `Dying` မှတဆင့်ထိန်းသိမ်းထားစဉ်၊ ထိုအရာများမှအစပြုပြီးတရားဝင်သည်ဟုမှတ်ယူကြသည်။
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// အသစ်တစ်ခုကို boxed `InternalNode` ဖန်တီးသည်။
    ///
    /// # Safety
    /// အတွင်းပိုင်း node များတစ်ခုလျော့ပါးသွားမည်ဖြစ်သလိုသူတို့အနည်းဆုံးအစပြုနှင့်တရားဝင် edge ရှိသည်။
    /// ဤလုပ်ဆောင်မှုသည်ထိုကဲ့သို့သော edge ကိုမတပ်ဆင်ပါ။
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // ဒေတာများကို အစပြု၍ သာလိုအပ်သည်။အစွန်း MaybeUninit ဖြစ်ကြသည်။
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// node တစ်ခုသို့စီမံခန့်ခွဲသော non-null pointer ။၎င်းသည် `LeafNode<K, V>` မှပိုင်ဆိုင်သော pointer တစ်ခုသို့မဟုတ် `InternalNode<K, V>` သို့ပိုင်ဆိုင်သော pointer တစ်ခုဖြစ်သည်။
///
/// သို့သော် `BoxedNode` တွင်မည်သည့် node အမျိုးအစားများတွင်အမှန်တကယ်ပါ ၀ င်သည်နှင့်ပတ်သက်သောအချက်အလက်မရှိပါ၊ တစ်စိတ်တစ်ပိုင်းအားဖြင့်ဤအချက်အလက်များမရှိခြင်းကြောင့်သီးခြားအမျိုးအစားမဟုတ်သောကြောင့်ပျက်စီးခြင်းမရှိပါ။
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// ပိုင်သစ်ပင်တစ်ပင်၏ရင်းမြစ် node ။
///
/// သတိပြုရန်မှာ၎င်းတွင်အဖျက်စွမ်းအားမရှိသောကြောင့်ကိုယ်တိုင်သန့်ရှင်းရေးလုပ်ရန်လိုအပ်သည်။
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// အစပိုင်း၌အချည်းနှီးဖြစ်သော၎င်း၏ကိုယ်ပိုင်အမြစ် node ကိုအတူပိုင်ဆိုင်သစ်ပင်အသစ်တစ်ခုကိုပြန်ပို့သည်။
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` သုညမဖြစ်ရ။
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// အပြန်အလှန်ဆက်စပ်ပိုင်အမြစ် node ကိုချေး။
    /// `reborrow_mut` နှင့်မတူဘဲ၎င်းသည်လုံခြုံသည်။ အမြစ်ကိုဖျက်ဆီးရန် return value ကိုအသုံးမပြုနိုင်သောကြောင့်၊ သစ်ပင်နှင့် ပတ်သက်၍ အခြားရည်ညွှန်းချက်များလည်းမရှိနိုင်ပါ။
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ပိုင်ဆိုင်မှုအရင်းအမြစ် node ကိုအနည်းငယ်အပြန်အလှန်ချေးယူသည်။
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// နောက်ကြောင်းပြန်လှည့ ်၍ အကူးအပြောင်းကိုခွင့်ပြုပြီးအဖျက်အဖျက်နည်းစနစ်များနှင့်အခြားအရာများကိုပေးထားသည်။
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// z0edge0Z တစ်ခုတည်းနှင့်အတူ node အသစ်တစ်ခုကိုအရင် root node ကိုညွှန်ပြပြီး၎င်း node အသစ်ကို root node ကိုလုပ်ပြီးပြန်ပို့ပါ။
    /// ၎င်းသည်အမြင့်ကို 1 တိုးစေပြီး `pop_internal_level` ၏ဆန့်ကျင်ဘက်ဖြစ်သည်။
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, မှန်ကန်တဲ့အရာကအခုကျွန်တော်တို့အတွင်းပိုင်းဖြစ်နေပြီဆိုတာကိုမေ့သွားတယ်။
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// အတွင်းပိုင်း root node ကို ၄ င်း၏ပထမဆုံးကလေးအား root node အသစ်အဖြစ်အသုံးပြုသည်။
    /// ၎င်းသည် root node တွင်ကလေးတစ် ဦး တည်းသာရှိသောအခါခေါ်ရန်ရည်ရွယ်ထားသောကြောင့်သော့များ၊ တန်ဖိုးများနှင့်အခြားကလေးများအတွက်မည်သည့်သန့်ရှင်းမှုမျှမပြုလုပ်ပါ။
    ///
    /// ၎င်းသည်အမြင့်ကို 1 ဖြင့်လျှော့ချပြီး `push_internal_level` ၏ဆန့်ကျင်ဘက်ဖြစ်သည်။
    ///
    /// `Root` အရာဝတ္ထုကိုသီးသန့်ရယူရန်လိုအပ်သော်လည်း root node ကိုမလိုအပ်ပါ။
    /// ၎င်းသည် root node ကိုအခြား handles များနှင့်ကိုးကားချက်များကိုပျက်ပြယ်စေလိမ့်မည်မဟုတ်ပါ။
    ///
    /// အတွင်းပိုင်းအဆင့်မရှိလျှင်ဆိုလိုသည်မှာ root node သည်သစ်ရွက်တစ်ခုဖြစ်သည်ဆိုလျှင် Panics ။
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // လုံခြုံမှု-ကျွန်တော်တို့ဟာအတွင်းပိုင်းဖြစ်တယ်လို့ပြောခဲ့တယ်။
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // လုံခြုံမှု-ကျွန်ုပ်တို့သည် `self` ကိုသီးသန့်ငှားရမ်းခဲ့ပြီးယင်း၏ချေးငွေအမျိုးအစားမှာသီးသန့်ဖြစ်သည်။
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // လုံခြုံမှု-ပထမဆုံး edge သည်အမြဲတမ်းနဂိုမူလဖြစ်သည်။
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` သည် `K` နှင့် `V` တို့တွင်အမြဲတမ်း covariant ဖြစ်သည်၊ `BorrowType` `Mut` ဖြစ်သော်လည်း
// ၎င်းသည်နည်းပညာပိုင်းအရမှားယွင်းနေသည်၊ သို့သော် X0 `K` နှင့် `V` တို့အပေါ်ယေဘူယျအားဖြင့်သာဆက်လက်တည်ရှိနေသောကြောင့် `NodeRef` ကိုအသုံးပြုခြင်းကြောင့်လုံခြုံစိတ်ချမှုမရှိပါ။
//
// သို့သော်အများပြည်သူအမျိုးအစား `NodeRef` ကိုထုပ်သည့်အခါတိုင်း၎င်းတွင်မှန်ကန်သောကှဲလှဲရှိသည်ကိုသေချာပါစေ။
//
/// node တစ်ခုသို့ရည်ညွှန်းခြင်း။
///
/// ဒီအမျိုးအစားမှာဘယ်လိုအလုပ်လုပ်တယ်ဆိုတာကိုထိန်းချုပ်တဲ့ parameters များစွာရှိပါတယ်။
/// - `BorrowType`: ငွေချေးခြင်းနှင့်တစ်သက်တာသယ်ဆောင်ရသောအတုအမျိုးအစားတစ်မျိုး။
///    - ၎င်းသည် `Immut<'a>` ဖြစ်သည့်အခါ `NodeRef` သည် `&'a Node` ကဲ့သို့အကြမ်းအားဖြင့်ပြုမူသည်။
///    - ၎င်းသည် `ValMut<'a>` ဖြစ်သည့်အခါ `NodeRef` သည်သော့နှင့်သစ်ပင်တည်ဆောက်ပုံနှင့် ပတ်သက်၍ အကြမ်းအားဖြင့် `&'a Node` ကဲ့သို့ပြုမူသည်သာမကသစ်ပင်တစ်လျှောက်ရှိတန်ဖိုးများကိုပြောင်းလဲနိုင်သောကိုးကားချက်များကိုအတူတကွတည်ရှိရန်ခွင့်ပြုသည်။
///    - ဤအရာသည် `Mut<'a>` ဖြစ်သည့်အခါ `NodeRef` သည်အကြမ်းအားဖြင့် `&'a mut Node` ကဲ့သို့ပြုမူသည်။ ထည့်သွင်းခြင်းနည်းလမ်းများသည် mutable pointer ကိုတန်ဖိုးတစ်ခုနှင့်အတူတွဲဖက်အသုံးပြုခွင့်ပေးသည်။
///    - ၎င်းသည် `Owned` ဖြစ်သည့်အခါ `NodeRef` သည်အကြမ်းအားဖြင့် `Box<Node>` ကဲ့သို့ပြုမူသည်၊ သို့သော်ဖျက်ဆီးသူမပါ ရှိ၍ ကိုယ်တိုင်သန့်ရှင်းရမည်။
///    - ၎င်းသည် `Dying` ဖြစ်သည့်အခါ `NodeRef` သည် `Box<Node>` ကဲ့သို့အကြမ်းဖျင်းပြုမူသော်လည်းသစ်ပင်ကိုနည်းနည်းချင်းဖျက်ဆီးရန်နည်းလမ်းများရှိသည်။ ပုံမှန်နည်းလမ်းများသည်မခေါ်ရန်အန္တရာယ်မကင်းဟုမှတ်သားထားခြင်းမရှိသော်လည်း UB ကိုမှားယွင်းစွာခေါ်ဆိုနိုင်သည်။
///
///   မည်သည့် `NodeRef` ကမဆိုသစ်ပင်မှတဆင့်သွားလာရန်ခွင့်ပြုထားသောကြောင့် `BorrowType` သည်သစ်ပင်တစ်ခုလုံးနှင့်သက်ဆိုင်သည်။
/// - `K` နှင့် `V`: ဤအချက်များသည် node များ၌သိမ်းဆည်းထားသောသော့များနှင့်တန်ဖိုးများဖြစ်သည်။
/// - `Type`: ၎င်းသည် `Leaf`, `Internal` သို့မဟုတ် `LeafOrInternal` ဖြစ်နိုင်သည်။
/// ၎င်းသည် `Leaf` ဖြစ်သည့်အခါ `NodeRef` သည်သစ်သား node ကိုညွှန်ပြသည်၊ ၎င်းသည် `Internal` ဖြစ်သည့်အခါ `NodeRef` သည်အတွင်းပိုင်း node ကိုညွှန်ပြသည်။ ၎င်းသည် `LeafOrInternal` ဖြစ်သည့်အခါ `NodeRef` သည်မည်သည့် node အမျိုးအစားကိုမဆိုညွှန်ပြနိုင်သည်။
///   `Type` `NodeRef` အပြင်ဘက်တွင်အသုံးပြုသောအခါ `NodeType` အမည်ရှိသည်။
///
/// တည်ငြိမ်သောလုံခြုံမှုကိုအသုံးချရန် `BorrowType` နှင့် `NodeType` နှစ်ခုလုံးသည်ကျွန်ုပ်တို့မည်သည့်နည်းလမ်းကိုအသုံးပြုသည်ကိုကန့်သတ်ထားသည်။ထိုကဲ့သို့သောကန့်သတ်ချက်များကိုကျွန်ုပ်တို့အသုံးပြုနိုင်သည့်နည်းလမ်းတွင်ကန့်သတ်ချက်များရှိသည်။
/// - တစ်ခုချင်းစီကိုအမျိုးအစား parameter သည်အဘို့, သာယေဘုယျအားဖြင့်သို့မဟုတ်တစ် ဦး အထူးသဖြင့်အမျိုးအစားတစ်ခုနည်းလမ်းကိုသာသတ်မှတ်နိုင်ပါတယ်။
/// ဥပမာအားဖြင့်၊ ကျွန်ုပ်တို့သည် X0 `into_kv` ကဲ့သို့သောနည်းလမ်းတစ်ခုကိုယေဘူယျအားဖြင့် `BorrowType` အားလုံးအတွက်သို့မဟုတ်တစ်သက်တာသယ်ဆောင်သောအမျိုးအစားအားလုံးအတွက်မသတ်မှတ်နိုင်ပါ၊ အဘယ်ကြောင့်ဆိုသော်ကျွန်ုပ်တို့သည် `&'a` ကိုးကားချက်များကိုပြန်ပို့လိုသောကြောင့်ဖြစ်သည်။
///   ထို့ကြောင့်ကျွန်ုပ်တို့သည်၎င်းကိုအနည်းဆုံးအစွမ်းထက်ဆုံးအမျိုးအစား `Immut<'a>` အတွက်သာသတ်မှတ်သည်။
/// - `Mut<'a>` မှ `Immut<'a>` သို့အတင်းအကျပ်အတင်းအကျပ်စေခိုင်းမှုကိုကျွန်ုပ်တို့မလုပ်နိုင်ပါ။
///   ထို့ကြောင့်ကျွန်ုပ်တို့သည် `into_kv` ကဲ့သို့သောနည်းလမ်းတစ်ခုကိုရောက်ရှိရန်ပိုမိုအားကောင်းသော `NodeRef` ပေါ်တွင် `reborrow` ကိုအတိအလင်းခေါ်ဆိုရသည်။
///
/// ရည်ညွှန်းချက်အချို့ကိုပြန်ပေးသည့် `NodeRef` ရှိနည်းလမ်းအားလုံးသည်-
/// - `self` တန်ဖိုးကိုယူပြီး `BorrowType` သယ်ဆောင်သည့်သက်တမ်းကိုပြန်ပို့ပါ။
///   တခါတရံတွင်ဤနည်းလမ်းကိုအသုံးပြုရန်ကျွန်ုပ်တို့သည် `reborrow_mut` ကိုခေါ်ရန်လိုအပ်သည်။
/// - `self` ကိုရည်ညွှန်း။ ယူပါ၊ (implicitly) သည်ထိုရည်ညွှန်းချက်သက်တမ်းကို `BorrowType` သယ်ဆောင်သည့်သက်တမ်းအစားပြန်ပို့ပါ။
/// ဤနည်းအားဖြင့်ငွေချေးယူသူက `NodeRef` သည်ပြန်လာသောရည်ညွှန်းကိုသုံးနေသမျှကာလပတ်လုံးချေးယူထားနိုင်သည်ဟုအာမခံသည်။
///   ထည့်သွင်းမှုအတွက်ပံ့ပိုးသောနည်းလမ်းများသည်ဤနည်းဥပဒေကို bend pointer တစ်ခုသို့မဟုတ်သက်တမ်းတစ်စုံတစ်ရာမရှိဘဲပြန်ပို့ခြင်းဖြင့်ပြုလုပ်နိုင်သည်။
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// node နှင့်အရွက်များ၏အဆင့်ခွဲခြားထားသည့်အဆင့်များ၊ `Type` မှလုံးဝမဖော်ပြနိုင်သော node တစ်ခု၏အဆက်မပြတ်နှင့် node ကိုယ်နှိုက်သိုလှောင်ထားခြင်းမရှိပါ။
    /// root node ၏အမြင့်ကိုသာသိုလှောင်ရန်လိုအပ်ပြီး၎င်းမှအခြား node အမြင့်များကိုသာရယူရန်လိုအပ်သည်။
    /// `Type` `Leaf` ဖြစ်ပါကသုညဖြစ်ရမည်။ `Type` `Internal` ဖြစ်ပါကသုညမဟုတ်ရပါ။
    ///
    ///
    height: usize,
    /// အရွက်သို့မဟုတ်အတွင်းပိုင်း node ကိုရန်ညွှန်ပြ။
    /// `InternalNode` ၏အဓိပ္ပာယ်သည်၎င်းသည်မည်သည့်နည်းနှင့်မဆိုမှန်ကန်ကြောင်းသေချာစေသည်။
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// `NodeRef::parent` အဖြစ်ထုပ်ပိုးထားသော node တစ်ခုရည်ညွှန်းချက်ကိုဖြုတ်ပါ။
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// အတွင်းပိုင်း node တစ်ခု၏ဒေတာကိုဖော်ထုတ်သည်။
    ///
    /// ဤဆုံမှတ်နှင့်အခြားရည်ညွှန်းချက်များကိုမမှန်ကန်စေရန်ရှောင်ရှားသော ptr တစ်ခုကိုပြန်သွားသည်။
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // လုံခြုံမှု-static node အမျိုးအစားသည် `Internal` ဖြစ်သည်။
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// အတွင်းပိုင်း node တစ်ခု၏ဒေတာကိုသီးသန့်ရယူသုံးစွဲသည်။
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// node ရဲ့အရှည်ကိုရှာတယ်။၎င်းသည်သော့သို့မဟုတ်တန်ဖိုးများအရေအတွက်ဖြစ်သည်။
    /// အနား၏အရေအတွက်သည် `len() + 1` ဖြစ်သည်။
    /// သတိပြုရန်မှာ၊ လုံခြုံမှုရှိသော်လည်း၊ ဤလုပ်ဆောင်မှုသည်မလုံခြုံသောကုဒ်နံပါတ်ဖန်တီးထားသော mutable ကိုးကားချက်များကိုဘေးထွက်ဆိုးကျိုးသက်ရောက်စေနိုင်သည်။
    ///
    pub fn len(&self) -> usize {
        // အရေးကြီးသည်မှာကျွန်ုပ်တို့သည် `len` field ကိုသာဤတွင်ရရှိသည်။
        // အကယ်၍ BorrowType သည် marker::ValMut ဖြစ်ပါကကျွန်ုပ်တို့မှမမှားသင့်သောတန်ဖိုးများနှင့်ထူးခြားသောပြောင်းလဲနိုင်သောရည်ညွှန်းချက်များရှိနိုင်သည်။
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// node နှင့်အရွက်များကွဲကွာနေသော level မ်ားကို return လုပ်သည်။
    /// သုညသုညဆိုသည်မှာ node သည်အရွက်တစ်ခုဖြစ်သည်။
    /// အပေါ်ဘက်ရှိအမြစ်များနှင့်သစ်ပင်များကိုသင်မြင်ယောင်ကြည့်ပါကနံပါတ်သည်မည်သည့်အမြင့်တွင် node ပေါ်လာမည်ကိုဖော်ပြသည်။
    /// သစ်ပင်များကိုသစ်ရွက်များပေါ်တွင်သင်မြင်ယောင်ကြည့်ပါကနံပါတ်သည် node အထက်တွင်မည်မျှမြင့်တက်သည်ကိုဖော်ပြထားသည်။
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// တူညီသော node တစ်ခုသို့မပြောင်းလဲနိုင်သောအရာတစ်ခုကိုယာယီယူထားသည်။
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// မည်သည့်အရွက်သို့မဟုတ်အတွင်းပိုင်း node ကိုမဆိုအရွက်ဖြင့်ဖော်ထုတ်သည်။
    ///
    /// ဤဆုံမှတ်နှင့်အခြားရည်ညွှန်းချက်များကိုမမှန်ကန်စေရန်ရှောင်ရှားသော ptr တစ်ခုကိုပြန်သွားသည်။
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // node သည်အနည်းဆုံး LeafNode အပိုင်းအတွက်တရားဝင်ဖြစ်ရမည်။
        // ၎င်းသည် NodeRef အမျိုးအစားတွင်ရည်ညွှန်းခြင်းမဟုတ်ပါ၊ အဘယ်ကြောင့်ဆိုသော်၎င်းသည်ထူးခြားမှုရှိ၊ မရှိခွဲဝေမှုဖြစ်သင့်သည်ကိုကျွန်ုပ်တို့မသိပါ။
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// လက်ရှိ node ၏မိဘကိုရှာသည်။
    /// အကယ်၍ လက်ရှိ node တွင်မိဘရှိပါက `Ok(handle)` သို့ပြန်သွားသည်။ `handle` သည်လက်ရှိ node ကိုညွှန်ပြသောမိဘ၏ edge ကိုညွှန်ပြသည်။
    ///
    /// လက်ရှိ node တွင်မူလမရှိသော `NodeRef` ကိုပြန်ပေးလျှင် `Err(self)` ကိုပြန်ပို့ပေးသည်။
    ///
    /// method name သည်သင့်အား top node နှင့်အတူသစ်ပင်များကိုပုံဖော်သည်။
    ///
    /// `edge.descend().ascend().unwrap()` နှင့် `node.ascend().unwrap().descend()` နှစ်ခုစလုံး, အောင်မြင်မှုအပျေါမှာဘာမျှမလုပ်သင့်ပါတယ်။
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // node များသို့ point point များသုံးရန်လိုသည်။ အဘယ်ကြောင့်ဆိုသော် BorrowType သည် marker::ValMut ဖြစ်ပါကကျွန်ုပ်တို့သည်မှားယွင်းမှုမပြုသင့်သောတန်ဖိုးများအတွက်ထူးခြားသောပြောင်းလဲနိုင်သောရည်ညွှန်းချက်များရှိနိုင်သည်။
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// `self` ဟာမသန့်ရှင်းဘူးဆိုတာသတိပြုပါ။
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// `self` ဟာမသန့်ရှင်းဘူးဆိုတာသတိပြုပါ။
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// မပြောင်းလဲနိုင်သောအပင်တစ်ပင်ရှိမည်သည့်အရွက်သို့မဟုတ်မည်သည့်အတွင်းပိုင်း node မဆိုအရွက်ကိုဖော်ထုတ်သည်။
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // လုံခြုံမှု-`Immut` ဟုချေးထားသောဤသစ်ပင်သို့ပြောင်းလဲနိုင်သောညွှန်းဆိုချက်များမရှိပါ။
        unsafe { &*ptr }
    }

    /// node ထဲတွင်သိမ်းထားသောသော့များထဲမှမြင်ကွင်းကိုငှားသည်။
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// `ascend` နှင့်ဆင်တူသည် node တစ်ခု၏ parent node ကိုရည်ညွှန်းသည်။ သို့သော်လက်ရှိ node ကိုလုပ်ငန်းစဉ်အတွင်းဖျက်သိမ်းသည်။
    /// ၎င်းကိုလုံခြုံမှုမရှိသောကြောင့်လက်ရှိ node ကိုဖယ်ရှားပြီးသော်လည်းလက်လှမ်းမီနိုင်ဆဲဖြစ်သည်။
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// ဤ node သည် `Leaf` ဖြစ်သည်ဟူသောအချက်အလက်များအားလုံခြုံမှုကင်းမဲ့စွာအား compiler သို့အခိုင်အမာပြောဆိုသည်။
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ဤ node သည် `Internal` ဖြစ်သည်ဟူသောအချက်အလက်များအားလုံခြုံမှုမရှိသောအချက်အလက်များကို compiler ကို compiler ကပြောပြသည်။
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// တူညီသော node တစ်ခုသို့အခြားပြောင်းလဲနိုင်သောရည်ညွှန်းကိုယာယီထုတ်ယူသည်။သတိပြုပါ၊ ဤနည်းလမ်းသည်အလွန်အန္တရာယ်ရှိသောကြောင့်ချက်ချင်းပင်အန္တရာယ်ရှိပုံမပေါ်သောကြောင့်၊
    ///
    /// mutable pointers သည်သစ်ပင်ပတ်ပတ်လည်တွင်မည်သည့်နေရာ၌မဆိုလှည့်လည်သွားနိုင်သောကြောင့်၊ ပြန်လာသော pointer သည်မူလ pointer ကို dangling, bounds, stacked loan rules များအောက်တွင် invalid လုပ်ရန်အလွယ်တကူအသုံးပြုနိုင်သည်။
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) ထပ်မံထည့်သွင်းရန် `NodeRef` သို့ထပ်မံထည့်သွင်းရန်စဉ်းစားပါ၊
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// မည်သည့်အရွက်သို့မဟုတ်အတွင်းပိုင်း node မဆို၏အရွက်အပိုင်းကိုအထူးသီးသန့်ရယူနိုင်သည်။
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // လုံခြုံမှု-ကျွန်ုပ်တို့ node တစ်ခုလုံးကိုသီးသန့် ၀ င်ရောက်ခွင့်ရှိသည်။
        unsafe { &mut *ptr }
    }

    /// မည်သည့်အရွက်သို့မဟုတ်အတွင်းပိုင်း node မဆို၏အရွက်အပိုင်းကိုအထူးသီးသန့်ရရှိနိုင်သည်။
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // လုံခြုံမှု-ကျွန်ုပ်တို့ node တစ်ခုလုံးကိုသီးသန့် ၀ င်ရောက်ခွင့်ရှိသည်။
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// သော့ခတ်သိမ်းဆည်းခြင်းofရိယာ၏ဒြပ်စင်တစ်ခုသို့သီးသန့် ၀ င်ရောက်ခွင့်ပြုသည်။
    ///
    /// # Safety
    /// `index` 0. .CAPACITY ၏ဘောငျ၌တည်ရှိ၏
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // လုံခြုံမှု-ခေါ်ဆိုသူသည်မိမိကိုယ်မိမိနောက်ထပ်နည်းလမ်းများကိုခေါ်ဆိုနိုင်မည်မဟုတ်ပါ
        // ကျနော်တို့ချေး၏တစ်သက်တာများအတွက်ထူးခြားသော access ရှိသည်အဖြစ်သော့ချက်အချပ်ရည်ညွှန်းကျဆင်းသွားသည်အထိ။
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// node ၏တန်ဖိုးသိုလှောင်ရာနေရာ၏ Element တစ်ခုသို့မဟုတ်အချပ်ကိုသီးသန့်ရယူရန်ငှားသည်။
    ///
    /// # Safety
    /// `index` 0. .CAPACITY ၏ဘောငျ၌တည်ရှိ၏
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // လုံခြုံမှု-ခေါ်ဆိုသူသည်မိမိကိုယ်မိမိနောက်ထပ်နည်းလမ်းများကိုခေါ်ဆိုနိုင်မည်မဟုတ်ပါ
        // ကျနော်တို့ကချေး၏တစ်သက်တာများအတွက်ထူးခြားသော access ကိုရှိသည်အဖြစ်တန်ဖိုးအချပ်ရည်ညွှန်းကျဆင်းသွားသည်အထိ။
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// edge ပါဝင်သည့်အရာများအတွက် node ၏သိုလှောင်မှုနယ်မြေ၏ဒြပ်စင်တစ်ခုသို့မဟုတ်အချပ်တစ်ခုသို့သီးသန့် ၀ င်ရောက်ခွင့်ပြုသည်။
    ///
    /// # Safety
    /// `index` 0. .CAPACITY + 1 ၏ဘောငျ၌တည်ရှိ၏
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // လုံခြုံမှု-ခေါ်ဆိုသူသည်မိမိကိုယ်မိမိနောက်ထပ်နည်းလမ်းများကိုခေါ်ဆိုနိုင်မည်မဟုတ်ပါ
        // ကျနော်တို့ချေး၏တစ်သက်တာများအတွက်ထူးခြားသော access ကိုရှိသည်အဖြစ် edge အချပ်ရည်ညွှန်းကျဆင်းသွားသည်အထိ။
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - အဆိုပါ node ကို `idx` ထက်ပိုသောအစပျိုး element တွေရှိပါတယ်။
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // အခြားစိတ်ဝင်စားသောထူးခြားသောအကိုးအကားများနှင့်စကားပြောခြင်းကိုရှောင်ကြဉ်ရန်၊ ကျွန်ုပ်တို့စိတ်ဝင်စားသောဒြပ်စင်တစ်ခုကိုသာရည်ညွှန်းဖန်တီးသည်၊ အထူးသဖြင့်အစောပိုင်းကြားဖြတ်များ၌ခေါ်ဆိုသူသို့ပြန်သွားသော
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Rust ပြXနာ #74679 ကြောင့်ကျွန်ုပ်တို့သည် unsized array pointers သို့အတင်းအကျပ်တောင်းဆိုရမည်။
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// node အရှည်ကိုသီးသန့်အသုံးပြုခွင့်ရယူသည်။
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// node ကိုအခြားရည်ညွှန်းချက်များအားအလုပ်မလုပ်ဘဲ၊ ၎င်းကိုသူ့မိဘ edge သို့ဆက်သွယ်သည်။
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// root link အား၎င်း၏ parent edge အားရှင်းလင်းသည်။
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// node ၏အဆုံးသို့သော့ချက်တန်ဖိုးစုံကိုထည့်သည်။
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// `range` မှပြန်လာသောပစ္စည်းတိုင်းသည် node အတွက်မှန်ကန်သော edge အညွှန်းကိန်းဖြစ်သည်။
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// သော့ချက်တန်ဖိုးအတွဲနှင့် edge ကိုထိုအတွဲ၏ညာဘက်သို့သွားရန် node ၏အဆုံးသို့ထည့်သည်။
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// node တစ်ခု `Internal` node တစ်ခုလား၊ `Leaf` node လားဆိုတာစစ်ဆေးသည်။
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// တစ် ဦး node ကိုအတွင်းတိကျတဲ့ key ကိုတန်ဖိုးကို pair တစုံသို့မဟုတ် edge တစ် ဦး ကိုကိုးကား။
/// `Type` သည် `KV` (key-value pair တစုံတွင်လက်ကိုင်ကိုဖော်ပြခြင်း) သို့မဟုတ် `Edge` (edge ပေါ်ရှိလက်ကိုင်ကိုဖော်ပြခြင်း) ဖြစ်စေသော်လည်း `Node` parameter သည် `NodeRef` ဖြစ်ရမည်။
///
/// `Leaf` node များ၌ပင် `Edge` လက်ကိုင်များရှိနိုင်သည်ကိုသတိပြုပါ။
/// child node တစ်ခုသို့ pointer ကိုကိုယ်စားပြုမည့်အစား၊ ၎င်းတို့သည် key-value အတွဲများအကြားရှိကလေး pointers များသွားမည့်နေရာများကိုကိုယ်စားပြုသည်။
/// ဥပမာအားဖြင့်၊ အရှည် ၂ ရှိသည့် node တစ်ခုတွင်ဖြစ်နိုင်သောဖြစ်နိုင်ချေရှိသော edge တည်နေရာ ၃ ခု၊ node ၏ဘယ်ဘက်တွင်တစ်ခု၊ အတွဲနှစ်ခုအကြားနှင့်တစ်ခုသည် node ၏ညာဘက်တွင်ရှိသည်။
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// `Node` `Clone`able will တစ်ခုတည်းသောအချိန်ကာလသည်မပြောင်းလဲနိုင်သောအရာများဖြစ်သောကြောင့်ထို့ကြောင့် `Copy` ဖြစ်သည့်အတွက်ကျွန်ုပ်တို့သည် `#[derive(Clone)]` အပြည့်အဝယေဘူယျအားဖြင့်မလိုအပ်ပါ။
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// ဒီလက်ကိုင်ကညွှန်ပြသည့် edge သို့မဟုတ်သော့ချက်တန်ဖိုးအတွဲပါသော node ကိုပြန်လည်ထုတ်ယူသည်။
    pub fn into_node(self) -> Node {
        self.node
    }

    /// node ထဲတွင်ဤလက်ကိုင်၏အနေအထားကိုပြန်သွားသည်။
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// `node` ရှိ key-value pair အတွက်လက်ကိုင်အသစ်တစ်ခုကိုဖန်တီးသည်။
    /// လုံခြုံမှုမရှိသောကြောင့်ခေါ်ဆိုသူသည် `idx < node.len()` ကိုသေချာအောင်ပြုလုပ်ရမည်။
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// PartialEq ၏အများပြည်သူဆိုင်ရာအကောင်အထည်ဖော်မှုဖြစ်နိုင်သော်လည်းဤ module တွင်သာအသုံးပြုနိုင်သည်။
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// တူညီသောနေရာတွင်နောက်ထပ်မပြောင်းလဲနိုင်သောအရာတစ်ခုကိုခေတ္တထုတ်ယူသည်။
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // ကျွန်ုပ်တို့၏အမျိုးအစားကိုမသိသောကြောင့်ကျွန်ုပ်တို့သည် Handle::new_kv သို့မဟုတ် Handle::new_edge ကို သုံး၍ မရပါ
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// လုံခြုံမှုမရှိခြင်းသည် compiler အားအချက်အလက်အချက်အလက်များကိုလက်ကိုင်၏ node သည် `Leaf` ဖြစ်ကြောင်းဖော်ပြသည်။
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// တူညီသောနေရာတွင်အခြားပြောင်းလဲနိုင်သောလက်ကိုင်ကိုခေတ္တထုတ်ယူသည်။
    /// သတိပြုပါ၊ ဤနည်းလမ်းသည်အလွန်အန္တရာယ်ရှိသောကြောင့်ချက်ချင်းပင်အန္တရာယ်ရှိပုံမပေါ်သောကြောင့်၊
    ///
    ///
    /// အသေးစိတ်အတွက် `NodeRef::reborrow_mut` ကိုကြည့်ပါ။
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // ကျွန်ုပ်တို့၏အမျိုးအစားကိုမသိသောကြောင့်ကျွန်ုပ်တို့သည် Handle::new_kv သို့မဟုတ် Handle::new_edge ကို သုံး၍ မရပါ
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// `node` ရှိ edge အတွက်လက်ကိုင်အသစ်တစ်ခုကိုဖန်တီးသည်။
    /// လုံခြုံမှုမရှိသောကြောင့်ခေါ်ဆိုသူသည် `idx <= node.len()` ကိုသေချာအောင်ပြုလုပ်ရမည်။
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// ကျနော်တို့စွမ်းရည်ဖြည့်တဲ့ node ကိုသို့ထည့်သွင်းချင်ဘယ်မှာတစ်ခု edge အညွှန်းကိန်းပေးထားသော, split point ၏တစ် ဦး ပညာရှိ KV အညွှန်းကိန်းနှင့်ဘယ်မှာသွင်းဖျော်ဖြေဖို့တွက်ချက်။
///
/// split point ၏ရည်မှန်းချက်သည်၎င်းကိုသော့နှင့်တန်ဖိုးသည် parent node တစ်ခုတွင်အဆုံးသတ်ရန်ဖြစ်သည်။
/// split point ၏ဘယ်ဘက်ရှိသော့များ၊ တန်ဖိုးများနှင့်အနားများသည်ဘယ်ဘက်ကလေးဖြစ်လာသည်။
/// split point ၏ညာဘက်ရှိသော့များ၊ တန်ဖိုးများနှင့်အနားများသည်မှန်ကန်သောကလေးဖြစ်လာသည်။
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust ပြissueနာ #74834 သည်ဤအချိုးကျသောစည်းမျဉ်းများကိုရှင်းပြရန်ကြိုးစားသည်။
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// ဒီ edge ၏ညာဘက်နှင့်ဘယ်ဘက်သို့သော့ချက်တန်ဖိုးအတွဲများအကြား key-value pair အသစ်တစ်ခုကိုထည့်သည်။
    /// ဒီနည်းလမ်းကအသစ်သော pair တစုံကိုအံဝင်ခွင်ကျဖြစ်စေရန်အတွက် node ထဲတွင်နေရာအလုံအလောက်ရှိသည်ဟုယူဆသည်။
    ///
    /// ပြန်လာသော pointer သည်ဖြည့်ထားသောတန်ဖိုးကိုညွှန်ပြသည်။
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// ဒီ edge ၏ညာဘက်နှင့်ဘယ်ဘက်သို့သော့ချက်တန်ဖိုးအတွဲများအကြား key-value pair အသစ်တစ်ခုကိုထည့်သည်။
    /// နေရာမလုံလောက်ပါကဤနည်းလမ်းသည် node ကိုကွဲစေသည်။
    ///
    /// ပြန်လာသော pointer သည်ဖြည့်ထားသောတန်ဖိုးကိုညွှန်ပြသည်။
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// ဒီ edge ဆက်သွယ်ထားသော child node အတွင်းရှိမိဘညွှန်ကိန်းနှင့်အညွှန်းကိုပြုပြင်သည်။
    /// အနားရဲ့အမိန့်ကိုပြောင်းပြီးတဲ့အခါဒါကအသုံးဝင်ပါတယ်။
    fn correct_parent_link(self) {
        // အခြားဆုံမှတ်များကိုကိုးကားခြင်းမရှိဘဲ backpointer ကိုဖန်တီးပါ။
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// key-value pair အသစ်နှင့် edge အသစ်တစ်ခုကိုထည့်ပြီး edge ၏ညာဘက်ရှိ edge နှင့် key-value pair ကြားရှိ pair တစုံအသစ်၏ညာဘက်သို့သွားလိမ့်မည်။
    /// ဒီနည်းလမ်းကအသစ်သော pair တစုံကိုအံဝင်ခွင်ကျဖြစ်စေရန်အတွက် node ထဲတွင်နေရာအလုံအလောက်ရှိသည်ဟုယူဆသည်။
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// key-value pair အသစ်နှင့် edge အသစ်တစ်ခုကိုထည့်ပြီး edge ၏ညာဘက်ရှိ edge နှင့် key-value pair ကြားရှိ pair တစုံအသစ်၏ညာဘက်သို့သွားလိမ့်မည်။
    /// နေရာမလုံလောက်ပါကဤနည်းလမ်းသည် node ကိုကွဲစေသည်။
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// ဒီ edge ၏ညာဘက်နှင့်ဘယ်ဘက်သို့သော့ချက်တန်ဖိုးအတွဲများအကြား key-value pair အသစ်တစ်ခုကိုထည့်သည်။
    /// ဤနည်းလမ်းသည်နေရာမလုံလောက်ပါက node ကိုကွဲစေပြီး၊ root node သို့မရောက်မချင်း၊ ကွဲလွဲသောအပိုင်းကို parent node ထဲသို့ပြန်လည်ထည့်သွင်းရန်ကြိုးစားသည်။
    ///
    ///
    /// ပြန်လာသောရလဒ်သည် `Fit` ဖြစ်ပါက၎င်း၏လက်ကိုင် node သည်ဤ edge ၏ node သို့မဟုတ်ဘိုးဘေးတစ်မျိုးဖြစ်နိုင်သည်။
    /// ပြန်လာသောရလဒ်သည် `Split` ဖြစ်ပါက `left` အကွက်သည်မူလဆုံမှတ်ဖြစ်လိမ့်မည်။
    /// ပြန်လာသော pointer သည်ဖြည့်ထားသောတန်ဖိုးကိုညွှန်ပြသည်။
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// ဒီ edge မှညွှန်ပြသော node ကိုရှာသည်။
    ///
    /// method name သည်သင့်အား top node နှင့်အတူသစ်ပင်များကိုပုံဖော်သည်။
    ///
    /// `edge.descend().ascend().unwrap()` နှင့် `node.ascend().unwrap().descend()` နှစ်ခုစလုံး, အောင်မြင်မှုအပျေါမှာဘာမျှမလုပ်သင့်ပါတယ်။
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // node များသို့ point point များသုံးရန်လိုသည်။ အဘယ်ကြောင့်ဆိုသော် BorrowType သည် marker::ValMut ဖြစ်ပါကကျွန်ုပ်တို့သည်မှားယွင်းမှုမပြုသင့်သောတန်ဖိုးများအတွက်ထူးခြားသောပြောင်းလဲနိုင်သောရည်ညွှန်းချက်များရှိနိုင်သည်။
        // ထိုတန်ဖိုးကိုကူးယူသောကြောင့်အမြင့်ကိုလယ်ကွင်းကိုဝင်ရောက်ရန်စိတ်မပူပါ။
        // သတိပြုပါ။ node pointer သည် deferenferenced လုပ်သည်နှင့်တစ်ပြိုင်နက်ကျွန်ုပ်တို့သည်အနားကအနားကွပ်ကို (Rust issue #73987) ဖြင့် ဝင်ရောက်၍ အခြားမည်သည့်ရည်ညွှန်းချက်များကိုမဆိုပတ် ၀ န်းကျင်ရှိသင့်သည်ကိုသတိပြုပါ။
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // သီးခြားသော့နှင့်တန်ဖိုးနည်းလမ်းများကိုကျွန်ုပ်တို့မခေါ်နိုင်ပါ၊ အဘယ့်ကြောင့်ဆိုသော်ဒုတိယတစ်ခုခေါ်ခြင်းသည်ပထမကပြန်လာသည့်ရည်ညွှန်းချက်ကိုပျက်ပြားစေသည်။
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// KV လက်ကိုင်များရည်ညွှန်းသောသော့နှင့်တန်ဖိုးကိုအစားထိုးပါ။
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// သစ်ရွက်အချက်အလက်များကိုဂရုစိုက်ခြင်းအားဖြင့် `NodeType` တစ်ခုအတွက် `split` ၏အကောင်အထည်ဖော်မှုကိုကူညီပါ။
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// နောက်ခံ node ကိုအပိုင်းသုံးပိုင်းခွဲထားသည်။
    ///
    /// - ဒီလက်ကိုင်၏ဘယ်ဘက်တွင်သော့တန်ဖိုးတန်ဖိုးအားလုံးပါ ၀ င်ရန်သာ node ကိုဖြတ်သည်။
    /// - ဒီလက်ကိုင်အားဖြင့်ညွှန်ပြသော့နှင့်တန်ဖိုးကိုထုတ်ယူနေကြသည်။
    /// - ဒီလက်ကိုင်၏ညာဘက်ရှိ key-value များအားလုံးကိုအသစ်စက်စက်ခွဲဝေထားသော node ထဲသို့ထည့်သည်။
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// ဒီလက်ကိုင်ကညွှန်ပြသော key-value pair ကိုဖယ်ရှားလိုက်ပြီး key-value pair တစ္ခုပြိုကျသွားသော edge နှင့်အတူပြန်သွားသည်။
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// နောက်ခံ node ကိုအပိုင်းသုံးပိုင်းခွဲထားသည်။
    ///
    /// - ဒီလက်ကိုင်၏ဘယ်ဘက်မှအနားနှင့်သော့တန်ဖိုးတန်ဖိုးများပါ ၀ င်ရန်သာ node ကိုဖြတ်သည်။
    /// - ဒီလက်ကိုင်အားဖြင့်ညွှန်ပြသော့နှင့်တန်ဖိုးကိုထုတ်ယူနေကြသည်။
    /// - ဒီလက်ကိုင်၏ညာဘက်ရှိအနားအားလုံးနှင့်အနားရှိတန်ဖိုးနှင့်တန်ဖိုးအတွဲများအားလုံးကိုအသစ်စက်စက်ခွဲဝေထားသောဆုံမှတ်ထဲသို့ထည့်သည်။
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// အတွင်းပိုင်းသော့ချက်တန်ဖိုးအတွဲတစ်ခုတွင်ဟန်ချက်ညီညီလုပ်ဆောင်မှုကိုအကဲဖြတ်ခြင်းနှင့်လုပ်ဆောင်ခြင်းအတွက် session တစ်ခုကိုကိုယ်စားပြုသည်။
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// node ကိုကလေးတစ် ဦး အနေဖြင့်ဟန်ချက်ညီစေသည့်အခြေအနေကိုရွေးချယ်သည်။ ထို့ကြောင့် KV အကြားဘယ်ဘက်သို့သို့မဟုတ်မိဘဆုံမှတ်ရှိညာဘက်သို့သွားသည်။
    /// မိဘမရှိလျှင် `Err` တစ်ခုကိုပြန်ပို့သည်။
    /// မိဘအချည်းနှီးဖြစ်ပါက Panics
    ///
    /// ဘယ်ဘက်အခြမ်းကိုပေးထားသော node သည်တစ်နည်းနည်းဖြင့်ပြည့်နေလျှင်အကောင်းဆုံးဖြစ်ရန်ဆိုလိုသည်။ ဤနေရာတွင်၎င်း၏တည်ရှိနေလျှင်၎င်းတွင်၎င်း၏ဘယ်ဘက်မောင်နှမထက်ညာဘက်မှေးမှိန်ခြင်းထက်ပိုနည်းသည်။
    /// ကျွန်ုပ်တို့သည် node's N element များကိုရွေ့လျားရုံသာမဟုတ်ဘဲညာဘက်သို့ရွှေ့ပြီးရှေ့ဘက် N ထက်ပိုသောလှုပ်ရှားမှုများကိုသာလုပ်ရန်လိုအပ်သည်။
    /// ဘယ်ဘက်မှေးခငျြးမှခိုးယူခြင်းသည်လည်းပုံမှန်အားဖြင့်ပိုမိုမြန်ဆန်ပါသည်။ အဘယ်ကြောင့်ဆိုသော်မောင်နှမ၏ဒြပ်စင်အနည်းဆုံး N ကိုဘယ်ဘက်သို့ရွှေ့ပြောင်းမည့်အစား node ၏ N element များကိုညာဘက်သို့သာရွေ့ရန်လိုအပ်သည်။
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// ပေါင်းစည်းမှုဖြစ်နိုင်ခြေရှိမရှိပြန်သွားသည်။ ဆိုလိုသည်မှာဗဟို KV ကိုကပ်လျက်ကလေး node နှစ်ခုလုံးနှင့်ပေါင်းစပ်ရန်နေရာအလုံအလောက်ရှိမရှိပြန်ပို့သည်။
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// ပေါင်းစည်းမှုကိုလုပ်ဆောင်သည်နှင့်တစ် ဦး ပိတ်သိမ်းပြန်လာဖို့ဘာဆုံးဖြတ်ရန်ပေးနိုင်ပါတယ်။
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // လုံခြုံမှု-ပေါင်းစည်းနေသည့် node များ၏အမြင့်သည်အမြင့်ထက်နည်းသည်
                // ဒီ edge ၏ node ကို၏, အရှင်သုညအထက်, ဒါကြောင့်သူတို့ကပြည်တွင်းရေးဖြစ်ကြသည်။
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// မိဘ၏ key-value pair နှင့်ကပ်လျက်ကလေး node နှစ်ခုစလုံးကိုဘယ်ဘက် node ထဲသို့ပေါင်းထည့်လိုက်ပြီးကျုံ့မိဘ node ကိုပြန်လည်ပေးသည်။
    ///
    ///
    /// ကျွန်တော် `.can_merge()` မဟုတ်လျှင် Panics ။
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// မိဘ၏သော့တန်ဖိုးတန်ဖိုးစုံနှင့်ကပ်လျက်ကလေး node နှစ်ခုစလုံးကိုဘယ်ဘက် node ထဲသို့ပေါင်းထည့်ပြီးထို node ကိုပြန်ပို့သည်။
    ///
    ///
    /// ကျွန်တော် `.can_merge()` မဟုတ်လျှင် Panics ။
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// မိဘ၏သော့တန်ဖိုးတန်ဖိုးစုံနှင့်ကပ်လျက်ကလေး node နှစ်ခုစလုံးကိုဘယ်ဘက် node ထဲသို့ပေါင်းထည့်လိုက်ပြီးခြေရာခံကလေး edge အဆုံးသတ်သွားသောထိုကလေး node အတွင်းရှိ edge လက်ကိုင်ကိုပြန်ပို့သည်။
    ///
    ///
    /// ကျွန်တော် `.can_merge()` မဟုတ်လျှင် Panics ။
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// ဘယ်ဘက်ကလေးမှ key-value pair ကိုဖယ်ရှားပြီး၎င်းသည်မိဘ၏ key-value pair ကိုညာဘက်ကလေးသို့တွန်းပို့နေစဉ်မိဘ၏သော့ချက်တန်ဖိုးသိုလှောင်မှုတွင်နေရာချသည်။
    ///
    /// ညာဘက်ကလေးရှိ edge သို့လက်ကိုင်တစ်ခုကို `track_right_edge_idx` မှသတ်မှတ်ထားသောမူရင်း edge မှအဆုံးသတ်သည်။
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// key-value pair ကိုညာဘက်ကလေးထံမှဖယ်ရှားပြီး၎င်းသည်မိဘ၏သော့တန်ဖိုးသိုလှောင်မှုတွင်နေရာချပြီးမိဘဟောင်းသော key-value pair ကိုဘယ်ဘက်ကလေးသို့ထည့်လိုက်သည်။
    ///
    /// `track_left_edge_idx` မှသတ်မှတ်ထားသောဘယ်ဘက်ကလေးရှိ edge သို့လက်ကိုင်တစ်ခုကိုပြန်ပို့သည်။ ၎င်းသည်မရွှေ့ပါ။
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// ၎င်းသည် `steal_left` နှင့်အလားတူခိုးယူသော်လည်းဒြပ်စင်မျိုးစုံကိုခိုးယူသည်။
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // လုံခြုံစွာခိုးယူနိုင်အောင်သေချာအောင်လုပ်ပါ။
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // အရွက်ဒေတာကိုရွှေ့ပါ။
            {
                // သင့်တော်သောကလေးတွင်ခိုးယူသောအရာများအတွက်နေရာချထားပါ။
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // ဘယ်ဘက်ကလေးမှ element များကိုညာဘက်သို့ရွှေ့ပါ။
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // ဘယ်သန်ဆုံးခိုးယူခံရသောစုံတွဲကိုမိဘထံသို့ရွှေ့ပါ။
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // မိဘ၏သော့တန်ဖိုးတန်ဖိုးကိုညာဘက်ကလေးသို့ရွှေ့ပါ။
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // ခိုးယူအနားများအတွက်အခန်းတစ်ခန်းလုပ်ပါ။
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // အနားခိုးယူ။
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// `bulk_steal_left` ၏အချိုးကျကိုယ်ပွား။
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // လုံခြုံစွာခိုးယူနိုင်အောင်သေချာအောင်လုပ်ပါ။
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // အရွက်ဒေတာကိုရွှေ့ပါ။
            {
                // လက်ျာဆုံးခိုးယူခံရသောအတွဲကိုမိဘထံသို့ရွှေ့ပါ။
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // မိဘ၏သော့တန်ဖိုးအတွဲကိုဘယ်ဘက်ကလေးသို့ရွှေ့ပါ။
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // ဒြပ်စင်များကိုလက်ျာကလေးမှဘယ်ဘက်သို့ရွှေ့ပါ။
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // ခိုးယူသောဒြပ်စင်များဖြစ်လေ့ရှိရာကွာဟမှုကိုဖြည့်ပါ။
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // အနားခိုးယူ။
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // ခိုးယူအနားဖြစ်လေ့ရှိရာကွာဟမှုကိုဖြည့်ပါ။
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// ဤ node သည် `Leaf` node တစ်ခုဖြစ်သည်ဟုအခိုင်အမာဆိုသောမည်သည့် static information ကိုမဆိုဖယ်ရှားသည်။
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// ဤ node သည် `Internal` node တစ်ခုဖြစ်သည်ဟုအခိုင်အမာဆိုသည့်မည်သည့် static information ကိုမဆိုဖယ်ရှားပါသည်။
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// နောက်ခံ node သည် `Internal` node တစ်ခုသို့မဟုတ် `Leaf` node ဟုတ်မဟုတ်စစ်ဆေးသည်။
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// `self` ပြီးနောက်နောက်ဆက်ကိုဆုံမှတ်တစ်ခုမှတစ်ခုသို့ရွှေ့ပါ။`right` ဗလာဖြစ်ရမည်
    /// `right` ၏ပထမဆုံး edge သည်မပြောင်းလဲပါ။
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// ထည့်သွင်းခြင်း၏ရလဒ်, တစ်ခု node ကို၎င်း၏စွမ်းရည်ကိုကျော်လွန်ပြီးချဲ့ထွင်ရန်လိုအပ်သည့်အခါ။
pub struct SplitResult<'a, K, V, NodeType> {
    // `kv` ၏ဘယ်ဘက်နှင့်သက်ဆိုင်သော element များနှင့်အနားများရှိရှိပြီးသားသစ်ပင်ရှိရှိပြီးသားသစ်ပင်တွင်ပြောင်းလဲထားသော node ။
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // အချို့သောသော့နှင့်တန်ဖိုးများကိုအခြားနေရာများတွင်ထည့်သွင်းရန်ခွဲထား။
    pub kv: (K, V),
    // `kv` ၏ညာဘက်နှင့်သက်ဆိုင်သောဒြပ်စင်များနှင့်အနားများရှိသည့်ပိုင်ရှင်မပါ ၀ င်သော node အသစ်။
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // ဤချပ်ချပ်အမျိုးအစား၏ node ကိုးကားချက်များသည်သစ်ပင်ရှိအခြား node များသို့သွားရန်ခွင့်ပြုခြင်းရှိမရှိ။
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversal မလိုအပ်ပါ။ ၎င်းသည် `borrow_mut` ၏ရလဒ်ကိုအသုံးပြုသည်။
        // traversal ကို disable လုပ်ခြင်းနှင့်အမြစ်များကိုရည်ညွှန်းခြင်းအသစ်များဖန်တီးခြင်းအားဖြင့် `Owned` type အမျိုးအစားတိုင်းသည် root node တစ်ခုဖြစ်ကြောင်းကျွန်ုပ်တို့သိတယ်။
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// တန်ဖိုးတစ်ခုကိုထည့်သွင်းထားသောဒြပ်စင်၏အချပ်တစ်ခုထဲသို့ထည့်ပြီး uninitialized element တစ်ခုဖြင့်ထည့်သည်။
///
/// # Safety
/// အဆိုပါအချပ်ထက်ပို `idx` ဒြပ်စင်ရှိပါတယ်။
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// uninitialized element တစ်ခု၏နောက်ကွယ်တွင်ကျန်ရှိနေသော initialized element အားလုံး၏တန်ဖိုးတစ်ခုမှတန်ဖိုးတစ်ခုကိုဖယ်ထုတ်ပြီးပြန်ပေးသည်။
///
///
/// # Safety
/// အဆိုပါအချပ်ထက်ပို `idx` ဒြပ်စင်ရှိပါတယ်။
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// element များကိုဘယ်ဘက်သို့အချပ် `distance` အနေအထားဖြင့်ပြောင်းသည်။
///
/// # Safety
/// အချပ်မှာအနည်းဆုံး `distance` element တွေရှိတယ်။
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// element များကိုညာဘက်သို့အချပ် `distance` တည်နေရာများသို့ရွှေ့ပြောင်းသည်။
///
/// # Safety
/// အချပ်မှာအနည်းဆုံး `distance` element တွေရှိတယ်။
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// တန်ဖိုးများအားလုံးကို initialized element များ၏အချပ်တစ်ခုမှ uninitialized element များ၏အချပ်တစ်ခုသို့ရွှေ့လိုက်ပြီး `src` အားလုံးကို uninitialized အနေဖြင့်ထားခဲ့သည်။
///
/// `dst.copy_from_slice(src)` ကဲ့သို့အလုပ်လုပ်သော်လည်း X0XX မလိုအပ်ပါ။
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;