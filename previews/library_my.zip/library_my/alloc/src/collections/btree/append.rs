use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// လမ်းတစ်လျှောက် `length` variable ကိုတိုးခြင်း၊ တက်သောကြားနှစ်ခု၏ပေါင်းစည်းမှုမှ key-value များအားလုံးကို appends ။အပြန်အလှန်အားဖြင့်ဖုန်းကိုင်သူတစ် ဦး အနေဖြင့် drop handler တောက်ပလာသောအခါယိုစိမ့်ခြင်းကိုလွယ်ကူစေသည်။
    ///
    /// အကယ်၍ ကြားမှာနှစ်မျိုးစလုံးကတူညီတဲ့ key ကိုထုတ်လုပ်မယ်ဆိုရင်ဒီနည်းလမ်းကဘယ်ဖက်ကြားမှာရှိတဲ့ pair တစုံကိုကျဆင်းသွားမှာဖြစ်ပြီး၊
    ///
    /// အကယ်၍ သင်သည်သစ်ပင်တစ်ပင်ကိုတင်းကျပ်စွာမြင့်တက်နေသည့် `BTreeMap` ကဲ့သို့အဆုံးသတ်စေလိုပါက၎င်းကြားဖြတ်နှစ်မျိုးလုံးသည်တင်းကျပ်စွာမြင့်တက်နေသည့်အစဉ်အတိုင်းသော့များထုတ်ပေးသင့်သည်။ သစ်ပင်ရှိသော့အားလုံးထက်တစ်ခုစီသည်ဝင်ပေါက်ရှိသစ်ပင်၌ရှိနှင့်ပြီးသောသော့များအပါအဝင်ဖြစ်သည်။
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // ကျွန်ုပ်တို့သည် linear အချိန်၌ `left` နှင့် `right` ကိုအမျိုးအစားအလိုက်စီထားရန်ပြင်ဆင်သည်။
        let iter = MergeIter(MergeIterInner::new(left, right));

        // ဤအတောအတွင်းကျွန်ုပ်တို့သည် linear အချိန်တွင် sorted sequence ကိုမှအပင်တစ်ပင်ကိုတည်ဆောက်။
        self.bulk_push(iter, length)
    }

    /// key-value များအားလုံးကိုသစ်ပင်၏အဆုံးသို့တွန်းပို့ပြီး `length` variable ကိုလမ်းတစ်လျှောက်တိုးချဲ့သည်။
    /// နောက်တစ်ခုအနေဖြင့်ခေါ်ဆိုသူအနေနှင့်ကြားဖြတ်အထိတ်တလန့်ဖြစ်သည့်အခါယိုစိမ့်မှုကိုရှောင်ရှားရန်ပိုမိုလွယ်ကူစေသည်။
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // key-value အတွဲများအားလုံးကိုဖြတ်ပြီး၎င်းကိုညာဘက်အဆင့်ရှိ node များထဲသို့တွန်းပို့ပါ။
        for (key, value) in iter {
            // key-value pair ကိုလက်ရှိအရွက် node ထဲသို့တွန်းရန်ကြိုးစားပါ။
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // နေရာမရှိ၊ တက်ပြီးထိုတွင်တွန်းပါ။
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // နေရာလွတ်ကျန်ရှိသည့် node တစ်ခုရှာပြီးဒီမှာနှိပ်ပါ။
                                open_node = parent;
                                break;
                            } else {
                                // ပြန်သွားပါ
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // ထိပ်ဆုံးရောက်နေပြီ၊ root node အသစ်တစ်ခုဖန်တီးပြီးအဲဒီမှာတွန်းလိုက်ပါ။
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // key-value pair နှင့်လက်ျာ subtree အသစ်ကိုတွန်းပါ။
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // တဖန်လက်ျာအများဆုံးရွက်ကိုဆင်းသွားပါ။
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // တိုးမြှင့်မှုတိုင်းကိုတိုးရန်၊ မြေပုံသည်ထပ်တလဲလဲထိတ်လန့်တုန်လှုပ်နေလျှင်တောင်မှမြေပုံသည်တွဲဖက်ထားသည့်အရာများကိုမြေပုံကျစေမည်။
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// နှစ်ခုခွဲထားခဲ့သည်ပာတစ်ခုထဲသို့ပေါင်းစည်းဘို့ကြားမှာ
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// အကယ်၍ key နှစ်ခုသည်တန်းတူဖြစ်လျှင်မှန်ကန်သောရင်းမြစ်မှ key value value ကိုပြန်ပို့သည်။
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}