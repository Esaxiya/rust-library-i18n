use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef};

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    /// သစ်ပင်မှ key-value pair ကိုဖယ်ရှားပြီး၎င်းစုံတွဲကို၎င်းဟောင်း pair နှင့်သက်ဆိုင်သော edge အရွက်ကိုပြန်ပို့သည်။
    /// ဖြစ်နိုင်သည်မှာ၎င်းသည်အတွင်းပိုင်းဖြစ်သော root node တစ်ခုကိုသုတ်သင်နိုင်သည်။ ၎င်းအားသစ်ပင်ကိုင်ထားသောမြေပုံမှခေါ်ဆိုသူသည်ခေါ်ဆိုသင့်သည်။
    /// ခေါ်ဆိုသူသည်မြေပုံ၏အရှည်ကိုလည်းလျှော့ချသင့်သည်။
    ///
    pub fn remove_kv_tracking<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        match self.force() {
            Leaf(node) => node.remove_leaf_kv(handle_emptied_internal_root),
            Internal(node) => node.remove_internal_kv(handle_emptied_internal_root),
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    fn remove_leaf_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let (old_kv, mut pos) = self.remove();
        let len = pos.reborrow().into_node().len();
        if len < MIN_LEN {
            let idx = pos.idx();
            // ကလေး၏အမျိုးအစားကိုယာယီမေ့ထားရမည်။ အဘယ်ကြောင့်ဆိုသော်အရွက်၏အနီးဆုံးမိဘများအတွက်ကွဲပြားသော node အမျိုးအစားမရှိပါ။
            //
            let new_pos = match pos.into_node().forget_type().choose_parent_kv() {
                Ok(Left(left_parent_kv)) => {
                    debug_assert!(left_parent_kv.right_child_len() == MIN_LEN - 1);
                    if left_parent_kv.can_merge() {
                        left_parent_kv.merge_tracking_child_edge(Right(idx))
                    } else {
                        debug_assert!(left_parent_kv.left_child_len() > MIN_LEN);
                        left_parent_kv.steal_left(idx)
                    }
                }
                Ok(Right(right_parent_kv)) => {
                    debug_assert!(right_parent_kv.left_child_len() == MIN_LEN - 1);
                    if right_parent_kv.can_merge() {
                        right_parent_kv.merge_tracking_child_edge(Left(idx))
                    } else {
                        debug_assert!(right_parent_kv.right_child_len() > MIN_LEN);
                        right_parent_kv.steal_right(idx)
                    }
                }
                Err(pos) => unsafe { Handle::new_edge(pos, idx) },
            };
            // လုံခြုံမှု-`new_pos` ဆိုသည်မှာကျွန်ုပ်တို့စတင်ခဲ့သောအရွက်ဖြစ်သည်။
            pos = unsafe { new_pos.cast_to_leaf_unchecked() };

            // ကျွန်ုပ်တို့ပေါင်းစည်းမှသာမိဘ (ရှိလျှင်) ကျုံ့သွားသော်လည်းအောက်ပါအဆင့်ကိုကျော်သွားလျှင်၎င်းသည်အခြေခံစံနှုန်းများနှင့်မကိုက်ညီပါ။
            //
            // လုံခြုံမှု-`pos` ရှိသည့်အရွက်များကိုကျွန်ုပ်တို့မဖျက်ဆီးပါ
            // ၎င်း၏မိဘကိုပြန်လည်အသုံးပြုခြင်းအားဖြင့်,အဆိုးဆုံးမှာမိဘကိုအဘိုးအဘွားမှတစ်ဆင့်ဖျက်စီးခြင်းသို့မဟုတ်ပြန်လည်စီစဉ်ခြင်းပြုလုပ်လိုက်ခြင်းဖြင့်အရွက်အတွင်းရှိမိဘနှင့်ချိတ်ဆက်မှုကိုပြောင်းလဲပစ်လိုက်ခြင်းဖြစ်သည်။
            //
            //
            //
            if let Ok(parent) = unsafe { pos.reborrow_mut() }.into_node().ascend() {
                if !parent.into_node().forget_type().fix_node_and_affected_ancestors() {
                    handle_emptied_internal_root();
                }
            }
        }
        (old_kv, pos)
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    fn remove_internal_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        // ကပ်လျက် KV ကို၎င်း၏အရွက်မှဖယ်ရှားပြီးနောက်ကျွန်ုပ်တို့ဖယ်ရှားရန်တောင်းဆိုသည့်ဒြပ်စင်နေရာတွင်ပြန်ထည့်ပါ။
        //
        // `choose_parent_kv` တွင်ဖော်ပြထားသောအကြောင်းပြချက်များအတွက်ဘယ်ဘက်ကပ်လျက် KV ကို ဦး စားပေးမည်။
        let left_leaf_kv = self.left_edge().descend().last_leaf_edge().left_kv();
        let left_leaf_kv = unsafe { left_leaf_kv.ok().unwrap_unchecked() };
        let (left_kv, left_hole) = left_leaf_kv.remove_leaf_kv(handle_emptied_internal_root);

        // Internal node မှခိုးယူခံရခြင်းသို့မဟုတ်ပေါင်းစည်းခြင်းဖြစ်နိုင်သည်။
        // မူလ KV ဘယ်မှာလဲဆိုတာကိုရှာတွေ့ဖို့ညာဘက်ပြန်သွားပါ။
        let mut internal = unsafe { left_hole.next_kv().ok().unwrap_unchecked() };
        let old_kv = internal.replace_kv(left_kv.0, left_kv.1);
        let pos = internal.next_leaf_edge();
        (old_kv, pos)
    }
}