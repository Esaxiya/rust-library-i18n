use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// တူညီသောအကွာအဝေး၏အခြား, မပြောင်းလဲနိုင်သောအရာများနှင့်ညီမျှခဏထွက်ယူ။
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// သစ်ပင်တစ်ပင်တွင်သတ်မှတ်ထားသောအကွာအဝေးကိုကန့်သတ်ထားသည့်ကွဲပြားသောအရွက်အနားများကိုတွေ့သည်။
    /// ကွဲပြားခြားနားသော handles တစုံကိုပင်တပင်တည်းသို့တည်းမဟုတ်အချည်းနှီးသော option များဖြစ်စေပြန်သည်။
    ///
    /// # Safety
    ///
    /// `BorrowType` သည် `Immut` မဟုတ်လျှင်ထပ်တူလက်ကိုင်များကို KV အတူတူနှစ်ကြိမ်လည်ပတ်ရန်မသုံးပါနှင့်။
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// `(root1.first_leaf_edge(), root2.last_leaf_edge())` နှင့်ညီမျှသော်လည်း ပို၍ ထိရောက်သည်။
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// သစ်ပင်တစ်ပင်တွင်သတ်သတ်မှတ်မှတ်အကွာအဝေးကိုကန့်သတ်ထားသည့်အရွက်အနားများအတွဲကိုရှာသည်။
    ///
    /// `BTreeMap` ရှိသစ်ပင်ကဲ့သို့သစ်ပင်ကိုသော့ဖြင့်အမိန့်ပေးမှသာလျှင်ရလဒ်သည်အဓိပ္ပါယ်ရှိသည်။
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // လုံခြုံမှု-ကျွန်ုပ်တို့၏ချေးငွေအမျိုးအစားမှာမပြောင်းလဲနိုင်သောအရာများဖြစ်သည်။
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// သစ်ပင်တစ်ပင်လုံးကိုခုတ်လှဲထားသည့်သစ်ရွက်အနားများအတွဲကိုရှာသည်။
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// သတ်မှတ်ထားသောအကွာအဝေး delimiting အရွက်အနားတရံသို့ထူးခြားသောရည်ညွှန်းပိုင်းခွဲ။
    /// ရလဒ်မှာ (some) mutation ကိုခွင့်ပြုထားသောထူးခြားသောကိုးကားချက်များဖြစ်သည်။ ၎င်းကိုဂရုတစိုက်အသုံးပြုရမည်။
    ///
    /// `BTreeMap` ရှိသစ်ပင်ကဲ့သို့သစ်ပင်ကိုသော့ဖြင့်အမိန့်ပေးမှသာလျှင်ရလဒ်သည်အဓိပ္ပါယ်ရှိသည်။
    ///
    ///
    /// # Safety
    /// တူညီသော KV ကိုနှစ်ကြိမ်လည်ပတ်ရန်ပုံတူလက်ကိုင်များကိုမသုံးပါနှင့်။
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// သစ်ပင်၏အသီးအပွင့်အကွာအဝေးကိုကန့်သတ်ထားသည့်အရွက်တစ်စုံသို့ထူးခြားသောရည်ညွှန်းချက်ကိုခွဲထုတ်သည်။
    /// ရလာဒ်များသည် mutation ကို (တန်ဖိုးများသာ) ခွင့်ပြုသည့်ထူးခြားသောကိုးကားချက်များဖြစ်သဖြင့်ဂရုတစိုက်အသုံးပြုရမည်။
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // ဤနေရာတွင် NodeRef root ကိုကျွန်ုပ်တို့ထပ်တူပြုသည်။ ကျွန်ုပ်တို့သည် KV တခါတည်းထပ်မံသွားရောက်လည်ပတ်မည်မဟုတ်ပါ၊ ထပ်တူထပ်နေသောတန်ဖိုးညွှန်းကိန်းများနှင့်လည်းအဆုံးသတ်လိမ့်မည်မဟုတ်ပါ။
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// သစ်ပင်၏အသီးအပွင့်အကွာအဝေးကိုကန့်သတ်ထားသည့်အရွက်တစ်စုံသို့ထူးခြားသောရည်ညွှန်းချက်ကိုခွဲထုတ်သည်။
    /// ရလဒ်များသည်အလွန်အမင်းပျက်စီးစေသော mutation ကိုခွင့်ပြုထားသောထူးခြားသောကိုးကားချက်များဖြစ်သဖြင့်အထူးဂရုပြုရန်အသုံးပြုရမည်။
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // ဤနေရာတွင် NodeRef root ကိုကျွန်ုပ်တို့ထပ်ပွားသည်။ ၎င်းသည် root မှရရှိသောရည်ညွှန်းချက်များထပ်တူကျအောင်မည်သည့်အခါမျှထိုအရာကိုဘယ်တော့မျှသုံးမည်မဟုတ်ပါ။
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// အရွက် edge လက်ကိုင်ကိုပေးပြီး [`Result::Ok`] ကိုလက်ျာဘက်ရှိအိမ်နီးချင်း KV ဆီသို့ပြန်ပို့ပေးသည်။ ၎င်းသည်တူညီသောအရွက် node တစ်ခုသို့မဟုတ်ဘိုးဘွား node တစ်ခုတွင်ဖြစ်လိမ့်မည်။
    ///
    /// edge အရွက်သည်သစ်ပင်တွင်နောက်ဆုံးဖြစ်သည်ဆိုလျှင် root node နှင့် [`Result::Err`] ကိုပြန်ပို့သည်။
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// အရွက် edge လက်ကိုင်ကိုပေးထားပြီး [`Result::Ok`] ကိုလက်ဝဲဘက်ရှိ KV ဆီသို့ပြန်ပို့ပေးသည်။ ၎င်းသည်တူညီသောအရွက် node တစ်ခုသို့မဟုတ်ဘိုးဘွား node တစ်ခုအတွင်းတွင်ရှိနေသည်။
    ///
    /// အကယ်၍ အရွက် edge သည်သစ်ပင်တွင်ပထမဆုံးဖြစ်သည်ဆိုလျှင်၊ root node နှင့် [`Result::Err`] ကိုပြန်ပို့သည်။
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// အတွင်းပိုင်း edge လက်ကိုင်တစ်ခုအနေနှင့် [`Result::Ok`] ကိုလက်ျာဘက်ရှိအိမ်နီးချင်း KV ဆီသို့ပြန်သွားသည်။ ၎င်းသည်အတွင်းပိုင်း node တစ်ခုတည်းတွင်သို့မဟုတ်မျိုးရိုးလိုက် node တစ်ခုတွင်ရှိနေသည်။
    ///
    /// အတွင်းပိုင်း edge သည်သစ်ပင်၏နောက်ဆုံးတစ်ခုဖြစ်လျှင်၊ XodeX root root ကိုပြန်ပို့သည်။
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// အရွက် edge သည်သေနေသည့်အပင်ထဲသို့လက်ကိုင်ထားပြီးလျှင်ညာဘက်ခြမ်းရှိနောက်အရွက် edge နှင့်အရွက်တစ်ခုအတွင်းတွင်ရှိသည့်သော့ချက်တန်ဖိုးတန်ဖိုးကိုပြန်ပေးသည်။
    ///
    ///
    /// ဤနည်းလမ်းသည်၎င်းအဆုံးသို့ရောက်သောမည်သည့် node(s) ကိုမဆို deallocates လုပ်သည်။
    /// ဆိုလိုသည်မှာ key-value pair မရှိလျှင်သစ်ပင်၏ကျန်တစ်ခုလုံးကိုဖယ်ရှားလိုက်ပြီးပြန်သွားစရာဘာမှမရှိတော့ဟုဆိုလိုသည်။
    ///
    /// # Safety
    /// ပေးထားသော edge သည်ယခင် Xpartx counterpart အားဖြင့်ပြန်ပို့ခြင်းမပြုရပါ။
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// အရွက် edge သည်သေနေသောအပင်ထဲသို့လက်ကိုင်ထားပြီးလျှင်လက်ဝဲဘက်ရှိနောက်အရွက် edge နှင့်အရွက်ဆုံချက်အမှတ်အသားတစ်ခု၊ ဘိုးဘွား node တစ်ခုသို့မဟုတ်မတည်ရှိသောအကြားရှိကြားထဲရှိသော့တန်ဖိုးတန်ဖိုး။
    ///
    ///
    /// ဤနည်းလမ်းသည်၎င်းအဆုံးသို့ရောက်သောမည်သည့် node(s) ကိုမဆို deallocates လုပ်သည်။
    /// ဆိုလိုသည်မှာ key-value pair မရှိလျှင်သစ်ပင်၏ကျန်တစ်ခုလုံးကိုဖယ်ရှားလိုက်ပြီးပြန်သွားစရာဘာမှမရှိတော့ဟုဆိုလိုသည်။
    ///
    /// # Safety
    /// ပေးထားသော edge သည်ယခင် Xpartx counterpart အားဖြင့်ပြန်ပို့ခြင်းမပြုရပါ။
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// အရွက်မှအမြစ်အထိ node များပုံကိုဖယ်ထုတ်သည်။
    /// ဤသည်မှာ `deallocating_next` နှင့် `deallocating_next_back` သည်သစ်ပင်၏နှစ်ဖက်စလုံးတွင် nibbling ပြီးလျှင် edge ကိုထပ်မံထိတွေ့ပြီးနောက်ကျန်ရှိသောအပင်၏အသီးကိုဖယ်ရှားရန်တစ်ခုတည်းသောနည်းလမ်းဖြစ်သည်။
    /// သော့နှင့်တန်ဖိုးများအားလုံးကိုပြန်ပို့ပြီးသောအခါခေါ်ရန်သာရည်ရွယ်ထားသောကြောင့်မည်သည့်သော့နှင့်တန်ဖိုးများကိုမျှသန့်ရှင်းအောင်မပြုလုပ်နိုင်ပါ။
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// အရွက် edge လက်ကိုင်ကိုနောက်အရွက် edge သို့ရွှေ့။ ကြားကြားရှိသော့နှင့်တန်ဖိုးကိုရည်ညွှန်းသည်။
    ///
    ///
    /// # Safety
    /// ခရီးသွားသော ဦး တည်ချက်တွင်အခြားကေဗွီရှိရမည်။
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// အရွက် edge လက်ကိုင်ကိုယခင်အရွက် edge သို့ရွှေ့။ ကြားကြားရှိသော့နှင့်တန်ဖိုးကိုရည်ညွှန်းသည်။
    ///
    ///
    /// # Safety
    /// ခရီးသွားသော ဦး တည်ချက်တွင်အခြားကေဗွီရှိရမည်။
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// အရွက် edge လက်ကိုင်ကိုနောက်အရွက် edge သို့ရွှေ့။ ကြားကြားရှိသော့နှင့်တန်ဖိုးကိုရည်ညွှန်းသည်။
    ///
    ///
    /// # Safety
    /// ခရီးသွားသော ဦး တည်ချက်တွင်အခြားကေဗွီရှိရမည်။
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // သတ်မှတ်ချက်များအရဤနောက်ဆုံးလုပ်ခြင်းသည်ပိုမိုမြန်ဆန်သည်။
        kv.into_kv_valmut()
    }

    /// edge လက်ကိုင်အရွက်ကိုယခင်အရွက်သို့ရွှေ့ပြီးကြားထဲရှိသော့နှင့်တန်ဖိုးကိုရည်ညွှန်းသည်။
    ///
    ///
    /// # Safety
    /// ခရီးသွားသော ဦး တည်ချက်တွင်အခြားကေဗွီရှိရမည်။
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // သတ်မှတ်ချက်များအရဤနောက်ဆုံးလုပ်ခြင်းသည်ပိုမိုမြန်ဆန်သည်။
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// edge အရွက်လက်ကိုင်ကိုနောက်အရွက် edge သို့ရွှေ့လိုက်ပြီးသက်ဆိုင်ရာ edge သည်၎င်း၏ node dangling တွင်ကျန်နေစဉ်ကျန်ရှိနေသေးသောမည်သည့် node ကိုမဆိုဖယ်ရှားပစ်လိုက်သည်။
    ///
    /// # Safety
    /// - ခရီးသွားသော ဦး တည်ချက်တွင်အခြားကေဗွီရှိရမည်။
    /// - သစ်ပင်ကိုဖြတ်ကူးရန်အသုံးပြုသောလက်ကိုင်များကို KV သည် counterpart `next_back_unchecked` မှယခင်ကပြန်မရခဲ့ပေ။
    ///
    /// အဆင့်မြှင့်ထားသောလက်ကိုင်ကိုဆက်လက်လုပ်ဆောင်ရန်တစ်ခုတည်းသောလုံခြုံသည့်နည်းလမ်းမှာ၎င်းအားနှိုင်းယှဉ်ခြင်း၊ ပစ်ချခြင်း၊ ဤနည်းလမ်းကို၎င်း၏လုံခြုံမှုအခြေအနေများနှင့်ထပ်မံခေါ်ယူခြင်းသို့မဟုတ်သူနှင့်သက်ဆိုင်သော `next_back_unchecked` ဘာသာရပ်ကို၎င်း၏လုံခြုံရေးအခြေအနေများအားခေါ်ဆိုခြင်းဖြစ်သည်။
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// edge အရွက်လက်ကိုင်ကိုယခင်အရွက် edge သို့ရွှေ့လိုက်ပြီးသက်ဆိုင်ရာ edge သည်၎င်း၏ node dangling တွင်ကျန်နေစဉ်ကျန်ရှိနေသေးသောမည်သည့် node ကိုမဆိုဖယ်ရှားပစ်လိုက်သည်။
    ///
    /// # Safety
    /// - ခရီးသွားသော ဦး တည်ချက်တွင်အခြားကေဗွီရှိရမည်။
    /// - ထိုအရွက် edge သည်ယခင်က counterpart `next_unchecked` မှသစ်ပင်ကိုဖြတ်ကူးရန်အသုံးပြုသောလက်ကိုင်မိတ္တူများမှပြန်လည်မပေးခဲ့ပါ။
    ///
    /// အဆင့်မြှင့်ထားသောလက်ကိုင်ကိုဆက်လက်လုပ်ဆောင်ရန်တစ်ခုတည်းသောလုံခြုံသည့်နည်းလမ်းမှာ၎င်းအားနှိုင်းယှဉ်ခြင်း၊ ပစ်ချခြင်း၊ ဤနည်းလမ်းကို၎င်း၏လုံခြုံမှုအခြေအနေများနှင့်ထပ်မံခေါ်ယူခြင်းသို့မဟုတ်သူနှင့်သက်ဆိုင်သော `next_unchecked` ဘာသာရပ်ကို၎င်း၏လုံခြုံရေးအခြေအနေများအားခေါ်ဆိုခြင်းဖြစ်သည်။
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// တစ်နည်းအားဖြင့်ရှေ့သို့သွားသောအခါ (သို့မဟုတ်နောက်သို့နောက်သို့သွားသောအခါ) ပထမ ဦး ဆုံးသင်လိုအပ်သည့် edge သည် node တစ်ခုအတွင်းသို့မဟုတ်အောက်ရှိလက်ဝဲဘက်အရွက် edge ကိုပြန်ပို့ပေးသည်။
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// တစ်နည်းအားဖြင့်ရှေ့သို့သွားသောအခါရှေ့သို့သွားရန် (သို့မဟုတ်နောက်သို့နောက်သို့သွားလျှင်) နောက်ဆုံးလိုအပ်သော edge သည် node တစ်ခုအတွင်းသို့မဟုတ်အောက်ရှိညာဘက်အရွက် edge ကိုပြန်ပို့ပေးသည်။
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// မြင့်တက်သောသော့များအရွက် node များနှင့် internal KVs များသို့လည်ပတ်သည်။ အတွင်းပိုင်း node များတစ်ခုလုံးသည် KVs များနှင့်သူတို့၏ကလေး node များမတိုင်မီအတွင်းနက်ရှိုင်းသောပထမအကြိမ်အတွင်းအတွင်းပိုင်း node များသို့လည်းလည်ပတ်သည်။
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// (sub) tree ထဲမှာ element အရေအတွက်ကိုတွက်ချက်သည်။
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// ရှေ့သို့သွားရန်အတွက် K0 နှင့်အနီးဆုံး edge အရွက်ကိုပြန်ပို့သည်။
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// နောက်ပြန်လမ်းညွှန်မှုအတွက် KV နှင့်အနီးဆုံး edge အရွက်ကိုပြန်ပို့သည်။
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}