//! Single-ချည်ရည်ညွှန်း-ရေတွက်ထောက်ပြ။'Rc' သည် 'ရည်ညွှန်းချက်' ကိုဆိုလိုသည်
//! Counted'.
//!
//! [`Rc<T>`][`Rc`] အမျိုးအစားသည်အမှိုက်ပုံတွင်ခွဲဝေထားသော `T` အမျိုးအစားတန်ဖိုးခွဲဝေပိုင်ဆိုင်မှုကိုထောက်ပံ့ပေးသည်။
//! [`Rc`] တွင် [`clone`][clone] ကိုအသုံးပြုခြင်းသည်အမှိုက်ပုံထဲရှိတူညီသောခွဲဝေမှုအတွက် pointer အသစ်တစ်ခုကိုထုတ်လုပ်သည်။
//! ပေးထားသောခွဲဝေခြင်းအတွက်နောက်ဆုံး [`Rc`] ညွှန်ကိန်းဖျက်ဆီးခံရသောအခါ၎င်းခွဲဝေတွင်သိမ်းဆည်းထားသောတန်ဖိုး (များသောအားဖြင့် "inner value" ဟုရည်ညွှန်း) လည်းကျဆင်းသွားသည်။
//!
//! Rust ရှိမျှဝေထားသောကိုးကားချက်များသည်ပုံမှန်အားဖြင့် mutation ကိုတားမြစ်သည်။ [`Rc`] သည်ခြွင်းချက်မဟုတ်ပါ။ သင်သည်ယေဘုယျအားဖြင့် [`Rc`] အတွင်းရှိတစ်ခုခုအတွက်ပြောင်းလဲနိုင်သောရည်ညွှန်းချက်ကိုမရနိုင်ပါ။
//! သင်ပြောင်းလဲလိုသည်ဆိုပါက [`Cell`] သို့မဟုတ် [`RefCell`] ကို [`Rc`] အတွင်း၌ထားပါ။[an example of mutability inside an `Rc`][mutability] ကိုကြည့်ပါ။
//!
//! [`Rc`] Non-atomic reference counting ကိုသုံးတယ်။
//! ဆိုလိုသည်မှာ overhead သည်အလွန်နိမ့်သော်လည်း [`Rc`] တစ်ခုသည် Thread များအကြားမပို့နိူင်သောကြောင့် X0 [`Rc`][`Send`][send] ကိုအကောင်အထည်မဖော်နိုင်ပါ။
//! ရလဒ်အနေနှင့် Rust compiler သည်သင် ``Rc` s များပို့ခြင်းမပြုသည်ကို *compile အချိန်တွင်* စစ်ဆေးလိမ့်မည်။
//! သငျသညျ Multi-threaded, အနုမြူဗုံးရည်ညွှန်းရေတွက်လိုအပ်လျှင်, [`sync::Arc`][arc] ကိုသုံးပါ။
//!
//! [`downgrade`][downgrade] နည်းလမ်းသည်ပိုင်ဆိုင်မှုမရှိသော [`Weak`] pointer ကိုဖန်တီးရန်အသုံးပြုနိုင်သည်။
//! [`Weak`] pointer သည် [`upgrade`][upgrade] d ကို [`Rc`] သို့ဖြစ်စေနိုင်သည်။ အကယ်၍ ခွဲဝေထားသည့်သိုလှောင်ထားသောတန်ဖိုးကိုကျဆင်းသွားပါက၎င်းသည် [`None`] ကိုပြန်ပေးလိမ့်မည်။
//! တနည်းအားဖြင့် `Weak` ထောက်ပြသူများသည်ခွဲဝေချထားမှုအတွင်းရှိတန်ဖိုးကိုအသက်မရှင်နိုင်ကြပါ။သို့သော်သူတို့သည်ခွဲဝေခြင်း (အတွင်းတန်ဖိုးအတွက်ကျောထောက်နောက်ခံပြုထားသောစတိုးဆိုင်) ကိုရှင်သန်နေစေသည်။
//!
//! [`Rc`] ထောက်ပြသူများအကြားသံသရာတစ်ခုကိုဘယ်တော့မှဖယ်ရှား။ မရပါ။
//! ဤအကြောင်းကြောင့်, [`Weak`] သံသရာကိုချိုးဖျက်ဖို့အသုံးပြုသည်။
//! ဥပမာအားဖြင့်သစ်ပင်တစ်ပင်တွင်မိဘဆုံမှတ်များမှကလေးများအထိခိုင်မာသည့် [`Rc`] ညွှန်ပြချက်များနှင့်ကလေးများမှ [`Weak`] အမှတ်အသားများရှိနိုင်သည်။
//!
//! `Rc<T>` X0 `T`([`Deref`] trait မှတဆင့်) ကိုအလိုအလျောက် dereferences, သို့ဖြစ်လျှင်သင်သည် T00's method ကို type [`Rc<T>`][`Rc`] တန်ဖိုးဖြင့်ခေါ်နိုင်သည်။
//! `T` ၏နည်းနာများနှင့်အမည်တိုက်မှုဖြစ်ပွားခြင်းမှရှောင်ရှားရန်၊ [`Rc<T>`][`Rc`] ၏နည်းလမ်းများသည်ဆက်နွယ်နေသောလုပ်ဆောင်မှုများဖြစ်သည်။ [fully qualified syntax] ကိုသုံးသည်။
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>`Clone` ကဲ့သို့`traits ၏အကောင်အထည်ဖော်မှုများကိုအပြည့်အဝအရည်အချင်းပြည့်မီသော syntax သုံး၍ ခေါ်နိုင်သည်။
//! အချို့လူများကအပြည့်အဝအရည်အချင်းပြည့်မီသော syntax ကိုသုံးရန်ပိုနှစ်သက်ကြပြီးအချို့ကမူ method-call syntax ကိုပိုနှစ်သက်ကြသည်။
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Method ကို-ခေါ်ဆိုခ syntax
//! let rc2 = rc.clone();
//! // အပြည့်အဝအရည်အချင်းပြည့် syntax
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] အတွင်းတန်ဖိုးကိုပြီးသားကျဆင်းသွားခဲ့ကြပေမည်ဖြစ်သောကြောင့်, `T` မှ auto-dereference မထားဘူး။
//!
//! # ကိုးကားပွားခြင်း
//!
//! ရှိပြီးသားရည်ညွှန်းရေတွက် pointer ကဲ့သို့တူညီသောခွဲဝေမှုကိုရည်ညွှန်းအသစ်တစ်ခုကိုဖန်တီးရန် [`Rc<T>`][`Rc`] နှင့် [`Weak<T>`][`Weak`] အတွက်အကောင်အထည်ဖော်ခဲ့သော `Clone` trait ကိုအသုံးပြုသည်။
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // အောက်က syntaxes နှစ်ခုဟာညီမျှတယ်။
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a နှင့် b နှစ်ခုစလုံးသည် foo ကဲ့သို့မှတ်ဉာဏ်တည်နေရာကိုညွှန်ပြသည်။
//! ```
//!
//! `Rc::clone(&from)` syntax သည်အသုံးအများဆုံးဖြစ်သည်။ အဘယ်ကြောင့်ဆိုသော်၎င်းသည်ကုဒ်၏အဓိပ္ပာယ်ကိုပိုမိုရှင်းလင်းစွာဖော်ပြသည်။
//! အပေါ်ကဥပမာမှာ၊ ဒီ syntax သည်ဒီကုဒ်သည် foo အကြောင်းအရာတစ်ခုလုံးကိုကူးယူခြင်းထက်ရည်ညွှန်းချက်အသစ်တစ်ခုဖန်တီးနေသည်ကိုပိုမိုလွယ်ကူစေသည်။
//!
//! # Examples
//!
//! `Gadget`s အစုကိုပေးထားသော `Owner` ကပိုင်ဆိုင်သည့်မြင်ကွင်းကိုသုံးသပ်ကြည့်ပါ။
//! ကျွန်တော်တို့ရဲ့ `Gadget`s point ကိုသူတို့ `Owner` ကိုလိုချင်သည်။ထူးခြားသောပိုင်ဆိုင်မှုဖြင့်ကျွန်ုပ်တို့မလုပ်နိုင်ပါ၊ အကြောင်းမှာ gadget တစ်ခုသည် `Owner` တစ်ခုတည်းနှင့်သက်ဆိုင်သောကြောင့်ဖြစ်သည်။
//! [`Rc`] ကျွန်တော်တို့ကို ``Gadget`s များ between အကြားရှိ `Owner` ကိုမျှဝေရန်ခွင့်ပြုထားပြီး `Owner` သည်မည်သည့် `Gadget` အချက်များမဆိုရှိနေသမျှကာလပတ်လုံးခွဲဝေသတ်မှတ်ထားခွင့်ရှိသည်။
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... အခြားလယ်ကွင်း
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... အခြားလယ်ကွင်း
//! }
//!
//! fn main() {
//!     // ရည်ညွှန်းရေတွက်ထားသော `Owner` ကိုဖန်တီးပါ။
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // `Gadget`s `gadget_owner` ကိုဖန်တီးပါ။
//!     // အဆိုပါ `Rc<Owner>` ကို Cloning ကျွန်တော်တို့ကိုလုပ်ငန်းစဉ်များတွင်ရည်ညွှန်းအရေအတွက်တိုးမြှင့်အတူတူ `Owner` ခွဲဝေဖို့ pointer အသစ်တစ်ခုကိုပေးသည်။
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // ကျွန်တော်တို့ရဲ့ဒေသခံ variable ကို `gadget_owner` ၏ဖယ်ရှားပါ။
//!     drop(gadget_owner);
//!
//!     // `gadget_owner` ကျဆင်းသွားသော်လည်း `Gadget`s ၏ `Owner` ၏အမည်ကိုကျွန်ုပ်တို့ပုံနှိပ်ထုတ်ဝေနိုင်သေးသည်။
//!     // ဘာလို့လဲဆိုတော့ကျွန်တော်တို့ဟာ `Rc<Owner>` တစ်ခုတည်းကိုပဲကျဆင်းသွားတာမဟုတ်ဘဲဒါကိုထောက်ပြခဲ့တဲ့ `Owner` ကိုသာကျဆင်းစေလို့ပဲ
//!     // နေသမျှကာလပတ်လုံး `Owner` ခွဲဝေမှုမှာအခြား `Rc<Owner>` ညွှန်ပြနေသမျှကာလပတ်လုံး၊
//!     // `Rc<Owner>` သည် `Owner` ကိုအလိုအလျောက် dereferences ဖြစ်သောကြောင့် field projection `gadget1.owner.name` သည်အလုပ်လုပ်သည်။
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // လုပ်ဆောင်ချက်အဆုံးမှာ `gadget1` နှင့် `gadget2` ဖျက်ဆီးခံရပြီးသူတို့နှင့်အတူကျွန်ုပ်တို့၏ `Owner` ၏နောက်ဆုံးရေတွက်ညွှန်းကိန်းများရှိသည်။
//!     // Gadget Man ကိုအခုလည်းဖျက်ဆီးပစ်လိုက်ပြီ။
//!     //
//! }
//! ```
//!
//! ကျွန်ုပ်တို့၏လိုအပ်ချက်များပြောင်းလဲပြီး၊ ကျွန်ုပ်တို့သည်လည်း `Owner` မှ `Gadget` သို့လမ်းကြောင်းပြောင်းရန်လိုအပ်ပါကကျွန်ုပ်တို့သည်ပြproblemsနာများပေါ်ပေါက်လိမ့်မည်။
//! `Owner` မှ `Gadget` သို့ [`Rc`] pointer တစ်ခုသံသရာကိုစတင်ခဲ့သည်။
//! ဆိုလိုသည်မှာ ၄ င်းတို့၏ရည်ညွှန်းအရေအတွက်သည် 0 သို့မရောက်နိုင်ပါ။
//! မှတ်ဥာဏ်ယိုစိမ့်မှု။ဒါကိုကျော်လွှားနိုင်ရန် [`Weak`] pointers ကိုသုံးနိုင်သည်။
//!
//! Rust သည်၎င်းကိုကွင်းဆက်ထုတ်လုပ်ရန်အတန်ငယ်ခက်ခဲစေသည်။တစ် ဦး နှင့်တစ် ဦး ထောက်ပြသည့်တန်ဖိုးနှစ်ခုနှင့်အဆုံးသတ်နိုင်ရန်၎င်းတို့ထဲမှတစ်ခုသည် mutable ဖြစ်ရန်လိုအပ်သည်။
//! ၎င်းသည်ခက်ခဲသည်၊ အဘယ်ကြောင့်ဆိုသော် [`Rc`] သည်ထုပ်ထားသောတန်ဖိုးနှင့် ပတ်သက်၍ မျှဝေထားသောကိုးကားချက်များကိုသာပေးခြင်းဖြင့်မှတ်ဉာဏ်လုံခြုံမှုကိုပြenfor္ဌာန်းပေးသည်၊ ၎င်းကတိုက်ရိုက် mutation ကိုခွင့်မပြုပါ
//! ကျွန်ုပ်တို့ mutate လုပ်လိုသောတန်ဖိုး၏အစိတ်အပိုင်းကို [`RefCell`] တွင်ခြုံငုံ။ လိုအပ်သည်။ ၎င်းသည်အတွင်းပိုင်း mutability * ကိုမျှဝေထားသောရည်ညွှန်းချက်မှတစ်ဆင့် mutability ရရှိရန်နည်းလမ်းဖြစ်သည်။
//! [`RefCell`] runtime မှာ Rust ရဲ့ချေးငွေစည်းမျဉ်းများကိုပြ္ဌာန်းပေးသည်။
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... အခြားလယ်ကွင်း
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... အခြားလယ်ကွင်း
//! }
//!
//! fn main() {
//!     // ရည်ညွှန်းရေတွက်ထားသော `Owner` ကိုဖန်တီးပါ။
//!     // သတိပြုရန်မှာ `Owner` ၏ vector of`Gadget`s ကို `RefCell` ထဲ၌ထည့်ပြီး၎င်းသည်မျှဝေထားသောရည်ညွှန်းချက်မှတစ်ဆင့်ပြောင်းလဲနိုင်သည်။
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // အရင်တုန်းကလုပ်ခဲ့တဲ့ `Gadget`s `gadget_owner` ကိုဖန်တီးပါ။
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // `Gadget`s 'ကိုသူတို့ရဲ့ `Owner` ထဲသို့ထည့်ပါ။
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` ပြောင်းလဲနေသောချေးငွေသည်ဤနေရာတွင်အဆုံးသတ်သည်။
//!     }
//!
//!     // ကျွန်ုပ်တို့၏ `Gadget`s ကို ဖြတ်၍ သူတို့၏အသေးစိတ်အချက်အလက်များကိုပုံနှိပ်ထုတ်ပါ။
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` တစ် `Weak<Gadget>` ဖြစ်ပါတယ်။
//!         // `Weak` ထောက်ပြသူများသည်ခွဲဝေချထားပေးခြင်းများကိုအာမခံနိုင်ခြင်းမရှိသေးသောကြောင့်ကျွန်ုပ်တို့သည် `upgrade` ကိုပြန်ခေါ်သည့် `upgrade` ကိုခေါ်ရန်လိုအပ်သည်။
//!         //
//!         //
//!         // ဤကိစ္စတွင်ကျွန်ုပ်တို့သည်ခွဲဝေမှုရှိနေသေးသည်ကိုသိသောကြောင့်ကျွန်ုပ်တို့သည် `unwrap` ကိုရိုးရှင်းစွာ `unwrap` ပေးသည်။
//!         // ပိုမိုရှုပ်ထွေးသောပရိုဂရမ်တစ်ခုအနေနှင့်သင်သည် `None` ရလဒ်အတွက်လျောက်ပတ်သောအမှားကိုင်တွယ်ခြင်းကိုလိုအပ်လိမ့်မည်။
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // လုပ်ဆောင်ချက်အဆုံးမှာ `gadget_owner`, `gadget1` နှင့် `gadget2` ဖျက်ဆီးခံရသည်။
//!     // အခု gadget တွေအတွက်အားကောင်းသော (`Rc`) pointers တွေမရှိတော့ဘူး။
//!     // ဤသည် Gadget က Man အပေါ်ရည်ညွှန်းရေတွက်သုည, ဒါကြောင့်သူလည်းအဖြစ်ကောင်းစွာဖျက်ဆီးခံရတယ်။
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// ဤသည် repr(C) မှ future-proof ဖြစ်၍ ဖြစ်နိုင်သည့် field-reordering ကိုဆန့်ကျင်။ transmutable အတွင်းပိုင်းအမျိုးအစားများ၏ဘေးကင်းလုံခြုံသည့် [into|from]_raw() ကို ၀ င်ရောက်စွက်ဖက်နိုင်သည်။
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// တစ် ဦး က Single-threaded ရည်ညွှန်း-ရေတွက် pointer ။'Rc' သည် 'ရည်ညွှန်းချက်' ကိုဆိုလိုသည်
/// Counted'.
///
/// အသေးစိတ်အတွက် [module-level documentation](./index.html) ကိုကြည့်ပါ။
///
/// `Rc` ၏မူလရင်းမြစ်နည်းလမ်းများအားလုံးသည်ဆက်နွယ်နေသောလုပ်ဆောင်ချက်များဖြစ်သည်။ ဆိုလိုသည်မှာသင်သည် `value.get_mut()` အစား [`Rc::get_mut(&mut value)`][get_mut] ဟုခေါ်သည်။
/// ၎င်းသည် `T` အတွင်းပိုင်းအမျိုးအစားများနှင့်ပconflictsိပက္ခများကိုရှောင်ရှားနိုင်သည်။
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // ဤ Rc သည်အသက်ရှင်နေစဉ်အတွင်းတွင် pointer သည်မှန်ကန်ကြောင်းအာမခံပါသည်။
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// အသစ်တစ်ခုကို `Rc<T>` တည်ဆောက်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // အားကောင်းသော pointers အားလုံးကပိုင်ဆိုင်ထားတဲ့သွယ်ဝိုက်အားနည်းသော pointer တစ်ခုရှိသည်။ အားနည်းသော pointer အားအားကြီးသောအတွင်း၌သိမ်းဆည်းထားလျှင်ပင်အားကြီးသော destructor လည်ပတ်နေစဉ်အားနည်းသောဖျက်ဆီးခြင်းသည်ခွဲဝေချထားခြင်းကိုဘယ်တော့မှမလွတ်မြောက်စေရန်သေချာစေသည်။
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// သူ့ဟာသူအားနည်းရည်ညွှန်းသုံးပြီး `Rc<T>` အသစ်တစ်ခုကိုတည်ဆောက်သည်။
    /// အားနည်းသောရည်ညွှန်းကိုဤ function ပြန်မရောက်မီအဆင့်မြှင့်တင်ရန်ကြိုးစားခြင်းသည် `None` တန်ဖိုးရရှိလိမ့်မည်။
    ///
    /// သို့သော်အားနည်းသောရည်ညွှန်းချက်ကိုလွတ်လပ်စွာပုံတူကူးယူပြီးနောက်ပိုင်းတွင်အသုံးပြုရန်သိမ်းဆည်းထားနိုင်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... ပိုပြီးလယ်
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // အတွင်းပိုင်းတစ်ခုအားအားနည်းသောရည်ညွှန်းမှုတစ်ခုဖြင့်တည်ဆောက်ပါ။
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // အားနည်းသော pointer ၏ပိုင်ဆိုင်မှုကိုကျွန်ုပ်တို့မစွန့်လွှတ်ရန်အရေးကြီးသည်၊ သို့မဟုတ်ပါက `data_fn` ပြန်လာသည့်အချိန်တွင်ပင်မှတ်ဉာဏ်အားလွတ်မြောက်စေနိုင်သည်။
        // အကယ်၍ ကျွန်ုပ်တို့သည်ပိုင်ဆိုင်မှုကိုအမှန်တကယ်ပိုင်ဆိုင်လိုပါကမိမိကိုယ်ကိုအပိုဆောင်းအားနည်းသောညွှန်ကိန်းတစ်ခုဖန်တီးနိုင်သည်၊ သို့သော်၎င်းသည်အားနည်းနေသောရည်ညွှန်းအရေအတွက်အတွက်နောက်ထပ်မွမ်းမံမှုများဖြစ်ပေါ်စေလိမ့်မည်၊
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // အားကောင်းသောရည်ညွှန်းချက်များသည်စုပေါင်းအားနည်းသောကိုးကားထားသောရည်ညွှန်းချက်တစ်ခုတည်းကိုပိုင်ဆိုင်သင့်သည်။ ထို့ကြောင့်ကျွန်ုပ်တို့၏အားနည်းသောရည်ညွှန်းမှုဟောင်းအတွက်ဖျက်ဆီးခြင်းကိုမ run ပါနှင့်
        //
        mem::forget(weak);
        strong
    }

    /// uninitialized contents တွေကိုနှင့်အတူအသစ်တစ်ခုကို `Rc` တည်ဆောက်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // ရွှေ့ဆိုင်းခြင်းစတင်ခြင်း
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// မှတ်ဉာဏ်သည် `0` bytes နှင့်ပြည့်နှက်လျက် Xinx အသစ်တစ်ခုကို uninitialized contents များဖြင့်တည်ဆောက်သည်။
    ///
    ///
    /// ဤနည်းလမ်း၏မှန်ကန်သောနှင့်မမှန်ကန်သောအသုံးပြုမှုဥပမာများအတွက် [`MaybeUninit::zeroed`][zeroed] ကိုကြည့်ပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// ခွဲဝေမှုပျက်ကွက်လျှင်အမှားတစ်ခုပြန်လာသည့် `Rc<T>` အသစ်တစ်ခုကိုတည်ဆောက်သည်
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // အားကောင်းသော pointers အားလုံးကပိုင်ဆိုင်ထားတဲ့သွယ်ဝိုက်အားနည်းသော pointer တစ်ခုရှိသည်။ အားနည်းသော pointer အားအားကြီးသောအတွင်း၌သိမ်းဆည်းထားလျှင်ပင်အားကြီးသော destructor လည်ပတ်နေစဉ်အားနည်းသောဖျက်ဆီးခြင်းသည်ခွဲဝေချထားခြင်းကိုဘယ်တော့မှမလွတ်မြောက်စေရန်သေချာစေသည်။
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// ခွဲဝေမှုပျက်ကွက်လျှင်အမှားတစ်ခုပြန်လာ, uninitialized အကြောင်းအရာများနှင့်အတူအသစ်တစ်ခုကို `Rc` တည်ဆောက်သည်
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // ရွှေ့ဆိုင်းခြင်းစတင်ခြင်း
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// မှတ်ဉာဏ်သည် `0` bytes နှင့်ပြည့်နေပြီးခွဲဝေချထားမှုမအောင်မြင်ပါကအမှားတစ်ခုပြနေသည်။
    ///
    ///
    /// ဤနည်းလမ်း၏မှန်ကန်သောနှင့်မမှန်ကန်သောအသုံးပြုမှုဥပမာများအတွက် [`MaybeUninit::zeroed`][zeroed] ကိုကြည့်ပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// အသစ်တစ်ခုကို `Pin<Rc<T>>` တည်ဆောက်။
    /// အကယ်၍ `T` က `Unpin` ကိုအကောင်အထည်မဖော်ပါက၊ `value` သည်မှတ်ဉာဏ်ထဲ၌ရှိနေပြီးရွေ့ပြောင်း။ မရပါ။
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// အကယ်၍ `Rc` တွင်အားကောင်းသောရည်ညွှန်းချက်တစ်ခုရှိခဲ့လျှင်အတွင်းတန်ဖိုးကိုပြန်သွားသည်။
    ///
    /// ဒီလိုမှမဟုတ်ရင် [`Err`] ကိုပြန်ပို့လိုက်တဲ့ `Rc` အတူတူပဲ။
    ///
    ///
    /// ညံ့ဖျင်းသောအားနည်းသောရည်ညွှန်းချက်များရှိသည့်တိုင်၎င်းသည်အောင်မြင်လိမ့်မည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // ပါရှိသောအရာဝတ္ထုကိုကူးယူပါ

                // အားနည်းချက်ကိုလျှော့ချခြင်းအားဖြင့်ရာထူးတိုးမြှင့ ်၍ မရနိုင်ကြောင်း Weaks သို့ညွှန်ပြပါ။ ထို့နောက်အားနည်းချက်အတုတစ်ခုဖန်တီးရုံဖြင့် drop logic ကိုကိုင်တွယ်နေစဉ်သွယ်ဝိုက် "strong weak" pointer ကိုဖယ်ရှားပါ။
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// uninitialized contents တွေကိုအသစ်တစ်ခုကိုရည်ညွှန်းရေတွက်အချပ်တည်ဆောက်ခြင်း။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // ရွှေ့ဆိုင်းခြင်းစတင်ခြင်း
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// memory ကို `0` bytes ဖြင့်ပြည့်နှက်နေသည်နှင့်အတူ uninitialized contents တွေကိုအသစ်ရည်ညွှန်းရေတွက်အချပ်, တည်ဆောက်သည်။
    ///
    ///
    /// ဤနည်းလမ်း၏မှန်ကန်သောနှင့်မမှန်ကန်သောအသုံးပြုမှုဥပမာများအတွက် [`MaybeUninit::zeroed`][zeroed] ကိုကြည့်ပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// `Rc<T>` သို့ပြောင်းသည်
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] ကဲ့သို့ပင်အတွင်းတန်ဖိုးသည်ပကတိအခြေအနေ၌ရှိကြောင်းအာမခံရန်ခေါ်ဆိုသူအပေါ်မူတည်သည်။
    ///
    /// အကြောင်းအရာကိုအပြည့်အဝအစပြုခြင်းမရှိသေးသောအချိန်တွင်ဤအရာကိုခေါ်ဆိုခြင်းအားချက်ချင်းသတ်မှတ်ထားသောအပြုအမူကိုဖြစ်ပေါ်စေသည်။
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // ရွှေ့ဆိုင်းခြင်းစတင်ခြင်း
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// `Rc<[T]>` သို့ပြောင်းသည်
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] ကဲ့သို့ပင်အတွင်းတန်ဖိုးသည်ပကတိအခြေအနေ၌ရှိကြောင်းအာမခံရန်ခေါ်ဆိုသူအပေါ်မူတည်သည်။
    ///
    /// အကြောင်းအရာကိုအပြည့်အဝအစပြုခြင်းမရှိသေးသောအချိန်တွင်ဤအရာကိုခေါ်ဆိုခြင်းအားချက်ချင်းသတ်မှတ်ထားသောအပြုအမူကိုဖြစ်ပေါ်စေသည်။
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // ရွှေ့ဆိုင်းခြင်းစတင်ခြင်း
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// `Rc` ကိုအသုံးပြုသည်။
    ///
    /// မှတ်ဥာဏ်ယိုစိမ့်မှုမဖြစ်စေရန် pointer ကို [`Rc::from_raw`][from_raw] သုံး၍ `Rc` သို့ပြန်ပြောင်းရမည်။
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// ဒေတာတစ်ခု raw pointer ပေးသည်။
    ///
    /// ရေတွက်ခြင်းကိုမည်သည့်နည်းနှင့်မျှမထိခိုက်ပါ၊ `Rc` ကိုမစားပါ။
    /// `Rc` တွင်ခိုင်မာသောအရေအတွက်ရှိသရွေ့ pointer သည်တရားဝင်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // လုံခြုံမှု-ဤသည်မှာ Deref::deref သို့မဟုတ် Rc::inner ကို ဖြတ်၍ မသွားနိုင်ပါ
        // ဤကဲ့သို့သောဥပမာသည် raw/mut သက်သေပြမှုကိုထိန်းသိမ်းရန်လိုအပ်သည်
        // `get_mut` အဆိုပါ Rc `from_raw` မှတဆင့်ပြန်လည်ကောင်းမွန်ပြီးနောက် pointer မှတဆင့်ရေးသားနိုင်ပါတယ်။
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// pointer တစ်ခုမှ `Rc<T>` တစ်ခုတည်ဆောက်သည်။
    ///
    /// `U` သည် `T` ကဲ့သို့တူညီသောအရွယ်အစားနှင့်ညှိနှိုင်းမှုရှိရမည်။
    /// `U` `T` ဖြစ်ပါကဤအချက်သည်အသေးအဖွဲဖြစ်သည်။
    /// အကယ်၍ `U` သည် `T` မဟုတ်သော်လည်းအရွယ်အစားနှင့်တူညီစွာရှိလျှင်၎င်းသည်အခြေခံအားဖြင့်မတူကွဲပြားသောအမျိုးအစားများကိုကိုးကားခြင်းနှင့်တူသည်ကိုသတိပြုပါ။
    /// ဤကိစ္စတွင်မည်သည့်ကန့်သတ်ချက်များနှင့်သက်ဆိုင်သည်ကိုပိုမိုသိရှိလိုပါက [`mem::transmute`][transmute] တွင်ကြည့်ပါ။
    ///
    /// `from_raw` ၏အသုံးပြုသူသည် `T` ၏သတ်သတ်မှတ်မှတ်တန်ဖိုးတစ်ချိန်ကကျဆင်းသွားသည်ကိုသေချာအောင်ပြုလုပ်ရမည်။
    ///
    /// အဘယ်ကြောင့်ဆိုသော်မသင့်လျော်သောအသုံးပြုမှုသည်ပြန်လာသော `Rc<T>` သည်ဘယ်သောအခါမျှ ၀ င်ရောက်ခြင်းမရှိသော်လည်း၊
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // ယိုစိမ့်မှုကိုကာကွယ်ရန် `Rc` သို့ပြန်ပြောင်းပါ။
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Rc::from_raw(x_ptr)` သို့နောက်ထပ်ဖုန်းခေါ်ဆိုမှုများသည်မှတ်ဉာဏ်မကင်းပါ။
    /// }
    ///
    /// // အထက်တွင်ဖော်ပြထားသောအတိုင်း `x` ထွက်သွားသည့်အခါမှတ်ဥာဏ်သည်လွတ်မြောက်သွားပြီဖြစ်ရာယခုအခါ `x_ptr` သည် dangling!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // မူလ RcBox ကိုရှာရန် offset ကိုပြောင်းပါ။
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// ဒီခွဲဝေမှုမှအသစ်တစ်ခုကို [`Weak`] pointer ကိုဖန်တီးပေးပါတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // ကျွန်တော်တို့ဟာ dangling အားနည်းချက်ကိုမဖန်တီးဘူးသေချာအောင်လုပ်ပါ
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// ဒီခွဲဝေမှုမှ [`Weak`] ထောက်ပြ၏နံပါတ်ရရှိသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// ဒီခွဲဝေရန်ခိုင်မာတဲ့ (`Rc`) ထောက်ပြ၏နံပါတ်ရရှိသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// ဒီခွဲဝေခြင်းမရှိပါအခြား `Rc` သို့မဟုတ် [`Weak`] ထောက်ပြရှိပါတယ်လျှင် `true` သို့ပြန်သွားသည်။
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// တူညီသောခွဲဝေရန်မပါအခြား `Rc` သို့မဟုတ် [`Weak`] ထောက်ပြသူများမရှိပါကပေးထားသော `Rc` သို့ပြောင်းလဲနိုင်သောရည်ညွှန်းချက်ကိုပြန်ပို့သည်။
    ///
    ///
    /// မဟုတ်ရင် [`None`] ကို return ပြန်ပေးတယ်။
    ///
    /// [`make_mut`][make_mut] ကိုလည်းကြည့်ပါ။ ၎င်းသည်အခြားအညွှန်းများရှိပါကအတွင်းတန်ဖိုးကို [`clone`][clone] ဖြစ်လိမ့်မည်။
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// မည်သည့်စစ်ဆေးမှုမှမပါဘဲပေးထားသော `Rc` သို့ပြောင်းလဲနိုင်သောရည်ညွှန်းချက်ကိုပြန်ပို့သည်။
    ///
    /// [`get_mut`] ကိုလည်းရှုပါ။
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// တူညီသောခွဲဝေဖို့အခြားမည်သည့် `Rc` သို့မဟုတ် [`Weak`] ထောက်ပြပြန်လာသောချေး၏ကြာချိန်အဘို့အ dereferenced မပြုရပါ။
    ///
    /// ဥပမာ-`Rc::new` ပြီးနောက်ချက်ချင်းဆိုလျှင်ထိုကဲ့သို့သောညွှန်ကြားချက်များမရှိပါကဤအချက်သည်အသေးအဖွဲကိစ္စဖြစ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // ကျွန်ုပ်တို့သည် "count" အကွက်များနှင့်သက်ဆိုင်သည့်ရည်ညွှန်းကိုးကားဖန်တီးခြင်းကိုမပြုလုပ်ရန်သတိထားသည်၊
        // `Weak` အားဖြင့်) ။
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// နှစ်ခု ``Rc`s အချက်သည် ([`ptr::eq`] နှင့်ဆင်တူသည့်သွေးပြန်ကြောတစ်ခု) တွင်တူညီသောခွဲဝေမှုကိုညွှန်ပြပါက `true` ကိုပြန်သွားသည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// ပေးထားသော `Rc` သို့ mutable ရည်ညွှန်းသည်။
    ///
    /// တူညီသောခွဲဝေမှုမှအခြား `Rc` ထောက်ပြရှိပါတယ်လျှင်, `make_mut` ထူးခြားသောပိုင်ဆိုင်မှုသေချာစေရန်အသစ်တစ်ခုကိုခွဲဝေဖို့အတွင်းပိုင်းတန်ဖိုး [`clone`] ပါလိမ့်မယ်။
    /// ၎င်းကို Clone-on-write အဖြစ်ရည်ညွှန်းသည်။
    ///
    /// ဒီခွဲဝေရန်အခြား `Rc` ထောက်ပြမရှိလျှင်, ဒီခွဲဝေဖို့ [`Weak`] ထောက်ပြ disassociated လိမ့်မည်။
    ///
    /// [`get_mut`] ကိုလည်းရှုပါ။
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // ဘာမှမကူးတော့ပါ
    /// let mut other_data = Rc::clone(&data);    // အတွင်းပိုင်းဒေတာကိုပုံတူပွား။ မရပါ
    /// *Rc::make_mut(&mut data) += 1;        // အတွင်းပိုင်းဒေတာ Clone
    /// *Rc::make_mut(&mut data) += 1;        // ဘာမှမကူးတော့ပါ
    /// *Rc::make_mut(&mut other_data) *= 2;  // ဘာမှမကူးတော့ပါ
    ///
    /// // ယခု `data` နှင့် `other_data` သည်ကွဲပြားသောခွဲဝေချထားမှုများကိုညွှန်ပြသည်။
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] ထောက်ပြ disassociated လိမ့်မည်
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // အခြား Rcs တွေရှိတယ်။
            // ပုံတူပွားထားသည့်တန်ဖိုးကိုတိုက်ရိုက်ရေးသားရန်အတွက်မှတ်ဉာဏ်ကိုကြိုတင်ခွဲထားပါ။
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // အချက်အလက်များကိုခိုးယူရုံသာမက၊
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // လုံးလုံးလျားလျားခိုင်မာအားနည်းသော ref ကိုဖယ်ရှားပါ (အားနည်းချက်အတုတစ်ခုကိုပြုလုပ်ရန်မလိုအပ်ပါ။ အခြားအားနည်းချက်များသည်ကျွန်ုပ်တို့အတွက်ရှင်းလင်းနိုင်ကြောင်းကျွန်ုပ်တို့သိပါသည်)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // ဤလုံခြုံမှုမရှိခြင်းသည်အဆင်ပြေပါသည်။ အဘယ်ကြောင့်ဆိုသော်ကျွန်ုပ်တို့ပြန်လာသည့် pointer သည် T. သို့ပြန်သွားပါမည်။
        // ကျွန်ုပ်တို့၏ရည်ညွှန်းအရေအတွက်သည်ယခုအချိန်တွင် ၁ ဖြစ်မည်ဟုအာမခံထားပြီး `Rc<T>` ကိုယ်နှိုက်က `mut` ဖြစ်ရန်လိုသည်၊ ထို့ကြောင့်ကျွန်ုပ်တို့သည်ခွဲဝေချထားပေးမှုအတွက်တစ်ခုတည်းသောရည်ညွှန်းကိုပြန်ပို့နေသည်။
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Rc<dyn Any>` ကိုကွန်ကရစ်အမျိုးအစားသို့လျှော့ချရန်ကြိုးစားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// `RcBox<T>` တစ်ခုသည်တန်ဖိုးကိုသတ်မှတ်ထားသည့်အတွင်းတန်ဖိုးအတွက်နေရာအလုံအလောက်ရှိရန်နေရာချသည်။
    ///
    /// `mem_to_rcbox` function ကို data pointer ဖြင့်ခေါ်။ `RcBox<T>` အတွက် (ဖြစ်နိုင်ခြေရှိသောအဆီ)-pointer ကိုပြန်ပေးရမည်။
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // ပေးထားတဲ့ value layout ကိုအသုံးပြုပြီး layout ကိုတွက်ချက်ပါ။
        // ယခင်က layout ကို `&*(ptr as* const RcBox<T>)` ဟူသောအသုံးအနှုနျးအတိုငျးတွက်ခဲ့တယျ၊
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// `RcBox<T>` တစ်ခုသည်တန်ဖိုးတစ်ခုစီမထားသည့်အတွင်းတန်ဖိုးအတွက်လုံလောက်သောနေရာရှိရန်နေရာချထားသည်။ ၎င်းသည်တန်ဖိုးအရစီစဉ်ထားသည့်နေရာရှိသည်။
    ///
    ///
    /// `mem_to_rcbox` function ကို data pointer ဖြင့်ခေါ်။ `RcBox<T>` အတွက် (ဖြစ်နိုင်ခြေရှိသောအဆီ)-pointer ကိုပြန်ပေးရမည်။
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // ပေးထားတဲ့ value layout ကိုအသုံးပြုပြီး layout ကိုတွက်ချက်ပါ။
        // ယခင်က layout ကို `&*(ptr as* const RcBox<T>)` ဟူသောအသုံးအနှုနျးအတိုငျးတွက်ခဲ့တယျ၊
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // အပြင်အဆင်အတွက်ခွဲဝေချထားပါ။
        let ptr = allocate(layout)?;

        // RcBox ကိုအစပြုပါ
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// တစ် ဦး unsized အတွင်းစိတ်တန်ဖိုးကိုများအတွက်လုံလောက်သောအာကာသနှင့်အတူတစ် ဦး `RcBox<T>` ချထားသည်
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // ပေးထားသောတန်ဖိုးကို အသုံးပြု၍ `RcBox<T>` အတွက်ခွဲဝေချထားပါ။
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // တန်ဖိုးကို bytes အဖြစ်ကူးယူပါ
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // ၎င်း၏ contents တွေကိုကျဆင်းနေစရာမလိုဘဲခွဲဝေချထားပေးရန်
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// ပေးထားသောအရှည်နှင့်အတူ `RcBox<[T]>` ခွဲဝေချထားပေးရန်။
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// အသစ်သောခွဲဝေထားသည့် RC သို့အချပ်မှ element များကိုကူးယူပါ
    ///
    /// အန္တရာယ်မကင်းသောကြောင့်ခေါ်ဆိုသူသည်ပိုင်ဆိုင်မှုကိုယူရသို့မဟုတ် `T: Copy` ကိုချည်ရမည်
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// အချို့သောအရွယ်အစားဟုလူသိများသောကြားမှာမှ `Rc<[T]>` တစ်ခုတည်ဆောက်သည်။
    ///
    /// အရွယ်အစားမှားယွင်းပါကအပြုအမူအားသတ်မှတ်ခြင်းမပြုပါ။
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // T ကိုဒြပ်စင်ပုံတူပွားစဉ် Panic ကိုယ်ရံတော်။
        // panic တစ်ခုဖြစ်ခဲ့လျှင် RcBox အသစ်ထဲသို့ရေးသွင်းလိုက်သောဒြပ်စင်များကိုဖယ်ထုတ်ပြီးမှတ်ဉာဏ်လွတ်သွားလိမ့်မည်။
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // ပထမ ဦး ဆုံးဒြပ်စင်မှညွှန်ပြ
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // အားလုံးရှင်းတယ်။RcBox အသစ်ကိုပြန်မလွတ်နိုင်အောင်ကိုယ်ရံတော်ကိုမမေ့ပါနှင့်။
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` အတွက်အထူးပြု trait အထူးပြု။
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// အဆိုပါ `Rc` drop ။
    ///
    /// ဤသည်အားကြီးသောရည်ညွှန်းအရေအတွက်လျှော့ချပါလိမ့်မယ်။
    /// အကယ်၍ အားကောင်းသောရည်ညွှန်းအရေအတွက်သည်သုညသို့ရောက်ရှိပါကအခြားသောရည်ညွှန်းချက်များ (ရှိခဲ့ပါက) သည် [`Weak`] ဖြစ်သည်၊ ထို့ကြောင့်ကျွန်ုပ်တို့သည်အတွင်းတန်ဖိုးကို `drop` ဖြစ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // ဘာမှမပုံနှိပ်ပါဘူး
    /// drop(foo2);   // "dropped!" ထုတ်
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // ပါရှိသောအရာဝတ္ထုကိုဖကျြဆီး
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // ပါ ၀ င်သောအရာများကိုဖျက်ဆီးပြီးပြီဖြစ်သော implicit "strong weak" pointer ကိုဖယ်ရှားလိုက်ပါ။
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// `Rc` pointer ၏ကိုယ်ပွားကိုပြုလုပ်သည်။
    ///
    /// ၎င်းသည်ရည်ညွှန်းမှုအရေအတွက်အားတိုးမြှင့်ခြင်းအားဖြင့်တူညီသောခွဲဝေမှုအတွက်အခြားသောညွန်ကိန်းကိုဖန်တီးပေးသည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// `T` အတွက် `Default` တန်ဖိုးရှိသည့် `Rc<T>` အသစ်တစ်ခုကိုဖန်တီးသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// `Eq` တွင်နည်းလမ်းရှိသော်လည်း `Eq` ကိုအထူးပြုခွင့်ပြုပါ။
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// ဒီမှာ `&T` ကိုယေဘူယျအားဖြင့်ပိုမိုကောင်းမွန်အောင်လုပ်ခြင်းမဟုတ်ဘဲဒီအထူးပြုကိုလုပ်နေခြင်းဖြစ်သည်။ ဘာဖြစ်လို့လဲဆိုတော့ refs အပေါ်တန်းတူညီမျှမှုစစ်ဆေးခြင်းအတွက်ကုန်ကျစရိတ်ကိုထပ်ပေါင်းပေးလို့ပဲ။
/// ``Rc`s များသည်ကြီးမားသောတန်ဖိုးများကိုသိုလှောင်ရန်အသုံးပြုသည်၊ ၎င်းသည်ပုံတူပွားရန်နှေးကွေးသော်လည်း၊ တန်းတူညီမျှမှုရှိမရှိစစ်ဆေးရန်အလွန်လေးသောကြောင့်၎င်းကုန်ကျစရိတ်ကိုပိုမိုလွယ်ကူစွာပေးဆပ်နိုင်သည်။
///
/// ထို့အပြင် `&T`s နှစ်ခုထက်ပိုမိုသော `Rc` Clone နှစ်ခုရှိသည်။
///
/// `PartialEq` တစ်ခုအနေဖြင့် `T: Eq` သည်တမင်တကာတုံ့ပြန်မှုမရှိသောအခါကျွန်ုပ်တို့ဤသို့ပြုလုပ်နိုင်သည်။
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// နှစ်ခု `Rc`s အတွက်တန်းတူရေး။
    ///
    /// Rc`s နှစ်ခုသည်သူတို့၏အတွင်းပိုင်းတန်ဖိုးများကိုညီမျှလျှင် ၄ င်းတို့သည်မတူညီသောခွဲဝေထားသည့်သိုတွင်အတူတူပင်ဖြစ်သည်။
    ///
    /// အကယ်၍ `T` သည် `Eq` (ညီမျှခြင်း၏ရောင်ပြန်ဟပ်မှုကိုဆိုလိုခြင်း) ကိုအသုံးပြုပါက ```` ```` ```` ```` `အချင်းလူ၊
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// နှစ်ခု `Rc`s မညီမျှမှု။
    ///
    /// သူတို့ရဲ့အတွင်းပိုင်းတန်ဖိုးများမညီမျှမှုရှိလျှင် ``Rc`s နှစ်ခုမညီမျှပါ။
    ///
    /// အကယ်၍ `T` သည် `Eq` (ညီမျှခြင်း၏ရောင်ပြန်ဟပ်မှုကိုဆိုလိုခြင်း) ကိုအကောင်အထည်ဖော်ပါက ```` ```` ```` ```` `` `
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// နှစ်ခု `Rc`s များအတွက်တစ်စိတ်တစ်ပိုင်းနှိုင်းယှဉ်။
    ///
    /// နှစ်ခုကိုသူတို့၏အတွင်းတန်ဖိုးများကို `partial_cmp()` ဖြင့်ခေါ်ခြင်းဖြင့်နှိုင်းယှဉ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// နှစ်ခု `Rc`s နှိုင်းယှဉ်နည်းသည်။
    ///
    /// နှစ်ခုကိုသူတို့၏အတွင်းတန်ဖိုးများကို `<` ဖြင့်ခေါ်ခြင်းဖြင့်နှိုင်းယှဉ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Rc`s နှစ်ခုအတွက်နှိုင်းယှဉ်မှုကနည်းသည်သို့မဟုတ်ညီမျှသည်။
    ///
    /// နှစ်ခုကိုသူတို့၏အတွင်းတန်ဖိုးများကို `<=` ဖြင့်ခေါ်ခြင်းဖြင့်နှိုင်းယှဉ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Rc`s နှစ်ခုအတွက်နှိုင်းယှဉ်ခြင်းက ပို၍ ကြီးသည်။
    ///
    /// နှစ်ခုကိုသူတို့၏အတွင်းတန်ဖိုးများကို `>` ဖြင့်ခေါ်ခြင်းဖြင့်နှိုင်းယှဉ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// Rc`s နှစ်ခုနှင့်နှိုင်းယှဉ်လျှင် ပို၍ ကြီးသည်သို့မဟုတ်ညီမျှသည်။
    ///
    /// နှစ်ခုကိုသူတို့၏အတွင်းတန်ဖိုးများကို `>=` ဖြင့်ခေါ်ခြင်းဖြင့်နှိုင်းယှဉ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// နှစ်ခု `Rc`s များအတွက်နှိုင်းယှဉ်။
    ///
    /// နှစ်ခုကိုသူတို့၏အတွင်းတန်ဖိုးများကို `cmp()` ဖြင့်ခေါ်ခြင်းဖြင့်နှိုင်းယှဉ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// ရည်ညွှန်းထားသောအချပ်ကိုခွဲဝေချပြီး `v` ၏ပစ္စည်းများကိုပုံတူပွားပါ။
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// ရည်ညွှန်းရေတွက်ထားသော string slice ကိုခွဲဝေချပြီး `v` ထဲသို့ကူးထည့်ပါ။
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// ရည်ညွှန်းရေတွက်ထားသော string slice ကိုခွဲဝေချပြီး `v` ထဲသို့ကူးထည့်ပါ။
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// ကိုးကားထားသောရေတွက်ခြင်း၊ ခွဲဝေခြင်းအသစ်သို့ boxed object တစ်ခုကိုရွှေ့ပါ။
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// ရည်ညွှန်းထားသောအချပ်ကိုခွဲဝေချပြီး `v` ၏ပစ္စည်းများကို၎င်းသို့ရွှေ့ပါ။
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Vec အား၎င်း၏မှတ်ဥာဏ်ကိုလွှတ်ပေးရန်ခွင့်ပြုပါ
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// element တစ်ခုချင်းစီကို `Iterator` တွင်ယူပြီး၎င်းကို `Rc<[T]>` သို့စုဆောင်းသည်။
    ///
    /// # စွမ်းဆောင်ရည်ဝိသေသလက္ခဏာများ
    ///
    /// ## ယေဘူယျကိစ္စ
    ///
    /// ယေဘူယျအားဖြင့် `Rc<[T]>` သို့စုဆောင်းခြင်းကို `Vec<T>` ထဲသို့ပထမဆုံးစုဆောင်းခြင်းအားဖြင့်ပြုလုပ်သည်။ဆိုလိုသည်မှာ၊
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ဒါကိုငါတို့ရေးခဲ့တာနဲ့တူတယ်
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // ခွဲဝေချခြင်း၏ပထမအစုသည်ဤနေရာတွင်ဖြစ်ပျက်သည်။
    ///     .into(); // `Rc<[T]>` အတွက်ဒုတိယမြောက်ခွဲဝေချထားမှုသည်ဤနေရာတွင်ဖြစ်ပျက်သည်။
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ၎င်းသည် `Vec<T>` ကိုတည်ဆောက်ရန်လိုအပ်သကဲ့သို့အကြိမ်ပေါင်းများစွာခွဲဝေချထားပေးပြီး `Vec<T>` ကို `Rc<[T]>` သို့ပြောင်းလဲရန်တစ်ကြိမ်ခွဲဝေပေးလိမ့်မည်။
    ///
    ///
    /// ## လူသိများအရှည်၏ကြားမှာ
    ///
    /// သင်၏ `Iterator` `TrustedLen` ကိုအကောင်အထည်ဖော်ပြီးအရွယ်အစားအတိအကျဖြစ်သည့်အခါ `Rc<[T]>` အတွက်ခွဲဝေတစ်ခုတည်းပြုလုပ်လိမ့်မည်။ဥပမာ:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // တစ်ခုတည်းသောခွဲဝေရုံကဒီမှာဖြစ်ပျက်။
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// အထူးပြု trait သည် `Rc<[T]>` သို့စုဆောင်းရန်အသုံးပြုသည်။
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // ဤသည်မှာ `TrustedLen` ကြားဖြတ်အတွက်ဖြစ်သည်။
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // လုံခြုံမှု-ကြားမှာတိကျတဲ့အရှည်ရှိပြီးကျွန်ုပ်တို့မှာရှိဖို့လိုတယ်။
                Rc::from_iter_exact(self, low)
            }
        } else {
            // နောက်ကျောပုံမှန်အကောင်အထည်ဖော်မှုသို့ကျလိမ့်မည်။
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` [`Rc`] ၏ဗားရှင်းသည်ပိုင်ဆိုင်မှုမရှိသောရည်ညွှန်းမှုအားစီမံခန့်ခွဲထားသောခွဲဝေမှုကိုရည်ညွှန်းသည်။ခွဲဝေချထားပေးမှုကို `Weak` pointer ပေါ်ရှိ [`upgrade`] ကိုခေါ်ဆိုခြင်းအားဖြင့်ရရှိနိုင်သည်။ ၎င်းသည် [`Option`]`<`[`Rc`] `<T>>`။
///
/// `Weak` ရည်ညွှန်းမှုသည်ပိုင်ဆိုင်မှုနှင့်သက်ဆိုင်ခြင်းမရှိသောကြောင့်၎င်းသည်ခွဲဝေထားခြင်းတွင်သိမ်းဆည်းထားသောတန်ဖိုးကိုကျဆင်းခြင်းမှတားဆီးမည်မဟုတ်ပါ၊ `Weak` ကိုယ်တိုင်ရှိနေဆဲတန်ဖိုးနှင့် ပတ်သက်၍ အာမခံချက်မရှိပါ။
/// ထို့ကြောင့် [`upgrade`] when [`None`] သို့ပြန်လာနိုင်သည်။
/// သို့သော်သတိပြုပါက `Weak` ရည်ညွှန်းချက် * ခွဲဝေခြင်း (backing store) အားခွဲဝေချထားခြင်းကိုမတားဆီးကြောင်းသတိပြုပါ။
///
/// `Weak` pointer သည်၎င်းအတွင်းပိုင်းတန်ဖိုးကိုကျဆင်းခြင်းမှကာကွယ်ရန်မလိုဘဲ [`Rc`] မှစီမံခန့်ခွဲထားသောခွဲဝေမှုကိုယာယီရည်ညွှန်းထားခြင်းအတွက်အသုံးဝင်သည်။
/// နှစ် ဦး နှစ်ဖက်အပြန်အလှန်ပိုင်ဆိုင်သည့်ကိုးကားမှုများသည် [`Rc`] ကိုကျဆင်းစေရန်ဘယ်တော့မျှခွင့်ပြုမည်မဟုတ်သောကြောင့် [`Rc`] pointers များအကြား circular reference များကိုလည်းကာကွယ်ရန်အသုံးပြုသည်။
/// ဥပမာအားဖြင့်သစ်ပင်တစ်ပင်တွင်မိဘဆုံမှတ်များမှကလေးများအထိခိုင်မာသည့် [`Rc`] ညွှန်ပြချက်များနှင့်ကလေးများမှ `Weak` အမှတ်အသားများရှိနိုင်သည်။
///
/// `Weak` pointer ရရှိရန်ပုံမှန်နည်းလမ်းမှာ [`Rc::downgrade`] ကိုခေါ်ခြင်းဖြစ်သည်။
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // enums တွင်ဤအမျိုးအစား၏အရွယ်အစားကိုအကောင်းဆုံးခွင့်ပြုရန်ဤသည်မှာ `NonNull` ဖြစ်သည်။ သို့သော်၎င်းသည်ခိုင်လုံသော pointer မဟုတ်ပါ။
    //
    // `Weak::new` အမှိုက်ပုံပေါ်တွင်နေရာချစရာမလိုခြင်းကြောင့်၎င်းကို `usize::MAX` ဟုသတ်မှတ်သည်။
    // RcBox မှာအနည်းဆုံး ၂ နေရာသတ်မှတ်ထားလို့ဘာကြောင့်လဲဆိုတော့ဒါကတကယ့် pointer မှာရနိုင်မယ့်တန်ဖိုးမဟုတ်ဘူး။
    // `T: Sized` သာဤအရာသည်ဖြစ်နိုင်သည်;unsized `T` dangle ဘယ်တော့မှ။
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// မည်သည့်မှတ်ဉာဏ်ကိုမျှခွဲဝေခြင်းမပြုဘဲ `Weak<T>` အသစ်တစ်ခုကိုတည်ဆောက်သည်။
    /// [`upgrade`] ကိုပြန်ပို့သည့်တန်ဖိုးမှာအမြဲတမ်း [`None`] ကိုပေးသည်။
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// အချက်အလက်နယ်ပယ်နှင့်ပတ်သက်ပြီးအခိုင်အမာပြောဆိုခြင်းမပြုဘဲရည်ညွှန်းရေတွက်ခြင်းကိုကြည့်ရှုရန်ခွင့်ပြုသည့်အကူအညီအမျိုးအစား။
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// ဤ `Weak<T>` မှညွှန်းထားသော `T` အရာဝတ္ထုသို့ raw pointer တစ်ခု return ပြန်သည်။
    ///
    /// ခိုင်မာသောကိုးကားချက်များရှိမှသာ pointer သည်မှန်ကန်သည်။
    /// အဆိုပါ pointer မဟုတ်ရင် XangX dangling, unaligned သို့မဟုတ်ပင်ဖြစ်နိုင်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // နှစ် ဦး စလုံးတူညီသောအရာဝတ္ထုကိုညွှန်ပြ
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // ဒီမှာအားကောင်းတဲ့သူကရှင်သန်နေစေတယ်၊ ဒါကြောင့်အရာဝတ္ထုကိုကြည့်လို့ရသေးတယ်။
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // သို့သော်မပိုတော့ပါ။
    /// // weak.as_ptr() ကိုကျွန်ုပ်တို့လုပ်နိုင်သည်၊ သို့သော် pointer ကိုအသုံးပြုခြင်းသည်အပြုအမူကိုဖြစ်ပေါ်စေသည်။
    /// // assert_eq ("မင်္ဂလာပါ"၊ unsafe {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // အကယ်၍ ညွှန်ပြသည် dangling ဖြစ်နေပါက sentinel ကိုပြန်ပို့ပါမည်။
            // ဤသည်သည်မှန်ကန်သော payload လိပ်စာမဖြစ်နိုင်ပါ၊ အကြောင်းမှာ paycload သည်အနည်းဆုံး RcBox (usize) နှင့်တူညီသောကြောင့်ဖြစ်သည်။
            ptr as *const T
        } else {
            // လုံခြုံမှု-အကယ်၍ is_dangling သည် false ကို return ပြန်လျှင် pointer သည် dereferencable ဖြစ်သည်။
            // payload ကိုယခုအချိန်တွင်ကျဆင်းသွားနိုင်ပြီးကျွန်ုပ်တို့သည်သက်သေပြမှုကိုဆက်လက်ထိန်းသိမ်းထားရန်လိုသည်။ ထို့ကြောင့် raw pointer manipulation ကိုသုံးပါ။
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// `Weak<T>` ကိုသုံးပြီးအဲဒါကို pointer raw တစ်ခုအဖြစ်ပြောင်းလဲလိုက်သည်။
    ///
    /// ၎င်းသည်အားနည်းသောညွှန်ပြသူအဖြစ်သို့ပြောင်းလဲသွားပြီးအားနည်းသောရည်ညွှန်းချက်တစ်ခု၏ပိုင်ဆိုင်မှုကိုဆက်လက်ထိန်းသိမ်းထားဆဲဖြစ်သည်။ အားနည်းသောအရေအတွက်ကိုဤစစ်ဆင်ရေးမှပြုပြင်မထားပါ။
    /// ၎င်းကို [`from_raw`] နှင့်အတူ `Weak<T>` သို့ပြန်လှည့်နိုင်သည်။
    ///
    /// [`as_ptr`] ကဲ့သို့ pointer ၏ target ကိုရယူရန်ကန့်သတ်ချက်များသည်အတူတူပင်ဖြစ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// ယခင်က [`into_raw`] မှဖန်တီးခဲ့သော pointer raw `Weak<T>` သို့ပြောင်းသည်။
    ///
    /// ၎င်းသည်ခိုင်မာသောရည်ညွှန်းချက် (နောက်ပိုင်းတွင် [`upgrade`] သို့ခေါ်ဆိုခြင်း) ကိုရရှိရန် (သို့) `Weak<T>` ကိုကျဆင်းခြင်းအားဖြင့်အားနည်းသောအရေအတွက်ကိုဖယ်ရှားရန်အတွက်အသုံးပြုနိုင်သည်။
    ///
    /// ၎င်းသည်အားနည်းသောရည်ညွှန်းချက်တစ်ခု၏ပိုင်ဆိုင်မှုကိုရယူသည် ([`new`] မှပြုလုပ်သော pointers များ မှလွဲ၍ ၎င်းတို့သည်မည်သည့်အရာမှပိုင်ဆိုင်ခြင်းမရှိသောကြောင့်ဖြစ်သည်။
    ///
    /// # Safety
    ///
    /// pointer သည် [`into_raw`] မှဆင်းသက်လာပြီးဖြစ်နိုင်သောအားနည်းသောရည်ညွှန်းချက်ကိုပိုင်ဆိုင်ထားရမည်။
    ///
    /// ၎င်းခေါ်ဆိုသည့်အချိန်တွင်အားကောင်းသောအရေအတွက်ကို ၀ ဖြစ်ခွင့်ပြုသည်။
    /// မည်သို့ပင်ဆိုစေကာမူ၊ ၎င်းသည်လက်ရှိအားဖြင့်ကုန်ကြမ်း pointer အဖြစ်ကိုယ်စားပြုသောအားနည်းသောရည်ညွှန်းချက်တစ်ခုကိုပိုင်ဆိုင်သည် (အားနည်းချက်ကိုဒီလုပ်ဆောင်မှုမှပြုပြင်မထားပါ) ထို့ကြောင့်၎င်းသည်ယခင် [`into_raw`] သို့ခေါ်ဆိုမှုနှင့်တွဲဖက်ရမည်ဖြစ်သည်။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // နောက်ဆုံးအားနည်းအရေအတွက်လျော့။
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // input pointer မည်သို့ဆင်းသက်လာသည်ကိုအခြေအနေတွင် Weak::as_ptr တွင်ကြည့်ပါ။

        let ptr = if is_dangling(ptr as *mut T) {
            // ဒါ dangling အားနည်းချက်ပဲ။
            ptr as *mut RcBox<T>
        } else {
            // ဒီလိုမှမဟုတ်ရင်ကျနော်တို့ကညွှန်ပြနေတဲ့အားနည်းတဲ့အားနည်းချက်ကနေလာတာသေချာတယ်။
            // လုံခြုံမှု: ptr သည်အမှန်တကယ် (ဖြစ်နိုင်ခြေကျဆင်းသွားသည်) ကိုရည်ညွှန်းသောကြောင့် data_offset သည်လုံခြုံစွာခေါ်ဆိုနိုင်သည်။
            let offset = unsafe { data_offset(ptr) };
            // ထို့ကြောင့်ကျွန်ုပ်တို့သည် RcBox တစ်ခုလုံးရရန် offset ကိုပြောင်းလိုက်သည်။
            // လုံခြုံမှု-ညွှန်ပြသူသည်အားနည်းချက်မှဆင်းသက်လာသောကြောင့်ဤချိန်ညှိမှုသည်လုံခြုံသည်။
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // လုံခြုံမှု-ယခုကျွန်ုပ်တို့အားနည်းသော pointer ကိုပြန်လည်ရရှိပြီးဖြစ်သောကြောင့်အားနည်းမှုကိုဖန်တီးနိုင်သည်။
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// `Weak` pointer ကို [`Rc`] သို့မြှင့်တင်ရန်ကြိုးပမ်းသည်။
    ///
    ///
    /// အတွင်းပိုင်းတန်ဖိုးကိုကတည်းကကျဆင်းသွားခဲ့ပြီးလျှင် [`None`] ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // အားကြီးသောထောက်ပြသူအားလုံးကိုဖျက်ဆီးပစ်ပါ။
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// ဒီခွဲဝေမှုကိုညွှန်ပြခိုင်မာတဲ့ (`Rc`) ထောက်ပြများ၏နံပါတ်ရရှိသည်။
    ///
    /// `self` ကို [`Weak::new`] သုံး၍ ဖန်တီးခဲ့လျှင်၎င်းသည် 0 သို့ပြန်သွားလိမ့်မည်။
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// ဒီခွဲဝေမှုကိုညွှန်ပြ `Weak` ထောက်ပြ၏နံပါတ်ရရှိသည်။
    ///
    /// ခိုင်မာသောထောက်ပြသူမရှိလျှင်၊ သုညသို့ပြန်သွားလိမ့်မည်။
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // အဆိုပါသွယ်ဝိုက်အားနည်း ptr နုတ်
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// pointer သည်ချိတ်ထားသောအခါ `None` ကို return ပြန်သည်။ `RcBox` မရှိပါ။ (ဆိုလိုသည်မှာ `Weak` မှ `Weak::new` ဖန်တီးသောအခါ) ။
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // ကျွန်ုပ်တို့သည် "data" field ကိုဖုံးအုပ်ထားသောရည်ညွှန်းကိုးကားခြင်းကိုမဖန်တီးရန်သတိထားသည်။ ဥပမာအားဖြင့်၊ နောက်ဆုံး `Rc` ကျဆင်းသွားပါကဒေတာနယ်ပယ်တွင်ကျဆင်းသွားလိမ့်မည်။
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// `Weak`s နှစ်ခုသည် ([`ptr::eq`] နှင့်ဆင်တူသည်) တူညီသောခွဲဝေမှုကိုရည်ညွှန်းပါက၊ သို့မဟုတ်နှစ်မျိုးလုံးသည် `Weak::new()`) ဖြင့်ဖန်တီးထားခြင်းကြောင့်မည်သည့်ခွဲဝေမှုကိုမညွှန်ပြလျှင် `true` ကိုပြန်ပို့သည်။
    ///
    ///
    /// # Notes
    ///
    /// ၎င်းသည် pointers များနှင့်နှိုင်းယှဉ်လျှင် `Weak::new()` သည်မည်သည့်ခွဲဝေသတ်မှတ်ချက်ကိုမျှညွှန်ပြခြင်းမရှိသော်လည်း၊
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` ကိုနှိုင်းယှဉ်။
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// အဆိုပါ `Weak` pointer ကို drop ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // ဘာမှမပုံနှိပ်ပါဘူး
    /// drop(foo);        // "dropped!" ထုတ်
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // အားနည်းသောအရေအတွက်သည် 1 မှစတင်ပြီး၊ အားကြီးသောညွှန်ပြသူအားလုံးပျောက်ကွယ်သွားပါကသုညသို့သာသွားလိမ့်မည်။
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// တူညီသောခွဲဝေမှုကိုညွှန်ပြသော `Weak` pointer ၏ကိုယ်ပွားကိုပြုလုပ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// `T` အသစ်တစ်ခုကိုတည်ဆောက်သည်။ ၎င်းသည်အစပျိုးခြင်းမရှိဘဲ `T` အတွက်မှတ်ဉာဏ်ချထားပေးသည်။
    /// [`upgrade`] ကိုပြန်ပို့သည့်တန်ဖိုးမှာအမြဲတမ်း [`None`] ကိုပေးသည်။
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: mem::forget ကိုအန္တရာယ်ကင်းစွာကိုင်တွယ်ရန်ဤနေရာတွင်ကျွန်ုပ်တို့ check_add ရောက်ခဲ့သည်။အထူးသဖြင့်
// အကယ်၍ သင်သည် mem::forget Rcs (သို့မဟုတ် Weaks) ဖြစ်ပါက ref-count သည်အလွန်များပြားပြီးထူးခြားသော Rcs (သို့မဟုတ် Weaks) တည်ရှိနေစဉ်ခွဲဝေချခြင်းကိုသင်လွတ်မြောက်နိုင်သည်။
//
// ဘာလို့လဲဆိုတော့ဒီဟာကဆုတ်ယုတ်ပျက်စီးယိုယွင်းနေတဲ့အခြေအနေမျိုးဖြစ်လို့ဘာတွေဖြစ်နေလဲဆိုတာကိုဂရုမစိုက်ဘူး။ ဒါကိုလက်တွေ့ကျတဲ့ဘယ်အစီအစဉ်မှမတွေ့ကြုံရဘူး။
//
// ပိုင်ဆိုင်မှုနှင့်ရွေ့လျားမှုဆိုင်ရာအချက်အလက်များကြောင့်သင် Rust တွင်ဤအရာများကိုပုံတူပွားရန်မလိုပါ။
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // တန်ဖိုးကိုကျဆင်းမသွားစေလိုဘဲလျတ်စီးဆင်းမှုကိုရပ်နားရန်လိုသည်။
        // ဒီကိုခေါ်သည့်အခါရည်ညွှန်းအရေအတွက်သုညဖြစ်ဘယ်တော့မှ;
        // မည်သို့ပင်ဆိုစေ, ငါတို့မဟုတ်ရင်လွဲချော် optimization မှာ LLVM အရိပ်အမြွက်ဤနေရာတွင်တစ်ခု abort ထည့်သွင်း။
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // တန်ဖိုးကိုကျဆင်းမသွားစေလိုဘဲလျတ်စီးဆင်းမှုကိုရပ်နားရန်လိုသည်။
        // ဒီကိုခေါ်သည့်အခါရည်ညွှန်းအရေအတွက်သုညဖြစ်ဘယ်တော့မှ;
        // မည်သို့ပင်ဆိုစေ, ငါတို့မဟုတ်ရင်လွဲချော် optimization မှာ LLVM အရိပ်အမြွက်ဤနေရာတွင်တစ်ခု abort ထည့်သွင်း။
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// pointer တစ်ခု၏နောက်ကွယ်ရှိ payload အတွက် `RcBox` အတွင်း offset ကိုရယူပါ။
///
/// # Safety
///
/// ညွှန်ပြသူသည်ယခင်ကခိုင်လုံသော T ၏ဥပမာ (နှင့်မှန်ကန်သော metadata များရှိရမည်) ကိုညွှန်ပြရမည်၊ သို့သော် T ကိုကျဆင်းနိုင်သည်။
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // unsized တန်ဖိုးကို RcBox ၏အဆုံးနှင့် align ။
    // RcBox သည် repr(C) ဖြစ်သောကြောင့်၎င်းသည်အမြဲတမ်းမှတ်ဉာဏ်တွင်နောက်ဆုံးနေရာဖြစ်လိမ့်မည်။
    // လုံခြုံမှု-မဖြစ်နိုင်သည့်တစ်ခုတည်းသောအမျိုးအစားများသည်ချပ်များ ဖြစ်၍ trait တ္ထုများ၊
    // နှင့်ပြင်ပအမျိုးအစားများ, input ကိုဘေးကင်းလုံခြုံမှုလိုအပ်ချက် align_of_val_raw ၏လိုအပ်ချက်များကိုကျေနပ်အောင်လက်ရှိအလုံအလောက်;ဤသည်သည် std ပြင်ပ၌မှီခိုအားထားနိုင်သည့်ဘာသာစကား၏အကောင်အထည်ဖော်မှုအသေးစိတ်ဖြစ်သည်။
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}