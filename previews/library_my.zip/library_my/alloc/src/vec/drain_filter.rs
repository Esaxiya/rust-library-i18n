use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// Element တစ်ခုရဲ့ဖယ်ရှားရမည်ဆိုပါကဆုံးဖြတ်ရန်တစ်ပိတ်သိမ်းကိုအသုံးပြုသည့်ကြားမှာ။
///
/// ဤဖွဲ့စည်းပုံကို [`Vec::drain_filter`] မှဖန်တီးသည်။
/// ပိုမိုသိရှိလိုပါက၎င်း၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// `next` ဖို့လာမယ့်ခေါ်ဆိုခများကကြည့်ရှုစစ်ဆေးသည်မည်သည့်အကြောင်းအရာ၏အညွှန်းကိန်း။
    pub(super) idx: usize,
    /// ယခုအချိန်အထိ (removed) ညှစ်ခဲ့ပြီပစ္စည်းအရေအတွက်။
    pub(super) del: usize,
    /// ယိုစီးမှုမတိုင်မီ `vec` ၏မူလအရှည်။
    pub(super) old_len: usize,
    /// အဆိုပါ filter ကိုစမ်းသပ် predicate ။
    pub(super) pred: F,
    /// panic တစ်ခုကိုညွှန်ပြသောအလံသည်စစ်ထုတ်မှုအစမ်းခန့်မှန်းတွင်ဖြစ်ပွားခဲ့သည်။
    /// ဒါက `DrainFilter` ၏ကျန်ရှိသော၏စားသုံးမှုကိုတားဆီးဖို့တစ်စက်အကောင်အထည်ဖော်ရေးအတွက်အရိပ်အမြွက်အဖြစ်အသုံးပြုပါသည်။
    /// မဆို unprocessed ပစ္စည်းများကိုအဆိုပါ `vec` အတွက် backshifted ပါလိမ့်မည်, ဒါပေမယ့်ဘယ်သူမျှမကနောက်ထပ်ပစ္စည်းများကိုအဆိုပါစစ်ထုတ် predicate အားဖြင့်ကျဆင်းသွားသို့မဟုတ်စမ်းသပ်ပြီးပါလိမ့်မည်။
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// အခြေခံခွဲဝေပေးသူတစ် ဦး ကိုကိုးကား Returns ။
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // predicate ကိုခေါ်ပြီးနောက် * index ကို update လုပ်ပါ။
                // ညွှန်းကိန်းကိုကြိုတင်မွမ်းမံပြီး panics ကိုကြိုတင်ခန့်မှန်းထားသည်ဆိုပါကဤအညွှန်းကိန်းရှိဒြပ်စင်သည်ပေါက်ကြားလိမ့်မည်။
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // ဒါကတော်တော်ရှုပ်ထွေးနေတဲ့ပြည်နယ်ဖြစ်ပြီးတကယ်လုပ်ဖို့မသင့်တော်တဲ့အရာမရှိဘူး။
                        // `pred` ကို ဆက်၍ မကွိုးစားဘဲမနေလိုပါ၊ ထို့ကြောင့်ကျွန်ုပ်တို့သည် unprocessed element များအားလုံးကို backshift လုပ်ပြီး၎င်းတို့တည်ရှိနေဆဲဖြစ်သည်။
                        //
                        // အဆိုပါ backshift ကြိုတင် predicate အတွက် panic မတိုင်မီနောက်ဆုံးအောင်မြင်စွာညှစ်ပစ္စည်း၏နှစ်ကြိမ်-Drop တားဆီးဖို့လိုအပ်သည်။
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // ကျန်ရှိသောဒြပ်စင်များကိုစီစစ်ရန်ကြိုတင်မထိတ်လန့်သေးလျှင်ကြိုးစားပါ။
        // ကျွနု်ပ်တို့ထိတ်လန့်နေပြီလားသို့မဟုတ်ဤနေရာတွင် panics သုံးစွဲမှုရှိပါကကျန်ရှိသောမည်သည့်ဒြပ်စင်ကိုမဆိုပြောင်းလဲလိမ့်မည်။
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}