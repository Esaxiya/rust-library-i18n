use core::ptr::{self};
use core::slice::{self};

// ဦး တည်ရာနေရာကိုဆိုလိုသည်မှာခေါင်းကိုဆိုလိုသည်။
// အရင်းအမြစ်အချပ် (အမြီး) IntoIter အားဖြင့်ကျဆင်းသွားသည်။
pub(super) struct InPlaceDrop<T> {
    pub(super) inner: *mut T,
    pub(super) dst: *mut T,
}

impl<T> InPlaceDrop<T> {
    fn len(&self) -> usize {
        unsafe { self.dst.offset_from(self.inner) as usize }
    }
}

impl<T> Drop for InPlaceDrop<T> {
    #[inline]
    fn drop(&mut self) {
        unsafe {
            ptr::drop_in_place(slice::from_raw_parts_mut(self.inner, self.len()));
        }
    }
}