use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Vec::from_iter အတွက်အထူးပြု trait အထူးပြု
///
/// ## ကိုယ်စားလှယ်အဖွဲ့ဂရပ်:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // အဖြစ်များသည့်အမှုတစ်ခုသည် vector ကိုလုပ်ဆောင်မှုတစ်ခုသို့ချက်ချင်း vector သို့ပြန်လည်စုဆောင်းသည်။
        // အကယ်၍ IntoIter သည်အဆင့်မမြင့်လျှင်၎င်းကိုကျွန်ုပ်တို့တိုတောင်းနိုင်သည်။
        // ၎င်းကိုအဆင့်မြှင့်တင်ပြီးပါကကျွန်ုပ်တို့သည်မှတ်ဉာဏ်ကိုပြန်လည် အသုံးပြု၍ အချက်အလက်များကိုရှေ့သို့ရွှေ့ပြောင်းနိုင်သည်။
        // သို့သော်ရရှိလာသော Vec သည်ယေဘူယျ FromIterator အကောင်အထည်ဖော်မှုမှတဆင့်ဖန်တီးခြင်းထက်ပိုမိုအသုံးမပြုခြင်းစွမ်းရည်ရှိမှသာလုပ်နိုင်လိမ့်မည်။
        //
        // Vec ၏ခွဲဝေချထားသည့်အပြုအမူကိုရည်ရွယ်ချက်ရှိရှိမသတ်မှတ်ထားသောကြောင့်ထိုကန့်သတ်ချက်သည်လုံးဝမလိုအပ်ပါ။
        // သို့သော်ရှေးရိုးစွဲရွေးချယ်မှုတစ်ခုဖြစ်သည်။
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // extend() သူ့ဟာသူအချည်းနှီးသော Vecs များအတွက် spec_from မှလွှဲအပ်ကတည်းက spec_extend() မှလွှဲအပ်ရမည်ဖြစ်သည်
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// spec_extend သည်နောက်ဆုံးစွမ်းရည် + အရှည်နှင့်ပတ်သက်ပြီးကျိုးကြောင်းဆင်ခြင်ရန်ပိုမိုလုပ်ဆောင်ရမည်ဖြစ်သဖြင့်အလုပ်ပိုလုပ်ရန်အတွက် `iterator.as_slice().to_vec()` ကိုအသုံးပြုသည်။
// `to_vec()` မှန်ကန်သောငွေပမာဏကိုတိုက်ရိုက်ခွဲဝေချထားပေးပြီးအတိအကျဖြည့်စွက်။
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): cfg(test) နှင့်အတူဤနည်းလမ်းနှင့်အဓိပ္ပါယ်အတွက်လိုအပ်သောမွေးရာပါ `[T]::to_vec` နည်းလမ်းကိုမရရှိနိုင်ပါ။
    // cfg(test) NB နှင့်သာရရှိနိုင်သည့် `slice::to_vec` function ကိုသုံးပါ။ နောက်ထပ်အချက်အလက်များအတွက် slice.rs ရှိ slice::hack module ကိုကြည့်ပါ။
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}