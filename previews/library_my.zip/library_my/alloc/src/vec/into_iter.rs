use crate::alloc::{Allocator, Global};
use crate::raw_vec::RawVec;
use core::fmt;
use core::intrinsics::arith_offset;
use core::iter::{FusedIterator, InPlaceIterable, SourceIter, TrustedLen, TrustedRandomAccess};
use core::marker::PhantomData;
use core::mem::{self};
use core::ptr::{self, NonNull};
use core::slice::{self};

/// vector မှထွက်သွားသည့်ကြားမှာ။
///
/// ဤ `struct` ကို [`Vec`](super::Vec) ([`IntoIterator`] trait မှထောက်ပံ့သော) ပေါ်ရှိ `into_iter` နည်းလမ်းဖြင့်ဖန်တီးထားသည်။
///
///
/// # Example
///
/// ```
/// let v = vec![0, 1, 2];
/// let iter: std::vec::IntoIter<_> = v.into_iter();
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<
    T,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> {
    pub(super) buf: NonNull<T>,
    pub(super) phantom: PhantomData<T>,
    pub(super) cap: usize,
    pub(super) alloc: A,
    pub(super) ptr: *const T,
    pub(super) end: *const T,
}

#[stable(feature = "vec_intoiter_debug", since = "1.13.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for IntoIter<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}

impl<T, A: Allocator> IntoIter<T, A> {
    /// ကျန်အကြွင်းအကျန်များကိုဤကြားဖြတ်၏အချပ်တစ်ခုအဖြစ်ပြန်ပို့သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let vec = vec!['a', 'b', 'c'];
    /// let mut into_iter = vec.into_iter();
    /// assert_eq!(into_iter.as_slice(), &['a', 'b', 'c']);
    /// let _ = into_iter.next().unwrap();
    /// assert_eq!(into_iter.as_slice(), &['b', 'c']);
    /// ```
    #[stable(feature = "vec_into_iter_as_slice", since = "1.15.0")]
    pub fn as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr, self.len()) }
    }

    /// ကျန်ရှိသောအရာများကိုဤကြားဖြတ်၏အပြောင်းအလဲတစ်ခုအဖြစ်ပြန်ပို့သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// let vec = vec!['a', 'b', 'c'];
    /// let mut into_iter = vec.into_iter();
    /// assert_eq!(into_iter.as_slice(), &['a', 'b', 'c']);
    /// into_iter.as_mut_slice()[2] = 'z';
    /// assert_eq!(into_iter.next().unwrap(), 'a');
    /// assert_eq!(into_iter.next().unwrap(), 'b');
    /// assert_eq!(into_iter.next().unwrap(), 'z');
    /// ```
    #[stable(feature = "vec_into_iter_as_slice", since = "1.15.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        unsafe { &mut *self.as_raw_mut_slice() }
    }

    /// အခြေခံခွဲဝေပေးသူတစ် ဦး ကိုကိုးကား Returns ။
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn as_raw_mut_slice(&mut self) -> *mut [T] {
        ptr::slice_from_raw_parts_mut(self.ptr as *mut T, self.len())
    }

    /// ကျန်ရှိနေသေးသောဒြပ်စင်များကိုဖယ်ရှားပြီးကျောထောက်နောက်ခံပြုထားသောခွဲဝေချထားမှုကိုလျှော့ချသည်။
    ///
    /// ၎င်းသည်အောက်ပါနှင့်အကြမ်းအားဖြင့်ညီမျှသော်လည်း ပို၍ ထိရောက်သည်
    ///
    /// ```
    /// # let mut into_iter = Vec::<u8>::with_capacity(10).into_iter();
    /// (&mut into_iter).for_each(core::mem::drop);
    /// unsafe { core::ptr::write(&mut into_iter, Vec::new().into_iter()); }
    /// ```
    pub(super) fn forget_allocation_drop_remaining(&mut self) {
        let remaining = self.as_raw_mut_slice();

        // တစ် ဦး ချင်းစီနယ်ပယ်အသစ်တစ်ခုကိုဖွဲ့စည်းပြီးတော့ &mut မိမိကိုယ်ကို overwrite လုပ်မယ့်အစားတစ် ဦး ချင်းစီလယ်ကွင်း overwrite ။
        //
        // ဒီလျော့နည်းစည်းဝေးပွဲကိုဖန်တီးပေးပါတယ်
        self.cap = 0;
        self.buf = unsafe { NonNull::new_unchecked(RawVec::NEW.ptr()) };
        self.ptr = self.buf.as_ptr();
        self.end = self.buf.as_ptr();

        unsafe {
            ptr::drop_in_place(remaining);
        }
    }
}

#[stable(feature = "vec_intoiter_as_ref", since = "1.46.0")]
impl<T, A: Allocator> AsRef<[T]> for IntoIter<T, A> {
    fn as_ref(&self) -> &[T] {
        self.as_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send, A: Allocator + Send> Send for IntoIter<T, A> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync, A: Allocator> Sync for IntoIter<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Iterator for IntoIter<T, A> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        if self.ptr as *const _ == self.end {
            None
        } else if mem::size_of::<T>() == 0 {
            // ရည်ရွယ်ချက်ရှိရှိ 'ptr.offset' ကိုမသုံးပါနှင့်အဘယ်ကြောင့်ဆိုသော် vectors အတွက် 0-size element များပါ ၀ င်လျှင်၎င်းသည်အတူတူ pointer ကိုပြန်ပေးလိမ့်မည်။
            //
            //
            self.ptr = unsafe { arith_offset(self.ptr as *const i8, 1) as *mut T };

            // ဒီ ZST ၏တန်ဖိုးကိုတက်ပါစေ။
            Some(unsafe { mem::zeroed() })
        } else {
            let old = self.ptr;
            self.ptr = unsafe { self.ptr.offset(1) };

            Some(unsafe { ptr::read(old) })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = if mem::size_of::<T>() == 0 {
            (self.end as usize).wrapping_sub(self.ptr as usize)
        } else {
            unsafe { self.end.offset_from(self.ptr) as usize }
        };
        (exact, Some(exact))
    }

    #[inline]
    fn count(self) -> usize {
        self.len()
    }

    unsafe fn __iterator_get_unchecked(&mut self, i: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        // လုံခြုံမှု: `i` ၏မှတ်သားသောခေါ်ဆိုသူ၏မဖြစ်မနေအာမခံချက်
        // `Vec<T>`, ထို့ကြောင့် `i` သည် `isize` ကိုမလျှံနိုင်ဘဲ `self.ptr.add(i)` သည် `Vec<T>` ၏ဒြပ်စင်တစ်ခုသို့ညွှန်ပြရန်အာမခံထားသည်။
        //
        //
        // `Self: TrustedRandomAccess` ၏အကောင်အထည်ဖော်မှုသည် `T: Copy` အနေဖြင့်ကြားခံမှဖတ်သောအရာများသည် `Drop` အတွက်မှားယွင်းမှုမရှိစေရန်လိုအပ်သည်ကိုသတိပြုပါ။
        //
        //
        //
        unsafe {
            if mem::size_of::<T>() == 0 { mem::zeroed() } else { ptr::read(self.ptr.add(i)) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> DoubleEndedIterator for IntoIter<T, A> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        if self.end == self.ptr {
            None
        } else if mem::size_of::<T>() == 0 {
            // 'ptr.offset' ကိုဘာကြောင့်အသုံးမပြုသည်ကိုအထက်တွင်ကြည့်ပါ
            self.end = unsafe { arith_offset(self.end as *const i8, -1) as *mut T };

            // ဒီ ZST ၏တန်ဖိုးကိုတက်ပါစေ။
            Some(unsafe { mem::zeroed() })
        } else {
            self.end = unsafe { self.end.offset(-1) };

            Some(unsafe { ptr::read(self.end) })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ExactSizeIterator for IntoIter<T, A> {
    fn is_empty(&self) -> bool {
        self.ptr == self.end
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T, A: Allocator> FusedIterator for IntoIter<T, A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T, A: Allocator> TrustedLen for IntoIter<T, A> {}

#[doc(hidden)]
#[unstable(issue = "none", feature = "std_internals")]
// T_: get_unchecked self.ptr ကိုတိုးမပေးသောကြောင့် !Drop အတွက်အကြမ်းဖျင်းအဖြစ်ကူးယူပါ
// ထို့ကြောင့်ကျွန်ုပ်တို့သည် drop-handling ကိုအကောင်အထည်မဖော်နိုင်ပါ
unsafe impl<T, A: Allocator> TrustedRandomAccess for IntoIter<T, A>
where
    T: Copy,
{
    const MAY_HAVE_SIDE_EFFECT: bool = false;
}

#[stable(feature = "vec_into_iter_clone", since = "1.8.0")]
impl<T: Clone, A: Allocator + Clone> Clone for IntoIter<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        self.as_slice().to_vec_in(self.alloc.clone()).into_iter()
    }
    #[cfg(test)]
    fn clone(&self) -> Self {
        crate::slice::to_vec(self.as_slice(), self.alloc.clone()).into_iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for IntoIter<T, A> {
    fn drop(&mut self) {
        struct DropGuard<'a, T, A: Allocator>(&'a mut IntoIter<T, A>);

        impl<T, A: Allocator> Drop for DropGuard<'_, T, A> {
            fn drop(&mut self) {
                unsafe {
                    // `IntoIter::alloc` ဒီပြီးနောက်တော့ဘူးအသုံးပြုသည်မဟုတ်
                    let alloc = ptr::read(&self.0.alloc);
                    // RawVec သည်ဖျက်သိမ်းခြင်းကိုကိုင်တွယ်သည်
                    let _ = RawVec::from_raw_parts_in(self.0.buf.as_ptr(), self.0.cap, alloc);
                }
            }
        }

        let guard = DropGuard(self);
        // ကျန်ရှိသောဒြပ်စင်ကိုဖကျြဆီး
        unsafe {
            ptr::drop_in_place(guard.0.as_raw_mut_slice());
        }
        // ယခု `guard` ကျဆင်းသွားပြီးကျန်တာတွေကိုလုပ်ပါလိမ့်မည်
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T, A: Allocator> InPlaceIterable for IntoIter<T, A> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T, A: Allocator> SourceIter for IntoIter<T, A> {
    type Source = Self;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

// In-place ကြားမှာအထူးပြုများအတွက်ပြည်တွင်းရေးအထောက်အ trait ။
#[rustc_specialization_trait]
pub(crate) trait AsIntoIter {
    type Item;
    fn as_into_iter(&mut self) -> &mut IntoIter<Self::Item>;
}

impl<T> AsIntoIter for IntoIter<T> {
    type Item = T;

    fn as_into_iter(&mut self) -> &mut IntoIter<Self::Item> {
        self
    }
}