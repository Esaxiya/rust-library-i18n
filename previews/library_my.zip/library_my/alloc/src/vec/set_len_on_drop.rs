// `SetLenOnDrop` တန်ဖိုးနယ်ပယ်မှထွက်သွားသောအခါ vec ၏အရှည်ကိုသတ်မှတ်ပါ။
//
// အယူအဆမှာ SetLenOnDrop ရှိအရှည်ကွက်သည် local variable တစ်ခုဖြစ်သည်။ ၎င်းသည် Vec ၏ data pointer မှတဆင့်မည်သည့်စတိုးဆိုင်များတွင်မဆို alias ကိုမြင်နိုင်လိမ့်မည်မဟုတ်ပေ။
// ဤသည် alias ကိုခွဲခြမ်းစိတ်ဖြာပြissueနာ #32155 များအတွက်ပြသနာကိုကျော်လွှားနိုင်စေရန်ဖြစ်သည်
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}