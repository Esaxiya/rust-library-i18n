use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// အရင်းအမြစ်ခွဲဝေချထားမှုများကိုပြန်လည်အသုံးပြုနေစဉ်ကြားဖြတ်ပိုက်လိုင်းအား Vec တစ်ခုအတွင်းစုဆောင်းရန်အထူးပြုအမှတ်အသားဖြစ်သည်
/// အရပျ၌ပိုက်လိုင်းကွပ်မျက်။
///
/// ပြန်လည်သုံးသပ်ရမည့်ခွဲဝေချထားပေးမှုကိုအထူးလုပ်ဆောင်ရန်အတွက် SourceIter parent trait လိုအပ်သည်။
/// သို့သော်အထူးပြုတရားဝင်ဖြစ်ရန်မလုံလောက်ပါ။
/// အဆိုပါ impl အပေါ်အပိုဆောင်းဘောငျကိုကြည့်ပါ။
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-internal SourceIter/InPlaceIterable traits ကို Adapter ၏ချည်နှောင်မှုဖြင့်သာအကောင်အထည်ဖော်သည် <Adapter<Adapter<IntoIter>>> (အားလုံး core/std ကပိုင်ဆိုင်) ။
// Adapter implementations (`impl<I: Trait> Trait for Adapter<I>` ထက်ကျော်လွန်သော) အပိုထပ်ဆောင်းသတ်သတ်မှတ်မှတ် traits (Copy, TrustedRandomAccess, FusedIterator) ဟုမှတ်သားထားသောအခြား traits ပေါ်တွင်သာမူတည်သည်။
//
// I.e. ညွှန်ကိန်းသည်သုံးစွဲသူများထောက်ပံ့သည့်အမျိုးအစားများ၏သက်တမ်းပေါ်တွင်မူတည်သည်။များစွာသောအခြားအထူးပြီးသားပေါ်မူတည်သော Copy အပေါက် Modulo ။
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // trait bounds မှတဆင့်ထုတ်ဖော်ပြောဆိုမရနိုင်သည့်အပိုဆောင်းလိုအပ်ချက်များ။ကျနော်တို့ const eval အပေါ်အားကိုး:
        // (က) Alloc စာချုပ်အရလိုအပ်သောအတိုင်းအတာကိုက်ညီမှု (Z) နံပါတ်ကိုက်ညီမှုရှိလျှင်ပြန်လည်အသုံးပြုနိုင်ရန်ခွဲဝေခြင်းမရှိသောကြောင့်ဂဏန်းသင်္ချာကိုညွှန်ပြခြင်း (Z) နံပါတ် spanic ။
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // ပိုပြီးယေဘုယျအကောင်အထည်ဖော်မှုမှ fallback
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // ကတည်းက try-fold ကိုသုံးပါ
        // - အချို့ကြားမှာလိုက်လျောညီထွေဖြစ်အောင်အတွက်ပိုကောင်းတဲ့ vectorizes
        // - Internal Iteration Method များနှင့်မတူသည်က &mut self သာကြာသည်
        // - အဲဒါကကျွန်တော်တို့ကို write pointer ကိုသူ့ရဲ့အထဲကိုဖြတ်ပြီးအဆုံးအထိပြန်ပို့ပေးတယ်
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // ခေါင်းကိုမကျပါနဲ့
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // SourceIter စာချုပ်ကိုထောက်ခံမှုရှိမရှိစစ်ဆေးပါ။ သူတို့မပါရှိပါကကျွန်ုပ်တို့ဤအချက်ကိုပင်ပြုလုပ်နိုင်မည်မဟုတ်ပါ
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // InPlaceIterable စာချုပ်စစ်ဆေးပါ။ကြားမှာအရင်းအမြစ်ညွှန်ပြသူကိုအဆင့်မြင့်လိုက်ရင်ဒါကဖြစ်နိုင်တယ်။
        // TrustedRandomAccess မှတဆင့် unchecked access ကိုအသုံးပြုသည်ဆိုလျှင် source pointer သည်၎င်း၏ကန ဦး အနေအထားတွင်ရှိနေမည်ဖြစ်ပြီး၎င်းကိုရည်ညွှန်းချက်အနေဖြင့် အသုံးပြု၍ မရပါ။
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // ကျန်ရှိသောတန်ဖိုးများကိုအရင်းအမြစ်၏အမြီးတွင်ချန်ထားပါ။ အကယ်၍ အကယ်၍ drop panics ကျလျှင်ကျွန်ုပ်တို့သည် dst_buf သို့စုဆောင်းထားသည့်မည်သည့်ဒြပ်စင်ကိုမဆိုယိုစိမ့်သွားပါက IntoIter နယ်ပယ်မှထွက်သွားပါကခွဲဝေချထားခြင်းများကျဆင်းခြင်းကိုတားဆီးပါ။
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // try_fold သည် source pointer ကိုသီးသန့်ရည်ညွှန်းထားသည့်အတွက် InPlaceIterable စာချုပ်ကိုဤနေရာတွင်အတိအကျမစစ်ဆေးနိုင်ပါ
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}