use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// ထပ်နေသည်ကိုအထူးပြုလုပ်ရန်ကိုယ်တိုင် ဦး စားပေးလုပ်ဆောင်ရန်အတွက် Vec::from_iter အတွက်နောက်ထပ်အထူးပြု trait သည်အသေးစိတ်အတွက် [`SpecFromIter`](super::SpecFromIter) တွင်ကြည့်ပါ။
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // ပထမဆုံးကြားဖြတ်ကို unoll လုပ်ပါ။ vector သည်ကြားမှာအချည်းနှီးမဖြစ်သည့်အခါတိုင်းဤကြားဖြတ်တွင်တိုးချဲ့သွားမည်ဖြစ်သော်လည်း extend_desugared() ရှိကွင်းဆက်သည်နောက်ဆက်တွဲကွင်းဆက်အနည်းငယ်တွင် vector ပြည့်နေသည်ကိုမြင်လိမ့်မည်မဟုတ်ပါ။
        //
        // ဒါကြောင့်ငါတို့ branch ဟောကိန်းကိုပိုကောင်းတယ်။
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // extend() သူ့ဟာသူအချည်းနှီးသော Vecs များအတွက် spec_from မှလွှဲအပ်ကတည်းက spec_extend() မှလွှဲအပ်ရမည်ဖြစ်သည်
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // extend() သူ့ဟာသူအချည်းနှီးသော Vecs များအတွက် spec_from မှလွှဲအပ်ကတည်းက spec_extend() မှလွှဲအပ်ရမည်ဖြစ်သည်
        //
        vector.spec_extend(iterator);
        vector
    }
}