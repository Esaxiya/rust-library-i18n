//! ငှားရမ်းထားသောဒေတာနှင့်အလုပ်လုပ်ရန်အတွက် module တစ်ခု။

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::Ordering;
use core::hash::{Hash, Hasher};
use core::ops::{Add, AddAssign, Deref};

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::borrow::{Borrow, BorrowMut};

use crate::fmt;
use crate::string::String;

use Cow::*;

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, B: ?Sized> Borrow<B> for Cow<'a, B>
where
    B: ToOwned,
    <B as ToOwned>::Owned: 'a,
{
    fn borrow(&self) -> &B {
        &**self
    }
}

/// ချေးထားသောဒေတာအတွက် `Clone` ၏ယေဘူယျ။
///
/// အချို့သောအမျိုးအစားများသည်များသောအားဖြင့် `Clone` trait ကိုအကောင်အထည်ဖော်ခြင်းဖြင့်ငှားရမ်းခြင်းမှပိုင်ဆိုင်သည့်ပစ္စည်းသို့သွားနိုင်သည်။
/// သို့သော် `Clone` သည် `&T` မှ `T` သို့သာသွားနိုင်သည်။
/// ပေးထားသောအမျိုးအစားတစ်ခု၏ငှားရမ်းခြင်းမှပိုင်ဆိုင်သောအချက်အလက်များကိုတည်ဆောက်ရန် `Clone` trait က `Clone` ကိုယေဘူယျပြုသည်။
///
#[cfg_attr(not(test), rustc_diagnostic_item = "ToOwned")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToOwned {
    /// ပိုင်ဆိုင်မှုရရှိပြီးနောက်ရရှိလာတဲ့အမျိုးအစား။
    #[stable(feature = "rust1", since = "1.0.0")]
    type Owned: Borrow<Self>;

    /// ငှားရမ်းထားသောဒေတာများမှပိုင်ဆိုင်သောအချက်အလက်များကိုများသောအားဖြင့်ပုံတူပွားခြင်းဖြင့်ပြုလုပ်သည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let s: &str = "a";
    /// let ss: String = s.to_owned();
    ///
    /// let v: &[i32] = &[1, 2];
    /// let vv: Vec<i32> = v.to_owned();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn to_owned(&self) -> Self::Owned;

    /// ပိုင်ဆိုင်သည့်ဒေတာများကိုအစားထိုးရန်ငှားရမ်းထားသောဒေတာကိုအသုံးပြုသည်။
    ///
    /// ဤသည်မှာ `Clone::clone_from` ၏ချေးငှားထားသောဗားရှင်းဖြစ်သည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// # #![feature(toowned_clone_into)]
    /// let mut s: String = String::new();
    /// "hello".clone_into(&mut s);
    ///
    /// let mut v: Vec<i32> = Vec::new();
    /// [1, 2][..].clone_into(&mut v);
    /// ```
    #[unstable(feature = "toowned_clone_into", reason = "recently added", issue = "41263")]
    fn clone_into(&self, target: &mut Self::Owned) {
        *target = self.to_owned();
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ToOwned for T
where
    T: Clone,
{
    type Owned = T;
    fn to_owned(&self) -> T {
        self.clone()
    }

    fn clone_into(&self, target: &mut T) {
        target.clone_from(self);
    }
}

/// Clone-on-write smart pointer ။
///
/// `Cow` အမျိုးအစားသည် clone-on-write လုပ်ဆောင်နိုင်စွမ်းကိုထောက်ပံ့ပေးသောစမတ်လက်ညှိုးတစ်ချောင်းဖြစ်သည်။ ၎င်းသည်ချေးယူထားသောဒေတာများကိုမပြောင်းလဲနိုင်သောအရာများပါဝင်စေနိုင်သည်။
///
/// အမျိုးအစားကို `Borrow` trait မှတစ်ဆင့်ယေဘူယျချေးယူထားသောဒေတာများနှင့်အလုပ်လုပ်ရန်ဒီဇိုင်းပြုလုပ်ထားသည်။
///
/// `Cow` `Deref` ကိုအကောင်အထည်ဖော်သည်၊ ဆိုလိုသည်မှာသင်သည်၎င်းတွင်ပါဝင်သောဒေတာများ၌သင် mutating non-mutating method များကိုတိုက်ရိုက်ခေါ်ဆိုနိုင်သည်။
/// အကယ်၍ mutation ကိုအလိုရှိပါက `to_mut` သည်ပိုင်ဆိုင်သောတန်ဖိုးတစ်ခုသို့ပြောင်းလဲနိုင်သောရည်ညွှန်းချက်ကိုရရှိလိမ့်မည်၊ လိုအပ်ပါကပုံတူပွားခြင်း။
///
/// သင်ရည်ညွှန်းရေတွက်ထောက်ပြလိုသည်ဆိုပါက [`Rc::make_mut`][crate::rc::Rc::make_mut] နှင့် [`Arc::make_mut`][crate::sync::Arc::make_mut] သည်ကိုယ်ပွား-on-write လုပ်ဆောင်ချက်များကိုလည်းထောက်ပံ့ပေးနိုင်သည်ကိုသတိပြုပါ။
///
/// # Examples
///
/// ```
/// use std::borrow::Cow;
///
/// fn abs_all(input: &mut Cow<[i32]>) {
///     for i in 0..input.len() {
///         let v = input[i];
///         if v < 0 {
///             // ပိုင်ဆိုင်ပြီးသားမဟုတ်ပါက vector ထဲသို့ Clone များထည့်ပါ။
///             input.to_mut()[i] = -v;
///         }
///     }
/// }
///
/// // `input` သည် mutation လုပ်ရန်မလိုအပ်သောကြောင့် clone မရှိပါ။
/// let slice = [0, 1, 2];
/// let mut input = Cow::from(&slice[..]);
/// abs_all(&mut input);
///
/// // ဘာလို့လဲဆိုတော့ `input` ကို mutate လုပ်ဖို့လိုလို့ပါပဲ။
/// let slice = [-1, 0, 1];
/// let mut input = Cow::from(&slice[..]);
/// abs_all(&mut input);
///
/// // `input` ကိုပိုင်ဆိုင်ထားပြီးဖြစ်သောကြောင့်မည်သည့်ပုံတူပွားများမဖြစ်ပေါ်ပါ။
/// let mut input = Cow::from(vec![-1, 0, 1]);
/// abs_all(&mut input);
/// ```
///
/// `Cow` ကို struct တစ်ခုထဲမှာဘယ်လိုထားမလဲဆိုတာပြတဲ့ဥပမာတစ်ခု။
///
/// ```
/// use std::borrow::Cow;
///
/// struct Items<'a, X: 'a> where [X]: ToOwned<Owned = Vec<X>> {
///     values: Cow<'a, [X]>,
/// }
///
/// impl<'a, X: Clone + 'a> Items<'a, X> where [X]: ToOwned<Owned = Vec<X>> {
///     fn new(v: Cow<'a, [X]>) -> Self {
///         Items { values: v }
///     }
/// }
///
/// // အချပ်တစ်ခု၏ချေးထားသောတန်ဖိုးများမှကွန်တိန်နာတစ်ခုကိုဖန်တီးသည်
/// let readonly = [1, 2];
/// let borrowed = Items::new((&readonly[..]).into());
/// match borrowed {
///     Items { values: Cow::Borrowed(b) } => println!("borrowed {:?}", b),
///     _ => panic!("expect borrowed value"),
/// }
///
/// let mut clone_on_write = borrowed;
/// // အချပ်မှဒေတာများကိုပိုင်ဆိုင်သော vec သို့ mutate လုပ်၍ တန်ဖိုးအသစ်တစ်ခုကိုထိပ်ဆုံးသို့တင်သည်
/// clone_on_write.values.to_mut().push(3);
/// println!("clone_on_write = {:?}", clone_on_write.values);
///
/// // အဆိုပါဒေတာ mutated ခဲ့သည်။ဒီဟာကိုကြည့်ကြည့်ရအောင်
/// match clone_on_write {
///     Items { values: Cow::Owned(_) } => println!("clone_on_write contains owned data"),
///     _ => panic!("expect owned data"),
/// }
/// ```
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Cow<'a, B: ?Sized + 'a>
where
    B: ToOwned,
{
    /// ချေးထားတဲ့အချက်အလက်။
    #[stable(feature = "rust1", since = "1.0.0")]
    Borrowed(#[stable(feature = "rust1", since = "1.0.0")] &'a B),

    /// ပိုင်ဆိုင်သည့်ဒေတာ။
    #[stable(feature = "rust1", since = "1.0.0")]
    Owned(#[stable(feature = "rust1", since = "1.0.0")] <B as ToOwned>::Owned),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<B: ?Sized + ToOwned> Clone for Cow<'_, B> {
    fn clone(&self) -> Self {
        match *self {
            Borrowed(b) => Borrowed(b),
            Owned(ref o) => {
                let b: &B = o.borrow();
                Owned(b.to_owned())
            }
        }
    }

    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (&mut Owned(ref mut dest), &Owned(ref o)) => o.borrow().clone_into(dest),
            (t, s) => *t = s.clone(),
        }
    }
}

impl<B: ?Sized + ToOwned> Cow<'_, B> {
    /// ဒေတာများကိုငှားရမ်းသည်ဆိုပါက true ပြန်သည်။ ဆိုလိုသည်မှာ `to_mut` သည်နောက်ထပ်အလုပ်လိုအပ်သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cow_is_borrowed)]
    /// use std::borrow::Cow;
    ///
    /// let cow = Cow::Borrowed("moo");
    /// assert!(cow.is_borrowed());
    ///
    /// let bull: Cow<'_, str> = Cow::Owned("...moo?".to_string());
    /// assert!(!bull.is_borrowed());
    /// ```
    #[unstable(feature = "cow_is_borrowed", issue = "65143")]
    #[rustc_const_unstable(feature = "const_cow_is_borrowed", issue = "65143")]
    pub const fn is_borrowed(&self) -> bool {
        match *self {
            Borrowed(_) => true,
            Owned(_) => false,
        }
    }

    /// ဒေတာပိုင်ဆိုင်လျှင်မှန်သည်၊ အကယ်၍ `to_mut` သည် op-no မဟုတ်ပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cow_is_borrowed)]
    /// use std::borrow::Cow;
    ///
    /// let cow: Cow<'_, str> = Cow::Owned("moo".to_string());
    /// assert!(cow.is_owned());
    ///
    /// let bull = Cow::Borrowed("...moo?");
    /// assert!(!bull.is_owned());
    /// ```
    #[unstable(feature = "cow_is_borrowed", issue = "65143")]
    #[rustc_const_unstable(feature = "const_cow_is_borrowed", issue = "65143")]
    pub const fn is_owned(&self) -> bool {
        !self.is_borrowed()
    }

    /// အချက်အလက်များ၏ပိုင်ပုံစံကိုတစ် ဦး mutable ရည်ညွှန်းရယူသည်။
    ///
    /// ၎င်းကိုပိုင်ဆိုင်ပြီးသားမဟုတ်ပါက Clone လုပ်ပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Cow;
    ///
    /// let mut cow = Cow::Borrowed("foo");
    /// cow.to_mut().make_ascii_uppercase();
    ///
    /// assert_eq!(
    ///   cow,
    ///   Cow::Owned(String::from("FOO")) as Cow<str>
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn to_mut(&mut self) -> &mut <B as ToOwned>::Owned {
        match *self {
            Borrowed(borrowed) => {
                *self = Owned(borrowed.to_owned());
                match *self {
                    Borrowed(..) => unreachable!(),
                    Owned(ref mut owned) => owned,
                }
            }
            Owned(ref mut owned) => owned,
        }
    }

    /// ပိုင်ဒေတာထုတ်ယူ။
    ///
    /// ၎င်းကိုပိုင်ဆိုင်ပြီးသားမဟုတ်ပါက Clone လုပ်ပါ။
    ///
    /// # Examples
    ///
    /// `Cow::Borrowed` တစ်ခုပေါ်တွင် `into_owned` ကိုခေါ်ခြင်းသည်အခြေခံအချက်အလက်များကိုပုံတူပွား။ `Cow::Owned` ဖြစ်လာသည်။
    ///
    ///
    /// ```
    /// use std::borrow::Cow;
    ///
    /// let s = "Hello world!";
    /// let cow = Cow::Borrowed(s);
    ///
    /// assert_eq!(
    ///   cow.into_owned(),
    ///   String::from(s)
    /// );
    /// ```
    ///
    /// `Cow::Owned` တစ်ခုပေါ်တွင် `into_owned` ကိုခေါ်ခြင်းသည်အဘယ်သူမျှမဖြစ်နိုင်ပါ။
    ///
    /// ```
    /// use std::borrow::Cow;
    ///
    /// let s = "Hello world!";
    /// let cow: Cow<str> = Cow::Owned(String::from(s));
    ///
    /// assert_eq!(
    ///   cow.into_owned(),
    ///   String::from(s)
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_owned(self) -> <B as ToOwned>::Owned {
        match self {
            Borrowed(borrowed) => borrowed.to_owned(),
            Owned(owned) => owned,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<B: ?Sized + ToOwned> Deref for Cow<'_, B> {
    type Target = B;

    fn deref(&self) -> &B {
        match *self {
            Borrowed(borrowed) => borrowed,
            Owned(ref owned) => owned.borrow(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<B: ?Sized> Eq for Cow<'_, B> where B: Eq + ToOwned {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<B: ?Sized> Ord for Cow<'_, B>
where
    B: Ord + ToOwned,
{
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, 'b, B: ?Sized, C: ?Sized> PartialEq<Cow<'b, C>> for Cow<'a, B>
where
    B: PartialEq<C> + ToOwned,
    C: ToOwned,
{
    #[inline]
    fn eq(&self, other: &Cow<'b, C>) -> bool {
        PartialEq::eq(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, B: ?Sized> PartialOrd for Cow<'a, B>
where
    B: PartialOrd + ToOwned,
{
    #[inline]
    fn partial_cmp(&self, other: &Cow<'a, B>) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<B: ?Sized> fmt::Debug for Cow<'_, B>
where
    B: fmt::Debug + ToOwned<Owned: fmt::Debug>,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {
            Borrowed(ref b) => fmt::Debug::fmt(b, f),
            Owned(ref o) => fmt::Debug::fmt(o, f),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<B: ?Sized> fmt::Display for Cow<'_, B>
where
    B: fmt::Display + ToOwned<Owned: fmt::Display>,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {
            Borrowed(ref b) => fmt::Display::fmt(b, f),
            Owned(ref o) => fmt::Display::fmt(o, f),
        }
    }
}

#[stable(feature = "default", since = "1.11.0")]
impl<B: ?Sized> Default for Cow<'_, B>
where
    B: ToOwned<Owned: Default>,
{
    /// ပါ ၀ င်သောတန်ဖိုးအတွက်ပုံမှန်တန်ဖိုးဖြင့်ပိုင်ဆိုင်သောနွား <'a, B> ကိုဖန်တီးသည်။
    fn default() -> Self {
        Owned(<B as ToOwned>::Owned::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<B: ?Sized> Hash for Cow<'_, B>
where
    B: Hash + ToOwned,
{
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + ToOwned> AsRef<T> for Cow<'_, T> {
    fn as_ref(&self) -> &T {
        self
    }
}

#[stable(feature = "cow_add", since = "1.14.0")]
impl<'a> Add<&'a str> for Cow<'a, str> {
    type Output = Cow<'a, str>;

    #[inline]
    fn add(mut self, rhs: &'a str) -> Self::Output {
        self += rhs;
        self
    }
}

#[stable(feature = "cow_add", since = "1.14.0")]
impl<'a> Add<Cow<'a, str>> for Cow<'a, str> {
    type Output = Cow<'a, str>;

    #[inline]
    fn add(mut self, rhs: Cow<'a, str>) -> Self::Output {
        self += rhs;
        self
    }
}

#[stable(feature = "cow_add", since = "1.14.0")]
impl<'a> AddAssign<&'a str> for Cow<'a, str> {
    fn add_assign(&mut self, rhs: &'a str) {
        if self.is_empty() {
            *self = Cow::Borrowed(rhs)
        } else if !rhs.is_empty() {
            if let Cow::Borrowed(lhs) = *self {
                let mut s = String::with_capacity(lhs.len() + rhs.len());
                s.push_str(lhs);
                *self = Cow::Owned(s);
            }
            self.to_mut().push_str(rhs);
        }
    }
}

#[stable(feature = "cow_add", since = "1.14.0")]
impl<'a> AddAssign<Cow<'a, str>> for Cow<'a, str> {
    fn add_assign(&mut self, rhs: Cow<'a, str>) {
        if self.is_empty() {
            *self = rhs
        } else if !rhs.is_empty() {
            if let Cow::Borrowed(lhs) = *self {
                let mut s = String::with_capacity(lhs.len() + rhs.len());
                s.push_str(lhs);
                *self = Cow::Owned(s);
            }
            self.to_mut().push_str(&rhs);
        }
    }
}