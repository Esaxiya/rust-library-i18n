#![stable(feature = "wake_trait", since = "1.51.0")]
//! ပြတ်တောင်းပြတ်တောင်းအလုပ်များနှင့်အလုပ်လုပ်ဘို့အမျိုးအစားများနှင့် Traits ။
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// အမှုဆောင်အရာရှိတစ် ဦး အပေါ်အလုပ်တစ်ခုနိုး၏အကောင်အထည်ဖော်မှု။
///
/// ဤ trait ကို [`Waker`] တစ်ခုဖန်တီးရန်အသုံးပြုနိုင်သည်။
/// Execoror တစ်ခုသည်ဤ trait ၏အကောင်အထည်ဖော်မှုကိုအဓိပ္ပါယ်ဖွင့်နိုင်သည်။ ၎င်းသည်၎င်း executor ပေါ်ရှိလုပ်ဆောင်မှုများကိုလွှဲပြောင်းရန် Waker တစ်ခုတည်ဆောက်ရန်၎င်းကိုအသုံးပြုနိုင်သည်။
///
/// ဤ trait သည် [`RawWaker`] တည်ဆောက်ခြင်းအတွက်မှတ်ဉာဏ်လုံခြုံပြီး Ergonomic ဆိုင်ရာရွေးချယ်စရာတစ်ခုဖြစ်သည်။
/// ၎င်းသည်အလုပ်တစ်ခုကိုနိုးရန်အသုံးပြုသောဒေတာများကို [`Arc`] တွင်သိမ်းဆည်းထားသောဘုံအမှုဆောင်အရာရှိဒီဇိုင်းကိုထောက်ပံ့သည်။
/// အချို့သော executors များ (အထူးသဖြင့် embedded systems အတွက်) သည်ဤ API ကိုအသုံးမပြုနိုင်ပါ။ ထို့ကြောင့်၎င်းစနစ်များအတွက် [`RawWaker`] သည်တည်ရှိနေသောကြောင့်ဖြစ်သည်။
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// တစ်ဦး future ကြာနှင့်လက်ရှိချည်ပေါ်ပြီးစီးဖို့ကပြေးသောအခြေခံ `block_on` function ကို။
///
/// **Note:** ဤဥပမာသည်ရိုးရှင်းမှုအတွက်မှန်ကန်မှုကိုကုန်သွယ်သည်။
/// အကျပ်အတည်းများကိုကာကွယ်ရန်ထုတ်လုပ်မှုအဆင့်အကောင်အထည်ဖော်မှုများသည်အလယ်အလတ်ဖုန်းခေါ်ဆိုမှုများနှင့် `thread::unpark` သို့ဆက်သွယ်မှုများကိုလည်းကိုင်တွယ်ရန်လိုအပ်လိမ့်မည်။
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// ခေါ်သည့်အခါလက်ရှိချည်နှိုးသော Waker ။
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// လက်ရှိချည်အပေါ်ပြီးစီးရန် future run ပါ။
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // pin အဆိုပါ future ကနေရာ၌ရှိနေသော်လည်းနိုင်ပါတယ်ဒါကြောင့်။
///     let mut fut = Box::pin(fut);
///
///     // future သို့သွားမည့်အခြေအနေအသစ်တစ်ခုကိုဖန်တီးပါ။
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // ပြီးစီးရန် future ကို run ။
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// ဒီအလုပ်ကိုနိုးပါ။
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Waker ကိုမသုံးပဲဒီအလုပ်ကိုနိုးပါ။
    ///
    /// အမှုဆောင်အရာရှိတစ် ဦး သည် waker ကိုမစားဘဲနှိုးရန်စျေးနှုန်းချိုသာသောနည်းလမ်းကိုထောက်ခံသည်ဆိုပါက၎င်းနည်းလမ်းကိုကျော်လွှားသင့်သည်။
    /// ပုံမှန်အားဖြင့်၎င်းသည် [`Arc`] ကို Clone လုပ်ပြီး [`wake`] ကို Clone တွင်ခေါ်ဆိုသည်။
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // လုံခြုံမှု-raw_waker သည်လုံခြုံစွာတည်ဆောက်သောကြောင့်၎င်းသည်လုံခြုံသည်
        // Arc ကနေ RawWaker<W>။
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: RawWaker တစ်ခုတည်ဆောက်ရန်ဤသီးသန့်လုပ်ဆောင်ချက်ကိုမဟုတ်ဘဲအသုံးပြုသည်
// ၎င်းကို `From<Arc<W>> for RawWaker` impl သို့ထည့်သွင်းရန်၊ `From<Arc<W>> for Waker` ၏လုံခြုံမှုသည်မှန်ကန်သော trait ပေးပို့မှုအပေါ်တွင်မမူတည်စေရန်၊ ၎င်းနှစ်ခုလုံးကဤလုပ်ဆောင်မှုကိုတိုက်ရိုက်နှင့်အတိအလင်းခေါ်ဆိုသည်။
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // ၎င်းကိုပုံတူကူးရန်အတွက် arc ၏ရည်ညွှန်းအရေအတွက်ကိုတိုးပါ။
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // တန်ဖိုးအားဖြင့်နိုးပါ။ Arc ကို Wake::wake function သို့ပြောင်းပါ
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // ရည်ညွှန်းခြင်းအားဖြင့်နိုးပါ၊ ၎င်းကိုမချမိစေရန် Waker ကို ManuallyDrop ဖြင့်ပတ်ပါ
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // drop အပေါ် Arc ၏ရည်ညွှန်းရေတွက် Decrement
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}