use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // `RawVec` API သည်မှားယွင်းစွာခွဲဝေချထားပေးသောနည်းလမ်းများကိုဖော်ထုတ်ခြင်းမရှိသောကြောင့် third-party allocators နှင့် `RawVec` အကြားပေါင်းစည်းမှုဆိုင်ရာစမ်းသပ်မှုတစ်ခုကိုရေးသားခြင်းသည်အနည်းငယ်ခက်ခဲသည်။ ထို့ကြောင့်ကျွန်ုပ်တို့သည်ခွဲဝေချထားပေးသူကုန်ဆုံးသွားသောအခါ (panic ကိုရှာဖွေတွေ့ရှိခြင်းထက် ကျော်လွန်၍) ဘာဖြစ်မည်ကိုမစစ်ဆေးနိုင်ပါ။
    //
    //
    // ၎င်းအစား `RawVec` နည်းစနစ်များသည်သိုလှောင်မှုကိုသိုလှောင်သည့်အခါအနည်းဆုံး Allocator API ကိုဖြတ်သန်းသွားသည်ကိုသာစစ်ဆေးသည်။
    //
    //
    //
    //
    //

    // ခွဲဝေရန်ကြိုးပမ်းမှုများမအောင်မြင်မီသတ်မှတ်ထားသောလောင်စာပမာဏကိုလောင်ကျွမ်းစေသောစကားမပြောနိုင်သောခွဲဝေချထားပေးသူ။
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (realloc ကိုဖြစ်ပေါ်စေသည်၊ ထို့ကြောင့် 50 + 150=200 ယူနစ်လောင်စာကိုသုံးနိုင်သည်)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // ပထမ ဦး စွာ `reserve` သည် `reserve_exact` ကဲ့သို့ခွဲဝေချထားသည်။
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 သည် 7 ထက်နှစ်ဆပိုများသည်၊ ထို့ကြောင့် `reserve` သည် `reserve_exact` ကဲ့သို့အလုပ်လုပ်သင့်သည်။
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // ၃ သည် ၁၂ ၏ထက်ဝက်အောက်မပြည့်သောကြောင့် `reserve` သည်အဆတိုးကြီးထွားရမည်။
        // ဒီစမ်းသပ်မှုကြီးထွားမှုအချက်ရေးသားချိန်မှာ 2 ဖြစ်တယ်, ဒါကြောင့်အသစ်ကစွမ်းရည်ကို 24 ဖြစ်ပါတယ်, သို့သော် 1.5 ၏ကြီးထွားအချက်ကိုလည်း OK ကိုဖြစ်ပါတယ်။
        //
        // ထို့ကြောင့်အခိုင်အမာအတွက် `>= 18` ။
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}