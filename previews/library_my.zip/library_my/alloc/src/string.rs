//! UTF-8-encoded, ကြီးထွားလာ string ကို။
//!
//! ဤ module တွင် [`String`] အမျိုးအစား၊ string များသို့ပြောင်းရန်အတွက် [`ToString`] trait နှင့် [`String`] များနှင့်အလုပ်လုပ်ခြင်းကြောင့်ဖြစ်ပေါ်လာနိုင်သည့်အမှားအယွင်းများများစွာပါဝင်သည်။
//!
//!
//! # Examples
//!
//! [`String`] အသစ်တစ်ခုကို string literal မှဖန်တီးရန်နည်းလမ်းများစွာရှိပါသည်။
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! [`String`] အသစ်တစ်ခုကိုရှိပြီးသားတစ်ခုမှသင်စုစည်းခြင်းဖြင့်ဖန်တီးနိုင်သည်
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! သင့်တွင်မှန်ကန်သော UTF-8 bytes ၏ vector ရှိပါက၎င်းကို [`String`] တစ်ခုပြုလုပ်နိုင်သည်။သင်လည်းပြောင်းပြန်လုပ်နိုင်ပါတယ်။
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // ဤ bytes များသည်မှန်ကန်ကြောင်းကျွန်ုပ်တို့သိသည်။ ထို့ကြောင့် `unwrap()` ကိုကျွန်ုပ်တို့သုံးမည်။
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// UTF-8-encoded, ကြီးထွားလာ string ကို။
///
/// `String` type သည် string ၏ contents များအပေါ်ပိုင်ဆိုင်မှုအများဆုံးအသုံးအများဆုံး string အမျိုးအစားဖြစ်သည်။၎င်းသည်ငှားရမ်းထားသော counterpart ဖြစ်သော [`str`] နှင့်ရင်းနှီးသောဆက်ဆံရေးရှိသည်။
///
/// # Examples
///
/// [`String::from`] နှင့် [a literal string][`str`] မှ `String` တစ်ခုဖန်တီးနိုင်သည်။
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// [`push`] နည်းလမ်းဖြင့် [`char`] ကို `String` နှင့်ပေါင်းနိုင်သည်၊ [`push_str`] နည်းလမ်းဖြင့် [`&str`] ကိုပေါင်းနိုင်သည်။
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// သင့်တွင် vector UTF-8 bytes ရှိပါက X0 [`from_utf8`] နည်းလမ်းဖြင့်၎င်းမှ `String` တစ်ခုကိုဖန်တီးနိုင်သည်။
///
/// ```
/// // တစ် ဦး vector အတွက်အချို့သော bytes
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // ဤ bytes များသည်မှန်ကန်ကြောင်းကျွန်ုပ်တို့သိသည်။ ထို့ကြောင့် `unwrap()` ကိုကျွန်ုပ်တို့သုံးမည်။
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `String`s သည်အမြဲတမ်းတရားဝင် UTF-8 ဖြစ်သည်။၎င်းတွင်အနည်းငယ်သက်ရောက်မှုများရှိသည်။ ပထမတစ်ခုမှာသင် UTF-8 string မလိုအပ်ပါက [`OsString`] ကိုစဉ်းစားပါ။ဒါဟာဆင်တူပေမယ့် UTF-8 သတ်မရှိဘဲ။ဒုတိယဆိုလိုသည်မှာသင်သည် `String` သို့စာရင်းမသွင်းနိုင်ခြင်းဖြစ်သည်။
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Indexing ကိုအမြဲတမ်းအလုပ်လုပ်ရန်ရည်ရွယ်ထားသော်လည်း UTF-8 encoding ကကျွန်ုပ်တို့အားထိုသို့လုပ်ရန်ခွင့်မပြုပါ။ထို့အပြင်အညွှန်းကိန်းကမည်သည့်အရာကိုပြန်ပို့ရမည်ကိုမသိရသေးပါ။ က byte၊ codepoint သို့မဟုတ် grapheme cluster ။
/// [`bytes`] နှင့် [`chars`] နည်းစနစ်များသည်ပထမနှစ်ချက်တွင်ကြားဖြတ်များကိုပြန်ပေးသည်။
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `String`s implement [`Deref`] `<Target=str>`, and so [`str`] 's နည်းလမ်းများအားလုံးကိုအမွေခံရသည်။ထို့အပြင်ဆိုလိုသည်မှာသင်သည် `String` ကို ampersand (`&`) သုံး၍ [`&str`] ကိုယူသော function သို့လွှဲပြောင်းနိုင်သည်။
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// ၎င်းသည် `String` မှ [`&str`] တစ်ခုကိုဖန်တီးပြီး၎င်းကိုလွှဲပြောင်းပေးလိမ့်မည်။ ပြောင်းလဲခြင်းသည်အလွန်စျေးသိပ်မကြီးသောကြောင့်အချို့သောအကြောင်းပြချက်များအတွက် `String` မလိုအပ်ပါကလုပ်ဆောင်ချက်များကို [`&str`] အားအငြင်းပွားမှုများအဖြစ်လက်ခံလိမ့်မည်။
///
/// အချို့သောကိစ္စရပ်များတွင် Rust သည်ဤပြောင်းလဲခြင်းကိုပြုလုပ်ရန် [`Deref`] coercion ဟုလူသိများသည်။အောက်ပါဥပမာတွင် [`&'a str`][`&str`] string slice သည် trait `TraitExample` ကိုအသုံးပြုသည်။ `example_func` function သည် trait ကိုအကောင်အထည်ဖော်သည့်အရာမှန်သမျှကိုလုပ်ဆောင်သည်။
/// ဤကိစ္စတွင် Rust သည်သွယ်ဝိုက်ပြောင်းလဲမှုနှစ်ခုပြုလုပ်ရန်လိုအပ်လိမ့်မည်၊ ၎င်းမှာ Rust လုပ်ရန်နည်းလမ်းမရှိပါ။
/// ထိုအကြောင်းကြောင့်အောက်ပါဥပမာသည် compile မဟုတ်ပါ။
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// အဲဒီအစားအလုပ်မလုပ်မယ်လို့ရွေးချယ်မှုနှစ်ခုရှိပါတယ်။ပထမတစ်ခုမှာ `example_func(&example_string);` လိုင်းကို `example_func(example_string.as_str());` သို့ပြောင်းရန်ဖြစ်သည်။ ၎င်းမှာ string0ice string string ကိုအတိအလင်းထုတ်ယူရန်နည်းလမ်း [`as_str()`] ကိုအသုံးပြုသည်။
/// ဒုတိယနည်းက `example_func(&example_string);` ကို `example_func(&*example_string);` သို့ပြောင်းသည်။
/// ဤကိစ္စတွင်ကျွန်ုပ်တို့သည် `String` ကို [`str`][`&str`] တစ်ခုသို့ရည်ညွှန်းပြီး [`str`][`&str`] ကို [`&str`] သို့ပြန်ပို့သည်။
/// ဒုတိယနည်းလမ်းမှာ ပို၍ ထူးခြားသည်၊ သို့သော်နှစ် ဦး စလုံးသည်ပြောင်းလဲခြင်းကိုလုံးလုံးလျားလျားပြောင်းလဲခြင်းအပေါ်မှီခိုခြင်းထက် ပို၍ ရှင်းလင်းစွာလုပ်ဆောင်ရန်လုပ်ဆောင်သည်။
///
/// # Representation
///
/// `String` ကိုအစိတ်အပိုင်းသုံးခုနဲ့ဖွဲ့စည်းထားပါတယ်။ အချို့သော bytes များအတွက် pointer၊ length နှင့် capacity တစ်ခုဖြစ်သည်။အဆိုပါ pointer သည်၎င်း၏ဒေတာများကိုသိမ်းဆည်းရန်အသုံးပြုသည့်အတွင်းပိုင်းကြားခံ `String` မှညွှန်ပြသည်။အရှည်ဆိုသည်မှာလက်ရှိကြားခံတွင်သိုလှောင်ထားသော bytes အရေအတွက်နှင့်စွမ်းရည်သည် bytes ရှိ buffer အရွယ်အစားဖြစ်သည်။
///
/// ထိုကဲ့သို့သောကဲ့သို့, အရှည်အမြဲလျော့နည်းသို့မဟုတ်စွမ်းရည်ညီမျှလိမ့်မည်။
///
/// ဤသည်ကြားခံအမြဲအမှိုက်ပုံပေါ်တွင်သိမ်းဆည်းထားသည်။
///
/// ဤအရာများကို [`as_ptr`], [`len`] နှင့် [`capacity`] နည်းလမ်းများဖြင့်ကြည့်နိုင်သည်။
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME vec_into_raw_parts တည်ငြိမ်သောအခါဤအရာကို Update လုပ်ပါ။
/// // String ၏ဒေတာများကိုအလိုအလျောက်ကျဆင်းအောင်တားဆီးပါ
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // ဇာတ်လမ်းကိုး bytes ရှိပါတယ်
/// assert_eq!(19, len);
///
/// // ကျွန်ုပ်တို့သည် String ကို ptr, len နှင့် capacity မှပြန်လည်တည်ဆောက်နိုင်သည်။
/// // အစိတ်အပိုင်းများမှန်ကန်မှုရှိစေရန်ကျွန်ုပ်တို့တွင်တာ ၀ န်ရှိသောကြောင့်ဤအချက်များအားလုံးသည်အန္တရာယ်ကင်းသည်။
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// အကယ်၍ `String` တွင်စွမ်းရည်အလုံအလောက်ရှိပါက၎င်းတွင်ထည့်သွင်းထားသည့်အရာများသည်ထပ်မံခွဲဝေချထားမှုမရှိပါ။ဥပမာဒီအစီအစဉ်ကိုစဉ်းစားပါ။
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// ဤသည်ကအောက်ပါ output ကိုပါလိမ့်မယ်:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// အစပိုင်းမှာတော့ကျွန်ုပ်တို့မှာမှတ်ဉာဏ်လုံးဝမရှိဘူး၊ ဒါပေမယ့် string ကိုဖြည့်လိုက်တာနဲ့၎င်းရဲ့စွမ်းဆောင်ရည်ကိုသင့်တော်စွာတိုးမြှင့်ပေးတယ်။အကယ်၍ ကျွန်ုပ်တို့သည်အစားထိုး [`with_capacity`] နည်းလမ်းကို အသုံးပြု၍ မှန်ကန်သောစွမ်းရည်ကိုကန ဦး ခွဲဝေပေးလျှင်။
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// ကျနော်တို့ကွဲပြားခြားနားသောရလဒ်နှင့်အတူတက်အဆုံးသတ်:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// ဒီနေရာမှာ loop အတွင်းမှာ memory တွေထပ်ထည့်စရာမလိုပါဘူး။
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// UTF-8 byte vector တစ်ခုမှ `String` တစ်ခုကိုပြောင်းလဲသောအခါဖြစ်နိုင်သောအမှားတန်ဖိုးတစ်ခု။
///
/// ဒီအမျိုးအစား [`String`] အပေါ် [`from_utf8`] နည်းလမ်းအတွက်အမှားအမျိုးအစားဖြစ်ပါတယ်။
/// ၎င်းသည်ပြန်လည်ခွဲဝေခြင်းများကိုဂရုတစိုက်ပြုလုပ်ရန်ဒီဇိုင်းထုတ်ထားခြင်းဖြစ်သည်။ [`into_bytes`] နည်းလမ်းသည်ပြောင်းလဲမှုကြိုးပမ်းမှုတွင်အသုံးပြုခဲ့သော byte vector ကိုပြန်ပေးလိမ့်မည်။
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// [`std::str`] မှပေးသော [`Utf8Error`] အမျိုးအစားသည် [`u8`] s ၏အချပ်ကို [`&str`] သို့ပြောင်းလဲသောအခါဖြစ်ပေါ်လာနိုင်သည့်အမှားတစ်ခုကိုဆိုလိုသည်။
/// ဤသဘောမျိုးဖြင့်၎င်းသည် `FromUtf8Error` နှင့်အလားတူပြီး `FromUtf8Error` မှ [`utf8_error`] နည်းလမ်းမှတစ်ခုကိုရယူနိုင်သည်။
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// အခြေခံအသုံးပြုမှု-
///
/// ```
/// // vector ထဲတွင်မမှန်ကန်တဲ့ bytes အချို့
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// UTF-16 byte slice တစ်ခုမှ `String` တစ်ခုကိုပြောင်းလဲသောအခါဖြစ်နိုင်သောအမှားတန်ဖိုးတစ်ခု။
///
/// ဒီအမျိုးအစား [`String`] အပေါ် [`from_utf16`] နည်းလမ်းအတွက်အမှားအမျိုးအစားဖြစ်ပါတယ်။
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// အခြေခံအသုံးပြုမှု-
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// အသစ်တစ်ခုကိုအချည်းနှီးသော `String` ဖန်တီးသည်။
    ///
    /// `String` သည်အချည်းနှီးဖြစ်သောကြောင့်၎င်းသည်မည်သည့်ကန ဦး ကြားခံကိုမျှခွဲဝေချထားပေးမည်မဟုတ်ပါ။ဆိုလိုသည်မှာဤကန ဦး စစ်ဆင်ရေးသည်အလွန်စျေးသိပ်မကြီးသော၊ သင်ဒေတာထည့်သောအခါနောင်တွင်အလွန်အကျွံခွဲဝေချထားမှုဖြစ်ပေါ်စေနိုင်သည်
    ///
    /// သင့်တွင် `String` အချက်အလက်မည်မျှသိမ်းမည်ကိုသင်စိတ်ကူးထားရှိပါကအလွန်အမင်းပြန်လည်ခွဲဝေမှုကိုကာကွယ်ရန် [`with_capacity`] နည်းလမ်းကိုစဉ်းစားပါ။
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// သီးခြားစွမ်းရည်ရှိသော `String` အသစ်တစ်ခုကိုဖန်တီးသည်။
    ///
    /// `String`s တွင်အချက်အလက်များကိုသိမ်းထားရန်အတွက် internal buffer ရှိသည်။
    /// အဆိုပါစွမ်းရည်သည်ထိုကြားခံ၏အရှည်ဖြစ်ပြီး [`capacity`] နည်းလမ်းဖြင့်မေးမြန်းနိုင်ပါသည်။
    /// ဤနည်းလမ်းသည်အချည်းနှီးသော `String` ကိုဖန်တီးသည်၊ သို့သော် `capacity` bytes ကိုကိုင်နိုင်သည့်ကန ဦး ကြားခံတစ်ခုပါရှိသည်။
    /// သင် `String` သို့ဒေတာအစုအဝေးတစ်ခုထပ်မံထည့်သွင်းခြင်းကလိုအပ်သောပြန်လည်နေရာချထားခြင်းများကိုလျှော့ချသောအခါ၎င်းသည်အသုံးဝင်သည်။
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// ပေးထားသောစွမ်းရည် `0` သည်ဆိုပါက, အဘယ်သူမျှခွဲဝေပေါ်ပေါက်လိမ့်မယ်, ဤနည်းလမ်း [`new`] နည်းလမ်းမှတူညီသည်။
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // String တွင်စွမ်းရည်ပိုမိုရှိသော်လည်းမည်သည့်အက္ခရာမျှမရှိပါ
    /// assert_eq!(s.len(), 0);
    ///
    /// // ဤအရာအားလုံးကိုပြန်လည်ခွဲဝေခြင်းမပြုဘဲပြုမိသည် ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... ဒါပေမယ့်ဒီ string ကို reallocate စေနိုင်သည်
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): cfg(test) နှင့်အတူဤနည်းလမ်းနှင့်အဓိပ္ပါယ်အတွက်လိုအပ်သောမွေးရာပါ `[T]::to_vec` နည်းလမ်းကိုမရရှိနိုင်ပါ။
    // စမ်းသပ်ခြင်းအတွက်ဤနည်းလမ်းကိုကျွန်ုပ်တို့မလိုအပ်သောကြောင့်၎င်းကို ထပ်မံ၍ အချက်အလက်များအတွက် slice.rs ရှိ slice::hack module ကိုကြည့်ပါ
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// bytes တစ်ခု vector ကို `String` တစ်ခုသို့ပြောင်းပေးသည်။
    ///
    /// ([`String`]) string ကို bytes ([`u8`]) နဲ့လုပ်ထားပြီး၊ vector bytes ([`Vec<u8>`]) က bytes နဲ့လုပ်ထားတာဖြစ်လို့ဒီ function ကနှစ်ခုကြားမှာပြောင်းသွားပါတယ်။
    /// သို့သော် byte slices အားလုံးသည် `String`s 'မမှန်ပါ။ `String` သည် UTF-8 အတွက်လိုအပ်သည်။
    /// `from_utf8()` bytes များသည်တရားဝင် UTF-8 ဟုတ်မဟုတ်သေချာစေရန်စစ်ဆေးပြီးနောက်ပြောင်းလဲခြင်းကိုပြုလုပ်သည်။
    ///
    /// အကယ်၍ byte slice သည် UTF-8 သည်မှန်ကန်ကြောင်းနှင့်သင်စစ်ဆေးမှု၏ overhead ကိုမခံယူလိုပါလျှင်ဤ function ၏လုံခြုံမှုမရှိသောဗားရှင်း-[`from_utf8_unchecked`] ရှိသည်။ ၎င်းသည်အတူတူပင်ပြုမူသော်လည်းထိုစစ်ဆေးမှုကိုကျော်သွားသည်။
    ///
    ///
    /// ထိရောက်မှုအတွက် vector ကိုကူးယူရန်ဤနည်းလမ်းသည်ဂရုစိုက်လိမ့်မည်။
    ///
    /// သင် `String` အစား [`&str`] တစ်ခုလိုအပ်ပါက [`str::from_utf8`] ကိုစဉ်းစားပါ။
    ///
    /// ဤနည်းလမ်း၏ပြောင်းပြန် [`into_bytes`] ဖြစ်ပါတယ်။
    ///
    /// # Errors
    ///
    /// ပေးထားသော bytes များသည် UTF-8 မဟုတ်သည့်အတွက်ဖော်ပြချက်တစ်ခုသည် UTF-8 မဟုတ်ပါက [`Err`] ကိုပြန်ပို့သည်။သင်ပြောင်းရွှေ့ခဲ့သော vector တွင်လည်းပါဝင်သည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// // တစ် ဦး vector အတွက်အချို့သော bytes
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // ဤ bytes များသည်မှန်ကန်ကြောင်းကျွန်ုပ်တို့သိသည်။ ထို့ကြောင့် `unwrap()` ကိုကျွန်ုပ်တို့သုံးမည်။
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// မမှန်ကန်ကြောင်းက bytes:
    ///
    /// ```
    /// // vector ထဲတွင်မမှန်ကန်တဲ့ bytes အချို့
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// သင်ဤအမှားနှင့်အတူသင်ဘာလုပ်နိုင်သည်နှင့်ပတ်သက်။ အသေးစိတ်ကို [`FromUtf8Error`] များအတွက် docs ကိုကြည့်ပါ။
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// မမှန်ကန်တဲ့အက္ခရာများအပါအ ၀ င် bytes တစ်ထပ်စီကို string တစ်ခုသို့ပြောင်းပေးသည်။
    ///
    /// String တွေကို bytes ([`u8`]) နဲ့လုပ်ထားတယ်။ ([`&[u8]`][byteslice]) အတိုတစ်ခုကို bytes နဲ့လုပ်တယ်။ ဒါကြောင့်ဒီ function ကနှစ်ခုကြားမှာပြောင်းသွားတယ်။byte slices အားလုံးသည်မှန်ကန်သော strings များမဟုတ်ပါ။ strings များသည် UTF-8 ဖြစ်သည်။
    /// ဤပြောင်းလဲမှုပြုလုပ်စဉ် `from_utf8_lossy()` သည်မမှန်ကန်သော UTF-8 အစီအစဉ်များကို [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] ဖြင့်အစားထိုးလိမ့်မည်။
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// အကယ်၍ သင် byte slice သည် UTF-8 သည်မှန်ကန်ကြောင်းနှင့်သင်တို့၏ပြောင်းလဲခြင်း၏ overhead ကိုမခံယူလိုလျှင်၊ ဤ function ၏လုံခြုံမှုမရှိသောဗားရှင်း [`from_utf8_unchecked`] သည်အလားတူအပြုအမူမျိုးရှိသော်လည်းစစ်ဆေးမှုများကိုကျော်သွားသည်။
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// ဒီ function ကတစ် ဦး [`Cow<'a, str>`] ပြန်လည်ရောက်ရှိ။ကျွန်ုပ်တို့၏ byte slice သည် UTF-8 သည်မမှန်ကန်ပါကကျွန်ုပ်တို့သည် string ၏အရွယ်အစားကိုပြောင်းလဲစေမည့်အစားထိုးအက္ခရာများကိုထည့်သွင်းရန်လိုအပ်သည်။ ထို့ကြောင့် `String` လိုအပ်သည်။
    /// ဒါပေမယ့် UTF-8 ရှိပြီးသားဆိုရင်၊ ကျွန်တော်တို့ခွဲတမ်းအသစ်မလိုအပ်ပါဘူး။
    /// ဒီ return type ကကိစ္စနှစ်ခုစလုံးကိုဖြေရှင်းဖို့ခွင့်ပြုတယ်။
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// // တစ် ဦး vector အတွက်အချို့သော bytes
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// မမှန်ကန်ကြောင်းက bytes:
    ///
    /// ```
    /// // မမှန်ကန်တဲ့ bytes အချို့
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// UTF-16-encoded vector `v` ကို `String` တစ်ခုထဲသို့ decode လုပ်ပါ၊ `v` မှာမမှန်ကန်တဲ့ data တွေပါရှိရင် [`Err`] ကိုပြန်သွားပါ။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // ဤအရာသည် collect မှတဆင့်မလုပ်ပါ။: : <Result<_, _>စွမ်းဆောင်ရည်အကြောင်းပြချက်များအတွက်> () ။
        // FIXME: #48994 ပိတ်သောအခါ function ကိုနောက်တဖန်ရိုးရှင်းနိုင်ပါတယ်။
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// UTF-16-encoded slice `v` ကို `String` တစ်ခုထဲသို့ decode လုပ်၍ မမှန်ကန်သောအချက်အလက်များကို [the replacement character (`U+FFFD`)][U+FFFD] နှင့်အစားထိုးပါ။
    ///
    /// [`Cow<'a, str>`] ကိုပြန်ပေးသည့် [`from_utf8_lossy`] နှင့်မတူဘဲ `from_utf16_lossy` သည် UTF-16 သို့ UTF-8 ကူးပြောင်းခြင်းသည်မှတ်ဥာဏ်ခွဲဝေမှုလိုအပ်သောကြောင့် `String` ကိုပြန်လည်ပေးသည်။
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// `String` ကို၎င်း၏ကုန်ကြမ်းအစိတ်အပိုင်းများအဖြစ်သို့ပြိုကွဲစေသည်။
    ///
    /// ညွှန်ပြထားသောကုန်ကြမ်းအမှတ်အသားကိုနောက်ခံဒေတာ၊ ကြိုး၏အရှည် (bytes ဖြင့်) နှင့် (bytes ဖြင့်) အချက်အလက်များ၏သတ်မှတ်ထားသောစွမ်းရည်သို့ပြန်သွားသည်။
    /// ဤရွေ့ကား [`from_raw_parts`] မှအငြင်းပွားမှုများကဲ့သို့တူညီသောနိုင်ရန်အတွက်တူညီသောအငြင်းပွားမှုများဖြစ်ကြသည်။
    ///
    /// ဤလုပ်ဆောင်မှုကိုခေါ်ဆိုပြီးနောက် `String` မှစီမံခန့်ခွဲခဲ့သောမှတ်ဉာဏ်အတွက်ခေါ်ဆိုသူသည်တာဝန်ရှိသည်။
    /// ဤသို့လုပ်ရန်တစ်ခုတည်းသောနည်းလမ်းမှာအညစ်အကြေး၊ အရှည်နှင့်စွမ်းရည်တို့ကို [`from_raw_parts`] function ဖြင့်အတူ `String` အဖြစ်သို့ပြောင်းလဲခြင်းဖြစ်ပြီးဖျက်စီးသူကိုသန့်ရှင်းရေးလုပ်ရန်ဖြစ်သည်။
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// `String` အသစ်တစ်ခုကိုအရှည်၊ လုပ်ဆောင်နိုင်စွမ်းနှင့် pointer မှဖန်တီးသည်။
    ///
    /// # Safety
    ///
    /// စစ်ဆေးမှုမလုပ်ရသေးသောလျော့ပါးသွားမည်ဖြစ်သည့်အရေအတွက်ကြောင့်၎င်းသည်အလွန်အန္တရာယ်ကင်းသည်။
    ///
    /// * `buf` ရှိမှတ်ဉာဏ်သည်စံသတ်မှတ်ထားသည့်စာကြည့်တိုက်အသုံးပြုသောတူညီသောခွဲဝေချထားပေးသူနှင့်ခွဲဝေထားရန်လိုအပ်သည်။
    /// * `length` `capacity` သည်ထိုထက်နည်းရမည်။
    /// * `capacity` မှန်ကန်သောတန်ဖိုးဖြစ်ရန်လိုအပ်သည်။
    /// * `buf` ရှိပထမဆုံး `length` bytes သည်တရားဝင် UTF-8 ဖြစ်ရန်လိုအပ်သည်။
    ///
    /// ယင်းတို့ကိုချိုးဖောက်ခြင်းသည်ခွဲဝေချထားပေးသူ၏အတွင်းပိုင်းဒေတာဖွဲ့စည်းပုံကိုပျက်စီးစေနိုင်သည်။
    ///
    /// `buf` ၏ပိုင်ဆိုင်မှုကို `String` သို့ထိရောက်စွာလွှဲပြောင်းသည်။ ထို့နောက်အလိုအလျောက်ညွှန်ပြသူမှမှတ်သားထားသည့်မှတ်ဉာဏ်ပါ ၀ င်မှုများကိုပြန်လည်ခွဲဝေချထားပေးနိုင်သည်သို့မဟုတ်ပြောင်းလဲနိုင်သည်။
    /// ဒီ function ကိုခေါ်ပြီးနောက်အခြားဘာမျှမ pointer ကိုအသုံးပြုသည်သေချာအောင်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME vec_into_raw_parts တည်ငြိမ်သောအခါဤအရာကို Update လုပ်ပါ။
    ///     // String ၏ဒေတာများကိုအလိုအလျောက်ကျဆင်းအောင်တားဆီးပါ
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// vector သည် bytes တစ်ခု၏ vector ကို `String` သို့ပြောင်းပြီး string သည်မှန်ကန်သော UTF-8 ပါ ၀ င်သည်ကိုပြောင်းလဲစေသည်။
    ///
    /// အသေးစိတ်အတွက်လုံခြုံသောဗားရှင်း [`from_utf8`] ကိုကြည့်ပါ။
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// ၄ င်း function သည်လုံခြုံမှုမရှိဘူး၊ ဘာလို့လဲဆိုတော့သူက bytes များမှန်ကန်စွာ UTF-8 ဟုတ်မဟုတ်ဆိုတာကိုမစစ်ဆေးသောကြောင့်ဖြစ်သည်။
    /// အကယ်၍ ဤကန့်သတ်ချက်ကိုချိုးဖောက်ပါက၎င်းသည် `String` ၏ future အသုံးပြုသူများနှင့်မှတ်ဉာဏ်လုံခြုံမှုမရှိသောပြissuesနာများဖြစ်ပေါ်စေနိုင်သည်။ စံစာကြည့်တိုက်မှကျန်ရှိနေသော `String`s သည် UTF-8 ဖြစ်သည်ဟုယူဆသည်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// // တစ် ဦး vector အတွက်အချို့သော bytes
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// `String` ကို byte vector အဖြစ်ပြောင်းသည်။
    ///
    /// ၎င်းသည် `String` ကိုအသုံးပြုသည်။ ထို့ကြောင့်၎င်းတွင်ပါ ၀ င်သောအရာများကိုကူးယူရန်မလိုအပ်ပါ။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// `String` တစ်ခုလုံးပါဝင်သော string အပိုင်းအစတစ်ခုကိုထုတ်ယူသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// `String` ကို mutable string slice တစ်ခုအဖြစ်ပြောင်းသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// ပေးထားသော string ကိုအချပ်ကိုဒီ `String` ရဲ့အဆုံးပေါ်ကိုချပေးသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// ဒီ `String` ရဲ့စွမ်းရည်ကို bytes နဲ့ return ပြန်ပေးတယ်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// `String` ၏စွမ်းရည်သည်အနည်းဆုံး `additional` bytes သည်၎င်း၏အရှည်ထက်ပိုကြီးသည်ကိုသေချာစေသည်။
    ///
    /// မကြာခဏပြန်လည်နေရာချထားခြင်းကိုတားဆီးရန်၎င်းကိုရွေးချယ်ပါကစွမ်းဆောင်ရည်ကို `additional` bytes ထက်ပိုပြီးတိုးနိုင်သည်။
    ///
    ///
    /// သင်ဤ "at least" အပြုအမူကိုမလိုချင်ပါက [`reserve_exact`] နည်းလမ်းကိုကြည့်ပါ။
    ///
    /// # Panics
    ///
    /// အသစ်ကစွမ်းရည် [`usize`] လျံလျှင် Panics ။
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// ဤသည်အမှန်တကယ်စွမ်းရည်ကိုတိုးမြှင့်မည်မဟုတ်ပါ:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s တွင်ယခုအရှည် 2 နှင့်စွမ်းရည် 10 ရှိပါတယ်
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // ကျွန်ုပ်တို့မှာနောက်ထပ်စွမ်းရည် ၈ ခုရှိတယ်၊
    /// s.reserve(8);
    ///
    /// // ... တကယ်တော့မတိုးပါဘူး
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// `String` ၏စွမ်းရည်သည်အရှည်ထက် `additional` bytes ပိုကြီးသည်ကိုသေချာစေသည်။
    ///
    /// အကယ်၍ သင်ခွဲဝေချထားပေးသူထက်ပိုမိုသိသည်မဟုတ်လျှင် [`reserve`] နည်းလမ်းကိုအသုံးပြုရန်စဉ်းစားပါ။
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// အသစ်ကစွမ်းရည် `usize` လျံလျှင် Panics ။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// ဤသည်အမှန်တကယ်စွမ်းရည်ကိုတိုးမြှင့်မည်မဟုတ်ပါ:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s တွင်ယခုအရှည် 2 နှင့်စွမ်းရည် 10 ရှိပါတယ်
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // ကျွန်ုပ်တို့မှာနောက်ထပ်စွမ်းရည် ၈ ခုရှိတယ်၊
    /// s.reserve_exact(8);
    ///
    /// // ... တကယ်တော့မတိုးပါဘူး
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// ပေးထားသော `String` တွင်ထည့်သွင်းရန်အနည်းဆုံး `additional` ထက်ပိုသောဒြပ်စင်များအတွက်စွမ်းရည်ကိုသိုလှောင်ရန်ကြိုးစားသည်။
    /// မကြာခဏပြန်လည်ခွဲဝေခြင်းများကိုရှောင်ရှားရန်စုဆောင်းခြင်းသည်နေရာပိုယူနိုင်သည်။
    /// `reserve` ကိုခေါ်ပြီးနောက်စွမ်းရည်သည် `self.len() + additional` ထက်ကြီးသည်သို့မဟုတ်ညီမျှသည်။
    /// စွမ်းရည်လုံလောက်ပြီးသားလျှင်ဘာမျှမလုပ်။
    ///
    /// # Errors
    ///
    /// အကယ်၍ စွမ်းရည်ပြည့်နေလျှင်၊ သို့မဟုတ်ခွဲဝေချထားသူမှမအောင်မြင်ပါကအမှားတစ်ခုကိုပြန်ပို့သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // မှတ်ဥာဏ်ကိုကြိုတင်စာရင်းသွင်းပါ
    ///     output.try_reserve(data.len())?;
    ///
    ///     // ယခုကျွန်ုပ်တို့ OOM သည်ကျွန်ုပ်တို့၏ရှုပ်ထွေးသောအလုပ်၏အလယ်တွင်မဖြစ်နိုင်ပါ
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// ပေးထားသော `String` တွင်ထည့်သွင်းရန်ပိုသော `additional` ဒြပ်စင်အတိအကျအတွက်အနည်းဆုံးစွမ်းရည်ကိုကြိုတင်ယူထားရန်ကြိုးစားသည်။
    ///
    /// `reserve_exact` ကိုခေါ်ပြီးနောက်စွမ်းရည်သည် `self.len() + additional` ထက်ကြီးသည်သို့မဟုတ်ညီမျှသည်။
    /// စွမ်းရည်ပြီးသားလျှင်ဘာမျှမလုပ်။
    ///
    /// ခွဲဝေချထားပေးသူသည်စုဆောင်းမှုကိုသူတောင်းလိုသောနေရာထက်ပိုပေးနိုင်ကြောင်းသတိပြုပါ။
    /// ထို့ကြောင့်စွမ်းရည်သည်အတိအကျအနည်းဆုံးဖြစ်ရန်မမှီခိုနိုင်ပါ။
    /// future ထည့်သွင်းမှုများပြုလုပ်ရန်မျှော်လင့်ပါက `reserve` ကို ဦး စားပေးမည်။
    ///
    /// # Errors
    ///
    /// အကယ်၍ စွမ်းရည်ပြည့်နေလျှင်၊ သို့မဟုတ်ခွဲဝေချထားသူမှမအောင်မြင်ပါကအမှားတစ်ခုကိုပြန်ပို့သည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // မှတ်ဥာဏ်ကိုကြိုတင်စာရင်းသွင်းပါ
    ///     output.try_reserve(data.len())?;
    ///
    ///     // ယခုကျွန်ုပ်တို့ OOM သည်ကျွန်ုပ်တို့၏ရှုပ်ထွေးသောအလုပ်၏အလယ်တွင်မဖြစ်နိုင်ပါ
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// ဤ `String` ၏စွမ်းရည်သည်၎င်း၏အရှည်နှင့်ကိုက်ညီသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// ဒီ `String` ရဲ့စွမ်းဆောင်ရည်ကိုအနိမ့်ဆုံးသို့လျော့ကျစေသည်။
    ///
    /// စွမ်းဆောင်ရည်သည်အနည်းဆုံးအရှည်နှင့်ထောက်ပံ့ထားသောတန်ဖိုးနှစ်ခုလုံးအတိုင်းအတာအထိကြီးမားသည်။
    ///
    ///
    /// လက်ရှိစွမ်းရည်နိမ့်ဆုံးကန့်သတ်ထက်လျော့နည်းသည်ဆိုပါကဤသည်ကိုမ op ဖြစ်ပါတယ်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// ပေးထားသော [`char`] ကိုဒီ `String` ရဲ့အဆုံးအထိပေးသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// ဒီ `String` ရဲ့ contents ရဲ့ byte slice တစ်ခုကို return ပြန်ပေးတယ်။
    ///
    /// ဤနည်းလမ်း၏ပြောင်းပြန် [`from_utf8`] ဖြစ်ပါတယ်။
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// ဒီ `String` ကိုသတ်မှတ်ထားသောအရှည်ကိုအတိုကောက်။
    ///
    /// အကယ်၍ `new_len` သည် string ၏လက်ရှိအရှည်ထက်ကြီးလျှင်၎င်းသည်အကျိုးသက်ရောက်မှုမရှိပါ။
    ///
    ///
    /// ဤနည်းလမ်းသည် string ၏သတ်မှတ်ထားသောစွမ်းရည်အပေါ်အကျိုးသက်ရောက်မှုမရှိကြောင်းသတိပြုပါ
    ///
    /// # Panics
    ///
    /// `new_len` တစ် [`char`] နယ်နိမိတ်ပေါ်မှာမုသာမပါလျှင် Panics ။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// string buffer မှနောက်ဆုံးအက္ခရာကိုဖယ်ရှားပြီးပြန်ပို့ပေးသည်။
    ///
    /// ဒီ `String` ဗလာဖြစ်လျှင် [`None`] ကိုပြန်ပို့သည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// ဤ `String` မှ [`char`] ကို byte အနေအထားဖြင့်ဖယ်ရှားပြီးပြန်ပို့သည်။
    ///
    /// ၎င်းသည်ကြားခံရှိဒြပ်စင်တိုင်းကိုကူးယူရန်လိုအပ်သောကြောင့်၎င်းသည် *O*(*n*) စစ်ဆင်ရေးတစ်ခုဖြစ်သည်။
    ///
    /// # Panics
    ///
    /// Panics သည် `idx` သည် `String` ၏အရှည်ထက်ကြီးသည်သို့မဟုတ်ညီမျှလျှင်သို့မဟုတ်၎င်းသည် [`char`] နယ်နိမိတ်ပေါ်တွင်မတည်ရှိပါက။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// အဆိုပါ `String` အတွက်ပုံစံ `pat` အပေါငျးတို့သပွဲစဉ်ဖယ်ရှားပါ။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// ကိုက်ညီမှုများကိုရှာဖွေတွေ့ရှိပြီးကြားဖြတ်တွက်ချက်မည်။ ထို့ကြောင့်ပုံစံများထပ်နေသည့်အခါပထမပုံစံကိုသာဖယ်ရှားလိမ့်မည်။
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // လုံခြုံမှု-start နှင့် end သည် utf8 byte boundaries per per အပေါ်တွင်ရှိသည်
        // ရှာဖွေသူစာရွက်စာတမ်းများ
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// အဆိုပါ predicate အားဖြင့်သတ်မှတ်ထားသောဇာတ်ကောင်သာဆက်လက်ထိန်းသိမ်းထားသည်။
    ///
    /// တစ်နည်းအားဖြင့် `c` အက္ခရာများအားလုံးကိုဖယ်ရှားပါ `f(c)` `false` ကိုပြန်ပေးသည်။
    /// ဤနည်းသည်မူလနေရာတွင်ဇာတ်ကောင်တစ်ခုချင်းစီကိုတစ်ကြိမ်တည်းသွားခြင်း၊ နေရာတွင်လည်ပတ်ခြင်းနှင့်ထိန်းသိမ်းထားသောစာလုံးများ၏အစဉ်ကိုထိန်းသိမ်းခြင်း။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// အမိန့်အတိအကျသည်အညွှန်းတစ်ခုကဲ့သို့ပြင်ပအခြေအနေကိုခြေရာခံရန်အသုံးဝင်သည်။
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // လာမည့် char မှ IDX ပွိုင့်
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// ဇာတ်ကောင်ကိုဒီ `String` သို့ byte အနေအထားဖြင့်ထည့်သည်။
    ///
    /// ၎င်းသည်ကြားခံရှိဒြပ်စင်တိုင်းကိုကူးယူရန်လိုအပ်သောကြောင့်၎င်းသည် *O*(*n*) စစ်ဆင်ရေးတစ်ခုဖြစ်သည်။
    ///
    /// # Panics
    ///
    /// Panics သည် `idx` သည် `String` ၏အရှည်ထက်ကြီးလျှင်သို့မဟုတ်၎င်းသည် [`char`] နယ်နိမိတ်ပေါ်တွင်မတည်ရှိပါက။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// ဤ `String` သို့ string အချပ်ကို byte position တွင်ထည့်သည်။
    ///
    /// ၎င်းသည်ကြားခံရှိဒြပ်စင်တိုင်းကိုကူးယူရန်လိုအပ်သောကြောင့်၎င်းသည် *O*(*n*) စစ်ဆင်ရေးတစ်ခုဖြစ်သည်။
    ///
    /// # Panics
    ///
    /// Panics သည် `idx` သည် `String` ၏အရှည်ထက်ကြီးလျှင်သို့မဟုတ်၎င်းသည် [`char`] နယ်နိမိတ်ပေါ်တွင်မတည်ရှိပါက။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// ဒီ `String` ရဲ့ contents တစ်ခု mutable ရည်ညွှန်းပြန်သွားသည်။
    ///
    /// # Safety
    ///
    /// ၄ င်း function သည်လုံခြုံမှုမရှိဘူး၊ ဘာလို့လဲဆိုတော့သူက bytes များမှန်ကန်စွာ UTF-8 ဟုတ်မဟုတ်ဆိုတာကိုမစစ်ဆေးသောကြောင့်ဖြစ်သည်။
    /// အကယ်၍ ဤကန့်သတ်ချက်ကိုချိုးဖောက်ပါက၎င်းသည် `String` ၏ future အသုံးပြုသူများနှင့်မှတ်ဉာဏ်လုံခြုံမှုမရှိသောပြissuesနာများဖြစ်ပေါ်စေနိုင်သည်။ စံစာကြည့်တိုက်မှကျန်ရှိနေသော `String`s သည် UTF-8 ဖြစ်သည်ဟုယူဆသည်။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// ဒီ `String` ရဲ့အရှည်ကို bytes နဲ့ return ပြန်ပေးပါတယ်။
    /// တနည်းအားဖြင့်လူသားတစ် ဦး သည်ကြိုး၏အရှည်ကိုစဉ်းစားသောအရာမဟုတ်ပါ။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// ဤ `String` တွင်သုညအရှည်ရှိပြီး `false` ရှိပါက `true` သို့ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// ပေးထားတဲ့ byte အညွှန်းကိန်းမှာ string ကိုနှစ်ပိုင်းခွဲလိုက်တယ်။
    ///
    /// အသစ်တစ်ခုကိုခွဲဝေ `String` ပြန်သွားသည်။
    /// `self` bytes `[0, at)` ပါရှိသည်။ ပြန်လာသော `String` တွင် bytes `[at, len)` ပါရှိသည်။
    /// `at` တစ် ဦး UTF-8 ကုဒ်အမှတ်၏နယ်နိမိတ်ပေါ်မှာဖြစ်ရပါမည်။
    ///
    /// သတိပြုရမည်မှာ `self` ၏စွမ်းရည်သည်မပြောင်းလဲပါ။
    ///
    /// # Panics
    ///
    /// X0 `at` သည် `UTF-8` ကုဒ်အမှတ်နယ်နိမိတ်မဟုတ်လျှင်သို့မဟုတ်၎င်းသည် string ၏နောက်ဆုံးကုဒ်အမှတ်ထက်ကျော်လွန်ပါက Panics ။
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// မာတိကာအားလုံးကိုဖယ်ရှား, ဒီ `String` ကို Truncates ။
    ///
    /// ဆိုလိုသည်မှာ `String` သည်သုညအရှည်ရှိသော်လည်း၎င်းသည်၎င်း၏စွမ်းဆောင်ရည်ကိုမထိပါ။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// `String` အတွင်းရှိသတ်မှတ်ထားသောအကွာအဝေးကိုဖယ်ရှားပြီးဖယ်ရှားပစ်သည့် `chars` ကိုထုတ်ပေးသည့်ရေထုပ်ကိုကြားဖြတ်ဖန်တီးပေးသည်။
    ///
    ///
    /// Note: ကြားမှာအဆုံးအထိမသုံးရင်တောင် element range ကိုဖယ်ထုတ်လိုက်တယ်။
    ///
    /// # Panics
    ///
    /// Panics သည်စမှတ်သို့မဟုတ်အဆုံးအမှတ်သည် [`char`] နယ်နိမိတ်ပေါ်တွင်မတည်ရှိပါကသို့မဟုတ်၎င်းတို့သည်အကန့်အသတ်မရှိဖြစ်ပါက။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // string ကိုကနေβသည်အထိအကွာအဝေးအထိဖယ်ရှားပါ
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // တစ် ဦး ကအပြည့်အဝအကွာအဝေး string ကိုရှင်းလင်းရေး
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // မှတ်ဉာဏ်လုံခြုံမှု
        //
        // Drain ၏ String ဗားရှင်းတွင် vector ဗားရှင်း၏မှတ်ဉာဏ်လုံခြုံမှုဆိုင်ရာပြissuesနာများမရှိပါ။
        // ဒေတာကလွင်ပြင်က bytes ပဲ။
        // အကွာအဝေးဖယ်ရှားရေး Drop တွင်ဖြစ်ပျက်သောကြောင့်, Drain ကြားမှာပေါက်ကြားလျှင်, ဖယ်ရှားရေးဖြစ်ပျက်လိမ့်မည်မဟုတ်ပါ။
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // တစ်ပြိုင်နက်တည်းချေးနှစ်ချောင်းကိုယူပါ။
        // Drop တွင်, ကြားမှာပြီးဆုံးသည်အထိ &mut String ကိုအသုံးပြုလိမ့်မည်မဟုတ်ပါ။
        let self_ptr = self as *mut _;
        // လုံခြုံမှု-`slice::range` နှင့် `is_char_boundary` တို့သည်သင့်လျော်သောသတ်မှတ်ချက်များကိုစစ်ဆေးသည်။
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// သတ်မှတ်ထားသောအကွာအဝေးကို string ထဲမှာဖယ်ရှားပြီးပေးထားသော string နဲ့အစားထိုးလိုက်သည်။
    /// ပေးထားသော string သည် range နှင့်တူညီသောအရှည်မလိုအပ်ပါ။
    ///
    /// # Panics
    ///
    /// Panics သည်စမှတ်သို့မဟုတ်အဆုံးအမှတ်သည် [`char`] နယ်နိမိတ်ပေါ်တွင်မတည်ရှိပါကသို့မဟုတ်၎င်းတို့သည်အကန့်အသတ်မရှိဖြစ်ပါက။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // string ကိုကနေβသည်အထိအကွာအဝေးကိုတက်အစားထိုးပါ
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // မှတ်ဉာဏ်လုံခြုံမှု
        //
        // Replace_range တွင် vector Splice ၏မှတ်ဉာဏ်လုံခြုံမှုပြissuesနာမရှိပါ။
        // အဆိုပါ vector ဗားရှင်း၏။ဒေတာကလွင်ပြင်က bytes ပဲ။

        // သတိပေးချက်-ဤ variable ကိုထည့်သွင်းခြင်းသည် (#81138) မအောင်မြင်ပါ
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // သတိပေးချက်-ဤ variable ကိုထည့်သွင်းခြင်းသည် (#81138) မအောင်မြင်ပါ
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // `range` ကိုထပ်မံအသုံးပြုခြင်းသည်မလွယ်ကူပါ။ (#81138) ကျွန်ုပ်တို့သည် `range` မှဖော်ပြသောကန့်သတ်ချက်များသည်အတူတူပင်ဖြစ်သည်ဟုယူဆသည်၊ သို့သော်ရန်ဘက်ပြုသောအကောင်အထည်ဖော်မှုသည်ဖုန်းခေါ်ဆိုမှုများအကြားပြောင်းလဲနိုင်သည်
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// ဒီ `String` ကို [`Box`]`<`[`str`] `>` သို့ပြောင်းပေးသည်။
    ///
    /// ဤသည်မဆိုပိုလျှံစွမ်းရည်ကျဆင်းပါလိမ့်မယ်။
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// `String` တစ်ခုသို့ပြောင်းလဲရန်ကြိုးပမ်းခဲ့သော [`u8`] s bytes ၏အချပ်ကိုပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// // vector ထဲတွင်မမှန်ကန်တဲ့ bytes အချို့
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// `String` တစ်ခုသို့ပြောင်းရန်ကြိုးစားသော bytes များကိုပြန်ပို့သည်။
    ///
    /// ခွဲဝေခြင်းကိုရှောင်ရှားရန်ဤနည်းလမ်းကိုဂရုတစိုက်တည်ဆောက်ထားသည်။
    /// ၎င်းသည်အမှားများကိုလောင်ကျွမ်းစေပြီး၊ bytes များကိုဖယ်ထုတ်ခြင်းကြောင့် bytes များ၏မိတ္တူတစ်ခုပြုလုပ်ရန်မလိုအပ်ပါ။
    ///
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// // vector ထဲတွင်မမှန်ကန်တဲ့ bytes အချို့
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// ပြောင်းလဲခြင်းပျက်ကွက်မှုနှင့် ပတ်သက်၍ အသေးစိတ်အချက်အလက်များရရှိရန် `Utf8Error` တစ်ခုကိုခေါ်ယူပါ။
    ///
    /// [`std::str`] မှပေးသော [`Utf8Error`] အမျိုးအစားသည် [`u8`] s ၏အချပ်ကို [`&str`] သို့ပြောင်းလဲသောအခါဖြစ်ပေါ်လာနိုင်သည့်အမှားတစ်ခုကိုဆိုလိုသည်။
    /// ဤအဓိပ္ပာယ်ဖွင့်ဆိုချက်သည် `FromUtf8Error` နှင့်အလားတူသည်။
    /// ၎င်းကိုအသုံးပြုခြင်းနှင့် ပတ်သက်၍ အသေးစိတ်အချက်အလက်များအတွက်၎င်း၏မှတ်တမ်းကိုကြည့်ပါ။
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// // vector ထဲတွင်မမှန်ကန်တဲ့ bytes အချို့
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // ပထမက byte ကဒီမှာမမှန်ကန်ပါ
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // အဘယ်ကြောင့်ဆိုသော် `String`s 'ကိုကျော်။ သွားသောကြောင့်ကျွန်ုပ်တို့သည်ကြားခံမှပထမဆုံး string ကိုယူပြီးနောက်ဆက်တွဲ string များအားထပ်ဖြည့်ခြင်းအားဖြင့်အနည်းဆုံးခွဲဝေမှုတစ်ခုကိုရှောင်ရှားနိုင်သည်။
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // ကျွန်တော်တို့က CoWs ကိုကျော်ပြီးလုပ်နေကြလို့ပါ။ (potentially) ကပထမပစ္စည်းကိုရယူပြီးနောက်ဆက်တွဲပစ္စည်းများအားလုံးကိုဖြည့်စွက်ခြင်းအားဖြင့်အနည်းဆုံးခွဲဝေမှုတစ်ခုကိုရှောင်ရှားနိုင်ပါတယ်။
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// `&str` အတွက် impl မှလွှဲပေးလိုက်သောအဆင်ပြေမှုတစ်ခုဖြစ်သည်။
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// တစ် ဦး အချည်းနှီးသော `String` ဖန်တီး။
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// ကြိုးနှစ်ချပ်ကို `+` အော်ပရေတာကအကောင်အထည်ဖော်သည်။
///
/// ၎င်းသည်ဘယ်ဘက်ခြမ်းရှိ `String` ကိုစားသုံးပြီး၎င်း၏ buffer ကိုပြန်လည်အသုံးပြုသည် (လိုအပ်လျှင်ကြီးထွားလာသည်) ။
/// ၎င်းသည် `String` အသစ်တစ်ခုကိုခွဲဝေချထားခြင်းနှင့်လုပ်ဆောင်မှုတိုင်းတွင်ပါ ၀ င်သည့်အရာအားလုံးကိုကူးယူခြင်းကိုရှောင်ရှားရန်ပြုလုပ်သည်။ ၎င်းသည်ထပ်ခါတလဲလဲဆက်စပ်မှုများဖြင့် *n*-byte string ကိုတည်ဆောက်သည့်အခါ *O*(*n*^ 2) အချိန်လည်ပတ်မှုဆီသို့ ဦး တည်စေသည်။
///
///
/// လက်ျာဘက်၌ရှိသော string ကိုသာချေးယူသည်,၎င်း၏ contents တွေကိုပြန်လာသော `String` သို့ကူးယူထားပါသည်။
///
/// # Examples
///
/// နှစ်ခု Concatenating `String`s တန်ဖိုးကိုနေဖြင့်ပထမဦးဆုံးကြာနှင့်ဒုတိယငှါး:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` ပြောင်းရွှေ့ခြင်းနှင့်မရှိတော့ဒီမှာအသုံးပွုနိုငျသညျ။
/// ```
///
/// သင်ပထမ ဦး ဆုံး `String` ကိုဆက်သုံးချင်ပါက၎င်းကိုကိုယ်ပုံတူကူးယူပြီးကိုယ်ပွားပုံစံသို့အစားထိုးနိုင်သည်။
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` ဒီနေရာမှာတရားဝင်နေဆဲဖြစ်သည်။
/// ```
///
/// `&str` အချပ်များကိုစုစည်းထားသောပထမ ဦး ဆုံး `String` သို့ပြောင်းလဲခြင်းဖြင့်ပြုလုပ်နိုင်သည်။
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// `+=` ကိုပေါင်းထည့်ရန်အတွက် `+=` အော်ပရေတာကိုအကောင်အထည်ဖော်သည်။
///
/// ဤသည် [`push_str`][String::push_str] နည်းလမ်းနှင့်အတူတူပင်အပြုအမူရှိပါတယ်။
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// [`Infallible`] အတွက်အမျိုးအစားနာမည်တစ်ခု
///
/// ဤသည် alias ကိုနောက်ပြန်လိုက်ဖက်တဲ့အဘို့တည်ရှိနှင့်နောက်ဆုံးတွင်ကန့်ကွက်နိုင်ပါသည်။
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// တန်ဖိုးတစ်ခုကို `String` သို့ပြောင်းရန်အတွက် trait ။
///
/// [`Display`] 0000Z ကိုအကောင်အထည်ဖော်သောမည်သည့်အမျိုးအစားအတွက်မဆိုဤ trait ကိုအလိုအလျောက်အကောင်အထည်ဖော်သည်။
/// ထို့ကြောင့် `ToString` ကိုတိုက်ရိုက်အကောင်အထည်မဖော်သင့်ပါ။
/// [`Display`] အစား `ToString` အကောင်အထည်ဖော်မှုကိုအခမဲ့ရယူသင့်ပါတယ်။
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// ပေးထားသောတန်ဖိုးကို `String` သို့ပြောင်းပေးသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// ဒီအကောင်အထည်ဖော်မှုအတွက်, `to_string` နည်းလမ်း panics အဆိုပါ `Display` အကောင်အထည်ဖော်မှုအမှားတစ်ခုပြန်လာလျှင်။
/// `fmt::Write for String` သည်အမှားတစ်ခုကိုမိမိဘာသာပြန်လည်မပေးသောကြောင့်ဤအချက်သည်မမှန်ကန်သော `Display` အကောင်အထည်ဖော်မှုကိုပြသည်။
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // ယေဘူယျလမ်းညွှန်သည်ယေဘူယျလုပ်ဆောင်ချက်များကိုမဖော်ပြရန်ဖြစ်သည်။
    // သို့သော်ဤနည်းလမ်းမှ `#[inline]` ကိုဖယ်ရှားခြင်းသည်အရေးမကြီးသောဆုတ်ယုတ်မှုကိုဖြစ်စေသည်။
    // <https://github.com/rust-lang/rust/pull/74852> ကို၎င်းဖယ်ရှားရန်နောက်ဆုံးကြိုးစားမှုကိုကြည့်ပါ။
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// `&mut str` ကို `String` အဖြစ်ပြောင်းပေးသည်။
    ///
    /// ရလဒ်ကိုအမှိုက်ပုံပေါ်တွင်ခွဲဝေချထားသည်။
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: ဤနေရာတွင်အမှားများဖြစ်ပေါ်စေသော libstd ကိုစစ်ဆေးသည်
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// ပေးထားသော boxed `str` အချပ်ကို `String` အဖြစ်ပြောင်းသည်။
    /// `str` အချပ်ကိုပိုင်ဆိုင်သည်မှာထင်ရှားသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// ပေးထားသော `String` ကိုပိုင်ဆိုင်သည့် box box `str` အချပ်အဖြစ်ပြောင်းပေးသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// string အချပ်ကိုချေးထားတဲ့မူကွဲသို့ပြောင်းသည်။
    /// အမှိုက်ပုံခွဲဝေမှုလုပ်ဆောင်ခြင်းမရှိပါ၊ ကြိုးမျှင်မကူးပါ။
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// တစ် ဦး String တစ်ခုပိုင်ဆိုင်မူကွဲသို့ပြောင်းလဲ။
    /// အမှိုက်ပုံခွဲဝေမှုလုပ်ဆောင်ခြင်းမရှိပါ၊ ကြိုးမျှင်မကူးပါ။
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// တစ် ဦး String ကိုကိုးကားတဲ့ငှားရမ်းမူကွဲသို့ပြောင်းလဲ။
    /// အမှိုက်ပုံခွဲဝေမှုလုပ်ဆောင်ခြင်းမရှိပါ၊ ကြိုးမျှင်မကူးပါ။
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// ပေးထားသော `String` ကို vector `Vec` သို့အမျိုးအစား `u8` တန်ဖိုးများကိုပြောင်းပေးသည်။
    ///
    /// # Examples
    ///
    /// အခြေခံအသုံးပြုမှု-
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// `String` အတွက်တစ် ဦး ကဖျန်ကြားမှာ။
///
/// ဤသည် struct [`String`] အပေါ် [`drain`] နည်းလမ်းအားဖြင့်ဖန်တီးထားသည်။
/// ပိုမိုသိရှိလိုပါက၎င်း၏စာရွက်စာတမ်းများကိုကြည့်ပါ။
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// ဖျက်ဆီးခြင်းတွင် mut String အဖြစ်&'သုံးမည်
    string: *mut String,
    /// ဖယ်ရှားပစ်ရန်အစိတ်အပိုင်း၏အစ
    start: usize,
    /// ဖယ်ရှားပစ်ရန်တစ်စိတ်တစ်ပိုင်း၏အဆုံး
    end: usize,
    /// ဖယ်ရှားပစ်ရန်လက်ရှိကျန်ရှိသောအကွာအဝေး
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Vec::drain ကိုသုံးပါ။
            // "Reaffirm" panic ကုဒ်ကိုထပ်မံထည့်သွင်းခြင်းကိုရှောင်ရှားရန်ဘောင်များသည်စစ်ဆေးသည်။
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// ကျန်ရှိနေသော (sub) string ကိုဤကြားမှာ၏အချပ်အဖြစ်ပြန်သွားသည်။
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: တည်ငြိမ်သည့်အခါ AsRef ၏အောက်ခြေမှတ်ချက်
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// `string_drain_as_str` ကိုတည်ငြိမ်သောအခါမကျေနပ်မှု။
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>Drain အတွက် <'a> {fn as_ref(&self)-> &str {အတွက်)
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// Drain အတွက် <<a> AsRef <[u8]> အဓိပ္ပာယ်သက်ရောက် <a a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}