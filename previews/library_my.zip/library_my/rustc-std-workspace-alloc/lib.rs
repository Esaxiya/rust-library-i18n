#![feature(no_core)]
#![no_core]

// ဤ crate သည်အဘယ်ကြောင့်လိုအပ်သည်ကို rustc-std-workspace-core ကိုကြည့်ပါ။

// liballoc ရှိ alloc module နှင့်ပingိပက္ခမဖြစ်စေရန် crate ကိုအမည်ပြောင်းပါ။
extern crate alloc as foo;

pub use foo::*;