use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri on liian hidas
fn exact_sanity_test() {
    // Tämä testi suoritetaan loppuun, minkä voin vain olettaa olevan `exp2`-kirjastotoiminnon kulma-ish tapaus, joka on määritelty missä tahansa C-ajonaikassa.
    // VS 2013: ssa tällä toiminnolla oli ilmeisesti vika, koska tämä testi epäonnistui linkitettynä, mutta VS 2015: n kanssa vika näyttää olevan kiinteä, kun testi toimii hyvin.
    //
    // Virhe näyttää olevan ero `exp2(-1057)`: n palautusarvossa, jossa VS 2013: ssa se palauttaa kaksinkertaisen bittikuvion 0x2 kanssa ja VS 2015: ssä 0x20000.
    //
    //
    // Ohita nyt vain tämä testi kokonaan MSVC: llä, koska se on joka tapauksessa testattu muualla, emmekä ole kovin kiinnostuneita testaamaan jokaisen alustan exp2-toteutusta.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}