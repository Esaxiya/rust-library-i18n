use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Tämä ei ole vakaa pinta-ala, mutta auttaa pitämään `?`: n halpaa niiden välillä, vaikka LLVM ei aina pysty hyödyntämään sitä heti.
    //
    // (Valitettavasti tulos ja vaihtoehto ovat epäjohdonmukaisia, joten ControlFlow ei voi sovittaa molempia.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}