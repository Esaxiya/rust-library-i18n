use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Tämä trait tarjoaa transitiivisen pääsyn lähde-vaiheeseen interaattori-sovitinputkessa olosuhteissa
/// * iteraattorilähde `S` itse toteuttaa `SourceIter<Source = S>`: n
/// * tämä trait on delegoitu toteutus jokaiselle lähteen ja putkikuluttajan välisessä putkessa olevalle sovittimelle.
///
/// Kun lähde on omistava iteraattorirakenne (kutsutaan yleisesti nimellä `IntoIter`), tästä voi olla hyötyä erikoistumalla [`FromIterator`]-toteutuksiin tai palauttamalla jäljellä olevat elementit iteraattorin osittaisesta loppuun saamisesta.
///
///
/// Huomaa, että toteutusten ei välttämättä tarvitse tarjota pääsyä putkilinjan sisimpään lähteeseen.Tilallinen välisovitin saattaa innokkaasti arvioida osan putkilinjasta ja paljastaa sen sisäisen tallennustilan lähteeksi.
///
/// trait on vaarallinen, koska toteuttajien on noudatettava muita turvallisuusominaisuuksia.
/// Katso lisätietoja [`as_inner`]: stä.
///
/// # Examples
///
/// Osittain kulutetun lähteen haku:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Lähdevaihe iteraattoriputkessa.
    type Source: Iterator;

    /// Hae iteraattoriputken lähde.
    ///
    /// # Safety
    ///
    /// Toteutusten on palautettava sama muuttuva viite elinaikanaan, ellei soittaja korvaa niitä.
    /// Soittajat voivat korvata viitteen vasta lopetettuaan iteroinnin ja pudottaen iteraattoriputken lähteen purkamisen jälkeen.
    ///
    /// Tämä tarkoittaa, että iteraattorisovittimet voivat luottaa siihen, että lähde ei muutu iteroinnin aikana, mutta he eivät voi luottaa siihen Drop-toteutuksissaan.
    ///
    /// Tämän menetelmän käyttöönotto tarkoittaa, että sovittimet luopuvat vain yksityisen pääsyn lähteelleen ja voivat luottaa vain menetelmän vastaanottotyyppien perusteella tehtyihin takuisiin.
    /// Rajoitetun pääsyn puute edellyttää myös, että sovittimien on pidettävä yllä lähteen julkista sovellusliittymää, vaikka heillä olisi pääsy sen sisäisiin osiin.
    ///
    /// Soittajien on puolestaan odotettava, että lähde on missä tahansa tilassa, joka on yhdenmukainen sen julkisen sovellusliittymän kanssa, koska sen ja lähteen välissä istuvilla sovittimilla on sama pääsy.
    /// Erityisesti sovitin on saattanut kuluttaa enemmän elementtejä kuin ehdottoman välttämätöntä.
    ///
    /// Näiden vaatimusten yleisenä tavoitteena on antaa kuluttajalle mahdollisuus käyttää putkistoa
    /// * mikä jää lähteeseen iteroinnin loputtua
    /// * muisti, josta on kulunut kuluttamatta kuluttavaa iteraattoria
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Iteraattorisovitin, joka tuottaa ulostuloa niin kauan kuin taustalla oleva iteraattori tuottaa `Result::Ok`-arvoja.
///
///
/// Jos havaitaan virhe, iteraattori pysähtyy ja virhe tallennetaan.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Käsittele annettu iteraattori ikään kuin se antaisi `T`: n `Result<T, _>`: n sijaan.
/// Mahdolliset virheet pysäyttävät sisäisen iteraattorin ja kokonaistulos on virhe.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}