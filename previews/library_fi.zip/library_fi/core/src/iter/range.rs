use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// Objektit, joilla on käsite *seuraaja* ja *edeltäjä* toiminnot.
///
/// *Seuraaja*-toiminto siirtyy kohti arvoja, jotka vertailevat suurempia.
/// *Edeltäjä*-operaatio siirtyy kohti arvoja, jotka verrataan vähemmän.
///
/// # Safety
///
/// Tämä trait on `unsafe`, koska sen toteutuksen on oltava oikeaa `unsafe trait TrustedLen`-toteutusten turvallisuuden kannalta, ja muuten `unsafe`-koodi voi luottaa tämän trait: n käytön tuloksiin oikein ja täyttää luetellut velvoitteet.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// Palauttaa `start`: stä `end`: ään siirtymiseen tarvittavien *seuraaja*-vaiheiden määrän.
    ///
    /// Palauttaa arvon `None`, jos vaiheiden määrä ylittää `usize`: n (tai on ääretön tai jos `end`: ää ei koskaan saavuteta).
    ///
    ///
    /// # Invariants
    ///
    /// Kaikille `a`, `b` ja `n`:
    ///
    /// * `steps_between(&a, &b) == Some(n)` vain ja vain, jos `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` vain ja vain, jos `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` vain, jos `a <= b`
    ///   * Seuraus: `steps_between(&a, &b) == Some(0)` vain ja vain, jos `a == b`
    ///   * Huomaa, että `a <= b` tarkoittaa _not_: ää `steps_between(&a, &b) != None`: ää;
    ///     tämä on tapaus, kun `b`: ään siirtyminen vaatii enemmän kuin `usize::MAX`-vaiheita
    /// * `steps_between(&a, &b) == None` jos `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// Palauttaa arvon, joka saataisiin ottamalla *seuraaja*`self` `count` kertaa.
    ///
    /// Jos tämä ylittää `Self`: n tukeman arvojen alueen, palauttaa `None`.
    ///
    /// # Invariants
    ///
    /// Kaikille `a`, `n` ja `m`:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// Mille tahansa `a`-, `n`-ja `m`-mallille, jossa `n + m` ei ylity:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// Kaikille `a` ja `n`:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// Palauttaa arvon, joka saataisiin ottamalla *seuraaja*`self` `count` kertaa.
    ///
    /// Jos tämä ylittäisi `Self`: n tukeman arvoalueen, tämän toiminnon sallitaan panic, kääri tai kyllästys.
    ///
    /// Ehdotettu käyttäytyminen on panic: lle, kun virheenkorjausvaatimukset ovat käytössä, ja pakata tai kyllästää muuten.
    ///
    /// Turvallisen koodin ei pitäisi luottaa käyttäytymisen oikeellisuuteen ylivuoton jälkeen.
    ///
    /// # Invariants
    ///
    /// Kaikille `a`-, `n`-ja `m`-laitteille, joissa ei tapahdu ylivuotoa:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// Kaikille `a`-ja `n`-laitteille, joissa ei tapahdu ylivuotoa:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// Palauttaa arvon, joka saataisiin ottamalla *seuraaja*`self` `count` kertaa.
    ///
    /// # Safety
    ///
    /// Tämän toiminnon määrittelemätön käyttäytyminen ylittää `Self`: n tukeman arvojen alueen.
    /// Jos et voi taata, että tämä ei tule liikaa, käytä sen sijaan `forward` tai `forward_checked`.
    ///
    /// # Invariants
    ///
    /// Kaikille `a`:
    ///
    /// * jos on olemassa `b`, joka on `b > a`, on turvallista soittaa `Step::forward_unchecked(a, 1)`: ään
    /// * jos on olemassa `b`, `n`, joka on `steps_between(&a, &b) == Some(n)`, on turvallista soittaa `Step::forward_unchecked(a, m)` mille tahansa `m <= n`: lle.
    ///
    ///
    /// Kaikille `a`-ja `n`-laitteille, joissa ei tapahdu ylivuotoa:
    ///
    /// * `Step::forward_unchecked(a, n)` vastaa `Step::forward(a, n)`: ää
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// Palauttaa arvon, joka saadaan, kun otetaan *edeltäjä*`self` `count` kertaa.
    ///
    /// Jos tämä ylittää `Self`: n tukeman arvojen alueen, palauttaa `None`.
    ///
    /// # Invariants
    ///
    /// Kaikille `a`, `n` ja `m`:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// Kaikille `a` ja `n`:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// Palauttaa arvon, joka saadaan, kun otetaan *edeltäjä*`self` `count` kertaa.
    ///
    /// Jos tämä ylittäisi `Self`: n tukeman arvoalueen, tämän toiminnon sallitaan panic, kääri tai kyllästys.
    ///
    /// Ehdotettu käyttäytyminen on panic: lle, kun virheenkorjausvaatimukset ovat käytössä, ja pakata tai kyllästää muuten.
    ///
    /// Turvallisen koodin ei pitäisi luottaa käyttäytymisen oikeellisuuteen ylivuoton jälkeen.
    ///
    /// # Invariants
    ///
    /// Kaikille `a`-, `n`-ja `m`-laitteille, joissa ei tapahdu ylivuotoa:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// Kaikille `a`-ja `n`-laitteille, joissa ei tapahdu ylivuotoa:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// Palauttaa arvon, joka saadaan, kun otetaan *edeltäjä*`self` `count` kertaa.
    ///
    /// # Safety
    ///
    /// Tämän toiminnon määrittelemätön käyttäytyminen ylittää `Self`: n tukeman arvojen alueen.
    /// Jos et voi taata, että tämä ei tule liikaa, käytä sen sijaan `backward` tai `backward_checked`.
    ///
    /// # Invariants
    ///
    /// Kaikille `a`:
    ///
    /// * jos `b` on olemassa niin, että `b < a`, on turvallista soittaa `Step::backward_unchecked(a, 1)`: ään
    /// * jos on olemassa `b`, `n`, joka on `steps_between(&b, &a) == Some(n)`, on turvallista soittaa `Step::backward_unchecked(a, m)` mille tahansa `m <= n`: lle.
    ///
    ///
    /// Kaikille `a`-ja `n`-laitteille, joissa ei tapahdu ylivuotoa:
    ///
    /// * `Step::backward_unchecked(a, n)` vastaa `Step::backward(a, n)`: ää
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// Nämä luodaan edelleen makrossa, koska kokonaislukulukijat kirjataan eri tyyppisiin.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // TURVALLISUUS: soittajan on taattava, että `start + n` ei ylikuormitu.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // TURVALLISUUS: soittajan on taattava, että `start - n` ei ylikuormitu.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // Käynnistä virheenkorjausrakenteissa panic ylivuotoon.
            // Tämän pitäisi optimoida kokonaan julkaisurakenteissa.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // Suorita matematiikka, jotta esim `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // Käynnistä virheenkorjausrakenteissa panic ylivuotoon.
            // Tämän pitäisi optimoida kokonaan julkaisurakenteissa.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // Suorita matematiikka, jotta esim `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Tämä perustuu $u_narrower <=usize
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // jos n on alueen ulkopuolella, myös `unsigned_start + n`
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // jos n on alueen ulkopuolella, myös `unsigned_start - n`
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Tämä perustuu $i_narrower <=usize
                        //
                        // Isisointivalu pidentää leveyttä, mutta säilyttää merkin.
                        // Käytä wrapping_sub isize-avaruudessa ja cast-funktiota laskeaksesi eron, joka ei välttämättä sovi isize-alueelle.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Kääre käsittelee tapauksia, kuten `Step::forward(-120_i8, 200) == Some(80_i8)`, vaikka 200 on i8: n kantaman ulkopuolella.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // Lisäys täynnä
                            }
                        }
                        // Jos n on esim
                        // u8, silloin se on suurempi kuin koko i8-alue on leveä, joten `any_i8 + n` ylittää välttämättä i8: n.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Kääre käsittelee tapauksia, kuten `Step::forward(-120_i8, 200) == Some(80_i8)`, vaikka 200 on i8: n kantaman ulkopuolella.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // Vähennyslasku on täynnä
                            }
                        }
                        // Jos n on esim
                        // u8, silloin se on suurempi kuin koko i8-alue on leveä, joten `any_i8 - n` ylittää välttämättä i8: n.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // Jos ero on liian suuri esim
                            // i128, se tulee olemaan myös liian suuri käytettäväksi vähemmän bitteillä.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // TURVALLISUUS: res on kelvollinen unicode-skalaari
            // (alle 0x110000 eikä 0xD800..0xE000)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // TURVALLISUUS: res on kelvollinen unicode-skalaari
        // (alle 0x110000 eikä 0xD800..0xE000)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // TURVALLISUUS: soittajan on taattava, että tämä ei tule liikaa
        // merkin arvoalue
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // TURVALLISUUS: soittajan on taattava, että tämä ei tule liikaa
            // merkin arvoalue
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // TURVALLISUUS: edellisen sopimuksen takia se on taattu
        // soittajan mukaan olevan kelvollinen merkki.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // TURVALLISUUS: soittajan on taattava, että tämä ei tule liikaa
        // merkin arvoalue
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // TURVALLISUUS: soittajan on taattava, että tämä ei tule liikaa
            // merkin arvoalue
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // TURVALLISUUS: edellisen sopimuksen takia se on taattu
        // soittajan mukaan olevan kelvollinen merkki.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // TURVALLISUUS: juuri tarkistettu edellytys
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // TURVALLISUUS: juuri tarkistettu edellytys
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// Nämä makrot tuottavat `ExactSizeIterator`-implittejä erilaisille alueille.
//
// * `ExactSizeIterator::len` tarvitaan aina palauttamaan tarkka `usize`, joten mikään alue ei voi olla pidempi kuin `usize::MAX`.
//
// * `Range<_>`: n kokonaislukutyyppien kohdalla tämä pätee tyyppeihin, jotka ovat kapeammat tai yhtä leveät kuin `usize`.
//   `RangeInclusive<_>`: n kokonaislukutyyppien kohdalla tämä pätee tyyppeihin *tiukasti kapeampi* kuin `usize`, koska esim
//   `(0..=u64::MAX).len()` olisi `u64::MAX + 1`.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // Nämä on sisällytetty yllä olevien perustelujen mukaan, mutta niiden poistaminen olisi murtavaa muutosta, koska ne stabiloitiin Rust 1.0.0: ssä.
    // Joten esim
    // `(0..66_000_u32).len()` Esimerkiksi kääntää ilman virheitä tai varoituksia 16-bittisillä alustoilla, mutta antaa edelleen väärän tuloksen.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // Nämä on sisällytetty yllä olevien perustelujen mukaan, mutta niiden poistaminen olisi murtavaa muutosta, koska ne stabiloitiin Rust 1.26.0: ssä.
    // Joten esim
    // `(0..=u16::MAX).len()` Esimerkiksi kääntää ilman virheitä tai varoituksia 16-bittisillä alustoilla, mutta antaa edelleen väärän tuloksen.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // TURVALLISUUS: juuri tarkistettu edellytys
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // TURVALLISUUS: juuri tarkistettu edellytys
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // TURVALLISUUS: juuri tarkistettu edellytys
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // TURVALLISUUS: juuri tarkistettu edellytys
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // TURVALLISUUS: juuri tarkistettu edellytys
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // TURVALLISUUS: juuri tarkistettu edellytys
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}