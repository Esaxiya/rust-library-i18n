//! Komposiittinen ulkoinen iterointi.
//!
//! Jos olet löytänyt jonkinlaisen kokoelman ja sinun on suoritettava toimenpide mainitun kokoelman elementeille, törmäät nopeasti 'iterators': ään.
//! Iteraattoreita käytetään voimakkaasti idiomaattisessa Rust-koodissa, joten on syytä tutustua niihin.
//!
//! Ennen kuin selitämme lisää, puhutaan tämän moduulin rakenteesta:
//!
//! # Organization
//!
//! Tämä moduuli on pääosin järjestetty tyypin mukaan:
//!
//! * [Traits] ovat ydinosa: nämä traits määrittelevät millaisia iteraattoreita on olemassa ja mitä voit tehdä niiden kanssa.Näiden traits-menetelmien arvo on ylimääräinen opiskeluaika.
//! * [Functions] tarjoaa hyödyllisiä tapoja luoda iteraattoreita.
//! * [Structs] ovat usein moduulin traits eri menetelmien palautustyypit.Yleensä kannattaa tarkastella menetelmää, jolla `struct` luodaan, eikä itse `struct`: ää.
//! Lisätietoja miksi, katso `[Implementing Iterator](#Implementing-iterator)`.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Se siitä!Kaivetaan iteraattoreihin.
//!
//! # Iterator
//!
//! Tämän moduulin sydän ja sielu on [`Iterator`] trait.[`Iterator`]: n ydin näyttää tältä:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Iteraattorilla on menetelmä [`next`], joka kutsutaan palauttamaan [``Optio`]]<Item>".
//! [`next`] palauttaa [`Some(Item)`]: n, kunhan elementtejä on, ja kun ne kaikki on käytetty loppuun, palauttaa `None`: n osoittamaan, että iterointi on valmis.
//! Yksittäiset iteraattorit voivat päättää jatkaa iterointia, joten [`next`]: n uudelleen soittaminen voi lopulta aloittaa [`Some(Item)`]: n palauttamisen jossakin vaiheessa (esimerkiksi katso [`TryIter`]).
//!
//!
//! [`Iterator`]: n täydellinen määritelmä sisältää myös useita muita menetelmiä, mutta ne ovat oletusmenetelmiä, jotka on rakennettu [`next`]: n päälle, joten saat ne ilmaiseksi.
//!
//! Iteraattorit ovat myös yhdistettävissä, ja on yleistä ketjuttaa ne yhteen monimutkaisempien käsittelymuotojen tekemiseksi.Katso lisätietoja alla olevasta [Adapters](#adapters)-osiosta.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Kolme iteroinnin muotoa
//!
//! On olemassa kolme yleistä menetelmää, jotka voivat luoda iteraattoreita kokoelmasta:
//!
//! * `iter()`, joka toistaa `&T`: n kautta.
//! * `iter_mut()`, joka toistaa `&mut T`: n kautta.
//! * `into_iter()`, joka toistaa `T`: n kautta.
//!
//! Vakiokirjaston erilaisissa asioissa voidaan tarvittaessa toteuttaa yksi tai useampi kolmesta.
//!
//! # Iteratorin toteutus
//!
//! Oman iteraattorin luominen edellyttää kahta vaihetta: `struct`: n luominen iteraattorin tilan pitämiseksi ja [`Iterator`]: n käyttöönotto tälle `struct`: lle.
//! Siksi tässä moduulissa on niin monta strukturoitavaa: yksi on jokaiselle iteraattorille ja iteraattorisovittimelle.
//!
//! Tehdään iteraattori nimeltä `Counter`, joka laskee välillä `1`-`5`:
//!
//! ```
//! // Ensinnäkin rakenne:
//!
//! /// Iteraattori, joka laskee yhdestä viiteen
//! struct Counter {
//!     count: usize,
//! }
//!
//! // haluamme, että laskemamme alkaa yhdellä, joten lisätään new()-menetelmä auttamaan.
//! // Tämä ei ole ehdottoman välttämätöntä, mutta on kätevää.
//! // Huomaa, että aloitamme `count`: n nollasta, näemme miksi `next()`'s-toteutuksessa alla.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Sitten toteutamme `Iterator`: n `Counter`: lle:
//!
//! impl Iterator for Counter {
//!     // me laskemme usizen kanssa
//!     type Item = usize;
//!
//!     // next() on ainoa vaadittu menetelmä
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Kasvata lukumääräämme.Siksi aloitimme nollasta.
//!         self.count += 1;
//!
//!         // Tarkista onko laskeminen lopetettu vai ei.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Ja nyt voimme käyttää sitä!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! [`next`]: n soittaminen tällä tavalla saa toistumaan.Rust: llä on rakenne, joka voi soittaa iteraattorillasi [`next`]: n, kunnes se saavuttaa `None`: n.Mennään seuraavaksi.
//!
//! Huomaa myös, että `Iterator` tarjoaa oletusarvoisen menetelmän, kuten `nth` ja `fold`, jotka kutsuvat `next`: ää sisäisesti.
//! On kuitenkin myös mahdollista kirjoittaa mukautettu toteutusmenetelmiä, kuten `nth` ja `fold`, jos iteraattori voi laskea ne tehokkaammin soittamatta `next`: ää.
//!
//! # `for` silmukat ja `IntoIterator`
//!
//! Rust: n `for`-silmukan syntaksi on itse asiassa sokeri iteraattoreille.Tässä on perusesimerkki `for`: stä:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Tämä tulostaa numerot yhdestä viiteen, kukin omalle rivilleen.Mutta huomaat jotain täällä: emme koskaan soittaneet mitään vector-laitteellemme iteraattorin tuottamiseksi.Mikä antaa?
//!
//! Tavallisessa kirjastossa on trait muuntaa jotain iteraattoriksi: [`IntoIterator`].
//! Tällä trait: llä on yksi menetelmä, [`into_iter`], joka muuntaa [`IntoIterator`]: n toteuttavan asian iteraattoriksi.
//! Katsotaanpa uudelleen `for`-silmukka ja mitä kääntäjä muuntaa sen:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust poistaa sokerit tästä:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Ensinnäkin kutsumme arvoa `into_iter()`.Sitten sovitetaan takaisin iteraattoriin, kutsumalla [`next`]: ää uudestaan ja uudestaan, kunnes näemme `None`: n.
//! Siinä vaiheessa me `break` ulos silmukasta, ja olemme suorittaneet iteroinnin.
//!
//! Tässä on vielä yksi hienovarainen bitti: vakiokirjasto sisältää mielenkiintoisen [`IntoIterator`]-toteutuksen:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Toisin sanoen, kaikki [``Iterator``) toteuttavat [`IntoIterator`]: n vain palauttamalla itsensä.Tämä tarkoittaa kahta asiaa:
//!
//! 1. Jos kirjoitat [`Iterator`]: ää, voit käyttää sitä `for`-silmukan kanssa.
//! 2. Jos luot kokoelman, [`IntoIterator`]: n käyttöönotto sille sallii kokoelmasi käytön `for`-silmukan kanssa.
//!
//! # Toistetaan viitteenä
//!
//! Koska [`into_iter()`] ottaa `self`: n arvon, `for`-silmukan käyttäminen kokoelman toistamiseen kuluttaa kokoelmaa.Usein saatat haluta toistaa kokoelman kuluttamatta sitä.
//! Monet kokoelmat tarjoavat menetelmiä, jotka tarjoavat iteraattoreita viitteiden yli, perinteisesti nimeltään `iter()` ja `iter_mut()`:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` on edelleen tämän toiminnon omistuksessa.
//! ```
//!
//! Jos kokoelmatyyppi `C` tarjoaa `iter()`: n, se toteuttaa yleensä myös `IntoIterator`: n `&C`: lle toteutuksella, joka vain kutsuu `iter()`: ää.
//! Samoin kokoelma `C`, joka toimittaa `iter_mut()`: n, yleensä toteuttaa `IntoIterator`: n `&mut C`: lle delegoimalla `iter_mut()`: lle.Tämä mahdollistaa kätevän lyhenteen:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // sama kuin `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // sama kuin `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Vaikka monet kokoelmat tarjoavat `iter()`: n, kaikki eivät tarjoa `iter_mut()`: ää.
//! Esimerkiksi [`HashSet<T>`]: n tai [`HashMap<K, V>`]: n avainten mutatointi saattaa kokoelman olla epäjohdonmukaisessa tilassa, jos avaimen hajautus muuttuu, joten nämä kokoelmat tarjoavat vain `iter()`: n.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Toimintoja, jotka ottavat [`Iterator`]: n ja palauttavat toisen [`Iterator`]: n, kutsutaan usein iteraattorisovittimiksi, koska ne ovat eräänlainen 'sovitin'
//! pattern'.
//!
//! Yleisiä iteraattorisovittimia ovat [`map`], [`take`] ja [`filter`].
//! Katso lisätietoja heidän dokumentaatiosta.
//!
//! Jos iteraattorisovitin panics, iteraattori on määrittelemättömässä tilassa (mutta muisti turvallinen).
//! Tämän tilan ei myöskään taata pysyvän samana kaikissa Rust-versioissa, joten sinun tulisi välttää luottamasta paniikkia aiheuttaneen iteraattorin palauttamiin tarkkoihin arvoihin.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iteraattorit (ja iteraattori [adapters](#adapters)) ovat *laiskoja*. Tämä tarkoittaa, että pelkkä iteraattorin luominen ei tarkoita _do_: ää. Mitään ei todellakaan tapahdu ennen kuin soitat [`next`]: lle.
//! Tämä on joskus sekaannusta, kun iteraattori luodaan vain sen sivuvaikutuksia varten.
//! Esimerkiksi [`map`]-menetelmä kutsuu sulkemisen jokaiselle elementille, jolla se toistetaan:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Tämä ei tulosta arvoja, koska olemme luoneet vain iteraattorin sen sijaan, että käyttäisimme sitä.Kääntäjä varoittaa meitä tällaisesta käyttäytymisestä:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Idioomaattinen tapa kirjoittaa [`map`] sivuvaikutuksilleen on käyttää `for`-silmukkaa tai kutsua [`for_each`]-menetelmä:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Toinen yleinen tapa arvioida iteraattoria on käyttää [`collect`]-menetelmää uuden kokoelman tuottamiseen.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iteraattoreiden ei tarvitse olla äärellisiä.Esimerkiksi avoin alue on ääretön iteraattori:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! [`take`]-iteraattorisovittimen avulla on tavallista muuttaa ääretön iteraattori äärelliseksi:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Tämä tulostaa numerot `0`-`4`, kukin omalle rivilleen.
//!
//! Muista, että äärettömien iteraattoreiden menetelmät, myös ne, joille tulos voidaan määrittää matemaattisesti rajallisessa ajassa, eivät välttämättä pääty.
//! Erityisesti [`min`]: n kaltaiset menetelmät, jotka yleensä vaativat iteraattorin jokaisen elementin kulkemisen, eivät todennäköisesti palaa onnistuneesti mihinkään äärettömään iteraattoriin.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Voi ei!Ääretön silmukka!
//! // `ones.min()` aiheuttaa loputtoman silmukan, joten emme pääse tähän pisteeseen!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;