use crate::iter::{FusedIterator, TrustedLen};

/// Luo uuden iteraattorin, joka toistaa loputtomasti yhden elementin.
///
/// `repeat()`-toiminto toistaa yhden arvon uudestaan ja uudestaan.
///
/// Äärettömiä iteraattoreita, kuten `repeat()`, käytetään usein [`Iterator::take()`]: n kaltaisten sovittimien kanssa, jotta niistä tulisi rajallisia.
///
/// Jos tarvitsemasi iteraattorin elementtityyppi ei toteuta `Clone`: ää tai jos et halua pitää toistettua elementtiä muistissa, voit sen sijaan käyttää [`repeat_with()`]-toimintoa.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Peruskäyttö:
///
/// ```
/// use std::iter;
///
/// // numero neljä 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // jo, vielä neljä
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// [`Iterator::take()`]: n kanssa lopullinen:
///
/// ```
/// use std::iter;
///
/// // viimeinen esimerkki oli liian monta neljästä.Meillä on vain neljä neljä.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... ja nyt olemme valmiit
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Iteraattori, joka toistaa elementin loputtomasti.
///
/// Tämä `struct` on luotu [`repeat()`]-toiminnolla.Katso lisätietoja sen dokumentaatiosta.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}