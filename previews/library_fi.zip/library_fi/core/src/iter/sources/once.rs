use crate::iter::{FusedIterator, TrustedLen};

/// Luo iteraattorin, joka tuottaa elementin tarkalleen kerran.
///
/// Tätä käytetään yleisesti yhden arvon sovittamiseen muun tyyppiseen iterointiin [`chain()`].
/// Ehkä sinulla on iteraattori, joka kattaa melkein kaiken, mutta tarvitset erityisen erikoistapauksen.
/// Ehkä sinulla on toiminto, joka toimii iteraattoreilla, mutta sinun on käsiteltävä vain yksi arvo.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Peruskäyttö:
///
/// ```
/// use std::iter;
///
/// // yksi on yksinäisin numero
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // vain yksi, se on kaikki mitä saamme
/// assert_eq!(None, one.next());
/// ```
///
/// Ketjua yhdessä toisen iteraattorin kanssa.
/// Oletetaan, että haluamme toistaa `.foo`-hakemiston jokaisen tiedoston, mutta myös määritystiedoston,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // meidän on muutettava DirEntry-s-iteraattorista PathBufs-iteraattoriksi, joten käytämme karttaa
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // nyt iteraattorimme vain määritystiedostollemme
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // ketjua kaksi iteraattoria yhteen suureksi iteraattoriksi
/// let files = dirs.chain(config);
///
/// // tämä antaa meille kaikki tiedostot .foo: ssä ja .foorc: ssä
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Iteraattori, joka tuottaa elementin tarkalleen kerran.
///
/// Tämä `struct` on luotu [`once()`]-toiminnolla.Katso lisätietoja sen dokumentaatiosta.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}