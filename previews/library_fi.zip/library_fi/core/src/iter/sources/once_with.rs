use crate::iter::{FusedIterator, TrustedLen};

/// Luo iteraattorin, joka tuottaa laiskasti arvon täsmälleen kerran vedoten annettuun sulkemiseen.
///
/// Tätä käytetään yleisesti yhden arvogeneraattorin sovittamiseen muunlaiseen iterointiin [`chain()`]: ään.
/// Ehkä sinulla on iteraattori, joka kattaa melkein kaiken, mutta tarvitset erityisen erikoistapauksen.
/// Ehkä sinulla on toiminto, joka toimii iteraattoreilla, mutta sinun on käsiteltävä vain yksi arvo.
///
/// Toisin kuin [`once()`], tämä toiminto tuottaa laiskasti arvon pyynnöstä.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Peruskäyttö:
///
/// ```
/// use std::iter;
///
/// // yksi on yksinäisin numero
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // vain yksi, se on kaikki mitä saamme
/// assert_eq!(None, one.next());
/// ```
///
/// Ketjua yhdessä toisen iteraattorin kanssa.
/// Oletetaan, että haluamme toistaa `.foo`-hakemiston jokaisen tiedoston, mutta myös määritystiedoston,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // meidän on muutettava DirEntry-s-iteraattorista PathBufs-iteraattoriksi, joten käytämme karttaa
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // nyt iteraattorimme vain määritystiedostollemme
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // ketjua kaksi iteraattoria yhteen suureksi iteraattoriksi
/// let files = dirs.chain(config);
///
/// // tämä antaa meille kaikki tiedostot .foo: ssä ja .foorc: ssä
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Iteraattori, joka tuottaa yhden elementin tyypistä `A` soveltamalla mukana toimitettua sulkinta `F: FnOnce() -> A`.
///
///
/// Tämä `struct` on luotu [`once_with()`]-toiminnolla.
/// Katso lisätietoja sen dokumentaatiosta.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}