use crate::fmt;

/// Luo uuden iteraattorin, jossa jokainen iteraatio kutsuu toimitettua sulkua `F: FnMut() -> Option<T>`.
///
/// Tämä mahdollistaa mukautetun iteraattorin luomisen millä tahansa käyttäytymisellä käyttämättä tarkempaa syntaksia omistetun tyypin luomisessa ja [`Iterator`] trait: n toteuttamisessa.
///
/// Huomaa, että `FromFn`-iteraattori ei tee oletuksia sulkimen toiminnasta, eikä siksi konservatiivisesti toteuta [`FusedIterator`]: ää tai ohittaa [`Iterator::size_hint()`]: n oletusarvostaan `(0, None)`.
///
///
/// Sulkeminen voi käyttää sieppauksia ja sen ympäristöä tilan seuraamiseen iteraatioiden yli.Iteraattorin käyttötavasta riippuen tämä saattaa edellyttää [`move`]-avainsanan määrittämistä sulkimessa.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Toteutetaan laskurin iteraattori uudelleen [module-level documentation]: stä:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Kasvata lukumääräämme.Siksi aloitimme nollasta.
///     count += 1;
///
///     // Tarkista onko laskeminen lopetettu vai ei.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Iteraattori, jossa kukin iterointi kutsuu toimitettua sulkua `F: FnMut() -> Option<T>`.
///
/// Tämä `struct` on luotu [`iter::from_fn()`]-toiminnolla.
/// Katso lisätietoja sen dokumentaatiosta.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}