use crate::iter::{FusedIterator, TrustedLen};

/// Luo uuden iteraattorin, joka toistaa tyypin `A` elementtejä loputtomasti soveltamalla mukana toimitettua sulkinta, toistinta, `F: FnMut() -> A`.
///
/// `repeat_with()`-toiminto kutsuu toistinta uudestaan ja uudestaan.
///
/// Äärettömiä iteraattoreita, kuten `repeat_with()`, käytetään usein [`Iterator::take()`]: n kaltaisten sovittimien kanssa, jotta niistä tulisi rajallisia.
///
/// Jos tarvitsemasi iteraattorin elementtityyppi toteuttaa [`Clone`]: n ja lähde-elementin pitäminen muistissa on hyvä, käytä sen sijaan [`repeat()`]-toimintoa.
///
///
/// `repeat_with()`: n tuottama iteraattori ei ole [`DoubleEndedIterator`].
/// Jos tarvitset `repeat_with()`: n palauttamaan [`DoubleEndedIterator`]: n, avaa GitHub-ongelma, jossa selitetään käyttötapauksesi.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Peruskäyttö:
///
/// ```
/// use std::iter;
///
/// // Oletetaan, että meillä on jokin arvo tyypistä, joka ei ole `Clone` tai joka ei halua vielä muistia, koska se on kallista:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // tietty arvo ikuisesti:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Mutaation käyttäminen ja äärelliseksi meneminen:
///
/// ```rust
/// use std::iter;
///
/// // Nollasta kahden kolmanneksi voimaksi:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... ja nyt olemme valmiit
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Iteraattori, joka toistaa tyypin `A` elementtejä loputtomasti soveltamalla mukana toimitettua suljinta `F: FnMut() -> A`.
///
///
/// Tämä `struct` on luotu [`repeat_with()`]-toiminnolla.
/// Katso lisätietoja sen dokumentaatiosta.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}