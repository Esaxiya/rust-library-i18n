use crate::ops::{ControlFlow, Try};

/// Iteraattori, joka pystyy tuottamaan elementtejä molemmista päistä.
///
/// Jotain, joka toteuttaa `DoubleEndedIterator`: n, tarjoaa yhden ylimääräisen kyvyn johonkin, joka toteuttaa [`Iterator`]: n: kyky ottaa myös `Tuote`` takaosasta sekä edestä.
///
///
/// On tärkeää huomata, että molemmat edestakaisin toimivat samalla alueella eivätkä ylitä: iterointi on ohi, kun he kohtaavat keskellä.
///
/// Samalla tavalla kuin [`Iterator`]-protokolla, kun `DoubleEndedIterator` palauttaa [`None`]: n [`next_back()`]: stä, soittamalla sille uudelleen voidaan tai ei voi koskaan palauttaa [`Some`]: ää uudelleen.
/// [`next()`] ja [`next_back()`] ovat keskenään vaihdettavissa tähän tarkoitukseen.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Peruskäyttö:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Poistaa ja palauttaa elementin iteraattorin päästä.
    ///
    /// Palauttaa `None`, kun elementtejä ei ole enää.
    ///
    /// [trait-level]-asiakirjat sisältävät lisätietoja.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// "DoubleEndedIterator"-menetelmien tuottamat elementit voivat poiketa ["Iterator"]-menetelmien tuottamista:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Edistää iteraattoria takaosasta `n`-elementeillä.
    ///
    /// `advance_back_by` on [`advance_by`]: n käänteinen versio.Tämä menetelmä ohittaa innokkaasti `n`-elementit takaa alkaen soittamalla [`next_back`]: ään jopa `n` kertaa, kunnes [`None`] havaitaan.
    ///
    /// `advance_back_by(n)` palauttaa [`Ok(())`]: n, jos iteraattori etenee onnistuneesti `n`-elementeillä, tai [`Err(k)`], jos [`None`] esiintyy, missä `k` on niiden elementtien lukumäärä, joihin iteraattori on edennyt ennen kuin elementit loppuvat (ts.
    /// iteraattorin pituus).
    /// Huomaa, että `k` on aina pienempi kuin `n`.
    ///
    /// `advance_back_by(0)`: n soittaminen ei kuluta mitään elementtejä ja palauttaa aina [`Ok(())`]: n.
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // vain `&3` ohitettiin
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Palauttaa n: nnen elementin iteraattorin päästä.
    ///
    /// Tämä on lähinnä [`Iterator::nth()`]: n päinvastainen versio.
    /// Vaikka useimpien indeksointitoimintojen tavoin laskenta alkaa nollasta, `nth_back(0)` palauttaa ensimmäisen arvon lopusta, `nth_back(1)` toisen ja niin edelleen.
    ///
    ///
    /// Huomaa, että kaikki loppuosan ja palautetun elementin väliset elementit kulutetaan, mukaan lukien palautettu elementti.
    /// Tämä tarkoittaa myös sitä, että `nth_back(0)`: n soittaminen useita kertoja samalla iteraattorilla palauttaa eri elementit.
    ///
    /// `nth_back()` palauttaa arvon [`None`], jos `n` on suurempi tai yhtä suuri kuin iteraattorin pituus.
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// `nth_back()`: n soittaminen useita kertoja ei peruuta iteraattoria:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Palautetaan `None`, jos elementtejä on vähemmän kuin `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Tämä on [`Iterator::try_fold()`]: n käänteinen versio: se vie elementit iteraattorin takaosasta alkaen.
    ///
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Koska se oli oikosulussa, loput elementit ovat edelleen käytettävissä iteraattorin kautta.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Iteraattorimenetelmä, joka pienentää iteraattorin elementit yhdeksi lopulliseksi arvoksi takaa alkaen.
    ///
    /// Tämä on [`Iterator::fold()`]: n käänteinen versio: se vie elementit iteraattorin takaosasta alkaen.
    ///
    /// `rfold()` ottaa kaksi argumenttia: alkuarvon ja sulkemisen kahdella argumentilla: 'accumulator' ja elementti.
    /// Sulkeminen palauttaa arvon, joka akulla pitäisi olla seuraavaa iteraatiota varten.
    ///
    /// Alkuarvo on arvo, joka akulla on ensimmäisen puhelun yhteydessä.
    ///
    /// Kun tämä suljin on asetettu kaikkiin iteraattorin elementteihin, `rfold()` palauttaa akun.
    ///
    /// Tätä toimintoa kutsutaan joskus 'reduce' tai 'inject'.
    ///
    /// Taittaminen on hyödyllistä aina, kun sinulla on kokoelma jotain ja haluat tuottaa siitä yhden arvon.
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // a: n kaikkien elementtien summa
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Tämä esimerkki rakentaa merkkijonon, joka alkaa alkuarvosta ja jatkuu jokaisella elementillä takaa eteenpäin:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Hakee iteraattorin elementin takaa, joka täyttää predikaatin.
    ///
    /// `rfind()` sulkee arvon `true` tai `false`.
    /// Se soveltaa tätä sulkua iteraattorin jokaiseen elementtiin alkaen alusta, ja jos jokin niistä palauttaa `true`: n, niin `rfind()` palauttaa [`Some(element)`]: n.
    /// Jos ne kaikki palauttavat `false`: n, se palauttaa [`None`]: n.
    ///
    /// `rfind()` on oikosulku;toisin sanoen se lopettaa käsittelyn heti, kun sulkeminen palauttaa `true`: n.
    ///
    /// Koska `rfind()` ottaa viitteen ja monet iteraattorit iteroivat viitteitä, tämä johtaa mahdollisesti hämmentävään tilanteeseen, jossa argumentti on kaksinkertainen viite.
    ///
    /// Tämä vaikutus näkyy alla olevissa esimerkeissä `&&x`: n kanssa.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Pysähtyminen ensimmäisellä `true`: llä:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // voimme silti käyttää `iter`: ää, koska elementtejä on enemmän.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}