/// Iteraattori, joka tuottaa jatkuvasti `None`: n loppuessaan.
///
/// Seuraavan soittaminen sulatetulla iteraattorilla, joka on palauttanut `None`: n kerran, takaa [`None`]: n uudelleen.
/// Kaikkien tällä tavalla käyttäytyvien iteraattorien tulisi toteuttaa tämä trait, koska se mahdollistaa [`Iterator::fuse()`]: n optimoinnin.
///
///
/// Note: Yleensä sinun ei pitäisi käyttää `FusedIterator`: ää yleisissä rajoissa, jos tarvitset sulatettua iteraattoria.
/// Sen sijaan sinun pitäisi vain soittaa [`Iterator::fuse()`] iteraattoriin.
/// Jos iteraattori on jo sulatettu, ylimääräinen [`Fuse`]-kääre on ei-pakollinen ilman rangaistusta.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Iteraattori, joka ilmoittaa tarkan pituuden käyttämällä size_hint.
///
/// Iteraattori ilmoittaa koon vihjeen, jos se on joko tarkka (alaraja on yhtä suuri kuin yläraja) tai yläraja on [`None`].
///
/// Ylärajan on oltava [`None`] vain, jos iteraattorin todellinen pituus on suurempi kuin [`usize::MAX`].
/// Tällöin alarajan on oltava [`usize::MAX`], jolloin `(usize::MAX, None)` on [`Iterator::size_hint()`].
///
/// Iteraattorin on tuotettava täsmälleen lukumäärä elementtejä, jotka se on ilmoittanut tai jotka vaihtelevat ennen lopun saavuttamista.
///
/// # Safety
///
/// Tämä trait on pantava täytäntöön vain sopimuksen voimassa ollessa.
/// Tämän trait: n kuluttajien on tarkastettava [`Iterator::size_hint()`]’s: n yläraja.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Iteraattori, jonka tuottaessa kohde on ottanut vähintään yhden elementin sen taustalla olevasta [`SourceIter`]: stä.
///
/// Kutsu mitä tahansa iteraattoria etenevää menetelmää, esim
/// [`next()`] tai [`try_fold()`], takaa, että kustakin vaiheesta ainakin yksi iteraattorin taustalähteen arvo on siirretty pois ja iteraattoriketjun tulos voidaan lisätä sen tilalle, olettaen, että lähteen rakenteelliset rajoitukset sallivat tällaisen lisäyksen.
///
/// Toisin sanoen tämä trait osoittaa, että iteraattoriputki voidaan kerätä paikalleen.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}