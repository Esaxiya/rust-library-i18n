/// Iteraattori, joka tietää tarkan pituuden.
///
/// Monet [iteraattorit] eivät tiedä kuinka monta kertaa he toistavat, mutta jotkut tietävät.
/// Jos iteraattori tietää kuinka monta kertaa se voi toistaa, pääsy kyseisiin tietoihin voi olla hyödyllistä.
/// Esimerkiksi, jos haluat toistaa taaksepäin, hyvä alku on tietää, missä loppu on.
///
/// Kun otat käyttöön `ExactSizeIterator`: n, sinun on toteutettava myös [`Iterator`].
/// Tällöin [`Iterator::size_hint`]*: n toteutuksen on* palautettava tarkka iteraattorin koko.
///
/// [`len`]-menetelmällä on oletustoteutus, joten sinun ei yleensä pitäisi käyttää sitä.
/// Saatat kuitenkin pystyä tarjoamaan oletusarvoa tehokkaamman toteutuksen, joten sen ohittaminen on tässä tapauksessa järkevää.
///
///
/// Huomaa, että tämä trait on turvallinen trait ja sellaisenaan *ei* eikä *voi* taata, että palautettu pituus on oikea.
/// Tämä tarkoittaa, että `unsafe`-koodi **ei saa** luottaa [`Iterator::size_hint`]: n oikeellisuuteen.
/// Epävakaa ja vaarallinen [`TrustedLen`](super::marker::TrustedLen) trait antaa tämän lisätakuun.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Peruskäyttö:
///
/// ```
/// // rajallinen alue tietää tarkalleen, kuinka monta kertaa se toistaa
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// [module-level docs]: ssä otimme käyttöön [`Iterator`]: n, `Counter`.
/// Toteutetaan myös `ExactSizeIterator` sille:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Voimme helposti laskea jäljellä olevan iteraatioiden määrän.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Ja nyt voimme käyttää sitä!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Palauttaa iteraattorin tarkan pituuden.
    ///
    /// Toteutus varmistaa, että iteraattori palauttaa tarkalleen `len()` enemmän kuin [`Some(T)`]-arvo ennen [`None`]-arvon palauttamista.
    ///
    /// Tällä menetelmällä on oletustoteutus, joten sinun ei yleensä pitäisi toteuttaa sitä suoraan.
    /// Jos kuitenkin pystyt tarjoamaan tehokkaamman toteutuksen, voit tehdä sen.
    /// Katso esimerkki [trait-level]-asiakirjoista.
    ///
    /// Tällä toiminnolla on samat turvallisuustakuut kuin [`Iterator::size_hint`]-toiminnolla.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// // rajallinen alue tietää tarkalleen, kuinka monta kertaa se toistaa
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Tämä väite on liian puolustava, mutta se tarkistaa invarianttia
        // takaa trait.
        // Jos tämä trait olisi rust-sisäinen, voisimme käyttää debug_assert !;assert_eq!tarkistaa myös kaikki Rust-käyttäjän toteutukset.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Palauttaa `true`: n, jos iteraattori on tyhjä.
    ///
    /// Tällä menetelmällä on oletustoteutus [`ExactSizeIterator::len()`]: n avulla, joten sinun ei tarvitse toteuttaa sitä itse.
    ///
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}