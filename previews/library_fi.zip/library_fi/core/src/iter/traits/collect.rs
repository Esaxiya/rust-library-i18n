/// Muunnos [`Iterator`]: stä.
///
/// Toteuttamalla `FromIterator` tyypille määrität, miten se luodaan iteraattorista.
/// Tämä on yleistä tyyppeille, jotka kuvaavat jonkinlaista kokoelmaa.
///
/// [`FromIterator::from_iter()`] kutsutaan harvoin nimenomaisesti, ja sitä käytetään sen sijaan [`Iterator::collect()`]-menetelmällä.
///
/// Katso lisää esimerkkejä [`Iterator::collect()`]'s-ohjeista.
///
/// Katso myös: [`IntoIterator`].
///
/// # Examples
///
/// Peruskäyttö:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// `FromIterator`: n käyttäminen implisiittisesti `FromIterator`: n käyttämiseen:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// `FromIterator`: n käyttöönotto tyypillesi:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Näytekokoelma, joka on vain kääre Vecin yli<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Annetaan sille joitain menetelmiä, jotta voimme luoda sellaisen ja lisätä siihen asioita.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ja toteutamme FromIteratorin
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Nyt voimme tehdä uuden iteraattorin ...
/// let iter = (0..5).into_iter();
///
/// // ... ja tee siitä Oma kokoelma
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // kerää myös teoksia!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Luo arvon iteraattorista.
    ///
    /// Katso lisätietoja [module-level documentation]: stä.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Muunnos [`Iterator`]: ksi.
///
/// Toteuttamalla `IntoIterator` tyypille määrität, kuinka se muunnetaan iteraattoriksi.
/// Tämä on yleistä tyyppeille, jotka kuvaavat jonkinlaista kokoelmaa.
///
/// Yksi etu `IntoIterator`: n käyttöönotossa on se, että tyyppisi tulee [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Katso myös: [`FromIterator`].
///
/// # Examples
///
/// Peruskäyttö:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// `IntoIterator`: n käyttöönotto tyypillesi:
///
/// ```
/// // Näytekokoelma, joka on vain kääre Vecin yli<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Annetaan sille joitain menetelmiä, jotta voimme luoda sellaisen ja lisätä siihen asioita.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ja toteutamme IntoIteratorin
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Nyt voimme tehdä uuden kokoelman ...
/// let mut c = MyCollection::new();
///
/// // ... lisää siihen jotain ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... ja muuta sitten iteraattori:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// On yleistä käyttää `IntoIterator`: ää trait bound-laitteena.Tämä sallii tulokokoelman tyypin muuttamisen, kunhan se on edelleen iteraattori.
/// Muita rajoja voidaan määrittää rajoittamalla
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Toistettavien elementtien tyyppi.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Minkälaiseksi iteraattoriksi me muutamme tämän?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Luo iteraattorin arvosta.
    ///
    /// Katso lisätietoja [module-level documentation]: stä.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Laajenna kokoelma iteraattorin sisällöllä.
///
/// Iteraattorit tuottavat sarjan arvoja, ja kokoelmia voidaan ajatella myös arvosarjoina.
/// `Extend` trait yhdistää tämän aukon, jolloin voit laajentaa kokoelmaa sisällyttämällä kyseisen iteraattorin sisällön.
/// Kun kokoelmaa laajennetaan jo olemassa olevalla avaimella, kyseinen merkintä päivitetään tai, jos kokoelmissa sallitaan useita merkintöjä samoilla avaimilla, kyseinen merkintä lisätään.
///
///
/// # Examples
///
/// Peruskäyttö:
///
/// ```
/// // Voit pidentää merkkijonoa joillakin merkeillä:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// `Extend`: n käyttöönotto:
///
/// ```
/// // Näytekokoelma, joka on vain kääre Vecin yli<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Annetaan sille joitain menetelmiä, jotta voimme luoda sellaisen ja lisätä siihen asioita.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // Koska MyCollectionilla on luettelo i32-tiedostoista, toteutamme Xendon i32-laitteen
/// impl Extend<i32> for MyCollection {
///
///     // Tämä on hieman yksinkertaisempaa betonityyppisen allekirjoituksen kanssa: voimme kutsua laajennusta mihin tahansa, mikä voidaan muuttaa iteratoriksi, joka antaa meille i32: t.
///     // Koska tarvitsemme i32: itä laitettavaksi MyCollectioniin.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Toteutus on hyvin suoraviivaista: kierrä iteraattorin läpi ja add() jokainen elementti itsellemme.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // laajennetaan kokoelmamme vielä kolmella numerolla
/// c.extend(vec![1, 2, 3]);
///
/// // olemme lisänneet nämä elementit loppuun
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Laajentaa kokoelman iteraattorin sisällöllä.
    ///
    /// Koska tämä on ainoa vaadittu menetelmä tälle trait: lle, [trait-level]-dokumentit sisältävät lisätietoja.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// // Voit pidentää merkkijonoa joillakin merkeillä:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Laajentaa kokoelmaa tarkalleen yhdellä elementillä.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Varaa kokoelman kapasiteetin tietylle määrälle lisäelementtejä.
    ///
    /// Oletustoteutus ei tee mitään.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}