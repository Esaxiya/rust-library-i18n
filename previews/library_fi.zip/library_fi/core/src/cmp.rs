//! Toiminnallisuus tilaamiseen ja vertailuun.
//!
//! Tämä moduuli sisältää useita työkaluja arvojen järjestämiseen ja vertaamiseen.Yhteenvetona:
//!
//! * [`Eq`] ja [`PartialEq`] ovat traits, joiden avulla voit määrittää vastaavasti arvojen välisen täydellisen ja osittaisen tasa-arvon.
//! Niiden toteuttaminen ylikuormittaa `==`-ja `!=`-operaattoreita.
//! * [`Ord`] ja [`PartialOrd`] ovat traits, joiden avulla voit määrittää kokonais-ja osittaisen järjestyksen arvojen välillä.
//!
//! Niiden toteuttaminen ylikuormittaa operaattoreita `<`, `<=`, `>` ja `>=`.
//! * [`Ordering`] on luku, jonka [`Ord`]: n ja [`PartialOrd`]: n päätoiminnot palauttavat, ja kuvaa tilaamista.
//! * [`Reverse`] on rakenne, jonka avulla voit helposti peruuttaa tilauksen.
//! * [`max`] ja [`min`] ovat toimintoja, jotka rakentuvat [`Ord`]: stä ja joiden avulla voit löytää kahden tai useamman arvon.
//!
//! Lisätietoja on luettelon kunkin kohteen vastaavissa asiakirjoissa.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait tasa-arvon vertailuihin, jotka ovat [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation).
///
/// Tämä trait sallii osittaisen tasa-arvon, tyypeille, joilla ei ole täydellistä ekvivalenssisuhdetta.
/// Esimerkiksi liukulukuissa `NaN != NaN`, joten liukulukutyypit toteuttavat `PartialEq`: n, mutta eivät [`trait@Eq`]: ää.
///
/// Muodollisesti tasa-arvon on oltava (kaikille `a`, `b`, `c` tyypille `A`, `B`, `C`):
///
/// - **Symmetrinen**: jos `A: PartialEq<B>` ja `B: PartialEq<A>`, niin **`a==b` tarkoittaa`b==a`**;ja
///
/// - **Transitiivinen**: jos `A: PartialEq<B>` ja `B: PartialEq<C>` ja `A:
///   Osittainen<C>`, sitten **` a==b`ja `b == c` tarkoittaa`a==c`**.
///
/// Huomaa, että `B: PartialEq<A>` (symmetric)-ja `A: PartialEq<C>` (transitive)-implit eivät ole pakotettuja olemaan, mutta näitä vaatimuksia sovelletaan aina, kun niitä on.
///
/// ## Derivable
///
/// Tätä trait: tä voidaan käyttää `#[derive]`: n kanssa.Kun `johdetaan`d struktureille, kaksi esiintymää ovat yhtä suuret, jos kaikki kentät ovat samat, eivätkä yhtä suuret, jos kentät eivät ole yhtä suuret.Kun `johdetaan`d laskelmista, kukin muunnos on sama kuin itsensä eikä ole yhtä suuri kuin muut muunnokset.
///
/// ## Kuinka voin ottaa `PartialEq`: n käyttöön?
///
/// `PartialEq` vaatii vain [`eq`]-menetelmän toteuttamisen;[`ne`] määritellään oletusarvoisesti sen mukaan.Kaikkien [`ne`]*: n manuaalisten toteutusten on* noudatettava sääntöä, jonka mukaan [`eq`] on [`ne`]: n tiukka käänteinen;eli `!(a == b)` vain ja vain, jos `a != b`.
///
/// `PartialEq`: n, [`PartialOrd`]: n ja [`Ord`]: n *toteutusten* on * sovittava keskenään.On helppo saada vahingossa erimielisyydet johtamalla osa traits: stä ja toteuttamalla toiset manuaalisesti.
///
/// Esimerkkitoteutus verkkotunnukselle, jossa kahta kirjaa pidetään yhtenä kirjana, jos niiden ISBN-koodi vastaa, vaikka muodot poikkeavat toisistaan:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Kuinka voin verrata kahta erilaista tyyppiä?
///
/// Tyyppiä, johon voit verrata, ohjataan `PartialEq'-tyypin parametrilla.
/// Muutetaan esimerkiksi edellistä koodia hieman:
///
/// ```
/// // Johdanna toteutetaan<BookFormat>==<BookFormat>vertailut
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // Toteuta<Book>==<BookFormat>vertailut
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // Toteuta<BookFormat>==<Book>vertailut
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// Vaihtamalla `impl PartialEq for Book`: stä `impl PartialEq<BookFormat> for Book`: ksi sallimme BookFormat-tiedostojen vertaamisen Book-tiedostoihin.
///
/// Yllä olevan kaltainen vertailu, joka jättää huomiotta jotkin rakennekentät, voi olla vaarallista.Se voi helposti johtaa osittaisen vastaavuussuhteen vaatimusten tahattomaan rikkomiseen.
/// Esimerkiksi, jos pidämme yllä olevan `PartialEq<Book>`: n `BookFormat`-toteutuksen ja lisäämme `PartialEq<Book>`: n `Book`-toteutuksen (joko `#[derive]`: n tai ensimmäisen esimerkin manuaalisen toteutuksen kautta), tulos rikkoo transitiivisuutta:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// Tällä menetelmällä testataan `self`-ja `other`-arvojen olevan yhtä suuret, ja `==` käyttää sitä.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// Tämä menetelmä testaa `!=`: ää.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// Johda makro, joka tuottaa implantaatin trait `PartialEq`: stä.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait tasa-arvon vertailuihin, jotka ovat [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation).
///
/// Tämä tarkoittaa, että sen lisäksi, että `a == b` ja `a != b` ovat tiukkoja käänteisiä, tasa-arvon on oltava (kaikille `a`, `b` ja `c`):
///
/// - reflexive: `a == a`;
/// - symmetrinen: `a == b` tarkoittaa `b == a`;ja
/// - transitiivinen: `a == b` ja `b == c` tarkoittaa `a == c`: ää.
///
/// Kääntäjä ei voi tarkistaa tätä ominaisuutta, joten `Eq` tarkoittaa [`PartialEq`]: ää eikä sillä ole ylimääräisiä menetelmiä.
///
/// ## Derivable
///
/// Tätä trait: tä voidaan käyttää `#[derive]`: n kanssa.
/// Kun `derive`d, koska `Eq`: llä ei ole ylimääräisiä menetelmiä, se vain ilmoittaa kääntäjälle, että tämä on vastaavuussuhde eikä osittainen vastaavuussuhde.
///
/// Huomaa, että `derive`-strategia edellyttää, että kaikki kentät ovat `Eq`, jota ei aina haluta.
///
/// ## Kuinka voin ottaa `Eq`: n käyttöön?
///
/// Jos et voi käyttää `derive`-strategiaa, määritä, että tyypisi toteuttaa `Eq`: n, jolla ei ole menetelmiä:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // tätä menetelmää käyttää yksinomaan#[johdetaan] väittämään, että jokainen tyypin komponentti toteuttaa itse [johdon], nykyinen johdannainen infrastruktuuri tarkoittaa tämän väitteen tekemistä käyttämättä menetelmää tällä trait: llä.
    //
    //
    // Tätä ei pitäisi koskaan toteuttaa käsin.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// Johda makro, joka tuottaa implantaatin trait `Eq`: stä.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: tätä rakennetta käyttää vain#[derive] to
// väittävät, että jokainen tyypin komponentti toteuttaa Eq.
//
// Tämän rakenteen ei pitäisi koskaan näkyä käyttäjäkoodissa.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// `Ordering` on kahden vertailun tulos.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// Tilaukset, joissa vertailtu arvo on pienempi kuin toinen.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// Tilaukset, joissa vertailtu arvo on yhtä suuri kuin toinen.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// Tilaukset, joissa vertailtu arvo on suurempi kuin toinen.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Palauttaa arvon `true`, jos tilaus on `Equal`-muunnos.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Palauttaa arvon `true`, jos tilaus ei ole `Equal`-muunnos.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Palauttaa arvon `true`, jos tilaus on `Less`-muunnos.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Palauttaa arvon `true`, jos tilaus on `Greater`-muunnos.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Palauttaa arvon `true`, jos tilaus on joko `Less`-tai `Equal`-muunnos.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Palauttaa arvon `true`, jos tilaus on joko `Greater`-tai `Equal`-muunnos.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// Kääntää `Ordering`: n.
    ///
    /// * `Less` tulee `Greater`.
    /// * `Greater` tulee `Less`.
    /// * `Equal` tulee `Equal`.
    ///
    /// # Examples
    ///
    /// Peruskäyttäytyminen:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Tätä menetelmää voidaan käyttää vertailun kääntämiseen:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // lajittele taulukko suurimmasta pienimpään.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Ketjuttaa kaksi tilausta.
    ///
    /// Palauttaa arvon `self`, kun se ei ole `Equal`.Muussa tapauksessa palauttaa arvon `other`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Ketjuttaa järjestyksen annetulla toiminnolla.
    ///
    /// Palauttaa `self`, kun se ei ole `Equal`.
    /// Muuten kutsuu `f` ja palauttaa tuloksen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// Auttajarakenne käänteiseen tilaamiseen.
///
/// Tämä rakenne on auttaja, jota voidaan käyttää [`Vec::sort_by_key`]: n kaltaisten toimintojen kanssa, ja sitä voidaan käyttää avaimen osan järjestykseen päinvastaisessa järjestyksessä.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait tyyppeille, jotka muodostavat [total order](https://en.wikipedia.org/wiki/Total_order): n.
///
/// Tilaus on kokonaistilaus, jos se on (kaikille `a`, `b` ja `c`):
///
/// - summa ja epäsymmetrinen: täsmälleen yksi `a < b`-, `a == b`-tai `a > b`-arvoista on totta;ja
/// - transitiivinen, `a < b` ja `b < c` tarkoittaa `a < c`: ää.Sama koskee sekä `==`: ää että `>`: ää.
///
/// ## Derivable
///
/// Tätä trait: tä voidaan käyttää `#[derive]`: n kanssa.
/// Kun `johdetaan`d rakenteista, se tuottaa [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order)-järjestyksen, joka perustuu strukturan jäsenten ylhäältä alas-deklarointijärjestykseen.
///
/// Kun `johdetaan`d enumeista, variantit järjestetään niiden ylhäältä alaspäin erottelevan järjestyksen mukaan.
///
/// ## Leksikografinen vertailu
///
/// Leksikografinen vertailu on operaatio, jolla on seuraavat ominaisuudet:
///  - Kahta sekvenssiä verrataan elementtittäin.
///  - Ensimmäinen yhteensopimaton elementti määrittää, mikä sekvenssi on leksikografisesti pienempi tai suurempi kuin toinen.
///  - Jos yksi sekvenssi on toisen etuliite, lyhyempi sekvenssi on leksikografisesti pienempi kuin toinen.
///  - Jos kahdella sekvenssillä on vastaavat elementit ja ne ovat samanpituisia, niin sekvenssit ovat leksikografisesti samat.
///  - Tyhjä jakso on leksikografisesti pienempi kuin mikään muu kuin tyhjä jakso.
///  - Kaksi tyhjää sekvenssiä ovat leksikografisesti samat.
///
/// ## Kuinka voin ottaa `Ord`: n käyttöön?
///
/// `Ord` vaatii, että tyyppi on myös [`PartialOrd`] ja [`Eq`] (mikä vaatii [`PartialEq`]).
///
/// Sitten sinun on määritettävä toteutus [`cmp`]: lle.Saatat olla hyödyllistä käyttää [`cmp`]: tä tyypin kentissä.
///
/// [`PartialEq`]: n, [`PartialOrd`]: n ja `Ord`: n *toteutusten* on * sovittava keskenään.
/// Eli `a.cmp(b) == Ordering::Equal` vain ja vain, jos `a == b` ja `Some(a.cmp(b)) == a.partial_cmp(b)` kaikille `a`: lle ja `b`: lle.
/// On helppo saada vahingossa erimielisyydet johtamalla osa traits: stä ja toteuttamalla toiset manuaalisesti.
///
/// Tässä on esimerkki, jossa haluat lajitella ihmiset vain korkeuden mukaan `id` ja `name` huomioon ottamatta:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// Tämä menetelmä palauttaa [`Ordering`]: n välillä `self`: n ja `other`: n.
    ///
    /// Tavanomaisesti `self.cmp(&other)` palauttaa lauseketta `self <operator> other` vastaavan järjestyksen, jos se on tosi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Vertaa ja palauttaa kahden arvon maksimiarvon.
    ///
    /// Palauttaa toisen argumentin, jos vertailun perusteella ne ovat samat.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// Vertaa ja palauttaa kahden arvon vähimmäisarvot.
    ///
    /// Palauttaa ensimmäisen argumentin, jos vertailun perusteella ne ovat samat.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// Rajoita arvo tietylle aikavälille.
    ///
    /// Palauttaa arvon `max`, jos `self` on suurempi kuin `max`, ja `min`, jos `self` on pienempi kuin `min`.
    /// Muuten tämä palauttaa arvon `self`.
    ///
    /// # Panics
    ///
    /// Panics jos `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// Johda makro, joka tuottaa implantaatin trait `Ord`: stä.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait arvoille, joita voidaan verrata lajittelujärjestykseen.
///
/// Vertailun on täytettävä kaikki `a`, `b` ja `c`:
///
/// - epäsymmetria: jos `a < b`, sitten `!(a > b)`, samoin kuin `a > b`, mikä viittaa `!(a < b)`: ään;ja
/// - transitiivisuus: `a < b` ja `b < c` tarkoittaa `a < c`: ää.Sama koskee sekä `==`: ää että `>`: ää.
///
/// Huomaa, että nämä vaatimukset tarkoittavat, että trait itsessään on toteutettava symmetrisesti ja siirtyvästi: jos `T: PartialOrd<U>` ja `U: PartialOrd<V>`, niin `U: PartialOrd<T>` ja `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// Tätä trait: tä voidaan käyttää `#[derive]`: n kanssa.Kun `johdetaan`d rakenteista, se tuottaa leksikografisen järjestyksen, joka perustuu strukturan jäsenten ylhäältä alas-ilmoitusjärjestykseen.
/// Kun `johdetaan`d enumeista, variantit järjestetään niiden ylhäältä alaspäin erottelevan järjestyksen mukaan.
///
/// ## Kuinka voin ottaa `PartialOrd`: n käyttöön?
///
/// `PartialOrd` vaatii vain [`partial_cmp`]-menetelmän toteuttamisen, kun taas muut luodaan oletustoteutuksista.
///
/// On kuitenkin edelleen mahdollista toteuttaa muut erikseen tyypeille, joilla ei ole kokonaisjärjestystä.
/// Esimerkiksi liukulukuluvuille `NaN < 0 == false` ja `NaN >= 0 == false` (vrt.
/// IEEE 754-2008-osio 5.11).
///
/// `PartialOrd` edellyttää, että tyyppisi on [`PartialEq`].
///
/// [`PartialEq`]: n, `PartialOrd`: n ja [`Ord`]: n *toteutusten* on * sovittava keskenään.
/// On helppo saada vahingossa erimielisyydet johtamalla osa traits: stä ja toteuttamalla toiset manuaalisesti.
///
/// Jos tyyppi on [`Ord`], voit ottaa [`partial_cmp`]: n käyttöön [`cmp`]: llä:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// Saatat myös olla hyödyllistä käyttää [`partial_cmp`]: tä tyypin kentissä.
/// Tässä on esimerkki `Person`-tyypeistä, joilla on liukuluku `height`-kenttä, joka on ainoa lajittelussa käytettävä kenttä:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Tämä menetelmä palauttaa `self`-ja `other`-arvojen välisen järjestyksen, jos sellainen on olemassa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// Kun vertailu on mahdotonta:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// Tämä menetelmä testaa vähemmän kuin (malleille `self` ja `other`), ja `<`-operaattori käyttää sitä.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Tämä menetelmä testaa vähemmän tai yhtä suuri kuin (`self`: lle ja `other`: lle) ja `<=`-operaattori käyttää sitä.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// Tämä menetelmä testaa enemmän kuin (malleille `self` ja `other`), ja `>`-operaattori käyttää sitä.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// Tämä menetelmä testaa vähintään (`self` ja `other`) tai on yhtä suuri kuin `>=`-operaattori.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// Johda makro, joka tuottaa implantaatin trait `PartialOrd`: stä.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Vertaa ja palauttaa kahden arvon vähimmäisarvot.
///
/// Palauttaa ensimmäisen argumentin, jos vertailun perusteella ne ovat samat.
///
/// Sisäisesti käyttää aliasta [`Ord::min`]: ään.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Palauttaa vähintään kahden arvon määritetyn vertailutoiminnon suhteen.
///
/// Palauttaa ensimmäisen argumentin, jos vertailun perusteella ne ovat samat.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Palauttaa elementin, joka antaa määritetyn funktion vähimmäisarvon.
///
/// Palauttaa ensimmäisen argumentin, jos vertailun perusteella ne ovat samat.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Vertaa ja palauttaa kahden arvon maksimiarvon.
///
/// Palauttaa toisen argumentin, jos vertailun perusteella ne ovat samat.
///
/// Sisäisesti käyttää aliasta [`Ord::max`]: ään.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Palauttaa kahden arvon maksimimäärän suhteessa määritettyyn vertailutoimintoon.
///
/// Palauttaa toisen argumentin, jos vertailun perusteella ne ovat samat.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Palauttaa elementin, joka antaa määritetyn funktion suurimman arvon.
///
/// Palauttaa toisen argumentin, jos vertailun perusteella ne ovat samat.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// PartialEq-, Eq-, PartialOrd-ja Ord-sovellusten toteutus primitiivisille tyypeille
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // Tässä oleva järjestys on tärkeä optimaalisen kokoonpanon aikaansaamiseksi.
                    // Katso lisätietoja <https://github.com/rust-lang/rust/issues/63758>: stä.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // Suoratoisto i8: een ja eron muuntaminen tilaukseksi tuottaa optimaalisemman kokoonpanon.
            //
            // Katso lisätietoja <https://github.com/rust-lang/rust/issues/66780>: stä.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // TURVALLISUUS: bool kun i8 palauttaa arvon 0 tai 1, joten ero ei voi olla mitään muuta
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &osoittimet

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}