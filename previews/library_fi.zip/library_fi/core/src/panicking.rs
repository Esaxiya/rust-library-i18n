//! Panic-tuki libcorelle
//!
//! Ydinkirjasto ei voi määritellä paniikkia, mutta se *julistaa* paniikkia.
//! Tämä tarkoittaa sitä, että libcoren sisällä olevat toiminnot ovat sallittuja panic: lle, mutta ollakseen hyödyllinen ylävirran crate: n on määriteltävä paniikki, jotta libcore toimii.
//! Nykyinen paniikkiliitäntä on:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Tämä määritelmä sallii panikoinnin minkä tahansa yleisen viestin kanssa, mutta se ei salli epäonnistumista `Box<Any>`-arvon kanssa.
//! (`PanicInfo` sisältää vain `&(dyn Any + Send)`: n, jota varten täytämme nuken arvon kohdassa PanicInfo::internal_constructor.) Syynä tähän on se, että libcore ei saa allokoida.
//!
//!
//! Tämä moduuli sisältää muutamia muita paniikkitoimintoja, mutta nämä ovat vain tarvittavia kääntäjän lang-elementtejä.Kaikki panics kanavoidaan tämän yhden toiminnon kautta.
//! Todellinen symboli ilmoitetaan `#[panic_handler]`-attribuutin kautta.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Libcore `panic!`-makron taustalla oleva toteutus, kun muotoilua ei käytetä.
#[cold]
// Älä koskaan inline, ellei panic_immediate_abort välttää koodin paisuminen puhelusivustoissa niin paljon kuin mahdollista
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // jota codegen tarvitsee panic: lle ylivirtauksessa ja muissa `Assert` MIR-päätteissä
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Käytä Arguments::new_v1: ää format_args! ("{}", Lausekkeen) sijaan pienentämään kokoa.
    // The format_args!makro käyttää str: n Display trait: tä kirjoittaakseen lausekkeen, joka kutsuu Formatter::pad: ää, jonka on sovitettava merkkijonon katkaisu ja täyte (vaikka mitään ei käytetä täällä).
    //
    // Arguments::new_v1: n käyttö voi antaa kääntäjän jättää Formatter::pad: n pois binäärilähdöstä, mikä säästää muutaman kilotavun.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // tarvitaan const-arvioidulle panics: lle
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // jota codegen tarvitsee panic: lle OOB array/slice-yhteydessä
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Libcore `panic!`-makron taustalla oleva toteutus muotoilua käytettäessä.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // HUOMAUTUS Tämä toiminto ei koskaan ylitä FFI-rajaa;se on Rust-to-Rust-puhelu, joka ratkaistaan `#[panic_handler]`-toiminnolle.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // TURVALLISUUS: `panic_impl` on määritelty turvallisessa Rust-koodissa ja on siten turvallista soittaa.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Sisäinen toiminto `assert_eq!`-ja `assert_ne!`-makroille
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}