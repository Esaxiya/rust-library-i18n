//! Primitiivinen traits ja tyypit, jotka edustavat tyyppien perusominaisuuksia.
//!
//! Rust-tyypit voidaan luokitella useilla hyödyllisillä tavoilla niiden luontaisten ominaisuuksien mukaan.
//! Nämä luokitukset ovat edustettuina nimellä traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Tyypit, jotka voidaan siirtää säiereiden yli.
///
/// Tämä trait toteutetaan automaattisesti, kun kääntäjä toteaa sen olevan tarkoituksenmukainen.
///
/// Esimerkki muusta kuin `` Lähetä ''-tyypistä on referenssilaskuri [`rc::Rc`][`Rc`].
/// Jos kaksi ketjua yrittää kloonata [`Rc`]: t, jotka osoittavat samaan viitteeseen laskettuun arvoon, he saattavat yrittää päivittää viitemäärän samanaikaisesti, mikä on [undefined behavior][ub], koska [`Rc`] ei käytä atomioperaatioita.
///
/// Sen serkku [`sync::Arc`][arc] käyttää atomioperaatioita (joista aiheutuu jonkin verran ylimääräisiä kustannuksia) ja on siten `Send`.
///
/// Katso lisätietoja [the Nomicon](../../nomicon/send-and-sync.html): stä.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Tyypit, joiden koko on vakio, tunnetaan kokoamisajankohtana.
///
/// Kaikilla tyypin parametreilla on implisiittinen sidos `Sized`.Erityistä syntaksia `?Sized` voidaan käyttää poistamaan tämä sidos, jos se ei ole tarkoituksenmukaista.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // rakenne FooUse(Foo<[i32]>);//virhe: kokoa ei ole otettu käyttöön mallille [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Ainoa poikkeus on trait: n implisiittinen `Self`-tyyppi.
/// trait: llä ei ole implisiittistä `Sized`-sidosta, koska se ei ole yhteensopiva [trait-objektin] kanssa, joissa trait: n on määritelmänsä mukaan työskenneltävä kaikkien mahdollisten toteuttajien kanssa, joten se voi olla minkä tahansa kokoinen.
///
///
/// Vaikka Rust antaa sinun sitoa `Sized` trait-laitteeseen, et voi käyttää sitä muodostamaan trait-objektia myöhemmin:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // olkoon y: &dyn-palkki= &Impl;//virhe: trait `Bar`: stä ei voida tehdä kohdetta
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // esimerkiksi Defaultille, mikä edellyttää, että `[T]: !Default` on arvioitavissa
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Tyypit, jotka voivat olla "unsized" dynaamisen kokoisiksi.
///
/// Esimerkiksi kokoinen taulukotyyppi `[i8; 2]` toteuttaa `Unsize<[i8]>` ja `Unsize<dyn fmt::Debug>`.
///
/// Kääntäjä tarjoaa kaikki `Unsize`-sovellukset automaattisesti.
///
/// `Unsize` toteutetaan:
///
/// - `[T; N]` on `Unsize<[T]>`
/// - `T` on `Unsize<dyn Trait>`, kun `T: Trait`
/// - `Foo<..., T, ...>` on `Unsize<Foo<..., U, ...>>`, jos:
///   - `T: Unsize<U>`
///   - Foo on rakenne
///   - Vain `Foo`: n viimeisellä kentällä on tyyppi, johon liittyy `T`
///   - `T` ei ole osa minkään muun kentän tyyppiä
///   - `Bar<T>: Unsize<Bar<U>>`, jos `Foo`: n viimeisellä kentällä on tyyppi `Bar<T>`
///
/// `Unsize` käytetään yhdessä [`ops::CoerceUnsized`]: n kanssa, jotta "user-defined"-säiliöt, kuten [`Rc`], voivat sisältää dynaamisen kokoisia tyyppejä.
/// Katso lisätietoja [DST coercion RFC][RFC982]-ja [the nomicon entry on coercion][nomicon-coerce]-laitteista.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Vaaditaan trait vakioille, joita käytetään kuvion otteluissa.
///
/// Mikä tahansa `PartialEq`: n johtava tyyppi toteuttaa tämän trait: n automaattisesti * riippumatta siitä, toteutetaanko sen tyyppisillä parametreilla `Eq`.
///
/// Jos `const`-elementissä on jokin tyyppi, joka ei toteuta tätä trait: tä, kyseinen tyyppi joko (1.) ei toteuta `PartialEq`: ää (mikä tarkoittaa, että vakio ei tarjoa vertailumenetelmää, jonka koodin luonti oletetaan olevan käytettävissä), tai (2.), jonka se toteuttaa *omansa*`PartialEq`-version versio (jonka oletetaan olevan rakenteellisen tasa-arvon vertailun vastainen).
///
///
/// Kummassakin yllä olevasta skenaariosta hylkäämme tällaisen vakion käytön kuvion vastaavuudessa.
///
/// Katso myös [structural match RFC][RFC1445] ja [issue 63438], jotka motivoivat siirtymistä attribuuttipohjaisesta suunnittelusta tähän trait-malliin.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Vaaditaan trait vakioille, joita käytetään kuvion otteluissa.
///
/// Mikä tahansa tyyppi, joka johtaa `Eq`: n, toteuttaa tämän trait: n automaattisesti * riippumatta siitä, toteutetaanko sen tyyppisillä parametreilla `Eq`.
///
/// Tämä on hakata kiertämään rajoitusta tyypin järjestelmässä.
///
/// # Background
///
/// Haluamme vaatia, että kuviootteluissa käytetyillä const-tyypeillä on attribuutti `#[derive(PartialEq, Eq)]`.
///
/// Ihanteellisemmassa maailmassa voisimme tarkistaa tämän vaatimuksen tarkistamalla vain, että annettu tyyppi toteuttaa sekä `StructuralPartialEq` trait *että*`Eq` trait.
/// Sinulla voi kuitenkin olla ADT: itä, jotka *tekevät*`derive(PartialEq, Eq)`, ja olla tapaus, jonka haluamme kääntäjän hyväksyvän, mutta vakion tyyppi ei kuitenkaan toteuta `Eq`: ää.
///
/// Nimittäin tällainen tapaus:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Yllä olevan koodin ongelma on, että `Wrap<fn(&())>` ei toteuta `PartialEq`: ää eikä `Eq`: tä, koska `` for <'a> fn(&'a _)` does not implement those traits.)
///
/// Siksi emme voi luottaa naiiveihin `StructuralPartialEq`-ja `Eq`-tarkistuksiin.
///
/// Hakkerina kiertääksesi tätä, käytämme kahta erillistä traits-pistettä, jotka molemmat johdetut (`#[derive(PartialEq)]` ja `#[derive(Eq)]`) ovat injektoineet, ja tarkistamme, että molemmat ovat läsnä osana rakenteellisen ottelun tarkistusta.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Tyypit, joiden arvot voidaan kopioida yksinkertaisesti kopioimalla bittiä.
///
/// Oletusarvoisesti muuttujasidonnalla on 'siirrä semantiikka'.Toisin sanoen:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` on siirtynyt `y`: ään, joten sitä ei voida käyttää
///
/// // println! ("{: ?}", x);//virhe: siirretyn arvon käyttö
/// ```
///
/// Jos tyyppi kuitenkin toteuttaa `Copy`: n, sillä on sen sijaan 'kopiosemantiikka':
///
/// ```
/// // Voimme johtaa `Copy`-toteutuksen.
/// // `Clone` tarvitaan myös, koska se on `Copy`: n supermuotokuva.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` on kopio `x`: stä
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// On tärkeää huomata, että näissä kahdessa esimerkissä ainoa ero on, saako `x`: n käyttää tehtävän jälkeen.
/// Konepellin alla sekä kopiointi että siirto voivat johtaa bittien kopiointiin muistiin, vaikka tämä joskus optimoidaankin pois.
///
/// ## Kuinka voin ottaa `Copy`: n käyttöön?
///
/// `Copy` voidaan ottaa käyttöön tyypillesi kahdella tavalla.Yksinkertaisin on käyttää `derive`: ää:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Voit myös ottaa `Copy`: n ja `Clone`: n käyttöön manuaalisesti:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Näiden kahden välillä on pieni ero: `derive`-strategia asettaa myös `Copy`: n sidottu tyypin parametreihin, mikä ei ole aina toivottavaa.
///
/// ## Mitä eroa on `Copy`: llä ja `Clone`: llä?
///
/// Kopiot tapahtuvat epäsuorasti, esimerkiksi osana tehtävää `y = x`.`Copy`: n toiminta ei ole ylikuormitettavissa;se on aina yksinkertainen bittiviisa kopio.
///
/// Kloonaus on nimenomainen toiminta, `x.clone()`.[`Clone`]: n käyttöönotto voi tarjota minkä tahansa tyyppikohtaisen toiminnan, joka tarvitaan arvojen turvalliseen kopiointiin.
/// Esimerkiksi [`Clone`] for [`String`]: n käyttöönoton on kopioitava teräväpiirinen merkkijonopuskuri kasaan.
/// Yksinkertainen bittikopio [`String`]-arvoista vain kopioi osoittimen, mikä johtaa kaksinkertaiseen vapaaseen viivaan.
/// Tästä syystä [`String`] on [`Clone`], mutta ei `Copy`.
///
/// [`Clone`] on `Copy`: n supersuoja, joten kaiken, mikä on `Copy`, on myös toteutettava [`Clone`].
/// Jos tyyppi on `Copy`, sen [`Clone`]-toteutuksen täytyy palauttaa vain `*self` (katso yllä oleva esimerkki).
///
/// ## Milloin tyypini voi olla `Copy`?
///
/// Tyyppi voi toteuttaa `Copy`: n, jos kaikki sen komponentit toteuttavat `Copy`: n.Esimerkiksi tämä rakenne voi olla `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Rakenne voi olla `Copy` ja [`i32`] on `Copy`, joten `Point` voi olla `Copy`.
/// Sitä vastoin harkitse
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Struct `PointList` ei voi toteuttaa `Copy`: ää, koska [`Vec<T>`] ei ole `Copy`.Jos yritämme johtaa `Copy`-toteutusta, saat virheilmoituksen:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Jaetut viitteet (`&T`) ovat myös `Copy`, joten tyyppi voi olla `Copy`, vaikka siinä olisi jaettuja viitteitä tyyppeistä `T`, jotka eivät ole * `Copy`.
/// Harkitse seuraavaa rakennetta, joka voi toteuttaa `Copy`: n, koska sillä on vain *jaettu viite* ei-kopiointityyppiin `PointList` ylhäältä:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Milloin *ei* voi olla tyyppiäni `Copy`?
///
/// Joitakin tyyppejä ei voida kopioida turvallisesti.Esimerkiksi `&mut T`: n kopiointi luo aliaksen muutettavan viitteen.
/// [`String`]: n kopiointi merkitsisi päällekkäistä vastuuta [String`]-puskurin hallinnasta, mikä johtaisi kaksinkertaiseen ilmaiseen.
///
/// Jälkimmäisestä tapauksesta voidaan todeta, että mikä tahansa [`Drop`]: tä käyttävä tyyppi ei voi olla `Copy`, koska se hallinnoi joitain resursseja omien [`size_of::<T>`]-tavujensa lisäksi.
///
/// Jos yrität ottaa `Copy`: n käyttöön strukturissa tai enumissa, joka sisältää ei-Kopio-tietoja, saat virheen [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Milloin *minun* pitäisi olla tyypini `Copy`?
///
/// Yleisesti ottaen, jos _can_-tyyppisi toteuttaa `Copy`: n, sen pitäisi.
/// Muista kuitenkin, että `Copy`: n käyttöönotto on osa tyypillistä julkista sovellusliittymää.
/// Jos future-tyypistä saattaa tulla ei-kopioitua, `Copy`-toteutus voi olla järkevää jättää pois nyt, jotta vältetään rikkomaton API-muutos.
///
/// ## Lisätoteuttajat
///
/// [implementors listed below][impls]: n lisäksi seuraavat tyypit toteuttavat myös `Copy`: n:
///
/// * Toimintokohteiden tyypit (ts. Kullekin toiminnolle määritetyt erilliset tyypit)
/// * Toimintojen osoittimen tyypit (esim. `fn() -> i32`)
/// * Matriisityypit, kaikenkokoisille, jos tuotetyypissä on myös `Copy` (esim. `[i32; 123456]`)
/// * Tuple-tyypit, jos jokainen komponentti toteuttaa myös `Copy`: n (esim. `()`, `(i32, bool)`)
/// * Suljetustyypit, jos ne eivät kerää arvoa ympäristöstä tai jos kaikki tällaiset kaapatut arvot toteuttavat `Copy`: n itse.
///   Huomaa, että jaetulla viitteellä kaapatut muuttujat toteuttavat aina `Copy`: n (vaikka referenssi ei myöskään), kun taas muutettavan viitteen siepatut muuttujat eivät koskaan toteuta `Copy`: tä.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Tämä sallii kopioida tyypin, joka ei toteuta `Copy`: tä käyttöiän tyydyttämättömien rajojen vuoksi (kopioi `A<'_>`, kun vain `A<'static>: Copy` ja `A<'_>: Clone`).
// Meillä on tämä ominaisuus tässä toistaiseksi vain siksi, että `Copy`: ssä on melko paljon olemassa olevia erikoistumisia, jotka ovat jo olemassa vakiokirjastossa, eikä tällä tavalla ole mitään tapaa toimia turvallisesti.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Johda makro, joka tuottaa implantaatin trait `Copy`: stä.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Tyypit, joille on turvallista jakaa viitteitä ketjujen välillä.
///
/// Tämä trait toteutetaan automaattisesti, kun kääntäjä toteaa sen olevan tarkoituksenmukainen.
///
/// Tarkka määritelmä on: tyyppi `T` on [`Sync`] vain ja vain, jos `&T` on [`Send`].
/// Toisin sanoen, jos [undefined behavior][ub] (mukaan lukien tietokilpailut) ei ole mahdollista ohitettaessa `&T`-viitteitä ketjujen välillä.
///
/// Kuten voidaan odottaa, primitiiviset tyypit, kuten [`u8`] ja [`f64`], ovat kaikki [`Sync`], ja niin ovat myös yksinkertaiset aggregaattityypit, jotka sisältävät niitä, kuten joukot, rakenteet ja enumit.
/// Lisää esimerkkejä [`Sync`]-perustyypeistä ovat "immutable"-tyypit, kuten `&T`, ja tyypit, joilla on yksinkertainen perinnöllinen muutettavuus, kuten [`Box<T>`][box], [`Vec<T>`][vec] ja useimmat muut kokoelmatyypit.
///
/// (Yleisten parametrien on oltava [`Sync`], jotta niiden säilö on [Synkronoi].)
///
/// Hieman yllättävä seuraus määritelmästä on, että `&mut T` on `Sync` (jos `T` on `Sync`), vaikka näyttää siltä, että se saattaisi tarjota synkronoimattomia mutaatioita.
/// Temppu on, että jaetun viitteen (ts. `& &mut T`) takana olevasta muutettavasta viitteestä tulee vain lukukelpoinen, ikään kuin se olisi `& &T`.
/// Siksi ei ole riskiä datakilpailusta.
///
/// Tyypit, jotka eivät ole `Sync`, ovat tyyppejä, joissa "interior mutability" ei ole langattomassa muodossa, kuten [`Cell`][cell] ja [`RefCell`][refcell].
/// Nämä tyypit mahdollistavat sisällön mutaation jopa muuttumattoman, jaetun viitteen avulla.
/// Esimerkiksi `set`-menetelmä [`Cell<T>`][cell]: ssä vie `&self`: n, joten se vaatii vain jaetun viitteen [`&Cell<T>`][cell].
/// Menetelmä ei suorita synkronointia, joten [`Cell`][cell] ei voi olla `Sync`.
///
/// Toinen esimerkki ei-Synkron-tyypistä on referenssilaskuri [`Rc`][rc].
/// Kun otetaan huomioon mikä tahansa viite [`&Rc<T>`][rc], voit kloonata uuden [`Rc<T>`][rc]: n muokkaamalla vertailumääriä ei-atomisella tavalla.
///
/// Tapauksissa, joissa tarvitaan langattomaa sisätilojen muuttuvuutta, Rust tarjoaa [atomic data types]: n sekä nimenomaisen lukituksen [`sync::Mutex`][mutex]: n ja [`sync::RwLock`][rwlock]: n kautta.
/// Nämä tyypit varmistavat, että mutaatiot eivät voi aiheuttaa tietokilpailuja, joten tyypit ovat `Sync`.
/// Samoin [`sync::Arc`][arc] tarjoaa langankestävän analogin [`Rc`][rc]: stä.
///
/// Kaikkien tyyppien, joilla on sisäinen muuntuvuus, on myös käytettävä [`cell::UnsafeCell`][unsafecell]-kääriä value(s): n ympärillä, joka voidaan mutatoida jaetun viitteen avulla.
/// Tämän tekemättä jättäminen on [undefined behavior][ub].
/// Esimerkiksi [`transmute`][transmute]-ing `&T`: stä `&mut T`: ään on virheellinen.
///
/// Katso [the Nomicon][nomicon-send-and-sync] lisätietoja `Sync`: stä.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): kun tuki muistiinpanojen lisäämiseksi `rustc_on_unimplemented`: ssä laskeutuu beetaversiossa, ja sitä on laajennettu tarkistamaan, onko sulkeutumista missä tahansa vaatimusketjussa, laajenna sitä sellaisenaan (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Nollakokoinen tyyppi merkitsi asioita, jotka "act like" omistaa `T`: n.
///
/// `PhantomData<T>`-kentän lisääminen tyyppiin kertoo kääntäjälle, että tyyppi toimii ikään kuin se tallentaa `T`-tyypin arvon, vaikka se ei oikeastaan.
/// Näitä tietoja käytetään laskettaessa tiettyjä turvallisuusominaisuuksia.
///
/// Katso tarkempi kuvaus `PhantomData<T>`: n käytöstä [the Nomicon](../../nomicon/phantom-data.html): stä.
///
/// # Kauhea nuotti 👻👻👻
///
/// Vaikka molemmilla on pelottavia nimiä, `PhantomData` ja 'fantomityypit' ovat toisiinsa liittyviä, mutta eivät identtisiä.Fantomityyppinen parametri on yksinkertaisesti tyyppiparametri, jota ei koskaan käytetä.
/// Rust: ssä tämä saa kääntäjän usein valittamaan, ja ratkaisu on lisätä "dummy"-käyttö `PhantomData`: n kautta.
///
/// # Examples
///
/// ## Käyttämättömät käyttöiän parametrit
///
/// Ehkä yleisin `PhantomData`: n käyttötapaus on rakenne, jolla on käyttämätön elinikäinen parametri, tyypillisesti osana jotakin vaarallista koodia.
/// Esimerkiksi tässä on struct `Slice`, jossa on kaksi osoitinta tyyppiä `*const T`, oletettavasti osoittavat jonoon jonnekin:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Tarkoituksena on, että taustalla olevat tiedot ovat voimassa vain koko käyttöiän `'a`, joten `Slice` ei saisi elää `'a`: ää vanhempaa.
/// Tätä tarkoitusta ei kuitenkaan ilmaista koodissa, koska käyttöikää `'a` ei käytetä, joten ei ole selvää, mihin tietoihin sitä sovelletaan.
/// Voimme korjata tämän käskemällä kääntäjää toimimaan *ikään kuin*`Slice`-rakenne sisältäisi viitteen `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Tämä puolestaan vaatii merkinnän `T: 'a`, mikä osoittaa, että kaikki viitteet `T`: ssä ovat voimassa koko `'a`: n käyttöiän ajan.
///
/// Kun alustat `Slice`: n, annat vain arvon `PhantomData` kentälle `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Käyttämättömät tyypin parametrit
///
/// Joskus tapahtuu, että sinulla on käyttämättömiä tyyppiparametreja, jotka osoittavat, minkä tyyppiseen tietoon rakenne "tied" kuuluu, vaikka kyseistä tietoa ei itse asiassa löydy itse strukturista.
/// Tässä on esimerkki [FFI]: n kanssa.
/// Vieras käyttöliittymä käyttää tyypin `*mut ()` kahvoita viitaten erityyppisiin Rust-arvoihin.
/// Seuraamme Rust-tyyppiä käyttämällä phantom type-parametriä strukturalla `ExternalResource`, joka kietoo kahvan.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Omistusoikeus ja pudotustarkistus
///
/// `PhantomData<T>`-tyyppisen kentän lisääminen osoittaa, että tyypilläsi on tyypin `T` tietoja.Tämä puolestaan tarkoittaa, että kun tyyppi pudotetaan, se voi pudottaa yhden tai useamman tyypin `T` esiintymän.
/// Tämä vaikuttaa Rust-kääntäjän [drop check]-analyysiin.
///
/// Jos strukturisi ei itse asiassa *omista* tyypin `T` tietoja, on parempi käyttää viitetyyppiä, kuten `PhantomData<&'a T>` (ideally) tai `PhantomData<*const T>` (jos käyttöikää ei ole), jotta ei ilmoiteta omistajuutta.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Kääntäjä-sisäinen trait käytetään osoittamaan enum-erottelijoiden tyyppi.
///
/// Tämä trait otetaan automaattisesti käyttöön kaikentyyppisille laitteille, eikä se lisää mitään takuita [`mem::Discriminant`]: lle.
/// Muunnos `DiscriminantKind::Discriminant`: n ja `mem::Discriminant`: n välillä on **määrittelemätöntä käyttäytymistä**.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Erottelijan tyyppi, jonka on täytettävä `mem::Discriminant`: n vaatima trait bounds.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Kääntäjä-sisäinen trait käytetään määrittämään, sisältääkö tyyppi `UnsafeCell`: ää sisäisesti, muttei indirektion kautta.
///
/// Tämä vaikuttaa esimerkiksi siihen, asetetaanko tämän tyyppinen `static` vain luku-staattiseen vai kirjoitettavaan staattiseen muistiin.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Tyypit, joita voidaan turvallisesti siirtää kiinnityksen jälkeen.
///
/// Itse Rust: llä ei ole käsitystä kiinteistä tyypeistä, ja se pitää liikkeet (esim. Tehtävän kautta tai [`mem::replace`]) aina turvallisina.
///
/// [`Pin`][Pin]-tyyppiä käytetään sen sijaan estämään liikkeet tyyppijärjestelmän läpi.[`Pin<P<T>>`][Pin]-kääreeseen käärittyjä osoittimia `P<T>` ei voida siirtää pois.
/// Katso lisätietoja kiinnittämisestä [`pin` module]-dokumentaatiosta.
///
/// `Unpin` trait: n käyttöönotto `T`: lle poistaa tyypin kiinnittämisen rajoitukset, mikä sallii `T`: n siirtämisen [`Pin<P<T>>`][Pin]: stä esimerkiksi [`mem::replace`]: n kaltaisilla toiminnoilla.
///
///
/// `Unpin` ei ole mitään vaikutusta kiinnittämättömiin tietoihin.
/// Erityisesti [`mem::replace`] siirtää mielellään `!Unpin`-tietoja (se toimii mille tahansa `&mut T`: lle, ei vain silloin, kun `T: Unpin`).
/// Et kuitenkaan voi käyttää [`mem::replace`]: ää [`Pin<P<T>>`][Pin]: n sisäpuolelle käärittyihin tietoihin, koska et saa tarvitsemasi `&mut T`: ää, ja *tämä* saa järjestelmän toimimaan.
///
/// Joten tämä voidaan tehdä esimerkiksi vain tyyppeille, jotka toteuttavat `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Tarvitsemme muutettavan viitteen soittamaan `mem::replace`.
/// // Voimme saada tällaisen viitteen (implicitly): llä käyttämällä `Pin::deref_mut`: ää, mutta se on mahdollista vain siksi, että `String` toteuttaa `Unpin`: n.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Tämä trait toteutetaan automaattisesti melkein kaikentyyppisille.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Merkintätyyppi, joka ei toteuta `Unpin`: ää.
///
/// Jos tyyppi sisältää `PhantomPinned`: n, se ei toteuta `Unpin`: ää oletusarvoisesti.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// `Copy`: n toteutukset primitiivisille tyypeille.
///
/// Toteutukset, joita ei voida kuvata Rust: ssä, toteutetaan `traits::SelectionContext::copy_clone_conditions()`: ssä `rustc_trait_selection`: ssä.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Jaetut viitteet voidaan kopioida, mutta muutettavissa olevat viitteet *eivät*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}