//! Moduuli lainattujen tietojen käsittelyyn.

#![stable(feature = "rust1", since = "1.0.0")]

/// trait lainaa tietoja.
///
/// Rust: ssä on tavallista tarjota tyypin erilaisia esityksiä erilaisille käyttötapauksille.
/// Esimerkiksi arvon tallennuspaikka ja hallinta voidaan valita erityisesti sopivaksi tiettyyn käyttöön osoitintyyppien, kuten [`Box<T>`] tai [`Rc<T>`], kautta.
/// Näiden minkä tahansa tyyppisten yleisten kääreiden lisäksi jotkut tyypit tarjoavat valinnaisia puolia, jotka tarjoavat mahdollisesti kalliita toimintoja.
/// Esimerkki tällaisesta tyypistä on [`String`], joka lisää mahdollisuuden laajentaa merkkijonoa perus-[`str`]: ään.
/// Tämä edellyttää lisätietojen pitämistä tarpeettomina yksinkertaiselle, muuttumattomalle merkkijonolle.
///
/// Nämä tyypit tarjoavat pääsyn taustalla oleviin tietoihin viittaamalla kyseisten tietojen tyyppiin.Niiden sanotaan olevan 'lainattu' sellaisina.
/// Esimerkiksi [`Box<T>`] voidaan lainata nimellä `T`, kun taas [`String`] voidaan lainata nimellä `str`.
///
/// Tyypit ilmaisevat, että ne voidaan lainata jonkin tyyppisenä `T` toteuttamalla `Borrow<T>`, antamalla viite `T`: ään trait: n [`borrow`]-menetelmässä.Tyyppi voi lainata ilmaiseksi useina erityyppisinä.
/// Jos se haluaa lainata tyypillisesti-jolloin taustalla olevia tietoja voidaan muuttaa, se voi lisäksi toteuttaa [`BorrowMut<T>`]: n.
///
/// Edelleen tarjottaessa toteutuksia muille traits: lle on harkittava, pitäisikö niiden käyttäytyä identtisesti perustyyppisten kanssa seurauksena toimimisesta kyseisen alla olevan tyypin edustajana.
/// Yleinen koodi käyttää tyypillisesti `Borrow<T>`: ää, kun se luottaa näiden muiden trait-toteutusten identtiseen käyttäytymiseen.
/// Nämä traits näkyvät todennäköisesti lisänä trait bounds.
///
/// Erityisesti `Eq`: n, `Ord`: n ja `Hash`: n on vastattava lainattuja ja omistettuja arvoja: `x.borrow() == y.borrow()`: n pitäisi antaa sama tulos kuin `x == y`.
///
/// Jos yleisen koodin on vain toimittava kaikentyyppisten laitteiden kanssa, jotka voivat antaa viittauksen vastaavaan tyyppiin `T`, on usein parempi käyttää [`AsRef<T>`]: ää, koska useammat tyypit voivat toteuttaa sen turvallisesti.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Tiedonkeräyksenä [`HashMap<K, V>`] omistaa sekä avaimet että arvot.Jos avaimen todelliset tiedot on kääritty jonkin tyyppiseen hallintatyyppiin, arvon tulisi kuitenkin olla mahdollista hakea viittaamalla avaimen tietoihin.
/// Esimerkiksi, jos avain on merkkijono, se todennäköisesti tallennetaan hash-kartan kanssa [`String`]: nä, kun taas haun pitäisi olla mahdollista käyttää [`&str`][`str`]: ää.
/// Siksi `insert`: n on toimittava `String`: llä, kun taas `get`: n on voitava käyttää `&str`: ää.
///
/// Hieman yksinkertaistettuna `HashMap<K, V>`: n asiaankuuluvat osat näyttävät tältä:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // kentät jätetty pois
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Koko hash-kartta on yleinen avaintyypille `K`.Koska nämä avaimet on tallennettu hash-karttaan, tämän tyypin on omistettava avaimen tiedot.
/// Kun lisäät avain-arvo-paria, kartalle annetaan sellainen `K`, ja sen on löydettävä oikea hash-ämpäri ja tarkistettava, onko avain jo olemassa kyseisen `K`: n perusteella.Siksi se vaatii `K: Hash + Eq`.
///
/// Kun etsit arvoa kartalta, joudutaan antamaan viittaus `K`: ään haettavana avaimena vaatisi aina sellaisen omistetun arvon luomista.
/// Merkkijonoavaimille tämä tarkoittaisi `String`-arvon luomista vain sellaisten tapausten etsimiseksi, joissa käytettävissä on vain `str`.
///
/// Sen sijaan `get`-menetelmä on yleinen taustalla olevien avaintietojen tyypin suhteen, jota kutsutaan yllä olevassa metodin allekirjoituksessa `Q`.Siinä todetaan, että `K` lainaa `Q`: nä vaatimalla `K: Borrow<Q>`: ää.
/// Vaadimalla lisäksi `Q: Hash + Eq`, se ilmoittaa vaatimuksesta, että `K`: llä ja `Q`: llä on `Hash`-ja `Eq` traits-toteutukset, jotka tuottavat identtisiä tuloksia.
///
/// `get`: n toteutus riippuu erityisesti identtisistä `Hash`: n toteutuksista määrittämällä avaimen hash-ämpäri kutsumalla `Hash::hash` `Q`-arvoon, vaikka se lisäsi avaimen `K`-arvosta lasketun hash-arvon perusteella.
///
///
/// Tämän seurauksena hajautuskartta rikkoutuu, jos `Q`-arvon käärivä `K` tuottaa erilaisen hajautusmerkin kuin `Q`.Kuvittele esimerkiksi, että sinulla on tyyppi, joka kääri merkkijonon, mutta vertaa ASCII-kirjaimia välittämättä heidän kirjaimistaan:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Koska kahden samanarvoisen arvon on tuotettava sama hash-arvo, `Hash`: n käyttöönoton on myös jätettävä huomioimatta ASCII-tapaus:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Voiko `CaseInsensitiveString` toteuttaa `Borrow<str>`: n?Se voi varmasti tarjota viitteen merkkijonolohkoon sisältyvän merkkijonon kautta.
/// Mutta koska sen `Hash`-toteutus eroaa, se käyttäytyy eri tavalla kuin `str`, eikä sitä sen vuoksi pidä itse asiassa toteuttaa `Borrow<str>`: ää.
/// Jos se haluaa antaa muille pääsyn taustalla olevaan `str`: ään, se voi tehdä sen `AsRef<str>`: n kautta, jolla ei ole ylimääräisiä vaatimuksia.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Lainaa ehdottomasti omistetusta arvosta.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// trait tietojen lainaamiseen.
///
/// [`Borrow<T>`]: n kumppanina tämä trait sallii tyypin lainata taustalla antamalla muutettavan viitteen.
/// Katso [`Borrow<T>`] saadaksesi lisätietoja lainanotosta toisena tyyppinä.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Lainaa kiinteästi omistetusta arvosta.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}