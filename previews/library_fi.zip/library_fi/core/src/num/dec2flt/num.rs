//! Apuohjelmatoiminnot bignumeille, joilla ei ole liikaa järkeä muuttaa menetelmiä.

// FIXME Tämän moduulin nimi on hieman valitettava, koska muut moduulit tuovat myös `core::num`: ää.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Testaa, aiheuttaako kaikkien vähemmän merkitsevien kuin `ones_place` bittien katkaisu suhteellinen virhe, joka on pienempi, yhtä suuri tai suurempi kuin 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Jos kaikki jäljellä olevat bitit ovat nollia, se on= 0.5 ULP, muuten> 0.5 Jos bittejä ei ole enää (half_bit==0), alla oleva palauttaa myös oikein.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Muuntaa ASCII-merkkijonon, joka sisältää vain desimaaliluvut, `u64`: ksi.
///
/// Ei tarkista ylivuotoja tai virheellisiä merkkejä, joten jos soittaja ei ole varovainen, tulos on väärä ja voi panic (vaikka se ei ole `unsafe`).
/// Lisäksi tyhjiä merkkijonoja käsitellään nollana.
/// Tämä toiminto on olemassa, koska
///
/// 1. `FromStr`: n käyttäminen `&[u8]`: ssä vaatii `from_utf8_unchecked`: n, mikä on huono, ja
/// 2. `integral.parse()`: n ja `fractional.parse()`: n tulosten kokoaminen on monimutkaisempi kuin koko tämä toiminto.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Muuntaa merkkijonon ASCII-numeroista bignumiksi.
///
/// Kuten `from_str_unchecked`, tämä toiminto perustuu jäsentimeen karsimaan ei-numeroita.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Peruu bignumin 64-bittiseksi kokonaisluvuksi.Panics, jos numero on liian suuri.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Poimii joukon bittejä.

/// Indeksi 0 on vähiten merkitsevä bitti ja alue on puoliksi auki tavalliseen tapaan.
/// Panics, jos sitä pyydetään purkamaan enemmän bittejä kuin mahtuisi palautustyyppiin.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}