//! Bittiä hölynpölyä positiivisilla IEEE 754-kellukkeilla.Negatiivisia lukuja ei tarvitse eikä niitä tarvitse käsitellä.
//! Normaalien liukulukujen kanoninen edustus on (frac, exp) siten, että arvo on 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)), jossa N on bittien lukumäärä.
//!
//! Subnormaalit ovat hieman erilaisia ja outoja, mutta sama periaate pätee.
//!
//! Tässä me kuitenkin edustamme niitä (sig, k) f positiivisilla, niin että arvo on f *
//! 2 <sup>e</sup> .Sen lisäksi, että "hidden bit" on eksplisiittinen, se muuttaa eksponentin niin sanotulla mantissa-siirtymällä.
//!
//! Toisin sanoen, normaalisti kellukkeet kirjoitetaan (1): nä, mutta täällä ne kirjoitetaan (2): ksi:
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Kutsumme (1): ää **murtoesitykseksi** ja (2): ää **integraaliesitykseksi**.
//!
//! Monet tämän moduulin toiminnot käsittelevät vain normaaleja numeroita.Dec2flt-rutiinit kuluttavat konservatiivisesti yleisesti oikein hidasta polkua (algoritmi M) hyvin pienille ja erittäin suurille numeroille.
//! Tuo algoritmi tarvitsee vain next_float(): n, joka käsittelee alinormaalit ja nollat.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Auttaja trait välttää päällekkäisten `f32`-ja `f64`-muunnoskoodien päällekkäisyyttä.
///
/// Katso vanhemman moduulin doc-kommentista, miksi tämä on tarpeen.
///
/// Pitäisikö **koskaan** toteuttaa muille tyypeille tai käyttää dec2flt-moduulin ulkopuolella.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Tyyppi, jota `to_bits` ja `from_bits` käyttävät.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Suorittaa raakamuutoksen kokonaislukuun.
    fn to_bits(self) -> Self::Bits;

    /// Suorittaa raakamuutoksen kokonaisluvusta.
    fn from_bits(v: Self::Bits) -> Self;

    /// Palauttaa luokan, johon tämä numero kuuluu.
    fn classify(self) -> FpCategory;

    /// Palauttaa mantissan, eksponentin ja merkin kokonaislukuina.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Dekoodaa uimurin.
    fn unpack(self) -> Unpacked;

    /// Suoratoisto pienestä kokonaisluvusta, joka voidaan esittää tarkasti.
    /// Panic, jos kokonaislukua ei voida edustaa, tämän moduulin toinen koodi varmistaa, ettei sitä koskaan anneta tapahtua.
    fn from_int(x: u64) -> Self;

    /// Hakee arvon 10 <sup>e</sup> ennalta lasketusta taulukosta.
    /// Panics `e >= CEIL_LOG5_OF_MAX_SIG`: lle.
    fn short_fast_pow10(e: usize) -> Self;

    /// Mitä nimi sanoo.
    /// Koodaaminen on helpompaa kuin sisäisen sisällön taisteleminen ja toivoen, että LLVM vakio taittaa sen.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Konservatiivinen sidottu syötteiden desimaalilukuihin, jotka eivät voi tuottaa ylivuotoa tai nollaa tai
    /// subnormaalit.Todennäköisesti maksimiarvon desimaaliluku, joten nimi.
    const MAX_NORMAL_DIGITS: usize;

    /// Kun merkittävimmällä desimaaliluvulla on tämän arvo suurempi, luku pyöristetään varmasti äärettömään.
    ///
    const INF_CUTOFF: i64;

    /// Kun merkittävimmän desimaalin tarkkuudella paikan arvo on pienempi kuin tämä, luku pyöristetään varmasti nollaan.
    ///
    const ZERO_CUTOFF: i64;

    /// Bittien lukumäärä eksponentissa.
    const EXP_BITS: u8;

    /// Bittien lukumäärä merkitsevässä merkinnässä, * piilotettu bitti mukaan lukien.
    const SIG_BITS: u8;

    /// Bittien lukumäärä merkitsevässä, * pois lukien piilotettu bitti.
    const EXPLICIT_SIG_BITS: u8;

    /// Suurin oikeudellinen eksponentti murtoesityksessä.
    const MAX_EXP: i16;

    /// Pienin oikeudellinen eksponentti murtoesityksessä, lukuun ottamatta aliarvoja.
    const MIN_EXP: i16;

    /// `MAX_EXP` integraalille edustukselle, ts. käytetyn siirron kanssa.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` koodattu (ts. offset-puolueellisuudella)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` integraalille edustukselle, ts. käytetyn siirron kanssa.
    const MIN_EXP_INT: i16;

    /// Suurin normalisoitu merkitys integraaliesityksessä.
    const MAX_SIG: u64;

    /// Pienin normalisoitu merkitys integraaliesityksessä.
    const MIN_SIG: u64;
}

// Enimmäkseen kiertotapa #34344: lle.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Palauttaa mantissan, eksponentin ja merkin kokonaislukuina.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Eksponentti bias + mantissan siirto
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe on epävarma, pyöristääkö `as` oikein kaikilla alustoilla.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Palauttaa mantissan, eksponentin ja merkin kokonaislukuina.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Eksponentti bias + mantissan siirto
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe on epävarma, pyöristääkö `as` oikein kaikilla alustoilla.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Muuntaa `Fp`: n lähimpään koneen kelluketyyppiin.
/// Ei käsittele epänormaalia tulosta.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f on 64-bittinen, joten xen mantissisiirtymä on 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Pyöristä 64-bittinen merkitys T::SIG_BITS-bitteihin puolittamalla.
/// Ei käsittele eksponentin ylivuotoa.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Säädä mantissasiirtymä
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Käänteinen `RawFloat::unpack()` normalisoiduille numeroille.
/// Panics, jos merkitys tai eksponentti eivät kelpaa normalisoiduille numeroille.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Poista piilotettu kärki
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Säädä eksponentti eksponentti bias ja mantissa siirtymä
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Jätä merkkibitti arvoon 0 ("+"), kaikki numeromme ovat positiivisia
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Muodosta subnormaali.0: n mantissa on sallittu ja rakentaa nollan.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Koodattu eksponentti on 0, merkkibitti on 0, joten meidän on vain tulkittava bitit uudelleen.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Arvioi bignumi Fp: llä.Pyöristyy 0.5 ULP: n sisällä puolitasaisella.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Katkaistiin kaikki bitit ennen indeksiä `start`, eli siirrymme oikealle oikealla `start`-määrällä, joten tämä on myös tarvitsemamme eksponentti.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Pyöreä (half-to-even) katkaistusta kärjestä riippuen.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Löytää suurimman liukuluvun numeron, joka on ehdottomasti argumenttia pienempi.
/// Ei käsittele alinormaalia, nollaa tai eksponentin alivuotoa.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Etsi pienin liukuluku, joka on ehdottomasti argumenttia suurempi.
// Tämä toiminto on kyllästyvä, ts. next_float(inf) ==inf.
// Toisin kuin useimmat tämän moduulin koodit, tämä toiminto käsittelee nollan, alinormaalit ja äärettömät.
// Kuten kaikki muutkin koodit, se ei kuitenkaan käsittele NaN-ja negatiivisia lukuja.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Tämä näyttää liian hyvältä ollakseen totta, mutta se toimii.
        // 0.0 on koodattu kaikki-nolla-sanaksi.Subnormaalit ovat 0x000m ... m, missä m on mantissa.
        // Erityisesti pienin subnormaali on 0x0 ... 01 ja suurin 0x000F ... F.
        // Pienin normaali luku on 0x0010 ... 0, joten tämä kulmakotelo toimii myös.
        // Jos lisäys ylittää mantissan, kantobitti lisää eksponenttia haluamallamme tavalla, ja mantissabiteistä tulee nolla.
        // Piilotetun bittisopimuksen vuoksi myös tämä on juuri sitä mitä haluamme!
        // Lopuksi f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}