//! Paperin eri algoritmit.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Merkitysbittien lukumäärä Fp: ssä
const P: u32 = 64;

// Tallennamme yksinkertaisesti parhaan likiarvon *kaikille* eksponenteille, joten muuttuja "h" ja siihen liittyvät ehdot voidaan jättää pois.
// Tämä käy kauppaa suorituskyvyllä pari kilotavua tilaa.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Useimmissa arkkitehtuureissa liukulukuoperaatioilla on selkeä bittikoko, joten laskennan tarkkuus määritetään operaatiokohtaisesti.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// x86: ssä x87 FPU: ta käytetään kelluntatoimintoihin, jos SSE/SSE2-laajennuksia ei ole saatavana.
// x87 FPU toimii oletusarvoisesti 80 bitin tarkkuudella, mikä tarkoittaa, että toiminnot pyöristyvät 80 bittiin, jolloin kaksinkertainen pyöristys tapahtuu, kun arvot esitetään lopulta
//
// 32/64 bittiset float-arvot.Tämän voittamiseksi FPU-ohjaussana voidaan asettaa siten, että laskelmat suoritetaan halutulla tarkkuudella.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Rakenne, jota käytetään FPU-ohjaussanan alkuperäisen arvon säilyttämiseen, jotta se voidaan palauttaa, kun rakenne pudotetaan.
    ///
    ///
    /// x87 FPU on 16-bittinen rekisteri, jonka kentät ovat seuraavat:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Kaikkien kenttien dokumentaatio on saatavana IA-32 Architectures-ohjelmiston kehittäjän käsikirjassa (osa 1).
    ///
    /// Ainoa kenttä, joka liittyy seuraavaan koodiin, on PC, Precision Control.
    /// Tämä kenttä määrittää FPU: n suorittamien toimintojen tarkkuuden.
    /// Se voidaan asettaa:
    ///  - 0b00, yksi tarkkuus eli 32-bittinen
    ///  - 0b10, kaksoistarkkuus eli 64-bittinen
    ///  - 0b11, kaksinkertainen laajennettu tarkkuus, ts. 80-bittinen (oletusarvo) 0b01-arvo on varattu eikä sitä tule käyttää.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // TURVALLISUUS: `fldcw`-käsky on auditoitu voidakseen toimia oikein
        // mikä tahansa `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Käytämme ATT-syntaksia tukemaan LLVM 8: ta ja LLVM 9: ää.
                options(att_syntax, nostack),
            )
        }
    }

    /// Asettaa FPU: n tarkkuuskentän arvoksi `T` ja palauttaa `FPUControlWord`: n.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Laske `T`: lle sopivan Precision Control-kentän arvo.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bittiä
            8 => 0x0200, // 64 bittiä
            _ => 0x0300, // oletus, 80 bittiä
        };

        // Hanki ohjaussanan alkuperäinen arvo palauttaaksesi sen myöhemmin, kun `FPUControlWord`-rakenne pudotetaan TURVALLISUUS: `fnstcw`-käsky on tarkastettu voidakseen toimia oikein minkä tahansa `u16`: n kanssa
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Käytämme ATT-syntaksia tukemaan LLVM 8: ta ja LLVM 9: ää.
                options(att_syntax, nostack),
            )
        }

        // Aseta ohjaussana haluttuun tarkkuuteen.
        // Tämä saavutetaan peittämällä vanha tarkkuus (bitit 8 ja 9, 0x300) ja korvaamalla se edellä lasketulla tarkkuuslipulla.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Bellerophonin nopea polku käyttäen koneenkokoisia kokonaislukuja ja kellukkeita.
///
/// Tämä erotetaan erilliseksi funktioksi, jotta sitä voidaan yrittää ennen bignumin rakentamista.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Vertailemme tarkkaa arvoa MAX_SIG: ään loppupuolella, tämä on vain nopea, halpa hylkääminen (ja myös vapauttaa loput koodista huolehtimasta alivirtauksesta).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Nopea polku riippuu ratkaisevasti siitä, onko aritmeetti pyöristetty oikeaan bittimäärään ilman välipyöristystä.
    // x86: ssä (ilman SSE: tä tai SSE2: ää) tämä edellyttää x87 FPU-pinon tarkkuuden muuttamista siten, että se pyörii suoraan 64/32-bitiksi.
    // `set_precision`-toiminto huolehtii tarkkuuden asettamisesta arkkitehtuureille, jotka edellyttävät sen asettamista muuttamalla globaalia tilaa (kuten x87 FPU: n ohjaussana).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Tapaus e <0 ei ole taitettavissa toiseen haaraan.
    // Negatiivisten voimien seurauksena toistuva murtolukuosa binaarissa, joka on pyöristetty, mikä aiheuttaa todellisia (ja joskus melko merkittäviä!) Virheitä lopputuloksessa.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algoritmi Bellerophon on triviaalikoodi, joka on perusteltu ei-triviaalisella numeerisella analyysillä.
///
/// Se pyöristää f: n 64-bittisellä merkinnällä varustettuun kellukkeeseen ja kertoo sen `10^e`: n parhaalla likiarvolla (samassa liukulukuformaatissa).Tämä riittää usein oikean tuloksen saamiseksi.
/// Kuitenkin, kun tulos on lähellä puolivälissä kahden vierekkäisen (ordinary)-kellukkeen välillä, yhdistetty pyöristysvirhe kertomalla kaksi likiarvoa tarkoittaa, että tulos voi olla pois muutamalla bitillä.
/// Kun näin tapahtuu, iteratiivinen algoritmi R korjaa asian.
///
/// Käsin aaltoileva "close to halfway" täsmennetään paperin numeerisen analyysin avulla.
/// Clingerin sanoin:
///
/// > Slope, ilmaistuna vähiten merkitsevän bitin yksikköinä, on virheen osallistava sidos
/// > kertynyt likimäärän arvoon f * 10 ^ e laskettaessa liukuluku.(Slop on
/// > ei sido todellista virhettä, mutta rajoittaa likiarvojen z ja
/// > paras mahdollinen likiarvo, joka käyttää p merkitsevää bittiä.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Tapaukset abs(e) <log5(2^N) ovat muodossa fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Onko kaltevuus riittävän suuri erottamiseksi pyöristettäessä n bittiin?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Iteratiivinen algoritmi, joka parantaa `f * 10^e`: n liukulaskua.
///
/// Jokainen iterointi saa yhden yksikön viimeiselle paikalle lähemmäksi, mikä tietysti kestää kauan kauan, jos `z0` on edes lievästi pois päältä.
/// Onneksi, kun sitä käytetään Bellerophonin varatoimena, aloitusarviointi on pois käytöstä enintään yhdellä ULP: llä.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Etsi positiiviset kokonaisluvut `x`, `y` siten, että `x / y` on täsmälleen `(f *10^e) / (m* 2^k)`.
        // Tämä välttää paitsi `e`: n ja `k`: n merkkien käsittelyn, myös eliminoimme kahden `10^e`: lle ja `2^k`: lle yhteisen voiman tehdä numeroista pienempiä.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Tämä on kirjoitettu hieman hankalasti, koska bignumimme eivät tue negatiivisia lukuja, joten käytämme absoluuttista arvoa + merkkitietoja.
        // Kertominen m_digitsillä ei voi ylittyä.
        // Jos `x` tai `y` ovat riittävän suuria, jotta meidän on huolehdittava ylivuotosta, niin ne ovat myös riittävän suuria, jotta `make_ratio` on pienentänyt murto-osaa 2 ^ 64 tai enemmän.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Älä enää tarvitse x: tä, tallenna clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Tarvitset vielä y, tee kopio.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Koska `x = f` ja `y = m`, joissa `f` edustaa syötteen desimaalilukuja tavalliseen tapaan ja `m` on liukuluvun approksimaation merkitys, tee suhde `x / y` yhtä suureksi kuin `(f *10^e) / (m* 2^k)`, mahdollisesti pienennettynä kahden teholla molemmilla on yhteistä.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, paitsi että pienennämme murto-osaa jonkin verran kahdella.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Tämä ei voi ylittyä, koska se vaatii positiivisen `e`: n ja negatiivisen `k`: n, mikä voi tapahtua vain erittäin lähellä arvoja 1: lle, mikä tarkoittaa, että `e` ja `k` ovat suhteellisen pieniä.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Tämä ei voi myöskään ylivuotoa, katso yllä.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), jälleen pienentämällä kahden yhteisellä voimalla.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Käsitteellisesti algoritmi M on yksinkertaisin tapa muuntaa desimaali kelluvaksi.
///
/// Muodostetaan suhde, joka on yhtä suuri kuin `f * 10^e`, ja heitämme sitten kahden voiman, kunnes se antaa kelvollisen kelluvan merkinnän.
/// Binaarinen eksponentti `k` on niiden kertojen määrä, jolloin kerrotaan osoittaja tai nimittäjä kahdella, ts. Aina `f *10^e` on yhtä suuri kuin `(u / v)* 2^k`.
/// Kun olemme huomanneet merkityksen, meidän on vain pyöristettävä tarkastamalla loput jaosta, mikä tehdään auttajatoiminnoissa jäljempänä.
///
///
/// Tämä algoritmi on erittäin hidas, jopa `quick_start()`: ssä kuvatulla optimoinnilla.
/// Se on kuitenkin yksinkertaisin algoritmeista sopeutua ylivuoto-, alivuoto-ja epänormaalituloksiin.
/// Tämä toteutus otetaan käyttöön, kun Bellerophon ja Algorithm R ovat hukkua.
/// Ala-ja ylivuotojen havaitseminen on helppoa: suhde ei silti ole alueen sisällä oleva merkintä, mutta minimum/maximum-eksponentti on saavutettu.
/// Ylivuototapauksessa palautamme yksinkertaisesti äärettömyyden.
///
/// Alivirtausten ja alinormaalien käsittely on hankalampaa.
/// Yksi iso ongelma on, että pienimmän eksponentin ollessa kyseessä suhde voi silti olla liian suuri merkitsevälle.
/// Katso lisätietoja underflow(): stä.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // Korjaa mahdollinen optimointi: yleistä big_to_fp niin, että voimme tehdä fp_to_float(big_to_fp(u)): n ekvivalentin täällä vain ilman kaksinkertaista pyöristystä.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Meidän on pysähdyttävä minimiarvon eksponenttiin, jos odotamme `k < T::MIN_EXP_INT`: ään, niin olisimme poissa kaksi kertaa.
            // Valitettavasti tämä tarkoittaa sitä, että meidän on tapauskohtaisesti käytettävä normaalilukuja minimilaskurin kanssa.
            // FIXME löytää tyylikkäämpi muotoilu, mutta suorita `tiny-pow10`-testi varmistaaksesi, että se on todella oikea!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Ohittaa useimmat algoritmi M-iteraatiot tarkistamalla bittipituuden.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Bittipituus on arvio kahden peruslogaritmin arvosta ja log(u / v) = log(u), log(v).
    // Arvio on pois päältä enintään 1, mutta aina aliarvioitu, joten log(u): n ja log(v): n virheillä on sama merkki ja ne poistuvat (jos molemmat ovat suuria).
    // Siksi log(u / v): n virhe on enintään yksi.
    // Kohdesuhde on sellainen, jossa u/v on alueen sisällä.Siten lopetusehtomme on, että log2(u / v) on merkitsevä bitti, plus/minus yksi.
    // FIXME Toisen bitin tarkastelu voisi parantaa estimaattia ja välttää joitain lisäjakaumia.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Alivirta tai subnormaali.Jätä se päätoimintoon.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Ylivuoto.Jätä se päätoimintoon.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Suhde ei ole vaihteluvälin sisällä oleva merkitsevä arvo pienimmän eksponentin kanssa, joten meidän on pyöristettävä ylimääräiset bitit ja säädettävä eksponentti vastaavasti.
    // Todellinen arvo näyttää nyt tältä:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(edustaja Rem)
    //
    // Siksi, kun pyöristetyt bitit ovat!= 0.5 ULP, he päättävät pyöristyksen itse.
    // Kun ne ovat yhtä suuret ja loppuosa ei ole nolla, arvo on vielä pyöristettävä ylöspäin.
    // Vasta kun pyöristetyt bitit ovat 1/2 ja loppuosa on nolla, meillä on puolitasainen tilanne.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Tavallinen tasainen, tasainen, hämmentynyt joutumalla pyöristämään lopun jaon perusteella.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}