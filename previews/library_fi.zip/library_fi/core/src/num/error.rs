//! Virhetyypit muunnettaessa integraaleiksi.

use crate::convert::Infallible;
use crate::fmt;

/// Virhetyyppi palautettiin, kun tarkistettu integraalityypin muunnos epäonnistui.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Yhdistä pikemminkin kuin pakota varmistaaksesi, että yllä olevan `From<Infallible> for TryFromIntError`: n kaltainen koodi toimii edelleen, kun `Infallible`: stä tulee `!`: n alias.
        //
        //
        match never {}
    }
}

/// Virhe, joka voidaan palauttaa jäsennettäessä kokonaislukua.
///
/// Tätä virhettä käytetään `from_str_radix()`-toimintojen virhetyyppinä primitiivisillä kokonaislukutyypeillä, kuten [`i8::from_str_radix`].
///
/// # Mahdolliset syyt
///
/// Muiden syiden vuoksi `ParseIntError` voidaan heittää johtuen merkkijonosta johtuvan tai jäljessä olevan välilyönnin takia, esimerkiksi kun se saadaan vakiosyötöstä.
///
/// [`str::trim()`]-menetelmän avulla varmistetaan, että tyhjää tilaa ei ole jäljellä ennen jäsentämistä.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum tallentaa erityyppiset virheet, jotka voivat aiheuttaa kokonaisluvun jäsentämisen epäonnistumisen.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Jäsennetty arvo on tyhjä.
    ///
    /// Muiden syiden joukosta tämä muunnos rakennetaan jäsennettäessä tyhjää merkkijonoa.
    Empty,
    /// Sisältää virheellisen numeron kontekstissaan.
    ///
    /// Muiden syiden joukosta tämä muunnos rakennetaan jäsennettäessä merkkijonoa, joka sisältää ei-ASCII-merkin.
    ///
    /// Tämä muunnos rakennetaan myös silloin, kun `+` tai `-` on sijoitettu väärin merkkijonoon joko yksinään tai luvun keskellä.
    ///
    ///
    InvalidDigit,
    /// Kokonaisluku on liian suuri tallennettavaksi kohdelukutyyppiin.
    PosOverflow,
    /// Kokonaisluku on liian pieni tallennettavaksi kohdelukutyyppiin.
    NegOverflow,
    /// Arvo oli nolla
    ///
    /// Tämä muunnos lähetetään, kun jäsennysmerkkijonon arvo on nolla, mikä olisi laitonta muille kuin nollatyypeille.
    ///
    Zero,
}

impl ParseIntError {
    /// Lähetetään yksityiskohtainen syy kokonaisluvun epäonnistumiseen.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}