//! Vakiot 16-bittiselle allekirjoitetulle kokonaislukutyypille.
//!
//! *[See also the `i16` primitive type][i16].*
//!
//! Uuden koodin tulisi käyttää siihen liittyviä vakioita suoraan primitiivityypissä.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i16`"
)]

int_module! { i16 }