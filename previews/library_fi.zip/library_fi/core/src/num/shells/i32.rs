//! Vakiot 32-bittiselle allekirjoitetulle kokonaislukutyypille.
//!
//! *[See also the `i32` primitive type][i32].*
//!
//! Uuden koodin tulisi käyttää siihen liittyviä vakioita suoraan primitiivityypissä.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i32`"
)]

int_module! { i32 }