//! Vakiot 32-bittiselle allekirjoittamattomalle kokonaislukutyypille.
//!
//! *[See also the `u32` primitive type][u32].*
//!
//! Uuden koodin tulisi käyttää siihen liittyviä vakioita suoraan primitiivityypissä.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u32`"
)]

int_module! { u32 }