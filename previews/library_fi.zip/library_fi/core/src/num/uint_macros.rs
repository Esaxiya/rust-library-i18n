macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Pienin arvo, jota tällä kokonaislukutyypillä voidaan edustaa.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// Suurin arvo, jota tällä kokonaislukutyypillä voidaan edustaa.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// Tämän kokonaislukutyypin koko bitteinä.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Muuntaa merkkijonolohkon tietyssä emäksessä kokonaisluvuksi.
        ///
        /// Merkkijonon odotetaan olevan valinnainen `+`-merkki, jota seuraa numerot.
        ///
        /// Välilyönnin johto ja perässä on virhe.
        /// Numerot ovat näiden merkkien osajoukko `radix`: stä riippuen:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Tämä toiminto panics, jos `radix` ei ole alueella 2-36.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Palauttaa `self`: n binaariesityksen niiden lukumäärän.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// Palauttaa nollien määrän `self`: n binaariesityksessä.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Palauttaa `self`: n binaariesityksen johtavien nollien määrän.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// Palauttaa jäljellä olevien nollien määrän `self`: n binaariesityksessä.
        ///
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// Palauttaa johtavien lukumäärän `self`: n binaariesityksessä.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// Palauttaa jäljessä olevien lukumäärän `self`: n binaariesityksessä.
        ///
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// Siirtää bittejä vasemmalle määrätyllä määrällä, `n`, käärimällä katkaistut bitit tuloksena olevan kokonaisluvun loppuun.
        ///
        ///
        /// Huomaa, että tämä ei ole sama toiminto kuin `<<`-vaihdeoperaattori!
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// Siirtää bitit oikealle määrätyllä määrällä, `n`, käärimällä katkaistut bitit tuloksena olevan kokonaisluvun alkuun.
        ///
        ///
        /// Huomaa, että tämä ei ole sama toiminto kuin `>>`-vaihdeoperaattori!
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// Kääntää kokonaisluvun tavujärjestyksen.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// olkoon m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// Kääntää bittien järjestyksen kokonaisluvussa.
        /// Vähiten merkitsevästä bitistä tulee merkittävin bitti, toisesta vähiten merkitsevästä bitistä tulee toinen merkittävin bitti jne.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// olkoon m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// Muuntaa kokonaisluvun suuresta endianista kohteen endianiteetiksi.
        ///
        /// Isolla endianilla tämä on ei-op.
        /// Pienellä endianilla tavut vaihdetaan.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// jos cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } muu {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Muuntaa kokonaisluvun pienestä endianista kohteen endianiteetiksi.
        ///
        /// Pienellä endianilla tämä on ei-op.
        /// Suurella endianilla tavut vaihdetaan.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// jos cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } muu {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Muuntaa `self`: n suureksi endianiksi kohteen endianiteetista.
        ///
        /// Isolla endianilla tämä on ei-op.
        /// Pienellä endianilla tavut vaihdetaan.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// jos cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } muu { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // vai ei olla?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Muuntaa `self`: n pieneksi endianiksi kohteen endianiteetista.
        ///
        /// Pienellä endianilla tämä on ei-op.
        /// Suurella endianilla tavut vaihdetaan.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// jos cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } muu { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Tarkistettu kokonaisluvun lisäys.
        /// Laskee `self + rhs`: n, palauttaa `None`: n, jos ylivuoto esiintyy.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Tarkistamaton kokonaisluvun lisäys.Laskee `self + rhs`, olettaen, että ylivuotoa ei voi tapahtua.
        /// Tämä johtaa määrittelemättömään käyttäytymiseen, kun
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // TURVALLISUUS: soittajan on noudatettava `unchecked_add`: n turvasopimusta.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Tarkistettu kokonaislukumääräinen vähennys.
        /// Laskee `self - rhs`: n, palauttaa `None`: n, jos ylivuoto esiintyy.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Tarkistamaton kokonaislukumääräinen vähennys.Laskee `self - rhs`, olettaen, että ylivuotoa ei voi tapahtua.
        /// Tämä johtaa määrittelemättömään käyttäytymiseen, kun
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // TURVALLISUUS: soittajan on noudatettava `unchecked_sub`: n turvasopimusta.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Tarkistettu kokonaislukukerta.
        /// Laskee `self * rhs`: n, palauttaa `None`: n, jos ylivuoto esiintyy.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Tarkistamaton kokonaislukukerta.Laskee `self * rhs`, olettaen, että ylivuotoa ei voi tapahtua.
        /// Tämä johtaa määrittelemättömään käyttäytymiseen, kun
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // TURVALLISUUS: soittajan on noudatettava `unchecked_mul`: n turvasopimusta.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Tarkistettu kokonaislukujako.
        /// Laskee `self / rhs`: n, palauttaa `None`: n, jos `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // TURVALLISUUS: div nollalla on tarkistettu yllä ja allekirjoittamattomilla tyypeillä ei ole muita
                // vikatilat jakoa varten
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Tarkistettu euklidinen jako.
        /// Laskee `self.div_euclid(rhs)`: n, palauttaa `None`: n, jos `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// Tarkistettu kokonaisluvun loppuosa.
        /// Laskee `self % rhs`: n, palauttaa `None`: n, jos `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // TURVALLISUUS: div nollalla on tarkistettu yllä ja allekirjoittamattomilla tyypeillä ei ole muita
                // vikatilat jakoa varten
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Tarkistettu euklidinen moduuli.
        /// Laskee `self.rem_euclid(rhs)`: n, palauttaa `None`: n, jos `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Tarkistettu kielto.Laskee `-self`: n ja palauttaa `None`: n, ellei `itse==
        /// 0`.
        ///
        /// Huomaa, että minkä tahansa positiivisen kokonaisluvun nollaaminen ylittää.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Tarkastettu vaihto vasemmalle.
        /// Laskee `self << rhs`: n ja palauttaa `None`: n, jos `rhs` on suurempi tai yhtä suuri kuin `self`: n bittien määrä.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Tarkistettu vaihto oikealle.
        /// Laskee `self >> rhs`: n ja palauttaa `None`: n, jos `rhs` on suurempi tai yhtä suuri kuin `self`: n bittien määrä.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Tarkastettu eksponentio.
        /// Laskee `self.pow(exp)`: n, palauttaa `None`: n, jos ylivuoto esiintyy.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // koska exp!=0, lopuksi exp: n on oltava 1.
            // Käsittele eksponentin viimeistä bittiä erikseen, koska pohjan neliöinti jälkikäteen ei ole välttämätöntä ja voi aiheuttaa turhaa ylivuotoa.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Kyllästyvä kokonaislukun lisäys.
        /// Laskee `self + rhs`: n, joka kyllästyy numeerisilla rajoilla ylivuotamisen sijaan.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Kyllästävä kokonaislukumääräinen vähennys.
        /// Laskee `self - rhs`: n, joka kyllästyy numeerisilla rajoilla ylivuotamisen sijaan.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Kyllästävä kokonaislukukerta.
        /// Laskee `self * rhs`: n, joka kyllästyy numeerisilla rajoilla ylivuotamisen sijaan.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Kyllästyvä kokonaisluvun eksponentio.
        /// Laskee `self.pow(exp)`: n, joka kyllästyy numeerisilla rajoilla ylivuotamisen sijaan.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// (modular)-lisäyksen kääriminen.
        /// Laskee `self + rhs`: n kiertämällä tyypin rajalla.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// (modular)-vähennyslaskun kääriminen.
        /// Laskee `self - rhs`: n kiertämällä tyypin rajalla.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// (modular)-kertomuksen kääriminen.
        /// Laskee `self * rhs`: n kiertämällä tyypin rajalla.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// Huomaa, että tämä esimerkki on jaettu kokonaislukutyyppien välillä.
        /// Mikä selittää, miksi `u8`: ää käytetään täällä.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// (modular)-jakamisen kääriminen.Laskee `self / rhs`.
        /// Allekirjoitettujen tyyppien kääritty jakaminen on vain normaalia jakoa.
        /// Käärimistä ei voi koskaan tapahtua.
        /// Tämä toiminto on olemassa, joten kaikki toiminnot otetaan huomioon käärintäoperaatioissa.
        ///
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Euklidisen jaon kääriminen.Laskee `self.div_euclid(rhs)`.
        /// Allekirjoitettujen tyyppien kääritty jakaminen on vain normaalia jakoa.
        /// Käärimistä ei voi koskaan tapahtua.
        /// Tämä toiminto on olemassa, joten kaikki toiminnot otetaan huomioon käärintäoperaatioissa.
        /// Koska positiivisten kokonaislukujen osalta kaikki jaon yleiset määritelmät ovat samat, tämä on täsmälleen yhtä suuri kuin `self.wrapping_div(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// (modular): n kääriminen loput.Laskee `self % rhs`.
        /// Kääritty loppulaskenta allekirjoittamattomille tyypeille on vain säännöllinen jäännöslaskenta.
        ///
        /// Käärimistä ei voi koskaan tapahtua.
        /// Tämä toiminto on olemassa, joten kaikki toiminnot otetaan huomioon käärintäoperaatioissa.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Euklidisen moduulin kääriminen.Laskee `self.rem_euclid(rhs)`.
        /// Kääritty modulo-laskenta allekirjoittamattomille tyypeille on vain säännöllinen loppulaskenta.
        /// Käärimistä ei voi koskaan tapahtua.
        /// Tämä toiminto on olemassa, joten kaikki toiminnot otetaan huomioon käärintäoperaatioissa.
        /// Koska positiivisten kokonaislukujen osalta kaikki jaon yleiset määritelmät ovat samat, tämä on täsmälleen yhtä suuri kuin `self.wrapping_rem(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// (modular)-negaation kääriminen.
        /// Laskee `-self`: n kiertämällä tyypin rajalla.
        ///
        /// Koska allekirjoittamattomilla tyypeillä ei ole negatiivisia vastaavia, kaikki tämän toiminnon sovellukset kääritään (paitsi `-0`).
        /// Jos arvo on pienempi kuin vastaavan allekirjoitetun tyypin enimmäismäärä, tulos on sama kuin vastaavan allekirjoitetun arvon heittäminen.
        ///
        /// Suuremmat arvot vastaavat `MAX + 1 - (val - MAX - 1)`: ää, jossa `MAX` on vastaavan allekirjoitetun tyypin maksimiarvo.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// Huomaa, että tämä esimerkki on jaettu kokonaislukutyyppien välillä.
        /// Mikä selittää, miksi `i8`: ää käytetään täällä.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-vapaa siirtyminen vasemmalle;
        /// tuottaa `self << mask(rhs)`: n, jossa `mask` poistaa kaikki korkean asteen `rhs`-bitit, jotka aiheuttaisivat muutoksen ylittävän tyypin bittileveyden.
        ///
        /// Huomaa, että tämä *ei* ole sama kuin vasemmalle kiertäminen;käärimisen vasemmanpuoleinen RHS on rajoitettu tyypin alueelle sen sijaan, että LHS: stä siirretyt bitit palautettaisiin toiseen päähän.
        /// Kaikki primitiiviset kokonaislukutyypit toteuttavat [`rotate_left`](Self::rotate_left)-toiminnon, joka voi olla mitä haluat sen sijaan.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // TURVALLISUUS: tyypin bittikokoon peittäminen varmistaa, ettemme muutu
            // rajojen ulkopuolella
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-vapaa bittisuuntainen siirto oikealle;
        /// tuottaa `self >> mask(rhs)`: n, jossa `mask` poistaa kaikki korkean asteen `rhs`-bitit, jotka aiheuttaisivat muutoksen ylittävän tyypin bittileveyden.
        ///
        /// Huomaa, että tämä *ei* ole sama kuin oikea kiertäminen;käärimisen siirtymisoikeuden RHS on rajoitettu tyypin alueelle sen sijaan, että LHS: stä siirretyt bitit palautettaisiin toiseen päähän.
        /// Kaikki primitiiviset kokonaislukutyypit toteuttavat [`rotate_right`](Self::rotate_right)-toiminnon, joka voi olla mitä haluat sen sijaan.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // TURVALLISUUS: tyypin bittikokoon peittäminen varmistaa, ettemme muutu
            // rajojen ulkopuolella
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// (modular)-eksponention kääriminen.
        /// Laskee `self.pow(exp)`: n kiertämällä tyypin rajalla.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // koska exp!=0, lopuksi exp: n on oltava 1.
            // Käsittele eksponentin viimeistä bittiä erikseen, koska pohjan neliöinti jälkikäteen ei ole välttämätöntä ja voi aiheuttaa turhaa ylivuotoa.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Laskee `self` + `rhs`
        ///
        /// Palauttaa tuplan lisäyksestä sekä loogisen arvon, joka osoittaa, tapahtuuko aritmeettinen ylivuoto.
        /// Jos ylivuoto olisi tapahtunut, kääritty arvo palautetaan.
        ///
        /// # Examples
        ///
        /// Peruskäyttö
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Laskee `self`, `rhs`
        ///
        /// Palauttaa kaksinkertaisen vähennyslasin ja loogisen arvon, joka osoittaa, tapahtuuko aritmeettinen ylivuoto.
        /// Jos ylivuoto olisi tapahtunut, kääritty arvo palautetaan.
        ///
        /// # Examples
        ///
        /// Peruskäyttö
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Laskee `self`: n ja `rhs`: n kertolaskun.
        ///
        /// Palauttaa kertolaskuparin sekä loogisen arvon, joka ilmaisee, tapahtuuko aritmeettinen ylivuoto.
        /// Jos ylivuoto olisi tapahtunut, kääritty arvo palautetaan.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// Huomaa, että tämä esimerkki on jaettu kokonaislukutyyppien välillä.
        /// Mikä selittää, miksi `u32`: ää käytetään täällä.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Laskee jakajan, kun `self` jaetaan `rhs`: llä.
        ///
        /// Palauttaa kaksinkertaisen jakajan ja loogisen arvon osoittamalla, tapahtuuko aritmeettinen ylivuoto.
        /// Huomaa, että allekirjoittamattomien kokonaislukujen ylivuotoa ei koskaan tapahdu, joten toinen arvo on aina `false`.
        ///
        /// # Panics
        ///
        /// Tämä toiminto on panic, jos `rhs` on 0.
        ///
        /// # Examples
        ///
        /// Peruskäyttö
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Laskee euklidisen jakauman `self.div_euclid(rhs)` osamäärän.
        ///
        /// Palauttaa kaksinkertaisen jakajan ja loogisen arvon osoittamalla, tapahtuuko aritmeettinen ylivuoto.
        /// Huomaa, että allekirjoittamattomien kokonaislukujen ylivuotoa ei koskaan tapahdu, joten toinen arvo on aina `false`.
        /// Koska positiivisten kokonaislukujen osalta kaikki jaon yleiset määritelmät ovat samat, tämä on täsmälleen yhtä suuri kuin `self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Tämä toiminto on panic, jos `rhs` on 0.
        ///
        /// # Examples
        ///
        /// Peruskäyttö
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Laskee loput, kun `self` jaetaan `rhs`: llä.
        ///
        /// Palauttaa jäljellä olevan tuplan jakautumisen jälkeen loogisen arvon kanssa osoittaen, tapahtuuko aritmeettinen ylivuoto.
        /// Huomaa, että allekirjoittamattomien kokonaislukujen ylivuotoa ei koskaan tapahdu, joten toinen arvo on aina `false`.
        ///
        /// # Panics
        ///
        /// Tämä toiminto on panic, jos `rhs` on 0.
        ///
        /// # Examples
        ///
        /// Peruskäyttö
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Laskee loput `self.rem_euclid(rhs)` ikään kuin Euklideksen jaolla.
        ///
        /// Palauttaa moduulin tuplan sen jälkeen, kun se on jaettu loogisen arvon kanssa, mikä osoittaa, tapahtuuko aritmeettinen ylivuoto.
        /// Huomaa, että allekirjoittamattomien kokonaislukujen ylivuotoa ei koskaan tapahdu, joten toinen arvo on aina `false`.
        /// Koska positiivisten kokonaislukujen osalta kaikki jaon yleiset määritelmät ovat samat, tämä operaatio on täsmälleen yhtä suuri kuin `self.overflowing_rem(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Tämä toiminto on panic, jos `rhs` on 0.
        ///
        /// # Examples
        ///
        /// Peruskäyttö
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Neuvottelee itseään ylivoimaisella tavalla.
        ///
        /// Palauttaa `!self + 1`: n käärintäoperaatioiden avulla palauttamaan arvon, joka edustaa tämän allekirjoittamattoman arvon negaatiota.
        /// Huomaa, että positiivisilla allekirjoittamattomilla arvoilla esiintyy aina ylivuotoa, mutta 0: n hylkääminen ei ylitä.
        ///
        /// # Examples
        ///
        /// Peruskäyttö
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// Vaihtaa itsensä `rhs`-bittien vasemmalle puolelle.
        ///
        /// Palauttaa itsensä siirretyn version tuplan ja loogisen arvon, joka osoittaa, onko siirtymäarvo suurempi tai yhtä suuri kuin bittien lukumäärä.
        /// Jos siirtoarvo on liian suuri, arvo peitetään (N-1), jossa N on bittien lukumäärä, ja tätä arvoa käytetään sitten siirron suorittamiseen.
        ///
        /// # Examples
        ///
        /// Peruskäyttö
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Vaihtaa itsensä oikealle `rhs`-bitillä.
        ///
        /// Palauttaa itsensä siirretyn version tuplan ja loogisen arvon, joka osoittaa, onko siirtymäarvo suurempi tai yhtä suuri kuin bittien lukumäärä.
        /// Jos siirtoarvo on liian suuri, arvo peitetään (N-1), jossa N on bittien lukumäärä, ja tätä arvoa käytetään sitten siirron suorittamiseen.
        ///
        /// # Examples
        ///
        /// Peruskäyttö
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Nostaa itsensä `exp`: n tehoon käyttämällä eksponenttia neliöittämällä.
        ///
        /// Palauttaa eksponention dupleksin yhdessä bool: n kanssa, mikä osoittaa, tapahtui ylivuoto.
        ///
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (Totta 217));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Raaputustila overflowing_mul-tulosten tallentamiseen.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // koska exp!=0, lopuksi exp: n on oltava 1.
            // Käsittele eksponentin viimeistä bittiä erikseen, koska pohjan neliöinti jälkikäteen ei ole välttämätöntä ja voi aiheuttaa turhaa ylivuotoa.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// Nostaa itsensä `exp`: n tehoon käyttämällä eksponenttia neliöittämällä.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // koska exp!=0, lopuksi exp: n on oltava 1.
            // Käsittele eksponentin viimeistä bittiä erikseen, koska pohjan neliöinti jälkikäteen ei ole välttämätöntä ja voi aiheuttaa turhaa ylivuotoa.
            //
            //
            acc * base
        }

        /// Suorittaa euklidisen jaon.
        ///
        /// Koska positiivisten kokonaislukujen osalta kaikki jaon yleiset määritelmät ovat samat, tämä on täsmälleen yhtä suuri kuin `self / rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Tämä toiminto on panic, jos `rhs` on 0.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// Laskee `self (mod rhs)`: n pienimmän loppuosan.
        ///
        /// Koska positiivisten kokonaislukujen osalta kaikki jaon yleiset määritelmät ovat samat, tämä on täsmälleen yhtä suuri kuin `self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Tämä toiminto on panic, jos `rhs` on 0.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Palauttaa `true` vain ja vain, jos `self == 2^k` joillekin `k`: lle.
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // Palauttaa yhden vähemmän kuin seuraavan kahden voima.
        // (8u8: lla kahden seuraava teho on 8u8 ja 6u8: lla 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // Tämä menetelmä ei voi ylivuotoa, koska `next_power_of_two`-ylivuototapauksissa se päätyy palauttamaan tyypin enimmäisarvon ja voi palauttaa 0 arvolle 0.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // TURVALLISUUS: Koska `p > 0`, se ei voi koostua kokonaan etunollista.
            // Tämä tarkoittaa, että muutos on aina rajojen sisällä, ja joillakin prosessoreilla (kuten Intel pre-haswell) on tehokkaampia ctlz-sisäisiä ominaisuuksia, kun argumentti ei ole nolla.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// Palauttaa kahden pienimmän tehon, joka on suurempi tai yhtä suuri kuin `self`.
        ///
        /// Kun paluuarvo ylittyy (ts. `self > (1 << (N-1))` tyypille `uN`), se panics virheenkorjaustilassa ja palautusarvo kääritään 0: een vapautustilassa (ainoa tilanne, jossa menetelmä voi palauttaa 0).
        ///
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// Palauttaa kahden pienimmän tehon, joka on suurempi tai yhtä suuri kuin `n`.
        /// Jos kahden seuraava teho on suurempi kuin tyypin maksimiarvo, palautetaan `None`, muuten kahden teho kääritään `Some`: ään.
        ///
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// Palauttaa kahden pienimmän tehon, joka on suurempi tai yhtä suuri kuin `n`.
        /// Jos kahden seuraavan teho on suurempi kuin tyypin enimmäisarvo, palautusarvo kääritään arvoon `0`.
        ///
        ///
        /// # Examples
        ///
        /// Peruskäyttö:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Palauta tämän kokonaisluvun muistiesitys tavuryhmänä suurten endioiden (network)-tavujärjestyksessä.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Palauta tämän kokonaisluvun muistiesitys tavuryhmänä pienen endian tavujärjestyksessä.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Palauta tämän kokonaisluvun muistiesitys tavuryhmänä alkuperäisessä tavujärjestyksessä.
        ///
        /// Koska kohdealustan natiivia endiaanisyyttä käytetään, kannettavan koodin tulisi käyttää sen sijaan tarvittaessa [`to_be_bytes`]-tai [`to_le_bytes`]-koodia.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     tavua, jos cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } muu {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // TURVALLISUUS: const-ääni, koska kokonaisluvut ovat tavallisia vanhoja tietotyyppejä, joten voimme aina
        // muuntaa ne tavuiksi
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // TURVALLISUUS: kokonaisluvut ovat tavallisia vanhoja tietotyyppejä, joten voimme aina muuntaa ne
            // joukko tavuja
            unsafe { mem::transmute(self) }
        }

        /// Palauta tämän kokonaisluvun muistiesitys tavuryhmänä alkuperäisessä tavujärjestyksessä.
        ///
        ///
        /// [`to_ne_bytes`] olisi suositeltava tähän verrattuna aina kun mahdollista.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// anna tavua= num.as_ne_bytes();
        /// assert_eq!(
        ///     tavua, jos cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } muu {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // TURVALLISUUS: kokonaisluvut ovat tavallisia vanhoja tietotyyppejä, joten voimme aina muuntaa ne
            // joukko tavuja
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Luo natiivi endian kokonaislukuarvo sen esityksestä tavutaulukkona suuressa endianissa.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// käytä std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * syöttö=lepo;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Luo natiivi endian kokonaislukuarvo sen esityksestä tavutaulukkona pienessä endianissa.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// käytä std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * syöttö=lepo;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Luo natiivi endian kokonaislukuarvo muistin esityksestään tavuryhmänä alkuperäisessä endianiteetissa.
        ///
        /// Kohdealustan natiivin endianiteetin käyttämisen vuoksi kannettava koodi haluaa todennäköisesti käyttää [`from_be_bytes`]: ää tai [`from_le_bytes`]: ää sen sijaan.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } muu {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// käytä std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * syöttö=lepo;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // TURVALLISUUS: const-ääni, koska kokonaisluvut ovat tavallisia vanhoja tietotyyppejä, joten voimme aina
        // muistaa heille
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // TURVALLISUUS: kokonaisluvut ovat yksinkertaisia vanhoja tietotyyppejä, joten voimme aina muuntaa ne
            unsafe { mem::transmute(bytes) }
        }

        /// Uuden koodin tulisi mieluummin käyttää
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Palauttaa pienimmän arvon, jota tällä kokonaislukutyypillä voidaan edustaa.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// Uuden koodin tulisi mieluummin käyttää
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Palauttaa suurimman arvon, jota tällä kokonaislukutyypillä voidaan edustaa.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}