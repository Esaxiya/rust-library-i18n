//! Grisu3-algoritmin Rust-sovitus, joka on kuvattu kohdassa "Liukulukujen tulostaminen nopeasti ja tarkasti kokonaislukujen avulla" [^ 1].
//! Se käyttää noin 1 kt esilaskettua taulukkoa, ja vuorostaan se on erittäin nopea useimmille syötteille.
//!
//! [^1]: Florian Loitsch.2010. Liukulukujen tulostaminen nopeasti ja
//!   tarkasti kokonaislukuilla.SIGPLAN Ei.45, 6 (kesäkuu 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// katso perustelut `format_shortest_opt`: n kommenteista.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Annettu `x > 0` palauttaa arvon `(k, 10^k)` siten, että `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Lyhin tila-toteutus Grisulle.
///
/// Se palauttaa `None`: n, kun se muuten palauttaisi epätarkan esityksen.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // tarvitsemme vähintään kolme bittiä tarkkuutta

    // aloita normalisoiduilla arvoilla jaetulla eksponentilla
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // löytää mikä tahansa `cached = 10^minusk` niin, että `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // koska `plus` on normalisoitu, se tarkoittaa `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // `ALPHA`: n ja `GAMMA`: n valintojen perusteella tämä asettaa `plus * cached`: n `[4, 2^32)`: ään.
    //
    // on tietysti toivottavaa maksimoida `GAMMA - ALPHA`, jotta emme tarvitse paljon välimuistissa olevia 10: n tehoja, mutta on joitain näkökohtia:
    //
    //
    // 1. Haluamme pitää `floor(plus * cached)`: n `u32`: n sisällä, koska se tarvitsee kallista jakoa.
    //    (Tätä ei voida välttää, loput vaaditaan tarkkuuden arvioimiseksi.)
    // 2.
    // loppuosa `floor(plus * cached)` kerrotaan toistuvasti 10: llä, eikä sen tule ylittyä.
    //
    // ensimmäinen antaa `64 + GAMMA <= 32`, kun taas toinen antaa `10 * 2^-ALPHA <= 2^64`;
    // -60 ja -32 on suurin rajoitus tällä rajoituksella, ja V8 käyttää niitä myös.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // asteikko fps.tämä antaa maksimivirheen 1 ulp (todettu lauseesta 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-todellinen miinusalue
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // `minus`: n yläpuolella `v` ja `plus`*kvantisoidaan* likiarvot (virhe <1 ulp).
    // koska emme tiedä, että virhe on positiivinen tai negatiivinen, käytämme kahta likiarvoa, jotka on sijoitettu tasan toisistaan ja joiden suurin virhe on 2 ulps.
    //
    // "unsafe region" on liberaali intervalli, jonka luomme alun perin.
    // "safe region" on konservatiivinen aikaväli, jonka vain hyväksymme.
    // aloitamme oikealla repr-toiminnolla vaarallisella alueella ja yritämme löytää lähimmän repr-arvon `v`: lle, joka on myös turvallisella alueella.
    // jos emme pysty, luopumme.
    //
    let plus1 = plus.f + 1;
    // olkoon plus0 = plus.f, 1;//vain selitykseksi olkoon minus0 = minus.f + 1;//vain selityksen vuoksi
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // jaettu eksponentti

    // jaa `plus1` kiinteiksi ja murto-osiksi.
    // kiinteät osat voidaan taata u32: ssä, koska välimuistissa oleva teho takaa `plus < 2^32`: n ja normalisoitu `plus.f` on aina pienempi kuin `2^64 - 2^4` tarkkuusvaatimuksen vuoksi.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // Laske suurin `10^max_kappa` enintään `plus1` (siis `plus1 < 10^(max_kappa+1)`).
    // tämä on `kappa`: n yläraja alapuolella.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Lause 6.2: jos `k` on suurin kokonaisluku st
    // `0 <= y mod 10^k <= y - x`,              sitten `V = floor(y / 10^k) * 10^k` on `[x, y]`: ssä ja yksi lyhimmistä esityksistä (minimaalisella merkitsevien numeroiden lukumäärällä) tällä alueella.
    //
    //
    // etsi numeron pituus `kappa` välillä `(minus1, plus1)` lauseen 6.2 mukaisesti.
    // Lause 6.2 voidaan hyväksyä sulkemaan pois `x` vaatimalla sen sijaan `y mod 10^k < y - x`.
    // (esim. `x` =32000, `y` =32777; `kappa` =2, koska "y mod 10 ^ 3=777 <y, x=777".) algoritmi luottaa myöhempään todentamisvaiheeseen `y`: n poissulkemiseksi.
    //
    let delta1 = plus1 - minus1;
    // anna delta1int=(delta1>> e) käyttää;//vain selityksen vuoksi
    let delta1frac = delta1 & ((1 << e) - 1);

    // renderoi kiinteät osat tarkistaen samalla tarkkuuden jokaisessa vaiheessa.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // numerot, joita ei vielä ole renderöity
    loop {
        // meillä on aina vähintään yksi numero renderöitävissä, `plus1 >= 10^kappa`-invarianteina:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (tästä seuraa, että `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // jaa `remainder` luvulla `10^kappa`.molemmat ovat skaalattu `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; olemme löytäneet oikean `kappa`.
            let ten_kappa = (ten_kappa as u64) << e; // skaalaa 10 ^ kappa takaisin jaettuun eksponenttiin
            return round_and_weed(
                // TURVALLISUUS: alustimme muistin yllä.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // katkaise silmukka, kun olemme renderöineet kaikki integraaliluvut.
        // numeroiden tarkka lukumäärä on `max_kappa + 1` kuten `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // palauttaa invariants
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // renderoi murto-osat tarkistaen samalla tarkkuuden jokaisessa vaiheessa.
    // tällä kertaa luotamme toistuviin kertolaskuihin, koska jakaminen menettää tarkkuuden.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // seuraavan numeron tulisi olla merkittävä, koska olemme testanneet sen ennen invariantien puhkeamista, missä `m = max_kappa + 1` (numeroiden erottamaton osa):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // ei vuoda, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // jaa `remainder` `10^kappa`: llä.
        // molemmat on skaalattu `2^e / 10^kappa`: llä, joten jälkimmäinen on implisiittinen tässä.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // implisiittinen jakaja
            return round_and_weed(
                // TURVALLISUUS: alustimme muistin yllä.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // palauttaa invariants
        kappa -= 1;
        remainder = r;
    }

    // Olemme luoneet kaikki `plus1`: n merkittävät numerot, mutta emme ole varmoja, onko se optimaalinen.
    // Esimerkiksi, jos `minus1` on 3.14153 ... ja `plus1` on 3.14158 ..., 3.14154: stä 3.14158: ään on 5 erilaista lyhintä esitystä, mutta meillä on vain suurin.
    // meidän on vähennettävä peräkkäin viimeistä numeroa ja tarkistettava, onko tämä optimaalinen repr.
    // ehdokkaita on korkeintaan 9 (.1-..9), joten tämä on melko nopea.("rounding"-vaihe)
    //
    // toiminto tarkistaa, onko tämä "optimal"-repr todella ulp-alueiden sisällä, ja on myös mahdollista, että "second-to-optimal"-repr voi todella olla optimaalinen pyöristysvirheen vuoksi.
    // molemmissa tapauksissa tämä palauttaa `None`.
    // ("weeding"-vaihe)
    //
    // kaikki tässä olevat argumentit skaalataan yhteisellä (mutta implisiittisellä) arvolla `k` siten, että:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (ja myös `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (ja myös `threshold > plus1v` aiemmilta invarianteilta)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // tuottaa kaksi likiarvoa `v`: ään (itse asiassa `plus1 - v`) 1.5-ulpsissa.
        // tuloksena olevan edustuksen tulisi olla lähin edustus molemmille.
        //
        // tässä käytetään `plus1 - v`: ää, koska `plus1`: n suhteen tehdään laskelmat overflow/underflow: n välttämiseksi (tästä syystä näennäisesti vaihdetut nimet).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // pienennä viimeistä numeroa ja pysähdy lähimpään `v + 1 ulp`: n esitykseen.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // työskentelemme likimääräisten numeroiden `w(n)` kanssa, joka on alun perin yhtä suuri kuin `plus1 - plus1 % 10^kappa`.silmukan rungon suorittamisen jälkeen `n` kertaa, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // asetamme `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (siis `jäännös= plus1w(0)`) yksinkertaistaa tarkastuksia.
            // Huomaa, että `plus1w(n)` kasvaa aina.
            //
            // meillä on kolme ehtoa lopettaa.mikä tahansa niistä tekee silmukasta kykenemättömän jatkamaan, mutta meillä on sitten ainakin yksi kelvollinen edustus, joka tiedetään olevan lähinnä `v + 1 ulp`: ää.
            // merkitsemme ne lyhyinä sanoina TC1-TC3.
            //
            // TC1: `w(n) <= v + 1 ulp`, ts. Tämä on viimeinen repr, joka voi olla lähin.
            // tämä vastaa `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`: ää.
            // yhdistettynä TC2: ään (joka tarkistaa, onko `w(n+1)` is valid), tämä estää `plus1w(n)`: n laskennan mahdollisen ylivuotamisen.
            //
            // TC2: `w(n+1) < minus1`, toisin sanoen seuraava edustaja ei ehdottomasti pyöristy `v`: ään.
            // tämä vastaa `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`: ää.
            // vasen puoli voi ylittyä, mutta tiedämme `threshold > plus1v`: n, joten jos TC1 on väärä, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` ja voimme testata turvallisesti `threshold - plus1w(n) < 10^kappa`: n.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, eli seuraava edustaja on
            // ei lähempänä `v + 1 ulp` kuin nykyinen repr.
            // `z(n) = plus1v_up - plus1w(n)` antaa `abs(z(n)) <= abs(z(n+1))`.taas olettaen, että TC1 on väärä, meillä on `z(n) > 0`.meillä on kaksi harkittavaa tapausta:
            //
            // - kun `z(n+1) >= 0`: TC3: stä tulee `z(n) <= z(n+1)`.
            // kun `plus1w(n)` kasvaa, `z(n)`: n pitäisi laskea, ja tämä on selvästi väärä.
            // - kun `z(n+1) < 0`:
            //   - TC3a: ennakkoedellytys on `plus1v_up < plus1w(n) + 10^kappa`.olettaen, että TC2 on väärä, `threshold >= plus1w(n) + 10^kappa`, joten se ei voi ylivuotaa.
            //   - TC3b: TC3: stä tulee `z(n) <= -z(n+1)`, ts. `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   negatiivinen TC1 antaa `plus1v_up > plus1w(n)`: n, joten se ei voi ylittää tai alivuotoa yhdistettynä TC3a: n kanssa.
            //
            // näin ollen meidän pitäisi lopettaa, kun `TC1 || TC2 || (TC3a && TC3b)`.seuraava on yhtä suuri kuin sen käänteinen, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // Lyhin repr ei voi loppua `0`: llä
                plus1w += ten_kappa;
            }
        }

        // Tarkista, onko tämä esitys myös lähinnä `v - 1 ulp`: tä.
        //
        // tämä on yksinkertaisesti sama kuin `v + 1 ulp`: n päättämisehdot, jolloin kaikki `plus1v_up` korvataan `plus1v_down`: llä.
        // ylivuotoanalyysi pätee yhtä lailla.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // nyt meillä on lähin edustus `v`: ään `plus1`: n ja `minus1`: n välillä.
        // tämä on kuitenkin liian liberaalia, joten hylkäämme kaikki `w(n)`-tiedostot, jotka eivät ole `plus0`: n ja `minus0`: n välillä, eli `plus1 - plus1w(n) <= minus0` tai `plus1 - plus1w(n) >= plus0`.
        // käytämme tosiseikkoja, jotka `threshold = plus1 - minus1` ja `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Lyhin tila-toteutus Grisulle Dragon-varalla.
///
/// Tätä tulisi käyttää useimmissa tapauksissa.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // TURVALLISUUS: Lainan tarkistaja ei ole tarpeeksi älykäs, jotta voimme käyttää `buf`: ää
    // toisessa branch: ssä, joten pesemme täällä eliniän.
    // Mutta käytämme `buf`: ää uudelleen vain, jos `format_shortest_opt` palautti `None`: n, joten tämä on kunnossa.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Tarkka ja kiinteän tilan toteutus Grisulle.
///
/// Se palauttaa `None`: n, kun se muuten palauttaisi epätarkan esityksen.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // tarvitsemme vähintään kolme bittiä tarkkuutta
    assert!(!buf.is_empty());

    // normalisoi ja skaalaa `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // jaa `v` kiinteiksi ja murto-osiksi.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // sekä vanhan `v`: n että uuden `v`: n (skaalaa `10^-k`) virhe on <1 ulp (lause 5.1).
    // koska emme tiedä, että virhe on positiivinen tai negatiivinen, käytämme kahta likiarvoa, jotka on sijoitettu tasan toisistaan ja joiden suurin virhe on 2 ulps (sama lyhyimmässä tapauksessa).
    //
    //
    // Tavoitteena on löytää tarkalleen pyöristetyt numerosarjat, jotka ovat yhteisiä sekä `v - 1 ulp`: lle että `v + 1 ulp`: lle, jotta olemme mahdollisimman varmoja.
    // jos tämä ei ole mahdollista, emme tiedä mikä on oikea lähtö `v`: lle, joten luopumme ja pudotamme takaisin.
    //
    // `err` on määritelty `1 ulp * 2^e`: ksi (sama kuin XP: n `vfrac`: ssä), ja skaalamme sen aina, kun `v` skaalataan.
    //
    //
    //
    let mut err = 1;

    // Laske suurin `10^max_kappa` enintään `v` (siis `v < 10^(max_kappa+1)`).
    // tämä on `kappa`: n yläraja alapuolella.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // jos työskentelemme viimeisen numeron rajoituksen kanssa, meidän on lyhennettävä puskuria ennen varsinaista renderointia kaksinkertaisen pyöristyksen välttämiseksi.
    //
    // Huomaa, että puskuria on suurennettava uudelleen, kun pyöristäminen tapahtuu!
    let len = if exp <= limit {
        // Hups, emme voi edes tuottaa *yhtä* numeroa.
        // tämä on mahdollista, kun meillä on esimerkiksi jotain 9.5 ja se pyöristetään kymmeneen.
        //
        // periaatteessa voimme soittaa välittömästi `possibly_round`: lle tyhjällä puskurilla, mutta `max_ten_kappa << e`: n skaalaus 10: llä voi johtaa ylivuotoon.
        //
        // joten olemme täällä huolimattomia ja laajennamme virhealuetta kertoimella 10.
        // tämä lisää väärän negatiivisen osuutta, mutta vain hyvin,*hyvin* vähän;
        // sillä voi olla merkitystä vain, kun mantissa on yli 60 bittiä.
        //
        // TURVALLISUUS: `len=0`, joten velvollisuus alustaa tämä muisti on triviaali.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // renderöi kiinteät osat.
    // virhe on kokonaan murto-osa, joten meidän ei tarvitse tarkistaa sitä tässä osassa.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // numerot, joita ei vielä ole renderöity
    loop {
        // meillä on aina vähintään yksi numero, joka tekee invarianteista:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (tästä seuraa, että `remainder = vint % 10^(kappa+1)`)
        //
        //

        // jaa `remainder` luvulla `10^kappa`.molemmat ovat skaalattu `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // onko puskuri täynnä?Suorita pyöristyslupa loppuosan kanssa.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // TURVALLISUUS: Olemme alustaneet `len`: n monta tavua.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // katkaise silmukka, kun olemme renderöineet kaikki integraaliluvut.
        // numeroiden tarkka lukumäärä on `max_kappa + 1` kuten `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // palauttaa invariants
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // renderoi murto-osat.
    //
    // periaatteessa voimme jatkaa viimeiseen käytettävissä olevaan numeroon ja tarkistaa tarkkuuden.
    // valitettavasti työskentelemme rajallisten kokoisten kokonaislukujen kanssa, joten tarvitsemme jonkin kriteerin ylivuoton havaitsemiseksi.
    // V8 käyttää `remainder > err`: ää, josta tulee väärä, kun `v - 1 ulp`: n ja `v`: n ensimmäiset `i`-merkitsevät numerot eroavat toisistaan.
    // tämä kuitenkin hylkää liian monen muuten kelvollisen syötteen.
    //
    // koska myöhemmässä vaiheessa on oikea ylivuototunnistus, käytämme sen sijaan tiukempaa kriteeriä:
    // Jatkamme, kunnes `err` ylittää `10^kappa / 2`, joten `v - 1 ulp`: n ja `v + 1 ulp`: n välinen alue sisältää ehdottomasti kaksi tai useampia pyöristettyjä esityksiä.
    //
    // tämä on sama kuin `possibly_round`: n kaksi ensimmäistä vertailua viitteeksi.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // invariants, jossa `m = max_kappa + 1` (numeroiden luku kiinteässä osassa):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // ei vuoda, `2^e * 10 < 2^64`
        err *= 10; // ei vuoda, `err * 10 < 2^e * 5 < 2^64`

        // jaa `remainder` `10^kappa`: llä.
        // molemmat on skaalattu `2^e / 10^kappa`: llä, joten jälkimmäinen on implisiittinen tässä.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // onko puskuri täynnä?Suorita pyöristyslupa loppuosan kanssa.
        if i == len {
            // TURVALLISUUS: Olemme alustaneet `len`: n monta tavua.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // palauttaa invariants
        remainder = r;
    }

    // lisälaskenta on hyödytöntä (`possibly_round` epäonnistuu ehdottomasti), joten luopumme.
    return None;

    // Olemme luoneet kaikki vaaditut `v`-numerot, joiden on oltava samat kuin `v - 1 ulp`: n vastaavilla numeroilla.
    // nyt tarkistamme, onko sekä `v - 1 ulp`: llä että `v + 1 ulp`: llä yhteinen edustus;tämä voi olla sama generoiduille numeroille tai näiden numeroiden pyöristetylle versiolle.
    //
    // Jos alue sisältää useita saman pituisia esityksiä, emme voi olla varmoja ja meidän pitäisi palauttaa sen sijaan `None`.
    //
    // kaikki tässä olevat argumentit skaalataan yhteisellä (mutta implisiittisellä) arvolla `k` siten, että:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // TURVALLISUUS: `buf`: n ensimmäiset `len`-tavut on alustettava.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (viitteeksi katkoviiva osoittaa tarkan arvon mahdollisille esityksille tietyssä numeromäärässä.)
        //
        //
        // virhe on liian suuri, jotta `v - 1 ulp`: n ja `v + 1 ulp`: n välillä on ainakin kolme mahdollista esitystapaa.
        // emme voi määrittää, mikä on oikea.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // itse asiassa 1/2 ulp riittää esittämään kaksi mahdollista esitystä.
        // (muista, että tarvitsemme ainutlaatuisen esityksen sekä `v - 1 ulp`: lle että `v + 1 ulp`: lle.) Tämä ei tule yli, kuten `ulp < ten_kappa` ensimmäisestä tarkistuksesta.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // Jos `v + 1 ulp` on lähempänä pyöristettyä kuvaa (joka on jo `buf`: ssä), voimme palata turvallisesti.
        // Huomaa, että `v - 1 ulp`*voi olla* pienempi kuin nykyinen esitys, mutta `1 ulp < 10^kappa / 2`: nä tämä ehto riittää:
        // `v - 1 ulp`: n ja nykyisen esityksen välinen etäisyys ei voi olla suurempi kuin `10^kappa / 2`.
        //
        // ehto on yhtä suuri kuin `remainder + ulp < 10^kappa / 2`.
        // koska tämä voi helposti ylivuotoa, tarkista ensin, onko `remainder < 10^kappa / 2`.
        // Olemme jo vahvistaneet, että `ulp < 10^kappa / 2`, joten niin kauan kuin `10^kappa` ei ylivuotoa loppujen lopuksi, toinen tarkistus on hieno.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // TURVALLISUUS: soittajamme alustaa muistin.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------loput------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // toisaalta, jos `v - 1 ulp` on lähempänä pyöristettyä esitystä, meidän tulisi pyöristää ylöspäin ja palata.
        // samasta syystä meidän ei tarvitse tarkistaa `v + 1 ulp`: ää.
        //
        // ehto on yhtä suuri kuin `remainder - ulp >= 10^kappa / 2`.
        // jälleen tarkistamme ensin, onko `remainder > ulp` (huomaa, että tämä ei ole `remainder >= ulp`, koska `10^kappa` ei ole koskaan nolla).
        //
        // Huomaa myös, että `remainder - ulp <= 10^kappa`, joten toinen tarkistus ei ylikuormitu.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // TURVALLISUUS: soittajan on oltava alustanut muistin.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // lisää ylimääräinen numero vain, kun meiltä on pyydetty kiinteää tarkkuutta.
                // meidän on myös tarkistettava, että jos alkuperäinen puskuri oli tyhjä, lisänumero voidaan lisätä vain, kun `exp == limit` (edge-tapaus).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // TURVALLISUUS: me ja soittajamme alustimme muistin.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // muuten olemme tuomittuja (ts. jotkut `v - 1 ulp`: n ja `v + 1 ulp`: n väliset arvot pyöristyvät alaspäin ja toiset pyöristävät ylöspäin) ja luopumme.
        //
        None
    }
}

/// Tarkka ja kiinteän tilan toteutus Grisulle Dragon-varalla.
///
/// Tätä tulisi käyttää useimmissa tapauksissa.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // TURVALLISUUS: Lainan tarkistaja ei ole tarpeeksi älykäs, jotta voimme käyttää `buf`: ää
    // toisessa branch: ssä, joten pesemme täällä eliniän.
    // Mutta käytämme `buf`: ää uudelleen vain, jos `format_exact_opt` palautti `None`: n, joten tämä on kunnossa.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}