//! Dekoodaa liukuluvun arvon yksittäisiksi osiksi ja virhealueiksi.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Dekoodattu allekirjoittamaton äärellinen arvo, joka:
///
/// - Alkuperäinen arvo on yhtä suuri kuin `mant * 2^exp`.
///
/// - Mikä tahansa numero `(mant - minus)*2^exp`-`(mant + plus)* 2^exp` pyöristyy alkuperäiseen arvoon.
/// Alue on kattava vain, kun `inclusive` on `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Skaalattu mantissa.
    pub mant: u64,
    /// Alempi virhealue.
    pub minus: u64,
    /// Ylävirhealue.
    pub plus: u64,
    /// Pohjan 2 jaettu eksponentti.
    pub exp: i16,
    /// Totta, kun virhealue on kattava.
    ///
    /// IEEE 754: ssä tämä pätee, kun alkuperäinen mantissa oli tasainen.
    pub inclusive: bool,
}

/// Dekoodattu allekirjoittamaton arvo.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Ääretön, joko positiivinen tai negatiivinen.
    Infinite,
    /// Nolla, joko positiivinen tai negatiivinen.
    Zero,
    /// Äärelliset numerot, joissa on edelleen dekoodatut kentät.
    Finite(Decoded),
}

/// Liukulukutyyppi, joka voidaan "purkaa" d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Pienin positiivinen normalisoitu arvo.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Palauttaa merkin (tosi, kun negatiivinen) ja `FullDecoded`-arvon annetusta liukuluvun luvusta.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // naapurit: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode säilyttää aina eksponentin, joten mantissa skaalataan subnormaalille.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // naapurit: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // missä maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // naapurit: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}