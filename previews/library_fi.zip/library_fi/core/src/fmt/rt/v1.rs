//! Tämä on sisäinen moduuli, jota ifmt!ajonaikainen.Nämä rakenteet lähetetään staattisiin matriiseihin muotoilujonojen kääntämiseksi ennenaikaisesti.
//!
//! Nämä määritelmät ovat samanlaisia kuin niiden `ct`-ekvivalentit, mutta eroavat toisistaan siinä, että ne voidaan allokoida staattisesti ja optimoida hieman ajonaikaisiksi
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Mahdolliset tasaukset, joita voidaan pyytää osana muotoiludirektiiviä.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Ilmoitus siitä, että sisällön tulee olla vasemmalle tasattu.
    Left,
    /// Ilmoitus siitä, että sisällön tulee olla oikeassa linjassa.
    Right,
    /// Ilmoitus sisällön kohdistamisesta keskelle.
    Center,
    /// Kohdistamista ei pyydetty.
    Unknown,
}

/// [width](https://doc.rust-lang.org/std/fmt/#width)-ja [precision](https://doc.rust-lang.org/std/fmt/#precision)-määrittelijät käyttävät sitä.
#[derive(Copy, Clone)]
pub enum Count {
    /// Määritetty kirjaimellisella numerolla, tallentaa arvon
    Is(usize),
    /// Määritetty `$`-ja `*`-syntaksilla, tallentaa hakemiston `args`: ään
    Param(usize),
    /// Ei määritelty
    Implied,
}