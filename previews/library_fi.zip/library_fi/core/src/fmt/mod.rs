//! Apuohjelmat merkkijonojen muotoiluun ja tulostamiseen.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// `Formatter::align` palauttaa mahdolliset kohdistukset
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Ilmoitus siitä, että sisällön tulee olla vasemmalle tasattu.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Ilmoitus siitä, että sisällön tulee olla oikeassa linjassa.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Ilmoitus sisällön kohdistamisesta keskelle.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// Muotoilumenetelmillä palautettu tyyppi.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// Virhetyyppi, joka palautetaan viestin muotoilemisesta streamiksi.
///
/// Tämä tyyppi ei tue muun kuin virheilmoituksen lähettämistä.
/// Mahdolliset ylimääräiset tiedot on järjestettävä välitettäväksi muulla tavalla.
///
/// Tärkeä asia on muistaa, että tyyppiä `fmt::Error` ei pidä sekoittaa [`std::io::Error`]: ään tai [`std::error::Error`]: ään, mikä voi myös olla soveltamisalasi.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// trait kirjoittamiseen tai muotoilemiseen Unicode-hyväksyviin puskureihin tai suoratoistoihin.
///
/// Tämä trait hyväksyy vain UTF-8-koodatut tiedot eikä [flushable].
/// Jos haluat hyväksyä vain Unicoden etkä tarvitse huuhtelua, ota tämä trait käyttöön;
/// muuten sinun tulisi toteuttaa [`std::io::Write`].
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// Kirjoittaa merkkijonon tähän kirjoittajaan palauttaen, onnistuiko kirjoitus.
    ///
    /// Tämä menetelmä voi onnistua vain, jos koko merkkijonolohko on kirjoitettu onnistuneesti, eikä tätä menetelmää voida palata ennen kuin kaikki tiedot on kirjoitettu tai tapahtuu virhe.
    ///
    ///
    /// # Errors
    ///
    /// Tämä toiminto palauttaa [`Error`]-esiintymän virheen yhteydessä.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// Kirjoittaa [`char`]: n tähän kirjoittajaan palauttaen, onnistuiko kirjoitus.
    ///
    /// Yksi [`char`] voidaan koodata useammaksi kuin yhdeksi tavuksi.
    /// Tämä menetelmä voi onnistua vain, jos koko tavusekvenssi on kirjoitettu onnistuneesti, ja tämä menetelmä ei palaa ennen kuin kaikki tiedot on kirjoitettu tai tapahtuu virhe.
    ///
    ///
    /// # Errors
    ///
    /// Tämä toiminto palauttaa [`Error`]-esiintymän virheen yhteydessä.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// Liimaa [`write!`]-makron käyttöön tämän trait-sovelluksen toteuttajien kanssa.
    ///
    /// Tätä menetelmää ei yleensä pidä käyttää manuaalisesti, vaan itse [`write!`]-makron kautta.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// Alustuksen kokoonpano.
///
/// `Formatter` edustaa erilaisia muotoiluun liittyviä vaihtoehtoja.
/// Käyttäjät eivät rakenna `` muotoilijoita '' suoraan;muutettava viittaus yhteen siirretään kaikkien muotoilun traits, kuten [`Debug`] ja [`Display`], `fmt`-menetelmälle.
///
///
/// Jos haluat olla vuorovaikutuksessa `Formatter`: n kanssa, sinun on käytettävä erilaisia tapoja muuttaa muotoiluun liittyviä vaihtoehtoja.
/// Katso esimerkkejä `Formatter`: ssä määriteltyjen menetelmien dokumentaatiosta.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// Argumentti on pohjimmiltaan optimoitu osittain käytetty muotoilutoiminto, joka vastaa `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result`: ää.

extern "C" {
    type Opaque;
}

/// Tämä rakenne edustaa yleistä "argument": ää, jonka Xprintf-toimintoperhe ottaa.Se sisältää toiminnon, jolla muotoillaan annettu arvo.
/// Käännöshetkellä varmistetaan, että funktiolla ja arvolla on oikeat tyypit, ja sitten tätä rakennetta käytetään kanonisoimaan argumentit yhdeksi tyypiksi.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// Tämä takaa yhden vakaan arvon indices/counts: ään liittyvälle toiminnon osoittimelle muotoilun infrastruktuurissa.
//
// Huomaa, että sellaisenaan määritelty funktio ei olisi oikea, koska funktiot merkitään aina nimettömäksi_addr nykyisen laskun avulla LLVM IR: ään, joten niiden osoitetta ei pidetä tärkeänä LLVM: lle ja sellaisenaan as_usize-näyttelijä olisi voitu kääntää väärin.
//
// Käytännössä emme koskaan kutsu as_usize-asetuksia ei-usize-sisältävissä tiedoissa (muotoiluparametrien staattisen luomisen vuoksi), joten tämä on vain lisätarkistus.
//
// Haluamme ensisijaisesti varmistaa, että `USIZE_MARKER`: n funktion osoittimella on osoite, joka vastaa *vain* toimintoja, jotka myös ottavat `&usize`: n ensimmäiseksi argumentiksi.
// Tässä oleva read_volatile varmistaa, että voimme turvallisesti valmistaa käyttömuodon ohitetusta viitteestä ja että tämä osoite ei osoita ei-käyttää-toimintoa.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // TURVALLISUUS: ptr on viite
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // TURVALLISUUS: `mem::transmute(x)` on turvallinen, koska
        //     1. `&'b T` säilyttää `'b`: n alkuperäisen käyttöiän (jotta sillä ei olisi rajatonta käyttöikää)
        //     2.
        //     `&'b T` ja `&'b Opaque`: llä on sama muistiasettelu (kun `T` on `Sized`, kuten täälläkin), `mem::transmute(f)` on turvallinen, koska `fn(&T, &mut Formatter<'_>) -> Result`: llä ja `fn(&Opaque, &mut Formatter<'_>) -> Result`: llä on sama ABI (kunhan `T` on `Sized`)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // TURVALLISUUS: `formatter`-kentän arvoksi asetetaan vain USIZE_MARKER, jos
            // arvo on usize, joten tämä on turvallista
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// liput, jotka ovat käytettävissä muodossa_args v1-muodossa
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// Kun käytetään format_args! ()-Makroa, tätä toimintoa käytetään Arguments-rakenteen luomiseen.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// Tätä toimintoa käytetään määrittämään epätyypilliset muotoiluparametrit.
    /// `pieces`-ryhmän on oltava vähintään yhtä pitkä kuin `fmt`, jotta voidaan luoda kelvollinen Arguments-rakenne.
    /// Lisäksi kaikkien `fmt`: n `Count`: n, jotka ovat `CountIsParam` tai `CountIsNextParam`, on osoitettava `argumentusize`: llä luotuun argumenttiin.
    ///
    /// Tämän tekemättä jättäminen ei kuitenkaan aiheuta vaarallisuutta, mutta jättää kelpaamattomat huomiotta.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// Arvioi alustetun tekstin pituuden.
    ///
    /// Tätä on tarkoitus käyttää alkuperäisen `String`-kapasiteetin asettamiseen `format!`: ää käytettäessä.
    /// Note: tämä ei ole ala-eikä yläraja.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // Jos muotoilumerkkijono alkaa argumentilla, älä jaa mitään uudelleen, ellei kappaleiden pituus ole merkittävä.
            //
            //
            0
        } else {
            // Joitakin argumentteja on, joten kaikki lisäpainallukset jakavat merkkijonon uudelleen.
            //
            // Tämän välttämiseksi olemme "pre-doubling"-kapasiteettia täällä.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// Tämä rakenne edustaa turvallisesti esikäännettyä versiota muotoilumerkkijonosta ja sen argumenteista.
/// Tätä ei voida luoda ajon aikana, koska sitä ei voida tehdä turvallisesti, joten rakennuttajia ei anneta ja kentät ovat yksityisiä muokkaamisen estämiseksi.
///
///
/// [`format_args!`]-makro luo turvallisesti esiintymän tästä rakenteesta.
/// Makro vahvistaa muotoilumerkkijonon kokoamisajankohtana, joten [`write()`]-ja [`format()`]-toimintojen käyttö voidaan suorittaa turvallisesti.
///
/// Voit käyttää `Arguments<'a>`: ää, jonka [`format_args!`] palauttaa `Debug`-ja `Display`-konteksteissa, kuten alla on esitetty.
/// Esimerkki osoittaa myös, että `Debug` ja `Display` muotoilevat saman asian: interpoloidun muotoisen merkkijonon `format_args!`: ssä.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // Alusta merkkijonokappaleet tulostettavaksi.
    pieces: &'a [&'static str],

    // Paikkamerkki-tai `None`-tiedot, jos kaikki tiedot ovat oletusarvoisia (kuten "{}{}": ssä).
    fmt: Option<&'a [rt::v1::Argument]>,

    // Dynaamiset argumentit interpolointia varten, limitettävät merkkijonoilla.
    // (Jokaista argumenttia edeltää merkkijono.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// Hanki alustettu merkkijono, jos sillä ei ole alustettavia argumentteja.
    ///
    /// Tätä voidaan käyttää varausten välttämiseen kaikkein triviaalimmassa tapauksessa.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` pitäisi muotoilla lähtö ohjelmoijaa kohti, virheenkorjauskontekstissa.
///
/// Yleisesti ottaen sinun tulisi vain toteuttaa `derive` a `Debug`.
///
/// Kun sitä käytetään vaihtoehtoisen `#?`-muotoilijan kanssa, tulosteet ovat melko painettuja.
///
/// Lisätietoja alustajista on kohdassa [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// Tätä trait: tä voidaan käyttää `#[derive]`: n kanssa, jos kaikki kentät toteuttavat `Debug`: n.
/// Kun `derive`d sanoille, se käyttää `struct`: n nimeä, sitten `{`, sitten pilkulla erotettua luetteloa kunkin kentän nimestä ja `Debug`-arvosta ja sitten `}`.
/// Lausekkeelle "enum" käytetään variantin nimeä ja tarvittaessa `(`, sitten kenttien `Debug`-arvoja ja sitten `)`.
///
/// # Stability
///
/// Johdetut `Debug`-muodot eivät ole vakaita, joten ne voivat muuttua future Rust-versioiden kanssa.
/// Lisäksi vakiokirjaston tarjoamien tyyppien `Debug`-toteutukset (`libstd`, `libcore`, `liballoc` jne.) Eivät ole vakaita, ja ne voivat myös muuttua future Rust-versioiden kanssa.
///
///
/// # Examples
///
/// Toteutuksen johtaminen:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Manuaalinen toteutus:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// [`Formatter`]-rakenteessa on useita apumenetelmiä, jotka auttavat sinua manuaalisissa toteutuksissa, kuten [`debug_struct`].
///
/// `Debug` joko `derive`: ää tai [`Formatter`]: n debug builder-sovellusliittymää käyttävät toteutukset tukevat melko tulostusta vaihtoehtoisella lipulla: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// Kaunis tulostus `#?`: llä:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// Muotoile arvo annetulla muotoilijalla.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// Erillinen moduuli viedä makro `Debug` uudelleen prelude: stä ilman trait `Debug`: ää.
pub(crate) mod macros {
    /// Johda makro, joka tuottaa implantaatin trait `Debug`: stä.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// Alusta trait tyhjälle muodolle, `{}`.
///
/// `Display` on samanlainen kuin [`Debug`], mutta `Display` on tarkoitettu käyttäjälle suunnattuun lähtöön, joten sitä ei voida johtaa.
///
///
/// Lisätietoja alustajista on kohdassa [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `Display`: n käyttöönotto tyypissä:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// Muotoile arvo annetulla muotoilijalla.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// `Octal` trait: n tulisi muotoilla ulostulonsa numero base-8: ssä.
///
/// Alkeellisilla allekirjoitetuilla kokonaisluvuilla (`i8`-`i128` ja `isize`) negatiiviset arvot muotoillaan näiden kahden komplementtiesityksenä.
///
///
/// Vaihtoehtoinen lippu `#` lisää `0o`: n lähdön eteen.
///
/// Lisätietoja alustajista on kohdassa [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32`: n peruskäyttö:
///
/// ```
/// let x = 42; // 42 on '52' oktaalissa
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// `Octal`: n käyttöönotto tyypissä:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // delegoida i32: n käyttöönottoon
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// Muotoile arvo annetulla muotoilijalla.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// `Binary` trait: n tulisi muotoilla ulostulonsa luku binäärimuodossa.
///
/// Alkeellisilla allekirjoitetuilla kokonaisluvuilla ([`i8`]-[`i128`] ja [`isize`]) negatiiviset arvot muotoillaan näiden kahden komplementtiesityksenä.
///
///
/// Vaihtoehtoinen lippu `#` lisää `0b`: n lähdön eteen.
///
/// Lisätietoja alustajista on kohdassa [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// [`i32`]: n peruskäyttö:
///
/// ```
/// let x = 42; // 42 on '101010' binäärimuodossa
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// `Binary`: n käyttöönotto tyypissä:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // delegoida i32: n käyttöönottoon
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// Muotoile arvo annetulla muotoilijalla.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// `LowerHex` trait: n tulisi muotoilla tulosteensa luku heksadesimaalina, `a`-`f` pienillä kirjaimilla.
///
/// Alkeellisilla allekirjoitetuilla kokonaisluvuilla (`i8`-`i128` ja `isize`) negatiiviset arvot muotoillaan näiden kahden komplementtiesityksenä.
///
///
/// Vaihtoehtoinen lippu `#` lisää `0x`: n lähdön eteen.
///
/// Lisätietoja alustajista on kohdassa [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32`: n peruskäyttö:
///
/// ```
/// let x = 42; // 42 on '2a' heksadesimaalina
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// `LowerHex`: n käyttöönotto tyypissä:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // delegoida i32: n käyttöönottoon
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// Muotoile arvo annetulla muotoilijalla.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// `UpperHex` trait: n tulisi muotoilla tulosteensa luku heksadesimaalina, `A`-`F` isoilla kirjaimilla.
///
/// Alkeellisilla allekirjoitetuilla kokonaisluvuilla (`i8`-`i128` ja `isize`) negatiiviset arvot muotoillaan näiden kahden komplementtiesityksenä.
///
///
/// Vaihtoehtoinen lippu `#` lisää `0x`: n lähdön eteen.
///
/// Lisätietoja alustajista on kohdassa [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32`: n peruskäyttö:
///
/// ```
/// let x = 42; // 42 on '2A' heksadesimaalina
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// `UpperHex`: n käyttöönotto tyypissä:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // delegoida i32: n käyttöönottoon
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// Muotoile arvo annetulla muotoilijalla.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// `Pointer` trait: n tulisi muotoilla ulostulonsa muistipaikkana.
/// Tämä esitetään yleisesti heksadesimaalina.
///
/// Lisätietoja alustajista on kohdassa [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `&i32`: n peruskäyttö:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // tämä tuottaa jotain '0x7f06092ac6d0'
/// ```
///
/// `Pointer`: n käyttöönotto tyypissä:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // käytä `as` muuntaa `*const T`, joka toteuttaa Pointer, jota voimme käyttää
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// Muotoile arvo annetulla muotoilijalla.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// `LowerExp` trait: n tulisi muotoilla tuotanto tieteellisessä muodossa pienillä `e`-kirjaimilla.
///
/// Lisätietoja alustajista on kohdassa [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64`: n peruskäyttö:
///
/// ```
/// let x = 42.0; // 42.0 on '4.2e1' tieteellisessä merkinnässä
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// `LowerExp`: n käyttöönotto tyypissä:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // delegoida f64: n toteutukseen
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// Muotoile arvo annetulla muotoilijalla.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// `UpperExp` trait: n tulisi muotoilla tuotoksensa tieteellisessä notaatiossa isoilla `E`-kirjaimilla.
///
/// Lisätietoja alustajista on kohdassa [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64`: n peruskäyttö:
///
/// ```
/// let x = 42.0; // 42.0 on '4.2E1' tieteellisessä merkinnässä
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// `UpperExp`: n käyttöönotto tyypissä:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // delegoida f64: n toteutukseen
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// Muotoile arvo annetulla muotoilijalla.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `write`-toiminto ottaa ulostulovirran ja `Arguments`-rakenteen, joka voidaan esikäännellä `format_args!`-makrolla.
///
///
/// Argumentit muotoillaan määritetyn merkkijonon mukaan annettuun lähtövirtaan.
///
/// # Examples
///
/// Peruskäyttö:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// Huomaa, että [`write!`]: n käyttö saattaa olla suositeltavaa.Esimerkki:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // Voimme käyttää oletusmuotoiluparametreja kaikille argumenteille.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // Jokaisella spesifillä on vastaava argumentti, jota edeltää merkkijono.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // TURVALLISUUS: arg ja args.args ovat peräisin samoista argumenteista,
                // mikä takaa, että indeksit ovat aina rajojen sisällä.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // Jäljellä voi olla vain yksi merkkijono.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // TURVALLISUUS: arg ja argit tulevat samoista argumenteista,
    // mikä takaa, että indeksit ovat aina rajojen sisällä.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // Pura oikea argumentti
    debug_assert!(arg.position < args.len());
    // TURVALLISUUS: arg ja argit tulevat samoista argumenteista,
    // mikä takaa sen indeksin olevan aina rajojen sisällä.
    let value = unsafe { args.get_unchecked(arg.position) };

    // Tee sitten jonkin verran tulostusta
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // TURVALLISUUS: cnt ja args tulevat samoista argumenteista,
            // mikä takaa, että tämä indeksi on aina rajojen sisällä.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// Pehmuste loppuaan jotain.Palautti `Formatter::padding`.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// Kirjoita tämä viesti täyte.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // Haluamme muuttaa tätä
            buf: wrap(self.buf),

            // Ja säilytä nämä
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // Apumenetelmät, joita käytetään argumenttien muotoilussa ja käsittelyssä, joita kaikki traits-muotoilut voivat käyttää.
    //

    /// Suorittaa oikean täytteen kokonaisluvulle, joka on jo lähetetty str.
    /// Str: n ei tulisi *sisältää* kokonaislukumerkkiä, joka lisätään tällä menetelmällä.
    ///
    /// # Arguments
    ///
    /// * is_negegative, onko alkuperäinen kokonaisluku joko positiivinen vai nolla.
    /// * etuliite, jos '#'-merkki (Alternate) on annettu, tämä on etuliite, joka laitetaan numeron eteen.
    ///
    /// * buf, tavutaulukko, johon numero on muotoiltu
    ///
    /// Tämä toiminto ottaa huomioon annetut liput ja vähimmäisleveyden oikein.
    /// Se ei ota tarkkuutta huomioon.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // Meidän on poistettava "-" numerolähdöstä.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // Kirjoittaa merkin, jos se on olemassa, ja sitten etuliitteen, jos sitä pyydettiin
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // `width`-kenttä on tässä vaiheessa pikemminkin `min-width`-parametri.
        match self.width {
            // Jos vähimmäispituuden vaatimuksia ei ole, voimme vain kirjoittaa tavut.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Tarkista, ylitämmekö vähimmäisleveyden, jos näin on, voimme myös kirjoittaa tavut.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Merkki ja etuliite menevät ennen täytettä, jos täytemerkki on nolla
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // Muussa tapauksessa merkki ja etuliite kulkevat täytteen jälkeen
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Tämä toiminto ottaa merkkijonolohkon ja lähettää sen sisäiseen puskuriin sovellettujen määritettyjen muotoilulippujen käytön jälkeen.
    /// Geneeristen merkkijonojen tunnistamat liput ovat:
    ///
    /// * leveys, emittoitavan vähimmäisleveys
    /// * fill/align - mitä lähettää ja missä lähettää, jos annettu merkkijono on pehmustettava
    /// * tarkkuus, suurin sallittu pituus, merkkijono katkaistaan, jos se on pidempi kuin tämä pituus
    ///
    /// Tämä toiminto jättää huomiotta `flag`-parametrit.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // Varmista, että edessä on nopea polku
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // `precision`-kenttä voidaan tulkita `max-width`: ksi muotoillulle merkkijonolle.
        //
        let s = if let Some(max) = self.precision {
            // Jos merkkijonomme on pidempi kuin tarkkuus, meillä on oltava katkaisu.
            // Muiden lippujen, kuten `fill`, `width` ja `align`, on kuitenkin toimittava kuten aina.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // Tässä oleva LLVM ei voi todistaa, että `..i` ei panic `&s[..i]`, mutta tiedämme, että se ei voi panic.
                // Käytä `get` + `unwrap_or` välttääksesi `unsafe`: tä, äläkä muuten lähetä mitään panic-koodia tässä.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // `width`-kenttä on tässä vaiheessa pikemminkin `min-width`-parametri.
        match self.width {
            // Jos olemme alle enimmäispituuden eikä minimipituuden vaatimuksia ole, voimme vain lähettää merkkijonon
            //
            None => self.buf.write_str(s),
            // Jos olemme alle enimmäisleveyden, tarkista, ylitämmekö vähimmäisleveyden, jos niin, se on yhtä helppoa kuin vain antaa merkkijono.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // Jos olemme alle enimmäis-ja vähimmäisleveyden, täytä sitten minimileveys määritetyllä merkkijonolla + jonkin verran tasausta.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Kirjoita esitäyte ja palauta kirjoittamaton jälkitäyte.
    /// Soittajat ovat vastuussa siitä, että täytteen jälkeinen kirjoitus kirjoitetaan pehmustetun asian jälkeen.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// Ottaa alustetut osat ja kiinnittää pehmusteen.
    /// Oletetaan, että soittaja on jo renderoinut osat vaaditulla tarkkuudella, jotta `self.precision` voidaan jättää huomiotta.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // merkkitietoiselle nollatäytteelle renderöimme merkin ensin ja käyttäydymme ikään kuin meillä ei olisi mitään merkkiä alusta alkaen.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // merkki menee aina ensin
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // poista merkki alustetuista osista
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // loput osat käyvät läpi tavallisen pehmusteprosessin.
            let len = formatted.len();
            let ret = if width <= len {
                // ei pehmustetta
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // tämä on yleinen tapaus ja valitsemme oikotien
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // TURVALLISUUS: Tätä käytetään malleissa `flt2dec::Part::Num` ja `flt2dec::Part::Copy`.
            // Se on turvallista käyttää `flt2dec::Part::Num`: ssä, koska kaikki merkit `c` ovat `b'0'`: n ja `b'9'`: n välillä, mikä tarkoittaa, että `s` on kelvollinen UTF-8.
            // On myös käytännössä turvallista käyttää `flt2dec::Part::Copy(buf)`: ää, koska `buf`: n pitäisi olla tavallinen ASCII, mutta joku voi siirtää `buf`: n huonon arvon `flt2dec::to_shortest_str`: ään, koska se on julkinen toiminto.
            //
            // FIXME: Selvitä, johtaako tämä UB: hen.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 nollaa
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// Kirjoittaa joitain tietoja tämän muotoilijan sisältämään alla olevaan puskuriin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // Tämä vastaa:
    ///         // kirjoita! (muotoilija, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// Kirjoittaa joitain alustettuja tietoja tähän instanssiin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// Liput muotoilua varten
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// Merkki, jota käytetään 'fill': nä aina tasauksen aikana.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // Asetamme kohdistuksen oikealle ">": llä.
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// Lippu, joka osoittaa, mitä tasausmuotoa pyydettiin.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// Valinnaisesti määritetty kokonaisluvun leveys, jonka tuloksen tulisi olla.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // Jos saimme leveyden, käytämme sitä
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // Muuten emme tee mitään erityistä
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// Valinnaisesti määritelty tarkkuus numerotyypeille.
    /// Vaihtoehtoisesti merkkijonotyyppien enimmäisleveys.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // Jos saimme tarkkuuden, käytämme sitä.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // Muuten oletuksena on 2.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// Määrittää, onko `+`-lippu määritetty.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// Määrittää, onko `-`-lippu määritetty.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // Haluatko miinusmerkin?Ota yksi!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// Määrittää, onko `#`-lippu määritetty.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// Määrittää, onko `0`-lippu määritetty.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // Ohitamme muotoilijan vaihtoehdot.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: Päätä, minkä julkisen sovellusliittymän haluamme näille kahdelle lipulle.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// Luo [`DebugStruct`]-rakennustyökalun, joka on suunniteltu auttamaan [`fmt::Debug`]-toteutusten luomisessa rakenteille.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// Luo `DebugTuple`-rakennustyökalun, joka on suunniteltu auttamaan luomaan `fmt::Debug`-toteutuksia kaksisuuntaisille rakenteille.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// Luo `DebugList`-rakennustyökalun, joka on suunniteltu auttamaan `fmt::Debug`-toteutusten luomisessa luettelomaisille rakenteille.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// Luo `DebugSet`-rakennustyökalun, joka on suunniteltu auttamaan `fmt::Debug`-toteutusten luomisessa joukon kaltaisille rakenteille.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// Tässä monimutkaisemmassa esimerkissä käytämme [`format_args!`]: ää ja `.debug_set()`: tä rakentamaan luettelon otteluvarastoista:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// Luo `DebugMap`-rakennustyökalun, joka on suunniteltu auttamaan karttamaisten rakenteiden `fmt::Debug`-toteutusten luomisessa.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// Ytimen muotoilun traits toteutukset

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // Jos hiili tarvitsee pakenemista, huuhtele toistaiseksi myöhästyminen ja kirjoita, muuten ohita
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // LowerHex käsittelee jo vaihtoehtoista lippua erityisenä-se merkitsee, haluatko lisätä etuliitteen 0x: llä.
        // Käytämme sitä selvittämään, nollataanko nolla vai ei, ja asetamme sen sitten ehdoitta etuliitteen saamiseksi.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// Display/Debug: n käyttöönotto erilaisille ydintyypeille

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // RefCell on lainattu mutatiivisesti, joten emme voi tarkastella sen arvoa täällä.
                // Näytä sen sijaan paikkamerkki.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// Jos odotit testien olevan täällä, katso sen sijaan core/tests/fmt.rs-tiedostoa, se on paljon helpompaa kuin kaikkien rt::Piece-rakenteiden luominen täällä.
//
// Jaossa crate on myös testejä niille, jotka tarvitsevat varauksia.