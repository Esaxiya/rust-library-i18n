//! Perustoiminnot muistin käsittelemiseksi.
//!
//! Tämä moduuli sisältää toimintoja tyyppien koon ja tasauksen kyselyyn, muistin alustamiseen ja käsittelyyn.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Omistaa arvon "forgets" arvosta **suorittamatta sen tuhoajaa**.
///
/// Kaikki resurssit, joita arvo hallinnoi, kuten kasan muisti tai tiedostokahva, viipyvät ikuisesti saavuttamattomassa tilassa.Se ei kuitenkaan takaa, että tämän muistin osoittimet pysyvät voimassa.
///
/// * Jos haluat vuotaa muistia, katso [`Box::leak`].
/// * Jos haluat saada raakaa osoittinta muistiin, katso [`Box::into_raw`].
/// * Jos haluat hävittää arvon oikein, suorita sen tuhoaja, katso [`mem::drop`].
///
/// # Safety
///
/// `forget` ei ole merkitty `unsafe`: ksi, koska Rust: n turvatakuut eivät sisällä takuuta siitä, että tuhoajat toimivat aina.
/// Esimerkiksi ohjelma voi luoda referenssisyklin [`Rc`][rc]: n avulla tai soittaa [`process::exit`][exit]: lle poistuakseen ilman destruktoreita.
/// Siten `mem::forget`: n salliminen turvallisesta koodista ei muuta Rust: n turvallisuustakeita perusteellisesti.
///
/// Resurssien, kuten muistin tai I/O-objektien, vuotaminen ei yleensä ole toivottavaa.
/// Tarve tulee esiin joissakin erikoistuneissa käyttötapauksissa FFI: lle tai vaaralliselle koodille, mutta silloinkin [`ManuallyDrop`] on tyypillisesti edullinen.
///
/// Koska arvon unohtaminen on sallittua, minkä tahansa kirjoittamasi `unsafe`-koodin on sallittava tämä mahdollisuus.Et voi palauttaa arvoa ja odottaa, että soittaja suorittaa välttämättä arvon tuhoajan.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// `mem::forget`: n kanoninen turvallinen käyttö on kiertää `Drop` trait: n toteuttama arvon tuhoaja.Esimerkiksi tämä vuotaa `File`: n, ts
/// takaisin muuttujan ottama tila, mutta älä koskaan sulje taustalla olevaa järjestelmäresurssia:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Tämä on hyödyllistä, kun taustalla olevan resurssin omistajuus on aiemmin siirretty koodiin Rust: n ulkopuolelle, esimerkiksi lähettämällä raakatiedoston kuvaaja C-koodiin.
///
/// # Suhde `ManuallyDrop`: ään
///
/// Vaikka `mem::forget`: ää voidaan käyttää myös *muistin* omistajuuden siirtämiseen, se on virhealtista.
/// [`ManuallyDrop`] tulisi käyttää sen sijaan.Harkitse esimerkiksi tätä koodia:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Rakenna `String` käyttämällä `v`: n sisältöä
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // vuotaa `v`, koska sen muistia hallinnoi nyt `s`
/// mem::forget(v);  // VIRHE, v on virheellinen eikä sitä saa siirtää funktiolle
/// assert_eq!(s, "Az");
/// // `s` on epäsuorasti pudonnut ja sen muisti on jaettu.
/// ```
///
/// Edellä olevassa esimerkissä on kaksi ongelmaa:
///
/// * Jos `String`: n rakentamisen ja `mem::forget()`: n kutsumisen väliin lisätään enemmän koodia, panic sisällä aiheuttaisi kaksinkertaisen vapauden, koska samaa muistia käsittelevät sekä `v` että `s`.
/// * Soittamisen jälkeen `v.as_mut_ptr()` ja tietojen omistajuuden välittäminen `s`: lle `v`-arvo on virheellinen.
/// Silloinkin kun arvo siirretään juuri `mem::forget`: ään (joka ei tarkasta sitä), joillakin tyypeillä on tiukat vaatimukset arvoilleen, mikä tekee niistä virheellisiä roikkuessaan tai kun niitä ei enää omisteta.
/// Virheellisten arvojen käyttö millään tavalla, mukaan lukien niiden välittäminen funktioihin tai palauttaminen funktioista, on määrittelemätöntä käyttäytymistä ja saattaa rikkoa kääntäjän tekemiä oletuksia.
///
/// Siirtyminen `ManuallyDrop`: ään välttää molemmat ongelmat:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Ennen kuin purat `v`: n raaka-osiinsa, varmista, että se ei putoa!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Pura nyt `v`.Nämä toiminnot eivät voi olla panic, joten vuotoja ei voi tapahtua.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Lopuksi rakenna `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` on epäsuorasti pudonnut ja sen muisti on jaettu.
/// ```
///
/// `ManuallyDrop` estää voimakkaasti kaksinkertaisen vapauden, koska poistamme `v: n tuhoajan käytöstä ennen kuin teemme mitään muuta.
/// `mem::forget()` ei salli tätä, koska se kuluttaa argumenttinsa ja pakottaa meidät kutsumaan sitä vasta, kun olemme purkaneet kaikki tarvitsemamme `v`: stä.
/// Vaikka panic otettaisiin käyttöön `ManuallyDrop`: n rakentamisen ja merkkijonon rakentamisen välillä (mitä ei voi tapahtua kuvassa esitetyssä koodissa), se johtaisi vuotoon eikä kaksinkertaiseen vapautukseen.
/// Toisin sanoen, `ManuallyDrop` erehtyy vuotamisen puolella sen sijaan, että erehtyisi (kaksois) pudotuksen puolelle.
///
/// Lisäksi `ManuallyDrop` estää meitä joutumasta "touch" `v`: ään sen jälkeen, kun omistusoikeus on siirretty `s`: lle. Viimeinen vaihe vuorovaikutuksessa `v`: n kanssa sen hävittämiseksi suorittamatta sen tuhoajaa vältetään kokonaan.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Kuten [`forget`], mutta hyväksyy myös mitoittamattomat arvot.
///
/// Tämä toiminto on vain välilevy, joka on tarkoitus poistaa, kun `unsized_locals`-ominaisuus vakautuu.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Palauttaa tyypin koon tavuina.
///
/// Tarkemmin sanottuna tämä on tavuissa siirtymä matriisin peräkkäisten elementtien välillä kyseisen alkiotyypin mukaan lukien kohdistuspehmuste.
///
/// Siten minkä tahansa tyypin `T` ja pituuden `n` kohdalla `[T; n]`: n koko on `n * size_of::<T>()`.
///
/// Yleensä tyypin koko ei ole vakaa kokoelmissa, mutta tietyt tyypit, kuten primitiivit, ovat.
///
/// Seuraava taulukko antaa primitiivien koon.
///
/// Tyyppi |koko: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 merkkiä |4
///
/// Lisäksi `usize` ja `isize` ovat saman kokoisia.
///
/// Tyypeillä `*const T`, `&T`, `Box<T>`, `Option<&T>` ja `Option<Box<T>>` on kaikki sama koko.
/// Jos `T` on kokoa, kaikilla näillä tyypeillä on sama koko kuin `usize`.
///
/// Osoittimen muutettavuus ei muuta sen kokoa.`&T` ja `&mut T` ovat sinänsä saman kokoisia.
/// Samoin `*const T` ja `* mut T`.
///
/// # `#[repr(C)]`-tuotteiden koko
///
/// Kohteiden `C`-esityksellä on määritelty asettelu.
/// Tämän asettelun avulla kohteiden koko on myös vakaa, kunhan kaikilla kentillä on vakaa koko.
///
/// ## Rakenteiden koko
///
/// `structs`: n koko määritetään seuraavalla algoritmilla.
///
/// Jokaiselle rakennekentän kentälle, joka on järjestetty ilmoitusjärjestyksellä:
///
/// 1. Lisää kentän koko.
/// 2. Pyöristä nykyinen koko lähimpään seuraavan kentän [alignment]-kertoimeen.
///
/// Lopuksi pyöristetään rakennekoko sen [alignment]: n lähimpään kerrokseen.
/// Rakenteen tasaus on yleensä kaikkien sen kenttien suurin tasaus;tätä voidaan muuttaa `repr(align(N))`: n avulla.
///
/// Toisin kuin `C`, nollakokoisia rakenteita ei pyöristetä yhden tavun kokoon.
///
/// ## Enumien koko
///
/// Enumeilla, joilla ei ole muuta tietoa kuin erotuskyky, on sama koko kuin C-enumeilla alustalla, jolle ne on koottu.
///
/// ## Unionien koko
///
/// Unionin koko on sen suurimman kentän koko.
///
/// Toisin kuin `C`, nollakokoisia liittoja ei pyöristetä yhden tavun kokoon.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Joitakin alkukantaisia
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Jotkut taulukot
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Osoittimen koon tasa-arvo
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// `#[repr(C)]`: n käyttö.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Ensimmäisen kentän koko on 1, joten lisää 1 kokoon.Koko on 1.
/// // Toisen kentän kohdistus on 2, joten lisää 1 täytteen kokoon.Koko on 2.
/// // Toisen kentän koko on 2, joten lisää 2 kokoon.Koko on 4.
/// // Kolmannen kentän kohdistus on 1, joten lisää 0 täytteen kokoon.Koko on 4.
/// // Kolmannen kentän koko on 1, joten lisää 1 kokoon.Koko on 5.
/// // Lopuksi rakenteen kohdistus on 2 (koska suurin tasaus sen kenttien välillä on 2), joten lisää 1 täytteen kokoon.
/// // Koko on 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuplen rakenteet noudattavat samoja sääntöjä.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Huomaa, että kenttien järjestäminen uudelleen voi pienentää kokoa.
/// // Voimme poistaa molemmat täytetavut asettamalla `third` ennen `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Unionin koko on suurimman kentän koko.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Palauttaa osoitetun arvon koon tavuina.
///
/// Tämä on yleensä sama kuin `size_of::<T>()`.
/// Kuitenkin, kun `T`*: lla ei ole* staattisesti tunnettua kokoa, esim. Siivu [`[T]`][slice] tai [trait object], `size_of_val`: ää voidaan käyttää dynaamisesti tunnetun koon saamiseksi.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // TURVALLISUUS: `val` on viite, joten se on kelvollinen raaka osoitin
    unsafe { intrinsics::size_of_val(val) }
}

/// Palauttaa osoitetun arvon koon tavuina.
///
/// Tämä on yleensä sama kuin `size_of::<T>()`.Kuitenkin, kun `T`*: lla ei ole* staattisesti tunnettua kokoa, esim. Siivu [`[T]`][slice] tai [trait object], `size_of_val_raw`: ää voidaan käyttää dynaamisesti tunnetun koon saamiseksi.
///
/// # Safety
///
/// Tätä toimintoa voidaan soittaa vain, jos seuraavat ehdot täyttyvät:
///
/// - Jos `T` on `Sized`, tämä toiminto on aina turvallinen soittaa.
/// - Jos `T`: n kokoinen pyrstö on:
///     - [slice], viipaleen pituuden on oltava alustettu kokonaisluku ja *koko arvon*(dynaamisen hännän pituus + staattisen kokoinen etuliite) koon on oltava `isize`.
///     - [trait object], osoittimen vtable-osan on osoitettava kelvollisella pakolla hankittu kelvollinen vtable, ja *koko arvon*(dynaamisen hännän pituus + staattisen kokoinen etuliite) koon on oltava `isize`.
///
///     - (unstable) [extern type], tämä toiminto on aina turvallinen soittaa, mutta voi panic tai palauttaa muuten väärän arvon, koska ulkoisen tyypin asettelua ei tunneta.
///     Tämä on sama käyttäytyminen kuin [`size_of_val`] viittauksessa tyyppiin, jolla on ulkoisen tyyppinen pyrstö.
///     - muuten tätä toimintoa ei voida kutsua konservatiivisesti.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // TURVALLISUUS: soittajan on annettava kelvollinen raaka osoitin
    unsafe { intrinsics::size_of_val(val) }
}

/// Palauttaa tyypin [ABI] vaaditun vähimmäistasoituksen.
///
/// Jokaisen viittauksen tyypin `T` arvoon on oltava tämän luvun kerrannaisena.
///
/// Tätä tasausta käytetään rakennekentissä.Se voi olla pienempi kuin edullinen kohdistus.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Palauttaa arvon [ABI] vaaditun vähimmäistasoituksen sen arvon tyypille, johon `val` osoittaa.
///
/// Jokaisen viittauksen tyypin `T` arvoon on oltava tämän luvun kerrannaisena.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // TURVALLISUUS: val on viite, joten se on kelvollinen raaka osoitin
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Palauttaa tyypin [ABI] vaaditun vähimmäistasoituksen.
///
/// Jokaisen viittauksen tyypin `T` arvoon on oltava tämän luvun kerrannaisena.
///
/// Tätä tasausta käytetään rakennekentissä.Se voi olla pienempi kuin edullinen kohdistus.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Palauttaa arvon [ABI] vaaditun vähimmäistasoituksen sen arvon tyypille, johon `val` osoittaa.
///
/// Jokaisen viittauksen tyypin `T` arvoon on oltava tämän luvun kerrannaisena.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // TURVALLISUUS: val on viite, joten se on kelvollinen raaka osoitin
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Palauttaa arvon [ABI] vaaditun vähimmäistasoituksen sen arvon tyypille, johon `val` osoittaa.
///
/// Jokaisen viittauksen tyypin `T` arvoon on oltava tämän luvun kerrannaisena.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Tätä toimintoa voidaan soittaa vain, jos seuraavat ehdot täyttyvät:
///
/// - Jos `T` on `Sized`, tämä toiminto on aina turvallinen soittaa.
/// - Jos `T`: n kokoinen pyrstö on:
///     - [slice], viipaleen pituuden on oltava alustettu kokonaisluku ja *koko arvon*(dynaamisen hännän pituus + staattisen kokoinen etuliite) koon on oltava `isize`.
///     - [trait object], osoittimen vtable-osan on osoitettava kelvollisella pakolla hankittu kelvollinen vtable, ja *koko arvon*(dynaamisen hännän pituus + staattisen kokoinen etuliite) koon on oltava `isize`.
///
///     - (unstable) [extern type], tämä toiminto on aina turvallinen soittaa, mutta voi panic tai palauttaa muuten väärän arvon, koska ulkoisen tyypin asettelua ei tunneta.
///     Tämä on sama käyttäytyminen kuin [`align_of_val`] viittauksessa tyyppiin, jolla on ulkoisen tyyppinen pyrstö.
///     - muuten tätä toimintoa ei voida kutsua konservatiivisesti.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // TURVALLISUUS: soittajan on annettava kelvollinen raaka osoitin
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Palauttaa arvon `true`, jos tyypin `T` pudottamisella on merkitystä.
///
/// Tämä on puhtaasti optimointivihje, ja se voidaan toteuttaa konservatiivisesti:
/// se voi palauttaa `true`-tyypin, jota ei tarvitse pudottaa.
/// Sellaisenaan aina palauttava `true` olisi kelvollinen toteutus tälle toiminnolle.Jos tämä toiminto tosiasiallisesti palauttaa `false`: n, voit olla varma, että `T`: n pudottamisella ei ole sivuvaikutuksia.
///
/// Alhaisen tason toteutusten, kuten kokoelmien, joiden on pudotettava tiedot manuaalisesti, tulisi käyttää tätä toimintoa välttääkseen turhaa yrittää pudottaa kaikkea sisältöä tuhoutuessaan.
///
/// Tällä ei ehkä ole merkitystä julkaisuversioissa (jossa silmukka, jolla ei ole sivuvaikutuksia, voidaan helposti havaita ja poistaa), mutta se on usein suuri voitto virheenkorjausrakenteille.
///
/// Huomaa, että [`drop_in_place`] suorittaa jo tämän tarkistuksen, joten jos työmääräsi voidaan vähentää pieneksi määräksi [`drop_in_place`]-puheluita, tämän käyttäminen on tarpeetonta.
/// Huomaa erityisesti, että voit [`drop_in_place`]: n siivun, ja se tarkistaa yhden needs_drop-tarkistuksen kaikille arvoille.
///
/// Vecin kaltaiset tyypit vain siksi vain `drop_in_place(&mut self[..])` ilman `needs_drop`: n käyttöä.
/// [`HashMap`]: n kaltaisten tyyppien on sen sijaan pudotettava arvot yksi kerrallaan, ja niiden tulisi käyttää tätä API: ta.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Tässä on esimerkki siitä, miten kokoelma voisi käyttää `needs_drop`: ää:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // pudota tiedot
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Palauttaa tyypin `T` arvon, jota edustaa kaikki nollatavu-kuvio.
///
/// Tämä tarkoittaa, että esimerkiksi `(u8, u16)`: n täytetavu ei välttämättä nollaudu.
///
/// Ei ole takeita siitä, että kaikki nollatavuinen kuvio edustaa kelvollista arvoa joillekin tyypille `T`.
/// Esimerkiksi kaikki nollatavuinen kuvio ei ole kelvollinen arvo viitetyypeille (``&T``, `&mut T`) ja funktiosoittimille.
/// `zeroed`: n käyttö tällaisissa tyypeissä aiheuttaa välittömän [undefined behavior][ub]: n, koska [the Rust compiler assumes][inv]: llä on aina kelvollinen arvo muuttujassa, jonka se pitää alustettuna.
///
///
/// Tällä on sama vaikutus kuin [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Se on joskus hyödyllinen FFI: lle, mutta sitä tulisi yleensä välttää.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Tämän toiminnon oikea käyttö: kokonaisluvun nollaaminen.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Tämän toiminnon väärä* käyttö: alustetaan viite nollalla.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Määrittelemätön käyttäytyminen!
/// let _y: fn() = unsafe { mem::zeroed() }; // Ja uudelleen!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // TURVALLISUUS: soittajan on taattava, että kaikki nollatiedot ovat voimassa mallille `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Ohittaa Rust: n normaalit muistin alustustarkistukset teeskentelemällä tuottavan tyypin `T` arvoa tekemättä kuitenkaan mitään.
///
/// **Tämä toiminto on poistettu käytöstä.** Käytä sen sijaan [`MaybeUninit<T>`]: ää.
///
/// Vanhentumisen syy on se, että toimintoa ei periaatteessa voida käyttää oikein: sillä on sama vaikutus kuin [`MaybeUninit::uninit().assume_init()`][uninit]: llä.
///
/// Kuten [`assume_init` documentation][assume_init] selittää, [the Rust compiler assumes][inv], että arvot alustetaan oikein.
/// Tämän seurauksena soittaminen esim
/// `mem::uninitialized::<bool>()` aiheuttaa välitöntä määrittelemätöntä käyttäytymistä palautettaessa `bool`, joka ei ole ehdottomasti joko `true` tai `false`.
/// Pahempi, todella alustamaton muisti, kuten se, mitä tänne palautetaan, on erityistä siinä mielessä, että kääntäjä tietää, että sillä ei ole kiinteää arvoa.
/// Tämä tekee määrittelemättömäksi käyttäytymiseksi, että muuttujassa on alustamattomia tietoja, vaikka muuttujalla olisi kokonaisluku.
/// (Huomaa, että alustamattomia kokonaislukuja koskevia sääntöjä ei ole vielä viimeistelty, mutta ennen kuin ne ovat, on suositeltavaa välttää niitä.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // TURVALLISUUS: soittajan on taattava, että `T`: lle on voimassa yhtenäistetty arvo.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Vaihtaa arvot kahdessa muutettavissa olevassa paikassa ilman, että kumpaakin aloitetaan.
///
/// * Jos haluat vaihtaa oletusarvoon tai näennäisarvoon, katso [`take`].
/// * Jos haluat vaihtaa välitetyn arvon palauttamalla vanhan arvon, katso [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // TURVALLISUUS: raakaviitteet on luotu turvallisista muutettavissa olevista viitteistä, jotka täyttävät kaikki vaatimukset
    // `ptr::swap_nonoverlapping_one`: n rajoitukset
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Korvaa `dest`: n oletusarvolla `T` palauttaen edellisen `dest`-arvon.
///
/// * Jos haluat korvata kahden muuttujan arvot, katso [`swap`].
/// * Jos haluat korvata välitetyn arvon oletusarvon sijaan, katso [`replace`].
///
/// # Examples
///
/// Yksinkertainen esimerkki:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` mahdollistaa strukturikentän omistamisen korvaamalla sen "empty"-arvolla.
/// Ilman `take`: ää voit törmätä tällaisiin ongelmiin:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Huomaa, että `T` ei välttämättä toteuta [`Clone`]: ää, joten se ei voi edes kloonata ja nollata `self.buf`: ää.
/// Mutta `take`: ää voidaan käyttää erottamaan `self.buf`: n alkuperäinen arvo `self`: stä, jolloin se voidaan palauttaa:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Siirtää `src`: n viitattuun `dest`: ään palauttamalla edellisen `dest`-arvon.
///
/// Kumpikaan arvo ei pudota.
///
/// * Jos haluat korvata kahden muuttujan arvot, katso [`swap`].
/// * Jos haluat korvata oletusarvon, katso [`take`].
///
/// # Examples
///
/// Yksinkertainen esimerkki:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` sallii rakennekentän kulutuksen korvaamalla sen toisella arvolla.
/// Ilman `replace`: ää voit törmätä tällaisiin ongelmiin:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Huomaa, että `T` ei välttämättä toteuta [`Clone`]: ää, joten emme voi edes kloonata `self.buf[i]`: tä välttääksemme liikkumisen.
/// Mutta `replace`: ää voidaan käyttää erottamaan kyseisen indeksin alkuperäinen arvo `self`: stä, jolloin se voidaan palauttaa:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // TURVALLISUUS: Luemme `dest`: stä, mutta kirjoitamme `src`: n suoraan sen jälkeen,
    // siten, että vanhaa arvoa ei kopioida.
    // Mikään ei pudota eikä mikään tässä voi panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Hävittää arvon.
///
/// Tämä tapahtuu kutsumalla argumentin [`Drop`][drop]-toteutus.
///
/// Tämä ei todellakaan tee mitään malleille, jotka toteuttavat `Copy`: n, esim
/// integers.
/// Tällaiset arvot kopioidaan ja _then_ siirretään funktioon, joten arvo säilyy tämän funktion kutsun jälkeen.
///
///
/// Tämä toiminto ei ole taikuutta;se on kirjaimellisesti määritelty
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Koska `_x` siirretään funktioon, se pudotetaan automaattisesti ennen funktion paluuta.
///
/// [drop]: Drop
///
/// # Examples
///
/// Peruskäyttö:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // pudota vector nimenomaisesti
/// ```
///
/// Koska [`RefCell`] panee lainasäännöt täytäntöön ajon aikana, `drop` voi vapauttaa [`RefCell`]-lainan:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // luopua muutettavissa olevasta lainasta tässä paikassa
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// `drop` ei vaikuta kokonaislukuihin ja muihin tyyppeihin, jotka toteuttavat [`Copy`]: n.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // kopio `x`: stä siirretään ja pudotetaan
/// drop(y); // kopio `y`: stä siirretään ja pudotetaan
///
/// println!("x: {}, y: {}", x, y.0); // yhä saatavilla
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Tulkitsee `src`: n tyypin `&U` ja lukee sitten `src` siirtämättä sisältämää arvoa.
///
/// Tämä toiminto olettaa, että osoitin `src` on kelvollinen [`size_of::<U>`][size_of]-tavuille muuntamalla `&T`: stä `&U`: iin ja lukemalla sitten `&U` (paitsi että tämä tehdään oikein, vaikka `&U` asettaa tiukemmat kohdistamisvaatimukset kuin `&T`).
/// Se luo myös turvallisesti kopion sisältämästä arvosta sen sijaan, että siirtyisi `src`: stä.
///
/// Se ei ole kääntöaikavirhe, jos `T` ja `U` ovat erikokoisia, mutta on erittäin suositeltavaa käyttää tätä toimintoa vain silloin, kun `T`: llä ja `U`: llä on sama koko.Tämä toiminto laukaisee [undefined behavior][ub]: n, jos `U` on suurempi kuin `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Kopioi tiedot 'foo_array': stä ja käsittele niitä 'Foo': nä
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Muokkaa kopioituja tietoja
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // 'foo_array': n sisällön ei olisi pitänyt muuttua
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Jos U: lla on korkeampi kohdistusvaatimus, src ei ehkä ole kohdistettu sopivasti.
    if align_of::<U>() > align_of::<T>() {
        // TURVALLISUUS: `src` on viite, joka on taattu voimassa lukemiseen.
        // Soittajan on taattava, että varsinainen transmutaatio on turvallista.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // TURVALLISUUS: `src` on viite, joka on taattu voimassa lukemiseen.
        // Tarkistimme juuri, että `src as *const U` oli kohdistettu oikein.
        // Soittajan on taattava, että varsinainen transmutaatio on turvallista.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Läpinäkymätön tyyppi, joka edustaa enumin erottelijaa.
///
/// Katso lisätietoja tämän moduulin [`discriminant`]-toiminnosta.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Näitä trait-toteutuksia ei voida johtaa, koska emme halua rajoja T: lle.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Palauttaa arvon, joka yksilöi yksilöllisesti enum-muunnoksen `v`: ssä.
///
/// Jos `T` ei ole enum, tämän toiminnon kutsuminen ei johda määrittelemättömään käyttäytymiseen, mutta palautusarvo on määrittelemätön.
///
///
/// # Stability
///
/// Enum-muunnoksen erottelija voi muuttua, jos enum-määritelmä muuttuu.
/// Joidenkin varianttien erottelija ei muutu samalla kääntäjällä tehtyjen käännösten välillä.
///
/// # Examples
///
/// Tätä voidaan käyttää vertailemaan tietoja, jotka kuljettavat tietoa, samalla kun todelliset tiedot jätetään huomioimatta:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Palauttaa varianttien lukumäärän laskentatyypissä `T`.
///
/// Jos `T` ei ole enum, tämän toiminnon kutsuminen ei johda määrittelemättömään käyttäytymiseen, mutta palautusarvo on määrittelemätön.
/// Vastaavasti, jos `T` on enum, jossa on enemmän variantteja kuin `usize::MAX`, palautusarvo on määrittelemätön.
/// Asuttamattomat variantit lasketaan.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}