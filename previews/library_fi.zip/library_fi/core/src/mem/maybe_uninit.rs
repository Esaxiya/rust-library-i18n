use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Käärintätyyppi `T`: n alustamattomien instanssien rakentamiseksi.
///
/// # Alustus muuttumaton
///
/// Kääntäjä olettaa yleensä, että muuttuja on alustettu oikein muuttujan tyypin vaatimusten mukaisesti.Esimerkiksi vertailutyyppisen muuttujan on oltava kohdistettu ja ei-NULL.
/// Tämä on invariantti, jota on aina noudatettava, myös vaarallisessa koodissa.
/// Tämän seurauksena viitetyyppisen muuttujan nolla-alustaminen aiheuttaa hetkellisen [undefined behavior][ub]: n riippumatta siitä, onko kyseinen viite koskaan käytetty muistin käyttämiseen:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // määrittelemätön käyttäytyminen!⚠️
/// // Vastaava koodi `MaybeUninit<&i32>`: n kanssa:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // määrittelemätön käyttäytyminen!⚠️
/// ```
///
/// Kääntäjä hyödyntää tätä erilaisissa optimoinnissa, kuten ajonaikaisissa tarkistuksissa ja `enum`-asettelun optimoinnissa.
///
/// Vastaavasti täysin alustamattomassa muistissa voi olla mitä tahansa sisältöä, kun taas `bool`: n on aina oltava `true` tai `false`.Siksi alustamattoman `bool`: n luominen on määrittelemätöntä käyttäytymistä:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // määrittelemätön käyttäytyminen!⚠️
/// // Vastaava koodi `MaybeUninit<bool>`: n kanssa:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // määrittelemätön käyttäytyminen!⚠️
/// ```
///
/// Lisäksi alustamaton muisti on erityinen siinä mielessä, että sillä ei ole kiinteää arvoa ("fixed" tarkoittaa "it won't change without being written to").Saman alustamattoman tavun lukeminen useita kertoja voi antaa erilaisia tuloksia.
/// Tämä tekee määrittelemättömäksi käyttäytymiseksi, että muuttujassa on alustamattomia tietoja, vaikka muuttujalla olisi kokonaislukutyyppi, joka muuten voi pitää mitä tahansa *kiinteää* bittikuviota:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // määrittelemätön käyttäytyminen!⚠️
/// // Vastaava koodi `MaybeUninit<i32>`: n kanssa:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // määrittelemätön käyttäytyminen!⚠️
/// ```
/// (Huomaa, että alustamattomia kokonaislukuja koskevia sääntöjä ei ole vielä viimeistelty, mutta ennen kuin ne ovat, on suositeltavaa välttää niitä.)
///
/// Tämän lisäksi muista, että useimmilla tyypeillä on muita invariantteja, paitsi että niitä pidetään pelkästään alustettuina tyyppitasolla.
/// Esimerkiksi "1"-alustettua [`Vec<T>`]: ää pidetään alustettuna (nykyisen toteutuksen mukaan; tämä ei ole vakaa takuu), koska ainoa vaatimus, jonka kääntäjä tietää siitä, on, että datan osoittimen on oltava nolla.
/// Tällaisen `Vec<T>`: n luominen ei aiheuta *välitöntä* määrittelemätöntä käyttäytymistä, mutta aiheuttaa määrittelemättömän käyttäytymisen useimmissa turvallisissa toiminnoissa (mukaan lukien pudottaminen).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` palvelee vaarallisen koodin käyttöä alustamattomien tietojen käsittelyssä.
/// Se on signaali kääntäjälle, joka osoittaa, että tässä olevia tietoja ei ehkä * alusteta:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Luo nimenomaisesti alustamaton viite.
/// // Kääntäjä tietää, että `MaybeUninit<T>`: n sisällä olevat tiedot saattavat olla virheellisiä, joten tämä ei ole UB: tä:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Aseta se kelvolliseen arvoon.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Pura alustetut tiedot-tämä on sallittua vain * sen jälkeen, kun `x` on alustettu oikein!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Sitten kääntäjä tietää, ettei tälle koodille tee virheellisiä oletuksia tai optimointeja.
///
/// Voit ajatella, että `MaybeUninit<T>` on vähän kuin `Option<T>`, mutta ilman ajoajan seurantaa ja ilman mitään turvatarkastuksia.
///
/// ## out-pointers
///
/// Voit käyttää `MaybeUninit<T>`: ää "out-pointers": n toteuttamiseen: sen sijaan, että palautat tietoja toiminnosta, välitä se osoittimeen johonkin (uninitialized)-muistiin tuloksen sijoittamiseksi.
/// Tästä voi olla hyötyä, kun soittajan on tärkeää hallita, kuinka tulos muistiin tallennetaan, ja haluat välttää tarpeettomia liikkeitä.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` ei pudota vanhaa sisältöä, mikä on tärkeää.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Nyt tiedämme, että `v` on alustettu!Tämä varmistaa myös, että vector putoaa oikein.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Alustetaan taulukko elementeittäin
///
/// `MaybeUninit<T>` voidaan käyttää alustamaan suuri joukko elementteittäin:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Luo alustamaton `MaybeUninit`-taulukko.
///     // `assume_init` on turvallinen, koska tyyppi, jonka väitämme alustaneen tässä, on joukko ``EhkäUninit``-tiedostoja, jotka eivät vaadi alustamista.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // `MaybeUninit`: n pudottaminen ei tee mitään.
///     // Siten raakan osoittimen määrityksen käyttäminen `ptr::write`: n sijaan ei aiheuta vanhan alustamattoman arvon pudottamista.
/////
///     // Myös jos silmukan aikana on panic, meillä on muistivuoto, mutta muistiturvallisuusongelmia ei ole.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Kaikki alustetaan.
///     // Muunna taulukko alustetuksi tyypiksi.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Voit työskennellä myös osittain alustettujen taulukoiden kanssa, jotka löytyvät matalan tason datarakenteista.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Luo alustamaton `MaybeUninit`-taulukko.
/// // `assume_init` on turvallinen, koska tyyppi, jonka väitämme alustaneen tässä, on joukko ``EhkäUninit``-tiedostoja, jotka eivät vaadi alustamista.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Laske määrittelemiemme elementtien määrä.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Pudota taulukon jokaiselle kohteelle, jos jaoimme sen.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Alustetaan rakennekohtainen kenttä
///
/// Voit käyttää `MaybeUninit<T>`: ää ja [`std::ptr::addr_of_mut`]-makroa alustaaksesi kentät kenttien mukaan:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Alustetaan `name`-kenttä
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // `list`-kentän alustus Jos täällä on panic, `name`-kentän `String` vuotaa.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Kaikki kentät alustetaan, joten soitamme `assume_init`: lle saadaksesi alustetun Foo: n.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` taataan, että sillä on sama koko, suuntaus ja ABI kuin `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Muista kuitenkin, että tyyppi *, joka sisältää*`MaybeUninit<T>`, ei välttämättä ole sama asettelu;Rust ei yleensä takaa, että `Foo<T>`: n kentillä on sama järjestys kuin `Foo<U>`: llä, vaikka `T`: llä ja `U`: llä on sama koko ja suuntaus.
///
/// Lisäksi koska mikä tahansa bittiarvo on kelvollinen `MaybeUninit<T>`: lle, kääntäjä ei voi käyttää non-zero/niche-filling-optimointeja, mikä saattaa johtaa suurempaan kokoon:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Jos `T` on FFI-turvallinen, niin on myös `MaybeUninit<T>`.
///
/// Vaikka `MaybeUninit` on `#[repr(transparent)]` (mikä tarkoittaa, että se takaa saman koon, kohdistuksen ja ABI: n kuin `T`), tämä ei *muuta* mitään edellisistä varoituksista.
/// `Option<T>` ja `Option<MaybeUninit<T>>`: llä voi silti olla erikokoisia, ja tyypit, jotka sisältävät tyypin `T` kentän, voidaan sijoittaa (ja mitoittaa) toisin kuin jos kenttä olisi `MaybeUninit<T>`.
/// `MaybeUninit` on liitostyyppi, ja liittojen `#[repr(transparent)]` on epävakaa (katso [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Ajan myötä `#[repr(transparent)]`: n tarkat takuut liitoissa voivat kehittyä, ja `MaybeUninit` voi jäädä `#[repr(transparent)]`: ksi.
/// `MaybeUninit<T>` takaa *aina*, että sillä on sama koko, suuntaus ja ABI kuin `T`;vain se, miten `MaybeUninit` toteuttaa tämän takuun, voi kehittyä.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang-esine, jotta voimme kääriä siihen muita tyyppejä.Tästä on hyötyä generaattoreille.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Emme soita `T::clone()`: lle, emme voi tietää, onko meidät alustettu riittävästi sitä varten.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Luo uuden `MaybeUninit<T>`: n, joka alustetaan annetulla arvolla.
    /// [`assume_init`]: lle on turvallista soittaa tämän toiminnon paluuarvo.
    ///
    /// Huomaa, että `MaybeUninit<T>`: n pudottaminen ei koskaan soita `T: n pudotuskoodia.
    /// Sinun vastuullasi on varmistaa, että `T` pudotetaan, jos se alustetaan.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Luo uuden `MaybeUninit<T>`: n alustamattomassa tilassa.
    ///
    /// Huomaa, että `MaybeUninit<T>`: n pudottaminen ei koskaan soita `T: n pudotuskoodia.
    /// Sinun vastuullasi on varmistaa, että `T` pudotetaan, jos se alustetaan.
    ///
    /// Katso esimerkkejä [type-level documentation][MaybeUninit]: stä.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Luo uusi `MaybeUninit<T>`-kohteiden ryhmä alustamattomassa tilassa.
    ///
    /// Note: future Rust-versiossa tämä menetelmä saattaa olla tarpeeton, kun matriisin kirjaimellinen syntakse sallii [repeating const expressions](https://github.com/rust-lang/rust/issues/49147): n.
    ///
    /// Alla olevassa esimerkissä voidaan sitten käyttää `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`: ää.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Palauttaa (mahdollisesti pienemmän) osion tosiasiallisesti luetuista tiedoista
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // TURVALLISUUS: Aloittamaton `[MaybeUninit<_>; LEN]` on kelvollinen.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Luo uuden `MaybeUninit<T>`: n alustamattomassa tilassa muistin ollessa täynnä `0`-tavuja.`T`: stä riippuu, tekeekö se jo oikean alustuksen.
    ///
    /// Esimerkiksi `MaybeUninit<usize>::zeroed()` alustetaan, mutta `MaybeUninit<&'static i32>::zeroed()` ei johdu siitä, että viitteet eivät saa olla nollia.
    ///
    /// Huomaa, että `MaybeUninit<T>`: n pudottaminen ei koskaan soita `T: n pudotuskoodia.
    /// Sinun vastuullasi on varmistaa, että `T` pudotetaan, jos se alustetaan.
    ///
    /// # Example
    ///
    /// Tämän toiminnon oikea käyttö: alustetaan nolla nollaan, jossa kaikissa rakennen kentissä voi olla bittikuvio 0 kelvollisena arvona.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Tämän toiminnon väärä* käyttö: `x.zeroed().assume_init()`: n soittaminen, kun `0` ei ole kelvollinen tyypin bittikuvio:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Parin sisällä luomme `NotZero`: n, jolla ei ole kelvollista erottelijaa.
    /// // Tämä on määrittelemätöntä käyttäytymistä.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // TURVALLISUUS: `u.as_mut_ptr()` osoittaa osoitettua muistia.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Asettaa `MaybeUninit<T>`: n arvon.
    /// Tämä korvaa kaikki aikaisemmat arvot pudottamatta niitä, joten ole varovainen, ettet käytä tätä kahdesti, ellet halua ohittaa destruktorin suorittamista.
    ///
    /// Mukavuutesi vuoksi tämä palauttaa myös muutettavan viitteen `self`: n (nyt turvallisesti alustettu) sisältöön.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // TURVALLISUUS: Alustimme juuri tämän arvon.
        unsafe { self.assume_init_mut() }
    }

    /// Hakee osoittimen sisältämään arvoon.
    /// Tästä osoittimesta lukeminen tai sen muuttaminen viitteeksi on määrittelemätöntä toimintaa, ellei `MaybeUninit<T>` ole alustettu.
    /// Muistiin kirjoittaminen, johon tämä osoitin (non-transitively) osoittaa, on määrittelemätöntä toimintaa (paitsi `UnsafeCell<T>`: n sisällä).
    ///
    /// # Examples
    ///
    /// Tämän menetelmän oikea käyttö:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Luo viite `MaybeUninit<T>`: ään.Tämä on ok, koska aloitimme sen.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// * Tämän menetelmän väärä käyttö:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Olemme luoneet viittauksen alustamattomaan vector-malliin!Tämä on määrittelemätöntä käyttäytymistä.⚠️
    /// ```
    ///
    /// (Huomaa, että alustamattomiin tietoihin viittaavia sääntöjä ei ole vielä viimeistelty, mutta niitä on suositeltavaa välttää, kunnes ne ovat valmiita.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` ja `ManuallyDrop` ovat molemmat `repr(transparent)`, jotta voimme heittää osoittimen.
        self as *const _ as *const T
    }

    /// Hakee muutettavan osoittimen sisältämään arvoon.
    /// Tästä osoittimesta lukeminen tai sen muuttaminen viitteeksi on määrittelemätöntä toimintaa, ellei `MaybeUninit<T>` ole alustettu.
    ///
    /// # Examples
    ///
    /// Tämän menetelmän oikea käyttö:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Luo viite `MaybeUninit<Vec<u32>>`: ään.
    /// // Tämä on ok, koska aloitimme sen.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// * Tämän menetelmän väärä käyttö:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Olemme luoneet viittauksen alustamattomaan vector-malliin!Tämä on määrittelemätöntä käyttäytymistä.⚠️
    /// ```
    ///
    /// (Huomaa, että alustamattomiin tietoihin viittaavia sääntöjä ei ole vielä viimeistelty, mutta niitä on suositeltavaa välttää, kunnes ne ovat valmiita.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` ja `ManuallyDrop` ovat molemmat `repr(transparent)`, jotta voimme heittää osoittimen.
        self as *mut _ as *mut T
    }

    /// Poimi arvo `MaybeUninit<T>`-säilöstä.Tämä on loistava tapa varmistaa, että data pudotetaan, koska tuloksena olevaan `T`: ään sovelletaan tavallista pudotuskäsittelyä.
    ///
    /// # Safety
    ///
    /// Soittajan on taattava, että `MaybeUninit<T>` on todella alustetussa tilassa.Tämän kutsuminen, kun sisältöä ei ole vielä täysin alustettu, aiheuttaa välittömästi määrittelemätöntä käyttäytymistä.
    /// [type-level documentation][inv] sisältää lisätietoja tästä alustusmuuttujasta.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Tämän lisäksi muista, että useimmilla tyypeillä on muita invariantteja, paitsi että niitä pidetään pelkästään alustettuina tyyppitasolla.
    /// Esimerkiksi "1"-alustettua [`Vec<T>`]: ää pidetään alustettuna (nykyisen toteutuksen mukaan; tämä ei ole vakaa takuu), koska ainoa vaatimus, jonka kääntäjä tietää siitä, on, että datan osoittimen on oltava nolla.
    ///
    /// Tällaisen `Vec<T>`: n luominen ei aiheuta *välitöntä* määrittelemätöntä käyttäytymistä, mutta aiheuttaa määrittelemättömän käyttäytymisen useimmissa turvallisissa toiminnoissa (mukaan lukien pudottaminen).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Tämän menetelmän oikea käyttö:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// * Tämän menetelmän väärä käyttö:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` ei ollut vielä alustettu, joten tämä viimeinen rivi aiheutti määrittelemätöntä käyttäytymistä.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // TURVALLISUUS: soittajan on taattava, että `self` alustetaan.
        // Tämä tarkoittaa myös sitä, että `self`: n on oltava `value`-muunnos.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Lukee arvon `MaybeUninit<T>`-säilöstä.Tuloksena olevalle `T`: lle tehdään tavallinen pudotuskäsittely.
    ///
    /// Aina kun mahdollista, on parempi käyttää [`assume_init`]: ää, mikä estää `MaybeUninit<T>`: n sisällön kopioinnin.
    ///
    /// # Safety
    ///
    /// Soittajan on taattava, että `MaybeUninit<T>` on todella alustetussa tilassa.Tämän kutsuminen, kun sisältöä ei ole vielä täysin alustettu, aiheuttaa määrittelemätöntä käyttäytymistä.
    /// [type-level documentation][inv] sisältää lisätietoja tästä alustusmuuttujasta.
    ///
    /// Lisäksi tämä jättää kopion samoista tiedoista `MaybeUninit<T>`: n taakse.
    /// Kun käytät useita kopioita tiedoista (soittamalla `assume_init_read`: lle useita kertoja tai soittamalla ensin `assume_init_read`: lle ja sitten [`assume_init`]: lle), sinun vastuullasi on varmistaa, että tiedot todellakin kopioidaan.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Tämän menetelmän oikea käyttö:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` on `Copy`, joten voimme lukea useita kertoja.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `None`-arvon kopioiminen on kunnossa, joten voimme lukea useita kertoja.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// * Tämän menetelmän väärä käyttö:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Olemme nyt luoneet kaksi kopiota samasta vector: stä, mikä johtaa kaksoisvapaaseen when️, kun molemmat putoavat!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // TURVALLISUUS: soittajan on taattava, että `self` alustetaan.
        // Lukeminen `self.as_ptr()`: stä on turvallista, koska `self` tulisi alustaa.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Pudottaa sisältämän arvon paikalleen.
    ///
    /// Jos sinulla on `MaybeUninit`: n omistusoikeus, voit käyttää sen sijaan [`assume_init`]: ää.
    ///
    /// # Safety
    ///
    /// Soittajan on taattava, että `MaybeUninit<T>` on todella alustetussa tilassa.Tämän kutsuminen, kun sisältöä ei ole vielä täysin alustettu, aiheuttaa määrittelemätöntä käyttäytymistä.
    ///
    /// Tämän lisäksi kaikkien muiden tyypin `T` invariantien on täytyttävä, koska `T`: n (tai sen jäsenten) `Drop`-toteutus voi luottaa tähän.
    /// Esimerkiksi "1"-alustettua [`Vec<T>`]: ää pidetään alustettuna (nykyisen toteutuksen mukaan; tämä ei ole vakaa takuu), koska ainoa vaatimus, jonka kääntäjä tietää siitä, on, että datan osoittimen on oltava nolla.
    ///
    /// Tällaisen `Vec<T>`: n pudottaminen aiheuttaa kuitenkin määrittelemätöntä käyttäytymistä.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // TURVALLISUUS: soittajan on taattava, että `self` alustetaan ja
        // tyydyttää kaikki `T`: n invariants.
        // Arvon pudottaminen paikalleen on tässä tapauksessa turvallista.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Hakee jaetun viitteen sisältämään arvoon.
    ///
    /// Tästä voi olla hyötyä, kun haluamme käyttää `MaybeUninit`: ää, joka on alustettu, mutta meillä ei ole `MaybeUninit`: n omistusta (estää `.assume_init()`): n käytön.
    ///
    /// # Safety
    ///
    /// Tämän soittaminen, kun sisältöä ei ole vielä täysin alustettu, aiheuttaa määrittelemätöntä käyttäytymistä: soittajan on taattava, että `MaybeUninit<T>` on todella alustetussa tilassa.
    ///
    ///
    /// # Examples
    ///
    /// ### Tämän menetelmän oikea käyttö:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Alusta `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Nyt kun `MaybeUninit<_>` tiedetään alustettavaksi, on hyvä luoda jaettu viite siihen:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // TURVALLISUUS: `x` on alustettu.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Tämän menetelmän väärät* käytöt:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Olemme luoneet viittauksen alustamattomaan vector-malliin!Tämä on määrittelemätöntä käyttäytymistä.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Alusta `MaybeUninit` `Cell::set`: llä:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Viittaus alustamattomaan `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // TURVALLISUUS: soittajan on taattava, että `self` alustetaan.
        // Tämä tarkoittaa myös sitä, että `self`: n on oltava `value`-muunnos.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Hakee muutettavan (unique)-viitteen sisältämään arvoon.
    ///
    /// Tästä voi olla hyötyä, kun haluamme käyttää `MaybeUninit`: ää, joka on alustettu, mutta meillä ei ole `MaybeUninit`: n omistusta (estää `.assume_init()`): n käytön.
    ///
    /// # Safety
    ///
    /// Tämän soittaminen, kun sisältöä ei ole vielä täysin alustettu, aiheuttaa määrittelemätöntä käyttäytymistä: soittajan on taattava, että `MaybeUninit<T>` on todella alustetussa tilassa.
    /// Esimerkiksi `.assume_init_mut()`: ää ei voida käyttää `MaybeUninit`: n alustamiseen.
    ///
    /// # Examples
    ///
    /// ### Tämän menetelmän oikea käyttö:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Alustaa *kaikki* tulopuskurin tavut.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Alusta `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Nyt tiedämme, että `buf` on alustettu, joten voimme `.assume_init()`: n.
    /// // `.assume_init()`: n käyttö voi kuitenkin laukaista 2048 tavun `memcpy`: n.
    /// // Voit väittää, että puskurimme on alustettu kopioimatta sitä, päivitämme `&mut MaybeUninit<[u8; 2048]>`: n `&mut [u8; 2048]`: ksi:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // TURVALLISUUS: `buf` on alustettu.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Nyt voimme käyttää `buf`: ää normaalina siivuna:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Tämän menetelmän väärät* käytöt:
    ///
    /// `.assume_init_mut()`: ää ei voi käyttää arvon alustamiseen:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Olemme luoneet (mutable)-viittauksen alustamattomaan `bool`: ään!
    ///     // Tämä on määrittelemätöntä käyttäytymistä.⚠️
    /// }
    /// ```
    ///
    /// Et esimerkiksi voi [`Read`]: ää alustamattomaan puskuriin:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) viittaus alustamattomaan muistiin!
    ///                             // Tämä on määrittelemätöntä käyttäytymistä.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Et voi myöskään käyttää suoraa kenttäkäyttöä asteittaiseen kenttäkohtaiseen alustukseen:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) viittaus alustamattomaan muistiin!
    ///                  // Tämä on määrittelemätöntä käyttäytymistä.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) viittaus alustamattomaan muistiin!
    ///                  // Tämä on määrittelemätöntä käyttäytymistä.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Luotamme tällä hetkellä siihen, että yllä olevat tiedot ovat virheellisiä, ts. Meillä on viittauksia alustamattomiin tietoihin (esim. `libcore/fmt/float.rs`: ssä).
    // Meidän on tehtävä lopullinen päätös säännöistä ennen vakauttamista.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // TURVALLISUUS: soittajan on taattava, että `self` alustetaan.
        // Tämä tarkoittaa myös sitä, että `self`: n on oltava `value`-muunnos.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Poimi arvot `MaybeUninit`-säilöryhmästä.
    ///
    /// # Safety
    ///
    /// Soittajan on taattava, että kaikki matriisin elementit ovat alustetussa tilassa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // TURVALLISUUS: Nyt turvallinen, kun kaikki elementit alustettiin
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Soittaja takaa, että kaikki matriisin elementit alustetaan
        // * `MaybeUninit<T>` ja T: llä on taattu sama ulkoasu
        // * Ehkä Unint ei pudota, joten kaksoisvapautuksia ei ole. Ja siten muuntaminen on turvallista
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Olettaen, että kaikki elementit on alustettu, hanki siivu niihin.
    ///
    /// # Safety
    ///
    /// Soittajan on taattava, että `MaybeUninit<T>`-elementit ovat todella alustetussa tilassa.
    ///
    /// Tämän kutsuminen, kun sisältöä ei ole vielä täysin alustettu, aiheuttaa määrittelemätöntä käyttäytymistä.
    ///
    /// Katso lisätietoja ja esimerkkejä [`assume_init_ref`]: stä.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // TURVALLISUUS: Viipaleen heittäminen `*const [T]`: ään on turvallista, koska soittaja takaa sen
        // `slice` on alustettu, ja ``EhkäUninit` 'taataan olevan sama asettelu kuin `T`.
        // Saatu osoitin on kelvollinen, koska se viittaa `slice`: n omistamaan muistiin, joka on viite ja siten taattu kelvolliseksi lukemisille.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Olettaen, että kaikki elementit on alustettu, hanki heille muutettava osa.
    ///
    /// # Safety
    ///
    /// Soittajan on taattava, että `MaybeUninit<T>`-elementit ovat todella alustetussa tilassa.
    ///
    /// Tämän kutsuminen, kun sisältöä ei ole vielä täysin alustettu, aiheuttaa määrittelemätöntä käyttäytymistä.
    ///
    /// Katso lisätietoja ja esimerkkejä [`assume_init_mut`]: stä.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // TURVALLISUUS: samanlainen kuin `slice_get_ref`: n turvaohjeet, mutta meillä on
        // muutettava viite, joka on taattu myös päteväksi kirjoituksille.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Hakee taulukon ensimmäisen elementin osoittimen.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Hakee muutettavan osoittimen taulukon ensimmäiseen elementtiin.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Kopioi elementit `src`: stä `this`: een palauttaen muutettavan viitteen `this`: n nyt alkusisällölle.
    ///
    /// Jos `T` ei toteuta `Copy`: tä, käytä [`write_slice_cloned`]: ää
    ///
    /// Tämä on samanlainen kuin [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Tämä toiminto tulee olemaan panic, jos kahdella viipaleella on eripituiset pisteet.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // TURVALLISUUS: Olemme juuri kopioineet kaikki len-elementit varakapasiteettiin
    /// // vanhojen src.len()-elementit ovat voimassa nyt.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // TURVALLISUUS: &[T] ja&[EhkäUninit<T>] on sama asettelu
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // TURVALLISUUS: Kelvolliset elementit on juuri kopioitu `this`: ään, joten se on alustettu
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Kloonaa elementit `src`: stä `this`: ään, palauttaen muutettavan viitteen `this`: n nyt aktivoituun sisältöön.
    /// Jo alkupäätyneitä elementtejä ei pudota.
    ///
    /// Jos `T` toteuttaa `Copy`: n, käytä [`write_slice`]: ää
    ///
    /// Tämä on samanlainen kuin [`slice::clone_from_slice`], mutta se ei pudota olemassa olevia elementtejä.
    ///
    /// # Panics
    ///
    /// Tämä toiminto tulee olemaan panic, jos kahdella osalla on eri pituudet tai jos `Clone` panics: n toteutus.
    ///
    /// Jos panic on olemassa, jo kloonatut elementit pudotetaan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // TURVALLISUUS: Olemme juuri kloonanneet kaikki len-elementit ylimääräiseen kapasiteettiin
    /// // vanhojen src.len()-elementit ovat voimassa nyt.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // toisin kuin copy_from_slice, tämä ei kutsu osiota clone_from_slice, koska `MaybeUninit<T: Clone>` ei toteuta kloonia.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // TURVALLISUUS: tämä raaka siivu sisältää vain alustettuja objekteja
                // sen vuoksi sen saa pudottaa.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Meidän on leikattava ne nimenomaisesti samalle pituudelle
        // rajatarkastuksen poistamiseksi, ja optimoija luo memcpy: n yksinkertaisissa tapauksissa (esimerkiksi T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // vartija tarvitaan b/c panic saattaa tapahtua kloonin aikana
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // TURVALLISUUS: Kelvolliset elementit on juuri kirjoitettu `this`: ään, joten se on alustettu
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}