use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Kääre, joka estää kääntäjää soittamasta automaattisesti T: n tuhoajaa.
/// Tämä kääre on 0-hinta.
///
/// `ManuallyDrop<T>` on samat ulkoasun optimoinnit kuin `T`.
/// Tämän seurauksena sillä ei *ole vaikutusta* oletuksiin, jotka kääntäjä tekee sisällöstä.
/// Esimerkiksi `ManuallyDrop<&mut T>`: n alustaminen [`mem::zeroed`]: llä on määrittelemätöntä toimintaa.
/// Jos haluat käsitellä alustamattomia tietoja, käytä sen sijaan [`MaybeUninit<T>`]-laitetta.
///
/// Huomaa, että `ManuallyDrop<T>`: n sisällä olevan arvon käyttäminen on turvallista.
/// Tämä tarkoittaa, että `ManuallyDrop<T>`: ää, jonka sisältö on pudonnut, ei saa paljastaa yleisen turvallisen sovellusliittymän kautta.
/// Vastaavasti `ManuallyDrop::drop` on vaarallinen.
///
/// # `ManuallyDrop` ja pudota järjestys.
///
/// Rust: llä on tarkat [drop order]-arvot.
/// Varmista, että kentät tai paikalliset pudotetaan tietyssä järjestyksessä, järjestämällä ilmoitukset uudelleen siten, että implisiittinen pudotusjärjestys on oikea.
///
/// `ManuallyDrop`: llä on mahdollista hallita pudotusjärjestystä, mutta tämä vaatii vaarallista koodia ja on vaikea tehdä oikein purkamisen aikana.
///
///
/// Esimerkiksi, jos haluat varmistaa, että tietty kenttä pudotetaan muiden jälkeen, tee siitä rakenneen viimeinen kenttä:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` pudotetaan `children`: n jälkeen.
///     // Rust takaa, että kentät pudotetaan ilmoituksen järjestyksessä.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Kääri arvo, jonka haluat pudottaa manuaalisesti.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Voit silti käyttää arvoa turvallisesti
    /// assert_eq!(*x, "Hello");
    /// // Mutta `Drop`: ää ei käytetä täällä
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Poimi arvo `ManuallyDrop`-säilöstä.
    ///
    /// Tämä mahdollistaa arvon pudottamisen uudelleen.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Tämä pudottaa `Box`: n.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Ottaa `ManuallyDrop<T>`-säiliön arvon pois.
    ///
    /// Tämä menetelmä on tarkoitettu ensisijaisesti arvojen siirtämiseen pudotuksessa.
    /// Sen sijaan, että laskisit arvon [`ManuallyDrop::drop`] manuaalisesti, voit käyttää tätä menetelmää arvon ottamiseksi ja haluamallasi tavalla.
    ///
    /// Aina kun mahdollista, on parempi käyttää [`into_inner`][`ManuallyDrop::into_inner`]: ää, mikä estää `ManuallyDrop<T>`: n sisällön kopioinnin.
    ///
    ///
    /// # Safety
    ///
    /// Tämä toiminto siirtää semanttisesti sisältämän arvon pois estämättä jatkokäyttöä, jättäen tämän säiliön tilan muuttumattomaksi.
    /// Sinun vastuullasi on varmistaa, että tätä `ManuallyDrop`: ää ei käytetä uudelleen.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // TURVALLISUUS: luemme viitteestä, joka on taattu
        // on voimassa lukemiseen.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Pudottaa sisältämän arvon manuaalisesti.Tämä vastaa tarkalleen [`ptr::drop_in_place`]: n kutsumista osoittimella sisältyvään arvoon.
    /// Sellaisena, ellei sisältyvä arvo ole pakattu rakenne, tuhoaja kutsutaan paikalleen liikuttamatta arvoa, ja siten sitä voidaan käyttää [pinned]-datan turvalliseen pudottamiseen.
    ///
    /// Jos sinulla on arvon omistaja, voit käyttää sen sijaan [`ManuallyDrop::into_inner`]: ää.
    ///
    /// # Safety
    ///
    /// Tämä toiminto suorittaa sisältämän arvon tuhoajan.
    /// Muita kuin itse destruktorin tekemiä muutoksia, muisti jätetään muuttumattomaksi, ja kääntäjän osalta on silti bittikuvio, joka on voimassa tyypille `T`.
    ///
    ///
    /// Tätä "zombie"-arvoa ei kuitenkaan saisi altistaa turvalliselle koodille, eikä tätä toimintoa tulisi kutsua useammin kuin kerran.
    /// Arvon käyttäminen sen pudottamisen jälkeen tai arvon pudottaminen useita kertoja voi aiheuttaa määrittelemättömän käyttäytymisen (riippuen siitä, mitä `drop` tekee).
    /// Tyyppijärjestelmä estää tämän yleensä, mutta `ManuallyDrop`: n käyttäjien on pidettävä nämä takuut voimassa ilman kääntäjän apua.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // TURVALLISUUS: pudotamme arvon, johon mutatoitava viite viittaa
        // jonka taataan olevan voimassa kirjoituksissa.
        // Soittajan on varmistettava, että `slot` ei pudota uudelleen.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}