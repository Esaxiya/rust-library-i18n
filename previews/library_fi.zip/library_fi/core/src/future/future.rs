#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// future edustaa asynkronista laskentaa.
///
/// future on arvo, jota ei ehkä ole vielä laskettu loppuun.
/// Tällainen "asynchronous value" mahdollistaa ketjun jatkamisen hyödyllisessä työssä odottaessaan arvon saatavuutta.
///
///
/// # `poll`-menetelmä
///
/// future: n ydinmenetelmä, `poll`,*yrittää* ratkaista future: n lopulliseksi arvoksi.
/// Tämä menetelmä ei estä, jos arvo ei ole valmis.
/// Sen sijaan nykyinen tehtävä on ajoitettu herättämään, kun on mahdollista edetä edelleen "kyselemällä" uudelleen.
/// `poll`-menetelmälle välitetty `context` voi tuottaa [`Waker`]: n, joka on kahva nykyisen tehtävän herättämiseen.
///
/// Kun käytät future: tä, et yleensä soita `poll`: lle, vaan `.await`: n arvo.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Valmistuttuaan tuotetun arvon tyyppi.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Yritä ratkaista future lopulliseksi arvoksi rekisteröimällä nykyinen tehtävä herätykseen, jos arvo ei ole vielä käytettävissä.
    ///
    /// # Palautusarvo
    ///
    /// Tämä toiminto palauttaa:
    ///
    /// - [`Poll::Pending`] jos future ei ole vielä valmis
    /// - [`Poll::Ready(val)`] tämän future: n tuloksella `val`, jos se on onnistunut.
    ///
    /// Kun future on valmis, asiakkaiden ei pitäisi `poll`: ää uudestaan.
    ///
    /// Kun future ei ole vielä valmis, `poll` palauttaa `Poll::Pending`: n ja tallentaa nykyisestä [`Context`]: stä kopioidun [`Waker`]-kloonin.
    /// Tämä [`Waker`] herätetään sitten, kun future voi edistyä.
    /// Esimerkiksi future, joka odottaa, että pistorasia tulee luettavaksi, soittaa `.clone()`: ään [`Waker`]: ssä ja tallentaa sen.
    /// Kun muualle saapuu signaali, joka ilmoittaa, että liitäntä on luettavissa, [`Waker::wake`] kutsutaan ja pistorasian future tehtävä herätetään.
    /// Kun tehtävä on herännyt, sen tulisi yrittää `poll` future: tä uudelleen, mikä voi tuottaa lopullisen arvon tai ei.
    ///
    /// Huomaa, että kun `poll`: lle soitetaan useita puheluja, vain viimeisimmälle puhelulle välitetyn [`Context`]: n [`Waker`]: n tulisi olla ajastettu vastaanottamaan herätys.
    ///
    /// # Ajon ominaisuudet
    ///
    /// Pelkästään Futures ovat *inerttejä*;heidät on *aktiivisesti*`kysyttävä` edistymisen saavuttamiseksi, mikä tarkoittaa, että joka kerta kun nykyinen tehtävä herätetään, sen tulisi aktiivisesti uudelleen` `kysellä '' odottavaa futures: tä kohtaan, josta se on edelleen kiinnostunut.
    ///
    /// `poll`-toimintoa ei kutsuta toistuvasti tiukassa silmukassa-sen sijaan se tulisi kutsua vain, kun future ilmoittaa olevansa valmis edistymään (soittamalla `wake()`).
    /// Jos olet perehtynyt Unix: n `poll(2)`-tai `select(2)`-syscallsiin, on syytä huomata, että futures yleensä *ei* kärsi samoista ongelmista kuin "all wakeups must poll all events";ne ovat enemmän kuin `epoll(4)`.
    ///
    /// `poll`: n toteutuksen tulisi pyrkiä palaamaan nopeasti, eikä sen pitäisi estää.Nopea palautus estää tarpeettoman tukkeutumisen ketjuihin tai tapahtumasilmukkoihin.
    /// Jos etukäteen tiedetään, että puhelu `poll`: lle voi viedä jonkin aikaa, työ on ladattava säiealueeseen (tai vastaavaan) sen varmistamiseksi, että `poll` voi palata nopeasti.
    ///
    /// # Panics
    ///
    /// Kun future on valmis (palautti `Ready`: n `poll`: ltä), sen `poll`-menetelmän kutsuminen uudelleen voi panic: n estää, ikuisesti tai aiheuttaa muita ongelmia;`Future` trait ei aseta vaatimuksia tällaisen puhelun vaikutuksille.
    /// Koska `poll`-menetelmää ei ole merkitty `unsafe`: ksi, sovelletaan Rust: n tavanomaisia sääntöjä: puhelut eivät saa koskaan aiheuttaa määrittelemätöntä käyttäytymistä (muistivirheitä, `unsafe`-toimintojen väärää käyttöä tai vastaavaa), riippumatta future-tilasta.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}