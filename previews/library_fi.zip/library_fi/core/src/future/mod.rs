#![stable(feature = "futures_api", since = "1.36.0")]

//! Asynkroniset arvot.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Tätä tyyppiä tarvitaan, koska:
///
/// a) Generaattorit eivät voi toteuttaa `for<'a, 'b> Generator<&'a mut Context<'b>>`: ää, joten meidän on siirrettävä raaka osoitin (katso <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Raaka osoittimet ja `NonNull` eivät ole `Send` tai `Sync`, joten se tekisi jokaisesta future non-Send/Sync: stä, emmekä halua sitä.
///
/// Se myös yksinkertaistaa `.await`: n HIR-laskua.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Kääri generaattori future: ään.
///
/// Tämä toiminto palauttaa `GenFuture`: n alapuolelle, mutta piilottaa sen `impl Trait`: ssä parempien virheilmoitusten saamiseksi (`impl Future` eikä `GenFuture<[closure.....]>`).
///
// Tämä on `const`, jotta vältetään ylimääräiset virheet, kun olemme palautuneet `const async fn`: stä
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Luotamme siihen tosiasiaan, että async/await futures on kiinteä, jotta voimme luoda itseviittaavia lainoja taustalla olevaan generaattoriin.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // TURVALLISUUS: Turvallinen, koska olemme !Unpin + !Drop, ja tämä on vain kenttäennuste.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Jatka generaattorin käyttöä muuttamalla `&mut Context`: stä `NonNull`-raakaosoitin.
            // `.await`-lasku heittää sen turvallisesti takaisin `&mut Context`-malliin.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // TURVALLISUUS: soittajan on taattava, että `cx.0` on kelvollinen osoitin
    // joka täyttää kaikki muutettavissa olevan viitteen vaatimukset.
    unsafe { &mut *cx.0.as_ptr().cast() }
}