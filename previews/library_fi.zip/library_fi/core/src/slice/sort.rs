//! Viipaleiden lajittelu
//!
//! Tämä moduuli sisältää lajittelualgoritmin, joka perustuu Orson Petersin mallia hylkäävään pikalajiin, joka on julkaistu osoitteessa <https://github.com/orlp/pdqsort>
//!
//!
//! Epävakaa lajittelu on yhteensopiva libcoren kanssa, koska se ei jaa muistia, toisin kuin vakaa lajittelutoteutuksemme.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Kun pudotetaan, kopiot `src`: stä `dest`: ään.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // TURVALLISUUS: Tämä on auttajaluokka.
        //          Katso sen käytöstä oikeellisuus.
        //          Nimittäin on oltava varma, että `src` ja `dst` eivät ole päällekkäisiä `ptr::copy_nonoverlapping`: n vaatimalla tavalla.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Siirtää ensimmäisen elementin oikealle, kunnes se kohtaa suuremman tai yhtä suuren osan.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // TURVALLISUUS: Alla olevat vaaralliset toiminnot sisältävät indeksoinnin ilman sidottua tarkastusta (`get_unchecked` ja `get_unchecked_mut`)
    // ja kopioimalla muistia (`ptr::copy_nonoverlapping`).
    //
    // a.Indeksointi:
    //  1. Tarkistimme taulukon koon arvoon>=2.
    //  2. Kaikki tekemämme indeksoinnit ovat aina enintään {0 <= index < len}: n välillä.
    //
    // b.Muistikopiointi
    //  1. Saamme viitteitä viitteisiin, jotka ovat taatusti päteviä.
    //  2. Ne eivät voi olla päällekkäisiä, koska saamme viitteitä leikkeen eroindekseihin.
    //     Nimittäin `i` ja `i-1`.
    //  3. Jos leike on kohdistettu oikein, elementit ovat kohdakkain.
    //     Soittajan vastuulla on varmistaa, että leike on kohdistettu oikein.
    //
    // Katso lisätietoja alla olevista kommenteista.
    unsafe {
        // Jos kaksi ensimmäistä elementtiä ovat epäkunnossa ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Lue ensimmäinen elementti pinolle varattuun muuttujaan.
            // Jos seuraava vertailutoiminto panics, `hole` putoaa ja kirjoittaa elementin automaattisesti osaan.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Siirrä "i": n elementti yksi paikka vasemmalle, siirtäen siten reikää oikealle.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` putoaa ja kopioi siten `tmp`: n jäljellä olevaan reikään `v`: ssä.
        }
    }
}

/// Siirtää viimeistä elementtiä vasemmalle, kunnes se törmää pienempään tai yhtä suureen elementtiin.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // TURVALLISUUS: Alla olevat vaaralliset toiminnot sisältävät indeksoinnin ilman sidottua tarkastusta (`get_unchecked` ja `get_unchecked_mut`)
    // ja kopioimalla muistia (`ptr::copy_nonoverlapping`).
    //
    // a.Indeksointi:
    //  1. Tarkistimme taulukon koon arvoon>=2.
    //  2. Kaikki tekemämme indeksoinnit ovat aina enintään `0 <= index < len-1`: n välillä.
    //
    // b.Muistikopiointi
    //  1. Saamme viitteitä viitteisiin, jotka ovat taatusti päteviä.
    //  2. Ne eivät voi olla päällekkäisiä, koska saamme viitteitä leikkeen eroindekseihin.
    //     Nimittäin `i` ja `i+1`.
    //  3. Jos leike on kohdistettu oikein, elementit ovat kohdakkain.
    //     Soittajan vastuulla on varmistaa, että leike on kohdistettu oikein.
    //
    // Katso lisätietoja alla olevista kommenteista.
    unsafe {
        // Jos kaksi viimeistä elementtiä ovat epäkunnossa ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Lue viimeinen elementti pinolle varattuun muuttujaan.
            // Jos seuraava vertailutoiminto panics, `hole` putoaa ja kirjoittaa elementin automaattisesti osaan.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Siirrä "i"-elementti yksi paikka oikealle, siirtäen siten reikää vasemmalle.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` putoaa ja kopioi siten `tmp`: n jäljellä olevaan reikään `v`: ssä.
        }
    }
}

/// Lajittelee osion osittain siirtämällä useita epäkunnossa olevia elementtejä ympäri.
///
/// Palauttaa `true`, jos leike on lajiteltu lopussa.Tämä toiminto on *O*(*n*) pahimmassa tapauksessa.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Suurin sallittu vierekkäisten out-of-order-parien määrä, joka siirtyy.
    const MAX_STEPS: usize = 5;
    // Jos viipale on tätä lyhyempi, älä siirrä mitään elementtejä.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // TURVALLISUUS: Teimme jo nimenomaisesti sidotun tarkistuksen `i < len`: llä.
        // Kaikki seuraavat indeksointimme ovat vain alueella `0 <= index < len`
        unsafe {
            // Etsi seuraava pari vierekkäisiä sopimattomia elementtejä.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Olemmeko valmiita?
        if i == len {
            return true;
        }

        // Älä siirrä elementtejä lyhyillä matriiseilla, mikä maksaa suorituskykyä.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Vaihda löydetty elementtipari.Tämä asettaa ne oikeaan järjestykseen.
        v.swap(i - 1, i);

        // Siirrä pienempi elementti vasemmalle.
        shift_tail(&mut v[..i], is_less);
        // Siirrä suurempi elementti oikealle.
        shift_head(&mut v[i..], is_less);
    }

    // Ei onnistunut lajittelemaan leikettä rajoitetussa määrässä vaiheita.
    false
}

/// Lajittelee leikkeen käyttämällä lisäyslajittelua, joka on *O*(*n*^ 2) pahimmassa tapauksessa.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Lajittelee `v`: n heapsortilla, mikä takaa *O*(*n*\*log(* n*)) pahimmassa tapauksessa.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Tämä binäärikasa kunnioittaa muuttumattomaa `parent >= child`-mallia.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // `node`: n lapset:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Valitse isompi lapsi.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Lopeta, jos invariantti pitää `node`: ssä.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Vaihda `node` isomman lapsen kanssa, siirry yksi askel alaspäin ja jatka seulomista.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Rakenna kasa lineaarisessa ajassa.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pop maksimaaliset elementit kasasta.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Osiot `v` pienemmiksi elementeiksi kuin `pivot`, ja sen jälkeen elementit, jotka ovat suurempia tai yhtä suuria kuin `pivot`.
///
///
/// Palauttaa elementtien lukumäärän, joka on pienempi kuin `pivot`.
///
/// Osiointi suoritetaan lohkokohtaisesti haarautumisoperaatioiden kustannusten minimoimiseksi.
/// Tämä ajatus on esitetty [BlockQuicksort][pdf]-paperissa.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Elementtien lukumäärä tyypillisessä lohkossa.
    const BLOCK: usize = 128;

    // Osiointialgoritmi toistaa seuraavat vaiheet loppuun asti:
    //
    // 1. Jäljitä lohko vasemmalta puolelta tunnistaaksesi elementit, jotka ovat suurempia tai yhtä suuria kuin kääntö.
    // 2. Jäljitä lohko oikealta puolelta tunnistaaksesi saranaa pienemmät elementit.
    // 3. Vaihda tunnistetut elementit vasemman ja oikean puolen välillä.
    //
    // Säilytämme seuraavat muuttujat elementtilohkolle:
    //
    // 1. `block` - Lohkon elementtien lukumäärä.
    // 2. `start` - Aloita osoitin `offsets`-ryhmään.
    // 3. `end` - Päätösosio `offsets`-ryhmään.
    // 4. `offsetit, Lohkon järjestyksessä olevien elementtien indeksit.

    // Nykyinen lohko vasemmalla puolella (`l`: stä `l.add(block_l)`): ään.
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Nykyinen lohko oikealla puolella (`r.sub(block_r)` to `r`): stä).
    // TURVALLISUUS: .add(): n dokumentaatiossa mainitaan erityisesti, että `vec.as_ptr().add(vec.len())` on aina turvallinen
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Kun saamme VLA: t, yritä luoda pikemminkin yksi taulukko, jonka pituus on `min(v.len(), 2 * BLOCK)
    // kuin kaksi kiinteäkokoista `BLOCK`-pituista ryhmää.VLA: t voivat olla välimuistia tehokkaampia.

    // Palauttaa osoittimien `l` (inclusive) ja `r` (exclusive) välisen elementtien lukumäärän.
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Olemme suorittaneet osioinnin lohko kerrallaan, kun `l` ja `r` lähestyvät hyvin.
        // Sitten teemme korjaustöitä jakamaan loput elementit väliin.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Jäljellä olevien elementtien määrä (ei vieläkään verrattu pivotiin).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Säädä lohkokokoja niin, että vasen ja oikea lohko eivät mene päällekkäin, mutta asettuvat täydellisesti koko jäljellä olevan aukon kattamiseksi.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Seuraa `block_l`-elementtejä vasemmalta puolelta.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // TURVALLISUUS: Alla olevat vaarattomat toiminnot sisältävät `offset`: n käytön.
                //         Funktion edellyttämien ehtojen mukaisesti täytämme ne, koska:
                //         1. `offsets_l` on pinolle varattu ja sitä pidetään siten erillisenä allokoituna objektina.
                //         2. Toiminto `is_less` palauttaa `bool`: n.
                //            `bool`: n suoratoisto ei koskaan ylitä `isize`: ää.
                //         3. Olemme takaaneet, että `block_l` on `<= BLOCK`.
                //            Plus, `end_l` asetettiin alun perin `offsets_`: n aloitusosoittimeen, joka ilmoitettiin pinossa.
                //            Siksi tiedämme, että jopa pahimmassa tapauksessa (kaikki `is_less`: n kutsut palauttavat epätosi) olemme vain yhden tavun ohi.
                //        Toinen vaarallinen toimenpide on `elem`: n poikkeama.
                //        `elem` oli kuitenkin alun perin aloitusosoite osalle, joka on aina voimassa.
                unsafe {
                    // Haaraton vertailu.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Seuraa `block_r`-elementtejä oikealta puolelta.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // TURVALLISUUS: Alla olevat vaarattomat toiminnot sisältävät `offset`: n käytön.
                //         Funktion edellyttämien ehtojen mukaisesti täytämme ne, koska:
                //         1. `offsets_r` on pinolle varattu ja sitä pidetään siten erillisenä allokoituna objektina.
                //         2. Toiminto `is_less` palauttaa `bool`: n.
                //            `bool`: n suoratoisto ei koskaan ylitä `isize`: ää.
                //         3. Olemme takaaneet, että `block_r` on `<= BLOCK`.
                //            Plus, `end_r` asetettiin alun perin `offsets_`: n aloitusosoittimeen, joka ilmoitettiin pinossa.
                //            Siksi tiedämme, että jopa pahimmassa tapauksessa (kaikki `is_less`: n kutsut palauttavat tosi), me ylitämme vain yhden tavun.
                //        Toinen vaarallinen toimenpide on `elem`: n poikkeama.
                //        Kuitenkin `elem` oli alun perin `1 *sizeof(T)` ohi loppu, ja vähennämme sitä `1* sizeof(T)`: llä ennen pääsyä siihen.
                //        Lisäksi `block_r`: n väitettiin olevan pienempi kuin `BLOCK` ja `elem` osoittaa siten korkeintaan viipaleen alkuun.
                unsafe {
                    // Haaraton vertailu.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Vasemman ja oikean puolen välillä vaihdettavien epäkunnossa olevien elementtien määrä.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Sen sijaan, että vaihdettaisiin yksi pari kerrallaan, on tehokkaampaa suorittaa syklinen permutaatio.
            // Tämä ei tarkalleen vastaa vaihtamista, mutta tuottaa samanlaisen tuloksen käyttämällä vähemmän muistitoimintoja.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Vasemman lohkon kaikki järjestyksessä olevat elementit siirrettiin.Siirry seuraavaan lohkoon.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Kaikki oikean lohkon järjestyksessä olevat elementit siirrettiin.Siirry edelliseen lohkoon.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Nyt jäljellä on vain yksi lohko (joko vasen tai oikea), jossa on järjestyksessä olevia elementtejä, jotka on siirrettävä.
    // Tällaiset jäljellä olevat elementit voidaan yksinkertaisesti siirtää loppuun lohkon sisällä.
    //

    if start_l < end_l {
        // Vasen lohko pysyy.
        // Siirrä jäljellä olevat epäkunnossa olevat elementit äärioikeistoon.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Oikea lohko säilyy.
        // Siirrä jäljellä olevat epäkunnossa olevat elementit vasemman reunaan.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Ei muuta tekemistä, olemme valmiit.
        width(v.as_mut_ptr(), l)
    }
}

/// Osiot `v` pienemmiksi elementeiksi kuin `v[pivot]`, ja sen jälkeen elementit, jotka ovat suurempia tai yhtä suuria kuin `v[pivot]`.
///
///
/// Palauttaa joukon:
///
/// 1. Elementtien lukumäärä pienempi kuin `v[pivot]`.
/// 2. Totta, jos `v` oli jo osioitu.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Aseta kääntö leikkeen alkuun.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Lue pivot pinoon varattuun muuttujaan tehokkuuden lisäämiseksi.
        // Jos seuraava vertailutoiminto panics, pivot kirjoitetaan automaattisesti takaisin osaan.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Etsi ensimmäinen pari järjestyksessä olevia elementtejä.
        let mut l = 0;
        let mut r = v.len();

        // TURVALLISUUS: Alla olevaan vaarattomuuteen liittyy taulukon indeksointi.
        // Ensimmäiselle: Teemme jo rajat tarkistamalla täällä `l < r`: llä.
        // Toinen: Meillä on alun perin `l == 0` ja `r == v.len()`, ja tarkasimme `l < r`: n jokaisessa indeksointitoiminnossa.
        //                     Täältä tiedämme, että `r`: n on oltava vähintään `r == l`, jonka osoitettiin olevan kelvollinen ensimmäisestä.
        unsafe {
            // Etsi ensimmäinen elementti, joka on suurempi tai yhtä suuri kuin pivot.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Etsi viimeinen elementti, joka on pienempi kuin pivot.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` menee ulkopuolelle ja kirjoittaa pivotin (joka on pinolle varattu muuttuja) takaisin osaan, missä se alun perin oli.
        // Tämä vaihe on kriittinen turvallisuuden varmistamiseksi!
        //
    };

    // Aseta kääntö kahden osion väliin.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Jakaa `v` elementeiksi, joka on yhtä suuri kuin `v[pivot]`, ja sen jälkeen elementit, jotka ovat suurempia kuin `v[pivot]`.
///
/// Palauttaa pivot-elementtien määrän.
/// Oletetaan, että `v` ei sisällä pivotia pienempiä elementtejä.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Aseta kääntö leikkeen alkuun.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Lue pivot pinoon varattuun muuttujaan tehokkuuden lisäämiseksi.
    // Jos seuraava vertailutoiminto panics, pivot kirjoitetaan automaattisesti takaisin osaan.
    // TURVALLISUUS: Osoitin on voimassa, koska se saadaan viitteestä viipaleeseen.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Osoita viipale.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // TURVALLISUUS: Alla olevaan vaarattomuuteen liittyy taulukon indeksointi.
        // Ensimmäiselle: Teemme jo rajat tarkistamalla täällä `l < r`: llä.
        // Toinen: Meillä on alun perin `l == 0` ja `r == v.len()`, ja tarkasimme `l < r`: n jokaisessa indeksointitoiminnossa.
        //                     Täältä tiedämme, että `r`: n on oltava vähintään `r == l`, jonka osoitettiin olevan kelvollinen ensimmäisestä.
        unsafe {
            // Etsi ensimmäinen elementti, joka on suurempi kuin kääntö.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Etsi viimeinen elementti, joka on yhtä suuri kuin pivot.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Olemmeko valmiita?
            if l >= r {
                break;
            }

            // Vaihda löydetty pari järjestyksessä olevia elementtejä.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Löysimme `l`-elementit, jotka vastaavat pivotia.Lisää 1 tilille itse kääntö.
    l + 1

    // `_pivot_guard` menee ulkopuolelle ja kirjoittaa pivotin (joka on pinolle varattu muuttuja) takaisin osaan, missä se alun perin oli.
    // Tämä vaihe on kriittinen turvallisuuden varmistamiseksi!
}

/// Hajottaa joitain elementtejä yrittäessään rikkoa malleja, jotka saattavat aiheuttaa epätasapainoisia osioita pikalajikkeessa.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // George Marsaglian näennäissatunnaislukugeneraattori "Xorshift RNGs"-paperista.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Ota satunnaisluvut modulo tämä luku.
        // Luku sopii `usize`: ään, koska `len` ei ole suurempi kuin `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Jotkut kääntöehdokkaat ovat tämän hakemiston läheisyydessä.Satunnaistetaan heidät.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Luo satunnaisluku modulo `len`.
            // Kalliiden toimintojen välttämiseksi otamme sen ensin moduloiksi kahden tehon ja pienennämme sitten `len`: llä, kunnes se sopii `[0, len - 1]`-alueelle.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` on taattu alle `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Valitsee pivotin `v`: ssä ja palauttaa indeksin ja `true`: n, jos osa on todennäköisesti jo lajiteltu.
///
/// `v`: n elementit voidaan järjestää uudelleen prosessin aikana.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Pienin pituus mediaanimediaani-menetelmän valitsemiseksi.
    // Lyhyemmissä viipaleissa käytetään yksinkertaista mediaani kolmesta-menetelmää.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Tällä toiminnolla suoritettavien vaihtojen enimmäismäärä.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Kolme indeksiä, joiden lähellä aiomme valita pivotin.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Laskee vaihtojen määrän, jonka aiomme suorittaa indeksien lajittelun aikana.
    let mut swaps = 0;

    if len >= 8 {
        // Vaihtaa indeksit niin, että `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Vaihtaa indeksit niin, että `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Hakee `v[a - 1], v[a], v[a + 1]`: n mediaanin ja tallentaa indeksin `a`: ään.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Löydä mediaaneja alueilta `a`, `b` ja `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Etsi mediaani joukosta `a`, `b` ja `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Suorituskyky oli suurin.
        // Mahdollisuudet ovat, että viipale on laskeva tai enimmäkseen laskeutuva, joten peruutus auttaa todennäköisesti lajittelemaan sen nopeammin.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Lajittelee `v` rekursiivisesti.
///
/// Jos viipaleella oli edeltäjä alkuperäisessä taulukossa, se määritetään `pred`: ksi.
///
/// `limit` on sallittujen epätasapainoisten osioiden määrä ennen siirtymistä `heapsort`: ään.
/// Jos arvo on nolla, tämä toiminto vaihtuu välittömästi heapsortiksi.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Tämän pituiset viipaleet lajitellaan lisäyslajittelun avulla.
    const MAX_INSERTION: usize = 20;

    // Totta, jos viimeinen osiointi oli kohtuullisen tasapainossa.
    let mut was_balanced = true;
    // Totta, jos viimeinen osiointi ei sekoittanut elementtejä (osa oli jo osioitu).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Hyvin lyhyet viipaleet lajitellaan käyttämällä lisäyslajittelua.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Jos tehtiin liian monta huonoa pivot-valintaa, palaa yksinkertaisesti takaisin heapsortiin taatakseen `O(n * log(n))`: n pahimman tapauksen.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Jos viimeinen osiointi oli epätasapainossa, yritä rikkoa leikkeen kuviot sekoittamalla joitain elementtejä ympärille.
        // Toivottavasti valitsemme tällä kertaa paremman kääntöpisteen.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Valitse pivot ja yritä arvata, onko osa jo lajiteltu.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Jos viimeinen osiointi oli tasapainoinen eikä se sekoittanut elementtejä, ja jos pivot-valinta ennustaa, leike on todennäköisesti jo lajiteltu ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Yritä tunnistaa useita järjestyksessä olevia elementtejä ja siirtää ne oikeaan asentoon.
            // Jos viipale päätyy lajitella kokonaan, olemme valmiit.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Jos valittu pivot on yhtä suuri kuin edeltäjänsä, se on viipaleen pienin elementti.
        // Jaa viipale elementteihin, jotka ovat yhtä suuret ja suuremmat kuin pivot.
        // Tämä tapaus osuu yleensä, kun siivu sisältää useita päällekkäisiä elementtejä.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Jatka kääntöelementtien lajittelua.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Osioi leike.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Jaa leike osiin `left`, `pivot` ja `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Palaa takaisin vain lyhyemmälle puolelle rekursiivisten puheluiden kokonaismäärän minimoimiseksi ja pinotilan säästämiseksi.
        // Jatka sitten vain pidemmällä puolella (tämä muistuttaa hännän rekursiota).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Lajittelee `v` käyttämällä mallia hylkäävää pikalajiketta, joka on *O*(*n*\*log(* n*)) pahimmassa tapauksessa.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Lajittelulla ei ole merkityksellistä käyttäytymistä nollakokoisissa tyypeissä.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Rajoita epätasapainoisten osioiden määrä `floor(log2(len)) + 1`: ään.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Tämän pituisille viipaleille on todennäköisesti nopeampi lajitella ne.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Valitse pivot
        let (pivot, _) = choose_pivot(v, is_less);

        // Jos valittu pivot on yhtä suuri kuin edeltäjänsä, se on viipaleen pienin elementti.
        // Jaa viipale elementteihin, jotka ovat yhtä suuret ja suuremmat kuin pivot.
        // Tämä tapaus osuu yleensä, kun siivu sisältää useita päällekkäisiä elementtejä.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Jos olemme ylittäneet indeksimme, olemme hyviä.
                if mid > index {
                    return;
                }

                // Muussa tapauksessa jatka elementtien lajittelua kuin pivot.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Jaa leike osiin `left`, `pivot` ja `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Jos keskiarvo==indeksi, niin olemme valmiit, koska partition() takasi, että kaikki puolivälin jälkeen olevat elementit ovat suurempia tai yhtä suuria kuin puolivälissä.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Lajittelulla ei ole merkityksellistä käyttäytymistä nollakokoisissa tyypeissä.Älä tee mitään.
    } else if index == v.len() - 1 {
        // Etsi max-elementti ja aseta se matriisin viimeiseen kohtaan.
        // Voimme käyttää `unwrap()`: ää täällä, koska tiedämme, että v ei saa olla tyhjä.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Etsi min-elementti ja aseta se matriisin ensimmäiseen kohtaan.
        // Voimme käyttää `unwrap()`: ää täällä, koska tiedämme, että v ei saa olla tyhjä.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}