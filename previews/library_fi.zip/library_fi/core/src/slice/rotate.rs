// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Kierrä aluetta `[mid-left, mid+right)` siten, että `mid`: n elementistä tulee ensimmäinen elementti.Vastaavasti kääntää alueen `left` elementit vasemmalle tai `right` elementit oikealle.
///
/// # Safety
///
/// Määritetyn alueen on oltava voimassa lukemiseen ja kirjoittamiseen.
///
/// # Algorithm
///
/// Algoritmia 1 käytetään pienille `left + right`-arvoille tai suurille `T`-arvoille.
/// Elementit siirretään lopullisiin paikkoihinsa yksi kerrallaan alkaen `mid - left`: stä ja etenemällä `right`-askeleilla modulo `left + right`, siten että tarvitaan vain yksi väliaikainen.
/// Lopulta palaamme takaisin `mid - left`: ään.
/// Jos `gcd(left + right, right)` ei ole 1, yllä olevat vaiheet ohittivat elementit.
/// Esimerkiksi:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Onneksi ohitettujen elementtien määrä viimeisteltyjen elementtien välillä on aina yhtä suuri, joten voimme vain kompensoida lähtöasemamme ja tehdä enemmän kierroksia (kierrosten kokonaismäärä on `gcd(left + right, right)` value).
///
/// Lopputulos on, että kaikki elementit viimeistellään kerran ja vain kerran.
///
/// Algoritmia 2 käytetään, jos `left + right` on suuri, mutta `min(left, right)` on tarpeeksi pieni mahtuakseen pinopuskuriin.
/// `min(left, right)`-elementit kopioidaan puskurille, `memmove` levitetään muille ja puskurissa olevat siirretään takaisin reikään, joka on niiden alkuperäisen vastakkaisella puolella.
///
/// Vektoroitavat algoritmit ylittävät edellä mainitut, kun `left + right`: stä tulee riittävän suuri.
/// Algoritmi 1 voidaan vektoroida pilkkomalla ja suorittamalla useita kierroksia kerralla, mutta kierroksia on keskimäärin liian vähän, kunnes `left + right` on valtava, ja pahin yksittäisen kierroksen tapaus on aina olemassa.
/// Sen sijaan algoritmi 3 käyttää `min(left, right)`-elementtien toistuvaa vaihtamista, kunnes jäljellä on pienempi kierto-ongelma.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// kun `left < right`, vaihto tapahtuu sen sijaan vasemmalta.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. alla olevat algoritmit voivat epäonnistua, jos näitä tapauksia ei tarkisteta
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algoritmi 1: n mikromerkit osoittavat, että satunnaisten siirtymien keskimääräinen suorituskyky on parempi aina noin `left + right == 32`: ään saakka, mutta pahimmassa tapauksessa suorituskyky rikkoutuu noin 16: een.
            // 24 valittiin keskitie.
            // Jos `T`: n koko on suurempi kuin 4 "usize", tämä algoritmi ylittää myös muut algoritmit.
            //
            //
            let x = unsafe { mid.sub(left) };
            // ensimmäisen kierroksen alku
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` löytyy etukäteen laskemalla `gcd(left + right, right)`, mutta on nopeampi tehdä yksi silmukka, joka laskee gcd: n sivuvaikutuksena, ja sitten tehdä loput palasesta
            //
            //
            let mut gcd = right;
            // vertailuarvot paljastavat, että on nopeampaa vaihtaa väliaikaiset tiedot koko ajan sen sijaan, että luisit yhden väliaikaisen kerran, kopioitaisiin taaksepäin ja kirjoitettaisiin sitten väliaikainen loppuun.
            // Tämä johtuu mahdollisesti siitä, että väliaikaisten vaihtaminen tai korvaaminen käyttää silmukassa vain yhtä muistiosoitetta sen sijaan, että tarvitsisi hallita kahta.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // sen sijaan, että korottaisimme `i`: ää ja tarkistaisimme sitten, onko se rajojen ulkopuolella, tarkistamme, meneekö `i` seuraavalla lisäyksellä rajojen ulkopuolelle.
                // Tämä estää osoittimien tai `usize`: n käärimisen.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // ensimmäisen kierroksen loppu
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // tämän ehdollisen on oltava täällä, jos `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // viimeistele palas lisää kierroksilla
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` ei ole nollakokoinen tyyppi, joten on hyvä jakaa sen koon mukaan.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algoritmi 2 `[T; 0]`: n on varmistettava, että tämä on kohdistettu asianmukaisesti T: lle
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algoritmi 3 Vaihtoon on olemassa vaihtoehtoinen tapa, joka sisältää sen, että löydetään, missä tämän algoritmin viimeinen vaihto olisi, ja vaihdetaan tällä viimeisellä palalla vierekkäisten palojen vaihtamisen sijaan, kuten tämä algoritmi tekee, mutta tämä tapa on silti nopeampi.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algoritmi 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}