//! Ilmaiset toiminnot `&[T]`: n ja `&mut [T]`: n luomiseen.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Muodostaa siivun osoittimesta ja pituudesta.
///
/// `len`-argumentti on **elementtien** määrä, ei tavujen lukumäärä.
///
/// # Safety
///
/// Käyttäytymistä ei ole määritelty, jos jotakin seuraavista ehdoista rikotaan:
///
/// * `data` on oltava [valid] lukemalla `len * mem::size_of::<T>()` monta tavua, ja sen on oltava oikein kohdistettu.Tämä tarkoittaa erityisesti:
///
///     * Tämän leikkeen koko muistialue on sisällytettävä yhteen varattuun objektiin!
///       Viipaleet eivät voi koskaan ulottua useiden allokoitujen objektien yli.Katso esimerkki [below](#incorrect-usage) virheellisesti ottamatta tätä huomioon.
///     * `data` ei saa olla nolla ja tasattu myös nollapituisille viipaleille.
///     Yksi syy tähän on, että enum-asettelun optimoinnit voivat luottaa siihen, että viitteet (mukaan lukien minkä tahansa pituiset viipaleet) on kohdistettu ja ei-nolla erottaakseen ne muista tiedoista.
///     Voit hankkia osoittimen, jota voidaan käyttää `data`: nä nollapituisille viipaleille käyttämällä [`NonNull::dangling()`]: ää.
///
/// * `data` on osoitettava `len`: n peräkkäisiin oikein alustettuihin tyypin `T` arvoihin.
///
/// * Palautetun osion viittaamaa muistia ei saa mutatoida koko käyttöiän ajan `'a`, paitsi `UnsafeCell`: n sisällä.
///
/// * Viipaleen koko `len * mem::size_of::<T>()` ei saa olla suurempi kuin `isize::MAX`.
///   Katso [`pointer::offset`]: n turvallisuusohjeet.
///
/// # Caveat
///
/// Palautetun viipalon käyttöikä päätellään sen käytöstä.
/// Tahattoman väärinkäytön estämiseksi on suositeltavaa sitoa käyttöikä siihen, mikä lähteen käyttöikä on turvallinen kontekstissa, esimerkiksi tarjoamalla auttajatoiminto, joka vie isäntän arvon eliniän, tai nimenomaisella merkinnällä.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // ilmentää siivu yhdelle elementille
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Väärä käyttö
///
/// Seuraava `join_slices`-toiminto on **epäherkkä** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Yllä oleva väite varmistaa, että `fst` ja `snd` ovat vierekkäisiä, mutta ne saattavat silti olla _different allocated objects_: ssä, jolloin tämän osion luominen on määrittelemätöntä käyttäytymistä.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` ja `b` ovat erilaisia allokoituja objekteja ...
///     let a = 42;
///     let b = 27;
///     // ... joka voidaan kuitenkin sijoittaa vierekkäin muistiin: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // TURVALLISUUS: soittajan on noudatettava `from_raw_parts`: n turvasopimusta.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Suorittaa saman toiminnallisuuden kuin [`from_raw_parts`], paitsi että muutettava osa palautetaan.
///
/// # Safety
///
/// Käyttäytymistä ei ole määritelty, jos jotakin seuraavista ehdoista rikotaan:
///
/// * `data` on oltava [valid] sekä luku-että kirjoitus `len * mem::size_of::<T>()`: lle monta tavua, ja sen on oltava kohdistettu oikein.Tämä tarkoittaa erityisesti:
///
///     * Tämän leikkeen koko muistialue on sisällytettävä yhteen varattuun objektiin!
///       Viipaleet eivät voi koskaan ulottua useiden allokoitujen objektien yli.
///     * `data` ei saa olla nolla ja tasattu myös nollapituisille viipaleille.
///     Yksi syy tähän on, että enum-asettelun optimoinnit voivat luottaa siihen, että viitteet (mukaan lukien minkä tahansa pituiset viipaleet) on kohdistettu ja ei-nolla erottaakseen ne muista tiedoista.
///
///     Voit hankkia osoittimen, jota voidaan käyttää `data`: nä nollapituisille viipaleille käyttämällä [`NonNull::dangling()`]: ää.
///
/// * `data` on osoitettava `len`: n peräkkäisiin oikein alustettuihin tyypin `T` arvoihin.
///
/// * Palautetun osion viittaamaan muistiin ei saa käyttää mitään muuta osoitinta (ei johdettu palautusarvosta) `'a`-käyttöiän ajan.
///   Sekä luku-että kirjoitusoikeudet ovat kiellettyjä.
///
/// * Viipaleen koko `len * mem::size_of::<T>()` ei saa olla suurempi kuin `isize::MAX`.
///   Katso [`pointer::offset`]: n turvallisuusohjeet.
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // TURVALLISUUS: soittajan on noudatettava `from_raw_parts_mut`: n turvasopimusta.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Muuntaa viitteen T: ksi viipaksi, jonka pituus on 1 (kopioimatta).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Muuntaa viitteen T: ksi viipaksi, jonka pituus on 1 (kopioimatta).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}