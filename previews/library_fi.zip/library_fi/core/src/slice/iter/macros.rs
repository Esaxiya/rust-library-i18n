//! Viipaleen iteraattorien käyttämät makrot.

// Inlinining is_empty ja len tekee valtavan suorituskykyeron
macro_rules! is_empty {
    // Tapa, jolla koodataan ZST-iteraattorin pituus, toimii sekä ZST: lle että muulle kuin ZST: lle.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Päästäkseen eräistä rajatarkastuksista (katso `position`) laskemme pituuden hieman odottamattomalla tavalla.
// (Testattu mallilla "codegen/slice-position-bounds-check".)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // meitä käytetään joskus vaarallisessa tilassa

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Tämä _cannot_ käyttää `unchecked_sub`: ää, koska riippumme kääreestä edustamaan pitkien ZST-viipaleiden iteraattoreiden pituutta.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Tiedämme, että `start <= end`, joten se voi toimia paremmin kuin `offset_from`, jonka on käsiteltävä allekirjoitettuna.
            // Asettamalla sopivat liput tähän voimme kertoa LLVM: lle tämän, mikä auttaa sitä poistamaan rajatarkastukset.
            // TURVALLISUUS: Inveriantin tyypin mukaan `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Kertomalla LLVM: lle, että osoittimet ovat erillään tyypin koon tarkasta kerrannaisesta, se voi optimoida `len() == 0`: n aina `start == end`: ään `(end - start) < size`: n sijaan.
            //
            // TURVALLISUUS: Tyypin invariantin mukaan osoittimet kohdistetaan siten, että
            //         niiden välisen etäisyyden on oltava kerrottava pointeen koosta
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// `Iter`-ja `IterMut`-iteraattoreiden jaettu määritelmä
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Palauttaa ensimmäisen elementin ja siirtää iteraattorin alkua eteenpäin yhdellä.
        // Parantaa huomattavasti suorituskykyä verrattuna sisäänrakennettuun toimintoon.
        // Iteraattori ei saa olla tyhjä.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Palauttaa viimeisen elementin ja siirtää iteraattorin päätä taaksepäin yhdellä.
        // Parantaa huomattavasti suorituskykyä verrattuna sisäänrakennettuun toimintoon.
        // Iteraattori ei saa olla tyhjä.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Kutistaa iteraattorin, kun T on ZST, siirtämällä iteraattorin päätä taaksepäin `n`: llä.
        // `n` ei saa ylittää arvoa `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Aputoiminto leikkeen luomiseksi iteraattorista.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // TURVALLISUUS: iteraattori luotiin osasta osoittimella
                // `self.ptr` ja pituus `len!(self)`.
                // Tämä takaa, että kaikki `from_raw_parts`: n edellytykset täyttyvät.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Aputoiminto iteraattorin alun siirtämiseksi eteenpäin `offset`-elementeillä palauttaen vanhan alun.
            //
            // Vaarallinen, koska siirtymä ei saa olla suurempi kuin `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // TURVALLISUUS: soittaja takaa, että `offset` ei ylitä arvoa `self.len()`,
                    // joten tämä uusi osoitin on `self`: n sisällä ja siten taattu olemaan nolla.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Aputoiminto iteraattorin pään siirtämiseksi taaksepäin `offset`-elementeillä palauttamalla uusi pää.
            //
            // Vaarallinen, koska siirtymä ei saa olla suurempi kuin `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // TURVALLISUUS: soittaja takaa, että `offset` ei ylitä arvoa `self.len()`,
                    // joka ei taatusti ylitä `isize`: ää.
                    // Tuloksena oleva osoitin on myös `slice`: n rajoissa, mikä täyttää muut `offset`: n vaatimukset.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // voitaisiin toteuttaa viipaleilla, mutta tällä vältetään rajatarkastukset

                // TURVALLISUUS: `assume`-puhelut ovat turvallisia, koska viipaleiden aloitusosoitin
                // ei saa olla nolla, ja muiden kuin ZST-osien päällä olevilla viipaleilla on oltava myös ei-nolla loppuosoitin.
                // Puhelu `next_unchecked!`: lle on turvallinen, koska tarkistamme ensin, onko iteraattori tyhjä.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Tämä iteraattori on nyt tyhjä.
                    if mem::size_of::<T>() == 0 {
                        // Meidän on tehtävä se tällä tavalla, koska `ptr` ei ehkä koskaan ole 0, mutta `end` voi olla (käärimisen vuoksi).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // TURVALLISUUS: loppu ei voi olla 0, jos T ei ole ZST, koska ptr ei ole 0 ja loppu>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // TURVALLISUUS: Olemme rajoilla.`post_inc_start` tekee oikein myös ZST-laitteille.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Ohitamme oletustoteutuksen, joka käyttää `try_fold`: ää, koska tämä yksinkertainen toteutus tuottaa vähemmän LLVM IR: ää ja on nopeampi kääntää.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Ohitamme oletustoteutuksen, joka käyttää `try_fold`: ää, koska tämä yksinkertainen toteutus tuottaa vähemmän LLVM IR: ää ja on nopeampi kääntää.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Ohitamme oletustoteutuksen, joka käyttää `try_fold`: ää, koska tämä yksinkertainen toteutus tuottaa vähemmän LLVM IR: ää ja on nopeampi kääntää.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Ohitamme oletustoteutuksen, joka käyttää `try_fold`: ää, koska tämä yksinkertainen toteutus tuottaa vähemmän LLVM IR: ää ja on nopeampi kääntää.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Ohitamme oletustoteutuksen, joka käyttää `try_fold`: ää, koska tämä yksinkertainen toteutus tuottaa vähemmän LLVM IR: ää ja on nopeampi kääntää.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Ohitamme oletustoteutuksen, joka käyttää `try_fold`: ää, koska tämä yksinkertainen toteutus tuottaa vähemmän LLVM IR: ää ja on nopeampi kääntää.
            // Lisäksi `assume` välttää rajatarkastuksen.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // TURVALLISUUS: loop-invariantti takaa meidän olevan rajoja:
                        // kun `i >= n`, `self.next()` palauttaa `None`: n ja silmukka katkeaa.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Ohitamme oletustoteutuksen, joka käyttää `try_fold`: ää, koska tämä yksinkertainen toteutus tuottaa vähemmän LLVM IR: ää ja on nopeampi kääntää.
            // Lisäksi `assume` välttää rajatarkastuksen.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // TURVALLISUUS: `i`: n on oltava pienempi kuin `n`, koska se alkaa `n`: stä
                        // ja vain vähenee.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // TURVALLISUUS: soittajan on taattava, että `i` on rajojen ulkopuolella
                // taustalla olevan siivun, joten `i` ei voi ylittää `isize`: ää, ja palautetut viitteet taataan viittaavan leikkeen osaan ja siten taatusti päteviksi.
                //
                // Huomaa myös, että soittaja takaa myös, että meille ei koskaan soiteta samalla indeksillä ja että mitään muita menetelmiä, jotka käyttävät tätä alisarjaa, ei käytetä, joten on kelvollista, että palautettu viite on muutettavissa
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // voitaisiin toteuttaa viipaleilla, mutta tällä vältetään rajatarkastukset

                // TURVALLISUUS: `assume`-puhelut ovat turvallisia, koska leikkeen aloitusosoittimen on oltava nolla,
                // ja viipaleilla, jotka eivät ole ZST: itä, on oltava myös ei-nolla loppuosoite.
                // Puhelu `next_back_unchecked!`: lle on turvallinen, koska tarkistamme ensin, onko iteraattori tyhjä.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Tämä iteraattori on nyt tyhjä.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // TURVALLISUUS: Olemme rajoilla.`pre_dec_end` tekee oikein myös ZST-laitteille.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}