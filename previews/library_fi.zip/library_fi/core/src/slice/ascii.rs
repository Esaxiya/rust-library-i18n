//! Toiminnot ASCII `[u8]`-laitteella.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Tarkistaa, ovatko kaikki tämän osion tavut ASCII-alueen sisällä.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Tarkistaa, että kaksi leikettä vastaavat ASCII-kirjainkokoa.
    ///
    /// Sama kuin `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, mutta jakamatta ja kopioimatta väliaikaisia.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Muuntaa tämän osion ASCII-isojen kirjainten vastaavaksi paikalleen.
    ///
    /// ASCII-kirjaimet 'a'-'z' yhdistetään numeroihin 'A'-'Z', mutta muut kuin ASCII-kirjaimet eivät muutu.
    ///
    /// Jos haluat palauttaa uuden ylemmän tason arvon muuttamatta nykyistä arvoa, käytä [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Muuntaa tämän osion pieneksi kirjaimeksi vastaavaksi ASCII: ksi.
    ///
    /// ASCII-kirjaimet 'A'-'Z' yhdistetään numeroihin 'a'-'z', mutta muut kuin ASCII-kirjaimet eivät muutu.
    ///
    /// Jos haluat palauttaa uuden pienikokoisen arvon muuttamatta nykyistä arvoa, käytä [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Palauttaa arvon `true`, jos jokin tavu sanassa `v` on nonascii (>=128).
/// Snarfed `../str/mod.rs`: stä, joka tekee jotain samanlaista utf8-tarkistuksessa.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Optimoitu ASCII-testi, joka käyttää usize-at-a-time-toimintoja tavu-at-a-time-toimintojen sijaan (kun mahdollista).
///
/// Tässä käytettävä algoritmi on melko yksinkertainen.Jos `s` on liian lyhyt, tarkistamme vain jokaisen tavun ja teemme sen loppuun.Muuten:
///
/// - Lue ensimmäinen sana kohdistamattomalla kuormalla.
/// - Kohdista osoitin, lue seuraavat sanat loppuun asti kohdistetuilla kuormilla.
/// - Lue viimeinen `usize` `s`: stä kohdistamattomalla kuormalla.
///
/// Jos jokin näistä kuormista tuottaa jotain, jolle `contains_nonascii` (above) palauttaa arvon tosi, tiedämme vastauksen vääräksi.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Jos emme saisi mitään sana-kerrallaan-toteutuksesta, palaa takaisin skalaarisilmukkaan.
    //
    // Teemme tämän myös arkkitehtuureille, joissa `size_of::<usize>()` ei ole riittävä kohdistaminen `usize`: lle, koska se on outo edge-tapaus.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Luemme ensimmäisen sanan aina kohdistamattomana, mikä tarkoittaa, että `align_offset` on
    // 0, luisimme saman arvon uudelleen kohdistetulle lukemalle.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // TURVALLISUUS: Tarkistamme `len < USIZE_SIZE`: n yllä.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Tarkistimme tämän yllä epäsuorasti.
    // Huomaa, että `offset_to_aligned` on joko `align_offset` tai `USIZE_SIZE`, molemmat on nimenomaisesti tarkistettu yllä.
    //
    debug_assert!(offset_to_aligned <= len);

    // TURVALLISUUS: word_ptr on (oikein kohdistettu) usize-ptr, jota käytämme lukemaan
    // viipaleen keskiosa.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` on `word_ptr`: n tavuindeksi, jota käytetään silmukan lopputarkistuksiin.
    let mut byte_pos = offset_to_aligned;

    // Paranoia tarkistaa kohdistuksen, koska olemme tekemässä joukko kohdistamattomia kuormia.
    // Käytännössä tämän pitäisi olla mahdotonta estää virheen `align_offset`: ssä.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Lue seuraavat sanat viimeiseen tasattuun sanaan asti, lukuun ottamatta viimeistä tasattua sanaa, joka tehdään myöhemmin hännätarkastuksessa, jotta varmistetaan, että häntä on aina enintään yksi `usize` ylimääräiseen branch `byte_pos == len`: ään.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Sanity tarkista, että lukema on rajattu
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Ja että oletuksemme `byte_pos`: stä pitävät paikkansa.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // TURVALLISUUS: Tiedämme, että `word_ptr` on kohdistettu oikein (johtuen
        // `align_offset`), ja tiedämme, että meillä on tarpeeksi tavuja `word_ptr`: n ja loppun välillä
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // TURVALLISUUS: Tiedämme `byte_pos <= len - USIZE_SIZE`: n, mikä tarkoittaa sitä
        // tämän `add`: n jälkeen `word_ptr` on korkeintaan yksi ohi.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Saniteettitarkistus sen varmistamiseksi, että `usize` on todella jäljellä.
    // Tämä tulisi taata silmukan kunnolla.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // TURVALLISUUS: Tämä perustuu `len >= USIZE_SIZE`: ään, jonka tarkistamme alussa.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}