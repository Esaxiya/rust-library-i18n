//! Komposiittinen asynkroninen iteraatio.
//!
//! Jos futures ovat asynkronisia arvoja, virrat ovat asynkronisia iteraattoreita.
//! Jos olet löytänyt jonkinlainen asynkroninen kokoelma ja sinun on suoritettava toimenpide mainitun kokoelman elementeillä, törmäät nopeasti 'streams': ään.
//! Striimejä käytetään voimakkaasti idiomaattisessa asynkronisessa Rust-koodissa, joten on syytä tutustua niihin.
//!
//! Ennen kuin selitämme lisää, puhutaan tämän moduulin rakenteesta:
//!
//! # Organization
//!
//! Tämä moduuli on pääosin järjestetty tyypin mukaan:
//!
//! * [Traits] ovat ydinosa: nämä traits määrittelevät millaisia virtoja on ja mitä voit tehdä niiden kanssa.Näiden traits-menetelmien arvo on ylimääräinen opiskeluaika.
//! * Toiminnot tarjoavat hyödyllisiä tapoja luoda joitain perusvirtoja.
//! * Rakenteet ovat usein moduulin traits eri menetelmien palautustyyppejä.Yleensä kannattaa tarkastella menetelmää, jolla `struct` luodaan, eikä itse `struct`: ää.
//! Lisätietoja miksi, katso `[Streamin käyttöönotto](#Implementing-stream)`.
//!
//! [Traits]: #traits
//!
//! Se siitä!Kaivetaan puroihin.
//!
//! # Stream
//!
//! Tämän moduulin sydän ja sielu on [`Stream`] trait.[`Stream`]: n ydin näyttää tältä:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Toisin kuin `Iterator`, `Stream` erottaa [`poll_next`]-menetelmän, jota käytetään toteutettaessa `Stream`, ja (to-be-implemented) `next`-menetelmän, jota käytetään virtaa kulutettaessa.
//!
//! `Stream`: n kuluttajien on otettava huomioon vain `next`, joka soitettaessa palauttaa future: n, joka tuottaa `Option<Stream::Item>`: n.
//!
//! `next`: n palauttama future tuottaa `Some(Item)`: n, kunhan elementtejä on, ja kun kaikki on käytetty loppuun, saadaan `None` osoittamaan, että iterointi on valmis.
//! Jos odotamme jotain asynkronista ratkaisua, future odottaa, kunnes virta on valmis tuottamaan uudelleen.
//!
//! Yksittäiset virrat voivat päättää jatkaa iterointia, joten `next`: n uudelleen soittaminen voi tai ei välttämättä tuota `Some(Item)`: ää uudelleen jossain vaiheessa.
//!
//! [`Stream`]: n täysi määritelmä sisältää myös useita muita menetelmiä, mutta ne ovat oletusmenetelmiä, jotka on rakennettu [`poll_next`]: n päälle, joten saat ne ilmaiseksi.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Streamin käyttöönotto
//!
//! Oman virran luominen edellyttää kahta vaihetta: `struct`: n luominen virran tilan pitämiseksi ja [`Stream`]: n käyttöönotto tälle `struct`: lle.
//!
//! Tehdään virta, jonka nimi on `Counter` ja joka laskee välillä `1`-`5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Ensinnäkin rakenne:
//!
//! /// Virta, joka laskee yhdestä viiteen
//! struct Counter {
//!     count: usize,
//! }
//!
//! // haluamme, että laskemamme alkaa yhdellä, joten lisätään new()-menetelmä auttamaan.
//! // Tämä ei ole ehdottoman välttämätöntä, mutta on kätevää.
//! // Huomaa, että aloitamme `count`: n nollasta, näemme miksi `poll_next()`'s-toteutuksessa alla.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Sitten toteutamme `Stream`: n `Counter`: lle:
//!
//! impl Stream for Counter {
//!     // me laskemme usizen kanssa
//!     type Item = usize;
//!
//!     // poll_next() on ainoa vaadittu menetelmä
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Kasvata lukumääräämme.Siksi aloitimme nollasta.
//!         self.count += 1;
//!
//!         // Tarkista onko laskeminen lopetettu vai ei.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Virrat ovat *laiskoja*.Tämä tarkoittaa, että vain virran luominen ei ole _do_ paljon.Mitään ei todellakaan tapahdu, ennen kuin soitat `next`: ään.
//! Tämä aiheuttaa joskus hämmennystä, kun luot virtaa vain sen sivuvaikutuksia varten.
//! Kääntäjä varoittaa meitä tällaisesta käyttäytymisestä:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;