use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Rajapinta asynkronisten iteraattorien käsittelemiseksi.
///
/// Tämä on päävirta trait.
/// Katso lisätietoja virtojen käsitteestä [module-level documentation]: stä.
/// Erityisesti haluat ehkä tietää, miten [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Striimin tuottamien kohteiden tyyppi.
    type Item;

    /// Yritä vetää tämän virran seuraava arvo rekisteröimällä nykyinen tehtävä herätykseen, jos arvo ei ole vielä käytettävissä, ja palauttamalla `None`, jos virta on loppunut.
    ///
    /// # Palautusarvo
    ///
    /// Palautusarvoja on useita, joista jokainen osoittaa erillisen virtaustilan:
    ///
    /// - `Poll::Pending` tarkoittaa, että tämän virran seuraava arvo ei ole vielä valmis.Toteutukset varmistavat, että nykyinen tehtävä ilmoitetaan, kun seuraava arvo voi olla valmis.
    ///
    /// - `Poll::Ready(Some(val))` tarkoittaa, että virta on tuottanut arvon `val` onnistuneesti ja voi tuottaa lisää arvoja seuraavilla `poll_next`-puheluilla.
    ///
    /// - `Poll::Ready(None)` tarkoittaa, että virta on päättynyt ja `poll_next`: ää ei pitäisi käynnistää uudelleen.
    ///
    /// # Panics
    ///
    /// Kun virta on valmis (palauttanut `Ready(None)` from `poll_next`): n, kutsumalla sen uudelleen `poll_next`-menetelmää, panic voi estää, ikuisesti tai aiheuttaa muita ongelmia; `Stream` trait ei aseta vaatimuksia tällaisen puhelun vaikutuksille.
    ///
    /// Koska `poll_next`-menetelmää ei ole merkitty `unsafe`: ksi, sovelletaan Rust: n tavanomaisia sääntöjä: puhelut eivät saa koskaan aiheuttaa määrittelemätöntä käyttäytymistä (muistivirheitä, `unsafe`-toimintojen väärää käyttöä tai vastaavia) virran tilasta riippumatta.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Palauttaa virran jäljellä olevan pituuden rajat.
    ///
    /// Tarkemmin sanottuna `size_hint()` palauttaa dupleksin, jossa ensimmäinen elementti on alaraja ja toinen elementti on yläraja.
    ///
    /// Palautettavan kaksoispuoliskon toinen puolisko on [``Vaihtoehto``] ```` ```` käytä '' `` `.
    /// [`None`] tarkoittaa tässä, että joko tunnettua ylärajaa ei ole tai yläraja on suurempi kuin [`usize`].
    ///
    /// # Toteutustiedot
    ///
    /// Ei ole pakko, että virran toteutus tuottaa ilmoitetun määrän elementtejä.Buginen virta voi tuottaa vähemmän kuin elementtien ala-tai yläraja.
    ///
    /// `size_hint()` on ensisijaisesti tarkoitettu käytettäväksi optimointiin, kuten tilan varaamiseen virran elementeille, mutta siihen ei saa luottaa esimerkiksi jättämään rajatarkastukset pois vaarallisessa koodissa.
    /// `size_hint()`: n virheellinen käyttöönotto ei saisi johtaa muistin turvallisuusrikkomuksiin.
    ///
    /// Täytäntöönpanon pitäisi kuitenkin antaa oikea arvio, koska muuten se loukkaa trait-protokollaa.
    ///
    /// Oletusarvoinen toteutus palauttaa `(0,` [``Ei mitään '')`)` `, joka on oikea kaikille virroille.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}