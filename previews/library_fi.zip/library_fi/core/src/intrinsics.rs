//! Kääntäjän luontaiset piirteet.
//!
//! Vastaavat määritelmät ovat muodossa `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Vastaavat vakiototeutukset ovat `compiler/rustc_mir/src/interpret/intrinsics.rs`: ssä
//!
//! # Const luonnostaan
//!
//! Note: kaikista muutoksista luontaisten ominaisuuksien vakauteen tulee keskustella kielitiimin kanssa.
//! Tämä sisältää muutoksia vakauden vakaudessa.
//!
//! Jotta sisäinen sisältö olisi käyttökelpoinen kokoamisajankohtana, toteutus täytyy kopioida <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs>: stä `compiler/rustc_mir/src/interpret/intrinsics.rs`: ään ja lisätä `#[rustc_const_unstable(feature = "foo", issue = "01234")]` luontaiseen.
//!
//!
//! Jos oletetaan, että sisäistä ominaisuutta käytetään `const fn`: stä `rustc_const_stable`-määritteen kanssa, myös sisäisen attribuutin on oltava `rustc_const_stable`.
//! Tällaista muutosta ei pidä tehdä ilman T-lang-kuulemista, koska se laittaa kielelle ominaisuuden, jota ei voida kopioida käyttäjäkoodissa ilman kääntäjän tukea.
//!
//! # Volatiles
//!
//! Haihtuvat sisäiset tekijät tarjoavat toimintoja, jotka on tarkoitettu toimimaan I/O-muistissa, ja kääntäjä ei taata niitä järjestää muiden haihtuvien sisäisten ominaisuuksien kautta.Katso LLVM-dokumentaatio [[volatile]]: stä.
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Atomiset sisäosat tarjoavat yhteisiä atomioperaatioita konesanoille, useilla mahdollisilla muistijärjestyksillä.Ne noudattavat samaa semantiikkaa kuin C++ 11.Katso LLVM-dokumentaatio [[atomics]]: stä.
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Nopea päivitys muistin tilaamiseen:
//!
//! * Hanki este lukon hankkimiseksi.Seuraava lukeminen ja kirjoittaminen tapahtuu esteen jälkeen.
//! * Vapauta, este lukon vapauttamiseksi.Edelliset lukut ja kirjoitukset tapahtuvat ennen estettä.
//! * Peräkkäin yhdenmukaiset, peräkkäin yhdenmukaiset operaatiot taataan järjestyksessä.Tämä on vakiotila työskenneltäessä atomityyppien kanssa ja vastaa Java: n `volatile`: ää.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Tätä tuontia käytetään yksinkertaistamaan sisäisiä linkkejä
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // TURVALLISUUS: katso `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // Huomaa, että nämä sisäiset tekijät ottavat raakoja viitteitä, koska ne mutatoivat aliased-muistia, mikä ei ole kelvollinen `&`: lle tai `&mut`: lle.
    //

    /// Tallentaa arvon, jos nykyinen arvo on sama kuin `old`-arvo.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `compare_exchange`-menetelmän kautta välittämällä [`Ordering::SeqCst`] sekä `success`-että `failure`-parametreina.
    ///
    /// Esimerkiksi, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tallentaa arvon, jos nykyinen arvo on sama kuin `old`-arvo.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `compare_exchange`-menetelmän kautta välittämällä [`Ordering::Acquire`] sekä `success`-että `failure`-parametreina.
    ///
    /// Esimerkiksi, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tallentaa arvon, jos nykyinen arvo on sama kuin `old`-arvo.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyypeille `compare_exchange`-menetelmän kautta välittämällä [`Ordering::Release`] `success`: ksi ja [`Ordering::Relaxed`] `failure`-parametreiksi.
    /// Esimerkiksi, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tallentaa arvon, jos nykyinen arvo on sama kuin `old`-arvo.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyypeille `compare_exchange`-menetelmän kautta välittämällä [`Ordering::AcqRel`] `success`: ksi ja [`Ordering::Acquire`] `failure`-parametreiksi.
    /// Esimerkiksi, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tallentaa arvon, jos nykyinen arvo on sama kuin `old`-arvo.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `compare_exchange`-menetelmän kautta välittämällä [`Ordering::Relaxed`] sekä `success`-että `failure`-parametreina.
    ///
    /// Esimerkiksi, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tallentaa arvon, jos nykyinen arvo on sama kuin `old`-arvo.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyypeille `compare_exchange`-menetelmän kautta välittämällä [`Ordering::SeqCst`] `success`: ksi ja [`Ordering::Relaxed`] `failure`-parametreiksi.
    /// Esimerkiksi, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tallentaa arvon, jos nykyinen arvo on sama kuin `old`-arvo.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyypeille `compare_exchange`-menetelmän kautta välittämällä [`Ordering::SeqCst`] `success`: ksi ja [`Ordering::Acquire`] `failure`-parametreiksi.
    /// Esimerkiksi, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tallentaa arvon, jos nykyinen arvo on sama kuin `old`-arvo.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyypeille `compare_exchange`-menetelmän kautta välittämällä [`Ordering::Acquire`] `success`: ksi ja [`Ordering::Relaxed`] `failure`-parametreiksi.
    /// Esimerkiksi, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tallentaa arvon, jos nykyinen arvo on sama kuin `old`-arvo.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyypeille `compare_exchange`-menetelmän kautta välittämällä [`Ordering::AcqRel`] `success`: ksi ja [`Ordering::Relaxed`] `failure`-parametreiksi.
    /// Esimerkiksi, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Tallentaa arvon, jos nykyinen arvo on sama kuin `old`-arvo.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `compare_exchange_weak`-menetelmän kautta välittämällä [`Ordering::SeqCst`] sekä `success`-että `failure`-parametreina.
    ///
    /// Esimerkiksi, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tallentaa arvon, jos nykyinen arvo on sama kuin `old`-arvo.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `compare_exchange_weak`-menetelmän kautta välittämällä [`Ordering::Acquire`] sekä `success`-että `failure`-parametreina.
    ///
    /// Esimerkiksi, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tallentaa arvon, jos nykyinen arvo on sama kuin `old`-arvo.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyypeille `compare_exchange_weak`-menetelmän kautta välittämällä [`Ordering::Release`] `success`: ksi ja [`Ordering::Relaxed`] `failure`-parametreiksi.
    /// Esimerkiksi, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tallentaa arvon, jos nykyinen arvo on sama kuin `old`-arvo.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyypeille `compare_exchange_weak`-menetelmän kautta välittämällä [`Ordering::AcqRel`] `success`: ksi ja [`Ordering::Acquire`] `failure`-parametreiksi.
    /// Esimerkiksi, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tallentaa arvon, jos nykyinen arvo on sama kuin `old`-arvo.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `compare_exchange_weak`-menetelmän kautta välittämällä [`Ordering::Relaxed`] sekä `success`-että `failure`-parametreina.
    ///
    /// Esimerkiksi, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tallentaa arvon, jos nykyinen arvo on sama kuin `old`-arvo.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyypeille `compare_exchange_weak`-menetelmän kautta välittämällä [`Ordering::SeqCst`] `success`: ksi ja [`Ordering::Relaxed`] `failure`-parametreiksi.
    /// Esimerkiksi, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tallentaa arvon, jos nykyinen arvo on sama kuin `old`-arvo.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyypeille `compare_exchange_weak`-menetelmän kautta välittämällä [`Ordering::SeqCst`] `success`: ksi ja [`Ordering::Acquire`] `failure`-parametreiksi.
    /// Esimerkiksi, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tallentaa arvon, jos nykyinen arvo on sama kuin `old`-arvo.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyypeille `compare_exchange_weak`-menetelmän kautta välittämällä [`Ordering::Acquire`] `success`: ksi ja [`Ordering::Relaxed`] `failure`-parametreiksi.
    /// Esimerkiksi, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tallentaa arvon, jos nykyinen arvo on sama kuin `old`-arvo.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyypeille `compare_exchange_weak`-menetelmän kautta välittämällä [`Ordering::AcqRel`] `success`: ksi ja [`Ordering::Relaxed`] `failure`-parametreiksi.
    /// Esimerkiksi, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Lataa osoittimen nykyisen arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `load`-menetelmän kautta ohittamalla [`Ordering::SeqCst`] nimellä `order`.
    /// Esimerkiksi, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Lataa osoittimen nykyisen arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `load`-menetelmän kautta ohittamalla [`Ordering::Acquire`] nimellä `order`.
    /// Esimerkiksi, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Lataa osoittimen nykyisen arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `load`-menetelmän kautta ohittamalla [`Ordering::Relaxed`] nimellä `order`.
    /// Esimerkiksi, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Tallentaa arvon määritettyyn muistipaikkaan.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `store`-menetelmän kautta ohittamalla [`Ordering::SeqCst`] nimellä `order`.
    /// Esimerkiksi, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Tallentaa arvon määritettyyn muistipaikkaan.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `store`-menetelmän kautta ohittamalla [`Ordering::Release`] nimellä `order`.
    /// Esimerkiksi, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Tallentaa arvon määritettyyn muistipaikkaan.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `store`-menetelmän kautta ohittamalla [`Ordering::Relaxed`] nimellä `order`.
    /// Esimerkiksi, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Tallentaa arvon määritettyyn muistipaikkaan palauttamalla vanhan arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `swap`-menetelmän kautta ohittamalla [`Ordering::SeqCst`] nimellä `order`.
    /// Esimerkiksi, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tallentaa arvon määritettyyn muistipaikkaan palauttamalla vanhan arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `swap`-menetelmän kautta ohittamalla [`Ordering::Acquire`] nimellä `order`.
    /// Esimerkiksi, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tallentaa arvon määritettyyn muistipaikkaan palauttamalla vanhan arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `swap`-menetelmän kautta ohittamalla [`Ordering::Release`] nimellä `order`.
    /// Esimerkiksi, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tallentaa arvon määritettyyn muistipaikkaan palauttamalla vanhan arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `swap`-menetelmän kautta ohittamalla [`Ordering::AcqRel`] nimellä `order`.
    /// Esimerkiksi, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tallentaa arvon määritettyyn muistipaikkaan palauttamalla vanhan arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `swap`-menetelmän kautta ohittamalla [`Ordering::Relaxed`] nimellä `order`.
    /// Esimerkiksi, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Lisää nykyiseen arvoon palauttaen edellisen arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `fetch_add`-menetelmän kautta ohittamalla [`Ordering::SeqCst`] nimellä `order`.
    /// Esimerkiksi, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lisää nykyiseen arvoon palauttaen edellisen arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `fetch_add`-menetelmän kautta ohittamalla [`Ordering::Acquire`] nimellä `order`.
    /// Esimerkiksi, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lisää nykyiseen arvoon palauttaen edellisen arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `fetch_add`-menetelmän kautta ohittamalla [`Ordering::Release`] nimellä `order`.
    /// Esimerkiksi, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lisää nykyiseen arvoon palauttaen edellisen arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `fetch_add`-menetelmän kautta ohittamalla [`Ordering::AcqRel`] nimellä `order`.
    /// Esimerkiksi, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lisää nykyiseen arvoon palauttaen edellisen arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `fetch_add`-menetelmän kautta ohittamalla [`Ordering::Relaxed`] nimellä `order`.
    /// Esimerkiksi, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Vähennä nykyisestä arvosta ja palauta edellinen arvo.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `fetch_sub`-menetelmän kautta ohittamalla [`Ordering::SeqCst`] nimellä `order`.
    /// Esimerkiksi, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Vähennä nykyisestä arvosta ja palauta edellinen arvo.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `fetch_sub`-menetelmän kautta ohittamalla [`Ordering::Acquire`] nimellä `order`.
    /// Esimerkiksi, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Vähennä nykyisestä arvosta ja palauta edellinen arvo.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `fetch_sub`-menetelmän kautta ohittamalla [`Ordering::Release`] nimellä `order`.
    /// Esimerkiksi, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Vähennä nykyisestä arvosta ja palauta edellinen arvo.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `fetch_sub`-menetelmän kautta ohittamalla [`Ordering::AcqRel`] nimellä `order`.
    /// Esimerkiksi, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Vähennä nykyisestä arvosta ja palauta edellinen arvo.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `fetch_sub`-menetelmän kautta ohittamalla [`Ordering::Relaxed`] nimellä `order`.
    /// Esimerkiksi, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bittisuuntaisesti ja nykyisellä arvolla palauttaen edellisen arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `fetch_and`-menetelmän kautta ohittamalla [`Ordering::SeqCst`] nimellä `order`.
    /// Esimerkiksi, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bittisuuntaisesti ja nykyisellä arvolla palauttaen edellisen arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `fetch_and`-menetelmän kautta ohittamalla [`Ordering::Acquire`] nimellä `order`.
    /// Esimerkiksi, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bittisuuntaisesti ja nykyisellä arvolla palauttaen edellisen arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `fetch_and`-menetelmän kautta ohittamalla [`Ordering::Release`] nimellä `order`.
    /// Esimerkiksi, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bittisuuntaisesti ja nykyisellä arvolla palauttaen edellisen arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `fetch_and`-menetelmän kautta ohittamalla [`Ordering::AcqRel`] nimellä `order`.
    /// Esimerkiksi, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bittisuuntaisesti ja nykyisellä arvolla palauttaen edellisen arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `fetch_and`-menetelmän kautta ohittamalla [`Ordering::Relaxed`] nimellä `order`.
    /// Esimerkiksi, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Nykyinen arvo bittiä kohti nand, palauttaen edellisen arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`AtomicBool`]-tyypille `fetch_nand`-menetelmän kautta ohittamalla [`Ordering::SeqCst`] nimellä `order`.
    /// Esimerkiksi, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nykyinen arvo bittiä kohti nand, palauttaen edellisen arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`AtomicBool`]-tyypille `fetch_nand`-menetelmän kautta ohittamalla [`Ordering::Acquire`] nimellä `order`.
    /// Esimerkiksi, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nykyinen arvo bittiä kohti nand, palauttaen edellisen arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`AtomicBool`]-tyypille `fetch_nand`-menetelmän kautta ohittamalla [`Ordering::Release`] nimellä `order`.
    /// Esimerkiksi, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nykyinen arvo bittiä kohti nand, palauttaen edellisen arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`AtomicBool`]-tyypille `fetch_nand`-menetelmän kautta ohittamalla [`Ordering::AcqRel`] nimellä `order`.
    /// Esimerkiksi, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nykyinen arvo bittiä kohti nand, palauttaen edellisen arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`AtomicBool`]-tyypille `fetch_nand`-menetelmän kautta ohittamalla [`Ordering::Relaxed`] nimellä `order`.
    /// Esimerkiksi, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitittain tai nykyisellä arvolla, palauttamalla edellisen arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `fetch_or`-menetelmän kautta ohittamalla [`Ordering::SeqCst`] nimellä `order`.
    /// Esimerkiksi, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitittain tai nykyisellä arvolla, palauttamalla edellisen arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `fetch_or`-menetelmän kautta ohittamalla [`Ordering::Acquire`] nimellä `order`.
    /// Esimerkiksi, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitittain tai nykyisellä arvolla, palauttamalla edellisen arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `fetch_or`-menetelmän kautta ohittamalla [`Ordering::Release`] nimellä `order`.
    /// Esimerkiksi, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitittain tai nykyisellä arvolla, palauttamalla edellisen arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `fetch_or`-menetelmän kautta ohittamalla [`Ordering::AcqRel`] nimellä `order`.
    /// Esimerkiksi, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitittain tai nykyisellä arvolla, palauttamalla edellisen arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `fetch_or`-menetelmän kautta ohittamalla [`Ordering::Relaxed`] nimellä `order`.
    /// Esimerkiksi, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bittisuuntaisesti tai nykyisen arvon kanssa, palauttaen edellisen arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `fetch_xor`-menetelmän kautta ohittamalla [`Ordering::SeqCst`] nimellä `order`.
    /// Esimerkiksi, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bittisuuntaisesti tai nykyisen arvon kanssa, palauttaen edellisen arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `fetch_xor`-menetelmän kautta ohittamalla [`Ordering::Acquire`] nimellä `order`.
    /// Esimerkiksi, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bittisuuntaisesti tai nykyisen arvon kanssa, palauttaen edellisen arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `fetch_xor`-menetelmän kautta ohittamalla [`Ordering::Release`] nimellä `order`.
    /// Esimerkiksi, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bittisuuntaisesti tai nykyisen arvon kanssa, palauttaen edellisen arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `fetch_xor`-menetelmän kautta ohittamalla [`Ordering::AcqRel`] nimellä `order`.
    /// Esimerkiksi, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bittisuuntaisesti tai nykyisen arvon kanssa, palauttaen edellisen arvon.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-tyyppeihin `fetch_xor`-menetelmän kautta ohittamalla [`Ordering::Relaxed`] nimellä `order`.
    /// Esimerkiksi, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Suurin nykyisen arvon kanssa käyttäen allekirjoitettua vertailua.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-allekirjoitetuille kokonaislukutyypeille `fetch_max`-menetelmän kautta ohittamalla [`Ordering::SeqCst`] `order`: nä.
    /// Esimerkiksi, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Suurin nykyisen arvon kanssa käyttäen allekirjoitettua vertailua.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-allekirjoitetuille kokonaislukutyypeille `fetch_max`-menetelmän kautta ohittamalla [`Ordering::Acquire`] `order`: nä.
    /// Esimerkiksi, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Suurin nykyisen arvon kanssa käyttäen allekirjoitettua vertailua.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-allekirjoitetuille kokonaislukutyypeille `fetch_max`-menetelmän kautta ohittamalla [`Ordering::Release`] `order`: nä.
    /// Esimerkiksi, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Suurin nykyisen arvon kanssa käyttäen allekirjoitettua vertailua.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-allekirjoitetuille kokonaislukutyypeille `fetch_max`-menetelmän kautta ohittamalla [`Ordering::AcqRel`] `order`: nä.
    /// Esimerkiksi, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Suurin nykyisellä arvolla.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-allekirjoitetuille kokonaislukutyypeille `fetch_max`-menetelmän kautta ohittamalla [`Ordering::Relaxed`] `order`: nä.
    /// Esimerkiksi, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Pienin nykyisen arvon kanssa käyttäen allekirjoitettua vertailua.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-allekirjoitetuille kokonaislukutyypeille `fetch_min`-menetelmän kautta ohittamalla [`Ordering::SeqCst`] `order`: nä.
    /// Esimerkiksi, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pienin nykyisen arvon kanssa käyttäen allekirjoitettua vertailua.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-allekirjoitetuille kokonaislukutyypeille `fetch_min`-menetelmän kautta ohittamalla [`Ordering::Acquire`] `order`: nä.
    /// Esimerkiksi, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pienin nykyisen arvon kanssa käyttäen allekirjoitettua vertailua.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-allekirjoitetuille kokonaislukutyypeille `fetch_min`-menetelmän kautta ohittamalla [`Ordering::Release`] `order`: nä.
    /// Esimerkiksi, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pienin nykyisen arvon kanssa käyttäen allekirjoitettua vertailua.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-allekirjoitetuille kokonaislukutyypeille `fetch_min`-menetelmän kautta ohittamalla [`Ordering::AcqRel`] `order`: nä.
    /// Esimerkiksi, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pienin nykyisen arvon kanssa käyttäen allekirjoitettua vertailua.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana [`atomic`]-allekirjoitetuille kokonaislukutyypeille `fetch_min`-menetelmän kautta ohittamalla [`Ordering::Relaxed`] `order`: nä.
    /// Esimerkiksi, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Pienin nykyiseen arvoon käyttämällä allekirjoittamatonta vertailua.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana allekirjoittamattomille [`atomic`]-kokonaislukutyypeille `fetch_min`-menetelmän kautta ohittamalla [`Ordering::SeqCst`] `order`: nä.
    /// Esimerkiksi, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pienin nykyiseen arvoon käyttämällä allekirjoittamatonta vertailua.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana allekirjoittamattomille [`atomic`]-kokonaislukutyypeille `fetch_min`-menetelmän kautta ohittamalla [`Ordering::Acquire`] `order`: nä.
    /// Esimerkiksi, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pienin nykyiseen arvoon käyttämällä allekirjoittamatonta vertailua.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana allekirjoittamattomille [`atomic`]-kokonaislukutyypeille `fetch_min`-menetelmän kautta ohittamalla [`Ordering::Release`] `order`: nä.
    /// Esimerkiksi, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pienin nykyiseen arvoon käyttämällä allekirjoittamatonta vertailua.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana allekirjoittamattomille [`atomic`]-kokonaislukutyypeille `fetch_min`-menetelmän kautta ohittamalla [`Ordering::AcqRel`] `order`: nä.
    /// Esimerkiksi, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pienin nykyiseen arvoon käyttämällä allekirjoittamatonta vertailua.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana allekirjoittamattomille [`atomic`]-kokonaislukutyypeille `fetch_min`-menetelmän kautta ohittamalla [`Ordering::Relaxed`] `order`: nä.
    /// Esimerkiksi, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Suurin nykyisen arvon kanssa käyttämällä allekirjoittamatonta vertailua.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana allekirjoittamattomille [`atomic`]-kokonaislukutyypeille `fetch_max`-menetelmän kautta ohittamalla [`Ordering::SeqCst`] `order`: nä.
    /// Esimerkiksi, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Suurin nykyisen arvon kanssa käyttämällä allekirjoittamatonta vertailua.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana allekirjoittamattomille [`atomic`]-kokonaislukutyypeille `fetch_max`-menetelmän kautta ohittamalla [`Ordering::Acquire`] `order`: nä.
    /// Esimerkiksi, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Suurin nykyisen arvon kanssa käyttämällä allekirjoittamatonta vertailua.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana allekirjoittamattomille [`atomic`]-kokonaislukutyypeille `fetch_max`-menetelmän kautta ohittamalla [`Ordering::Release`] `order`: nä.
    /// Esimerkiksi, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Suurin nykyisen arvon kanssa käyttämällä allekirjoittamatonta vertailua.
    ///
    /// Tämän luontaisen version vakautettu versio on saatavana allekirjoittamattomille [`atomic`]-kokonaislukutyypeille `fetch_max`-menetelmän kautta ohittamalla [`Ordering::AcqRel`] `order`: nä.
    /// Esimerkiksi, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Suurin nykyisen arvon kanssa käyttämällä allekirjoittamatonta vertailua.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana allekirjoittamattomille [`atomic`]-kokonaislukutyypeille `fetch_max`-menetelmän kautta ohittamalla [`Ordering::Relaxed`] `order`: nä.
    /// Esimerkiksi, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Sisäinen `prefetch` on vihje koodigeneraattorille esihakukäskyn lisäämiseksi, jos sitä tuetaan;muuten se on ei-op.
    /// Esihakeilla ei ole vaikutusta ohjelman käyttäytymiseen, mutta ne voivat muuttaa sen suorituskykyominaisuuksia.
    ///
    /// `locality`-argumentin on oltava vakio kokonaisluku ja se on ajallinen paikkatietomääritin, joka vaihtelee (0): stä, ei sijaintia, (3): ään, erittäin paikallinen välimuistissa.
    ///
    ///
    /// Tällä luontaisella ei ole vakaata vastaavaa.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Sisäinen `prefetch` on vihje koodigeneraattorille esihakukäskyn lisäämiseksi, jos sitä tuetaan;muuten se on ei-op.
    /// Esihakeilla ei ole vaikutusta ohjelman käyttäytymiseen, mutta ne voivat muuttaa sen suorituskykyominaisuuksia.
    ///
    /// `locality`-argumentin on oltava vakio kokonaisluku ja se on ajallinen paikkatietomääritin, joka vaihtelee (0): stä, ei sijaintia, (3): ään, erittäin paikallinen välimuistissa.
    ///
    ///
    /// Tällä luontaisella ei ole vakaata vastaavaa.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Sisäinen `prefetch` on vihje koodigeneraattorille esihakukäskyn lisäämiseksi, jos sitä tuetaan;muuten se on ei-op.
    /// Esihakeilla ei ole vaikutusta ohjelman käyttäytymiseen, mutta ne voivat muuttaa sen suorituskykyominaisuuksia.
    ///
    /// `locality`-argumentin on oltava vakio kokonaisluku ja se on ajallinen paikkatietomääritin, joka vaihtelee (0): stä, ei sijaintia, (3): ään, erittäin paikallinen välimuistissa.
    ///
    ///
    /// Tällä luontaisella ei ole vakaata vastaavaa.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Sisäinen `prefetch` on vihje koodigeneraattorille esihakukäskyn lisäämiseksi, jos sitä tuetaan;muuten se on ei-op.
    /// Esihakeilla ei ole vaikutusta ohjelman käyttäytymiseen, mutta ne voivat muuttaa sen suorituskykyominaisuuksia.
    ///
    /// `locality`-argumentin on oltava vakio kokonaisluku ja se on ajallinen paikkatietomääritin, joka vaihtelee (0): stä, ei sijaintia, (3): ään, erittäin paikallinen välimuistissa.
    ///
    ///
    /// Tällä luontaisella ei ole vakaata vastaavaa.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Atomiaita.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana versiossa [`atomic::fence`] ohittamalla [`Ordering::SeqCst`] nimellä `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Atomiaita.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana versiossa [`atomic::fence`] ohittamalla [`Ordering::Acquire`] nimellä `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Atomiaita.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana versiossa [`atomic::fence`] ohittamalla [`Ordering::Release`] nimellä `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Atomiaita.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana versiossa [`atomic::fence`] ohittamalla [`Ordering::AcqRel`] nimellä `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Vain kääntäjälle tarkoitettu muistimuuri.
    ///
    /// Kääntäjä ei koskaan järjestä muistiliittymiä tämän esteen yli, mutta sille ei anneta ohjeita.
    /// Tämä soveltuu saman säikeen toimintoihin, jotka voidaan estää, kuten vuorovaikutuksessa signaalinkäsittelijöiden kanssa.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana versiossa [`atomic::compiler_fence`] ohittamalla [`Ordering::SeqCst`] nimellä `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Vain kääntäjälle tarkoitettu muistimuuri.
    ///
    /// Kääntäjä ei koskaan järjestä muistiliittymiä tämän esteen yli, mutta sille ei anneta ohjeita.
    /// Tämä soveltuu saman säikeen toimintoihin, jotka voidaan estää, kuten vuorovaikutuksessa signaalinkäsittelijöiden kanssa.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana versiossa [`atomic::compiler_fence`] ohittamalla [`Ordering::Acquire`] nimellä `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Vain kääntäjälle tarkoitettu muistimuuri.
    ///
    /// Kääntäjä ei koskaan järjestä muistiliittymiä tämän esteen yli, mutta sille ei anneta ohjeita.
    /// Tämä soveltuu saman säikeen toimintoihin, jotka voidaan estää, kuten vuorovaikutuksessa signaalinkäsittelijöiden kanssa.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana versiossa [`atomic::compiler_fence`] ohittamalla [`Ordering::Release`] nimellä `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Vain kääntäjälle tarkoitettu muistimuuri.
    ///
    /// Kääntäjä ei koskaan järjestä muistiliittymiä tämän esteen yli, mutta sille ei anneta ohjeita.
    /// Tämä soveltuu saman säikeen toimintoihin, jotka voidaan estää, kuten vuorovaikutuksessa signaalinkäsittelijöiden kanssa.
    ///
    /// Tämän sisäisen osan vakiintunut versio on saatavana versiossa [`atomic::compiler_fence`] ohittamalla [`Ordering::AcqRel`] nimellä `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Sisäinen taika, joka saa merkityksensä funktioon liitetyistä ominaisuuksista.
    ///
    /// Esimerkiksi tietovirta käyttää tätä staattisten väitteiden injektointiin niin, että `rustc_peek(potentially_uninitialized)` tarkistaisi itse asiassa, että tietovirta todellakin laskee, että sitä ei ole alustettu ohjausvuohon tässä kohdassa.
    ///
    ///
    /// Tätä luonnetta ei tule käyttää kääntäjän ulkopuolella.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Keskeyttää prosessin suorittamisen.
    ///
    /// Käyttäjäystävällisempi ja vakaa versio tästä toiminnosta on [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Ilmoittaa optimoijalle, että koodin tähän kohtaan ei päästä, mikä mahdollistaa lisäoptimoinnin.
    ///
    /// Huomaa, että tämä eroaa suuresti `unreachable!()`-makrosta: Toisin kuin makro, jonka panics suoritettaessa on *määrittelemätön käyttäytyminen* saavuttaa tällä toiminnolla merkitty koodi.
    ///
    ///
    /// Tämän sisäisen osan vakiintunut versio on [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Ilmoittaa optimoijalle, että ehto on aina totta.
    /// Jos ehto on väärä, käyttäytymistä ei ole määritelty.
    ///
    /// Tälle luontaiselle koodille ei luoda koodia, mutta optimoija yrittää säilyttää sen (ja sen kunnon) läpäisyjen välillä, mikä voi häiritä ympäröivän koodin optimointia ja heikentää suorituskykyä.
    /// Sitä ei tule käyttää, jos optimoija voi löytää invarianttin yksin tai jos se ei salli merkittäviä optimointeja.
    ///
    /// Tällä luontaisella ei ole vakaata vastaavaa.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Vihjeitä kääntäjälle, että branch-ehto on todennäköisesti totta.
    /// Palauttaa sille välitetyn arvon.
    ///
    /// Millä tahansa muulla kuin `if`-lauseiden käytöllä ei todennäköisesti ole vaikutusta.
    ///
    /// Tällä luontaisella ei ole vakaata vastaavaa.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Vihjeitä kääntäjälle, että branch-tila on todennäköisesti väärä.
    /// Palauttaa sille välitetyn arvon.
    ///
    /// Millä tahansa muulla kuin `if`-lauseiden käytöllä ei todennäköisesti ole vaikutusta.
    ///
    /// Tällä luontaisella ei ole vakaata vastaavaa.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Suorittaa vikailmoittajan virheenkorjaajan tarkastettavaksi.
    ///
    /// Tällä luontaisella ei ole vakaata vastaavaa.
    pub fn breakpoint();

    /// Tyypin koko tavuina.
    ///
    /// Tarkemmin sanottuna tämä on tavujen siirtymä peräkkäisten saman tyyppisten kohteiden välillä, mukaan lukien kohdistuspehmusteet.
    ///
    ///
    /// Tämän sisäisen osan vakiintunut versio on [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Tyypin vähimmäistasaus.
    ///
    /// Tämän sisäisen osan vakiintunut versio on [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Tyypin ensisijainen kohdistus.
    ///
    /// Tällä luontaisella ei ole vakaata vastaavaa.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Viitatun arvon koko tavuina.
    ///
    /// Tämän sisäisen osan vakiintunut versio on [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Vaadittu viitatun arvon kohdistus.
    ///
    /// Tämän sisäisen osan vakiintunut versio on [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Haetaan staattinen merkkijono, joka sisältää tyypin nimen.
    ///
    /// Tämän sisäisen osan vakiintunut versio on [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Hankkii tunnisteen, joka on globaalisti yksilöllinen määritetylle tyypille.
    /// Tämä toiminto palauttaa saman arvon tyypille riippumatta siitä, missä crate: ssä sitä käytetään.
    ///
    ///
    /// Tämän sisäisen osan vakiintunut versio on [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Suojaus vaarallisille toiminnoille, joita ei voida koskaan suorittaa, jos `T` on asumaton:
    /// Tämä joko staattisesti joko panic tai ei tee mitään.
    ///
    /// Tällä luontaisella ei ole vakaata vastaavaa.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Suojaus vaarallisille toiminnoille, joita ei voida koskaan suorittaa, jos `T` ei salli nolla-alustusta: Tämä joko staattisesti joko panic tai ei tee mitään.
    ///
    ///
    /// Tällä luontaisella ei ole vakaata vastaavaa.
    pub fn assert_zero_valid<T>();

    /// Suojaus vaarallisille toiminnoille, joita ei voida koskaan suorittaa, jos `T`: llä on virheellisiä bittikuvioita: Tämä joko staattisesti joko panic tai ei tee mitään.
    ///
    ///
    /// Tällä luontaisella ei ole vakaata vastaavaa.
    pub fn assert_uninit_valid<T>();

    /// Hakee viitteen staattiseen `Location`: ään, joka osoittaa missä sitä kutsuttiin.
    ///
    /// Harkitse sen sijaan [`core::panic::Location::caller`](crate::panic::Location::caller): n käyttöä.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Siirtää arvon soveltamisalan ulkopuolelle ilman pudotusliimaa.
    ///
    /// Tämä koskee vain mallia [`mem::forget_unsized`];normaali `forget` käyttää sen sijaan `ManuallyDrop`: ää.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Tulkitsee uudelleen yhden tyyppisen arvon bitit uudeksi tyypiksi.
    ///
    /// Molempien tyyppien on oltava saman kokoisia.
    /// Alkuperäinen tai tulos eivät saa olla [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` on semanttisesti saman tyyppisen bitin siirtyminen toiseen.Se kopioi bitit lähdearvosta kohde-arvoon ja sitten unohtaa alkuperäisen.
    /// Se vastaa C: n `memcpy` konepellin alla, aivan kuten `transmute_copy`.
    ///
    /// Koska `transmute` on sivutoiminto, itse transmutoitujen arvojen * kohdistaminen ei ole huolenaihe.
    /// Kuten minkä tahansa muun toiminnon kohdalla, kääntäjä varmistaa jo, että sekä `T` että `U` on kohdennettu oikein.
    /// Kuitenkin, kun muunnetaan arvoja, jotka *osoittavat muualle*(kuten osoittimet, viitteet, laatikot ...), soittajan on varmistettava osoitettujen arvojen oikea kohdistus.
    ///
    /// `transmute` on **uskomattoman** vaarallinen.[undefined behavior][ub]: n aiheuttamiseksi tällä toiminnolla on valtava määrä tapoja.`transmute`: n pitäisi olla ehdoton viimeinen keino.
    ///
    /// [nomicon](../../nomicon/transmutes.html): llä on lisädokumentaatio.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// `transmute` on todella hyödyllinen muutamille asioille.
    ///
    /// Osoittimen muuttaminen toiminnon osoittimeksi.Tämä ei *ole* kannettava koneille, joissa toiminto-ja datan osoittimet ovat erikokoisia.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Eliniän pidentäminen tai muuttumattoman käyttöiän lyhentäminen.Tämä on edistynyt, erittäin vaarallinen Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Älä epätoivo: `transmute`: n monet käyttötavat voidaan saavuttaa muilla tavoin.
    /// Alla on yleisiä `transmute`-sovelluksia, jotka voidaan korvata turvallisemmilla rakenteilla.
    ///
    /// Raakan bytes(`&[u8]`) kääntäminen `u32`: ksi, `f64`: ksi jne.:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // käytä sen sijaan `u32::from_ne_bytes`: ää
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // tai määritä endianisuus `u32::from_le_bytes`-tai `u32::from_be_bytes`-koodilla
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Osoittimen muuttaminen `usize`: ksi:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Käytä sen sijaan `as`-valua
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// `*mut T`: n muuttaminen `&mut T`: ksi:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Käytä sen sijaan takaisinlainaa
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// `&mut T`: n muuttaminen `&mut U`: ksi:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Yhdistä nyt `as` ja lainanotto, huomaa, että `as`: n ketjutus ei ole transitiivinen
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// `&str`: n muuttaminen `&[u8]`: ksi:
    ///
    /// ```
    /// // tämä ei ole hyvä tapa tehdä tämä.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Voit käyttää `str::as_bytes`: ää
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Tai käytä vain tavumerkkijonoa, jos hallitset merkkijonon kirjainta
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// `Vec<&T>`: n muuttaminen `Vec<Option<&T>>`: ksi.
    ///
    /// Säiliön sisätyypin muuntamiseksi sinun on varmistettava, että et loukkaa mitään säiliön invariantteja.
    /// `Vec`: ssä tämä tarkoittaa, että sekä sisätyyppien koon *että kohdistuksen* on vastattava toisiaan.
    /// Muut säiliöt saattavat luottaa tyypin kokoon, kohdistukseen tai jopa `TypeId`: ään, jolloin muuntaminen ei ole ollenkaan mahdollista rikkomatta säiliön invarianteja.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // kloonaa vector, koska käytämme niitä myöhemmin uudelleen
    /// let v_clone = v_orig.clone();
    ///
    /// // Transmute-käyttö: tämä perustuu `Vec`: n määrittelemättömään data-asetteluun, mikä on huono idea ja voi aiheuttaa määrittelemättömän käyttäytymisen.
    /////
    /// // Se ei kuitenkaan ole kopiota.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Tämä on ehdotettu, turvallinen tapa.
    /// // Se kuitenkin kopioi koko vector: n uudeksi taulukoksi.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Tämä on "transmuting": n ja `Vec`: n oikea kopioimaton, vaarallinen tapa luottaa datan asetteluun.
    /// // Sen sijaan, että kutsuisimme kirjaimellisesti `transmute`, suoritamme osoittimen näyttämisen, mutta alkuperäisen sisätyypin (`&i32`) muuntamiseksi uudeksi (`Option<&i32>`): ksi tällä on kaikki samat varoitukset.
    /////
    /// // Yllä olevien tietojen lisäksi tutustu myös [`from_raw_parts`]-dokumentaatioon.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Päivitä tämä, kun vec_into_raw_parts on vakiintunut.
    ///     // Varmista, että alkuperäistä vector-laitetta ei pudota.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// `split_at_mut`: n käyttöönotto:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Tätä varten on useita tapoja, ja seuraavalla (transmute)-tavalla on useita ongelmia.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // ensimmäinen: transmute ei ole tyypiltään turvallista;se tarkistaa vain, että T ja
    ///         // U ovat samankokoisia.
    ///         // Toiseksi, täällä on kaksi muutettavaa viittausta, jotka osoittavat samaan muistiin.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Tämä poistaa tyypin turvallisuusongelmat;`&mut *` antaa* vain *`&mut T`: n `&mut T`: stä tai `* mut T`: stä.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // sinulla on kuitenkin vielä kaksi muutettavaa viittausta samaan muistiin.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Näin tavallinen kirjasto tekee sen.
    /// // Tämä on paras tapa, jos sinun on tehtävä jotain tällaista
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Tällä on nyt kolme muutettavaa viittausta, jotka osoittavat samaan muistiin.`slice`, arvo ret.0 ja arvo ret.1.
    ///         // `slice` ei koskaan käytetä `let ptr = ...`: n jälkeen, joten sitä voidaan pitää "dead": nä, ja siksi sinulla on vain kaksi todellista muutettavaa osaa.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Vaikka tämä tekee sisäisestä const: sta vakaan, meillä on joitain mukautettuja koodeja const fn: ssä
    // tarkastukset, jotka estävät sen käytön `const fn`: ssä.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Palauttaa arvon `true`, jos todellinen `T`-tyyppinen tyyppi vaatii pisaraliiman;palauttaa arvon `false`, jos `T`: lle annettu todellinen tyyppi toteuttaa `Copy`: n.
    ///
    ///
    /// Jos varsinainen tyyppi ei vaadi pudotusliimaa eikä toteuta `Copy`: ää, tämän toiminnon palautusarvo on määrittelemätön.
    ///
    /// Tämän sisäisen osan vakiintunut versio on [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Laskee siirtymän osoittimesta.
    ///
    /// Tämä toteutetaan luontaisena, jotta vältetään muuntaminen kokonaisluvuksi ja kokonaisluvuksi, koska muuntaminen heittäisi aliaksen tiedot pois.
    ///
    /// # Safety
    ///
    /// Sekä aloitus-että tuloksena olevan osoittimen on oltava joko rajattuina tai yksi tavu ohitetun objektin lopun ohi.
    /// Jos jompikumpi osoitin on rajojen ulkopuolella tai esiintyy aritmeettista ylivuotoa, palautetun arvon jatkuva käyttö johtaa määrittelemättömään käyttäytymiseen.
    ///
    ///
    /// Tämän sisäisen osan vakiintunut versio on [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Laskee siirtymän osoittimesta, joka voi kääriä.
    ///
    /// Tämä toteutetaan luontaisena, jotta vältetään muuntaminen kokonaisluvuksi ja siitä, koska muunnos estää tiettyjä optimointeja.
    ///
    /// # Safety
    ///
    /// Toisin kuin sisäinen `offset`, tämä luonnostaan ei rajoita syntynyttä osoitinta osoittamaan allokoidun objektin päähän tai yhden tavun ohi, ja se kietoutuu kahden komplementtiaritmeettiseen.
    /// Tuloksena oleva arvo ei välttämättä ole kelvollinen käytettäväksi muistin todelliseen käyttöön.
    ///
    /// Tämän sisäisen osan vakiintunut versio on [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Vastaa asianmukaista sisäistä `llvm.memcpy.p0i8.0i8.*`: ää, koko `count`*`size_of::<T>()` ja suunta
    ///
    /// `min_align_of::<T>()`
    ///
    /// Haihtuvan parametrin arvoksi on asetettu `true`, joten sitä ei optimoida, ellei koko ole nolla.
    ///
    /// Tällä luontaisella ei ole vakaata vastaavaa.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Vastaa asianmukaista sisäistä `llvm.memmove.p0i8.0i8.*`: ää, koko `count* size_of::<T>()` ja suuntaus
    ///
    /// `min_align_of::<T>()`
    ///
    /// Haihtuvan parametrin arvoksi on asetettu `true`, joten sitä ei optimoida, ellei koko ole nolla.
    ///
    /// Tällä luontaisella ei ole vakaata vastaavaa.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Vastaa asianmukaista sisäistä `llvm.memset.p0i8.*`: ää, koko `count* size_of::<T>()` ja suuntaus `min_align_of::<T>()`.
    ///
    ///
    /// Haihtuvan parametrin arvoksi on asetettu `true`, joten sitä ei optimoida, ellei koko ole nolla.
    ///
    /// Tällä luontaisella ei ole vakaata vastaavaa.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Suorittaa haihtuvaa kuormitusta `src`-osoittimesta.
    ///
    /// Tämän sisäisen osan vakiintunut versio on [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Suorittaa haihtuvan varastoinnin `dst`-osoittimeen.
    ///
    /// Tämän sisäisen osan vakiintunut versio on [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Suorittaa haihtuvaa kuormitusta `src`-osoittimesta Osoitinta ei tarvitse kohdistaa.
    ///
    ///
    /// Tällä luontaisella ei ole vakaata vastaavaa.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Suorittaa haihtuvan varastoinnin `dst`-osoittimeen.
    /// Osoitinta ei tarvitse kohdistaa.
    ///
    /// Tällä luontaisella ei ole vakaata vastaavaa.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Palauttaa `f32`: n neliöjuuren
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Palauttaa `f64`: n neliöjuuren
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Nostaa `f32`: n kokonaisluvuksi.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Nostaa `f64`: n kokonaisluvuksi.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Palauttaa `f32`: n sinin.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Palauttaa `f64`: n sinin.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Palauttaa `f32`: n kosinin.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Palauttaa `f64`: n kosinin.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Nostaa `f32`: n `f32`-tehoksi.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Nostaa `f64`: n `f64`-tehoksi.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Palauttaa `f32`: n eksponentin.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Palauttaa `f64`: n eksponentin.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Palauttaa 2 korotettuna `f32`: n tehoon.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Palauttaa 2 korotettuna `f64`: n tehoon.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Palauttaa `f32`: n luonnollisen logaritmin.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Palauttaa `f64`: n luonnollisen logaritmin.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Palauttaa `f32`: n 10 peruslogaritmin.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Palauttaa `f64`: n 10 peruslogaritmin.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Palauttaa `f32`: n perustason 2 logaritmin.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Palauttaa `f64`: n perustason 2 logaritmin.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Palauttaa `a * b + c` `f32`-arvoille.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Palauttaa `a * b + c` `f64`-arvoille.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Palauttaa `f32`: n absoluuttisen arvon.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Palauttaa `f64`: n absoluuttisen arvon.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Palauttaa vähintään kahden `f32`-arvon.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Palauttaa vähintään kahden `f64`-arvon.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Palauttaa kahden `f32`-arvon maksimimäärän.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Palauttaa kahden `f64`-arvon maksimimäärän.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Kopioi merkin `y`: stä `x`: ään `f32`-arvoille.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Kopioi merkin `y`: stä `x`: ään `f64`-arvoille.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Palauttaa suurimman kokonaisluvun, joka on pienempi tai yhtä suuri kuin `f32`.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Palauttaa suurimman kokonaisluvun, joka on pienempi tai yhtä suuri kuin `f64`.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Palauttaa pienimmän kokonaisluvun, joka on suurempi tai yhtä suuri kuin `f32`.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Palauttaa pienimmän kokonaisluvun, joka on suurempi tai yhtä suuri kuin `f64`.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Palauttaa `f32`: n kokonaisluvun osan.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Palauttaa `f64`: n kokonaisluvun osan.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Palauttaa lähimmän kokonaisluvun `f32`: ksi.
    /// Voi nostaa epätarkan liukulukuisen poikkeuksen, jos argumentti ei ole kokonaisluku.
    pub fn rintf32(x: f32) -> f32;
    /// Palauttaa lähimmän kokonaisluvun `f64`: ksi.
    /// Voi nostaa epätarkan liukulukuisen poikkeuksen, jos argumentti ei ole kokonaisluku.
    pub fn rintf64(x: f64) -> f64;

    /// Palauttaa lähimmän kokonaisluvun `f32`: ksi.
    ///
    /// Tällä luontaisella ei ole vakaata vastaavaa.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Palauttaa lähimmän kokonaisluvun `f64`: ksi.
    ///
    /// Tällä luontaisella ei ole vakaata vastaavaa.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Palauttaa lähimmän kokonaisluvun `f32`: ksi.Pyöristää puolivälitapaukset pois nollasta.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Palauttaa lähimmän kokonaisluvun `f64`: ksi.Pyöristää puolivälitapaukset pois nollasta.
    ///
    /// Tämän luontaisen vakiintunut versio on
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Float-lisäys, joka mahdollistaa optimoinnin algebrallisiin sääntöihin perustuen.
    /// Voi olettaa, että panokset ovat rajallisia.
    ///
    /// Tällä luontaisella ei ole vakaata vastaavaa.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Kelluva vähennyslasku, joka mahdollistaa optimoinnin algebrallisiin sääntöihin perustuen.
    /// Voi olettaa, että panokset ovat rajallisia.
    ///
    /// Tällä luontaisella ei ole vakaata vastaavaa.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Kelluva kertolasku, joka mahdollistaa optimoinnin algebrallisiin sääntöihin perustuen.
    /// Voi olettaa, että panokset ovat rajallisia.
    ///
    /// Tällä luontaisella ei ole vakaata vastaavaa.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Float-jako, joka mahdollistaa optimoinnin algebrallisiin sääntöihin perustuen.
    /// Voi olettaa, että panokset ovat rajallisia.
    ///
    /// Tällä luontaisella ei ole vakaata vastaavaa.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Kelluva loppuosa, joka mahdollistaa optimoinnin algebrallisiin sääntöihin perustuen.
    /// Voi olettaa, että panokset ovat rajallisia.
    ///
    /// Tällä luontaisella ei ole vakaata vastaavaa.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Muunna LLVM: n fptoui/fptosi: llä, joka voi palauttaa undef-arvon alueen ulkopuolella oleville arvoille
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Vakautettu [`f32::to_int_unchecked`] ja [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Palauttaa kokonaislukutyypissä `T` asetettujen bittien lukumäärän
    ///
    /// Tämän luontaisen aineen stabiloidut versiot ovat saatavissa kokonaislukuprimitiiveillä `count_ones`-menetelmällä.
    /// Esimerkiksi,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Palauttaa johtamattomien bittien määrän (zeroes) kokonaislukutyypissä `T`.
    ///
    /// Tämän luontaisen aineen stabiloidut versiot ovat saatavissa kokonaislukuprimitiiveillä `leading_zeros`-menetelmällä.
    /// Esimerkiksi,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `x`, jonka arvo on `0`, palauttaa `T`: n bittileveyden.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Kuten `ctlz`, mutta erittäin vaarallinen, koska se palauttaa `undef`: n, kun hänelle annetaan `x`, jonka arvo on `0`.
    ///
    ///
    /// Tällä luontaisella ei ole vakaata vastaavaa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Palauttaa jäljellä olevien kuittaamattomien bittien määrän (zeroes) kokonaislukutyypissä `T`.
    ///
    /// Tämän luontaisen aineen stabiloidut versiot ovat saatavissa kokonaislukuprimitiiveillä `trailing_zeros`-menetelmällä.
    /// Esimerkiksi,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `x`, jonka arvo on `0`, palauttaa `T`: n bittileveyden:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Kuten `cttz`, mutta erittäin vaarallinen, koska se palauttaa `undef`: n, kun hänelle annetaan `x`, jonka arvo on `0`.
    ///
    ///
    /// Tällä luontaisella ei ole vakaata vastaavaa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Kääntää tavut kokonaislukutyypissä `T`.
    ///
    /// Tämän luontaisen aineen stabiloidut versiot ovat saatavissa kokonaislukuprimitiiveillä `swap_bytes`-menetelmällä.
    /// Esimerkiksi,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Kääntää bitit kokonaislukutyypissä `T`.
    ///
    /// Tämän luontaisen aineen stabiloidut versiot ovat saatavissa kokonaislukuprimitiiveillä `reverse_bits`-menetelmällä.
    /// Esimerkiksi,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Suorittaa tarkistetun kokonaisluvun lisäyksen.
    ///
    /// Tämän luontaisen aineen stabiloidut versiot ovat saatavissa kokonaislukuprimitiiveillä `overflowing_add`-menetelmällä.
    /// Esimerkiksi,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Suorittaa tarkistetun kokonaisluvun vähennyksen
    ///
    /// Tämän luontaisen aineen stabiloidut versiot ovat saatavissa kokonaislukuprimitiiveillä `overflowing_sub`-menetelmällä.
    /// Esimerkiksi,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Suorittaa tarkistetun kokonaisluvun kertomisen
    ///
    /// Tämän luontaisen aineen stabiloidut versiot ovat saatavissa kokonaislukuprimitiiveillä `overflowing_mul`-menetelmällä.
    /// Esimerkiksi,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Suorittaa tarkan jaon, mikä johtaa määrittelemättömään käyttäytymiseen missä `x % y != 0` tai `y == 0` tai `x == T::MIN && y == -1`
    ///
    ///
    /// Tällä luontaisella ei ole vakaata vastaavaa.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Suorittaa tarkistamattoman jaon, mikä johtaa määrittelemättömään käyttäytymiseen, kun `y == 0` tai `x == T::MIN && y == -1`
    ///
    ///
    /// Tämän sisäosan turvallisia kääreitä on saatavana kokonaislukuprimitiiveille `checked_div`-menetelmällä.
    /// Esimerkiksi,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Palauttaa tarkistamattoman jaon loppuosan, mikä johtaa määrittelemättömään käyttäytymiseen, kun `y == 0` tai `x == T::MIN && y == -1`
    ///
    ///
    /// Tämän sisäosan turvallisia kääreitä on saatavana kokonaislukuprimitiiveille `checked_rem`-menetelmällä.
    /// Esimerkiksi,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Suorittaa tarkistamattoman vasemman siirron, mikä johtaa määrittelemättömään käyttäytymiseen, kun `y < 0` tai `y >= N`, jossa N on T: n leveys bitteinä.
    ///
    ///
    /// Tämän sisäosan turvallisia kääreitä on saatavana kokonaislukuprimitiiveille `checked_shl`-menetelmällä.
    /// Esimerkiksi,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Suorittaa tarkistamattoman oikean siirtymän, mikä johtaa määrittelemättömään käyttäytymiseen, kun `y < 0` tai `y >= N`, missä N on T: n leveys bitteinä.
    ///
    ///
    /// Tämän sisäosan turvallisia kääreitä on saatavana kokonaislukuprimitiiveille `checked_shr`-menetelmällä.
    /// Esimerkiksi,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Palauttaa tarkistamattoman lisäyksen tuloksen, mikä johtaa määrittelemättömään käyttäytymiseen, kun `x + y > T::MAX` tai `x + y < T::MIN`.
    ///
    ///
    /// Tällä luontaisella ei ole vakaata vastaavaa.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Palauttaa tarkastamattoman vähennyksen tuloksen, mikä johtaa määrittelemättömään käyttäytymiseen, kun `x - y > T::MAX` tai `x - y < T::MIN`.
    ///
    ///
    /// Tällä luontaisella ei ole vakaata vastaavaa.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Palauttaa tarkistamattoman kertolaskun tuloksen, mikä johtaa määrittelemättömään käyttäytymiseen, kun `x *y > T::MAX` tai `x* y < T::MIN`.
    ///
    ///
    /// Tällä luontaisella ei ole vakaata vastaavaa.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Suorittaa kiertämistä vasemmalle.
    ///
    /// Tämän luontaisen aineen stabiloidut versiot ovat saatavissa kokonaislukuprimitiiveillä `rotate_left`-menetelmällä.
    /// Esimerkiksi,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Suorita kiertää oikealle.
    ///
    /// Tämän luontaisen aineen stabiloidut versiot ovat saatavissa kokonaislukuprimitiiveillä `rotate_right`-menetelmällä.
    /// Esimerkiksi,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Palauttaa (a + b) mod 2 <sup>N</sup>, jossa N on T: n leveys bitteinä.
    ///
    /// Tämän luontaisen aineen stabiloidut versiot ovat saatavissa kokonaislukuprimitiiveillä `wrapping_add`-menetelmällä.
    /// Esimerkiksi,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Palauttaa (a, b) mod 2 <sup>N</sup>, jossa N on T: n leveys bitteinä.
    ///
    /// Tämän luontaisen aineen stabiloidut versiot ovat saatavissa kokonaislukuprimitiiveillä `wrapping_sub`-menetelmällä.
    /// Esimerkiksi,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Palauttaa (a * b) mod 2 <sup>N</sup>, jossa N on T: n leveys bitteinä.
    ///
    /// Tämän luontaisen aineen stabiloidut versiot ovat saatavissa kokonaislukuprimitiiveillä `wrapping_mul`-menetelmällä.
    /// Esimerkiksi,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Laskee `a + b`, kyllästetty numeerisilla rajoilla.
    ///
    /// Tämän luontaisen aineen stabiloidut versiot ovat saatavissa kokonaislukuprimitiiveillä `saturating_add`-menetelmällä.
    /// Esimerkiksi,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Laskee `a - b`, kyllästetty numeerisilla rajoilla.
    ///
    /// Tämän luontaisen aineen stabiloidut versiot ovat saatavissa kokonaislukuprimitiiveillä `saturating_sub`-menetelmällä.
    /// Esimerkiksi,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Palauttaa muunnoksen erottelijan arvon 'v': ssä;
    /// jos `T`: llä ei ole eroa, palauttaa `0`.
    ///
    /// Tämän sisäisen osan vakiintunut versio on [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Palauttaa `T`-tyypin muunnelmien määrän `usize`: ksi;
    /// jos `T`: llä ei ole muunnelmia, palauttaa `0`.Asuttamattomat variantit lasketaan.
    ///
    /// Tämän luontaisen tuotteen vakiintunut versio on [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust: n "try catch"-rakenne, joka kutsuu funktiosoittimen `try_fn` datan osoittimella `data`.
    ///
    /// Kolmas argumentti on funktio, jota kutsutaan, jos panic tapahtuu.
    /// Tämä toiminto vie datan osoittimen ja osoittimen kiinniotettuun kohdekohtaiseen poikkeuskohteeseen.
    ///
    /// Lisätietoja on kääntäjän lähteessä sekä std: n saalis toteutuksessa.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Lähettää `!nontemporal`-myymälän LLVM: n mukaan (katso heidän asiakirjaansa).
    /// Luultavasti ei koskaan vakaa.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Katso lisätietoja `<*const T>::offset_from`: n dokumentaatiosta.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Katso lisätietoja `<*const T>::guaranteed_eq`: n dokumentaatiosta.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Katso lisätietoja `<*const T>::guaranteed_ne`: n dokumentaatiosta.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Kohdista kokoamisajankohtana.Ei pitäisi kutsua ajon aikana.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Jotkut toiminnot on määritelty tässä, koska ne on vahingossa tehty saataville tässä moduulissa vakaana.
// Katso <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` kuuluu myös tähän luokkaan, mutta sitä ei voi kääriä, koska tarkistetaan, että `T` ja `U` ovat samankokoisia.)
//

/// Tarkistaa, onko `ptr` kohdistettu oikein `align_of::<T>()`: ään nähden.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Kopioi `count *size_of::<T>()`-tavut tiedostosta `src`-`dst`.Lähde ja kohde eivät saa* olla päällekkäisiä.
///
/// Käytä sen sijaan muistialueilla, jotka saattavat olla päällekkäisiä, [`copy`].
///
/// `copy_nonoverlapping` on semanttisesti vastaava kuin C: n [`memcpy`], mutta argumenttijärjestys vaihdetaan.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Käyttäytymistä ei ole määritelty, jos jotakin seuraavista ehdoista rikotaan:
///
/// * `src` on oltava [valid], kun luetaan `count * size_of::<T>()`-tavuja.
///
/// * `dst` on oltava [valid], kun kirjoitetaan `count * size_of::<T>()`-tavuja.
///
/// * Sekä `src` että `dst` on kohdistettava oikein.
///
/// * Muistialue, joka alkaa `src`: stä ja jonka koko on `count *
///   koko: :<T>() `tavujen ei *saa* olla päällekkäisiä muistikohdan kanssa, joka alkaa `dst`: stä samankokoisina.
///
/// Kuten [`read`], `copy_nonoverlapping` luo `T`: n bittikopion riippumatta siitä, onko `T` [`Copy`].
/// Jos `T` ei ole [`Copy`], voidaan [violate memory safety][read-ownership] käyttää *molempia* arvoja alueella `*src` alkavalla alueella ja alueella `* dst` alkavalla alueella.
///
///
/// Huomaa, että vaikka tosiasiallisesti kopioitu koko (`count * size_of: :<T>()`) on `0`, osoittimien on oltava ei-NULL ja oikein kohdistettuja.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Ota [`Vec::append`] käyttöön manuaalisesti:
///
/// ```
/// use std::ptr;
///
/// /// Siirtää kaikki `src`: n elementit kohtaan `dst`, jolloin `src` jää tyhjäksi.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Varmista, että `dst`: llä on riittävästi kapasiteettia koko `src`: n pitämiseen.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Offset-kutsu on aina turvallista, koska `Vec` ei koskaan allokoi enempää kuin `isize::MAX`-tavua.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Katkaise `src` pudottamatta sen sisältöä.
///         // Teemme tämän ensin välttääksemme ongelmia, jos jokin panics: n alapuolella.
///         src.set_len(0);
///
///         // Nämä kaksi aluetta eivät voi olla päällekkäisiä, koska muutettavissa olevat viitteet eivät ole aliaksia, ja kaksi eri vektoria eivät voi omistaa samaa muistia.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Ilmoita `dst`: lle, että se sisältää nyt `src`: n sisällön.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Suorita nämä tarkastukset vain ajon aikana
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Ei paniikkia pitämään codegen-vaikutuksia pienempinä.
        abort();
    }*/

    // TURVALLISUUS: `copy_nonoverlapping`: n turvasopimuksen on oltava
    // soittaja tukee.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Kopioi `count * size_of::<T>()`-tavut tiedostosta `src`-`dst`.Lähde ja kohde voivat olla päällekkäisiä.
///
/// Jos lähde ja kohde * eivät koskaan päällekkäin, [`copy_nonoverlapping`]: ää voidaan käyttää sen sijaan.
///
/// `copy` on semanttisesti vastaava kuin C: n [`memmove`], mutta argumenttijärjestys vaihdetaan.
/// Kopiointi tapahtuu ikään kuin tavut kopioitiin `src`: stä väliaikaiseen ryhmään ja sitten kopioitaisiin ryhmästä `dst`: ään.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Käyttäytymistä ei ole määritelty, jos jotakin seuraavista ehdoista rikotaan:
///
/// * `src` on oltava [valid], kun luetaan `count * size_of::<T>()`-tavuja.
///
/// * `dst` on oltava [valid], kun kirjoitetaan `count * size_of::<T>()`-tavuja.
///
/// * Sekä `src` että `dst` on kohdistettava oikein.
///
/// Kuten [`read`], `copy` luo `T`: n bittikopion riippumatta siitä, onko `T` [`Copy`].
/// Jos `T` ei ole [`Copy`], voidaan [violate memory safety][read-ownership] käyttää sekä arvoja alueella `*src` alkavalla alueella että alueella `* dst` alkavaa aluetta.
///
///
/// Huomaa, että vaikka tosiasiallisesti kopioitu koko (`count * size_of: :<T>()`) on `0`, osoittimien on oltava ei-NULL ja oikein kohdistettuja.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Luo Rust vector tehokkaasti vaarallisesta puskurista:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` on kohdistettava oikein tyyppinsä ja nollan ulkopuolelle.
/// /// * `ptr` on oltava voimassa `elts`-tyyppisten `T`-vierekkäisten elementtien lukemille.
/// /// * Näitä elementtejä ei saa käyttää tämän toiminnon kutsumisen jälkeen, ellei `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // TURVALLISUUS: Edellytys varmistaa, että lähde on linjassa ja voimassa,
///     // ja `Vec::with_capacity` varmistaa, että meillä on käytettävissä oleva tila niiden kirjoittamiseen.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // TURVALLISUUS: Loimme sen näin paljon kapasiteetilla aiemmin,
///     // ja edellinen `copy` on alustanut nämä elementit.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Suorita nämä tarkastukset vain ajon aikana
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Ei paniikkia pitämään codegen-vaikutuksia pienempinä.
        abort();
    }*/

    // TURVALLISUUS: soittajan on noudatettava `copy`: n turvasopimusta.
    unsafe { copy(src, dst, count) }
}

/// Asettaa `count * size_of::<T>()`-tavun muistin alkaen `dst`-`val`.
///
/// `write_bytes` on samanlainen kuin C: n [`memset`], mutta asettaa `count * size_of::<T>()`-tavuiksi `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Käyttäytymistä ei ole määritelty, jos jotakin seuraavista ehdoista rikotaan:
///
/// * `dst` on oltava [valid], kun kirjoitetaan `count * size_of::<T>()`-tavuja.
///
/// * `dst` on kohdistettava oikein.
///
/// Lisäksi soittajan on varmistettava, että `count * size_of::<T>()`-tavujen kirjoittaminen tietylle muistialueelle antaa kelvollisen arvon `T`.
/// `T`: ksi kirjoitetun muistialueen käyttö, joka sisältää virheellisen arvon `T`, on määrittelemätöntä toimintaa.
///
/// Huomaa, että vaikka tosiasiallisesti kopioitu koko (`count * size_of: :<T>()`) on `0`, osoittimen on oltava ei-NULL ja oikein kohdistettu.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Peruskäyttö:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Virheellisen arvon luominen:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Vuotaa aiemmin pidetyn arvon korvaamalla `Box<T>`: n nollaosoittimella.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Tässä vaiheessa `v`: n käyttö tai pudottaminen johtaa määrittelemättömään käyttäytymiseen.
/// // drop(v); // ERROR
///
/// // Jopa `v` "uses": n vuotaminen, ja siten on määrittelemätöntä käyttäytymistä.
/// // mem::forget(v); // ERROR
///
/// // Itse asiassa `v` on virheellinen perustyyppisten asetteluvarianttien mukaan, joten *kaikki* sitä koskettavat * toiminnot ovat määrittelemätöntä käyttäytymistä.
/////
/// // olkoon v2 =v;//VIRHE
///
/// unsafe {
///     // Anna sen sijaan antaa kelvollinen arvo
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Nyt laatikko on kunnossa
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // TURVALLISUUS: soittajan on noudatettava `write_bytes`: n turvasopimusta.
    unsafe { write_bytes(dst, val, count) }
}