//! Laiska-arvot ja staattisen datan alustaminen kerran.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// Solu, johon voi kirjoittaa vain kerran.
///
/// Toisin kuin `RefCell`, `OnceCell` tarjoaa vain jaetut `&T`-viitteet sen arvoon.
/// Toisin kuin `Cell`, `OnceCell` ei vaadi arvon kopiointia tai korvaamista sen käyttämiseksi.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // Variantti: kirjoitettu enintään kerran.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// Luo uuden tyhjän solun.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// Hakee viittauksen alla olevaan arvoon.
    ///
    /// Palauttaa `None`, jos solu on tyhjä.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // TURVALLISUUS: Turvallinen "sisäisen" invarianttin vuoksi
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// Hakee muutettavissa olevan viitteen alla olevaan arvoon.
    ///
    /// Palauttaa `None`, jos solu on tyhjä.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // TURVALLISUUS: Turvallinen, koska meillä on ainutlaatuinen pääsy
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// Asettaa solun sisällöksi `value`.
    ///
    /// # Errors
    ///
    /// Tämä menetelmä palauttaa `Ok(())`, jos solu oli tyhjä, ja `Err(value)`, jos se oli täynnä.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // TURVALLISUUS: Turvallinen, koska meillä ei voi olla päällekkäisiä vaihtuvia lainoja
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // TURVALLISUUS: Tämä on ainoa paikka, jossa asetamme lähtöpaikan, ei kilpailuja
        // reentrancy/concurrency: n takia ovat mahdollisia, ja olemme tarkistaneet, että paikka on tällä hetkellä `None`, joten tämä kirjoitus ylläpitää `sisäisen 'invarianttia.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// Hakee solun sisällön ja alustaa sen `f`: llä, jos solu oli tyhjä.
    ///
    /// # Panics
    ///
    /// Jos `f` panics, panic levitetään soittajalle ja solu pysyy alustamattomana.
    ///
    ///
    /// On virhe alustaa solu uudelleen `f`: stä.Tällöin saadaan panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// Hakee solun sisällön ja alustaa sen `f`: llä, jos solu oli tyhjä.
    /// Jos solu oli tyhjä ja `f` epäonnistui, virhe palautetaan.
    ///
    /// # Panics
    ///
    /// Jos `f` panics, panic levitetään soittajalle ja solu pysyy alustamattomana.
    ///
    ///
    /// On virhe alustaa solu uudelleen `f`: stä.Tällöin saadaan panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // Huomaa, että *jotkut* uudelleenkäynnistyksen alustusmuodot saattavat johtaa UB: hen (katso `reentrant_init`-testi).
        // Uskon, että tämän `assert`: n poistaminen pitäen `set/get`: n pitäminen olisi järkevää, mutta panic: lle näyttää paremmalta kuin vanhan arvon käyttäminen hiljaa.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// Kuluttaa solun palauttaen kääritty arvo.
    ///
    /// Palauttaa `None`, jos solu oli tyhjä.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // Koska `into_inner` ottaa `self`: n arvon, kääntäjä tarkistaa staattisesti, ettei sitä ole tällä hetkellä lainattu.
        // Joten on turvallista siirtyä pois `Option<T>`: stä.
        self.inner.into_inner()
    }

    /// Ottaa arvon tästä `OnceCell`: stä ja siirtää sen takaisin alustamattomaan tilaan.
    ///
    /// Ei vaikutusta ja palauttaa `None`: n, jos `OnceCell`: ää ei ole alustettu.
    ///
    /// Turvallisuus taataan vaatimalla muutettava viite.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// Arvo, joka alustetaan ensimmäisen käytön yhteydessä.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   valmis alustamaan
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// Luo uuden laiskan arvon annetulla alustustoiminnolla.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// Pakottaa tämän laiskan arvon arvioinnin ja palauttaa viitteen tulokseen.
    ///
    ///
    /// Tämä vastaa `Deref` impl-mallia, mutta on eksplisiittinen.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// Luo uuden laiskan arvon käyttämällä `Default`: ää alustustoimintona.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}