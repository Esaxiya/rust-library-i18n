//! Määrittää `IntoIter`: n omistaman iteraattorin matriiseille.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// By-value [array]-iteraattori.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Tämä on taulukko, jota toistamme.
    ///
    /// Elementtejä, joiden hakemisto on `i`, jossa `alive.start <= i < alive.end`, ei ole vielä saatu ja ne ovat kelvollisia taulukon merkintöjä.
    /// Elementit, joiden indeksit ovat `i < alive.start` tai `i >= alive.end`, on jo saatu, eikä niitä saa enää käyttää!Nuo kuolleet elementit saattavat olla jopa täysin alustamattomassa tilassa!
    ///
    ///
    /// Joten invariants ovat:
    /// - `data[alive]` on elossa (eli sisältää kelvollisia elementtejä)
    /// - `data[..alive.start]` ja `data[alive.end..]` ovat kuolleet (eli elementit oli jo luettu eikä niihin saa enää koskettaa!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// `data`: n elementit, joita ei ole vielä saatu.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Luo uuden iteraattorin annetulle `array`: lle.
    ///
    /// *Huomaa*: Tämä menetelmä saattaa olla vanhentunut future: ssä [`IntoIterator` is implemented for arrays][array-into-iter]: n jälkeen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // `value`: n tyyppi on tässä `i32` `&i32`: n sijaan
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // TURVALLISUUS: Transmute tässä on todella turvallista.`MaybeUninit`: n asiakirjat
        // promise:
        //
        // > `MaybeUninit<T>` taataan, että sillä on sama koko ja suunta
        // > kuten `T`.
        //
        // Asiakirjoissa näytetään jopa muunnos `MaybeUninit<T>`-ryhmästä `T`-ryhmään.
        //
        //
        // Tällä tavoin tämä alustaminen tyydyttää invarianteja.

        // FIXME(LukasKalbertodt): käytä `mem::transmute`: ää täällä, kun se toimii const-geneeristen tuotteiden kanssa:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Siihen saakka voimme käyttää `mem::transmute_copy`: ää bittikopion luomiseen toisen tyyppisenä, unohda sitten `array`, jotta sitä ei pudoteta.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Palauttaa muuttumattoman osan kaikista alkioista, joita ei ole vielä saatu.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // TURVALLISUUS: Tiedämme, että kaikki `alive`: n elementit on alustettu oikein.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Palauttaa muutettavan osion kaikista elementeistä, joita ei ole vielä tuotettu.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // TURVALLISUUS: Tiedämme, että kaikki `alive`: n elementit on alustettu oikein.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Hanki seuraava hakemisto edestä.
        //
        // `alive.start`: n lisääminen yhdellä ylläpitää `alive`: n muuttujaa.
        // Tämän muutoksen takia elävä vyöhyke ei kuitenkaan ole hetkeksi enää `data[alive]`, vaan `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Lue elementti taulukosta.
            // TURVALLISUUS: `idx` on hakemisto alueen entiselle "alive"-alueelle
            // taulukko.Tämän elementin lukeminen tarkoittaa, että `data[idx]` katsotaan kuolleeksi (eli älä kosketa).
            // Koska `idx` oli elävän vyöhykkeen alku, elävä vyöhyke on nyt jälleen `data[alive]`, palauttaen kaikki invariantit.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Hanki seuraava hakemisto takaa.
        //
        // `alive.end`: n pienentäminen yhdellä ylläpitää `alive`: n muuttujaa.
        // Tämän muutoksen takia elävä vyöhyke ei kuitenkaan ole hetkeksi enää `data[alive]`, vaan `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Lue elementti taulukosta.
            // TURVALLISUUS: `idx` on hakemisto alueen entiselle "alive"-alueelle
            // taulukko.Tämän elementin lukeminen tarkoittaa, että `data[idx]` katsotaan kuolleeksi (eli älä kosketa).
            // Koska `idx` oli elävän vyöhykkeen loppu, elävä vyöhyke on nyt taas `data[alive]`, palauttaen kaikki invariantit.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // TURVALLISUUS: Tämä on turvallista: `as_mut_slice` palauttaa täsmälleen osa-osan
        // elementeistä, joita ei ole vielä siirretty pois ja jotka ovat vielä pudottamatta.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Ei koskaan tyhjennä invariantin `elossa. Aloita <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Iteraattori todellakin ilmoittaa oikean pituuden.
// "alive"-elementtien määrä (joka saadaan edelleen) on alueen `alive` pituus.
// Tämän alueen pituutta vähennetään joko `next` tai `next_back`.
// Se lasketaan aina 1: llä näissä menetelmissä, mutta vain, jos `Some(_)` palautetaan.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Huomaa, että meidän ei oikeastaan tarvitse sovittaa täsmälleen samaa elävää aluetta, joten voimme vain kloonata offsetiin 0 `self`: n sijainnista riippumatta.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Kloonaa kaikki elävät alkuaineet.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Kirjoita klooni uuteen ryhmään ja päivitä sitten sen elävä alue.
            // Jos kloonataan panics, pudotamme edelliset kohteet oikein.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Tulosta vain ne elementit, joita ei vielä tuotettu: emme voi enää käyttää tuotettuja elementtejä.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}