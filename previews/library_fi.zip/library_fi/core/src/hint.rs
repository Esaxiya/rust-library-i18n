#![stable(feature = "core_hint", since = "1.27.0")]

//! Vihjeitä kääntäjälle, joka vaikuttaa siihen, miten koodi tulisi lähettää tai optimoida.
//! Vihjeitä voi olla käännösaika tai ajonaika.

use crate::intrinsics;

/// Ilmoittaa kääntäjälle, että koodin tätä kohtaa ei voida saavuttaa, mikä mahdollistaa lisäoptimoinnin.
///
/// # Safety
///
/// Tämän toiminnon saavuttaminen on täysin *määrittelemätöntä käyttäytymistä*(UB).Kääntäjä olettaa erityisesti, että kaikkia UB: tä ei saa koskaan tapahtua, ja poistaa siten kaikki haarat, jotka saavuttavat puhelun `unreachable_unchecked()`: lle.
///
/// Kuten kaikki UB-esiintymät, jos tämä oletus osoittautuu vääräksi, ts. `unreachable_unchecked()`-kutsu on todella saavutettavissa kaikkien mahdollisten ohjausvirtojen joukossa, kääntäjä käyttää väärää optimointistrategiaa ja saattaa joskus jopa vioittaa näennäisesti etuyhteydettömän koodin aiheuttaen vaikeita virheenkorjausongelmia.
///
///
/// Käytä tätä toimintoa vain, kun voit todistaa, että koodi ei koskaan soita sitä.
/// Muussa tapauksessa harkitse [`unreachable!`]-makron käyttöä, joka ei salli optimointia, mutta panic suoritettaessa.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` on aina positiivinen (ei nolla), joten `checked_div` ei koskaan palauta `None`: ää.
/////
///     // Siksi toinen branch ei ole tavoitettavissa.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // TURVALLISUUS: `intrinsics::unreachable`: n turvasopimus on tehtävä
    // soittajan pitää olla voimassa.
    unsafe { intrinsics::unreachable() }
}

/// Lähettää koneen käskyn ilmoittaakseen prosessorille, että se toimii varattu-odotuskierrossa ("linkouslukko").
///
/// Saatuaan spin-loop-signaalin prosessori voi optimoida käyttäytymisensä esimerkiksi säästämällä virtaa tai vaihtamalla hyper-ketjuja.
///
/// Tämä toiminto eroaa [`thread::yield_now`]: stä, joka antaa suoraan järjestelmän ajastimelle, kun taas `spin_loop` ei ole vuorovaikutuksessa käyttöjärjestelmän kanssa.
///
/// `spin_loop`: n yleinen käyttötapa on rajatun optimistisen kehruun toteuttaminen CAS-silmukassa synkronointiprimitiiveissä.
/// Prioriteetin kääntämisen kaltaisten ongelmien välttämiseksi on erittäin suositeltavaa, että linkoussilmukka lopetetaan lopullisen määrän iteraatioiden jälkeen ja sopiva estojärjestelmä on suoritettu.
///
///
/// **Huomaa**: Alustoilla, jotka eivät tue spin-loop-vihjeiden vastaanottamista, tämä toiminto ei tee mitään.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Jaettu atomiarvo, jota ketjut käyttävät koordinointiin
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Taustaketjussa asetamme lopulta arvon
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Tee töitä ja anna arvo elää
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Palataksemme nykyiseen säikeeseen, odotamme arvon asettamista
/// while !live.load(Ordering::Acquire) {
///     // Spin loop on vihje prosessorille, jota odotamme, mutta todennäköisesti ei kovin kauan
/////
///     hint::spin_loop();
/// }
///
/// // Arvo on nyt asetettu
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // TURVALLISUUS: `cfg`-attr varmistaa, että suoritamme tämän vain x86-kohteissa.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // TURVALLISUUS: `cfg`-attr varmistaa, että suoritamme tämän vain x86_64-kohteissa.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // TURVALLISUUS: `cfg`-attr varmistaa, että suoritamme tämän vain aarch64-kohteissa.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // TURVALLISUUS: `cfg`-attr varmistaa, että suoritamme tämän vain käsivarsiin
            // tukee v6-ominaisuutta.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Identiteettitoiminto, joka *__ vihjaa __* kääntäjälle olemaan mahdollisimman pessimistinen siitä, mitä `black_box` voisi tehdä.
///
/// Toisin kuin [`std::convert::identity`], Rust-kääntäjää kannustetaan olettamaan, että `black_box` voi käyttää `dummy`: ää kaikilla mahdollisilla pätevillä tavoilla, joihin Rust-koodi sallitaan, lisäämättä kutsukoodiin määrittelemätöntä käyttäytymistä.
///
/// Tämän ominaisuuden ansiosta `black_box` on hyödyllinen kirjoitettaessa koodia, jossa tiettyjä optimointeja, kuten vertailuarvoja, ei haluta.
///
/// Huomaa kuitenkin, että `black_box` toimitetaan (ja voidaan toimittaa) vain "best-effort"-pohjalta.Se, missä määrin se voi estää optimoinnit, voi vaihdella käytetyn alustan ja koodigeenien taustajärjestelmän mukaan.
/// Ohjelmat eivät voi luottaa `black_box`: ään *oikeellisuuden* suhteen millään tavalla.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Meidän on "use"-argumentti jollain tavalla LLVM ei voi tutkia itseään, ja sitä tukevilla kohteilla voimme tyypillisesti hyödyntää sisäistä kokoonpanoa tähän.
    // LLVM: n tulkinta sisäisestä kokoonpanosta on, että se on hyvin musta laatikko.
    // Tämä ei ole suurin toteutus, koska se todennäköisesti poistaa enemmän kuin haluamme, mutta se on toistaiseksi tarpeeksi hyvä.
    //
    //

    #[cfg(not(miri))] // Tämä on vain vihje, joten on hyvä ohittaa Miri.
    // TURVALLISUUS: sisäinen kokoonpano on ei-op.
    unsafe {
        // FIXME: `asm!`: ää ei voi käyttää, koska se ei tue MIPS: ää ja muita arkkitehtuureja.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}