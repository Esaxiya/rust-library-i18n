#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Sisältää rakenteelliset määritelmät kääntäjän sisäänrakennettujen tyyppien asettelulle.
//!
//! Niitä voidaan käyttää vaarallisten koodien muunnosten kohteina käsittelemällä suoraan raakaesityksiä.
//!
//!
//! Niiden määritelmän tulisi aina vastata `rustc_middle::ty::layout`: ssä määritettyä ABI: tä.
//!

/// Esitys trait-objektista, kuten `&dyn SomeTrait`.
///
/// Tällä rakenteella on sama asettelu kuin `&dyn SomeTrait`-ja `Box<dyn AnotherTrait>`-tyypeillä.
///
/// `TraitObject` taataan vastaavan asettelua, mutta se ei ole trait-objektien tyyppi (esim. kentät eivät ole suoraan käytettävissä `&dyn SomeTrait`: llä) eikä se hallitse kyseistä asettelua (määritelmän muuttaminen ei muuta `&dyn SomeTrait`: n asettelua).
///
/// Se on suunniteltu käytettäväksi vain vaarallisten koodien kanssa, joiden on käsiteltävä matalan tason yksityiskohtia.
///
/// Ei ole mitään tapaa viitata kaikkiin trait-objekteihin yleisesti, joten ainoa tapa luoda tämän tyyppisiä arvoja on [`std::mem::transmute`][transmute]: n kaltaisilla toiminnoilla.
/// Vastaavasti ainoa tapa luoda todellinen trait-objekti `TraitObject`-arvosta on `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// trait-objektin syntetisointi yhteensopimattomilla tyypeillä-sellainen, jossa vtable ei vastaa sen arvon tyyppiä, johon datanosoitin osoittaa-johtaa todennäköisesti määrittelemättömään käyttäytymiseen.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // esimerkki trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // anna kääntäjän tehdä trait-objekti
/// let object: &dyn Foo = &value;
///
/// // katso raakaa esitystä
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // datanosoitin on `value`: n osoite
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // rakentaa uusi objekti, joka osoittaa eri `i32`: n, varoen `object`: n `i32` vtable-ohjelmaa
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // sen pitäisi toimia aivan kuin olisimme rakentaneet trait-objektin suoraan `other_value`: stä
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}