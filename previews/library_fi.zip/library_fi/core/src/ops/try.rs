/// trait `?`-operaattorin käyttäytymisen mukauttamiseksi.
///
/// `Try`: n toteuttaja on tyyppi, jolla on kanoninen tapa tarkastella sitä success/failure-dikotomiana.
/// Tämä trait mahdollistaa sekä onnistumis-tai epäonnistumisarvojen poiminnan olemassa olevasta ilmentymästä että uuden ilmentymän luomisen onnistumis-tai epäonnistumisarvosta.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Tämän arvon tyyppi, kun sitä katsotaan onnistuneeksi.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Tämän arvon tyyppi, kun sitä katsotaan epäonnistuneeksi.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Asettaa "?"-operaattorin.`Ok(t)`: n palautus tarkoittaa, että suorituksen tulisi jatkua normaalisti, ja `?`: n tulos on arvo `t`.
    /// `Err(e)`: n palautus tarkoittaa, että suorituksen tulisi branch sisimpään `catch`: n ympäröivään alueeseen tai palata funktiosta.
    ///
    /// Jos palautetaan `Err(e)`-tulos, arvo `e` on "wrapped" suljetussa laajuudessa (jonka on itse toteutettava `Try`).
    ///
    /// Erityisesti palautetaan arvo `X::from_error(From::from(e))`, jossa `X` on sulkutoiminnon palautustyyppi.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Kääri virhearvo muodostaaksesi yhdistetyn tuloksen.
    /// Esimerkiksi `Result::Err(x)` ja `Result::from_error(x)` ovat vastaavia.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Kierrä OK-arvo yhdistetyn tuloksen muodostamiseksi.
    /// Esimerkiksi `Result::Ok(x)` ja `Result::from_ok(x)` ovat vastaavia.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}