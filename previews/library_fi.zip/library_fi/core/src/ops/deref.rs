/// Käytetään muuttumattomiin alijohdon operaatioihin, kuten `*v`.
///
/// Sen lisäksi, että `Deref`-laitetta käytetään (unary) X0 `*`-operaattorin kanssa nimenomaisissa poikkeavissa poikkeavissa operaatioissa muuttumattomissa yhteyksissä, kääntäjä käyttää sitä epäsuorasti monissa olosuhteissa.
/// Tätä mekanismia kutsutaan ['`Deref` coercion'][more].
/// Vaihtuvissa yhteyksissä käytetään [`DerefMut`]: ää.
///
/// `Deref`: n käyttöönotto älykkäille osoittimille helpottaa niiden takana olevien tietojen käyttöä, minkä vuoksi he ottavat käyttöön `Deref`: n.
/// Toisaalta `Deref`: ää ja [`DerefMut`]: ää koskevat säännöt on suunniteltu erityisesti älykkäiden osoittimien sijoittamiseksi.
/// Tästä johtuen **``Deref`` tulisi ottaa käyttöön vain älykkäille osoittimille** sekaannusten välttämiseksi.
///
/// Vastaavista syistä **tämän trait: n ei pitäisi koskaan epäonnistua**.Epäonnistuminen viittausten aikana voi olla erittäin hämmentävää, kun `Deref`: ää kutsutaan implisiittisesti.
///
/// # Lisätietoja `Deref`-pakosta
///
/// Jos `T` toteuttaa `Deref<Target = U>`: n ja `x` on tyypin `T` arvo, toimi seuraavasti:
///
/// * Muuttamattomissa yhteyksissä `*x` (missä `T` ei ole viite-tai raakaosoitin) vastaa `* Deref::deref(&x)`: ää.
/// * Tyypin `&T` arvot pakotetaan tyypin `&U` arvoihin
/// * `T` toteuttaa implisiittisesti kaikki `U`-tyypin (immutable)-menetelmät.
///
/// Lisätietoja on osoitteessa [the chapter in *The Rust Programming Language*][book] sekä viiteosioissa [the dereference operator][ref-deref-op], [method resolution] ja [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Rakenne, jolla on yksi kenttä, johon pääsee tekemällä viittaus strukturiin.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Tuloksena oleva tyyppi jälkiviittauksen jälkeen.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Poikkeaa arvosta.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Käytetään muutettavissa oleviin alijäämäoperaatioihin, kuten `*v = 1;`: ssä.
///
/// Sen lisäksi, että kääntäjä käyttää `DerefMut`: ää eksplisiittisiin alijohdonpoisto-operaatioihin (unary) `*`-operaattorin kanssa muutettavissa olevissa yhteyksissä, se on epäsuorasti myös monissa olosuhteissa.
/// Tätä mekanismia kutsutaan ['`Deref` coercion'][more].
/// Muuttamattomissa yhteyksissä käytetään [`Deref`]: ää.
///
/// `DerefMut`: n käyttöönotto älykkäille osoittimille tekee takana olevien tietojen muokkaamisen käteväksi, minkä vuoksi he ottavat käyttöön `DerefMut`: n.
/// Toisaalta [`Deref`]: ää ja `DerefMut`: ää koskevat säännöt on suunniteltu erityisesti älykkäiden osoittimien sijoittamiseksi.
/// Tästä johtuen **`` DerefMut '' tulisi ottaa käyttöön vain älykkäille osoittimille** sekaannusten välttämiseksi.
///
/// Vastaavista syistä **tämän trait: n ei pitäisi koskaan epäonnistua**.Epäonnistuminen viittausten aikana voi olla erittäin hämmentävää, kun `DerefMut`: ää kutsutaan implisiittisesti.
///
/// # Lisätietoja `Deref`-pakosta
///
/// Jos `T` toteuttaa `DerefMut<Target = U>`: n ja `x` on tyypin `T` arvo, toimi seuraavasti:
///
/// * Vaihtuvissa yhteyksissä `*x` (jossa `T` ei ole viite-tai raakaosoitin) vastaa `* DerefMut::deref_mut(&mut x)`: ää.
/// * Tyypin `&mut T` arvot pakotetaan tyypin `&mut U` arvoihin
/// * `T` toteuttaa implisiittisesti kaikki `U`-tyypin (mutable)-menetelmät.
///
/// Lisätietoja on osoitteessa [the chapter in *The Rust Programming Language*][book] sekä viiteosioissa [the dereference operator][ref-deref-op], [method resolution] ja [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Rakenne, jossa on yksi kenttä, jota on muokattavissa viittaamalla strukturiin.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Dereferoi arvon.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Osoittaa, että rakennetta voidaan käyttää menetelmävastaanottimena ilman `arbitrary_self_types`-ominaisuutta.
///
/// Tämän toteuttavat stdlib-osoitintyypit, kuten `Box<T>`, `Rc<T>`, `&T` ja `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}