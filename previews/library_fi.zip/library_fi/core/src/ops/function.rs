/// Soittajaoperaattorin versio, joka ottaa muuttumattoman vastaanottimen.
///
/// `Fn`: n esiintymiä voidaan kutsua toistuvasti ilman mutaatiotilaa.
///
/// *Tätä trait (`Fn`)-laitetta ei pidä sekoittaa [function pointers] (`fn`)-laitteeseen.*
///
/// `Fn` toteutetaan automaattisesti sulkemisilla, jotka vievät vain muuttumattomia viittauksia siepattuihin muuttujiin tai eivät kaapaa mitään ollenkaan, samoin kuin (safe) [function pointers] (joidenkin varoitusten kanssa, katso lisätietoja niiden dokumentaatiosta).
///
/// Lisäksi kaikentyyppisille `F`, jotka toteuttavat `Fn`, myös `&F` toteuttaa `Fn`.
///
/// Koska sekä [`FnMut`] että [`FnOnce`] ovat `Fn`: n supermuotoja, mitä tahansa `Fn`: n esiintymää voidaan käyttää parametrina, jossa [`FnMut`]: n tai [`FnOnce`]: n odotetaan olevan.
///
/// Käytä `Fn`: ää sidoksena, kun haluat hyväksyä funktiotyyppisen parametrin ja sinun on kutsuttava sitä toistuvasti ja ilman mutaatiotilaa (esim. Kun sitä kutsutaan samanaikaisesti).
/// Jos et tarvitse niin tiukkoja vaatimuksia, käytä [`FnMut`]-tai [`FnOnce`]-rajoituksia.
///
/// Katso lisätietoja aiheesta [chapter on closures in *The Rust Programming Language*][book]: stä.
///
/// Huomaa myös `Fn` traits: n erityinen syntakse (esim
/// `Fn(usize, bool) -> käytä).Kiinnostuneet tämän teknisistä yksityiskohdista voivat viitata [the relevant section in the *Rustonomicon*][nomicon]: ään.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Soitetaan sulkemista
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## `Fn`-parametrin käyttö
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // jotta regex voi luottaa `&str: !FnMut`: ään
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Suorittaa puhelutoiminnon.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Soittajaoperaattorin versio, joka ottaa muutettavan vastaanottimen.
///
/// `FnMut`: n esiintymiä voidaan kutsua toistuvasti, ja ne voivat muuttaa tilaa.
///
/// `FnMut` toteutetaan automaattisesti sulkemisilla, jotka viittaavat muuttuviin viittauksiin siepattuihin muuttujiin, sekä kaikkiin tyyppeihin, jotka toteuttavat [`Fn`]: n, esim. (safe) [function pointers] (koska `FnMut` on [`Fn`]: n supersuoja).
/// Lisäksi kaikentyyppisille `F`, jotka toteuttavat `FnMut`, myös `&mut F` toteuttaa `FnMut`.
///
/// Koska [`FnOnce`] on `FnMut`: n supersuoja, voidaan käyttää mitä tahansa `FnMut`: n esiintymää siellä, missä [`FnOnce`]: n odotetaan olevan, ja koska [`Fn`] on `FnMut`: n alamuotokuva, mitä tahansa [`Fn`]: n esiintymää voidaan käyttää siellä, missä `FnMut`: n odotetaan olevan.
///
/// Käytä `FnMut`: ää sidoksena, kun haluat hyväksyä funktiotyyppisen parametrin ja sinun on kutsuttava sitä toistuvasti, samalla kun sallitaan sen mutaatio.
/// Jos et halua parametrin muuttavan tilaa, käytä [`Fn`]: ää sidoksena;jos sinun ei tarvitse soittaa sitä toistuvasti, käytä [`FnOnce`]: ää.
///
/// Katso lisätietoja aiheesta [chapter on closures in *The Rust Programming Language*][book]: stä.
///
/// Huomaa myös `Fn` traits: n erityinen syntakse (esim
/// `Fn(usize, bool) -> käytä).Kiinnostuneet tämän teknisistä yksityiskohdista voivat viitata [the relevant section in the *Rustonomicon*][nomicon]: ään.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Kutsutaan mutatiivisesti kaappaavaa sulkemista
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## `FnMut`-parametrin käyttö
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // jotta regex voi luottaa `&str: !FnMut`: ään
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Suorittaa puhelutoiminnon.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Soittajaoperaattorin versio, joka vie sivuarvovastaanottimen.
///
/// `FnOnce`-esiintymiä voidaan kutsua, mutta niitä ei ehkä voi kutsua useita kertoja.Tämän vuoksi, jos ainoa tyyppiä tiedettävä asia on, että se toteuttaa `FnOnce`: n, sitä voidaan kutsua vain kerran.
///
/// `FnOnce` toteutetaan automaattisesti sulkemisilla, jotka saattavat kuluttaa siepattuja muuttujia, samoin kuin kaikilla tyypeillä, jotka toteuttavat [`FnMut`]: n, esim. (safe) [function pointers] (koska `FnOnce` on [`FnMut`]: n supersuoja).
///
///
/// Koska sekä [`Fn`] että [`FnMut`] ovat `FnOnce`: n alamuotoja, mitä tahansa [`Fn`]-tai [`FnMut`]-esiintymää voidaan käyttää siellä, missä `FnOnce`: n odotetaan olevan.
///
/// Käytä `FnOnce`: ää sidoksena, kun haluat hyväksyä funktiotyyppisen parametrin ja sinun on kutsuttava sitä vain kerran.
/// Jos haluat soittaa parametrille toistuvasti, käytä [`FnMut`]: ää sidoksena;Jos tarvitset sitä myös tilan mutaation estämiseksi, käytä [`Fn`]: ää.
///
/// Katso lisätietoja aiheesta [chapter on closures in *The Rust Programming Language*][book]: stä.
///
/// Huomaa myös `Fn` traits: n erityinen syntakse (esim
/// `Fn(usize, bool) -> käytä).Kiinnostuneet tämän teknisistä yksityiskohdista voivat viitata [the relevant section in the *Rustonomicon*][nomicon]: ään.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## `FnOnce`-parametrin käyttö
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` kuluttaa siepatut muuttujansa, joten sitä ei voida käyttää useammin kuin kerran.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Yritetään käynnistää `func()` uudestaan heittää `use of moved value`-virhe `func`: lle.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` ei voida enää vedota tässä vaiheessa
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // jotta regex voi luottaa `&str: !FnMut`: ään
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Palautettu tyyppi puheluoperaattorin käytön jälkeen.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Suorittaa puhelutoiminnon.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}