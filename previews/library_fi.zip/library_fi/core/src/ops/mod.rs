//! Ylikuormitettavat operaattorit.
//!
//! Näiden traits: n käyttöönotto mahdollistaa tiettyjen operaattoreiden ylikuormituksen.
//!
//! Joitakin näistä traits: stä tuo prelude, joten ne ovat saatavilla jokaisessa Rust-ohjelmassa.Vain operaattorit, joita traits tukee, voivat olla ylikuormitettuja.
//! Esimerkiksi lisäysoperaattori (`+`) voidaan ylikuormittaa [`Add`] trait: n kautta, mutta koska tehtäväoperaattorilla (`=`) ei ole tukea trait: lle, sen semantiikkaa ei voida ylikuormittaa.
//! Lisäksi tämä moduuli ei tarjoa mekanismia uusien operaattoreiden luomiseksi.
//! Jos tarvitaan piirteetöntä ylikuormitusta tai mukautettuja operaattoreita, sinun tulisi etsiä makroja tai kääntäjän laajennuksia Rust: n syntaksin laajentamiseksi.
//!
//! Operaattorin traits toteutusten ei pitäisi olla yllättäviä niiden asiayhteyksissä, pitäen mielessä niiden tavanomaiset merkitykset ja [operator precedence].
//! Esimerkiksi [`Mul`]: n käyttöönotossa operaation tulisi olla jonkin verran samanlainen kuin kertolasku (ja jakaa odotetut ominaisuudet, kuten assosiatiivisuus).
//!
//! Huomaa, että `&&`-ja `||`-operaattorit ovat oikosulussa, ts. Ne arvioivat toista operandiaan vain, jos se vaikuttaa tulokseen.Koska traits ei voi valvoa tätä käyttäytymistä, `&&`: ää ja `||`: ää ei tueta ylikuormitettavina operaattoreina.
//!
//! Monet operaattorit ottavat operandinsa arvon mukaan.Muissa kuin yleisissä tilanteissa, joihin liittyy sisäänrakennettuja tyyppejä, tämä ei yleensä ole ongelma.
//! Näiden operaattoreiden käyttäminen yleisessä koodissa vaatii kuitenkin jonkin verran huomiota, jos arvoja on käytettävä uudelleen, sen sijaan, että annettaisiin operaattoreille kuluttaa niitä.Yksi vaihtoehto on ajoittain käyttää [`clone`]: ää.
//! Toinen vaihtoehto on luottaa mukana oleviin tyyppeihin, jotka tarjoavat lisäoperaattoreiden toteutuksia viitteiksi.
//! Esimerkiksi käyttäjän määrittelemälle tyypille `T`, jonka oletetaan tukevan lisäystä, on luultavasti hyvä, että sekä `T` että `&T` toteuttavat traits [`Add<T>`][`Add`] ja [`Add<&T>`][`Add`], jotta yleinen koodi voidaan kirjoittaa ilman tarpeetonta kloonausta.
//!
//!
//! # Examples
//!
//! Tämä esimerkki luo `Point`-rakenteen, joka toteuttaa [`Add`]: n ja [`Sub`]: n, ja osoittaa sitten kahden "pisteen" lisäämisen ja vähentämisen.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Katso kunkin trait: n dokumentaatiosta esimerkkitoteutus.
//!
//! [`Fn`], [`FnMut`] ja [`FnOnce`] traits toteutetaan tyypeillä, joihin voidaan kutsua kuten toimintoja.Huomaa, että [`Fn`] vie `&self`: n, [`FnMut`] vie `&mut self`: n ja [`FnOnce`] vie `self`: n.
//! Nämä vastaavat kolmentyyppisiä menetelmiä, joihin voidaan vedota ilmentymässä: kutsu-viite, kutsu-muutettava-viite ja kutsu-arvo.
//! Näiden traits: n yleisin käyttö on toimia rajoina ylemmän tason toiminnoille, jotka ottavat funktiot tai sulkut argumenteiksi.
//!
//! [`Fn`]: n ottaminen parametriksi:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! [`FnMut`]: n ottaminen parametriksi:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! [`FnOnce`]: n ottaminen parametriksi:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` kuluttaa siepatut muuttujansa, joten sitä ei voida käyttää useammin kuin kerran
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Yritetään käynnistää `func()` uudestaan heittää `use of moved value`-virhe `func`: lle
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` ei voida enää vedota tässä vaiheessa
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;