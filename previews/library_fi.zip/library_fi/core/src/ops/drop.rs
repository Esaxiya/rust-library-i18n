/// Mukautettu koodi hävittäjässä.
///
/// Kun arvoa ei enää tarvita, Rust suorittaa "destructor": n kyseisellä arvolla.
/// Yleisin tapa, jolla arvoa ei enää tarvita, on, kun se menee soveltamisalan ulkopuolelle.Hävittäjät voivat silti toimia muissa olosuhteissa, mutta keskitymme tässä olevien esimerkkien soveltamisalaan.
/// Lisätietoja joistakin näistä tapauksista on [the reference]-osassa, joka käsittelee tuhoajia.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Tämä tuhoaja koostuu kahdesta osasta:
/// - Kutsu `Drop::drop`: lle kyseiselle arvolle, jos tämä erityinen `Drop` trait on toteutettu sen tyypille.
/// - Automaattisesti luotu "drop glue", joka kutsuu rekursiivisesti tämän arvon kaikkien kenttien tuhoajia.
///
/// Koska Rust kutsuu automaattisesti kaikkien sisältämien kenttien tuhoajat, sinun ei tarvitse useimmissa tapauksissa toteuttaa `Drop`: ää.
/// Mutta joissakin tapauksissa se on hyödyllistä, esimerkiksi tyyppeille, jotka hallinnoivat suoraan resurssia.
/// Se resurssi voi olla muisti, se voi olla tiedostokuvaaja, se voi olla verkkopistoke.
/// Kun tämän tyyppistä arvoa ei enää käytetä, sen tulisi "clean up"-resurssi vapauttaa muistia tai sulkea tiedosto tai liitäntä.
/// Tämä on hävittäjän ja siten `Drop::drop`: n tehtävä.
///
/// ## Examples
///
/// Katsotaanpa seuraavaa ohjelmaa nähdäksesi tuhoajat toiminnassa:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust soittaa ensin `Drop::drop`: lle `_x`: lle ja sitten sekä `_x.one`: lle että `_x.two`: lle, mikä tarkoittaa, että tämän suorittaminen tulostaa
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Vaikka poistaisimme `Drop`: n `HasTwoDrop`: lle toteutuksen, sen kenttien tuhoajia kutsutaan edelleen.
/// Tämä johtaisi
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Et voi soittaa `Drop::drop`: lle itse
///
/// Koska `Drop::drop`: ää käytetään arvon puhdistamiseen, voi olla vaarallista käyttää tätä arvoa menetelmän kutsumisen jälkeen.
/// Koska `Drop::drop` ei ota tulonsa omistajaa, Rust estää väärinkäytön estämällä sinua soittamasta suoraan `Drop::drop`: ään.
///
/// Toisin sanoen, jos yritit nimenomaisesti kutsua `Drop::drop`: ää yllä olevassa esimerkissä, saat kääntäjävirheen.
///
/// Jos haluat nimenomaisesti kutsua arvon tuhoajan, sen sijaan voidaan käyttää [`mem::drop`]: ää.
///
/// [`mem::drop`]: drop
///
/// ## Pudota tilaus
///
/// Mikä kahdestamme `HasDrop`: stä putoaa ensin?Rakenteille se on sama järjestys kuin ne ilmoitetaan: ensin `one`, sitten `two`.
/// Jos haluat kokeilla tätä itse, voit muokata yllä olevaa `HasDrop`: ää sisältämään joitain tietoja, kuten kokonaisluku, ja käyttää sitä sitten `Drop`: n sisällä olevassa `println!`: ssä.
/// Kieli takaa tämän käyttäytymisen.
///
/// Toisin kuin rakenteissa, paikalliset muuttujat pudotetaan päinvastaisessa järjestyksessä:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Tämä tulostaa
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Katso kaikki säännöt [the reference]: stä.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` ja `Drop` ovat yksinomaisia
///
/// Sekä [`Copy`]: tä että `Drop`: tä ei voi käyttää samaan tyyppiin.Kääntäjä kopioi epäsuorasti tyypit, jotka ovat `Copy`, joten on erittäin vaikea ennustaa, milloin ja kuinka usein tuhoajat suoritetaan.
///
/// Sellaisina näillä tyypeillä ei voi olla tuhoajia.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Suorittaa tämän tyyppisen hävittäjän.
    ///
    /// Tätä menetelmää kutsutaan implisiittisesti, kun arvo menee ulkopuolelle, eikä sitä voida kutsua yksiselitteisesti (tämä on kääntäjävirhe [E0040]).
    /// prelude: n [`mem::drop`]-funktiota voidaan kuitenkin käyttää kutsumaan argumentin `Drop`-toteutus.
    ///
    /// Kun tämä menetelmä on kutsuttu, `self`: ää ei ole vielä jaettu.
    /// Se tapahtuu vasta, kun menetelmä on ohi.
    /// Jos näin ei ole, `self` olisi roikkuva viite.
    ///
    /// # Panics
    ///
    /// Ottaen huomioon, että [`panic!`] kutsuu `drop`: ää avautuessaan, mikä tahansa [`panic!`] `drop`-toteutuksessa todennäköisesti keskeytyy.
    ///
    /// Huomaa, että vaikka tämä panics, arvo katsotaan pudotetuksi;
    /// et saa aiheuttaa `drop`: n soittamista uudelleen.
    /// Kääntäjä käsittelee tämän yleensä automaattisesti, mutta vaarallista koodia käytettäessä voi joskus tapahtua tahattomasti, etenkin [`ptr::drop_in_place`]: ää käytettäessä.
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}