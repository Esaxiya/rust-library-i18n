use crate::marker::Unpin;
use crate::pin::Pin;

/// Generaattorin jatkamisen tulos.
///
/// Tämä luku palautetaan `Generator::resume`-menetelmästä ja ilmaisee generaattorin mahdolliset paluuarvot.
/// Tällä hetkellä tämä vastaa joko ripustuspistettä (`Yielded`) tai päätepistettä (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Generaattori riippuu arvosta.
    ///
    /// Tämä tila osoittaa, että generaattori on keskeytetty, ja se vastaa tyypillisesti `yield`-käskyä.
    /// Tässä muunnoksessa annettu arvo vastaa `yield`: lle välitettyä lauseketta ja antaa generaattoreiden antaa arvon aina, kun ne tuottavat.
    ///
    ///
    Yielded(Y),

    /// Generaattori täydennetty palautusarvolla.
    ///
    /// Tämä tila osoittaa, että generaattori on suorittanut suorituksen annetulla arvolla.
    /// Kun generaattori on palauttanut `Complete`: n, katsotaan ohjelmointivirhe kutsua `resume` uudelleen.
    ///
    Complete(R),
}

/// Sisäänrakennettujen generaattorityyppien toteuttama trait.
///
/// Generaattorit, joita kutsutaan yleisesti korutiineiksi, ovat tällä hetkellä kokeellinen kieliominaisuus Rust: ssä.
/// [RFC 2033]-generaattoreilla lisättyjen generaattoreiden on tällä hetkellä tarkoitus tarjota ensisijaisesti rakennuspalikka async/await-syntaksille, mutta todennäköisesti laajennetaan myös tarjoamaan ergonominen määritelmä iteraattoreille ja muille primitiiveille.
///
///
/// Syntaksi ja semantiikka generaattoreille on epävakaa ja vaatii uuden RFC: n vakauttamiseksi.Tällä hetkellä syntaksi on kuitenkin sulkemisen kaltainen:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Lisää generaattoreiden dokumentaatiota löytyy epävakaasta kirjasta.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Tämän generaattorin tuottaman arvon tyyppi.
    ///
    /// Tämä liitetty tyyppi vastaa `yield`-lauseketta ja arvoja, jotka voidaan palauttaa joka kerta, kun generaattori tuottaa.
    ///
    /// Esimerkiksi iteraattori generaattorina todennäköisesti on tämän tyyppinen kuin `T`, tyyppiä toistetaan.
    ///
    type Yield;

    /// Tämän generaattorin palauttaman arvon tyyppi.
    ///
    /// Tämä vastaa tyyppiä, joka on palautettu generaattorilta joko `return`-käskyllä tai implisiittisesti generaattorin literaalin viimeisenä lausekkeena.
    /// Esimerkiksi futures käyttäisi tätä `Result<T, E>`: nä, koska se edustaa valmistunutta future: tä.
    ///
    ///
    type Return;

    /// Jatka tämän generaattorin suorittamista.
    ///
    /// Tämä toiminto jatkaa generaattorin suorittamista tai aloittaa suorituksen, jos se ei ole vielä tehnyt sitä.
    /// Tämä puhelu palaa takaisin generaattorin viimeiseen keskeytyskohtaan ja jatkaa suoritusta uusimmasta `yield`: stä.
    /// Generaattori jatkaa suoritusta, kunnes se joko tuottaa tai palaa, jolloin tämä toiminto palaa.
    ///
    /// # Palautusarvo
    ///
    /// Tästä toiminnosta palautettu `GeneratorState`-enum osoittaa, missä tilassa generaattori on palatessaan.
    /// Jos `Yielded`-muunnos palautetaan, generaattori on saavuttanut ripustuspisteen ja arvo on annettu.
    /// Tässä tilassa olevat generaattorit ovat käytettävissä uudelleen myöhemmin.
    ///
    /// Jos `Complete` palautetaan, generaattori on täysin valmis annetulla arvolla.Generaattorin jatkaminen uudelleen on virheellinen.
    ///
    /// # Panics
    ///
    /// Tämä toiminto voi olla panic, jos sitä kutsutaan sen jälkeen, kun `Complete`-muunnos on palautettu aiemmin.
    /// Vaikka kielen generaattorin literaalit ovat taatut panic: lle, kun niitä jatketaan `Complete`: n jälkeen, tätä ei voida taata kaikille `Generator` trait: n toteutuksille.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}