//! Jaettavat muunneltavat astiat.
//!
//! Rust-muistin turvallisuus perustuu tähän sääntöön: Kun otetaan huomioon objekti `T`, on mahdollista saada vain yksi seuraavista:
//!
//! - (`&T`): llä on useita muuttumattomia viitteitä esineeseen (tunnetaan myös nimellä **aliasing**).
//! - Yksi muutettava viittaus (`&mut T`) esineeseen (tunnetaan myös nimellä **mutability**).
//!
//! Tämän toteuttaa Rust-kääntäjä.On kuitenkin tilanteita, joissa tämä sääntö ei ole riittävän joustava.Joskus vaaditaan, että sillä on useita viittauksia objektiin ja silti mutatoidaan se.
//!
//! Jaettavia muunneltavia säiliöitä on olemassa, jotta ne ovat hallittavissa muunneltavuudeltaan, jopa aliaksen ollessa läsnä.Sekä [`Cell<T>`] että [`RefCell<T>`] mahdollistavat tämän tekemisen yksisäikeisellä tavalla.
//! `Cell<T>` ja `RefCell<T>` eivät kuitenkaan ole langattomia (ne eivät toteuta [`Sync`]: ää).
//! Jos sinun on tehtävä aliasing ja mutaatio useiden säikeiden välillä, on mahdollista käyttää tyyppejä [`Mutex<T>`], [`RwLock<T>`] tai [`atomic`].
//!
//! `Cell<T>`-ja `RefCell<T>`-tyyppiset arvot voidaan mutatoida jaettujen viitteiden (esim
//! yleinen `&T`-tyyppi), kun taas useimmat Rust-tyypit voidaan mutatoida vain ainutlaatuisten (`&mut T`) viitteiden kautta.
//! Sanomme, että `Cell<T>` ja `RefCell<T>` tarjoavat 'sisätilan muuntuvuuden', toisin kuin tyypilliset Rust-tyypit, joilla on 'perinnöllinen muuntuvuus'.
//!
//! Solutyyppejä on kahta makua: `Cell<T>` ja `RefCell<T>`.`Cell<T>` toteuttaa sisäisen muuttuvuuden siirtämällä arvoja sisään ja ulos `Cell<T>`: stä.
//! Jos haluat käyttää viitteitä arvojen sijaan, on käytettävä tyyppiä `RefCell<T>`, hankittava kirjoituslukko ennen mutatointia.`Cell<T>` tarjoaa menetelmiä nykyisen sisätilan arvon hakemiseksi ja muuttamiseksi:
//!
//!  - Tyypeille, jotka toteuttavat [`Copy`]: n, [`get`](Cell::get)-menetelmä hakee nykyisen sisätilan arvon.
//!  - Tyypeille, jotka toteuttavat [`Default`]: n, [`take`](Cell::take)-menetelmä korvaa nykyisen sisätilan arvon [`Default::default()`]: llä ja palauttaa korvatun arvon.
//!  - Kaikille tyypeille [`replace`](Cell::replace)-menetelmä korvaa nykyisen sisätilan arvon ja palauttaa korvatun arvon, ja [`into_inner`](Cell::into_inner)-menetelmä kuluttaa `Cell<T>`: n ja palauttaa sisätilan arvon.
//!  Lisäksi [`set`](Cell::set)-menetelmä korvaa sisätilan arvon pudottamalla korvatun arvon.
//!
//! `RefCell<T>` käyttää Rust: n elinaikoja 'dynaamisen lainanoton' toteuttamiseen, prosessiin, jossa voidaan vaatia väliaikaista, yksinomaista, muutettavissa olevaa pääsyä sisäiseen arvoon.
//! Lainaa tuotteelle `RefCell<T>S: itä seurataan 'ajon aikana', toisin kuin Rust: n alkuperäisiä viitetyyppejä, joita seurataan kokonaan staattisesti käännösaikana.
//! Koska `RefCell<T>`-lainat ovat dynaamisia, on mahdollista yrittää lainata arvo, joka on jo lainattu mutatiivisesti;kun näin tapahtuu, tuloksena on lanka panic.
//!
//! # Milloin on valittava sisätilojen muutettavuus
//!
//! Yleisempi periytynyt muutettavuus, jossa on oltava ainutlaatuinen pääsy arvon mutaatioon, on yksi keskeisistä kielielementeistä, jonka avulla Rust voi päättää voimakkaasti osoittimen aliaksesta estäen staattisesti kaatumisvirheet.
//! Tästä johtuen peritty muuntuvuus on suositeltava, ja sisätilojen muuttuvuus on viimeinen keino.
//! Koska solutyypit mahdollistavat mutaation siellä, missä sitä muuten estettäisiin, on kuitenkin tilanteita, jolloin sisäinen muuntelu saattaa olla tarkoituksenmukaista tai jopa * täytyy käyttää, esim.
//!
//! * Esittelyssä muuttumattomuuden 'inside'
//! * Loogisesti muuttumattomien menetelmien toteutustiedot.
//! * [`Clone`]: n toteutusten mutaatio.
//!
//! ## Esittelyssä muuttumattomuuden 'inside'
//!
//! Monet jaetut älykkäät osoitintyypit, mukaan lukien [`Rc<T>`] ja [`Arc<T>`], tarjoavat kontteja, jotka voidaan kloonata ja jakaa useiden osapuolten kesken.
//! Koska sisältämät arvot voivat olla moninkertaisia aliaksia, ne voidaan lainata vain `&`: llä, ei `&mut`: llä.
//! Ilman soluja olisi mahdotonta muunnella tietoja näiden älykkäiden osoittimien sisällä ollenkaan.
//!
//! Sitten on hyvin yleistä laittaa `RefCell<T>` jaettujen osoitintyyppien sisälle palautettavuuden palauttamiseksi:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Luo uusi lohko rajoittaa dynaamisen lainan määrää
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Huomaa, että jos emme olisi antaneet välimuistin edellisen lainan pudota soveltamisalasta, seuraava lainaus aiheuttaisi dynaamisen säieen panic.
//!     //
//!     // Tämä on `RefCell`: n käytön suurin vaara.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Huomaa, että tässä esimerkissä käytetään `Rc<T>` eikä `Arc<T>`.`RefCell<T>Ne ovat yksisäikeisiä skenaarioita varten.Harkitse [`RwLock<T>`]: n tai [`Mutex<T>`]: n käyttöä, jos tarvitset jaettua muutettavuutta monisäikeisessä tilanteessa.
//!
//! ## Loogisesti muuttumattomien menetelmien toteutustiedot
//!
//! Joskus voi olla toivottavaa olla paljastamatta API: ssa, että "under the hood" tapahtuu mutaatiota.
//! Tämä voi johtua siitä, että loogisesti operaatio on muuttumaton, mutta esim. Välimuisti pakottaa toteutuksen suorittamaan mutaation;tai koska sinun on käytettävä mutaatiota trait-menetelmän toteuttamiseksi, joka alun perin määritettiin ottamaan `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Kallis laskenta menee tähän
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## `Clone`: n toteutusten mutaatio
//!
//! Tämä on yksinkertaisesti erityinen, mutta yleinen tapaus edellisestä: muuttumattomuuden näyttävien toimintojen piilottaminen.
//! [`clone`](Clone::clone)-menetelmän ei odoteta muuttavan lähdearvoa, ja sen ilmoitetaan ottavan `&self`: n, ei `&mut self`: n.
//! Siksi kaikissa `clone`-menetelmässä tapahtuvissa mutaatioissa on käytettävä solutyyppejä.
//! Esimerkiksi [`Rc<T>`] säilyttää referenssimääränsä `Cell<T>`: ssä.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Vaihdettava muistipaikka.
///
/// # Examples
///
/// Tässä esimerkissä näet, että `Cell<T>` mahdollistaa mutaation muuttumattomassa rakenteessa.
/// Toisin sanoen se mahdollistaa "interior mutability": n.
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // VIRHE: `my_struct` on muuttumaton
/// // my_struct.regular_field =uusi_arvo;
///
/// // TEOKSET: vaikka `my_struct` on muuttumaton, `special_field` on `Cell`,
/// // joka voidaan aina mutatoida
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Katso lisätietoja [module-level documentation](self): stä.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Luo `Cell<T>`-arvon, jonka X-arvo on T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Luo uuden `Cell`: n, joka sisältää annetun arvon.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Asettaa sisältämän arvon.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Vaihtaa kahden solun arvot.
    /// Ero `std::mem::swap`: n kanssa on, että tämä toiminto ei vaadi `&mut`-viitteitä.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // TURVALLISUUS: Tämä voi olla vaarallista, jos sitä kutsutaan erillisistä säikeistä, mutta `Cell`
        // on `!Sync`, joten tätä ei tapahdu.
        // Tämä ei myöskään mitätöi mitään osoittimia, koska `Cell` varmistaa, ettei mikään muu osoita kumpaakaan näistä soluista.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Korvaa sisältämän arvon arvolla `val` ja palauttaa vanhan sisältämän arvon.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // TURVALLISUUS: Tämä voi aiheuttaa tietokilpailuja, jos niitä kutsutaan erillisestä ketjusta,
        // mutta `Cell` on `!Sync`, joten tätä ei tapahdu.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Kumoa arvo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Palauttaa kopion sisältämästä arvosta.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // TURVALLISUUS: Tämä voi aiheuttaa tietokilpailuja, jos niitä kutsutaan erillisestä ketjusta,
        // mutta `Cell` on `!Sync`, joten tätä ei tapahdu.
        unsafe { *self.value.get() }
    }

    /// Päivittää sisältämän arvon funktion avulla ja palauttaa uuden arvon.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Palauttaa raakaosoittimen tämän solun taustalla oleviin tietoihin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Palauttaa muutettavan viitteen taustalla oleviin tietoihin.
    ///
    /// Tämä puhelu lainaa `Cell`: ää mutabiilisti (käännösaikana), mikä takaa, että meillä on ainoa viite.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Palauttaa `&Cell<T>`: n `&mut T`: stä
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // TURVALLISUUS: `&mut` takaa ainutlaatuisen pääsyn.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Ottaa solun arvon jättäen `Default::default()` paikalleen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Palauttaa `&[Cell<T>]`: n `&Cell<[T]>`: stä
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // TURVALLISUUS: `Cell<T>`: llä on sama muistiasettelu kuin `T`: llä.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Vaihtuva muistipaikka, jossa on dynaamisesti tarkistetut lainasäännöt
///
/// Katso lisätietoja [module-level documentation](self): stä.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// [`RefCell::try_borrow`] palautti virheen.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// [`RefCell::try_borrow_mut`] palautti virheen.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Positiiviset arvot edustavat aktiivisen `Ref`: n määrää.Negatiiviset arvot edustavat aktiivisen `RefMut`: n määrää.
// Useat `RefMut`-elementit voivat olla aktiivisia kerrallaan vain, jos ne viittaavat `RefCell`: n erillisiin, ei-päällekkäisiin komponentteihin (esim. Sektorin eri alueet).
//
// `Ref` ja `RefMut` ovat molemmat kahden sanan kokoisia, joten olemassa olevia "Ref"-tai "RefMut"-merkkejä ei todennäköisesti koskaan tule ylittämään puolta `usize`-alueesta.
// Siten `BorrowFlag` ei todennäköisesti koskaan ylivuodosta tai alivirtauksesta.
// Tämä ei kuitenkaan ole takuu, koska patologinen ohjelma voi luoda toistuvasti mem::forget ``Ref`s '' tai `RefMut`s.
// Siksi kaiken koodin on nimenomaisesti tarkistettava ylivuoto ja alivuoto, jotta vältetään vaarattomuus tai ainakin toimittava oikein siinä tapauksessa, että ylivuoto tai alivuoto tapahtuu (esim. Katso BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Luo uuden `RefCell`: n, joka sisältää `value`: n.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Kuluttaa `RefCell`: n palauttaen kääritty arvo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Koska tämä toiminto ottaa arvon `self` (`RefCell`), kääntäjä tarkistaa staattisesti, ettei sitä ole lainattu tällä hetkellä.
        //
        self.value.into_inner()
    }

    /// Korvaa kääritty arvo uudella, palauttamalla vanhan arvon poistamatta kumpaakaan arvoa.
    ///
    ///
    /// Tämä toiminto vastaa mallia [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics, jos arvo on tällä hetkellä lainattu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Korvaa kääritty arvo uudella, joka on laskettu `f`: stä, palauttaen vanhan arvon poistamatta kumpaakaan arvoa.
    ///
    ///
    /// # Panics
    ///
    /// Panics, jos arvo on tällä hetkellä lainattu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Vaihtaa `self`: n kääritty arvo `other`: n käärittyyn arvoon deinitalisoimatta kumpaakaan.
    ///
    ///
    /// Tämä toiminto vastaa mallia [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics, jos jommankumman `RefCell`: n arvo on lainattu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Lainaa käärittyä arvoa ehdottomasti.
    ///
    /// Laina on voimassa, kunnes palautettu `Ref` poistuu.
    /// Useita muuttumattomia lainoja voidaan nostaa samanaikaisesti.
    ///
    /// # Panics
    ///
    /// Panics, jos arvo on tällä hetkellä lainattu.
    /// Käytä paniikkia vaihtoehtoa [`try_borrow`](#method.try_borrow): llä.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Esimerkki panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Lainaa käärimättömän arvon muuttumattomasti ja palauttaa virheen, jos arvo on tällä hetkellä lainattu.
    ///
    ///
    /// Laina on voimassa, kunnes palautettu `Ref` poistuu.
    /// Useita muuttumattomia lainoja voidaan nostaa samanaikaisesti.
    ///
    /// Tämä on [`borrow`](#method.borrow): n ei-paniikkivariantti.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // TURVALLISUUS: `BorrowRef` varmistaa, että pääsy on vain muuttamatonta
            // lainaan.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Lainaa kääritty arvo muuttumattomasti.
    ///
    /// Laina kestää, kunnes palautettu `RefMut` tai kaikki siitä johdetut `RefMut`-tuotteet poistuvat.
    ///
    /// Arvoa ei voi lainata, kun tämä laina on aktiivinen.
    ///
    /// # Panics
    ///
    /// Panics, jos arvo on tällä hetkellä lainattu.
    /// Käytä paniikkia vaihtoehtoa [`try_borrow_mut`](#method.try_borrow_mut): llä.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Esimerkki panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Lainaa kääritty arvo vaihtuvasti palauttaen virheen, jos arvo on tällä hetkellä lainattu.
    ///
    ///
    /// Laina kestää, kunnes palautettu `RefMut` tai kaikki siitä johdetut `RefMut`-tuotteet poistuvat.
    /// Arvoa ei voi lainata, kun tämä laina on aktiivinen.
    ///
    /// Tämä on [`borrow_mut`](#method.borrow_mut): n ei-paniikkivariantti.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // TURVALLISUUS: `BorrowRef` takaa ainutlaatuisen pääsyn.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Palauttaa raakaosoittimen tämän solun taustalla oleviin tietoihin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Palauttaa muutettavan viitteen taustalla oleviin tietoihin.
    ///
    /// Tämä puhelu lainaa `RefCell`: n muuttumattomasti (kokoamisajankohtana), joten dynaamisia tarkistuksia ei tarvita.
    ///
    /// Ole kuitenkin varovainen: tämä menetelmä odottaa `self`: n olevan muuttuva, mikä ei yleensä ole asia `RefCell`: ää käytettäessä.
    ///
    /// Katsokaa sen sijaan [`borrow_mut`]-menetelmää, jos `self` ei ole muutettavissa.
    ///
    /// Huomaa myös, että tämä menetelmä on tarkoitettu vain erityistilanteisiin eikä se yleensä ole sitä mitä haluat.
    /// Käytä epäselvissä tapauksissa [`borrow_mut`]: ää.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Kumoa vuotaneiden suojusten vaikutus `RefCell`: n lainatilaan.
    ///
    /// Tämä puhelu on samanlainen kuin [`get_mut`], mutta erikoistunut.
    /// Se lainaa `RefCell`: n mutabisti varmistaakseen, että lainoja ei ole, ja nollaa sitten tilan, joka seuraa jaettuja lainoja.
    /// Tämä on merkitystä, jos joitain `Ref`-tai `RefMut`-lainoja on vuotanut.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Lainaa käärimättömän arvon muuttumattomasti ja palauttaa virheen, jos arvo on tällä hetkellä lainattu.
    ///
    /// # Safety
    ///
    /// Toisin kuin `RefCell::borrow`, tämä menetelmä on vaarallinen, koska se ei palauta `Ref`: ää, jolloin lainan lippu jää koskematta.
    /// `RefCell`: n lainallinen vaihtaminen tämän menetelmän palauttaman viitteen ollessa elossa on määrittelemätöntä käyttäytymistä.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // TURVALLISUUS: Tarkistamme, ettei kukaan kirjoita aktiivisesti nyt, mutta niin on
            // soittajan vastuulla varmistaa, että kukaan ei kirjoita ennen kuin palautettua viittausta ei enää käytetä.
            // `self.value.get()` viittaa myös `self`: n omistamaan arvoon ja on siten taattu päteväksi `self`: n koko käyttöiän ajan.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Ottaa kääritty arvo jättäen `Default::default()` paikalleen.
    ///
    /// # Panics
    ///
    /// Panics, jos arvo on tällä hetkellä lainattu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics, jos arvo on tällä hetkellä lainattu.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Luo `RefCell<T>`-arvon, jonka X-arvo on T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics, jos jommankumman `RefCell`: n arvo on lainattu.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics, jos jommankumman `RefCell`: n arvo on lainattu.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics, jos jommankumman `RefCell`: n arvo on lainattu.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, jos jommankumman `RefCell`: n arvo on lainattu.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, jos jommankumman `RefCell`: n arvo on lainattu.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, jos jommankumman `RefCell`: n arvo on lainattu.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics, jos jommankumman `RefCell`: n arvo on lainattu.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Lainan korottaminen voi johtaa lukemattomaan arvoon (<=0) näissä tapauksissa:
            // 1. Se oli <0, eli kirjoituslainaa on, joten emme voi sallia lukulainaa Rust: n viitteiden aliaksisääntöjen vuoksi
            // 2.
            // Se oli isize::MAX (luettavien lainojen enimmäismäärä) ja se ylitti isize::MIN: n (kirjoituslainojen enimmäismäärä), joten emme voi sallia ylimääräistä lukulainaa, koska isize ei voi edustaa niin monta luettua lainaa (tämä voi tapahtua vain, jos mem::forget enemmän kuin pieni vakio määrä `` Ref '', mikä ei ole hyvä käytäntö)
            //
            //
            //
            //
            None
        } else {
            // Lainan korottaminen voi johtaa lukuarvoon (> 0) seuraavissa tapauksissa:
            // 1. Se oli=0, ts. Sitä ei lainattu, ja otamme ensimmäisen luetun lainan
            // 2. Se oli> 0 ja <isize::MAX, ts
            // siellä oli luettuja lainoja, ja isize on tarpeeksi suuri edustamaan yhden luetun lainan lisää
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Koska tämä viite on olemassa, tiedämme, että lainalippu on lukulaina.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Estä lainalaskurin vuotamista kirjoituslainaksi.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Kääri lainatun viitteen arvoon `RefCell`-ruutuun.
/// Kotelotyyppi kiinteästi lainatulle arvolle `RefCell<T>`: ltä.
///
/// Katso lisätietoja [module-level documentation](self): stä.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Kopioi `Ref`: n.
    ///
    /// `RefCell` on jo lainattu muuttumattomasti, joten tämä ei voi epäonnistua.
    ///
    /// Tämä on liitetty toiminto, jota on käytettävä `Ref::clone(...)`: nä.
    /// `Clone`-toteutus tai menetelmä häiritsisi `r.borrow().clone()`: n laajaa käyttöä `RefCell`: n sisällön kloonaamiseksi.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Tekee uuden `Ref`: n lainatun datan komponentille.
    ///
    /// `RefCell` on jo lainattu muuttumattomasti, joten tämä ei voi epäonnistua.
    ///
    /// Tämä on liitetty toiminto, jota on käytettävä `Ref::map(...)`: nä.
    /// Menetelmä häiritsisi saman nimisiä menetelmiä `Deref`: n kautta käytetyn `RefCell`: n sisällössä.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Tekee uuden `Ref`: n lainatun datan valinnaiselle komponentille.
    /// Alkuperäinen suojus palautetaan `Err(..)`: nä, jos suljin palauttaa `None`: n.
    ///
    /// `RefCell` on jo lainattu muuttumattomasti, joten tämä ei voi epäonnistua.
    ///
    /// Tämä on liitetty toiminto, jota on käytettävä `Ref::filter_map(...)`: nä.
    /// Menetelmä häiritsisi saman nimisiä menetelmiä `Deref`: n kautta käytetyn `RefCell`: n sisällössä.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Jakaa `Ref`: n useisiin viitteisiin lainatun datan eri osille.
    ///
    /// `RefCell` on jo lainattu muuttumattomasti, joten tämä ei voi epäonnistua.
    ///
    /// Tämä on liitetty toiminto, jota on käytettävä `Ref::map_split(...)`: nä.
    /// Menetelmä häiritsisi saman nimisiä menetelmiä `Deref`: n kautta käytetyn `RefCell`: n sisällössä.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Muunna viitteeksi taustalla oleviin tietoihin.
    ///
    /// Taustalla olevaa `RefCell`: ää ei voida koskaan lainata uudestaan, ja se näyttää aina olevan lainatonta.
    ///
    /// Ei ole hyvä idea vuotaa enemmän kuin vakiomäärä viitteitä.
    /// `RefCell` voidaan lainata uudelleen muuttumattomasti, jos vuotoja on esiintynyt vain pienempi määrä.
    ///
    /// Tämä on liitetty toiminto, jota on käytettävä `Ref::leak(...)`: nä.
    /// Menetelmä häiritsisi saman nimisiä menetelmiä `Deref`: n kautta käytetyn `RefCell`: n sisällössä.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Unohtamalla tämän viitteen varmistamme, että RefCellin lainalaskuri ei voi palata käyttämättömäksi `'b`: n käyttöiän aikana.
        // Viitaseurannan tilan nollaaminen edellyttäisi ainutlaatuista viittausta lainattuun RefCelliin.
        // Alkuperäisestä solusta ei voida luoda muita muutettavia viitteitä.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Tekee uuden `RefMut`: n lainatun datan komponentille, esim. Enum-muunnokselle.
    ///
    /// `RefCell` on jo lainattu mutatiivisesti, joten tämä ei voi epäonnistua.
    ///
    /// Tämä on liitetty toiminto, jota on käytettävä `RefMut::map(...)`: nä.
    /// Menetelmä häiritsisi saman nimisiä menetelmiä `Deref`: n kautta käytetyn `RefCell`: n sisällössä.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): korjaa lainan tarkistus
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Tekee uuden `RefMut`: n lainatun datan valinnaiselle komponentille.
    /// Alkuperäinen suojus palautetaan `Err(..)`: nä, jos suljin palauttaa `None`: n.
    ///
    /// `RefCell` on jo lainattu mutatiivisesti, joten tämä ei voi epäonnistua.
    ///
    /// Tämä on liitetty toiminto, jota on käytettävä `RefMut::filter_map(...)`: nä.
    /// Menetelmä häiritsisi saman nimisiä menetelmiä `Deref`: n kautta käytetyn `RefCell`: n sisällössä.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): korjaa lainan tarkistus
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // TURVALLISUUS: toiminto pysyy voimassa yksinomaan viitteenä
        // `orig`: n kautta, ja osoitin viitataan vain toimintokutsun sisäpuolelle, jolloin yksinomainen viittaus ei pääse poistumaan.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // TURVALLISUUS: sama kuin yllä.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Jakaa `RefMut`: n useisiin RefMut-tiedostoihin lainatun datan eri osille.
    ///
    /// Taustalla oleva `RefCell` pysyy lainattuna, kunnes molemmat palautetut RefMutit poistuvat soveltamisalasta.
    ///
    /// `RefCell` on jo lainattu mutatiivisesti, joten tämä ei voi epäonnistua.
    ///
    /// Tämä on liitetty toiminto, jota on käytettävä `RefMut::map_split(...)`: nä.
    /// Menetelmä häiritsisi saman nimisiä menetelmiä `Deref`: n kautta käytetyn `RefCell`: n sisällössä.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Muunna muutettavaksi viitteeksi taustalla oleviin tietoihin.
    ///
    /// Taustalla olevaa `RefCell`: ää ei voida lainata uudestaan, ja se näkyy aina jo lainattuna, mikä tekee palautetusta viitteestä ainoan sisustukseen.
    ///
    ///
    /// Tämä on liitetty toiminto, jota on käytettävä `RefMut::leak(...)`: nä.
    /// Menetelmä häiritsisi saman nimisiä menetelmiä `Deref`: n kautta käytetyn `RefCell`: n sisällössä.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Unohtamalla tämä BorrowRefMut varmistamme, että RefCellin lainalaskuri ei voi palata käyttämättömäksi `'b`: n käyttöiän aikana.
        // Viitaseurannan tilan nollaaminen edellyttäisi ainutlaatuista viittausta lainattuun RefCelliin.
        // Alkuperäisestä solusta ei voida luoda lisää viitteitä tuon elinkaaren aikana, jolloin nykyinen laina on ainoa viite jäljellä olevalle eliniälle.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Toisin kuin BorrowRefMut::clone, uusi kutsutaan luomaan alkukirjain
        // muutettavissa oleva viite, joten tällä hetkellä ei saa olla olemassa olevia viitteitä.
        // Siten, vaikka klooni lisää muuttuvaa uudelleenlaskentaa, sallimme tässä nimenomaisesti vain siirtymisen käyttämättömästä käyttämättömään, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Kloonaa `BorrowRefMut`: n.
    //
    // Tämä on voimassa vain, jos kutakin `BorrowRefMut`: ää käytetään seuraamaan muutettavaa viittausta alkuperäisen objektin erilliseen, ei-päällekkäiseen alueeseen.
    //
    // Tämä ei ole klooni-implisiitissä, joten koodi ei soita tätä implisiittisesti.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Estä lainalaskurin vuotaminen.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Kotelotyyppi `RefCell<T>`: stä lainatulle arvolle.
///
/// Katso lisätietoja [module-level documentation](self): stä.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Rust: n sisäinen primitiivisyys sisäisen muuntuvuuden suhteen.
///
/// Jos sinulla on viite `&T`, kääntäjä suorittaa normaalisti Rust: ssä optimoinnin tietoon perustuen, että `&T` osoittaa muuttumattomiin tietoihin.Kyseisen datan mutatointia esimerkiksi aliaksen kautta tai muuntamalla `&T` `&mut T`: ksi pidetään määrittelemättömänä käyttäytymisenä.
/// `UnsafeCell<T>` lopettaa muuttumattomuuden takuun `&T`: lle: jaettu viite `&UnsafeCell<T>` voi osoittaa tietoja, jotka ovat mutatoituja.Tätä kutsutaan "interior mutability".
///
/// Kaikki muut tyypit, jotka sallivat sisäisen muutettavuuden, kuten `Cell<T>` ja `RefCell<T>`, käyttävät `UnsafeCell`: ää sisäisesti tietojensa käärimiseen.
///
/// Huomaa, että `UnsafeCell` vaikuttaa vain jaettujen viitteiden muuttumattomuuteen.Muutettavissa olevien viitteiden ainutlaatuisuustakuu ei muutu.`&mut`-aliaksen saamiseksi ei ole * laillista tapaa, ei edes `UnsafeCell<T>`: llä.
///
/// Itse `UnsafeCell`-sovellusliittymä on teknisesti hyvin yksinkertainen: [`.get()`] antaa sinulle raakan osoittimen `*mut T` sen sisältöön._you_ on abstraktiosuunnittelijan tehtävä käyttää kyseistä raakaa osoitinta oikein.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Tarkat Rust-aliaksisäännöt vaihtelevat jonkin verran, mutta pääkohdat eivät ole kiistanalaisia:
///
/// - Jos luot turvallisen viitteen, jonka käyttöikä on `'a` (joko `&T`-tai `&mut T`-viite), johon pääsee turvakoodilla (esimerkiksi siksi, että palautit sen), et saa käyttää tietoja millään tavalla, joka on ristiriidassa kyseisen viitteen kanssa loppuosan ajan. `'a`: stä.
/// Esimerkiksi tämä tarkoittaa, että jos otat `*mut T`: n `UnsafeCell<T>`: stä ja heität sen `&T`: ksi, `T`: n tietojen on pysyttävä muuttumattomina (tietysti kaikki `T`: ssä löydetyt `UnsafeCell`-tiedot, tietysti), kunnes viitteen elinaika päättyy.
/// Vastaavasti, jos luot `&mut T`-viitteen, joka vapautetaan turvalliseen koodiin, et saa käyttää `UnsafeCell`: n tietoja vasta, kun viite vanhenee.
///
/// - Aina on vältettävä tietokilpailuja.Jos useilla säikeillä on pääsy samaan `UnsafeCell`: ään, kaikilla kirjoituksilla on oltava asianmukainen tapahtuma-ennen-suhde kaikkiin muihin pääsyihin (tai käytä atomia).
///
/// Oikean suunnittelun helpottamiseksi seuraavat skenaariot on nimenomaisesti julistettu laillisiksi yksisäikeiselle koodille:
///
/// 1. `&T`-viite voidaan vapauttaa turvalliseen koodiin ja siellä se voi olla olemassa yhdessä muiden `&T`-viitteiden kanssa, mutta ei `&mut T`: n kanssa
///
/// 2. `&mut T`-viite voidaan vapauttaa turvalliseen koodiin edellyttäen, että sen kanssa ei ole olemassa muita `&mut T`-tai `&T`-koodeja.`&mut T`: n on aina oltava ainutlaatuinen.
///
/// Huomaa, että vaikka `&UnsafeCell<T>`: n sisällön muuntaminen (vaikka muut `&UnsafeCell<T>`-viitteet peittävät solun aliaksen) on ok (edellyttäen, että ylläolevat muuttujat pakotetaan jollakin muulla tavalla), on silti määrittelemätöntä käyttäytymistä, jos sinulla on useita `&mut UnsafeCell<T>`-aliaksia.
/// Toisin sanoen `UnsafeCell` on kääre, joka on suunniteltu toimimaan erityisessä vuorovaikutuksessa _shared_ accesses (_i.e._: n kanssa `&UnsafeCell<_>`-viitteen kautta);ei ole mitään taikuutta käsitellessäsi _exclusive_ accesses (_e.g._: ää `&mut UnsafeCell<_>`: n kautta): solua tai käärittyä arvoa ei voida käyttää aliaksina kyseisen `&mut`-lainan ajan.
///
/// Tätä esittelee [`.get_mut()`]-liitäntä, joka on _safe_ getter, joka tuottaa `&mut T`: n.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Tässä on esimerkki `UnsafeCell<_>`: n sisällön mutaatiosta huolimatta siitä, että solun aliaksena on useita viitteitä:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Hanki useita/jaettuja viitteitä samalle `x`: lle.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // TURVALLISUUS: tässä laajuudessa ei ole muita viittauksia `` x '': n sisältöön,
///     // joten meidän on käytännössä ainutlaatuinen.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- lainata-+
///     *p1_exclusive += 27; // |
/// } // <---------- ei voi ylittää tätä kohtaa -------------------+
///
/// unsafe {
///     // TURVALLISUUS: Tässä laajuudessa kukaan ei odota saavansa yksinoikeutta käyttää x-sisältöä,
///     // joten meillä voi olla useita jaettuja käyttöoikeuksia samanaikaisesti.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Seuraava esimerkki esittelee tosiasian, että `UnsafeCell<T>`: n yksinoikeus tarkoittaa yksinoikeutta käyttää myös sen `T`: tä:
///
/// ```rust
/// #![forbid(unsafe_code)] // yksinoikeudella
///                         // `UnsafeCell` on läpinäkyvä ei-op-kääre, joten `unsafe`: ää ei tarvita täällä.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Hanki käännösajan tarkistama yksilöllinen viite `x`: ään.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Yksinoikeudella voimme muokata sisältöä ilmaiseksi.
/// *p_unique.get_mut() = 0;
/// // Tai vastaavasti:
/// x = UnsafeCell::new(0);
///
/// // Kun omistamme arvon, voimme purkaa sisällön ilmaiseksi.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Rakentaa uuden `UnsafeCell`-ilmentymän, joka kääri määritetyn arvon.
    ///
    ///
    /// Sisäiseen arvoon pääsy kaikkien menetelmien avulla on `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Kumoa arvo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Hakee muutettavan osoittimen käärittyyn arvoon.
    ///
    /// Tämä voidaan heittää minkä tahansa osoittimen kohdalle.
    /// Varmista, että pääsy on yksilöllinen (ei aktiivisia viitteitä, muutettavissa tai ei), kun suoratoistetaan `&mut T`: ään, ja varmista, että `&T`: ään suoratoistossa ei ole mutaatioita tai muutettavissa olevia aliaksia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Voimme vain heittää osoittimen `UnsafeCell<T>`: stä `T`: ään #[repr(transparent)]: n takia.
        // Tämä hyödyntää libstd: n erityistilaa, eikä käyttäjäkoodille voida taata, että tämä toimii kääntäjän future-versioissa!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Palauttaa muutettavan viitteen taustalla oleviin tietoihin.
    ///
    /// Tämä kutsu lainaa `UnsafeCell`: n mutatiivisesti (käännösaikana), mikä takaa, että meillä on ainoa viite.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Hakee muutettavan osoittimen käärittyyn arvoon.
    /// Ero [`get`]: ään on se, että tämä toiminto hyväksyy raakaosoittimen, joka on hyödyllinen väliaikaisten viitteiden luomisen välttämiseksi.
    ///
    /// Tulos voidaan heittää minkä tahansa osoittimen kohdalle.
    /// Varmista, että pääsy on yksilöllinen (ei aktiivisia viitteitä, muutettavissa tai ei), kun suoratoistetaan `&mut T`: ään, ja varmista, että `&T`: ään suoratoistossa ei ole mutaatioita tai muutettavissa olevia aliaksia.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// `UnsafeCell`: n asteittainen alustaminen vaatii `raw_get`: n, koska `get`: n soittaminen edellyttää viitteen luomista alustamattomille tiedoille:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Voimme vain heittää osoittimen `UnsafeCell<T>`: stä `T`: ään #[repr(transparent)]: n takia.
        // Tämä hyödyntää libstd: n erityistilaa, eikä käyttäjäkoodille voida taata, että tämä toimii kääntäjän future-versioissa!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Luo `UnsafeCell`: n, jonka X-arvo on T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}