#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Laajentuu joko `$crate::panic::panic_2015` tai `$crate::panic::panic_2021` soittajan version mukaan.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Väittää, että kaksi lauseketta ovat yhtä suuret ([`PartialEq`]: n avulla).
///
/// panic: ssä tämä makro tulostaa lausekkeiden arvot virheenkorjausesityksineen.
///
///
/// Kuten [`assert!`], tällä makrolla on toinen muoto, jossa mukautettu panic-viesti voidaan antaa.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Alla olevat lainat ovat tarkoituksellisia.
                    // Ilman niitä lainan pinoarvo alustetaan jo ennen arvojen vertailua, mikä johtaa huomattavaan hidastumiseen.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Alla olevat lainat ovat tarkoituksellisia.
                    // Ilman niitä lainan pinoarvo alustetaan jo ennen arvojen vertailua, mikä johtaa huomattavaan hidastumiseen.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Väittää, että kaksi lauseketta eivät ole keskenään yhtä suuret ([`PartialEq`]: ää käytettäessä).
///
/// panic: ssä tämä makro tulostaa lausekkeiden arvot virheenkorjausesityksineen.
///
///
/// Kuten [`assert!`], tällä makrolla on toinen muoto, jossa mukautettu panic-viesti voidaan antaa.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Alla olevat lainat ovat tarkoituksellisia.
                    // Ilman niitä lainan pinoarvo alustetaan jo ennen arvojen vertailua, mikä johtaa huomattavaan hidastumiseen.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Alla olevat lainat ovat tarkoituksellisia.
                    // Ilman niitä lainan pinoarvo alustetaan jo ennen arvojen vertailua, mikä johtaa huomattavaan hidastumiseen.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Vahvistaa, että looginen lauseke on `true` ajon aikana.
///
/// Tämä käynnistää [`panic!`]-makron, jos annettua lauseketta ei voida arvioida `true`: ksi ajon aikana.
///
/// Kuten [`assert!`], tällä makrolla on myös toinen versio, jossa voidaan tarjota mukautettu panic-viesti.
///
/// # Uses
///
/// Toisin kuin [`assert!`], `debug_assert!`-lauseet ovat oletusarvoisesti käytössä vain optimoimattomissa koontiversioissa.
/// Optimoitu koontiversio ei suorita `debug_assert!`-käskyjä, ellei `-C debug-assertions` välitetä kääntäjälle.
/// Tämä tekee `debug_assert!`: stä hyödyllisen tarkistuksissa, jotka ovat liian kalliita esiintyä julkaisurakenteessa, mutta voivat olla hyödyllisiä kehityksen aikana.
/// `debug_assert!`: n laajentamisen tulos tarkistetaan aina.
///
/// Tarkistamaton väite antaa epäjohdonmukaisessa tilassa olevan ohjelman jatkaa toimintaansa, jolla voi olla odottamattomia seurauksia, mutta se ei aiheuta vaarattomuutta, kunhan se tapahtuu vain turvallisessa koodissa.
///
/// Väitteiden suorituskustannuksia ei kuitenkaan voida mitata yleisesti.
/// [`assert!`]: n korvaaminen `debug_assert!`: llä on siis suositeltavaa vasta perusteellisen profiloinnin jälkeen ja mikä tärkeintä, vain turvallisessa koodissa!
///
/// # Examples
///
/// ```
/// // Näiden väitteiden panic-sanoma on annetun lausekkeen tarkennettu arvo.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // hyvin yksinkertainen toiminto
/// debug_assert!(some_expensive_computation());
///
/// // vakuuttaa mukautetulla viestillä
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Väittää, että kaksi lauseketta ovat yhtä suuret keskenään.
///
/// panic: ssä tämä makro tulostaa lausekkeiden arvot virheenkorjausesityksineen.
///
/// Toisin kuin [`assert_eq!`], `debug_assert_eq!`-lauseet ovat oletusarvoisesti käytössä vain optimoimattomissa koontiversioissa.
/// Optimoitu koontiversio ei suorita `debug_assert_eq!`-käskyjä, ellei `-C debug-assertions` välitetä kääntäjälle.
/// Tämä tekee `debug_assert_eq!`: stä hyödyllisen tarkistuksissa, jotka ovat liian kalliita esiintyä julkaisurakenteessa, mutta voivat olla hyödyllisiä kehityksen aikana.
///
/// `debug_assert_eq!`: n laajentamisen tulos tarkistetaan aina.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Väittää, että kaksi lauseketta eivät ole keskenään samanarvoisia.
///
/// panic: ssä tämä makro tulostaa lausekkeiden arvot virheenkorjausesityksineen.
///
/// Toisin kuin [`assert_ne!`], `debug_assert_ne!`-lauseet ovat oletusarvoisesti käytössä vain optimoimattomissa koontiversioissa.
/// Optimoitu koontiversio ei suorita `debug_assert_ne!`-käskyjä, ellei `-C debug-assertions` välitetä kääntäjälle.
/// Tämä tekee `debug_assert_ne!`: stä hyödyllisen tarkistuksissa, jotka ovat liian kalliita esiintyä julkaisurakenteessa, mutta voivat olla hyödyllisiä kehityksen aikana.
///
/// `debug_assert_ne!`: n laajentamisen tulos tarkistetaan aina.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Palauttaa vastaako annettu lauseke jotakin annetuista malleista.
///
/// Kuten `match`-lausekkeessa, mallia voi valinnaisesti seurata `if` ja suojalauseke, jolla on pääsy kuvion sitomiin nimiin.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Kumoa tulos tai levittää sen virhettä.
///
/// `?`-operaattori lisättiin korvaamaan `try!` ja sitä tulisi käyttää sen sijaan.
/// Lisäksi `try` on varattu sana Rust 2018: ssa, joten jos sinun on käytettävä sitä, sinun on käytettävä [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` vastaa annettua [`Result`]: ää.`Ok`-muunnoksen tapauksessa lausekkeella on kääritty arvo.
///
/// `Err`-muunnoksen tapauksessa se hakee sisäisen virheen.`try!` suorittaa sitten muunnoksen `From`: llä.
/// Tämä tarjoaa automaattisen muunnoksen erikoistuneiden virheiden ja yleisempien virheiden välillä.
/// Tuloksena oleva virhe palautetaan sitten välittömästi.
///
/// Varhaisen palautuksen takia `try!`: ää voidaan käyttää vain toiminnoissa, jotka palauttavat [`Result`]: n.
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Suositeltu tapa palauttaa virheet nopeasti
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Edellinen tapa palauttaa virheet nopeasti
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Tämä vastaa:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Kirjoittaa alustetut tiedot puskuriin.
///
/// Tämä makro hyväksyy 'writer': n, muotoilumerkkijonon ja argumenttiluettelon.
/// Argumentit muotoillaan määritetyn merkkijonon mukaan ja tulos välitetään kirjoittajalle.
/// Kirjoittaja voi olla mikä tahansa arvo `write_fmt`-menetelmällä;yleensä tämä johtuu joko [`fmt::Write`]: n tai [`io::Write`] trait: n toteutuksesta.
/// Makro palauttaa sen, mitä `write_fmt`-menetelmä palauttaa;yleensä [`fmt::Result`] tai [`io::Result`].
///
/// Katso lisätietoja merkkijonon syntaksista kohdasta [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Moduuli voi tuoda sekä `std::fmt::Write`: n että `std::io::Write`: n ja kutsua `write!`: tä kumpaankin toteutettavaan objektiin, koska objektit eivät tyypillisesti toteuta molempia.
///
/// Moduulin on kuitenkin tuotava traits-hyväksytty, jotta heidän nimensä eivät ole ristiriidassa:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // käyttää fmt::Write::write_fmt: ää
///     write!(&mut v, "s = {:?}", s)?; // käyttää io::Write::write_fmt: ää
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Tätä makroa voidaan käyttää myös `no_std`-asetuksissa.
/// `no_std`-asennuksessa olet vastuussa komponenttien toteutuksen yksityiskohdista.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Kirjoita alustetut tiedot puskuriin, uuden rivin liitteenä.
///
/// Kaikilla alustoilla uusi rivi on yksinomaan LINE FEED-merkki (`\n`/`U+000A`) (ei ylimääräistä CARRIAGE RETURN (`\r`/`U+000D`)-merkkiä).
///
/// Lisätietoja on artikkelissa [`write!`].Katso lisätietoja merkkijonon syntaksista kohdasta [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Moduuli voi tuoda sekä `std::fmt::Write`: n että `std::io::Write`: n ja kutsua `write!`: tä kumpaankin toteutettavaan objektiin, koska objektit eivät tyypillisesti toteuta molempia.
/// Moduulin on kuitenkin tuotava traits-hyväksytty, jotta heidän nimensä eivät ole ristiriidassa:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // käyttää fmt::Write::write_fmt: ää
///     writeln!(&mut v, "s = {:?}", s)?; // käyttää io::Write::write_fmt: ää
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Osoittaa tavoitettavissa olevan koodin.
///
/// Tästä on hyötyä milloin tahansa, kun kääntäjä ei pysty selvittämään, ettei jokin koodi ole tavoitettavissa.Esimerkiksi:
///
/// * Yhdistä varret vartijaolosuhteisiin.
/// * Dynaamisesti päättyvät silmukat.
/// * Dynaamisesti päättyvät iteraattorit.
///
/// Jos koodin saavuttamattomuuden toteaminen osoittautuu virheelliseksi, ohjelma päättyy välittömästi [`panic!`]: llä.
///
/// Tämän makron vaarallinen vastine on [`unreachable_unchecked`]-funktio, joka aiheuttaa määrittelemätöntä käyttäytymistä, jos koodi saavutetaan.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Tämä on aina [`panic!`].
///
/// # Examples
///
/// Otteluvarret:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // koota virhe, jos kommentoidaan
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // yksi x/3: n heikoimmista toteutuksista
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Osoittaa toteuttamattoman koodin paniikilla "not implemented"-sanomalla.
///
/// Tämän avulla koodisi voi tarkistaa tyypin, mikä on hyödyllistä, jos olet prototyyppinen tai otat käyttöön trait: tä, joka vaatii useita menetelmiä, joita et aio käyttää kaikkia.
///
/// Ero `unimplemented!`: n ja [`todo!`]: n välillä on, että vaikka `todo!` välittää aikomuksen toteuttaa toiminnallisuus myöhemmin ja viesti on "not yet implemented", `unimplemented!` ei esitä tällaisia vaatimuksia.
/// Sen viesti on "not implemented".
/// Myös jotkut IDE: t merkitsevät toden!
///
/// # Panics
///
/// Tämä on aina [`panic!`], koska `unimplemented!` on vain lyhenne `panic!`: lle, jossa on kiinteä, erityinen viesti.
///
/// Kuten `panic!`, tällä makrolla on toinen muoto mukautettujen arvojen näyttämiseen.
///
/// # Examples
///
/// Sano, että meillä on trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Haluamme toteuttaa `Foo`: n 'MyStruct': lle, mutta jostain syystä on järkevää toteuttaa vain `bar()`-toiminto.
/// `baz()` ja `qux()` on vielä määriteltävä toteuttaessamme `Foo`, mutta voimme käyttää `unimplemented!`: tä niiden määritelmissä, jotta koodimme voi kääntyä.
///
/// Haluamme edelleen, että ohjelmamme pysähtyy, jos toteutamattomat menetelmät saavutetaan.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // `baz`: llä ei ole järkeä `MyStruct`: lle, joten meillä ei ole logiikkaa lainkaan.
/////
///         // Tämä näyttää "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Meillä on täällä logiikkaa, voimme lisätä viestin toteuttamattomaan!näyttääksemme laiminlyönnimme.
///         // Tämä näyttää: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Ilmaisee keskeneräisen koodin.
///
/// Tästä voi olla hyötyä, jos olet tekemässä prototyyppejä ja haluat vain tarkistaa koodisi.
///
/// Ero [`unimplemented!`]: n ja `todo!`: n välillä on, että vaikka `todo!` välittää aikomuksen toteuttaa toiminnallisuus myöhemmin ja viesti on "not yet implemented", `unimplemented!` ei esitä tällaisia vaatimuksia.
/// Sen viesti on "not implemented".
/// Myös jotkut IDE: t merkitsevät toden!
///
/// # Panics
///
/// Tämä on aina [`panic!`].
///
/// # Examples
///
/// Tässä on esimerkki joistakin käynnissä olevista koodeista.Meillä on trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Haluamme ottaa `Foo`: n käyttöön yhdellä tyypillämme, mutta haluamme myös työskennellä ensin vain `bar()`: n kanssa.Koodin kokoamiseksi meidän on toteutettava `baz()`, jotta voimme käyttää `todo!`: tä:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // täytäntöönpano menee tänne
///     }
///
///     fn baz(&self) {
///         // älä huolehdi baz(): n käyttöönotosta toistaiseksi
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // emme edes käytä baz(): ää, joten tämä on hieno.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Määritelmät sisäänrakennetuista makroista.
///
/// Suurin osa makro-ominaisuuksista (vakaus, näkyvyys jne.) On otettu lähdekoodista, lukuun ottamatta laajennustoimintoja, jotka muuttavat makrotulot lähtöiksi, nämä toiminnot tarjoaa kääntäjä.
///
///
pub(crate) mod builtin {

    /// Aiheuttaa kääntämisen epäonnistumaan annetulla virheilmoituksella, kun se havaitaan.
    ///
    /// Tätä makroa tulisi käyttää, kun crate käyttää ehdollista kokoamisstrategiaa parempien virheilmoitusten tuottamiseksi virheellisissä olosuhteissa.
    ///
    /// Se on [`panic!`]: n kääntäjätason muoto, mutta antaa virheen *kääntämisen* aikana eikä ajonaikana *.
    ///
    /// # Examples
    ///
    /// Kaksi tällaista esimerkkiä ovat makrot ja `#[cfg]`-ympäristöt.
    ///
    /// Anna parempi kääntäjävirhe, jos makro välittää virheellisiä arvoja.
    /// Ilman lopullista branch: tä kääntäjä aiheuttaisi edelleen virheen, mutta virhesanomassa ei mainita kahta kelvollista arvoa.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Lähetä kääntäjävirhe, jos jokin ominaisuuksista ei ole käytettävissä.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Rakentaa parametrit muille merkkijonon muotoilulle makroille.
    ///
    /// Tämä makro toimii ottamalla `{}`-muotoinen merkkijono-literaali jokaiselle ylimääräiselle argumentille.
    /// `format_args!` valmistelee lisäparametrit varmistaakseen, että tulos voidaan tulkita merkkijonoksi, ja kanonisoi argumentit yhdeksi tyypiksi.
    /// Kaikki [`Display`] trait: n toteuttavat arvot voidaan välittää `format_args!`: lle, samoin kuin mikä tahansa [`Debug`]-toteutus voidaan välittää `{:?}`: lle muotoilumerkkijonossa.
    ///
    ///
    /// Tämä makro tuottaa tyypin [`fmt::Arguments`] arvon.Tämä arvo voidaan välittää [`std::fmt`]: n makroille hyödyllisen uudelleenohjauksen suorittamiseksi.
    /// Kaikki muut muotoilumakrot ([`format!`], [`write!`], [`println!`] jne.) Välitetään tämän kautta.
    /// `format_args!`, toisin kuin johdetut makrot, välttää kasan allokaatioita.
    ///
    /// Voit käyttää [`fmt::Arguments`]-arvoa, jonka `format_args!` palauttaa `Debug`-ja `Display`-konteksteissa, kuten alla on esitetty.
    /// Esimerkki osoittaa myös, että `Debug` ja `Display` muotoilevat saman asian: interpoloidun muotoisen merkkijonon `format_args!`: ssä.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Lisätietoja on [`std::fmt`]: n dokumentaatiossa.
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Sama kuin `format_args`, mutta lisää lopulta uuden rivin.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Tarkistaa ympäristömuuttujan kääntöhetkellä.
    ///
    /// Tämä makro laajenee nimettyyn ympäristömuuttujan arvoon kokoamisajankohtana, jolloin saadaan tyypin `&'static str` lauseke.
    ///
    ///
    /// Jos ympäristömuuttujaa ei ole määritelty, lähetetään käännösvirhe.
    /// Jos haluat lähettää kääntämisvirheen, käytä sen sijaan [`option_env!`]-makroa.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Voit mukauttaa virhesanoman välittämällä merkkijonon toisena parametrina:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Jos `documentation`-ympäristömuuttujaa ei ole määritelty, saat seuraavan virheen:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Valinnaisesti tarkastaa ympäristömuuttujan kääntöhetkellä.
    ///
    /// Jos nimetty ympäristömuuttuja on läsnä kääntöhetkellä, tämä laajenee tyypin `Option<&'static str>` lausekkeeksi, jonka arvo on `Some` ympäristömuuttujan arvosta.
    /// Jos ympäristömuuttujaa ei ole, se laajenee `None`: ään.
    /// Katso [`Option<T>`][Option] saadaksesi lisätietoja tästä tyypistä.
    ///
    /// Kääntöaikavirhettä ei koskaan lähetetä tätä makroa käytettäessä riippumatta siitä, onko ympäristömuuttuja läsnä vai ei.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Yhdistä tunnisteet yhdeksi tunnisteeksi.
    ///
    /// Tämä makro ottaa minkä tahansa määrän pilkuilla erotettuja tunnisteita ja yhdistää ne kaikki yhdeksi, jolloin saadaan lauseke, joka on uusi tunniste.
    /// Huomaa, että hygienia tekee siitä niin, että tämä makro ei pysty sieppaamaan paikallisia muuttujia.
    /// Lisäksi makrot ovat pääsääntöisesti sallittuja vain kohteen, lauseen tai lausekkeen sijainnissa.
    /// Tämä tarkoittaa, että vaikka voit käyttää tätä makroa viittaamaan olemassa oleviin muuttujiin, toimintoihin tai moduuleihin jne., Et voi määrittää sitä uudella.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (uusi, hauska, nimi) { }//ei voida käyttää tällä tavalla!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Liitä literaalit staattiseksi merkkijonoksi.
    ///
    /// Tämä makro vie minkä tahansa määrän pilkuilla erotettuja literaaleja, jolloin saadaan tyypin `&'static str` lauseke, joka edustaa kaikkia literaaleja, jotka on liitetty vasemmalta oikealle.
    ///
    ///
    /// Kokonais-ja liukulukuiset literaalit on kiristetty ketjutettavaksi.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Laajenee rivinumeroon, johon sitä kutsuttiin.
    ///
    /// [`column!`]: n ja [`file!`]: n kanssa nämä makrot tarjoavat virheenkorjaustietoja kehittäjille sijainnista lähteessä.
    ///
    /// Laajennetulla lausekkeella on tyyppi `u32` ja se on 1-pohjainen, joten kunkin tiedoston ensimmäinen rivi arvioi arvon 1, toinen arvon 2 jne.
    /// Tämä on yhdenmukaista yleisten kääntäjien tai suosittujen toimittajien virheilmoitusten kanssa.
    /// Palautettu rivi *ei välttämättä* ole itse `line!`-kutsun rivi, vaan pikemminkin ensimmäinen makrokutsu, joka johtaa `line!`-makron kutsuun.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Laajenee sen sarakkeen numeroon, jossa sitä käytettiin.
    ///
    /// [`line!`]: n ja [`file!`]: n kanssa nämä makrot tarjoavat virheenkorjaustietoja kehittäjille sijainnista lähteessä.
    ///
    /// Laajennetulla lausekkeella on tyyppi `u32` ja se on 1-pohjainen, joten jokaisen rivin ensimmäinen sarake arvioi arvon 1, toinen arvon 2 jne.
    /// Tämä on yhdenmukaista yleisten kääntäjien tai suosittujen toimittajien virheilmoitusten kanssa.
    /// Palautettu sarake *ei välttämättä* ole itse `column!`-kutsun rivi, vaan pikemminkin ensimmäinen makrokutsu, joka johtaa `column!`-makron kutsuun.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Laajenee tiedostonimeksi, jossa sitä kutsuttiin.
    ///
    /// [`line!`]: n ja [`column!`]: n kanssa nämä makrot tarjoavat virheenkorjaustietoja kehittäjille sijainnista lähteessä.
    ///
    /// Laajennetulla lausekkeella on tyyppi `&'static str`, ja palautettu tiedosto ei ole itse `file!`-makron kutsu, vaan pikemminkin ensimmäinen makro-kutsu, joka johtaa `file!`-makron kutsumiseen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Tarkentaa sen argumentteja.
    ///
    /// Tämä makro tuottaa tyypin `&'static str` lausekkeen, joka on kaikkien makrolle välitetyn tokens: n merkkijono.
    /// Itse makron kutsun syntaksissa ei ole rajoituksia.
    ///
    /// Huomaa, että tulon tokens laajennetut tulokset voivat muuttua future: ssä.Sinun tulisi olla varovainen, jos luotat tulokseen.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Sisältää UTF-8-koodatun tiedoston merkkijonona.
    ///
    /// Tiedosto sijaitsee suhteessa nykyiseen tiedostoon (samalla tavalla kuin moduulit löytyvät).
    /// Annettu polku tulkitaan alustakohtaisesti kääntämisajankohtana.
    /// Joten esimerkiksi kutsu Windows-polulla, joka sisältää taaksepäin viiltoja `\`, ei käänny oikein Unix: ssä.
    ///
    ///
    /// Tämä makro tuottaa `&'static str`-tyyppisen lausekkeen, joka on tiedoston sisältö.
    ///
    /// # Examples
    ///
    /// Oletetaan, että samassa hakemistossa on kaksi tiedostoa, joiden sisältö on seuraava:
    ///
    /// Tiedosto 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Tiedosto 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// 'main.rs': n kääntäminen ja tuloksena olevan binäärin suorittaminen tulostaa "adiós": n.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Sisältää tiedoston viitteenä tavutaulukkoon.
    ///
    /// Tiedosto sijaitsee suhteessa nykyiseen tiedostoon (samalla tavalla kuin moduulit löytyvät).
    /// Annettu polku tulkitaan alustakohtaisesti kääntämisajankohtana.
    /// Joten esimerkiksi kutsu Windows-polulla, joka sisältää taaksepäin viiltoja `\`, ei käänny oikein Unix: ssä.
    ///
    ///
    /// Tämä makro tuottaa `&'static [u8; N]`-tyyppisen lausekkeen, joka on tiedoston sisältö.
    ///
    /// # Examples
    ///
    /// Oletetaan, että samassa hakemistossa on kaksi tiedostoa, joiden sisältö on seuraava:
    ///
    /// Tiedosto 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Tiedosto 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// 'main.rs': n kääntäminen ja tuloksena olevan binäärin suorittaminen tulostaa "adiós": n.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Laajenee merkkijonoksi, joka edustaa nykyistä moduulin polkua.
    ///
    /// Nykyinen moduulin polku voidaan ajatella moduulien hierarkiana, joka johtaa takaisin ylöspäin crate root.
    /// Palautetun polun ensimmäinen komponentti on parhaillaan kootun crate: n nimi.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Arvioi kokoonpanolippujen loogiset yhdistelmät kääntöaikana.
    ///
    /// `#[cfg]`-attribuutin lisäksi tämä makro on tarkoitettu konfigurointilippujen totuusarvon arviointiin.
    /// Tämä johtaa usein vähemmän päällekkäisiin koodeihin.
    ///
    /// Tälle makrolle annettu syntaksin muoto on sama kuin [`cfg`]-attribuutin.
    ///
    /// `cfg!`, toisin kuin `#[cfg]`, ei poista koodia ja arvioi vain tosi tai väärä.
    /// Esimerkiksi kaikkien if/else-lausekkeen lohkojen on oltava kelvollisia, kun `cfg!`: ää käytetään ehtoon riippumatta siitä, mitä `cfg!` arvioi.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Jäsentää tiedoston lausekkeena tai kohteena kontekstin mukaan.
    ///
    /// Tiedosto sijaitsee suhteessa nykyiseen tiedostoon (samalla tavalla kuin moduulit löytyvät).Annettu polku tulkitaan alustakohtaisesti kääntämisajankohtana.
    /// Joten esimerkiksi kutsu Windows-polulla, joka sisältää taaksepäin viiltoja `\`, ei käänny oikein Unix: ssä.
    ///
    /// Tämän makron käyttäminen on usein huono idea, koska jos tiedosto jäsennetään lausekkeena, se sijoitetaan ympäröivään koodiin epähygieenisesti.
    /// Tämä voi johtaa siihen, että muuttujat tai toiminnot poikkeavat tiedostosta odotetusta, jos nykyisessä tiedostossa on muuttujia tai toimintoja, joilla on sama nimi.
    ///
    ///
    /// # Examples
    ///
    /// Oletetaan, että samassa hakemistossa on kaksi tiedostoa, joiden sisältö on seuraava:
    ///
    /// Tiedosto 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Tiedosto 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// 'main.rs': n kääntäminen ja tuloksena olevan binäärin suorittaminen tulostaa "🙈🙊🙉🙈🙊🙉": n.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Vahvistaa, että looginen lauseke on `true` ajon aikana.
    ///
    /// Tämä käynnistää [`panic!`]-makron, jos annettua lauseketta ei voida arvioida `true`: ksi ajon aikana.
    ///
    /// # Uses
    ///
    /// Väitteet tarkistetaan aina sekä virheenkorjaus-että julkaisurakenteissa, eikä niitä voi poistaa käytöstä.
    /// Katso väitteistä, jotka eivät ole oletusarvoisesti käytössä julkaisurakenteissa, katso [`debug_assert!`].
    ///
    /// Turvallinen koodi voi luottaa `assert!`: ään pakottaakseen ajonaikaisia invarianteja, jotka rikkomisen seurauksena voivat johtaa vaarattomuuteen.
    ///
    /// Muita `assert!`: n käyttötapauksia ovat ajonaikaisten invariantien testaaminen ja täytäntöönpano turvallisessa koodissa (jonka rikkominen ei voi johtaa vaarattomuuteen).
    ///
    ///
    /// # Mukautetut viestit
    ///
    /// Tällä makrolla on toinen muoto, jossa mukautettu panic-viesti voidaan antaa muotoilun argumenteilla tai ilman.
    /// Katso tämän lomakkeen syntaksia [`std::fmt`]: stä.
    /// Muoto argumentteina käytetyt lausekkeet arvioidaan vain, jos väite epäonnistuu.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // Näiden väitteiden panic-sanoma on annetun lausekkeen tarkennettu arvo.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // hyvin yksinkertainen toiminto
    ///
    /// assert!(some_computation());
    ///
    /// // vakuuttaa mukautetulla viestillä
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Inline-kokoonpano.
    ///
    /// Lue [unstable book] käyttöä varten.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM-tyylinen sisäkokoonpano.
    ///
    /// Lue [unstable book] käyttöä varten.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Moduulitasoinen kokoonpano.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Tulokset välittivät tokens: n vakiolähtöön.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Ottaa käyttöön tai poistaa käytöstä jäljitystoiminnon, jota käytetään muiden makrojen virheenkorjauksessa.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Määritemakro, jota käytetään johdettaessa makroja.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Funktiolle määritetty attribuuttimakro muuttaakseen sen yksikötestiksi.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Funktiolle määritetty attribuuttimakro muuttaakseen siitä vertailutestin.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// `#[test]`-ja `#[bench]`-makrojen toteutustiedot.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Staattiselle attribuuttimakro rekisteröidään se globaalina allokaattorina.
    ///
    /// Katso myös [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Säilyttää kohteen, johon sitä käytetään, jos ohitettu polku on käytettävissä, ja poistaa sen muuten.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Laajentaa kaikki `#[cfg]`-ja `#[cfg_attr]`-attribuutit koodifragmentissa, johon sitä käytetään.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// `rustc`-kääntäjän epävakaat toteutustiedot, älä käytä.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// `rustc`-kääntäjän epävakaat toteutustiedot, älä käytä.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}