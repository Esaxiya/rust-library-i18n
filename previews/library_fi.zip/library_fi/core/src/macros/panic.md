Panics nykyinen säie.

Tämä antaa ohjelman lopettaa välittömästi ja antaa palautetta ohjelman soittajalle.
`panic!` tulisi käyttää, kun ohjelma on palautumattomassa tilassa.

Tämä makro on täydellinen tapa vahvistaa olosuhteet esimerkkikoodissa ja testeissä.
`panic!` on läheisesti sidottu sekä [`Option`][ounwrap]-että [`Result`][runwrap]-enumien `unwrap`-menetelmään.
Molemmat toteutukset kutsuvat `panic!`: ää, kun ne on asetettu [`None`]-tai [`Err`]-muunnoksiin.

Kun käytät `panic!()`: ää, voit määrittää merkkijonon hyötykuorman, joka on rakennettu [`format!`]-syntaksilla.
Tätä hyötykuormaa käytetään, kun ruiskutetaan panic kutsuvaan Rust-lankaan, aiheuttaen langan kokonaan panic: lle.

Oletusarvon `std` hook käyttäytyminen, ts
koodi, joka suoritetaan heti panic: n kutsumisen jälkeen, on tulostaa viestin hyötykuorma `stderr`: ään yhdessä `panic!()`-puhelun file/line/column-tietojen kanssa.

Voit ohittaa panic hook: n [`std::panic::set_hook()`]: llä.
hook: n sisällä pääsee panic: ksi `&dyn Any + Send`: nä, joka sisältää joko `&str` tai `String` tavallisille `panic!()`-kutsutapauksille.
panic: lle, jolla on muun tyyppinen arvo, [`panic_any`]: ää voidaan käyttää.

[`Result`] enum on usein parempi ratkaisu virheistä toipumiseen kuin `panic!`-makron käyttäminen.
Tätä makroa tulisi käyttää välttämään väärien arvojen käyttöä, kuten ulkoisista lähteistä.
Yksityiskohtaista tietoa virheiden käsittelystä on [book]: ssä.

Katso myös makro [`compile_error!`], josta ilmenee virheitä kokoamisen aikana.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Nykyinen toteutus

Jos pääkehys panics lopettaa kaikki ketjut ja lopettaa ohjelman koodilla `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





