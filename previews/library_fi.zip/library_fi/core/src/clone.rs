//! `Clone` trait-tyypeille, joita ei voida 'implisiittisesti kopioida'.
//!
//! Rust: ssä jotkut yksinkertaiset tyypit ovat "implicitly copyable", ja kun määrität ne tai välität ne argumentteina, vastaanotin saa kopion, jättäen alkuperäisen arvon paikalleen.
//! Nämä tyypit eivät vaadi allokointia kopiointiin ja niillä ei ole viimeistelylaitteita (ts. Ne eivät sisällä omistettuja laatikoita tai [`Drop`]-toteutusjärjestelmää), joten kääntäjä pitää niitä kopioimalla halvalla ja turvallisella tavalla.
//!
//! Muille tyypeille kopiot on tehtävä nimenomaisesti, sopimalla [`Clone`] trait: n käyttöönotosta ja kutsumalla [`clone`]-menetelmä.
//!
//! [`clone`]: Clone::clone
//!
//! Peruskäyttöesimerkki:
//!
//! ```
//! let s = String::new(); // Jousityyppiset työvälineet Klooni
//! let copy = s.clone(); // jotta voimme kloonata sen
//! ```
//!
//! Voit käyttää Clone trait: tä helposti myös `#[derive(Clone)]`: llä.Esimerkki:
//!
//! ```
//! #[derive(Clone)] // lisätään Clone trait Morpheus-rakenteeseen
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // ja nyt voimme kloonata sen!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Yleinen trait kykyyn nimenomaisesti kopioida objekti.
///
/// Eroa [`Copy`]: stä siinä, että [`Copy`] on implisiittinen ja erittäin halpa, kun taas `Clone` on aina eksplisiittinen ja voi olla kallista tai ei.
/// Näiden ominaisuuksien toteuttamiseksi Rust ei salli sinun täydentää [`Copy`]: ää, mutta voit lisätä `Clone`: n ja suorittaa mielivaltaisen koodin.
///
/// Koska `Clone` on yleisempi kuin [`Copy`], voit tehdä mistä tahansa [`Copy`]: stä myös `Clone`.
///
/// ## Derivable
///
/// Tätä trait: tä voidaan käyttää `#[derive]`: n kanssa, jos kaikki kentät ovat `Clone`.[`Clone`]: n "derive" toteutus kutsuu [`clone`]: ää kullekin kentälle.
///
/// [`clone`]: Clone::clone
///
/// Yleistä rakennetta varten `#[derive]` toteuttaa `Clone`: n ehdollisesti lisäämällä sitoutuneen `Clone`: n yleisiin parametreihin.
///
/// ```
/// // `derive` toteuttaa kloonin lukemista varten<T>kun T on klooni.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Kuinka voin ottaa `Clone`: n käyttöön?
///
/// Tyypeillä, jotka ovat [`Copy`], tulisi olla vähäinen `Clone`-toteutus.Muodollisemmin:
/// jos `T: Copy`, `x: T` ja `y: &T`, niin `let x = y.clone();` vastaa `let x = *y;`: ää.
/// Manuaalisen toteutuksen tulisi olla varovainen ylläpitääkseen tätä invarianttia;vaarallinen koodi ei kuitenkaan saa luottaa siihen muistin turvallisuuden varmistamiseksi.
///
/// Esimerkki on yleinen rakenne, jolla on funktion osoitin.Tässä tapauksessa `Clone`: n toteutusta ei voida "johtaa", mutta se voidaan toteuttaa seuraavasti:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Lisätoteuttajat
///
/// [implementors listed below][impls]: n lisäksi seuraavat tyypit toteuttavat myös `Clone`: n:
///
/// * Toimintokohteiden tyypit (ts. Kullekin toiminnolle määritetyt erilliset tyypit)
/// * Toimintojen osoittimen tyypit (esim. `fn() -> i32`)
/// * Matriisityypit, kaikenkokoisille, jos tuotetyypissä on myös `Clone` (esim. `[i32; 123456]`)
/// * Tuple-tyypit, jos jokainen komponentti toteuttaa myös `Clone`: n (esim. `()`, `(i32, bool)`)
/// * Suljetustyypit, jos ne eivät kerää arvoa ympäristöstä tai jos kaikki tällaiset kaapatut arvot toteuttavat `Clone`: n itse.
///   Huomaa, että jaetulla viitteellä kaapatut muuttujat toteuttavat aina `Clone`: n (vaikka referenssi ei myöskään), kun taas muutettavan viitteen siepatut muuttujat eivät koskaan toteuta `Clone`: tä.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Palauttaa kopion arvosta.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str toteuttaa Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Suorittaa kopioinnin `source`: stä.
    ///
    /// `a.clone_from(&b)` on toiminnallisuudeltaan vastaava kuin `a = b.clone()`, mutta se voidaan ohittaa `a`: n resurssien uudelleenkäytölle tarpeettomien varausten välttämiseksi.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Johda makro, joka tuottaa implantaatin trait `Clone`: stä.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): näitä rakenteita käyttää yksinomaan#[derive] väittääkseen, että jokainen tyypin komponentti toteuttaa kloonin tai kopion.
//
//
// Näiden rakenteiden ei pitäisi koskaan näkyä käyttäjäkoodissa.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// `Clone`: n toteutukset primitiivisille tyypeille.
///
/// Toteutukset, joita ei voida kuvata Rust: ssä, toteutetaan `traits::SelectionContext::copy_clone_conditions()`: ssä `rustc_trait_selection`: ssä.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Jaetut viitteet voidaan kloonata, mutta muutettavissa olevat viitteet *eivät*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Jaetut viitteet voidaan kloonata, mutta muutettavissa olevat viitteet *eivät*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}