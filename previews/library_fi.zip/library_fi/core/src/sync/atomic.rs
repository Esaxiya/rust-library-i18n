//! Atomityypit
//!
//! Atomityypit tarjoavat primitiivisen jaetun muistin viestinnän ketjujen välillä ja ovat muiden samanaikaisten tyyppien rakennuspalikoita.
//!
//! Tämä moduuli määrittelee atomiversiot valitusta joukosta primitiivisiä tyyppejä, mukaan lukien [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`] jne.
//! Atomic-tyypit esittävät toimintoja, jotka oikein käytettynä synkronoivat päivitykset ketjujen välillä.
//!
//! Kukin menetelmä ottaa [`Ordering`]: n, joka edustaa muistimuurin vahvuutta kyseiselle toiminnolle.Nämä tilaukset ovat samat kuin [C++20 atomic orderings][1].Katso lisätietoja [nomicon][2]: stä.
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Atomimuuttujia on turvallinen jakaa ketjujen välillä (ne toteuttavat [`Sync`]: n), mutta ne eivät itse tarjoa mekanismia jakamiseen ja seuraavat Rust: n [threading model](../../../std/thread/index.html#the-threading-model): ää.
//!
//! Yleisin tapa jakaa atomimuuttuja on laittaa se [`Arc`][arc]: ään (atomi-viitteenä laskettu jaettu osoitin).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Atomityypit voidaan tallentaa staattisiin muuttujiin ja alustaa vakiokäynnistimillä, kuten [`AtomicBool::new`].Atomistaatiota käytetään usein laiskaan globaaliin alustamiseen.
//!
//! # Portability
//!
//! Kaikissa tämän moduulin atomityypeissä taataan olevan [lock-free], jos niitä on saatavilla.Tämä tarkoittaa, että he eivät sisäisesti hanki globaalia mykistystä.Atomityyppejä ja toimintoja ei voida taata odottamatta.
//! Tämä tarkoittaa, että `fetch_or`: n kaltaiset toiminnot voidaan toteuttaa vertailu-ja vaihtosilmukalla.
//!
//! Atomioperaatiot voidaan toteuttaa komentokerroksessa suurempikokoisilla atomilla.Esimerkiksi jotkut käyttöympäristöt käyttävät nelitavuisia atomiohjeita `AtomicI8`: n toteuttamiseen.
//! Huomaa, että tällä emuloinnilla ei pitäisi olla vaikutusta koodin oikeellisuuteen, se on vain tietoinen asia.
//!
//! Tämän moduulin atomityypit eivät välttämättä ole käytettävissä kaikilla alustoilla.Kaikki atomityypit ovat kuitenkin laajalti saatavilla, ja niihin voidaan yleensä luottaa olemassa oleviin.Joitakin merkittäviä poikkeuksia ovat:
//!
//! * PowerPC ja 32-bittisillä osoittimilla varustetuilla MIPS-alustoilla ei ole `AtomicU64`-tai `AtomicI64`-tyyppejä.
//! * ARM `armv5te`: n kaltaiset alustat, jotka eivät ole Linux: ää varten, tarjoavat vain `load`-ja `store`-operaatioita, eivätkä tue (CAS)-vertailu-ja vaihtotoimintoja, kuten `swap`, `fetch_add` jne.
//! Lisäksi Linux: ssä nämä CAS-toiminnot toteutetaan [operating system support]: n kautta, mihin voi liittyä suoritusrangaistus.
//! * ARM kohteet, joissa on `thumbv6m`, tarjoavat vain `load`-ja `store`-operaatioita, eivätkä tue (CAS)-vertailu-ja vaihtotoimintoja, kuten `swap`, `fetch_add` jne.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Huomaa, että voidaan lisätä future-alustoja, joilla ei myöskään ole tukea joillekin atomitoiminnoille.Maksimikannettava koodi haluaa olla varovainen siitä, mitä atomityyppejä käytetään.
//! `AtomicUsize` ja `AtomicIsize` ovat yleensä kannettavimpia, mutta silloinkin niitä ei ole saatavilla kaikkialla.
//! Vertailun vuoksi `std`-kirjasto vaatii osoittimen kokoisen atomin, vaikka `core` ei.
//!
//! Tällä hetkellä sinun on käytettävä `#[cfg(target_arch)]`: ää ensisijaisesti ehdolliseen koodaamiseen atomien kanssa.On myös epävakaa `#[cfg(target_has_atomic)]`, joka voidaan stabiloida future: ssä.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Yksinkertainen spinlock:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Odota, että toinen lanka vapauttaa lukon
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Pidä maailmanlaajuinen live-säikeiden määrä:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Boolen tyyppi, joka voidaan jakaa turvallisesti ketjujen välillä.
///
/// Tällä tyypillä on sama muistin esitys kuin [`bool`]: llä.
///
/// **Huomautus**: Tämä tyyppi on saatavana vain alustoilla, jotka tukevat `u8`: n atomikuormitusta ja varastoja.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Luo `false`: ksi alustetun `AtomicBool`: n.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Lähetä on implisiittisesti toteutettu AtomicBoolille.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Raaka osoitintyyppi, joka voidaan jakaa turvallisesti ketjujen välillä.
///
/// Tällä tyypillä on sama muistin esitys kuin `*mut T`: llä.
///
/// **Huomaa**: Tämä tyyppi on saatavana vain alustoilla, jotka tukevat atomikuormitusta ja osoittimien varastoja.
/// Sen koko riippuu kohden osoittimen koosta.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Luo tyhjän `AtomicPtr<T>`: n.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Atomimuistitilaukset
///
/// Muistijärjestys määrittelee tavan, jolla atomioperaatiot synkronoivat muistia.
/// Heikimmässä [`Ordering::Relaxed`]: ssä vain tahdistettu muisti, jota toiminto koskettaa suoraan.
/// Toisaalta [`Ordering::SeqCst`]-toimintojen myymälälataus-synkronointipari synkronoi muun muistin säilyttäen lisäksi tällaisten operaatioiden kokonaisjärjestyksen kaikissa säikeissä.
///
///
/// Rust: n muistijärjestys on [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// Katso lisätietoja [nomicon]: stä.
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Ei tilausrajoituksia, vain atomioperaatiot.
    ///
    /// Vastaa [`memory_order_relaxed`]: ää C++ 20: ssa.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Kun yhdistetään myymälään, kaikki aiemmat toiminnot tilataan ennen tämän arvon lataamista [`Acquire`] (tai vahvempi) tilauksella.
    ///
    /// Erityisesti kaikki edelliset kirjoitukset tulevat näkyviin kaikille säikeille, jotka suorittavat tämän arvon [`Acquire`] (tai vahvemman) kuormituksen.
    ///
    /// Huomaa, että tämän tilauksen käyttö toiminnossa, joka yhdistää kuormat ja tallentaa, johtaa [`Relaxed`]-kuormitustapahtumaan!
    ///
    /// Tämä tilaus koskee vain toimintoja, jotka voivat suorittaa myymälän.
    ///
    /// Vastaa [`memory_order_release`]: ää C++ 20: ssa.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Yhdistettynä kuormaan, jos ladattu arvo kirjoitettiin myymäläkäynnistyksellä [`Release`] (tai vahvempi)-tilauksella, kaikki seuraavat toiminnot tilataan kyseisen varaston jälkeen.
    /// Erityisesti kaikki myöhemmät kuormat näkevät ennen kauppaa kirjoitetut tiedot.
    ///
    /// Huomaa, että tämän tilauksen käyttäminen kuormia ja varastoja yhdistävään toimintaan johtaa [`Relaxed`]-varastotoimintaan!
    ///
    /// Tämä tilaus koskee vain toimintoja, jotka voivat suorittaa kuormituksen.
    ///
    /// Vastaa [`memory_order_acquire`]: ää C++ 20: ssa.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Sisältää sekä [`Acquire`]: n että [`Release`]: n vaikutukset:
    /// Kuormille se käyttää [`Acquire`]-tilausta.Kaupoissa se käyttää [`Release`]-tilausta.
    ///
    /// Huomaa, että `compare_and_swap`: n tapauksessa on mahdollista, että operaatio ei lopulta suorita mitään tallennustilaa, ja siksi sillä on vain [`Acquire`]-tilauksia.
    ///
    /// `AcqRel` ei kuitenkaan koskaan tee [`Relaxed`]-käyttöoikeuksia.
    ///
    /// Tämä tilaus koskee vain toimintoja, joissa yhdistyvät sekä kuormat että varastot.
    ///
    /// Vastaa [`memory_order_acq_rel`]: ää C++ 20: ssa.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Kuten [`Hanki`]/[`Vapauta`]/[``AcqRel`](vastaavasti lataus-, säilytys-ja lataus varastolla-toiminnoille) ja lisäksi takuu siitä, että kaikki ketjut näkevät kaikki peräkkäiset yhdenmukaiset toiminnot samassa järjestyksessä .
    ///
    ///
    /// Vastaa [`memory_order_seq_cst`]: ää C++ 20: ssa.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// [`AtomicBool`] alustetaan `false`: ksi.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Luo uuden `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Palauttaa muutettavan viitteen alla olevaan [`bool`]: ään.
    ///
    /// Tämä on turvallista, koska muutettava viite takaa, että mikään muu ketju ei pääse samanaikaisesti atomidataan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // TURVALLISUUS: muutettava viite takaa ainutlaatuisen omistajuuden.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Hanki atomiyhteys `&mut bool`: ään.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // TURVALLISUUS: muutettava viite takaa ainutlaatuisen omistajuuden ja
        // sekä `bool`: n että `Self`: n kohdistus on 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Kuluttaa atomin ja palauttaa sisältämän arvon.
    ///
    /// Tämä on turvallista, koska `self`: n välittäminen arvolla takaa, että mikään muu ketju ei pääse samanaikaisesti atomidataan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Lataa arvon bool: stä.
    ///
    /// `load` ottaa [`Ordering`]-argumentin, joka kuvaa tämän operaation muistijärjestystä.
    /// Mahdolliset arvot ovat [`SeqCst`], [`Acquire`] ja [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics, jos `order` on [`Release`] tai [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // TURVALLISUUS: atomirakenteet ja raaka estävät kaikki tietokilpailut
        // syötetty osoitin on kelvollinen, koska saimme sen viitteestä.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Tallentaa arvon bool: ään.
    ///
    /// `store` ottaa [`Ordering`]-argumentin, joka kuvaa tämän operaation muistijärjestystä.
    /// Mahdolliset arvot ovat [`SeqCst`], [`Release`] ja [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics, jos `order` on [`Acquire`] tai [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // TURVALLISUUS: atomirakenteet ja raaka estävät kaikki tietokilpailut
        // syötetty osoitin on kelvollinen, koska saimme sen viitteestä.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Tallentaa arvon bool: ään palauttaen edellisen arvon.
    ///
    /// `swap` ottaa [`Ordering`]-argumentin, joka kuvaa tämän operaation muistijärjestystä.Kaikki tilaustilat ovat mahdollisia.
    /// Huomaa, että [`Acquire`]: n käyttö tekee tämän toiminnon varasto-osasta [`Relaxed`] ja [`Release`]: n käyttö kuormitusosaksi [`Relaxed`].
    ///
    ///
    /// **Note:** Tämä menetelmä on käytettävissä vain alustoilla, jotka tukevat atomioperaatioita `u8`: ssä.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // TURVALLISUUS: Atomiset tekijät estävät tietokilpailut.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Tallentaa arvon [`bool`]: ään, jos nykyinen arvo on sama kuin `current`.
    ///
    /// Palautusarvo on aina edellinen arvo.Jos se on yhtä suuri kuin `current`, arvo päivitettiin.
    ///
    /// `compare_and_swap` ottaa myös [`Ordering`]-argumentin, joka kuvaa tämän operaation muistijärjestystä.
    /// Huomaa, että jopa [`AcqRel`]: ää käytettäessä operaatio saattaa epäonnistua ja suorittaa siten vain `Acquire`-kuormituksen, mutta ei `Release`-semantiikkaa.
    /// [`Acquire`]: n käyttäminen tekee tallennusosasta tämän toiminnan [`Relaxed`], jos se tapahtuu, ja [`Release`]: n käyttö tekee kuormitusosasta [`Relaxed`].
    ///
    /// **Note:** Tämä menetelmä on käytettävissä vain alustoilla, jotka tukevat atomioperaatioita `u8`: ssä.
    ///
    /// # Siirtyminen malleihin `compare_exchange` ja `compare_exchange_weak`
    ///
    /// `compare_and_swap` vastaa `compare_exchange`: ää seuraavalla kartoituksella muistijärjestyksiä varten:
    ///
    /// Alkuperäinen |Menestys |Epäonnistuminen
    /// -------- | ------- | -------
    /// Rento |Rento |Rento Hanki |Hanki |Hanki julkaisu |Vapauta |Rento AcqRel |AcqRel |Hanki SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` sallitaan epäonnistua väärin silloinkin, kun vertailu onnistuu, mikä antaa kääntäjän luoda paremman kokoonpanokoodin, kun vertailua ja vaihtamista käytetään silmukassa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Tallentaa arvon [`bool`]: ään, jos nykyinen arvo on sama kuin `current`.
    ///
    /// Palautusarvo on tulos, joka osoittaa, onko uusi arvo kirjoitettu ja sisältääkö edellisen arvon.
    /// Menestyksessä tämä arvo taataan olevan yhtä suuri kuin `current`.
    ///
    /// `compare_exchange` vie kaksi [`Ordering`]-argumenttia kuvaamaan tämän operaation muistijärjestystä.
    /// `success` kuvaa vaaditun tilauksen luku-, muokkaa-kirjoita-operaatiolle, joka tapahtuu, jos vertailu `current`: ään onnistuu.
    /// `failure` kuvaa vaaditun tilauksen kuormitustoiminnalle, joka tapahtuu, kun vertailu epäonnistuu.
    /// [`Acquire`]: n käyttäminen onnistuneena tilauksena tekee myymälästä osan tätä toimintoa [`Relaxed`], ja [`Release`]: n käyttäminen onnistuneen latauksen [`Relaxed`].
    ///
    /// Vikatilaus voi olla vain [`SeqCst`], [`Acquire`] tai [`Relaxed`], ja sen on oltava yhtä suuri tai heikompi kuin onnistunut tilaus.
    ///
    /// **Note:** Tämä menetelmä on käytettävissä vain alustoilla, jotka tukevat atomioperaatioita `u8`: ssä.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // TURVALLISUUS: Atomiset tekijät estävät tietokilpailut.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Tallentaa arvon [`bool`]: ään, jos nykyinen arvo on sama kuin `current`.
    ///
    /// Toisin kuin [`AtomicBool::compare_exchange`], tämän toiminnon annetaan epäonnistua väärin, vaikka vertailu onnistuu, mikä voi johtaa tehokkaampaan koodiin joillakin alustoilla.
    ///
    /// Palautusarvo on tulos, joka osoittaa, onko uusi arvo kirjoitettu ja sisältääkö edellisen arvon.
    ///
    /// `compare_exchange_weak` vie kaksi [`Ordering`]-argumenttia kuvaamaan tämän operaation muistijärjestystä.
    /// `success` kuvaa vaaditun tilauksen luku-, muokkaa-kirjoita-operaatiolle, joka tapahtuu, jos vertailu `current`: ään onnistuu.
    /// `failure` kuvaa vaaditun tilauksen kuormitustoiminnalle, joka tapahtuu, kun vertailu epäonnistuu.
    /// [`Acquire`]: n käyttäminen onnistuneena tilauksena tekee myymälästä osan tätä toimintoa [`Relaxed`], ja [`Release`]: n käyttäminen onnistuneen latauksen [`Relaxed`].
    /// Vikatilaus voi olla vain [`SeqCst`], [`Acquire`] tai [`Relaxed`], ja sen on oltava yhtä suuri tai heikompi kuin onnistunut tilaus.
    ///
    /// **Note:** Tämä menetelmä on käytettävissä vain alustoilla, jotka tukevat atomioperaatioita `u8`: ssä.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // TURVALLISUUS: Atomiset tekijät estävät tietokilpailut.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Looginen "and" loogisella arvolla.
    ///
    /// Suorittaa loogisen "and"-operaation nykyiselle arvolle ja argumentille `val` ja asettaa uuden arvon tulokseen.
    ///
    /// Palauttaa edellisen arvon.
    ///
    /// `fetch_and` ottaa [`Ordering`]-argumentin, joka kuvaa tämän operaation muistijärjestystä.Kaikki tilaustilat ovat mahdollisia.
    /// Huomaa, että [`Acquire`]: n käyttö tekee tämän toiminnon varasto-osasta [`Relaxed`] ja [`Release`]: n käyttö kuormitusosaksi [`Relaxed`].
    ///
    ///
    /// **Note:** Tämä menetelmä on käytettävissä vain alustoilla, jotka tukevat atomioperaatioita `u8`: ssä.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // TURVALLISUUS: Atomiset tekijät estävät tietokilpailut.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Looginen "nand" loogisella arvolla.
    ///
    /// Suorittaa loogisen "nand"-operaation nykyiselle arvolle ja argumentille `val` ja asettaa uuden arvon tulokseen.
    ///
    /// Palauttaa edellisen arvon.
    ///
    /// `fetch_nand` ottaa [`Ordering`]-argumentin, joka kuvaa tämän operaation muistijärjestystä.Kaikki tilaustilat ovat mahdollisia.
    /// Huomaa, että [`Acquire`]: n käyttö tekee tämän toiminnon varasto-osasta [`Relaxed`] ja [`Release`]: n käyttö kuormitusosaksi [`Relaxed`].
    ///
    ///
    /// **Note:** Tämä menetelmä on käytettävissä vain alustoilla, jotka tukevat atomioperaatioita `u8`: ssä.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Emme voi käyttää atomic_nandia tässä, koska se voi johtaa bool: ään, jonka arvo on virheellinen.
        // Tämä tapahtuu, koska atomioperaatio suoritetaan sisäisesti 8-bittisellä kokonaisluvulla, joka asettaa ylemmät 7 bittiä.
        //
        // Joten käytämme vain fetch_xor tai swap sijaan.
        if val {
            // ! (x&true)== !x bool täytyy kääntää.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==true Meidän on asetettava bool arvoksi true.
            //
            self.swap(true, order)
        }
    }

    /// Looginen "or" loogisella arvolla.
    ///
    /// Suorittaa loogisen "or"-operaation nykyiselle arvolle ja argumentille `val` ja asettaa uuden arvon tulokseen.
    ///
    /// Palauttaa edellisen arvon.
    ///
    /// `fetch_or` ottaa [`Ordering`]-argumentin, joka kuvaa tämän operaation muistijärjestystä.Kaikki tilaustilat ovat mahdollisia.
    /// Huomaa, että [`Acquire`]: n käyttö tekee tämän toiminnon varasto-osasta [`Relaxed`] ja [`Release`]: n käyttö kuormitusosaksi [`Relaxed`].
    ///
    ///
    /// **Note:** Tämä menetelmä on käytettävissä vain alustoilla, jotka tukevat atomioperaatioita `u8`: ssä.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // TURVALLISUUS: Atomiset tekijät estävät tietokilpailut.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Looginen "xor" loogisella arvolla.
    ///
    /// Suorittaa loogisen "xor"-operaation nykyiselle arvolle ja argumentille `val` ja asettaa uuden arvon tulokseen.
    ///
    /// Palauttaa edellisen arvon.
    ///
    /// `fetch_xor` ottaa [`Ordering`]-argumentin, joka kuvaa tämän operaation muistijärjestystä.Kaikki tilaustilat ovat mahdollisia.
    /// Huomaa, että [`Acquire`]: n käyttö tekee tämän toiminnon varasto-osasta [`Relaxed`] ja [`Release`]: n käyttö kuormitusosaksi [`Relaxed`].
    ///
    ///
    /// **Note:** Tämä menetelmä on käytettävissä vain alustoilla, jotka tukevat atomioperaatioita `u8`: ssä.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // TURVALLISUUS: Atomiset tekijät estävät tietokilpailut.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Palauttaa muutettavan osoittimen alla olevaan [`bool`]: ään.
    ///
    /// Ei-atomisten lukujen ja kirjoitusten tekeminen tuloksena olevaan kokonaislukuun voi olla tietokilpailu.
    /// Tämä menetelmä on enimmäkseen hyödyllinen FFI: lle, jossa funktion allekirjoitus voi käyttää `*mut bool`: ää `&AtomicBool`: n sijaan.
    ///
    /// `*mut`-osoittimen palauttaminen jaetusta viitteestä tähän atomiin on turvallista, koska atomityypit toimivat sisäisen muuttuvuuden kanssa.
    /// Kaikki atomin muunnokset muuttavat arvoa yhteisen viitteen avulla ja voivat tehdä sen turvallisesti, kunhan ne käyttävät atomioperaatioita.
    /// Palautetun raakaosoittimen käyttö vaatii `unsafe`-lohkon, ja sen on silti noudatettava samaa rajoitusta: sen toimintojen on oltava atomisia.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Hakee arvon ja käyttää siihen funktion, joka palauttaa valinnaisen uuden arvon.Palauttaa arvon `Ok(previous_value)` arvosta `Ok(previous_value)`, jos funktio palautti arvon `Some(_)`, muuten arvon `Err(previous_value)`.
    ///
    /// Note: Tämä voi kutsua funktiota useita kertoja, jos arvo on muutettu muista säikeistä sillä välin, kunhan funktio palauttaa `Some(_)`: n, mutta funktiota on käytetty vain kerran tallennettuun arvoon.
    ///
    ///
    /// `fetch_update` vie kaksi [`Ordering`]-argumenttia kuvaamaan tämän operaation muistijärjestystä.
    /// Ensimmäinen kuvaa vaaditun tilauksen, kun operaatio onnistuu, kun taas toinen kuvaa vaaditun kuormitustilauksen.
    /// Nämä vastaavat [`AtomicBool::compare_exchange`]: n onnistumis-ja epäonnistumisjärjestyksiä.
    ///
    /// [`Acquire`]: n käyttäminen onnistuneena tilauksena tekee myymälästä osan tätä toimintoa [`Relaxed`], ja [`Release`]: n käyttäminen tekee lopullisen onnistuneen latauksen [`Relaxed`].
    /// (failed)-kuormitustilaus voi olla vain [`SeqCst`], [`Acquire`] tai [`Relaxed`], ja sen on oltava yhtä suuri tai heikompi kuin onnistunut tilaus.
    ///
    /// **Note:** Tämä menetelmä on käytettävissä vain alustoilla, jotka tukevat atomioperaatioita `u8`: ssä.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Luo uuden `AtomicPtr`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Palauttaa muutettavan viitteen taustalla olevaan osoittimeen.
    ///
    /// Tämä on turvallista, koska muutettava viite takaa, että mikään muu ketju ei pääse samanaikaisesti atomidataan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Hanki atomiyhteys osoittimeen.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - muutettava viite takaa ainutlaatuisen omistajuuden.
        //  - `*mut T`: n ja `Self`: n kohdistus on sama kaikilla rust: n tukemilla alustoilla, kuten edellä todettiin.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Kuluttaa atomin ja palauttaa sisältämän arvon.
    ///
    /// Tämä on turvallista, koska `self`: n välittäminen arvolla takaa, että mikään muu ketju ei pääse samanaikaisesti atomidataan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Lataa arvon osoittimesta.
    ///
    /// `load` ottaa [`Ordering`]-argumentin, joka kuvaa tämän operaation muistijärjestystä.
    /// Mahdolliset arvot ovat [`SeqCst`], [`Acquire`] ja [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics, jos `order` on [`Release`] tai [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // TURVALLISUUS: Atomiset tekijät estävät tietokilpailut.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Tallentaa arvon osoittimeen.
    ///
    /// `store` ottaa [`Ordering`]-argumentin, joka kuvaa tämän operaation muistijärjestystä.
    /// Mahdolliset arvot ovat [`SeqCst`], [`Release`] ja [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics, jos `order` on [`Acquire`] tai [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // TURVALLISUUS: Atomiset tekijät estävät tietokilpailut.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Tallentaa arvon osoittimeen palauttamalla edellisen arvon.
    ///
    /// `swap` ottaa [`Ordering`]-argumentin, joka kuvaa tämän operaation muistijärjestystä.Kaikki tilaustilat ovat mahdollisia.
    /// Huomaa, että [`Acquire`]: n käyttö tekee tämän toiminnon varasto-osasta [`Relaxed`] ja [`Release`]: n käyttö kuormitusosaksi [`Relaxed`].
    ///
    ///
    /// **Note:** Tämä menetelmä on käytettävissä vain alustoilla, jotka tukevat atomitoimintoja osoittimissa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // TURVALLISUUS: Atomiset tekijät estävät tietokilpailut.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Tallentaa arvon osoittimeen, jos nykyinen arvo on sama kuin `current`-arvo.
    ///
    /// Palautusarvo on aina edellinen arvo.Jos se on yhtä suuri kuin `current`, arvo päivitettiin.
    ///
    /// `compare_and_swap` ottaa myös [`Ordering`]-argumentin, joka kuvaa tämän operaation muistijärjestystä.
    /// Huomaa, että jopa [`AcqRel`]: ää käytettäessä operaatio saattaa epäonnistua ja suorittaa siten vain `Acquire`-kuormituksen, mutta ei `Release`-semantiikkaa.
    /// [`Acquire`]: n käyttäminen tekee tallennusosasta tämän toiminnan [`Relaxed`], jos se tapahtuu, ja [`Release`]: n käyttö tekee kuormitusosasta [`Relaxed`].
    ///
    /// **Note:** Tämä menetelmä on käytettävissä vain alustoilla, jotka tukevat atomitoimintoja osoittimissa.
    ///
    /// # Siirtyminen malleihin `compare_exchange` ja `compare_exchange_weak`
    ///
    /// `compare_and_swap` vastaa `compare_exchange`: ää seuraavalla kartoituksella muistijärjestyksiä varten:
    ///
    /// Alkuperäinen |Menestys |Epäonnistuminen
    /// -------- | ------- | -------
    /// Rento |Rento |Rento Hanki |Hanki |Hanki julkaisu |Vapauta |Rento AcqRel |AcqRel |Hanki SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` sallitaan epäonnistua väärin silloinkin, kun vertailu onnistuu, mikä antaa kääntäjän luoda paremman kokoonpanokoodin, kun vertailua ja vaihtamista käytetään silmukassa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Tallentaa arvon osoittimeen, jos nykyinen arvo on sama kuin `current`-arvo.
    ///
    /// Palautusarvo on tulos, joka osoittaa, onko uusi arvo kirjoitettu ja sisältääkö edellisen arvon.
    /// Menestyksessä tämä arvo taataan olevan yhtä suuri kuin `current`.
    ///
    /// `compare_exchange` vie kaksi [`Ordering`]-argumenttia kuvaamaan tämän operaation muistijärjestystä.
    /// `success` kuvaa vaaditun tilauksen luku-, muokkaa-kirjoita-operaatiolle, joka tapahtuu, jos vertailu `current`: ään onnistuu.
    /// `failure` kuvaa vaaditun tilauksen kuormitustoiminnalle, joka tapahtuu, kun vertailu epäonnistuu.
    /// [`Acquire`]: n käyttäminen onnistuneena tilauksena tekee myymälästä osan tätä toimintoa [`Relaxed`], ja [`Release`]: n käyttäminen onnistuneen latauksen [`Relaxed`].
    ///
    /// Vikatilaus voi olla vain [`SeqCst`], [`Acquire`] tai [`Relaxed`], ja sen on oltava yhtä suuri tai heikompi kuin onnistunut tilaus.
    ///
    /// **Note:** Tämä menetelmä on käytettävissä vain alustoilla, jotka tukevat atomitoimintoja osoittimissa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // TURVALLISUUS: Atomiset tekijät estävät tietokilpailut.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Tallentaa arvon osoittimeen, jos nykyinen arvo on sama kuin `current`-arvo.
    ///
    /// Toisin kuin [`AtomicPtr::compare_exchange`], tämän toiminnon annetaan epäonnistua väärin, vaikka vertailu onnistuu, mikä voi johtaa tehokkaampaan koodiin joillakin alustoilla.
    ///
    /// Palautusarvo on tulos, joka osoittaa, onko uusi arvo kirjoitettu ja sisältääkö edellisen arvon.
    ///
    /// `compare_exchange_weak` vie kaksi [`Ordering`]-argumenttia kuvaamaan tämän operaation muistijärjestystä.
    /// `success` kuvaa vaaditun tilauksen luku-, muokkaa-kirjoita-operaatiolle, joka tapahtuu, jos vertailu `current`: ään onnistuu.
    /// `failure` kuvaa vaaditun tilauksen kuormitustoiminnalle, joka tapahtuu, kun vertailu epäonnistuu.
    /// [`Acquire`]: n käyttäminen onnistuneena tilauksena tekee myymälästä osan tätä toimintoa [`Relaxed`], ja [`Release`]: n käyttäminen onnistuneen latauksen [`Relaxed`].
    /// Vikatilaus voi olla vain [`SeqCst`], [`Acquire`] tai [`Relaxed`], ja sen on oltava yhtä suuri tai heikompi kuin onnistunut tilaus.
    ///
    /// **Note:** Tämä menetelmä on käytettävissä vain alustoilla, jotka tukevat atomitoimintoja osoittimissa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // TURVALLISUUS: Tämä ominaisuus on vaarallinen, koska se toimii raakalla osoittimella
        // mutta tiedämme varmasti, että osoitin on kelvollinen (saimme sen juuri viitteenä olevalta `UnsafeCell`: ltä) ja itse atomitoiminnan avulla voimme turvallisesti mutatoida `UnsafeCell`-sisällön.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Hakee arvon ja käyttää siihen funktion, joka palauttaa valinnaisen uuden arvon.Palauttaa arvon `Ok(previous_value)` arvosta `Ok(previous_value)`, jos funktio palautti arvon `Some(_)`, muuten arvon `Err(previous_value)`.
    ///
    /// Note: Tämä voi kutsua funktiota useita kertoja, jos arvo on muutettu muista säikeistä sillä välin, kunhan funktio palauttaa `Some(_)`: n, mutta funktiota on käytetty vain kerran tallennettuun arvoon.
    ///
    ///
    /// `fetch_update` vie kaksi [`Ordering`]-argumenttia kuvaamaan tämän operaation muistijärjestystä.
    /// Ensimmäinen kuvaa vaaditun tilauksen, kun operaatio onnistuu, kun taas toinen kuvaa vaaditun kuormitustilauksen.
    /// Nämä vastaavat [`AtomicPtr::compare_exchange`]: n onnistumis-ja epäonnistumisjärjestyksiä.
    ///
    /// [`Acquire`]: n käyttäminen onnistuneena tilauksena tekee myymälästä osan tätä toimintoa [`Relaxed`], ja [`Release`]: n käyttäminen tekee lopullisen onnistuneen latauksen [`Relaxed`].
    /// (failed)-kuormitustilaus voi olla vain [`SeqCst`], [`Acquire`] tai [`Relaxed`], ja sen on oltava yhtä suuri tai heikompi kuin onnistunut tilaus.
    ///
    /// **Note:** Tämä menetelmä on käytettävissä vain alustoilla, jotka tukevat atomitoimintoja osoittimissa.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Muuntaa `bool`: n `AtomicBool`: ksi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Tätä makroa ei käytetä joissakin arkkitehtuureissa.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Kokonaislukutyyppi, joka voidaan jakaa turvallisesti ketjujen välillä.
        ///
        /// Tällä tyypillä on sama muistin esitys kuin taustalla olevalla kokonaislukutyypillä ["
        ///
        #[doc = $s_int_type]
        /// `].
        /// Lisätietoja atomityyppien ja muiden kuin atomiatyyppien välisistä eroista sekä tietoja tämäntyyppisten siirrettävyydestä, katso [module-level documentation].
        ///
        ///
        /// **Note:** Tämä tyyppi on saatavana vain alustoilla, jotka tukevat atomikuormitusta ja varastoivat [
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Atominen kokonaisluku alustetaan arvoon `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Lähetä on implisiittisesti toteutettu.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Luo uuden atomiluvun.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Palauttaa muutettavan viitteen alla olevaan kokonaislukuun.
            ///
            /// Tämä on turvallista, koska muutettava viite takaa, että mikään muu ketju ei pääse samanaikaisesti atomidataan.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// olkoon mut jotkut_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (jotkut_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - muutettava viite takaa ainutlaatuisen omistajuuden.
                //  - `$int_type`: n ja `Self`: n kohdistus on sama, kuten $cfg_align lupasi ja todennettu edellä.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Kuluttaa atomin ja palauttaa sisältämän arvon.
            ///
            /// Tämä on turvallista, koska `self`: n välittäminen arvolla takaa, että mikään muu ketju ei pääse samanaikaisesti atomidataan.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Lataa arvon atomi-kokonaisluvusta.
            ///
            /// `load` ottaa [`Ordering`]-argumentin, joka kuvaa tämän operaation muistijärjestystä.
            /// Mahdolliset arvot ovat [`SeqCst`], [`Acquire`] ja [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics, jos `order` on [`Release`] tai [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // TURVALLISUUS: Atomiset tekijät estävät tietokilpailut.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Tallentaa arvon atomi-kokonaislukuun.
            ///
            /// `store` ottaa [`Ordering`]-argumentin, joka kuvaa tämän operaation muistijärjestystä.
            ///  Mahdolliset arvot ovat [`SeqCst`], [`Release`] ja [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics, jos `order` on [`Acquire`] tai [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // TURVALLISUUS: Atomiset tekijät estävät tietokilpailut.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Tallentaa arvon atomi-kokonaislukuun palauttaen edellisen arvon.
            ///
            /// `swap` ottaa [`Ordering`]-argumentin, joka kuvaa tämän operaation muistijärjestystä.Kaikki tilaustilat ovat mahdollisia.
            /// Huomaa, että [`Acquire`]: n käyttö tekee tämän toiminnon varasto-osasta [`Relaxed`] ja [`Release`]: n käyttö kuormitusosaksi [`Relaxed`].
            ///
            ///
            /// **Huomautus**: Tämä menetelmä on käytettävissä vain alustoilla, jotka tukevat atomioperaatioita
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // TURVALLISUUS: Atomiset tekijät estävät tietokilpailut.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Tallentaa arvon atomi-kokonaislukuun, jos nykyinen arvo on sama kuin `current`-arvo.
            ///
            /// Palautusarvo on aina edellinen arvo.Jos se on yhtä suuri kuin `current`, arvo päivitettiin.
            ///
            /// `compare_and_swap` ottaa myös [`Ordering`]-argumentin, joka kuvaa tämän operaation muistijärjestystä.
            /// Huomaa, että jopa [`AcqRel`]: ää käytettäessä operaatio saattaa epäonnistua ja suorittaa siten vain `Acquire`-kuormituksen, mutta ei `Release`-semantiikkaa.
            ///
            /// [`Acquire`]: n käyttäminen tekee tallennusosasta tämän toiminnan [`Relaxed`], jos se tapahtuu, ja [`Release`]: n käyttö tekee kuormitusosasta [`Relaxed`].
            ///
            /// **Huomautus**: Tämä menetelmä on käytettävissä vain alustoilla, jotka tukevat atomioperaatioita
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Siirtyminen malleihin `compare_exchange` ja `compare_exchange_weak`
            ///
            /// `compare_and_swap` vastaa `compare_exchange`: ää seuraavalla kartoituksella muistijärjestyksiä varten:
            ///
            /// Alkuperäinen |Menestys |Epäonnistuminen
            /// -------- | ------- | -------
            /// Rento |Rento |Rento Hanki |Hanki |Hanki julkaisu |Vapauta |Rento AcqRel |AcqRel |Hanki SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` sallitaan epäonnistua väärin silloinkin, kun vertailu onnistuu, mikä antaa kääntäjän luoda paremman kokoonpanokoodin, kun vertailua ja vaihtamista käytetään silmukassa.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Tallentaa arvon atomi-kokonaislukuun, jos nykyinen arvo on sama kuin `current`-arvo.
            ///
            /// Palautusarvo on tulos, joka osoittaa, onko uusi arvo kirjoitettu ja sisältääkö edellisen arvon.
            /// Menestyksessä tämä arvo taataan olevan yhtä suuri kuin `current`.
            ///
            /// `compare_exchange` vie kaksi [`Ordering`]-argumenttia kuvaamaan tämän operaation muistijärjestystä.
            /// `success` kuvaa vaaditun tilauksen luku-, muokkaa-kirjoita-operaatiolle, joka tapahtuu, jos vertailu `current`: ään onnistuu.
            /// `failure` kuvaa vaaditun tilauksen kuormitustoiminnalle, joka tapahtuu, kun vertailu epäonnistuu.
            /// [`Acquire`]: n käyttäminen onnistuneena tilauksena tekee myymälästä osan tätä toimintoa [`Relaxed`], ja [`Release`]: n käyttäminen onnistuneen latauksen [`Relaxed`].
            ///
            /// Vikatilaus voi olla vain [`SeqCst`], [`Acquire`] tai [`Relaxed`], ja sen on oltava yhtä suuri tai heikompi kuin onnistunut tilaus.
            ///
            /// **Huomautus**: Tämä menetelmä on käytettävissä vain alustoilla, jotka tukevat atomioperaatioita
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // TURVALLISUUS: Atomiset tekijät estävät tietokilpailut.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Tallentaa arvon atomi-kokonaislukuun, jos nykyinen arvo on sama kuin `current`-arvo.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// tämän toiminnon annetaan epäonnistua väärin, vaikka vertailu onnistuu, mikä voi johtaa tehokkaampaan koodiin joillakin alustoilla.
            /// Palautusarvo on tulos, joka osoittaa, onko uusi arvo kirjoitettu ja sisältääkö edellisen arvon.
            ///
            /// `compare_exchange_weak` vie kaksi [`Ordering`]-argumenttia kuvaamaan tämän operaation muistijärjestystä.
            /// `success` kuvaa vaaditun tilauksen luku-, muokkaa-kirjoita-operaatiolle, joka tapahtuu, jos vertailu `current`: ään onnistuu.
            /// `failure` kuvaa vaaditun tilauksen kuormitustoiminnalle, joka tapahtuu, kun vertailu epäonnistuu.
            /// [`Acquire`]: n käyttäminen onnistuneena tilauksena tekee myymälästä osan tätä toimintoa [`Relaxed`], ja [`Release`]: n käyttäminen onnistuneen latauksen [`Relaxed`].
            ///
            /// Vikatilaus voi olla vain [`SeqCst`], [`Acquire`] tai [`Relaxed`], ja sen on oltava yhtä suuri tai heikompi kuin onnistunut tilaus.
            ///
            /// **Huomautus**: Tämä menetelmä on käytettävissä vain alustoilla, jotka tukevat atomioperaatioita
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// anna mut vanha= val.load(Ordering::Relaxed);
            /// silmukka {anna uuden=vanhan * 2;
            ///     ottelu val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // TURVALLISUUS: Atomiset tekijät estävät tietokilpailut.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Lisää nykyiseen arvoon palauttaen edellisen arvon.
            ///
            /// Tämä toiminto kiertyy ylivuotoon.
            ///
            /// `fetch_add` ottaa [`Ordering`]-argumentin, joka kuvaa tämän operaation muistijärjestystä.Kaikki tilaustilat ovat mahdollisia.
            /// Huomaa, että [`Acquire`]: n käyttö tekee tämän toiminnon varasto-osasta [`Relaxed`] ja [`Release`]: n käyttö kuormitusosaksi [`Relaxed`].
            ///
            ///
            /// **Huomautus**: Tämä menetelmä on käytettävissä vain alustoilla, jotka tukevat atomioperaatioita
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // TURVALLISUUS: Atomiset tekijät estävät tietokilpailut.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Vähentää nykyisestä arvosta palauttaen edellisen arvon.
            ///
            /// Tämä toiminto kiertyy ylivuotoon.
            ///
            /// `fetch_sub` ottaa [`Ordering`]-argumentin, joka kuvaa tämän operaation muistijärjestystä.Kaikki tilaustilat ovat mahdollisia.
            /// Huomaa, että [`Acquire`]: n käyttö tekee tämän toiminnon varasto-osasta [`Relaxed`] ja [`Release`]: n käyttö kuormitusosaksi [`Relaxed`].
            ///
            ///
            /// **Huomautus**: Tämä menetelmä on käytettävissä vain alustoilla, jotka tukevat atomioperaatioita
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // TURVALLISUUS: Atomiset tekijät estävät tietokilpailut.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bittikohtaisesti "and" nykyisellä arvolla.
            ///
            /// Suorittaa nykyisen arvon ja argumentin `val` bittikohtaisen "and"-operaation ja asettaa uuden arvon tulokseen.
            ///
            /// Palauttaa edellisen arvon.
            ///
            /// `fetch_and` ottaa [`Ordering`]-argumentin, joka kuvaa tämän operaation muistijärjestystä.Kaikki tilaustilat ovat mahdollisia.
            /// Huomaa, että [`Acquire`]: n käyttö tekee tämän toiminnon varasto-osasta [`Relaxed`] ja [`Release`]: n käyttö kuormitusosaksi [`Relaxed`].
            ///
            ///
            /// **Huomautus**: Tämä menetelmä on käytettävissä vain alustoilla, jotka tukevat atomioperaatioita
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // TURVALLISUUS: Atomiset tekijät estävät tietokilpailut.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bittikohtaisesti "nand" nykyisellä arvolla.
            ///
            /// Suorittaa nykyisen arvon ja argumentin `val` bittikohtaisen "nand"-operaation ja asettaa uuden arvon tulokseen.
            ///
            /// Palauttaa edellisen arvon.
            ///
            /// `fetch_nand` ottaa [`Ordering`]-argumentin, joka kuvaa tämän operaation muistijärjestystä.Kaikki tilaustilat ovat mahdollisia.
            /// Huomaa, että [`Acquire`]: n käyttö tekee tämän toiminnon varasto-osasta [`Relaxed`] ja [`Release`]: n käyttö kuormitusosaksi [`Relaxed`].
            ///
            ///
            /// **Huomautus**: Tämä menetelmä on käytettävissä vain alustoilla, jotka tukevat atomioperaatioita
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // TURVALLISUUS: Atomiset tekijät estävät tietokilpailut.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bittikohtaisesti "or" nykyisellä arvolla.
            ///
            /// Suorittaa nykyisen arvon ja argumentin `val` bittikohtaisen "or"-operaation ja asettaa uuden arvon tulokseen.
            ///
            /// Palauttaa edellisen arvon.
            ///
            /// `fetch_or` ottaa [`Ordering`]-argumentin, joka kuvaa tämän operaation muistijärjestystä.Kaikki tilaustilat ovat mahdollisia.
            /// Huomaa, että [`Acquire`]: n käyttö tekee tämän toiminnon varasto-osasta [`Relaxed`] ja [`Release`]: n käyttö kuormitusosaksi [`Relaxed`].
            ///
            ///
            /// **Huomautus**: Tämä menetelmä on käytettävissä vain alustoilla, jotka tukevat atomioperaatioita
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // TURVALLISUUS: Atomiset tekijät estävät tietokilpailut.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bittikohtaisesti "xor" nykyisellä arvolla.
            ///
            /// Suorittaa nykyisen arvon ja argumentin `val` bittikohtaisen "xor"-operaation ja asettaa uuden arvon tulokseen.
            ///
            /// Palauttaa edellisen arvon.
            ///
            /// `fetch_xor` ottaa [`Ordering`]-argumentin, joka kuvaa tämän operaation muistijärjestystä.Kaikki tilaustilat ovat mahdollisia.
            /// Huomaa, että [`Acquire`]: n käyttö tekee tämän toiminnon varasto-osasta [`Relaxed`] ja [`Release`]: n käyttö kuormitusosaksi [`Relaxed`].
            ///
            ///
            /// **Huomautus**: Tämä menetelmä on käytettävissä vain alustoilla, jotka tukevat atomioperaatioita
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // TURVALLISUUS: Atomiset tekijät estävät tietokilpailut.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Hakee arvon ja käyttää siihen funktion, joka palauttaa valinnaisen uuden arvon.Palauttaa arvon `Ok(previous_value)` arvosta `Ok(previous_value)`, jos funktio palautti arvon `Some(_)`, muuten arvon `Err(previous_value)`.
            ///
            /// Note: Tämä voi kutsua funktiota useita kertoja, jos arvo on muutettu muista säikeistä sillä välin, kunhan funktio palauttaa `Some(_)`: n, mutta funktiota on käytetty vain kerran tallennettuun arvoon.
            ///
            ///
            /// `fetch_update` vie kaksi [`Ordering`]-argumenttia kuvaamaan tämän operaation muistijärjestystä.
            /// Ensimmäinen kuvaa vaaditun tilauksen, kun operaatio onnistuu, kun taas toinen kuvaa vaaditun kuormitustilauksen.Nämä vastaavat onnistumisen ja epäonnistumisen tilauksia
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// [`Acquire`]: n käyttäminen onnistuneena tilauksena tekee myymälästä osan tätä toimintoa [`Relaxed`], ja [`Release`]: n käyttäminen tekee lopullisen onnistuneen latauksen [`Relaxed`].
            /// (failed)-kuormitustilaus voi olla vain [`SeqCst`], [`Acquire`] tai [`Relaxed`], ja sen on oltava yhtä suuri tai heikompi kuin onnistunut tilaus.
            ///
            /// **Huomautus**: Tämä menetelmä on käytettävissä vain alustoilla, jotka tukevat atomioperaatioita
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Tilaaminen: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Tilaaminen: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Suurin nykyisellä arvolla.
            ///
            /// Hakee nykyisen arvon maksimiarvon ja argumentin `val` ja asettaa uuden arvon tulokseen.
            ///
            /// Palauttaa edellisen arvon.
            ///
            /// `fetch_max` ottaa [`Ordering`]-argumentin, joka kuvaa tämän operaation muistijärjestystä.Kaikki tilaustilat ovat mahdollisia.
            /// Huomaa, että [`Acquire`]: n käyttö tekee tämän toiminnon varasto-osasta [`Relaxed`] ja [`Release`]: n käyttö kuormitusosaksi [`Relaxed`].
            ///
            ///
            /// **Huomautus**: Tämä menetelmä on käytettävissä vain alustoilla, jotka tukevat atomioperaatioita
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// let bar=42;
            /// anna max_foo=foo.fetch_max (palkki, Ordering::SeqCst).max(bar);
            /// väitä! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // TURVALLISUUS: Atomiset tekijät estävät tietokilpailut.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Pienin nykyisellä arvolla.
            ///
            /// Hakee nykyisen arvon minimiarvon ja argumentin `val` ja asettaa uuden arvon tulokseen.
            ///
            /// Palauttaa edellisen arvon.
            ///
            /// `fetch_min` ottaa [`Ordering`]-argumentin, joka kuvaa tämän operaation muistijärjestystä.Kaikki tilaustilat ovat mahdollisia.
            /// Huomaa, että [`Acquire`]: n käyttö tekee tämän toiminnon varasto-osasta [`Relaxed`] ja [`Release`]: n käyttö kuormitusosaksi [`Relaxed`].
            ///
            ///
            /// **Huomautus**: Tämä menetelmä on käytettävissä vain alustoilla, jotka tukevat atomioperaatioita
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// anna palkin=12;
            /// anna min_foo=foo.fetch_min (palkki, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // TURVALLISUUS: Atomiset tekijät estävät tietokilpailut.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Palauttaa muutettavan osoittimen taustalla olevaan kokonaislukuun.
            ///
            /// Ei-atomisten lukujen ja kirjoitusten tekeminen tuloksena olevaan kokonaislukuun voi olla tietokilpailu.
            /// Tämä menetelmä on enimmäkseen hyödyllinen FFI: lle, jossa funktion allekirjoitus voi käyttää
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// `*mut`-osoittimen palauttaminen jaetusta viitteestä tähän atomiin on turvallista, koska atomityypit toimivat sisäisen muuttuvuuden kanssa.
            /// Kaikki atomin muunnokset muuttavat arvoa yhteisen viitteen avulla ja voivat tehdä sen turvallisesti, kunhan ne käyttävät atomioperaatioita.
            /// Palautetun raakaosoittimen käyttö vaatii `unsafe`-lohkon, ja sen on silti noudatettava samaa rajoitusta: sen toimintojen on oltava atomisia.
            ///
            ///
            /// # Examples
            ///
            /// `` Ohita (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// ulkoinen "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // TURVALLISUUS: Turvallinen niin kauan kuin `my_atomic_op` on atomi.
            /// vaarallinen {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // TURVALLISUUS: soittajan on noudatettava `atomic_store`: n turvasopimusta.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // TURVALLISUUS: soittajan on noudatettava `atomic_load`: n turvasopimusta.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TURVALLISUUS: soittajan on noudatettava `atomic_swap`: n turvasopimusta.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Palauttaa edellisen arvon (kuten __sync_haku_ja_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TURVALLISUUS: soittajan on noudatettava `atomic_add`: n turvasopimusta.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Palauttaa edellisen arvon (kuten __sync_haku_ja_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TURVALLISUUS: soittajan on noudatettava `atomic_sub`: n turvasopimusta.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // TURVALLISUUS: soittajan on noudatettava `atomic_compare_exchange`: n turvasopimusta.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // TURVALLISUUS: soittajan on noudatettava `atomic_compare_exchange_weak`: n turvasopimusta.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TURVALLISUUS: soittajan on noudatettava `atomic_and`: n turvasopimusta
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TURVALLISUUS: soittajan on noudatettava `atomic_nand`: n turvasopimusta
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TURVALLISUUS: soittajan on noudatettava `atomic_or`: n turvasopimusta
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TURVALLISUUS: soittajan on noudatettava `atomic_xor`: n turvasopimusta
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// palauttaa enimmäisarvon (allekirjoitettu vertailu)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TURVALLISUUS: soittajan on noudatettava `atomic_max`: n turvasopimusta
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// palauttaa min-arvon (allekirjoitettu vertailu)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TURVALLISUUS: soittajan on noudatettava `atomic_min`: n turvasopimusta
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// palauttaa maksimiarvon (allekirjoittamaton vertailu)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TURVALLISUUS: soittajan on noudatettava `atomic_umax`: n turvasopimusta
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// palauttaa min-arvon (allekirjoittamaton vertailu)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TURVALLISUUS: soittajan on noudatettava `atomic_umin`: n turvasopimusta
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Atomiaita.
///
/// Määritetystä järjestyksestä riippuen aita estää kääntäjää ja keskusyksikköä järjestämästä tietyntyyppisiä muistitoimintoja sen ympärillä.
/// Se luo synkronointisuhteet sen ja atomioperaatioiden tai muiden säikeiden aidan välille.
///
/// Aita 'A', jolla on (ainakin) [`Release`]-semantiikka, synkronoituu aidan 'B' kanssa (vähintään) [`Acquire`]-semantiikan kanssa, jos ja vain, jos on olemassa toimintoja X ja Y, jotka molemmat toimivat jollakin atomiobjektilla 'M' siten, että A sekvensoidaan ennen X, Y synkronoidaan ennen kuin B ja Y havaitsee muutoksen M.
/// Tämä tarjoaa A: n ja B: n välillä ennen tapahtuvaa riippuvuutta.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Atomitoiminnot [`Release`]-tai [`Acquire`]-semantiikan kanssa voivat myös synkronoitua aidan kanssa.
///
/// Aita, jolla on [`SeqCst`]-tilaus, sekä [`Acquire`]-että [`Release`]-semantiikan lisäksi osallistuu muiden [`SeqCst`]-operaatioiden ja/tai aidojen globaaliin ohjelmajärjestykseen.
///
/// Hyväksyy [`Acquire`]-, [`Release`]-, [`AcqRel`]-ja [`SeqCst`]-tilaukset.
///
/// # Panics
///
/// Panics, jos `order` on [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Spinlockiin perustuva keskinäinen poissulkemisprimitiivi.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Odota, kunnes vanha arvo on `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Tämä aita synkronoituu `unlock`: n myymälän kanssa.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // TURVALLISUUS: atomiaidan käyttö on turvallista.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Kääntäjän muistiaita.
///
/// `compiler_fence` ei lähetä konekoodia, mutta rajoittaa sellaisia muistimuotoja, jotka kääntäjä saa tilata uudelleen.Erityisesti annetusta [`Ordering`]-semantiikasta riippuen kääntäjä voidaan kieltää siirtämästä luku-tai kirjoituslukuja ennen tai jälkeen puhelun `compiler_fence`-puhelun toiselle puolelle.Huomaa, että se **ei** estä *laitteistoa* tilaamasta uudelleen.
///
/// Tämä ei ole ongelma yksisäikeisessä suoritusympäristössä, mutta kun muut säikeet voivat muokata muistia samanaikaisesti, tarvitaan vahvempia synkronointiprimitiivejä, kuten [`fence`].
///
/// Eri järjestyssemantiikan estämä uudelleenjärjestäminen on:
///
///  - [`SeqCst`]: n kanssa luku-ja kirjoitusjärjestysten uudelleenjärjestäminen tässä kohdassa ei ole sallittua.
///  - [`Release`]: n kanssa edeltäviä lukuja ja kirjoituksia ei voida siirtää myöhempien kirjoitusten ohi.
///  - [`Acquire`]: n kanssa seuraavia lukuja ja kirjoituksia ei voida siirtää edellisiä lukuja eteenpäin.
///  - [`AcqRel`]: n kanssa molemmat yllä olevat säännöt pannaan täytäntöön.
///
/// `compiler_fence` on yleensä hyödyllinen vain estämään langan kilpailemista * itsensä kanssa.Toisin sanoen, jos tietty säie suorittaa yhden koodinpätkän ja sitten keskeytyy ja alkaa suorittaa koodia muualla (ollessaan edelleen samassa säikeessä ja käsitteellisesti edelleen samalla ytimellä).Perinteisissä ohjelmissa tämä voi tapahtua vain, kun signaalinkäsittelijä on rekisteröity.
/// Matalammassa koodissa tällaisia tilanteita voi ilmetä myös keskeytysten käsittelyssä, vihreiden säikeiden toteuttamisessa esivalinnalla jne.
/// Uteliaita lukijoita kannustetaan lukemaan Linux-ytimen keskustelu [memory barriers]: stä.
///
/// # Panics
///
/// Panics, jos `order` on [`Relaxed`].
///
/// # Examples
///
/// Ilman `compiler_fence`: ää `assert_eq!` seuraavassa koodissa ei *ole* taattua onnistua, vaikka kaikki tapahtuu yhdessä säikeessä.
/// Muista, että kääntäjä voi vapaasti vaihtaa kaupat kohteisiin `IMPORTANT_VARIABLE` ja `IS_READ`, koska ne ovat molemmat `Ordering::Relaxed`.Jos se tapahtuu ja signaalinkäsittelijä käynnistetään heti sen jälkeen, kun `IS_READY` on päivitetty, signaalinkäsittelijä näkee `IS_READY=1`: n, mutta `IMPORTANT_VARIABLE=0`.
/// `compiler_fence`: n käyttö korjaa tämän tilanteen.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // estää aikaisempia kirjoituksia siirtymästä tämän kohdan yli
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // TURVALLISUUS: atomiaidan käyttö on turvallista.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Ilmoittaa prosessorille, että se on varattu-odotus-spin-silmukan sisällä ("linkouslukko").
///
/// Tämä toiminto on vanhentunut [`hint::spin_loop`]: n eduksi.
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}