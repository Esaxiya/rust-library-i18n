//! Traits tyyppien välisille muunnoksille.
//!
//! Tämän moduulin traits tarjoaa tavan muuntaa tyypistä toiseen.
//! Jokaisella trait: llä on eri tarkoitus:
//!
//! - Toteuta [`AsRef`] trait, jotta saat halvat vertailu-viite-muunnokset
//! - Toteuta [`AsMut`] trait, jotta muunnettavat hinnat muuttuisivat helposti
//! - Toteuta [`From`] trait kuluttamalla arvo-arvo-muunnoksia
//! - Toteuta [`Into`] trait kuluttamalla arvo-arvo-muunnokset tyyppeihin, jotka ovat nykyisen crate: n ulkopuolella
//! - [`TryFrom`] ja [`TryInto`] traits käyttäytyvät kuten [`From`] ja [`Into`], mutta ne tulisi toteuttaa, kun muunnos voi epäonnistua.
//!
//! Tämän moduulin traits: tä käytetään usein nimellä trait bounds yleisiin toimintoihin siten, että monen tyyppisiä argumentteja tuetaan.Katso esimerkkejä kunkin trait: n dokumentaatiosta.
//!
//! Kirjaston kirjoittajana kannattaa aina mieluummin toteuttaa [`From<T>`][`From`] tai [`TryFrom<T>`][`TryFrom`] kuin [`Into<U>`][`Into`] tai [`TryInto<U>`][`TryInto`], koska [`From`] ja [`TryFrom`] tarjoavat suuremman joustavuuden ja tarjoavat vastaavia [`Into`]-tai [`TryInto`]-toteutuksia ilmaiseksi vakiokirjaston yleisen toteutuksen ansiosta.
//! Kohdistettaessa versiota, joka on vanhempi kuin Rust 1.41, voi olla tarpeen toteuttaa [`Into`] tai [`TryInto`] suoraan muunnettaessa nykyisen crate: n ulkopuoliseen tyyppiin.
//!
//! # Yleiset toteutukset
//!
//! - [`AsRef`] ja [`AsMut`]-automaattinen poikkeama, jos sisempi tyyppi on viite
//! - [`Lähettäjä`` <U>T: lle tarkoittaa [`Into`] `</u><T><U>joukkueelle U`</u>
//! - [`TryFrom`]`<U>T: lle tarkoittaa [`TryInto`]</u><T><U>joukkueelle U`</u>
//! - [`From`] ja [`Into`] ovat refleksiivisiä, mikä tarkoittaa, että kaikki tyypit voivat `into` itseään ja `from` itseään
//!
//! Katso käyttöesimerkkejä jokaisesta trait-mallista.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Identiteettitoiminto.
///
/// Kaksi asiaa on tärkeää huomioida tässä toiminnossa:
///
/// - Se ei aina vastaa `|x| x`: n kaltaista suljinta, koska suljin voi pakottaa `x`: n erityyppiseksi.
///
/// - Se siirtää funktiolle välitetyn tulon `x`.
///
/// Vaikka saattaa tuntua oudolta, että toiminnolla on vain palautus syötteelle, on joitain mielenkiintoisia käyttötarkoituksia.
///
///
/// # Examples
///
/// `identity`: n käyttäminen tekemättä mitään muita mielenkiintoisia toimintoja:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Oletetaan, että yhden lisääminen on mielenkiintoinen toiminto.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// `identity`: n käyttö "do nothing"-peruskotelona ehdollisena:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Tee mielenkiintoisempia juttuja ...
///
/// let _results = do_stuff(42);
/// ```
///
/// `identity`: n käyttäminen `Option<T>`: n iteraattorin `Some`-muunnosten pitämiseen:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Käytetään halvan referenssi-viite-muunnoksen tekemiseen.
///
/// Tämä trait on samanlainen kuin [`AsMut`], jota käytetään muunnettaessa muuttuvien viitteiden välillä.
/// Jos sinun on tehtävä kallis muunnos, on parempi toteuttaa [`From`] tyypillä `&T` tai kirjoittaa mukautettu toiminto.
///
/// `AsRef` on sama allekirjoitus kuin [`Borrow`], mutta [`Borrow`] on erilainen muutamilta osin:
///
/// - Toisin kuin `AsRef`, [`Borrow`]: ssä on yleinen implikaatti mille tahansa `T`: lle, ja sitä voidaan käyttää joko viitteen tai arvon hyväksymiseen.
/// - [`Borrow`] edellyttää myös, että lainatun arvon [`Hash`], [`Eq`] ja [`Ord`] vastaavat omistetun arvon arvoja.
/// Tästä syystä, jos haluat lainata vain yhden kentän rakenteesta, voit toteuttaa `AsRef`: n, mutta ei [`Borrow`]: ää.
///
/// **Note: Tämä trait ei saa epäonnistua **.Jos muuntaminen epäonnistuu, käytä erityistä menetelmää, joka palauttaa [`Option<T>`]-tai [`Result<T, E>`]-arvon.
///
/// # Yleiset toteutukset
///
/// - `AsRef` automaattiset viittaukset, jos sisempi tyyppi on viite tai muutettava viite (esim: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Käyttämällä trait bounds voimme hyväksyä erityyppisiä argumentteja, kunhan ne voidaan muuntaa määritetyksi tyypiksi `T`.
///
/// Esimerkiksi: Luomalla yleinen funktio, joka vie `AsRef<str>`: n, ilmaisemme, että haluamme hyväksyä kaikki viitteet, jotka voidaan muuntaa [`&str`]: ksi argumenttina.
/// Koska sekä [`String`] että [`&str`] toteuttavat `AsRef<str>`: n, voimme molemmat hyväksyä syöttöargumentteina.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Suorittaa muunnoksen.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Käytetään halvan muuttuvasta muunnettavaksi-muunnokseen.
///
/// Tämä trait on samanlainen kuin [`AsRef`], mutta sitä käytetään muunnettavaksi muuttuvien viitteiden välillä.
/// Jos sinun on tehtävä kallis muunnos, on parempi toteuttaa [`From`] tyypillä `&mut T` tai kirjoittaa mukautettu toiminto.
///
/// **Note: Tämä trait ei saa epäonnistua **.Jos muuntaminen epäonnistuu, käytä erityistä menetelmää, joka palauttaa [`Option<T>`]-tai [`Result<T, E>`]-arvon.
///
/// # Yleiset toteutukset
///
/// - `AsMut` automaattiset poikkeamat, jos sisempi tyyppi on muutettava viite (esim .: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Käyttämällä `AsMut`: ää trait bound: ksi yleisenä toimintona voimme hyväksyä kaikki muutettavat viitteet, jotka voidaan muuntaa tyypiksi `&mut T`.
/// Koska [`Box<T>`] toteuttaa `AsMut<T>`: n, voimme kirjoittaa funktion `add_one`, joka ottaa kaikki argumentit, jotka voidaan muuntaa `&mut u64`: ksi.
/// Koska [`Box<T>`] toteuttaa `AsMut<T>`: n, `add_one` hyväksyy myös tyypin `&mut Box<u64>` argumentit:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Suorittaa muunnoksen.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Arvo-arvo-muunnos, joka kuluttaa syötetyn arvon.[`From`]: n vastakohta.
///
/// Vältä [`Into`]: n ja [`From`]: n käyttöönottoa.
/// [`From`]: n käyttöönotto tarjoaa automaattisesti [`Into`]: n toteutuksen vakiokirjaston yleisen toteutuksen ansiosta.
///
/// Käytä [`Into`]: ää mieluummin kuin [`From`], kun määrität trait bounds-toiminnon yleiseen toimintoon, jotta voidaan varmistaa, että voidaan käyttää myös tyyppejä, jotka toteuttavat vain [`Into`]: n.
///
/// **Note: Tämä trait ei saa epäonnistua **.Jos muuntaminen voi epäonnistua, käytä [`TryInto`]: ää.
///
/// # Yleiset toteutukset
///
/// - [`` Lähettäjä '')<T>U: lle tarkoittaa `Into<U> for T`: ää
/// - [`Into`] on refleksiivinen, mikä tarkoittaa, että `Into<T> for T` on otettu käyttöön
///
/// # [`Into`]: n käyttöönotto muunnoksille ulkoisiin tyyppeihin Rust: n vanhoissa versioissa
///
/// Ennen Rust 1.41-ohjelmaa, jos kohdetyyppi ei kuulunut nykyiseen crate-osaan, et voinut toteuttaa [`From`]: ää suoraan.
/// Ota esimerkiksi tämä koodi:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Tätä ei voida koota kielen vanhemmissa versioissa, koska Rust: n orposäännöt olivat aiemmin hieman tiukempia.
/// Tämän ohittamiseksi voit toteuttaa [`Into`]: n suoraan:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// On tärkeää ymmärtää, että [`Into`] ei tarjoa [`From`]-toteutusta (kuten [`From`] tekee [`Into`]: n kanssa).
/// Siksi sinun on aina yritettävä toteuttaa [`From`] ja palata sitten takaisin [`Into`]: ään, jos [`From`]: ää ei voida toteuttaa.
///
/// # Examples
///
/// [`String`] toteuttaa [`Into`]``` ```` ```` ```` ```` ```` ```` ````:
///
/// Sen ilmaisemiseksi, että haluamme yleisen funktion ottavan kaikki argumentit, jotka voidaan muuntaa määritetyksi tyypiksi `T`, voimme käyttää trait bound: n arvoa [`Into`] '.<T>".
///
/// Esimerkiksi: Funktio `is_hello` ottaa kaikki argumentit, jotka voidaan muuntaa [``Vec`` '' <`[` `u8`]`>`: ksi.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Suorittaa muunnoksen.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Käytetään arvo-arvo-muunnosten tekemiseen samalla kun syötetään arvo.Se on [`Into`]: n vastavuoroisuus.
///
/// `From`: n käyttöönottoa tulisi aina suositella [`Into`]: n sijaan, koska `From`: n käyttöönotto tarjoaa automaattisesti [`Into`]: n toteutuksen vakiokirjaston yleisen toteutuksen ansiosta.
///
///
/// Toteuta [`Into`] vain kohdistettaessa versiota, joka on ennen Rust 1.41, ja muunnettaessa nykyisen crate: n ulkopuoliseen tyyppiin.
/// `From` ei voinut tehdä tämän tyyppisiä muunnoksia aiemmissa versioissa Rust: n orposääntöjen takia.
/// Katso lisätietoja [`Into`]: stä.
///
/// Määritä mieluummin [`Into`] kuin `From`, kun määrität trait bounds: n yleisfunktiolle.
/// Tällä tavalla tyyppejä, jotka toteuttavat suoraan [`Into`]: n, voidaan käyttää myös argumentteina.
///
/// `From` on myös erittäin hyödyllinen suoritettaessa virheiden käsittelyä.Rakennettaessa toimintoa, joka kykenee epäonnistumaan, palautustyyppi on yleensä muodoltaan `Result<T, E>`.
/// `From` trait yksinkertaistaa virheenkäsittelyä antamalla toiminnon palauttaa yhden virhetyypin, joka kapseloi useita virhetyyppejä.Katso lisätietoja osioista "Examples" ja [the book][book].
///
/// **Note: Tämä trait ei saa epäonnistua **.Jos muuntaminen voi epäonnistua, käytä [`TryFrom`]: ää.
///
/// # Yleiset toteutukset
///
/// - `From<T> for U` merkitsee [``Into ''`` <U>T: lle ''</u>
/// - `From` on refleksiivinen, mikä tarkoittaa, että `From<T> for T` on otettu käyttöön
///
/// # Examples
///
/// [`String`] työlaitteet `From<&str>`:
///
/// Selkeä muunnos `&str`: stä merkkijonoksi tapahtuu seuraavasti:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Virheenkäsittelyä suoritettaessa on usein hyödyllistä ottaa `From` käyttöön omalle virhetyypillesi.
/// Muuntamalla taustalla olevat virhetyypit omaksi mukautetuksi virhetyypiksi, joka kapseloi taustalla olevan virhetyypin, voimme palauttaa yhden virhetyypin menettämättä tietoja taustalla olevasta syystä.
/// '?'-operaattori muuntaa taustalla olevan virhetyypin automaattisesti mukautetuksi virhetyypiksi soittamalla numeroon `Into<CliError>::into`, joka toimitetaan automaattisesti, kun `From` otetaan käyttöön.
/// Sitten kääntäjä päättelee, mitä `Into`: n toteutusta tulisi käyttää.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Suorittaa muunnoksen.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Muunnosyritys, joka kuluttaa `self`: ää, mikä voi olla kallista tai ei.
///
/// Kirjastojen kirjoittajien ei yleensä pidä toteuttaa tätä trait: tä suoraan, mutta heidän tulisi mieluummin toteuttaa [`TryFrom`] trait, joka tarjoaa suuremman joustavuuden ja tarjoaa vastaavan `TryInto`-toteutuksen ilmaiseksi, vakiokirjaston yleisen toteutuksen ansiosta.
/// Lisätietoja tästä on [`Into`]: n dokumentaatiossa.
///
/// # `TryInto`: n käyttöönotto
///
/// Tämä kärsii samoista rajoituksista ja perusteluista kuin [`Into`]: n käyttöönotto, katso lisätietoja siitä.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Palautettu tyyppi muunnosvirheen sattuessa.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Suorittaa muunnoksen.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Yksinkertaiset ja turvalliset muunnokset, jotka voivat epäonnistua hallitusti tietyissä olosuhteissa.Se on [`TryInto`]: n vastavuoroisuus.
///
/// Tästä on hyötyä, kun teet tyyppimuunnosta, joka voi menestyä vähäpätöisesti, mutta saattaa myös tarvita erityistä käsittelyä.
/// Esimerkiksi [`i64`]: ää ei voida muuntaa [`i32`]: ksi [`From`] trait: llä, koska [`i64`] voi sisältää arvon, jota [`i32`] ei voi edustaa, joten muuntaminen menettäisi tietoja.
///
/// Tämä voidaan hoitaa katkaisemalla [`i64`] [`i32`]: ksi (antamalla [i64 "]: n arvo modulo [`i32::MAX`]) tai yksinkertaisesti palauttamalla [`i32::MAX`] tai jollakin muulla menetelmällä.
/// [`From`] trait on tarkoitettu täydellisiin muunnoksiin, joten `TryFrom` trait ilmoittaa ohjelmoijalle, kun tyyppimuunnos voi mennä pieleen, ja antaa heidän päättää, miten se käsitellään.
///
/// # Yleiset toteutukset
///
/// - `TryFrom<T> for U` tarkoittaa [`TryInto`]` <U>T: lle</u>
/// - [`try_from`] on refleksiivinen, mikä tarkoittaa, että `TryFrom<T> for T` on toteutettu eikä voi epäonnistua-siihen liittyvä `Error`-tyyppi `T::try_from()`: n kutsumiseksi tyypin `T` arvolle on [`Infallible`].
/// Kun [`!`]-tyyppi on vakautettu, [`Infallible`] ja [`!`] vastaavat.
///
/// `TryFrom<T>` voidaan toteuttaa seuraavasti:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Kuten kuvattu, [`i32`] toteuttaa TryFrom <`[[i64`]`> ':
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Katkaisee äänettömästi `big_number`: n, vaatii katkaisun havaitsemisen ja käsittelemisen tosiasian jälkeen.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Palauttaa virheen, koska `big_number` on liian suuri sopimaan `i32`: ään.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Palauttaa `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Palautettu tyyppi muunnosvirheen sattuessa.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Suorittaa muunnoksen.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// YLEISET VAIKUTUKSET
////////////////////////////////////////////////////////////////////////////////

// Kun nousee yli
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Nostettaessa yli &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): Korvaa yllä olevat&/&mut-sisällöt seuraavalla yleisemmällä:
// // Nostettaessa Derefin yli
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Koko> AsRef <U>mallille D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut nostaa &mut: n yli
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): Korvaa yllä oleva &mut: n implantaatti seuraavalla yleisemmällä:
// // AsMut nousee DerefMutin yli
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Koko> AsMut <U>mallille D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// From merkitsee Into
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// From (ja siten Into) on refleksiivinen
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Vakaushuomautus:** Tätä implisiittiä ei vielä ole, mutta olemme "reserving space", jotta voimme lisätä sen future-tiedostoon.
/// Katso lisätietoja [rust-lang/rust#64715][#64715]: stä.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): tee sen sijaan periaatteellinen korjaus.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom tarkoittaa TryIntoa
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Virheettömät konversiot vastaavat semanttisesti virheellisiä konversioita, joissa on asumaton virhetyyppi.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// BETONIEN VAIKUTUKSET
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// VIRHEETTÖVIRHETYYPPI
////////////////////////////////////////////////////////////////////////////////

/// Virhetyyppi virheille, joita ei voi koskaan tapahtua.
///
/// Koska tällä enumilla ei ole muunnosta, tämän tyyppistä arvoa ei voi koskaan olla olemassa.
/// Tästä voi olla hyötyä yleisille sovellusliittymille, jotka käyttävät [`Result`]: ää ja parametroivat virhetyypin, osoittaakseen, että tulos on aina [`Ok`].
///
/// Esimerkiksi [`TryFrom`] trait (muunnos, joka palauttaa [`Result`]: n) sisältää yleisen toteutuksen kaikille tyypeille, joissa on käänteinen [`Into`]-toteutus.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future-yhteensopivuus
///
/// Tällä enumilla on sama rooli kuin [the `!`“never”type][never]: llä, joka on epävakaa tässä Rust-versiossa.
/// Kun `!` on vakautettu, aiomme tehdä `Infallible`: stä tyypin aliaksen:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …Ja lopulta lopettaa `Infallible`: n.
///
/// On kuitenkin yksi tapaus, jossa `!`-syntaksia voidaan käyttää ennen kuin `!` vakiintuu täysimittaiseksi tyypiksi: toiminnon palautustyypin asemassa.
/// Erityisesti on mahdollista toteuttaa kahta erilaista funktiosoitintyyppiä:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Koska `Infallible` on enum, tämä koodi on kelvollinen.
/// Kuitenkin, kun `Infallible`: stä tulee alias never type: lle, nämä kaksi implisiittiä alkavat olla päällekkäisiä, joten kielen trait koherenssisäännöt estävät sen.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}