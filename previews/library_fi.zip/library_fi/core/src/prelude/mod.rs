//! Libcore prelude
//!
//! Tämä moduuli on tarkoitettu libcore-käyttäjille, jotka eivät myöskään linkitä libstd: hen.
//! Tämä moduuli tuodaan oletuksena, kun `#![no_std]`: ää käytetään samalla tavalla kuin vakiokirjaston prelude.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Vuoden 2015 versio ytimestä prelude.
///
/// Katso lisätietoja [module-level documentation](self): stä.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// prelude-ytimen vuoden 2018 versio.
///
/// Katso lisätietoja [module-level documentation](self): stä.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Ytimen prelude vuoden 2021 versio.
///
/// Katso lisätietoja [module-level documentation](self): stä.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Lisää lisää asioita.
}