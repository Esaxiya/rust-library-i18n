//! Tämä moduuli toteuttaa `Any` trait: n, joka mahdollistaa minkä tahansa `'static`-tyypin dynaamisen kirjoittamisen ajonaikaisen heijastuksen avulla.
//!
//! `Any` itseään voidaan käyttää `TypeId`: n hankkimiseen, ja sillä on enemmän ominaisuuksia, kun sitä käytetään trait-objektina.
//! Koska `&dyn Any` (lainattu trait-objekti), sillä on `is`-ja `downcast_ref`-menetelmät, jotta voidaan testata, onko sisällytetty arvo tietyn tyyppinen, ja saada viittaus sisäiseen arvoon tyypinä.
//! Kuten `&mut dyn Any`, on myös `downcast_mut`-menetelmä, jolla saadaan muutettava viittaus sisäiseen arvoon.
//! `Box<dyn Any>` lisää `downcast`-menetelmän, joka yrittää muuntaa `Box<T>`: ksi.
//! Katso täydelliset tiedot [`Box`]-ohjeista.
//!
//! Huomaa, että `&dyn Any` on rajoitettu testaamaan, onko arvo tietyn tyyppinen betoni, eikä sitä voida käyttää testaamaan, onko tyyppi trait: n.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Älykkäät osoittimet ja `dyn Any`
//!
//! Yksi käytös, joka on pidettävä mielessä käytettäessä `Any`: tä trait-objektina, etenkin sellaisten tyyppien kanssa kuin `Box<dyn Any>` tai `Arc<dyn Any>`, on se, että pelkkä `.type_id()`: n kutsuminen arvoon tuottaa *kontin*`TypeId`: n, ei taustalla olevan trait-objektin.
//!
//! Tämä voidaan välttää muuntamalla älykäs osoitin `&dyn Any`: ksi, mikä palauttaa objektin `TypeId`: n.
//! Esimerkiksi:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Haluat todennäköisemmin tämän:
//! let actual_id = (&*boxed).type_id();
//! // ... kuin tämä:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Tarkastellaan tilannetta, jossa haluamme kirjautua ulos funktiolle välitetystä arvosta.
//! Tiedämme arvon, jolla työskentelemme, toteuttaa Debugin, mutta emme tiedä sen konkreettista tyyppiä.Haluamme antaa erityiskohtelun tietyille tyypeille: tässä tapauksessa tulostetaan merkkijonoarvojen pituus ennen niiden arvoa.
//! Emme tiedä arvomme konkreettista tyyppiä kokoamisajankohtana, joten meidän on käytettävä sen sijaan ajonaikaisia heijastuksia.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Logger-toiminto kaikentyyppisille, jotka toteuttavat virheenkorjauksen.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Yritä muuntaa arvo `String`: ksi.
//!     // Jos se onnistuu, haluamme antaa merkkijonon pituuden ja arvon.
//!     // Jos ei, se on erilainen tyyppi: tulosta se vain koristamattomana.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Tämä toiminto haluaa kirjautua parametrinsa ulos ennen kuin teet sen kanssa työtä.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... tehdä muuta työtä
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Mikä tahansa trait
///////////////////////////////////////////////////////////////////////////////

/// trait jäljittelemään dynaamista kirjoittamista.
///
/// Useimmat tyypit toteuttavat `Any`: n.Tyyppi, joka sisältää ei-staattisen viitteen, ei kuitenkaan.
/// Katso lisätietoja [module-level documentation][mod]: stä.
///
/// [mod]: crate::any
// Tämä trait ei ole vaarallinen, vaikka luotamme sen ainoan implantaatin `type_id`-toiminnon erityispiirteisiin vaarallisessa koodissa (esim. `downcast`).Normaalisti se olisi ongelma, mutta koska `Any`: n ainoa tarkoitus on yleinen toteutus, mikään muu koodi ei voi toteuttaa `Any`: ää.
//
// Voisimme tehdä tästä trait: sta todennäköisesti vaarallisen-se ei aiheuttaisi rikkoutumista, koska hallitsemme kaikkia toteutuksia-mutta päätämme olla tekemättä, koska se ei ole molempien todellakin välttämätöntä ja saattaa hämmentää käyttäjiä vaarallisten traits: n ja vaarallisten menetelmien (ts. `type_id` olisi silti turvallinen soittaa, mutta haluaisimme todennäköisesti ilmoittaa sellaisenaan dokumentaatiossa).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Haetaan `self`: n `TypeId`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Laajennusmenetelmät mille tahansa trait-objektille.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Varmista, että esim. Langan liittämisen tulos voidaan tulostaa ja siten käyttää `unwrap`: n kanssa.
// Ei välttämättä enää tarvita, jos lähetys toimii upcastingin kanssa.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Palauttaa arvon `true`, jos laatikkotyyppi on sama kuin `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Hanki `TypeId`, jonka tyyppinen toiminto on.
        let t = TypeId::of::<T>();

        // Hae tyypin `TypeId` trait-objektista (`self`).
        let concrete = self.type_id();

        // Vertaa molempia tasa-arvon tyyppejä.
        t == concrete
    }

    /// Palauttaa viittauksen ruutuun merkittyyn arvoon, jos se on tyyppiä `T`, tai `None`, jos se ei ole.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // TURVALLISUUS: tarkasimme vain, osoitammeko oikeaa tyyppiä, ja voimme luottaa
            // että tarkistaa muistin turvallisuuden, koska olemme toteuttaneet Any kaikentyyppisille;muita implikaatteja ei voi olla, koska ne olisivat ristiriidassa implisiittimme kanssa.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Palauttaa muutettavan viitteen ruudulliseen arvoon, jos se on tyyppiä `T`, tai `None`, jos se ei ole.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // TURVALLISUUS: tarkasimme vain, osoitammeko oikeaa tyyppiä, ja voimme luottaa
            // että tarkistaa muistin turvallisuuden, koska olemme toteuttaneet Any kaikentyyppisille;muita implikaatteja ei voi olla, koska ne olisivat ristiriidassa implisiittimme kanssa.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Edelleen tyypille `Any` määriteltyyn menetelmään.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Edelleen tyypille `Any` määriteltyyn menetelmään.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Edelleen tyypille `Any` määriteltyyn menetelmään.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Edelleen tyypille `Any` määriteltyyn menetelmään.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Edelleen tyypille `Any` määriteltyyn menetelmään.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Edelleen tyypille `Any` määriteltyyn menetelmään.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID ja sen menetelmät
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` edustaa tyypin globaalisti yksilöllistä tunnistetta.
///
/// Jokainen `TypeId` on läpinäkymätön esine, joka ei salli sisällön tarkastamista, mutta sallii perustoiminnot, kuten kloonauksen, vertailun, tulostamisen ja näyttämisen.
///
///
/// `TypeId` on tällä hetkellä saatavana vain tyypeille, jotka kuuluvat `'static`: ään, mutta tämä rajoitus voidaan poistaa future: stä.
///
/// Vaikka `TypeId` toteuttaa `Hash`: n, `PartialOrd`: n ja `Ord`: n, on syytä huomata, että tiivisteet ja järjestys vaihtelevat Rust-julkaisujen välillä.
/// Varo luottaa niihin koodisi sisällä!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Palauttaa tyypin `TypeId`, johon tämä yleinen toiminto on tehty.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Palauttaa tyypin nimen merkkijonona.
///
/// # Note
///
/// Tämä on tarkoitettu diagnostiikkakäyttöön.
/// Palautetun merkkijonon tarkkaa sisältöä ja muotoa ei määritellä, paitsi että se on tyypin paras kuvaus.
/// Esimerkiksi merkkijonoista, jotka `type_name::<Option<String>>()` saattaa palauttaa, ovat `"Option<String>"` ja `"std::option::Option<std::string::String>"`.
///
///
/// Palautettua merkkijonoa ei saa pitää tyypin yksilöllisenä tunnisteena, koska useat tyypit voivat liittyä samaan tyyppiin.
/// Vastaavasti ei voida taata, että kaikki tyypin osat näkyvät palautetussa merkkijonossa: esimerkiksi käyttöiän määrittelijöitä ei tällä hetkellä sisällytetä.
/// Lisäksi lähtö voi vaihdella kääntäjän versioiden välillä.
///
/// Nykyinen toteutus käyttää samaa infrastruktuuria kuin kääntäjän diagnostiikka ja debuginfo, mutta tätä ei voida taata.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Palauttaa osoitetun arvon tyypin nimen merkkijonona.
/// Tämä on sama kuin `type_name::<T>()`, mutta sitä voidaan käyttää, kun muuttujan tyyppiä ei ole helposti saatavilla.
///
/// # Note
///
/// Tämä on tarkoitettu diagnostiikkakäyttöön.Merkkijonon tarkkaa sisältöä ja muotoa ei määritetä, paitsi että se on tyypin paras kuvaus.
/// Esimerkiksi `type_name_of_val::<Option<String>>(None)` voi palauttaa arvon `"Option<String>"` tai `"std::option::Option<std::string::String>"`, mutta ei `"foobar"`.
///
/// Lisäksi lähtö voi vaihdella kääntäjän versioiden välillä.
///
/// Tämä toiminto ei ratkaise trait-objekteja, mikä tarkoittaa, että `type_name_of_val(&7u32 as &dyn Debug)` voi palauttaa `"dyn Debug"`: n, mutta ei `"u32"`.
///
/// Tyypin nimeä ei tule pitää tyypin yksilöivänä tunnuksena;
/// usealla tyypillä voi olla sama tyyppinimi.
///
/// Nykyinen toteutus käyttää samaa infrastruktuuria kuin kääntäjän diagnostiikka ja debuginfo, mutta tätä ei voida taata.
///
/// # Examples
///
/// Tulostaa oletusluku-ja kelluntatyypit.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}