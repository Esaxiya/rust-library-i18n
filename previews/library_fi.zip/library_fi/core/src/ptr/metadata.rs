#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Antaa minkä tahansa teräväpiirtotyypin osoittimen metatietotyypin.
///
/// # Osoittimen metatiedot
///
/// Raaka osoittimen tyypit ja viitetyypit Rust: ssä voidaan ajatella kahdesta osasta:
/// dataosoitin, joka sisältää arvon muistiosoitteen ja joitain metatietoja.
///
/// Staattisen kokoisille tyyppeille (jotka toteuttavat `Sized` traits) ja `extern`-tyypeille osoitinten sanotaan olevan "ohuita": metatiedot ovat nollakokoisia ja niiden tyyppi on `()`.
///
///
/// [dynamically-sized types][dst]-osoittimien sanotaan olevan "leveitä" tai "rasvaisia", niillä on nollakokoiset metatiedot:
///
/// * Struktuureille, joiden viimeinen kenttä on DST, metatiedot ovat viimeisen kentän metatiedot
/// * `str`-tyypin metatiedot ovat pituus tavuina kuten `usize`
/// * Viipalatyypeille, kuten `[T]`, metatiedot ovat kohteiden pituus muodossa `usize`
/// * trait-objektien, kuten `dyn SomeTrait`, metatiedot ovat [`DynMetadata<Self>`][DynMetadata] (esim. `DynMetadata<dyn SomeTrait>`)
///
/// future: ssä Rust-kieli voi saada uudenlaisia tyyppejä, joilla on erilaiset osoittimen metatiedot.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// Tämän trait: n piste on sen `Metadata`-tyyppinen tyyppi, joka on `()` tai `usize` tai `DynMetadata<_>`, kuten yllä on kuvattu.
/// Se toteutetaan automaattisesti jokaiselle tyypille.
/// Sen voidaan olettaa toteutettavan yleisessä yhteydessä, myös ilman vastaavaa sidosta.
///
/// # Usage
///
/// Raaka osoittimet voidaan hajottaa dataosoitteeksi ja metatietokomponenteiksi niiden [`to_raw_parts`]-menetelmällä.
///
/// Vaihtoehtoisesti pelkkä metatieto voidaan purkaa [`metadata`]-toiminnolla.
/// Viite voidaan välittää [`metadata`]: lle ja implisiittisesti pakottaa.
///
/// (possibly-wide)-osoitin voidaan koota uudelleen osoitteestaan ja metatiedoistaan [`from_raw_parts`]-tai [`from_raw_parts_mut`]-koodilla.
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Osoitteissa olevien metatietojen tyyppi ja viitteet `Self`: ään.
    #[lang = "metadata_type"]
    // NOTE: Pidä trait bounds `static_assert_expected_bounds_for_metadata`: ssä
    //
    // `library/core/src/ptr/metadata.rs`: ssä synkronoituna täällä olevien kanssa:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Osoitteet tämän trait-aliaksen toteuttaviin tyyppeihin ovat "ohuita".
///
/// Tämä sisältää staattisesti `` koon '' tyypit ja `extern`-tyypit.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: älä vakauta tätä ennen kuin trait-aliakset ovat vakaita kielellä?
pub trait Thin = Pointee<Metadata = ()>;

/// Pura osoittimen metatietokomponentti.
///
/// Tyypin `*mut T`, `&T` tai `&mut T` arvot voidaan välittää suoraan tälle toiminnolle, koska ne pakottavat implisiittisesti `* const T`: lle.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // TURVALLISUUS: Arvoon pääsy `PtrRepr`-liitoksesta on turvallista, koska * const T
    // ja PtrComponents<T>on samat muistipaikat.
    // Vain std voi antaa tämän takuun.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Muodostaa (possibly-wide)-raakaosoittimen dataosoitteesta ja metatiedoista.
///
/// Tämä toiminto on turvallinen, mutta palautettu osoitin ei välttämättä ole turvallista poikkeamiselle.
/// Viipaleiden osalta katso turvallisuusvaatimukset [`slice::from_raw_parts`]: n dokumentaatiosta.
/// trait-objektien metatietojen on oltava peräisin osoittimesta samaan taustalla olevaan vapautettuun tyyppiin.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // TURVALLISUUS: Arvoon pääsy `PtrRepr`-liitoksesta on turvallista, koska * const T
    // ja PtrComponents<T>on samat muistipaikat.
    // Vain std voi antaa tämän takuun.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Suorittaa saman toiminnallisuuden kuin [`from_raw_parts`], paitsi että palautetaan raaka `*mut`-osoitin, toisin kuin raaka `* const`-osoitin.
///
///
/// Katso lisätietoja [`from_raw_parts`]: n dokumentaatiosta.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // TURVALLISUUS: Arvoon pääsy `PtrRepr`-liitoksesta on turvallista, koska * const T
    // ja PtrComponents<T>on samat muistipaikat.
    // Vain std voi antaa tämän takuun.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Manuaalinen implantaatio tarvitaan `T: Copy`-sidoksen välttämiseksi.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Manuaalinen implantaatio tarvitaan `T: Clone`-sidoksen välttämiseksi.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// `Dyn = dyn SomeTrait` trait-kohdetyypin metatiedot.
///
/// Se on osoitus vtable-tiedostoon (virtuaalinen puhelutaulukko), joka edustaa kaikkia tarvittavia tietoja trait-objektiin tallennetun betonityypin manipuloimiseksi.
/// Vtable sisältää erityisesti:
///
/// * tyypin koko
/// * tyypin tasaus
/// * osoitin tyypin `drop_in_place` implille (voi olla ei-op tavalliselle vanhalle tiedolle)
/// * viittaa kaikkiin menetelmiin tyypin trait: n toteuttamiseksi
///
/// Huomaa, että kolme ensimmäistä ovat erityisiä, koska ne ovat tarpeen minkä tahansa trait-objektin varaamiseksi, pudottamiseksi ja jakamiseksi uudelleen.
///
/// On mahdollista nimetä tämä rakenne tyypin parametrilla, joka ei ole `dyn` trait-objekti (esimerkiksi `DynMetadata<u64>`), mutta ei saada kyseisen strukturation merkityksellistä arvoa.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Kaikkien vtablettien yhteinen etuliite.Sitä seuraa funktion osoittimet trait-menetelmille.
///
/// Yksityinen toteutustiedot `DynMetadata::size_of`: stä jne.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Palauttaa tähän vtable-tyyppiin liittyvän tyypin koon.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Palauttaa tähän vtable-tyyppiin liittyvän tyypin kohdistuksen.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Palauttaa koon ja kohdistuksen yhdessä `Layout`: nä
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // TURVALLISUUS: kääntäjä lähetti tämän kuvauksen betonille Rust, joka
        // tiedetään olevan kelvollinen asettelu.Sama perustelu kuin `Layout::for_value`: ssä.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Manuaalisia implittejä tarvitaan `Dyn: $Trait`-rajojen välttämiseksi.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}