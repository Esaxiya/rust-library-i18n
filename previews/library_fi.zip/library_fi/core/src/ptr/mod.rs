//! Hallitse muistia manuaalisesti raakojen osoittimien avulla.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Monet tämän moduulin toiminnot pitävät raakaviitteitä argumentteina ja lukevat niistä tai kirjoittavat niihin.Jotta tämä olisi turvallista, näiden osoittimien on oltava *kelvollisia*.
//! Osoittimen pätevyys riippuu toiminnasta, jota varten sitä käytetään (luku tai kirjoitus), ja käytetyn muistin laajuudesta (ts. Kuinka monta tavua ovat read/written).
//! Useimmat toiminnot käyttävät `*mut T`: ää ja `* const T`: tä vain yhden arvon käyttämiseen, jolloin dokumentaatiossa koko jätetään pois ja oletetaan implisiittisesti olevan `size_of::<T>()`-tavu.
//!
//! Tarkkoja voimassaolosääntöjä ei ole vielä määritelty.Tässä vaiheessa annetut takuut ovat hyvin vähäiset:
//!
//! * [null]-osoitin ei ole *koskaan* kelvollinen, ei edes [size zero][zst]: n pääsyille.
//! * Osoittimen ollessa kelvollinen, on välttämätöntä, mutta ei aina riittävää, että osoitin on *viitattavissa*: osoittimesta alkavan tietyn kokoisen muistialueen on oltava yhden allokoidun objektin rajoissa.
//!
//! Huomaa, että Rust: ssä jokaista (stack-allocated)-muuttujaa pidetään erillisenä allokoituna objektina.
//! * Jopa [size zero][zst]: n operaatioissa osoitin ei saa osoittaa kohdistettua muistia, ts. Jakauma tekee osoittimista virheellisiä edes nollakokoisissa operaatioissa.
//! Kaikkien nollasta poikkeavien kokonaislukujen *literaalien* lähettäminen osoittimeen pätee kuitenkin nollakokoisille pääsyille, vaikka kyseisessä osoitteessa sattuisi olemaan muistia ja se jakautuu.
//! Tämä vastaa oman allokaattorin kirjoittamista: nollakokoisten objektien varaaminen ei ole kovin vaikeaa.
//! Kanoninen tapa saada osoitin, joka on voimassa nollakokoisille pääsyille, on [`NonNull::dangling`].
//! * Kaikki tämän moduulin toimintojen suorittamat pääsyt ovat *ei-atomi*[atomic operations]: n mielessä, jota käytetään ketjujen synkronointiin.
//! Tämä tarkoittaa, että ei ole määriteltyä käyttäytymistä kahden samanaikaisen pääsyn suorittamiseksi samaan sijaintiin eri säikeistä, paitsi jos molemmat pääsyt luetaan vain muistista.
//! Huomaa, että tämä sisältää nimenomaisesti [`read_volatile`] ja [`write_volatile`]: Haihtuvia pääsyjä ei voida käyttää ketjujen väliseen synkronointiin.
//! * Osoittimeen viittauksen lähettämisen tulos on voimassa niin kauan kuin taustalla oleva kohde on aktiivinen eikä mitään muistia (vain raakoja osoittimia) käytetä saman muistin käyttämiseen.
//!
//! Nämä aksioomat yhdessä [`offset`]: n huolellisen käytön osoittimen aritmeettiseen käyttöön ovat riittävät toteuttamaan oikein monia hyödyllisiä asioita vaarallisessa koodissa.
//! Vahvemmat takuut annetaan lopulta, kun [aliasing]-sääntöjä määritetään.
//! Katso lisätietoja [book]: stä sekä [undefined behavior][ub]: lle omistetun viitteen osiosta.
//!
//! ## Alignment
//!
//! Edellä määriteltyjä kelvollisia raaka-osoittimia ei välttämättä ole kohdistettu oikein (missä "proper"-tasaus määritetään kohdetyypillä, ts. `*const T` on kohdistettava `mem::align_of::<T>()`: ään).
//! Useimmat toiminnot vaativat kuitenkin argumenttiensa yhdenmukaistamisen, ja tämä vaatimus mainitaan nimenomaisesti asiakirjoissa.
//! Merkittäviä poikkeuksia tähän ovat [`read_unaligned`] ja [`write_unaligned`].
//!
//! Kun toiminto vaatii oikean kohdistuksen, se tekee niin, vaikka pääsyllä olisi koko 0, vaikka muistia ei tosiasiallisesti kosketettakaan.Harkitse [`NonNull::dangling`]: n käyttöä tällaisissa tapauksissa.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Suorittaa huomautetun arvon tuhoajan (jos sellainen on).
///
/// Tämä vastaa semanttisesti [`ptr::read`]: n soittamista ja tuloksen hylkäämistä, mutta sillä on seuraavat edut:
///
/// * `drop_in_place`: ää on *vaadittava* pudottamaan kokoisia tyyppejä, kuten trait-esineitä, koska niitä ei voi lukea pinoon ja pudottaa normaalisti.
///
/// * Optimoijalle on ystävällisempää tehdä tämä [`ptr::read`]: n kautta, kun pudotetaan manuaalisesti allokoitua muistia (esim. `Box`/`Rc`/`Vec`: n toteutuksissa), koska kääntäjän ei tarvitse todistaa, että se on äänen kopioimiseksi.
///
///
/// * Sitä voidaan käyttää [pinned]-tietojen pudottamiseen, kun `T` ei ole `repr(packed)` (kiinnitettyjä tietoja ei saa siirtää ennen pudottamista).
///
/// Kohdistamattomia arvoja ei voida pudottaa paikalleen, ne on kopioitava ensin kohdistettuun sijaintiin [`ptr::read_unaligned`]: n avulla.Pakattujen rakenteiden osalta kääntäjä suorittaa tämän siirron automaattisesti.
/// Tämä tarkoittaa, että pakattujen rakenteiden kenttiä ei pudoteta paikalleen.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Käyttäytymistä ei ole määritelty, jos jotakin seuraavista ehdoista rikotaan:
///
/// * `to_drop` on oltava [valid] sekä luettaessa että kirjoitettaessa.
///
/// * `to_drop` on kohdistettava oikein.
///
/// * `to_drop`-pisteiden arvon on oltava pätevä pudotettaessa, mikä voi tarkoittaa, että sen on pidettävä yllä muita invarianteja, tämä on tyypistä riippuvainen.
///
/// Lisäksi, jos `T` ei ole [`Copy`], teräväpiirto-arvon käyttäminen `drop_in_place`: n kutsumisen jälkeen voi aiheuttaa määrittelemätöntä käyttäytymistä.Huomaa, että `*to_drop = foo` lasketaan käytöksi, koska se laskee arvon uudelleen.
/// [`write()`] voidaan käyttää tietojen korvaamiseen aiheuttamatta niiden pudottamista.
///
/// Huomaa, että vaikka `T`: llä on koko `0`, osoittimen on oltava ei-NULL ja kohdistettu oikein.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Poista viimeinen kohde manuaalisesti vector: stä:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Hanki raaka osoitin viimeiseen elementtiin `v`: ssä.
///     let ptr = &mut v[1] as *mut _;
///     // Lyhennä `v` estääksesi viimeisen kohteen pudottamisen.
///     // Teemme sen ensin estääkseen ongelmat, jos `drop_in_place` on alle panics.
///     v.set_len(1);
///     // Ilman puhelua `drop_in_place` viimeistä kohdetta ei koskaan pudoteta, ja sen hallitsema muisti vuotaa.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Varmista, että viimeinen kohde pudotettiin.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Huomaa, että kääntäjä suorittaa tämän kopion automaattisesti pudottaessaan pakattuja rakenteita, ts. Sinun ei yleensä tarvitse huolehtia tällaisista ongelmista, ellet soita `drop_in_place`: ään manuaalisesti.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Koodilla ei ole merkitystä, kääntäjä korvaa tämän todellisella drop-liimalla.
    //

    // TURVALLISUUS: katso yllä oleva kommentti
    unsafe { drop_in_place(to_drop) }
}

/// Luo tyhjän raakaosoittimen.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Luo tyhjän muutettavan raakapainikkeen.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Manuaalinen implantaatio tarvitaan `T: Clone`-sidoksen välttämiseksi.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Manuaalinen implantaatio tarvitaan `T: Copy`-sidoksen välttämiseksi.
impl<T> Copy for FatPtr<T> {}

/// Muodostaa raakaviipale osoittimen ja pituuden.
///
/// `len`-argumentti on **elementtien** määrä, ei tavujen lukumäärä.
///
/// Tämä toiminto on turvallinen, mutta palautusarvon käyttäminen on vaarallista.
/// Katso viipaleiden turvallisuusvaatimukset [`slice::from_raw_parts`]: n dokumentaatiosta.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // luo viipaleosoitin, kun aloitat osoittimella ensimmäiseen elementtiin
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // TURVALLISUUS: Arvoon pääsy `Repr`-liitoksesta on turvallista, koska * const [T]
        //
        // ja FatPtr: llä on samat muistiasettelut.Vain std voi antaa tämän takuun.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Suorittaa saman toiminnallisuuden kuin [`slice_from_raw_parts`], paitsi että palautetaan raaka muutettava viipale toisin kuin raaka muuttumaton viipale.
///
///
/// Katso lisätietoja [`slice_from_raw_parts`]: n dokumentaatiosta.
///
/// Tämä toiminto on turvallinen, mutta palautusarvon käyttäminen on vaarallista.
/// Katso viipaleiden turvallisuusvaatimukset [`slice::from_raw_parts_mut`]: n dokumentaatiosta.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // määritä arvo leikkeen hakemistoon
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // TURVALLISUUS: Arvoon pääsy `Repr`-liitoksesta on turvallista, koska * mut [T]
        // ja FatPtr: llä on samat muistiasettelut
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Vaihtaa arvot kahteen samantyyppiseen muuttuvaan sijaintiin kumpaakaan deinitalisoimatta.
///
/// Mutta seuraavista kahdesta poikkeuksesta tämä toiminto vastaa semanttisesti [`mem::swap`]: ää:
///
///
/// * Se toimii raaka viitteillä viitteiden sijaan.
/// Kun viitteitä on saatavilla, [`mem::swap`] on suositeltava.
///
/// * Kaksi osoitettua arvoa voivat olla päällekkäisiä.
/// Jos arvot menevät päällekkäin, käytetään `x`: n muistin limittyvää aluetta.
/// Tämä osoitetaan alla olevassa toisessa esimerkissä.
///
/// # Safety
///
/// Käyttäytymistä ei ole määritelty, jos jotakin seuraavista ehdoista rikotaan:
///
/// * Sekä `x`: n että `y`: n on oltava [valid] sekä lukea että kirjoittaa.
///
/// * Sekä `x` että `y` on kohdistettava oikein.
///
/// Huomaa, että vaikka `T`: llä on koko `0`, osoittimien on oltava ei-NULL ja oikein kohdistettuja.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Kahden päällekkäisen alueen vaihtaminen:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // tämä on `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // tämä on `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Kahden päällekkäisen alueen vaihtaminen:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // tämä on `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // tämä on `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Viipaleen indeksit `1..3` ovat päällekkäisiä `x`: n ja `y`: n välillä.
///     // Kohtuulliset tulokset olisivat heidän mielestään `[2, 3]`, joten indeksit `0..3` ovat `[1, 2, 3]` (vastaavat `y` ennen `swap`);tai että ne olisivat `[0, 1]` niin, että indeksit `1..4` ovat `[0, 1, 2]` (vastaavat `x`: ää ennen `swap`: ää).
/////
///     // Tämä toteutus on määritelty jälkimmäisen valinnan tekemiseksi.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Anna itsellemme raaputilaa työskennellä.
    // Meidän ei tarvitse huolehtia pudotuksista: `MaybeUninit` ei tee mitään pudotessaan.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Suorita vaihdon TURVALLISUUS: soittajan on taattava, että `x` ja `y` ovat kelvollisia kirjoituksille ja kohdistettu oikein.
    // `tmp` ei voi olla päällekkäinen joko `x`: n tai `y`: n kanssa, koska `tmp` oli juuri varattu pinolle erillisenä allokoituna objektina.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` ja `y` voivat olla päällekkäisiä
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Vaihtaa `count * size_of::<T>()`-tavut muistialueiden välillä, jotka alkavat kohdasta `x` ja `y`.
/// Kahden alueen ei tule * olla päällekkäisiä.
///
/// # Safety
///
/// Käyttäytymistä ei ole määritelty, jos jotakin seuraavista ehdoista rikotaan:
///
/// * Sekä `x`: n että `y`: n on oltava [valid] sekä lukemalla että kirjoitettaessa `count *
///   koko: :<T>() `tavua.
///
/// * Sekä `x` että `y` on kohdistettava oikein.
///
/// * Muistialue, joka alkaa `x`: stä ja jonka koko on `count *
///   koko: :<T>() `tavujen ei *saa* olla päällekkäisiä muistikohdan kanssa, joka alkaa `y`: stä samankokoisina.
///
/// Huomaa, että vaikka tosiasiallisesti kopioitu koko (`count * size_of: :<T>()`) on `0`, osoittimien on oltava ei-NULL ja oikein kohdistettuja.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Peruskäyttö:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // TURVALLISUUS: soittajan on taattava, että `x` ja `y` ovat
    // voimassa kirjoituksille ja kohdistettu oikein.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Vaihda alla olevien lohkooptimointia pienempien tyyppien kohdalla vain suoraan, jotta vältetään koodegeenin pessimointi.
    //
    if mem::size_of::<T>() < 32 {
        // TURVALLISUUS: soittajan on taattava, että `x` ja `y` ovat kelvollisia
        // kirjoituksille, tasattu oikein ja ei päällekkäisiä.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // TURVALLISUUS: soittajan on noudatettava `swap_nonoverlapping`: n turvasopimusta.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Lähestymistapa on simd: n hyödyntäminen x&y: n vaihtamiseksi tehokkaasti.
    // Testaus paljastaa, että joko 32 tai 64 tavun vaihto kerrallaan on tehokkainta Intel Haswell E-prosessoreille.
    // LLVM pystyy optimoimaan paremmin, jos annamme strukturille #[repr(simd)]: n, vaikka emme itse käytä tätä rakennetta suoraan.
    //
    //
    // FIXME repr(simd) rikki emscriptenissä ja redoxissa
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Silmukka x&y: n läpi kopioimalla ne `Block` kerrallaan Optimoijan tulisi purkaa silmukka kokonaan useimpien tyyppien kohdalla NB
    // Emme voi käyttää silmukkaa, koska `range`-implisiitti kutsuu `mem::swap`: ää rekursiivisesti
    //
    let mut i = 0;
    while i + block_size <= len {
        // Luo alustamatonta muistia tyhjäksi. `t`: n ilmoittaminen välttää pinon kohdistamisen, kun tätä silmukkaa ei käytetä
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // TURVALLISUUS: Kuten `i < len` ja soittajan on taattava, että `x` ja `y` ovat kelvollisia
        // `len`-tavuille `x + i`: n ja `y + i`: n on oltava kelvollisia osoitteita, jotka täyttävät `add`: n turvasopimuksen.
        //
        // Soittajan on myös taattava, että `x` ja `y` ovat kelvollisia kirjoituksille, oikein kohdistetut ja päällekkäiset, mikä täyttää `copy_nonoverlapping`: n turvasopimuksen.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Vaihda x&y-tavun lohko käyttämällä väliaikaisena puskurina t: tä. Tämä tulisi optimoida tehokkaiksi SIMD-operaatioiksi, jos sellaisia on
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Vaihda jäljellä olevat tavut
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // TURVALLISUUS: katso edellinen turvallisuuskommentti.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Siirtää `src`: n terävään `dst`: ään palauttamalla edellisen `dst`-arvon.
///
/// Kumpikaan arvo ei pudota.
///
/// Tämä toiminto vastaa semanttisesti [`mem::replace`]: ää paitsi, että se toimii raaka-osoittimilla viitteiden sijaan.
/// Kun viitteitä on saatavilla, [`mem::replace`] on suositeltava.
///
/// # Safety
///
/// Käyttäytymistä ei ole määritelty, jos jotakin seuraavista ehdoista rikotaan:
///
/// * `dst` on oltava [valid] sekä luettaessa että kirjoitettaessa.
///
/// * `dst` on kohdistettava oikein.
///
/// * `dst` on osoitettava oikein alustettu arvo tyyppi `T`.
///
/// Huomaa, että vaikka `T`: llä on koko `0`, osoittimen on oltava ei-NULL ja kohdistettu oikein.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` olisi sama vaikutus tarvitsematta vaarallista estoa.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // TURVALLISUUS: soittajan on taattava, että `dst` on voimassa
    // valettu muutettavaksi viitteeksi (voimassa kirjoitettaessa, tasattu, alustettu), eikä se voi olla päällekkäinen `src`: n kanssa, koska `dst`: n on osoitettava erilliseen allokoituun objektiin.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // eivät voi olla päällekkäisiä
    }
    src
}

/// Lukee arvon `src`: stä siirtämättä sitä.Tämä jättää `src`: n muistin muuttumattomaksi.
///
/// # Safety
///
/// Käyttäytymistä ei ole määritelty, jos jotakin seuraavista ehdoista rikotaan:
///
/// * `src` on oltava [valid] lukemista varten.
///
/// * `src` on kohdistettava oikein.Käytä [`read_unaligned`], jos näin ei ole.
///
/// * `src` on osoitettava oikein alustettu arvo tyyppi `T`.
///
/// Huomaa, että vaikka `T`: llä on koko `0`, osoittimen on oltava ei-NULL ja kohdistettu oikein.
///
/// # Examples
///
/// Peruskäyttö:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Ota [`mem::swap`] käyttöön manuaalisesti:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Luo bittikopio arvosta `a` `tmp`: ssä.
///         let tmp = ptr::read(a);
///
///         // Tässä vaiheessa poistuminen (joko nimenomaisella palautuksella tai kutsumalla funktio, jonka panics) aiheuttaisi arvon `tmp` pudotuksen samalla kun `a` viittaa edelleen samaan arvoon.
///         // Tämä voi laukaista määrittelemättömän käyttäytymisen, jos `T` ei ole `Copy`.
/////
/////
///
///         // Luo bittikopio arvosta `b` `a`: ssä.
///         // Tämä on turvallista, koska muutettavissa olevat viitteet eivät voi olla aliaksia.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Kuten yllä, täältä poistuminen voi laukaista määrittelemättömän käyttäytymisen, koska `a` ja `b` viittaavat samaan arvoon.
/////
///
///         // Siirrä `tmp` kohtaan `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` on siirretty (`write` ottaa toisen argumentin omistukseen), joten mitään ei jätetä implisiittisesti tähän.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Palautetun arvon omistusoikeus
///
/// `read` luo `T`: n bittikopion riippumatta siitä, onko `T` [`Copy`].
/// Jos `T` ei ole [`Copy`], sekä palautetun arvon että `*src`: n arvon käyttö voi vahingoittaa muistin turvallisuutta.
/// Huomaa, että määrittäminen `*src`: lle lasketaan käytöksi, koska se yrittää pudottaa arvon `* src`: ssä.
///
/// [`write()`] voidaan käyttää tietojen korvaamiseen aiheuttamatta niiden pudottamista.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` osoittaa nyt samaan muistiin kuin `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Määrittäminen `s2`: ään aiheuttaa sen alkuperäisen arvon pudotuksen.
///     // Tämän kohdan jälkeen `s`: ää ei enää tarvitse käyttää, koska taustalla oleva muisti on vapautettu.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Määrittäminen `s`: hen aiheuttaisi vanhan arvon pudottamisen uudelleen, mikä johtaisi määrittelemättömään käyttäytymiseen.
/////
///     // s= String::from("bar");//VIRHE
///
///     // `ptr::write` voidaan käyttää korvaamaan arvo pudottamatta sitä.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // TURVALLISUUS: soittajan on taattava, että `src` on voimassa lukemiseen.
    // `src` ei voi olla päällekkäinen `tmp`: n kanssa, koska `tmp` oli juuri varattu pinoon erillisenä allokoituna objektina.
    //
    //
    // Lisäksi, koska kirjoitimme juuri kelvollisen arvon `tmp`: ään, se on taatusti alustettu oikein.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Lukee arvon `src`: stä siirtämättä sitä.Tämä jättää `src`: n muistin muuttumattomaksi.
///
/// Toisin kuin [`read`], `read_unaligned` toimii kohdistamattomien osoittimien kanssa.
///
/// # Safety
///
/// Käyttäytymistä ei ole määritelty, jos jotakin seuraavista ehdoista rikotaan:
///
/// * `src` on oltava [valid] lukemista varten.
///
/// * `src` on osoitettava oikein alustettu arvo tyyppi `T`.
///
/// Kuten [`read`], `read_unaligned` luo `T`: n bittikopion riippumatta siitä, onko `T` [`Copy`].
/// Jos `T` ei ole [`Copy`], [violate memory safety][read-ownership] voidaan käyttää sekä palautetun arvon että `*src`: n arvon avulla.
///
/// Huomaa, että vaikka `T`: llä on koko `0`, osoittimen on oltava ei-NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## `packed`-rakenteissa
///
/// Tällä hetkellä on mahdotonta luoda raakoja viitteitä pakatun rakenteen kohdistamattomille kentille.
///
/// Yritetään luoda raaka osoitin `unaligned`-rakennekenttään lausekkeella, kuten `&packed.unaligned as *const FieldType`, luo välitön viittaamaton viite ennen sen muuntamista raakaksi osoittimeksi.
///
/// Sillä, että tämä viittaus on väliaikainen ja välittömästi valettu, ei ole merkitystä, koska kääntäjä odottaa aina viitteiden olevan oikeassa linjassa.
/// Tämän seurauksena `&packed.unaligned as *const FieldType`: n käyttö aiheuttaa välitöntä* määrittelemätöntä käyttäytymistä * ohjelmassasi.
///
/// Esimerkki siitä, mitä ei pidä tehdä ja miten tämä liittyy `read_unaligned`: ään, on:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Tässä yritetään ottaa 32-bittisen kokonaisluvun osoite, jota ei ole kohdistettu.
///     let unaligned =
///         // Tällöin luodaan väliaikainen kohdistamaton viite, joka johtaa määrittelemättömään käyttäytymiseen riippumatta siitä, käytetäänkö viittausta vai ei.
/////
///         &packed.unaligned
///         // Raaka-osoittimeen lähettäminen ei auta;virhe jo tapahtui.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Suoraan pääsy kohdistamattomille kentille esim. `packed.unaligned`: llä on kuitenkin turvallista.
///
///
///
///
///
///
// FIXME: Päivitä asiakirjat RFC #2582: n ja ystävien tulosten perusteella.
/// # Examples
///
/// Lue usize-arvo tavupuskurista:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // TURVALLISUUS: soittajan on taattava, että `src` on voimassa lukemiseen.
    // `src` ei voi olla päällekkäinen `tmp`: n kanssa, koska `tmp` oli juuri varattu pinoon erillisenä allokoituna objektina.
    //
    //
    // Lisäksi, koska kirjoitimme juuri kelvollisen arvon `tmp`: ään, se on taatusti alustettu oikein.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Korvaa muistipaikan annetulla arvolla lukematta tai pudottamatta vanhaa arvoa.
///
/// `write` ei pudota `dst`: n sisältöä.
/// Tämä on turvallista, mutta se voi vuotaa allokaatioita tai resursseja, joten tulisi olla varovainen, ettet korvaa pudotettavaa esinettä.
///
///
/// Lisäksi se ei pudota `src`: tä.Semanttisesti `src` siirretään `dst`: n osoittamaan paikkaan.
///
/// Tämä sopii alustamattoman muistin alustamiseen tai aikaisemmin [`read`]: stä muokatun muistin korvaamiseen.
///
/// # Safety
///
/// Käyttäytymistä ei ole määritelty, jos jotakin seuraavista ehdoista rikotaan:
///
/// * `dst` on oltava [valid] kirjoitettaessa.
///
/// * `dst` on kohdistettava oikein.Käytä [`write_unaligned`], jos näin ei ole.
///
/// Huomaa, että vaikka `T`: llä on koko `0`, osoittimen on oltava ei-NULL ja kohdistettu oikein.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Peruskäyttö:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Ota [`mem::swap`] käyttöön manuaalisesti:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Luo bittikopio arvosta `a` `tmp`: ssä.
///         let tmp = ptr::read(a);
///
///         // Tässä vaiheessa poistuminen (joko nimenomaisella palautuksella tai kutsumalla funktio, jonka panics) aiheuttaisi arvon `tmp` pudotuksen samalla kun `a` viittaa edelleen samaan arvoon.
///         // Tämä voi laukaista määrittelemättömän käyttäytymisen, jos `T` ei ole `Copy`.
/////
/////
///
///         // Luo bittikopio arvosta `b` `a`: ssä.
///         // Tämä on turvallista, koska muutettavissa olevat viitteet eivät voi olla aliaksia.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Kuten yllä, täältä poistuminen voi laukaista määrittelemättömän käyttäytymisen, koska `a` ja `b` viittaavat samaan arvoon.
/////
///
///         // Siirrä `tmp` kohtaan `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` on siirretty (`write` ottaa toisen argumentin omistukseen), joten mitään ei jätetä implisiittisesti tähän.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Soitamme sisäisiin ominaisuuksiin suoraan välttääksemme funktiokutsuja luotavassa koodissa, koska `intrinsics::copy_nonoverlapping` on kääritoiminto.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // TURVALLISUUS: soittajan on taattava, että `dst` on kelvollinen kirjoituksiin.
    // `dst` ei voi olla päällekkäinen `src`: n kanssa, koska soittajalla on muutettava pääsy `dst`: ään, kun taas `src` on tämän toiminnon omistuksessa.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Korvaa muistipaikan annetulla arvolla lukematta tai pudottamatta vanhaa arvoa.
///
/// Toisin kuin [`write()`], osoitin voi olla kohdistamaton.
///
/// `write_unaligned` ei pudota `dst`: n sisältöä.Tämä on turvallista, mutta se voi vuotaa allokaatioita tai resursseja, joten tulisi olla varovainen, ettet korvaa pudotettavaa esinettä.
///
/// Lisäksi se ei pudota `src`: tä.Semanttisesti `src` siirretään `dst`: n osoittamaan paikkaan.
///
/// Tämä sopii alustamattoman muistin alustamiseen tai aiemmin [`read_unaligned`]: llä luetun muistin korvaamiseen.
///
/// # Safety
///
/// Käyttäytymistä ei ole määritelty, jos jotakin seuraavista ehdoista rikotaan:
///
/// * `dst` on oltava [valid] kirjoitettaessa.
///
/// Huomaa, että vaikka `T`: llä on koko `0`, osoittimen on oltava ei-NULL.
///
/// [valid]: self#safety
///
/// ## `packed`-rakenteissa
///
/// Tällä hetkellä on mahdotonta luoda raakoja viitteitä pakatun rakenteen kohdistamattomille kentille.
///
/// Yritetään luoda raaka osoitin `unaligned`-rakennekenttään lausekkeella, kuten `&packed.unaligned as *const FieldType`, luo välitön viittaamaton viite ennen sen muuntamista raakaksi osoittimeksi.
///
/// Sillä, että tämä viittaus on väliaikainen ja välittömästi valettu, ei ole merkitystä, koska kääntäjä odottaa aina viitteiden olevan oikeassa linjassa.
/// Tämän seurauksena `&packed.unaligned as *const FieldType`: n käyttö aiheuttaa välitöntä* määrittelemätöntä käyttäytymistä * ohjelmassasi.
///
/// Esimerkki siitä, mitä ei pidä tehdä ja miten tämä liittyy `write_unaligned`: ään, on:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Tässä yritetään ottaa 32-bittisen kokonaisluvun osoite, jota ei ole kohdistettu.
///     let unaligned =
///         // Tällöin luodaan väliaikainen kohdistamaton viite, joka johtaa määrittelemättömään käyttäytymiseen riippumatta siitä, käytetäänkö viittausta vai ei.
/////
///         &mut packed.unaligned
///         // Raaka-osoittimeen lähettäminen ei auta;virhe jo tapahtui.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Suoraan pääsy kohdistamattomille kentille esim. `packed.unaligned`: llä on kuitenkin turvallista.
///
///
///
///
///
///
///
///
///
// FIXME: Päivitä asiakirjat RFC #2582: n ja ystävien tulosten perusteella.
/// # Examples
///
/// Kirjoita tavun puskuriin usize-arvo:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // TURVALLISUUS: soittajan on taattava, että `dst` on kelvollinen kirjoituksiin.
    // `dst` ei voi olla päällekkäinen `src`: n kanssa, koska soittajalla on muutettava pääsy `dst`: ään, kun taas `src` on tämän toiminnon omistuksessa.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Kutsumme sisäistä suoraan välttääksemme funktiokutsut luotavassa koodissa.
        intrinsics::forget(src);
    }
}

/// Suorittaa arvon haihtuvan lukemisen `src`: stä siirtämättä sitä.Tämä jättää `src`: n muistin muuttumattomaksi.
///
/// Haihtuvien operaatioiden on tarkoitus toimia I/O-muistissa, ja kääntäjä ei taata, että niitä valitaan tai järjestetään uudelleen muiden haihtuvien toimintojen yhteydessä.
///
/// # Notes
///
/// Rust: llä ei tällä hetkellä ole tiukasti ja muodollisesti määriteltyä muistimallia, joten "volatile": n tarkan semantiikan merkitys tässä voi muuttua ajan myötä.
/// Tästä huolimatta semantiikka loppuu melkein aina melko samanlaiseksi kuin [C11's definition of volatile][c11].
///
/// Kääntäjä ei saa muuttaa haihtuvien muistitoimintojen suhteellista järjestystä tai lukumäärää.
/// Haihtuvien muistitoimintojen tekeminen nollakokoisilla tyypeillä (esim. Jos nollakokoinen tyyppi siirretään `read_volatile`: lle) ovat noops ja ne voidaan jättää huomioimatta.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Käyttäytymistä ei ole määritelty, jos jotakin seuraavista ehdoista rikotaan:
///
/// * `src` on oltava [valid] lukemista varten.
///
/// * `src` on kohdistettava oikein.
///
/// * `src` on osoitettava oikein alustettu arvo tyyppi `T`.
///
/// Kuten [`read`], `read_volatile` luo `T`: n bittikopion riippumatta siitä, onko `T` [`Copy`].
/// Jos `T` ei ole [`Copy`], [violate memory safety][read-ownership] voidaan käyttää sekä palautetun arvon että `*src`: n arvon avulla.
/// Muiden kuin [`kopio ']-tyyppien tallentaminen haihtuvaan muistiin on kuitenkin melkein varmasti virheellistä.
///
/// Huomaa, että vaikka `T`: llä on koko `0`, osoittimen on oltava ei-NULL ja kohdistettu oikein.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Aivan kuten C: ssä, onko operaatio epävakaa, ei ole mitään merkitystä kysymyksissä, joihin liittyy samanaikainen pääsy useista säikeistä.Haihtuvat pääsyt käyttäytyvät tältä osin täsmälleen kuin ei-atomiyhteydet.
///
/// Erityisesti kilpailu `read_volatile`: n ja minkä tahansa kirjoitusoperaation välillä samaan paikkaan on määrittelemätöntä käyttäytymistä.
///
/// # Examples
///
/// Peruskäyttö:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Ei paniikkia pitämään codegen-vaikutuksia pienempinä.
        abort();
    }
    // TURVALLISUUS: soittajan on noudatettava `volatile_load`: n turvasopimusta.
    unsafe { intrinsics::volatile_load(src) }
}

/// Suorittaa haihtuvan muistipaikan kirjoittamisen annetulla arvolla lukematta tai pudottamatta vanhaa arvoa.
///
/// Haihtuvien operaatioiden on tarkoitus toimia I/O-muistissa, ja kääntäjä ei taata, että niitä valitaan tai järjestetään uudelleen muiden haihtuvien toimintojen yhteydessä.
///
/// `write_volatile` ei pudota `dst`: n sisältöä.Tämä on turvallista, mutta se voi vuotaa allokaatioita tai resursseja, joten tulisi olla varovainen, ettet korvaa pudotettavaa esinettä.
///
/// Lisäksi se ei pudota `src`: tä.Semanttisesti `src` siirretään `dst`: n osoittamaan paikkaan.
///
/// # Notes
///
/// Rust: llä ei tällä hetkellä ole tiukasti ja muodollisesti määriteltyä muistimallia, joten "volatile": n tarkan semantiikan merkitys tässä voi muuttua ajan myötä.
/// Tästä huolimatta semantiikka loppuu melkein aina melko samanlaiseksi kuin [C11's definition of volatile][c11].
///
/// Kääntäjä ei saa muuttaa haihtuvien muistitoimintojen suhteellista järjestystä tai lukumäärää.
/// Haihtuvien muistitoimintojen tekeminen nollakokoisilla tyypeillä (esim. Jos nollakokoinen tyyppi siirretään `write_volatile`: lle) ovat noops ja ne voidaan jättää huomioimatta.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Käyttäytymistä ei ole määritelty, jos jotakin seuraavista ehdoista rikotaan:
///
/// * `dst` on oltava [valid] kirjoitettaessa.
///
/// * `dst` on kohdistettava oikein.
///
/// Huomaa, että vaikka `T`: llä on koko `0`, osoittimen on oltava ei-NULL ja kohdistettu oikein.
///
/// [valid]: self#safety
///
/// Aivan kuten C: ssä, onko operaatio epävakaa, ei ole mitään merkitystä kysymyksissä, joihin liittyy samanaikainen pääsy useista säikeistä.Haihtuvat pääsyt käyttäytyvät tältä osin täsmälleen kuin ei-atomiyhteydet.
///
/// Erityisesti kilpailu `write_volatile`: n ja minkä tahansa muun toiminnon (lukeminen tai kirjoittaminen) välillä samassa paikassa on määrittelemätöntä käyttäytymistä.
///
/// # Examples
///
/// Peruskäyttö:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Ei paniikkia pitämään codegen-vaikutuksia pienempinä.
        abort();
    }
    // TURVALLISUUS: soittajan on noudatettava `volatile_store`: n turvasopimusta.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Kohdista osoitin `p`.
///
/// Laske siirtymä (`stride`-askeleen elementteinä), joka on sovellettava osoittimeen `p`, jotta osoitin `p` kohdistuisi `a`: ään.
///
/// Note: Tämä toteutus on räätälöity huolellisesti panic: n sijasta.Tämän on UB panic: lle.
/// Ainoa todellinen muutos, joka voidaan tehdä tässä, on `INV_TABLE_MOD_16`: n ja siihen liittyvien vakioiden muutos.
///
/// Jos päätämme koskaan tehdä mahdolliseksi kutsua luontaista `a`: llä, joka ei ole kahden teho, on luultavasti järkevämpää vaihtaa vain naiiviin toteutukseen sen sijaan, että yritettäisiin mukauttaa tätä vastaamaan muutokseen.
///
///
/// Kysymykset menevät osoitteeseen@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Näiden sisäisten ominaisuuksien suora käyttö parantaa koodegeeniä merkittävästi opt-tasolla <=
    // 1, jossa näiden toimintojen menetelmäversioita ei ole piirretty.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Laske `x` modulo `m`: n multiplikatiivinen modulaarinen käänteinen.
    ///
    /// Tämä toteutus on räätälöity `align_offset`: lle ja sillä on seuraavat edellytykset:
    ///
    /// * `m` on kahden voima;
    /// * `x < m`; (jos `x ≥ m`, välitä sen sijaan `x % m`)
    ///
    /// Tämän toiminnon toteuttaminen ei saa olla panic.Koskaan.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Moninkertainen modulaarinen käänteinen taulukko modulo 2=16.
        ///
        /// Huomaa, että tämä taulukko ei sisällä arvoja, joissa käänteistä ei ole (esim. `0⁻¹ mod 16`, `2⁻¹ mod 16` jne.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo, johon `INV_TABLE_MOD_16` on tarkoitettu.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // TURVALLISUUS: `m`: n on oltava kahden teho, joten ei nolla.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Toistamme "up": n seuraavalla kaavalla:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // kunnes 2²ⁿ ≥ m.Sitten voimme pienentää haluamaamme `m`: ää ottamalla tuloksen `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Huomaa, että käytämme kääritoimintoja tässä tarkoituksella-alkuperäinen kaava käyttää esimerkiksi vähennyslaskua `mod n`.
                // On hienoa tehdä heille sen sijaan `mod usize::MAX`, koska otamme lopputuloksen `mod n` joka tapauksessa.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // TURVALLISUUS: `a` on kahden teho, joten se ei ole nolla.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` tapaus voidaan laskea yksinkertaisemmin `-p (mod a)`: n kautta, mutta se estää LLVM: n kykyä valita ohjeita, kuten `lea`.Sen sijaan laskemme
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // joka jakaa toiminnot kantavien alueiden ympärille, mutta pessimoi `and`: n riittävästi, jotta LLVM pystyy hyödyntämään tietämiään optimointeja.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Jo kohdistettu.Jee!
        return 0;
    } else if stride == 0 {
        // Jos osoitinta ei ole kohdistettu ja elementti on nollakokoinen, mikään määrä elementtejä ei koskaan kohdista osoitinta.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // TURVALLISUUS: a on kahden teho, joten ei nolla.stride==0 tapausta käsitellään yllä.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // TURVALLISUUS: gcdpow: lla on yläraja, joka on enintään usize-bittien määrä.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // TURVALLISUUS: gcd on aina suurempi tai yhtä suuri kuin 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Tämä branch ratkaisee seuraavan lineaarisen kongruenssiyhtälön:
        //
        // ` p + so = 0 mod a `
        //
        // `p` tässä on osoittimen arvo `s`, `T`: n juoksu, `o`-siirtymä `T: ssä 'ja `a`, pyydetty kohdistus.
        //
        // Kun `g = gcd(a, s)` ja yllä oleva ehto väittävät, että `p` on myös jaettavissa `g`: llä, voimme merkitä `a' = a/g`, `s' = s/g`, `p' = p/g`, niin tästä tulee vastaava:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Ensimmäinen termi on "the relative alignment of `p` to `a`" (jaettuna `g`: llä), toinen termi on "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (jaettuna jälleen `g`: llä).
        //
        // Jako `g`: llä on välttämätön käänteisosan muodostamiseksi hyvin, jos `a` ja `s` eivät ole yhteispohjaisia.
        //
        // Lisäksi tämän ratkaisun tuottama tulos ei ole "minimal", joten tulos on otettava `o mod lcm(s, a)`.Voimme korvata `lcm(s, a)`: n vain `a'`: llä.
        //
        //
        //
        //
        //

        // TURVALLISUUS: `gcdpow`: llä on yläraja, joka ei ole suurempi kuin takana olevien 0-bittien määrä `a`: ssä.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // TURVALLISUUS: `a2` ei ole nolla.`a`: n siirtäminen `gcdpow`: llä ei voi siirtää mitään asetettuja bittejä
        // `a`: ssä (josta sillä on täsmälleen yksi).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // TURVALLISUUS: `gcdpow`: llä on yläraja, joka ei ole suurempi kuin takana olevien 0-bittien määrä `a`: ssä.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // TURVALLISUUS: `gcdpow`: n yläraja ei ole suurempi kuin jäljessä olevien 0-bittien lukumäärä
        // `a`.
        // Lisäksi vähennyslasku ei voi ylittyä, koska `a2 = a >> gcdpow` on aina ehdottomasti suurempi kuin `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // TURVALLISUUS: `a2` on kahden teho, kuten edellä todistettiin.`s2` on ehdottomasti pienempi kuin `a2`
        // koska `(s % a) >> gcdpow` on ehdottomasti pienempi kuin `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Ei voida kohdistaa lainkaan.
    usize::MAX
}

/// Vertaa tasa-arvon raakoja ohjeita.
///
/// Tämä on sama kuin `==`-operaattorin käyttö, mutta vähemmän yleinen:
/// argumenttien on oltava `*const T`-raaka-osoittimia, ei mitään `PartialEq`: ää toteuttavaa.
///
/// Tätä voidaan käyttää vertaamaan `&T`-viitteitä (jotka pakottavat implisiittisesti `*const T`: ään) niiden osoitteen perusteella sen sijaan, että vertaisivat niitä, joihin ne osoittavat (mihin `PartialEq for &T`-toteutus tekee).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Viipaleita verrataan myös niiden pituuden perusteella (rasvaviitteet):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits: ää verrataan myös niiden toteutuksella:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Osoittimilla on sama osoite.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Objekteilla on samat osoitteet, mutta `Trait`: llä on erilaiset toteutukset.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Viittauksen muuntaminen `*const u8`: ksi vertaa osoitteen mukaan.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash raaka osoitin.
///
/// Tätä voidaan käyttää `&T`-viitteen (joka implisiittisesti pakottaa `*const T`: ään) hajauttamiseen sen osoitteen perusteella sen arvon sijaan, johon se osoittaa (mihin `Hash for &T`-toteutus tekee).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Impls toiminnon osoittimille
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: AVR: lle vaaditaan välittäjävalinta kuten usize
                // niin, että lähdefunktion osoittimen osoiteavaruus säilytetään lopullisessa funktion osoittimessa.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: AVR: lle vaaditaan välittäjävalinta kuten usize
                // niin, että lähdefunktion osoittimen osoiteavaruus säilytetään lopullisessa funktion osoittimessa.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Ei variaattisia funktioita 0 parametrilla
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Luo `const`-raaka osoitin paikkaan luomatta väliviittausta.
///
/// Viitteen luominen `&`/`&mut`: llä on sallittua vain, jos osoitin on kohdistettu oikein ja osoittaa alustettuihin tietoihin.
/// Tapauksissa, joissa nämä vaatimukset eivät täyty, sen sijaan tulisi käyttää raakaviitteitä.
/// `&expr as *const _` kuitenkin luo viitteen ennen sen heittämistä raakaa osoittimeen, ja tähän viitteeseen sovelletaan samoja sääntöjä kuin kaikkiin muihin viitteisiin.
///
/// Tämä makro voi luoda raakaosoittimen * luomatta ensin viitteitä.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` loisi viittauksen kohdistamattomaksi ja olisi siten määrittelemätöntä käyttäytymistä!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Luo `mut`-raaka osoitin paikkaan luomatta väliviittausta.
///
/// Viitteen luominen `&`/`&mut`: llä on sallittua vain, jos osoitin on kohdistettu oikein ja osoittaa alustettuihin tietoihin.
/// Tapauksissa, joissa nämä vaatimukset eivät täyty, sen sijaan tulisi käyttää raakaviitteitä.
/// `&mut expr as *mut _` kuitenkin luo viitteen ennen sen heittämistä raakaa osoittimeen, ja tähän viitteeseen sovelletaan samoja sääntöjä kuin kaikkiin muihin viitteisiin.
///
/// Tämä makro voi luoda raakaosoittimen * luomatta ensin viitteitä.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` loisi viittauksen kohdistamattomaksi ja olisi siten määrittelemätöntä käyttäytymistä!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` pakottaa kopioimaan kentän viitteen luomisen sijaan.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}