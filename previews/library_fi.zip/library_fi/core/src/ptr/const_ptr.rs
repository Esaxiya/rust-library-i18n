use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::mem;
use crate::slice::{self, SliceIndex};

#[lang = "const_ptr"]
impl<T: ?Sized> *const T {
    /// Palauttaa `true`, jos osoitin on nolla.
    ///
    /// Huomaa, että mitoittamattomilla tyypeillä on monia mahdollisia nollaosoittimia, koska vain raakatietojen osoitin otetaan huomioon, ei niiden pituuksia, näennäisiä jne.
    /// Siksi kaksi nollaa osoitinta eivät välttämättä edes vertaa toisiaan.
    ///
    /// ## Käyttäytyminen const-arvioinnin aikana
    ///
    /// Kun tätä toimintoa käytetään const-arvioinnin aikana, se voi palauttaa `false`: n osoittimille, jotka osoittautuvat nolliksi ajon aikana.
    /// Tarkemmin sanottuna, kun osoitin johonkin muistiin siirretään sen rajojen ulkopuolelle siten, että tuloksena oleva osoitin on nolla, funktio palauttaa silti `false`: n.
    ///
    /// CTFE ei voi mitenkään tietää kyseisen muistin absoluuttista sijaintia, joten emme voi kertoa, onko osoitin tyhjä vai ei.
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Vertaa valun kautta ohueseen osoittimeen, joten paksut osoittimet harkitsevat vain niiden "data"-osaa tyhjäksi.
        //
        (self as *const u8).guaranteed_eq(null())
    }

    /// Heittää toisen tyyppiseen osoittimeen.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// Hajota (mahdollisesti leveä) osoitin osoite-ja metatietokomponenteiksi.
    ///
    /// Osoitin voidaan myöhemmin rekonstruoida [`from_raw_parts`]: llä.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// Palauttaa arvon `None`, jos osoitin on nolla, tai palauttaa jaetun viitteen `Some`: ään käärittyyn arvoon.Jos arvo voi olla alustamaton, sen sijaan on käytettävä [`as_uninit_ref`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// Kun kutsut tätä menetelmää, sinun on varmistettava, että *joko* osoitin on NULL *tai* kaikki seuraavat ovat totta:
    ///
    /// * Osoittimen on oltava kohdistettu oikein.
    ///
    /// * Sen on oltava "dereferencable" siinä merkityksessä kuin [the module documentation].
    ///
    /// * Osoittimen on osoitettava alustettu `T`-ilmentymä.
    ///
    /// * Sinun on pantava täytäntöön Rust: n aliaksisäännöt, koska palautettu elinikä `'a` valitaan mielivaltaisesti eikä välttämättä kuvasta tietojen todellista käyttöikää.
    ///   Erityisesti tämän käyttöiän ajan muisti, johon osoitin osoittaa, ei saa mutatoitua (paitsi `UnsafeCell`: n sisällä).
    ///
    /// Tämä pätee, vaikka tämän menetelmän tulosta ei käytettäisikään!
    /// (Alustamista koskevaa osaa ei ole vielä täysin päätetty, mutta ennen kuin se on, ainoa turvallinen lähestymistapa on varmistaa, että ne todella alustetaan.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Tyhjä-tarkistamaton versio
    ///
    /// Jos olet varma, että osoitin ei voi koskaan olla tyhjä ja etsit jonkinlaista `as_ref_unchecked`: ää, joka palauttaa `&T`: n `Option<&T>`: n sijaan, tiedä, että voit jättää osoittimen suoraan poikkeamaan.
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // TURVALLISUUS: soittajan on taattava, että `self` on kelvollinen
        // viitteeksi, jos se ei ole nolla.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Palauttaa arvon `None`, jos osoitin on nolla, tai palauttaa jaetun viitteen `Some`: ään käärittyyn arvoon.
    /// Toisin kuin [`as_ref`], tämä ei edellytä arvon alustamista.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Kun kutsut tätä menetelmää, sinun on varmistettava, että *joko* osoitin on NULL *tai* kaikki seuraavat ovat totta:
    ///
    /// * Osoittimen on oltava kohdistettu oikein.
    ///
    /// * Sen on oltava "dereferencable" siinä merkityksessä kuin [the module documentation].
    ///
    /// * Sinun on pantava täytäntöön Rust: n aliaksisäännöt, koska palautettu elinikä `'a` valitaan mielivaltaisesti eikä välttämättä kuvasta tietojen todellista käyttöikää.
    ///
    ///   Erityisesti tämän käyttöiän ajan muisti, johon osoitin osoittaa, ei saa mutatoitua (paitsi `UnsafeCell`: n sisällä).
    ///
    /// Tämä pätee, vaikka tämän menetelmän tulosta ei käytettäisikään!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // TURVALLISUUS: soittajan on taattava, että `self` täyttää kaikki vaatimukset
        // vaatimukset viitteelle.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Laskee siirtymän osoittimesta.
    ///
    /// `count` on T: n yksikköinä;esim. `count` 3 edustaa `3 * size_of::<T>()`-tavujen osoittimen siirtymää.
    ///
    /// # Safety
    ///
    /// Jos jotain seuraavista ehdoista rikotaan, tulos on määrittelemätön käyttäytyminen:
    ///
    /// * Sekä aloitus-että tuloksena olevan osoittimen on oltava joko rajattuina tai yksi tavu saman allokoidun objektin lopun ohi.
    /// Huomaa, että Rust: ssä jokaista (stack-allocated)-muuttujaa pidetään erillisenä allokoituna objektina.
    ///
    /// * Laskettu siirto **tavuina** ei voi ylittää `isize`: ää.
    ///
    /// * Raja-alueiden siirtymä ei voi luottaa "wrapping around"-osoitetilaan.Toisin sanoen äärettömän tarkan summan **tavuina** on sovitettava usiziin.
    ///
    /// Kääntäjä ja vakiokirjasto pyrkivät yleensä varmistamaan, että allokaatiot eivät koskaan saavuta kokoa, jossa siirtymä on huolestuttava.
    /// Esimerkiksi `Vec` ja `Box` varmistavat, että ne eivät koskaan jaa enempää kuin `isize::MAX` tavua, joten `vec.as_ptr().add(vec.len())` on aina turvallinen.
    ///
    /// Suurin osa alustoista ei periaatteessa pysty edes rakentamaan tällaista allokointia.
    /// Esimerkiksi mikään tunnettu 64-bittinen alusta ei voi koskaan palvella 2 <sup>63</sup> tavun pyyntöä sivutaulukkorajoitusten tai osoitetilan jakamisen vuoksi.
    /// Jotkut 32-bittiset ja 16-bittiset käyttöympäristöt voivat kuitenkin onnistuneesti palvella yli `isize::MAX`-tavujen pyyntöä esimerkiksi fyysisen osoitteen laajennuksen avulla.
    ///
    /// Suoraan allokaattoreista hankittu muisti tai muistikartoitetut tiedostot * voivat sinänsä olla liian suuria käsittelemään tätä toimintoa.
    ///
    /// Harkitse [`wrapping_offset`]: n käyttöä, jos näitä rajoituksia on vaikea täyttää.
    /// Tämän menetelmän ainoa etu on, että se mahdollistaa aggressiivisemmat kääntäjien optimoinnit.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // TURVALLISUUS: soittajan on noudatettava `offset`: n turvasopimusta.
        unsafe { intrinsics::offset(self, count) }
    }

    /// Laskee siirtymän osoittimesta rivitysaritmeettisesti.
    ///
    /// `count` on T: n yksikköinä;esim. `count` 3 edustaa `3 * size_of::<T>()`-tavujen osoittimen siirtymää.
    ///
    /// # Safety
    ///
    /// Tämä toiminto itsessään on aina turvallista, mutta tuloksena olevan osoittimen käyttö ei ole.
    ///
    /// Tuloksena oleva osoitin pysyy kiinnitettynä samaan allokoituun objektiin, johon `self` osoittaa.
    /// Sitä *ei* voida käyttää toisen varatun objektin käyttämiseen.Huomaa, että Rust: ssä jokaista (stack-allocated)-muuttujaa pidetään erillisenä allokoituna objektina.
    ///
    /// Toisin sanoen, `let z = x.wrapping_offset((y as isize) - (x as isize))` ei *tee*`z`: stä samaa kuin `y`, vaikka oletamme, että `T`: llä on koko `1` eikä ylivuotoa ole: `z` on edelleen kiinnitetty objektiin, johon `x` on kiinnitetty, ja sen alijäämä on määrittelemätöntä käyttäytymistä, ellei `x` ja `y`-piste samaan allokoituun objektiin.
    ///
    /// Verrattuna [`offset`]: ään tämä menetelmä viivästyttää periaatteessa vaatimusta pysyä samassa allokoidussa objektissa: [`offset`] on välitön määrittelemätön käyttäytyminen ylittäessään objektirajoja;`wrapping_offset` tuottaa osoittimen, mutta johtaa silti määrittelemättömään käyttäytymiseen, jos osoitin on poissuljettu, kun se on kiinnitetyn objektin rajojen ulkopuolella.
    /// [`offset`] voidaan optimoida paremmin ja on siten parempi suorituskykyherkässä koodissa.
    ///
    /// Viivästetty tarkistus ottaa huomioon vain viitatun osoittimen arvon, ei lopputuloksen laskennassa käytettyjä väliarvoja.
    /// Esimerkiksi `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` on aina sama kuin `x`.Toisin sanoen, varatun objektin jättäminen ja sitten uudelleen syöttäminen myöhemmin on sallittua.
    ///
    /// Jos sinun on ylitettävä objektirajat, heitä osoitin kokonaislukuun ja suorita aritmeettinen tulos siellä.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// // Toista käyttämällä raakaa osoittinta kahden elementin välein
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // Tämä silmukka tulostaa "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // TURVALLISUUS: Sisäisellä `arith_offset`: llä ei ole edellytyksiä kutsua.
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// Laskee kahden osoittimen välisen etäisyyden.Palautettu arvo on T-yksikköinä: tavuina oleva etäisyys jaetaan `mem::size_of::<T>()`: llä.
    ///
    /// Tämä toiminto on käänteinen [`offset`]: lle.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// Jos jotain seuraavista ehdoista rikotaan, tulos on määrittelemätön käyttäytyminen:
    ///
    /// * Sekä aloitus-että toisen osoittimen on oltava joko rajattuina tai yksi tavu saman allokoidun kohteen lopussa.
    /// Huomaa, että Rust: ssä jokaista (stack-allocated)-muuttujaa pidetään erillisenä allokoituna objektina.
    ///
    /// * Molempien osoittimien on oltava *johdettuja* saman objektin osoittimesta.
    ///   (Katso esimerkki alla.)
    ///
    /// * Osoittimien välisen etäisyyden tavuina on oltava `T`: n koon tarkka kerroin.
    ///
    /// * Osoittimien välinen etäisyys **tavuina** ei voi ylittää `isize`: ää.
    ///
    /// * Rajat ylittävä etäisyys ei voi luottaa "wrapping around"-osoitetilaan.
    ///
    /// Rust-tyypit eivät ole koskaan suurempia kuin `isize::MAX` ja Rust-allokaatiot eivät koskaan kääri osoiteavaruutta, joten kaksi minkä tahansa Rust-tyypin `T` jonkin arvon arvoa osoittavaa osoitinta täyttävät aina kaksi viimeistä ehtoa.
    ///
    /// Vakiokirjasto varmistaa myös, että allokaatiot eivät koskaan saavuta kokoa, jossa siirtymä on huolestuttava.
    /// Esimerkiksi `Vec` ja `Box` varmistavat, että ne eivät koskaan jaa enempää kuin `isize::MAX` tavua, joten `ptr_into_vec.offset_from(vec.as_ptr())` täyttää aina kaksi viimeistä ehtoa.
    ///
    /// Suurin osa alustoista ei periaatteessa pysty edes rakentamaan niin suurta allokointia.
    /// Esimerkiksi mikään tunnettu 64-bittinen alusta ei voi koskaan palvella 2 <sup>63</sup> tavun pyyntöä sivutaulukkorajoitusten tai osoitetilan jakamisen vuoksi.
    /// Jotkut 32-bittiset ja 16-bittiset käyttöympäristöt voivat kuitenkin onnistuneesti palvella yli `isize::MAX`-tavujen pyyntöä esimerkiksi fyysisen osoitteen laajennuksen avulla.
    /// Suoraan allokaattoreista hankittu muisti tai muistikartoitetut tiedostot * voivat sinänsä olla liian suuria käsittelemään tätä toimintoa.
    /// (Huomaa, että [`offset`]: llä ja [`add`]: llä on myös samanlainen rajoitus, joten niitä ei voida käyttää myöskään niin suurissa allokoinnissa.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Tämä toiminto panics, jos `T` on nollakokoinen tyyppi ("ZST").
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Väärä* käyttö:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Tee ptr2_other: sta "alias" ptr2: stä, mutta johdettu ptr1: stä.
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Koska ptr2_other ja ptr2 ovat peräisin eri objektien osoittimista, niiden siirtymän laskeminen on määrittelemätöntä käyttäytymistä, vaikka ne osoittavatkin samaan osoitteeseen!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Määrittelemätön käyttäytyminen
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // TURVALLISUUS: soittajan on noudatettava `ptr_offset_from`: n turvasopimusta.
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// Palauttaa, taataanko kahden osoittimen yhtäläisyys.
    ///
    /// Ajon aikana tämä toiminto käyttäytyy kuten `self == other`.
    /// Joissakin yhteyksissä (esim. Kokoamisajan arviointi) ei kuitenkaan aina ole mahdollista määrittää kahden osoittimen tasa-arvoa, joten tämä toiminto voi väärin palauttaa `false`: n osoittimille, jotka myöhemmin osoittautuvat samanlaisiksi.
    ///
    /// Mutta kun se palauttaa `true`: n, osoittimet ovat taatusti samat.
    ///
    /// Tämä toiminto on [`guaranteed_ne`]: n peili, mutta ei sen käänteinen.On osoitinvertailuja, joille molemmat toiminnot palauttavat `false`: n.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Palautusarvo voi muuttua kääntäjän versiosta riippuen, ja vaarallinen koodi ei välttämättä ole riippuvainen tämän toiminnon tuloksesta.
    /// On suositeltavaa käyttää tätä toimintoa vain suorituskyvyn optimointiin, jos tämän toiminnon väärät `false`-palautusarvot eivät vaikuta tulokseen, vaan vain suorituskykyyn.
    /// Tämän menetelmän seurauksia ajon ja käännösaikakoodin käyttäytymiselle eri tavoin ei ole tutkittu.
    /// Tätä menetelmää ei pidä käyttää tällaisten erojen aikaansaamiseen, eikä sitä pitäisi myöskään vakauttaa, ennen kuin olemme ymmärtäneet paremmin tämän asian.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self, other)
    }

    /// Palauttaa, taataanko kahden osoittimen eriarvoisuus.
    ///
    /// Ajon aikana tämä toiminto käyttäytyy kuten `self != other`.
    /// Joissakin yhteyksissä (esim. Kokoamisajan arviointi) ei kuitenkaan aina ole mahdollista määrittää kahden osoittimen eriarvoisuutta, joten tämä toiminto saattaa väärin palauttaa `false`: n osoittimille, jotka myöhemmin osoittautuvat epätasaisiksi.
    ///
    /// Mutta kun se palauttaa `true`: n, osoittimet ovat taatusti epätasaiset.
    ///
    /// Tämä toiminto on [`guaranteed_eq`]: n peili, mutta ei sen käänteinen.On osoitinvertailuja, joille molemmat toiminnot palauttavat `false`: n.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Palautusarvo voi muuttua kääntäjän versiosta riippuen, ja vaarallinen koodi ei välttämättä ole riippuvainen tämän toiminnon tuloksesta.
    /// On suositeltavaa käyttää tätä toimintoa vain suorituskyvyn optimointiin, jos tämän toiminnon väärät `false`-palautusarvot eivät vaikuta tulokseen, vaan vain suorituskykyyn.
    /// Tämän menetelmän seurauksia ajon ja käännösaikakoodin käyttäytymiselle eri tavoin ei ole tutkittu.
    /// Tätä menetelmää ei pidä käyttää tällaisten erojen aikaansaamiseen, eikä sitä pitäisi myöskään vakauttaa, ennen kuin olemme ymmärtäneet paremmin tämän asian.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self, other)
    }

    /// Laskee siirtymän osoittimesta (mukavuus `.offset(count as isize)`): lle.
    ///
    /// `count` on T: n yksikköinä;esim. `count` 3 edustaa `3 * size_of::<T>()`-tavujen osoittimen siirtymää.
    ///
    /// # Safety
    ///
    /// Jos jotain seuraavista ehdoista rikotaan, tulos on määrittelemätön käyttäytyminen:
    ///
    /// * Sekä aloitus-että tuloksena olevan osoittimen on oltava joko rajattuina tai yksi tavu saman allokoidun objektin lopun ohi.
    /// Huomaa, että Rust: ssä jokaista (stack-allocated)-muuttujaa pidetään erillisenä allokoituna objektina.
    ///
    /// * Laskettu siirto **tavuina** ei voi ylittää `isize`: ää.
    ///
    /// * Raja-alueiden siirtymä ei voi luottaa "wrapping around"-osoitetilaan.Eli äärettömän tarkan summan on mahtuttava `usize`: ään.
    ///
    /// Kääntäjä ja vakiokirjasto pyrkivät yleensä varmistamaan, että allokaatiot eivät koskaan saavuta kokoa, jossa siirtymä on huolestuttava.
    /// Esimerkiksi `Vec` ja `Box` varmistavat, että ne eivät koskaan jaa enempää kuin `isize::MAX` tavua, joten `vec.as_ptr().add(vec.len())` on aina turvallinen.
    ///
    /// Suurin osa alustoista ei periaatteessa pysty edes rakentamaan tällaista allokointia.
    /// Esimerkiksi mikään tunnettu 64-bittinen alusta ei voi koskaan palvella 2 <sup>63</sup> tavun pyyntöä sivutaulukkorajoitusten tai osoitetilan jakamisen vuoksi.
    /// Jotkut 32-bittiset ja 16-bittiset käyttöympäristöt voivat kuitenkin onnistuneesti palvella yli `isize::MAX`-tavujen pyyntöä esimerkiksi fyysisen osoitteen laajennuksen avulla.
    ///
    /// Suoraan allokaattoreista hankittu muisti tai muistikartoitetut tiedostot * voivat sinänsä olla liian suuria käsittelemään tätä toimintoa.
    ///
    /// Harkitse [`wrapping_add`]: n käyttöä, jos näitä rajoituksia on vaikea täyttää.
    /// Tämän menetelmän ainoa etu on, että se mahdollistaa aggressiivisemmat kääntäjien optimoinnit.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // TURVALLISUUS: soittajan on noudatettava `offset`: n turvasopimusta.
        unsafe { self.offset(count as isize) }
    }

    /// Laskee siirtymän osoittimesta (mukavuus mallille `.offset ((lasketaan isize).wrapping_neg())`): ksi).
    ///
    /// `count` on T: n yksikköinä;esim. `count` 3 edustaa `3 * size_of::<T>()`-tavujen osoittimen siirtymää.
    ///
    /// # Safety
    ///
    /// Jos jotain seuraavista ehdoista rikotaan, tulos on määrittelemätön käyttäytyminen:
    ///
    /// * Sekä aloitus-että tuloksena olevan osoittimen on oltava joko rajattuina tai yksi tavu saman allokoidun objektin lopun ohi.
    /// Huomaa, että Rust: ssä jokaista (stack-allocated)-muuttujaa pidetään erillisenä allokoituna objektina.
    ///
    /// * Laskettu siirtymä ei voi ylittää `isize::MAX`**tavua**.
    ///
    /// * Raja-alueiden siirtymä ei voi luottaa "wrapping around"-osoitetilaan.Toisin sanoen, äärettömän tarkan summan on mahtuttava usiziin.
    ///
    /// Kääntäjä ja vakiokirjasto pyrkivät yleensä varmistamaan, että allokaatiot eivät koskaan saavuta kokoa, jossa siirtymä on huolestuttava.
    /// Esimerkiksi `Vec` ja `Box` varmistavat, että ne eivät koskaan jaa enempää kuin `isize::MAX` tavua, joten `vec.as_ptr().add(vec.len()).sub(vec.len())` on aina turvallinen.
    ///
    /// Suurin osa alustoista ei periaatteessa pysty edes rakentamaan tällaista allokointia.
    /// Esimerkiksi mikään tunnettu 64-bittinen alusta ei voi koskaan palvella 2 <sup>63</sup> tavun pyyntöä sivutaulukkorajoitusten tai osoitetilan jakamisen vuoksi.
    /// Jotkut 32-bittiset ja 16-bittiset käyttöympäristöt voivat kuitenkin onnistuneesti palvella yli `isize::MAX`-tavujen pyyntöä esimerkiksi fyysisen osoitteen laajennuksen avulla.
    ///
    /// Suoraan allokaattoreista hankittu muisti tai muistikartoitetut tiedostot * voivat sinänsä olla liian suuria käsittelemään tätä toimintoa.
    ///
    /// Harkitse [`wrapping_sub`]: n käyttöä, jos näitä rajoituksia on vaikea täyttää.
    /// Tämän menetelmän ainoa etu on, että se mahdollistaa aggressiivisemmat kääntäjien optimoinnit.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // TURVALLISUUS: soittajan on noudatettava `offset`: n turvasopimusta.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Laskee siirtymän osoittimesta rivitysaritmeettisesti.
    /// (mukavuus `.wrapping_offset(count as isize)`): lle
    ///
    /// `count` on T: n yksikköinä;esim. `count` 3 edustaa `3 * size_of::<T>()`-tavujen osoittimen siirtymää.
    ///
    /// # Safety
    ///
    /// Tämä toiminto itsessään on aina turvallista, mutta tuloksena olevan osoittimen käyttö ei ole.
    ///
    /// Tuloksena oleva osoitin pysyy kiinnitettynä samaan allokoituun objektiin, johon `self` osoittaa.
    /// Sitä *ei* voida käyttää toisen varatun objektin käyttämiseen.Huomaa, että Rust: ssä jokaista (stack-allocated)-muuttujaa pidetään erillisenä allokoituna objektina.
    ///
    /// Toisin sanoen, `let z = x.wrapping_add((y as usize) - (x as usize))` ei *tee*`z`: stä samaa kuin `y`, vaikka oletamme, että `T`: llä on koko `1` eikä ylivuotoa ole: `z` on edelleen kiinnitetty objektiin, johon `x` on kiinnitetty, ja sen alijäämä on määrittelemätöntä käyttäytymistä, ellei `x` ja `y`-piste samaan allokoituun objektiin.
    ///
    /// Verrattuna [`add`]: ään tämä menetelmä viivästyttää periaatteessa vaatimusta pysyä samassa allokoidussa objektissa: [`add`] on välitön määrittelemätön käyttäytyminen ylittäessään objektirajoja;`wrapping_add` tuottaa osoittimen, mutta johtaa silti määrittelemättömään käyttäytymiseen, jos osoitin on poissuljettu, kun se on kiinnitetyn objektin rajojen ulkopuolella.
    /// [`add`] voidaan optimoida paremmin ja on siten parempi suorituskykyherkässä koodissa.
    ///
    /// Viivästetty tarkistus ottaa huomioon vain viitatun osoittimen arvon, ei lopputuloksen laskennassa käytettyjä väliarvoja.
    /// Esimerkiksi `x.wrapping_add(o).wrapping_sub(o)` on aina sama kuin `x`.Toisin sanoen, varatun objektin jättäminen ja sitten uudelleen syöttäminen myöhemmin on sallittua.
    ///
    /// Jos sinun on ylitettävä objektirajat, heitä osoitin kokonaislukuun ja suorita aritmeettinen tulos siellä.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// // Toista käyttämällä raakaa osoittinta kahden elementin välein
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Tämä silmukka tulostaa "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Laskee siirtymän osoittimesta rivitysaritmeettisesti.
    /// (mukavuus mallille `.wrapping_offset ((lasketaan isize).wrapping_neg())`): ksi)
    ///
    /// `count` on T: n yksikköinä;esim. `count` 3 edustaa `3 * size_of::<T>()`-tavujen osoittimen siirtymää.
    ///
    /// # Safety
    ///
    /// Tämä toiminto itsessään on aina turvallista, mutta tuloksena olevan osoittimen käyttö ei ole.
    ///
    /// Tuloksena oleva osoitin pysyy kiinnitettynä samaan allokoituun objektiin, johon `self` osoittaa.
    /// Sitä *ei* voida käyttää toisen varatun objektin käyttämiseen.Huomaa, että Rust: ssä jokaista (stack-allocated)-muuttujaa pidetään erillisenä allokoituna objektina.
    ///
    /// Toisin sanoen, `let z = x.wrapping_sub((x as usize) - (y as usize))` ei *tee*`z`: stä samaa kuin `y`, vaikka oletamme, että `T`: llä on koko `1` eikä ylivuotoa ole: `z` on edelleen kiinnitetty objektiin, johon `x` on kiinnitetty, ja sen alijäämä on määrittelemätöntä käyttäytymistä, ellei `x` ja `y`-piste samaan allokoituun objektiin.
    ///
    /// Verrattuna [`sub`]: ään tämä menetelmä viivästyttää periaatteessa vaatimusta pysyä samassa allokoidussa objektissa: [`sub`] on välitön määrittelemätön käyttäytyminen ylittäessään objektirajoja;`wrapping_sub` tuottaa osoittimen, mutta johtaa silti määrittelemättömään käyttäytymiseen, jos osoitin on poissuljettu, kun se on kiinnitetyn objektin rajojen ulkopuolella.
    /// [`sub`] voidaan optimoida paremmin ja on siten parempi suorituskykyherkässä koodissa.
    ///
    /// Viivästetty tarkistus ottaa huomioon vain viitatun osoittimen arvon, ei lopputuloksen laskennassa käytettyjä väliarvoja.
    /// Esimerkiksi `x.wrapping_add(o).wrapping_sub(o)` on aina sama kuin `x`.Toisin sanoen, varatun objektin jättäminen ja sitten uudelleen syöttäminen myöhemmin on sallittua.
    ///
    /// Jos sinun on ylitettävä objektirajat, heitä osoitin kokonaislukuun ja suorita aritmeettinen tulos siellä.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// // Toista käyttämällä raakaa osoittinta kahden elementin välein (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Tämä silmukka tulostaa "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Asettaa osoittimen arvoksi `ptr`.
    ///
    /// Jos `self` on (fat)-osoitin kokoiselle tyypille, tämä toiminto vaikuttaa vain osoittimen osaan, kun taas (thin)-osoittimille, jotka ovat kooltaan kooltaan tyypillisiä, tällä on sama vaikutus kuin yksinkertaisella määrityksellä.
    ///
    /// Tuloksena olevalla osoittimella on `val`: n lähtöpaikka, eli rasvapainikkeelle tämä toiminto on semanttisesti sama kuin uuden rasvapainikkeen luominen datan osoittimen arvolla `val`, mutta `self`: n metatiedoilla.
    ///
    ///
    /// # Examples
    ///
    /// Tämä toiminto on ensisijaisesti hyödyllinen mahdollistettaessa tavuittain osoittimen osoittava aritmeettinen potentiaalisesti rasvaosoittimissa:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &arr[0] as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // tulostaa "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *const u8) -> Self {
        let thin = &mut self as *mut *const T as *mut *const u8;
        // TURVALLISUUS: Ohutosoittimen ollessa kyseessä nämä toiminnot ovat identtiset
        // yksinkertaiseen tehtävään.
        // Rasvan osoittimen tapauksessa nykyisen rasvan osoittimen asettelun toteutuksen yhteydessä tällaisen osoittimen ensimmäinen kenttä on aina datanosoitin, joka samoin osoitetaan.
        //
        unsafe { *thin = val };
        self
    }

    /// Lukee arvon `self`: stä siirtämättä sitä.
    /// Tämä jättää `self`: n muistin muuttumattomaksi.
    ///
    /// Katso [`ptr::read`]: stä turvallisuusongelmia ja esimerkkejä.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // TURVALLISUUS: soittajan on noudatettava `read`: n turvasopimusta.
        unsafe { read(self) }
    }

    /// Suorittaa arvon haihtuvan lukemisen `self`: stä siirtämättä sitä.Tämä jättää `self`: n muistin muuttumattomaksi.
    ///
    /// Haihtuvien operaatioiden on tarkoitus toimia I/O-muistissa, ja kääntäjä ei taata, että niitä valitaan tai järjestetään uudelleen muiden haihtuvien toimintojen yhteydessä.
    ///
    ///
    /// Katso [`ptr::read_volatile`]: stä turvallisuusongelmia ja esimerkkejä.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // TURVALLISUUS: soittajan on noudatettava `read_volatile`: n turvasopimusta.
        unsafe { read_volatile(self) }
    }

    /// Lukee arvon `self`: stä siirtämättä sitä.
    /// Tämä jättää `self`: n muistin muuttumattomaksi.
    ///
    /// Toisin kuin `read`, osoitin voi olla kohdistamaton.
    ///
    /// Katso [`ptr::read_unaligned`]: stä turvallisuusongelmia ja esimerkkejä.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // TURVALLISUUS: soittajan on noudatettava `read_unaligned`: n turvasopimusta.
        unsafe { read_unaligned(self) }
    }

    /// Kopioi `count * size_of<T>`-tavut tiedostosta `self`-`dest`.
    /// Lähde ja kohde voivat olla päällekkäisiä.
    ///
    /// NOTE: tällä on *sama* argumenttijärjestys kuin [`ptr::copy`].
    ///
    /// Katso [`ptr::copy`]: stä turvallisuusongelmia ja esimerkkejä.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // TURVALLISUUS: soittajan on noudatettava `copy`: n turvasopimusta.
        unsafe { copy(self, dest, count) }
    }

    /// Kopioi `count * size_of<T>`-tavut tiedostosta `self`-`dest`.
    /// Lähde ja kohde eivät välttämättä ole päällekkäisiä.
    ///
    /// NOTE: tällä on *sama* argumenttijärjestys kuin [`ptr::copy_nonoverlapping`].
    ///
    /// Katso [`ptr::copy_nonoverlapping`]: stä turvallisuusongelmia ja esimerkkejä.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // TURVALLISUUS: soittajan on noudatettava `copy_nonoverlapping`: n turvasopimusta.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Laskee siirtymän, joka on sovellettava osoittimeen, jotta se kohdistetaan `align`: ään.
    ///
    /// Jos osoitinta ei ole mahdollista kohdistaa, toteutus palauttaa arvon `usize::MAX`.
    /// Toteutus sallii *aina* palauttaa `usize::MAX`: n.
    /// Ainoastaan algoritmin suorituskyky voi riippua siitä, että saat käyttökelpoisen offsetin, ei sen oikeellisuudesta.
    ///
    /// Siirtymä ilmaistaan `T`-elementtien lukumääränä eikä tavuina.Palautettua arvoa voidaan käyttää `wrapping_add`-menetelmällä.
    ///
    /// Ei ole mitään takeita siitä, että osoittimen siirtäminen ei ylitä tai ylitä osoittimen osoittamaa allokaatiota.
    ///
    /// Soittajan on varmistettava, että palautettu siirtymä on oikein kaikilla muilla tavoilla kuin kohdistus.
    ///
    /// # Panics
    ///
    /// Toiminto panics, jos `align` ei ole kahden teho.
    ///
    /// # Examples
    ///
    /// Pääsy viereiseen `u8`: ään `u16`: nä
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // vaikka osoitin voidaan kohdistaa `offset`: n kautta, se osoittaisi varauksen ulkopuolelle
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // TURVALLISUUS: `align` on tarkistettu olevan 2: n teho edellä
        unsafe { align_offset(self, align) }
    }
}

#[lang = "const_slice_ptr"]
impl<T> *const [T] {
    /// Palauttaa raakaleikkeen pituuden.
    ///
    /// Palautettu arvo on **elementtien** määrä, ei tavujen lukumäärä.
    ///
    /// Tämä toiminto on turvallinen, vaikka raakalohkoa ei voida heittää viipaleeksi, koska osoitin on tyhjä tai kohdistamaton.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // TURVALLISUUS: tämä on turvallista, koska `*const [T]`: llä ja `FatPtr<T>`: llä on sama asettelu.
            // Vain `std` voi antaa tämän takuun.
            unsafe { Repr { rust: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Palauttaa raakan osoittimen leikkeen puskuriin.
    ///
    /// Tämä vastaa `self`: n valamista `*const T`: ään, mutta enemmän tyyppiturvallista.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), 0 as *const i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// Palauttaa raakan osoittimen elementille tai alalohkolle tekemättä rajojen tarkistusta.
    ///
    /// Tämän menetelmän kutsuminen ulkopuolisen indeksin kanssa tai kun `self` ei ole poissuljettavissa, on *[määrittelemätön käyttäytyminen]*, vaikka tuloksena olevaa osoitinta ei käytetä.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: SliceIndex<[T]>,
    {
        // TURVALLISUUS: soittaja varmistaa, että `self` on aliedustettava ja `index` on rajojen ulkopuolella.
        unsafe { index.get_unchecked(self) }
    }

    /// Palauttaa arvon `None`, jos osoitin on nolla, tai palauttaa jaetun viipaleen arvoon, joka on kääritty `Some`: ään.
    /// Toisin kuin [`as_ref`], tämä ei edellytä arvon alustamista.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Kun kutsut tätä menetelmää, sinun on varmistettava, että *joko* osoitin on NULL *tai* kaikki seuraavat ovat totta:
    ///
    /// * Osoittimen on oltava [valid], kun luetaan useita tavuja `ptr.len() * mem::size_of::<T>()`, ja sen on oltava kohdistettu oikein.Tämä tarkoittaa erityisesti:
    ///
    ///     * Tämän leikkeen koko muistialue on sisällytettävä yhteen varattuun objektiin!
    ///       Viipaleet eivät voi koskaan ulottua useiden allokoitujen objektien yli.
    ///
    ///     * Osoitin on kohdistettava myös nollapituisten viipaleiden kohdalla.
    ///     Yksi syy tähän on, että enum-asettelun optimoinnit voivat luottaa siihen, että viitteet (mukaan lukien minkä tahansa pituiset viipaleet) on kohdistettu ja ei-nolla erottaakseen ne muista tiedoista.
    ///
    ///     Voit hankkia osoittimen, jota voidaan käyttää `data`: nä nollapituisille viipaleille käyttämällä [`NonNull::dangling()`]: ää.
    ///
    /// * Viipaleen koko `ptr.len() * mem::size_of::<T>()` ei saa olla suurempi kuin `isize::MAX`.
    ///   Katso [`pointer::offset`]: n turvallisuusohjeet.
    ///
    /// * Sinun on pantava täytäntöön Rust: n aliaksisäännöt, koska palautettu elinikä `'a` valitaan mielivaltaisesti eikä välttämättä kuvasta tietojen todellista käyttöikää.
    ///   Erityisesti tämän käyttöiän ajan muisti, johon osoitin osoittaa, ei saa mutatoitua (paitsi `UnsafeCell`: n sisällä).
    ///
    /// Tämä pätee, vaikka tämän menetelmän tulosta ei käytettäisikään!
    ///
    /// Katso myös [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // TURVALLISUUS: soittajan on noudatettava `as_uninit_slice`: n turvasopimusta.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// Tasa-arvo viitteille
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// Osoitteiden vertailu
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}