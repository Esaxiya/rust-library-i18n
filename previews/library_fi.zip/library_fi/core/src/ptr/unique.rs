use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Kääre raakan ei-nolla-`*mut T`: n ympärille, joka osoittaa, että tämän kääreen haltija omistaa referenssin.
/// Hyödyllinen rakennusten abstraktioille, kuten `Box<T>`, `Vec<T>`, `String` ja `HashMap<K, V>`.
///
/// Toisin kuin `*mut T`, `Unique<T>` käyttäytyy "as if", se oli `T`: n ilmentymä.
/// Se toteuttaa `Send`/`Sync`: n, jos `T` on `Send`/`Sync`.
/// Se tarkoittaa myös sellaista vahvaa aliaksen takuuta, jonka `T`-ilmentymä voi odottaa:
/// osoittimen referenttiä ei pitäisi muokata ilman yksilöllistä polkua sen omistavalle Unique.
///
/// Jos et ole varma siitä, onko oikein käyttää `Unique`: ää tarkoituksiin, harkitse `NonNull`: n käyttöä, jolla on heikompi semantiikka.
///
///
/// Toisin kuin `*mut T`, osoittimen on aina oltava nolla, vaikka osoitinta ei koskaan päätettäisi.
/// Tämän tarkoituksena on, että enumit voivat käyttää tätä kiellettyä arvoa erottelijana-`Option<Unique<T>>` on kooltaan `Unique<T>`.
/// Osoitin voi kuitenkin roikkua, ellei sitä ole viitattu.
///
/// Toisin kuin `*mut T`, `Unique<T>` on kovariaatti `T`: n kanssa.
/// Tämän pitäisi olla aina oikein kaikentyyppisille, jotka noudattavat Uniquen aliaksivaatimuksia.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: tällä merkinnällä ei ole vaikutuksia varianssiin, mutta se on välttämätön
    // jotta dropck ymmärtäisi, että omistamme loogisesti `T`: n.
    //
    // Katso lisätietoja:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` osoittimet ovat `Send`, jos `T` on `Send`, koska niihin viittaamat tiedot ovat aliaseettomia.
/// Huomaa, että tyyppijärjestelmä ei pakota tätä aliaksen muuttujaa;`Unique`: ää käyttävän abstraktion on pakotettava se täytäntöön.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` osoittimet ovat `Sync`, jos `T` on `Sync`, koska niihin viittaamat tiedot ovat aliaseettomia.
/// Huomaa, että tyyppijärjestelmä ei pakota tätä aliaksen muuttujaa;`Unique`: ää käyttävän abstraktion on pakotettava se täytäntöön.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Luo uuden `Unique`: n, joka on roikkuva, mutta hyvin kohdistettu.
    ///
    /// Tämä on hyödyllistä alustettaessa tyyppejä, jotka varauksetta allokoidaan, kuten `Vec::new` tekee.
    ///
    /// Huomaa, että osoittimen arvo voi mahdollisesti edustaa kelvollista osoitinta `T`: lle, mikä tarkoittaa, että tätä ei saa käyttää "not yet initialized": n sentinel-arvona.
    /// Laiskan varaavien tyyppien on seurattava alustusta muilla tavoilla.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // TURVALLISUUS: mem::align_of() palauttaa kelvollisen osoittimen, joka ei ole nolla.
        // new_unchecked(): n soittamista koskevia ehtoja noudatetaan.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Luo uuden `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` ei saa olla nolla.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // TURVALLISUUS: soittajan on taattava, että `ptr` ei ole nolla.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Luo uuden `Unique`: n, jos `ptr` ei ole nolla.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // TURVALLISUUS: Osoitin on jo tarkistettu eikä se ole tyhjä.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Hankkii taustalla olevan `*mut`-osoittimen.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Poikkeaa sisällöstä.
    ///
    /// Tuloksena oleva elinikä on sidottu itseensä, joten tämä käyttäytyy "as if", se oli itse asiassa T-tapausta, jota lainataan.
    /// Jos tarvitaan pidempi (unbound)-käyttöikä, käytä `&*my_ptr.as_ptr()`-laitetta.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // TURVALLISUUS: soittajan on taattava, että `self` täyttää kaikki vaatimukset
        // vaatimukset viitteelle.
        unsafe { &*self.as_ptr() }
    }

    /// Poikkeaa sisällön sisällöstä.
    ///
    /// Tuloksena oleva elinikä on sidottu itseensä, joten tämä käyttäytyy "as if", se oli itse asiassa T-tapausta, jota lainataan.
    /// Jos tarvitaan pidempi (unbound)-käyttöikä, käytä `&mut *my_ptr.as_ptr()`-laitetta.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // TURVALLISUUS: soittajan on taattava, että `self` täyttää kaikki vaatimukset
        // vaatimukset muuttuvalle viitteelle.
        unsafe { &mut *self.as_ptr() }
    }

    /// Heittää toisen tyyppiseen osoittimeen.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // TURVALLISUUS: Unique::new_unchecked() luo uuden ainutlaatuisuuden ja tarpeet
        // annettu osoitin ei ole tyhjä.
        // Koska ohitamme itsemme osoittimena, se ei voi olla tyhjä.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // TURVALLISUUS: Muokattava viite ei voi olla tyhjä
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}