use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` mutta ei nolla ja kovarianssi.
///
/// Tämä on usein oikea asia, kun rakennetaan tietorakenteita käyttämällä raakaviitteitä, mutta on viime kädessä vaarallisempi käyttää sen lisäominaisuuksien vuoksi.Jos et ole varma, pitäisikö sinun käyttää `NonNull<T>`: ää, käytä vain `*mut T`: ää!
///
/// Toisin kuin `*mut T`, osoittimen on aina oltava nolla, vaikka osoitinta ei koskaan päätettäisi.Tämän tarkoituksena on, että enumit voivat käyttää tätä kiellettyä arvoa erottelijana-`Option<NonNull<T>>` on kooltaan `* mut T`.
/// Osoitin voi kuitenkin roikkua, ellei sitä ole viitattu.
///
/// Toisin kuin `*mut T`, `NonNull<T>` valittiin kovarianssiksi `T`: n yli.Tämä mahdollistaa `NonNull<T>`: n käytön kovariaattityyppien rakentamisessa, mutta tuo epävakauden riskin, jos sitä käytetään tyypissä, joka ei todellisuudessa saa olla kovariaantti.
/// (`*mut T`: lle tehtiin päinvastainen valinta, vaikka teknisesti häiriöt voivat johtua vain vaarallisten toimintojen kutsumisesta.)
///
/// Kovarianssi on oikea useimmille turvallisille abstraktioille, kuten `Box`, `Rc`, `Arc`, `Vec` ja `LinkedList`.Näin on, koska ne tarjoavat julkisen sovellusliittymän, joka noudattaa Rust: n tavallisia jaettuja XOR-muutettavissa olevia sääntöjä.
///
/// Jos tyyppiäsi ei voi turvallisesti olla vaihteleva, sinun on varmistettava, että siinä on muutama kenttä, joka antaa muuttumattomuuden.Usein tämä kenttä on [`PhantomData`]-tyyppinen, kuten `PhantomData<Cell<T>>` tai `PhantomData<&'a mut T>`.
///
/// Huomaa, että `NonNull<T>`: llä on `From`-ilmentymä `&T`: lle.Tämä ei kuitenkaan muuta sitä tosiasiaa, että mutaatio (osoitin, joka on johdettu a) jaetusta viitteestä, on määrittelemätöntä käyttäytymistä, ellei mutaatio tapahdu [`UnsafeCell<T>`]: n sisällä.Sama koskee muutettavan viitteen luomista jaetusta viitteestä.
///
/// Kun käytät tätä `From`-ilmentymää ilman `UnsafeCell<T>`-laitetta, sinun on varmistettava, että `as_mut`: ää ei koskaan kutsuta eikä `as_ptr`: ää koskaan käytetä mutaatioon.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` osoittimet eivät ole `Send`, koska ne, joihin ne viittaavat, voivat olla aliaksia.
// Huom. Tämä implisi on tarpeeton, mutta sen pitäisi tarjota parempia virheilmoituksia.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` osoittimet eivät ole `Sync`, koska ne, joihin ne viittaavat, voivat olla aliaksia.
// Huom. Tämä implisi on tarpeeton, mutta sen pitäisi tarjota parempia virheilmoituksia.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Luo uuden `NonNull`: n, joka on roikkuva, mutta hyvin kohdistettu.
    ///
    /// Tämä on hyödyllistä alustettaessa tyyppejä, jotka varauksetta allokoidaan, kuten `Vec::new` tekee.
    ///
    /// Huomaa, että osoittimen arvo voi mahdollisesti edustaa kelvollista osoitinta `T`: lle, mikä tarkoittaa, että tätä ei saa käyttää "not yet initialized": n sentinel-arvona.
    /// Laiskan varaavien tyyppien on seurattava alustusta muilla tavoilla.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // TURVALLISUUS: mem::align_of() palauttaa nollasta poikkeavan käytön, joka sitten heitetään
        // * muttiin T.
        // Siksi `ptr` ei ole nolla ja new_unchecked(): n kutsumisen ehtoja noudatetaan.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Palauttaa jaetut viitteet arvoon.Toisin kuin [`as_ref`], tämä ei edellytä arvon alustamista.
    ///
    /// Katso muutettava vastine kohdasta [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Kun kutsut tätä menetelmää, sinun on varmistettava, että kaikki seuraavat ovat totta:
    ///
    /// * Osoittimen on oltava kohdistettu oikein.
    ///
    /// * Sen on oltava "dereferencable" siinä merkityksessä kuin [the module documentation].
    ///
    /// * Sinun on pantava täytäntöön Rust: n aliaksisäännöt, koska palautettu elinikä `'a` valitaan mielivaltaisesti eikä välttämättä kuvasta tietojen todellista käyttöikää.
    ///
    ///   Erityisesti tämän käyttöiän ajan muisti, johon osoitin osoittaa, ei saa mutatoitua (paitsi `UnsafeCell`: n sisällä).
    ///
    /// Tämä pätee, vaikka tämän menetelmän tulosta ei käytettäisikään!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // TURVALLISUUS: soittajan on taattava, että `self` täyttää kaikki vaatimukset
        // vaatimukset viitteelle.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Palauttaa yksilölliset viittaukset arvoon.Toisin kuin [`as_mut`], tämä ei edellytä arvon alustamista.
    ///
    /// Katso jaettu vastine kohdasta [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Kun kutsut tätä menetelmää, sinun on varmistettava, että kaikki seuraavat ovat totta:
    ///
    /// * Osoittimen on oltava kohdistettu oikein.
    ///
    /// * Sen on oltava "dereferencable" siinä merkityksessä kuin [the module documentation].
    ///
    /// * Sinun on pantava täytäntöön Rust: n aliaksisäännöt, koska palautettu elinikä `'a` valitaan mielivaltaisesti eikä välttämättä kuvasta tietojen todellista käyttöikää.
    ///
    ///   Erityisesti tämän käyttöiän ajan muistia, johon osoitin osoittaa, ei saa käyttää (lukea tai kirjoittaa) minkään muun osoittimen kautta.
    ///
    /// Tämä pätee, vaikka tämän menetelmän tulosta ei käytettäisikään!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // TURVALLISUUS: soittajan on taattava, että `self` täyttää kaikki vaatimukset
        // vaatimukset viitteelle.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Luo uuden `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` ei saa olla nolla.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // TURVALLISUUS: soittajan on taattava, että `ptr` ei ole nolla.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Luo uuden `NonNull`: n, jos `ptr` ei ole nolla.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // TURVALLISUUS: Osoitin on jo tarkistettu eikä se ole tyhjä
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Suorittaa samat toiminnot kuin [`std::ptr::from_raw_parts`], paitsi että palautetaan `NonNull`-osoitin, toisin kuin raaka `*const`-osoitin.
    ///
    ///
    /// Katso lisätietoja [`std::ptr::from_raw_parts`]: n dokumentaatiosta.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // TURVALLISUUS: `ptr::from::raw_parts_mut`: n tulos ei ole nolla, koska `data_address` on.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Hajota (mahdollisesti leveä) osoitin osoite-ja metatietokomponenteiksi.
    ///
    /// Osoitin voidaan myöhemmin rekonstruoida [`NonNull::from_raw_parts`]: llä.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Hankkii taustalla olevan `*mut`-osoittimen.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Palauttaa jaetun viitteen arvoon.Jos arvo voi olla alustamaton, sen sijaan on käytettävä [`as_uninit_ref`].
    ///
    /// Katso muutettava vastine kohdasta [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Kun kutsut tätä menetelmää, sinun on varmistettava, että kaikki seuraavat ovat totta:
    ///
    /// * Osoittimen on oltava kohdistettu oikein.
    ///
    /// * Sen on oltava "dereferencable" siinä merkityksessä kuin [the module documentation].
    ///
    /// * Osoittimen on osoitettava alustettu `T`-ilmentymä.
    ///
    /// * Sinun on pantava täytäntöön Rust: n aliaksisäännöt, koska palautettu elinikä `'a` valitaan mielivaltaisesti eikä välttämättä kuvasta tietojen todellista käyttöikää.
    ///
    ///   Erityisesti tämän käyttöiän ajan muisti, johon osoitin osoittaa, ei saa mutatoitua (paitsi `UnsafeCell`: n sisällä).
    ///
    /// Tämä pätee, vaikka tämän menetelmän tulosta ei käytettäisikään!
    /// (Alustamista koskevaa osaa ei ole vielä täysin päätetty, mutta ennen kuin se on, ainoa turvallinen lähestymistapa on varmistaa, että ne todella alustetaan.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // TURVALLISUUS: soittajan on taattava, että `self` täyttää kaikki vaatimukset
        // vaatimukset viitteelle.
        unsafe { &*self.as_ptr() }
    }

    /// Palauttaa yksilöllisen viittauksen arvoon.Jos arvo voi olla alustamaton, sen sijaan on käytettävä [`as_uninit_mut`].
    ///
    /// Katso jaettu vastine kohdasta [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Kun kutsut tätä menetelmää, sinun on varmistettava, että kaikki seuraavat ovat totta:
    ///
    /// * Osoittimen on oltava kohdistettu oikein.
    ///
    /// * Sen on oltava "dereferencable" siinä merkityksessä kuin [the module documentation].
    ///
    /// * Osoittimen on osoitettava alustettu `T`-ilmentymä.
    ///
    /// * Sinun on pantava täytäntöön Rust: n aliaksisäännöt, koska palautettu elinikä `'a` valitaan mielivaltaisesti eikä välttämättä kuvasta tietojen todellista käyttöikää.
    ///
    ///   Erityisesti tämän käyttöiän ajan muistia, johon osoitin osoittaa, ei saa käyttää (lukea tai kirjoittaa) minkään muun osoittimen kautta.
    ///
    /// Tämä pätee, vaikka tämän menetelmän tulosta ei käytettäisikään!
    /// (Alustamista koskevaa osaa ei ole vielä täysin päätetty, mutta ennen kuin se on, ainoa turvallinen lähestymistapa on varmistaa, että ne todella alustetaan.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // TURVALLISUUS: soittajan on taattava, että `self` täyttää kaikki vaatimukset
        // vaatimukset muuttuvalle viitteelle.
        unsafe { &mut *self.as_ptr() }
    }

    /// Heittää toisen tyyppiseen osoittimeen.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // TURVALLISUUS: `self` on `NonNull`-osoitin, joka ei välttämättä ole nolla
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Luo ei-nolla raakaviipale ohuesta osoittimesta ja pituudesta.
    ///
    /// `len`-argumentti on **elementtien** määrä, ei tavujen lukumäärä.
    ///
    /// Tämä toiminto on turvallinen, mutta palautusarvon poikkeaminen on vaarallista.
    /// Katso viipaleiden turvallisuusvaatimukset [`slice::from_raw_parts`]: n dokumentaatiosta.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // luo viipaleosoitin, kun aloitat osoittimella ensimmäiseen elementtiin
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Huomaa, että tämä esimerkki osoittaa keinotekoisesti tämän menetelmän käytön, mutta `anna slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // TURVALLISUUS: `data` on `NonNull`-osoitin, joka ei välttämättä ole nolla
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Palauttaa ei-nolla-raakalohkon pituuden.
    ///
    /// Palautettu arvo on **elementtien** määrä, ei tavujen lukumäärä.
    ///
    /// Tämä toiminto on turvallinen, vaikka ei-nollaa raakalohkoa ei voida viitata viipaleeseen, koska osoittimella ei ole kelvollista osoitetta.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Palauttaa ei-nollan osoittimen leikkeen puskuriin.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // TURVALLISUUS: Tiedämme, että `self` ei ole nolla.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Palauttaa raakan osoittimen leikkeen puskuriin.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Palauttaa jaetun viitteen osaan mahdollisesti alustamattomia arvoja.Toisin kuin [`as_ref`], tämä ei edellytä arvon alustamista.
    ///
    /// Katso muutettava vastine kohdasta [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Kun kutsut tätä menetelmää, sinun on varmistettava, että kaikki seuraavat ovat totta:
    ///
    /// * Osoittimen on oltava [valid], kun luetaan useita tavuja `ptr.len() * mem::size_of::<T>()`, ja sen on oltava kohdistettu oikein.Tämä tarkoittaa erityisesti:
    ///
    ///     * Tämän leikkeen koko muistialue on sisällytettävä yhteen varattuun objektiin!
    ///       Viipaleet eivät voi koskaan ulottua useiden allokoitujen objektien yli.
    ///
    ///     * Osoitin on kohdistettava myös nollapituisten viipaleiden kohdalla.
    ///     Yksi syy tähän on, että enum-asettelun optimoinnit voivat luottaa siihen, että viitteet (mukaan lukien minkä tahansa pituiset viipaleet) on kohdistettu ja ei-nolla erottaakseen ne muista tiedoista.
    ///
    ///     Voit hankkia osoittimen, jota voidaan käyttää `data`: nä nollapituisille viipaleille käyttämällä [`NonNull::dangling()`]: ää.
    ///
    /// * Viipaleen koko `ptr.len() * mem::size_of::<T>()` ei saa olla suurempi kuin `isize::MAX`.
    ///   Katso [`pointer::offset`]: n turvallisuusohjeet.
    ///
    /// * Sinun on pantava täytäntöön Rust: n aliaksisäännöt, koska palautettu elinikä `'a` valitaan mielivaltaisesti eikä välttämättä kuvasta tietojen todellista käyttöikää.
    ///   Erityisesti tämän käyttöiän ajan muisti, johon osoitin osoittaa, ei saa mutatoitua (paitsi `UnsafeCell`: n sisällä).
    ///
    /// Tämä pätee, vaikka tämän menetelmän tulosta ei käytettäisikään!
    ///
    /// Katso myös [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // TURVALLISUUS: soittajan on noudatettava `as_uninit_slice`: n turvasopimusta.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Palauttaa yksilöllisen viitteen osaan mahdollisesti alustamattomia arvoja.Toisin kuin [`as_mut`], tämä ei edellytä arvon alustamista.
    ///
    /// Katso jaettu vastine kohdasta [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Kun kutsut tätä menetelmää, sinun on varmistettava, että kaikki seuraavat ovat totta:
    ///
    /// * Osoittimen on oltava [valid] lukuisten ja tavuisten `ptr.len() * mem::size_of::<T>()`-lukujen kohdalla, ja sen on oltava kohdistettu oikein.Tämä tarkoittaa erityisesti:
    ///
    ///     * Tämän leikkeen koko muistialue on sisällytettävä yhteen varattuun objektiin!
    ///       Viipaleet eivät voi koskaan ulottua useiden allokoitujen objektien yli.
    ///
    ///     * Osoitin on kohdistettava myös nollapituisten viipaleiden kohdalla.
    ///     Yksi syy tähän on, että enum-asettelun optimoinnit voivat luottaa siihen, että viitteet (mukaan lukien minkä tahansa pituiset viipaleet) on kohdistettu ja ei-nolla erottaakseen ne muista tiedoista.
    ///
    ///     Voit hankkia osoittimen, jota voidaan käyttää `data`: nä nollapituisille viipaleille käyttämällä [`NonNull::dangling()`]: ää.
    ///
    /// * Viipaleen koko `ptr.len() * mem::size_of::<T>()` ei saa olla suurempi kuin `isize::MAX`.
    ///   Katso [`pointer::offset`]: n turvallisuusohjeet.
    ///
    /// * Sinun on pantava täytäntöön Rust: n aliaksisäännöt, koska palautettu elinikä `'a` valitaan mielivaltaisesti eikä välttämättä kuvasta tietojen todellista käyttöikää.
    ///   Erityisesti tämän käyttöiän ajan muistia, johon osoitin osoittaa, ei saa käyttää (lukea tai kirjoittaa) minkään muun osoittimen kautta.
    ///
    /// Tämä pätee, vaikka tämän menetelmän tulosta ei käytettäisikään!
    ///
    /// Katso myös [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Tämä on turvallista, koska `memory` on kelvollinen lukemiseen ja kirjoittamiseen `memory.len()`: lle monta tavua.
    /// // Huomaa, että `memory.as_mut()`: ään soittaminen ei ole sallittua, koska sisältöä ei voida alustaa.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // TURVALLISUUS: soittajan on noudatettava `as_uninit_slice_mut`: n turvasopimusta.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Palauttaa raakan osoittimen elementille tai alalohkolle tekemättä rajojen tarkistusta.
    ///
    /// Tämän menetelmän kutsuminen ulkopuolisen indeksin kanssa tai kun `self` ei ole poissuljettavissa, on *[määrittelemätön käyttäytyminen]*, vaikka tuloksena olevaa osoitinta ei käytetä.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // TURVALLISUUS: soittaja varmistaa, että `self` on aliedustettava ja `index` on rajojen ulkopuolella.
        // Tämän seurauksena tuloksena oleva osoitin ei voi olla NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // TURVALLISUUS: Ainutlaatuinen osoitin ei voi olla tyhjä, joten ehdot
        // new_unchecked() kunnioitetaan.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // TURVALLISUUS: Muokattava viite ei voi olla tyhjä.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // TURVALLISUUS: Viite ei voi olla tyhjä, joten ehdot
        // new_unchecked() kunnioitetaan.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}