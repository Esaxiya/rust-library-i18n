//! impl. merkki {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Korkein voimassa oleva koodipiste, jonka `char` voi olla.
    ///
    /// `char` on [Unicode Scalar Value], mikä tarkoittaa, että se on [Code Point], mutta vain tietyllä alueella.
    /// `MAX` on korkein kelvollinen koodipiste, joka on kelvollinen [Unicode Scalar Value].
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` (): ää käytetään Unicode-muodossa edustamaan dekoodausvirhettä.
    ///
    /// Se voi tapahtua esimerkiksi antamalla huonosti muotoiltuja UTF-8-tavuja [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy): lle.
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// [Unicode](http://www.unicode.org/)-versio, johon `char`-ja `str`-menetelmien Unicode-osat perustuvat.
    ///
    /// Uusia versioita Unicodesta julkaistaan säännöllisesti, minkä jälkeen kaikki standardikirjastossa olevat menetelmät päivitetään Unicodesta riippuen.
    /// Siksi joidenkin `char`-ja `str`-menetelmien käyttäytyminen ja tämän vakion arvo muuttuvat ajan myötä.
    /// Tätä *ei* pidetä murtavana muutoksena.
    ///
    /// Versioiden numerointijärjestelmä on selitetty [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4): ssä.
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Luo iteraattorin UTF-16-koodattujen koodipisteiden päälle `iter`: ssä, palauttamalla parittomat korvikkeet `` Err''inä.
    ///
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Häviöllinen dekooderi voidaan saada korvaamalla `Err`-tulokset korvaavalla merkillä:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Muuntaa `u32`: n `char`: ksi.
    ///
    /// Huomaa, että kaikki merkit ovat kelvollisia [`u32`] ja ne voidaan heittää yhdeksi
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Päinvastoin ei kuitenkaan pidä paikkaansa: kaikki kelvolliset [`u32`]-merkit eivät ole kelvollisia merkkejä.
    /// `from_u32()` palauttaa arvon `None`, jos tulo ei ole kelvollinen arvo `char`: lle.
    ///
    /// Lisätietoja tämän toiminnon vaarallisesta versiosta, joka ohittaa nämä tarkastukset, on kohdassa [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Palautetaan `None`, kun tulo ei ole kelvollinen `char`:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Muuntaa `u32`: n `char`: ksi, huomioimatta pätevyyttä.
    ///
    /// Huomaa, että kaikki merkit ovat kelvollisia [`u32`] ja ne voidaan heittää yhdeksi
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Päinvastoin ei kuitenkaan pidä paikkaansa: kaikki kelvolliset [`u32`]-merkit eivät ole kelvollisia merkkejä.
    /// `from_u32_unchecked()` jättää tämän huomiotta ja heittää sokeasti `char`: ään luoden mahdollisesti virheellisen.
    ///
    ///
    /// # Safety
    ///
    /// Tämä toiminto on vaarallinen, koska se voi muodostaa virheellisiä `char`-arvoja.
    ///
    /// Katso tämän toiminnon turvallinen versio [`from_u32`]-toiminnosta.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // TURVALLISUUS: soittajan on noudatettava turvasopimusta.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Muuntaa annetun radiksin luvun `char`: ksi.
    ///
    /// 'radix': ää kutsutaan tässä joskus myös 'base': ksi.
    /// Kahden radikaali osoittaa binääriluvun, kymmenen desimaalin tarkkuuden ja kuusitoista heksadesimaalin radiksin, jotta saadaan joitakin yhteisiä arvoja.
    ///
    /// Mielivaltaiset säteet tuetaan.
    ///
    /// `from_digit()` palauttaa `None`, jos tulo ei ole annettu radiksin numero.
    ///
    /// # Panics
    ///
    /// Panics, jos säde on suurempi kuin 36.
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Desimaali 11 on yksinumeroinen perusta 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Palautetaan `None`, kun tulo ei ole numero:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Suuren radiksin ohittaminen aiheuttaen panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Tarkistaa, onko `char` annettu radiksin numero.
    ///
    /// 'radix': ää kutsutaan tässä joskus myös 'base': ksi.
    /// Kahden radikaali osoittaa binääriluvun, kymmenen desimaalin tarkkuuden ja kuusitoista heksadesimaalin radiksin, jotta saadaan joitakin yhteisiä arvoja.
    ///
    /// Mielivaltaiset säteet tuetaan.
    ///
    /// Verrattuna [`is_numeric()`]: ään tämä toiminto tunnistaa vain merkit `0-9`, `a-z` ja `A-Z`.
    ///
    /// 'Digit' on määritelty olevan vain seuraavat merkit:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Katso [`is_numeric()`]: n kattavampi käsitys 'digit': stä.
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics, jos säde on suurempi kuin 36.
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Suuren radiksin ohittaminen aiheuttaen panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Muuntaa `char`: n numeroksi annetussa radiksissa.
    ///
    /// 'radix': ää kutsutaan tässä joskus myös 'base': ksi.
    /// Kahden radikaali osoittaa binääriluvun, kymmenen desimaalin tarkkuuden ja kuusitoista heksadesimaalin radiksin, jotta saadaan joitakin yhteisiä arvoja.
    ///
    /// Mielivaltaiset säteet tuetaan.
    ///
    /// 'Digit' on määritelty olevan vain seuraavat merkit:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Palauttaa arvon `None`, jos `char` ei viittaa annettuun radiksiin.
    ///
    /// # Panics
    ///
    /// Panics, jos säde on suurempi kuin 36.
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Ei-numeron välittäminen johtaa epäonnistumiseen:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Suuren radiksin ohittaminen aiheuttaen panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // koodi jaetaan tähän parantamaan suoritusnopeutta tapauksissa, joissa `radix` on vakio ja 10 tai pienempi
        //
        let val = if likely(radix <= 10) {
            // Jos se ei ole numero, luodaan radiksia suurempi luku.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Palauttaa iteraattorin, joka tuottaa merkin heksadesimaalisen Unicode-pakeneen `` char''ina.
    ///
    /// Tämä pakenee merkit `\u{NNNNNN}`-muodon Rust-syntaksilla, jossa `NNNNNN` on heksadesimaalinen esitys.
    ///
    ///
    /// # Examples
    ///
    /// Iteraattorina:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!`: n käyttö suoraan:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Molemmat vastaavat:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// `to_string`: n käyttö:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // tai-1 varmistaa, että arvolle c==0 koodi laskee, että yksi numero on tulostettava, ja (mikä on sama) välttää (31, 32) alivirran
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // merkittävimmän heksadesimaalin indeksi
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// `escape_debug`: n laajennettu versio, joka sallii pakenemisen laajennetuista Grapheme-koodipisteistä.
    /// Tämä antaa meille mahdollisuuden muotoilla merkkejä, kuten ei-välimerkkejä, paremmin, kun ne ovat merkkijonon alussa.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Palauttaa iteraattorin, joka antaa merkin kirjaimellisen pakokoodin `` char''ina.
    ///
    /// Tämä välttää merkit, jotka muistuttavat `str`: n tai `char`: n `Debug`-toteutuksia.
    ///
    ///
    /// # Examples
    ///
    /// Iteraattorina:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!`: n käyttö suoraan:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Molemmat vastaavat:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// `to_string`: n käyttö:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Palauttaa iteraattorin, joka antaa merkin kirjaimellisen pakokoodin `` char''ina.
    ///
    /// Oletusarvo valitaan ennakkoluulottomasti sellaisten literaalien tuottamiseksi, jotka ovat laillisia useilla kielillä, mukaan lukien C++ 11 ja vastaavat C-perhekielet.
    /// Tarkat säännöt ovat:
    ///
    /// * Välilehti pakenee nimellä `\t`.
    /// * Vaunun paluupyynnössä on `\r`.
    /// * Linjasyöttö vältetään nimellä `\n`.
    /// * Yksittäinen tarjous on vältetty nimellä `\'`.
    /// * Kaksinkertainen lainaus on vältetty nimellä `\"`.
    /// * Takasuuntainen viiva on vältetty nimellä `\\`.
    /// * Tulostettavan ASCII-alueen `0x20` .. `0x7e` (mukaan lukien) merkkejä ei poisteta.
    /// * Kaikille muille merkeille annetaan heksadesimaaliset Unicode-pakot;katso [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Iteraattorina:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!`: n käyttö suoraan:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Molemmat vastaavat:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// `to_string`: n käyttö:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Palauttaa tavujen määrän, jonka tämä `char` tarvitsee, jos se koodataan UTF-8: ssä.
    ///
    /// Tämä tavujen määrä on aina välillä 1 ja 4, mukaan lukien.
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// `&str`-tyyppi takaa, että sen sisältö on UTF-8, joten voimme verrata pituutta, joka kestäisi, jos jokainen koodipiste olisi esitetty `char` vs. itse `&str`: ssä:
    ///
    ///
    /// ```
    /// // merkkeinä
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // molemmat voidaan esittää kolmella tavulla
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // &str: nä nämä kaksi on koodattu UTF-8: ään
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // voimme nähdä, että ne vievät yhteensä 6 tavua ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... aivan kuten &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Palauttaa määrän 16-bittisiä koodiyksiköitä, joita `char` tarvitsee, jos ne koodataan UTF-16: ssä.
    ///
    ///
    /// Katso [`len_utf8()`]: n dokumentaatiosta lisätietoja tästä käsitteestä.
    /// Tämä toiminto on peili, mutta UTF-16: lle UTF-8: n sijaan.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Koodaa tämän merkin UTF-8: ksi toimitettuun tavupuskuriin ja palauttaa sitten koodatun merkin sisältävän puskurin alalohkon.
    ///
    ///
    /// # Panics
    ///
    /// Panics, jos puskuri ei ole tarpeeksi suuri.
    /// Neljän pituinen puskuri on riittävän suuri koodaamaan mitä tahansa `char`: ää.
    ///
    /// # Examples
    ///
    /// Molemmissa näissä esimerkeissä 'ß' koodaa kaksi tavua.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Liian pieni puskuri:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // TURVALLISUUS: `char` ei ole korvike, joten tämä on kelvollinen UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Koodaa tämän merkin UTF-16: ksi toimitettuun `u16`-puskuriin ja palauttaa sitten koodatun merkin sisältävän puskurin alalohkon.
    ///
    ///
    /// # Panics
    ///
    /// Panics, jos puskuri ei ole tarpeeksi suuri.
    /// Puskuri, jonka pituus on 2, on riittävän suuri koodaamaan mitä tahansa `char`: ää.
    ///
    /// # Examples
    ///
    /// Molemmissa näissä esimerkeissä '𝕊' koodaa kaksi u16: ta.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Liian pieni puskuri:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Palauttaa arvon `true`, jos tällä `char`: llä on `Alphabetic`-ominaisuus.
    ///
    /// `Alphabetic` on kuvattu [Unicode Standard]: n luvussa 4 (Character Properties) ja määritelty [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]: ssä.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // rakkaus on monia asioita, mutta se ei ole aakkosellinen
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Palauttaa arvon `true`, jos tällä `char`: llä on `Lowercase`-ominaisuus.
    ///
    /// `Lowercase` on kuvattu [Unicode Standard]: n luvussa 4 (Character Properties) ja määritelty [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]: ssä.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Erilaisilla kiinalaisilla skripteillä ja välimerkkeillä ei ole kirjainta, ja niin:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Palauttaa arvon `true`, jos tällä `char`: llä on `Uppercase`-ominaisuus.
    ///
    /// `Uppercase` on kuvattu [Unicode Standard]: n luvussa 4 (Character Properties) ja määritelty [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]: ssä.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Erilaisilla kiinalaisilla skripteillä ja välimerkkeillä ei ole kirjainta, ja niin:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Palauttaa arvon `true`, jos tällä `char`: llä on `White_Space`-ominaisuus.
    ///
    /// `White_Space` on määritetty [Unicode Character Database][ucd] [`PropList.txt`]: ssä.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // murtumaton tila
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Palauttaa arvon `true`, jos tämä `char` täyttää joko [`is_alphabetic()`]: n tai [`is_numeric()`]: n.
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Palauttaa arvon `true`, jos tällä `char`: llä on ohjauskoodien yleinen luokka.
    ///
    /// Ohjauskoodit (koodipisteet, joiden yleinen luokka on `Cc`) on kuvattu [Unicode Standard]: n luvussa 4 (Character Properties) ja määritelty [Unicode Character Database][ucd] [`UnicodeData.txt`]: ssä.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// // U + 009C, JOUSITERMINAATTORI
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Palauttaa arvon `true`, jos tällä `char`: llä on `Grapheme_Extend`-ominaisuus.
    ///
    /// `Grapheme_Extend` on kuvattu [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29]: ssä ja määritelty [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]: ssä.
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Palauttaa arvon `true`, jos tällä `char`: llä on jokin yleisimmistä numeroiden luokista.
    ///
    /// Numeroiden yleiset luokat (`Nd` desimaaliluvuille, `Nl` kirjainten kaltaisille numeromerkkeille ja `No` muille numeroille) on määritelty [Unicode Character Database][ucd] [`UnicodeData.txt`]: ssä.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Palauttaa iteraattorin, joka tuottaa tämän `char`: n pienet kartat yhtenä tai useampana
    /// `char`s.
    ///
    /// Jos tällä `char`: llä ei ole pientä kartoitusta, iteraattori tuottaa saman `char`: n.
    ///
    /// Jos tällä `char`: llä on [Unicode Character Database][ucd] [`UnicodeData.txt`]: n antama yksi-yhteen pienikokoinen kartoitus, iteraattori tuottaa kyseisen `char`: n.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Jos tämä `char` vaatii erityishuomioita (esim. Useita ``char'ja ''), iteraattori tuottaa [`SpecialCasing.txt`]: n antamat`char (s).
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Tämä toimenpide suorittaa ehdoton kartoitus ilman räätälöintiä.Toisin sanoen muunnos on riippumaton kontekstista ja kielestä.
    ///
    /// [Unicode Standard]: ssä luvussa 4 (Character Properties) käsitellään tapausten kartoitusta yleensä ja luvussa 3 (Conformance) käsitellään tapausten muuntamisen oletusalgoritmia.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Iteraattorina:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!`: n käyttö suoraan:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Molemmat vastaavat:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// `to_string`: n käyttö:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Joskus tulos on useampi kuin yksi merkki:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Hahmot, joissa ei ole sekä isoja että pieniä kirjaimia, muuttuvat itseksi.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Palauttaa iteraattorin, joka tuottaa tämän `char`: n isot kartat yhtenä tai useampana
    /// `char`s.
    ///
    /// Jos tällä `char`: llä ei ole isoja kartoituksia, iteraattori tuottaa saman `char`: n.
    ///
    /// Jos tällä `char`: llä on [Unicode Character Database][ucd] [`UnicodeData.txt`]: n antama yksi-yhteen isokokoinen kartoitus, iteraattori tuottaa kyseisen `char`: n.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Jos tämä `char` vaatii erityishuomioita (esim. Useita ``char'ja ''), iteraattori tuottaa [`SpecialCasing.txt`]: n antamat`char (s).
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Tämä toimenpide suorittaa ehdoton kartoitus ilman räätälöintiä.Toisin sanoen muunnos on riippumaton kontekstista ja kielestä.
    ///
    /// [Unicode Standard]: ssä luvussa 4 (Character Properties) käsitellään tapausten kartoitusta yleensä ja luvussa 3 (Conformance) käsitellään tapausten muuntamisen oletusalgoritmia.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Iteraattorina:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!`: n käyttö suoraan:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Molemmat vastaavat:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// `to_string`: n käyttö:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Joskus tulos on useampi kuin yksi merkki:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Hahmot, joissa ei ole sekä isoja että pieniä kirjaimia, muuttuvat itseksi.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Huomautus kielestä
    ///
    /// Turkin kielellä latinan 'i' vastaavalla on viisi muotoa kahden sijasta:
    ///
    /// * 'Dotless': I/ı, joskus kirjoitettu ï
    /// * 'Dotted': İ/i
    ///
    /// Huomaa, että pienet pisteviivat 'i' ovat samat kuin latinalaiset.Siksi:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// `upper_i`: n arvo riippuu tässä tekstin kielestä: jos olemme `en-US`: ssä, sen pitäisi olla `"I"`, mutta jos olemme `tr_TR`: ssä, sen pitäisi olla `"İ"`.
    /// `to_uppercase()` ei ota tätä huomioon, joten:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// koskee kaikkia kieliä.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Tarkistaa, onko arvo ASCII-alueen sisällä.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Tekee kopion arvosta isojen vastaavien ASCII-muodossa.
    ///
    /// ASCII-kirjaimet 'a'-'z' yhdistetään numeroihin 'A'-'Z', mutta muut kuin ASCII-kirjaimet eivät muutu.
    ///
    /// Suurenna arvo paikalleen käyttämällä [`make_ascii_uppercase()`].
    ///
    /// Jos haluat kirjoittaa isoja ASCII-merkkejä muiden kuin ASCII-merkkien lisäksi, käytä [`to_uppercase()`]-merkkiä.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Tekee kopion arvosta vastaavalla pienellä ASCII-kirjaimella.
    ///
    /// ASCII-kirjaimet 'A'-'Z' yhdistetään numeroihin 'a'-'z', mutta muut kuin ASCII-kirjaimet eivät muutu.
    ///
    /// Pienennä arvoa paikassa [`make_ascii_lowercase()`].
    ///
    /// Jos haluat piilottaa ASCII-merkkejä muiden kuin ASCII-merkkien lisäksi, käytä [`to_lowercase()`]-merkkiä.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Tarkistaa, että kaksi arvoa vastaavat ASCII-kirjainkokoa.
    ///
    /// Vastaa `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Muuntaa tämän tyyppisen ASCII-kirjaimen vastaavaksi isoksi.
    ///
    /// ASCII-kirjaimet 'a'-'z' yhdistetään numeroihin 'A'-'Z', mutta muut kuin ASCII-kirjaimet eivät muutu.
    ///
    /// Jos haluat palauttaa uuden ylemmän tason arvon muuttamatta nykyistä arvoa, käytä [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Muuntaa tämän tyyppisen ASCII-kirjaimen vastaavaksi paikalleen.
    ///
    /// ASCII-kirjaimet 'A'-'Z' yhdistetään numeroihin 'a'-'z', mutta muut kuin ASCII-kirjaimet eivät muutu.
    ///
    /// Jos haluat palauttaa uuden pienikokoisen arvon muuttamatta nykyistä arvoa, käytä [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Tarkistaa, onko arvo ASCII-aakkosmerkki:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' tai
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Tarkistaa, onko arvo ASCII-isojen kirjainten merkki:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Tarkistaa, onko arvo ASCII-kirjain:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Tarkistaa, onko arvo ASCII-aakkosnumeerinen merkki:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' tai
    /// - U + 0061 'a' ..=U + 007A 'z' tai
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Tarkistaa, onko arvo ASCII-desimaaliluku:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Tarkistaa, onko arvo ASCII-heksadesimaaliluku:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9' tai
    /// - U + 0041 'A' ..=U + 0046 'F' tai
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Tarkistaa, onko arvo ASCII-välimerkkejä:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /` tai
    /// - U + 003A ..=U + 0040 `: ; < = > ? @` tai
    /// - U + 005B ..=U + 0060 ``[\] ^ _`` tai
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Tarkistaa, onko arvo ASCII-graafinen merkki:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Tarkistaa, onko arvo ASCII-välilyönti:
    /// U + 0020 AVARUUS, U + 0009 VAAKASUUNTAINEN TAULUKKO, U + 000A RIVISYÖTTÖ, U + 000C Lomakemalli tai U + 000D KULJETUSTEN PALAUTUS.
    ///
    /// Rust käyttää WhatWG Infra Standardin [definition of ASCII whitespace][infra-aw]: ää.Laajassa käytössä on useita muita määritelmiä.
    /// Esimerkiksi [the POSIX locale][pct] sisältää U + 000B VERTICAL TAB-välilehden sekä kaikki yllä olevat merkit, mutta-samasta spesifikaatiosta-["field splitting": n oletussääntö Bourne shell: ssä][bfs] pitää *vain* SPACE, HORIZONTAL TAB ja RIVISYÖTTÖ tyhjänä tilana.
    ///
    ///
    /// Jos kirjoitat ohjelmaa, joka käsittelee olemassa olevaa tiedostomuotoa, tarkista, mitä kyseisen muodon välilyönnin määritelmä on ennen tämän toiminnon käyttämistä.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Tarkistaa, onko arvo ASCII-ohjausmerkki:
    /// U + 0000 NUL ..=U + 001F-YKSIKÖN Separaattori tai U + 007F POISTA.
    /// Huomaa, että suurin osa ASCII-välilyönneistä on ohjausmerkkejä, mutta SPACE ei ole.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Koodaa raakan u32-arvon UTF-8-muodossa toimitettuun tavupuskuriin ja palauttaa sitten koodatun merkin sisältävän puskurin alalohkon.
///
///
/// Toisin kuin `char::encode_utf8`, tämä menetelmä käsittelee myös korvike-alueen koodipisteet.
/// (`char`: n luominen korvaavaan alueeseen on UB.) Tulos on kelvollinen [generalized UTF-8], mutta ei kelvollinen UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics, jos puskuri ei ole tarpeeksi suuri.
/// Neljän pituinen puskuri on riittävän suuri koodaamaan mitä tahansa `char`: ää.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Koodaa raakan u32-arvon UTF-16: ksi toimitettuun `u16`-puskuriin ja palauttaa sitten puskurin alisarjan, joka sisältää koodatun merkin.
///
///
/// Toisin kuin `char::encode_utf16`, tämä menetelmä käsittelee myös korvike-alueen koodipisteet.
/// (`char`: n luominen korvaavaan alueeseen on UB.)
///
/// # Panics
///
/// Panics, jos puskuri ei ole tarpeeksi suuri.
/// Puskuri, jonka pituus on 2, on riittävän suuri koodaamaan mitä tahansa `char`: ää.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // TURVALLISUUS: kukin varsi tarkistaa, onko kirjoittamiseen tarpeeksi bittejä
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP putoaa läpi
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Lisätasot hajoavat korvikkeiksi.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}