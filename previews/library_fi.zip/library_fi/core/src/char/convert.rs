//! Merkkimuunnokset.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Muuntaa `u32`: n `char`: ksi.
///
/// Huomaa, että kaikki [`char '] ovat kelvollisia [` u32`] ja ne voidaan heittää yhdeksi
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Päinvastoin ei kuitenkaan pidä paikkaansa: kaikki kelvolliset [`u32`]: t eivät ole kelvollisia [`char`].
/// `from_u32()` palauttaa arvon `None`, jos tulo ei ole kelvollinen arvo [`char`]: lle.
///
/// Lisätietoja tämän toiminnon vaarallisesta versiosta, joka ohittaa nämä tarkastukset, on kohdassa [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Peruskäyttö:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Palautetaan `None`, kun tulo ei ole kelvollinen [`char`]:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Muuntaa `u32`: n `char`: ksi, huomioimatta pätevyyttä.
///
/// Huomaa, että kaikki [`char '] ovat kelvollisia [` u32`] ja ne voidaan heittää yhdeksi
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Päinvastoin ei kuitenkaan pidä paikkaansa: kaikki kelvolliset [`u32`]: t eivät ole kelvollisia [`char`].
/// `from_u32_unchecked()` jättää tämän huomiotta ja heittää sokeasti [`char`]: ään luoden mahdollisesti virheellisen.
///
///
/// # Safety
///
/// Tämä toiminto on vaarallinen, koska se voi muodostaa virheellisiä `char`-arvoja.
///
/// Katso tämän toiminnon turvallinen versio [`from_u32`]-toiminnosta.
///
/// # Examples
///
/// Peruskäyttö:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // TURVALLISUUS: soittajan on taattava, että `i` on kelvollinen char-arvo.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Muuntaa [`char`]: n [`u32`]: ksi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Muuntaa [`char`]: n [`u64`]: ksi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Merkki heitetään koodipisteen arvoon, ja sen jälkeen nolla laajennetaan 64-bittiseksi.
        // Katso [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Muuntaa [`char`]: n [`u128`]: ksi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Merkki heitetään koodipisteen arvoon, ja sen jälkeen pidennetään nolla 128 bittiin.
        // Katso [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Karttaa tavun 0x00 ..=0xFF `char`: ään, jonka koodipisteellä on sama arvo, U + 0000 ..=U + 00FF.
///
/// Unicode on suunniteltu siten, että tämä dekoodaa tehokkaasti tavut merkkikoodauksella, jonka IANA kutsuu ISO-8859-1: ksi.
/// Tämä koodaus on yhteensopiva ASCII: n kanssa.
///
/// Huomaa, että tämä eroaa mallista ISO/IEC 8859-1 aka
/// ISO 8859-1 (yhdellä tavuviivalla), joka jättää joitain "blanks"-tavuarvoja, joita ei ole määritetty mihinkään merkkiin.
/// ISO-8859-1 (IANA one) määrittää ne C0-ja C1-ohjauskoodeille.
///
/// Huomaa, että tämä on *myös* erilainen kuin Windows-1252 aka
/// koodisivu 1252, joka on supersetti ISO/IEC 8859-1, joka antaa joitain (ei kaikkia!) aihioita välimerkkeihin ja erilaisiin latinalaisiin merkkeihin.
///
/// Sekoittamaan asiat edelleen: [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` ja `windows-1252` ovat kaikki aliaksia Windows-1252: n supersetille, joka täyttää jäljellä olevat aihiot vastaavilla C0-ja C1-ohjauskoodeilla.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Muuntaa [`u8`]: n [`char`]: ksi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Virhe, joka voidaan palauttaa merkin jäsentämisessä.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // TURVALLISUUS: tarkisti, että se on laillinen unicode-arvo
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Virhetyyppi palasi, kun muuntaminen u32: stä chariksi epäonnistui.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Muuntaa annetun radiksin luvun `char`: ksi.
///
/// 'radix': ää kutsutaan tässä joskus myös 'base': ksi.
/// Kahden radikaali osoittaa binääriluvun, kymmenen desimaalin tarkkuuden ja kuusitoista heksadesimaalin radiksin, jotta saadaan joitakin yhteisiä arvoja.
///
/// Mielivaltaiset säteet tuetaan.
///
/// `from_digit()` palauttaa `None`, jos tulo ei ole annettu radiksin numero.
///
/// # Panics
///
/// Panics, jos säde on suurempi kuin 36.
///
/// # Examples
///
/// Peruskäyttö:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Desimaali 11 on yksinumeroinen perusta 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Palautetaan `None`, kun tulo ei ole numero:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Suuren radiksin ohittaminen aiheuttaen panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}