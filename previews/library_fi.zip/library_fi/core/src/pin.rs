//! Tyypit, jotka kiinnittävät tietoja muistin sijaintiin.
//!
//! Joskus on hyödyllistä, että esineitä ei taata liikkua siinä mielessä, että niiden sijoitus muistiin ei muutu ja että niihin voidaan siis luottaa.
//! Erinomainen esimerkki tällaisesta skenaariosta olisi itseohjerakenteiden rakentaminen, koska kohteen siirtäminen osoittimilla itsensä kanssa mitätöi ne, mikä voi aiheuttaa määrittelemätöntä käyttäytymistä.
//!
//! Korkealla tasolla [`Pin<P>`] varmistaa, että minkä tahansa osoitintyypin `P` vastaanottajalla on vakaa sijainti muistissa, joten sitä ei voida siirtää muualle eikä muistia voida kohdistaa ennen kuin se putoaa.Sanomme, että osoitettava on "pinned".Asiat muuttuvat hienovaraisemmiksi keskustellessaan tyypeistä, jotka yhdistyvät kiinnitettyyn ja kiinnittämättömään dataan;[see below](#projections-and-structural-pinning) lisätietoja.
//!
//! Oletusarvoisesti kaikki tyypit Rust ovat liikkuvia.
//! Rust sallii kaiken tyyppisten arvojen välittämisen, ja yleiset älykäs osoitintyypit, kuten [`Box<T>`] ja `&mut T`, sallivat niiden sisältämien arvojen korvaamisen ja siirtämisen: voit siirtyä pois [`Box<T>`]: stä tai käyttää [`mem::swap`]: ää.
//! [`Pin<P>`] kääri osoitintyypin `P`, joten [``Pin '' <<[[Box]]`<T>> `toimii kuten tavallinen
//!
//! [`Box<T>`]: when a [``Tappi``] <<[[Box]] `<T>>`putoaa, niin myös sen sisältö, ja muisti tulee
//!
//! jaettu.Vastaavasti [`Pin ']` <&mut T> `on paljon kuin `&mut T`.[`Pin<P>`] ei kuitenkaan anna asiakkaiden todella hankkia kiinnitettyihin tietoihin [`Box<T>`]-tai `&mut T`-tiedostoja, mikä tarkoittaa, että et voi käyttää toimintoja, kuten [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` tarvitsee `&mut T`: n, mutta emme voi saada sitä.
//!     // Olemme jumissa, emme voi vaihtaa näiden viitteiden sisältöä.
//!     // Voisimme käyttää `Pin::get_unchecked_mut`: ää, mutta se on vaarallista syystä:
//!     // emme saa käyttää sitä esineiden siirtämiseen `Pin`: stä.
//! }
//! ```
//!
//! On syytä toistaa, että [`Pin<P>`]*ei* muuta sitä tosiasiaa, että Rust-kääntäjä pitää kaikenlaisia liikkuvia.[`mem::swap`] pysyy soitettavissa kaikille `T`-laitteille.Sen sijaan [`Pin<P>`] estää tiettyjen *arvojen*(osoittavat [`Pin<P>`]: ään käärityt osoittimet) siirtymisen tekemällä mahdottomaksi kutsua menetelmiä, jotka edellyttävät `&mut T`: ää (kuten [`mem::swap`]).
//!
//! [`Pin<P>`] voidaan käyttää minkä tahansa osoitintyypin `P` käärimiseen ja sellaisenaan vuorovaikutuksessa [`Deref`]: n ja [`DerefMut`]: n kanssa.[`Pin<P>`], jossa `P: Deref` on katsottava kiinnitetylle `P::Target`: lle "`P`-style pointer": ksi-niin, [``Pin '' <<[[Box]]`<T>> `on kiinnitetyn `T`: n omistettu osoitin ja [` `Pin`]] <<[[Rc`]`<T>> `on viitteellä laskettu osoitin kiinnitetylle `T`: lle.
//! Oikeuden vuoksi [`Pin<P>`] luottaa siihen, että [`Deref`]: n ja [`DerefMut`]: n toteutukset eivät siirry pois `self`-parametristaan ja palauttavat osoittimen kiinnitettyihin tietoihin vain, kun heitä kutsutaan kiinnitettyyn osoittimeen.
//!
//! # `Unpin`
//!
//! Monet tyypit ovat aina vapaasti siirrettävissä, myös kiinnitettynä, koska ne eivät luota vakaaseen osoitteeseen.Tämä sisältää kaikki perustyypit (kuten [`bool`], [`i32`] ja viitteet) sekä tyypit, jotka koostuvat yksinomaan näistä tyypeistä.Tyypit, jotka eivät välitä kiinnittämisestä, toteuttavat [`Unpin`] auto-trait: n, joka kumoaa [`Pin<P>`]: n vaikutuksen.
//! `T: Unpin`: ssä: [``Pin '']`` ```` ``Box ''``<T>> `ja [`Box<T>`] toimivat identtisesti, samoin kuin [` `Kiinnitä``] <&mut T>` ja `&mut T`.
//!
//! Huomaa, että kiinnitys ja [`Unpin`] vaikuttavat vain teräväkärkiseen `P::Target`-tyyppiin, ei itse osoitintyyppiin `P`, joka käärittiin [`Pin<P>`]: ään.Esimerkiksi sillä, onko [`Box<T>`] [`Unpin`] vai ei, ei ole vaikutusta [`Pin ']` ```` ```Box' '' ') käyttäytymiseen.<T>>`(tässä `T` on teräväpiirtotyyppi).
//!
//! # Esimerkki: itseviittaava rakenne
//!
//! Ennen kuin käsittelemme tarkemmin `Pin<T>`: ään liittyviä takuita ja valintoja, keskustelemme joitain esimerkkejä siitä, miten sitä voidaan käyttää.
//! Voit vapaasti käyttää [skip to where the theoretical discussion continues](#drop-guarantee): ää.
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Tämä on itseviittaava rakenne, koska leikekenttä osoittaa tietokenttään.
//! // Emme voi kertoa siitä kääntäjälle normaalilla viitteellä, koska tätä mallia ei voida kuvata tavallisilla lainasäännöillä.
//! //
//! // Sen sijaan käytämme raakaa osoittinta, vaikkakin sellaisen, jonka tiedetään olevan tyhjä, koska tiedämme, että se osoittaa merkkijonoa.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Varmistaaksemme, että tiedot eivät liiku, kun funktio palaa, sijoitamme ne kasaan, johon ne pysyvät objektin eliniän ajan, ja ainoa tapa käyttää niitä olisi osoittimen kautta.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // Luomme osoittimen vasta, kun tiedot ovat paikoillaan, muuten se on jo liikkunut ennen kuin aloitimme
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // tiedämme, että tämä on turvallista, koska kentän muokkaaminen ei siirrä koko rakennetta
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Osoittimen tulee osoittaa oikeaan paikkaan, kunhan rakenne ei ole liikkunut.
//! //
//! // Sillä välin voimme vapaasti siirtää osoitinta ympäri.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Koska tyypimme ei ota käyttöön irrotusta, tämä ei onnistu kääntämään:
//! // let mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Esimerkki: tunkeileva kaksinkertaisesti linkitetty luettelo
//!
//! Tunkeilevassa kaksinkertaisesti linkitetyssä luettelossa kokoelma ei tosiasiallisesti jaa muistia itse elementeille.
//! Asiakkaat hallitsevat allokaatiota, ja elementit voivat elää pinokehyksessä, joka elää lyhyempää kuin kokoelma.
//!
//! Jotta tämä toimisi, jokaisella elementillä on viitteitä edeltäjälleen ja seuraajalleen luettelossa.Elementit voidaan lisätä vain, kun ne on kiinnitetty, koska elementtien siirtäminen mitätöi osoittimet.Lisäksi linkitetyn luetteloelementin [`Drop`]-toteutus korjaa edeltäjänsä ja seuraajansa osoittimet poistamaan itsensä luettelosta.
//!
//! Tärkeää on, että meidän on voitava luottaa siihen, että [`drop`] kutsutaan.Jos elementti voitaisiin jakaa tai muuten mitätöidä kutsumatta [`drop`]: ää, viereisiin elementteihin osoittavat osoittimet mitätöityisivät, mikä rikkoa tietorakennetta.
//!
//! Siksi kiinnittämiseen liittyy myös [pudotukseen] liittyvä takuu.
//!
//! # `Drop` guarantee
//!
//! Kiinnittämisen tarkoituksena on pystyä luottamaan joidenkin tietojen sijoittamiseen muistiin.
//! Jotta tämä toimisi, ei vain tietojen siirtämistä rajoiteta;Myös tietojen tallentamiseen käytetyn muistin jakaminen, uudelleensijoittaminen tai muuten mitätöinti on rajoitettua.
//! Konkreettisesti kiinnitettyjen tietojen kohdalla on säilytettävä invariantti, että *sen muisti ei mitätöity tai muutu uudelleen siitä hetkestä, kun se kiinnitetään siihen asti, kunnes [`drop`] kutsutaan*.Vasta kun [`drop`] palaa tai panics, muistia voidaan käyttää uudelleen.
//!
//! Muisti voi olla "invalidated" jakamalla, mutta myös korvaamalla [`Some(v)`] [`None`]: llä tai kutsumalla [`Vec::set_len`]-"kill" joihinkin vector-elementteihin.Se voidaan muuttaa käyttämällä [`ptr::write`]: ää korvaamaan se soittamatta ensin tuhoajaa.Mitään tätä ei sallita kiinnitetyille tiedoille soittamatta [`drop`]: ää.
//!
//! Tämä on täsmälleen sellainen takuu, että edellisen osan häiritsevän linkitetyn luettelon on toimittava oikein.
//!
//! Huomaa, että tämä takuu ei tarkoita, että muisti ei vuoda!Vielä ei ole koskaan okei kutsua [`drop`]: tä kiinnitetylle elementille (esim. Voit silti soittaa [`mem::forget`]: lle [``Pin '') <<[[Box]]`<T>> `).Kaksinkertaisesti linkitetyn luettelon esimerkissä kyseinen elementti pysyisi vain luettelossa.Et kuitenkaan voi vapauttaa tai käyttää tallennustilaa *uudelleen soittamatta [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Jos tyypisi käyttää kiinnitystä (kuten kaksi yllä olevaa esimerkkiä), sinun on oltava varovainen, kun otat [`Drop`]: n käyttöön.[`drop`]-toiminto vie `&mut self`: n, mutta tätä kutsutaan *vaikka tyyppisi olisi aiemmin kiinnitetty*!On kuin kääntäjä kutsui automaattisesti [`Pin::get_unchecked_mut`].
//!
//! Tämä ei voi koskaan aiheuttaa ongelmaa turvallisessa koodissa, koska kiinnittämiseen perustuvan tyypin käyttöönotto vaatii vaarallista koodia, mutta muista, että päätät käyttää kiinnitystä tyypissäsi (esimerkiksi suorittamalla jokin toiminto [``Pin`] '' <&Self-sovelluksessa) > `tai [` Pin '] `<&mut Self>`) on seurauksia myös [`Drop`]-toteutuksellesi: jos tyyppinen elementti olisi voitu kiinnittää, sinun on kohdeltava [`Drop`]: ää epäsuorasti ottamalla [`Pin']` <&mut Itse> `.
//!
//!
//! Voit esimerkiksi toteuttaa `Drop`: n seuraavasti:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` on kunnossa, koska tiedämme, että tätä arvoa ei koskaan käytetä enää pudotuksen jälkeen.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Todellinen pudotuskoodi menee tähän.
//!         }
//!     }
//! }
//! ```
//!
//! Toiminnolla `inner_drop` on tyyppi, jonka [`drop`]*: lla pitäisi olla*, joten tämä varmistaa, ettet käytä vahingossa `self`/`this`: ää tavalla, joka on ristiriidassa kiinnityksen kanssa.
//!
//! Lisäksi, jos tyyppi on `#[repr(packed)]`, kääntäjä siirtää automaattisesti kentät ympäri voidakseen pudottaa ne.Se saattaa jopa tehdä sen kenttien kohdalla, jotka sattuu olemaan riittävän linjassa.Tämän seurauksena et voi käyttää kiinnitystä `#[repr(packed)]`-tyypin kanssa.
//!
//! # Ennusteet ja rakenteellinen kiinnitys
//!
//! Kun työskentelet kiinnitettyjen rakenteiden kanssa, nousee esiin kysymys siitä, miten pääset kyseisen rakenteen kenttiin menetelmässä, joka vie vain [``Pin`] '<&mut Struct> `.
//! Tavallinen tapa on kirjoittaa apumenetelmiä (ns.*Projektioita*), jotka muuttavat [``Pin'] ''&&mut Struct>`viitteeksi kentälle, mutta minkä tyyppisen viitteen tulisi olla?Onko se [`Pin '] <&mut Field>` vai `&mut Field`?
//! Sama kysymys nousee `enum`-kenttien kohdalla ja myös tarkasteltaessa container/wrapper-tyyppejä, kuten [`Vec<T>`], [`Box<T>`] tai [`RefCell<T>`].
//! (Tämä kysymys koskee sekä muutettavissa olevia että jaettuja viitteitä, vain käytämme tässä esimerkkinä yleisempää muuttuvien viitteiden tapausta.)
//!
//! On käynyt ilmi, että tietorakenteen kirjoittajan on itse päätettävä, muuttaako tietyn kentän kiinnitetty projektio [``Pin'] ''&&mut Struct>`[[Pin]]` <&mut Field> 'vai `&mut Field`.Joitakin rajoituksia on kuitenkin, ja tärkein rajoitus on *johdonmukaisuus*:
//! jokainen kenttä voidaan *joko* heijastaa kiinnitettyyn viitteeseen,*tai* poistaa kiinnitys projisoinnin osana.
//! Jos molemmat tehdään samalle kentälle, se on todennäköisesti järkevää!
//!
//! Tietorakenteen kirjoittajana voit päättää jokaiselle kentälle, kiinnitetäänkö "propagates" tähän kenttään vai ei.
//! Levittävää kiinnitystä kutsutaan myös "structural": ksi, koska se seuraa tyypin rakennetta.
//! Seuraavissa osioissa kuvataan huomioita, jotka on tehtävä kummallekin valinnalle.
//!
//! ## Kiinnitys * ei ole `field`: n rakenteellinen
//!
//! Saattaa tuntua vasta-intuitiiviselta, että kiinnitetyn rakenteen kenttää ei välttämättä kiinnitetä, mutta se on itse asiassa helpoin valinta: jos [``Pin'] '' <&mut Field>`` ei koskaan luoda, mikään ei voi mennä pieleen!Joten, jos päätät, että joillakin kentillä ei ole rakenteellista kiinnitystä, sinun on vain varmistettava, että et koskaan luo kiinnitettyä viittausta kyseiseen kenttään.
//!
//! Kentillä, joissa ei ole rakenteellista kiinnitystä, voi olla projektiomenetelmä, joka muuttaa [``Pin ']``&mut Struct>' `&mut Field`: ksi:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Tämä on ok, koska `field`: ää ei koskaan pidetä kiinnitettynä.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Voit myös `impl Unpin for Struct`*, vaikka*`field` ei ole [`Unpin`].Sillä, minkä tyyppinen ajattelee kiinnittämisestä, ei ole merkitystä, kun [``Pin'] '' <&mut Field>`-tunnusta ei koskaan luoda.
//!
//! ## Kiinnittäminen * on `field`: n rakenteellinen
//!
//! Toinen vaihtoehto on päättää, että kiinnitys on "structural" `field`: lle, mikä tarkoittaa, että jos rakenne on kiinnitetty, niin on myös kenttä.
//!
//! Tämä antaa mahdollisuuden kirjoittaa projektio, joka luo [`Pin '] <&mut Field>`, mikä todistaa, että kenttä on kiinnitetty:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Tämä on ok, koska `field` on kiinnitetty, kun `self` on.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Rakenteiseen kiinnitykseen liittyy kuitenkin muutama lisävaatimus:
//!
//! 1. Rakenteen tulee olla vain [`Unpin`], jos kaikki rakennekentät ovat [`Unpin`].Tämä on oletusarvo, mutta [`Unpin`] on turvallinen trait, joten struktuurin kirjoittajana sinun on *ei* lisätä jotain `impl<T> Unpin for Struct<T>`: n kaltaista.
//! (Huomaa, että projektiotoiminnon lisääminen vaatii vaarallisen koodin, joten se, että [`Unpin`] on turvallinen trait, ei riko periaatetta, että sinun on huolehdittava tästä vain, jos käytät `` vaarallista ''.)
//! 2. Struktorin tuhoaja ei saa siirtää rakennekenttiä argumenttinsa ulkopuolelle.Tämä on tarkka kohta, joka otettiin esiin [previous section][drop-impl]: ssä: `drop` vie `&mut self`: n, mutta struct (ja siten sen kentät) on ehkä kiinnitetty aiemmin.
//!     Sinun on taattava, että et siirrä kenttää [`Drop`]-toteutuksen sisällä.
//!     Erityisesti, kuten aiemmin selitettiin, tämä tarkoittaa, että strukturisi ei *saa* olla `#[repr(packed)]`.
//!     Tästä osiosta saat ohjeet [`drop`]: n kirjoittamiseen siten, että kääntäjä voi auttaa sinua vahingossa rikkomatta kiinnittämistä.
//! 3. Varmista, että pidät [`Drop` guarantee][drop-guarantee]: ää voimassa:
//!     Kun rakenteesi on kiinnitetty, sisältöä sisältävää muistia ei korvata eikä jaeta kutsumatta sisällön tuhoajia.
//!     Tämä voi olla hankalaa, kuten [`VecDeque<T>`] on todistanut: [`VecDeque<T>`]: n tuhoaja voi epäonnistua kutsumasta [`drop`]: ää kaikissa elementeissä, jos jokin tuhoajista panics.Tämä rikkoo [`Drop`]-takuuta, koska se voi johtaa elementtien jakamiseen ilman, että niiden tuhoajaa kutsutaan.([`VecDeque<T>`]: llä ei ole kiinnityselementtejä, joten se ei aiheuta epämukavuutta.)
//! 4. Et saa tarjota muita toimintoja, jotka voivat johtaa tietojen siirtämiseen pois rakennekentistä, kun tyyppi on kiinnitetty.Esimerkiksi, jos struct sisältää [`Option<T>`]: n ja tyypillä `fn(Pin<&mut Struct<T>>) -> Option<T>` on `` take-like ''-operaatio, tätä toimintoa voidaan käyttää `T`: n siirtämiseen kiinnitetystä `Struct<T>`: stä-mikä tarkoittaa, että kiinnitys ei voi olla rakenteellinen tätä pitävälle kentälle tiedot.
//!
//!     Kuvittele monimutkaisempi esimerkki tietojen siirtämisestä kiinnitetystä tyypistä, jos [`RefCell<T>`]: llä olisi menetelmä `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Sitten voisimme tehdä seuraavat:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Tämä on katastrofaalista, se tarkoittaa, että voimme ensin kiinnittää [`RefCell<T>`]: n sisällön (`RefCell::get_pin_mut`: n avulla) ja siirtää sitten sisällön myöhemmin saamamme muutettavan viitteen avulla.
//!
//! ## Examples
//!
//! [`Vec<T>`]: n kaltaiselle tyypille molemmat mahdollisuudet (rakenteellinen kiinnitys vai ei) ovat järkeviä.
//! [`Vec<T>`]: llä, jolla on rakenteellinen kiinnitys, voi olla `get_pin`/`get_pin_mut`-menetelmiä kiinnitettyjen viittausten saamiseksi elementteihin.Se ei kuitenkaan voinut *ei* sallia [`pop`][Vec::pop]: n kutsumista kiinnitetylle [`Vec<T>`]: lle, koska se siirtäisi (rakenteellisesti kiinnitetyn) sisällön!Se ei myöskään voinut sallia [`push`][Vec::push]: ää, joka voi kohdistaa uudelleen ja siten myös siirtää sisältöä.
//!
//! [`Vec<T>`] ilman rakenteista kiinnitystä voisi `impl<T> Unpin for Vec<T>`, koska sisältöä ei koskaan kiinnitetä ja [`Vec<T>`] itsessään on kunnossa myös siirrettäessä.
//! Siinä vaiheessa kiinnittämisellä ei vain ole vaikutusta vector: een.
//!
//! Vakiokirjastossa osoitintyypeillä ei yleensä ole rakenteista kiinnitystä, joten ne eivät tarjoa kiinnityselementtejä.Siksi `Box<T>: Unpin` pätee kaikkiin `T`-laitteisiin.
//! On järkevää tehdä tämä osoitintyypeille, koska `Box<T>`: n siirtäminen ei todellakaan liikuta `T`: ää: [`Box<T>`] voi olla vapaasti liikutettavissa (alias `Unpin`), vaikka `T` ei olisikaan.Itse asiassa jopa [`Pin ']` ```` ``Box' '``<T>> `ja [` Pin '] `<&mut T>` ovat aina itse [`Unpin`], samasta syystä: niiden sisältö (`T`) kiinnitetään, mutta itse osoittimia voidaan siirtää siirtämättä kiinnitettyjä tietoja.
//! Sekä [`Box<T>`]: lle että [``Pin'ille] '' <`[``Box`] ''<T>> `, onko sisältö kiinnitetty, on täysin riippumaton siitä, kiinnitetäänkö osoitin, eli kiinnittäminen ei ole * rakenteellista.
//!
//! Kun otat käyttöön [`Future`]-yhdistimen, tarvitset yleensä rakenteellisen kiinnityksen sisäkkäisiin futures-sovelluksiin, koska sinun on hankittava kiinnitetyt viitteet niihin, jotta voit soittaa [`poll`]: n.
//! Mutta jos kombinaattorisi sisältää muita tietoja, joita ei tarvitse kiinnittää, voit tehdä kentistä rakenteettomia ja siten käyttää niitä vapaasti muunneltavalla viitteellä, vaikka sinulla olisi vain [``Pin`] '<&mut Self> `(kuten kuten omassa [`poll`]-toteutuksessa).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Kiinnitetty osoitin.
///
/// Tämä on kääre eräänlaisen osoittimen ympärille, joka tekee osoittimen "pin" arvon paikalleen, mikä estää osoittimen viittaaman arvon siirtämisen, ellei se toteuta [`Unpin`]: ää.
///
///
/// *Katso kiinnityksen selitys [`pin` module]-dokumentaatiosta.*
///
/// [`pin` module]: self
///
// Note: alla oleva `Clone`-johdannainen aiheuttaa epävarmuutta, koska se on mahdollista toteuttaa
// `Clone` muuttuville viitteille.
// Katso lisätietoja <https://internals.rust-lang.org/t/unsoundness-in-pin/11311>: stä.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Seuraavia toteutuksia ei ole johdettu äänenvoimakkuuden välttämiseksi.
// `&self.pointer` ei pitäisi olla epäluotettavien trait-toteutusten saatavilla.
//
// Katso lisätietoja <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73>: stä.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Rakenna uusi `Pin<P>` osoittimen ympärille joihinkin tietoihin, jotka käyttävät [`Unpin`]: ää.
    ///
    /// Toisin kuin `Pin::new_unchecked`, tämä menetelmä on turvallinen, koska osoitin `P` viittaa [`Unpin`]-tyyppiin, mikä kumoaa kiinnitystakuut.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // TURVALLISUUS: Osoitettu arvo on `Unpin`, joten sillä ei ole vaatimuksia
        // kiinnityksen ympärillä.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Kumoa tämä `Pin<P>` palauttamalla taustalla olevan osoittimen.
    ///
    /// Tämä edellyttää, että tämän `Pin`: n sisällä olevat tiedot ovat [`Unpin`], jotta voimme jättää kiinnittämättömät invariantit huomiotta, kun avaamme ne.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Muodosta uusi `Pin<P>` viittauksen ympärille joihinkin tietotyyppisiin tietoihin, jotka saattavat toteuttaa `Unpin`: n tai eivät.
    ///
    /// Jos `pointer`-viittaukset `Unpin`-tyyppiin, `Pin::new`: ää tulisi käyttää sen sijaan.
    ///
    /// # Safety
    ///
    /// Tämä rakentaja on vaarallinen, koska emme voi taata, että `pointer`: n osoittamat tiedot on kiinnitetty, mikä tarkoittaa, että tietoja ei siirretä tai niiden tallennus mitätöity, ennen kuin ne pudotetaan.
    /// Jos muodostettu `Pin<P>` ei takaa, että tiedot, joihin `P` osoittaa, kiinnitetään, se on API-sopimuksen vastaista ja voi johtaa määrittelemättömään toimintaan myöhemmissä (safe)-operaatioissa.
    ///
    /// Tällä menetelmällä luot promise: n `P::Deref`-ja `P::DerefMut`-toteutuksista, jos sellaisia on.
    /// Mikä tärkeintä, he eivät saa siirtyä pois `self`-argumenteistaan: `Pin::as_mut` ja `Pin::as_ref` kutsuvat `DerefMut::deref_mut`-ja `Deref::deref`*-merkkejä kiinnitetyssä osoittimessa* ja odottavat näiden menetelmien pitävän yllä kiinnittäviä invarianteja.
    /// Lisäksi kutsumalla tätä menetelmää sinä promise, josta viite `P`-viittauksia ei siirretä uudelleen;erityisesti ei saa olla mahdollista saada `&mut P::Target` ja sitten siirtyä pois tästä viitteestä (esimerkiksi [`mem::swap`]).
    ///
    ///
    /// Esimerkiksi `Pin::new_unchecked`: n soittaminen `&'a mut T`: llä on vaarallista, koska vaikka pystyt kiinnittämään sen tietyn käyttöiän `'a` ajaksi, et voi hallita, pidetäänkö sitä kiinnitettynä, kun `'a` päättyy:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Tämän pitäisi tarkoittaa sitä, että osoitettava `a` ei voi koskaan liikkua uudelleen.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // `a`: n osoite muuttui `b: n pinopaikaksi, joten `a` siirtyi, vaikka olemme aiemmin kiinnittäneet sen!Olemme rikkoneet pinning-sovellusliittymäsopimusta.
    /////
    /// }
    /// ```
    ///
    /// Kun arvo on kiinnitetty, sen on pysyttävä kiinnitettynä ikuisesti (ellei sen tyyppi toteuta `Unpin`: ää).
    ///
    /// Vastaavasti `Pin::new_unchecked`: ään soittaminen `Rc<T>`: llä on vaarallista, koska samoille tiedoille voi olla aliaksia, joihin ei sovelleta kiinnitysrajoituksia:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Tämän pitäisi tarkoittaa sitä, että osoitettava ei voi koskaan liikkua uudelleen.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Jos nyt `x` oli ainoa viite, meillä on muutettava viittaus yllä kiinnitettyihin tietoihin, joita voisimme käyttää siirtämään niitä, kuten olemme nähneet edellisessä esimerkissä.
    ///     // Olemme rikkoneet pinning-sovellusliittymäsopimusta.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Hakee kiinnitetyn jaetun viitteen tästä kiinnitetystä osoittimesta.
    ///
    /// Tämä on yleinen menetelmä siirtymiseen `&Pin<Pointer<T>>`: stä `Pin<&T>`: ään.
    /// Se on turvallista, koska osana `Pin::new_unchecked`: n sopimusta osoitettava ei voi liikkua sen jälkeen, kun `Pin<Pointer<T>>` on luotu.
    ///
    /// "Malicious" `Pin::new_unchecked`: n toteutus on myös suljettu pois `Pin::new_unchecked`: n sopimuksesta.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // TURVALLISUUS: katso tämän toiminnon ohjeet
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Kumoa tämä `Pin<P>` palauttamalla taustalla olevan osoittimen.
    ///
    /// # Safety
    ///
    /// Tämä toiminto on vaarallinen.Sinun on taattava, että jatkat osoittimen `P` käsittelyä kiinnitettynä tämän toiminnon kutsumisen jälkeen, jotta `Pin`-tyypin invarianteja voidaan ylläpitää.
    /// Jos tuloksena olevaa `P`: ää käyttävä koodi ei jatka kiinnitysvarianttien ylläpitämistä, se on API-sopimuksen vastaista ja voi johtaa määrittelemättömään toimintaan myöhemmissä (safe)-operaatioissa.
    ///
    ///
    /// Jos taustalla olevat tiedot ovat [`Unpin`], sen sijaan tulisi käyttää [`Pin::into_inner`].
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Hakee kiinnitetyn muutettavan viitteen tästä kiinnitetystä osoittimesta.
    ///
    /// Tämä on yleinen menetelmä siirtymiseen `&mut Pin<Pointer<T>>`: stä `Pin<&mut T>`: ään.
    /// Se on turvallista, koska osana `Pin::new_unchecked`: n sopimusta osoitettava ei voi liikkua sen jälkeen, kun `Pin<Pointer<T>>` on luotu.
    ///
    /// "Malicious" `Pin::new_unchecked`: n toteutus on myös suljettu pois `Pin::new_unchecked`: n sopimuksesta.
    ///
    /// Tämä menetelmä on hyödyllinen, kun soitetaan useita kutsuja kiinnitettyä tyyppiä käyttäviin toimintoihin.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // tee jotain
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` kuluttaa `self`: ää, joten lainaa `Pin<&mut Self>` uudelleen `as_mut`: n kautta.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // TURVALLISUUS: katso tämän toiminnon ohjeet
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Määrittää uuden arvon kiinnitetyn viitteen takana olevalle muistille.
    ///
    /// Tämä korvaa kiinnitetyt tiedot, mutta se on okei: sen tuhoaja suoritetaan ennen sen korvaamista, joten mitään kiinnitystakuuta ei rikota.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Rakentaa uuden tapin kartoittamalla sisätilojen arvon.
    ///
    /// Jos esimerkiksi haluat saada `Pin`-kentän jostakin kentästä, voit käyttää tätä päästäksesi kyseiseen kenttään yhdellä rivillä koodia.
    /// Näillä "pinning projections": llä on kuitenkin useita gotchoja;
    /// katso lisätietoja aiheesta [`pin` module]-ohjeista.
    ///
    /// # Safety
    ///
    /// Tämä toiminto on vaarallinen.
    /// Sinun on taattava, että palauttamasi tiedot eivät liiku niin kauan kuin argumentin arvo ei liiku (esimerkiksi koska se on yksi kyseisen arvon kentistä), ja että et myöskään siirry pois saamastasi argumentista sisätilan toiminto.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // TURVALLISUUS: `new_unchecked`: n turvasopimuksen on oltava
        // soittaja tukee.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Haetaan jaettu viite nastasta.
    ///
    /// Tämä on turvallista, koska jaetusta viitteestä ei ole mahdollista siirtyä.
    /// Saattaa tuntua siltä, että sisätilojen muutettavuudessa on ongelma: itse asiassa `T` voidaan siirtää `&RefCell<T>`: stä.
    /// Tämä ei kuitenkaan ole ongelma, kunhan ei ole myöskään samoille tiedoille osoittavaa `Pin<&T>`-laitetta, eikä `RefCell<T>` anna sinun luoda kiinnitettyä viittausta sen sisältöön.
    ///
    /// Katso lisätietoja ["pinning projections"]-keskustelusta.
    ///
    /// Note: `Pin` toteuttaa myös `Deref`: n kohteeseen, jota voidaan käyttää sisäisen arvon saavuttamiseen.
    /// `Deref` tarjoaa kuitenkin vain viitteen, joka elää niin kauan kuin `Pin`: n lainaa, ei itse `Pin`: n käyttöikää.
    /// Tämän menetelmän avulla `Pin` voidaan muuttaa referenssiksi, jolla on sama käyttöikä kuin alkuperäisellä `Pin`: llä.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Muuntaa tämän `Pin<&mut T>`: n saman käyttöiän omaavaksi `Pin<&T>`: ksi.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Hakee muutettavan viitteen tämän `Pin`: n sisällä oleviin tietoihin.
    ///
    /// Tämä edellyttää, että `Pin`: n sisällä olevat tiedot ovat `Unpin`.
    ///
    /// Note: `Pin` toteuttaa myös `DerefMut`-datan, jota voidaan käyttää sisäiseen arvoon pääsemiseksi.
    /// `DerefMut` tarjoaa kuitenkin vain viitteen, joka elää niin kauan kuin `Pin`: n lainaa, ei itse `Pin`: n käyttöikää.
    ///
    /// Tämän menetelmän avulla `Pin` voidaan muuttaa referenssiksi, jolla on sama käyttöikä kuin alkuperäisellä `Pin`: llä.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Hakee muutettavan viitteen tämän `Pin`: n sisällä oleviin tietoihin.
    ///
    /// # Safety
    ///
    /// Tämä toiminto on vaarallinen.
    /// Sinun on taattava, ettet koskaan siirrä tietoja pois muutettavasta viitteestä, jonka saat, kun soitat tätä toimintoa, jotta `Pin`-tyypin invarianteja voidaan ylläpitää.
    ///
    ///
    /// Jos taustalla olevat tiedot ovat `Unpin`, sen sijaan tulisi käyttää `Pin::get_mut`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Rakenna uusi tappi kartoittamalla sisätilojen arvo.
    ///
    /// Jos esimerkiksi haluat saada `Pin`-kentän jostakin kentästä, voit käyttää tätä päästäksesi kyseiseen kenttään yhdellä rivillä koodia.
    /// Näillä "pinning projections": llä on kuitenkin useita gotchoja;
    /// katso lisätietoja aiheesta [`pin` module]-ohjeista.
    ///
    /// # Safety
    ///
    /// Tämä toiminto on vaarallinen.
    /// Sinun on taattava, että palauttamasi tiedot eivät liiku niin kauan kuin argumentin arvo ei liiku (esimerkiksi koska se on yksi kyseisen arvon kentistä), ja että et myöskään siirry pois saamastasi argumentista sisätilan toiminto.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // TURVALLISUUS: soittaja on vastuussa laitteen siirtämisestä
        // arvo tästä viitteestä.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // TURVALLISUUS: koska `this`: n arvoa ei taata
        // on siirretty pois, tämä puhelu `new_unchecked`: lle on turvallinen.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Hanki kiinnitetty viite staattisesta viitteestä.
    ///
    /// Tämä on turvallista, koska `T` lainataan `'static`-käyttöikää varten, joka ei koskaan pääty.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // TURVALLISUUS: 'Staattinen laina takaa, että tietoja ei ole
        // moved/invalidated kunnes se putoaa (mikä ei ole koskaan).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Hanki kiinnitetty muutettava viite staattisesta muutettavasta viitteestä.
    ///
    /// Tämä on turvallista, koska `T` lainataan `'static`-käyttöikää varten, joka ei koskaan pääty.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // TURVALLISUUS: 'Staattinen laina takaa, että tietoja ei ole
        // moved/invalidated kunnes se putoaa (mikä ei ole koskaan).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: tämä tarkoittaa, että mikä tahansa `CoerceUnsized`: n implikaatio, joka sallii pakottamisen
// tyyppi, joka implantoi `Deref<Target=impl !Unpin>`: n tyypiksi, joka implisiitti `Deref<Target=Unpin>`: n, on epäterve.
// Kaikki tällaiset implisiitit ovat todennäköisesti perusteettomia muista syistä, joten meidän on vain varottava, ettemme anna tällaisten implikaatioiden laskeutua std: een.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}