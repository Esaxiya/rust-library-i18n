//! Muistin allokoinnin sovellusliittymät

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// `AllocError`-virhe osoittaa allokointivirheen, joka voi johtua resurssien ehtymisestä tai jostain vikasta, kun yhdistetään annetut syöteargumentit tähän kohdistimeen.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (tarvitsemme tätä trait-virheen alavirtaan)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// `Allocator`: n toteutus voi allokoida, kasvattaa, kutistaa ja jakaa [`Layout`][]: n kautta kuvattuja mielivaltaisia tietolohkoja.
///
/// `Allocator` on suunniteltu toteutettavaksi ZST: issä, viitteissä tai älykkäissä osoittimissa, koska `MyAlloc([u8; N])`: n kaltaista varainta ei voida siirtää ilman, että päivitettäisiin osoittimia varattuun muistiin.
///
/// Toisin kuin [`GlobalAlloc`][], nollakokoiset allokoinnit ovat sallittuja `Allocator`: ssä.
/// Jos taustalla oleva allokaattori ei tue tätä (kuten jemalloc) tai palauttaa nollaosoittimen (kuten `libc::malloc`), toteutus on kiinni.
///
/// ### Tällä hetkellä varattu muisti
///
/// Jotkut menetelmät edellyttävät, että muistilohko *varataan* tällä hetkellä varaimen kautta.Se tarkoittaa, että:
///
/// * [`allocate`], [`grow`] tai [`shrink`] palautti aiemmin kyseisen muistilohkon aloitusosoitteen ja
///
/// * muistilohkoa ei ole myöhemmin jaettu, jolloin lohkot joko jaetaan suoraan välittämällä [`deallocate`]: lle tai muutettu siirtämällä ne [`grow`]: lle tai [`shrink`]: lle, joka palauttaa `Ok`: n.
///
/// Jos `grow` tai `shrink` ovat palauttaneet `Err`: n, ohitettu osoitin pysyy voimassa.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Muisti sopii
///
/// Jotkut menetelmät edellyttävät, että asettelu *sopii* muistilohkoon.
/// "fit"-asettelulle muistilohko tarkoittaa (tai vastaavasti "fit"-muistilohkolle asettelua), että seuraavien ehtojen on täytyttävä:
///
/// * Lohko on allokoitava samalla linjalla kuin [`layout.align()`], ja
///
/// * Toimitettavan [`layout.size()`]: n on oltava alueella `min ..= max`, jossa:
///   - `min` on lohkon varaamiseen viimeksi käytetyn asettelun koko ja
///   - `max` on viimeisin todellinen koko, joka on palautettu laitteilta [`allocate`], [`grow`] tai [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Aloittimesta palautettujen muistilohkojen on osoitettava kelvolliseen muistiin ja säilytettävä pätevyytensä, kunnes instanssi ja kaikki sen kloonit pudotetaan,
///
/// * allokaattorin kloonaus tai siirtäminen ei saa mitätöidä tästä varaimesta palautettuja muistilohkoja.Kloonatun varaajan on toimittava samalla tavoin kuin sama
///
/// * mikä tahansa osoitin muistilohkoon, joka on [*currently allocated*], voidaan siirtää mihin tahansa muuhun allokaattorin menetelmään.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Yritetään allokoida muistilohko.
    ///
    /// Menestyksessä palauttaa [`NonNull<[u8]>`][NonNull]: n, joka täyttää `layout`: n koon ja linjauksen takuut.
    ///
    /// Palautetulla lohkolla voi olla suurempi koko kuin `layout.size()` on määrittänyt, ja sen sisältö voi olla alustettu tai ei.
    ///
    /// # Errors
    ///
    /// Palauttava `Err` osoittaa, että joko muisti on käytetty loppuun tai `layout` ei täytä varaimen koon tai kohdistuksen rajoituksia.
    ///
    /// Toteutuksia kannustetaan palauttamaan `Err` muistin loppumisen sijaan paniikkiin tai keskeytykseen, mutta tämä ei ole tiukka vaatimus.
    /// (Tarkemmin sanottuna: on *laillista* toteuttaa tämä trait taustalla olevan alkuperäisen allokointikirjaston yläpuolella, joka keskeyttää muistin ehtymisen.)
    ///
    /// Asiakkaita, jotka haluavat keskeyttää laskennan vastauksena allokointivirheeseen, kannustetaan kutsumaan [`handle_alloc_error`]-toiminto sen sijaan, että he vetosivat suoraan `panic!`: ään tai vastaavaan.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Käyttäytyy kuten `allocate`, mutta varmistaa myös, että palautettu muisti nollataan.
    ///
    /// # Errors
    ///
    /// Palauttava `Err` osoittaa, että joko muisti on käytetty loppuun tai `layout` ei täytä varaimen koon tai kohdistuksen rajoituksia.
    ///
    /// Toteutuksia kannustetaan palauttamaan `Err` muistin loppumisen sijaan paniikkiin tai keskeytykseen, mutta tämä ei ole tiukka vaatimus.
    /// (Tarkemmin sanottuna: on *laillista* toteuttaa tämä trait taustalla olevan alkuperäisen allokointikirjaston yläpuolella, joka keskeyttää muistin ehtymisen.)
    ///
    /// Asiakkaita, jotka haluavat keskeyttää laskennan vastauksena allokointivirheeseen, kannustetaan kutsumaan [`handle_alloc_error`]-toiminto sen sijaan, että he vetosivat suoraan `panic!`: ään tai vastaavaan.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // TURVALLISUUS: `alloc` palauttaa kelvollisen muistilohkon
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Jakaa muistin, johon `ptr` viittaa.
    ///
    /// # Safety
    ///
    /// * `ptr` on merkittävä muistilohko [*currently allocated*] tämän varaimen kautta ja
    /// * `layout` täytyy [*fit*] että muistilohko.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Yritetään laajentaa muistilohkoa.
    ///
    /// Palauttaa uuden [`NonNull<[u8]>`][NonNull]: n, joka sisältää osoittimen ja varatun muistin todellisen koon.Osoitin soveltuu `new_layout`: n kuvaamien tietojen säilyttämiseen.
    /// Tämän saavuttamiseksi allokaattori voi laajentaa `ptr`: n viittaamaa allokointia uuden asettelun mukaiseksi.
    ///
    /// Jos tämä palauttaa `Ok`: n, `ptr`: n viittaaman muistilohkon omistusoikeus on siirretty tälle allokaattorille.
    /// Muisti on saattanut vapautua tai olla vapaana, ja sitä on pidettävä käyttökelvottomana, ellei sitä siirretä takaisin soittajalle tämän menetelmän palautusarvon kautta.
    ///
    /// Jos tämä menetelmä palauttaa `Err`: n, muistilohkon omistajuutta ei ole siirretty tälle allokaattorille, ja muistilohkon sisältöä ei muuteta.
    ///
    /// # Safety
    ///
    /// * `ptr` täytyy merkitä muistilohko [*currently allocated*] tämän varaimen kautta.
    /// * `old_layout` täytyy [*fit*] tuoda muistilohko (`new_layout`-argumentin ei tarvitse sovittaa sitä.).
    /// * `new_layout.size()` on oltava suurempi tai yhtä suuri kuin `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Palauttaa `Err`: n, jos uusi asettelu ei vastaa varaajan kokoa ja kohdistimen rajoituksia tai jos kasvaminen muuten epäonnistuu.
    ///
    /// Toteutuksia kannustetaan palauttamaan `Err` muistin loppumisen sijaan paniikkiin tai keskeytykseen, mutta tämä ei ole tiukka vaatimus.
    /// (Tarkemmin sanottuna: on *laillista* toteuttaa tämä trait taustalla olevan alkuperäisen allokointikirjaston yläpuolella, joka keskeyttää muistin ehtymisen.)
    ///
    /// Asiakkaita, jotka haluavat keskeyttää laskennan vastauksena allokointivirheeseen, kannustetaan kutsumaan [`handle_alloc_error`]-toiminto sen sijaan, että he vetosivat suoraan `panic!`: ään tai vastaavaan.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // TURVALLISUUS: koska `new_layout.size()`: n on oltava suurempi tai yhtä suuri kuin
        // `old_layout.size()`, sekä vanha että uusi muistin allokointi ovat kelvollisia lukemisille ja kirjoituksille `old_layout.size()`-tavuille.
        // Koska vanhaa allokaatiota ei ollut vielä jaettu, se ei voi olla päällekkäinen `new_ptr`: n kanssa.
        // Siten puhelu `copy_nonoverlapping`: lle on turvallista.
        // Soittajan on noudatettava `dealloc`: n turvasopimusta.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Käyttäytyy kuten `grow`, mutta varmistaa myös, että uusi sisältö asetetaan nollaksi ennen palauttamista.
    ///
    /// Muistilohko sisältää seuraavan sisällön onnistuneen puhelun jälkeen
    /// `grow_zeroed`:
    ///   * Tavut `0..old_layout.size()` säilytetään alkuperäisestä varauksesta.
    ///   * Tavut `old_layout.size()..old_size` joko säilytetään tai nollataan varaajan toteutuksesta riippuen.
    ///   `old_size` viittaa muistilohkon kokoon ennen `grow_zeroed`-puhelua, joka voi olla suurempi kuin koko, jota alun perin pyydettiin varauksen yhteydessä.
    ///   * Tavut `old_size..new_size` nollataan.`new_size` viittaa `grow_zeroed`-puhelun palauttaman muistilohkon kokoon.
    ///
    /// # Safety
    ///
    /// * `ptr` täytyy merkitä muistilohko [*currently allocated*] tämän varaimen kautta.
    /// * `old_layout` täytyy [*fit*] tuoda muistilohko (`new_layout`-argumentin ei tarvitse sovittaa sitä.).
    /// * `new_layout.size()` on oltava suurempi tai yhtä suuri kuin `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Palauttaa `Err`: n, jos uusi asettelu ei vastaa varaajan kokoa ja kohdistimen rajoituksia tai jos kasvaminen muuten epäonnistuu.
    ///
    /// Toteutuksia kannustetaan palauttamaan `Err` muistin loppumisen sijaan paniikkiin tai keskeytykseen, mutta tämä ei ole tiukka vaatimus.
    /// (Tarkemmin sanottuna: on *laillista* toteuttaa tämä trait taustalla olevan alkuperäisen allokointikirjaston yläpuolella, joka keskeyttää muistin ehtymisen.)
    ///
    /// Asiakkaita, jotka haluavat keskeyttää laskennan vastauksena allokointivirheeseen, kannustetaan kutsumaan [`handle_alloc_error`]-toiminto sen sijaan, että he vetosivat suoraan `panic!`: ään tai vastaavaan.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // TURVALLISUUS: koska `new_layout.size()`: n on oltava suurempi tai yhtä suuri kuin
        // `old_layout.size()`, sekä vanha että uusi muistin allokointi ovat kelvollisia lukemisille ja kirjoituksille `old_layout.size()`-tavuille.
        // Koska vanhaa allokaatiota ei ollut vielä jaettu, se ei voi olla päällekkäinen `new_ptr`: n kanssa.
        // Siten puhelu `copy_nonoverlapping`: lle on turvallista.
        // Soittajan on noudatettava `dealloc`: n turvasopimusta.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Yritetään kutistaa muistilohkoa.
    ///
    /// Palauttaa uuden [`NonNull<[u8]>`][NonNull]: n, joka sisältää osoittimen ja varatun muistin todellisen koon.Osoitin soveltuu `new_layout`: n kuvaamien tietojen säilyttämiseen.
    /// Tämän saavuttamiseksi allokaattori voi pienentää `ptr`: n viittaamaa allokointia uuden asettelun mukaiseksi.
    ///
    /// Jos tämä palauttaa `Ok`: n, `ptr`: n viittaaman muistilohkon omistusoikeus on siirretty tälle allokaattorille.
    /// Muisti on saattanut vapautua tai olla vapaana, ja sitä on pidettävä käyttökelvottomana, ellei sitä siirretä takaisin soittajalle tämän menetelmän palautusarvon kautta.
    ///
    /// Jos tämä menetelmä palauttaa `Err`: n, muistilohkon omistajuutta ei ole siirretty tälle allokaattorille, ja muistilohkon sisältöä ei muuteta.
    ///
    /// # Safety
    ///
    /// * `ptr` täytyy merkitä muistilohko [*currently allocated*] tämän varaimen kautta.
    /// * `old_layout` täytyy [*fit*] tuoda muistilohko (`new_layout`-argumentin ei tarvitse sovittaa sitä.).
    /// * `new_layout.size()` on oltava pienempi tai yhtä suuri kuin `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Palauttaa arvon `Err`, jos uusi asettelu ei vastaa allokaattorin allokoijan kokoa ja kohdistuksen rajoituksia tai jos kutistuminen muuten epäonnistuu.
    ///
    /// Toteutuksia kannustetaan palauttamaan `Err` muistin loppumisen sijaan paniikkiin tai keskeytykseen, mutta tämä ei ole tiukka vaatimus.
    /// (Tarkemmin sanottuna: on *laillista* toteuttaa tämä trait taustalla olevan alkuperäisen allokointikirjaston yläpuolella, joka keskeyttää muistin ehtymisen.)
    ///
    /// Asiakkaita, jotka haluavat keskeyttää laskennan vastauksena allokointivirheeseen, kannustetaan kutsumaan [`handle_alloc_error`]-toiminto sen sijaan, että he vetosivat suoraan `panic!`: ään tai vastaavaan.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // TURVALLISUUS: koska `new_layout.size()`: n on oltava pienempi tai yhtä suuri kuin
        // `old_layout.size()`, sekä vanha että uusi muistin allokointi ovat kelvollisia lukemisille ja kirjoituksille `new_layout.size()`-tavuille.
        // Koska vanhaa allokaatiota ei ollut vielä jaettu, se ei voi olla päällekkäinen `new_ptr`: n kanssa.
        // Siten puhelu `copy_nonoverlapping`: lle on turvallista.
        // Soittajan on noudatettava `dealloc`: n turvasopimusta.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Luo "by reference"-sovittimen tälle `Allocator`-esiintymälle.
    ///
    /// Palautettu sovitin myös toteuttaa `Allocator`: n ja yksinkertaisesti lainaa tämän.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // TURVALLISUUS: soittajan on noudatettava turvasopimusta
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // TURVALLISUUS: soittajan on noudatettava turvasopimusta
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // TURVALLISUUS: soittajan on noudatettava turvasopimusta
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // TURVALLISUUS: soittajan on noudatettava turvasopimusta
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}