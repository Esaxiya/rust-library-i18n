use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Vaikka tätä toimintoa käytetään yhdessä paikassa ja sen toteutus voisi olla linjassa, aikaisemmat yritykset tehdä rustc: stä hitaampaa:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Muistilohkon asettelu.
///
/// `Layout`-esimerkki kuvaa tietyn muistin asettelun.
/// Rakennat `Layout`: n syötteenä antajalle.
///
/// Kaikilla asetteluilla on siihen liittyvä koko ja kahden voiman tasaus.
///
/// (Huomaa, että asetteluiden *ei* tarvitse olla nollasta poikkeavia, vaikka `GlobalAlloc` vaatii, että kaikkien muistipyyntöjen koko ei ole nolla.
/// Soittajan on joko varmistettava, että tämänkaltaiset ehdot täyttyvät, käytettävä tiettyjä jakoelimiä, joilla on tiukemmat vaatimukset, tai käyttää lievempää `Allocator`-liitäntää.
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // pyydetyn muistilohkon koko tavuina mitattuna.
    size_: usize,

    // pyydetyn muistilohkon kohdistus tavuina.
    // Varmistamme, että tämä on aina kahden voimaa, koska `posix_memalign`: n kaltaiset API: t vaativat sitä ja se on kohtuullinen rajoitus asettaa Layout-rakentajille.
    //
    //
    // (Emme kuitenkaan analogisesti vaadi `tasaa>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Muodostaa `Layout`: n tietyistä `size`: stä ja `align`: stä tai palauttaa `LayoutError`: n, jos jokin seuraavista ehdoista ei täyty:
    ///
    /// * `align` ei saa olla nolla,
    ///
    /// * `align` täytyy olla kahden voima,
    ///
    /// * `size`, pyöristettynä `align`: n lähimpään kerrokseen, ei saa ylivuotoa (eli pyöristetyn arvon on oltava pienempi tai yhtä suuri kuin `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (kahden voima merkitsee kohdistusta!=0.)

        // Pyöristetty koko on:
        //   size_rounded_up=(koko + tasaa, 1)&! (tasaa, 1);
        //
        // Tiedämme ylhäältä, että tasaus!=0.
        // Jos lisääminen (kohdista, 1) ei ylitä, pyöristäminen ylöspäin on hieno.
        //
        // Päinvastoin,&peittäminen!-Näppäimellä (tasaa, 1) vähentää vain matalamääräiset bitit.
        // Jos siis summan kanssa esiintyy ylivuotoa,&-maski ei voi vähentää tarpeeksi kumoamaan ylivuotoa.
        //
        //
        // Yllä oleva tarkoittaa, että summauksen ylivuoton tarkistus on sekä välttämätöntä että riittävää.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // TURVALLISUUS: `from_size_align_unchecked`: n ehdot ovat olleet
        // tarkistettu yllä.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Luo asettelun ohittamalla kaikki tarkistukset.
    ///
    /// # Safety
    ///
    /// Tämä toiminto on vaarallinen, koska se ei tarkista [`Layout::from_size_align`]: n ennakkoehtoja.
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // TURVALLISUUS: soittajan on varmistettava, että `align` on suurempi kuin nolla.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Tämän asettelun muistilohkon vähimmäiskoko tavuina.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Tämän asettelun muistilohkon tavujen vähimmäistasaus.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Rakentaa `Layout`: n, joka sopii tyypin `T` arvon pitämiseen.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // TURVALLISUUS: Rust takaa linjauksen kahden ja
        // koko + tasaa-yhdistelmä on taattu, että se sopii osoitetilaamme.
        // Tämän seurauksena käytä tarkastamatonta konstruktoria tässä välttääksesi panics-koodin lisäämistä, ellei sitä ole optimoitu tarpeeksi hyvin.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Tuottaa asettelun, joka kuvaa tietueen, jota voidaan käyttää `T`: n taustarakenteen varaamiseen (joka voi olla trait tai muu kokoinen tyyppi kuin siivu).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // TURVALLISUUS: katso `new`: n perustelut miksi tämä käyttää vaarallista versiota
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Tuottaa asettelun, joka kuvaa tietueen, jota voidaan käyttää `T`: n taustarakenteen varaamiseen (joka voi olla trait tai muu kokoinen tyyppi kuin siivu).
    ///
    /// # Safety
    ///
    /// Tätä toimintoa voidaan soittaa vain, jos seuraavat ehdot täyttyvät:
    ///
    /// - Jos `T` on `Sized`, tämä toiminto on aina turvallinen soittaa.
    /// - Jos `T`: n kokoinen pyrstö on:
    ///     - [slice], viipaleen pituuden on oltava intialisoitu kokonaisluku ja *koko arvon*(dynaamisen hännän pituus + staattisen kokoisen etuliitteen) koon on oltava `isize`.
    ///     - [trait object], osoittimen vtable-osan on osoitettava kelvottoman koerion hankkimalle kelvolliselle vtable-tyypille `T`, ja *koko arvon*(dynaamisen hännän pituus + staattisen kokoinen etuliite) koon on oltava `isize`.
    ///
    ///     - (unstable) [extern type], tämä toiminto on aina turvallinen soittaa, mutta voi panic tai palauttaa muuten väärän arvon, koska ulkoisen tyypin asettelua ei tunneta.
    ///     Tämä on sama käyttäytyminen kuin [`Layout::for_value`], kun viitataan ulkoisen tyyppiseen hännään.
    ///     - muuten tätä toimintoa ei voida kutsua konservatiivisesti.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // TURVALLISUUS: välitämme näiden toimintojen edellytykset soittajalle
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // TURVALLISUUS: katso `new`: n perustelut miksi tämä käyttää vaarallista versiota
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Luo `NonNull`: n, joka on roikkuva, mutta hyvin tasattu tälle asettelulle.
    ///
    /// Huomaa, että osoittimen arvo voi mahdollisesti edustaa kelvollista osoitinta, mikä tarkoittaa, että sitä ei saa käyttää "not yet initialized" sentinel-arvona.
    /// Laiskan varaavien tyyppien on seurattava alustusta muilla tavoilla.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // TURVALLISUUS: tasaus ei taata nollaa
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Luo tietueen kuvaavan asettelun, johon mahtuu sama asettelun arvo kuin `self`, mutta joka on myös kohdistettu kohdistukseen `align` (mitattuna tavuina).
    ///
    ///
    /// Jos `self` täyttää jo määrätyn suuntauksen, palauttaa `self`.
    ///
    /// Huomaa, että tämä menetelmä ei lisää pehmustetta kokonaiskoon riippumatta siitä, onko palautetulla asettelulla erilainen suuntaus.
    /// Toisin sanoen, jos `K`: llä on koko 16, `K.align_to(32)`: llä on edelleen * koko 16.
    ///
    /// Palauttaa virheen, jos `self.size()`: n ja annetun `align`: n yhdistelmä rikkoo [`Layout::from_size_align`]: ssä lueteltuja ehtoja.
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Palauttaa täytteen määrän, joka meidän on lisättävä `self`: n jälkeen varmistaaksemme, että seuraava osoite täyttää `align`: n (mitattuna tavuina).
    ///
    /// Esimerkiksi, jos `self.size()` on 9, niin `self.padding_needed_for(4)` palauttaa arvon 3, koska se on vähimmäismäärä tavuja täytettä, joka vaaditaan 4-kohdistetun osoitteen saamiseksi (olettaen, että vastaava muistilohko alkaa 4-kohdistetusta osoitteesta).
    ///
    ///
    /// Tämän funktion palautusarvolla ei ole merkitystä, jos `align` ei ole kahden teho.
    ///
    /// Huomaa, että palautetun arvon hyödyllisyys edellyttää, että `align` on pienempi tai yhtä suuri kuin koko osoitetun muistilohkon aloitusosoitteen kohdistus.Yksi tapa täyttää tämä rajoitus on varmistaa `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Pyöristetty arvo on:
        //   len_rounded_up=(len + tasaa, 1)&! (tasaa, 1);
        // ja sitten palautamme pehmusteeron: `len_rounded_up - len`.
        //
        // Käytämme modulaarista laskutoimitusta kaikkialla:
        //
        // 1. tasaus on taattu> 0, joten tasaa, 1 on aina voimassa.
        //
        // 2.
        // `len + align - 1` voi ylivuotaa enintään `align - 1`, joten&-maski `!(align - 1)`: llä varmistaa, että ylivuototapauksessa `len_rounded_up` on itse 0.
        //
        //    Täten palautettu pehmuste, kun se lisätään `len`: ään, tuottaa 0, joka triviaalisesti tyydyttää kohdistuksen `align`.
        //
        // (Tietenkin, yritetään allokoida muistilohkoja, joiden koko ja täyte ylivuotavat yllä olevalla tavalla, pitäisi saada kohdistimen joka tapauksessa aikaan virhe.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Luo asettelun pyöristämällä tämän asettelun koon kerrannaisen kerrannaiseksi.
    ///
    ///
    /// Tämä vastaa `padding_needed_for`: n tuloksen lisäämistä asettelun nykyiseen kokoon.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Tämä ei voi ylivuotoa.Lainaus Layoutin invariantista:
        // > `size`, kun pyöristetään ylöspäin `align`: n lähimpään kerrokseen,
        // > ei saa ylittää (eli pyöristetyn arvon on oltava pienempi kuin
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Luo asettelun, joka kuvaa `self`: n `n`-esiintymien tietueen, ja jokaisen välillä on sopiva määrä täytettä sen varmistamiseksi, että kullekin esiintymälle annetaan haluttu koko ja suuntaus.
    /// Menestyksessä palauttaa arvon `(k, offs)`, jossa `k` on taulukon asettelu ja `offs` on matriisin kunkin elementin alun välinen etäisyys.
    ///
    /// Aritmeettisen ylivuoton yhteydessä palauttaa arvon `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Tämä ei voi ylivuotoa.Lainaus Layoutin invariantista:
        // > `size`, kun pyöristetään ylöspäin `align`: n lähimpään kerrokseen,
        // > ei saa ylittää (eli pyöristetyn arvon on oltava pienempi kuin
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // TURVALLISUUS: self.align: n tiedetään jo olevan kelvollinen ja varauksen_koko on ollut
        // jo pehmustettu.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Luo asettelun, joka kuvaa `self`: n ja sen jälkeen `next`: n tietueen, mukaan lukien kaikki tarvittavat pehmusteet sen varmistamiseksi, että `next` kohdistetaan oikein, mutta *ei perää*.
    ///
    /// C-esitysasettelun `repr(C)` sovittamiseksi sinun on soitettava numeroon `pad_to_align`, kun olet laajentanut asettelua kaikilla kentillä.
    /// (Ei ole mitään tapaa sovittaa Rust-oletusesitysasettelua `repr(Rust)`, as it is unspecified.)
    ///
    /// Huomaa, että tuloksena olevan asettelun suuntaus on suurin kuin `self`: n ja `next`: n, jotta varmistetaan molempien osien kohdistus.
    ///
    /// Palauttaa arvon `Ok((k, offset))`, jossa `k` on ketjutetun tietueen asettelu ja `offset` on ketjutettuun tietueeseen upotetun `next`: n alun suhteellinen sijainti tavuina (olettaen, että tietue itse alkaa siirrosta 0).
    ///
    ///
    /// Aritmeettisen ylivuoton yhteydessä palauttaa arvon `LayoutError`.
    ///
    /// # Examples
    ///
    /// `#[repr(C)]`-rakenteen asettelun ja kenttien siirtymien laskeminen sen kenttien asetteluista:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Muista viimeistellä `pad_to_align`: llä!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // testaa, että se toimii
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Luo asettelun, joka kuvaa `self`: n `n`-esiintymien tietueen ilman, että jokaisen esiintymän välillä olisi täyte.
    ///
    /// Huomaa, että toisin kuin `repeat`, `repeat_packed` ei takaa, että toistuvat `self`-esiintymät kohdistetaan oikein, vaikka tietty `self`-esiintymä on kohdistettu oikein.
    /// Toisin sanoen, jos `repeat_packed`: n palauttamaa asettelua käytetään taulukon varaamiseen, ei voida taata, että kaikki matriisin elementit kohdistetaan oikein.
    ///
    /// Aritmeettisen ylivuoton yhteydessä palauttaa arvon `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Luo asettelun, joka kuvaa `self`-tietueen ja sen jälkeen `next`-tietueen ilman, että näiden kahden välillä on lisäpehmusteita.
    /// Koska pehmustetta ei ole asetettu, `next`: n kohdistuksella ei ole merkitystä, eikä sitä ole sisällytetty *ollenkaan* tuloksena olevaan asetteluun.
    ///
    ///
    /// Aritmeettisen ylivuoton yhteydessä palauttaa arvon `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Luo asettelun, joka kuvaa `[T; n]`-tietueen.
    ///
    /// Aritmeettisen ylivuoton yhteydessä palauttaa arvon `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// `Layout::from_size_align`: lle tai muulle `Layout`-konstruktorille annetut parametrit eivät täytä sen dokumentoituja rajoituksia.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (tarvitsemme tätä trait-virheen alavirtaan)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}