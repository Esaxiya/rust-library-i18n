use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Muistinjakolaite, joka voidaan rekisteröidä vakiokirjaston oletuksena `#[global_allocator]`-määritteen kautta.
///
/// Jotkut menetelmät edellyttävät, että muistilohko *varataan* tällä hetkellä varaimen kautta.Se tarkoittaa, että:
///
/// * kyseisen muistilohkon alkuosoite palautettiin aiemmin edellisellä kutsulla allokointimenetelmälle, kuten `alloc`, ja
///
/// * muistilohkoa ei ole myöhemmin jaettu uudelleen, jolloin lohkot jaetaan joko siirtämällä jakaumamenetelmälle, kuten `dealloc`, tai siirtämällä uudelleenjakomenetelmälle, joka palauttaa ei-nollan osoittimen.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// `GlobalAlloc` trait on `unsafe` trait useista syistä, ja toteuttajien on varmistettava, että he noudattavat näitä sopimuksia:
///
/// * Se on määrittelemätöntä käyttäytymistä, jos globaalit allokaattorit rentoutuvat.Tämä rajoitus voidaan poistaa future: ssä, mutta tällä hetkellä panic mistä tahansa näistä toiminnoista voi johtaa muistin turvattomuuteen.
///
/// * `Layout` kyselyiden ja laskelmien on yleensä oltava oikeita.Tämän trait: n soittajat voivat luottaa kullekin menetelmälle määriteltyihin sopimuksiin, ja toteuttajien on varmistettava, että tällaiset sopimukset pysyvät totta.
///
/// * Et voi luottaa tosiasiallisesti tapahtuviin allokaatioihin, vaikka lähteessä olisi nimenomaisia kasa-allokaatioita.
/// Optimoija voi havaita käyttämättömät varaukset, jotka se voi joko eliminoida kokonaan tai siirtyä pinoon eikä siten koskaan kutsua allokaattoria.
/// Optimoija voi lisäksi olettaa, että allokointi on erehtymätöntä, joten koodi, joka aiemmin epäonnistui allokaattorin vikojen takia, voi nyt yhtäkkiä toimia, koska optimoija kiertää allokoinnin tarpeen.
/// Konkreettisemmin seuraava koodiesimerkki on perusteeton, riippumatta siitä, salliko mukautettu varaimesi laskea kuinka monta allokointia on tapahtunut.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Huomaa, että yllä mainitut optimoinnit eivät ole ainoa sovellettava optimointi.Et yleensä voi luottaa kasan jakamiseen, jos ne voidaan poistaa muuttamatta ohjelman käyttäytymistä.
///   Se, tapahtuuko allokoinnit vai ei, ei ole osa ohjelman käyttäytymistä, vaikka se voitaisiin havaita varaimen avulla, joka seuraa allokaatioita tulostamalla tai muuten aiheuttamalla sivuvaikutuksia.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Kohdista muisti annetun `layout`: n kuvaamalla tavalla.
    ///
    /// Palauttaa osoittimen äskettäin varattuun muistiin tai tyhjän osoittamaan allokointivirhettä.
    ///
    /// # Safety
    ///
    /// Tämä toiminto on vaarallinen, koska seurauksena voi olla määrittelemätön toiminta, jos soittaja ei varmista, että `layout`: n koko on nollasta poikkeava.
    ///
    /// (Laajennuksen alaosaajat saattavat tarjota tarkempia rajoja käyttäytymiselle, esim. Taata sentinel-osoite tai nollaosoitin vastauksena nollakokoiseen allokointipyyntöön.)
    ///
    /// Varattu muistilohko voidaan alustaa tai ei.
    ///
    /// # Errors
    ///
    /// Nollaosoittimen palauttaminen osoittaa, että joko muisti on käytetty loppuun tai `layout` ei täytä tämän varaajan koon tai kohdistuksen rajoituksia.
    ///
    /// Toteutuksia kannustetaan palauttamaan tyhjä muistin ehtyminen eikä keskeyttämistä, mutta tämä ei ole tiukka vaatimus.
    /// (Tarkemmin sanottuna: on *laillista* toteuttaa tämä trait taustalla olevan alkuperäisen allokointikirjaston yläpuolella, joka keskeyttää muistin ehtymisen.)
    ///
    /// Asiakkaita, jotka haluavat keskeyttää laskennan vastauksena allokointivirheeseen, kannustetaan kutsumaan [`handle_alloc_error`]-toiminto sen sijaan, että he vetosivat suoraan `panic!`: ään tai vastaavaan.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Kohdista muistilohko annetulle `ptr`-osoittimelle annetulla `layout`: llä.
    ///
    /// # Safety
    ///
    /// Tämä toiminto on vaarallinen, koska määrittelemätöntä käyttäytymistä voi aiheutua, jos soittaja ei takaa kaikkia seuraavista:
    ///
    ///
    /// * `ptr` on merkittävä muistilohko, joka on tällä hetkellä varattu tämän varaimen kautta,
    ///
    /// * `layout` on oltava sama asettelu, jota käytettiin muistilohkon varaamiseen.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Käyttäytyy kuten `alloc`, mutta varmistaa myös, että sisältö asetetaan nollaksi ennen palauttamista.
    ///
    /// # Safety
    ///
    /// Tämä toiminto on vaarallinen samoista syistä kuin `alloc`.
    /// Varatun muistilohkon alustaminen on kuitenkin taattu.
    ///
    /// # Errors
    ///
    /// Nollaosoittimen palauttaminen osoittaa, että joko muisti on käytetty loppuun tai `layout` ei täytä varaajan koon tai kohdistuksen rajoituksia, aivan kuten `alloc`: ssä.
    ///
    /// Asiakkaita, jotka haluavat keskeyttää laskennan vastauksena allokointivirheeseen, kannustetaan kutsumaan [`handle_alloc_error`]-toiminto sen sijaan, että he vetosivat suoraan `panic!`: ään tai vastaavaan.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // TURVALLISUUS: soittajan on noudatettava `alloc`: n turvasopimusta.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // TURVALLISUUS: kun kohdennus onnistui, alue `ptr`: stä
            // `size`-kokoinen taataan olevan voimassa kirjoituksissa.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Kutista tai kasvata muistilohko annettuun `new_size`: ään.
    /// Lohko kuvataan annetulla `ptr`-osoittimella ja `layout`.
    ///
    /// Jos tämä palauttaa ei-nollan osoittimen, `ptr`: n viittaaman muistilohkon omistusoikeus on siirretty tälle allokaattorille.
    /// Muisti on saatettu jakaa tai olla jakamatta, ja sitä on pidettävä käyttökelvottomana (ellei sitä tietenkään siirretty takaisin soittajalle tämän menetelmän palautusarvon kautta).
    /// Uusi muistilohko varataan `layout`: llä, mutta `size` päivitetään arvoon `new_size`.
    /// Tätä uutta asettelua tulisi käyttää, kun uusi muistilohko jaetaan `dealloc`: n kanssa.
    /// Uuden muistilohkon alueella `0..min(layout.size(), new_size) `taataan olevan samat arvot kuin alkuperäisellä lohkolla.
    ///
    /// Jos tämä menetelmä palauttaa nollan, muistilohkon omistajuutta ei ole siirretty tälle varaajalle, ja muistilohkon sisältöä ei muuteta.
    ///
    /// # Safety
    ///
    /// Tämä toiminto on vaarallinen, koska määrittelemätöntä käyttäytymistä voi aiheutua, jos soittaja ei takaa kaikkia seuraavista:
    ///
    /// * `ptr` on jaettava tällä hetkellä tämän jakajan kautta,
    ///
    /// * `layout` on oltava sama asettelu, jota käytettiin muistilohkon varaamiseen,
    ///
    /// * `new_size` on oltava suurempi kuin nolla.
    ///
    /// * `new_size`, pyöristettynä ylöspäin `layout.align()`: n lähimpään kerrokseen, ei saa ylivuotoa (eli pyöristetyn arvon on oltava pienempi kuin `usize::MAX`).
    ///
    /// (Laajennuksen alaosaajat saattavat tarjota tarkempia rajoja käyttäytymiselle, esim. Taata sentinel-osoite tai nollaosoitin vastauksena nollakokoiseen allokointipyyntöön.)
    ///
    /// # Errors
    ///
    /// Palauttaa nollan, jos uusi asettelu ei vastaa allokaattorin koon ja kohdistuksen rajoituksia tai jos uudelleenjakaminen muuten epäonnistuu.
    ///
    /// Toteutuksia kannustetaan palauttamaan tyhjä muistin uupuminen paniikin tai keskeytymisen sijaan, mutta tämä ei ole tiukka vaatimus.
    /// (Tarkemmin sanottuna: on *laillista* toteuttaa tämä trait taustalla olevan alkuperäisen allokointikirjaston yläpuolella, joka keskeyttää muistin ehtymisen.)
    ///
    /// Asiakkaita, jotka haluavat keskeyttää laskennan uudelleenjakovirheen johdosta, kannustetaan kutsumaan [`handle_alloc_error`]-toiminto sen sijaan, että he kutsuvat suoraan `panic!`: ää tai vastaavaa.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // TURVALLISUUS: soittajan on varmistettava, että `new_size` ei ylikuormitu.
        // `layout.align()` tulee `Layout`: stä ja on siten taattu kelvolliseksi.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // TURVALLISUUS: soittajan on varmistettava, että `new_layout` on suurempi kuin nolla.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // TURVALLISUUS: aiemmin varattu lohko ei voi olla päällekkäinen uuden varauksen kanssa.
            // Soittajan on noudatettava `dealloc`: n turvasopimusta.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}