//! Tapoja luoda `str` tavuista.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Muuntaa tavusektion merkkijonoksi.
///
/// Merkkijono ([`&str`]) on valmistettu tavuista ([`u8`]) ja tavuosa ([`&[u8]`][byteslice]) on tehty tavuista, joten tämä toiminto muuntuu näiden kahden välillä.
/// Kaikki tavut eivät ole kelvollisia merkkijonoviipaleita, mutta [`&str`] vaatii, että se on kelvollinen UTF-8.
/// `from_utf8()` tarkistaa, että tavut ovat kelvollisia UTF-8, ja suorittaa sitten muunnoksen.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Jos olet varma, että tavulohko on kelvollinen UTF-8, etkä halua aiheuttaa oikeellisuustarkastuksen yleiskustannuksia, toiminnosta on vaarallinen versio [`from_utf8_unchecked`], jolla on sama käyttäytyminen, mutta se ohittaa tarkistuksen.
///
///
/// Jos tarvitset `String`: n `&str`: n sijaan, harkitse [`String::from_utf8`][string]: ää.
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Koska voit sijoittaa `[u8; N]`: n pinoon ja ottaa [`&[u8]`][byteslice]: n, tämä toiminto on yksi tapa saada pinolle allokoitu merkkijono.Tästä on esimerkki alla olevassa esimerkkiosassa.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Palauttaa arvon `Err`, jos osa ei ole UTF-8, ja kuvaus siitä, miksi annettu osa ei ole UTF-8.
///
/// # Examples
///
/// Peruskäyttö:
///
/// ```
/// use std::str;
///
/// // jotkut tavut-vektorissa
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Tiedämme, että nämä tavut ovat kelvollisia, joten käytä vain `unwrap()`: ää.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Virheelliset tavut:
///
/// ```
/// use std::str;
///
/// // joitain virheellisiä tavuja vector: ssä
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Lisätietoja palautettavissa olevista virheistä on [`Utf8Error`]: n asiakirjoissa.
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // jotkut tavut pinon allokoidussa taulukossa
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Tiedämme, että nämä tavut ovat kelvollisia, joten käytä vain `unwrap()`: ää.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // TURVALLISUUS: Juuri suoritettu vahvistus.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Muuntaa tavuista muutettavan osion muutettavaksi merkkijonoksi.
///
/// # Examples
///
/// Peruskäyttö:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" muuttuvana vektori
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Koska tiedämme, että nämä tavut ovat kelvollisia, voimme käyttää `unwrap()`: ää
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Virheelliset tavut:
///
/// ```
/// use std::str;
///
/// // Joitakin virheellisiä tavuja muutettavissa olevassa vector: ssä
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Lisätietoja palautettavissa olevista virheistä on [`Utf8Error`]: n asiakirjoissa.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // TURVALLISUUS: Juuri suoritettu vahvistus.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Muuntaa osan tavuista merkkijonolohkoksi tarkistamatta, että merkkijono sisältää kelvollisen UTF-8: n.
///
/// Katso turvallisesta versiosta [`from_utf8`] lisätietoja.
///
/// # Safety
///
/// Tämä toiminto on vaarallinen, koska se ei tarkista, että sille välitetyt tavut ovat kelvollisia UTF-8.
/// Jos tätä rajoitusta rikotaan, seurauksena on määrittelemätön käyttäytyminen, koska muu Rust olettaa, että [`&str`]: t ovat kelvollisia UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Peruskäyttö:
///
/// ```
/// use std::str;
///
/// // jotkut tavut-vektorissa
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // TURVALLISUUS: soittajan on taattava, että tavut `v` ovat kelvollisia UTF-8.
    // Luottaa myös siihen, että `&str`: llä ja `&[u8]`: llä on sama asettelu.
    unsafe { mem::transmute(v) }
}

/// Muuntaa tavuosan merkkijonosiiveksi tarkistamatta, että merkkijono sisältää kelvollisen UTF-8: n;muutettava versio.
///
///
/// Katso muuttumaton versio [`from_utf8_unchecked()`] saadaksesi lisätietoja.
///
/// # Examples
///
/// Peruskäyttö:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // TURVALLISUUS: soittajan on taattava, että tavut `v`
    // ovat kelvollisia UTF-8, joten valettu `*mut str`: ään on turvallista.
    // Osoittimen poikkeaminen on myös turvallista, koska kyseinen osoitin tulee viitteestä, joka taataan olevan voimassa kirjoituksissa.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}