//! Trait-toteutukset mallille `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Toteuttaa merkkijonojen järjestyksen.
///
/// Merkkijonot on järjestetty [lexicographically](Ord#lexicographical-comparison) niiden tavuarvojen mukaan.
/// Tämä tilaa Unicode-koodipisteet niiden sijainnin perusteella koodikaavioissa.
/// Tämä ei välttämättä ole sama kuin "alphabetical"-järjestys, joka vaihtelee kielen ja kielen mukaan.
/// Merkkijonojen lajittelu kulttuurisesti hyväksyttyjen standardien mukaan edellyttää aluekohtaisia tietoja, jotka eivät kuulu `str`-tyypin piiriin.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Toteuttaa merkkijonojen vertailutoiminnot.
///
/// Merkkijonoja verrataan [lexicographically](Ord#lexicographical-comparison): iin tavuarvoillaan.
/// Tämä vertaa Unicode-koodipisteitä niiden sijainnin perusteella koodikaavioissa.
/// Tämä ei välttämättä ole sama kuin "alphabetical"-järjestys, joka vaihtelee kielen ja kielen mukaan.
/// Merkkijonojen vertaaminen kulttuurisesti hyväksyttyjen standardien mukaisesti edellyttää aluekohtaista tietoa, joka ei kuulu `str`-tyypin piiriin.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Toteuttaa alimerkkileikkauksen syntaksilla `&self[..]` tai `&mut self[..]`.
///
/// Palauttaa osion koko merkkijonosta, ts. Palauttaa `&self` tai `&mut self`.Vastaa sanaa `&self [0 ..
/// len] `tai`&muttaa itsesi [0 ..
/// len]`.
/// Toisin kuin muut indeksointitoiminnot, tämä ei voi koskaan olla panic.
///
/// Tämä toiminto on *O*(1).
///
/// Ennen 1.20.0: tä näitä indeksointitoimintoja tuettiin edelleen `Index`: n ja `IndexMut`: n suoralla toteutuksella.
///
/// Vastaa `&self[0 .. len]` tai `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Toteuttaa alimerkkileikkauksen syntaksilla `&self[begin .. end]` tai `&mut self[begin .. end]`.
///
/// Palauttaa annetun merkkijonon siiman tavualueelta [`aloita`, `end`).
///
/// Tämä toiminto on *O*(1).
///
/// Ennen 1.20.0: tä näitä indeksointitoimintoja tuettiin edelleen `Index`: n ja `IndexMut`: n suoralla toteutuksella.
///
/// # Panics
///
/// Panics, jos `begin` tai `end` ei osoita merkin alkutavasiirtymää (määritelty `is_char_boundary`: llä), jos `begin > end` tai `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // nämä tulevat panic:
/// // tavu 2 sijaitsee `ö`: ssä:
/// // &s [2 .3];
///
/// // tavu 8 sijaitsee `老`&s: ssä [1 ..
/// // 8];
///
/// // tavu 100 on merkkijonon&s [3 .. ulkopuolella.
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // TURVALLISUUS: tarkista vain, että `start` ja `end` ovat hiiren rajalla,
            // ja ohitamme turvallisen viitteen, joten paluuarvo on myös yksi.
            // Tarkistimme myös hiiren rajat, joten tämä on kelvollinen UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // TURVALLISUUS: tarkista vain, että `start` ja `end` ovat hiiren rajalla.
            // Tiedämme, että osoitin on ainutlaatuinen, koska saimme sen `slice`: ltä.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // TURVALLISUUS: soittaja takaa, että `self` on `slice`: n rajoissa
        // joka täyttää kaikki `add`: n ehdot.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // TURVALLISUUS: katso `get_unchecked`: n kommentit.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary tarkistaa, että hakemisto on kohdassa [0, .len()] ei voi käyttää `get`: ää uudelleen kuten yllä, NLL-ongelmien takia
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // TURVALLISUUS: tarkista vain, että `start` ja `end` ovat hiiren rajalla,
            // ja ohitamme turvallisen viitteen, joten paluuarvo on myös yksi.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Toteuttaa alimerkkileikkauksen syntaksilla `&self[.. end]` tai `&mut self[.. end]`.
///
/// Palauttaa tietyn merkkijonon siiman tavualueelta [``0``, `end`).
/// Vastaa `&self[0 .. end]` tai `&mut self[0 .. end]`.
///
/// Tämä toiminto on *O*(1).
///
/// Ennen 1.20.0: tä näitä indeksointitoimintoja tuettiin edelleen `Index`: n ja `IndexMut`: n suoralla toteutuksella.
///
/// # Panics
///
/// Panics, jos `end` ei osoita merkin alkutavuesiirtymää (määritelty `is_char_boundary`: llä) tai jos `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // TURVALLISUUS: tarkisti juuri, että `end` on hiirellä,
            // ja ohitamme turvallisen viitteen, joten paluuarvo on myös yksi.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // TURVALLISUUS: tarkisti juuri, että `end` on hiirellä,
            // ja ohitamme turvallisen viitteen, joten paluuarvo on myös yksi.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // TURVALLISUUS: tarkisti juuri, että `end` on hiirellä,
            // ja ohitamme turvallisen viitteen, joten paluuarvo on myös yksi.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Toteuttaa alimerkkileikkauksen syntaksilla `&self[begin ..]` tai `&mut self[begin ..]`.
///
/// Palauttaa annetun merkkijonon siiman tavualueelta [`aloita`, `len`).Vastaa `` itseä ...
/// len] `tai`&muttaa itsesi [aloita ..
/// len]`.
///
/// Tämä toiminto on *O*(1).
///
/// Ennen 1.20.0: tä näitä indeksointitoimintoja tuettiin edelleen `Index`: n ja `IndexMut`: n suoralla toteutuksella.
///
/// # Panics
///
/// Panics, jos `begin` ei osoita merkin alkutavuesiirtymää (määritelty `is_char_boundary`: llä) tai jos `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // TURVALLISUUS: tarkisti juuri, että `start` on hiirellä,
            // ja ohitamme turvallisen viitteen, joten paluuarvo on myös yksi.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // TURVALLISUUS: tarkisti juuri, että `start` on hiirellä,
            // ja ohitamme turvallisen viitteen, joten paluuarvo on myös yksi.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // TURVALLISUUS: soittaja takaa, että `self` on `slice`: n rajoissa
        // joka täyttää kaikki `add`: n ehdot.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // TURVALLISUUS: identtinen `get_unchecked`: n kanssa.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // TURVALLISUUS: tarkisti juuri, että `start` on hiirellä,
            // ja ohitamme turvallisen viitteen, joten paluuarvo on myös yksi.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Toteuttaa alimerkkileikkauksen syntaksilla `&self[begin ..= end]` tai `&mut self[begin ..= end]`.
///
/// Palauttaa osion annetusta merkkijonosta tavualueelta [`begin`, `end`].Vastaava kuin `&self [begin .. end + 1]` tai `&mut self[begin .. end + 1]`, paitsi jos `end`: llä on `usize`: n enimmäisarvo.
///
/// Tämä toiminto on *O*(1).
///
/// # Panics
///
/// Panics, jos `begin` ei osoita merkin alkutavuesiirtymää (määritelty `is_char_boundary`: llä), jos `end` ei osoita merkin lopputavuesiirtoa (`end + 1` on joko aloitustavun siirtymä tai yhtä suuri kuin `len`), jos `begin > end` tai jos `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // TURVALLISUUS: soittajan on noudatettava `get_unchecked`: n turvasopimusta.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // TURVALLISUUS: soittajan on noudatettava `get_unchecked_mut`: n turvasopimusta.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Toteuttaa alimerkkileikkauksen syntaksilla `&self[..= end]` tai `&mut self[..= end]`.
///
/// Palauttaa osion annetusta merkkijonosta tavualueelta [0, `end`].
/// Vastaava kuin `&self [0 .. end + 1]`, paitsi jos `end`: llä on `usize`: n enimmäisarvo.
///
/// Tämä toiminto on *O*(1).
///
/// # Panics
///
/// Panics, jos `end` ei osoita merkin lopputavuesiirtoa (`end + 1` on joko aloitustavuesiirto, kuten `is_char_boundary` määrittelee, tai yhtä suuri kuin `len`), tai jos `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // TURVALLISUUS: soittajan on noudatettava `get_unchecked`: n turvasopimusta.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // TURVALLISUUS: soittajan on noudatettava `get_unchecked_mut`: n turvasopimusta.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Jäsennä arvo merkkijonosta
///
/// `FromStr`: n [`from_str`]-menetelmää käytetään usein implisiittisesti [[str`]: n [`parse`]-menetelmän kautta.
/// Katso esimerkkejä [Parse`]-oppaasta.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` ei ole elinikäistä parametria, joten voit jäsentää vain tyypit, jotka eivät sisällä elinikäistä parametria.
///
/// Toisin sanoen, voit jäsentää `i32`: n `FromStr`: n kanssa, mutta et `&i32`: ää.
/// Voit jäsentää rakenteen, joka sisältää `i32`: n, mutta ei sellaista, joka sisältää `&i32`: n.
///
/// # Examples
///
/// `FromStr`: n perustoteutus esimerkkityypille `Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Liittyvä virhe, joka voidaan palauttaa jäsentämällä.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Jäsennys merkkijono `s` palauttaa tämän tyyppisen arvon.
    ///
    /// Jos jäsentäminen onnistuu, palauta arvo [`Ok`]: n sisällä, muuten kun merkkijono on huonosti muotoiltu, palauta sisäiselle [`Err`]: lle ominainen virhe.
    /// Virhetyyppi on erityinen trait-sovelluksen käyttöönotolle.
    ///
    /// # Examples
    ///
    /// Peruskäyttö [`i32`]: n kanssa, tyyppi, joka toteuttaa `FromStr`: n:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Jäsennys `bool` merkkijonosta.
    ///
    /// Antaa `Result<bool, ParseBoolError>`: n, koska `s` voi olla tai ei välttämättä olla jäsennettävissä.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Huomaa, että monissa tapauksissa `.parse()`-menetelmä `str`: ssä on sopivampi.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}