//! Merkkijono manipulointi.
//!
//! Katso lisätietoja [`std::str`]-moduulista.
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. rajojen ulkopuolella
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. alku <=loppu
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. merkkiraja
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // löytää merkki
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` on oltava pienempi kuin len ja hiiren rajan
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Palauttaa `self`: n pituuden.
    ///
    /// Tämä pituus on tavuina, ei [merkkejä] tai grafeemeja.
    /// Toisin sanoen ihminen ei välttämättä pidä merkkijonon pituutta.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // fancy f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Palauttaa arvon `true`, jos `self`: n pituus on nolla tavua.
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Tarkistaa, että "indeksin" kolmas tavu on UTF-8-koodipistejärjestyksen ensimmäinen tavu tai merkkijonon loppu.
    ///
    ///
    /// Merkkijonon alku ja loppu (kun `index== self.len()`) katsotaan rajoiksi.
    ///
    /// Palauttaa arvon `false`, jos `index` on suurempi kuin `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // `老`: n alku
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // `ö`: n toinen tavu
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // `老`: n kolmas tavu
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 ja len ovat aina kunnossa.
        // Testi 0: lle nimenomaisesti, jotta se voi optimoida tarkistuksen helposti ja ohittaa merkkijonotietojen lukemisen kyseiselle tapaukselle.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Tämä on bittimaagia, joka vastaa: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Muuntaa merkkijonosiiton tavuiksi.
    /// Jos haluat muuntaa tavuosan takaisin merkkijonoksi, käytä [`from_utf8`]-toimintoa.
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // TURVALLISUUS: const-ääni, koska muunnetaan kaksi tyyppiä samalla asettelulla
        unsafe { mem::transmute(self) }
    }

    /// Muuntaa muutettavan merkkijonolohkon muuttuvaksi tavuksi.
    ///
    /// # Safety
    ///
    /// Soittajan on varmistettava, että leikkeen sisältö on kelvollinen UTF-8 ennen lainan päättymistä ja taustalla olevan `str`: n käyttöä.
    ///
    ///
    /// `str`: n käyttö, jonka sisältö ei kelpaa UTF-8, on määrittelemätöntä käyttäytymistä.
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // TURVALLISUUS: valettu `&str`-`&[u8]` on turvallinen `str`: n jälkeen
        // on sama asettelu kuin `&[u8]` (vain libstd voi antaa tämän takuun).
        // Osoittimen poikkeama on turvallista, koska se tulee muutettavasta viitteestä, joka taataan olevan voimassa kirjoituksissa.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Muuntaa merkkijonolohkon raakaosoittimeksi.
    ///
    /// Koska merkkijonoviipaleet ovat tavuina, raaka osoitin osoittaa [`u8`]: ään.
    /// Tämä osoitin osoittaa merkkijonolohkon ensimmäiseen tavuun.
    ///
    /// Soittajan on varmistettava, että palautettua osoitinta ei koskaan kirjoiteta.
    /// Jos joudut muokkaamaan merkkijonolohkon sisältöä, käytä [`as_mut_ptr`]: ää.
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Muuntaa muutettavan merkkijonolohkon raakaosoittimeksi.
    ///
    /// Koska merkkijonoviipaleet ovat tavuina, raaka osoitin osoittaa [`u8`]: ään.
    /// Tämä osoitin osoittaa merkkijonolohkon ensimmäiseen tavuun.
    ///
    /// Sinun vastuullasi on varmistaa, että merkkijonolohkoa muokataan vain siten, että se pysyy voimassa UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Palauttaa `str`: n osajoukon.
    ///
    /// Tämä on ei-paniikkivaihtoehto `str`: n indeksoinnille.
    /// Palauttaa [`None`] aina, kun vastaava indeksointitoiminto olisi panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // indeksit eivät UTF-8-sekvenssirajoilla
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // rajojen ulkopuolella
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Palauttaa `str`: n muutettavan osajoukon.
    ///
    /// Tämä on ei-paniikkivaihtoehto `str`: n indeksoinnille.
    /// Palauttaa [`None`] aina, kun vastaava indeksointitoiminto olisi panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // oikea pituus
    /// assert!(v.get_mut(0..5).is_some());
    /// // rajojen ulkopuolella
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Palauttaa `str`: n tarkistamattoman osajoukon.
    ///
    /// Tämä on tarkistamaton vaihtoehto `str`: n indeksoinnille.
    ///
    /// # Safety
    ///
    /// Tämän toiminnon soittajat ovat vastuussa siitä, että nämä edellytykset täyttyvät:
    ///
    /// * Aloitusindeksi ei saa ylittää loppuindeksiä;
    /// * Hakemistojen on oltava alkuperäisen leikkeen rajojen sisällä;
    /// * Hakemistojen on oltava UTF-8-sekvenssirajoilla.
    ///
    /// Muussa tapauksessa palautettu merkkijono voi viitata virheelliseen muistiin tai rikkoa `str`-tyypin ilmoittamia invarianteja.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // TURVALLISUUS: soittajan on noudatettava `get_unchecked`: n turvasopimusta;
        // viipale on viitattavissa, koska `self` on turvallinen viite.
        // Palautettu osoitin on turvallinen, koska `SliceIndex`: n implisiittien on taattava, että se on.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Palauttaa `str`: n muutettavan, tarkistamattoman aliosan.
    ///
    /// Tämä on tarkistamaton vaihtoehto `str`: n indeksoinnille.
    ///
    /// # Safety
    ///
    /// Tämän toiminnon soittajat ovat vastuussa siitä, että nämä edellytykset täyttyvät:
    ///
    /// * Aloitusindeksi ei saa ylittää loppuindeksiä;
    /// * Hakemistojen on oltava alkuperäisen leikkeen rajojen sisällä;
    /// * Hakemistojen on oltava UTF-8-sekvenssirajoilla.
    ///
    /// Muussa tapauksessa palautettu merkkijono voi viitata virheelliseen muistiin tai rikkoa `str`-tyypin ilmoittamia invarianteja.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // TURVALLISUUS: soittajan on noudatettava `get_unchecked_mut`: n turvasopimusta;
        // viipale on viitattavissa, koska `self` on turvallinen viite.
        // Palautettu osoitin on turvallinen, koska `SliceIndex`: n implisiittien on taattava, että se on.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Luo merkkijonolohkon toisesta merkkijonolohkosta ohittaen turvatarkastukset.
    ///
    /// Tätä ei yleensä suositella, käytä varoen!Katso turvallinen vaihtoehto kohdista [`str`] ja [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Tämä uusi osa siirtyy `begin`: stä `end`: ään, mukaan lukien `begin`, mutta ilman `end`: ää.
    ///
    /// Jos haluat saada muutettavan merkkijonolohkon, katso [`slice_mut_unchecked`]-menetelmä.
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Tämän toiminnon soittajat ovat vastuussa siitä, että kolme edellytystä täyttyvät:
    ///
    /// * `begin` ei saa ylittää arvoa `end`.
    /// * `begin` ja `end`: n on oltava tavuasemat merkkijonolohkossa.
    /// * `begin` ja `end`: n on oltava UTF-8-sekvenssirajoilla.
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // TURVALLISUUS: soittajan on noudatettava `get_unchecked`: n turvasopimusta;
        // viipale on viitattavissa, koska `self` on turvallinen viite.
        // Palautettu osoitin on turvallinen, koska `SliceIndex`: n implisiittien on taattava, että se on.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Luo merkkijonolohkon toisesta merkkijonolohkosta ohittaen turvatarkastukset.
    /// Tätä ei yleensä suositella, käytä varoen!Katso turvallinen vaihtoehto kohdista [`str`] ja [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Tämä uusi osa siirtyy `begin`: stä `end`: ään, mukaan lukien `begin`, mutta ilman `end`: ää.
    ///
    /// Jos haluat saada muuttumattoman merkkijonolohkon, katso [`slice_unchecked`]-menetelmä.
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Tämän toiminnon soittajat ovat vastuussa siitä, että kolme edellytystä täyttyvät:
    ///
    /// * `begin` ei saa ylittää arvoa `end`.
    /// * `begin` ja `end`: n on oltava tavuasemat merkkijonolohkossa.
    /// * `begin` ja `end`: n on oltava UTF-8-sekvenssirajoilla.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // TURVALLISUUS: soittajan on noudatettava `get_unchecked_mut`: n turvasopimusta;
        // viipale on viitattavissa, koska `self` on turvallinen viite.
        // Palautettu osoitin on turvallinen, koska `SliceIndex`: n implisiittien on taattava, että se on.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Jaa yksi merkkijono viipaleeksi kahdeksi hakemistossa.
    ///
    /// Argumentin `mid` tulisi olla tavun siirtymä merkkijonon alusta.
    /// Sen on oltava myös UTF-8-koodipisteen rajalla.
    ///
    /// Kaksi palattua viipaletta menevät merkkijonolohkon alusta kohtaan `mid` ja `mid`: stä merkkijonolohkon loppuun.
    ///
    /// Jos haluat saada muutettavissa olevat merkkijonoviipaleet, katso [`split_at_mut`]-menetelmä.
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics, jos `mid` ei ole UTF-8-koodipisteen rajalla tai jos se on merkkijonolohkon viimeisen koodipisteen lopussa.
    ///
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary tarkistaa, että hakemisto on kohdassa [0, .len()]
        if self.is_char_boundary(mid) {
            // TURVALLISUUS: tarkista vain, että `mid` on hiiren rajalla.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Jaa yksi muutettava merkkijono siivu kahdeksi hakemistossa.
    ///
    /// Argumentin `mid` tulisi olla tavun siirtymä merkkijonon alusta.
    /// Sen on oltava myös UTF-8-koodipisteen rajalla.
    ///
    /// Kaksi palattua viipaletta menevät merkkijonolohkon alusta kohtaan `mid` ja `mid`: stä merkkijonolohkon loppuun.
    ///
    /// Jos haluat saada muuttumattomia merkkijonoviipaleita, katso [`split_at`]-menetelmä.
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics, jos `mid` ei ole UTF-8-koodipisteen rajalla tai jos se on merkkijonolohkon viimeisen koodipisteen lopussa.
    ///
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary tarkistaa, että hakemisto on kohdassa [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // TURVALLISUUS: tarkista vain, että `mid` on hiiren rajalla.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Palauttaa iteraattorin merkkijonolohkon [`char ']: n yli.
    ///
    /// Koska merkkijonolohko koostuu kelvollisesta UTF-8: stä, voimme iteroida merkkijonolohkon läpi [`char`]: llä.
    /// Tämä menetelmä palauttaa tällaisen iteraattorin.
    ///
    /// On tärkeää muistaa, että [`char`] edustaa Unicode-skalaariarvoa ja ei välttämättä vastaa ideasi 'character': stä.
    ///
    /// Toisto grafeemiklustereissa voi olla mitä todella haluat.
    /// Tätä toimintoa ei tarjoa Rust: n vakiokirjasto, tarkista sen sijaan crates.io.
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Muista, että [`` hiiret '' eivät välttämättä sovi intuitioon hahmoista:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // ei 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Palauttaa iteraattorin merkkijono-osion ja niiden sijaintien yli.
    ///
    /// Koska merkkijonolohko koostuu kelvollisesta UTF-8: stä, voimme iteroida merkkijonolohkon läpi [`char`]: llä.
    /// Tämä menetelmä palauttaa näiden [merkkien] iteraattorin sekä niiden tavuasennot.
    ///
    /// Iteraattori tuottaa joukon.Asema on ensimmäinen, [`char`] on toinen.
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Muista, että [`` hiiret '' eivät välttämättä sovi intuitioon hahmoista:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // ei (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // huomaa kolme tässä, viimeinen merkki vie kaksi tavua
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Iteraattori merkkijonolohkon tavuilla.
    ///
    /// Koska merkkijono-osio koostuu tavusekvenssistä, voimme iteroida merkkijono-osion tavuina.
    /// Tämä menetelmä palauttaa tällaisen iteraattorin.
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Jakaa merkkijonoviivan välilyönnillä.
    ///
    /// Palautettu iteraattori palauttaa merkkijonoviipaleet, jotka ovat alkuperäisen merkkijonolohkon osioita, erotettuna millä tahansa välilyönnillä.
    ///
    ///
    /// 'Whitespace' on määritelty Unicode-johdetun ydinomaisuuden `White_Space` ehtojen mukaisesti.
    /// Jos haluat jakaa sen sijaan vain ASCII-välilyöntiin, käytä [`split_ascii_whitespace`]: ää.
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Kaikenlaisia välilyöntejä pidetään:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Jakaa merkkijonosi ASCII-välilyönnillä.
    ///
    /// Palautettu iteraattori palauttaa merkkijonoviipaleet, jotka ovat alkuperäisen merkkijonolohkon osioita, erotettuna millä tahansa määrällä ASCII-välilyöntejä.
    ///
    ///
    /// Jos haluat jakaa sen sijaan Unicode `Whitespace`: llä, käytä [`split_whitespace`]: ää.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Kaikenlaisia ASCII-välilyöntejä pidetään:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Iteraattori merkkijonon viivojen yli merkkijonoina.
    ///
    /// Rivit päättyvät joko uudella rivillä (`\n`) tai rivinvaihdolla rivin syötöllä (`\r\n`).
    ///
    /// Viimeisen rivin loppu on valinnainen.
    /// Merkkijono, joka päättyy viimeisen rivin loppuun, palauttaa samat rivit kuin muuten identtinen merkkijono ilman viimeisen rivin loppua.
    ///
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Viimeisen rivin loppua ei vaadita:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Iteraattori merkkijonon viivojen yli.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Palauttaa `u16`: n iteraattorin UTF-16: ksi koodatun merkkijonon yli.
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Palauttaa arvon `true`, jos annettu kuvio vastaa tämän merkkijonon osaa.
    ///
    /// Palauttaa `false`: n, jos ei.
    ///
    /// [pattern] voi olla `&str`, [`char`], leike [hiilejä] tai funktio tai sulkeminen, joka määrittää, täyttääkö merkki merkin.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Palauttaa `true`, jos annettu kuvio vastaa tämän merkkijonon etuliitettä.
    ///
    /// Palauttaa `false`: n, jos ei.
    ///
    /// [pattern] voi olla `&str`, [`char`], leike [hiilejä] tai funktio tai sulkeminen, joka määrittää, täyttääkö merkki merkin.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Palauttaa arvon `true`, jos annettu kuvio vastaa tämän merkkijonon jälkiliitettä.
    ///
    /// Palauttaa `false`: n, jos ei.
    ///
    /// [pattern] voi olla `&str`, [`char`], leike [hiilejä] tai funktio tai sulkeminen, joka määrittää, täyttääkö merkki merkin.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Palauttaa tämän merkkijonolohkon ensimmäisen merkin tavuindeksin, joka vastaa mallia.
    ///
    /// Palauttaa [`None`], jos kuvio ei täsmää.
    ///
    /// [pattern] voi olla `&str`, [`char`], leike [hiilejä] tai funktio tai sulkeminen, joka määrittää, täyttääkö merkki merkin.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Yksinkertaiset mallit:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Monimutkaisemmat kuviot, joissa on pisteettömät tyylit ja sulkimet:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Ei löydä mallia:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Palauttaa tavuindeksin kuvion oikeanpuolimmassa osumassa olevan merkin ensimmäiselle merkille tässä merkkijonossa.
    ///
    /// Palauttaa [`None`], jos kuvio ei täsmää.
    ///
    /// [pattern] voi olla `&str`, [`char`], leike [hiilejä] tai funktio tai sulkeminen, joka määrittää, täyttääkö merkki merkin.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Yksinkertaiset mallit:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Monimutkaisemmat kuviot sulkimilla:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Ei löydä mallia:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Iteraattori tämän merkkijonolohkon alaosassa, erotettu merkillä, johon on sovitettu kuvio.
    ///
    /// [pattern] voi olla `&str`, [`char`], leike [hiilejä] tai funktio tai sulkeminen, joka määrittää, täyttääkö merkki merkin.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteraattorin käyttäytyminen
    ///
    /// Palautettu iteraattori on [`DoubleEndedIterator`], jos kuvio sallii käänteisen haun ja forward/reverse-haku tuottaa samat elementit.
    /// Tämä pätee esimerkiksi [`char`]: ään, mutta ei `&str`: ään.
    ///
    /// Jos malli sallii käänteisen haun, mutta sen tulokset saattavat poiketa etsinnästä, voidaan käyttää [`rsplit`]-menetelmää.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Yksinkertaiset mallit:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Jos kuvio on viipale merkkejä, jaa jokaisen merkin esiintymän kohdalla:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Monimutkaisempi malli, jossa on suljin:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Jos merkkijono sisältää useita vierekkäisiä erottimia, lopputuloksessa on tyhjät merkkijonot:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Viereiset erottimet erotetaan tyhjällä merkkijonolla.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Merkkijonon alussa tai lopussa olevia erottimia ympäröivät tyhjät merkkijonot.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Kun tyhjää merkkijonoa käytetään erottimena, se erottaa merkkijonon kaikki merkit merkkijonon alun ja lopun kanssa.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Vierekkäiset erottimet voivat johtaa mahdollisesti yllättävään käyttäytymiseen, kun erotinta käytetään tyhjää tilaa.Tämä koodi on oikea:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// _not_ antaa sinulle:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Käytä [`split_whitespace`] tätä käyttäytymistä varten.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Iteraattori tämän merkkijonolohkon alaosassa, erotettu merkillä, johon on sovitettu kuvio.
    /// Erot `split`: n tuottamasta iteraattorista siinä, että `split_inclusive` jättää sovitetun osan alimerkkijonon päätteeksi.
    ///
    ///
    /// [pattern] voi olla `&str`, [`char`], leike [hiilejä] tai funktio tai sulkeminen, joka määrittää, täyttääkö merkki merkin.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Jos merkkijonon viimeinen elementti sovitetaan yhteen, kyseistä elementtiä pidetään edellisen alimerkkijonon päättäjänä.
    /// Tämä alimerkkijono on viimeinen iteraattorin palauttama kohde.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Iteraattori annetun merkkijonolohkon alaosien yli, erotettuna merkillä, jotka on sovitettu malliin ja saatu päinvastaisessa järjestyksessä.
    ///
    /// [pattern] voi olla `&str`, [`char`], leike [hiilejä] tai funktio tai sulkeminen, joka määrittää, täyttääkö merkki merkin.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteraattorin käyttäytyminen
    ///
    /// Palautettu iteraattori edellyttää, että kuvio tukee käänteistä hakua, ja se on [`DoubleEndedIterator`], jos forward/reverse-haku tuottaa samat elementit.
    ///
    ///
    /// Edestä iteroimiseksi voidaan käyttää [`split`]-menetelmää.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Yksinkertaiset mallit:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Monimutkaisempi malli, jossa on suljin:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Iteraattori annetun merkkijonolohkon alaosien yli, erotettuna merkillä, johon on sovitettu kuvio.
    ///
    /// [pattern] voi olla `&str`, [`char`], leike [hiilejä] tai funktio tai sulkeminen, joka määrittää, täyttääkö merkki merkin.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Vastaava kuin [`split`], paitsi että takalevy ohitetaan, jos se on tyhjä.
    ///
    /// [`split`]: str::split
    ///
    /// Tätä menetelmää voidaan käyttää merkkijonotiedoissa, jotka ovat _terminated_, eikä mallin mukaan _separated_.
    ///
    /// # Iteraattorin käyttäytyminen
    ///
    /// Palautettu iteraattori on [`DoubleEndedIterator`], jos kuvio sallii käänteisen haun ja forward/reverse-haku tuottaa samat elementit.
    /// Tämä pätee esimerkiksi [`char`]: ään, mutta ei `&str`: ään.
    ///
    /// Jos malli sallii käänteisen haun, mutta sen tulokset saattavat poiketa etsinnästä, voidaan käyttää [`rsplit_terminator`]-menetelmää.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Iteraattori `self`: n alaosien päällä, erotettu kuvioilla sovitetuilla merkeillä ja saatu päinvastaisessa järjestyksessä.
    ///
    /// [pattern] voi olla `&str`, [`char`], leike [hiilejä] tai funktio tai sulkeminen, joka määrittää, täyttääkö merkki merkin.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Vastaava kuin [`split`], paitsi että takalevy ohitetaan, jos se on tyhjä.
    ///
    /// [`split`]: str::split
    ///
    /// Tätä menetelmää voidaan käyttää merkkijonotiedoissa, jotka ovat _terminated_, eikä mallin mukaan _separated_.
    ///
    /// # Iteraattorin käyttäytyminen
    ///
    /// Palautettu iteraattori edellyttää, että kuvio tukee käänteistä hakua, ja se on kaksinkertainen, jos forward/reverse-haku tuottaa samat elementit.
    ///
    ///
    /// Edestä iteroimiseksi voidaan käyttää [`split_terminator`]-menetelmää.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Iteraattori annetun merkkijonolohkon alaosien yli, erotettu kuviolla, rajoitettu palauttamaan enintään `n`-kohteet.
    ///
    /// Jos `n`-alimerkkijonot palautetaan, viimeinen alimerkkijono ("n": n osa) sisältää loput merkkijonosta.
    ///
    /// [pattern] voi olla `&str`, [`char`], leike [hiilejä] tai funktio tai sulkeminen, joka määrittää, täyttääkö merkki merkin.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteraattorin käyttäytyminen
    ///
    /// Palautettua iteraattoria ei ole kaksinkertainen, koska sen tukeminen ei ole tehokasta.
    ///
    /// Jos kuvio sallii käänteisen haun, voidaan käyttää [`rsplitn`]-menetelmää.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Yksinkertaiset mallit:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Monimutkaisempi malli, jossa on suljin:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Iteraattori tämän merkkijonolohkon alaosien yli, erotettu kuviolla, alkaen merkkijonon päästä, rajoitettu enintään `n`-kohteiden palauttamiseen.
    ///
    ///
    /// Jos `n`-alimerkkijonot palautetaan, viimeinen alimerkkijono ("n": n osa) sisältää loput merkkijonosta.
    ///
    /// [pattern] voi olla `&str`, [`char`], leike [hiilejä] tai funktio tai sulkeminen, joka määrittää, täyttääkö merkki merkin.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteraattorin käyttäytyminen
    ///
    /// Palautettua iteraattoria ei ole kaksinkertainen, koska sen tukeminen ei ole tehokasta.
    ///
    /// Edessä jakamiseksi voidaan käyttää [`splitn`]-menetelmää.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Yksinkertaiset mallit:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Monimutkaisempi malli, jossa on suljin:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Jakaa merkkijonon määritetyn erottimen ensimmäisellä esiintymiskerralla ja palauttaa etuliitteen ennen erotinta ja jälkiliitteen erottimen jälkeen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Jakaa merkkijonon määritetyn erottimen viimeisen esiintymän kohdalla ja palauttaa etuliitteen ennen erotinta ja jälkiliitteen erottimen jälkeen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Iteraattori kuvion epäyhtenäisistä vastaavuuksista annetussa merkkijonossa.
    ///
    /// [pattern] voi olla `&str`, [`char`], leike [hiilejä] tai funktio tai sulkeminen, joka määrittää, täyttääkö merkki merkin.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteraattorin käyttäytyminen
    ///
    /// Palautettu iteraattori on [`DoubleEndedIterator`], jos kuvio sallii käänteisen haun ja forward/reverse-haku tuottaa samat elementit.
    /// Tämä pätee esimerkiksi [`char`]: ään, mutta ei `&str`: ään.
    ///
    /// Jos malli sallii käänteisen haun, mutta sen tulokset saattavat poiketa etsinnästä, voidaan käyttää [`rmatches`]-menetelmää.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Tämän merkkijonolohkon kuvion epäyhtenäisten osumien iteraattori tuotti päinvastaisessa järjestyksessä.
    ///
    /// [pattern] voi olla `&str`, [`char`], leike [hiilejä] tai funktio tai sulkeminen, joka määrittää, täyttääkö merkki merkin.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteraattorin käyttäytyminen
    ///
    /// Palautettu iteraattori edellyttää, että kuvio tukee käänteistä hakua, ja se on [`DoubleEndedIterator`], jos forward/reverse-haku tuottaa samat elementit.
    ///
    ///
    /// Edestä iteroimiseksi voidaan käyttää [`matches`]-menetelmää.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Iteraattori tämän merkkijonolohkon kuvion epäyhtenäisistä vastaavuuksista sekä hakemisto, josta ottelu alkaa.
    ///
    /// `pat`: n sisällä oleville `pat`-osumille, jotka ovat päällekkäisiä, palautetaan vain ensimmäistä ottelua vastaavat indeksit.
    ///
    /// [pattern] voi olla `&str`, [`char`], leike [hiilejä] tai funktio tai sulkeminen, joka määrittää, täyttääkö merkki merkin.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteraattorin käyttäytyminen
    ///
    /// Palautettu iteraattori on [`DoubleEndedIterator`], jos kuvio sallii käänteisen haun ja forward/reverse-haku tuottaa samat elementit.
    /// Tämä pätee esimerkiksi [`char`]: ään, mutta ei `&str`: ään.
    ///
    /// Jos malli sallii käänteisen haun, mutta sen tulokset saattavat poiketa etsinnästä, voidaan käyttää [`rmatch_indices`]-menetelmää.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // vain ensimmäinen `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Iteraattori `self`: n kuvion epäyhtenäisistä vastaavuuksista tuotti päinvastaisessa järjestyksessä yhdessä ottelun indeksin kanssa.
    ///
    /// `self`: n sisällä oleville `pat`-osumille, jotka ovat päällekkäisiä, palautetaan vain viimeistä ottelua vastaavat indeksit.
    ///
    /// [pattern] voi olla `&str`, [`char`], leike [hiilejä] tai funktio tai sulkeminen, joka määrittää, täyttääkö merkki merkin.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteraattorin käyttäytyminen
    ///
    /// Palautettu iteraattori edellyttää, että kuvio tukee käänteistä hakua, ja se on [`DoubleEndedIterator`], jos forward/reverse-haku tuottaa samat elementit.
    ///
    ///
    /// Edestä iteroimiseksi voidaan käyttää [`match_indices`]-menetelmää.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // vain viimeinen `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Palauttaa merkkijonolohkon, jonka etu-ja perätila on poistettu.
    ///
    /// 'Whitespace' on määritelty Unicode-johdetun ydinomaisuuden `White_Space` ehtojen mukaisesti.
    ///
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Palauttaa merkkijonolohkon, jonka etummainen välilyönti on poistettu.
    ///
    /// 'Whitespace' on määritelty Unicode-johdetun ydinomaisuuden `White_Space` ehtojen mukaisesti.
    ///
    /// # Tekstin suunta
    ///
    /// Merkkijono on tavusarja.
    /// `start` tässä yhteydessä tarkoittaa kyseisen tavujonon ensimmäistä sijaintia;vasemmalta oikealle kielelle, kuten englanti tai venäjä, tämä jää vasemmalle puolelle, ja oikealta vasemmalle kielille, kuten arabia tai heprea, tämä on oikea puoli.
    ///
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Palauttaa merkkijonolohkon, jonka jäljessä oleva välilyönti on poistettu.
    ///
    /// 'Whitespace' on määritelty Unicode-johdetun ydinomaisuuden `White_Space` ehtojen mukaisesti.
    ///
    /// # Tekstin suunta
    ///
    /// Merkkijono on tavusarja.
    /// `end` tässä yhteydessä tarkoittaa kyseisen tavujonon viimeistä sijaintia;vasemmalta oikealle kielelle, kuten englanti tai venäjä, tämä on oikea puoli, ja oikealta vasemmalle, kuten arabia tai heprea, tämä on vasen puoli.
    ///
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Palauttaa merkkijonolohkon, jonka etummainen välilyönti on poistettu.
    ///
    /// 'Whitespace' on määritelty Unicode-johdetun ydinomaisuuden `White_Space` ehtojen mukaisesti.
    ///
    /// # Tekstin suunta
    ///
    /// Merkkijono on tavusarja.
    /// 'Left' tässä yhteydessä tarkoittaa kyseisen tavujonon ensimmäistä sijaintia;arabian tai heprean kaltaisilla kielillä, jotka ovat 'oikealta vasemmalle' eikä 'vasemmalta oikealle', tämä on _right_-puoli, ei vasen.
    ///
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Palauttaa merkkijonolohkon, jonka jäljessä oleva välilyönti on poistettu.
    ///
    /// 'Whitespace' on määritelty Unicode-johdetun ydinomaisuuden `White_Space` ehtojen mukaisesti.
    ///
    /// # Tekstin suunta
    ///
    /// Merkkijono on tavusarja.
    /// 'Right' tässä yhteydessä tarkoittaa kyseisen tavujonon viimeistä sijaintia;arabian tai heprean kaltaisilla kielillä, jotka ovat 'oikealta vasemmalle' eikä 'vasemmalta oikealle', tämä on _left_-puoli, ei oikea.
    ///
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Palauttaa merkkijonolohkon, jossa on kaikki etuliitteet ja jälkiliitteet, jotka vastaavat toistuvasti poistettua mallia.
    ///
    /// [pattern] voi olla [`char`], leike [hiilejä] tai toiminto tai sulkeminen, joka määrittää, täyttääkö merkki.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Yksinkertaiset mallit:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Monimutkaisempi malli, jossa on suljin:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Muista aikaisin tunnettu ottelu, korjaa se alla, jos
            // viimeinen ottelu on erilainen
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // TURVALLISUUS: `Searcher`: n tiedetään palauttavan kelvolliset indeksit.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Palauttaa merkkijonolohkon, jossa on kaikki etuliitteet, jotka vastaavat toistuvasti poistettua mallia.
    ///
    /// [pattern] voi olla `&str`, [`char`], leike [hiilejä] tai funktio tai sulkeminen, joka määrittää, täyttääkö merkki merkin.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tekstin suunta
    ///
    /// Merkkijono on tavusarja.
    /// `start` tässä yhteydessä tarkoittaa kyseisen tavujonon ensimmäistä sijaintia;vasemmalta oikealle kielelle, kuten englanti tai venäjä, tämä jää vasemmalle puolelle, ja oikealta vasemmalle kielille, kuten arabia tai heprea, tämä on oikea puoli.
    ///
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // TURVALLISUUS: `Searcher`: n tiedetään palauttavan kelvolliset indeksit.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Palauttaa merkkijonolohkon, jonka etuliite on poistettu.
    ///
    /// Jos merkkijono alkaa kuviosta `prefix`, palauttaa alimerkinnän etuliitteen jälkeen, kääritty `Some`: ään.
    /// Toisin kuin `trim_start_matches`, tämä menetelmä poistaa etuliitteen täsmälleen kerran.
    ///
    /// Jos merkkijono ei ala `prefix`, palauttaa `None`.
    ///
    /// [pattern] voi olla `&str`, [`char`], leike [hiilejä] tai funktio tai sulkeminen, joka määrittää, täyttääkö merkki merkin.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Palauttaa merkkijonolohkon, jonka loppuliite on poistettu.
    ///
    /// Jos merkkijono päättyy kuvioon `suffix`, palauttaa alimerkkijonon ennen loppuliitettä käärittynä `Some`: ään.
    /// Toisin kuin `trim_end_matches`, tämä menetelmä poistaa loppuliitteen täsmälleen kerran.
    ///
    /// Jos merkkijono ei pääty `suffix`: llä, palauttaa `None`.
    ///
    /// [pattern] voi olla `&str`, [`char`], leike [hiilejä] tai funktio tai sulkeminen, joka määrittää, täyttääkö merkki merkin.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Palauttaa merkkijonolohkon, jonka kaikki jälkiliitteet vastaavat toistuvasti poistettua mallia.
    ///
    /// [pattern] voi olla `&str`, [`char`], leike [hiilejä] tai funktio tai sulkeminen, joka määrittää, täyttääkö merkki merkin.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tekstin suunta
    ///
    /// Merkkijono on tavusarja.
    /// `end` tässä yhteydessä tarkoittaa kyseisen tavujonon viimeistä sijaintia;vasemmalta oikealle kielelle, kuten englanti tai venäjä, tämä on oikea puoli, ja oikealta vasemmalle, kuten arabia tai heprea, tämä on vasen puoli.
    ///
    ///
    /// # Examples
    ///
    /// Yksinkertaiset mallit:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Monimutkaisempi malli, jossa on suljin:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // TURVALLISUUS: `Searcher`: n tiedetään palauttavan kelvolliset indeksit.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Palauttaa merkkijonolohkon, jossa on kaikki etuliitteet, jotka vastaavat toistuvasti poistettua mallia.
    ///
    /// [pattern] voi olla `&str`, [`char`], leike [hiilejä] tai funktio tai sulkeminen, joka määrittää, täyttääkö merkki merkin.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tekstin suunta
    ///
    /// Merkkijono on tavusarja.
    /// 'Left' tässä yhteydessä tarkoittaa kyseisen tavujonon ensimmäistä sijaintia;arabian tai heprean kaltaisilla kielillä, jotka ovat 'oikealta vasemmalle' eikä 'vasemmalta oikealle', tämä on _right_-puoli, ei vasen.
    ///
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Palauttaa merkkijonolohkon, jonka kaikki jälkiliitteet vastaavat toistuvasti poistettua mallia.
    ///
    /// [pattern] voi olla `&str`, [`char`], leike [hiilejä] tai funktio tai sulkeminen, joka määrittää, täyttääkö merkki merkin.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tekstin suunta
    ///
    /// Merkkijono on tavusarja.
    /// 'Right' tässä yhteydessä tarkoittaa kyseisen tavujonon viimeistä sijaintia;arabian tai heprean kaltaisilla kielillä, jotka ovat 'oikealta vasemmalle' eikä 'vasemmalta oikealle', tämä on _left_-puoli, ei oikea.
    ///
    ///
    /// # Examples
    ///
    /// Yksinkertaiset mallit:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Monimutkaisempi malli, jossa on suljin:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Jäsentää tämän merkkijonolohkon toiseen tyyppiin.
    ///
    /// Koska `parse` on niin yleinen, se voi aiheuttaa ongelmia tyyppipäätöksissä.
    /// Sellaisena `parse` on yksi harvoista kertoista, jolloin näet syntaksin, joka tunnetaan hellästi nimellä 'turbofish': `::<>`.
    ///
    /// Tämä auttaa päättelyalgoritmia ymmärtämään erityisesti, mihin tyyppiin yrität jäsentää.
    ///
    /// `parse` voi jäsentää mihin tahansa tyyppiin, joka toteuttaa [`FromStr`] trait: n.
    ///

    /// # Errors
    ///
    /// Palauttaa [`Err`]: n, jos tätä merkkijonoa ei ole mahdollista jäsentää haluttuun tyyppiin.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Peruskäyttö
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// 'turbofish': n käyttäminen `four`: n merkitsemisen sijaan:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Jäsennys epäonnistui:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Tarkistaa, ovatko kaikki tämän merkkijonon merkit ASCII-alueen sisällä.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Voimme käsitellä kutakin tavua merkkinä tässä: kaikki monitavuiset merkit alkavat tavulla, joka ei ole ascii-alueella, joten pysähdymme siinä jo.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Tarkistaa, että kaksi merkkijonoa vastaavat ASCII-kirjainkokoa.
    ///
    /// Sama kuin `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, mutta jakamatta ja kopioimatta väliaikaisia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Muuntaa tämän merkkijonon ASCII-isojen kirjainten vastaavaksi paikalleen.
    ///
    /// ASCII-kirjaimet 'a'-'z' yhdistetään numeroihin 'A'-'Z', mutta muut kuin ASCII-kirjaimet eivät muutu.
    ///
    /// Jos haluat palauttaa uuden ylemmän tason arvon muuttamatta nykyistä arvoa, käytä [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // TURVALLISUUS: turvallista, koska muunnamme kaksi tyyppiä samalla asettelulla.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Muuntaa tämän merkkijonon vastaavaksi pieneksi kirjaimeksi ASCII.
    ///
    /// ASCII-kirjaimet 'A'-'Z' yhdistetään numeroihin 'a'-'z', mutta muut kuin ASCII-kirjaimet eivät muutu.
    ///
    /// Jos haluat palauttaa uuden pienikokoisen arvon muuttamatta nykyistä arvoa, käytä [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // TURVALLISUUS: turvallista, koska muunnamme kaksi tyyppiä samalla asettelulla.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Palauta iteraattori, joka pakenee jokaisen merkin `self`: ssä [`char::escape_debug`]: n kanssa.
    ///
    ///
    /// Note: vain merkkijonon alkavat laajennetut grafeemikoodipisteet pakenevat.
    ///
    /// # Examples
    ///
    /// Iteraattorina:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!`: n käyttö suoraan:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Molemmat vastaavat:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// `to_string`: n käyttö:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Palauta iteraattori, joka pakenee jokaisen merkin `self`: ssä [`char::escape_default`]: n kanssa.
    ///
    ///
    /// # Examples
    ///
    /// Iteraattorina:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!`: n käyttö suoraan:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Molemmat vastaavat:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// `to_string`: n käyttö:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Palauta iteraattori, joka pakenee jokaisen merkin `self`: ssä [`char::escape_unicode`]: n kanssa.
    ///
    ///
    /// # Examples
    ///
    /// Iteraattorina:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!`: n käyttö suoraan:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Molemmat vastaavat:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// `to_string`: n käyttö:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Luo tyhjän str
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Luo tyhjän muutettavan merkkijonon
    #[inline]
    fn default() -> Self {
        // TURVALLISUUS: Tyhjä merkkijono on kelvollinen UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Nimettävä, kloonattava fn-tyyppi
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // TURVALLISUUS: ei ole turvallista
        unsafe { from_utf8_unchecked(bytes) }
    };
}