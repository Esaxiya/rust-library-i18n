// rsbegin.o ja rsend.o ovat ns. "compiler runtime startup objects".
// Ne sisältävät koodia, jota tarvitaan kääntäjän ajon aloittamiseen oikein.
//
// Kun suoritettava tiedosto tai dylib-kuva linkitetään, kaikki käyttäjäkoodit ja kirjastot ovat "sandwiched" näiden kahden objektitiedoston välillä, joten rsbegin.o: n koodista tai tiedoista tulee ensimmäisiä kuvan vastaavissa osissa, kun taas koodista ja tiedoista rsend.o: stä tulee viimeisiä.
// Tätä vaikutusta voidaan käyttää symbolien sijoittamiseen osan alkuun tai loppuun sekä tarvittavien otsikoiden tai alatunnisteiden lisäämiseen.
//
// Huomaa, että moduulin todellinen alkupiste sijaitsee C-ajonaikaisessa käynnistysobjektissa (kutsutaan yleensä nimellä `crtX.o`), joka sitten kutsuu muiden suorituksen alkukomponenttien alustussoittopyynnöt (jotka on rekisteröity vielä toisen erityisen kuvaosan kautta).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Merkitsee pinokehyksen purkautumistietoja
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Raaputustila levittäjän sisäiseen kirjanpitoon.
    // Tämä määritellään muodossa `struct object` tiedostossa $ GCC/unfind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Kierrä info registration/deregistration-rutiinit.
    // Katso libpanic_unwind-asiakirjat.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // rekisteröidä purkautumistiedot moduulin käynnistyessä
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // poista rekisteröinti sammutuksesta
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-kohtainen rutiinirekisteröinti init/uninit
    pub mod mingw_init {
        // MinGW: n käynnistysobjektit (crt0.o/dllcrt0.o) kutsuvat globaalit konstruktorit .ctors-ja .dtors-osioihin käynnistyksen ja poistumisen yhteydessä.
        // DLL-tiedostojen tapauksessa tämä tehdään, kun DLL ladataan ja puretaan.
        //
        // Linkittäjä lajittelee osiot, mikä varmistaa, että soittopyynnöt sijaitsevat luettelon lopussa.
        // Koska rakentajia ajetaan päinvastaisessa järjestyksessä, tämä varmistaa, että takaisinsoittomme ovat ensimmäisiä ja viimeisiä.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: C-alustussoittopyynnöt
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C-puhelun takaisinkutsut
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}