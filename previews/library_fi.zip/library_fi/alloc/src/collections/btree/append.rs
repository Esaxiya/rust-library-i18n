use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Liittää kaikki avainarvoparit kahden nousevan iteraattorin liitosta lisäämällä `length`-muuttujaa matkan varrella.Jälkimmäinen helpottaa soittajan vuotojen välttämistä, kun pudotuskäsittelijä paniikkiin.
    ///
    /// Jos molemmat iteraattorit tuottavat saman avaimen, tämä menetelmä pudottaa parin vasemmalta iteraattorilta ja liittää parin oikeasta iteraattorista.
    ///
    /// Jos haluat, että puu päätyy tiukasti nousevaan järjestykseen, kuten `BTreeMap`: lle, molempien iteraattorien tulisi tuottaa avaimet tiukasti nousevassa järjestyksessä, joista kukin on suurempi kuin kaikki puun avaimet, mukaan lukien kaikki avaimet, jotka ovat jo puussa sisäänkirjautumisen yhteydessä.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Valmistaudumme yhdistämään `left` ja `right` lajiteltuun sekvenssiin lineaarisessa ajassa.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Samaan aikaan rakennamme puun lajitellusta järjestyksestä lineaarisessa ajassa.
        self.bulk_push(iter, length)
    }

    /// Työnnä kaikki avainarvoparit puun päähän ja lisää `length`-muuttujaa matkan varrella.
    /// Jälkimmäinen helpottaa soittajan vuotojen välttämistä iteraattorin paniikissa.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Toista kaikki avainarvoparit läpi työntämällä ne oikean tason solmuihin.
        for (key, value) in iter {
            // Yritä työntää avain-arvo-pari nykyiseen lehtisolmuun.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Ei tilaa jäljellä, mene ylös ja työnnä sinne.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Löytyi solmu, jossa on tilaa jäljellä, paina tätä.
                                open_node = parent;
                                break;
                            } else {
                                // Mene uudestaan.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Olemme huipulla, luo uusi juurisolmu ja työnnä sinne.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Työnnä avainarvopari ja uusi oikea alipuu.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Mene taas oikeanpuoleiseen lehteen.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Lisää jokaisen iteraation pituutta varmistaaksesi, että kartta pudottaa liitteenä olevat elementit, vaikka iteraattori etenisi.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Iteraattori kahden lajitellun sekvenssin yhdistämiseksi yhdeksi
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Jos kaksi avainta on yhtä suuri, palauttaa avain-arvo-parin oikeasta lähteestä.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}