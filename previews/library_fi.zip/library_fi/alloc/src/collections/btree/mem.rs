use core::intrinsics;
use core::mem;
use core::ptr;

/// Tämä korvaa `v`-yksilöllisen viitteen takana olevan arvon kutsumalla asianomaista toimintoa.
///
///
/// Jos 0panic esiintyy `change`-sulkemisessa, koko prosessi keskeytetään.
#[allow(dead_code)] // säilytä kuvana ja future: n käyttöä varten
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Tämä korvaa `v`-yksilöllisen viitteen takana olevan arvon kutsumalla asianomaisen funktion ja palauttaa matkan aikana saadun tuloksen.
///
///
/// Jos 0panic esiintyy `change`-sulkemisessa, koko prosessi keskeytetään.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}