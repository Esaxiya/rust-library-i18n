use core::marker::PhantomData;
use core::ptr::NonNull;

/// Mallitsee jonkin ainutlaatuisen viitteen uudelleensyntymisen, kun tiedät, että takaisinlainaa ja kaikkia sen jälkeläisiä (eli kaikkia siitä saatuja viitteitä ja viitteitä) ei käytetä enää jossain vaiheessa, minkä jälkeen haluat käyttää alkuperäistä yksilöllistä viittausta uudelleen .
///
///
/// Lainan tarkistaja hoitaa yleensä tämän lainojen pinoamisen puolestasi, mutta jotkut ohjausvirrat, jotka suorittavat tämän pinoamisen, ovat liian monimutkaisia kääntäjän seuraamiseksi.
/// `DormantMutRef`: n avulla voit tarkistaa lainanoton itse ilmaisemalla silti sen pinotun luonteen ja kapseloimalla tähän tarvittavan raakakoodikoodin ilman määrittelemätöntä käyttäytymistä.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Ota ainutlaatuinen laina ja lainaa se välittömästi.
    /// Kääntäjälle uuden viitteen käyttöikä on sama kuin alkuperäisen viitteen elinaika, mutta promise käyttää sitä lyhyemmän ajan.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // TURVALLISUUS: pidämme lainaa läpi X-X: n kautta ja paljastamme
        // vain tämä viite, joten se on ainutlaatuinen.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Palaa alkuperäiseen talteen otettuun ainutlaatuiseen lainaan.
    ///
    /// # Safety
    ///
    /// Lainan on oltava päättynyt, ts. `new`: n palauttamaa viitettä ja kaikkia siitä johdettuja viitteitä ja viitteitä ei saa enää käyttää.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // TURVALLISUUS: Omat turvallisuusolosuhteet tarkoittavat, että tämä viite on jälleen ainutlaatuinen.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;