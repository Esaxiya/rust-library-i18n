//! Apuohjelmat Stringien muotoiluun ja tulostamiseen.
//!
//! Tämä moduuli sisältää ajonaikaisen tuen [`format!`]-syntaksilaajennukselle.
//! Tämä makro on toteutettu kääntäjässä lähettämään kutsuja tähän moduuliin muotoilemaan argumentit ajon aikana merkkijonoiksi.
//!
//! # Usage
//!
//! [`format!`]-makron on tarkoitus olla tuttu niille, jotka tulevat C: n `printf`/`fprintf`-toiminnoista tai Python: n `str.format`-toiminnosta.
//!
//! Joitakin esimerkkejä [`format!`]-laajennuksesta ovat:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" etunollilla
//! ```
//!
//! Näistä näet, että ensimmäinen argumentti on muotoilumerkkijono.Kääntäjä vaatii, että tämä on merkkijono-kirjain;se ei voi olla muuttuja, joka on syötetty (pätevyyden tarkistamiseksi).
//! Tämän jälkeen kääntäjä jäsentää muotoilumerkkijonon ja määrittää, voidaanko annettujen argumenttien luettelo siirtää tähän muotomerkkijonoon.
//!
//! Jos haluat muuntaa yhden arvon merkkijonoksi, käytä [`to_string`]-menetelmää.Tämä käyttää [`Display`]-muotoilua trait.
//!
//! ## Sijoitusparametrit
//!
//! Kukin muotoiluargumentti saa määrittää, mihin arvo-argumenttiin se viittaa, ja jos se jätetään pois, sen oletetaan olevan "the next argument".
//! Esimerkiksi muotoilumerkkijono `{} {} {}` ottaisi kolme parametria, ja ne muotoiltaisiin samassa järjestyksessä kuin ne on annettu.
//! `{2} {1} {0}`-muotoinen merkkijono muotoisi argumentit päinvastaisessa järjestyksessä.
//!
//! Asiat voivat olla hieman hankalia, kun aloitat kahden tyyppisen sijaintitunnistimen sekoittamisen."next argument"-määrittelijän voidaan ajatella olevan iteraattori argumentille.
//! Joka kerta, kun "next argument"-määritin näkyy, iteraattori etenee.Tämä johtaa tällaiseen käyttäytymiseen:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Argumentin sisäinen iteraattori ei ole edennyt ensimmäisen `{}`: n näkymiseen mennessä, joten se tulostaa ensimmäisen argumentin.Sitten saavutettuaan toisen `{}`: n iteraattori on edennyt toiseen argumenttiin.
//! Pohjimmiltaan parametrit, jotka nimenomaisesti nimeävät argumenttinsa, eivät vaikuta parametreihin, jotka eivät nimeä argumenttia sijaintitunnisteiden suhteen.
//!
//! Kaikkien argumenttien käyttämiseen tarvitaan muotoilumerkkijono, muuten se on käännösaika-virhe.Voit viitata samaan argumenttiin useammin kuin kerran muotoilumerkkijonossa.
//!
//! ## Nimetyt parametrit
//!
//! Itse Rust: llä ei ole Python-tyyppistä vastaavaa nimettyä parametria funktiolle, mutta [`format!`]-makro on syntaksilaajennus, jonka avulla se voi hyödyntää nimettyjä parametreja.
//! Nimetyt parametrit luetellaan argumenttiluettelon lopussa, ja niiden syntaksit ovat:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Esimerkiksi kaikki seuraavat [`format!`]-lausekkeet käyttävät nimettyä argumenttia:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Ei ole kelvollista sijoittaa sijaintiparametreja (niitä, joilla ei ole nimeä) argumenttien jälkeen, joilla on nimiä.Kuten sijaintiparametreissa, ei ole kelvollista antaa nimettyjä parametreja, joita muotoilumerkkijono ei käytä.
//!
//! # Parametrien muotoilu
//!
//! Jokainen alustettava argumentti voidaan muuntaa useilla muotoiluparametreilla (vastaa `format_spec`: ää [the syntax](#syntax)): ssä. Nämä parametrit vaikuttavat muotoilun merkkijonojen esitykseen.
//!
//! ## Width
//!
//! ```
//! // Kaikki nämä tulostavat "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Tämä on parametri "minimum width": lle, jonka muodon tulisi olla.
//! Jos arvon merkkijono ei täytä niin monta merkkiä, fill/alignment: n määrittelemää täytettä käytetään tarvittavan tilan viemiseen (katso alla).
//!
//! Leveyden arvo voidaan antaa myös parametriluettelossa [`usize`]: ksi lisäämällä postfix `$`, mikä osoittaa, että toinen argumentti on leveyden määrittävä [`usize`].
//!
//! Dollarin syntaksin sisältävään argumenttiin viittaaminen ei vaikuta "next argument"-laskuriin, joten on yleensä hyvä viitata argumentteihin sijainnin mukaan tai käyttää nimettyjä argumentteja.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Valinnainen täyttömerkki ja tasaus tarjotaan normaalisti [`width`](#width)-parametrin yhteydessä.Se on määriteltävä ennen `width`, heti `:`: n jälkeen.
//! Tämä osoittaa, että jos alustettava arvo on pienempi kuin `width`, sen ympärille tulostetaan joitain ylimääräisiä merkkejä.
//! Täyttöä on saatavana seuraavina muunnelmina eri suuntauksille:
//!
//! * `[fill]<` - argumentti on tasattu vasemmalle `width`-sarakkeisiin
//! * `[fill]^` - argumentti on kohdistettu keskelle `width`-sarakkeisiin
//! * `[fill]>` - argumentti on tasattu oikealle `width`-sarakkeissa
//!
//! Oletusarvoinen [fill/alignment](#fillalignment) ei-numeerisille numeroille on välilyönti ja tasattu vasemmalle.Numeeristen muotoilijoiden oletusarvo on myös välilyönti, mutta tasaus oikealla.
//! Jos `0`-lippu (katso alla) on määritetty numeroille, implisiittinen täytemerkki on `0`.
//!
//! Huomaa, että jotkin tyypit eivät välttämättä toteuta tasausta.Erityisesti sitä ei yleensä toteuteta `Debug` trait: lle.
//! Hyvä tapa varmistaa, että täytettä käytetään, on muotoilla syötteesi ja sitten täyttää tämä tuloksena oleva merkkijono tuloksen saamiseksi:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Hei Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Nämä kaikki ovat liput, jotka muuttavat muotoilijan käyttäytymistä.
//!
//! * `+` - Tämä on tarkoitettu numerotyypeille ja osoittaa, että merkki tulee aina tulostaa.Positiivisia merkkejä ei koskaan tulosteta oletuksena, ja negatiivinen merkki tulostetaan oletuksena vain mallille `Signed` trait.
//! Tämä lippu osoittaa, että oikea merkki (`+` tai `-`) tulee aina tulostaa.
//! * `-` - Tällä hetkellä ei käytetä
//! * `#` - Tämä lippu osoittaa, että "alternate"-tulostusmuotoa tulisi käyttää.Vaihtoehtoiset lomakkeet ovat:
//!     * `#?` - tulosta kauniisti [`Debug`]-muotoilu
//!     * `#x` - edeltää argumenttia `0x`: llä
//!     * `#X` - edeltää argumenttia `0x`: llä
//!     * `#b` - edeltää argumenttia `0b`: llä
//!     * `#o` - edeltää argumenttia `0o`: llä
//! * `0` - Tätä käytetään osoittamaan kokonaislukuformaattien osalta, että `width`: n täyttö tulisi tehdä sekä `0`-merkillä että olla merkki-tietoinen.
//! `{:08}`: n kaltainen muoto antaisi `00000001` kokonaisluvulle `1`, kun taas sama muoto antaisi `-0000001` kokonaisluvulle `-1`.
//! Huomaa, että negatiivisessa versiossa on yksi vähemmän nollaa kuin positiivisessa versiossa.
//!         Huomaa, että täytepisteet ovat aina merkin (jos sellainen on) jälkeen ja ennen numeroita.Kun käytetään yhdessä `#`-lipun kanssa, pätee samanlainen sääntö: täytteen nollat lisätään etuliitteen jälkeen, mutta ennen numeroita.
//!         Etuliite sisältyy kokonaisleveyteen.
//!
//! ## Precision
//!
//! Ei-numeeristen tyyppien tapauksessa tätä voidaan pitää "maximum width": nä.
//! Jos tuloksena oleva merkkijono on pidempi kuin tämä leveys, se katkaistaan niin moneksi merkiksi ja että katkaistu arvo lähetetään oikeilla `fill`-, `alignment`-ja `width`-arvoilla, jos nämä parametrit on asetettu.
//!
//! Integraalityypeissä tämä jätetään huomioimatta.
//!
//! Liukulukutyypeille tämä osoittaa, kuinka monta numeroa desimaalipilkun jälkeen on tulostettava.
//!
//! Haluttu `precision` voidaan määrittää kolmella tavalla:
//!
//! 1. Luku `.N`:
//!
//!    kokonaisluku `N` itsessään on tarkkuus.
//!
//! 2. Luku tai nimi, jota seuraa dollarin merkki `.N$`:
//!
//!    käytä muoto *argumentti*`N` (jonka on oltava `usize`) tarkkuudella.
//!
//! 3. Tähti `.*`:
//!
//!    `.*` tarkoittaa, että tämä `{...}` liittyy *kahteen* muotoiseen tuloon pikemminkin kuin yhteen: ensimmäinen tulo pitää `usize`-tarkkuuden ja toinen tulostaa arvon.
//!    Huomaa, että jos tässä tapauksessa käytetään muotoilumerkkijonoa `{<arg>:<spec>.*}`, `<arg>`-osa viittaa tulostukseen*-arvoon * ja `precision`: n on oltava `<arg>`: ää edeltävässä syötteessä.
//!
//! Esimerkiksi seuraavat puhelut tulostavat kaikki saman `Hello x is 0.01000`:
//!
//! ```
//! // Hei {arg 0 ("x")} on {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Hei {arg 1 ("x")} on {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Hei {arg 0 ("x")} on {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Hei {next arg ("x")} on {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Hei {next arg ("x")} on {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Hei {next arg ("x")} on {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Vaikka nämä:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! tulosta kolme merkittävästi erilaista asiaa:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Joillakin ohjelmointikielillä merkkijonon muotoilutoimintojen toiminta riippuu käyttöjärjestelmän kieliasetuksista.
//! Rust: n vakiokirjaston tarjoamilla muotoilutoiminnoilla ei ole aluekäsitettä, ja ne tuottavat samat tulokset kaikissa järjestelmissä käyttäjän kokoonpanosta riippumatta.
//!
//! Esimerkiksi seuraava koodi tulostaa aina `1.5`: n, vaikka järjestelmän kielialue käyttää muuta desimaalierotinta kuin pistettä.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Kirjaimelliset merkit `{` ja `}` voidaan sisällyttää merkkijonoon edeltämällä niitä samalla merkillä.Esimerkiksi `{`-merkki poistetaan `{{`-merkillä ja `}`-merkki poistetaan `}}`-merkillä.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Yhteenvetona voidaan todeta, että täältä löydät koko muotoisten merkkijonojen kieliopin.
//! Käytetyn muotoilukielen syntaksia käytetään muista kielistä, joten sen ei pitäisi olla liian vieras.Argumentit on muotoiltu Python: n kaltaisella syntaksilla, mikä tarkoittaa, että argumentteja ympäröi `{}` C: n kaltaisen `%`: n sijaan.
//! Muotoilun syntaksin todellinen kielioppi on:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Yllä olevassa kieliopissa `text` ei välttämättä sisällä `'{'`-tai `'}'`-merkkejä.
//!
//! # Muotoile traits
//!
//! Kun pyydät argumentin muotoilua tietyllä tyypillä, pyydät tosiasiallisesti argumentin omistamista tietylle trait: lle.
//! Tämä mahdollistaa useiden todellisten tyyppien alustamisen `{:x}`: n kautta (kuten [`i8`] ja [`isize`]).Nykyinen tyyppikartoitus traits: hen on:
//!
//! * *ei mitään* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] pienillä kirjaimilla heksadesimaaliluvuilla
//! * `X?` ⇒ [`Debug`] isoilla heksadesimaaleilla
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Tämä tarkoittaa sitä, että minkä tahansa tyyppinen argumentti, joka toteuttaa [`fmt::Binary`][`Binary`] trait: n, voidaan sitten muotoilla `{:b}`: llä.Toteutukset tarjotaan näille traits: lle useille primitiivisille tyypeille myös standardikirjastossa.
//!
//! Jos muotoa ei ole määritetty (kuten `{}`: ssä tai `{:6}`: ssä), käytetty muoto trait on [`Display`] trait.
//!
//! Kun otat käyttöön muodon trait omalle tyypillesi, sinun on toteutettava allekirjoitusmenetelmä:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // mukautettu tyyppi
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Tyyppisi välitetään `self`-viitteenä, ja sitten toiminnon pitäisi lähettää `f.buf`-virtaan.Jokaisen trait-muodon toteutus on itse noudatettava pyydettyjä muotoiluparametreja oikein.
//! Näiden parametrien arvot luetellaan [`Formatter`]-rakennekentissä.Tämän helpottamiseksi [`Formatter`]-rakenne tarjoaa myös joitain auttajamenetelmiä.
//!
//! Lisäksi tämän funktion palautusarvo on [`fmt::Result`], joka on tyypin aliakseksi [``Tulos`]] <(), `[` `std: : fmt::Error`]```.
//! Toteutusten muotoilun tulisi varmistaa, että ne levittävät virheitä [`Formatter`]: stä (esim. Soitettaessa [`write!`]).
//! Niiden ei kuitenkaan pitäisi koskaan palauttaa virheitä väärin.
//! Eli muotoilutoteutuksen on ja se voi palauttaa virheen vain, jos syötetty [`Formatter`] palauttaa virheen.
//! Tämä johtuu siitä, että toisin kuin funktion allekirjoitus voi ehdottaa, merkkijonon muotoilu on erehtymätön operaatio.
//! Tämä funktio palauttaa vain tuloksen, koska kirjoittaminen alla olevaan streamiin voi epäonnistua, ja sen on tarjottava tapa levittää tosiasia, että virhe on tapahtunut, takaisin pinoon.
//!
//! Esimerkki muotoilun traits toteuttamisesta näyttäisi tältä:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // `f`-arvo toteuttaa `Write` trait: n, minkä kirjoittaa!makro odottaa.
//!         // Huomaa, että tämä muotoilu jättää huomiotta merkkijonojen eri liput.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Erilaiset traits sallivat tyypin erilaiset ulostulomuodot.
//! // Tämän muodon tarkoitus on tulostaa vector: n suuruus.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Kunnioita muotoilulippuja käyttämällä muotoilijaobjektin auttajametodia `pad_integral`.
//!         // Katso lisätietoja menetelmän dokumentaatiosta, ja toimintoa `pad` voidaan käyttää merkkijonojen pehmustamiseen.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs. `fmt::Debug`
//!
//! Näillä kahdella traits-muotoilulla on erilliset tarkoitukset:
//!
//! - [`fmt::Display`][`Display`] toteutukset väittävät, että tyyppiä voidaan jatkuvasti esittää uskollisesti UTF-8-merkkijonona.**Ei ole** odotettavissa, että kaikki tyypit toteuttavat [`Display`] trait: n.
//! - [`fmt::Debug`][`Debug`] toteutukset tulisi toteuttaa **kaikille** julkisille tyyppeille.
//!   Tulos edustaa tyypillisesti sisäistä tilaa mahdollisimman uskollisesti.
//!   [`Debug`] trait: n tarkoituksena on helpottaa Rust-koodin virheenkorjausta.Useimmissa tapauksissa `#[derive(Debug)]`: n käyttö on riittävää ja suositeltavaa.
//!
//! Joitakin esimerkkejä molempien traits: n lähdöistä:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Liittyvät makrot
//!
//! [`format!`]-perheessä on useita toisiinsa liittyviä makroja.Tällä hetkellä toteutetaan:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Tämä ja [`writeln!`] ovat kaksi makroa, joita käytetään lähettämään muotoilumerkkijono määritettyyn virtaan.Tätä käytetään estämään muodon merkkijonojen välitön allokointi ja sen sijaan kirjoittamaan tulos suoraan.
//! Konepellin alla tämä toiminto vetoaa itse asiassa [`write_fmt`]-toimintoon, joka on määritelty [`std::io::Write`] trait: ssä.
//! Esimerkkikäyttö on:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Tämä ja [`println!`] lähettävät lähdön stdout: lle.Samoin kuin [`write!`]-makro, näiden makrojen tavoitteena on välttää välitön allokointi tulostettaessa.Esimerkkikäyttö on:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! [`eprint!`]-ja [`eprintln!`]-makrot ovat identtisiä vastaavasti [`print!`]-ja [`println!`]-makrojen kanssa, paitsi että ne lähettävät lähdön stderr: lle.
//!
//! ### `format_args!`
//!
//! Tämä on utelias makro, jota käytetään ohittamaan muodon merkkijonoa kuvaava läpinäkymätön objekti.Tämä objekti ei vaadi kasan varauksia luomaan, ja se viittaa vain pinon tietoihin.
//! Hupun alla kaikki siihen liittyvät makrot toteutetaan tämän mukaisesti.
//! Ensinnäkin joitain esimerkkejä käytöstä on:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! [`format_args!`]-makron tulos on tyypin [`fmt::Arguments`] arvo.
//! Tämä rakenne voidaan sitten siirtää tämän moduulin sisällä oleville [`write`]-ja [`format`]-funktioille muotoilumerkkijonon käsittelemiseksi.
//! Tämän makron tavoitteena on estää entisestään välikohteiden jakaminen merkkijonojen muotoilussa.
//!
//! Esimerkiksi kirjauskirjasto voisi käyttää vakiomuotoilun syntaksia, mutta se kulkisi sisäisesti tämän rakenteen ympärillä, kunnes on määritetty, mihin ulostulon pitäisi mennä.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// `format`-funktio ottaa [`Arguments`]-rakenteen ja palauttaa tuloksena olevan muotoillun merkkijonon.
///
///
/// [`Arguments`]-ilmentymä voidaan luoda [`format_args!`]-makrolla.
///
/// # Examples
///
/// Peruskäyttö:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Huomaa, että [`format!`]: n käyttö saattaa olla suositeltavaa.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}