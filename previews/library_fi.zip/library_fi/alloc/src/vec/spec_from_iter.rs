use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Erikoistuminen trait, jota käytetään mallissa Vec::from_iter
///
/// ## Valtuuskäyrä:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Yleinen tapaus on vector: n siirtäminen funktioon, joka kerää välittömästi uudelleen vector: ksi.
        // Voimme oikosulkea tämän, ellei IntoIteriä ole edistynyt lainkaan.
        // Kun se on edennyt, voimme myös käyttää muistia uudelleen ja siirtää tiedot eteen.
        // Mutta teemme niin vain, kun tuloksena olevalla Vecilla ei ole enemmän käyttämätöntä kapasiteettia kuin luomalla se yleisen FromIterator-toteutuksen kautta.
        //
        // Rajoitus ei ole ehdottoman välttämätöntä, koska Vecin allokointikäyttäytyminen on tarkoituksellisesti määrittelemätöntä.
        // Mutta se on konservatiivinen valinta.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // täytyy delegoida spec_extend(): lle, koska extend() itse delegoi spec_from tyhjiä Vecs-tiedostoja varten
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Tämä hyödyntää `iterator.as_slice().to_vec()`: ää, koska spec_extendin on tehtävä enemmän toimenpiteitä lopullisen kapasiteetin + pituuden perustelemiseksi ja tehtävä siten enemmän työtä.
// `to_vec()` kohdistaa oikean määrän suoraan ja täyttää sen tarkalleen.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): cfg(test): n kanssa luontainen `[T]::to_vec`-menetelmä, jota tarvitaan tämän menetelmän määrittelyyn, ei ole käytettävissä.
    // Käytä sen sijaan `slice::to_vec`-toimintoa, joka on saatavana vain cfg(test): n kanssa NB. Katso lisätietoja slice::hack-moduulista slice.rs: ssä.
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}