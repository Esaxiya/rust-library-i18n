//! Dynaamisesti kokoinen näkymä vierekkäiseksi sekvenssiksi, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Viipaleet ovat näkymä muistilohkoksi, joka on esitetty osoittimena ja pituudella.
//!
//! ```
//! // viipalointi Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // pakottaa matriisin viipaleeseen
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Viipaleet ovat joko muutettavissa olevia tai jaettuja.
//! Jaetun siipityypin tyyppi on `&[T]`, kun taas muutettavissa olevan siipityypin tyyppi on `&mut [T]`, jossa `T` edustaa elementtityyppiä.
//! Voit esimerkiksi mutatoida muistilohkon, johon muutettava osa osoittaa:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Tässä on joitain asioita, jotka tämä moduuli sisältää:
//!
//! ## Structs
//!
//! Viipaleille on hyödyllisiä useita rakenteita, kuten [`Iter`], joka edustaa iteraatiota viipaleen yli.
//!
//! ## Trait-toteutukset
//!
//! Viipaleille on useita yhteisen traits-toteutuksia.Joitakin esimerkkejä ovat:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], viipaleille, joiden elementtityyppi on [`Eq`] tai [`Ord`].
//! * [`Hash`] - viipaleille, joiden elementtityyppi on [`Hash`].
//!
//! ## Iteration
//!
//! Viipaleet toteuttavat `IntoIterator`: n.Iteraattori antaa viitteet siivuelementteihin.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Mutable slice tuottaa muuttuvia viitteitä elementteihin:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Tämä iteraattori tuottaa muuttuvia viitteitä leikkeen elementteihin, joten vaikka leikkeen elementtityyppi on `i32`, iteraattorin elementtityyppi on `&mut i32`.
//!
//!
//! * [`.iter`] ja [`.iter_mut`] ovat nimenomaisia menetelmiä palauttaa oletuksena iteraattorit.
//! * Muut iteraattoreita palauttavat menetelmät ovat [`.split`], [`.splitn`], [`.chunks`], [`.windows`] ja paljon muuta.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Monia tämän moduulin käyttökohteita käytetään vain testikokoonpanossa.
// On puhtaampaa poistaa käytöstä unused_imports-varoitus käytöstä kuin korjata ne.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Viipaleiden laajennusmenetelmät
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) tarvitaan `vec!`-makron toteuttamiseen NB: n testauksen aikana, katso lisätietoja tämän tiedoston `hack`-moduulista.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) tarvitaan `Vec::clone`: n käyttöönottoon NB: n testauksen aikana, katso lisätietoja tämän tiedoston `hack`-moduulista.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Kun cfg(test) ei ole käytettävissä, `impl [T]` ei ole käytettävissä, nämä kolme toimintoa ovat itse asiassa menetelmiä, jotka ovat `impl [T]`: ssä mutta eivät `core::slice::SliceExt`: ssä, nämä toiminnot on toimitettava `test_permutations`-testiä varten
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Meidän ei pitäisi lisätä tähän inline-attribuuttia, koska sitä käytetään enimmäkseen `vec!`-makrossa ja aiheuttaa täydellisen regression.
    // Katso #71204 keskustelua ja tuloksia varten.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // kohteet merkittiin alustetuiksi alla olevaan silmukkaan
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) on välttämätön LLVM: lle poistamaan rajatarkastukset ja sillä on parempi koodegen kuin zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec jaettiin ja alustettiin yllä ainakin tälle pituudelle.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // varattu yllä `s`: n kapasiteetilla, ja alusta `s.len()`: ään alla ptr::copy_to_non_overlapping: ssä.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Lajittelee leikkeen.
    ///
    /// Tämä lajittelu on vakaa (ts. Ei järjestä uudelleen samanlaisia elementtejä) ja *O*(*n*\*log(* n*)) pahimmassa tapauksessa.
    ///
    /// Epävakaa lajittelu on suositeltavaa, koska se on yleensä nopeampaa kuin vakaa lajittelu eikä se varaa lisämuistia.
    /// Katso [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Nykyinen toteutus
    ///
    /// Nykyinen algoritmi on [timsort](https://en.wikipedia.org/wiki/Timsort): n innoittama adaptiivinen, iteratiivinen yhdistämislajittelu.
    /// Se on suunniteltu toimimaan erittäin nopeasti tapauksissa, joissa viipale on melkein lajiteltu tai se koostuu kahdesta tai useammasta lajitellusta sekvenssistä, jotka on ketjutettu peräkkäin.
    ///
    ///
    /// Lisäksi se allokoi väliaikaisen tallennustilan puolet `self`: n koosta, mutta lyhyille viipaleille käytetään sen sijaan varaamatonta lisäyslajittelua.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Lajittelee leikkeen vertailutoiminnolla.
    ///
    /// Tämä lajittelu on vakaa (ts. Ei järjestä uudelleen samanlaisia elementtejä) ja *O*(*n*\*log(* n*)) pahimmassa tapauksessa.
    ///
    /// Vertailutoiminnon on määriteltävä viipaleen elementtien kokonaisjärjestys.Jos tilaus ei ole täydellinen, elementtien järjestystä ei ole määritelty.
    /// Tilaus on kokonaistilaus, jos se on (kaikille `a`, `b` ja `c`):
    ///
    /// * yhteensä ja antisymmetrinen: täsmälleen yksi seuraavista: `a < b`, `a == b` tai `a > b` on totta, ja
    /// * transitiivinen, `a < b` ja `b < c` tarkoittaa `a < c`: ää.Sama koskee sekä `==`: ää että `>`: ää.
    ///
    /// Esimerkiksi, vaikka [`f64`] ei toteuta [`Ord`]: ää, koska `NaN != NaN`, voimme käyttää `partial_cmp`: tä lajittelutoimintona, kun tiedämme, että viipale ei sisällä `NaN`: ää.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Epävakaa lajittelu on suositeltavaa, koska se on yleensä nopeampaa kuin vakaa lajittelu eikä se varaa lisämuistia.
    /// Katso [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Nykyinen toteutus
    ///
    /// Nykyinen algoritmi on [timsort](https://en.wikipedia.org/wiki/Timsort): n innoittama adaptiivinen, iteratiivinen yhdistämislajittelu.
    /// Se on suunniteltu toimimaan erittäin nopeasti tapauksissa, joissa viipale on melkein lajiteltu tai se koostuu kahdesta tai useammasta lajitellusta sekvenssistä, jotka on ketjutettu peräkkäin.
    ///
    /// Lisäksi se allokoi väliaikaisen tallennustilan puolet `self`: n koosta, mutta lyhyille viipaleille käytetään sen sijaan varaamatonta lisäyslajittelua.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // käänteinen lajittelu
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Lajittelee leikkeen avaintoiminnolla.
    ///
    /// Tämä lajittelu on vakaa (ts. Ei järjestä uudelleen yhtäläisiä elementtejä) ja *O*(*m*\* * n *\* log(*n*)) pahimmassa tapauksessa, jossa näppäintoiminto on *O*(*m*).
    ///
    /// Kalliille avaintoiminnoille (esim
    /// toiminnot, jotka eivät ole yksinkertaisia ominaisuuskäyttöjä tai perustoimintoja), [`sort_by_cached_key`](slice::sort_by_cached_key) on todennäköisesti huomattavasti nopeampi, koska se ei laske elementtiavaimia uudelleen.
    ///
    ///
    /// Epävakaa lajittelu on suositeltavaa, koska se on yleensä nopeampaa kuin vakaa lajittelu eikä se varaa lisämuistia.
    /// Katso [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Nykyinen toteutus
    ///
    /// Nykyinen algoritmi on [timsort](https://en.wikipedia.org/wiki/Timsort): n innoittama adaptiivinen, iteratiivinen yhdistämislajittelu.
    /// Se on suunniteltu toimimaan erittäin nopeasti tapauksissa, joissa viipale on melkein lajiteltu tai se koostuu kahdesta tai useammasta lajitellusta sekvenssistä, jotka on ketjutettu peräkkäin.
    ///
    /// Lisäksi se allokoi väliaikaisen tallennustilan puolet `self`: n koosta, mutta lyhyille viipaleille käytetään sen sijaan varaamatonta lisäyslajittelua.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Lajittelee leikkeen avaintoiminnolla.
    ///
    /// Lajittelun aikana avaintoimintoa kutsutaan vain kerran elementtiä kohti.
    ///
    /// Tämä lajittelu on vakaa (ts. Ei järjestä uudelleen yhtäläisiä elementtejä) ja *O*(*m*\* * n *+* n *\* log(*n*)) pahimmassa tapauksessa, jossa näppäintoiminto on *O*(*m*) .
    ///
    /// Yksinkertaisten avaintoimintojen (esim. Toimintojen, jotka ovat omaisuuden käyttöoikeudet tai perustoiminnot), [`sort_by_key`](slice::sort_by_key) on todennäköisesti nopeampi.
    ///
    /// # Nykyinen toteutus
    ///
    /// Nykyinen algoritmi perustuu Orson Petersin [pattern-defeating quicksort][pdqsort]: ään, joka yhdistää satunnaistetun quicksortin nopean keskimääräisen tapauksen ja nopeimman heapsortin tapauksen samalla kun saavutetaan lineaarinen aika viipaleilla, joilla on tietyt mallit.
    /// Se käyttää jonkin verran satunnaistamista rappeutuvien tapausten välttämiseksi, mutta kiinteällä seed: llä saadaan aina deterministinen käyttäytyminen.
    ///
    /// Pahimmassa tapauksessa algoritmi jakaa väliaikaisen tallennustilan `Vec<(K, usize)>`: ään viipaleen pituuden.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Apumakro vector: n indeksoimiseksi pienimmällä mahdollisella tyypillä allokoinnin vähentämiseksi.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // `indices`: n elementit ovat ainutlaatuisia, koska ne on indeksoitu, joten kaikki lajit ovat vakaita alkuperäiseen osaan nähden.
                // Käytämme `sort_unstable`: ää täällä, koska se vaatii vähemmän muistia.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Kopioi `self`: n uuteen `Vec`: ään.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Tässä `s`: ää ja `x`: ää voidaan muokata itsenäisesti.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Kopioi `self`: n uuteen `Vec`: ään varaimen avulla.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Tässä `s`: ää ja `x`: ää voidaan muokata itsenäisesti.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // Huom. Katso lisätietoja tämän tiedoston `hack`-moduulista.
        hack::to_vec(self, alloc)
    }

    /// Muuntaa `self`: n vector: ksi ilman klooneja tai allokointia.
    ///
    /// Tuloksena oleva vector voidaan muuntaa takaisin laatikkoon `Vec<T>`into_boxed_slice`-menetelmä.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` ei voida käyttää enää, koska se on muunnettu `x`: ksi.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // Huom. Katso lisätietoja tämän tiedoston `hack`-moduulista.
        hack::into_vec(self)
    }

    /// Luo vector toistamalla leikkeen `n` kertaa.
    ///
    /// # Panics
    ///
    /// Tämä toiminto on panic, jos kapasiteetti ylittää.
    ///
    /// # Examples
    ///
    /// Peruskäyttö:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// panic ylivuotoa kohden:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Jos `n` on suurempi kuin nolla, se voidaan jakaa `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`: ksi.
        // `2^expn` on numero, jota edustaa `n`: n vasemmanpuoleisin '1'-bitti, ja `rem` on `n`: n jäljellä oleva osa.
        //
        //

        // `set_len()`: n käyttö `Vec`: n avulla.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` toisto tapahtuu kaksinkertaistamalla `buf` `expn-kertaa.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Jos `m > 0`, vasemmalla olevaan '1': ään on jäljellä bittejä.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` kapasiteetti on `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) toistoa tehdään kopioimalla ensimmäiset `rem`-toistot itse `buf`: stä.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Tämä ei ole päällekkäinen `2^expn > rem`: n jälkeen.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` on yhtä suuri kuin `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Tasoittaa viipaleen `T` yhdeksi arvoksi `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Tasoittaa `T`-viipaleen yhdeksi arvoksi `Self::Output` asettamalla tietyn erottimen kunkin väliin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Tasoittaa `T`-viipaleen yhdeksi arvoksi `Self::Output` asettamalla tietyn erottimen kunkin väliin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Palauttaa vector: n, joka sisältää kopion tästä osasta, jossa jokainen tavu on kartoitettu sen ASCII-isojen kirjainten vastaavuuteen.
    ///
    ///
    /// ASCII-kirjaimet 'a'-'z' yhdistetään numeroihin 'A'-'Z', mutta muut kuin ASCII-kirjaimet eivät muutu.
    ///
    /// Suurenna arvo paikalleen käyttämällä [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Palauttaa vector: n, joka sisältää kopion tästä leikkeestä, jossa jokainen tavu on kartoitettu sen vastaavaan ASCII-kirjaimeen.
    ///
    ///
    /// ASCII-kirjaimet 'A'-'Z' yhdistetään numeroihin 'a'-'z', mutta muut kuin ASCII-kirjaimet eivät muutu.
    ///
    /// Pienennä arvoa paikassa [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Laajennus traits viipaleille tietyntyyppisille tiedoille
////////////////////////////////////////////////////////////////////////////////

/// Apulainen trait [[T]: : concat`]: lle (siivu::concat).
///
/// Note: `Item`-tyyppistä parametria ei käytetä tässä trait: ssä, mutta se sallii implitteiden olla yleisempiä.
/// Ilman sitä saamme tämän virheen:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Tämä johtuu siitä, että `V`-tyyppejä, joissa on useita `Borrow<[_]>`-implittejä, voisi olla olemassa, niin että useita `T`-tyyppejä sovellettaisiin:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Tuloksena oleva tyyppi ketjutuksen jälkeen
    type Output;

    /// [[T]: : concat`]: n (siivu::concat) toteutus
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Apulainen trait [[T]: : liittyä`](leike::liity)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Tuloksena oleva tyyppi ketjutuksen jälkeen
    type Output;

    /// [[[T]: : liity`]: n toteutus (leike::liity)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Standardi trait-toteutus viipaleille
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // pudota kaikki kohteet, joita ei korvata
        target.truncate(self.len());

        // target.len <= self.len yllä olevan katkaisun vuoksi, joten viipaleet ovat aina rajojen sisäpuolella.
        //
        let (init, tail) = self.split_at(target.len());

        // käytä uudelleen sisältämiä arvoja allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Lisää `v[0]` ennalta lajiteltuun jaksoon `v[1..]`, jotta koko `v[..]` lajitellaan.
///
/// Tämä on integrointilajittelun kiinteä alirutiini.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Tässä on kolme tapaa toteuttaa lisäys:
            //
            // 1. Vaihda vierekkäisiä elementtejä, kunnes ensimmäinen saavuttaa lopullisen määränpäänsä.
            //    Tällä tavalla kopioimme tietoja kuitenkin enemmän kuin on tarpeen.
            //    Jos elementit ovat suuria rakenteita (kopiointi kallista), tämä menetelmä on hidas.
            //
            // 2. Toista, kunnes löytyy oikea paikka ensimmäiselle elementille.
            // Siirrä sitten sen jälkeiset elementit vapauttamaan tilaa ja aseta se lopuksi reikään.
            // Tämä on hyvä menetelmä.
            //
            // 3. Kopioi ensimmäinen elementti väliaikaiseen muuttujaan.Toista, kunnes oikea paikka löytyy.
            // Kun kuljemme eteenpäin, kopioi kaikki kulkevat elementit sitä edeltävään aukkoon.
            // Lopuksi kopioi tiedot väliaikaisesta muuttujasta jäljellä olevaan reikään.
            // Tämä menetelmä on erittäin hyvä.
            // Vertailuarvot osoittivat hieman parempaa suorituskykyä kuin toisella menetelmällä.
            //
            // Kaikki menetelmät vertailtiin, ja kolmas osoitti parhaat tulokset.Joten valitsimme sen.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // `hole` seuraa aina lisäysprosessin välitilaa, jolla on kaksi tarkoitusta:
            // 1. Suojaa `v`: n eheyttä panics: ltä `is_less`: ssä.
            // 2. Täyttää lopulta `v`: n jäljellä olevan reiän.
            //
            // Panic-turvallisuus:
            //
            // Jos `is_less` panics missä tahansa prosessin vaiheessa, `hole` putoaa ja täyttää `v`: n reiän `tmp`: llä, varmistaen siten, että `v` pitää sisällään kaikki alun perin pitämänsä objektit tarkalleen kerran.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` putoaa ja kopioi siten `tmp`: n jäljellä olevaan reikään `v`: ssä.
        }
    }

    // Kun pudotetaan, kopiot `src`: stä `dest`: ään.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Yhdistää ei-vähenevät ajot `v[..mid]` ja `v[mid..]` käyttämällä väliaikaisena tallennustilana `buf`: ää ja tallentaa tulokset `v[..]`: ään.
///
/// # Safety
///
/// Kahden viipaleen on oltava tyhjiä ja `mid`: n on oltava rajoissa.
/// Puskurin `buf` on oltava riittävän pitkä pitämään kopio lyhyemmästä siivusta.
/// `T` ei myöskään saa olla nollakokoinen tyyppi.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Yhdistämisprosessi kopioi ensin lyhyemmän ajon `buf`: ään.
    // Sitten se jäljittää äskettäin kopioidun ajon ja pidemmän ajon eteenpäin (tai taaksepäin) vertaamalla niiden seuraavia käyttämättömiä elementtejä ja kopioimalla pienemmän (tai suuremman) `v`: ään.
    //
    // Heti kun lyhyempi ajo on käytetty loppuun, prosessi on valmis.Jos pidempi ajo kuluu ensin, meidän on kopioitava lyhyemmästä ajasta jäljellä oleva jäljellä oleva reikä `v`: ssä.
    //
    // Prosessin välitilaa seuraa aina `hole`, jolla on kaksi tarkoitusta:
    // 1. Suojaa `v`: n eheyttä panics: ltä `is_less`: ssä.
    // 2. Täyttää jäljellä olevan aukon `v`: ssä, jos pidempi ajo kuluu ensin.
    //
    // Panic-turvallisuus:
    //
    // Jos `is_less` panics jossakin prosessin vaiheessa, `hole` putoaa ja täyttää `v`: n reiän `buf`: n kuluttamattomalla alueella, varmistaen siten, että `v` pitää sisällään kaikki objektit, joita alun perin pidettiin tarkalleen kerran.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Vasen ajo on lyhyempi.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Aluksi nämä osoittimet viittaavat matriisiensa alkuun.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Kuluta pienempi puoli.
            // Jos se on yhtä suuri, mieluummin vasen ajo vakauden ylläpitämiseksi.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Oikea juoksu on lyhyempi.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Aluksi nämä osoittimet osoittavat matriisiensa päät.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Kuluta suurempi puoli.
            // Jos se on yhtä suuri, mieluummin oikea juoksu vakauden ylläpitämiseksi.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Lopuksi `hole` putoaa.
    // Jos lyhyempi ajo ei kulunut kokonaan, jäljellä olevat kopiot kopioidaan nyt `v`: n reikään.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Kun se pudotetaan, kopioi alue `start..end` `dest..`: ään.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` ei ole nollakokoinen tyyppi, joten on hyvä jakaa sen koon mukaan.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Tämä yhdistämislaji lainaa joitain (mutta ei kaikkia) ideoita TimSortilta, joka on kuvattu yksityiskohtaisesti [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// Algoritmi tunnistaa tarkasti laskeutuvat ja laskeutumattomat alijonot, joita kutsutaan luonnollisiksi ajoiksi.Pino odottavia ajoja on vielä yhdistämättä.
/// Jokainen äskettäin löydetty ajo työnnetään pinoon ja sitten jotkut vierekkäisten juoksuparit yhdistetään, kunnes nämä kaksi invarianttia täyttyvät:
///
/// 1. jokaiselle `i`: lle `1..runs.len()`: ssä: `runs[i - 1].len > runs[i].len`
/// 2. jokaiselle `i`: lle `2..runs.len()`: ssä: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Invariantit varmistavat, että kokonaisaika on *O*(*n*\*log(* n*)) pahimmassa tapauksessa.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Tämän pituiset viipaleet lajitellaan lisäyslajittelun avulla.
    const MAX_INSERTION: usize = 20;
    // Hyvin lyhyitä ajoja pidennetään lisäyslajittelulla ainakin tämän monien elementtien kattamiseksi.
    const MIN_RUN: usize = 10;

    // Lajittelulla ei ole merkityksellistä käyttäytymistä nollakokoisissa tyypeissä.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Lyhyet matriisit lajitellaan paikalleen lisäyslajittelun avulla varausten välttämiseksi.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Määritä puskuri käytettäväksi raaputusmuistina.Pidämme pituuden 0, jotta voimme pitää siinä matalat kopiot `v`: n sisällöstä vaarantamatta kopioilla käynnissä olevia lääkäreitä, jos `is_less` panics.
    //
    // Kun yhdistetään kaksi lajiteltua ajoa, tämä puskuri sisältää kopion lyhyemmästä ajasta, jonka pituus on aina enintään `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // `v`: n luonnollisten juoksujen tunnistamiseksi kulkemme sitä taaksepäin.
    // Se saattaa tuntua oudolta päätökseltä, mutta ota huomioon se tosiasia, että sulautumiset menevät useammin vastakkaiseen suuntaan (forwards).
    // Vertailuarvojen mukaan yhdistäminen eteenpäin on hieman nopeampi kuin sulautuminen taaksepäin.
    // Lopuksi totean, että juoksujen tunnistaminen taaksepäin parantamalla parantaa suorituskykyä.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Etsi seuraava luonnollinen ajo ja käännä se, jos se on tiukasti laskeva.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Lisää joitain elementtejä juoksuun, jos se on liian lyhyt.
        // Lisälajittelu on nopeampi kuin yhdistämislajittelu lyhyissä jaksoissa, joten tämä parantaa merkittävästi suorituskykyä.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Työnnä tämä juoksu pinolle.
        runs.push(Run { start, len: end - start });
        end = start;

        // Yhdistä muutama vierekkäinen juoksupari tyydyttämään invarianteja.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Lopuksi täsmälleen yhden ajon on oltava pinossa.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Tutki ajopinoa ja tunnistaa seuraavan yhdistettävän juoksuparin.
    // Tarkemmin sanottuna, jos `Some(r)` palautetaan, se tarkoittaa, että seuraavaksi `runs[r]` ja `runs[r + 1]` on yhdistettävä.
    // Jos algoritmin pitäisi jatkaa uuden ajon rakentamista, `None` palautetaan.
    //
    // TimSort on surullinen bugisista toteutuksistaan, kuten tässä kuvataan:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Tarinan ydin on: meidän on pakotettava invariantit pinon neljän parhaan juoksun päälle.
    // Niiden pakottaminen vain kolmen parhaan joukkoon ei riitä varmistamaan, että invariantit pitävät silti kiinni *kaikki* juoksusta pinossa.
    //
    // Tämä toiminto tarkistaa invariantit neljän ylemmän ajon suhteen.
    // Lisäksi, jos ylin ajo alkaa indeksistä 0, se vaatii aina yhdistämistoiminnon, kunnes pino on täysin romahtanut lajittelun suorittamiseksi.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}