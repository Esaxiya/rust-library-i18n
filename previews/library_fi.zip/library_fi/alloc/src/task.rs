#![stable(feature = "wake_trait", since = "1.51.0")]
//! Tyypit ja Traits asynkronisten tehtävien kanssa työskentelyyn.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Tehtävän herättäminen toteuttajalle.
///
/// Tätä trait: tä voidaan käyttää [`Waker`]: n luomiseen.
/// Suorittaja voi määritellä tämän trait: n toteutuksen ja käyttää sitä rakentamaan Wakerin siirtämään tehtäville, jotka suoritetaan kyseiselle suorittajalle.
///
/// Tämä trait on muistiturvallinen ja ergonominen vaihtoehto [`RawWaker`]: n rakentamiselle.
/// Se tukee yleistä suoritinsuunnittelua, jossa tehtävän herättämiseen käytetyt tiedot on tallennettu [`Arc`]: ään.
/// Jotkut toteuttajat (etenkin sulautettujen järjestelmien suorittimet) eivät voi käyttää tätä sovellusliittymää, minkä vuoksi [`RawWaker`] on olemassa vaihtoehtona näille järjestelmille.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Perustoiminto `block_on`, joka ottaa future: n ja suorittaa sen loppuun nykyisellä säikeellä.
///
/// **Note:** Tämä esimerkki käy kauppaa oikeellisuuden yksinkertaisuuden vuoksi.
/// Tukkeutumisten estämiseksi tuotantotason toteutusten on myös käsiteltävä välipuhelut `thread::unpark`: lle sekä sisäkkäiset kutsut.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Herätin, joka herättää nykyisen langan, kun sitä kutsutaan.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Suorita future loppuun nykyiselle säikeelle.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Kiinnitä future, jotta se voidaan äänestää.
///     let mut fut = Box::pin(fut);
///
///     // Luo uusi konteksti, joka välitetään future: lle.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Suorita future loppuun.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Herätä tämä tehtävä.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Herätä tämä tehtävä kuluttamatta herätintä.
    ///
    /// Jos toimeenpanija tukee halvempaa tapaa herätä käyttämättä herätintä, sen tulisi ohittaa tämä menetelmä.
    /// Oletuksena se kloonaa [`Arc`]: n ja kutsuu [`wake`]: n klooniin.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // TURVALLISUUS: Tämä on turvallista, koska raw_waker rakentaa turvallisesti
        // RawWaker Arc: lta<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Tätä yksityistä toimintoa RawWakerin rakentamiseen käytetään pikemminkin kuin
// sisällyttämällä tämä `From<Arc<W>> for RawWaker`-implettiin sen varmistamiseksi, että `From<Arc<W>> for Waker`: n turvallisuus ei riipu oikeasta trait-lähetyksestä, sen sijaan molemmat implisiitit kutsuvat tätä toimintoa suoraan ja nimenomaisesti.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Lisää kaaren vertailumäärää kloonaamiseksi.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Herää arvon mukaan siirtämällä kaari Wake::wake-toimintoon
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Herää viitteenä, kääri herätin ManuallyDropiin, jotta se ei pudota
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Vähennä kaaren referenssimäärää pudotettaessa
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}