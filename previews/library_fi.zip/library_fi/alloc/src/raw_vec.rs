#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Uuden muistin sisältö on alustamaton.
    Uninitialized,
    /// Uusi muisti nollataan.
    Zeroed,
}

/// Matalatasoinen apu, jolla voidaan ergonomisesti jakaa, jakaa uudelleen ja jakaa muistipuskuri kasaan ilman, että sinun tarvitsee huolehtia kaikista mukana olevista kulmatapauksista.
///
/// Tämä tyyppi sopii erinomaisesti omien tietorakenteiden, kuten Vec ja VecDeque, rakentamiseen.
/// Erityisesti:
///
/// * Tuottaa `Unique::dangling()`: n nollakokoisille malleille.
/// * Tuottaa `Unique::dangling()`: n nollapituisilla varauksilla.
/// * Välttää `Unique::dangling()`: n vapauttamisen.
/// * Sieppaa kaikki ylimääräiset kapasiteettilaskennat (ylentää ne "capacity overflow" panics: ksi).
/// * Suojaa 32-bittisiltä järjestelmiltä, jotka varaavat enemmän kuin isize::MAX tavua.
/// * Suojaa pituudeltaan täynnä.
/// * Saa `handle_alloc_error`: lle virheellisiä varauksia.
/// * Sisältää `ptr::Unique`: n ja antaa käyttäjälle kaikki siihen liittyvät edut.
/// * Käyttää allokaattorilta palautetun ylimäärän suurimman käytettävissä olevan kapasiteetin käyttämiseen.
///
/// Tämä tyyppi ei missään tapauksessa tarkasta hallitsemaansa muistia.Pudotettuaan se * vapauttaa muistinsa, mutta se ei yritä pudottaa sen sisältöä.
/// `RawVec`: n käyttäjän on hoidettava `RawVec`: n sisällä *tallennetut* asiat.
///
/// Huomaa, että nollakokoisten tyyppien ylimäärä on aina ääretön, joten `capacity()` palauttaa aina arvon `usize::MAX`.
/// Tämä tarkoittaa, että sinun on oltava varovainen, kun kompastat tämän tyypin `Box<[T]>`: llä, koska `capacity()` ei tuota pituutta.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Tämä on olemassa, koska `#[unstable]` `const fn: n ei tarvitse olla yhdenmukainen `min_const_fn`: n kanssa, joten niitä ei voida kutsua myöskään` min_const_fn`s.
    ///
    /// Jos vaihdat `RawVec<T>::new`: ää tai riippuvuuksia, älä ota käyttöön mitään sellaista, mikä todella rikkoo `min_const_fn`: ää.
    ///
    /// NOTE: Voisimme välttää tämän hakkeroinnin ja tarkistaa yhdenmukaisuuden jonkin `#[rustc_force_min_const_fn]`-määritteen kanssa, joka vaatii yhteensopivuutta `min_const_fn`: n kanssa, mutta ei välttämättä salli sen kutsumista `stable(...) const fn`: ssä/käyttäjäkoodissa, joka ei salli `foo`: ää, kun `#[rustc_const_unstable(feature = "foo", issue = "01234")]` on läsnä.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Luo suurimman mahdollisen `RawVec`: n (järjestelmän kasassa) varaamatta.
    /// Jos `T`: llä on positiivinen koko, niin siitä tulee `RawVec`, jonka kapasiteetti on `0`.
    /// Jos `T` on nollakokoinen, se tekee `RawVec`: n, jonka kapasiteetti on `usize::MAX`.
    /// Hyödyllinen viivästetyn allokoinnin toteuttamiseen.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Luo `RawVec` (järjestelmän kasaan), jolla on tarkalleen `[T; capacity]`: n kapasiteetti-ja kohdistusvaatimukset.
    /// Tämä vastaa `RawVec::new`: n soittamista, kun `capacity` on `0` tai `T` on nollakokoinen.
    /// Huomaa, että jos `T` on nollakokoinen, se tarkoittaa, että et *saa*`RawVec`: ää vaaditulla kapasiteetilla.
    ///
    /// # Panics
    ///
    /// Panics, jos pyydetty kapasiteetti ylittää `isize::MAX` tavua.
    ///
    /// # Aborts
    ///
    /// Keskeytykset OOM: ssa.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Kuten `with_capacity`, mutta takaa puskurin nollaamisen.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Muodostaa `RawVec`: n osoittimesta ja kapasiteetista.
    ///
    /// # Safety
    ///
    /// `ptr` on varattava (järjestelmän kasaan) ja annetulla `capacity`: llä.
    /// `capacity` ei voi ylittää arvoa `isize::MAX` kokoluokissa.(koskee vain 32-bittisiä järjestelmiä).
    /// ZST vectors: n kapasiteetti voi olla jopa `usize::MAX`.
    /// Jos `ptr` ja `capacity` tulevat `RawVec`: stä, tämä on taattu.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Pienet vecsit ovat tyhmä.Siirry:
    // - 8, jos elementin koko on 1, koska kaikki kasanallokaattorit todennäköisesti pyöristävät alle 8 tavun pyynnön vähintään 8 tavuun.
    //
    // - 4, jos elementit ovat kohtuullisen kokoisia (<=1 KiB).
    // - 1 muuten välttääksesi liikaa tilaa vioittamasta hyvin lyhyille Vecs-laitteille.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Kuten `new`, mutta parametroitu palauttavalle `RawVec`: lle varatun varaimen perusteella.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` tarkoittaa "unallocated".nollakokoiset tyypit jätetään huomiotta.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Kuten `with_capacity`, mutta parametroitu palauttavalle `RawVec`: lle varatun varaimen perusteella.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Kuten `with_capacity_zeroed`, mutta parametroitu palauttavalle `RawVec`: lle varatun varaimen perusteella.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Muuntaa `Box<[T]>`: n `RawVec<T>`: ksi.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Muuntaa koko puskurin `Box<[MaybeUninit<T>]>`: ksi määritetyllä `len`: llä.
    ///
    /// Huomaa, että tämä korjaa kaikki mahdollisesti tehdyt `cap`-muutokset oikein.(Katso lisätietoja tyypin kuvauksesta.)
    ///
    /// # Safety
    ///
    /// * `len` - sen on oltava suurempi tai yhtä suuri kuin viimeksi haettu kapasiteetti, ja-
    /// * `len` on oltava pienempi tai yhtä suuri kuin `self.capacity()`.
    ///
    /// Huomaa, että pyydetty kapasiteetti ja `self.capacity()` saattavat poiketa toisistaan, koska allokaattori voi kohdistaa ja palauttaa pyydettyä suuremman muistilohkon.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Tarkasta puolikas turvallisuusvaatimuksesta (emme voi tarkistaa toista puolta).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Vältämme `unwrap_or_else`: ää täällä, koska se paisuttaa syntyvän LLVM IR-määrän.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Muodostaa `RawVec`: n osoittimesta, kapasiteetista ja allokaattorista.
    ///
    /// # Safety
    ///
    /// `ptr` on allokoitava (annetun allokaattorin `alloc` kautta) ja annetulla `capacity`: llä.
    /// `capacity` ei voi ylittää arvoa `isize::MAX` kokoluokissa.
    /// (koskee vain 32-bittisiä järjestelmiä).
    /// ZST vectors: n kapasiteetti voi olla jopa `usize::MAX`.
    /// Jos `ptr` ja `capacity` tulevat `alloc`: llä luotusta `RawVec`: stä, tämä on taattu.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Saa raaka osoittimen allokoinnin alkuun.
    /// Huomaa, että tämä on `Unique::dangling()`, jos `capacity == 0` tai `T` on nollakokoinen.
    /// Edellisessä tapauksessa sinun on oltava varovainen.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Hankkii allokoinnin kapasiteetin.
    ///
    /// Tämä on aina `usize::MAX`, jos `T` on nollakokoinen.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Palauttaa jaetun viitteen tämän `RawVec`: n tukijalle.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Meillä on varattu muisti, joten voimme ohittaa ajonaikaiset tarkistukset saadaksemme nykyisen asettelumme.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Varmistaa, että puskurissa on vähintään tarpeeksi tilaa `len + additional`-elementtien pitämiseen.
    /// Jos sillä ei vielä ole tarpeeksi kapasiteettia, kohdennetaan uudelleen tarpeeksi tilaa ja mukava löysä tila amortizoidun *O*(1)-käyttäytymisen saamiseksi.
    ///
    /// Rajoittaa tätä käyttäytymistä, jos se aiheettomasti aiheuttaisi itsensä panic: lle.
    ///
    /// Jos `len` ylittää `self.capacity()`: n, tämä ei välttämättä pysty varaamaan pyydettyä tilaa.
    /// Tämä ei ole oikeastaan vaarallinen, mutta kirjoittamasi vaarallinen koodi, joka perustuu tämän toiminnon toimintaan, voi rikkoutua.
    ///
    /// Tämä on ihanteellinen `extend`: n kaltaisen massapainalluksen toteuttamiseen.
    ///
    /// # Panics
    ///
    /// Panics, jos uusi kapasiteetti ylittää `isize::MAX` tavua.
    ///
    /// # Aborts
    ///
    /// Keskeytykset OOM: ssa.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // reserve olisi keskeyttänyt tai paniikkiin, jos len ylitti `isize::MAX`: n, joten tämä on turvallista tehdä nyt tarkastamatta.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Sama kuin `reserve`, mutta palauttaa virheet paniikin tai keskeytyksen sijaan.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Varmistaa, että puskurissa on vähintään tarpeeksi tilaa `len + additional`-elementtien pitämiseen.
    /// Jos se ei vielä ole, kohdentaa uudelleen mahdollisimman pienen mahdollisen muistin määrän.
    /// Yleensä tämä on täsmälleen tarvittava muistin määrä, mutta periaatteessa allokaattori voi antaa takaisin enemmän kuin pyysimme.
    ///
    ///
    /// Jos `len` ylittää `self.capacity()`: n, tämä ei välttämättä pysty varaamaan pyydettyä tilaa.
    /// Tämä ei ole oikeastaan vaarallinen, mutta kirjoittamasi vaarallinen koodi, joka perustuu tämän toiminnon toimintaan, voi rikkoutua.
    ///
    /// # Panics
    ///
    /// Panics, jos uusi kapasiteetti ylittää `isize::MAX` tavua.
    ///
    /// # Aborts
    ///
    /// Keskeytykset OOM: ssa.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Sama kuin `reserve_exact`, mutta palauttaa virheet paniikin tai keskeytyksen sijaan.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Kutistaa allokoinnin määritettyyn määrään saakka.
    /// Jos annettu summa on 0, jakautuu kokonaan.
    ///
    /// # Panics
    ///
    /// Panics, jos annettu määrä on *suurempi* kuin nykyinen kapasiteetti.
    ///
    /// # Aborts
    ///
    /// Keskeytykset OOM: ssa.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Palauttaa, jos puskurin täytyy kasvaa tarvittavan ylimääräisen kapasiteetin täyttämiseksi.
    /// Käytetään pääasiassa varapuhelujen linjaamisen mahdollistamiseen ilman `grow`: n vuorottelua.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Tämä menetelmä havainnollistetaan yleensä monta kertaa.Joten haluamme sen olevan mahdollisimman pieni, parantamaan kääntöaikoja.
    // Mutta haluamme myös, että mahdollisimman suuri osa sen sisällöstä on staattisesti laskettavissa, jotta luotu koodi toimisi nopeammin.
    // Siksi tämä menetelmä on kirjoitettu huolellisesti niin, että kaikki `T`: stä riippuva koodi on sen sisällä, kun taas mahdollisimman suuri osa `T`: stä riippumattomasta koodista on toiminnoissa, jotka eivät ole yleisiä `T`: n kautta.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Tämän varmistavat kutsuvat kontekstit.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Koska palautamme `usize::MAX`-kapasiteetin, kun `elem_size` on
            // 0, tänne pääseminen tarkoittaa välttämättä sitä, että `RawVec` on täynnä.
            return Err(CapacityOverflow);
        }

        // Valitettavasti emme voi oikeastaan tehdä näitä tarkastuksia.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Tämä takaa eksponentiaalisen kasvun.
        // Tuplaaminen ei voi ylittyä, koska `cap <= isize::MAX` ja `cap`-tyyppi ovat `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` on ei-yleinen `T`: n kautta.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Tämän menetelmän rajoitukset ovat paljolti samat kuin `grow_amortized`: ssä, mutta tämä menetelmä on yleensä ilmentynyt harvemmin, joten se on vähemmän kriittinen.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Koska palautamme kapasiteetin `usize::MAX`, kun tyyppikoko on
            // 0, tänne pääseminen tarkoittaa välttämättä sitä, että `RawVec` on täynnä.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` on ei-yleinen `T`: n kautta.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Tämä toiminto on `RawVec`: n ulkopuolella kääntöaikojen minimoimiseksi.Katso lisätietoja `RawVec::grow_amortized`: n yllä olevasta kommentista.
// (`A`-parametri ei ole merkittävä, koska käytännössä havaittujen erilaisten `A`-tyyppien määrä on paljon pienempi kuin `T`-tyyppien määrä.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Tarkista virhe täältä minimoidaksesi `RawVec::grow_*`: n koon.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Aloittaja tarkistaa tasauksen tasa-arvon
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Vapauttaa `RawVec`: n *omistaman muistin* yrittämättä pudottaa sen sisältöä.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Keskitetty toiminto varavirheiden käsittelyyn.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Meidän on taattava seuraavat:
// * Emme koskaan jaa `> isize::MAX`-tavuisia objekteja.
// * Emme ylitä `usize::MAX`: ää ja osoitamme itse asiassa liian vähän.
//
// 64-bittisessä on vain tarkistettava ylivuoto, koska `> isize::MAX`-tavujen allokointi yrittää varmasti epäonnistua.
// 32-ja 16-bittisissä laitteissa meidän on lisättävä ylimääräinen suojaus tätä varten, jos ajamme alustalla, joka voi käyttää kaikkia 4 Gt: aa käyttäjän tilassa, esim. PAE tai x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Yksi keskeinen toiminto, joka vastaa kapasiteetin ylivuotojen ilmoittamisesta.
// Tämä varmistaa, että näihin panics: ään liittyvä koodin luonti on vähäistä, koska koko moduulissa on vain yksi sijainti, joka panics on joukko.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}