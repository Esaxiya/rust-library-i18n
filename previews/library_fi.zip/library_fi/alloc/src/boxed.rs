//! Osoitintyyppi kasan allokoinnille.
//!
//! [`Box<T>`], rennosti 'box', tarjoaa yksinkertaisimman muodon kasan allokoinnista muodossa Rust.Laatikot antavat omistajan tälle allokoinnille ja pudottavat niiden sisällön, kun ne poistuvat soveltamisalasta.Laatikot varmistavat myös, että ne eivät koskaan jaa enempää kuin `isize::MAX`-tavuja.
//!
//! # Examples
//!
//! Siirrä arvo pinosta kasaan luomalla [`Box`]:
//!
//! ```
//! let val: u8 = 5;
//! let boxed: Box<u8> = Box::new(val);
//! ```
//!
//! Siirrä arvo [`Box`]: stä takaisin pinoon [dereferencing]: llä:
//!
//! ```
//! let boxed: Box<u8> = Box::new(5);
//! let val: u8 = *boxed;
//! ```
//!
//! Rekursiivisen tietorakenteen luominen:
//!
//! ```
//! #[derive(Debug)]
//! enum List<T> {
//!     Cons(T, Box<List<T>>),
//!     Nil,
//! }
//!
//! let list: List<i32> = List::Cons(1, Box::new(List::Cons(2, Box::new(List::Nil))));
//! println!("{:?}", list);
//! ```
//!
//! Tämä tulostaa `Cons (1, Cons(2, Nil))`.
//!
//! Rekursiiviset rakenteet on merkittävä ruutuun, koska jos `Cons`: n määritelmä näytti tältä:
//!
//! ```compile_fail,E0072
//! # enum List<T> {
//! Cons(T, List<T>),
//! # }
//! ```
//!
//! Se ei toimisi.Tämä johtuu siitä, että `List`: n koko riippuu siitä, kuinka monta elementtiä on luettelossa, joten emme tiedä, kuinka paljon muistia `Cons`: lle tulisi varata.Ottamalla käyttöön [`Box<T>`]: n, jolla on määritelty koko, tiedämme kuinka suuren `Cons`: n on oltava.
//!
//! # Muistin asettelu
//!
//! Muiden kuin nollakokoisten arvojen kohdalla [`Box`] käyttää allokoijaansa [`Global`] allokoinnissaan.On kelvollista muuntaa molemmat tavat [`Box`]: n ja [`Global`]-varaimella allokoidun raakaosoittimen välillä, kun otetaan huomioon, että allokaattorin kanssa käytetty [`Layout`] on oikea tyypille.
//!
//! Tarkemmin sanottuna `value:*mut T`, joka on allokoitu [`Global`]-allokaattorilla `Layout::for_value(&* value)`: n kanssa, voidaan muuntaa laatikoksi [`Box::<T>::from_raw(value)`]: llä.
//! Päinvastoin, [`Box::<T>::into_raw`]: ltä saatu `value:*mut T`: n tukeva muisti voidaan kohdistaa käyttämällä [`Global`]-allokaattoria [`Layout::for_value(&* value)`]: n kanssa.
//!
//! Nollakokoisille arvoille `Box`-osoittimen on silti oltava [valid] luku-ja kirjoitusasiakirjoille ja riittävän linjassa.
//! Erityisesti minkä tahansa kohdistetun, nollasta poikkeavan kokonaisluvun heittäminen raakaa osoittimeen tuottaa kelvollisen osoittimen, mutta aiemmin osoitettuun muistiin osoittava osoitin, joka vapautumisen jälkeen ei ole kelvollinen.
//! Suositeltava tapa rakentaa laatikko ZST: lle, jos `Box::new`: ää ei voida käyttää, on käyttää [`ptr::NonNull::dangling`]: ää.
//!
//! Niin kauan kuin `T: Sized`, `Box<T>` on taattu edustettuna yhtenä osoittimena ja on myös ABI-yhteensopiva C-osoittimien (ts. C-tyypin `T*`) kanssa.
//! Tämä tarkoittaa, että jos sinulla on ulkoisia "C" Rust-toimintoja, jotka kutsutaan C: stä, voit määrittää ne Rust-toiminnot `Box<T>`-tyyppien avulla ja käyttää `T*`: tä vastaavana tyypinä C-puolella.
//! Tarkastellaan esimerkiksi tätä C-otsikkoa, joka ilmoittaa toiminnot, jotka luovat ja tuhoavat jonkinlaisen `Foo`-arvon:
//!
//! ```c
//! /* C-otsikko */
//!
//! /* Palauttaa omistajan soittajalle */
//! struct Foo* foo_new(void);
//!
//! /* Ottaa soittajan omistukseen;no-op, kun sitä kutsutaan NULL: llä */
//! void foo_delete(struct Foo*);
//! ```
//!
//! Nämä kaksi toimintoa voidaan toteuttaa Rust: ssä seuraavasti.Tässä `struct Foo*`-tyyppi C: stä käännetään `Box<Foo>`: ksi, joka ottaa huomioon omistusrajoitukset.
//! Huomaa myös, että `foo_delete`: n mitätöitävä argumentti esitetään muodossa Rust muodossa `Option<Box<Foo>>`, koska `Box<Foo>` ei voi olla nolla.
//!
//! ```
//! #[repr(C)]
//! pub struct Foo;
//!
//! #[no_mangle]
//! pub extern "C" fn foo_new() -> Box<Foo> {
//!     Box::new(Foo)
//! }
//!
//! #[no_mangle]
//! pub extern "C" fn foo_delete(_: Option<Box<Foo>>) {}
//! ```
//!
//! Vaikka `Box<T>`: llä on sama esitys ja C ABI kuin C-osoittimella, tämä ei tarkoita, että voit muuntaa mielivaltaisen `T*`: n `Box<T>`: ksi ja odottaa, että asiat toimivat.
//! `Box<T>` arvot ovat aina täysin tasattuja, ei-nollaviitteitä.Lisäksi `Box<T>`: n tuhoaja yrittää vapauttaa arvon globaalilla allokaattorilla.Yleensä paras käytäntö on käyttää `Box<T>`: ää vain osoittimille, jotka ovat peräisin globaalista allokaattorista.
//!
//! **Tärkeää.** Ainakin tällä hetkellä tulisi välttää `Box<T>`-tyyppien käyttöä toiminnoissa, jotka on määritelty C: ssä, mutta joita kutsutaan Rust: stä.Tällöin sinun tulisi peilata C-tyypit suoraan mahdollisimman tarkasti.
//! `Box<T>`: n kaltaisten tyyppien käyttö, kun C-määritelmä on vain `T*`: n käyttö, voi johtaa määrittelemättömään käyttäytymiseen, kuten [rust-lang/unsafe-code-guidelines#198][ucg#198]: ssä on kuvattu.
//!
//! [ucg#198]: https://github.com/rust-lang/unsafe-code-guidelines/issues/198
//! [dereferencing]: core::ops::Deref
//! [`Box::<T>::from_raw(value)`]: Box::from_raw
//! [`Global`]: crate::alloc::Global
//! [`Layout`]: crate::alloc::Layout
//! [`Layout::for_value(&*value)`]: crate::alloc::Layout::for_value
//! [valid]: ptr#safety
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::future::Future;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator, Iterator};
use core::marker::{Unpin, Unsize};
use core::mem;
use core::ops::{
    CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Generator, GeneratorState, Receiver,
};
use core::pin::Pin;
use core::ptr::{self, Unique};
use core::stream::Stream;
use core::task::{Context, Poll};

use crate::alloc::{handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw};
use crate::borrow::Cow;
use crate::raw_vec::RawVec;
use crate::str::from_boxed_utf8_unchecked;
use crate::vec::Vec;

/// Osoitintyyppi kasan allokoinnille.
///
/// Katso lisätietoja [module-level documentation](../../std/boxed/index.html): stä.
#[lang = "owned_box"]
#[fundamental]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Box<
    T: ?Sized,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
>(Unique<T>, A);

impl<T> Box<T> {
    /// Jakaa muistia kasaan ja sijoittaa sitten `x`: n siihen.
    ///
    /// Tätä ei varata, jos `T` on nollakokoinen.
    ///
    /// # Examples
    ///
    /// ```
    /// let five = Box::new(5);
    /// ```
    #[inline(always)]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(x: T) -> Self {
        box x
    }

    /// Rakentaa uuden laatikon, jossa on alustamaton sisältö.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Lykätty alustus:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn new_uninit() -> Box<mem::MaybeUninit<T>> {
        Self::new_uninit_in(Global)
    }

    /// Rakentaa uuden `Box`: n alustamattomalla sisällöllä muistin ollessa täynnä `0`-tavuja.
    ///
    ///
    /// Katso [`MaybeUninit::zeroed`][zeroed]: stä esimerkkejä tämän menetelmän oikeasta ja väärästä käytöstä.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let zero = Box::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[inline]
    #[doc(alias = "calloc")]
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Box<mem::MaybeUninit<T>> {
        Self::new_zeroed_in(Global)
    }

    /// Rakentaa uuden `Pin<Box<T>>`: n.
    /// Jos `T` ei toteuta `Unpin`: ää, `x` kiinnitetään muistiin eikä sitä voida siirtää.
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn pin(x: T) -> Pin<Box<T>> {
        (box x).into()
    }

    /// Varaa kasaan muistin ja sijoittaa sitten `x`: n, mikä palauttaa virheen, jos allokointi epäonnistuu
    ///
    ///
    /// Tätä ei varata, jos `T` on nollakokoinen.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// let five = Box::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(x: T) -> Result<Self, AllocError> {
        Self::try_new_in(x, Global)
    }

    /// Rakentaa uuden ruudun alustamattomalla sisällöllä kasaan palauttaen virheen, jos allokointi epäonnistuu
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let mut five = Box::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Lykätty alustus:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_uninit() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_uninit_in(Global)
    }

    /// Rakentaa uuden `Box`: n alustamattomalla sisällöllä, muistin ollessa täynnä kasan `0`-tavuja
    ///
    ///
    /// Katso [`MaybeUninit::zeroed`][zeroed]: stä esimerkkejä tämän menetelmän oikeasta ja väärästä käytöstä.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let zero = Box::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_zeroed() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_zeroed_in(Global)
    }
}

impl<T, A: Allocator> Box<T, A> {
    /// Jakaa muistia annetulle varaimelle ja sijoittaa sitten `x`: n siihen.
    ///
    /// Tätä ei varata, jos `T` on nollakokoinen.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::new_in(5, System);
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn new_in(x: T, alloc: A) -> Self {
        let mut boxed = Self::new_uninit_in(alloc);
        unsafe {
            boxed.as_mut_ptr().write(x);
            boxed.assume_init()
        }
    }

    /// Jakaa muistia annetulle varaimelle ja sijoittaa sitten `x`: n siihen, mikä palauttaa virheen, jos allokointi epäonnistuu
    ///
    ///
    /// Tätä ei varata, jos `T` on nollakokoinen.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::try_new_in(5, System)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new_in(x: T, alloc: A) -> Result<Self, AllocError> {
        let mut boxed = Self::try_new_uninit_in(alloc)?;
        unsafe {
            boxed.as_mut_ptr().write(x);
            Ok(boxed.assume_init())
        }
    }

    /// Rakentaa uuden laatikon alustamattomalla sisällöllä toimitettuun varaimeen.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::new_uninit_in(System);
    ///
    /// let five = unsafe {
    ///     // Lykätty alustus:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Mieluummin ottelu kuin untrap_or_else, koska sulkeminen ei joskus ole linjaamaton.
        // Se tekisi koodin koon suuremmaksi.
        match Box::try_new_uninit_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Muodostaa uuden laatikon alustamattomalla sisällöllä tarjotussa varaimessa ja palauttaa virheen, jos allokointi epäonnistuu
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::try_new_uninit_in(System)?;
    ///
    /// let five = unsafe {
    ///     // Lykätty alustus:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Rakentaa uuden `Box`: n, jossa ei ole alustettua sisältöä, muistin ollessa täynnä `0`-tavuilla toimitetussa varaimessa.
    ///
    ///
    /// Katso [`MaybeUninit::zeroed`][zeroed]: stä esimerkkejä tämän menetelmän oikeasta ja väärästä käytöstä.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::new_zeroed_in(System);
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Mieluummin ottelu kuin untrap_or_else, koska sulkeminen ei joskus ole linjaamaton.
        // Se tekisi koodin koon suuremmaksi.
        match Box::try_new_zeroed_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Rakentaa uuden `Box`: n alustamattomalla sisällöllä, muistin ollessa täynnä `0`-tavuja annetussa varaimessa, palauttaen virheen, jos allokointi epäonnistuu,
    ///
    ///
    /// Katso [`MaybeUninit::zeroed`][zeroed]: stä esimerkkejä tämän menetelmän oikeasta ja väärästä käytöstä.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::try_new_zeroed_in(System)?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate_zeroed(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Rakentaa uuden `Pin<Box<T, A>>`: n.
    /// Jos `T` ei toteuta `Unpin`: ää, `x` kiinnitetään muistiin eikä sitä voida siirtää.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline(always)]
    pub fn pin_in(x: T, alloc: A) -> Pin<Self>
    where
        A: 'static,
    {
        Self::new_in(x, alloc).into()
    }

    /// Muuntaa `Box<T>`: n `Box<[T]>`: ksi
    ///
    /// Tämä muunnos ei kohdistu kasaan ja tapahtuu paikallaan.
    #[unstable(feature = "box_into_boxed_slice", issue = "71582")]
    pub fn into_boxed_slice(boxed: Self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(boxed);
        unsafe { Box::from_raw_in(raw as *mut [T; 1], alloc) }
    }

    /// Kuluttaa `Box`: n palauttaen kääritty arvo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(box_into_inner)]
    ///
    /// let c = Box::new(5);
    ///
    /// assert_eq!(Box::into_inner(c), 5);
    /// ```
    #[unstable(feature = "box_into_inner", issue = "80437")]
    #[inline]
    pub fn into_inner(boxed: Self) -> T {
        *boxed
    }
}

impl<T> Box<[T]> {
    /// Rakentaa uuden laatikkolohkon, joka sisältää alustamattoman sisällön.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Lykätty alustus:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity(len).into_box(len) }
    }

    /// Rakentaa uuden laatikkolohkon, joka sisältää alustamattoman sisällön, muistin ollessa täynnä `0`-tavuja.
    ///
    ///
    /// Katso [`MaybeUninit::zeroed`][zeroed]: stä esimerkkejä tämän menetelmän oikeasta ja väärästä käytöstä.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let values = Box::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity_zeroed(len).into_box(len) }
    }
}

impl<T, A: Allocator> Box<[T], A> {
    /// Rakentaa uuden laatikkolohkon alustamattomalla sisällöllä toimitettuun allokaattoriin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut values = Box::<[u32], _>::new_uninit_slice_in(3, System);
    ///
    /// let values = unsafe {
    ///     // Lykätty alustus:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_in(len, alloc).into_box(len) }
    }

    /// Rakentaa uuden laatikkolohkon alustamattomalla sisällöllä toimitettuun allokaattoriin muistin ollessa täynnä `0`-tavuja.
    ///
    ///
    /// Katso [`MaybeUninit::zeroed`][zeroed]: stä esimerkkejä tämän menetelmän oikeasta ja väärästä käytöstä.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let values = Box::<[u32], _>::new_zeroed_slice_in(3, System);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_zeroed_in(len, alloc).into_box(len) }
    }
}

impl<T, A: Allocator> Box<mem::MaybeUninit<T>, A> {
    /// Muuntaa `Box<T, A>`: ksi.
    ///
    /// # Safety
    ///
    /// Kuten [`MaybeUninit::assume_init`]: n kohdalla, soittajan on taattava, että arvo todella on alustetussa tilassa.
    ///
    /// Tämän kutsuminen, kun sisältöä ei ole vielä täysin alustettu, aiheuttaa välittömästi määrittelemätöntä käyttäytymistä.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five: Box<u32> = unsafe {
    ///     // Lykätty alustus:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<T, A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut T, alloc) }
    }
}

impl<T, A: Allocator> Box<[mem::MaybeUninit<T>], A> {
    /// Muuntaa `Box<[T], A>`: ksi.
    ///
    /// # Safety
    ///
    /// Kuten [`MaybeUninit::assume_init`]: n kohdalla, soittajan on taattava, että arvot ovat todella alustetussa tilassa.
    ///
    /// Tämän kutsuminen, kun sisältöä ei ole vielä täysin alustettu, aiheuttaa välittömästi määrittelemätöntä käyttäytymistä.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Lykätty alustus:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut [T], alloc) }
    }
}

impl<T: ?Sized> Box<T> {
    /// Rakentaa laatikon raakasta osoittimesta.
    ///
    /// Kun tämä toiminto on kutsuttu, raaka osoitin on tuloksena olevan `Box`: n omistuksessa.
    /// Tarkemmin sanottuna `Box`-tuhoaja kutsuu `T`: n tuhoajan ja vapauttaa varatun muistin.
    /// Jotta tämä olisi turvallista, muistin on oltava allokoitu `Box`: n käyttämän [memory layout]: n mukaisesti.
    ///
    ///
    /// # Safety
    ///
    /// Tämä toiminto on vaarallinen, koska väärä käyttö voi johtaa muistiongelmiin.
    /// Esimerkiksi kaksoisvapaa voi esiintyä, jos funktiota kutsutaan kahdesti samassa raakaosoittimessa.
    ///
    /// Turvallisuusolosuhteet on kuvattu luvussa [memory layout].
    ///
    /// # Examples
    ///
    /// Luo uudelleen `Box`, joka on aiemmin muunnettu raakaosoittimeksi [`Box::into_raw`]: llä:
    ///
    /// ```
    /// let x = Box::new(5);
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Luo `Box` manuaalisesti tyhjästä käyttämällä globaalia kohdistinta:
    ///
    /// ```
    /// use std::alloc::{alloc, Layout};
    ///
    /// unsafe {
    ///     let ptr = alloc(Layout::new::<i32>()) as *mut i32;
    ///     // Yleensä .write vaaditaan välttämään yritystä tuhota `ptr`: n edellinen sisältö (uninitialized), vaikka tässä yksinkertaisessa esimerkissä `*ptr = 5` olisi toiminut myös.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw(ptr);
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub unsafe fn from_raw(raw: *mut T) -> Self {
        unsafe { Self::from_raw_in(raw, Global) }
    }
}

impl<T: ?Sized, A: Allocator> Box<T, A> {
    /// Rakentaa laatikon raaka osoittimesta annetulla allokaattorilla.
    ///
    /// Kun tämä toiminto on kutsuttu, raaka osoitin on tuloksena olevan `Box`: n omistuksessa.
    /// Tarkemmin sanottuna `Box`-tuhoaja kutsuu `T`: n tuhoajan ja vapauttaa varatun muistin.
    /// Jotta tämä olisi turvallista, muistin on oltava allokoitu `Box`: n käyttämän [memory layout]: n mukaisesti.
    ///
    ///
    /// # Safety
    ///
    /// Tämä toiminto on vaarallinen, koska väärä käyttö voi johtaa muistiongelmiin.
    /// Esimerkiksi kaksoisvapaa voi esiintyä, jos funktiota kutsutaan kahdesti samassa raakaosoittimessa.
    ///
    /// # Examples
    ///
    /// Luo uudelleen `Box`, joka on aiemmin muunnettu raakaosoittimeksi [`Box::into_raw_with_allocator`]: llä:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(5, System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Luo `Box` manuaalisesti tyhjästä käyttämällä järjestelmän varainta:
    ///
    /// ```
    /// #![feature(allocator_api, slice_ptr_get)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// unsafe {
    ///     let ptr = System.allocate(Layout::new::<i32>())?.as_mut_ptr();
    ///     // Yleensä .write vaaditaan välttämään yritystä tuhota `ptr`: n edellinen sisältö (uninitialized), vaikka tässä yksinkertaisessa esimerkissä `*ptr = 5` olisi toiminut myös.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw_in(ptr, System);
    /// }
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub unsafe fn from_raw_in(raw: *mut T, alloc: A) -> Self {
        Box(unsafe { Unique::new_unchecked(raw) }, alloc)
    }

    /// Kuluttaa `Box`: n ja palauttaa käärittyjen raakojen osoittimien.
    ///
    /// Osoitin on kohdistettu oikein ja ei nolla.
    ///
    /// Tämän toiminnon soittamisen jälkeen soittaja vastaa `Box`: n aiemmin hallinnoimasta muistista.
    /// Erityisesti soittajan tulisi tuhota `T` oikein ja vapauttaa muisti ottaen huomioon `Box`: n käyttämä [memory layout].
    /// Helpoin tapa tehdä tämä on muuntaa raaka osoitin takaisin `Box`: ksi [`Box::from_raw`]-toiminnolla, jolloin `Box`-hävittäjä voi suorittaa puhdistuksen.
    ///
    ///
    /// Note: tämä on liitetty toiminto, mikä tarkoittaa, että sinun on kutsuttava sitä nimellä `Box::into_raw(b)` eikä `b.into_raw()`.
    /// Tämä johtuu siitä, että sisätyypissä olevan menetelmän kanssa ei ole ristiriitaa.
    ///
    /// # Examples
    /// Raaka osoittimen muuntaminen takaisin `Box`: ksi [`Box::from_raw`]: llä automaattista puhdistusta varten:
    ///
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Manuaalinen puhdistus suorittamalla nimenomaan tuhoaja ja jakamalla muisti:
    ///
    /// ```
    /// use std::alloc::{dealloc, Layout};
    /// use std::ptr;
    ///
    /// let x = Box::new(String::from("Hello"));
    /// let p = Box::into_raw(x);
    /// unsafe {
    ///     ptr::drop_in_place(p);
    ///     dealloc(p as *mut u8, Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub fn into_raw(b: Self) -> *mut T {
        Self::into_raw_with_allocator(b).0
    }

    /// Kuluttaa `Box`: n palauttamalla kääritty raaka osoitin ja allokaattori.
    ///
    /// Osoitin on kohdistettu oikein ja ei nolla.
    ///
    /// Tämän toiminnon soittamisen jälkeen soittaja vastaa `Box`: n aiemmin hallinnoimasta muistista.
    /// Erityisesti soittajan tulisi tuhota `T` oikein ja vapauttaa muisti ottaen huomioon `Box`: n käyttämä [memory layout].
    /// Helpoin tapa tehdä tämä on muuntaa raaka osoitin takaisin `Box`: ksi [`Box::from_raw_in`]-toiminnolla, jolloin `Box`-hävittäjä voi suorittaa puhdistuksen.
    ///
    ///
    /// Note: tämä on liitetty toiminto, mikä tarkoittaa, että sinun on kutsuttava sitä nimellä `Box::into_raw_with_allocator(b)` eikä `b.into_raw_with_allocator()`.
    /// Tämä johtuu siitä, että sisätyypissä olevan menetelmän kanssa ei ole ristiriitaa.
    ///
    /// # Examples
    /// Raaka osoittimen muuntaminen takaisin `Box`: ksi [`Box::from_raw_in`]: llä automaattista puhdistusta varten:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Manuaalinen puhdistus suorittamalla nimenomaan tuhoaja ja jakamalla muisti:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    /// use std::ptr::{self, NonNull};
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// unsafe {
    ///     ptr::drop_in_place(ptr);
    ///     let non_null = NonNull::new_unchecked(ptr);
    ///     alloc.deallocate(non_null.cast(), Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn into_raw_with_allocator(b: Self) -> (*mut T, A) {
        let (leaked, alloc) = Box::into_unique(b);
        (leaked.as_ptr(), alloc)
    }

    #[unstable(
        feature = "ptr_internals",
        issue = "none",
        reason = "use `Box::leak(b).into()` or `Unique::from(Box::leak(b))` instead"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn into_unique(b: Self) -> (Unique<T>, A) {
        // Stacked Borrows tunnistaa Boxin "unique pointer": ksi, mutta sisäisesti se on tyyppijärjestelmän raaka osoitin.
        // Sen muuttamista suoraan raakaosoittimeksi ei tunnisteta "releasing": ksi, joka on yksilöllinen osoitin, joka sallii aliakselliset raakakäynnistykset, joten kaikkien raakapainosmenetelmien on käytävä läpi `Box::leak`.
        //
        // *Tämän* kääntäminen raakaksi osoittimeksi käyttäytyy oikein.
        //
        let alloc = unsafe { ptr::read(&b.1) };
        (Unique::from(Box::leak(b)), alloc)
    }

    /// Palauttaa viitteen alla olevaan allokaattoriin.
    ///
    /// Note: tämä on liitetty toiminto, mikä tarkoittaa, että sinun on kutsuttava sitä nimellä `Box::allocator(&b)` eikä `b.allocator()`.
    /// Tämä johtuu siitä, että sisätyypissä olevan menetelmän kanssa ei ole ristiriitaa.
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(b: &Self) -> &A {
        &b.1
    }

    /// Kuluttaa ja vuotaa `Box`: n palauttaen muutettavan viitteen, `&'a mut T`.
    /// Huomaa, että tyypin `T` on oltava yli valitun käyttöiän `'a`.
    /// Jos tyypillä on vain staattisia viitteitä tai ei lainkaan, tällöin voidaan valita `'static`.
    ///
    /// Tästä toiminnosta on hyötyä lähinnä tiedoille, jotka elävät ohjelman loppuosan.
    /// Palautetun viitteen pudottaminen aiheuttaa muistivuodon.
    /// Jos tämä ei ole hyväksyttävää, viite tulisi ensin kääriä [`Box::from_raw`]-toiminnolla, joka tuottaa `Box`: n.
    ///
    /// Tämä `Box` voidaan sitten pudottaa, mikä tuhoaa `T` oikein ja vapauttaa varatun muistin.
    ///
    /// Note: tämä on liitetty toiminto, mikä tarkoittaa, että sinun on kutsuttava sitä nimellä `Box::leak(b)` eikä `b.leak()`.
    /// Tämä johtuu siitä, että sisätyypissä olevan menetelmän kanssa ei ole ristiriitaa.
    ///
    /// # Examples
    ///
    /// Yksinkertainen käyttö:
    ///
    /// ```
    /// let x = Box::new(41);
    /// let static_ref: &'static mut usize = Box::leak(x);
    /// *static_ref += 1;
    /// assert_eq!(*static_ref, 42);
    /// ```
    ///
    /// Mitoittamattomat tiedot:
    ///
    /// ```
    /// let x = vec![1, 2, 3].into_boxed_slice();
    /// let static_ref = Box::leak(x);
    /// static_ref[0] = 4;
    /// assert_eq!(*static_ref, [4, 2, 3]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "box_leak", since = "1.26.0")]
    #[inline]
    pub fn leak<'a>(b: Self) -> &'a mut T
    where
        A: 'a,
    {
        unsafe { &mut *mem::ManuallyDrop::new(b).0.as_ptr() }
    }

    /// Muuntaa `Box<T>`: n `Pin<Box<T>>`: ksi
    ///
    /// Tämä muunnos ei kohdistu kasaan ja tapahtuu paikallaan.
    ///
    /// Tämä on saatavana myös [`From`]: n kautta.
    #[unstable(feature = "box_into_pin", issue = "62370")]
    pub fn into_pin(boxed: Self) -> Pin<Self>
    where
        A: 'static,
    {
        // `Pin<Box<T>>`: n sisäosia ei voida siirtää tai vaihtaa, kun `T: !Unpin`, joten on turvallista kiinnittää se suoraan ilman lisävaatimuksia.
        //
        //
        unsafe { Pin::new_unchecked(boxed) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized, A: Allocator> Drop for Box<T, A> {
    fn drop(&mut self) {
        // FIXME: Älä tee mitään, pudottimen suorittaa tällä hetkellä kääntäjä.
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Box<T> {
    /// Luo `Box<T>`-arvon, jonka X-arvo on T.
    fn default() -> Self {
        box T::default()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Box<[T]> {
    fn default() -> Self {
        Box::<[T; 0]>::new([])
    }
}

#[stable(feature = "default_box_extra", since = "1.17.0")]
impl Default for Box<str> {
    fn default() -> Self {
        unsafe { from_boxed_utf8_unchecked(Default::default()) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<T, A> {
    /// Palauttaa uuden laatikon, jossa on `clone()` tämän laatikon sisältöä.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let y = x.clone();
    ///
    /// // Arvo on sama
    /// assert_eq!(x, y);
    ///
    /// // Mutta ne ovat ainutlaatuisia esineitä
    /// assert_ne!(&*x as *const i32, &*y as *const i32);
    /// ```
    #[inline]
    fn clone(&self) -> Self {
        // Määritä muistia ennakolta, jotta kloonattu arvo voidaan kirjoittaa suoraan.
        let mut boxed = Self::new_uninit_in(self.1.clone());
        unsafe {
            (**self).write_clone_into_raw(boxed.as_mut_ptr());
            boxed.assume_init()
        }
    }

    /// Kopioi lähteen sisällön `self`: ään luomatta uutta varausta.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let mut y = Box::new(10);
    /// let yp: *const i32 = &*y;
    ///
    /// y.clone_from(&x);
    ///
    /// // Arvo on sama
    /// assert_eq!(x, y);
    ///
    /// // Ja mitään jakamista ei tapahtunut
    /// assert_eq!(yp, &*y);
    /// ```
    #[inline]
    fn clone_from(&mut self, source: &Self) {
        (**self).clone_from(&(**source));
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl Clone for Box<str> {
    fn clone(&self) -> Self {
        // tämä tekee kopion tiedoista
        let buf: Box<[u8]> = self.as_bytes().into();
        unsafe { from_boxed_utf8_unchecked(buf) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq, A: Allocator> PartialEq for Box<T, A> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        PartialEq::eq(&**self, &**other)
    }
    #[inline]
    fn ne(&self, other: &Self) -> bool {
        PartialEq::ne(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd, A: Allocator> PartialOrd for Box<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
    #[inline]
    fn lt(&self, other: &Self) -> bool {
        PartialOrd::lt(&**self, &**other)
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        PartialOrd::le(&**self, &**other)
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        PartialOrd::ge(&**self, &**other)
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        PartialOrd::gt(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord, A: Allocator> Ord for Box<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq, A: Allocator> Eq for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash, A: Allocator> Hash for Box<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<T: ?Sized + Hasher, A: Allocator> Hasher for Box<T, A> {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Box<T> {
    /// Muuntaa yleisen tyypin `T` `Box<T>`: ksi
    ///
    /// Muunnos kohdistaa kasaan ja siirtää `t`: n pinosta siihen.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let x = 5;
    /// let boxed = Box::new(5);
    ///
    /// assert_eq!(Box::from(x), boxed);
    /// ```
    fn from(t: T) -> Self {
        Box::new(t)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> From<Box<T, A>> for Pin<Box<T, A>>
where
    A: 'static,
{
    /// Muuntaa `Box<T>`: n `Pin<Box<T>>`: ksi
    ///
    /// Tämä muunnos ei kohdistu kasaan ja tapahtuu paikallaan.
    fn from(boxed: Box<T, A>) -> Self {
        Box::into_pin(boxed)
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl<T: Copy> From<&[T]> for Box<[T]> {
    /// Muuntaa `&[T]`: n `Box<[T]>`: ksi
    ///
    /// Tämä muunnos kohdistaa kasaan ja suorittaa kopion `slice`: stä.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // luo&[u8], jota käytetään laatikon luomiseen <[u8]>
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice: Box<[u8]> = Box::from(slice);
    ///
    /// println!("{:?}", boxed_slice);
    /// ```
    fn from(slice: &[T]) -> Box<[T]> {
        let len = slice.len();
        let buf = RawVec::with_capacity(len);
        unsafe {
            ptr::copy_nonoverlapping(slice.as_ptr(), buf.ptr(), len);
            buf.into_box(slice.len()).assume_init()
        }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl<T: Copy> From<Cow<'_, [T]>> for Box<[T]> {
    #[inline]
    fn from(cow: Cow<'_, [T]>) -> Box<[T]> {
        match cow {
            Cow::Borrowed(slice) => Box::from(slice),
            Cow::Owned(slice) => Box::from(slice),
        }
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl From<&str> for Box<str> {
    /// Muuntaa `&str`: n `Box<str>`: ksi
    ///
    /// Tämä muunnos kohdistaa kasaan ja suorittaa kopion `s`: stä.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<str> = Box::from("hello");
    /// println!("{}", boxed);
    /// ```
    #[inline]
    fn from(s: &str) -> Box<str> {
        unsafe { from_boxed_utf8_unchecked(Box::from(s.as_bytes())) }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl From<Cow<'_, str>> for Box<str> {
    #[inline]
    fn from(cow: Cow<'_, str>) -> Box<str> {
        match cow {
            Cow::Borrowed(s) => Box::from(s),
            Cow::Owned(s) => Box::from(s),
        }
    }
}

#[stable(feature = "boxed_str_conv", since = "1.19.0")]
impl<A: Allocator> From<Box<str, A>> for Box<[u8], A> {
    /// Muuntaa `Box<str>`: n `Box<[u8]>`: ksi
    /// Tämä muunnos ei kohdistu kasaan ja tapahtuu paikallaan.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // luo laatikko<str>jota käytetään laatikon <[u8]> luomiseen
    /// let boxed: Box<str> = Box::from("hello");
    /// let boxed_str: Box<[u8]> = Box::from(boxed);
    ///
    /// // luo&[u8], jota käytetään laatikon luomiseen <[u8]>
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice = Box::from(slice);
    ///
    /// assert_eq!(boxed_slice, boxed_str);
    /// ```
    #[inline]
    fn from(s: Box<str, A>) -> Self {
        let (raw, alloc) = Box::into_raw_with_allocator(s);
        unsafe { Box::from_raw_in(raw as *mut [u8], alloc) }
    }
}

#[stable(feature = "box_from_array", since = "1.45.0")]
impl<T, const N: usize> From<[T; N]> for Box<[T]> {
    /// Muuntaa `[T; N]`: n `Box<[T]>`: ksi
    /// Tämä muunnos siirtää matriisin vasta kasaan varattuun muistiin.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<[u8]> = Box::from([4, 2]);
    /// println!("{:?}", boxed);
    /// ```
    fn from(array: [T; N]) -> Box<[T]> {
        box array
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Box<[T]>> for Box<[T; N]> {
    type Error = Box<[T]>;

    fn try_from(boxed_slice: Box<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Box::from_raw(Box::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

impl<A: Allocator> Box<dyn Any, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Yritä alentaa laatikkoa konkreettiseksi tyypiksi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut dyn Any, _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Yritä alentaa laatikkoa konkreettiseksi tyypiksi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send), _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send + Sync, A> {
    #[inline]
    #[stable(feature = "box_send_sync_any_downcast", since = "1.51.0")]
    /// Yritä alentaa laatikkoa konkreettiseksi tyypiksi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send + Sync), _) =
                    Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized, A: Allocator> fmt::Display for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug + ?Sized, A: Allocator> fmt::Debug for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> fmt::Pointer for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Sisäistä Uniqia ei ole mahdollista purkaa suoraan laatikosta, vaan heitämme sen * const: iin, joka peittää Uniikin
        //
        let ptr: *const T = &**self;
        fmt::Pointer::fmt(&ptr, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> Deref for Box<T, A> {
    type Target = T;

    fn deref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> DerefMut for Box<T, A> {
    fn deref_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized, A: Allocator> Receiver for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized, A: Allocator> Iterator for Box<I, A> {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth(n)
    }
    fn last(self) -> Option<I::Item> {
        BoxIter::last(self)
    }
}

trait BoxIter {
    type Item;
    fn last(self) -> Option<Self::Item>;
}

impl<I: Iterator + ?Sized, A: Allocator> BoxIter for Box<I, A> {
    type Item = I::Item;
    default fn last(self) -> Option<I::Item> {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }
}

/// Erikoistuminen erikokoisille ``I``-laitteille, joka käyttää `last()`: n I-toteutusta oletusarvon sijaan.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator, A: Allocator> BoxIter for Box<I, A> {
    fn last(self) -> Option<I::Item> {
        (*self).last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: DoubleEndedIterator + ?Sized, A: Allocator> DoubleEndedIterator for Box<I, A> {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized, A: Allocator> ExactSizeIterator for Box<I, A> {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized, A: Allocator> FusedIterator for Box<I, A> {}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnOnce<Args> + ?Sized, A: Allocator> FnOnce<Args> for Box<F, A> {
    type Output = <F as FnOnce<Args>>::Output;

    extern "rust-call" fn call_once(self, args: Args) -> Self::Output {
        <F as FnOnce<Args>>::call_once(*self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnMut<Args> + ?Sized, A: Allocator> FnMut<Args> for Box<F, A> {
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output {
        <F as FnMut<Args>>::call_mut(self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: Fn<Args> + ?Sized, A: Allocator> Fn<Args> for Box<F, A> {
    extern "rust-call" fn call(&self, args: Args) -> Self::Output {
        <F as Fn<Args>>::call(self, args)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized, A: Allocator> CoerceUnsized<Box<U, A>> for Box<T, A> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Box<U>> for Box<T, Global> {}

#[stable(feature = "boxed_slice_from_iter", since = "1.32.0")]
impl<I> FromIterator<I> for Box<[I]> {
    fn from_iter<T: IntoIterator<Item = I>>(iter: T) -> Self {
        iter.into_iter().collect::<Vec<_>>().into_boxed_slice()
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<[T], A> {
    fn clone(&self) -> Self {
        let alloc = Box::allocator(self).clone();
        self.to_vec_in(alloc).into_boxed_slice()
    }

    fn clone_from(&mut self, other: &Self) {
        if self.len() == other.len() {
            self.clone_from_slice(&other);
        } else {
            *self = other.clone();
        }
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::Borrow<T> for Box<T, A> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::BorrowMut<T> for Box<T, A> {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsRef<T> for Box<T, A> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsMut<T> for Box<T, A> {
    fn as_mut(&mut self) -> &mut T {
        &mut **self
    }
}

/* Nota bene
 *
 *  We could have chosen not to add this impl, and instead have written a
 *  function of Pin<Box<T>> to Pin<T>. Such a function would not be sound,
 *  because Box<T> implements Unpin even when T does not, as a result of
 *  this impl.
 *
 *  We chose this API instead of the alternative for a few reasons:
 *      - Logically, it is helpful to understand pinning in regard to the
 *        memory region being pointed to. For this reason none of the
 *        standard library pointer types support projecting through a pin
 *        (Box<T> is the only pointer type in std for which this would be
 *        safe.)
 *      - It is in practice very useful to have Box<T> be unconditionally
 *        Unpin because of trait objects, for which the structural auto
 *        trait functionality does not apply (e.g., Box<dyn Foo> would
 *        otherwise not be Unpin).
 *
 *  Another type with the same semantics as Box but only a conditional
 *  implementation of `Unpin` (where `T: Unpin`) would be valid/safe, and
 *  could have a method to project a Pin<T> from it.
 */
#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> Unpin for Box<T, A> where A: 'static {}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R, A: Allocator> Generator<R> for Box<G, A>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R, A: Allocator> Generator<R> for Pin<Box<G, A>>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin, A: Allocator> Future for Box<F, A>
where
    A: 'static,
{
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut *self), cx)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for Box<S> {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        Pin::new(&mut **self).poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}