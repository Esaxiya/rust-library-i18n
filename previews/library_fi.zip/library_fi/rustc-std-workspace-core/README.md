# `rustc-std-workspace-core` crate

Tämä crate on välilevy ja tyhjä crate, joka yksinkertaisesti riippuu `libcore`: stä ja vie kaiken sisällön uudelleen.
crate on vakiokirjaston valtuuttamisen ydin crates.io: n riippuvuuteen crates: stä

Crates crates.io: ssä, että vakiokirjasto riippuu tarpeesta riippua crates.io: n `rustc-std-workspace-core` crate: sta, joka on tyhjä.

Käytämme `[patch]`: ää korvaamaan sen tähän arkistoon tälle crate: lle.
Tämän seurauksena crates.io: n crates piirtää riippuvuuden edge-`libcore`, tässä arkistossa määritetyn version.
Sen pitäisi piirtää kaikki riippuvuusreunat, jotta Cargo rakentaa crates: n onnistuneesti!

Huomaa, että crates.io: n crates: n on oltava riippuvainen tästä crate: stä nimellä `core`, jotta kaikki toimisi oikein.Tätä varten he voivat käyttää:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

`package`-avaimen avulla crate nimetään uudelleen `core`: ksi, mikä tarkoittaa, että se näyttää

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

kun Cargo käynnistää kääntäjän, täyttää kääntäjän injektoiman implisiittisen `extern crate core`-direktiivin.




