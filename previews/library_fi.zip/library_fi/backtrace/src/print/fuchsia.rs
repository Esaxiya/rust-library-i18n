use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr ottaa takaisinsoiton, joka vastaanottaa dl_phdr_info-osoittimen jokaisesta prosessiin linkitetystä DSO: sta.
    // dl_iterate_phdr varmistaa myös, että dynaaminen linkkeri on lukittu iteroinnin alusta loppuun.
    // Jos soittopyyntö palauttaa arvon, joka ei ole nolla, iterointi lopetetaan aikaisin.
    // 'data' siirretään kolmanneksi argumentiksi soiton takaisinsoittoon jokaisessa puhelussa.
    // 'size' antaa dl_phdr_infon koon.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Meidän on jäsennettävä koontitunnus ja joitain perusohjelman otsikkotietoja, mikä tarkoittaa, että tarvitsemme myös vähän tavaraa ELF-spesifikaatioista.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Nyt meidän on kopioitava bitistä bitteihin fuchsian nykyisen dynaamisen linkin käyttämän dl_phdr_info-tyypin rakenne.
// Chromiumilla on myös tämä ABI-raja sekä crashpad.
// Haluaisimme kuitenkin siirtää nämä tapaukset käyttää tonttuhakua, mutta meidän on annettava se SDK: ssa, mitä ei ole vielä tehty.
//
// Siksi meidän (ja heidän) on juuttunut siihen, että meidän on käytettävä tätä menetelmää, joka aiheuttaa tiukan kytkennän fuksia libc: n kanssa.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Meillä ei ole mitään tapaa tarkistaa, ovatko e_phoff ja e_phnum voimassa.
    // libc: n tulisi kuitenkin varmistaa tämä meille, joten on turvallista muodostaa siivu tähän.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr edustaa 64-bittistä ELF-ohjelman otsikkoa kohdearkkitehtuurin endianiteetissa.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr edustaa kelvollista ELF-ohjelman otsikkoa ja sen sisältöä.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Meillä ei ole mitään tapaa tarkistaa, ovatko p_addr tai p_memsz voimassa.
    // Fuksian libc jäsentää muistiinpanot ensin, joten täällä ollessaan näiden otsikoiden on oltava kelvollisia.
    //
    // NoteIter ei vaadi taustalla olevien tietojen olevan kelvollisia, mutta se vaatii rajojen olevan voimassa.
    // Luotamme siihen, että libc on varmistanut, että tämä pätee meihin täällä.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Rakennustunnusten muistiinpanotyyppi.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr edustaa ELF-huomautuksen otsikkoa kohteen endianiteetissa.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Huomautus edustaa ELF-muistiinpanoa (otsikko + sisältö).
// Nimi jätetään u8-siivuksi, koska se ei ole aina tyhjä ja rust tekee tarpeeksi helpoksi tarkistaa, että tavut vastaavat kumpaakin.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter antaa sinun toistaa turvallisesti muistiinpanosegmentin yli.
// Se päättyy heti, kun tapahtuu virhe tai muistiinpanoja ei ole enää.
// Jos toistat virheellisiä tietoja, se toimii ikään kuin muistiinpanoja ei löydy.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Toiminnon invariantti on se, että annettu osoitin ja koko merkitsevät kelvollista tavualueita, jotka kaikki voidaan lukea.
    // Näiden tavujen sisältö voi olla mitä tahansa, mutta alueen on oltava voimassa, jotta tämä olisi turvallista.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to kohdistaa 'x': n tavutyyppiseen kohdistukseen olettaen, että 'to' on 2: n teho.
// Tämä noudattaa standardimallia C/C ++ ELF-jäsentökoodissa, jossa käytetään (x +-, 1) ja -to.
// Rust ei anna sinun kiistää käyttöä, joten käytän
// 2: n komplementtimuunnos sen luomiseksi uudelleen.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 kuluttaa numeeria tavasta leikkeestä (jos sellainen on) ja varmistaa lisäksi, että lopullinen siivu on kohdistettu oikein.
// Jos joko pyydettyjen tavujen lukumäärä on liian suuri tai osiota ei voida kohdistaa jälkikäteen, koska jäljellä olevia tavuja ei ole riittävästi, None palautetaan eikä osaa muuteta.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Tällä toiminnolla ei ole todellisia invarianteja, joiden soittajan on pidettävä kiinni muusta kuin ehkä siitä, että 'bytes' tulisi kohdistaa suorituskyvyn (ja joissakin arkkitehtuureissa virheettömyyden) vuoksi.
// Elf_Nhdr-kenttien arvot saattavat olla hölynpölyä, mutta tämä toiminto ei takaa sellaista.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Tämä on turvallista, kunhan tilaa on tarpeeksi, ja me vain vahvistimme, että yllä olevassa if-lauseessa tämän ei pitäisi olla vaarallista.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Huomaa, että sice_of: :<Elf_Nhdr>() on tasattu aina 4 tavua.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Tarkista, onko päässyt loppuun.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Muunnamme nhdr: n, mutta harkitsemme tuloksena olevaa rakennetta huolellisesti.
        // Emme luota namesziin tai descsz: ään, emmekä tee vaarallisia päätöksiä tyypin perusteella.
        //
        // Joten vaikka saisimme täydellisen jätteen, meidän pitäisi silti olla turvassa.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Osoittaa, että segmentti on suoritettavissa.
const PERM_X: u32 = 0b00000001;
/// Osoittaa, että segmentti on kirjoitettavissa.
const PERM_W: u32 = 0b00000010;
/// Osoittaa, että segmentti on luettavissa.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Edustaa ELF-segmenttiä ajon aikana.
struct Segment {
    /// Antaa tämän segmentin sisällön ajonaikaisen virtuaalisen osoitteen.
    addr: usize,
    /// Antaa tämän segmentin sisällön muistikoon.
    size: usize,
    /// Antaa tämän segmentin moduulin virtuaalisen osoitteen ELF-tiedoston kanssa.
    mod_rel_addr: usize,
    /// Antaa ELF-tiedostosta löytyvät oikeudet.
    /// Nämä käyttöoikeudet eivät kuitenkaan välttämättä ole ajonaikaisia käyttöoikeuksia.
    flags: Perm,
}

/// Antaa yhden iteroida segmenttien välillä verkonhaltijalta.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Edustaa ELF DSO: ta (Dynamic Shared Object).
/// Tämä tyyppi viittaa varsinaiseen verkonhaltijaan tallennettuihin tietoihin sen sijaan, että tekisi oman kopion.
struct Dso<'a> {
    /// Dynaaminen linkkeri antaa meille aina nimen, vaikka nimi olisi tyhjä.
    /// Pääohjelman tapauksessa tämä nimi on tyhjä.
    /// Jaetun objektin tapauksessa se on soname (katso DT_SONAME).
    name: &'a str,
    /// Fuksiassa käytännössä kaikilla binääreillä on rakennustunnukset, mutta tämä ei ole tiukka vaatimus.
    /// Ei ole mitään tapaa sovittaa DSO-tietoja oikeaan ELF-tiedostoon jälkikäteen, jos build_id-tunnusta ei ole, joten vaadimme, että jokaisella jakeluverkonhaltijalla on yksi täällä.
    ///
    /// DSO: t, joilla ei ole build_id-tunnusta, jätetään huomioimatta.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Palauttaa iteraattorin tämän DSO: n segmenttien yli.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Nämä virheet koodaavat ongelmia, jotka syntyvät jäsennettäessä tietoja kustakin DSO: sta.
///
enum Error {
    /// NameError tarkoittaa, että tapahtui virhe muunnettaessa C-tyylimerkkijono rust-merkkijonoksi.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError tarkoittaa, että emme löytäneet rakennustunnusta.
    /// Tämä voi johtua joko siitä, että verkonhaltijalla ei ollut koontitunnusta, tai siksi, että koontitunnuksen sisältävä segmentti oli väärin muotoiltu.
    ///
    BuildIDError,
}

/// Kutsuu joko 'dso' tai 'error' jokaiselle DSO: lle, joka on linkitetty prosessiin dynaamisen linkin avulla.
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter, jolla on yksi syömismenetelmistä, nimeltään foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr varmistaa, että info.name osoittaa oikeaan sijaintiin.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Tämä toiminto tulostaa Fuchsia-symbolointimerkinnän kaikille DSO: n sisältämille tiedoille.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}