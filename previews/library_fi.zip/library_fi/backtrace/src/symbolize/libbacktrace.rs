//! Symbolointistrategia, joka käyttää DWARF-jäsentökoodia libbacktracessa.
//!
//! Libbacktrace C-kirjasto, joka tavallisesti jaetaan gcc: n kanssa, tukee paitsi jälkikäteen luomista (jota emme itse asiassa käytä), mutta myös symboloi taaksepäin jälkeä ja käsittelee kääpiöiden virheenkorjaustietoja esimerkiksi viivoitetuista kehyksistä ja muusta.
//!
//!
//! Tämä on suhteellisen monimutkaista, koska täällä on paljon erilaisia huolenaiheita, mutta perusajatus on:
//!
//! * Ensin soitamme `backtrace_syminfo`.Tämä saa symbolitiedot dynaamisesta symbolitaulukosta, jos voimme.
//! * Seuraavaksi soitamme `backtrace_pcinfo`.Tämä jäsentää debuginfotaulukot, jos ne ovat käytettävissä, ja antaa meille mahdollisuuden palauttaa tietoja sisäisistä kehyksistä, tiedostonimistä, rivinumeroista jne.
//!
//! Kääpiöpöytien saamiseksi libbacktraceen on paljon temppuja, mutta toivottavasti se ei ole maailman loppu ja on tarpeeksi selkeä lukiessasi alla.
//!
//! Tämä on oletusmerkkistrategia muille kuin MSVC-ja ei-OSX-alustoille.Libstd: ssä tämä on kuitenkin OSX: n oletusstrategia.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Jos mahdollista, mieluummin suosittelemme virheenkorjausinfosta tulevaa `function`-nimeä, joka voi tyypillisesti olla tarkempi esimerkiksi inline-kehyksille.
                // Jos sitä ei ole, palaa takaisin `symname`: ssä määritettyyn symbolitaulukon nimeen.
                //
                // Huomaa, että joskus `function` voi tuntua hieman epätarkemmalta, esimerkiksi se, että se on listattu `try<i32,closure>`: ksi, ei `std::panicking::try::do_call`: n sijasta.
                //
                // Ei ole oikeastaan selvää miksi, mutta kaiken kaikkiaan `function`-nimi näyttää tarkemmalta.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // älä tee mitään toistaiseksi
}

/// `data`-osoittimen tyyppi siirretään `syminfo_cb`: ään
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Kun tämä takaisinsoitto on kutsuttu `backtrace_syminfo`: ltä, kun aloitamme ratkaisun, menemme pidemmälle ja kutsumme `backtrace_pcinfo`: ää.
    // `backtrace_pcinfo`-toiminto etsii virheenkorjaustietoja ja yrittää tehdä asioita, kuten palauttaa file/line-tiedot sekä viivatut kehykset.
    // Huomaa kuitenkin, että `backtrace_pcinfo` voi epäonnistua tai tehdä paljon, jos virheenkorjaustietoja ei ole, joten jos näin tapahtuu, soitamme varmasti takaisinsoittoon vähintään yhdellä `syminfo_cb`: n symbolilla.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// `data`-osoittimen tyyppi siirretään `pcinfo_cb`: ään
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Libbacktrace-sovellusliittymä tukee tilan luomista, mutta se ei tue valtion tuhoamista.
// Henkilökohtaisesti pidän tätä tarkoittavana, että valtio on tarkoitus luoda ja elää sitten ikuisesti.
//
// Haluaisin rekisteröidä at_exit()-käsittelijän, joka puhdistaa tämän tilan, mutta libbacktrace ei tarjoa tapaa tehdä niin.
//
// Näillä rajoituksilla tällä toiminnolla on staattisesti välimuistissa oleva tila, joka lasketaan ensimmäisen kerran, kun tätä pyydetään.
//
// Muista, että kaikki jäljitelmät tapahtuvat sarjaan (yksi yleinen lukitus).
//
// Huomaa, että synkronoinnin puute johtuu vaatimuksesta, että `resolve` on ulkoisesti synkronoitu.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Älä käytä libbacktracen langattomia ominaisuuksia, koska kutsumme sitä aina synkronoidusti.
        //
        0,
        error_cb,
        ptr::null_mut(), // ei ylimääräisiä tietoja
    );

    return STATE;

    // Huomaa, että libbacktracen toimimiseksi se on löydettävä DWARF-virheenkorjaustiedot nykyiselle suoritettavalle tiedostolle.Se tekee sen tyypillisesti useiden mekanismien avulla, mukaan lukien muun muassa:
    //
    // * /proc/self/exe tuetuilla alustoilla
    // * Tiedostonimi välitettiin nimenomaisesti tilaa luodessa
    //
    // Libbacktrace-kirjasto on iso joukko C-koodia.Tämä tarkoittaa luonnollisesti, että sillä on muistin turvallisuushaavoittuvuudet, varsinkin kun käsitellään väärin muotoiltua debuginfoa.
    // Libstd on törmännyt paljon näihin historiallisesti.
    //
    // Jos käytetään /proc/self/exe: ää, voimme yleensä jättää nämä huomiotta, koska oletamme, että libbacktrace on "mostly correct" eikä muuten tee outoja asioita "attempted to be correct"-kääpiön virheenkorjaustiedoilla.
    //
    //
    // Jos välitämme kuitenkin tiedostonimen, se on mahdollista joillakin alustoilla (kuten BSD: t), joissa haitallinen toimija voi aiheuttaa mielivaltaisen tiedoston sijoittamisen kyseiseen sijaintiin.
    // Tämä tarkoittaa, että jos kerromme libbacktrace-tiedostolle tiedostonimen, se saattaa käyttää mielivaltaista tiedostoa, joka saattaa aiheuttaa häiriöitä.
    // Jos emme kuitenkaan kerro libbacktracelle mitään, niin se ei tee mitään alustoilla, jotka eivät tue polkuja, kuten /proc/self/exe!
    //
    // Kaiken kaikkiaan yritämme niin kovasti kuin mahdollista *ei* siirtää tiedostonimeä, mutta meidän on tehtävä alustoilla, jotka eivät tue /proc/self/exe: ää lainkaan.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Huomaa, että ihannetapauksessa käytämme `std::env::current_exe`: ää, mutta emme voi vaatia `std`: ää täällä.
            //
            // Käytä `_NSGetExecutablePath` ladataksesi nykyisen suoritettavan polun staattiselle alueelle (josta jos se on liian pieni, anna vain periksi).
            //
            //
            // Huomaa, että luotamme vakavasti siihen, että libbacktrace ei kuole korruptoituneisiin suoritettaviin tiedostoihin, mutta se varmasti ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows on tiedostojen avaustila, jossa avaamisen jälkeen sitä ei voida poistaa.
            // Se on yleensä sitä, mitä haluamme täällä, koska haluamme varmistaa, että suoritettava tiedostomme ei muutu alla olevasta sisällöstä sen jälkeen, kun luovutamme sen libbacktraceen, toivottavasti lieventämällä kykyä siirtää mielivaltaisia tietoja libbacktraceen (jota voidaan käsitellä väärin).
            //
            //
            // Ottaen huomioon, että teemme vähän tanssia yrittääksemme saada eräänlainen lukko omaan kuvaan:
            //
            // * Hanki kahva nykyiseen prosessiin, lataa sen tiedostonimi.
            // * Avaa tiedosto kyseiselle tiedostonimelle oikeilla lipuilla.
            // * Lataa nykyisen prosessin tiedostonimi uudelleen ja varmista, että se on sama
            //
            // Jos tämä kaikki kulkee, olemme teoriassa todella avanneet prosessimme tiedoston ja taataan, että se ei muutu.FWIW joukko tätä kopioidaan libstd: stä historiallisesti, joten tämä on paras tulkintani tapahtumasta.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Tämä elää staattisessa muistissa, jotta voimme palauttaa sen ..
                static mut BUF: [i8; N] = [0; N];
                // ... ja tämä elää pinossa, koska se on väliaikaista
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // vuotaa `handle` tahallaan tänne, koska sen avaaminen pitää säilyttää lukituksen tälle tiedostonimelle.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Haluamme palauttaa viipaleen, joka on nul-päättynyt, joten jos kaikki on täytetty ja se on yhtä suuri kuin kokonaispituus, vertaa se epäonnistumiseen.
                //
                //
                // Muussa tapauksessa, kun palaat menestykseen, varmista, että nul-tavu sisältyy osaan.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // backtrace-virheet on tällä hetkellä pyyhitty maton alle
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Soita `backtrace_syminfo`-sovellusliittymään, jonka (lukemalla koodi) pitäisi soittaa `syminfo_cb`: lle täsmälleen kerran (tai epäonnistua oletettavasti virheellä).
    // Sitten käsittelemme enemmän `syminfo_cb`: ssä.
    //
    // Huomaa, että teemme tämän, koska `syminfo` etsii symbolitaulukkoa etsimällä symbolien nimet, vaikka binaarissa ei ole virheenkorjaustietoja.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}