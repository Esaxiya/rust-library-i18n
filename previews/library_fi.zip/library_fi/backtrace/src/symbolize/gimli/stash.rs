// käytetään vain Linux: ssä juuri nyt, joten salli kuollut koodi muualla
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Yksinkertainen areenaallokaattori tavupuskureille.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Varaa määrätyn kokoisen puskurin ja palauttaa siihen muutettavan viitteen.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // TURVALLISUUS: tämä on ainoa toiminto, joka koskaan muodostaa muutettavan
        // viittaus `self.buffers`: ään.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // TURVALLISUUS: emme koskaan poista elementtejä `self.buffers`: stä, joten viite
        // minkä tahansa puskurin sisällä oleviin tietoihin elää niin kauan kuin `self` elää.
        &mut buffers[i]
    }
}