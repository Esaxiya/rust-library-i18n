use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Selvitä osoite symbolille ja välitä symboli määritetylle sulkimelle.
///
/// Tämä toiminto etsii annetun osoitteen alueilta, kuten paikallinen symbolitaulukko, dynaaminen symbolitaulukko tai DWARF-virheenkorjaustiedot (aktivoidusta toteutuksesta riippuen) löytääkseen tarvittavat symbolit.
///
///
/// Sulkemista ei voida kutsua, jos resoluutiota ei voitu suorittaa, ja sitä voidaan kutsua myös useammin kuin kerran, jos kyseessä ovat linjatut toiminnot.
///
/// Annetut symbolit edustavat suoritusta määritetyllä `addr`: llä ja palauttavat file/line-parit tälle osoitteelle (jos käytettävissä).
///
/// Huomaa, että jos sinulla on `Frame`, on suositeltavaa käyttää `resolve_frame`-toimintoa tämän sijaan.
///
/// # Vaaditut ominaisuudet
///
/// Tämä toiminto edellyttää, että `backtrace` crate: n `std`-ominaisuus on käytössä, ja `std`-ominaisuus on oletusarvoisesti käytössä.
///
/// # Panics
///
/// Tämä toiminto pyrkii olemaan koskaan panic, mutta jos `cb` toimitti panics: n, jotkut alustat pakottavat kaksinkertaisen panic: n keskeyttämään prosessin.
/// Jotkut käyttöympäristöt käyttävät C-kirjastoa, joka käyttää sisäisesti soittopyyntöjä, joita ei voi purkaa, joten `cb`: n paniikki voi aiheuttaa prosessin keskeytymisen.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // katso vain yläkehystä
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Selvitä aiemmin kaapattu kehys symboliksi ja välitä symboli määritettyyn sulkimeen.
///
/// Tämä funktiini suorittaa saman toiminnon kuin `resolve` paitsi, että se käyttää argumenttina osoitteen sijaan `Frame`: ää.
/// Tämä voi sallia joidenkin käyttöympäristöjen takaisinkelausratkaisujen tarjoavan tarkempia symbolitietoja tai tietoja esimerkiksi sisäisistä kehyksistä.
///
/// On suositeltavaa käyttää tätä, jos voit.
///
/// # Vaaditut ominaisuudet
///
/// Tämä toiminto edellyttää, että `backtrace` crate: n `std`-ominaisuus on käytössä, ja `std`-ominaisuus on oletusarvoisesti käytössä.
///
/// # Panics
///
/// Tämä toiminto pyrkii olemaan koskaan panic, mutta jos `cb` toimitti panics: n, jotkut alustat pakottavat kaksinkertaisen panic: n keskeyttämään prosessin.
/// Jotkut käyttöympäristöt käyttävät C-kirjastoa, joka käyttää sisäisesti soittopyyntöjä, joita ei voi purkaa, joten `cb`: n paniikki voi aiheuttaa prosessin keskeytymisen.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // katso vain yläkehystä
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Pino-kehysten IP-arvot ovat tyypillisesti (always?) käskyä * puhelun jälkeen, joka on varsinainen pinon jäljitys.
// Tämän symboloiminen aiheuttaa filename/line-numeron olevan yksi eteenpäin ja ehkä tyhjäksi, jos se on lähellä toiminnon loppua.
//
// Tämä näyttää olevan periaatteessa aina kaikilla alustoilla, joten vähennämme aina yhden ratkaistusta ip: stä ratkaistaksemme sen edelliseen puheluohjeeseen sen sijaan, että käsky palautettaisiin.
//
//
// Ihannetapauksessa emme tekisi tätä.
// Ihannetapauksessa vaadimme `resolve`-sovellusliittymien soittajia tekemään manuaalisesti -1 ja ottamaan huomioon, että he haluavat sijaintitiedot *edelliselle*-komennolle, ei nykyiselle.
// Ihannetapauksessa altistaisimme myös `Frame`: lle, jos todellakin olemme seuraavan käskyn tai nykyisen osoitteen osoite.
//
// Toistaiseksi tämä on melko kapea huolenaihe, joten me vain sisäisesti vähennämme yhden.
// Kuluttajien tulisi jatkaa työskentelyä ja saavuttaa melko hyviä tuloksia, joten meidän pitäisi olla tarpeeksi hyviä.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Sama kuin `resolve`, vain vaarallinen, koska sitä ei ole synkronoitu.
///
/// Tällä toiminnolla ei ole synkronointitakuita, mutta se on käytettävissä, kun tämän crate: n `std`-ominaisuutta ei ole käännetty sisään.
/// Katso lisätietoja `resolve`-toiminnosta ja esimerkkejä.
///
/// # Panics
///
/// Katso `resolve`: n tiedot `cb`-paniikkia koskevista varoituksista.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Sama kuin `resolve_frame`, vain vaarallinen, koska sitä ei ole synkronoitu.
///
/// Tällä toiminnolla ei ole synkronointitakuita, mutta se on käytettävissä, kun tämän crate: n `std`-ominaisuutta ei ole käännetty sisään.
/// Katso lisätietoja `resolve_frame`-toiminnosta ja esimerkkejä.
///
/// # Panics
///
/// Katso `resolve_frame`: n tiedot `cb`-paniikkia koskevista varoituksista.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait, joka edustaa tiedoston symbolin tarkkuutta.
///
/// Tämä trait tuotetaan trait-objektina `backtrace::resolve`-toiminnolle annettuun sulkemiseen, ja se lähetetään käytännössä, koska ei tiedetä, mikä toteutus on sen takana.
///
///
/// Symboli voi antaa asiayhteyteen liittyviä tietoja toiminnosta, esimerkiksi nimen, tiedostonimen, rivinumeron, tarkan osoitteen jne.
/// Kaikkia tietoja ei kuitenkaan aina ole saatavana symbolina, joten kaikki menetelmät palauttavat `Option`: n.
///
///
pub struct Symbol {
    // TODO: tämä elinikäinen sidos on lopulta jatkettava `Symbol`: ään,
    // mutta se on tällä hetkellä murtava muutos.
    // Toistaiseksi tämä on turvallista, koska `Symbol` on aina jaettu vain viitteenä, eikä sitä voida kloonata.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Palauttaa tämän toiminnon nimen.
    ///
    /// Palautettua rakennetta voidaan käyttää kyselemään erilaisia ominaisuuksia symbolin nimestä:
    ///
    ///
    /// * `Display`-toteutus tulostaa puretun symbolin.
    /// * Symbolin raakaa `str`-arvoa voidaan käyttää (jos se on kelvollinen utf-8).
    /// * Symbolin nimen käsittelemättömät tavut ovat käytettävissä.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Palauttaa tämän toiminnon aloitusosoitteen.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Palauttaa raakan tiedostonimen viipaleeksi.
    /// Tästä on hyötyä pääasiassa `no_std`-ympäristöissä.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Palauttaa sarakkeen numeron sille, missä tämä symboli parhaillaan suorittaa.
    ///
    /// Ainoastaan gimli antaa tällä hetkellä arvon tässä ja silloinkin vain, jos `filename` palauttaa `Some`: n, joten siihen kohdistuu vastaavasti varoituksia.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Palauttaa rivinumeron sille, missä tämä symboli parhaillaan suorittaa.
    ///
    /// Tämä palautusarvo on tyypillisesti `Some`, jos `filename` palauttaa `Some`: n, ja siksi siihen sovelletaan samanlaisia varoituksia.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Palauttaa tiedostonimen kohtaan, jossa tämä toiminto määritettiin.
    ///
    /// Tämä on tällä hetkellä käytettävissä vain, kun libbacktrace tai gimli on käytössä (esim
    /// unix alustat muut) ja kun binaari käännetään debuginfolla.
    /// Jos kumpikaan näistä ehdoista ei täyty, tämä palauttaa todennäköisesti `None`: n.
    ///
    /// # Vaaditut ominaisuudet
    ///
    /// Tämä toiminto edellyttää, että `backtrace` crate: n `std`-ominaisuus on käytössä, ja `std`-ominaisuus on oletusarvoisesti käytössä.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Ehkä jäsennetty C++ -symboli, jos jumittuneen symbolin jäsentäminen Rust-muodossa epäonnistui.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Pidä tämä nollakokoinen, jotta `cpp_demangle`-ominaisuus ei maksa mitään, kun se poistetaan käytöstä.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Symbolin nimen ympärille kääritty kääre, joka tarjoaa ergonomiset lisävarusteet sekoitetulle nimelle, käsittelemättömille tavuille, merkkijonolle jne.
///
// Salli kuollut koodi, kun `cpp_demangle`-ominaisuus ei ole käytössä.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Luo uuden symbolinimen raaka-pohjaisista tavuista.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Palauttaa raakan (mangled)-symbolinimen nimellä `str`, jos symboli on kelvollinen utf-8.
    ///
    /// Käytä `Display`-toteutusta, jos haluat puretun version.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Palauttaa raakamerkin nimen tavuina
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Tämä voi tulostaa, jos sekoitettu symboli ei ole oikea, joten käsittele virhettä tässä sulavasti, et levittämättä sitä ulospäin.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Yritä palauttaa välimuistissa oleva muisti, jota käytetään osoitteiden symbolointiin.
///
/// Tämä menetelmä yrittää vapauttaa kaikki globaalit tietorakenteet, jotka on muuten tallennettu välimuistiin globaalisti tai ketjussa, jotka tyypillisesti edustavat jäsennettyä DWARF-tietoa tai vastaavaa.
///
///
/// # Caveats
///
/// Vaikka tämä toiminto on aina käytettävissä, se ei todellakaan tee mitään useimmissa toteutuksissa.
/// Kirjastot, kuten dbghelp tai libbacktrace, eivät tarjoa tiloja tilan jakamiseen ja varatun muistin hallintaan.
/// Toistaiseksi tämän crate: n `gimli-symbolize`-ominaisuus on ainoa ominaisuus, jolla tällä toiminnolla on mitään vaikutusta.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}