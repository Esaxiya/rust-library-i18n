//! Moduuli, joka auttaa hallinnoimaan dbghelp-sidoksia Windows: ssä
//!
//! Windows: n taaksepäinjäljet (ainakin MSVC: lle) saavat virtansa suurelta osin `dbghelp.dll`: n ja sen sisältämien toimintojen kautta.
//! Nämä toiminnot ladataan tällä hetkellä *dynaamisesti* sen sijaan, että ne linkitettäisiin `dbghelp.dll`: ään staattisesti.
//! Tämän tekee tällä hetkellä tavallinen kirjasto (ja sitä teoreettisesti vaaditaan siellä), mutta se on pyrkimys auttaa vähentämään kirjaston staattisia dll-riippuvuuksia, koska jälkijäljet ovat yleensä melko valinnaisia.
//!
//! Tästä huolimatta `dbghelp.dll` latautuu melkein aina onnistuneesti Windows: ään.
//!
//! Huomaa kuitenkin, että koska lataamme kaiken tämän tuen dynaamisesti, emme voi itse asiassa käyttää raakamääritelmiä `winapi`: ssä, vaan pikemminkin meidän on määriteltävä funktiosoitintyypit itse ja käytettävä sitä.
//! Emme todellakaan halua olla winapi-liiketoiminnan jäljentämisessä, joten meillä on Cargo-ominaisuus `verify-winapi`, joka väittää, että kaikki siteet vastaavat Winapissa olevia ja tämä ominaisuus on käytössä CI: ssä.
//!
//! Lopuksi huomaat tässä, että `dbghelp.dll`: n dll-tiedostoa ei koskaan pureta, ja se on tällä hetkellä tarkoituksellista.
//! Ajattelu on, että voimme globaalisti tallentaa sen välimuistiin ja käyttää sitä sovellusliittymälle soitettujen puheluiden välillä välttäen kalliita loads/unloads: ää.
//! Jos tämä on ongelma vuodonilmaisimille tai vastaavalle, voimme ylittää sillan, kun pääsemme sinne.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Kiertele `SymGetOptions`: ää ja `SymSetOptions`: ää, kun et ole läsnä itse WinAPissa.
// Muuten tätä käytetään vain, kun tarkistamme tyypit Winapia vastaan.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Ei vielä määritelty winapissa
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Tämä on määritelty WinAPissa, mutta se on väärä (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Ei vielä määritelty winapissa
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Tätä makroa käytetään määrittelemään `Dbghelp`-rakenne, joka sisältää sisäisesti kaikki toiminnon osoittimet, jotka voimme ladata.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// Ladattu DLL `dbghelp.dll`: lle
            dll: HMODULE,

            // Kukin toiminnon osoitin jokaiselle toiminnolle, jota voimme käyttää
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Aluksi emme ole ladanneet DLL-tiedostoa
            dll: 0 as *mut _,
            // Kaikki toiminnot on asetettu nollaan sanomaan, että ne on ladattava dynaamisesti.
            //
            $($name: 0,)*
        };

        // Mukavuustyyppi jokaiselle toimintotyypille.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Yritetään avata `dbghelp.dll`.
            /// Palauttaa onnistumisen, jos se toimii, tai virheen, jos `LoadLibraryW` epäonnistuu.
            ///
            /// Panics, jos kirjasto on jo ladattu.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Toiminto jokaiselle käytetylle menetelmälle.
            // Kun sitä kutsutaan, se joko lukee välimuistissa olevan toiminnon osoittimen tai lataa sen ja palauttaa ladatun arvon.
            // Kuormien väitetään onnistuvan.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Kätevä välityspalvelin puhdistuslukkojen käyttämiseen viitata dbghelp-toimintoihin.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Alusta kaikki tarvittava tuki `dbghelp`-sovellusliittymän toimintojen käyttämiseksi tältä crate-laitteelta.
///
///
/// Huomaa, että tämä toiminto on **turvallinen**, sillä on sisäisesti oma synkronointi.
/// Huomaa myös, että tätä toimintoa on turvallista kutsua useita kertoja rekursiivisesti.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Ensimmäinen asia, joka meidän on tehtävä, on synkronoida tämä toiminto.Tätä voidaan kutsua samanaikaisesti muista säikeistä tai rekursiivisesti yhden säikeen sisällä.
        // Huomaa, että se on kuitenkin hankalampaa, koska mitä täällä käytämme, `dbghelp`,*myös* on synkronoitava kaikkien muiden `dbghelp`-soittajien kanssa tässä prosessissa.
        //
        // Tyypillisesti `dbghelp`: lle ei ole niin paljon puheluja saman prosessin aikana, ja voimme todennäköisesti olettaa, että olemme ainoat, jotka käyttävät sitä.
        // On kuitenkin yksi toinen ensisijainen käyttäjä, josta meidän on huolehdittava, mikä on ironista itsemme, mutta tavallisessa kirjastossa.
        // Rust-vakiokirjasto riippuu tästä crate: stä backtrace-tueksi, ja tämä crate on olemassa myös crates.io: ssä.
        // Tämä tarkoittaa, että jos vakiokirjasto tulostaa panic-jälkijäljen, se voi kilpailla tämän crates.io: stä tulevan crate: n kanssa aiheuttaen häiriöitä.
        //
        // Tämän synkronointiongelman ratkaisemiseksi käytämme Windows-erityistä temppua (se on loppujen lopuksi Windows-kohtainen synkronointirajoitus).
        // Luomme *session-local*-nimen Mutex tämän puhelun suojaamiseksi.
        // Tarkoituksena on, että vakiokirjaston ja tämän crate: n ei tarvitse jakaa Rust-tason sovellusliittymiä synkronoidakseen täällä, vaan ne voivat sen sijaan työskennellä kulissien takana varmistaakseen, että ne synkronoivat toistensa kanssa.
        //
        // Tällä tavoin, kun tätä toimintoa kutsutaan tavallisen kirjaston tai crates.io: n kautta, voimme olla varmoja, että samaa mutexia hankitaan.
        //
        // Joten kaikki tämä tarkoittaa sitä, että ensimmäinen asia, jonka teemme täällä, on luoda atomisesti `HANDLE`, joka on nimetty mutex Windows: ssä.
        // Synkronoimme vähän muiden säikeiden kanssa, jotka jakavat tämän toiminnon nimenomaan, ja varmistamme, että vain yksi kahva luodaan tätä toimintoa kohti.
        // Huomaa, että kahva ei ole koskaan suljettu, kun se on tallennettu maailmanlaajuisesti.
        //
        // Kun olemme todella menneet lukkoon, hankimme sen yksinkertaisesti, ja jakamamme `Init`-kahva on vastuussa sen pudottamisesta lopulta.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ok, phew!Nyt kun olemme kaikki synkronoitu turvallisesti, aloitetaan kaiken käsittely.
        // Ensin on varmistettava, että `dbghelp.dll` on todella ladattu tähän prosessiin.
        // Teemme tämän dynaamisesti staattisen riippuvuuden välttämiseksi.
        // Tämä on historiallisesti tehty kiertämään outoja linkitysongelmia, ja sen tarkoituksena on tehdä binääreistä hieman kannettavampia, koska tämä on suurelta osin vain virheenkorjausapuohjelma.
        //
        //
        // Kun olemme avanneet `dbghelp.dll`: n, meidän on kutsuttava siihen joitain alustustoimintoja, ja se on yksityiskohtaisempi alla.
        // Teemme tämän kuitenkin vain kerran, joten meillä on yleinen totuusarvo, joka osoittaa, olemmeko vielä valmiita vai ei.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Varmista, että `SYMOPT_DEFERRED_LOADS`-lippu on asetettu, koska MSVC: n omien asiakirjojen mukaan tästä: "This is the fastest, most efficient way to use the symbol handler.", joten tehkäämme se!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Alusta symbolit itse asiassa MSVC: llä.Huomaa, että tämä voi epäonnistua, mutta jätämme sen huomiotta.
        // Tätä sinänsä ei ole paljon tekniikan tasoa, mutta LLVM näyttää sisäisesti jättävän huomiotta palautusarvon tässä ja yksi LLVM: n desinfiointikirjastoista tulostaa pelottavan varoituksen, jos tämä epäonnistuu, mutta jättää sen periaatteessa huomiotta pitkällä aikavälillä.
        //
        //
        // Yksi tapaus tuo paljon esille Rust: lle, että sekä standardikirjasto että tämä `SymInitializeW`: n crate haluavat kilpailla `SymInitializeW`: stä.
        // Vakiokirjasto halusi historiallisesti alustaa sitten siivouksen suurimman osan ajasta, mutta nyt kun se käyttää tätä crate: tä, se tarkoittaa, että joku pääsee alustukseen ensin ja toinen ottaa tämän alustuksen.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}