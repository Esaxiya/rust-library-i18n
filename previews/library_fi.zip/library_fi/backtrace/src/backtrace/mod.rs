use core::ffi::c_void;
use core::fmt;

/// Tarkistaa nykyisen puhelupinon, siirtäen kaikki aktiiviset kehykset suljettuun pinon jäljityksen laskemiseen.
///
/// Tämä toiminto on tämän kirjaston työhevonen laskettaessa ohjelman pinojälkiä.Annetulla sulkimella `cb` saadaan `Frame`-esiintymät, jotka edustavat tietoa kyseisestä puhelukehyksestä pinossa.
/// Sulkeminen tuottaa kehykset ylhäältä alaspäin (viimeksi kutsutaan ensin toiminnoksi).
///
/// Sulkimen paluuarvo on osoitus siitä, pitäisikö jälkijunaa jatkaa.`false`: n palautusarvo lopettaa paluun ja palaa välittömästi.
///
/// Kun `Frame` on hankittu, haluat todennäköisesti soittaa `backtrace::resolve`: ään muuntamalla `ip` (käskyosoitin) tai symboliosoitteen `Symbol`: ksi, jonka kautta nimi ja/tai tiedostonimi/rivinumero voidaan oppia.
///
///
/// Huomaa, että tämä on suhteellisen matalan tason toiminto, ja jos haluat esimerkiksi kaapata myöhemmin tarkastettavan jälkijohdon, `Backtrace`-tyyppi voi olla sopivampi.
///
/// # Vaaditut ominaisuudet
///
/// Tämä toiminto edellyttää, että `backtrace` crate: n `std`-ominaisuus on käytössä, ja `std`-ominaisuus on oletusarvoisesti käytössä.
///
/// # Panics
///
/// Tämä toiminto pyrkii olemaan koskaan panic, mutta jos `cb` toimitti panics: n, jotkut alustat pakottavat kaksinkertaisen panic: n keskeyttämään prosessin.
/// Jotkut käyttöympäristöt käyttävät C-kirjastoa, joka käyttää sisäisesti soittopyyntöjä, joita ei voi purkaa, joten `cb`: n paniikki voi aiheuttaa prosessin keskeytymisen.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // jatka takaisinjälkeä
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Sama kuin `trace`, vain vaarallinen, koska sitä ei ole synkronoitu.
///
/// Tällä toiminnolla ei ole synkronointitakuita, mutta se on käytettävissä, kun tämän crate: n `std`-ominaisuutta ei ole käännetty sisään.
/// Katso lisätietoja `trace`-toiminnosta ja esimerkkejä.
///
/// # Panics
///
/// Katso `trace`: n tiedot `cb`-paniikkia koskevista varoituksista.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// trait, joka edustaa yhtä jälkijohdon kehystä, antautui tämän crate: n `trace`-toiminnolle.
///
/// Jäljitystoiminnon sulkemisesta saadaan kehyksiä, ja kehys lähetetään käytännössä, koska taustalla oleva toteutus ei ole aina tiedossa ennen ajonaikaa.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Palauttaa tämän kehyksen nykyisen käskyosoittimen.
    ///
    /// Tämä on normaalisti seuraava käsky, joka suoritetaan kehyksessä, mutta kaikissa toteutuksissa ei ole lueteltu tätä 100%: n tarkkuudella (mutta se on yleensä melko lähellä).
    ///
    ///
    /// On suositeltavaa välittää tämä arvo `backtrace::resolve`: lle, jotta se muutetaan symbolinimeksi.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Palauttaa tämän kehyksen nykyisen pinon osoittimen.
    ///
    /// Jos taustajärjestelmä ei pysty palauttamaan tämän kehyksen pinoosoitinta, palautetaan nollaosoitin.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Palauttaa tämän toiminnon kehyksen aloitusmerkin osoitteen.
    ///
    /// Tämä yrittää kelata `ip`: n palauttaman käskyosoittimen toiminnon alkuun palauttamalla kyseisen arvon.
    ///
    /// Joissakin tapauksissa backendit kuitenkin palauttavat `ip`: n tästä toiminnosta.
    ///
    /// Palautettua arvoa voidaan joskus käyttää, jos `backtrace::resolve` epäonnistui yllä annetulla `ip`: llä.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Palauttaa sen moduulin perusosoitteen, johon kehys kuuluu.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Tämän on oltava etusijalla sen varmistamiseksi, että Miri on etusijalla isäntäalustaan nähden
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // vain käytettynä dbghelpissä symboloivat
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}