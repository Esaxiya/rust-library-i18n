#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Muotoilija taustajälkiä varten.
///
/// Tätä tyyppiä voidaan käyttää takaosan jäljittämiseen riippumatta siitä, mistä itse jälki on peräisin.
/// Jos sinulla on `Backtrace`-tyyppi, sen `Debug`-toteutus käyttää jo tätä tulostusmuotoa.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Tulostustavat, joita voimme tulostaa
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Tulostaa peräkkäisen jälkijäljen, joka mieluiten sisältää vain asiaankuuluvia tietoja
    Short,
    /// Tulostaa takaiskun, joka sisältää kaikki mahdolliset tiedot
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Luo uusi `BacktraceFmt`, joka kirjoittaa lähdön toimitettuun `fmt`: ään.
    ///
    /// `format`-argumentti ohjaa tyyliä, jolla backtrace tulostetaan, ja `print_path`-argumenttia käytetään tiedostojen `BytesOrWideString`-esiintymien tulostamiseen.
    /// Itse tämä tyyppi ei tulosta tiedostonimiä, mutta tämä vaaditaan tätä soittamista varten.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Tulostaa johdantokappaleen tulostettavalle jälkijohdolle.
    ///
    /// Tätä vaaditaan joillakin alustoilla, jotta taaksepäin jäljitettävät tunnisteet näkyvät myöhemmin kokonaan, ja muuten tämän pitäisi olla vain ensimmäinen tapa, johon soitat `BacktraceFmt`: n luomisen jälkeen.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Lisää kehyksen backtrace-lähtöön.
    ///
    /// Tämä sitoutus palauttaa `BacktraceFrameFmt`: n RAII-ilmentymän, jota voidaan käyttää kehyksen todelliseen tulostamiseen, ja tuhotessaan se lisää kehyslaskuria.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Viimeistelee takaisinkelan lähdön.
    ///
    /// Tämä on tällä hetkellä ei-optio, mutta se lisätään future-yhteensopivuuden kanssa backtrace-muotojen kanssa.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Tällä hetkellä ei-optio-mukaan lukien tämä hook, jotta future-lisäykset voidaan sallia.
        Ok(())
    }
}

/// Muotoilija vain yhdelle taustan jäljen kehykselle.
///
/// Tämän tyypin luo `BacktraceFmt::frame`-toiminto.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Tulostaa `BacktraceFrame`: n tällä kehysformaatilla.
    ///
    /// Tämä tulostaa rekursiivisesti kaikki `BacktraceFrame`: n `BacktraceSymbol`-esiintymät.
    ///
    /// # Vaaditut ominaisuudet
    ///
    /// Tämä toiminto edellyttää, että `backtrace` crate: n `std`-ominaisuus on käytössä, ja `std`-ominaisuus on oletusarvoisesti käytössä.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Tulostaa `BacktraceSymbol`: n `BacktraceFrame`: n sisällä.
    ///
    /// # Vaaditut ominaisuudet
    ///
    /// Tämä toiminto edellyttää, että `backtrace` crate: n `std`-ominaisuus on käytössä, ja `std`-ominaisuus on oletusarvoisesti käytössä.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: tämä ei ole hieno, ettemme pääty tulostamaan mitään
            // ei-utf8-tiedostonimillä.
            // Onneksi melkein kaikki on utf8, joten tämän ei pitäisi olla liian huono.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Tulostaa jäljittelemättömät `Frame` ja `Symbol`, tyypillisesti tämän crate: n raakapuheluista.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Lisää raakakehyksen backtrace-lähtöön.
    ///
    /// Tämä menetelmä, toisin kuin edellinen, ottaa raaka-argumentit siltä varalta, että niitä lähdetään eri paikoista.
    /// Huomaa, että tätä voidaan kutsua useita kertoja yhdelle kehykselle.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Lisää raakakehyksen backtrace-lähtöön, mukaan lukien saraketiedot.
    ///
    /// Tämä menetelmä, kuten edellinen, ottaa raaka argumentit, jos ne ovat lähde eri paikoista.
    /// Huomaa, että tätä voidaan kutsua useita kertoja yhdelle kehykselle.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuksia ei pysty symboloimaan prosessissa, joten sillä on erityinen muoto, jota voidaan käyttää symboloimaan myöhemmin.
        // Tulosta se sen sijaan, että tulostat osoitteita omassa muodossa tässä.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // "null"-kehyksiä ei tarvitse tulostaa, se tarkoittaa periaatteessa vain sitä, että järjestelmän takaisinkytkentä oli hieman innokas jäljittämään erittäin pitkälle.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // TCG-koon pienentämiseksi Sgx-erillisalueella emme halua toteuttaa symbolien tarkkuustoimintoa.
        // Pikemminkin voimme tulostaa osoitteen siirtymän täältä, joka voidaan myöhemmin kartoittaa oikeaksi toiminnoksi.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Tulosta kehyksen hakemisto sekä kehyksen valinnainen ohjeosoitin.
        // Jos olemme tämän kehyksen ensimmäisen symbolin ulkopuolella, vaikka tulostamme vain sopivan välilyönnin.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Kirjoita seuraavaksi symbolin nimi käyttämällä vaihtoehtoista muotoilua saadaksesi lisätietoja, jos olemme täydellinen jälkijälki.
        // Täällä käsittelemme myös symboleja, joilla ei ole nimeä,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Viimeisenä, tulosta filename/line-numero, jos niitä on saatavilla.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line on painettu viivoille symbolinimen alle, joten tulosta sopiva välilyönti tasaamaan itsemme oikeaksi.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Siirrä sisäiseen soittopyyntöön tulostaa tiedostonimi ja sitten tulostaa rivinumero.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Lisää sarakkeen numero, jos saatavilla.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Me välitämme vain kehyksen ensimmäisestä symbolista
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}