# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Kirjasto taaksepäin jäljittämiseen ajon aikana Rust: lle.
Tämän kirjaston tarkoituksena on parantaa vakiokirjaston tukea tarjoamalla ohjelmallinen käyttöliittymä toimimaan, mutta se tukee myös yksinkertaisesti nykyisen takapalan, kuten libstd: n panics, tulostamista.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Voit yksinkertaisesti kaapata taaksepäin ja lykätä sen käsittelyä myöhempään ajankohtaan käyttämällä ylätason `Backtrace`-tyyppiä.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Jos kuitenkin haluat enemmän raakaa pääsyä todelliseen jäljitystoimintoon, voit käyttää `trace`-ja `resolve`-toimintoja suoraan.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Ratkaise tämä ohjeosoitin symbolin nimeksi
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // jatka seuraavaan kehykseen
    });
}
```

# License

Tämä projekti on lisensoitu jommallakummalla seuraavista:

 * Apache-lisenssi, versio 2.0, ([LICENSE-APACHE](LICENSE-APACHE) tai http://www.apache.org/licenses/LICENSE-2.0)
 * MIT-lisenssi ([LICENSE-MIT](LICENSE-MIT) tai http://opensource.org/licenses/MIT)

valintasi mukaan.

### Contribution

Ellet nimenomaisesti toisin ilmoita, kaikilla käyttäjän tahallisesti lähettämillä backtrace-r-tiedostoihin sisällyttämillä lahjoituksilla, jotka on määritelty Apache-2.0-lisenssissä, on kaksoislisenssi kuten yllä, ilman muita ehtoja.







