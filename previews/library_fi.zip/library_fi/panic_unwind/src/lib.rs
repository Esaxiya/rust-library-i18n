//! panics: n toteutus pinon purkamisen avulla
//!
//! Tämä crate on panics: n toteutus Rust: ssä käyttämällä alustan "most native"-pinon kelausmekanismia, jota varten kootaan.
//! Tämä luokitellaan olennaisesti kolmeen kauhaan tällä hetkellä:
//!
//! 1. MSVC-kohteet käyttävät SEH: ää `seh.rs`-tiedostossa.
//! 2. Emscripten käyttää C++ -poikkeuksia `emcc.rs`-tiedostossa.
//! 3. Kaikki muut kohteet käyttävät libunwind/libgcc-tiedostoa `gcc.rs`-tiedostossa.
//!
//! Lisää dokumentaatiota kustakin toteutuksesta löytyy vastaavasta moduulista.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` on käyttämätön Mirin kanssa, joten hiljaisuusvaroitukset.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Suorituksen Rust käynnistysobjektit riippuvat näistä symboleista, joten tee niistä julkisia.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Kohteet, jotka eivät tue purkamista.
        // - arch=wasm32
        // - os=ei mitään ("bare metal"-kohteet)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Käytä Mirin ajonaikaa.
        // Meidän on edelleen ladattava myös normaali ajonaikainen yllä, koska rustc odottaa tiettyjen lang-kohteiden määrittämistä sieltä.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Käytä todellista ajonaikaa.
        use real_imp as imp;
    }
}

extern "C" {
    /// Käsittelijä libstd: ssä soitti, kun panic-objekti pudotettiin `catch_unwind`: n ulkopuolelle.
    ///
    fn __rust_drop_panic() -> !;

    /// Käsittelijä libstd: ssä soitti, kun ulkomainen poikkeus on kiinni.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Lähtökohta poikkeuksen nostamiseksi vain delegoi alustakohtaiseen toteutukseen.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}