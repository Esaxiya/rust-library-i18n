//! Windows SEH
//!
//! Windows: ssä (tällä hetkellä vain MSVC: ssä) oletuspoikkeuksien käsittelymekanismi on strukturoitu poikkeusten käsittely (SEH).
//! Tämä on täysin erilainen kuin kääpiöpohjainen poikkeuskäsittely (esim. Mitä muut unix-alustat käyttävät) kääntäjien sisäisissä osissa, joten LLVM: llä vaaditaan paljon ylimääräistä tukea SEH: lle.
//!
//! Lyhyesti sanottuna täällä tapahtuu:
//!
//! 1. `panic`-toiminto kutsuu Windows-vakiotoimintoa `_CxxThrowException` heittämään C++ -tyyppisen poikkeuksen, joka käynnistää kelausprosessin.
//! 2.
//! Kaikki kääntäjän luomat laskeutumisalustat käyttävät persoonallisuusfunktiota `__CxxFrameHandler3`, CRT: n toimintoa, ja Windows: n purkautumiskoodi käyttää tätä persoonallisuusfunktiota suorittamaan kaikki pinon siivouskoodit.
//!
//! 3. Kaikissa kääntäjän luomissa `invoke`-puheluissa on laskeutumisalusta asetettu `cleanuppad` LLVM-käskyksi, mikä ilmaisee puhdistusrutiinin alkamisen.
//! Henkilö (vaiheessa 2, määritelty CRT: ssä) on vastuussa siivousrutiinien suorittamisesta.
//! 4. Lopulta `try`-sisäisen `try`-koodi (kääntäjän tuottama) suoritetaan ja osoittaa, että ohjauksen tulisi palata takaisin Rust: een.
//! Tämä tapahtuu `catchswitch`: n ja `catchpad`-käskyn avulla LLVM IR-termeillä, palauttaen lopulta normaalin ohjauksen ohjelmaan `catchret`-käskyllä.
//!
//! Joitakin erityisiä eroja gcc-pohjaiseen poikkeusten käsittelyyn ovat:
//!
//! * Rust: llä ei ole mukautettua persoonallisuustoimintoa, se on sen sijaan *aina*`__CxxFrameHandler3`.Lisäksi mitään ylimääräistä suodatusta ei suoriteta, joten saamme kiinni kaikki C++ -poikkeukset, jotka näyttävät näyttävän heittotyypeiltämme.
//! Huomaa, että poikkeuksen heittäminen Rust: ään on joka tapauksessa määrittelemätöntä käyttäytymistä, joten tämän pitäisi olla hieno.
//! * Meillä on tietoa siirrettäväksi purkautuvan rajan yli, erityisesti `Box<dyn Any + Send>`.Kuten kääpiöpoikkeuksilla, nämä kaksi osoitinta tallennetaan hyötykuormana itse poikkeukseen.
//! MSVC: ssä ei kuitenkaan tarvita ylimääräistä kasaallokointia, koska puhelupino säilyy suodatintoimintojen suorituksen aikana.
//! Tämä tarkoittaa, että osoittimet välitetään suoraan `_CxxThrowException`: lle, jotka palautetaan sitten suodatintoiminnossa kirjoitettaviksi `try`-sisäisen pinon kehykseen.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Tämän on oltava vaihtoehto, koska saamme poikkeuksen viitteellä ja sen tuhoaja suoritetaan C++ : n ajon aikana.
    // Kun otamme laatikon pois poikkeuksesta, meidän on jätettävä poikkeus kelvolliseen tilaan, jotta sen tuhoaja voi toimia ilman, että laatikko kaksois pudotetaan.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Ensinnäkin koko joukko tyyppimäärityksiä.Täällä on muutama alustakohtainen outo, ja paljon, joka on vain räikeästi kopioitu LLVM: stä.Kaiken tämän tarkoituksena on toteuttaa alla oleva `panic`-toiminto soittamalla `_CxxThrowException`: lle.
//
// Tässä toiminnossa on kaksi argumenttia.Ensimmäinen on osoitin siirtämillemme tiedoille, joka tässä tapauksessa on trait-objekti.Melko helppo löytää!Seuraava on kuitenkin monimutkaisempi.
// Tämä on osoitin `_ThrowInfo`-rakenteelle, ja yleensä se on tarkoitettu vain kuvaamaan heitettävää poikkeusta.
//
// Tällä hetkellä tämän tyyppisen [1]: n määritelmä on hieman karvainen, ja tärkein kummallisuus (ja ero online-artikkeliin nähden) on, että 32-bittisissä osoittimet ovat osoittimia, mutta 64-bittisissä osoittimet ilmaistaan 32-bittisinä siirtyminä `__ImageBase`-symboli.
//
// Tämän ilmaisemiseen käytetään alla olevien moduulien `ptr_t`-ja `ptr!`-makroja.
//
// Tyyppimääritysten sokkelo seuraa myös tarkasti, mitä LLVM lähettää tämäntyyppiseen toimintaan.Jos esimerkiksi koot tämän C++ -koodin MSVC: lle ja lähetät LLVM IR: n:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      mitätöi foo() { rust_panic a = {0, 1};
//          heittää a;}
//
// Juuri sitä yritämme jäljitellä.Suurin osa alla olevista vakioarvoista kopioitiin juuri LLVM: stä,
//
// Joka tapauksessa nämä rakenteet on rakennettu samalla tavalla, ja se on meille vain hieman verbose.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Huomaa, että jätämme tarkoituksellisesti huomiotta nimien sekoitussäännöt: emme halua, että C++ pystyy saamaan Rust panics: n yksinkertaisesti ilmoittamalla `struct rust_panic`: n.
//
//
// Muokatessasi varmista, että tyypin nimen merkkijono vastaa tarkalleen `compiler/rustc_codegen_llvm/src/intrinsic.rs`: ssä käytettyä merkkijonoa.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Johtava `\x01`-tavu on itse asiassa maaginen signaali LLVM: lle, jotta *ei* sovellettaisi mitään muuta hallintaa, kuten etuliitettä `_`-merkillä.
    //
    //
    // Tämä symboli on C++ : n `std::type_info`: n käyttämä kuva.
    // `std::type_info`-tyyppisillä objekteilla, tyyppikuvaajilla, on osoitin tähän taulukkoon.
    // Tyyppikuvaajiin viitataan edellä määritellyillä C++ EH-rakenteilla, jotka rakennamme alla.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Tätä tyyppikuvaajaa käytetään vain poikkeuksen heittämiseen.
// Saalisosaa hoitaa sisäinen try-kokeilu, joka luo oman TypeDescriptorin.
//
// Tämä on hieno, koska MSVC: n ajonaika käyttää merkkijonojen vertailua tyypin nimessä vastaamaan TypeDescriptorejä osoittimen tasa-arvon sijasta.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destructor käytetään, jos C++ -koodi päättää kaapata poikkeuksen ja pudottaa sen levittämättä sitä.
// Sisäisen try-osan saalisosa asettaa poikkeusobjektin ensimmäisen sanan arvoon 0 siten, että tuhoaja ohittaa sen.
//
// Huomaa, että x86 Windows käyttää "thiscall"-puhelukäytäntöä C++ -jäsenfunktioille "C"-oletuspuhelutavan sijaan.
//
// Excession_copy-toiminto on tässä hieman erikoinen: MSVC: n ajonaika käyttää sitä try/catch-lohkon alla ja täällä luomaa panic: tä käytetään poikkeuskopion tuloksena.
//
// Tätä käyttää C++ ajonaika tukemaan poikkeusten kaappaamista std::exception_ptr: llä, jota emme voi tukea, koska Box<dyn Any>ei ole kloonattava.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException suoritetaan kokonaan tällä pinokehyksellä, joten `data`: ää ei tarvitse muuten siirtää kasaan.
    // Välitämme vain pinon osoittimen tälle toiminnolle.
    //
    // Manuaalisesti pudotusta tarvitaan täällä, koska emme halua, että poikkeus pudotetaan purkamisen aikana.
    // Sen sijaan se pudotetaan excl_cleanup-toiminnolla, johon C++ ajonaika vie.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Tämä ... saattaa tuntua yllättävältä ja perustellusti.32-bittisessä MSVC: ssä näiden rakenteiden väliset osoittimet ovat juuri sitä, osoittimet.
    // 64-bittisessä MSVC: ssä rakenteiden väliset osoittimet ilmaistaan kuitenkin pikemminkin 32-bittisinä siirtyminä `__ImageBase`: stä.
    //
    // Näin ollen 32-bittisessä MSVC: ssä voimme ilmoittaa kaikki nämä osoittimet yllä olevissa "staattisissa".
    // 64-bittisessä MSVC: ssä meidän on ilmaistava osoittimien vähennys staattisissa kohteissa, mitä Rust ei tällä hetkellä salli, joten emme voi itse tehdä sitä.
    //
    // Seuraava paras asia on sitten täyttää nämä rakenteet ajon aikana (paniikki on joka tapauksessa jo "slow path").
    // Joten tässä tulkitsemme kaikki nämä osoitinkentät uudelleen 32-bittisiksi kokonaislukuiksi ja sitten tallennamme asiaankuuluvan arvon siihen (atomisesti, koska samanaikaista panics: tä voi tapahtua).
    //
    // Teknisesti ajonaika luultavasti lukee nämä kentät ei-atomisesti, mutta teoriassa he eivät koskaan lukeneet *väärää* arvoa, joten sen ei pitäisi olla liian huono ...
    //
    // Joka tapauksessa meidän on periaatteessa tehtävä jotain tällaista, kunnes voimme ilmaista enemmän operaatioita staattisina (ja emme ehkä koskaan pysty).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // NULL-hyötykuorma tarkoittaa tässä, että pääsimme tänne __rust_try-saalista (...).
    // Tämä tapahtuu, kun muu kuin Rust-poikkeus jää kiinni.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Kääntäjä vaatii tämän olemassaolon (esim. Se on lang-kohde), mutta kääntäjä ei ole koskaan kutsunut sitä, koska __C_specific_handler tai_except_handler3 on aina käytetty persoonallisuusfunktio.
//
// Siksi tämä on vain keskeyttävä tynkä.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}