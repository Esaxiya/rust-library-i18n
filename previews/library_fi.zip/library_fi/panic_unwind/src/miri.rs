//! Miri: n panics: n purkaminen.
use alloc::boxed::Box;
use core::any::Any;

// Hyötykuorman tyyppi, jota Miri-moottori levittää purkautumalla meille.
// On oltava osoittimen kokoinen.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Mirin tarjoama ulkoinen toiminto avautuu.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Hyötykuorma, jonka välitämme `miri_start_panic`: lle, on täsmälleen argumentti, jonka saamme alla olevassa `cleanup`: ssä.
    // Joten pakkaamme sen vain kerran saadaksemme jotain osoittimen kokoista.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Palauta taustalla oleva `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}