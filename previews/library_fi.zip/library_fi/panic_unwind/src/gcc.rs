//! libgcc/libunwind: n tukema panics: n toteutus (jossain muodossa).
//!
//! Katso poikkeusten käsittelyn ja pinon purkamisen tausta "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html): stä ja siihen linkitetyistä asiakirjoista.
//! Nämä ovat myös hyviä lukuja:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## Lyhyt yhteenveto
//!
//! Poikkeusten käsittely tapahtuu kahdessa vaiheessa: hakuvaiheessa ja siivousvaiheessa.
//!
//! Molemmissa vaiheissa kelauslaite kävelee pinokehyksiä ylhäältä alas käyttäen tietoja nykyisen prosessin moduulien pinokehyksen kelausosista ("module" viittaa tässä käyttöjärjestelmämoduuliin, ts. Suoritettavaan tai dynaamiseen kirjastoon).
//!
//!
//! Jokaiselle pinokehykselle se kutsuu siihen liittyvän "personality routine": n, jonka osoite tallennetaan myös purkautumistiedot-osioon.
//!
//! Etsintävaiheessa persoonallisuusrutiinin tehtävä on tutkia heitettävä poikkeuskohde ja päättää, pitäisikö se tarttua siihen pinokehykseen.Kun käsittelijän kehys on tunnistettu, puhdistusvaihe alkaa.
//!
//! Siivousvaiheessa käämitys käynnistää jokaisen persoonallisuusrutiinin uudelleen.
//! Tällä kertaa se päättää, mikä (jos sellainen) puhdistuskoodi on suoritettava nykyiselle pinokehykselle.Jos näin on, ohjaus siirretään toimintorungon erityiseen branch: ään, "landing pad": ään, joka kutsuu tuhoajia, vapauttaa muistia jne.
//! Laskeutumisalustan lopussa ohjaus siirtyy takaisin kelaukseen ja aukeaminen jatkuu.
//!
//! Kun pino on purettu alas käsittelijän kehystasolle, kelaus lopetetaan ja viimeinen persoonallisuusrutiini siirtää ohjauksen salpalohkoon.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Rust: n poikkeusluokan tunniste.
// Tätä persoonallisuusrutiinit käyttävät selvittääkseen, heittikö poikkeus heidän oma ajonaikansa.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-toimittaja, kieli
    0x4d4f5a_00_52555354
}

// Rekisteritunnukset nostettiin LLVM: n TargetLowering::getExceptionPointerRegister(): stä ja TargetLowering::getExceptionSelectorRegister(): stä kullekin arkkitehtuurille, ja sitten kartoitettiin DWARF-rekisterinumeroihin rekisterimääritystaulukoiden kautta (tyypillisesti<arch>RegisterInfo.td, etsi "DwarfRegNum").
//
// Katso myös http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// Seuraava koodi perustuu GCC: n C-ja C++ -persoonallisuusrutiiniin.Katso viitteenä:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM EHABI-persoonallisuusrutiini.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS käyttää sen sijaan oletusrutiinia, koska se käyttää SjLj-kelausta.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // ARM: n takapalat kutsuvat persoonallisuusrutiinin tilaksi==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // Tällöin haluamme jatkaa pinon purkamista, muuten kaikki taaksemme jäljet päättyisivät kohtaan __rust_try
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // DWARF-kelaus olettaa, että _Unwind_Context sisältää asioita, kuten funktio ja LSDA-osoittimet, kuitenkin ARM EHABI sijoittaa ne poikkeusobjektiin.
            // Jos haluat säilyttää vain kontekstiosoittimen vievien _Unwind_GetLanguageSpecificData(): n kaltaisten toimintojen allekirjoitukset, GCC-persoonallisuusrutiinit kiinnittävät osoitimen kontekstissa olevaan poikkeusobjektiin käyttämällä sijaintia, joka on varattu ARM: n "scratch register" (r12): lle.
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... Periaatteellisempi lähestymistapa olisi tarjota ARM: n_Unwind_Context täydellinen määritelmä libunwind-sidoksissamme ja hakea tarvittavat tiedot sieltä suoraan DWARF-yhteensopivuusfunktiot ohittamalla.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI vaatii persoonallisuusrutiinin päivittämään SP-arvon poikkeusobjektin estovälimuistissa.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // ARM EHABI-ohjelmassa persoonallisuusrutiini on vastuussa yksittäisen pinokehyksen kelautumisesta ennen paluuta (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // määritelty libgcc: ssä
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // Oletus persoonallisuusrutiini, jota käytetään suoraan useimmissa kohteissa ja epäsuorasti Windows x86_64: ssä SEH: n kautta.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // x86_64 MinGW-kohteissa kelausmekanismi on SEH, mutta kelauskäsittelijän data (alias LSDA) käyttää GCC-yhteensopivaa koodausta.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // Persoonallisuusrutiini useimmille kohteillemme.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // Paluuosoitepisteet 1 tavu ohittavat soittokäskyn, joka voi olla seuraavalla IP-alueella LSDA-aluetaulukossa.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// Kehyksen purkamisen tietojen rekisteröinti
//
// Jokaisen moduulin kuva sisältää kehyksen purkamisen info-osion (yleensä ".eh_frame").Kun moduuli on loaded/unloaded prosessissa, kelauslaitteelle on kerrottava tämän osan sijainnista muistissa.Menetelmät tämän saavuttamiseksi vaihtelevat alustan mukaan.
// Joissakin (esim. Linux), kelauslaite voi löytää itsensä tieto-osioista (lukemalla dynaamisesti ladatut moduulit dl_iterate_phdr() API and finding their ".eh_frame" sections): n kautta; toiset, kuten Windows, vaativat moduuleja rekisteröimään aktiivisesti purkautumistietonsa kelausohjelman sovellusliittymän kautta.
//
//
// Tämä moduuli määrittelee kaksi symbolia, joihin viitataan ja joita kutsutaan rsbegin.rs: ltä rekisteröimään tietomme GCC-ajonaikaan.
// Pinon purkamisen toteutus on (toistaiseksi) lykätty libgcc_eh: een, mutta Rust crates käyttää näitä Rust-spesifisiä syöttöpisteitä välttääkseen mahdolliset ristiriidat minkä tahansa GCC-ajon kanssa.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}