//! Rust panics: n toteutus prosessin keskeytyksillä
//!
//! Verrattuna purkamisen kautta tapahtuvaan toteutukseen tämä crate on *paljon* yksinkertaisempi!Tästä huolimatta se ei ole aivan yhtä monipuolinen, mutta tässä menee!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" hyötykuorma ja välilevy asianomaiselle keskeytykselle kyseisellä alustalla.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // soita std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Käytä Windows: ssä prosessorikohtaista __fastfail-mekanismia.Windows 8: ssa ja sitä uudemmissa versioissa prosessi lopetetaan välittömästi suorittamatta prosessin sisäisiä poikkeuskäsittelijöitä.
            // Windows: n aiemmissa versioissa tätä komentosarjaa pidetään käyttöoikeusloukkauksena, joka lopettaa prosessin mutta ei välttämättä välttämättä kaikkia poikkeusten käsittelijöitä.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: tämä on sama toteutus kuin libstd: n `abort_internal`: ssä
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Tämä ... on vähän outo.Tl; dr;on, että tämä vaaditaan linkittämiseksi oikein, pidempi selitys on alla.
//
// Tällä hetkellä libcore/libstd: n binääritiedostot, jotka lähetämme, kootaan kaikki `-C panic=unwind`: n kanssa.Tämä tehdään sen varmistamiseksi, että binäärit ovat mahdollisimman yhteensopivia mahdollisimman monien tilanteiden kanssa.
// Kääntäjä vaatii kuitenkin "personality function": n kaikille `-C panic=unwind`: llä kootuille toiminnoille.Tämä persoonallisuusfunktio on kovakoodattu symboliksi `rust_eh_personality` ja sen määrittelee `eh_personality` lang-elementti.
//
// So...
// miksi ei vain määritellä sitä lang-kohdetta täällä?Hyvä kysymys!Tapa, johon panic-ajonajat on linkitetty, on itse asiassa hieman hienovarainen, koska ne ovat "sort of" kääntäjän crate-myymälässä, mutta tosiasiallisesti linkitetyt vain, jos toista ei ole tosiasiallisesti linkitetty.
//
// Tämä tarkoittaa lopulta sitä, että sekä tämä crate että panic_unwind crate voivat näkyä kääntäjän crate-kaupassa, ja jos molemmat määrittävät `eh_personality` lang-kohteen, se osuu virheeseen.
//
// Tämän käsittelemiseksi kääntäjä vaatii vain, että `eh_personality` on määritelty, jos linkitettävä panic-ajonaika on purkautuva ajoaika, ja muuten sitä ei tarvitse määritellä (oikein).
// Tässä tapauksessa tämä kirjasto kuitenkin vain määrittelee tämän symbolin, joten jossain on ainakin jonkinlainen persoonallisuus.
//
// Pohjimmiltaan tämä symboli on määritelty vain kytkemään libcore/libstd-binaareihin, mutta sitä ei pidä koskaan kutsua, koska emme linkitä lainkaan purkautuvaa ajonaikaa.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // Malli x86_64-pc-windows-gnu käyttää omaa persoonallisuustoimintoa, jonka on palautettava `ExceptionContinueSearch`, kun välitämme kaikkia kehyksiä.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Samoin kuin yllä, tämä vastaa `eh_catch_typeinfo` lang-elementtiä, jota käytetään tällä hetkellä vain Emscriptenissä.
    //
    // Koska panics ei luo poikkeuksia ja ulkomaiset poikkeukset ovat tällä hetkellä UB: n kanssa -C panic=keskeytä (vaikka tämä voi muuttua), kaikki catch_unwind-puhelut eivät koskaan käytä tätä tyyppitietoa.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Käynnistysobjektit kutsuvat näitä kahta i686-pc-windows-gnu-palvelussa, mutta niiden ei tarvitse tehdä mitään, joten rungot ovat noppia.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}