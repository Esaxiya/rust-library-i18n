#![feature(no_core)]
#![no_core]

// Katso rustc-std-työtilan ydin, miksi tätä crate: tä tarvitaan.

// Nimeä crate uudelleen välttääksesi ristiriitoja liballocin allokointimoduulin kanssa.
extern crate alloc as foo;

pub use foo::*;