# Avustaminen stdarchille

`stdarch` crate on enemmän kuin halukas hyväksymään lahjoituksia!Ensinnäkin haluat todennäköisesti tarkistaa arkiston ja varmistaa, että testit läpäisevät sinulle:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Jossa `<your-target-arch>` on kohdekolmikko `rustup`: n käyttämänä, esim. `x86_x64-unknown-linux-gnu` (ilman edeltävää `nightly-`: ää tai vastaavaa).
Muista myös, että tämä arkisto vaatii Rust: n yökanavan!
Yllä olevat testit vaativat itse asiassa yön rust: n olevan oletusarvo järjestelmäsi asetukselle, joka käyttää `rustup default nightly`: ää (ja `rustup default stable` palata).

Jos jokin yllä olevista vaiheista ei toimi, [please let us know][new]!

Seuraavaksi voit [find an issue][issues] auttaa, olemme valinneet muutamia [`help wanted`][help]-ja [`impl-period`][impl]-tunnisteilla, jotka voisivat käyttää erityisesti apua. 
Saatat olla kiinnostunut [#40][vendor]: stä, kun kaikki toimittajan sisäiset ominaisuudet otetaan käyttöön x86: ssä.Tästä numerosta on saatu hyviä ohjeita siitä, mistä aloittaa!

Jos sinulla on yleisiä kysymyksiä, ota rohkeasti yhteyttä [join us on gitter][gitter]: ään ja kysy!Voit vapaasti pingata joko@BurntSushi tai@alexcrichton kysymyksillä.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Kuinka kirjoittaa esimerkkejä stdarchin sisäisistä ominaisuuksista

On olemassa muutamia ominaisuuksia, jotka on otettava käyttöön, jotta annettu luonnostaan toimisi oikein, ja esimerkin saa suorittaa vain `cargo test --doc`, kun keskusyksikkö tukee ominaisuutta.

Tämän seurauksena `rustdoc`: n luoma oletusarvoinen `fn main` ei toimi (useimmissa tapauksissa).
Harkitse seuraavien ohjeiden käyttöä varmistaaksesi, että esimerkkisi toimii odotetusti.

```rust
/// # // Tarvitsemme cfg_target_feature varmistaaksemme, että esimerkki on vain
/// # // `cargo test --doc` suorittaa, kun keskusyksikkö tukee ominaisuutta
/// # #![feature(cfg_target_feature)]
/// # // Tarvitsemme target_feature-ominaisuuden toimiakseen
/// # #![feature(target_feature)]
/// #
/// # // rustdoc käyttää oletuksena `extern crate stdarch`: ää, mutta tarvitsemme
/// # // `#[macro_use]`
/// # # [makro_käyttö] ulkoinen crate vakio;
/// #
/// # // Todellinen päätehtävä
/// # fn main() {
/// #     // Suorita tämä vain, jos `<target feature>` on tuettu
/// #     jos cfg_feature_enabled! ("<target feature>"){
/// #         // Luo `worker`-toiminto, joka suoritetaan vain, jos kohdeominaisuus
/// #         // on tuettu ja varmista, että `target_feature` on otettu käyttöön työntekijällesi
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         vaarallinen fn worker() {
/// // Kirjoita esimerkkisi tähän.Ominaisuuskohtaiset sisäiset ominaisuudet toimivat täällä!Villiintyä!
///
/// #         }
///
/// #         vaarallinen { worker(); }
/// #     }
/// # }
```

Jos jotkut yllä olevista syntaksista eivät näytä tutuilta, [Rust Book]: n [Documentation as tests]-osassa kuvataan `rustdoc`-syntaksia melko hyvin.
Kuten aina, ota rohkeasti yhteyttä [join us on gitter][gitter]: ään ja kysy jos osuitko osiin, ja kiitos, että autat parantamaan `stdarch`: n dokumentointia!

# Vaihtoehtoiset testausohjeet

Testien suorittamiseen on yleensä suositeltavaa käyttää `ci/run.sh`: ää.
Tämä ei kuitenkaan välttämättä toimi sinulle, esim. Jos käytät Windows-laitetta.

Tällöin voit palata `cargo +nightly test`: n ja `cargo +nightly test --release -p core_arch`: n suorittamiseen koodin luomisen testaamiseksi.
Huomaa, että nämä edellyttävät öisen työkaluketjun asentamista ja että `rustc` tietää kohdekolmiosta ja sen suorittimesta.
Erityisesti sinun on asetettava `TARGET`-ympäristömuuttuja samalla tavalla kuin `ci/run.sh`: lle.
Lisäksi sinun on asetettava `RUSTCFLAGS` (tarvitset `C`) osoittamaan kohdeominaisuudet, esim `RUSTCFLAGS="-C -target-features=+avx2"`.
Voit myös asettaa `-C -target-cpu=native`: n, jos "just" kehittyy nykyistä prosessoriasi vastaan.

Varoitetaan, että kun käytät näitä vaihtoehtoisia ohjeita, esim. [things may go less smoothly than they would with `ci/run.sh`][ci-run-good]
ohjeiden luontitestit voivat epäonnistua, koska purkija osasi ne eri tavalla, esim
se voi luoda `vaesenc`: n `aesenc`-ohjeiden sijaan huolimatta siitä, että ne käyttäytyvät samalla tavalla.
Myös nämä ohjeet suorittavat vähemmän testejä kuin normaalisti tehtäisiin, joten älä ihmettele, että kun lopulta haet pyyntöä, virheitä saattaa ilmetä testeissä, joita ei käsitellä tässä.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






