`core::arch` - Rust: n ydinkirjaston arkkitehtuurikohtaiset luonteet
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch`-moduuli toteuttaa arkkitehtuurista riippuvia sisäisiä ominaisuuksia (esim. SIMD).

# Usage 

`core::arch` on saatavana osana `libcore`: ää ja `libstd` vie sen uudelleen.Käytä sitä mieluummin `core::arch`: n tai `std::arch`: n kautta kuin tämän crate: n kautta.
Epävakaat ominaisuudet ovat usein käytettävissä öisin Rust: ssä `feature(stdsimd)`: n kautta.

`core::arch`: n käyttö tämän crate: n kautta vaatii Rust: n joka ilta, ja se voi (ja rikkoo) usein.Ainoat tapaukset, joissa sinun tulisi harkita sen käyttöä tämän crate: n kautta, ovat:

* jos joudut kääntämään `core::arch`: n uudelleen itse, esimerkiksi tietyillä käytössä olevilla kohdeominaisuuksilla, joita ei ole otettu käyttöön `libcore`/`libstd`: ssä.
Note: Jos haluat kääntää sen uudelleen epätyypilliselle kohteelle, käytä mieluummin `xargo`: ää ja `libcore`/`libstd`: ää uudelleen tämän crate: n sijaan.
  
* käyttämällä joitain ominaisuuksia, jotka eivät ehkä ole käytettävissä edes epävakaiden Rust-ominaisuuksien takana.Yritämme pitää nämä minimissä.
Jos haluat käyttää joitain näistä ominaisuuksista, avaa ongelma, jotta voimme paljastaa ne yöllä Rust ja voit käyttää niitä sieltä.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` jaetaan ensisijaisesti sekä MIT-lisenssin että Apache-lisenssin (versio 2.0) ehtojen mukaisesti, ja osia peittävät erilaiset BSD-tyyppiset lisenssit.

Katso lisätietoja kohdista LICENSE-APACHE ja LICENSE-MIT.

# Contribution

Ellet nimenomaisesti toisin sano, kaikilla käyttäjän `core_arch`: ään sisällyttämistä varten tarkoituksella lähettämillä lahjoituksilla, jotka on määritelty Apache-2.0-lisenssissä, on kaksoislisenssi kuten yllä, ilman muita ehtoja.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












