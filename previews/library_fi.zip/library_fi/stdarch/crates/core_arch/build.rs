use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Käytetään kertomaan `#[assert_instr]`-merkinnöillemme, että kaikki simd-sisäiset ominaisuudet ovat käytettävissä koodegeenin testaamiseen, koska jotkut ovat porteilla ylimääräisen `-Ctarget-feature=+unimplemented-simd128`: n takana, jolla ei ole vastaavaa `#[target_feature]`: ssä juuri nyt.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}