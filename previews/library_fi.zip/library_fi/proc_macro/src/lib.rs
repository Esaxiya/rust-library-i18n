//! Tukikirjasto makrokirjailijoille uusien makrojen määrittelyssä.
//!
//! Tämä kirjasto, jonka tarjoaa standardijako, tarjoaa tyypit, jotka kulutetaan menettelyllisesti määriteltyjen makromäärittelyjen rajapinnoissa, kuten toimintomaiset makrot `#[proc_macro]`, makroattribuutit `#[proc_macro_attribute]` ja mukautetut derivaattribuutit "#[proc_macro_derive]".
//!
//!
//! Katso lisätietoja [the book]: stä.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Selvittää, onko proc_macro otettu käyttöön käynnissä olevan ohjelman käytettävissä.
///
/// Proc_macro crate on tarkoitettu käytettäväksi vain prosessimakrojen toteutuksessa.Kaikki tämän crate: n toiminnot panic, jos ne kutsutaan prosessimakron ulkopuolelta, kuten koontikomentosarjasta tai yksikkötestistä tai tavallisesta Rust-binaarista.
///
/// Ottaen huomioon Rust-kirjastot, jotka on suunniteltu tukemaan sekä makro-että ei-makrokäyttöön liittyviä tapauksia, `proc_macro::is_available()` tarjoaa ei-paniikkitavan havaita, onko proc_macro-sovellusliittymän käyttöön vaadittu infrastruktuuri tällä hetkellä käytettävissä.
/// Palauttaa arvon tosi, jos sitä kutsutaan prosessimakron sisäpuolelta, epätosi, jos sitä kutsutaan jostakin muusta binääristä.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Tämän crate: n tarjoama päätyyppi, joka edustaa abstraktia tokens-virtaa tai tarkemmin sanottuna token-puiden sarjaa.
/// Tyyppi tarjoaa käyttöliittymät näiden token-puiden iteroimiseksi ja päinvastoin joukon token-puiden keräämiseksi yhteen virtaan.
///
///
/// Tämä on sekä `#[proc_macro]`-, `#[proc_macro_attribute]`-että `#[proc_macro_derive]`-määritelmien tulo ja lähtö.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Virhe palautettu `TokenStream::from_str`: ltä.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Palauttaa tyhjän `TokenStream`: n, joka ei sisällä token-puita.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Tarkistaa, onko tämä `TokenStream` tyhjä.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Yritetään katkaista merkkijono tokens: ksi ja jäsentää tokens token-virraksi.
/// Saattaa epäonnistua useista syistä, esimerkiksi jos merkkijono sisältää epätasapainoisia erottimia tai merkkejä, joita ei ole kielellä.
///
/// Kaikki jäsennetyn virran tokens saavat `Span::call_site()`-alueet.
///
/// NOTE: jotkut virheet voivat aiheuttaa panics: n palauttamisen sijaan `LexError`: n.Pidätämme oikeuden muuttaa nämä virheet myöhemmin `` LexErroriksi ''.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// Huomaa, että silta tarjoaa vain `to_string`: n, toteuttaa sen perusteella `fmt::Display` (käänteinen tavanomainen suhde näiden kahden välillä).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Tulostaa token-virran merkkijonona, jonka oletetaan olevan häviöttömästi muunnettavissa takaisin samaksi token-virraksi (moduuliväli), lukuun ottamatta mahdollisesti `TokenTree: : Group`: ia, joissa on `Delimiter::None`-erotimet ja negatiiviset numeeriset literaalit.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Tulostaa token: n virheenkorjaukseen sopivassa muodossa.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Luo token-virran, joka sisältää yhden token-puun.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Kerää useita token-puita yhteen virtaan.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// "flattening"-operaatio token-virroilla kerää token-puut useista token-virroista yhdeksi virraksi.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Käytä optimoitua if/when-toteutusta mahdollista.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// `TokenStream`-tyypin julkiset toteutustiedot, kuten iteraattorit.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Toistaja TokenStreamin TokenTree-levylle.
    /// Iteraatio on "shallow", esim. Iteraattori ei toistu rajattuihin ryhmiin ja palauttaa kokonaiset ryhmät token-puina.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` hyväksyy mielivaltaisen tokens: n ja laajenee `TokenStream`: ksi, joka kuvaa tuloa.
/// Esimerkiksi `quote!(a + b)` tuottaa lausekkeen, joka arvioituna muodostaa `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Tarjouspyyntö tehdään `$`: llä ja toimii ottamalla yksi seuraava tunnus noteeraamattomaksi termiksi.
/// Jos haluat lainata itse `$`: tä, käytä `$$`: ää.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Lähdekoodialue ja makrolaajennustiedot.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Luo uuden `Diagnostic`: n annetulla `message`-alueella `self`-alueella.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Alue, joka ratkaisee makron määrityspaikalla.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Nykyisen proseduurimakron kutsun alue.
    /// Tällä aikavälillä luodut tunnisteet ratkaistaan ikään kuin ne kirjoitettaisiin suoraan makropuhelun sijaintiin (puhelupaikan hygienia), ja muut makrokutsupaikan koodit voivat viitata niihin.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Alue, joka edustaa `macro_rules`-hygieniaa ja joka joskus ratkaistaan makron määrityspaikalla (paikalliset muuttujat, tunnisteet, `$crate`) ja joskus makrokutsupaikassa (kaikki muu).
    ///
    /// Alueen sijainti otetaan puhelupaikasta.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Alkuperäinen lähdetiedosto, johon tämä alue osoittaa.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// tokens: n `Span` edellisessä makrolaajennuksessa, josta `self` luotiin, jos sellainen on.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Alku lähdekoodin alue, josta `self` luotiin.
    /// Jos tätä `Span` ei luotu muista makrolaajennuksista, paluuarvo on sama kuin `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Hakee alkavan line/column: n lähdetiedostoon tälle alueelle.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Hakee loppupisteen line/column lähdetiedostoon tälle alueelle.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Luo uuden alueen, joka kattaa `self` ja `other`.
    ///
    /// Palauttaa arvon `None`, jos `self` ja `other` ovat eri tiedostoista.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Luo uuden alueen, jossa on samat line/column-tiedot kuin `self`, mutta se ratkaisee symbolit ikään kuin ne olisivat `other`: ssä.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Luo uuden mittausalueen, jolla on sama nimiresoluutio kuin `self`: llä, mutta `other`: n line/column-tiedoilla.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Vertaa jänneväliin nähdäkseen, ovatko ne tasa-arvoisia.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Palauttaa lähdetekstin alueen taakse.
    /// Tämä säilyttää alkuperäisen lähdekoodin, mukaan lukien välilyönnit ja kommentit.
    /// Se palauttaa tuloksen vain, jos alue vastaa todellista lähdekoodia.
    ///
    /// Note: Makron havaittavan tuloksen tulisi luottaa vain tokens: een eikä tähän lähdetekstiin.
    ///
    /// Tämän toiminnon tulos on paras tapa käyttää vain diagnooseja.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Tulostaa alueen muodon, joka on kätevä virheenkorjausta varten.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Rivi-sarakepari, joka edustaa `Span`: n alkua tai loppua.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// 1-indeksoitu rivi lähdetiedostossa, jolla alue alkaa tai päättyy (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// 0-indeksoitu sarake (UTF-8-merkkeinä) lähdetiedostossa, jolla alue alkaa tai päättyy (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Tietyn `Span`: n lähdetiedosto.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Hakee polun tähän lähdetiedostoon.
    ///
    /// ### Note
    /// Jos tähän `SourceFile`: ään liittyvä koodialue on luotu ulkoisella makrolla, tämä makro ei välttämättä ole varsinainen polku tiedostojärjestelmässä.
    /// Käytä [`is_real`] tarkistaa.
    ///
    /// Huomaa myös, että vaikka `is_real` palauttaisi `true`: n, jos `--remap-path-prefix` välitettiin komentorivillä, annettu polku ei ehkä ole oikea.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Palauttaa `true`: n, jos tämä lähdetiedosto on todellinen lähdetiedosto eikä sitä synny ulkoisen makron laajennuksella.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Tämä on hakkerointi, kunnes intercrate-alueet on toteutettu ja meillä voi olla todellisia lähdetiedostoja ulkoisille makroille.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Yksi token tai rajattu token-puiden sarja (esim. `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// token-virta, jota ympäröivät sulkuerottimet.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Tunniste.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Yksi välimerkki (``+`, `,`, `$` jne.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Kirjaimellinen merkki (`'a'`), merkkijono (`"hello"`), numero (`2.3`) jne.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Palauttaa tämän puun pituuden delegoimalla sisältyvän token: n tai erotetun virran `span`-menetelmään.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Konfiguroi vain tämän token *-alueen.
    ///
    /// Huomaa, että jos tämä token on `Group`, tämä menetelmä ei määritä kunkin sisäisen tokens: n aluetta, tämä yksinkertaisesti delegoi kunkin variantin `set_span`-menetelmän.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Tulostaa token-puun virheenkorjaukseen sopivassa muodossa.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Jokaisella näistä on nimi strukturityypissä johdetussa virheenkorjauksessa, joten älä vaivaudu ylimääräisellä epäsuoralla kerroksella
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// Huomaa, että silta tarjoaa vain `to_string`: n, toteuttaa sen perusteella `fmt::Display` (käänteinen tavanomainen suhde näiden kahden välillä).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Tulostaa token-puun merkkijonona, jonka oletetaan muunnettavan häviöttömästi takaisin samaan token-puuhun (moduuliväli), lukuun ottamatta mahdollisesti `TokenTree: : Group`, jossa on `Delimiter::None`-erotimet ja negatiiviset numeeriset literaalit.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Rajoitettu token-virta.
///
/// `Group` sisältää sisäisesti `TokenStream`: n, jota ympäröivät `Delimiter`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Kuvailee, kuinka token-puiden sarja on rajattu.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Epäsuora erotin, joka voi esiintyä esimerkiksi "macro variable" `$var`: sta tulevan tokens: n ympärillä.
    /// On tärkeää säilyttää käyttäjän prioriteetit sellaisissa tapauksissa kuin `$var * 3`, joissa `$var` on `1 + 2`.
    /// Implisiittiset erotimet eivät välttämättä selviä token-virran edestakaista merkkijonoa.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Luo uuden `Group`: n annetulla erottimella ja token-virralla.
    ///
    /// Tämä rakentaja asettaa tämän ryhmän alueeksi `Span::call_site()`.
    /// Voit muuttaa aluetta käyttämällä alla olevaa `set_span`-menetelmää.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Palauttaa tämän `Group`: n erottimen
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Palauttaa tässä `Group`: ssä erotetun tokens: n `TokenStream`: n.
    ///
    /// Huomaa, että palautettu token-virta ei sisällä yllä palautettua erotinta.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Palauttaa tämän token-virran raja-alueiden koko `Group`-alueen.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Palauttaa alueen osoittavan tämän ryhmän alkuerottimeen.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Palauttaa tämän ryhmän viimeiselle erottimelle osoittavan alueen.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Konfiguroi tämän `ryhmän 'erottimien välin, mutta ei sen sisäistä tokens: tä.
    ///
    /// Tämä menetelmä **ei** aseta kaikkien tämän ryhmän kattamien sisäisten tokens-alueiden aluetta, vaan pikemminkin asettaa vain erottimen tokens alueen `Group`: n tasolle.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// Huomaa, että silta tarjoaa vain `to_string`: n, toteuttaa sen perusteella `fmt::Display` (käänteinen tavanomainen suhde näiden kahden välillä).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Tulostaa ryhmän merkkijonona, jonka pitäisi olla häviöttömästi muunnettavissa takaisin samaan ryhmään (moduuliväli), lukuun ottamatta mahdollisesti `` TokenTree: : Group ''-kohteita, joissa on `Delimiter::None`-erotimet.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` on yksi välimerkki, kuten `+`, `-` tai `#`.
///
/// Monimerkkiset operaattorit, kuten `+=`, on esitetty kahtena `Punct`-esiintymänä, joissa `Spacing`: n eri muodot palautetaan.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Seurataanko `Punct`: ää välittömästi toinen `Punct` vai seuraa toinen token tai välilyönti.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// esim. `+` on `Alone` `+ =`: ssä, `+ident`: ssä tai `+()`: ssä.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// esim. `+` on `Joint` `+=`: ssä tai `'#`: ssä.
    /// Lisäksi yksi lainausmerkki `'` voi liittyä tunnisteisiin muodostaen elinaikoja `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Luo uuden `Punct` annetun merkin ja välin.
    /// `ch`-argumentin on oltava kelvollinen välimerkki, jonka kieli sallii, muuten funktio on panic.
    ///
    /// Palautetulla `Punct`: llä on oletusalue `Span::call_site()`, joka voidaan määrittää edelleen alla olevalla `set_span`-menetelmällä.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Palauttaa välimerkin arvon arvona `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Palauttaa tämän välimerkin välin ilmaisemalla, seuraaeko sitä välittömästi uusi `Punct` token-virrassa, jotta ne voidaan mahdollisesti yhdistää monimerkkiseksi operaattoriksi (`Joint`), tai sitä seuraa jokin muu token tai välilyönti (`Alone`), joten operaattori on varmasti päättyi.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Palauttaa tämän välimerkin span.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Määritä tämän välimerkin alue.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// Huomaa, että silta tarjoaa vain `to_string`: n, toteuttaa sen perusteella `fmt::Display` (käänteinen tavanomainen suhde näiden kahden välillä).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Tulostaa välimerkin merkkijonona, jonka pitäisi olla häviöttömästi muunnettavissa takaisin samaksi merkiksi.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Tunniste (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Luo uuden `Ident`: n annetulla `string`: llä sekä määritetyllä `span`: llä.
    /// `string`-argumentin on oltava kelvollinen kielen sallima tunniste (mukaan lukien avainsanat, esim. `self` tai `fn`).Muussa tapauksessa toiminto on panic.
    ///
    /// Huomaa, että `span`, tällä hetkellä rustc: ssä, määrittää tämän tunnisteen hygieniatiedot.
    ///
    /// Tästä ajankohdasta lähtien `Span::call_site()` on nimenomaisesti valinnut "call-site"-hygienian, mikä tarkoittaa, että tällä aikavälillä luodut tunnisteet ratkaistaan ikään kuin ne kirjoitettaisiin suoraan makropuhelun sijaintiin, ja muut makrokutsupaikan koodit voivat viitata myös heille.
    ///
    ///
    /// Myöhemmät jaksot, kuten `Span::def_site()`, sallivat "definition-site"-hygienian käytön, mikä tarkoittaa, että tällä aikavälillä luodut tunnisteet ratkaistaan makromäärittelyn sijainnissa ja muut makrosoittosivuston koodit eivät voi viitata niihin.
    ///
    /// Hygienian nykyisen tärkeyden vuoksi tämä rakentaja, toisin kuin muut tokens, vaatii `Span`: n määrittelemisen rakennuksessa.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Sama kuin `Ident::new`, mutta luo raakatunnisteen (`r#ident`).
    /// `string`-argumentti on kelvollinen kielen sallima tunniste (mukaan lukien avainsanat, esim. `fn`).
    /// Avainsanat, joita voidaan käyttää polkuosissa (esim
    /// `self`, ``super``) ei tueta ja aiheuttaa panic: n.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Palauttaa tämän `Ident`: n alueen, joka kattaa koko [`to_string`](Self::to_string): n palauttaman merkkijonon.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfiguroi tämän `Ident`: n alueen, mahdollisesti muuttamalla sen hygieniakontekstia.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// Huomaa, että silta tarjoaa vain `to_string`: n, toteuttaa sen perusteella `fmt::Display` (käänteinen tavanomainen suhde näiden kahden välillä).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Tulostaa tunnisteen merkkijonona, jonka pitäisi olla häviöttömästi muunnettavissa takaisin samaksi tunnisteeksi.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Kirjaimellinen merkkijono (`"hello"`), tavumerkkijono (`b"hello"`), merkki (`'a'`), tavumerkki (`b'a'`), kokonaisluku tai liukuluku numero, johon voi liittyä loppuliite (``1``, `1u8`, `2.3`, `2.3f32`).
///
/// Boolen kirjaimet, kuten `true` ja `false`, eivät kuulu tähän, ne ovat `Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Luo uuden täydennetyn kokonaislukutuloksen, jolla on määritetty arvo.
        ///
        /// Tämä toiminto luo kokonaisluvun, kuten `1u32`, jossa määritetty kokonaislukuarvo on token: n ensimmäinen osa ja integraali on myös loppuliite.
        /// Negatiivisista luvuista luodut literaalit eivät välttämättä selviä edestakaisia matkoja `TokenStream`: n tai merkkijonojen läpi, ja ne voidaan jakaa kahteen tokens: ään (`-` ja positiivinen literaali).
        ///
        ///
        /// Tällä menetelmällä luotuilla literaaleilla on oletusarvoisesti `Span::call_site()`-alue, joka voidaan määrittää alla olevalla `set_span`-menetelmällä.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Luo uuden täydentämättömän kokonaislukutunnuksen, jolla on määritetty arvo.
        ///
        /// Tämä toiminto luo kokonaisluvun, kuten `1`, jossa määritetty kokonaislukuarvo on token: n ensimmäinen osa.
        /// Tälle token: lle ei määritetä loppuliitettä, mikä tarkoittaa, että `Literal::i8_unsuffixed(1)`: n kaltaiset kutsut vastaavat `Literal::u32_unsuffixed(1)`: ää.
        /// Negatiivisista numeroista luodut literaalit eivät välttämättä selviä `TokenStream`: n tai merkkijonojen kautta tapahtuvista rrippeistä, ja ne voidaan jakaa kahteen tokens: ään (`-` ja positiivinen literaali).
        ///
        ///
        /// Tällä menetelmällä luotuilla literaaleilla on oletusarvoisesti `Span::call_site()`-alue, joka voidaan määrittää alla olevalla `set_span`-menetelmällä.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Luo uuden kiinnittämättömän kelluvan pisteen kirjaimen.
    ///
    /// Tämä konstruktori on samanlainen kuin `Literal::i8_unsuffixed`, jossa kellukkeen arvo lähetetään suoraan token: een, mutta jälkiliitettä ei käytetä, joten voidaan päätellä olevan `f64` myöhemmin kääntäjässä.
    ///
    /// Negatiivisista numeroista luodut literaalit eivät välttämättä selviä `TokenStream`: n tai merkkijonojen kautta tapahtuvista rrippeistä, ja ne voidaan jakaa kahteen tokens: ään (`-` ja positiivinen literaali).
    ///
    /// # Panics
    ///
    /// Tämä toiminto vaatii, että määritetty uimuri on äärellinen, esimerkiksi jos se on ääretön tai NaN, tämä toiminto tulee olemaan panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Luo uuden liukupisteen kirjainkirjan.
    ///
    /// Tämä konstruktori luo kirjaimen, kuten `1.0f32`, jossa määritetty arvo on token: n edellinen osa ja `f32` on token: n loppuliite.
    /// Tämä token päätellään aina kääntäjässä olevan `f32`.
    /// Negatiivisista numeroista luodut literaalit eivät välttämättä selviä `TokenStream`: n tai merkkijonojen kautta tapahtuvista rrippeistä, ja ne voidaan jakaa kahteen tokens: ään (`-` ja positiivinen literaali).
    ///
    ///
    /// # Panics
    ///
    /// Tämä toiminto vaatii, että määritetty uimuri on äärellinen, esimerkiksi jos se on ääretön tai NaN, tämä toiminto tulee olemaan panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Luo uuden kiinnittämättömän kelluvan pisteen kirjaimen.
    ///
    /// Tämä konstruktori on samanlainen kuin `Literal::i8_unsuffixed`, jossa kellukkeen arvo lähetetään suoraan token: een, mutta jälkiliitettä ei käytetä, joten voidaan päätellä olevan `f64` myöhemmin kääntäjässä.
    ///
    /// Negatiivisista numeroista luodut literaalit eivät välttämättä selviä `TokenStream`: n tai merkkijonojen kautta tapahtuvista rrippeistä, ja ne voidaan jakaa kahteen tokens: ään (`-` ja positiivinen literaali).
    ///
    /// # Panics
    ///
    /// Tämä toiminto vaatii, että määritetty uimuri on äärellinen, esimerkiksi jos se on ääretön tai NaN, tämä toiminto tulee olemaan panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Luo uuden liukupisteen kirjainkirjan.
    ///
    /// Tämä konstruktori luo kirjaimen, kuten `1.0f64`, jossa määritetty arvo on token: n edellinen osa ja `f64` on token: n loppuliite.
    /// Tämä token päätellään aina kääntäjässä olevan `f64`.
    /// Negatiivisista numeroista luodut literaalit eivät välttämättä selviä `TokenStream`: n tai merkkijonojen kautta tapahtuvista rrippeistä, ja ne voidaan jakaa kahteen tokens: ään (`-` ja positiivinen literaali).
    ///
    ///
    /// # Panics
    ///
    /// Tämä toiminto vaatii, että määritetty uimuri on äärellinen, esimerkiksi jos se on ääretön tai NaN, tämä toiminto tulee olemaan panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Merkkijono kirjaimellinen.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Hahmo kirjaimellinen.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Tavu merkkijono kirjaimellinen.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Palauttaa tämän kirjaimen kattavan alueen.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfiguroi tälle kirjaimelle liitetyn alueen.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Palauttaa `Span`: n, joka on `self.span()`: n osajoukko, joka sisältää vain lähdetavut alueella `range`.
    /// Palauttaa arvon `None`, jos mahdollinen leikattu alue on `self`: n rajojen ulkopuolella.
    ///
    // FIXME(SergioBenitez): Tarkista, että tavualue alkaa ja päättyy lähteen UTF-8-rajalla.
    // muuten on todennäköistä, että panic esiintyy muualla, kun lähdeteksti tulostetaan.
    // FIXME(SergioBenitez): Käyttäjällä ei ole mitään keinoa tietää, mihin `self.span()` todella kartoittaa, joten tätä menetelmää voidaan tällä hetkellä kutsua vain sokeasti.
    // Esimerkiksi `to_string()` merkille 'c' palauttaa arvon "'\u{63}'";Käyttäjällä ei ole mitään keinoa tietää, oliko lähdeteksti 'c' vai onko se '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) jotain samanlaista kuin `Option::cloned`, mutta `Bound<&T>`: lle.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// Huomaa, että silta tarjoaa vain `to_string`: n, toteuttaa sen perusteella `fmt::Display` (käänteinen tavanomainen suhde näiden kahden välillä).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Tulostaa literaalin merkkijonona, jonka pitäisi olla häviöttömästi muunnettavissa takaisin samaan literaaliin (lukuun ottamatta mahdollista liukulukuisten literaalien pyöristämistä).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Seurataan ympäristömuuttujien käyttöä.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Hae ympäristömuuttuja ja lisää se riippuvuustietojen rakentamiseen.
    /// Kääntäjää suorittava koontijärjestelmä tietää, että muuttujaa käytettiin kääntämisen aikana, ja pystyy suorittamaan koontiversion uudelleen, kun muuttujan arvo muuttuu.
    ///
    /// Riippuvuuden seurannan lisäksi tämän toiminnon tulisi olla samanlainen kuin standardikirjaston `env::var`, paitsi että argumentin on oltava UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}