use backtrace::Backtrace;

// 50-वर्ण मॉड्यूल नाव
mod _234567890_234567890_234567890_234567890_234567890 {
    // 50-वर्णांचे स्ट्रेट नाव
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// लांब फंक्शन नावे (MAX_SYM_NAME, 1) वर्णांपर्यंत लहान करणे आवश्यक आहे.
// gnu सर्व फ्रेमसाठी "<no info>" प्रिंट केल्यामुळे केवळ एमएसव्हीसीसाठी ही चाचणी चालवा.
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // संरचनेच्या नावाची 10 पुनरावृत्ती, तर पूर्णपणे पात्र फंक्शनचे नाव किमान 10 *(50 + 50)* 2=2000 वर्ण लांब आहे.
    //
    // यात `::`, `<>` आणि विद्यमान मॉड्यूलचे नावदेखील समाविष्ट आहे
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}