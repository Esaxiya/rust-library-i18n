use backtrace::Backtrace;

// ही चाचणी केवळ अशा प्लॅटफॉर्मवर कार्य करते ज्यात फ्रेमसाठी कार्यरत `symbol_address` कार्य आहे जे चिन्हाच्या सुरूवातीच्या पत्त्याचा अहवाल देतात.
// परिणामी ते केवळ काही प्लॅटफॉर्मवरच सक्षम केलेले आहे.
//
const ENABLED: bool = cfg!(all(
    // Windows खरोखर चाचणी केली गेली नाही आणि ओएसएक्स प्रत्यक्षात एन्कोसिंग फ्रेम शोधण्यात समर्थन देत नाही, म्हणून हे अक्षम करा
    //
    target_os = "linux",
    // एआरएम वर एन्कोल्जिंग फंक्शन शोधणे आयपीलाच परत करत आहे.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}