use core::ffi::c_void;
use core::fmt;

/// स्टॅक ट्रेसची गणना करण्यासाठी पुरवलेल्या क्लोजरमध्ये सर्व सक्रिय फ्रेम्स देऊन, वर्तमान कॉल-स्टॅकची तपासणी करते.
///
/// प्रोग्रामसाठी स्टॅक ट्रेस मोजण्यासाठी हे फंक्शन या लायब्ररीचे वर्क हॉर्स आहे.दिलेल्या क्लोजर एक्स 100 एक्सला एक्स01 एक्सची उदाहरणे दिली आहेत जी स्टॅकवरील त्या कॉल फ्रेमबद्दल माहितीचे प्रतिनिधित्व करतात.
/// क्लोजरला टॉप-डाऊन फॅशनमध्ये फ्रेम मिळतात (सर्वात अलीकडे फंक्शन्स आधी म्हणतात).
///
/// क्लोजरचे रिटर्न मूल्य बॅकट्रॅस चालू ठेवावे की नाही हे सूचित होते.`false` चे परतावा मूल्य बॅकट्रेस समाप्त करेल आणि त्वरित परत येईल.
///
/// एकदा `Frame` प्राप्त झाल्यावर आपणास `ip` (सूचना पॉईंटर) किंवा प्रतीक पत्त्याचे रूपांतर करण्यासाठी `backtrace::resolve` वर कॉल करावा लागेल ज्याद्वारे नाव आणि/किंवा फाइलनाव/ओळ क्रमांक शिकता येईल.
///
///
/// लक्षात ठेवा की हे एक तुलनेने निम्न-स्तरीय कार्य आहे आणि उदाहरणार्थ आपण नंतर तपासणीसाठी बॅकट्रॅस कॅप्चर करू इच्छित असाल तर `Backtrace` प्रकार अधिक योग्य असेल.
///
/// # आवश्यक वैशिष्ट्ये
///
/// या कार्यासाठी `backtrace` crate चे `std` वैशिष्ट्य सक्षम केले जाणे आवश्यक आहे आणि `std` वैशिष्ट्य डीफॉल्टनुसार सक्षम केलेले आहे.
///
/// # Panics
///
/// हे कार्य panic कधीही न करण्याचा प्रयत्न करीत आहे, परंतु जर `cb` ने panics प्रदान केले तर काही प्लॅटफॉर्म दुहेरी panic प्रक्रिया थांबविण्यास भाग पाडतील.
/// काही प्लॅटफॉर्म सी लायब्ररी वापरतात जे अंतर्गतरित्या कॉलबॅक वापरतात जे अवाउंड होऊ शकत नाहीत, म्हणून एक्स 100 एक्सपासून घाबरून एक प्रक्रिया थांबवणे चालू शकते.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // बॅकट्रेस सुरू ठेवा
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// `trace` प्रमाणेच, ते असिंक्रनाइझ केलेले आहे म्हणूनच असुरक्षित आहे.
///
/// या फंक्शनमध्ये सिंक्रोनाइझेशन गॅरेंटी नाहीत परंतु जेव्हा या झेडकेरेट0झेडचे एक्स 100 एक्स वैशिष्ट्य संकलित केलेले नसते तेव्हा उपलब्ध असते.
/// अधिक दस्तऐवजीकरण आणि उदाहरणांसाठी एक्स 100 एक्स कार्य पहा.
///
/// # Panics
///
/// पॅनीकिंगवर `cb` च्या कॅव्हेटसाठी `trace` ची माहिती पहा.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// या crate च्या `trace` फंक्शनला बॅकट्रसच्या एका फ्रेमचे प्रतिनिधित्व करणारे trait दिले.
///
/// ट्रेसिंग फंक्शनच्या समाप्तीस फ्रेम मिळतील आणि फ्रेम अंमलात पाठविला जाईल कारण अंतर्निहित अंमलबजावणी रनटाइमपर्यंत नेहमीच माहित नसते.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// या फ्रेमचा सद्य सूचना सूचक मिळवते.
    ///
    /// फ्रेममध्ये अंमलात आणण्याची ही साधारणत: पुढील सूचना असते, परंतु सर्व अंमलबजावणीमध्ये 100% अचूकतेची यादी नसते (परंतु ती सहसा खूपच जवळ असते).
    ///
    ///
    /// हे मूल्य प्रतीक नावात बदलण्यासाठी हे मूल्य `backtrace::resolve` वर देण्याची शिफारस केली जाते.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// या फ्रेमचा सद्य स्टॅक पॉईंटर मिळवते.
    ///
    /// या फ्रेमसाठी बॅकएंड स्टॅक पॉईन्टर पुनर्प्राप्त करू शकत नाही अशा बाबतीत, एक शून्य पॉईंटर परत केला जातो.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// या फंक्शनच्या फ्रेमचा प्रारंभिक प्रतीक पत्ता मिळवते.
    ///
    /// हे मूल्य परत करून `ip` ने कार्याच्या सुरूवातीस परत केलेले सूचना पॉइंटर रिवाइंड करण्याचा प्रयत्न करेल.
    ///
    /// तथापि, काही प्रकरणांमध्ये, बॅकएन्ड या फंक्शनमधून फक्त `ip` परत करेल.
    ///
    /// उपरोक्त `ip` वर `backtrace::resolve` अयशस्वी झाल्यास कधीकधी परत केलेले मूल्य वापरले जाऊ शकते.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// ज्या मॉडेलचा फ्रेम संबंधित आहे त्याचा मूळ पत्ता मिळवते.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // यजमान प्लॅटफॉर्मपेक्षा मिरीने प्राधान्य दिलेले आहे हे सुनिश्चित करण्यासाठी हे प्रथम येणे आवश्यक आहे
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // केवळ dbghelp प्रतीक म्हणून वापरले
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}