//! एक्स00 एक्स एपीआय वापरुन बॅकट्रेस समर्थन.
//!
//! या मॉड्यूलमध्ये लिबुनविंड-शैली एपीआय वापरुन स्टॅक अनव्हिंड करण्याची क्षमता आहे.
//! लक्षात घ्या की लिबुनविंड-सारख्या एपीआयच्या अंमलबजावणीचा संपूर्ण समूह आहे, आणि हे फक्त पिकण्याऐवजी बर्‍याचदा सुसंगत राहण्याचा प्रयत्न करीत आहे.
//!
//!
//! लिबुनविंड एपीआय एक्स00 एक्स द्वारा समर्थित आहे आणि बॅकट्रॅस व्युत्पन्न करण्यात व्यावहारिक आहे.
//! ते कसे करते हे पूर्णपणे स्पष्ट नाही (फ्रेम पॉईंटर्स? एह_फ्रेम माहिती? दोन्ही?) पण कार्य करते असे दिसते!
//!
//! या मॉड्यूलची बहुतेक जटिलता लिबुनविंड अंमलबजावणीमध्ये विविध प्लॅटफॉर्ममधील फरक हाताळत आहे.
//! अन्यथा हे लिबुनविंड एपीआय साठी एक सरळ सरळ Rust बंधनकारक आहे.
//!
//! हे सध्या सर्व विना-विंडोज प्लॅटफॉर्मसाठी डीफॉल्ट अनावश्यक API आहे.
//!
//!
//!

use super::super::Bomb;
use core::ffi::c_void;

pub enum Frame {
    Raw(*mut uw::_Unwind_Context),
    Cloned {
        ip: *mut c_void,
        sp: *mut c_void,
        symbol_address: *mut c_void,
    },
}

// कच्च्या लिबुनविंड पॉईंटरसह केवळ वाचन केवळ थ्रेडसेफ फॅशनमध्ये प्रवेश केला पाहिजे, म्हणून ते एक्स 100 एक्स आहे.
// `Clone` मार्गे अन्य थ्रेड्स पाठवित असताना आम्ही नेहमीच अशा आवृत्तीवर स्विच करतो जे इंटिरियर पॉईंटर्स राखून ठेवत नाही, म्हणून आपण देखील `Send` असले पाहिजे.
//
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        let ctx = match *self {
            Frame::Raw(ctx) => ctx,
            Frame::Cloned { ip, .. } => return ip,
        };
        unsafe { uw::_Unwind_GetIP(ctx) as *mut c_void }
    }

    pub fn sp(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ctx) => unsafe { uw::get_sp(ctx) as *mut c_void },
            Frame::Cloned { sp, .. } => sp,
        }
    }

    pub fn symbol_address(&self) -> *mut c_void {
        if let Frame::Cloned { symbol_address, .. } = *self {
            return symbol_address;
        }

        // असे दिसते आहे की OSX. _Uwwind_FindEnclosingFunction` वर एक पॉईंटर परत आला आहे ... काहीतरी अस्पष्ट आहे.
        // हे नक्कीच कोणत्याही कारणास्तव एन्कोल्सिंग फंक्शन नसते.
        // येथे काय चालले आहे हे माझ्यासाठी पूर्णपणे स्पष्ट नाही, म्हणून हे आता निराश करा आणि नेहमी आयपी परत करा.
        //
        // लक्षात घ्या की या कलमामुळे ओएसएक्सवर एक्स 100 एक्स चाचणी वगळली गेली आहे आणि जर हे निश्चित केले असेल तर सिद्धांतमधील चाचणी ओएसएक्सवर चालविली जाऊ शकते!
        //
        //
        //
        if cfg!(target_os = "macos") || cfg!(target_os = "ios") {
            self.ip()
        } else {
            unsafe { uw::_Unwind_FindEnclosingFunction(self.ip()) }
        }
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        None
    }
}

impl Clone for Frame {
    fn clone(&self) -> Frame {
        Frame::Cloned {
            ip: self.ip(),
            sp: self.sp(),
            symbol_address: self.symbol_address(),
        }
    }
}

#[inline(always)]
pub unsafe fn trace(mut cb: &mut dyn FnMut(&super::Frame) -> bool) {
    uw::_Unwind_Backtrace(trace_fn, &mut cb as *mut _ as *mut _);

    extern "C" fn trace_fn(
        ctx: *mut uw::_Unwind_Context,
        arg: *mut c_void,
    ) -> uw::_Unwind_Reason_Code {
        let cb = unsafe { &mut *(arg as *mut &mut dyn FnMut(&super::Frame) -> bool) };
        let cx = super::Frame {
            inner: Frame::Raw(ctx),
        };

        let mut bomb = Bomb { enabled: true };
        let keep_going = cb(&cx);
        bomb.enabled = false;

        if keep_going {
            uw::_URC_NO_REASON
        } else {
            uw::_URC_FAILURE
        }
    }
}

/// बॅकट्रेससाठी वापरलेले लायब्ररी इंटरफेस अनइंड करा
///
/// लक्षात घ्या की डेड कोडला अनुमती आहे कारण फक्त बाईंडिंग्स iOS हे सर्व वापरत नाहीत परंतु अधिक व्यासपीठ-विशिष्ट कॉन्फिगरेशन्स जोडल्याने कोड खूपच दूषित होतो
///
///
#[allow(non_camel_case_types)]
#[allow(non_snake_case)]
#[allow(dead_code)]
mod uw {
    pub use self::_Unwind_Reason_Code::*;

    use core::ffi::c_void;

    #[repr(C)]
    pub enum _Unwind_Reason_Code {
        _URC_NO_REASON = 0,
        _URC_FOREIGN_EXCEPTION_CAUGHT = 1,
        _URC_FATAL_PHASE2_ERROR = 2,
        _URC_FATAL_PHASE1_ERROR = 3,
        _URC_NORMAL_STOP = 4,
        _URC_END_OF_STACK = 5,
        _URC_HANDLER_FOUND = 6,
        _URC_INSTALL_CONTEXT = 7,
        _URC_CONTINUE_UNWIND = 8,
        _URC_FAILURE = 9, // फक्त एआरएम ईएबीआय द्वारे वापरलेले
    }

    pub enum _Unwind_Context {}

    pub type _Unwind_Trace_Fn =
        extern "C" fn(ctx: *mut _Unwind_Context, arg: *mut c_void) -> _Unwind_Reason_Code;

    extern "C" {
        // IOS वर मूळ नाही_अविंद_बॅकट्रेस
        #[cfg(not(all(target_os = "ios", target_arch = "arm")))]
        pub fn _Unwind_Backtrace(
            trace: _Unwind_Trace_Fn,
            trace_argument: *mut c_void,
        ) -> _Unwind_Reason_Code;

        // GCC 4.2.0 पासून उपलब्ध, आमच्या हेतूसाठी ठीक असावे
        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "s390x"))
        ))]
        // हे फंक्शन चुकीचे लिहिलेले आहे: या फ्रेमचा कॅनॉनिकल फ्रेम अ‍ॅड्रेस (उर्फ कॉलर फ्रेमचा एसपी) मिळण्याऐवजी या फ्रेमचा एसपी मिळवते.
        //
        //
        // https://github.com/libunwind/libunwind/blob/d32956507cf29d9b1a98a8bce53c78623908f4fe/src/unwind/GetCFA.c#L28-L35
        //
        #[link_name = "_Unwind_GetCFA"]
        pub fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t;
    }

    // s390x पक्षपाती सीएफए मूल्य वापरते, म्हणून आम्हाला _उंडविंड_गेटसीएफए वर अवलंबून न राहता स्टॅक पॉईंटर नोंदणी (%r15) मिळविण्यासाठी _उंडविंड_गेटजीआर वापरण्याची आवश्यकता आहे.
    //
    //
    #[cfg(all(target_os = "linux", target_arch = "s390x"))]
    pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
        extern "C" {
            pub fn _Unwind_GetGR(ctx: *mut _Unwind_Context, index: libc::c_int) -> libc::uintptr_t;
        }
        _Unwind_GetGR(ctx, 15)
    }

    // android आणि आर्म वर, एक्स ०१ एक्स फंक्शन आणि इतरांचे एक समूह मॅक्रो आहेत, म्हणून आम्ही मॅक्रोच्या विस्तारासह कार्ये परिभाषित करतो.
    //
    //
    // TODO: आपल्याला हे सापडल्यास, हे मॅक्रो परिभाषित करणार्‍या शीर्षलेख फाईलवर दुवा साधा.
    // (मी, फिटझेन, यापैकी काही मॅक्रो विस्तार मूळतः घेतलेल्या शीर्षलेख फाइल शोधू शकले नाहीत.)
    //
    //
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    pub use self::arm::*;
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    mod arm {
        pub use super::*;
        #[repr(C)]
        enum _Unwind_VRS_Result {
            _UVRSR_OK = 0,
            _UVRSR_NOT_IMPLEMENTED = 1,
            _UVRSR_FAILED = 2,
        }
        #[repr(C)]
        enum _Unwind_VRS_RegClass {
            _UVRSC_CORE = 0,
            _UVRSC_VFP = 1,
            _UVRSC_FPA = 2,
            _UVRSC_WMMXD = 3,
            _UVRSC_WMMXC = 4,
        }
        #[repr(C)]
        enum _Unwind_VRS_DataRepresentation {
            _UVRSD_UINT32 = 0,
            _UVRSD_VFPX = 1,
            _UVRSD_FPAX = 2,
            _UVRSD_UINT64 = 3,
            _UVRSD_FLOAT = 4,
            _UVRSD_DOUBLE = 5,
        }

        type _Unwind_Word = libc::c_uint;
        extern "C" {
            fn _Unwind_VRS_Get(
                ctx: *mut _Unwind_Context,
                klass: _Unwind_VRS_RegClass,
                word: _Unwind_Word,
                repr: _Unwind_VRS_DataRepresentation,
                data: *mut c_void,
            ) -> _Unwind_VRS_Result;
        }

        pub unsafe fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                15,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            (val & !1) as libc::uintptr_t
        }

        // R13 हातावर स्टॅक पॉईंटर आहे.
        const SP: _Unwind_Word = 13;

        pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                SP,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            val as libc::uintptr_t
        }

        // हे कार्य Android किंवा ARM/Linux वर देखील विद्यमान नाही, म्हणून त्यास नो-ऑप करा.
        //
        pub unsafe fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void {
            pc
        }
    }
}