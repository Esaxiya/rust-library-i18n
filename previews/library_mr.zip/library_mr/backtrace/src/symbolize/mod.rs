use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// पत्त्याचे प्रतीक निर्दिष्ट क्लोजरवर सोडत चिन्हावर सोडवा.
///
/// हे फंक्शन दिले जाणारे चिन्ह शोधण्यासाठी स्थानिक चिन्ह सारणी, डायनॅमिक प्रतीक सारणी किंवा DWARF डीबग माहिती (सक्रिय अंमलबजावणीवर अवलंबून) यासारख्या क्षेत्रात दिसेल.
///
///
/// रिझोल्यूशन केले गेले नाही तर क्लोजर म्हटले जाऊ शकत नाही, आणि इनलिंग फंक्शन्सच्या बाबतीत हे एकापेक्षा जास्त वेळा कॉल केले जाऊ शकते.
///
/// दिलेली चिन्हे निर्दिष्ट केलेल्या `addr` वर अंमलबजावणीचे प्रतिनिधित्व करतात, त्या पत्त्यासाठी (उपलब्ध असल्यास) file/line जोड्या परत करतात.
///
/// लक्षात घ्या की आपल्याकडे `Frame` असल्यास त्याऐवजी `resolve_frame` फंक्शन वापरण्याची शिफारस केली जाते.
///
/// # आवश्यक वैशिष्ट्ये
///
/// या कार्यासाठी `backtrace` crate चे `std` वैशिष्ट्य सक्षम केले जाणे आवश्यक आहे आणि `std` वैशिष्ट्य डीफॉल्टनुसार सक्षम केलेले आहे.
///
/// # Panics
///
/// हे कार्य panic कधीही न करण्याचा प्रयत्न करीत आहे, परंतु जर `cb` ने panics प्रदान केले तर काही प्लॅटफॉर्म दुहेरी panic प्रक्रिया थांबविण्यास भाग पाडतील.
/// काही प्लॅटफॉर्म सी लायब्ररी वापरतात जे अंतर्गतरित्या कॉलबॅक वापरतात जे अवाउंड होऊ शकत नाहीत, म्हणून एक्स 100 एक्सपासून घाबरून एक प्रक्रिया थांबवणे चालू शकते.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // फक्त वरच्या चौकटीकडे पहा
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// पूर्वीच्या कॅप्चर फ्रेमचे प्रतीक निर्दिष्ट क्लोजरवर सोडवून निराकरण करा.
///
/// हे फंक्टिन `resolve` प्रमाणेच कार्य करते परंतु त्याऐवजी पत्त्याऐवजी `Frame` वितर्क म्हणून घेते.
/// हे बॅकट्रॅसींगच्या काही प्लॅटफॉर्म अंमलबजावणीस अधिक अचूक प्रतीक माहिती किंवा इनलाइन फ्रेमबद्दल माहिती प्रदान करते.
///
/// शक्य असल्यास हे वापरण्याची शिफारस केली जाते.
///
/// # आवश्यक वैशिष्ट्ये
///
/// या कार्यासाठी `backtrace` crate चे `std` वैशिष्ट्य सक्षम केले जाणे आवश्यक आहे आणि `std` वैशिष्ट्य डीफॉल्टनुसार सक्षम केलेले आहे.
///
/// # Panics
///
/// हे कार्य panic कधीही न करण्याचा प्रयत्न करीत आहे, परंतु जर `cb` ने panics प्रदान केले तर काही प्लॅटफॉर्म दुहेरी panic प्रक्रिया थांबविण्यास भाग पाडतील.
/// काही प्लॅटफॉर्म सी लायब्ररी वापरतात जे अंतर्गतरित्या कॉलबॅक वापरतात जे अवाउंड होऊ शकत नाहीत, म्हणून एक्स 100 एक्सपासून घाबरून एक प्रक्रिया थांबवणे चालू शकते.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // फक्त वरच्या चौकटीकडे पहा
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// स्टॅक फ्रेम्समधील आयपी व्हॅल्यूज सामान्यत: एक्स कॉल एक्स निर्देश नंतर * कॉल नंतर वास्तविक स्टॅक ट्रेस असतात.
// यावर प्रतीक बनविण्यामुळे filename/line क्रमांकाची कार्यक्षमता संपुष्टात आल्यास जवळच्या शून्यामध्ये एक असू शकते.
//
// मुळात हे सर्व प्लॅटफॉर्मवर नेहमीच दिसून येते, म्हणून आम्ही सूचना परत केल्याऐवजी मागील कॉल इंस्ट्रक्शनवर सोडविण्यासाठी निराकरण केलेल्या आयपीमधून नेहमीच वजा करतो.
//
//
// तद्वतच आम्ही असे करणार नाही.
// तद्वतच आम्ही येथे एक्स 100 एक्स एपीआय च्या कॉलरना व्यक्तिचलितपणे एक्स ०१ एक्स करणे आवश्यक आहे आणि ते खाते चालू असलेल्याच्या नव्हे तर *मागील* सूचनांसाठी स्थान माहिती हवी आहे हे खाते आहे.
// आम्ही खरोखर पुढच्या सूचनाचा किंवा वर्तमानचा पत्ता असल्यास आम्ही खरोखरच `Frame` वर उघडकीस आणतो.
//
// आत्ता तरी ही एक अतिशय महत्वाची चिंता आहे म्हणून आम्ही फक्त अंतर्गतपणे नेहमीच एक वजा करतो.
// ग्राहकांनी कार्य करत रहावे आणि चांगले चांगले परिणाम मिळविले पाहिजेत, जेणेकरून आपण पुरेसे चांगले असले पाहिजे.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// `resolve` प्रमाणेच, ते असिंक्रनाइझ केलेले आहे म्हणूनच असुरक्षित आहे.
///
/// या फंक्शनमध्ये सिंक्रोनाइझेशन गॅरेंटी नाहीत परंतु जेव्हा या झेडकेरेट0झेडचे एक्स 100 एक्स वैशिष्ट्य संकलित केलेले नसते तेव्हा उपलब्ध असते.
/// अधिक दस्तऐवजीकरण आणि उदाहरणांसाठी एक्स 100 एक्स कार्य पहा.
///
/// # Panics
///
/// पॅनीकिंगवर `cb` च्या कॅव्हेटसाठी `resolve` ची माहिती पहा.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// `resolve_frame` प्रमाणेच, ते असिंक्रनाइझ केलेले आहे म्हणूनच असुरक्षित आहे.
///
/// या फंक्शनमध्ये सिंक्रोनाइझेशन गॅरेंटी नाहीत परंतु जेव्हा या झेडकेरेट0झेडचे एक्स 100 एक्स वैशिष्ट्य संकलित केलेले नसते तेव्हा उपलब्ध असते.
/// अधिक दस्तऐवजीकरण आणि उदाहरणांसाठी एक्स 100 एक्स कार्य पहा.
///
/// # Panics
///
/// पॅनीकिंगवर `cb` च्या कॅव्हेटसाठी `resolve_frame` ची माहिती पहा.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// फाईलमधील चिन्हाचे रिझोल्यूशन दर्शविणारा एक trait.
///
/// हे trait `backtrace::resolve` फंक्शनला दिलेल्या बंदकडे trait ऑब्जेक्ट म्हणून उत्पन्न केले आहे आणि त्यामागील अंमलबजावणी मागे आहे हे माहित नसल्याने हे अक्षरशः पाठविले गेले आहे.
///
///
/// चिन्ह एखाद्या कार्याबद्दल प्रासंगिक माहिती देऊ शकते, उदाहरणार्थ नाव, फाइलनाव, ओळ क्रमांक, अचूक पत्ता इ.
/// सर्व माहिती नेहमीच चिन्हात उपलब्ध नसते, तथापि, सर्व पद्धती एक एक्स 100 एक्स परत करतात.
///
///
pub struct Symbol {
    // TODO: ही आजीवन मर्यादा अखेरीस `Symbol` पर्यंत कायम ठेवणे आवश्यक आहे,
    // पण तो सध्या ब्रेकिंग बदल आहे.
    // आत्ता हे सुरक्षित आहे कारण `Symbol` केवळ संदर्भानुसार दिले गेले आहे आणि क्लोन करणे शक्य नाही.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// या कार्याचे नाव मिळवते.
    ///
    /// परत आलेल्या संरचनेचा उपयोग चिन्हांच्या नावाबद्दल विविध गुणधर्मांबद्दल विचार करण्यासाठी केला जाऊ शकतो.
    ///
    ///
    /// * `Display` अंमलबजावणी डिमॅन्ग्ड चिन्हांचे मुद्रण करेल.
    /// * चिन्हाचे कच्चे `str` मूल्य मिळू शकते (ते वैध utf-8 असल्यास).
    /// * चिन्हाच्या नावाचे कच्चे बाइट मिळू शकतात.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// या कार्याचा प्रारंभ पत्ता परत करते.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// स्लाईस म्हणून कच्चे फाइलनाव मिळवते.
    /// हे प्रामुख्याने `no_std` वातावरणात उपयुक्त आहे.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// हे चिन्ह सध्या ज्या ठिकाणी कार्यरत आहे तेथे स्तंभ क्रमांक मिळवते.
    ///
    /// केवळ जिमली येथे येथे मूल्य प्रदान करते आणि तरीही `filename` ने `Some` परत केले तरच, आणि म्हणूनच ते अशाच प्रकारच्या सावधगिरीच्या अधीन असेल.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// हे चिन्ह सध्या ज्या अंमलात येत आहे त्यासाठी रेखा क्रमांक मिळवते.
    ///
    /// हे रिटर्न मूल्य सामान्यत: `Some` असते जर `filename` ने `Some` परत केले आणि यामुळे समान सावधानतेच्या अधीन असेल.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// जिथे हे कार्य परिभाषित केले होते त्या फाईलचे नाव परत करते.
    ///
    /// हे केवळ तेव्हाच उपलब्ध आहे जेव्हा लिबब्रेट्रेस किंवा जिमली वापरली जात आहे (उदा
    /// unix प्लॅटफॉर्म अन्य) आणि जेव्हा बायनरी डीबगइन्फो सह संकलित केली जाते.
    /// जर यापैकी कोणतीही एक पूर्ण केली नाही तर कदाचित हे `None` परत करेल.
    ///
    /// # आवश्यक वैशिष्ट्ये
    ///
    /// या कार्यासाठी `backtrace` crate चे `std` वैशिष्ट्य सक्षम केले जाणे आवश्यक आहे आणि `std` वैशिष्ट्य डीफॉल्टनुसार सक्षम केलेले आहे.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Rust म्हणून मंगळ चिन्हाचे विश्लेषण करणे अयशस्वी झाल्यास कदाचित विश्लेषित C++ प्रतीक.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // हे शून्य-आकाराचे असल्याचे सुनिश्चित करा, जेणेकरून अक्षम झाल्यावर `cpp_demangle` वैशिष्ट्यास कोणतीही किंमत नसते.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// डिमॅंगल्ड नावावर एर्गोनोमिक orsक्सेसर्स, कच्चे बाइट, कच्चे स्ट्रिंग इत्यादी प्रदान करण्यासाठी चिन्हाच्या नावाभोवती एक आवरण
///
// जेव्हा `cpp_demangle` वैशिष्ट्य सक्षम केलेले नसेल तेव्हासाठी डेड कोडला अनुमती द्या.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// कच्च्या अंतर्निहित बाइटवरून एक नवीन प्रतीक नाव तयार करते.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// चिन्ह वैध utf-8 असल्यास `str` म्हणून कच्चे (mangled) प्रतीक नाव परत करते.
    ///
    /// आपणास डिमांड केलेली आवृत्ती हवी असल्यास `Display` अंमलबजावणीचा वापर करा.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// बाइटच्या सूची म्हणून कच्चे प्रतीक नाव परत करते
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // हे विकृत चिन्ह प्रत्यक्षात वैध नसल्यास हे मुद्रित करू शकते, म्हणून बाह्यरुपाचा प्रचार न करता त्रुटी येथे कुशलतेने हाताळा.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// पत्त्याचे प्रतीक म्हणून वापरलेल्या कॅश्ड मेमरीवर पुन्हा हक्क सांगण्याचा प्रयत्न करा.
///
/// ही पद्धत कोणत्याही जागतिक डेटा स्ट्रक्चर्सला सोडण्याचा प्रयत्न करेल जी अन्यथा जागतिक स्तरावर किंवा थ्रेडमध्ये कॅशे केलेली विशेषत: विश्लेषित DWARF माहिती किंवा तत्सम प्रतिनिधित्व करते.
///
///
/// # Caveats
///
/// हे कार्य नेहमी उपलब्ध असताना बहुतेक अंमलबजावणींवर प्रत्यक्षात काहीही करत नाही.
/// Dbghelp किंवा libbacktrace सारख्या ग्रंथालये राज्य कमी करण्यासाठी आणि वाटप केलेल्या मेमरी व्यवस्थापित करण्यासाठी सुविधा पुरवित नाहीत.
/// आता या झेडकेरेट0 झेडचे एक्स 100 एक्स वैशिष्ट्य एकमेव वैशिष्ट्य आहे जेथे या कार्याचा कोणताही प्रभाव आहे.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}