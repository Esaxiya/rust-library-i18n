//! लिबब्रेट्रेस मधील DWARF-विश्लेषण कोड वापरून प्रतीकात्मक कार्यनीती.
//!
//! लिबब्रेट्रेस सी लायब्ररी सामान्यत: झेडजीसीसी ० झेड सह वितरित केली जाते, जी केवळ बॅकट्रॅस (आम्ही प्रत्यक्षात वापरत नाही) तयार करणे समर्थन पुरवित नाही तर इनक्रिट फ्रेम आणि व्हॉट नॉट यासारख्या गोष्टींबद्दल बॅकट्रॅस प्रतीकित करते आणि बटू डीबग माहिती हाताळते.
//!
//!
//! येथे बर्‍याच प्रकारच्या विविध समस्यांमुळे हे तुलनेने गुंतागुंतीचे आहे, परंतु मूळ कल्पना अशीः
//!
//! * प्रथम आम्ही `backtrace_syminfo` कॉल करतो.आपल्याला शक्य असल्यास डायनॅमिक प्रतीक सारणी वरून चिन्हांची माहिती मिळेल.
//! * पुढे आम्ही `backtrace_pcinfo` कॉल करतो.हे डीबगइन्फो सारण्या उपलब्ध असल्यास त्या विश्लेषित करेल आणि आम्हाला इनलाइन फ्रेम, फाईलनावे, रेखा क्रमांक इत्यादी माहिती पुनर्प्राप्त करण्यास अनुमती देईल.
//!
//! बायर्न टेबल्सला लिबब्रेट्रेसमध्ये घेण्याविषयी बरेच युक्ती आहे, परंतु आशा आहे की या जगाचा शेवट नाही आणि खाली वाचताना हे स्पष्ट आहे.
//!
//! नॉन-एमएसव्हीसी आणि नॉन-ओएसएक्स प्लॅटफॉर्मसाठी हे डीफॉल्ट प्रतीकात्मक धोरण आहे.लिबस्टडीमध्ये जरी हे ओएसएक्ससाठी डीफॉल्ट धोरण आहे.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // शक्य असल्यास एक्सबॉक्सचे नाव पसंत करा जे डीबगिनफोमधून येते आणि उदाहरणार्थ इनलाइन फ्रेमसाठी अधिक अचूक असू शकते उदाहरणार्थ.
                // ते अस्तित्वात नसले तरी `symname` मध्ये निर्दिष्ट केलेल्या प्रतीक सारणीच्या नावावर परत जा.
                //
                // लक्षात ठेवा कधीकधी `function` थोडीशी अचूक वाटू शकते, उदाहरणार्थ `std::panicking::try::do_call` एक्स एक्स 2 एक्स विस्तारित म्हणून सूचीबद्ध केलेले.
                //
                // हे का स्पष्ट आहे हे का नाही, परंतु एकूणच `function` नाव अधिक अचूक दिसते.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // आत्ता काही करु नकोस
}

/// `data` पॉईंटरचा प्रकार `syminfo_cb` मध्ये पास झाला
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // एकदा आम्ही निराकरण करण्यास प्रारंभ केल्यावर हे कॉलबॅक `backtrace_syminfo` वरुन सुरू झाला की आम्ही `backtrace_pcinfo` वर कॉल करण्यास पुढे जाऊ.
    // `backtrace_pcinfo` फंक्शन डीबग माहितीचा सल्ला घेईल आणि file/line माहिती तसेच इनलाइन केलेल्या फ्रेम पुनर्प्राप्त करण्यासारख्या गोष्टी करण्याचा प्रयत्न करेल.
    // लक्षात ठेवा डीबग माहिती नसल्यास `backtrace_pcinfo` अयशस्वी होऊ शकतो किंवा बरेच काही करू शकत नाही, म्हणून जर तसे झाले तर आम्ही `syminfo_cb` मधील किमान एका चिन्हासह कॉलबॅक कॉल केल्याची खात्री आहे.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// `data` पॉईंटरचा प्रकार `pcinfo_cb` मध्ये पास झाला
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Libbacktrace API राज्य तयार करण्यास समर्थन देते, परंतु ते राज्य नष्ट करण्यास समर्थन देत नाही.
// मी वैयक्तिकरित्या याचा अर्थ असा होतो की एखादे राज्य तयार करायचे आहे आणि नंतर कायमचे जगणे आहे.
//
// मला हे at_exit() हँडलर नोंदणी करण्यास आवडेल जे हे राज्य साफ करते, परंतु लिबब्रेट्रस तसे करण्यास कोणताही मार्ग प्रदान करत नाही.
//
// या अडचणींसह, या फंक्शनमध्ये स्टॅटिकली कॅशेड स्टेट असते जे प्रथमच विनंती केल्यावर मोजले जाते.
//
// लक्षात ठेवा की सर्व काही ट्रॅक करणे अनुक्रमे होते (एक जागतिक लॉक).
//
// लक्षात घ्या की येथे सिंक्रोनाइझेशनची कमतरता `resolve` बाह्यरित्या सिंक्रोनाइझ केलेल्या आवश्यकतेमुळे आहे.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // लिबब्रेट्रेसच्या थ्रेडसेफ क्षमतांचा वापर करु नका कारण आम्ही त्याला नेहमी समक्रमित फॅशनमध्ये कॉल करतो.
        //
        0,
        error_cb,
        ptr::null_mut(), // अतिरिक्त डेटा नाही
    );

    return STATE;

    // लक्षात ठेवा लिबब्रेट्रेसला ऑपरेट करण्यासाठी सध्याच्या एक्झिक्युटेबलसाठी DWARF डीबग माहिती शोधणे आवश्यक आहे.हे सहसा असंख्य यंत्रणेद्वारे करते परंतु हे मर्यादित नाही:
    //
    // * /proc/self/exe समर्थित प्लॅटफॉर्मवर
    // * राज्य तयार करताना फाईलनाव स्पष्टपणे पास केले
    //
    // लिबब्रेट्रेस लायब्ररी सी कोडची एक मोठी वॅड आहे.याचा अर्थ असा आहे की त्यात मेमरी सेफ्टी असुरक्षा आहेत, विशेषत: विकृत डीबगिनफो हाताळताना.
    // लिब्स्टडी ऐतिहासिकदृष्ट्या यापैकी बरेच काही आहे.
    //
    // जर /proc/self/exe वापरला असेल तर आम्ही सामान्यतः याकडे दुर्लक्ष करू शकतो कारण आपण असे गृहीत धरते की लिबब्रेट्रेस हे एक्स ०१ एक्स आहे आणि अन्यथा एक्स ०२ एक्स ड्वार्फ डीबग माहितीसह विचित्र गोष्टी करत नाहीत.
    //
    //
    // आम्ही जर एखाद्या फाईलनावमध्ये पास केले तर ते नंतर काही प्लॅटफॉर्मवर (बीएसडी सारख्या) शक्य आहे जेथे दुर्भावनापूर्ण अभिनेता त्या जागी अनियंत्रित फाइल ठेवू शकतो.
    // याचा अर्थ असा की जर आम्ही एखाद्या फाईलनावाबद्दल लिबब्रेट्रेसला सांगितले तर कदाचित ते अनियंत्रित फाइल वापरत असेल, ज्यामुळे कदाचित सेगफॉल्ट्स होऊ शकतात.
    // आम्ही लिबब्रेट्रेसला काहीही न सांगल्यास ते /proc/self/exe सारख्या मार्गांना समर्थन देत नसलेल्या प्लॅटफॉर्मवर काहीही करणार नाही!
    //
    // फाईलनावात *पास न* करण्यासाठी आपण जितके शक्य प्रयत्न केले तितके दिले, परंतु आपण अशा प्लॅटफॉर्मवर असले पाहिजे जे /proc/self/exe अजिबात समर्थन देत नाहीत.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // लक्षात घ्या की आम्ही आदर्शपणे `std::env::current_exe` वापरू इच्छितो, परंतु येथे आपल्याला `std` आवश्यक नाही.
            //
            // सध्याचा कार्यवाहीयोग्य पथ स्थिर क्षेत्रात लोड करण्यासाठी `_NSGetExecutablePath` वापरा (जे खूपच लहान असेल तर ते सोडून द्या).
            //
            //
            // लक्षात घ्या की आम्ही भ्रष्टाचारी एक्जीक्यूटेबलवर मरणार नाही यासाठी लिबब्रेट्रेसवर गंभीरपणे विश्वास ठेवत आहोत, परंतु ते नक्कीच ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows फायली उघडण्याचा एक मोड आहे जिथे ती उघडल्यानंतर ती हटविली जाऊ शकत नाही.
            // आम्हाला येथे जे हवे आहे तेच सर्वसाधारणपणे आहे कारण आम्ही खात्री करुन घेऊ इच्छितो की लिबब्रेट्रेसला हस्तांतरित केल्यावर आमची कार्यवाही आपल्यापासून बदलत नाही, आशेने लिबब्रेट्रेसमध्ये अनियंत्रित डेटामध्ये प्रवेश करण्याची क्षमता कमी केली जाईल (जे कदाचित चुकीचे असू शकते).
            //
            //
            // आमच्या स्वत: च्या प्रतिमेवर एक प्रकारचे लॉक मिळविण्याचा प्रयत्न करण्यासाठी आम्ही येथे थोडासा नृत्य करतो:
            //
            // * सद्य प्रक्रियेस हँडल मिळवा, त्याचे फाइलनाव लोड करा.
            // * त्या ध्वजांकनासह त्या फाईलनाव योग्य फाईल उघडा.
            // * सद्य प्रक्रियेचे फाइलनाव रीलोड करा, ते एकसारखेच आहे याची खात्री करुन
            //
            // जर ते सिद्धांत सिद्ध झाले तर आम्ही खरोखरच आमच्या प्रक्रियेची फाईल उघडली आहे आणि ती बदलणार नाही याची आम्हाला हमी मिळाली आहे.एफडब्ल्यूआयडब्ल्यूडब्ल्यूडब्ल्यूडब्ल्यूडब्ल्यूडब्ल्यूडब्ल्यूडब्ल्यूडब्ल्यूडब्ल्यूडीची ऐतिहासिकदृष्ट्या कॉपी केली गेली आहे, म्हणून जे घडत आहे त्याबद्दल हे माझे उत्तम वर्णन आहे.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // हे स्थिर स्मृतीत जगते जेणेकरून आम्ही ते परत करू शकू ..
                static mut BUF: [i8; N] = [0; N];
                // ... आणि हे तात्पुरते असल्यामुळे हे स्टॅकवर आहे
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // येथे हेतुपुरस्सर `handle` गळती होईल कारण ते उघडल्यामुळे या फाईलच्या नावावरील आपले लॉक जतन केले जावे.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // आम्हाला एक स्लाइस परत द्यायची आहे जी शून्य-संपुष्टात आली आहे, म्हणून जर सर्व काही भरलेले असेल आणि ते एकूण लांबीच्या बरोबरीचे असेल तर ते अपयशी ठरते.
                //
                //
                // अन्यथा यश परत देताना स्लाइसमध्ये शून्य बाइट समाविष्ट असल्याचे सुनिश्चित करा.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // बॅकट्रेस त्रुटी सध्या गालिच्याखाली वाहत आहेत
    let state = init_state();
    if state.is_null() {
        return;
    }

    // `backtrace_syminfo` एपीआय वर कॉल करा ज्याने (कोड वाचून) `syminfo_cb` वर एकदाच कॉल करावा (किंवा संभाव्यत: त्रुटीमुळे अयशस्वी व्हा).
    // आम्ही नंतर एक्स00 एक्स मध्ये अधिक हाताळतो.
    //
    // लक्षात ठेवा आम्ही हे करत आहोत कारण `syminfo` प्रतीक सारणीचा सल्ला घेईल, बायनरीमध्ये डीबग माहिती नसतानाही चिन्हांची नावे शोधेल.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}