// आत्ता फक्त Linux वर वापरलेले आहे, म्हणून इतरत्र डेड कोडला अनुमती द्या
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// बाइट बफरसाठी एक सोपा रिंगण वाटपकर्ता.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// निर्दिष्ट आकाराचे बफर वाटप करते आणि त्यास बदलण्याचा संदर्भ देतो.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // सुरक्षा: हे एकमेव कार्य आहे जे कधीही बदल घडवून आणू शकते
        // `self.buffers` चा संदर्भ.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // सुरक्षितताः आम्ही कधीही `self.buffers` मधील घटक काढत नाही, म्हणून संदर्भ
        // कोणत्याही बफरच्या डेटावर `self` करेपर्यंत लाइव्ह राहील.
        &mut buffers[i]
    }
}