//! crates.io वर `gimli` crate वापरण्याच्या चिन्हासाठी समर्थन
//!
//! हे Rust साठी डीफॉल्ट प्रतीक अंमलबजावणी आहे.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'स्टॅफिक रेफरेन्शिअल स्ट्रक्चर्स' चे समर्थन नसल्यामुळे स्थिर जीवन जगणे खोटे आहे.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // 'स्थिर जीवनकाळात रूपांतरित करा कारण प्रतीकांनी केवळ `map` आणि `stash` घेतले पाहिजे आणि आम्ही त्या खाली जतन करीत आहोत.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // एक्स00 एक्स वर नेटिव्ह लायब्ररी लोड करण्यासाठी, येथे असलेल्या विविध धोरणांसाठी एक्स ०१ एक्स वर काही चर्चा पहा.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW लायब्ररी सध्या ASLR (rust-lang/rust#16514) चे समर्थन करत नाहीत, परंतु DLL अद्याप अ‍ॅड्रेस स्पेसमध्ये पुन्हा बदलली जाऊ शकतात.
            // असे दिसते आहे की डीबग माहितीमधील पत्ते सर्व जण जसे आहेत की ही लायब्ररी त्याच्या "image base" वर लोड केली गेली आहे, जे त्याच्या सीओएफएफ फाइल शीर्षलेखातील एक फील्ड आहे.
            // हे डीबगइन्फो असे दिसते जेणेकरून आम्ही चिन्ह सारणीचे विश्लेषण करतो आणि पत्ते संग्रहित करतो की जणू "image base" वर लायब्ररी लोड केली गेली आहे.
            //
            // तथापि, लायब्ररी "image base" वर लोड केले जाऊ शकत नाही.
            // (बहुधा तिथे काहीतरी लोड केले जाऊ शकते?) येथेच एक्स 100 एक्स फील्ड खेळात येईल आणि आम्हाला येथे एक्स ० ए एक्सचे मूल्य शोधण्याची आवश्यकता आहे.दुर्दैवाने जरी हे लोड केलेल्या मॉड्यूलमधून कसे मिळवावे हे स्पष्ट नाही.
            // आमच्याकडे जे आहे ते आहे, वास्तविक लोड पत्ता (`modBaseAddr`).
            //
            // आत्तासाठी एक कॉपी-आऊट म्हणून आम्ही फाईल एमएमपी करतो, फाईल शीर्षलेख माहिती वाचतो, त्यानंतर एमएमएपी ड्रॉप करतो.हे निरुपयोगी आहे कारण आम्ही नंतर कदाचित एमएमएपी पुन्हा उघडू, परंतु हे आता पुरेसे कार्य केले पाहिजे.
            //
            // एकदा आपल्याकडे `image_base` (इच्छित लोड स्थान) आणि `base_addr` (वास्तविक लोड स्थान) असल्यास आम्ही `bias` (वास्तविक आणि इच्छित दरम्यान फरक) भरू शकतो आणि नंतर प्रत्येक विभागाचा निर्दिष्ट पत्ता `image_base` आहे कारण फाइल म्हणतो.
            //
            //
            // आता असे दिसते आहे की ELF/MachO विरुध्द आम्ही संपूर्ण आकारात `modBaseSize` वापरुन प्रत्येक ग्रंथालयाच्या एका भागासह करू शकतो.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS मॅच-ओ फाइल स्वरूपन वापरते आणि अनुप्रयोगाचा भाग असलेल्या मूळ लायब्ररीची सूची लोड करण्यासाठी डीवायएलडी-विशिष्ट एपीआय वापरते.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // या लायब्ररीचे नाव मिळवा जे हे देखील कोठे लोड करावे या मार्गाशी संबंधित आहे.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // या लायब्ररीचे प्रतिमा शीर्षलेख लोड करा आणि सर्व लोड आदेशांचे विश्लेषण करण्यासाठी `object` वर प्रतिनिधीत्व करा जेणेकरुन आम्ही येथे सर्व विभाग शोधू शकू.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // विभागांना शोधून काढा आणि आम्हाला आढळणा se्या विभागांसाठी ज्ञात प्रदेश नोंदवा.
            // नंतर प्रक्रियेसाठी मजकूर विभागांविषयी माहिती नोंदवा, खाली टिप्पण्या पहा.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // या लायब्ररीसाठी एक्स 100 एक्स निश्चित करा जे मेमरी ऑब्जेक्ट्स कुठे लोड केले आहेत हे शोधण्यासाठी आम्ही वापरत असलेल्या बायसचा अंत होतो.
            // हे जरी थोडेसे विचित्र गणना आहे आणि वन्य जीवनात काही गोष्टी करण्याचा प्रयत्न करीत आहे आणि काय चिकटते आहे याचा परिणाम आहे.
            //
            // सर्वसाधारण कल्पना अशी आहे की `bias` प्लस सेगमेंटचे X01 एक्स असे होणार आहे जेथे प्रत्यक्ष पत्ता स्पेसमध्ये विभाग राहतो.
            // आम्ही यावर अवलंबून असलेली दुसरी गोष्ट ही आहे की खरा पत्ता वजा `bias` हे प्रतीक सारणी आणि डीबगिनफोमध्ये शोधण्यासाठी अनुक्रमणिका आहे.
            //
            // हे सिद्ध होते की सिस्टम लोड केलेल्या लायब्ररींसाठी ही गणना चुकीची आहे.नेटिव्ह एक्झिक्युटेबलसाठी, तथापि, ते योग्य दिसत आहे.
            // एलएलडीबीच्या स्त्रोतांकडून काही तर्क काढून टाकणे यात नॉनझेरो आकारासह फाइल ऑफसेट 0 मधून लोड केलेल्या प्रथम एक्स 100 एक्स विभागासाठी काही खास केसिंग आहे.
            // कोणत्याही कारणास्तव हे अस्तित्त्वात असल्यास याचा अर्थ असा आहे की प्रतीक सारणी केवळ लायब्ररीच्या vmaddr स्लाइडशी संबंधित आहे.
            // जर ते *उपस्थित नसेल* तर प्रतीक सारणी व्माडड्रिड स्लाइड व सेगमेंटच्या नमूद पत्त्याशी संबंधित असेल.
            //
            // ही परिस्थिती हाताळण्यासाठी जर आपल्याला फाइल ऑफसेट शून्यावर * एखादा मजकूर विभाग सापडला नाही तर आम्ही प्रथम मजकूर विभागांच्या नमूद पत्त्यानुसार बायस वाढवितो आणि त्यानुसार सर्व नमूद केलेले पत्तेही कमी करतो.
            //
            // अशा प्रकारे चिन्ह सारणी नेहमीच लायब्ररीच्या बायसच्या रकमेशी संबंधित दिसते.
            // प्रतीक सारणीद्वारे चिन्हित करण्यासाठी याचे योग्य परिणाम असल्याचे दिसून येत आहे.
            //
            // प्रामाणिकपणे मला हे पूर्णपणे बरोबर नाही की हे बरोबर आहे की नाही असे आहे किंवा असे काहीतरी आहे जे हे कसे करावे हे दर्शविते.
            // सध्या तरी हे पुरेसे (?) चांगले कार्य करत असल्याचे दिसत आहे आणि आवश्यक असल्यास आम्ही वेळोवेळी हे चिमटायला सक्षम असले पाहिजे.
            //
            // काही अधिक माहितीसाठी #318 पहा
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // इतर Unix (उदा
        // लिनक्स) प्लॅटफॉर्म एक ऑब्जेक्ट फाइल स्वरूप म्हणून ELF वापरतात आणि सामान्यत: नेटिव्ह लायब्ररी लोड करण्यासाठी `dl_iterate_phdr` नावाचे API लागू करतात.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` वैध पॉईंटर्स असावेत.
        // `vec` `std::Vec` चे वैध पॉईंटर असावे.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 मूळपणे डीबग माहितीचे समर्थन करत नाही, परंतु बिल्ड सिस्टम डीबग माहिती `romfs:/debug_info.elf` मार्गावर ठेवेल.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // इतर सर्व गोष्टींनी ईएलएफ वापरला पाहिजे, परंतु मूळ ग्रंथालये कशी लोड करावी हे माहित नाही.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// लोड केलेल्या सर्व ज्ञात सामायिक लायब्ररी.
    libraries: Vec<Library>,

    /// आम्ही पार्स केलेली बटू माहिती जिथे ठेवतो तिथे मॅपिंग कॅशे.
    ///
    /// या यादीमध्ये त्याच्या संपूर्ण आयुष्यासाठी एक निश्चित क्षमता आहे जी कधीही वाढत नाही.
    /// प्रत्येक जोडीचा `usize` घटक वरील `libraries` मध्ये अनुक्रमणिका आहे जिथे `usize::max_value()` वर्तमान कार्यवाहीचे प्रतिनिधित्व करते.
    ///
    /// `Mapping` परसेड बौने माहितीशी संबंधित आहे.
    ///
    /// लक्षात घ्या की ही मुळात एक एलआरयू कॅशे आहे आणि आम्ही पत्त्याचे प्रतीक म्हणून आम्ही इकडे वस्तू हलवत आहोत.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// या लायब्ररीचे विभाग मेमरीमध्ये लोड केले आहेत आणि ते कोठे लोड केले आहे.
    segments: Vec<LibrarySegment>,
    /// या लायब्ररीचा एक्स00 एक्स, सामान्यत: जिथे तो मेमरीमध्ये लोड केलेला असतो.
    /// विभागामध्ये लोड केलेला वास्तविक व्हर्च्युअल मेमरी पत्ता मिळविण्यासाठी प्रत्येक विभागाच्या नमूद पत्त्यावर हे मूल्य जोडले जाते.
    /// याव्यतिरिक्त हा पूर्वग्रह वास्तविक आभासी मेमरी पत्त्यांमधून अनुक्रमणिका डीबगइन्फो आणि प्रतीक सारणीमध्ये वजा केला जातो.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// ऑब्जेक्ट फाइलमध्ये या विभागाचा नमूद केलेला पत्ता.
    /// हे विभाग जेथे लोड केले गेले आहे असे नाही, परंतु हा पत्ता आणि त्यासह ग्रंथालयाचा एक्स 100 एक्स आहे जेथे तो सापडला आहे.
    ///
    stated_virtual_memory_address: usize,
    /// मेमरी मधील ths सेगमेंटचा आकार.
    len: usize,
}

// असुरक्षित कारण यासाठी बाह्य समक्रमित करणे आवश्यक आहे
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // असुरक्षित कारण यासाठी बाह्य समक्रमित करणे आवश्यक आहे
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // डीबग माहिती मॅपिंगसाठी खूप लहान, अगदी सोपी एलआरयू कॅशे.
        //
        // हिट रेट खूप जास्त असावा, कारण ठराविक स्टॅक बर्‍याच सामायिक लायब्ररीत नाही.
        //
        // एक्स 100 एक्स रचना तयार करणे खूपच महाग आहे.
        // त्यानंतरच्या `locate` क्वेरींद्वारे त्याची किंमत कमी करणे अपेक्षित आहे, जे चांगले वेग मिळविण्यासाठी `addr2line: : संदर्भ तयार करताना बांधलेल्या स्ट्रक्चर्सचा लाभ घेतात.
        //
        // आमच्याकडे ही कॅशे नसल्यास, ते orम्पोटायझेशन कधीही होणार नाही आणि बॅकट्रेसचे प्रतीक ssssllllooooowwww असेल.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // प्रथम, या `lib` मध्ये `addr` (हँडलिंग रीलोकेशन) असलेले कोणतेही विभाग असल्यास याची चाचणी घ्या.जर ही तपासणी पास झाली तर आम्ही खाली सुरू ठेवू आणि पत्त्याचे वास्तविक भाषांतर करू.
                //
                // लक्षात घ्या की ओव्हरफ्लो तपासणी टाळण्यासाठी आम्ही येथे `wrapping_add` वापरत आहोत.हे जंगलात पाहिले आहे की एसव्हीएमए + बायस कंप्यूटेशन ओव्हरफ्लो झाले आहे.
                // हे घडण्यासारखे काही विचित्र वाटते परंतु तसे करण्याऐवजी आम्ही या क्षेत्राकडे दुर्लक्ष केल्याशिवाय आपण याव्यतिरिक्त इतकी मोठी रक्कमही घेऊ शकत नाही की ते कदाचित अवकाशात लक्ष वेधतात.
                //
                // हे मुळात rust-lang/backtrace-rs#329 मध्ये आले.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // आता आम्हाला माहित आहे की `lib` मध्ये `addr` आहे, आम्ही सांगितलेला व्हायरल मेमरी पत्ता शोधण्यासाठी पूर्वाग्रह सह ऑफसेट करू शकतो.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // इन्व्हिएंट: हे सशर्त लवकर परत न येता पूर्ण झाल्यानंतर
        // चुकून या मार्गासाठी कॅशे प्रविष्टी अनुक्रमणिका 0 वर आहे.

        if let Some(idx) = idx {
            // जेव्हा मॅपिंग आधीपासूनच कॅशेमध्ये असेल तेव्हा त्यास पुढच्या भागावर हलवा.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // जेव्हा मॅपिंग कॅशेमध्ये नसते, तेव्हा एक नवीन मॅपिंग तयार करा, त्यास कॅशेच्या पुढील भागामध्ये घाला आणि आवश्यक असल्यास सर्वात जुनी कॅशे प्रविष्‍टी काढा.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // `'static` आजीवन लीक करू नका, ते फक्त स्वतःच असल्याचे सुनिश्चित करा
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // आपल्याकडे दुर्दैवाने येथे आवश्यक असल्यामुळे `sym` चे जीवनकाळ वाढवा, परंतु हा कधीही एक संदर्भ म्हणून बाहेर जात नाही म्हणून या चौकटीपलीकडे कोणत्याही प्रकारचा संदर्भ कायम राहू नये.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // शेवटी, कॅश्ड मॅपिंग मिळवा किंवा या फाईलसाठी एक नवीन मॅपिंग तयार करा आणि या पत्त्यासाठी file/line/name शोधण्यासाठी DWARF माहितीचे मूल्यांकन करा.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// आम्ही या चिन्हासाठी फ्रेम माहिती शोधण्यात सक्षम होतो आणि `addr2line` च्या फ्रेममध्ये अंतर्गत सर्व विचित्र तपशील आहेत.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// डीबग माहिती शोधू शकलो नाही, परंतु आम्हाला ती एल्फि एक्जिक्युटेबलच्या प्रतीक सारणीमध्ये सापडली.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}