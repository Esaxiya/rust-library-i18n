use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr एक कॉलबॅक घेते ज्यास प्रक्रियेत दुवा साधलेल्या प्रत्येक DSO साठी dl_phdr_info पॉईंटर प्राप्त होईल.
    // dl_iterate_phdr हे देखील सुनिश्चित करते की डायनेमिक लिंकर पुनरावृत्तीच्या सुरूवातीस प्रारंभ होण्यापासून लॉक केलेले आहे.
    // जर कॉलबॅकने शून्य मूल्य मिळवले तर पुनरावृत्ती लवकर संपुष्टात येते.
    // 'data' प्रत्येक कॉलवरील कॉलबॅकवर तिसरा वितर्क म्हणून पास केला जाईल.
    // 'size' dl_phdr_info चा आकार देते.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// आम्हाला बिल्ड आयडी आणि काही मूलभूत प्रोग्राम शीर्षलेख डेटा विश्लेषित करण्याची आवश्यकता आहे ज्याचा अर्थ असा आहे की आम्हाला देखील ईएलएफ स्पेकमधून थोडी सामग्री आवश्यक आहे.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// आता आपल्याला fssia च्या सध्याच्या डायनॅमिक लिंकरद्वारे वापरलेल्या dl_phdr_info टाईपची बिट बिट बिट बनवावी लागेल.
// क्रोमियमकडे ही एबीआय सीमा तसेच क्रॅशपॅड देखील आहे.
// अखेरीस आम्ही ही प्रकरणे एल्फ-सर्च वापरण्यासाठी हलवू इच्छितो परंतु आम्हाला ती एसडीकेमध्ये प्रदान करण्याची आवश्यकता आहे आणि ती अद्याप झालेली नाही.
//
// अशाप्रकारे आम्ही (आणि ते) ही पद्धत वापरण्यात अडकून पडलो आहोत ज्यात फ्यूशिया लिबिकसह घट्ट जोड आहे.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // आमच्याकडे e_phoff आणि e_phnum वैध आहेत की नाही हे तपासण्याचे कोणतेही मार्ग नाही.
    // libc ने आमच्यासाठी हे सुनिश्चित केले पाहिजे जेणेकरून येथे एक स्लाईस तयार करणे सुरक्षित आहे.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// लक्ष्य आर्किटेक्चरच्या अंतर्भागामध्ये एल्फ_Phdr एक 64-बिट ईएलएफ प्रोग्राम शीर्षलेख दर्शवते.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// पीएचडीआर एक वैध ईएलएफ प्रोग्राम हेडर आणि त्यातील सामग्रीचे प्रतिनिधित्व करते.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // आमच्याकडे p_addr किंवा p_memsz वैध आहेत की नाही हे तपासण्याचा कोणताही मार्ग नाही.
    // फुशियाच्या लिबसीकांनी प्रथम नोट्सचे विश्लेषण केले आहे जेणेकरुन हे शीर्षलेख वैध असणे आवश्यक आहे.
    //
    // टीपआयटरला मूलभूत डेटा वैध असणे आवश्यक नाही परंतु त्यासाठी मर्यादा वैध असणे आवश्यक नाही.
    // आमचा विश्वास आहे की इथे आमच्यासाठी हीच परिस्थिती आहे.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// बिल्ड आयडीसाठीचा नोट प्रकार.
const NT_GNU_BUILD_ID: u32 = 3;

// एल्फ_एनएचडीआर लक्ष्याच्या अंत्यत एक ELF टीप शीर्षलेख दर्शवते.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// टीप एक ELF टीप दर्शवते (शीर्षलेख + सामग्री)
// हे नाव u8 स्लाइस म्हणून सोडले जाते कारण ते नेहमीच निरस्त होत नाही आणि rust हे इतके सोपे करते की बाइट्स एकतर जुळतात हे तपासणे सोपे करते.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// नोटइटर आपल्याला टिप विभागावर सुरक्षितपणे पुनरावृत्ती करू देते.
// एखादी त्रुटी उद्भवताच किंवा अधिक नोट्स नसताच ती समाप्त होते.
// आपण अवैध डेटावर पुनरावृत्ती केल्यास नोटा सापडल्या नसल्या तरी कार्य करेल.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // पॉईंटर आणि आकार दिलेला बाइट ची एक वैध श्रेणी दर्शवितो जे कार्य वाचले जाऊ शकते.
    // या बाइटची सामग्री काहीही असू शकते परंतु हे सुरक्षित होण्यासाठी श्रेणी वैध असणे आवश्यक आहे.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to 'x' ला 'to'-बाइट संरेखन असे संरेखित करते की 'to' 2 ची शक्ती आहे.
// हे सी/सी ++ ईएलएफ पार्सिंग कोडमधील मानक पॅटर्नचे अनुसरण करते जेथे (x + to, 1) आणि -to वापरले जाते.
// Rust आपल्याला वापरण्यास नाकारू देत नाही म्हणून मी वापरतो
// ते पुन्हा तयार करण्यासाठी 2 चे पूरक रूपांतरण.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 स्लाइसमधून (उपस्थिती असल्यास) संख्या बाइटचे सेवन करते आणि त्या व्यतिरिक्त अंतिम स्लाइस योग्य प्रकारे संरेखित केली असल्याचे सुनिश्चित करते.
// एकतर विनंती केलेल्या बाईटची संख्या खूप मोठी असेल किंवा पुरेशी बाइट्स अस्तित्त्वात नसल्यामुळे स्लाइस नंतर पुन्हा ओळखता येणार नाही, काहीही परत केले जात नाही आणि स्लाईस सुधारित केली जात नाही.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// या फंक्शनमध्ये कोणतेही वास्तविक इनव्हिएंट नसलेले कॉलर कामगिरीसाठी (आणि काही आर्किटेक्चर अचूकतेवर) जुळले असावे याशिवाय कॉलरने इतरांचे समर्थन केले पाहिजे.
// Elf_Nhdr फील्ड मधील मूल्ये मूर्खपणाची असू शकतात परंतु हे कार्य अशा कोणत्याही गोष्टीची खात्री देत नाही.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // जोपर्यंत तेथे पुरेशी जागा आहे तोपर्यंत हे सुरक्षित आहे आणि आम्ही फक्त पुष्टी केली की वरील स्टेटमेंट स्टेटमेंटमध्ये हे असुरक्षित असू नये.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // लक्षात ठेवा की sice_of: :<Elf_Nhdr>() नेहमी 4-बाइट संरेखित असते.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // आम्ही शेवटपर्यंत पोहोचलो आहोत का ते तपासा.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // आम्ही एनएचडीआर ट्रान्समिट करतो परंतु परिणामी स्ट्रक्चरचा आम्ही काळजीपूर्वक विचार करतो.
        // आम्हाला नावे किंवा डेसेक्सचा विश्वास नाही आणि आम्ही या प्रकारावर आधारित असुरक्षित निर्णय घेत नाही.
        //
        // म्हणूनच जरी आम्ही संपूर्ण कचरा बाहेर काढला तरीही आपण सुरक्षित असले पाहिजे.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// विभाग कार्यवाहीयोग्य असल्याचे दर्शवितो.
const PERM_X: u32 = 0b00000001;
/// विभाग लिहिण्यायोग्य असल्याचे दर्शवितो.
const PERM_W: u32 = 0b00000010;
/// विभाग वाचनीय आहे असे दर्शवितो.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// रनटाइमवेळी ईएलएफ विभागाचे प्रतिनिधित्व करते.
struct Segment {
    /// या विभागाच्या सामग्रीचा रनटाइम व्हर्च्युअल पत्ता देते.
    addr: usize,
    /// या विभागाच्या सामग्रीचा मेमरी आकार देते.
    size: usize,
    /// या विभागाचा मॉड्यूल व्हर्च्युअल पत्ता ईएलएफ फाईलसह देतो.
    mod_rel_addr: usize,
    /// ईएलएफ फाइलमध्ये आढळलेल्या परवानग्या देते.
    /// या परवानग्या रनटाइम वर उपस्थित परवानग्या आवश्यक नसतात.
    flags: Perm,
}

/// डीएसओकडून विभागांवर एक पुनरावृत्ती करू देते.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// ईएलएफ डीएसओ (डायनॅमिक शेअर्ड ऑब्जेक्ट) चे प्रतिनिधित्व करते.
/// हा प्रकार स्वतःची प्रत बनविण्याऐवजी प्रत्यक्ष डीएसओमध्ये साठलेल्या डेटाचा संदर्भ देतो.
struct Dso<'a> {
    /// नाव रिक्त असले तरीही डायनॅमिक लिंकर नेहमी आम्हाला नाव देते.
    /// मुख्य कार्यवाहीच्या बाबतीत हे नाव रिक्त असेल.
    /// सामायिक ऑब्जेक्टच्या बाबतीत ते सोनम असेल (पहा DT_SONAME).
    name: &'a str,
    /// फुशिया वर अक्षरशः सर्व बायनरीजमध्ये बिल्ड आयडी असतात परंतु ही कठोर आवश्यकता नाही.
    /// डीएसओची माहिती नंतर ईएलएफ फाईलशी जुळवण्याचा कोणताही मार्ग नाही नंतर जर बिल्ड_आयडी नसेल तर आम्हाला प्रत्येक डीएसओकडे असणे आवश्यक आहे.
    ///
    /// डीएसओने बिल्ड_आयडीशिवाय दुर्लक्ष केले आहे.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// या डीएसओ मधील सेगमेंट्स दरम्यान एक इटरेटर परत करते.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// प्रत्येक डीएसओबद्दल माहितीचे विश्लेषण करतेवेळी उद्भवलेल्या या त्रुटी एन्कोड करतात.
///
enum Error {
    /// नेम एरर म्हणजे सी शैलीची स्ट्रिंग rust स्ट्रिंगमध्ये रूपांतरित करताना त्रुटी आली.
    ///
    NameError(core::str::Utf8Error),
    /// बिल्ड आयरर म्हणजे आम्हाला बिल्ड आयडी सापडला नाही.
    /// हे एकतर डीएसओकडे बिल्ड आयडी नसलेले किंवा बिल्ड आयडी असलेले विभाग खराब झालेला असू शकते.
    ///
    BuildIDError,
}

/// डायनॅमिक लिंकरद्वारे प्रक्रियेमध्ये दुवा साधलेल्या प्रत्येक डीएसओसाठी 'dso' किंवा 'error' एकतर कॉल करा.
///
///
/// # Arguments
///
/// * `visitor` - एक डीएसओ प्रिंटर ज्यास फोरॅच डीएसओ नावाची खाण्याची पद्धत असेल.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr हे सुनिश्चित करते की info.name वैध स्थान दर्शवेल.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// हे कार्य डीएसओमध्ये समाविष्ट असलेल्या सर्व माहितीसाठी फुसिया सिंबॅलाइझर मार्कअप प्रिंट करते.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}