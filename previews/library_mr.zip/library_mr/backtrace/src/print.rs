#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// बॅकट्रेससाठी एक स्वरूपन.
///
/// हा प्रकार बॅकट्रॅस कुठून आला याची पर्वा न करता बॅकट्रेस मुद्रित करण्यासाठी केला जाऊ शकतो.
/// आपल्याकडे `Backtrace` प्रकार असल्यास त्याची `Debug` अंमलबजावणी आधीपासून हे मुद्रण स्वरूप वापरते.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// आम्ही मुद्रित करू शकणार्‍या मुद्रणाच्या शैली
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// आदर्शपणे केवळ संबंधित माहिती असलेल्या टेरर बॅकट्रेसची छापा
    Short,
    /// बॅकट्रेस मुद्रित करते ज्यात सर्व संभाव्य माहिती असते
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// नवीन `BacktraceFmt` तयार करा जे प्रदान केलेल्या `fmt` वर आउटपुट लिहितील.
    ///
    /// एक्स00 एक्स युक्तिवाद ज्या शैलीमध्ये बॅकट्रेस मुद्रित केला आहे त्यावर नियंत्रण ठेवेल आणि `print_path` आर्ग्युमेंट फाइलनावेचे `BytesOrWideString` घटना मुद्रित करण्यासाठी वापरले जाईल.
    /// हा प्रकार स्वतः फाइलनावेचे कोणतेही मुद्रण करीत नाही, परंतु हे कॉलबॅक तसे करणे आवश्यक आहे.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// बॅकट्रेस मुद्रित करण्याच्या पूर्वसूचना छापते.
    ///
    /// बॅकट्रेससाठी नंतर पूर्ण प्रतीकित होण्यासाठी काही प्लॅटफॉर्मवर हे आवश्यक आहे आणि अन्यथा `BacktraceFmt` तयार केल्यानंतर आपण कॉल केलेली ही पहिलीच पद्धत असावी.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// बॅकट्रेस आउटपुटमध्ये एक फ्रेम जोडते.
    ///
    /// हे कमिट `BacktraceFrameFmt` चे RAII प्रसंग परत करते जे प्रत्यक्षात फ्रेम मुद्रित करण्यासाठी वापरले जाऊ शकते आणि विनाशावर ते फ्रेम प्रति वाढवते.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// बॅकट्रेस आउटपुट पूर्ण करते.
    ///
    /// हे सध्या एक निवड नाही परंतु बॅकट्रेस स्वरूपात झेडफ्यूचर0 झेड सुसंगततेसाठी जोडले गेले आहे.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // झेडफ्यूचर 0 झेड जोडण्यासाठी परवानगी देण्यासाठी सध्या या झेडहुक0झेडसह एक नाही
        Ok(())
    }
}

/// बॅकट्रेसच्या फक्त एका फ्रेमसाठी एक फॉर्मेटर.
///
/// हा प्रकार `BacktraceFmt::frame` फंक्शनद्वारे तयार केला गेला आहे.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// या फ्रेम स्वरूपासह एक `BacktraceFrame` मुद्रित करते.
    ///
    /// हे वारंवार `BacktraceFrame` मध्ये सर्व `BacktraceSymbol` घटना मुद्रित करेल.
    ///
    /// # आवश्यक वैशिष्ट्ये
    ///
    /// या कार्यासाठी `backtrace` crate चे `std` वैशिष्ट्य सक्षम केले जाणे आवश्यक आहे आणि `std` वैशिष्ट्य डीफॉल्टनुसार सक्षम केलेले आहे.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// `BacktraceFrame` मध्ये `BacktraceSymbol` मुद्रित करते.
    ///
    /// # आवश्यक वैशिष्ट्ये
    ///
    /// या कार्यासाठी `backtrace` crate चे `std` वैशिष्ट्य सक्षम केले जाणे आवश्यक आहे आणि `std` वैशिष्ट्य डीफॉल्टनुसार सक्षम केलेले आहे.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: हे काहीही चांगले नाही की आपण काहीही मुद्रित करत नाही
            // न-utf8 फाइलनावे सह.
            // कृतज्ञता म्हणजे जवळजवळ प्रत्येक गोष्ट utf8 आहे म्हणून हे खूप वाईट नसावे.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// या crate च्या कच्च्या कॉलबॅकमध्ये विशेषतः कच्चा ट्रेस केलेला `Frame` आणि `Symbol` मुद्रित करते.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// बॅकट्रेस आउटपुटमध्ये एक कच्चा फ्रेम जोडते.
    ///
    /// मागील पद्धतीप्रमाणे ही पद्धत कच्चे युक्तिवाद वेगवेगळ्या ठिकाणाहून स्रोत असल्याच्या कारणास्तव घेते.
    /// लक्षात घ्या की एका फ्रेमसाठी हे एकाधिक वेळा कॉल केले जाऊ शकते.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// कॉलम माहितीसह बॅकट्रेस आउटपुटमध्ये एक कच्चा फ्रेम जोडते.
    ///
    /// ही पद्धत, मागील प्रमाणे, कच्चे युक्तिवाद वेगवेगळ्या ठिकाणाहून स्रोत झाल्यास घेते.
    /// लक्षात घ्या की एका फ्रेमसाठी हे एकाधिक वेळा कॉल केले जाऊ शकते.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // फुशिया प्रक्रियेमध्ये प्रतीक दर्शविण्यास असमर्थ आहे म्हणून त्याचे एक विशेष स्वरूप आहे जे नंतर प्रतीक म्हणून वापरले जाऊ शकते.
        // येथे आमच्या स्वत: च्या स्वरूपात पत्ते मुद्रित करण्याऐवजी मुद्रित करा.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // "null" फ्रेम्स मुद्रित करण्याची आवश्यकता नाही, याचा मूळ म्हणजे सिस्टम बॅकट्रॅस सुपर सुपरपर्यंत ट्रेस करण्यास थोडा उत्सुक होता.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // एसजीएक्स एन्क्लेव्हमध्ये टीसीबी आकार कमी करण्यासाठी, आम्हाला प्रतीक निराकरण कार्यक्षमता लागू करण्याची इच्छा नाही.
        // त्याऐवजी, आम्ही येथे पत्त्याची ऑफसेट प्रिंट करू शकतो, जे नंतर कार्य सुधारण्यासाठी मॅप केले जाऊ शकते.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // फ्रेमची अनुक्रमणिका तसेच फ्रेमच्या वैकल्पिक सूचना सूचक मुद्रित करा.
        // आम्ही या फ्रेमच्या पहिल्या चिन्हाच्या पलीकडे असल्यास आम्ही फक्त योग्य पांढरे स्थान मुद्रित केले आहे.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // पुढे आम्ही पूर्ण बॅकट्रेस असल्यास अधिक माहितीसाठी वैकल्पिक स्वरूपन वापरून चिन्हाचे नाव लिहा.
        // येथे आम्ही चिन्ह नसतात ज्यांना नाव नाही,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // आणि शेवटचे, ते उपलब्ध असल्यास filename/line क्रमांक मुद्रित करा.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line प्रतीक नावाखाली रेषांवर छापलेले आहेत, म्हणून स्वत: ला उजवीकडे संरेखित करण्यासाठी काही योग्य व्हाइटस्पेस मुद्रित करा.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // फाइलनाव मुद्रित करण्यासाठी आमच्या अंतर्गत कॉलबॅकवर सोपवा आणि त्यानंतर लाइन नंबर मुद्रित करा.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // उपलब्ध असल्यास स्तंभ क्रमांक जोडा.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // आम्ही केवळ एका फ्रेमच्या पहिल्या चिन्हाबद्दल काळजी घेतो
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}