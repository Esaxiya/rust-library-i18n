//! Windows वर dbghelp बाइंडिंग व्यवस्थापित करण्यासाठी सहाय्य करणारे मॉड्यूल
//!
//! एक्स00 एक्सवरील बॅकट्रेस (कमीतकमी एमएसव्हीसीसाठी) एक्स01 एक्स आणि त्यात असलेल्या विविध कार्येद्वारे मोठ्या प्रमाणात समर्थित आहेत.
//! हे कार्ये सध्या `dbghelp.dll` शी स्थिरपणे जोडण्याऐवजी *डायनॅमिकली* लोड केल्या आहेत.
//! हे सध्या मानक लायब्ररीद्वारे केले गेले आहे (आणि तेथे सिद्धांतानुसार आवश्यक आहे), परंतु लायब्ररीची स्थिर dll अवलंबन कमी करण्यात मदत करण्याचा प्रयत्न केला जात आहे कारण बॅकट्रेसेस सामान्यत: बरेच पर्यायी असतात.
//!
//! असे म्हटले जात आहे की `dbghelp.dll` जवळजवळ नेहमीच Windows वर यशस्वीरित्या लोड होते.
//!
//! तरीसुद्धा लक्षात घ्या की आम्ही हे सर्व समर्थन गतिकरित्या लोड करीत असल्यामुळे आम्ही वास्तविकपणे एक्स00 एक्स मधील कच्च्या परिभाषा वापरू शकत नाही, परंतु त्याऐवजी कार्य फंक्शन पॉईंटर प्रकार स्वतः परिभाषित करणे आवश्यक आहे.
//! आम्हाला डुप्लीकेट विनापीच्या व्यवसायात खरोखर भाग घ्यायचा नाही, म्हणून आपल्याकडे झेड-कार्गो ० झेड एक्स एक्स एक्स एक्स वैशिष्ट्य आहे जे असे प्रतिपादन करते की सर्व बाईंडिंग्स विनापीमध्ये जुळतात आणि हे वैशिष्ट्य सीआय वर सक्षम केले आहे.
//!
//! शेवटी, आपण येथे लक्षात घ्याल की `dbghelp.dll` साठी dll कधीही लोड केले जात नाही आणि ते सध्या हेतूपूर्वक आहे.
//! विचारसरणी अशी आहे की आम्ही महागड्या loads/unloads टाळून त्यास जागतिक स्तरावर कॅशे करू आणि एपीआयच्या कॉल दरम्यान ते वापरू शकतो.
//! जर गळती शोधणार्‍यास किंवा असे काहीतरी असल्यास आपण तिथे पोहोचल्यावर पूल ओलांडू शकतो.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// एक्सपी एक्समध्ये एक्स एक्स एक्स आणि एक्स ० एक्स एक्स स्वतः विनेपीमध्ये उपस्थित नसलेले कार्य करा.
// अन्यथा हे फक्त तेव्हा वापरले जाते जेव्हा आम्ही विनापीविरूद्ध दोनदा प्रकार तपासत आहोत.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // अद्याप विनापीमध्ये परिभाषित केलेले नाही
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // हे विनापीमध्ये परिभाषित केले आहे, परंतु ते चुकीचे आहे (FIXME winapi-##768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // अद्याप विनापीमध्ये परिभाषित केलेले नाही
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// हे मॅक्रो `Dbghelp` स्ट्रक्चर परिभाषित करण्यासाठी वापरला जातो ज्यामध्ये अंतर्गतपणे आम्ही लोड करू शकणारे सर्व फंक्शन पॉईंटर असतात.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// `dbghelp.dll` साठी लोड केलेले डीएलएल
            dll: HMODULE,

            // आम्ही वापरू शकतो अशा प्रत्येक कार्यासाठी प्रत्येक फंक्शन पॉईंटर
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // सुरुवातीला आम्ही डीएलएल लोड केलेले नाही
            dll: 0 as *mut _,
            // आरंभिक सर्व कार्ये गतीशीलपणे लोड करणे आवश्यक आहे हे सांगण्यासाठी शून्यावर सेट केली आहे.
            //
            $($name: 0,)*
        };

        // प्रत्येक फंक्शन प्रकारासाठी सुविधा टाइपपेड.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// `dbghelp.dll` उघडण्याचे प्रयत्न.
            /// कार्य केले तर यश मिळवते किंवा `LoadLibraryW` अपयशी झाल्यास त्रुटी.
            ///
            /// लायब्ररी आधीपासून लोड केलेली असल्यास Panics.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // आम्हाला वापरू इच्छित असलेल्या प्रत्येक पद्धतीसाठी कार्य.
            // असे म्हटले जाते ते एकतर कॅश्ड फंक्शन पॉईंटर वाचेल किंवा लोड करेल आणि लोड केलेले मूल्य परत करेल.
            // यशस्वी होण्यासाठी भार निश्चित केले जातात.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Dbghelp कार्ये संदर्भात क्लीनअप लॉक वापरण्यासाठी सुविधा प्रॉक्सी.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// या crate वरून `dbghelp` API कार्ये प्रवेश करण्यासाठी आवश्यक सर्व समर्थनास प्रारंभ करा.
///
///
/// लक्षात ठेवा की हे कार्य **सेफ** आहे, अंतर्गत अंतर्गत त्याचे स्वतःचे सिंक्रोनाइझेशन आहे.
/// हे देखील लक्षात घ्या की या कार्यास निरंतर वारंवार कॉल करणे सुरक्षित आहे.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // आम्हाला प्रथम हे कार्य समक्रमित करणे आवश्यक आहे.हे इतर थ्रेडमधून एकाचवेळी किंवा एका धाग्यात वारंवार म्हणू शकते.
        // लक्षात घ्या की त्यापेक्षा हे अवघड आहे कारण आपण येथे काय वापरत आहोत, `dbghelp`,*देखील* या प्रक्रियेमध्ये इतर सर्व कॉलरसह `dbghelp` वर समक्रमित करणे आवश्यक आहे.
        //
        // सामान्यत: असे नाही की एकाच प्रक्रियेत `dbghelp` वर बरेच कॉल आहेत आणि आम्ही कदाचित सुरक्षितपणे असे गृहीत धरू शकतो की आपण त्यात प्रवेश करत आहोत.
        // तथापि, आम्हाला काळजी करण्याचा एक प्राथमिक अन्य वापरकर्ता आहे ज्याची आपण स्वतः विटंबना करतो परंतु मानक लायब्ररीत आहे.
        // Rust प्रमाणित लायब्ररी बॅकट्रेस समर्थनासाठी या crate वर अवलंबून आहे आणि हे crate देखील crates.io वर विद्यमान आहे.
        // याचा अर्थ असा की जर मानक ग्रंथालय झेडस्पॅनिक ० झेड बॅकट्रस मुद्रित करीत असेल तर ते झेडकेरेट0 झेड crates.io कडून येणा race्या शर्यतीस येऊ शकेल, ज्यामुळे सेगफॉल्ट्स होऊ शकतात.
        //
        // या समक्रमित समस्येचे निराकरण करण्यात आम्ही येथे विंडोज-विशिष्ट युक्ती नियुक्त करतो (हे सर्वकाही, सिंक्रोनाइझेशनबद्दल विंडोज-विशिष्ट प्रतिबंध) आहे.
        // हा कॉल संरक्षित करण्यासाठी आम्ही म्युटेक्स नावाचा एक सेशन-लोकल * तयार करतो.
        // येथे हेतू असा आहे की मानक लायब्ररी आणि या झेडक्रेट0 झेडला येथे संकालित करण्यासाठी झेडआरस्ट 0 झेड-स्तरीय एपीआय सामायिक करण्याची गरज नाही परंतु त्याऐवजी ते एकमेकांशी सिंक्रोनाइझ होत आहेत हे सुनिश्चित करण्यासाठी पडद्यामागून कार्य करू शकतात.
        //
        // अशा प्रकारे जेव्हा हे फंक्शन मानक लायब्ररीद्वारे किंवा crates.io द्वारे कॉल केले जाते तेव्हा आम्ही खात्रीपूर्वक खात्री बाळगू शकतो की समान म्युटेक्स अधिग्रहित केले गेले आहे.
        //
        // तर हे सर्व असे म्हणायचे आहे की आपण येथे करत असलेली पहिली गोष्ट आपण परमाणु पद्धतीने एक X01 एक्स तयार करतो जी एक्स 00 एक्स वर नामित म्युटेक्स आहे.
        // आम्ही हे कार्य विशेषत: सामायिक करून इतर थ्रेड्ससह थोडेसे सिंक्रोनाइझ करतो आणि हे सुनिश्चित करतो की या कार्याच्या प्रत्येक घटकासाठी केवळ एक हँडल तयार केले गेले आहे.
        // हे लक्षात घ्या की हे हँडल ग्लोबलमध्ये संचयित झाल्यावर कधीही बंद होणार नाही.
        //
        // आम्ही प्रत्यक्षात लॉक गेल्यानंतर आम्ही ते सहजपणे संपादन करतो आणि आपला एक्स 100 एक्स हँडल शेवटी सोडण्यास जबाबदार असेल.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // ठीक आहे, ओहो!आता आम्ही सर्व सुरक्षितपणे समक्रमित झाले आहोत, तर प्रत्यक्षात सर्व गोष्टींवर प्रक्रिया सुरू करूया.
        // प्रथम आम्हाला हे सुनिश्चित करण्याची आवश्यकता आहे की या प्रक्रियेत `dbghelp.dll` वास्तविकपणे लोड केले गेले आहे.
        // स्थिर अवलंबन टाळण्यासाठी आम्ही हे गतिकरित्या करतो.
        // हे ऐतिहासिकदृष्ट्या विचित्र दुवा साधण्याच्या समस्येवर कार्य करण्यासाठी केले गेले आहे आणि बायनरींना थोडे अधिक पोर्टेबल बनवण्याचा हेतू आहे कारण ही मुख्यत्वे फक्त डीबगिंग उपयुक्तता आहे.
        //
        //
        // एकदा आम्ही `dbghelp.dll` उघडल्यानंतर आम्हाला त्यात काही आरंभ कार्ये कॉल करण्याची आवश्यकता आहे आणि त्याबद्दल अधिक तपशीलवार आहे.
        // आम्ही फक्त एकदाच हे करतो, म्हणून आपल्याकडे अजून एक बुलियन मिळाला आहे जो दर्शवितो की आपण अद्याप पूर्ण केले आहे की नाही.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // `SYMOPT_DEFERRED_LOADS` ध्वज सेट केलेला असल्याची खात्री करा, कारण त्याबद्दल एमएसव्हीसीच्या स्वत: च्या दस्तऐवजानुसार: "This is the fastest, most efficient way to use the symbol handler.", तर हे करूया!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // वास्तविक एमएसव्हीसी सह चिन्हे आरंभ करा.लक्षात घ्या की हे अयशस्वी होऊ शकते परंतु आम्ही त्याकडे दुर्लक्ष करतो.
        // या साठी प्रति टन पूर्वीची कला नाही, परंतु एलएलव्हीएम अंतर्गतपणे येथे परताव्याच्या मूल्याकडे दुर्लक्ष करते आणि एलएलव्हीएममधील सेनिटायझर ग्रंथालयांपैकी एखादी धडकी भरवणारा इशारा मुद्रित करते परंतु हे अयशस्वी झाल्यास परंतु मुळात ते दीर्घकाळ दुर्लक्ष करते.
        //
        //
        // झेड 0 रस्ट ० झेडसाठी एक गोष्ट ही पुढे आली आहे ती म्हणजे मानक ग्रंथालय आणि एक्स ०१ एक्सवरील हे झेडकेरेट ० झेड दोघांनाही एक्स २०० एक्सची स्पर्धा करायची आहे.
        // ऐतिहासिक वाचनालयाला ऐतिहासिकदृष्ट्या नंतर बहुतेक वेळेस साफसफाईची इच्छा होती, परंतु आता हे झेडकेरेट 0 झेड वापरत आहे याचा अर्थ असा आहे की एखाद्यास प्रथम आरंभ होईल आणि दुसरे ती आरंभ निवडतील.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}