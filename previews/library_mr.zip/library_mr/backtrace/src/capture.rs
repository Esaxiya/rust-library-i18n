use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// मालकीचे आणि स्वयंपूर्ण बॅकट्रेसचे प्रतिनिधित्व.
///
/// या संरचनेचा उपयोग प्रोग्राममधील विविध बिंदूंवर बॅकट्रस कॅप्चर करण्यासाठी केला जाऊ शकतो आणि नंतर त्या वेळी बॅकट्रेस काय आहे याची तपासणी करण्यासाठी वापर केला जाऊ शकतो.
///
///
/// `Backtrace` त्याच्या `Debug` अंमलबजावणीद्वारे बॅकट्रेसचे चक्क-मुद्रण समर्थन करते.
///
/// # आवश्यक वैशिष्ट्ये
///
/// या कार्यासाठी `backtrace` crate चे `std` वैशिष्ट्य सक्षम केले जाणे आवश्यक आहे आणि `std` वैशिष्ट्य डीफॉल्टनुसार सक्षम केलेले आहे.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // येथे फ्रेम्स स्टॅकच्या शीर्षापासून तळाशी सूचीबद्ध आहेत
    frames: Vec<BacktraceFrame>,
    // आम्हाला वाटणारी अनुक्रमणिका म्हणजे बॅकट्रेसची वास्तविक सुरुवात, `Backtrace::new` आणि `backtrace::trace` सारख्या फ्रेम वगळणे.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// बॅकट्रेसमध्ये फ्रेमची कॅप्चर केलेली आवृत्ती.
///
/// हा प्रकार `Backtrace::frames` वरून परत केला गेला आहे आणि कॅप्चर केलेल्या बॅकट्रॅसमध्ये एक स्टॅक फ्रेम दर्शवितो.
///
/// # आवश्यक वैशिष्ट्ये
///
/// या कार्यासाठी `backtrace` crate चे `std` वैशिष्ट्य सक्षम केले जाणे आवश्यक आहे आणि `std` वैशिष्ट्य डीफॉल्टनुसार सक्षम केलेले आहे.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// बॅकट्रेसमध्ये चिन्हाची कब्जा केलेली आवृत्ती.
///
/// हा प्रकार `BacktraceFrame::symbols` वरून परत केला आहे आणि बॅकट्रेसमधील चिन्हासाठी मेटाडेटाचे प्रतिनिधित्व करतो.
///
/// # आवश्यक वैशिष्ट्ये
///
/// या कार्यासाठी `backtrace` crate चे `std` वैशिष्ट्य सक्षम केले जाणे आवश्यक आहे आणि `std` वैशिष्ट्य डीफॉल्टनुसार सक्षम केलेले आहे.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// या फंक्शनच्या कॉलसाईटवर बॅकट्रेस कॅप्चर करते, मालकीचे प्रतिनिधित्व परत करते.
    ///
    /// हे कार्य Rust मध्ये बॅकट्रेसला ऑब्जेक्ट म्हणून प्रतिनिधित्व करण्यासाठी उपयुक्त आहे.हे परत केलेले मूल्य थ्रेड्समध्ये पाठवले जाऊ शकते आणि इतरत्र मुद्रित केले जाऊ शकते आणि या मूल्याचे उद्दीष्ट संपूर्णपणे स्वत: चे असते.
    ///
    /// लक्षात घ्या की काही प्लॅटफॉर्मवर पूर्ण बॅकट्रेस मिळवणे आणि त्याचे निराकरण करणे अत्यंत महाग असू शकते.
    /// आपल्या अनुप्रयोगासाठी किंमत खूप जास्त असल्यास त्याऐवजी `Backtrace::new_unresolved()` वापरण्याची शिफारस केली जाते जे चिन्ह रेझोल्यूशन चरण (जे सहसा सर्वात जास्त काळ घेते) टाळते आणि नंतरच्या तारखेला पुढे ढकलण्यास परवानगी देते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # आवश्यक वैशिष्ट्ये
    ///
    /// या कार्यासाठी `backtrace` crate चे `std` वैशिष्ट्य सक्षम केले जाणे आवश्यक आहे आणि `std` वैशिष्ट्य डीफॉल्टनुसार सक्षम केलेले आहे.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // काढण्यासाठी येथे एक फ्रेम असल्याचे सुनिश्चित करू इच्छित आहात
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// हे कोणत्याही प्रतीकांचे निराकरण करीत नाही याशिवाय `new` प्रमाणेच, हे पत्त्याच्या सूचीच्या रूपात बॅकट्रेस सहजपणे पकडते.
    ///
    /// नंतरच्या काळात या बॅकट्रेसची चिन्हे वाचनीय नावांमध्ये सोडविण्यासाठी `resolve` फंक्शन कॉल केले जाऊ शकते.
    /// हे कार्य अस्तित्वात आहे कारण रिझोल्यूशन प्रक्रियेमध्ये काहीवेळा महत्त्वपूर्ण वेळ लागू शकतो तर एखादा बॅकट्रेस केवळ क्वचितच मुद्रित केला जाऊ शकतो.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // प्रतीक नावे नाहीत
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // प्रतीक नावे आता उपस्थित
    /// ```
    ///
    /// # आवश्यक वैशिष्ट्ये
    ///
    /// या कार्यासाठी `backtrace` crate चे `std` वैशिष्ट्य सक्षम केले जाणे आवश्यक आहे आणि `std` वैशिष्ट्य डीफॉल्टनुसार सक्षम केलेले आहे.
    ///
    ///
    ///
    #[inline(never)] // काढण्यासाठी येथे एक फ्रेम असल्याचे सुनिश्चित करू इच्छित आहात
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// जेव्हा हा बॅकट्रॅस हस्तगत केला होता तेव्हापासून फ्रेम परत करतो.
    ///
    /// या स्लाइसची पहिली प्रविष्टी बहुदा एक्स फंक्शन एक्स फंक्शन असेल आणि शेवटचा फ्रेम हा धागा किंवा मुख्य कार्य कसे सुरू झाले याबद्दल काहीतरी आहे.
    ///
    ///
    /// # आवश्यक वैशिष्ट्ये
    ///
    /// या कार्यासाठी `backtrace` crate चे `std` वैशिष्ट्य सक्षम केले जाणे आवश्यक आहे आणि `std` वैशिष्ट्य डीफॉल्टनुसार सक्षम केलेले आहे.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// जर हा बॅकट्रॅस `new_unresolved` वरून तयार केला गेला असेल तर हे फंक्शन बॅकट्रेसमधील सर्व पत्ते त्यांच्या प्रतीकात्मक नावे सोडवेल.
    ///
    ///
    /// जर हा बॅकट्रस पूर्वी निराकरण झाला असेल किंवा तो `new` द्वारे तयार केला गेला असेल तर हे कार्य काही करत नाही.
    ///
    /// # आवश्यक वैशिष्ट्ये
    ///
    /// या कार्यासाठी `backtrace` crate चे `std` वैशिष्ट्य सक्षम केले जाणे आवश्यक आहे आणि `std` वैशिष्ट्य डीफॉल्टनुसार सक्षम केलेले आहे.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// `Frame::ip` प्रमाणेच
    ///
    /// # आवश्यक वैशिष्ट्ये
    ///
    /// या कार्यासाठी `backtrace` crate चे `std` वैशिष्ट्य सक्षम केले जाणे आवश्यक आहे आणि `std` वैशिष्ट्य डीफॉल्टनुसार सक्षम केलेले आहे.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// `Frame::symbol_address` प्रमाणेच
    ///
    /// # आवश्यक वैशिष्ट्ये
    ///
    /// या कार्यासाठी `backtrace` crate चे `std` वैशिष्ट्य सक्षम केले जाणे आवश्यक आहे आणि `std` वैशिष्ट्य डीफॉल्टनुसार सक्षम केलेले आहे.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// `Frame::module_base_address` प्रमाणेच
    ///
    /// # आवश्यक वैशिष्ट्ये
    ///
    /// या कार्यासाठी `backtrace` crate चे `std` वैशिष्ट्य सक्षम केले जाणे आवश्यक आहे आणि `std` वैशिष्ट्य डीफॉल्टनुसार सक्षम केलेले आहे.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// या फ्रेमशी संबंधित असलेल्या चिन्हांची यादी मिळवते.
    ///
    /// सामान्यत: प्रति फ्रेममध्ये एकच प्रतीक असते, परंतु काहीवेळा जर अनेक कार्ये एका फ्रेममध्ये अंतर्भूत केली गेली तर अनेक चिन्हे परत मिळतील.
    /// सूचीबद्ध केलेले प्रथम चिन्ह एक्स 100 एक्स आहे, तर शेवटचे चिन्ह सर्वात बाह्य (अंतिम कॉलर) आहे.
    ///
    /// लक्षात ठेवा जर ही फ्रेम निराकरण न केलेल्या बॅकट्रॅसमधून आली असेल तर ही रिक्त सूची परत करेल.
    ///
    /// # आवश्यक वैशिष्ट्ये
    ///
    /// या कार्यासाठी `backtrace` crate चे `std` वैशिष्ट्य सक्षम केले जाणे आवश्यक आहे आणि `std` वैशिष्ट्य डीफॉल्टनुसार सक्षम केलेले आहे.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// `Symbol::name` प्रमाणेच
    ///
    /// # आवश्यक वैशिष्ट्ये
    ///
    /// या कार्यासाठी `backtrace` crate चे `std` वैशिष्ट्य सक्षम केले जाणे आवश्यक आहे आणि `std` वैशिष्ट्य डीफॉल्टनुसार सक्षम केलेले आहे.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// `Symbol::addr` प्रमाणेच
    ///
    /// # आवश्यक वैशिष्ट्ये
    ///
    /// या कार्यासाठी `backtrace` crate चे `std` वैशिष्ट्य सक्षम केले जाणे आवश्यक आहे आणि `std` वैशिष्ट्य डीफॉल्टनुसार सक्षम केलेले आहे.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// `Symbol::filename` प्रमाणेच
    ///
    /// # आवश्यक वैशिष्ट्ये
    ///
    /// या कार्यासाठी `backtrace` crate चे `std` वैशिष्ट्य सक्षम केले जाणे आवश्यक आहे आणि `std` वैशिष्ट्य डीफॉल्टनुसार सक्षम केलेले आहे.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// `Symbol::lineno` प्रमाणेच
    ///
    /// # आवश्यक वैशिष्ट्ये
    ///
    /// या कार्यासाठी `backtrace` crate चे `std` वैशिष्ट्य सक्षम केले जाणे आवश्यक आहे आणि `std` वैशिष्ट्य डीफॉल्टनुसार सक्षम केलेले आहे.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// `Symbol::colno` प्रमाणेच
    ///
    /// # आवश्यक वैशिष्ट्ये
    ///
    /// या कार्यासाठी `backtrace` crate चे `std` वैशिष्ट्य सक्षम केले जाणे आवश्यक आहे आणि `std` वैशिष्ट्य डीफॉल्टनुसार सक्षम केलेले आहे.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // पथ मुद्रित करताना आम्ही सीडब्ल्यूडी अस्तित्त्वात असल्यास तो काढून टाकण्याचा प्रयत्न करतो, अन्यथा आम्ही हा पथ जसे आहे तसे मुद्रित करतो.
        // लक्षात ठेवा आम्ही हे केवळ छोट्या स्वरूपासाठीच करतो, कारण हे पूर्ण असल्यास आम्हाला शक्यतो सर्व काही मुद्रित करायचे आहे.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}