//! प्लॅटफॉर्म आश्रित प्रकार

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::borrow::Cow;
        use std::fmt;
        use std::path::PathBuf;
        use std::prelude::v1::*;
        use std::str;
    }
}

/// स्ट्रिंगचे एक व्यासपीठ स्वतंत्र प्रतिनिधित्व.
/// `std` सक्षमसह कार्य करीत असताना `std` प्रकारांना रूपांतरित करण्यासाठी सोयीच्या पद्धतींची शिफारस केली जाते.
///
#[derive(Debug)]
pub enum BytesOrWideString<'a> {
    /// एक स्लाइस, विशेषत: एक्स00 एक्स प्लॅटफॉर्मवर प्रदान केली जाते.
    Bytes(&'a [u8]),
    /// विशेषत: Windows मधील वाइड स्ट्रिंग.
    Wide(&'a [u16]),
}

#[cfg(feature = "std")]
impl<'a> BytesOrWideString<'a> {
    /// लॉसी `Cow<str>` मध्ये रूपांतरित करते, `Bytes` वैध UTF-8 नसल्यास किंवा `BytesOrWideString` `Wide` असल्यास वाटप केले जाईल.
    ///
    /// # आवश्यक वैशिष्ट्ये
    ///
    /// या कार्यासाठी `backtrace` crate चे `std` वैशिष्ट्य सक्षम केले जाणे आवश्यक आहे आणि `std` वैशिष्ट्य डीफॉल्टनुसार सक्षम केलेले आहे.
    ///
    ///
    pub fn to_str_lossy(&self) -> Cow<'a, str> {
        use self::BytesOrWideString::*;

        match self {
            &Bytes(slice) => String::from_utf8_lossy(slice),
            &Wide(wide) => Cow::Owned(String::from_utf16_lossy(wide)),
        }
    }

    /// `BytesOrWideString` चे `Path` प्रतिनिधित्व प्रदान करते.
    ///
    /// # आवश्यक वैशिष्ट्ये
    ///
    /// या कार्यासाठी `backtrace` crate चे `std` वैशिष्ट्य सक्षम केले जाणे आवश्यक आहे आणि `std` वैशिष्ट्य डीफॉल्टनुसार सक्षम केलेले आहे.
    ///
    pub fn into_path_buf(self) -> PathBuf {
        #[cfg(unix)]
        {
            use std::ffi::OsStr;
            use std::os::unix::ffi::OsStrExt;

            if let BytesOrWideString::Bytes(slice) = self {
                return PathBuf::from(OsStr::from_bytes(slice));
            }
        }

        #[cfg(windows)]
        {
            use std::ffi::OsString;
            use std::os::windows::ffi::OsStringExt;

            if let BytesOrWideString::Wide(slice) = self {
                return PathBuf::from(OsString::from_wide(slice));
            }
        }

        if let BytesOrWideString::Bytes(b) = self {
            if let Ok(s) = str::from_utf8(b) {
                return PathBuf::from(s);
            }
        }
        unreachable!()
    }
}

#[cfg(feature = "std")]
impl<'a> fmt::Display for BytesOrWideString<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.to_str_lossy().fmt(f)
    }
}