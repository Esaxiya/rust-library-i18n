//! रनटाइमवेळी बॅकट्रेस मिळविण्यासाठी एक लायब्ररी
//!
//! हे लायब्ररी रनटाइम प्रोग्रामनुसार स्वयंचलितपणे बॅकट्रॅस घेण्याची परवानगी देऊन मानक लायब्ररीच्या `RUST_BACKTRACE=1` समर्थनास पूरक आहे.
//! या लायब्ररीद्वारे व्युत्पन्न केलेल्या बॅकट्रेसेस पार्स करणे आवश्यक नाही, उदाहरणार्थ, आणि एकाधिक बॅकएंड अंमलबजावणीची कार्यक्षमता उघड करा.
//!
//! # Usage
//!
//! प्रथम, हे आपल्या Cargo.toml मध्ये जोडा
//!
//! ```toml
//! [dependencies]
//! backtrace = "0.3"
//! ```
//!
//! Next:
//!
//! ```
//! fn main() {
//! # // येथे असुरक्षित आहे म्हणून चाचणी क्र.
//! # #[cfg(feature = "std")] {
//!     backtrace::trace(|frame| {
//!         let ip = frame.ip();
//!         let symbol_address = frame.symbol_address();
//!
//!         // या निर्देश सूचक नावावर निर्देशक सोडवा
//!         backtrace::resolve_frame(frame, |symbol| {
//!             if let Some(name) = symbol.name() {
//!                 // ...
//!             }
//!             if let Some(filename) = symbol.filename() {
//!                 // ...
//!             }
//!         });
//!
//!         true // पुढील चौकटीवर जा
//!     });
//! }
//! # }
//! ```
//!
//!
//!

#![doc(html_root_url = "https://docs.rs/backtrace")]
#![deny(missing_docs)]
#![no_std]
#![cfg_attr(
    all(feature = "std", target_env = "sgx", target_vendor = "fortanix"),
    feature(sgx_platform)
)]
#![warn(rust_2018_idioms)]
// जेव्हा आम्ही लिब्स्टडी च्या भागाच्या रूपात इमारत करीत असतो, तेव्हा सर्व इशारे शांत ठेवा कारण ते झेडकेरेट0 झेड वृक्ष नसलेल्या विकसित झाल्यामुळे ते अप्रासंगिक आहेत.
//
#![cfg_attr(backtrace_in_libstd, allow(warnings))]
#![cfg_attr(not(feature = "std"), allow(dead_code))]

#[cfg(feature = "std")]
#[macro_use]
extern crate std;

// हा आत्ता फक्त जिमलीसाठी वापरला जातो, जो फक्त काही प्लॅटफॉर्मवर वापरला जातो, म्हणून इतर कॉन्फिगरेशनमध्ये त्याचा वापर न झाल्यास काळजी करू नका.
//
#[allow(unused_extern_crates)]
extern crate alloc;

pub use self::backtrace::{trace_unsynchronized, Frame};
mod backtrace;

pub use self::symbolize::resolve_frame_unsynchronized;
pub use self::symbolize::{resolve_unsynchronized, Symbol, SymbolName};
mod symbolize;

pub use self::types::BytesOrWideString;
mod types;

#[cfg(feature = "std")]
pub use self::symbolize::clear_symbol_cache;

mod print;
pub use print::{BacktraceFmt, BacktraceFrameFmt, PrintFmt};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        pub use self::backtrace::trace;
        pub use self::symbolize::{resolve, resolve_frame};
        pub use self::capture::{Backtrace, BacktraceFrame, BacktraceSymbol};
        mod capture;
    }
}

#[allow(dead_code)]
struct Bomb {
    enabled: bool,
}

#[allow(dead_code)]
impl Drop for Bomb {
    fn drop(&mut self) {
        if self.enabled {
            panic!("cannot panic during the backtrace function");
        }
    }
}

#[allow(dead_code)]
#[cfg(feature = "std")]
mod lock {
    use std::boxed::Box;
    use std::cell::Cell;
    use std::sync::{Mutex, MutexGuard, Once};

    pub struct LockGuard(Option<MutexGuard<'static, ()>>);

    static mut LOCK: *mut Mutex<()> = 0 as *mut _;
    static INIT: Once = Once::new();
    thread_local!(static LOCK_HELD: Cell<bool> = Cell::new(false));

    impl Drop for LockGuard {
        fn drop(&mut self) {
            if self.0.is_some() {
                LOCK_HELD.with(|slot| {
                    assert!(slot.get());
                    slot.set(false);
                });
            }
        }
    }

    pub fn lock() -> LockGuard {
        if LOCK_HELD.with(|l| l.get()) {
            return LockGuard(None);
        }
        LOCK_HELD.with(|s| s.set(true));
        unsafe {
            INIT.call_once(|| {
                LOCK = Box::into_raw(Box::new(Mutex::new(())));
            });
            LockGuard(Some((*LOCK).lock().unwrap()))
        }
    }
}

#[cfg(all(windows, not(target_vendor = "uwp")))]
mod dbghelp;
#[cfg(windows)]
mod windows;