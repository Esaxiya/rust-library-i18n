# backtrace-rs

[Documentation](https://docs.rs/backtrace)

झेड रस्ट0 झेडसाठी रनटाइमवेळी बॅकट्रेस मिळविण्यासाठी एक लायब्ररी.
या लायब्ररीचे कार्य करण्यासाठी प्रोग्रामेटिक इंटरफेस प्रदान करुन मानक लायब्ररीचे समर्थन वाढविणे हे आहे, परंतु हे libstd च्या panics सारख्या वर्तमान बॅकट्रेसला सहजपणे मुद्रित करण्यास समर्थन देते.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

फक्त नंतरचा काळपर्यंत बॅकट्रेस आणि त्याच्याशी व्यवहार करण्यासाठी पुढे ढकलण्यासाठी आपण शीर्ष-स्तरीय `Backtrace` प्रकार वापरू शकता.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

तथापि, आपल्याला वास्तविक ट्रेसिंग कार्यक्षमतेत अधिक कच्चा प्रवेश हवा असेल तर आपण थेट `trace` आणि `resolve` कार्ये वापरू शकता.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // या निर्देश सूचक नावावर निर्देशक सोडवा
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // पुढील चौकटीवर जा
    });
}
```

# License

या प्रकल्पापैकी एका अंतर्गत परवानाकृत आहे

 * Apache परवाना, आवृत्ती 2.0, ([LICENSE-APACHE](LICENSE-APACHE) किंवा http://www.apache.org/licenses/LICENSE-2.0)
 * एमआयटी परवाना ([LICENSE-MIT](LICENSE-MIT) किंवा http://opensource.org/licenses/MIT)

आपल्या पर्यायावर.

### Contribution

जोपर्यंत आपण अन्यथा स्पष्टपणे सांगत नाही तोपर्यंत Apache-2.0 परवान्यात परिभाषित केल्याप्रमाणे आपल्याद्वारे बॅकट्रेस-आरएसमध्ये समावेशासाठी हेतूपूर्वक सबमिट केलेले कोणतेही योगदान कोणत्याही अतिरिक्त अटी व शर्तीशिवाय वरील प्रमाणे दुहेरी परवानाकृत असेल.







