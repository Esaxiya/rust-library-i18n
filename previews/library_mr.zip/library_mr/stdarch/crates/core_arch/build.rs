use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // आमच्या `#[assert_instr]` एनोटेशनना सांगायला वापरले की सर्व सिमड इंटिन्सिक्स त्यांच्या कोडेजेनची चाचणी घेण्यासाठी उपलब्ध आहेत, कारण काहींना आता अतिरिक्त `-Ctarget-feature=+unimplemented-simd128` च्या मागे दिले आहे ज्याचे आत्ता `#[target_feature]` मध्ये समकक्ष नाही.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}