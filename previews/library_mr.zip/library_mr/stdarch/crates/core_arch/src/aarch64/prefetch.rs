#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// [`prefetch`](fn._prefetch.html) पहा.
pub const _PREFETCH_READ: i32 = 0;

/// [`prefetch`](fn._prefetch.html) पहा.
pub const _PREFETCH_WRITE: i32 = 1;

/// [`prefetch`](fn._prefetch.html) पहा.
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// [`prefetch`](fn._prefetch.html) पहा.
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// [`prefetch`](fn._prefetch.html) पहा.
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// [`prefetch`](fn._prefetch.html) पहा.
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// दिलेली `rw` आणि `locality` वापरून `p` पत्ता असलेली कॅशे लाइन मिळवा.
///
/// `rw` यापैकी एक असणे आवश्यक आहे:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): प्रीफेच वाचनाची तयारी करत आहे.
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): प्रीफेच लिहिण्याची तयारी करत आहे.
///
/// `locality` यापैकी एक असणे आवश्यक आहे:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): फक्त एकदाच वापरल्या जाणार्‍या डेटासाठी प्रवाहित किंवा नॉन-टेम्पोरल प्रीफेच.
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): पातळी 3 कॅशेमध्ये आणा.
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): पातळी 2 कॅशेमध्ये आणा.
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): स्तर 1 कॅशेमध्ये आणा.
///
/// प्रीफेच मेमरी सूचना मेमरी सिस्टमला सिग्नल देतात की निर्दिष्ट पत्त्यावरून मेमरीद्वारे प्रवेश करणे जवळच्या झेडफ्यूचर0 झेडमध्ये उद्भवू शकते.
/// मेमरी सिस्टम जेव्हा असे होते तेव्हा मेमरी प्रवेश गतीसाठी अपेक्षित केलेल्या कृती करुन प्रतिसाद देऊ शकतो, जसे की निर्दिष्ट पत्ता एक किंवा अधिक कॅशमध्ये लोड करणे.
///
/// हे सिग्नल केवळ इशारेच असल्यामुळे विशिष्ट सीपीयूसाठी कोणत्याही किंवा सर्व प्रीफेच सूचनांना एनओपी म्हणून मानणे वैध आहे.
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // आम्ही `cache type` =1 (डेटा कॅशे) सह `llvm.prefetch` अंतःप्रेरक वापरतो.
    // `rw` आणि `strategy` फंक्शन पॅरामीटर्सवर आधारित आहेत.
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}