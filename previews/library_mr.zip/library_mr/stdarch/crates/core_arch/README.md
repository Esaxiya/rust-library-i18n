`core::arch` - Rust ची कोर लायब्ररी आर्किटेक्चर-विशिष्ट अंतर्ज्ञान
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch` मॉड्यूल आर्किटेक्चर-आधारित इंटिरनिक्स (उदा. सिमडी) लागू करते.

# Usage 

`core::arch` `libcore` चा भाग म्हणून उपलब्ध आहे आणि हे एक्स-एक्स एक्सद्वारे पुन्हा निर्यात केले जाते.या झेडकेरेट0झेडपेक्षा `core::arch` किंवा `std::arch` मार्गे ते वापरण्यास प्राधान्य द्या.
अस्थिर वैशिष्ट्ये सहसा `feature(stdsimd)` मार्गे रात्रीच्या Rust मध्ये उपलब्ध असतात.

या crate मार्गे `core::arch` वापरण्यासाठी रात्रीच्या वेळी Rust आवश्यक आहे आणि हे बर्‍याचदा (आणि करते) खंडित होऊ शकते.आपण या crate मार्गे वापरण्याचा विचार केला पाहिजे अशी केवळ प्रकरणे आहेत:

* आपण स्वत: `core::arch` पुन्हा-कंपाईल करणे आवश्यक असल्यास, उदाहरणार्थ, विशिष्ट लक्ष्य-वैशिष्ट्यांसह सक्षम केले जे `libcore`/`libstd` साठी सक्षम केलेले नाहीत.
Note: आपल्याला मानक-नसलेल्या लक्ष्यासाठी ते पुन्हा-संकलित करण्याची आवश्यकता असल्यास, कृपया हे झेड 0 क्रेट 0 झेड वापरण्याऐवजी `xargo` वापरणे आणि `libcore`/`libstd` योग्यरित्या पुन्हा संकलित करणे पसंत करा.
  
* अस्थिर Rust वैशिष्ट्यांमागे कदाचित उपलब्ध नसलेली काही वैशिष्ट्ये वापरणे.आम्ही या गोष्टी किमान ठेवण्याचा प्रयत्न करतो.
आपल्याला यापैकी काही वैशिष्ट्ये वापरण्याची आवश्यकता असल्यास, कृपया एखादे प्रकरण उघडा जेणेकरुन आम्ही त्यांना रात्रीच्या Rust मध्ये उघडकीस आणू आणि आपण तेथून त्या वापरू शकता.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` प्रामुख्याने एमआयटी परवाना आणि Apache परवाना (आवृत्ती 2.0) या दोन्ही अटींच्या अंतर्गत वितरित केले गेले आहे, ज्यामध्ये बीएसडी-सारख्या परवान्यासह काही भाग समाविष्ट आहेत.

तपशीलांसाठी लायसन्स-झेडएपॅचे ० झेड आणि लायसन्स-एमआयटी पहा.

# Contribution

आपण स्पष्टपणे अन्यथा सांगत नाही तोपर्यंत, Apache-2.0 परवान्यात परिभाषित केल्यानुसार आपण `core_arch` मध्ये समावेश हेतुपुरस्सर सबमिट केलेले कोणतेही योगदान अतिरिक्त अटी व शर्तीशिवाय वरील प्रमाणे दुहेरी परवानाकृत असेल.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












