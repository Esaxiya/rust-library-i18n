// rsbegin.o आणि rsend.o हे तथाकथित "compiler runtime startup objects" आहेत.
// त्यामध्ये कंपाइलर रनटाइम योग्यरित्या आरंभ करण्यासाठी आवश्यक कोड आहे.
//
// जेव्हा एक्झिक्युटेबल किंवा डायलीब प्रतिमा जोडली जातात तेव्हा सर्व वापरकर्ता कोड आणि लायब्ररी या दोन ऑब्जेक्ट फायलींमधील एक्स 100 एक्स असतात, म्हणून एक्स01 एक्स मधील कोड किंवा डेटा प्रतिमेच्या संबंधित विभागात प्रथम होतो, तर एक्स0 2 एक्स मधील कोड आणि डेटा अंतिम बनतात.
// हा प्रभाव आरंभात किंवा विभागाच्या शेवटी चिन्ह ठेवण्यासाठी तसेच आवश्यक असलेले शीर्षलेख किंवा तळटीप समाविष्ट करण्यासाठी वापरला जाऊ शकतो.
//
// लक्षात घ्या की वास्तविक मॉड्यूल एंट्री पॉईंट सी रनटाइम स्टार्टअप ऑब्जेक्ट मध्ये स्थित आहे (सामान्यत: एक्स 100 एक्स), जे नंतर इतर रनटाइम घटकांच्या आरंभिक कॉलबॅकची विनंती करते (अद्याप दुसर्‍या विशेष प्रतिमेच्या विभागात नोंदणीकृत).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // स्टॅक फ्रेम अनावंड माहिती विभागाची सुरूवात चिन्हांकित करते
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // अनविंदरच्या अंतर्गत पुस्तक ठेवण्यासाठी स्क्रॅच स्पेस.
    // हे 00 GCC/unwind-dw2-fde.h मध्ये `struct object` म्हणून परिभाषित केले आहे.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // एक्स एक्स एक्स एक्स रूटीन अनावृत करा.
    // लिबपॅनिक_विंड च्या दस्तऐवज पहा.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // मॉड्यूल स्टार्टअपवर अनावश्यक माहिती नोंदवा
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // शटडाऊनवर नोंदणी रद्द करा
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-विशिष्ट init/uninit रुटीन नोंदणी
    pub mod mingw_init {
        // मिनीजीडब्ल्यूच्या स्टार्टअप ऑब्जेक्ट्स (एक्स ०२ एक्स/एक्स ०3 एक्स) स्टार्टअप आणि एग्जिट वर एक्स-एक्स एक्स आणि एक्स ०१ एक्स विभागातील ग्लोबल कन्स्ट्रक्टर्सची विनंती करेल.
        // डीएलएलच्या बाबतीत, जेव्हा डीएलएल लोड आणि अनलोड केले जाते तेव्हा हे केले जाते.
        //
        // लिंकर विभागांची क्रमवारी लावेल, जे सुनिश्चित करतात की आमच्या कॉलबॅक सूचीच्या शेवटी आहेत.
        // कन्स्ट्रक्टर रिव्हर्स ऑर्डरमध्ये कार्यरत असल्याने हे सुनिश्चित होते की आमची कॉलबॅक प्रथम आणि शेवटची अंमलात आली आहेत.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: सी इनिशिएशन कॉलबॅक
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .डीटर्स. *: सी टर्मिनेशन कॉलबॅक
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}