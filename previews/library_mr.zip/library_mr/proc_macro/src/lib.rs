//! नवीन मॅक्रो परिभाषित करताना मॅक्रो लेखकांसाठी समर्थन लायब्ररी.
//!
//! प्रमाणित वितरणाद्वारे प्रदान केलेली ही लायब्ररी कार्यपद्धतीनुसार मॅक्रो `#[proc_macro]`, मॅक्रो विशेषता `#[proc_macro_attribute]` आणि सानुकूल व्युत्पन्न विशेषता`##[proc_macro_derive] as सारख्या कार्यपद्धतीनुसार परिभाषित मॅक्रो व्याख्याच्या इंटरफेसमध्ये वापरल्या जाणा provides्या प्रकारच्या सुविधा पुरवते.
//!
//!
//! अधिकसाठी [the book] पहा.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// सध्या चालू असलेल्या प्रोग्राममध्ये प्रो_मॅक्रो प्रवेशयोग्य आहे की नाही हे निर्धारित करते.
///
/// प्रोक_मॅक्रो झेडक्रेट0 झेड केवळ प्रक्रियात्मक मॅक्रोच्या अंमलबजावणीसाठी वापरण्यासाठी आहे.बिल्ड स्क्रिप्ट किंवा युनिट टेस्ट किंवा सामान्य Rust बायनरी सारख्या प्रक्रियात्मक मॅक्रोच्या बाहेरून मागितल्यास या झेडकेरेट0 झेड झेडस्पॅनिक0झेड मधील सर्व कार्ये.
///
/// Rust लायब्ररी विचारात घेऊन जे दोन्ही मॅक्रो आणि नॉन-मॅक्रो वापर प्रकरणांना समर्थन देण्यासाठी डिझाइन केलेले आहेत, `proc_macro::is_available()` प्रो_माक्रोच्या एपीआय वापरण्यासाठी आवश्यक पायाभूत सुविधा सध्या उपलब्ध आहे की नाही हे शोधण्याचा एक नॉन-पॅनीकिंग मार्ग प्रदान करते.
/// प्रक्रियात्मक मॅक्रोच्या आतून आवाहन केल्यास ते सत्य मिळवते, इतर कोणत्याही बायनरीमधून आवाहन केल्यास चुकीचे असते.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// मुख्यत्वे या झेडकेरेट0 झेड द्वारे प्रदान केलेला, झेड टोकन0 झेडचा एक अमूर्त प्रवाह दर्शवितो, किंवा विशेषतः झेड टोकन0 झेड वृक्षांचा क्रम.
/// प्रकार त्या झेड टोकन0 झेड वृक्षांवर पुनरावृत्ती करण्यासाठी इंटरफेस प्रदान करतो आणि त्याउलट असंख्य झेड टोकन0 झेड झाडे एकाच प्रवाहात एकत्रित करतो.
///
///
/// हे `#[proc_macro]`, `#[proc_macro_attribute]` आणि `#[proc_macro_derive]` व्याख्याचे इनपुट आणि आउटपुट दोन्ही आहे.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// `TokenStream::from_str` वरून त्रुटी परत आली.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// token झाडे नसलेले रिक्त `TokenStream` मिळवते.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// हे `TokenStream` रिक्त आहे का ते तपासेल.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// स्ट्रिंगला tokens मध्ये खंडित करण्याचा प्रयत्न करा आणि त्या tokens चे token प्रवाहात विश्लेषण करा.
/// बर्‍याच कारणांसाठी अयशस्वी होऊ शकते, उदाहरणार्थ, जर स्ट्रिंगमध्ये असंतुलित डिलिमिटर किंवा भाषेमध्ये विद्यमान नसलेले वर्ण असतील.
///
/// विश्लेषित प्रवाहामधील सर्व tokens ला `Span::call_site()` स्पॅन मिळतात.
///
/// NOTE: काही त्रुटींमुळे `LexError` परत करण्याऐवजी panics होऊ शकते.आम्ही नंतर या चुका `LexError` मध्ये बदलण्याचा अधिकार राखून ठेवला आहे.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// एनबी, हा पूल केवळ एक्स 100 एक्स प्रदान करतो, यावर आधारित एक्स01 एक्स लागू करतो (त्या दोघांच्या नेहमीच्या नात्याचा उलट).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// शक्यतो `टोकनट्री: : ग्रुपचे `Delimiter::None` डिलिमीटर आणि नकारात्मक संख्यात्मक अक्षरशः वगळता, token प्रवाहाचे तारण म्हणून त्याच token प्रवाहामध्ये (मोड्यूलो स्पॅन) रूपांतर न करता बदलता येण्यासारखे आहे.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// डीबगिंगसाठी सोयीस्कर फॉर्ममध्ये झेड टोकन0झेड मुद्रित करते.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// एकच token वृक्ष असलेला token प्रवाह तयार करतो.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// एकाच प्रवाहामध्ये अनेक झेड टोकन0 झेड झाडे संकलित करते.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// token प्रवाहांवर एक "flattening" ऑपरेशन, एकाधिक token प्रवाहातून token झाडे एकाच प्रवाहात संकलित करते.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) शक्य असलेले ऑप्टिमाइझ्ड अंमलबजावणी if/when वापरा.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// एक्सट्रॅक्टर सारख्या `TokenStream` प्रकारासाठी सार्वजनिक अंमलबजावणीचे तपशील.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// `टोकनस्ट्रीम'च्या` टोकनट्री'वर एक इटरेटर
    /// इरिटेशन एक्स 100 एक्स आहे, उदा., पुनरावृत्तीकर्ता मर्यादित गटांमध्ये पुनरावृत्ती करत नाही आणि संपूर्ण गट झेड टोकन0 झेड वृक्ष म्हणून परत करतो.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` अनियंत्रित tokens स्वीकारते आणि इनपुट वर्णन करणारे `TokenStream` मध्ये विस्तृत करते.
/// उदाहरणार्थ, `quote!(a + b)` एक अभिव्यक्ती तयार करेल, जेव्हा त्याचे मूल्यमापन केले की `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// एक्सकॉक्सिंग एक्स 100 एक्स सह केले जाते आणि एकल पुढची ओळख न लावलेल्या संज्ञा म्हणून घेऊन कार्य करते.
/// स्वतः `$` उद्धृत करण्यासाठी, `$$` वापरा.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// मॅक्रो विस्तार माहितीसह स्त्रोत कोडचा एक प्रदेश.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// कालावधी `self` येथे दिलेल्या `message` सह एक नवीन `Diagnostic` तयार करते.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// मॅक्रो परिभाषा साइटवर निराकरण करणारा स्पॅन
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// सद्य प्रक्रियात्मक मॅक्रोच्या विनंतीचा कालावधी.
    /// या कालावधीसह तयार केलेले अभिज्ञापकांचे निराकरण होईल जसे की ते थेट मॅक्रो कॉल लोकेशन (कॉल-साइट हायजीन) वर लिहिले गेले होते आणि मॅक्रो कॉल साइटवरील अन्य कोड देखील त्यांचा संदर्भ घेण्यास सक्षम असतील.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// `macro_rules` स्वच्छतेचे प्रतिनिधित्व करणारा स्पॅन, आणि कधीकधी मॅक्रो डेफिनिशन साइट (स्थानिक व्हेरिएबल्स, लेबले, एक्स 0 एक्स) आणि कधीकधी मॅक्रो कॉल साइटवर (इतर सर्व काही) निराकरण करतो.
    ///
    /// स्पॅन स्थान कॉल-साइटवरून घेतले जाते.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// मूळ स्त्रोत फाइल ज्यात या कालावधीचा उल्लेख आहे.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// मागील मॅक्रो विस्तारामधील tokens साठी `Span` ज्या वरुन `self` व्युत्पन्न केला होता.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// मूळ स्त्रोत कोडसाठी स्पॅन ज्याद्वारे `self` व्युत्पन्न झाला.
    /// जर हे `Span` इतर मॅक्रो विस्तारांमधून व्युत्पन्न झाले नाही तर परतावाचे मूल्य एक्स 100 एक्ससारखेच आहे.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// या कालावधीसाठी स्त्रोत फाइलमध्ये प्रारंभ होणारा line/column मिळतो.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// या कालावधीसाठी स्त्रोत फायलीमध्ये शेवटची line/column मिळते.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// `self` आणि `other` समाविष्ट करून नवीन कालावधी तयार करते.
    ///
    /// `self` आणि `other` भिन्न फायलींमधून असल्यास `None` मिळवते.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// `self` सारख्याच line/column माहितीसह एक नवीन स्पॅन तयार करतो परंतु ते प्रतीकांचे निराकरण करते जसे ते `other` वर होते.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// `self` सारख्याच नावाच्या रेजोल्यूशन वर्तनसह परंतु `other` च्या line/column माहितीसह नवीन कालावधी तयार करते.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// स्पॅनशी तुलना केली की ते समान आहेत किंवा नाही.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// कालावधीच्या मागे स्त्रोत मजकूर मिळवते.
    /// हे रिक्त स्थान आणि टिप्पण्यांसह मूळ स्त्रोत कोड संरक्षित करते.
    /// स्पॅन वास्तविक स्त्रोत कोडशी संबंधित असल्यासच तो निकाल देतो.
    ///
    /// Note: मॅक्रोचा निरीक्षणीय परिणाम केवळ झेडटोक्केन्झझेड वर अवलंबून असावा आणि या स्त्रोत मजकूरावर नाही.
    ///
    /// या फंक्शनचा परिणाम केवळ डायग्नोस्टिक्ससाठी वापरण्याचा एक उत्तम प्रयत्न आहे.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// डीबगिंगसाठी सोयीस्कर फॉर्ममध्ये स्पॅन मुद्रित करते.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// एक `Span` प्रारंभ किंवा शेवटचे प्रतिनिधित्व करणारी रेखा-स्तंभ जोडी.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// स्त्रोत फायलीमधील 1 अनुक्रमित रेखा ज्यावर कालावधी (inclusive) प्रारंभ होतो किंवा समाप्त होतो.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// स्त्रोत फायलीमध्ये 0 अनुक्रमित स्तंभ (UTF-8 वर्णांमधील) ज्यावरील कालावधी (inclusive) प्रारंभ होतो किंवा समाप्त होतो.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// दिलेल्या `Span` ची स्त्रोत फाइल.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// या स्त्रोताच्या फाईलचा मार्ग मिळतो.
    ///
    /// ### Note
    /// जर या `SourceFile` शी संबंधित कोड स्पेन बाह्य मॅक्रो, या मॅक्रोद्वारे व्युत्पन्न केला गेला असेल तर, हा कदाचित फाईल सिस्टमवरील वास्तविक पथ असू शकत नाही.
    /// तपासणी करण्यासाठी [`is_real`] वापरा.
    ///
    /// हे देखील लक्षात घ्या की `is_real` ने `true` परत केले तरीही, जर `--remap-path-prefix` कमांड लाइनवर गेली असेल तर, दिलेला मार्ग वास्तविक असू शकत नाही.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// ही स्त्रोत फाइल वास्तविक स्त्रोत फाइल असल्यास आणि बाह्य मॅक्रोच्या विस्ताराद्वारे व्युत्पन्न केली नसल्यास `true` मिळवते.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // इंटरक्रेट स्पॅन लागू होईपर्यंत हे एक खाच आहे आणि बाह्य मॅक्रोमध्ये व्युत्पन्न केलेल्या स्पॅनसाठी आपल्याकडे वास्तविक स्त्रोत फायली असू शकतात.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// एकल झेड टोकन ० झेड किंवा झेड टोकन ० झेड झाडाचा मर्यादित क्रम (उदा. एक्स ०१ एक्स).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// एक token प्रवाह ब्रॅकेट डिलिमीटरने वेढलेला आहे.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// एक अभिज्ञापक
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// एकच विरामचिन्हे वर्ण (`+`, `,`, `$`, इ.)
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// शाब्दिक वर्ण (`'a'`), स्ट्रिंग (`"hello"`), क्रमांक (`2.3`) इ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// या झाडाचा कालावधी मिळविते, समाविष्ट असलेल्या झेड टोकन0 झेड किंवा सीमांकित प्रवाहाच्या `span` पद्धतीवर हस्तांतरित करते.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// *केवळ या झेड टोकन 0 झेड* साठी स्पॅन कॉन्फिगर करते.
    ///
    /// लक्षात घ्या की जर झेड टोकन0 झेड एक्स 100 एक्स असेल तर ही पद्धत अंतर्गत अंतर्गत प्रत्येक झेड टोकन 0 झेडची रचना कॉन्फिगर करणार नाही, ही प्रत्येक व्हेरिएंटच्या एक्स01 एक्स पद्धतीने सोपविली जाईल.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// डीबगिंगसाठी सोयीस्कर फॉर्ममध्ये झेड टोकन ० झेड झाडाची छापा.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // या प्रत्येकाचे व्युत्पन्न डीबगमधील स्ट्रक्टी प्रकारात नाव आहे, म्हणून अतिरिक्त दिशानिर्देशाचा त्रास घेऊ नका.
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// एनबी, हा पूल केवळ एक्स 100 एक्स प्रदान करतो, यावर आधारित एक्स01 एक्स लागू करतो (त्या दोघांच्या नेहमीच्या नात्याचा उलट).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// शक्यतो `टोकनट्री: : ग्रुपचे `Delimiter::None` डिलिमीटर आणि नकारात्मक संख्यात्मक अक्षरशः वगळता, token झाडाला स्ट्रिंगच्या रूपात मुद्रित करते जे त्याच token ट्री (मोड्यूलो स्पॅन) मध्ये परत न नुकसानरहित रूपांतरित केले जावे.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// एक मर्यादित token प्रवाह.
///
/// एक्स एक्स एक्स मध्ये अंतर्गत एक एक्स ०१ एक्स असते जो surrounded डिलिमीटरने वेढलेला असतो.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// झेड टोकन0 झेड झाडाचा क्रम कसा मर्यादित केला जातो त्याचे वर्णन करते.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// एक अप्रत्यक्ष डिलिमीटर, उदाहरणार्थ, "macro variable" `$var` पासून येणार्‍या tokens च्या आसपास दिसू शकेल.
    /// `$var * 3` जेथे `$var` `1 + 2` आहे अशा प्रकरणांमध्ये ऑपरेटरची प्राथमिकता जतन करणे महत्वाचे आहे.
    /// अंतर्भूत डिलिमिटर स्ट्रिंगद्वारे token प्रवाहाच्या राउंडट्रिपमध्ये टिकू शकत नाहीत.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// दिलेल्या डिलिमीटर आणि token प्रवाहासह एक नवीन `Group` तयार करते.
    ///
    /// हे कन्स्ट्रक्टर या गटासाठी स्पेन `Span::call_site()` वर सेट करेल.
    /// कालावधी बदलण्यासाठी आपण खालील `set_span` पद्धत वापरू शकता.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// या `Group` चे डिलिमीटर परत करते
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// या `Group` मध्ये मर्यादित केलेल्या tokens चे `TokenStream` मिळवते.
    ///
    /// लक्षात घ्या की परत केलेल्या token प्रवाहात वर परत केलेला डेलीमीटर समाविष्ट नाही.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// संपूर्ण झेड0 टोकन 0झेड प्रवाहाच्या डिलिमिटरसाठी कालावधी परत करते, संपूर्ण `Group` विस्तारित करते.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// या गटाच्या सुरूवातीच्या डिलिमिटरकडे निर्देशित केलेला कालावधी परत करते.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// या गटाच्या बंद असलेल्या डिलिमिटरकडे निर्देशित केलेला कालावधी परत करते.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// या `ग्रुप'च्या डिलिमिटर्ससाठी कालावधी कॉन्फिगर करते, परंतु अंतर्गत tokens नाही.
    ///
    /// ही पद्धत **नाही** या गटाद्वारे विस्तारित सर्व अंतर्गत tokens कालावधी सेट करेल, परंतु त्याऐवजी ती केवळ `Group` च्या पातळीवर डेलीमीटर tokens कालावधी सेट करेल.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// एनबी, हा पूल केवळ एक्स 100 एक्स प्रदान करतो, यावर आधारित एक्स01 एक्स लागू करतो (त्या दोघांच्या नेहमीच्या नात्याचा उलट).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// संभाव्यत: en टोकनट्री::ग्रुपचे `Delimiter::None` डिलिमिटर्स वगळता, स्ट्रिंगच्या रूपात गटाची छापाई करतो जी त्याच प्रकारचे (मॉड्यूलो स्पॅन) मध्ये लॉशलेसपणे परत रूपांतरित केली जावी.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` हे `+`, `-` किंवा `#` सारखे एक विरामचिन्हे आहेत.
///
/// `+=` सारख्या मल्टी-कॅरेक्टर ऑपरेटर `Punct` चे दोन उदाहरण म्हणून दर्शविले गेले आहेत जे एक्स02 एक्सचे भिन्न स्वरूप परत आले.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// एक `Punct` त्वरित दुसर्‍या `Punct` नंतर किंवा त्यानंतर दुसरे झेड टोकन 0 झेड किंवा व्हाइटस्पेस आहे की नाही.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// उदा. `+` `+ =`, `+ident` किंवा `+()` मध्ये `Alone` आहे.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// उदा. `+` हे `+=` किंवा `'#` मधील `Joint` आहे.
    /// याव्यतिरिक्त, एकल कोट `'` ओळखकर्त्यांसह सामील होऊ शकते आजीवन काळ `'ident` तयार करण्यासाठी.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// दिलेल्या वर्ण आणि अंतरातून नवीन `Punct` तयार करते.
    /// `ch` वितर्क भाषेद्वारे अनुमत वैध विरामचिन्हे वर्ण असणे आवश्यक आहे, अन्यथा कार्य panic करेल.
    ///
    /// परत केलेल्या `Punct` मध्ये `Span::call_site()` चा डीफॉल्ट स्पॅन असेल जो खाली खालील `set_span` पद्धतीने कॉन्फिगर केला जाऊ शकतो.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// या विरामचिन्हाचे मूल्य `char` म्हणून मिळवते.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// या विरामचिन्हाचे अंतर परत करते, ते token प्रवाहात त्वरित दुसर्‍या `Punct` नंतर आहे की नाही हे दर्शविते, जेणेकरून ते संभाव्यतः मल्टी-कॅरेक्टर ऑपरेटर (`Joint`) मध्ये एकत्रित केले जाऊ शकतात, किंवा त्यानंतर काही अन्य token किंवा व्हाइटस्पेस (`Alone`) असेल ज्यामुळे ऑपरेटर नक्कीच संपला.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// या विरामचिन्हे साठी कालावधी परत करते.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// या विरामचिन्हासाठी कालावधी कॉन्फिगर करा.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// एनबी, हा पूल केवळ एक्स 100 एक्स प्रदान करतो, यावर आधारित एक्स01 एक्स लागू करतो (त्या दोघांच्या नेहमीच्या नात्याचा उलट).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// विरामचिन्हे अक्षरेच्या रूपात मुद्रित करतात जी दोषरहितपणे त्याच वर्णात परत रूपांतरित केली जावी.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// एक अभिज्ञापक (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// दिलेल्या `string` तसेच निर्दिष्ट `span` सह एक नवीन `Ident` तयार करते.
    /// `string` युक्तिवाद भाषेद्वारे परवानगी असलेला वैध अभिज्ञापक असणे आवश्यक आहे (कीवर्डसह, उदा. `self` किंवा `fn`)अन्यथा, कार्य panic करेल.
    ///
    /// लक्षात घ्या की सध्या rustc मध्ये `span` या अभिज्ञापकासाठी स्वच्छताविषयक माहिती कॉन्फिगर करते.
    ///
    /// यावेळेपर्यंत `Span::call_site()` स्पष्टपणे "call-site" स्वच्छतेची निवड करीत आहे म्हणजे या स्पॅनसह निर्मित अभिज्ञापकांचे निराकरण होईल जसे की ते थेट मॅक्रो कॉलच्या ठिकाणी लिहिले गेले आहेत आणि मॅक्रो कॉल साइटवरील अन्य कोड संदर्भित करण्यास सक्षम असतील त्यांना देखील.
    ///
    ///
    /// नंतर `Span::def_site()` सारख्या स्पॅनने "definition-site" स्वच्छतेची निवड करण्यास अनुमती दिली म्हणजे या स्पॅनसह तयार केलेले अभिज्ञापक मॅक्रो परिभाषाच्या ठिकाणी निराकरण केले जातील आणि मॅक्रो कॉल साइटवरील अन्य कोड त्यांचा संदर्भ घेण्यास सक्षम राहणार नाहीत.
    ///
    /// अस्वच्छतेच्या सद्यस्थितीमुळे, या बांधकामकर्त्याला, इतर झेड टोकन्स0 झेडच्या विपरीत, बांधकामासाठी निर्दिष्ट केलेले `Span` आवश्यक आहे.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// `Ident::new` प्रमाणेच, परंतु एक कच्चा अभिज्ञापक (`r#ident`) तयार करतो.
    /// `string` युक्तिवाद भाषेद्वारे परवानगी असलेला वैध अभिज्ञापक असेल (कीवर्डसह, उदा. X01 एक्स).
    /// पथ विभागांमध्ये वापरण्यायोग्य कीवर्ड (उदा
    /// `self`, `सुपर`) समर्थित नाहीत आणि यामुळे झेडस्पॅनिक 0 झेड होईल.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// या X01 एक्सचा कालावधी परत करते, [`to_string`](Self::to_string) ने परत केलेली संपूर्ण स्ट्रिंग समाविष्ट करते.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// या `Ident` चे कालावधी कॉन्फिगर करते, शक्यतो त्याच्या स्वच्छतेचा संदर्भ बदलतो.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// एनबी, हा पूल केवळ एक्स 100 एक्स प्रदान करतो, यावर आधारित एक्स01 एक्स लागू करतो (त्या दोघांच्या नेहमीच्या नात्याचा उलट).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// एक ओळ म्हणून अभिज्ञापक मुद्रित करतो जो तो त्याच अभिज्ञापकात परत न येता परिवर्तीत करण्यायोग्य असावा.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// एक अक्षरशः स्ट्रिंग (`"hello"`), बाइट स्ट्रिंग (`b"hello"`), वर्ण (`'a'`), बाइट वर्ण (`b'a'`), एक पूर्णांक किंवा फ्लोटिंग पॉईंट क्रमांक ज्याचे प्रत्यय (`1`, `1u8`, `2.3`, `2.3f32`) आहे किंवा त्याशिवाय आहे.
///
/// `true` आणि `false` सारख्या बुलियन अक्षरांचे येथे संबंधित नाहीत, ते `ओळख आहेत.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// निर्दिष्ट केलेल्या मूल्यासह नवीन प्रत्यय पूर्णांक पूर्ण बनवते.
        ///
        /// हे फंक्शन `1u32` सारखा पूर्णांक तयार करेल जिथे निर्दिष्ट केलेला पूर्णांक मूल्य token चा पहिला भाग आहे आणि अखंड शेवटी अविभाज्य देखील आहे.
        /// नकारात्मक संख्यांमधून तयार केलेली अक्षरे `TokenStream` किंवा तारांमधून फेरी-ट्रीपमध्ये टिकून नाहीत आणि कदाचित दोन झेड टोकन0 झेड (एक्स ०१ एक्स आणि पॉझिटिव) असेल.
        ///
        ///
        /// या पद्धतीद्वारे तयार केलेल्या लिटरेल्समध्ये डीफॉल्टनुसार एक्स00 एक्स कालावधी असतो, जो खाली असलेल्या एक्स01 एक्स पद्धतीने कॉन्फिगर केला जाऊ शकतो.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// निर्दिष्ट मूल्यासह एक नवीन नसलेला पूर्णांक अक्षरशः तयार करतो.
        ///
        /// हे फंक्शन `1` सारखा पूर्णांक तयार करेल जिथे निर्दिष्ट केलेला पूर्णांक मूल्य token चा पहिला भाग आहे.
        /// या झेड टोकन ० झेडवर कोणतेही प्रत्यय निर्दिष्ट केलेले नाही, याचा अर्थ असा की `Literal::i8_unsuffixed(1)` सारखी विनंती `Literal::u32_unsuffixed(1)` च्या समतुल्य आहे.
        /// नकारात्मक संख्यांमधून तयार केलेली अक्षरे `TokenStream` किंवा स्ट्रिंगच्या माध्यमाने टिकून राहू शकत नाहीत आणि दोन tokens (`-` आणि सकारात्मक शाब्दिक) मध्ये मोडली जाऊ शकतात.
        ///
        ///
        /// या पद्धतीद्वारे तयार केलेल्या लिटरेल्समध्ये डीफॉल्टनुसार एक्स00 एक्स कालावधी असतो, जो खाली असलेल्या एक्स01 एक्स पद्धतीने कॉन्फिगर केला जाऊ शकतो.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// नवीन नसलेले फ्लोटिंग-पॉइंट शब्दशः तयार करते.
    ///
    /// हे कन्स्ट्रक्टर `Literal::i8_unsuffixed` प्रमाणेच आहे जिथे फ्लोटचे मूल्य थेट token मध्ये उत्सर्जित होते परंतु कोणताही प्रत्यय वापरला जात नाही, म्हणून कंपाईलरमध्ये नंतर `f64` असल्याचे अनुमान काढले जाऊ शकते.
    ///
    /// नकारात्मक संख्यांमधून तयार केलेली अक्षरे `TokenStream` किंवा स्ट्रिंगच्या माध्यमाने टिकून राहू शकत नाहीत आणि दोन tokens (`-` आणि सकारात्मक शाब्दिक) मध्ये मोडली जाऊ शकतात.
    ///
    /// # Panics
    ///
    /// या कार्यासाठी निर्दिष्ट केलेले फ्लोट मर्यादित असणे आवश्यक आहे, उदाहरणार्थ जर ते अनंत किंवा एनएएन असेल तर हे कार्य झेडस्पॅनिक 0 झेड करेल.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// नवीन प्रत्यय लावलेला फ्लोटिंग पॉइंट शब्दशः तयार करतो.
    ///
    /// हे कन्स्ट्रक्टर `1.0f32` सारखे शाब्दिक तयार करेल जिथे निर्दिष्ट केलेले मूल्य token चा आधीचा भाग आहे आणि `f32` हे token चा प्रत्यय आहे.
    /// हे token नेहमी कंपाईलरमध्ये `f32` असल्याचे अनुमान काढले जाईल.
    /// नकारात्मक संख्यांमधून तयार केलेली अक्षरे `TokenStream` किंवा स्ट्रिंगच्या माध्यमाने टिकून राहू शकत नाहीत आणि दोन tokens (`-` आणि सकारात्मक शाब्दिक) मध्ये मोडली जाऊ शकतात.
    ///
    ///
    /// # Panics
    ///
    /// या कार्यासाठी निर्दिष्ट केलेले फ्लोट मर्यादित असणे आवश्यक आहे, उदाहरणार्थ जर ते अनंत किंवा एनएएन असेल तर हे कार्य झेडस्पॅनिक 0 झेड करेल.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// नवीन नसलेले फ्लोटिंग-पॉइंट शब्दशः तयार करते.
    ///
    /// हे कन्स्ट्रक्टर `Literal::i8_unsuffixed` प्रमाणेच आहे जिथे फ्लोटचे मूल्य थेट token मध्ये उत्सर्जित होते परंतु कोणताही प्रत्यय वापरला जात नाही, म्हणून कंपाईलरमध्ये नंतर `f64` असल्याचे अनुमान काढले जाऊ शकते.
    ///
    /// नकारात्मक संख्यांमधून तयार केलेली अक्षरे `TokenStream` किंवा स्ट्रिंगच्या माध्यमाने टिकून राहू शकत नाहीत आणि दोन tokens (`-` आणि सकारात्मक शाब्दिक) मध्ये मोडली जाऊ शकतात.
    ///
    /// # Panics
    ///
    /// या कार्यासाठी निर्दिष्ट केलेले फ्लोट मर्यादित असणे आवश्यक आहे, उदाहरणार्थ जर ते अनंत किंवा एनएएन असेल तर हे कार्य झेडस्पॅनिक 0 झेड करेल.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// नवीन प्रत्यय लावलेला फ्लोटिंग पॉइंट शब्दशः तयार करतो.
    ///
    /// हे कन्स्ट्रक्टर `1.0f64` सारखे शाब्दिक तयार करेल जिथे निर्दिष्ट केलेले मूल्य token चा आधीचा भाग आहे आणि `f64` हे token चा प्रत्यय आहे.
    /// हे token नेहमी कंपाईलरमध्ये `f64` असल्याचे अनुमान काढले जाईल.
    /// नकारात्मक संख्यांमधून तयार केलेली अक्षरे `TokenStream` किंवा स्ट्रिंगच्या माध्यमाने टिकून राहू शकत नाहीत आणि दोन tokens (`-` आणि सकारात्मक शाब्दिक) मध्ये मोडली जाऊ शकतात.
    ///
    ///
    /// # Panics
    ///
    /// या कार्यासाठी निर्दिष्ट केलेले फ्लोट मर्यादित असणे आवश्यक आहे, उदाहरणार्थ जर ते अनंत किंवा एनएएन असेल तर हे कार्य झेडस्पॅनिक 0 झेड करेल.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// शब्दशः अक्षरशः.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// अक्षरशः अक्षरशः.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// बाइट स्ट्रिंग अक्षरशः.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// हे शाब्दिक असणारे स्पॅन मिळवते.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// या शाब्दिक संबंधित स्पॅन कॉन्फिगर करते.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// एक `Span` मिळवते जे `self.span()` चा सबसेट आहे जो `range` श्रेणीतील केवळ स्त्रोत बाइटचा आहे.
    /// जर ट्रिम केलेली कालावधी `self` च्या सीमेबाहेर असेल तर X01 एक्स मिळवते.
    ///
    // FIXME(SergioBenitez): स्त्रोताच्या UTF-8 सीमेवर बाइट श्रेणी सुरू होते आणि समाप्त होते हे तपासा.
    // अन्यथा, स्त्रोत मजकूर मुद्रित केल्यावर झेडस्पॅनिक 0 झेड इतरत्र कोठेही असण्याची शक्यता आहे.
    // FIXME(SergioBenitez): वापरकर्त्यास `self.span()` प्रत्यक्षात काय मॅप करते हे जाणून घेण्याचा कोणताही मार्ग नाही, म्हणून ही पद्धत सध्या फक्त डोळसपणे म्हटले जाऊ शकते.
    // उदाहरणार्थ, एक्स ०3 एक्स अक्षरासाठी एक्स ०२ एक्स एक्स ०१ एक्स परत करतो;वापरकर्त्याकडे स्त्रोत मजकूर 'c' आहे किंवा तो '\u{63}' आहे की नाही हे जाणून घेण्याचा कोणताही मार्ग नाही.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) `Option::cloned` सारखे काहीतरी, परंतु `Bound<&T>` साठी.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// एनबी, हा पूल केवळ एक्स 100 एक्स प्रदान करतो, यावर आधारित एक्स01 एक्स लागू करतो (त्या दोघांच्या नेहमीच्या नात्याचा उलट).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// अक्षरशः एका स्ट्रिंगच्या रूपात मुद्रित करते जे परत त्याच अक्षरशः मध्ये दोषरहितपणे परिवर्तीत करण्यायोग्य असावे (फ्लोटिंग पॉइंट लिटरलसाठी शक्य गोल करणे वगळता).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// पर्यावरण चल करीता मागोवा घेण्यात आला.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// पर्यावरणीय चल पुनर्प्राप्त करा आणि अवलंबन माहिती तयार करण्यासाठी त्यास जोडा.
    /// कंपाईलर कार्यान्वित करणार्‍या बिल्ड सिस्टमला हे माहित असेल की संकलनाच्या वेळी व्हेरिएबलमध्ये प्रवेश केला गेला होता आणि जेव्हा त्या व्हेरिएबलचे मूल्य बदलते तेव्हा बिल्ड पुन्हा चालू करण्यास सक्षम असेल.
    ///
    /// हे कार्य निर्भरता ट्रॅक करण्याऐवजी मानक लायब्ररीतून `env::var` च्या समतुल्य असावे, याशिवाय अर्ग्युमेंट UTF-8 असणे आवश्यक आहे.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}