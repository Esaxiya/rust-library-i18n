//! `Cell` एक्स00 एक्स अस्तित्वातील आजीवन काळातील प्रकार

use std::cell::Cell;
use std::mem;
use std::ops::{Deref, DerefMut};

/// आजीवन सह लॅम्ब्डा अनुप्रयोग टाइप करा.
#[allow(unused_lifetimes)]
pub trait ApplyL<'a> {
    type Out;
}

/// आयुष्यभर लॅम्ब्डा टाइप करा, म्हणजे, `Lifetime -> Type`.
pub trait LambdaL: for<'a> ApplyL<'a> {}

impl<T: for<'a> ApplyL<'a>> LambdaL for T {}

// HACK(eddyb) X0Nwtype0Z FIXME(#52812) `&'a mut <T as ApplyL<'b>>::Out` सह पुनर्स्थित प्रोजेक्शन मर्यादांभोवती कार्य करा
//
pub struct RefMutL<'a, 'b, T: LambdaL>(&'a mut <T as ApplyL<'b>>::Out);

impl<'a, 'b, T: LambdaL> Deref for RefMutL<'a, 'b, T> {
    type Target = <T as ApplyL<'b>>::Out;
    fn deref(&self) -> &Self::Target {
        self.0
    }
}

impl<'a, 'b, T: LambdaL> DerefMut for RefMutL<'a, 'b, T> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        self.0
    }
}

pub struct ScopedCell<T: LambdaL>(Cell<<T as ApplyL<'static>>::Out>);

impl<T: LambdaL> ScopedCell<T> {
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new(value: <T as ApplyL<'static>>::Out) -> Self {
        ScopedCell(Cell::new(value))
    }

    /// `f` चालवित असताना `self` मधील मूल्य `replacement` वर सेट करते, ज्याला जुने मूल्य परस्परपणे मिळते.
    /// `f` बाहेर पडल्यानंतर जुने मूल्य पुनर्संचयित केले जाईल, जरी झेडस्पॅनिक 0 झेड, त्यात `f` ने केलेल्या बदलांसह.
    ///
    ///
    pub fn replace<'a, R>(
        &self,
        replacement: <T as ApplyL<'a>>::Out,
        f: impl for<'b, 'c> FnOnce(RefMutL<'b, 'c, T>) -> R,
    ) -> R {
        /// रॅपर जे `f` घाबरून गेला असला तरीही सेल नेहमी भरलेला असल्याचे सुनिश्चित करते (मूळ स्थितीसह, `f` ने वैकल्पिकरित्या बदलले आहे).
        ///
        ///
        struct PutBackOnDrop<'a, T: LambdaL> {
            cell: &'a ScopedCell<T>,
            value: Option<<T as ApplyL<'static>>::Out>,
        }

        impl<'a, T: LambdaL> Drop for PutBackOnDrop<'a, T> {
            fn drop(&mut self) {
                self.cell.0.set(self.value.take().unwrap());
            }
        }

        let mut put_back_on_drop = PutBackOnDrop {
            cell: self,
            value: Some(self.0.replace(unsafe {
                let erased = mem::transmute_copy(&replacement);
                mem::forget(replacement);
                erased
            })),
        };

        f(RefMutL(put_back_on_drop.value.as_mut().unwrap()))
    }

    /// `f` चालवित असताना `self` मधील मूल्य `value` वर सेट करते.
    pub fn set<R>(&self, value: <T as ApplyL<'_>>::Out, f: impl FnOnce() -> R) -> R {
        self.replace(value, |_| f())
    }
}