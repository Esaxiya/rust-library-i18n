//! एकल-थ्रेडेड संदर्भ-मोजणी पॉईंटर्स.'Rc' म्हणजे 'संदर्भ
//! Counted'.
//!
//! [`Rc<T>`][`Rc`] हा प्रकार ढीगमध्ये वाटप केलेल्या `T` प्रकारच्या मूल्याची सामायिक मालकी प्रदान करतो.
//! [`Rc`] वर एक्स 100 एक्सची सुरूवात केल्याने ढीगमध्ये समान वाटपासाठी नवीन पॉईंटर तयार होतो.
//! जेव्हा दिलेल्या वाटपाचे शेवटचे [`Rc`] पॉईंटर नष्ट होते तेव्हा त्या allocलोकेशनमध्ये संचयित केलेले मूल्य (बहुधा "inner value" म्हणून संदर्भित) देखील सोडले जाते.
//!
//! Rust मधील सामायिक संदर्भ डीफॉल्टनुसार उत्परिवर्तन करण्यास अनुमती देत नाहीत आणि [`Rc`] देखील याला अपवाद नाहीः आपण सामान्यत: [`Rc`] च्या आत कशासही बदल बदलू शकत नाही.
//! जर आपल्याला परिवर्तनाची आवश्यकता असेल तर, [`Rc`] मध्ये एक एक्स 2 एक्स किंवा एक्स 0 एक्स लावा;[an example of mutability inside an `Rc`][mutability] पहा.
//!
//! [`Rc`] अणू संदर्भ मोजणी वापरते.
//! याचा अर्थ असा की ओव्हरहेड खूप कमी आहे, परंतु थ्रेड्स दरम्यान एक एक्स 0 एक्स एक्स पाठविला जाऊ शकत नाही आणि परिणामी एक्स0 2 एक्स एक्स 100 एक्स लागू करत नाही.
//! परिणामी, Rust कंपाइलर *कंपाईल वेळेत* तपासेल की आपण [between Rc`] s धाग्यांच्या दरम्यान पाठवत नाही.
//! आपल्याला बहु-थ्रेडेड, अणु संदर्भ मोजणीची आवश्यकता असल्यास, एक्स00 एक्स वापरा.
//!
//! एक्स-00 एक्स पद्धत नॉन-मालकीचे [`Weak`] पॉईंटर तयार करण्यासाठी वापरली जाऊ शकते.
//! एक [`Weak`] पॉईंटर [`अपग्रेड`][अपग्रेड] डी एक्स एक्स एक्स एक्स पर्यंत असू शकतो, परंतु जर यापूर्वीच वाटपात संग्रहित केलेली मूल्य सोडली गेली असेल तर हे एक्स 0 एक्स एक्स परत करेल.
//! दुस words्या शब्दांत, `Weak` पॉईंटर्स वाटप अंतर्गत मूल्य जिवंत ठेवत नाही;तथापि, ते वाटप (अंतर्गत मूल्यासाठी आधार देणारी दुकान) जिवंत ठेवतात.
//!
//! [`Rc`] पॉइंटर्स दरम्यानचे चक्र कधीही कमी होणार नाही.
//! या कारणास्तव, चक्र खंडित करण्यासाठी [`Weak`] चा वापर केला जातो.
//! उदाहरणार्थ, एका झाडामध्ये पालकांकरिता नोडस् कडून [`Rc`] पॉईंटर्स आणि मुलांपासून त्यांच्या पालकांकडे [`Weak`] पॉईंटर्स असू शकतात.
//!
//! `Rc<T>` आपोआप `T` चा संदर्भ घ्या ([`Deref`] trait मार्गे), जेणेकरुन आपण [`Rc<T>`][`Rc`] प्रकारच्या मूल्यावर `T` च्या पद्धती कॉल करू शकता.
//! `T` च्या पद्धतींसह नावाचा संघर्ष टाळण्यासाठी, स्वतः [`Rc<T>`][`Rc`] च्या पद्धती संबंधित कार्ये आहेत, ज्यास [fully qualified syntax] वापरून म्हटले जाते:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `आरसी<T>`Clone` सारख्या traits च्या अंमलबजावणीस पूर्णपणे पात्र वाक्यरचना वापरुन देखील म्हटले जाऊ शकते.
//! काही लोक पूर्णपणे पात्र वाक्यरचना वापरण्यास प्राधान्य देतात तर काही मेथड-कॉल सिंटॅक्स वापरण्यास प्राधान्य देतात.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // मेथड-कॉल सिंटॅक्स
//! let rc2 = rc.clone();
//! // पूर्णपणे पात्र वाक्यरचना
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] `T` चे स्वयं-डीरेफरन्स देत नाही, कारण आतील मूल्य आधीपासून सोडले गेले आहे.
//!
//! # क्लोनिंग संदर्भ
//!
//! अस्तित्वातील संदर्भ मोजले जाणारे सूचक म्हणून समान वाटपासाठी नवीन संदर्भ तयार करणे [`Rc<T>`][`Rc`] आणि [`Weak<T>`][`Weak`] साठी लागू केलेल्या `Clone` trait वापरुन केले जाते.
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // खाली दोन वाक्यरचना समतुल्य आहेत.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a आणि b दोन्ही foo सारख्या मेमरी स्थानाकडे निर्देश करतात.
//! ```
//!
//! `Rc::clone(&from)` वाक्यरचना हा सर्वात मुर्खपणाचा आहे कारण तो कोडचा अर्थ अधिक स्पष्टपणे प्रकट करतो.
//! वरील उदाहरणात, हा वाक्यरचना foo ची संपूर्ण सामग्री कॉपी करण्याऐवजी नवीन संदर्भ तयार करीत आहे हे पाहणे सोपे करते.
//!
//! # Examples
//!
//! ज्या परिस्थितीत Consider गॅझेट्सचा संच दिलेल्या `Owner` च्या मालकीचा आहे त्याचा विचार करा.
//! आम्हाला आमच्या `गॅझेटचे बिंदू त्यांच्या `Owner` वर द्यायचे आहेत.आम्ही हे अद्वितीय मालकीसह करू शकत नाही, कारण एकापेक्षा जास्त गॅझेट समान `Owner` चे असू शकतात.
//! [`Rc`] आम्हाला एकाधिक `गॅझेट्स दरम्यान `Owner` सामायिक करण्यास आणि `Owner` जोपर्यंत कोणत्याही `Gadget` बिंदूपर्यंत तो वाटप करण्यास परवानगी देतो.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... इतर फील्ड
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... इतर फील्ड
//! }
//!
//! fn main() {
//!     // संदर्भ-मोजलेली `Owner` तयार करा.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // `gadget_owner` चे `गॅझेट तयार करा.
//!     // `Rc<Owner>` क्लोनिंग केल्याने आम्हाला प्रक्रियेतील संदर्भ संख्या वाढवून त्याच `Owner` वाटपाला नवीन पॉईंटर मिळतो.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // आमच्या स्थानिक चल `gadget_owner` ची विल्हेवाट लावा.
//!     drop(gadget_owner);
//!
//!     // `gadget_owner` सोडत असूनही आम्ही अद्याप गॅझेटचे `Owner` चे नाव मुद्रित करण्यास सक्षम आहोत.
//!     // कारण आम्ही फक्त एकच `Rc<Owner>` सोडला आहे, तो निर्देशित केलेला X01 एक्स नाही.
//!     // जोपर्यंत अन्य `Rc<Owner>` समान `Owner` वाटपाकडे निर्देशित करीत आहेत तोपर्यंत तो थेट राहील.
//!     // फील्ड प्रोजेक्शन `gadget1.owner.name` कार्य करते कारण `Rc<Owner>` स्वयंचलितपणे `Owner` चा संदर्भ घेते.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // कार्याच्या शेवटी, `gadget1` आणि `gadget2` नष्ट होतात आणि त्यांच्यासह आमच्या `Owner` चे शेवटचे मोजलेले संदर्भ.
//!     // गॅझेट मॅन आता नष्ट होईल.
//!     //
//! }
//! ```
//!
//! जर आमच्या आवश्यकता बदलल्या आणि आम्हाला `Owner` ते `Gadget` पर्यंत देखील जाणे आवश्यक असेल तर आम्ही अडचणीत येऊ.
//! `Owner` ते `Gadget` पर्यंत [`Rc`] पॉइंटर एक चक्र समाविष्ट करतो.
//! याचा अर्थ असा की त्यांची संदर्भ संख्या कधीही 0 वर पोहोचू शकत नाही आणि वाटप कधीही नष्ट होणार नाही:
//! एक स्मृती गळतीहे जाणून घेण्यासाठी आम्ही [`Weak`] पॉईंटर्स वापरू शकतो.
//!
//! Rust प्रत्यक्षात प्रथम या लूपचे उत्पादन करणे काहीसे अवघड आहे.एकमेकांना दर्शविणार्‍या दोन मूल्यांचा शेवट करण्यासाठी, त्यापैकी एक बदलण्याजोगी आहे.
//! हे अवघड आहे कारण [`Rc`] केवळ लपेटलेल्या मूल्याबद्दल सामायिक संदर्भ देऊन स्मृती सुरक्षिततेची अंमलबजावणी करते आणि यामुळे थेट उत्परिवर्तन होऊ शकत नाही.
//! आम्हाला [`RefCell`] मध्ये बदलण्याची इच्छा असलेल्या मूल्याचा भाग लपेटणे आवश्यक आहे, जे *आंतरिक उत्परिवर्तन* प्रदान करते: सामायिक संदर्भाद्वारे उत्परिवर्तन प्राप्त करण्याची एक पद्धत.
//! [`RefCell`] रनटाइमवर झेडआरस्ट0 झेडच्या कर्जाचे नियम लागू करते.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... इतर फील्ड
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... इतर फील्ड
//! }
//!
//! fn main() {
//!     // संदर्भ-मोजलेली `Owner` तयार करा.
//!     // लक्षात घ्या की आम्ही `मालकाचे vector चे` गॅझेटचे `RefCell` मध्ये ठेवले जेणेकरुन आम्ही ते सामायिक केलेल्या संदर्भाद्वारे बदलू शकू.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // पूर्वीप्रमाणेच `gadget_owner` चे `गॅझेट तयार करा.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // त्यांच्या `Owner` मध्ये their गॅझेट जोडा.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` डायनॅमिक कर्ज येथे संपेल.
//!     }
//!
//!     // आमच्या `गॅझेटचे तपशील शोधा आणि मुद्रित करा.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` हे `Weak<Gadget>` आहे.
//!         // `Weak` पॉईंटर्स अद्यापही अस्तित्त्वात असलेल्या हमीची हमी देऊ शकत नसल्यामुळे, आम्हाला `upgrade` वर कॉल करणे आवश्यक आहे, जे एक्स 100 एक्स परत करते.
//!         //
//!         //
//!         // या प्रकरणात आम्हाला माहित आहे की stillलोकेशन अद्याप अस्तित्त्वात आहे, म्हणून आम्ही फक्त एक्स0 एक्स एक्स 100 एक्स.
//!         // अधिक क्लिष्ट प्रोग्राममध्ये आपल्याला कदाचित `None` निकालासाठी आकर्षक त्रुटी हाताळण्याची आवश्यकता असू शकेल.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // कार्याच्या शेवटी, `gadget_owner`, `gadget1` आणि `gadget2` नष्ट झाले.
//!     // गॅझेटसाठी आता कोणतेही मजबूत (`Rc`) पॉईंटर्स नाहीत, म्हणून ते नष्ट झाले आहेत.
//!     // हे गॅझेट मॅनवरील संदर्भ गणना शून्य करते, म्हणून त्याचा नाश देखील होतो.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// संभाव्य फील्ड-रर्डरिंग विरूद्ध हे एक्स 100 एक्स ते झेडफ्यूचर 0 झेड-प्रूफ आहे, जे ट्रान्समिटेबल आतील प्रकारांच्या सुरक्षित [into|from]_raw() मध्ये व्यत्यय आणेल.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// एकल-थ्रेडेड संदर्भ-मोजणी पॉईंटर 'Rc' म्हणजे 'संदर्भ
/// Counted'.
///
/// अधिक तपशीलांसाठी [module-level documentation](./index.html) पहा.
///
/// `Rc` च्या मूळ पद्धती सर्व संबंधित कार्ये आहेत, याचा अर्थ असा की आपण त्यांना उदा. `value.get_mut()` ऐवजी [`Rc::get_mut(&mut value)`][get_mut] म्हटले पाहिजे.
/// हे अंतर्गत प्रकारातील `T` च्या पद्धतींसह विवाद टाळते.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // हे असुरक्षितपणा ठीक आहे कारण हा आरसी जिवंत असतानाच आपल्यास खात्री आहे की अंतर्गत पॉईंटर वैध आहे.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// नवीन `Rc<T>` तयार करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // सर्व मजबूत पॉईंटर्सच्या मालकीचे एक अंतर्भूत कमकुवत पॉईंटर आहे, जे हे सुनिश्चित करते की कमकुवत पॉइंटर मजबूत संरक्षक आत चालू असतानाही कमकुवत विध्वंसक कधीही वाटप मुक्त करत नाही.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// स्वतःचा कमकुवत संदर्भ वापरुन नवीन `Rc<T>` तयार करते.
    /// हे कार्य परत येण्यापूर्वी कमकुवत संदर्भ श्रेणीसुधारित करण्याचा प्रयत्न केल्यास `None` मूल्य मिळेल.
    ///
    /// तथापि, कमकुवत संदर्भ नंतर मुक्तपणे क्लोन केला जाऊ शकतो आणि नंतर वापरासाठी संग्रहित केला जाऊ शकतो.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... अधिक फील्ड
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // एकल कमकुवत संदर्भासह "uninitialized" स्थितीत अंतर्गत बनवा.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // हे महत्त्वाचे आहे की आम्ही कमकुवत पॉइंटरची मालकी सोडत नाही, अन्यथा `data_fn` परत येईपर्यंत मेमरी मोकळी होऊ शकते.
        // आम्हाला खरोखर मालकी उत्तीर्ण व्हायची असेल तर आम्ही स्वतःसाठी एक अतिरिक्त कमकुवत पॉईंटर तयार करु शकू, परंतु यामुळे कमकुवत संदर्भ मोजणीत अतिरिक्त अद्यतने आढळू शकतात जी कदाचित अन्यथा आवश्यक नसतील.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // मजबूत संदर्भ एकत्रितपणे सामायिक कमकुवत संदर्भाचे मालक असले पाहिजेत, म्हणून आमच्या जुन्या कमकुवत संदर्भासाठी डिस्ट्रक्टर चालवू नका.
        //
        mem::forget(weak);
        strong
    }

    /// निर्विवाद सामग्रीसह एक नवीन `Rc` तयार करते.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // स्थगित आरंभ:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// `0` बाइट्सने मेमरी भरल्यामुळे, बिनविभाजित सामग्रीसह नवीन `Rc` तयार करते.
    ///
    ///
    /// या पद्धतीच्या अचूक आणि चुकीच्या वापराच्या उदाहरणांसाठी [`MaybeUninit::zeroed`][zeroed] पहा.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// नवीन `Rc<T>` तयार करते, वाटप अयशस्वी झाल्यास त्रुटी परत करते
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // सर्व मजबूत पॉईंटर्सच्या मालकीचे एक अंतर्भूत कमकुवत पॉईंटर आहे, जे हे सुनिश्चित करते की कमकुवत पॉइंटर मजबूत संरक्षक आत चालू असतानाही कमकुवत विध्वंसक कधीही वाटप मुक्त करत नाही.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// वाटप अयशस्वी झाल्यास त्रुटी परत करून, निर्विवाद सामग्रीसह एक नवीन एक्स00 एक्स तयार करते
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // स्थगित आरंभ:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// `0` बाइट्सने मेमरी भरल्यामुळे, निर्विवाद सामग्रीसह एक नवीन `Rc` तयार करते, वाटप अयशस्वी झाल्यास त्रुटी परत करते
    ///
    ///
    /// या पद्धतीच्या अचूक आणि चुकीच्या वापराच्या उदाहरणांसाठी [`MaybeUninit::zeroed`][zeroed] पहा.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// नवीन `Pin<Rc<T>>` तयार करते.
    /// जर `T` ने `Unpin` लागू केले नाही तर `value` मेमरीमध्ये पिन होईल आणि हलविण्यात अक्षम आहे.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// जर एक्स 100 एक्स मध्ये एक मजबूत संदर्भ असेल तर अंतर्गत मूल्य मिळवते.
    ///
    /// अन्यथा, आत गेलेल्या `Rc` सह [`Err`] परत केला जाईल.
    ///
    ///
    /// थकबाकीदार दुर्बल संदर्भ असूनही हे यशस्वी होईल.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // समाविष्ट ऑब्जेक्ट कॉपी करा

                // दुर्बल व्यक्तींना सूचित करा की त्यांची संख्या मजबूत करुन कमी होऊ शकत नाही आणि बनावट कमकुवत हस्तकला करून ड्रॉप लॉजिक हाताळताना अंतर्निहित एक्स00 एक्स पॉईंटर काढा.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// निर्विवाद सामग्रीसह एक नवीन संदर्भ-मोजलेली स्लाईस तयार करते.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // स्थगित आरंभ:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// `0` बाइटसह मेमरी भरल्या गेलेल्या, निर्विवाद सामग्रीसह एक नवीन संदर्भ-मोजलेली स्लाईस तयार करते.
    ///
    ///
    /// या पद्धतीच्या अचूक आणि चुकीच्या वापराच्या उदाहरणांसाठी [`MaybeUninit::zeroed`][zeroed] पहा.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// `Rc<T>` मध्ये रूपांतरित करते.
    ///
    /// # Safety
    ///
    /// एक्स 100 एक्स प्रमाणेच, आतील मूल्य खरोखर आरंभिक स्थितीत आहे याची हमी देणे कॉल करणार्‍यावर अवलंबून आहे.
    ///
    /// जेव्हा सामग्री अद्याप पूर्णपणे प्रारंभ केलेली नसते तेव्हा कॉल केल्यास तत्काळ अपरिभाषित वर्तन होते.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // स्थगित आरंभ:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// `Rc<[T]>` मध्ये रूपांतरित करते.
    ///
    /// # Safety
    ///
    /// एक्स 100 एक्स प्रमाणेच, आतील मूल्य खरोखर आरंभिक स्थितीत आहे याची हमी देणे कॉल करणार्‍यावर अवलंबून आहे.
    ///
    /// जेव्हा सामग्री अद्याप पूर्णपणे प्रारंभ केलेली नसते तेव्हा कॉल केल्यास तत्काळ अपरिभाषित वर्तन होते.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // स्थगित आरंभ:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// गुंडाळलेला पॉईंटर परत करून, `Rc` घेतो.
    ///
    /// मेमरी गळती टाळण्यासाठी पॉईंटरला [`Rc::from_raw`][from_raw] वापरून परत एक्स 0 एक्स मध्ये रुपांतरित करणे आवश्यक आहे.
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// डेटाला एक कच्चा सूचक प्रदान करते.
    ///
    /// गणना कोणत्याही प्रकारे प्रभावित होत नाहीत आणि `Rc` वापरली जात नाही.
    /// जोपर्यंत `Rc` मध्ये मजबूत संख्या आहेत तोपर्यंत पॉईंटर वैध आहे.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // सुरक्षितता: हे Deref::deref किंवा Rc::inner मध्ये जाऊ शकत नाही कारण
        // यासाठी एक्स. एक्स एक्स प्रोव्हान्सन्स ठेवणे आवश्यक आहे उदा
        // `get_mut` `from_raw` द्वारे आरसी पुनर्प्राप्त झाल्यानंतर पॉईंटरद्वारे लिहू शकता.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// कच्च्या पॉईंटरमधून एक `Rc<T>` तयार करते.
    ///
    /// कच्चा सूचक यापूर्वी [`Rc<U>::into_raw`][into_raw] वर कॉलद्वारे परत आला असावा जिथे `U` चा आकार आणि संरेखन `T` सारखे असणे आवश्यक आहे.
    /// `U` `T` असल्यास हे क्षुल्लकपणे सत्य आहे.
    /// लक्षात घ्या की जर `U` हे X01 एक्स नसले परंतु त्याचे आकार आणि संरेखन समान असेल तर हे मुळात वेगवेगळ्या प्रकारचे संदर्भ ट्रान्समिट करण्यासारखे आहे.
    /// या प्रकरणात कोणते प्रतिबंध लागू आहेत याविषयी अधिक माहितीसाठी [`mem::transmute`][transmute] पहा.
    ///
    /// `from_raw` च्या वापरकर्त्यास हे निश्चित केले पाहिजे की `T` चे विशिष्ट मूल्य फक्त एकदाच सोडले गेले आहे.
    ///
    /// हे कार्य असुरक्षित आहे कारण अयोग्य वापरामुळे मेमरी असुरक्षित होऊ शकते, जरी परत आलेल्या `Rc<T>` मध्ये कधीही प्रवेश केला नसला तरीही.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // गळती रोखण्यासाठी परत `Rc` मध्ये रुपांतरित करा.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Rc::from_raw(x_ptr)` चे पुढील कॉल मेमरी-असुरक्षित असतील.
    /// }
    ///
    /// // जेव्हा एक्स 100 एक्स वरील व्याप्तीच्या बाहेर गेला तेव्हा मेमरी मोकळी झाली, म्हणून आता एक्स 0 एक्स एक्स झुकत आहे!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // मूळ आरसीबॉक्स शोधण्यासाठी ऑफसेट उलट करा.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// या वाटपासाठी नवीन [`Weak`] पॉईंटर तयार करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // आम्ही एक डेंगलिंग कमकुवत तयार करत नाही हे सुनिश्चित करा
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// या वाटपासाठी [`Weak`] पॉइंटर्सची संख्या मिळते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// या वाटपासाठी मजबूत (`Rc`) पॉइंटर्सची संख्या मिळते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// या वाटपासाठी कोणतेही `Rc` किंवा [`Weak`] पॉईंटर्स नसल्यास `true` मिळवते.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// समान वाटप करण्यासाठी कोणतेही इतर `Rc` किंवा [`Weak`] पॉईंटर्स नसल्यास दिलेल्या `Rc` मध्ये एक बदलण्यायोग्य संदर्भ मिळवते.
    ///
    ///
    /// अन्यथा [`None`] मिळवते, कारण सामायिक केलेल्या मूल्याचे रुपांतरण करणे सुरक्षित नाही.
    ///
    /// [`make_mut`][make_mut] देखील पहा, जे इतर पॉईंटर्स असतात तेव्हा अंतर्गत मूल्य [`clone`][clone] करेल.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// कोणत्याही चेकशिवाय, दिलेल्या `Rc` मध्ये बदलणारा संदर्भ मिळवते.
    ///
    /// [`get_mut`] देखील पहा, जे सुरक्षित आहे आणि योग्य तपासणी करते.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// परत दिलेल्या कर्जाच्या कालावधीसाठी समान वाटपासाठी अन्य कोणतेही `Rc` किंवा [`Weak`] पॉईंटर्सचा आदर करणे आवश्यक नाही.
    ///
    /// असे कोणतेही पॉइंटर्स अस्तित्वात नसल्यास, क्षुल्लकदृष्ट्या असे आहे उदाहरणार्थ, एक्स00 एक्स नंतर लगेच.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // आम्ही "count" फील्ड्स कव्हर करणारा *संदर्भ* तयार करू नये याची खबरदारी घेत आहोत कारण हे संदर्भ मोजणीच्या प्रवेशासह विवादित असेल (उदा.
        // `Weak` द्वारा).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// जर दोन `आरसीने समान वाटपाकडे ([`ptr::eq`] सारख्या शिरामध्ये) सूचित केले तर `true` मिळवते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// दिलेल्या `Rc` मध्ये एक परिवर्तनीय संदर्भ बनविते.
    ///
    /// समान वाटपासाठी इतर `Rc` पॉईंटर्स असल्यास, नंतर अद्वितीय मालकी सुनिश्चित करण्यासाठी `make_mut` नवीन वाटपाचे अंतर्गत मूल्य [`clone`] करेल.
    /// याला क्लोन-ऑन-राइट असेही म्हणतात.
    ///
    /// या वाटपासाठी इतर कोणतेही `Rc` पॉईंटर्स नसल्यास, या वाटपाचे [`Weak`] पॉईंटर्स वेगळे केले जातील.
    ///
    /// [`get_mut`] देखील पहा, जे क्लोनिंग करण्याऐवजी अपयशी ठरेल.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // काहीही क्लोन करणार नाही
    /// let mut other_data = Rc::clone(&data);    // अंतर्गत डेटा क्लोन करणार नाही
    /// *Rc::make_mut(&mut data) += 1;        // क्लोन्स अंतर्गत डेटा
    /// *Rc::make_mut(&mut data) += 1;        // काहीही क्लोन करणार नाही
    /// *Rc::make_mut(&mut other_data) *= 2;  // काहीही क्लोन करणार नाही
    ///
    /// // आता `data` आणि `other_data` वेगवेगळ्या वाटपाकडे निर्देश करतात.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] पॉईंटर्स वेगळे केले जातील:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // डेटा क्लोन करणे आवश्यक आहे, तेथे इतर आरसीएस आहेत.
            // क्लोन केलेले मूल्य थेट लिहिण्याची परवानगी देण्यासाठी पूर्व-वाटप मेमरी.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // फक्त डेटा चोरू शकतो, उरलेलं सगळं
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // अंतर्भूत मजबूत-कमकुवत रेफ काढा (येथे बनावट दुर्बल शिल्प करण्याची आवश्यकता नाही-आम्हाला माहित आहे की इतर कमकुवत आमच्यासाठी साफ करू शकतात)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // हे असुरक्षित आहे कारण आम्हाला खात्री आहे की पॉईंटर परत आला *फक्त* पॉईंटर जो कधीही टी वर परत जाईल.
        // आमची संदर्भ संख्या या टप्प्यावर 1 ची हमी आहे आणि आम्ही स्वतः `Rc<T>` देखील `mut` असणे आवश्यक आहे, म्हणून आम्ही वाटपाचा एकमेव संभाव्य संदर्भ परत करत आहोत.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// कॉंक्रिट प्रकारात एक्स 100 एक्स डाउनकास्ट करण्याचा प्रयत्न.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// संभाव्य-आकार नसलेल्या अंतर्गत मूल्यासाठी जेथे लेआउट प्रदान केले आहे तेथे पुरेशी जागा असलेल्या `RcBox<T>` चे वाटप करते.
    ///
    /// `mem_to_rcbox` फंक्शनला डेटा पॉईंटरसह म्हटले जाते आणि `RcBox<T>` साठी (संभाव्य चरबी)-पॉईंटर परत करणे आवश्यक आहे.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // दिलेल्या मूल्याच्या लेआउटचा वापर करुन लेआउटची गणना करा.
        // पूर्वी एक्सआॅक्सएक्सएक्सएक्सएक्सन वर लेआउटची गणना केली जात होती, परंतु यामुळे चुकीचा सही संदर्भ तयार केला गेला (#54908 पहा).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// संभाव्यत-आकार नसलेल्या आतील मूल्यासाठी पुरेशा जागेसह एक X00 एक्सचे वाटप करते जेथे मूल्य दिले आहे लेआउट प्रदान केले आहे, वाटप अयशस्वी झाल्यास त्रुटी परत करेल.
    ///
    ///
    /// `mem_to_rcbox` फंक्शनला डेटा पॉईंटरसह म्हटले जाते आणि `RcBox<T>` साठी (संभाव्य चरबी)-पॉईंटर परत करणे आवश्यक आहे.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // दिलेल्या मूल्याच्या लेआउटचा वापर करुन लेआउटची गणना करा.
        // पूर्वी एक्सआॅक्सएक्सएक्सएक्सएक्सन वर लेआउटची गणना केली जात होती, परंतु यामुळे चुकीचा सही संदर्भ तयार केला गेला (#54908 पहा).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // लेआउटसाठी वाटप करा.
        let ptr = allocate(layout)?;

        // आरसीबॉक्स प्रारंभ करा
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// आकार नसलेल्या अंतर्गत मूल्यासाठी पुरेशी जागा असलेले `RcBox<T>` चे वाटप करते
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // दिलेली व्हॅल्यू वापरुन एक्स00 एक्ससाठी वाटप करा.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // बाइट्स म्हणून मूल्य कॉपी करा
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Contentsलोकेशनची सामग्री न सोडता मोकळी करा
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// दिलेल्या लांबीसह एक `RcBox<[T]>` वाटप करते.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// नव्याने वाटप केलेल्या आरसी <\[टी\]> मध्ये स्लाइसमधून घटक कॉपी करा
    ///
    /// असुरक्षित आहे कारण कॉलरने एकतर मालकी घेणे आवश्यक आहे किंवा `T: Copy` प्रतिबद्ध करणे आवश्यक आहे
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// एका विशिष्ट आकाराचे ज्ञात असलेल्या इटरेटरकडून एक `Rc<[T]>` तयार करते.
    ///
    /// आकार चुकीचा असेल तर वर्तणूक अपरिभाषित आहे.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // टी घटकांची क्लोनिंग करत असताना झेडपॅनिक ० झेड गार्ड.
        // झेडस्पॅनिक0झेडच्या घटनेत, नवीन आरसीबॉक्समध्ये लिहिलेले घटक सोडले जातील, त्यानंतर मेमरी मुक्त होईल.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // प्रथम घटकाकडे निर्देशक
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // सर्व स्पष्ट.गार्डला विसरा जेणेकरून नवीन आरसीबॉक्स मुक्त होणार नाही.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` साठी वापरलेली विशेषीकरण trait.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// एक्स 100 एक्स ड्रॉप.
    ///
    /// यामुळे दृढ संदर्भ संख्या कमी होईल.
    /// जर सशक्त संदर्भ संख्या शून्यापर्यंत पोहोचली तर केवळ इतर संदर्भ (काही असल्यास) [`Weak`] आहेत, म्हणून आम्ही अंतर्गत मूल्य `drop` करतो.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // काहीही छापत नाही
    /// drop(foo2);   // "dropped!" मुद्रित करते
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // समाविष्ट ऑब्जेक्ट नष्ट
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // आम्ही आशय नष्ट केल्यामुळे आत्ता असलेले एक्स X एक्स पॉईंटर काढा.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// `Rc` पॉईंटरचा क्लोन बनवते.
    ///
    /// हे त्याच संदर्भात आणखी एक पॉईंटर तयार करते, मजबूत संदर्भ संख्या वाढवते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// `T` साठी `Default` मूल्यासह एक नवीन `Rc<T>` तयार करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// `Eq` मध्ये एक पद्धत असूनही `Eq` वर विशेषज्ञता आणण्यासाठी खाच.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// आम्ही हे स्पेशलायझेशन येथे करत आहोत, आणि एक्स 100 एक्स वर अधिक सामान्य ऑप्टिमायझेशन म्हणून नाही, कारण रेफवरील सर्व समानता तपासणीसाठी हे अन्यथा खर्च करेल.
/// आम्ही गृहित धरतो की `आरसीचा वापर मोठ्या मूल्यांच्या संचयित करण्यासाठी केला जातो, जो क्लोन करणे कमी आहे, परंतु समानता तपासण्यासाठी देखील भारी आहे, ज्यामुळे ही किंमत अधिक सहजतेने चुकते.
///
/// दोन एक्स 100 एक्स क्लोन असण्याचीही शक्यता आहे, ती समान मूल्याकडे दोन two&टीपेक्षा जास्त आहे.
///
/// आम्ही हे तेव्हाच करू शकतो जेव्हा `T: Eq` एक X01 एक्स म्हणून मुद्दाम इराफॅक्सिव्ह असू शकेल.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// दोन `आरसीसाठी समानता.
    ///
    /// दोन inner आरसी समान आहेत जर त्यांची अंतर्गत मूल्ये समान असतील, जरी ती वेगवेगळ्या ationलोकेशनमध्ये संग्रहित आहेत.
    ///
    /// जर `T` देखील `Eq` (समानतेची प्रतिक्षिप्तता) अंमलात आणत असेल तर, समान वाटपाकडे निर्देशित करणारे दोन `आरसी नेहमी समान असतात.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// दोन `आरसीसाठी असमानता.
    ///
    /// जर त्यांची अंतर्गत मूल्ये असमान असतील तर दोन आरसी असमान असतात.
    ///
    /// जर `T` देखील `Eq` (समानतेची प्रतिक्षिप्तता) ची अंमलबजावणी करीत असेल तर, समान वाटपाकडे निर्देश करणारे दोन `आरसी कधीही असमान नसतात.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// दोन `आरसीसाठी आंशिक तुलना.
    ///
    /// त्यांच्या अंतर्गत मूल्यांवर `partial_cmp()` कॉल करून या दोघांची तुलना केली जाते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// दोन `आरसीसाठी तुलना पेक्षा कमी.
    ///
    /// त्यांच्या अंतर्गत मूल्यांवर `<` कॉल करून या दोघांची तुलना केली जाते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// दोन `आरसीची तुलना 'पेक्षा कमी किंवा समान'.
    ///
    /// त्यांच्या अंतर्गत मूल्यांवर `<=` कॉल करून या दोघांची तुलना केली जाते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// दोन `आरसीसाठी मोठी-तुलना.
    ///
    /// त्यांच्या अंतर्गत मूल्यांवर `>` कॉल करून या दोघांची तुलना केली जाते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// दोन `आरसीची तुलना 'पेक्षा मोठी किंवा समान'.
    ///
    /// त्यांच्या अंतर्गत मूल्यांवर `>=` कॉल करून या दोघांची तुलना केली जाते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// दोन `आरसीसाठी तुलना.
    ///
    /// त्यांच्या अंतर्गत मूल्यांवर `cmp()` कॉल करून या दोघांची तुलना केली जाते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// संदर्भ-मोजलेल्या स्लाइसचे वाटप करा आणि cl v` च्या आयटम क्लोनिंग करुन भरा.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// संदर्भ-मोजलेल्या स्ट्रिंग स्लाइसचे वाटप करा आणि त्यामध्ये `v` कॉपी करा.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// संदर्भ-मोजलेल्या स्ट्रिंग स्लाइसचे वाटप करा आणि त्यामध्ये `v` कॉपी करा.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// बॉक्स केलेल्या ऑब्जेक्टला नवीन, संदर्भ मोजलेल्या, वाटपावर हलवा.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// संदर्भ-मोजलेली स्लाइस वाटप करा आणि त्यामध्ये आयटम हलवा.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // वेकला त्याची मेमरी मोकळी करण्यास परवानगी द्या परंतु त्यातील सामग्री नष्ट करू नका
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// प्रत्येक घटक `Iterator` मध्ये घेते आणि ते `Rc<[T]>` मध्ये संकलित करते.
    ///
    /// # कामगिरी वैशिष्ट्ये
    ///
    /// ## सामान्य प्रकरण
    ///
    /// सामान्य प्रकरणात, `Rc<[T]>` मध्ये संग्रह प्रथम `Vec<T>` मध्ये गोळा करून केले जाते.ते आहे की, पुढील गोष्टी लिहितानाः
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// आम्ही लिहिल्याप्रमाणे असे वागते:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // वाटपांचा पहिला सेट येथे होतो.
    ///     .into(); // `Rc<[T]>` चे दुसरे वाटप येथे होते.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// हे `Vec<T>` तयार करण्यासाठी आवश्यक तेवढे वेळा वाटप करेल आणि नंतर ते X02 एक्सला `Rc<[T]>` मध्ये बदलण्यासाठी एकदा वाटप करेल.
    ///
    ///
    /// ## ज्ञात लांबीचे आयटेटर
    ///
    /// जेव्हा आपल्या `Iterator` ने `TrustedLen` लागू केली आणि अचूक आकाराचे असेल तेव्हा, `Rc<[T]>` साठी एकल वाटप केले जाईल.उदाहरणार्थ:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // येथे फक्त एक वाटप होते.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// एक्स 100 एक्स मध्ये गोळा करण्यासाठी वापरले स्पेशलायझेशन झेडट्रायट 0 झेड.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // हे एक एक्स 100 एक्स इटरेटरसाठी आहे.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // सुरक्षितता: आम्हाला हे सुनिश्चित करण्याची आवश्यकता आहे की पुनरावृत्ती करणार्‍याची लांबी अचूक आहे आणि आपल्याकडे आहे.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // सामान्य अंमलबजावणीकडे परत जा.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` [`Rc`] ची एक आवृत्ती आहे ज्यात व्यवस्थापित वाटपाचा मालकीचा नसलेला संदर्भ आहे.`Weak` पॉईंटरवर [`upgrade`] ला कॉल करून वाटप प्रवेश केला जातो, जो [`पर्याय`] returns <`[`आरसी`] returns परत करतो<T>>`.
///
/// `Weak` संदर्भ मालकीकडे मोजत नसल्यामुळे, तो वाटप मध्ये संग्रहित मूल्य सोडण्यापासून प्रतिबंधित करणार नाही आणि स्वतः एक्स 0 एक्स एक्स अजूनही मूल्य असलेल्या अस्तित्वाची हमी देत नाही.
/// जेव्हा [`अपग्रेड`] डी. तेव्हा ते [`None`] परत येऊ शकते.
/// तथापि हे लक्षात घ्या की एक `Weak` संदर्भ *करतो* स्वत: चे वाटप (बॅकिंग स्टोअर) विपुल होण्यापासून प्रतिबंधित करतो.
///
/// एक `Weak` पॉईंटर [`Rc`] द्वारे व्यवस्थापित केलेल्या वाटपाचा तात्पुरता संदर्भ ठेवण्यासाठी उपयुक्त आहे कारण त्याचे अंतर्गत मूल्य खाली न येण्यापासून प्रतिबंधित करते.
/// हे [`Rc`] पॉइंटर्स दरम्यान परिपत्रक संदर्भ रोखण्यासाठी देखील वापरले जाते कारण परस्पर मालकीचे संदर्भ [`Rc`] कधीही सोडत नाहीत.
/// उदाहरणार्थ, एका झाडामध्ये पालकांकरिता नोडस् कडून [`Rc`] पॉईंटर्स आणि मुलांपासून त्यांच्या पालकांकडे `Weak` पॉईंटर्स असू शकतात.
///
/// `Weak` पॉईंटर मिळविण्यासाठीचा सामान्य मार्ग म्हणजे [`Rc::downgrade`] वर कॉल करणे.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Enums मध्ये या प्रकारच्या आकारास अनुकूलित करण्यासाठी हे एक `NonNull` आहे, परंतु हे वैध पॉईंटर असणे आवश्यक नाही.
    //
    // `Weak::new` हे `usize::MAX` वर सेट करते जेणेकरून ढीगवर जागा वाटपाची आवश्यकता नाही.
    // वास्तविक पॉईंटरला असलेले हे मूल्य नाही कारण आरसीबॉक्सचे संरेखन किमान 2 आहे.
    // हे तेव्हाच शक्य आहे जेव्हा एक्स 100 एक्स;आकार नसलेली `T` कधीही डँगल नका.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// कोणतीही मेमरी वाटप न करता नवीन `Weak<T>` तयार करते.
    /// परतीच्या मूल्यावर [`upgrade`] वर कॉल करणे नेहमी [`None`] देते.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// डेटा फील्डबद्दल कोणतेही ठाम मत न घेता संदर्भ गणनांमध्ये प्रवेश करण्यास अनुमती देणारा मदतनीस प्रकार.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// या `Weak<T>` द्वारे दर्शविलेल्या ऑब्जेक्ट `T` वर एक कच्चा सूचक मिळवते.
    ///
    /// काही मजबूत संदर्भ असल्यासच पॉईंटर वैध असते.
    /// पॉईंटर अन्यत्र अन्यथा, डेंगलिंग, अस्वाक्षरीकृत किंवा अगदी [`null`] देखील असू शकतो.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // दोन्ही एकाच वस्तूकडे निर्देश करतात
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // येथे मजबूत तो जिवंत ठेवतो, म्हणून आम्ही अद्याप त्या ऑब्जेक्टमध्ये प्रवेश करू शकतो.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // पण आता नाही.
    /// // आम्ही weak.as_ptr() करू शकतो, परंतु पॉईंटरमध्ये प्रवेश केल्याने अपरिभाषित वर्तन होते.
    /// // assert_eq! ("हॅलो", असुरक्षित {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // पॉईंटर डेंगिंग होत असल्यास आम्ही सेन्टिनल थेट परत करतो.
            // हा वैध पेलोड पत्ता असू शकत नाही कारण पेलोड किमान आरसीबॉक्स एक्स00 एक्स म्हणून संरेखित केलेला आहे.
            ptr as *const T
        } else {
            // सुरक्षाः जर is_dangling चुकीचे परत आले तर पॉइंटर डीरेफरेन्सेबल आहे.
            // पेलोड या टप्प्यावर सोडले जाऊ शकते आणि आम्हाला प्रोव्हन्सन्स राखणे आवश्यक आहे, म्हणून कच्चे पॉइंटर हाताळणे वापरा.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// `Weak<T>` घेते आणि त्यास कच्च्या पॉइंटरमध्ये बदलते.
    ///
    /// हे एक कमकुवत संदर्भ मालकीचे जतन करीत असताना दुर्बल पॉईंटरला कच्च्या पॉइंटरमध्ये रुपांतरित करते (कमकुवत गणना या ऑपरेशनद्वारे सुधारित केली जात नाही).
    /// हे परत [`from_raw`] सह `Weak<T>` मध्ये बदलले जाऊ शकते.
    ///
    /// [`as_ptr`] प्रमाणे पॉईंटरच्या लक्ष्यावर प्रवेश करण्याच्या समान निर्बंध लागू आहेत.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// पूर्वी [`into_raw`] द्वारे निर्मित कच्चा पॉइंटर परत `Weak<T>` मध्ये रूपांतरित करते.
    ///
    /// याचा सुरक्षितपणे एक मजबूत संदर्भ मिळविण्यासाठी (नंतर X01 एक्स वर कॉल करून) किंवा `Weak<T>` टाकून कमकुवत मोजणी कमी करण्यासाठी वापरले जाऊ शकते.
    ///
    /// हे एका कमकुवत संदर्भाची मालकी घेते ([`new`] ने निर्मित पॉईंटर्सचा अपवाद वगळता, या कशाचेही मालक नसतात; तरीही पद्धत त्यांच्यावर कार्य करते).
    ///
    /// # Safety
    ///
    /// पॉईंटर [`into_raw`] मधील मूळ असावा आणि अद्याप त्याच्या संभाव्य कमकुवत संदर्भाचे मालक असले पाहिजेत.
    ///
    /// हे कॉल करण्याच्या वेळी सशक्त मोजणी 0 असणे अनुमत आहे.
    /// तथापि, हे सध्या कच्चे पॉइंटर म्हणून दर्शविलेल्या एका कमकुवत संदर्भाची मालकी घेते (कमकुवत गणना या ऑपरेशनद्वारे सुधारित केलेली नाही) आणि म्हणूनच ती एक्स 100 एक्स वर मागील कॉलसह जोडली जाणे आवश्यक आहे.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // शेवटची कमकुवत गणना कमी करा.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // इनपुट पॉईंटर कसे प्राप्त होते या संदर्भात Weak::as_ptr पहा.

        let ptr = if is_dangling(ptr as *mut T) {
            // ही एक लहरी कमकुवत आहे.
            ptr as *mut RcBox<T>
        } else {
            // अन्यथा, आम्ही हमी देतो की पॉईंटर एका अशक्त कमकुवतपणाकडून आला आहे.
            // सुरक्षा: डेटा_ऑफसेट कॉल करणे सुरक्षित आहे, कारण पीटीआरचा संदर्भ वास्तविक (संभाव्यत: सोडलेला) टी.
            let offset = unsafe { data_offset(ptr) };
            // अशाप्रकारे, संपूर्ण आरसीबॉक्स मिळविण्यासाठी आम्ही ऑफसेटला उलट करतो.
            // सुरक्षितता: पॉईंटर दुर्बल पासून उत्पन्न झाले आहे, म्हणूनच हे ऑफसेट सुरक्षित आहे.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // सुरक्षितता: आम्ही आता मूळ कमकुवत पॉइंटर पुनर्प्राप्त केला आहे, त्यामुळे दुर्बल तयार करू शकतो.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// `Weak` पॉईंटरला [`Rc`] वर श्रेणीसुधारित करण्याचा प्रयत्न, यशस्वी झाल्यास अंतर्गत मूल्य सोडण्यास विलंब.
    ///
    ///
    /// आतील मूल्य नंतरपासून सोडल्यास [`None`] मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // सर्व मजबूत पॉईंटर्स नष्ट करा.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// या ationलोकेशनकडे निर्देश करणार्‍या सशक्त (`Rc`) पॉइंटर्सची संख्या मिळते.
    ///
    /// जर `self` हे [`Weak::new`] वापरून तयार केले गेले असेल तर ते 0 येईल.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// या ationलोकेशनकडे निर्देशित केलेल्या `Weak` पॉईंटर्सची संख्या मिळते.
    ///
    /// कोणतेही मजबूत पॉइंटर्स राहिले नाहीत तर ते शून्य परत येईल.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // अप्रत्यक्ष कमकुवत पीटीआर वजा करा
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// पॉईंटर डेंग होत असताना X01 एक्स मिळवते आणि तेथे कोणतेही `RcBox` वाटप केलेले नाही, (म्हणजे जेव्हा हे `Weak` `Weak::new` द्वारे तयार केले गेले होते).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // आम्ही एक्सएक्सएक्स एक्स फील्डला कव्हर करणारा *संदर्भ* तयार करू नये याची खबरदारी घेत आहोत, कारण हे फील्ड एकाचवेळी बदलले जाऊ शकते (उदाहरणार्थ, शेवटचा एक्स ०१ एक्स सोडल्यास डेटा फील्ड जागी सोडली जाईल).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// जर दोन `दुर्बलांचे समान वाटप ([`ptr::eq`] प्रमाणेच) वर निर्देशित केले तर किंवा दोन्ही कोणत्याही वितरणास सूचित करीत नसल्यास `true` मिळविते (कारण ते `Weak::new()`) सह तयार केले गेले होते).
    ///
    ///
    /// # Notes
    ///
    /// हे पॉईंटर्सची तुलना करत असल्याने याचा अर्थ असा की `Weak::new()` एकमेकांच्या बरोबरी करेल, जरी त्यांनी कोणत्याही वाटपाकडे लक्ष दिले नाही.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// तुलना करीत आहे `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` पॉईंटर ड्रॉप करा.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // काहीही छापत नाही
    /// drop(foo);        // "dropped!" मुद्रित करते
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // कमकुवत गणना 1 पासून सुरू होते आणि सर्व मजबूत पॉइंटर्स अदृश्य झाल्यास केवळ शून्यावर जाईल.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// त्याच वाटपाकडे निर्देशित करणारा `Weak` पॉईंटरचा क्लोन बनवितो.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// नवीन `Weak<T>` तयार करते, प्रारंभ न करता `T` साठी मेमरीचे वाटप करते.
    /// परतीच्या मूल्यावर [`upgrade`] वर कॉल करणे नेहमी [`None`] देते.
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: आम्ही mem::forget सुरक्षितपणे सामोरे जाण्यासाठी येथे_आड केले.विशेषतः
// आपण mem::forget आरसीएस (किंवा कमकुवत) असल्यास, रेफ-काउंट ओव्हरफ्लो होऊ शकते आणि नंतर थकबाकी आरसीएस (किंवा कमकुवत) अस्तित्वात असताना आपण वाटप मुक्त करू शकता.
//
// आम्ही गर्भपात करतो कारण हा असा अधोगती पडलेला देखावा आहे की आपल्याला काय होईल याची पर्वा नाही-कोणत्याही वास्तविक कार्यक्रमाचा अनुभव यापूर्वी येऊ नये.
//
// आपणास मालकी आणि हालचाली-अर्थविस्त्राबद्दल धन्यवाद Rust मध्ये हे खरोखर क्लोन करण्याची आवश्यकता नसल्यामुळे याकडे नगण्य ओव्हरहेड असावे.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // आम्हाला व्हॅल्यू टाकण्याऐवजी ओव्हरफ्लो वर थांबवायचे आहे.
        // जेव्हा हे म्हटले जाते तेव्हा संदर्भ गणना कधीही शून्य होणार नाही;
        // असे असले तरी, आम्ही एलएलव्हीएमला चुकवल्या गेलेल्या ऑप्टिमायझेशनवर इशारा देण्यासाठी येथे गर्भपात घालतो.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // आम्हाला व्हॅल्यू टाकण्याऐवजी ओव्हरफ्लो वर थांबवायचे आहे.
        // जेव्हा हे म्हटले जाते तेव्हा संदर्भ गणना कधीही शून्य होणार नाही;
        // असे असले तरी, आम्ही एलएलव्हीएमला चुकवल्या गेलेल्या ऑप्टिमायझेशनवर इशारा देण्यासाठी येथे गर्भपात घालतो.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// पॉईंटरच्या मागे असलेल्या पेलोडसाठी `RcBox` मध्ये ऑफसेट मिळवा.
///
/// # Safety
///
/// पॉईंटरने टीचे पूर्वीचे वैध उदाहरण दर्शविले पाहिजे (आणि यासाठी वैध मेटाडेटा असणे आवश्यक आहे), परंतु टी सोडण्याची परवानगी नाही.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // आरसीबॉक्सच्या शेवटी असुरक्षित मूल्य संरेखित करा.
    // कारण आरसीबॉक्स हे एक्स 100 एक्स आहे, ते नेहमीच मेमरीमधील शेवटचे फील्ड असेल.
    // सुरक्षितता: केवळ आकार नसलेले प्रकार म्हणजे काप, झेडट्रायट0 झेड ऑब्जेक्ट्स,
    // आणि बाह्य प्रकारांनुसार, align_of_val_raw च्या आवश्यकता पूर्ण करण्यासाठी इनपुट सुरक्षा आवश्यकता सध्या पुरेसे आहे;हे भाषेचे अंमलबजावणी तपशील आहे जे std च्या बाहेर अवलंबून राहू शकत नाही.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}