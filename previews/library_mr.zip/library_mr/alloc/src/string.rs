//! एक यूटीएफ-8 - एन्कोड, वाढण्यायोग्य स्ट्रिंग.
//!
//! या मॉड्यूलमध्ये तारांमध्ये रूपांतरित करण्यासाठी [`String`] प्रकार, [`ToString`] trait आणि [`स्ट्रिंग`] चे कार्य केल्यामुळे होऊ शकणारे अनेक त्रुटी प्रकार आहेत.
//!
//!
//! # Examples
//!
//! अक्षरशः नवीन [`String`] तयार करण्याचे अनेक मार्ग आहेत:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! आपण विद्यमान असलेल्यासह जुळवून नवीन एक्स 100 एक्स तयार करू शकता
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! आपल्याकडे वैध UTF-8 बाइटचे झेडवेवेक्टर0 झेड असल्यास आपण त्यातून एक्स01 एक्स बनवू शकता.आपण उलट देखील करू शकता.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // आम्हाला माहित आहे की हे बाइट वैध आहेत, म्हणून आम्ही `unwrap()` वापरू.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// एक यूटीएफ-8 - एन्कोड, वाढण्यायोग्य स्ट्रिंग.
///
/// एक्स ०१ एक्स प्रकार हा सर्वात सामान्य स्ट्रिंग प्रकार आहे ज्याची स्ट्रिंगमधील सामग्रीवर मालकी आहे.त्याचे कर्ज घेणार्‍या प्रतिभाचा, आदिम [`str`] सह जवळचा संबंध आहे.
///
/// # Examples
///
/// आपण [a literal string][`str`] वरून [`String::from`] सह एक `String` तयार करू शकता:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// आपण [`push`] पद्धतीने `String` वर एक [`char`] जोडू शकता आणि [`push_str`] पद्धतीने [`&str`] जोडू शकता:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// आपल्याकडे UTF-8 बाइटचे झेडवेक्टर 0 झेड असल्यास आपण त्यावरून एक्स0 2 एक्स पद्धतीने एक एक्स 0 एक्स एक्स तयार करू शकताः
///
/// ```
/// // vector मध्ये काही बाइट
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // आम्हाला माहित आहे की हे बाइट वैध आहेत, म्हणून आम्ही `unwrap()` वापरू.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `स्ट्रिंग्ज नेहमी वैध UTF-8 असतात.यात काही परिणाम आहेत, त्यातील प्रथम म्हणजे जर आपल्याला नॉन-यूटीएफ-8 स्ट्रिंगची आवश्यकता असेल तर एक्स0 2 एक्सचा विचार करा.हे समान आहे, परंतु UTF-8 मर्यादेशिवाय.दुसरा अर्थ असा आहे की आपण `String` मध्ये अनुक्रमित करू शकत नाही:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// अनुक्रमणिका हा सतत-वेळ ऑपरेशन करण्याचा हेतू आहे, परंतु UTF-8 एन्कोडिंग आम्हाला हे करण्यास अनुमती देत नाही.या व्यतिरिक्त, निर्देशांक कोणत्या प्रकारची परत येईल हे स्पष्ट नाही: बाइट, कोडपॉईंट किंवा ग्रॅफाइम क्लस्टर.
/// [`bytes`] आणि [`chars`] पद्धती अनुक्रमे पहिल्या दोनपेक्षा पुनरावृत्ती करतात.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// Implement स्ट्रिंग्जची अंमलबजावणी [`डेरेफ]`<Target=str>., आणि म्हणून [`str`] च्या सर्व पद्धतींचा वारसा मिळवा.याव्यतिरिक्त, याचा अर्थ असा की आपण एम्परसँड (`&`) चा वापर करून [`&str`] घेणार्‍या एखाद्या कार्यामध्ये `String` पाठवू शकता:
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// हे `String` वरून एक [`&str`] तयार करेल आणि त्यात प्रवेश करेल. हे रूपांतरण खूप स्वस्त आहे आणि म्हणूनच काही विशिष्ट कारणास्तव त्यांना `String` आवश्यक नसल्यास कार्ये [`&str`] ला वितर्क म्हणून स्वीकारतील.
///
/// काही प्रकरणांमध्ये झेडआरस्ट ० झेडकडे हे रूपांतरण करण्यासाठी पुरेशी माहिती नाही, ज्याला एक्स ०१ एक्स जबरदस्ती म्हणून ओळखले जाते.खालील उदाहरणात स्ट्रिंग स्लाइस [`&'a str`][`&str`] trait `TraitExample` लागू करते आणि `example_func` फंक्शन trait ची अंमलबजावणी करणारे काहीही घेते.
/// या प्रकरणात झेड रस्ट ० झेडला दोन अंतर्निहित रूपांतरणे आवश्यक आहेत, जी झेड रस्ट ० झेडकडे करण्याचे कोणतेही साधन नाही.
/// त्या कारणास्तव, खालील उदाहरण संकलित करणार नाही.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// त्याऐवजी दोन पर्याय आहेत.प्रथम `example_func(&example_string);` ही ओळ `example_func(example_string.as_str());` वर बदलणे, [`as_str()`] पद्धत वापरुन स्ट्रिंग असलेली स्ट्रिंग स्लाइस स्पष्टपणे काढू शकता.
/// दुसरा मार्ग `example_func(&example_string);` ला `example_func(&*example_string);` मध्ये बदलतो.
/// या प्रकरणात आम्ही एक X02 एक्सला [`str`][`&str`] चे संदर्भ देत आहोत, त्यानंतर एक्स03 एक्सचा संदर्भ परत एक्स 100 एक्स वर द्या.
/// दुसरा मार्ग अधिक मुर्खपणाचा आहे, तथापि दोन्ही अंतर्भूत रूपांतरणावर अवलंबून न राहता स्पष्टपणे रूपांतरण करण्याचे कार्य करतात.
///
/// # Representation
///
/// एक्स एक्स एक्स तीन घटकांनी बनलेला आहेः काही बाइट्स, पॉईंट, लांबी आणि क्षमता.पॉईंटर त्याचा डेटा संचयित करण्यासाठी अंतर्गत बफर `String` वर निर्देशित करते.लांबी सध्या बफरमध्ये संचयित केलेल्या बाइटची संख्या आहे आणि क्षमता बाइट्समधील बफरची आकार आहे.
///
/// जसे की, लांबी नेहमीच क्षमतेपेक्षा कमी किंवा समान असेल.
///
/// हा बफर नेहमी ढीगवर ठेवला जातो.
///
/// आपण यास [`as_ptr`], [`len`] आणि [`capacity`] पद्धतींनी पाहू शकता:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FCXME vec_into_raw_parts स्थीर झाल्यावर हे अद्यतनित करा.
/// // स्ट्रिंगचा डेटा आपोआप सोडण्यापासून प्रतिबंधित करा
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // कथेला एकोणीस बाइट्स आहेत
/// assert_eq!(19, len);
///
/// // आम्ही पीटीआर, लेन आणि क्षमता बाहेर स्ट्रिंग पुन्हा बनवू शकतो.
/// // हे सर्व असुरक्षित आहे कारण घटक वैध असल्याची खात्री करण्यासाठी आम्ही जबाबदार आहोत:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// जर `String` मध्ये पुरेशी क्षमता असेल तर त्यामध्ये घटक जोडणे पुन्हा वाटप केले जाणार नाही.उदाहरणार्थ, या प्रोग्रामचा विचार करा:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// हे खालील आउटपुट देईल:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// सुरुवातीला आपल्याकडे कोणतीही मेमरी वाटली जात नाही, परंतु जसे आपण स्ट्रिंगमध्ये जोडत आहोत, ते योग्यरित्या त्याची क्षमता वाढवते.सुरुवातीस योग्य क्षमताचे वाटप करण्यासाठी आम्ही त्याऐवजी [`with_capacity`] पद्धत वापरल्यास:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// आम्ही भिन्न आउटपुटसह संपतो:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// येथे लूपमध्ये अधिक मेमरी वाटप करण्याची आवश्यकता नाही.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// UTF-8 बाइट vector वरून `String` रूपांतरित करताना संभाव्य त्रुटी मूल्य.
///
/// हा प्रकार [`String`] वरील [`from_utf8`] पद्धतीचा त्रुटी प्रकार आहे.
/// हे पुन्हा काळजीपूर्वक टाळण्यासाठी अशा प्रकारे तयार केले गेले आहे: एक्स 100 एक्स पद्धत रूपांतरण प्रयत्नात वापरली गेलेली बाइट vector परत देईल.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// [`std::str`] द्वारे प्रदान केलेला [`Utf8Error`] प्रकार त्रुटी दर्शवितो जो [`u8`] च्या तुकड्याला [`&str`] मध्ये रूपांतरित करताना उद्भवू शकते.
/// या अर्थाने, हे `FromUtf8Error` चे एक समानता आहे आणि आपण [`utf8_error`] पद्धतीने `FromUtf8Error` वरून एक मिळवू शकता.
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// मूलभूत वापर:
///
/// ```
/// // vector मध्ये काही अवैध बाइट
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// UTF-16 बाइट स्लाइसमधून `String` रूपांतरित करताना संभाव्य त्रुटी मूल्य.
///
/// हा प्रकार [`String`] वरील [`from_utf16`] पद्धतीचा त्रुटी प्रकार आहे.
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// मूलभूत वापर:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// नवीन रिक्त `String` तयार करते.
    ///
    /// हे दिले की `String` रिक्त आहे, हे कोणत्याही प्रारंभिक बफरचे वाटप करणार नाही.याचा अर्थ असा की हे प्रारंभिक ऑपरेशन खूप स्वस्त आहे, परंतु जेव्हा आपण डेटा जोडता तेव्हा जास्त प्रमाणात वाटप होऊ शकते.
    ///
    /// आपल्याकडे `String` किती डेटा ठेवेल याची कल्पना असल्यास, अत्यधिक पुनर्-वाटप टाळण्यासाठी [`with_capacity`] पद्धतीचा विचार करा.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// विशिष्ट क्षमतेसह नवीन रिक्त `String` तयार करते.
    ///
    /// स्ट्रिंग्जकडे त्यांचा डेटा ठेवण्यासाठी अंतर्गत बफर असतो.
    /// क्षमता त्या बफरची लांबी आहे आणि [`capacity`] पद्धतीने चौकशी केली जाऊ शकते.
    /// ही पद्धत रिक्त `String` तयार करते, परंतु प्रारंभिक बफरसह एक `capacity` बाइट ठेवू शकते.
    /// जेव्हा आपण `String` वर डेटाचा गुच्छ जोडत असाल, तेव्हा त्यास आवश्यक असलेल्या रिकॉलोकेशन्सची संख्या कमी करत असताना हे उपयुक्त ठरेल.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// दिलेली क्षमता `0` असल्यास, कोणतेही वाटप होणार नाही आणि ही पद्धत [`new`] पद्धतीप्रमाणेच आहे.
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // त्यामध्ये अधिक क्षमता असूनही, या अक्षरात कोणतेही अक्षर नाहीत
    /// assert_eq!(s.len(), 0);
    ///
    /// // हे सर्व पुन्हा न सांगता करता आले ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... परंतु हे स्ट्रिंग पुन्हा कॉल करू शकते
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): cfg(test) सह अंतर्भूत `[T]::to_vec` पद्धत, जी या पद्धतीच्या परिभाषासाठी आवश्यक आहे, उपलब्ध नाही.
    // आम्हाला परीक्षेच्या हेतूसाठी ही पद्धत आवश्यक नसल्यामुळे, अधिक माहितीसाठी मी एनबी slice.rs मधील एक्स 100 एक्स मॉड्यूल पहात आहे.
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// एक vector बाइटचे `String` मध्ये रूपांतरित करते.
    ///
    /// एक स्ट्रिंग एक्स ०१ एक्स बाइट एक्स १००० एक्सने बनलेले आहे आणि बाईज एक्स ०२ एक्सचे एक झेडवेक्टोर ० झेड बाइट्सचे बनलेले आहे, म्हणून हे फंक्शन दोनच्या मध्ये रूपांतरित होते.
    /// सर्व बाइट स्लाइस वैध `स्ट्रिंग` नाहीत, तथापिः `String` ला वैध UTF-8 असणे आवश्यक आहे.
    /// `from_utf8()` बाइट्स वैध UTF-8 आहेत हे सुनिश्चित करण्यासाठी तपासणी करते आणि नंतर ते रूपांतरण करतात.
    ///
    /// जर आपल्याला खात्री असेल की बाइट स्लाईस वैध UTF-8 आहे आणि आपल्याला वैधता तपासणीचे ओव्हरहेड खर्च करायचे नाहीत तर या फंक्शनची एक असुरक्षित आवृत्ती आहे [`from_utf8_unchecked`], ज्याचे समान वर्तन आहे परंतु चेक वगळले आहे.
    ///
    ///
    /// कार्यक्षमतेसाठी, ही पद्धत vector कॉपी न करण्याची काळजी घेईल.
    ///
    /// आपल्याला `String` ऐवजी [`&str`] आवश्यक असल्यास, [`str::from_utf8`] चा विचार करा.
    ///
    /// या पद्धतीचा व्युत्क्रम [`into_bytes`] आहे.
    ///
    /// # Errors
    ///
    /// प्रदान केलेला बाइट UTF-8 का नाही यासह वर्णन असलेले स्लाइस UTF-8 नसल्यास [`Err`] मिळवते.आपण हलविलेल्या vector मध्ये देखील समाविष्ट आहे.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// // vector मध्ये काही बाइट
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // आम्हाला माहित आहे की हे बाइट वैध आहेत, म्हणून आम्ही `unwrap()` वापरू.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// चुकीचे बाइट:
    ///
    /// ```
    /// // vector मध्ये काही अवैध बाइट
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// या त्रुटीसह आपण काय करू शकता यावरील अधिक तपशीलांसाठी [`FromUtf8Error`] चे दस्तऐवज पहा.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// बाइट्सचा तुकडा अवैध वर्णांसह स्ट्रिंगमध्ये रूपांतरित करते.
    ///
    /// स्ट्रिंग्स बाइट्स एक्स ०१ एक्सने बनविलेले आहेत आणि एक्स बाईज एक्स ०२ एक्सचा एक तुकडा बाइट्सचा बनलेला आहे, म्हणून हे फंक्शन दोघांमध्ये रूपांतरित होते.सर्व बाइट स्लाइस वैध तार नसतात, तथापि: तारांना वैध UTF-8 असणे आवश्यक आहे.
    /// या रूपांतरणादरम्यान, `from_utf8_lossy()` असे कोणतेही अवैध UTF-8 अनुक्रम [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] सह पुनर्स्थित करेल, जे यासारखे दिसते:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// जर आपल्याला खात्री असेल की बाइट स्लाईस वैध UTF-8 आहे आणि आपल्याला रूपांतरणाचा ओव्हरहेड खर्च करायचा नसेल तर या फंक्शनची एक असुरक्षित आवृत्ती आहे [`from_utf8_unchecked`], हीच वर्तन आहे परंतु धनादेश वगळते.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// हे फंक्शन एक X01 एक्स परत करते.जर आमची बाइट स्लाईस अवैध UTF-8 असेल तर आम्हाला बदलीची अक्षरे समाविष्ट करण्याची आवश्यकता आहे, ज्यामुळे स्ट्रिंगचा आकार बदलेल आणि म्हणूनच, एक्स 100 एक्स आवश्यक आहे.
    /// परंतु हे आधीपासूनच वैध UTF-8 असल्यास, आम्हाला नवीन वाटपाची आवश्यकता नाही.
    /// हा रिटर्न प्रकार आपल्याला दोन्ही प्रकरणे हाताळू शकतो.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// // vector मध्ये काही बाइट
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// चुकीचे बाइट:
    ///
    /// ```
    /// // काही अवैध बाइट
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// UTF-16 - एन्कोड केलेले vector `v` एक `String` मध्ये डीकोड करा, `v` मध्ये अवैध डेटा असल्यास [`Err`] परत करा.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // हे संकलन: : मार्गे केले नाही <Result<_, _>> () कामगिरीच्या कारणास्तव.
        // FIXME: #48994 बंद केल्यावर कार्य पुन्हा सुलभ केले जाऊ शकते.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// एक यूटीएफ-16 - एन्कोडेड स्लाइस एक्स02 एक्सला एक्स01 एक्स मध्ये डीकोड करा, अवैध डेटाची जागा [the replacement character (`U+FFFD`)][U+FFFD] सह पुनर्स्थित करा.
    ///
    /// [`from_utf8_lossy`] जो [`Cow<'a, str>`] परत करतो याच्या विपरीत, `from_utf16_lossy` UTF-16 पासून UTF-8 रूपांतरणास मेमरी वाटप आवश्यक असल्याने `String` परत करते.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// एक `String` त्याच्या कच्च्या घटकांमध्ये विघटित करते.
    ///
    /// मूळ डेटा, स्ट्रिंगची लांबी (बाइटमध्ये) आणि डेटाची वाटप केलेली क्षमता (बाइटमध्ये) कच्चा पॉईंटर मिळवते.
    /// हे त्याच क्रमाने [`from_raw_parts`] ला वितर्क म्हणून समान वितर्क आहेत.
    ///
    /// या फंक्शनला कॉल केल्यानंतर, कॉलर पूर्वी एक्स00 एक्स द्वारे व्यवस्थापित केलेल्या मेमरीसाठी जबाबदार आहे.
    /// हे करण्याचा एकमेव मार्ग म्हणजे कच्चा पॉइंटर, लांबी आणि क्षमता परत एक्स 100 एक्स मध्ये एक्स01 एक्स फंक्शनसह रुपांतरित करणे, ज्यामुळे डिस्ट्रक्टरला क्लिनअप करण्यास परवानगी दिली जाते.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// लांबी, क्षमता आणि पॉइंटरमधून नवीन एक्स 100 एक्स तयार करते.
    ///
    /// # Safety
    ///
    /// हे अत्यंत असुरक्षित आहे, तपासणी न केलेल्या हल्ल्यांच्या संख्येमुळे:
    ///
    /// * `buf` मधील मेमरी पूर्वी समान आवंटकाद्वारे मानक लायब्ररी वापरत असलेल्या अचूक 1 च्या आवश्यक संरेखन सह वाटप करणे आवश्यक आहे.
    /// * `length` `capacity` पेक्षा कमी किंवा समान असणे आवश्यक आहे.
    /// * `capacity` योग्य मूल्य असणे आवश्यक आहे.
    /// * `buf` मधील प्रथम `length` बाइटचे वैध UTF-8 असणे आवश्यक आहे.
    ///
    /// या उल्लंघन केल्याने वाटप करणार्‍याच्या अंतर्गत डेटा स्ट्रक्चर्समध्ये भ्रष्ट होणे यासारख्या समस्या उद्भवू शकतात.
    ///
    /// `buf` ची मालकी प्रभावीपणे `String` वर हस्तांतरित केली गेली आहे जी नंतर पॉईंटरद्वारे दर्शविलेल्या मेमरीची सामग्री विखुरली, पुन्हा गमावू किंवा बदलू शकते.
    /// हे कार्य कॉल केल्यावर दुसरे काहीही पॉईंटर वापरत नाही याची खात्री करा.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FCXME vec_into_raw_parts स्थीर झाल्यावर हे अद्यतनित करा.
    ///     // स्ट्रिंगचा डेटा आपोआप सोडण्यापासून प्रतिबंधित करा
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// स्ट्रिंगमध्ये वैध UTF-8 आहे याची तपासणी न करता झेडवेक्टोर0 झेड बाइटला एक्स01 एक्स मध्ये रुपांतरीत करते.
    ///
    /// अधिक तपशीलांसाठी सुरक्षित आवृत्ती, [`from_utf8`] पहा.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// हे कार्य असुरक्षित आहे कारण ते त्यात पार केलेले बाइट वैध UTF-8 आहेत हे तपासत नाही.
    /// या मर्यादेचे उल्लंघन केल्यास, हे `String` च्या झेडफ्यूचर 0 झेड वापरकर्त्यांसह मेमरी असुरक्षित समस्या उद्भवू शकते, उर्वरित मानक लायब्ररीचे असे मानते की `स्ट्रिंग्ज वैध UTF-8 आहेत.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// // vector मध्ये काही बाइट
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// `String` ला बाइट vector मध्ये रूपांतरित करते.
    ///
    /// हे `String` वापरते, म्हणून आम्हाला त्यातील सामग्री कॉपी करण्याची आवश्यकता नाही.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// संपूर्ण `String` असलेली एक स्ट्रिंग स्लाइस काढते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// `String` ला रूपांतरित स्ट्रिंग स्लाइसमध्ये रूपांतरित करते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// या `String` च्या शेवटी दिलेली स्ट्रिंग स्लाइस जोडते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// या `स्ट्रिंगची क्षमता बाईटमध्ये मिळवते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// याची खात्री करुन घ्या की या `स्ट्रिंगची क्षमता कमीतकमी `additional` बाइट लांबीपेक्षा मोठी आहे.
    ///
    /// वारंवार पुनर्विक्री टाळण्यासाठी क्षमता निवडल्यास `additional` बाइटपेक्षा अधिक क्षमता वाढविली जाऊ शकते.
    ///
    ///
    /// आपण हे "at least" वर्तन घेऊ इच्छित नसल्यास, [`reserve_exact`] पद्धत पहा.
    ///
    /// # Panics
    ///
    /// नवीन क्षमता [`usize`] ओव्हरफ्लो झाल्यास Panics.
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// हे प्रत्यक्षात क्षमता वाढवू शकत नाही:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s ची लांबी 2 आणि क्षमता 10 आहे
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // आमच्याकडे आधीपासूनच अतिरिक्त 8 क्षमता असल्याने, हे कॉल करत आहे ...
    /// s.reserve(8);
    ///
    /// // ... प्रत्यक्षात वाढत नाही.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// याची खात्री करुन घेते की या `स्ट्रिंगची क्षमता `additional` बाइट त्याच्या लांबीपेक्षा मोठी आहे.
    ///
    /// जोपर्यंत आपल्याला पूर्णपणे वाटप करण्यापेक्षा चांगले माहित नाही तोपर्यंत [`reserve`] पद्धत वापरण्याचा विचार करा.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// नवीन क्षमता `usize` ओव्हरफ्लो झाल्यास Panics.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// हे प्रत्यक्षात क्षमता वाढवू शकत नाही:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s ची लांबी 2 आणि क्षमता 10 आहे
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // आमच्याकडे आधीपासूनच अतिरिक्त 8 क्षमता असल्याने, हे कॉल करत आहे ...
    /// s.reserve_exact(8);
    ///
    /// // ... प्रत्यक्षात वाढत नाही.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// दिलेल्या `String` मध्ये कमीतकमी `additional` अधिक घटक समाविष्ट करण्यासाठी क्षमता राखून ठेवण्याचा प्रयत्न करतो.
    /// वारंवार पुनर्विक्री टाळण्यासाठी संकलनात अधिक जागा राखीव असू शकते.
    /// `reserve` वर कॉल केल्यानंतर, क्षमता `self.len() + additional` पेक्षा मोठी किंवा समान असेल.
    /// क्षमता आधीच पुरेशी असल्यास काहीही करत नाही.
    ///
    /// # Errors
    ///
    /// जर क्षमता ओव्हरफ्लो झाली असेल किंवा वितरकाने अपयशाची नोंद केली असेल तर त्रुटी परत केली जाईल.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // मेमरी प्री-रिझर्व करा, शक्य नसल्यास बाहेर पडा
    ///     output.try_reserve(data.len())?;
    ///
    ///     // आता आम्हाला माहित आहे की आमच्या जटिल कार्याच्या मध्यभागी हे OOM करू शकत नाही
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// दिलेल्या `String` मध्ये अचूक `additional` अधिक घटक समाविष्ट करण्यासाठी किमान क्षमता राखण्याचा प्रयत्न करतो.
    ///
    /// `reserve_exact` वर कॉल केल्यानंतर, क्षमता `self.len() + additional` पेक्षा मोठी किंवा समान असेल.
    /// क्षमता आधीच पुरेशी असल्यास काहीही करत नाही.
    ///
    /// लक्षात ठेवा की वाटपकर्ता विनंत्यापेक्षा अधिक संग्रह देऊ शकेल.
    /// म्हणूनच क्षमतेवर तंतोतंत किमान असणे अवलंबून नाही.
    /// झेडफ्यूचर 0 झेडच्या आशेची अपेक्षा असल्यास `reserve` ला प्राधान्य द्या.
    ///
    /// # Errors
    ///
    /// जर क्षमता ओव्हरफ्लो झाली असेल किंवा वितरकाने अपयशाची नोंद केली असेल तर त्रुटी परत केली जाईल.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // मेमरी प्री-रिझर्व करा, शक्य नसल्यास बाहेर पडा
    ///     output.try_reserve(data.len())?;
    ///
    ///     // आता आम्हाला माहित आहे की आमच्या जटिल कार्याच्या मध्यभागी हे OOM करू शकत नाही
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// त्याच्या लांबीशी जुळण्यासाठी या `String` ची क्षमता कमी करते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// खालच्या सीमेसह या `String` ची क्षमता कमी करते.
    ///
    /// लांबी आणि पुरवठा केलेले मूल्य यापेक्षा कमीतकमी क्षमता राहील.
    ///
    ///
    /// जर सद्य क्षमता कमी मर्यादेपेक्षा कमी असेल तर ही एक निवड नाही.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// या `String` च्या शेवटी दिलेली [`char`] जोडली.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// या `स्ट्रिंग`च्या सामग्रीची बाइट स्लाइस मिळवते.
    ///
    /// या पद्धतीचा व्युत्क्रम [`from_utf8`] आहे.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// निर्दिष्ट केलेल्या लांबीपर्यंत हे `String` कमी करते.
    ///
    /// जर एक्स 100 एक्स स्ट्रिंगच्या सध्याच्या लांबीपेक्षा मोठे असेल तर याचा काही परिणाम होणार नाही.
    ///
    ///
    /// लक्षात घ्या की या पद्धतीचा स्ट्रिंगच्या वाटप क्षमतेवर कोणताही परिणाम होणार नाही
    ///
    /// # Panics
    ///
    /// `new_len` [`char`] सीमेवरील नसल्यास Panics.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// स्ट्रिंग बफरमधून शेवटचे पात्र काढून टाकते आणि ते परत करते.
    ///
    /// हे X01 एक्स रिक्त असल्यास [`None`] मिळवते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// या `String` वरून बाइट स्थितीवर एक [`char`] काढते आणि ते परत करते.
    ///
    /// हे *ओ*(*एन*) ऑपरेशन आहे, कारण त्यासाठी बफरमधील प्रत्येक घटकाची कॉपी करणे आवश्यक आहे.
    ///
    /// # Panics
    ///
    /// जर `idx` `स्ट्रिंग`च्या लांबीपेक्षा मोठे किंवा समान असेल किंवा ते [`char`] सीमेवरील नसल्यास Panics.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// `String` मधील नमुना `pat` चे सर्व सामने काढा.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// सामने शोधून काढले जातील आणि पुनरावृत्ती केल्या पाहिजेत, ज्यायोगे नमुने ओव्हरलॅप होतात तेव्हा फक्त पहिला नमुना काढला जाईल:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // सुरक्षितताः प्रारंभ आणि शेवट प्रति utf8 बाइट सीमांवर असेल
        // शोधकर्ता दस्तऐवज
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// केवळ पूर्वानुमानाने निर्दिष्ट केलेली अक्षरे टिकवून ठेवतात.
    ///
    /// दुसर्‍या शब्दांमध्ये, `c` सर्व वर्ण काढा जे `f(c)` ने `false` परत केले.
    /// ही पद्धत त्या ठिकाणी कार्य करते, प्रत्येक वर्णांना मूळ क्रमाने अगदी एकदाच भेट देते आणि कायम केलेल्या वर्णांची क्रमवारी जतन करते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// निर्देशांकप्रमाणे बाह्य स्थितीचा मागोवा घेण्यासाठी अचूक ऑर्डर उपयुक्त ठरू शकते.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // पुढील चार वर आयडीएक्स दाखवा
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// या `String` मध्ये बाइट स्थितीत एक वर्ण समाविष्ट करते.
    ///
    /// हे *ओ*(*एन*) ऑपरेशन आहे कारण त्यासाठी बफरमधील प्रत्येक घटकाची कॉपी करणे आवश्यक आहे.
    ///
    /// # Panics
    ///
    /// `idx` the स्ट्रिंग`च्या लांबीपेक्षा मोठे असल्यास किंवा ते [`char`] सीमेवरील नसल्यास Panics.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// या `String` मध्ये बाइट स्थितीत एक स्ट्रिंग स्लाइस घाला.
    ///
    /// हे *ओ*(*एन*) ऑपरेशन आहे कारण त्यासाठी बफरमधील प्रत्येक घटकाची कॉपी करणे आवश्यक आहे.
    ///
    /// # Panics
    ///
    /// `idx` the स्ट्रिंग`च्या लांबीपेक्षा मोठे असल्यास किंवा ते [`char`] सीमेवरील नसल्यास Panics.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// या `String` च्या सामग्रीचा बदल बदलणारा संदर्भ मिळवते.
    ///
    /// # Safety
    ///
    /// हे कार्य असुरक्षित आहे कारण ते त्यात पार केलेले बाइट वैध UTF-8 आहेत हे तपासत नाही.
    /// या मर्यादेचे उल्लंघन केल्यास, हे `String` च्या झेडफ्यूचर 0 झेड वापरकर्त्यांसह मेमरी असुरक्षित समस्या उद्भवू शकते, उर्वरित मानक लायब्ररीचे असे मानते की `स्ट्रिंग्ज वैध UTF-8 आहेत.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// या `String` ची लांबी, बाइट्समध्ये, [gra char`] चे किंवा ग्राफिक नाही तर मिळवते.
    /// दुस words्या शब्दांत, एखादी गोष्ट स्ट्रिंगची लांबी मानते.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// या `String` ची लांबी शून्य असल्यास `true` आणि अन्यथा `false` मिळवते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// दिलेल्या बाइट इंडेक्सवर स्ट्रिंग दोन मध्ये विभाजित करते.
    ///
    /// नवीन वाटप केलेले `String` मिळवते.
    /// `self` बाइट्स एक्स ०१ एक्स आणि परत केलेल्या एक्स ०२ एक्समध्ये बाइट एक्स १० एक्स समाविष्ट आहे.
    /// `at` UTF-8 कोड पॉइंटच्या सीमेवर असणे आवश्यक आहे.
    ///
    /// लक्षात घ्या की `self` ची क्षमता बदलत नाही.
    ///
    /// # Panics
    ///
    /// `at` `UTF-8` कोड पॉइंट सीमेवर नसल्यास Panics किंवा स्ट्रिंगच्या शेवटच्या कोड बिंदूच्या पलीकडे असल्यास.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// सर्व सामग्री काढून, हे `String` कमी करते.
    ///
    /// याचा अर्थ असा की `String` ची लांबी शून्य असेल, परंतु त्याची क्षमता स्पर्श करत नाही.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// `String` मधील निर्दिष्ट श्रेणी काढून टाकते आणि काढलेले `chars` मिळवते अशा जलवाहिनीचे इटररेटर तयार करते.
    ///
    ///
    /// Note: शेवटपर्यंत पुनरावृत्ती करणारा वापर केला जात नसला तरीही घटक श्रेणी काढली जाते.
    ///
    /// # Panics
    ///
    /// जर प्रारंभ बिंदू किंवा शेवटचा बिंदू [`char`] सीमेवरील नसल्यास किंवा ते मर्यादेबाहेर असल्यास Panics.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // स्ट्रिंगमधून until पर्यंत श्रेणी काढा
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // पूर्ण श्रेणी स्ट्रिंग साफ करते
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // मेमरी सुरक्षा
        //
        // Drain च्या स्ट्रिंग आवृत्तीमध्ये vector आवृत्तीची मेमरी सुरक्षा समस्या नाहीत.
        // डेटा फक्त साधा बाइट आहे.
        // ड्रॉपमध्ये श्रेणी हटविणे होत असल्याने, झेडड्रेन 0 झेड पुनरावृत्ती करणारा लीक झाल्यास, काढणे होणार नाही.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // दोन एकाचवेळी कर्ज घ्या.
        // ड्रॉपमध्ये पुनरावृत्ती संपेपर्यंत &mut स्ट्रिंगमध्ये प्रवेश केला जाणार नाही.
        let self_ptr = self as *mut _;
        // सुरक्षा: `slice::range` आणि `is_char_boundary` योग्य सीमा तपासणी करतात.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// स्ट्रिंगमधील निर्दिष्ट श्रेणी काढून टाकते आणि त्यास दिलेल्या स्ट्रिंगसह पुनर्स्थित करते.
    /// दिलेल्या स्ट्रिंगची श्रेणी समान लांबी असणे आवश्यक नाही.
    ///
    /// # Panics
    ///
    /// जर प्रारंभ बिंदू किंवा शेवटचा बिंदू [`char`] सीमेवरील नसल्यास किंवा ते मर्यादेबाहेर असल्यास Panics.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // स्ट्रिंगपासून until पर्यंत श्रेणी बदला
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // मेमरी सुरक्षा
        //
        // रिप्लेस_रेंजला vector Splice ची मेमरी सेफ्टी समस्या नाहीत.
        // vector आवृत्तीचेडेटा फक्त साधा बाइट आहे.

        // चेतावणी: हे व्हेरिएबल इनलाइन करणे हे अवाऊंड (#81138) असेल
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // चेतावणी: हे व्हेरिएबल इनलाइन करणे हे अवाऊंड (#81138) असेल
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // `range` पुन्हा वापरणे अप्रिय (#81138) असेल आम्ही असे गृहित धरले की `range` ने नोंदविलेली मर्यादा तशीच राहिली आहे परंतु प्रतिकूल अंमलबजावणी कॉल दरम्यान बदलू शकते
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// या `String` ला [`बॉक्स`]`<`[`स्ट्र`] `>` मध्ये रूपांतरित करते.
    ///
    /// यामुळे कोणतीही अतिरिक्त क्षमता कमी होईल.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// `String` मध्ये रूपांतरित करण्याचा प्रयत्न केला जाणारा [`u8`] बाइटचा तुकडा मिळवते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// // vector मध्ये काही अवैध बाइट
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// `String` मध्ये रूपांतरित करण्याचा प्रयत्न केलेला बाइट मिळवते.
    ///
    /// वाटप टाळण्यासाठी ही पद्धत काळजीपूर्वक तयार केली आहे.
    /// हे एरिटचा वापर बाइट्स हलवून घेईल, जेणेकरून बाइटची प्रत बनविण्याची गरज नाही.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// // vector मध्ये काही अवैध बाइट
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// रूपांतरण अपयशाबद्दल अधिक तपशील मिळविण्यासाठी `Utf8Error` मिळवा.
    ///
    /// [`std::str`] द्वारे प्रदान केलेला [`Utf8Error`] प्रकार त्रुटी दर्शवितो जो [`u8`] च्या तुकड्याला [`&str`] मध्ये रूपांतरित करताना उद्भवू शकते.
    /// या अर्थाने, हे `FromUtf8Error` चे एक समानता आहे.
    /// ते वापरण्यासाठी अधिक तपशीलांसाठी त्याचे दस्तऐवजीकरण पहा.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// // vector मध्ये काही अवैध बाइट
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // प्रथम बाइट येथे अवैध आहे
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // कारण आम्ही `स्ट्रिंग्ज वर पुनरावृत्ती करीत आहोत, तर पुनरावृत्ती करणार्‍याकडून प्रथम स्ट्रिंग मिळवून आणि त्यानंतरच्या सर्व तारांना जोडून आपण किमान एक वाटप टाळू शकतो.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // कारण आम्ही CoWs वर पुनरावृत्ती करीत आहोत, आम्ही पहिली वस्तू मिळवून आणि त्यानंतरच्या सर्व वस्तूंमध्ये कमीत कमी एक वाटप टाळू शकतो.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// `&str` साठी आव्हान सोपवलेली सोयीची सुविधा.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// रिक्त `String` तयार करते.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// दोन तार एकत्र करण्यासाठी `+` ऑपरेटरची अंमलबजावणी करते.
///
/// हे डाव्या बाजूला `String` घेते आणि त्याचे बफर पुन्हा वापरते (आवश्यक असल्यास ते वाढवित आहे).
/// नवीन एक्स 100 एक्सचे वाटप करणे आणि प्रत्येक ऑपरेशनवरील संपूर्ण सामग्रीची कॉपी करणे टाळण्यासाठी हे केले जाते, ज्यामुळे *ओ*(*एन*^ 2) पुन्हा वेळ देऊन कॉन्टिनेशनद्वारे *एन*-बायट स्ट्रिंग तयार करताना चालू वेळ मिळेल.
///
///
/// उजवीकडील बाजूची तार केवळ कर्ज घेतली जाते;परत आलेल्या `String` मध्ये त्यातील सामग्री कॉपी केल्या आहेत.
///
/// # Examples
///
/// दोन स्ट्रिंगचे प्रतिस्पर्धा प्रथम मूल्य मूल्यानुसार घेते आणि दुसरे कर्ज घेते:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` हलविले आहे आणि यापुढे यापुढे वापरले जाऊ शकत नाही.
/// ```
///
/// आपण प्रथम `String` वापरणे सुरू ठेवू इच्छित असल्यास आपण त्यास क्लोन करू शकता आणि त्याऐवजी क्लोनमध्ये जोडू शकता:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` येथे अद्याप वैध आहे.
/// ```
///
/// प्रथम `String` मध्ये रूपांतरित करून `&str` कापांचे संयोजन करणे शक्य आहे:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// `String` मध्ये जोडण्यासाठी `+=` ऑपरेटरची अंमलबजावणी करते.
///
/// यात [`push_str`][String::push_str] पद्धतीप्रमाणेच वर्तन आहे.
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// [`Infallible`] साठी एक उपनाव.
///
/// हा उपनाव मागील बाजूस सुसंगततेसाठी विद्यमान आहे आणि अखेरीस त्यास नकार दिला जाऊ शकतो.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// `String` मध्ये मूल्य रूपांतरित करण्यासाठी trait.
///
/// हे trait [`Display`] trait लागू करणार्‍या कोणत्याही प्रकारासाठी स्वयंचलितपणे अंमलात आणले गेले आहे.
/// यामुळे, `ToString` थेट लागू केले जाऊ नये:
/// [`Display`] त्याऐवजी अंमलबजावणी केली पाहिजे आणि आपल्याला `ToString` ची अंमलबजावणी विनामूल्य मिळेल.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// दिलेले मूल्य `String` मध्ये रूपांतरित करते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// या अंमलबजावणीमध्ये, `Display` अंमलबजावणीमध्ये त्रुटी परत आल्यास `to_string` पद्धत panics.
/// हे चुकीच्या `Display` अंमलबजावणीस सूचित करते कारण `fmt::Write for String` कधीही त्रुटी परत करीत नाही.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // सामान्य मार्गदर्शक सूचना म्हणजे सामान्य कार्ये इनलाइन न करणे.
    // तथापि, या पद्धतीतून `#[inline]` काढून टाकण्यामुळे-नगण्य नसल्याचा त्रास होतो.
    // ते काढण्याचा प्रयत्न करण्याचा शेवटचा प्रयत्न <https://github.com/rust-lang/rust/pull/74852> पहा.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// `&mut str` ला `String` मध्ये रूपांतरित करते.
    ///
    /// परिणाम ढिगा .्यावर वाटप केला जातो.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: चाचणी लिबस्टडी मध्ये खेचते, ज्यामुळे येथे चुका होतात
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// दिलेल्या बॉक्सिंग `str` स्लाइसला `String` मध्ये रूपांतरित करते.
    /// हे उल्लेखनीय आहे की `str` स्लाईस मालकीची आहे.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// दिलेल्या `String` ला मालकीच्या बॉक्सिंग `str` स्लाइसमध्ये रूपांतरित करते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// स्ट्रिंग स्लाइसला कर्ज घेतलेल्या प्रकारात रूपांतरित करते.
    /// कोणतेही ढीग वाटप केले जात नाही आणि स्ट्रिंग कॉपी केली जात नाही.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// एका स्ट्रिंगला मालकीच्या प्रकारात रूपांतरित करते.
    /// कोणतेही ढीग वाटप केले जात नाही आणि स्ट्रिंग कॉपी केली जात नाही.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// स्ट्रिंग संदर्भास कर्ज घेतलेल्या प्रकारात रूपांतरित करते.
    /// कोणतेही ढीग वाटप केले जात नाही आणि स्ट्रिंग कॉपी केली जात नाही.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// दिलेल्या `String` ला vector `Vec` मध्ये रूपांतरित करते ज्यामधे `u8` प्रकारची मूल्ये आहेत.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// `String` साठी निचरा करणारा इटरेटर
///
/// ही रचना [`String`] वर [`drain`] पद्धतीने तयार केली गेली आहे.
/// अधिकसाठी त्याचे दस्तऐवजीकरण पहा.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// &विध्वंसक मध्ये एक म्युट स्ट्रिंग म्हणून वापरले जाईल
    string: *mut String,
    /// काढण्यासाठी भाग प्रारंभ
    start: usize,
    /// काढण्यासाठी भाग शेवटी
    end: usize,
    /// काढण्यासाठी सध्याची उर्वरित श्रेणी
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Vec::drain वापरा.
            // "Reaffirm" panic कोड पुन्हा घातला जाऊ नये यासाठी सीमा तपासते.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// या पुनरावृत्ती करणार्‍याची उर्वरित (उप) स्ट्रिंग स्लाईस म्हणून मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: स्थिर असताना स्थिर परिस्थिती म्हणून AsRef खाली उतरवते.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// `string_drain_as_str` स्थिर करताना अ-टिप्पणी.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>Drain <'a> {fn as_ref(&self)-> &str for साठी
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// झेडड्रेन0 झेड <<a> {एफएन एक्स00 एक्स->&[u8] for साठी <<a> AsRef <[u8]>
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}