//! वाटप
//!
//! या मॉड्यूलचा हेतू `alloc` crate च्या सामान्यत: वापरल्या जाणार्‍या वस्तूंच्या आयात कमी करणे हे मॉड्यूल्सच्या शीर्षस्थानी ग्लोब इम्पोर्ट समाविष्ट करुन करणे आहे.
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;