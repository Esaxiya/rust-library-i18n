//! मेमरी वाटप एपीआय

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // ग्लोबल allocलोकटरला कॉल करण्यासाठी ही जादूची चिन्हे आहेत.rustc त्यांना `__rg_alloc` इ. कॉल करण्यासाठी व्युत्पन्न करते.
    // जर तेथे `#[global_allocator]` गुणधर्म असेल (तर ते गुणविशेष मॅक्रो त्या कार्ये व्युत्पन्न करते कोड) किंवा लिबस्टीडीमध्ये डीफॉल्ट अंमलबजावणी (`__rdl_alloc` इ.) कॉल करण्यासाठी.
    //
    // `library/std/src/alloc.rs` मध्ये) अन्यथा.
    // एलएलव्हीएमचे झेडस्ट्रोस्ट0झेड झेडफोर्क ० झेड देखील विशेषत: या कार्य नावे अनुक्रमे `malloc`, `realloc` आणि `free` सारख्या ऑप्टिमाइझ करण्यात सक्षम होण्यासाठी आहेत.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// ग्लोबल मेमरी allocलोकटर.
///
/// हा प्रकार `#[global_allocator]` विशेषतासह नोंदणीकृत registeredलोटरला कॉल अग्रेषित करून किंवा `std` crate चे डीफॉल्टद्वारे [`Allocator`] trait लागू करतो.
///
///
/// Note: हा प्रकार अस्थिर असताना, त्याद्वारे प्रदान केलेली कार्यक्षमता [free functions in `alloc`](self#functions) द्वारे प्रवेश करणे शक्य आहे.
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// ग्लोबल atorलोकटरसह मेमरी वाटप करा.
///
/// हे फंक्शन `#[global_allocator]` एट्रिब्युटसह नोंदणीकृत असलेल्या allocलोकटरच्या [`GlobalAlloc::alloc`] पद्धतीत किंवा `std` crate चे डीफॉल्ट असल्यास कॉल करते.
///
///
/// हे कार्य [`Global`] प्रकाराच्या `alloc` पध्दतीच्या वतीने आणि [`Allocator`] trait स्थिर झाल्यावर नापसंत होण्याची अपेक्षा आहे.
///
/// # Safety
///
/// [`GlobalAlloc::alloc`] पहा.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// ग्लोबल atorलोकटरसह मेमरी कमी करा.
///
/// हे फंक्शन `#[global_allocator]` एट्रिब्युटसह नोंदणीकृत असलेल्या allocलोकटरच्या [`GlobalAlloc::dealloc`] पद्धतीत किंवा `std` crate चे डीफॉल्ट असल्यास कॉल करते.
///
///
/// हे कार्य [`Global`] प्रकाराच्या `dealloc` पध्दतीच्या वतीने आणि [`Allocator`] trait स्थिर झाल्यावर नापसंत होण्याची अपेक्षा आहे.
///
/// # Safety
///
/// [`GlobalAlloc::dealloc`] पहा.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// ग्लोबल atorलोकरेटरसह मेमरी रीलोकॉकेट करा.
///
/// हे फंक्शन `#[global_allocator]` एट्रिब्युटसह नोंदणीकृत असलेल्या allocलोकटरच्या [`GlobalAlloc::realloc`] पद्धतीत किंवा `std` crate चे डीफॉल्ट असल्यास कॉल करते.
///
///
/// हे कार्य [`Global`] प्रकाराच्या `realloc` पध्दतीच्या वतीने आणि [`Allocator`] trait स्थिर झाल्यावर नापसंत होण्याची अपेक्षा आहे.
///
/// # Safety
///
/// [`GlobalAlloc::realloc`] पहा.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// ग्लोबल atorलोकटरसह शून्य-आरंभिक मेमरीचे वाटप करा.
///
/// हे फंक्शन `#[global_allocator]` एट्रिब्युटसह नोंदणीकृत असलेल्या allocलोकटरच्या [`GlobalAlloc::alloc_zeroed`] पद्धतीत किंवा `std` crate चे डीफॉल्ट असल्यास कॉल करते.
///
///
/// हे कार्य [`Global`] प्रकाराच्या `alloc_zeroed` पध्दतीच्या वतीने आणि [`Allocator`] trait स्थिर झाल्यावर नापसंत होण्याची अपेक्षा आहे.
///
/// # Safety
///
/// [`GlobalAlloc::alloc_zeroed`] पहा.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // सुरक्षितता: `layout` आकारात शून्य आहे,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // सुरक्षा: `Allocator::grow` प्रमाणेच
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // सुरक्षितता: `old_size` हे `new_size` पेक्षा मोठे किंवा समान असल्याने `new_size` शून्य नाही
            // सुरक्षा अटींनुसार आवश्यककॉलरद्वारे इतर अटी समर्थित केल्या पाहिजेत
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` कदाचित `new_size >= old_layout.size()` किंवा तत्सम काहीतरी तपासते.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // सुरक्षितता: कारण `new_layout.size()` हे `old_size` पेक्षा मोठे किंवा त्यास समान असले पाहिजे,
            // जुन्या आणि नवीन मेमरीचे दोन्ही वाटप `old_size` बाइटसाठी वाचन आणि लेखनासाठी वैध आहेत.
            // तसेच, जुने वाटप अद्याप रद्दबातल झाले नव्हते म्हणून ते एक्स 100 एक्सला आच्छादित करू शकत नाही.
            // अशा प्रकारे, `copy_nonoverlapping` वर कॉल सुरक्षित आहे.
            // कॉलरद्वारे `dealloc` चे सुरक्षा कराराचे समर्थन केले जाणे आवश्यक आहे.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // सुरक्षितता: `layout` आकारात शून्य आहे,
            // अन्य अटी कॉलरद्वारे समर्थित केल्या पाहिजेत
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // सुरक्षितता: कॉलरद्वारे सर्व अटी समर्थित केल्या पाहिजेत
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // सुरक्षितता: कॉलरद्वारे सर्व अटी समर्थित केल्या पाहिजेत
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // सुरक्षितता: कॉलरद्वारे शर्ती पाळल्या पाहिजेत
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // सुरक्षाः `new_size` शून्य आहे.कॉलरद्वारे इतर अटी समर्थित केल्या पाहिजेत
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` कदाचित `new_size <= old_layout.size()` किंवा तत्सम काहीतरी तपासते.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // सुरक्षितता: कारण `new_size` हे `old_layout.size()` पेक्षा लहान किंवा त्यासमान असणे आवश्यक आहे,
            // जुन्या आणि नवीन मेमरीचे दोन्ही वाटप `new_size` बाइटसाठी वाचन आणि लेखनासाठी वैध आहेत.
            // तसेच, जुने वाटप अद्याप रद्दबातल झाले नव्हते म्हणून ते एक्स 100 एक्सला आच्छादित करू शकत नाही.
            // अशा प्रकारे, `copy_nonoverlapping` वर कॉल सुरक्षित आहे.
            // कॉलरद्वारे `dealloc` चे सुरक्षा कराराचे समर्थन केले जाणे आवश्यक आहे.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// अनन्य पॉईंटर्ससाठी वाटपकर्ता.
// हे कार्य न उलगडणे आवश्यक आहे.जर तसे झाले तर एमआयआर कोडगेन अपयशी ठरेल.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// हे स्वाक्षरी `Box` प्रमाणेच असणे आवश्यक आहे, अन्यथा एक आयसीई होईल.
// जेव्हा `Box` वर अतिरिक्त पॅरामीटर जोडला गेला (`A: Allocator` प्रमाणे), हे येथे देखील जोडावे लागेल.
// उदाहरणार्थ `Box` `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)` मध्ये बदलल्यास, हे कार्य `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` मध्ये देखील बदलावे लागेल.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # वाटप त्रुटी हँडलर

extern "Rust" {
    // हे ग्लोबल ऑलोक एरर हँडलर कॉल करण्यासाठी जादूचे प्रतीक आहे.
    // rustc एक `#[alloc_error_handler]` असल्यास `__rg_oom` वर कॉल करण्यासाठी किंवा अन्यथा (`__rdl_oom`) च्या खाली डीफॉल्ट अंमलबजावणी कॉल करण्यासाठी व्युत्पन्न करते.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// मेमरी ationलोकेशन त्रुटी किंवा अयशस्वी होण्यावर सोडून द्या.
///
/// वाटप त्रुटीच्या उत्तरात कंप्यूटेशन थांबवू इच्छिणा memory्या मेमरी APIलोकेशन एपीआयच्या कॉलरना थेट `panic!` किंवा तत्सम आवाहन करण्याऐवजी हे कार्य कॉल करण्यास प्रोत्साहित केले जाते.
///
///
/// या फंक्शनची डीफॉल्ट वर्तन म्हणजे मानक त्रुटीवर संदेश मुद्रित करणे आणि प्रक्रिया रद्द करणे.
/// हे [`set_alloc_error_hook`] आणि [`take_alloc_error_hook`] सह पुनर्स्थित केले जाऊ शकते.
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// वाटप चाचणीसाठी `std::alloc::handle_alloc_error` थेट वापरला जाऊ शकतो.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // व्युत्पन्न `__rust_alloc_error_handler` मार्गे म्हटले जाते

    // जर एक्स 100 एक्स नसेल तर
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // जर तेथे `#[alloc_error_handler]` असेल
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// पूर्व-वाटप, निर्विवाद स्मृतीत क्लोन विशेषज्ञ करा.
/// `Box::clone` आणि `Rc`/`Arc::make_mut` द्वारे वापरले.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // *प्रथम* वाटप केल्याने ऑप्टिमाइझरला क्लोन व्हॅल्यू जागेत तयार करण्याची अनुमती मिळते, लोकल वगळू आणि हलवा.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // स्थानिक मूल्याचा समावेश न करता आम्ही नेहमीच जागेत कॉपी करू शकतो.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}