//! ढीग वाटपासाठी पॉईंटर प्रकार.
//!
//! [`Box<T>`], एक 'box' म्हणून सहसा संदर्भित, झेडआरस्ट0 झेडमध्ये ढीग वाटप करण्याचा सर्वात सोपा फॉर्म प्रदान करतो.बॉक्स या वाटपासाठी मालकी प्रदान करतात आणि जेव्हा ते वाचनाच्या बाहेर जातात तेव्हा त्यातील सामग्री खाली टाकतात.बॉक्स देखील हे सुनिश्चित करतात की ते कधीही एक्स 0 एक्स एक्स बाइटपेक्षा जास्त वाटप करत नाहीत.
//!
//! # Examples
//!
//! एक [`Box`] तयार करून स्टॅकमधून ढीगवर एक मूल्य हलवा:
//!
//! ```
//! let val: u8 = 5;
//! let boxed: Box<u8> = Box::new(val);
//! ```
//!
//! [`Box`] मधील मूल्य परत [dereferencing] ने स्टॅकवर हलवा:
//!
//! ```
//! let boxed: Box<u8> = Box::new(5);
//! let val: u8 = *boxed;
//! ```
//!
//! रिकर्सिव्ह डेटा स्ट्रक्चर तयार करणे:
//!
//! ```
//! #[derive(Debug)]
//! enum List<T> {
//!     Cons(T, Box<List<T>>),
//!     Nil,
//! }
//!
//! let list: List<i32> = List::Cons(1, Box::new(List::Cons(2, Box::new(List::Nil))));
//! println!("{:?}", list);
//! ```
//!
//! हे `Cons (1, Cons(2, Nil))`.
//!
//! रिकर्सिव्ह स्ट्रक्चर्स बॉक्सिंग असणे आवश्यक आहे, कारण जर `Cons` ची व्याख्या यासारखे दिसत असेल तर:
//!
//! ```compile_fail,E0072
//! # enum List<T> {
//! Cons(T, List<T>),
//! # }
//! ```
//!
//! हे कार्य करणार नाही.हे असे आहे कारण `List` चा आकार सूचीतील किती घटकांवर अवलंबून आहे आणि म्हणूनच आम्हाला हे माहित नाही की `Cons` साठी किती मेमरी वाटप करावी.एक परिभाषित आकार असलेला एक X01 एक्स सादर करून, आम्हाला माहित आहे की किती मोठे `Cons` असणे आवश्यक आहे.
//!
//! # मेमरी लेआउट
//!
//! शून्य-आकार नसलेल्या मूल्यांसाठी, एक [`Box`] त्याच्या वाटपासाठी [`Global`] allocलोटर वापरेल.[`Box`] आणि [`Global`] वाटप करणार्‍याला वाटप केलेला कच्चा पॉईंटर दरम्यान दोन्ही मार्गांमध्ये रूपांतरित करणे वैध आहे, दिलेली आहे की वोटकासाठी वापरलेला [`Layout`] प्रकार योग्य आहे.
//!
//! अधिक स्पष्टपणे, `Layout::for_value(&*value)` सह [`Global`] allocलोटरसह वाटप केलेले `value:* mut T` [`Box::<T>::from_raw(value)`] वापरून बॉक्समध्ये रूपांतरित केले जाऊ शकते.
//! याउलट, [`Box::<T>::into_raw`] वरुन प्राप्त केलेल्या `value:*mut T` चे समर्थन करणारी मेमरी [`Layout::for_value(&* value)`] सह [`Global`] अ‍ॅलोकरेटरचा वापर करून कमी केली जाऊ शकते.
//!
//! शून्य-आकाराच्या मूल्यांसाठी, वाचण्यासाठी व लिहिण्यासाठी आणि पुरेसे संरेखित करण्यासाठी `Box` पॉईंटर अद्याप [valid] असणे आवश्यक आहे.
//! विशेषतः, कोणतीही संरेखित नॉन-शून्य पूर्णांक कच्च्या पॉइंटरवर टाकणे वैध पॉईंटर तयार करते, परंतु पूर्वी वाटप केलेल्या मेमरीकडे निर्देशित करणारा पॉईंटर वैध नाही.
//! `Box::new` वापरला जाऊ शकत नसल्यास झेडएसटी वर बॉक्स तयार करण्याचा शिफारस केलेला मार्ग म्हणजे एक्स 100 एक्स.
//!
//! `T: Sized` पर्यंत, `Box<T>` ला एकच पॉईंटर म्हणून प्रतिनिधित्व करण्याची हमी दिलेली आहे आणि सी पॉइंटर्स (म्हणजे सी प्रकार `T*`) सह देखील ABI-सुसंगत आहे.
//! याचा अर्थ असा की आपल्याकडे बाह्य "C" Rust कार्ये आहेत जी सी वरुन कॉल केली जातील, आपण `Box<T>` प्रकारांचा वापर करुन त्या झेडआरस्ट0 झेड कार्ये परिभाषित करू शकता आणि सी साइड वर संबंधित प्रकार म्हणून एक्स0 2 एक्स वापरू शकता.
//! उदाहरणार्थ, या सी शीर्षलेखाचा विचार करा जे काही प्रकारचे `Foo` मूल्य तयार आणि नष्ट करते अशी कार्ये घोषित करते:
//!
//! ```c
//! /* सी शीर्षलेख */
//!
//! /* कॉलरकडे मालकी परत करते */
//! struct Foo* foo_new(void);
//!
//! /* कॉलरकडून मालकी घेते;एनओएलएल सह आवाहन केल्यावर कोणतीही निवड नाही */
//! void foo_delete(struct Foo*);
//! ```
//!
//! हे दोन कार्ये खालीलप्रमाणे Rust मध्ये अंमलात येऊ शकतात.येथे, सी मधील एक्स 01 एक्स प्रकार एक्स 100 एक्स मध्ये अनुवादित केला गेला आहे, जो मालकीच्या मर्यादा पकडतो.
//! हे देखील लक्षात घ्या की `foo_delete` मधील अपूर्ण युक्तिवाद Rust मध्ये `Option<Box<Foo>>` म्हणून प्रस्तुत केले आहे, कारण `Box<Foo>` अशक्त असू शकत नाही.
//!
//! ```
//! #[repr(C)]
//! pub struct Foo;
//!
//! #[no_mangle]
//! pub extern "C" fn foo_new() -> Box<Foo> {
//!     Box::new(Foo)
//! }
//!
//! #[no_mangle]
//! pub extern "C" fn foo_delete(_: Option<Box<Foo>>) {}
//! ```
//!
//! जरी एक्स00 एक्सचे प्रतिनिधित्व आणि सी एबीआय सारखे सी पॉईन्टर आहेत, याचा अर्थ असा नाही की आपण अनियंत्रित एक्स 0 एक्सला एक्स एक्स 2 एक्स मध्ये रुपांतरित करू शकता आणि गोष्टींनी कार्य करण्याची अपेक्षा करू शकता.
//! `Box<T>` मूल्ये नेहमी पूर्णपणे संरेखित केली जातील, निरर्थक पॉइंटर्स.शिवाय, एक्स00 एक्सचा विनाशक जागतिक मूल्यनिर्माताद्वारे मूल्य मुक्त करण्याचा प्रयत्न करेल.सर्वसाधारणपणे, सर्वोत्कृष्ट सराव म्हणजे केवळ जागतिक वाटपकर्त्यापासून उद्भवलेल्या पॉईंटर्ससाठी एक्स ०१ एक्सचा वापर करणे.
//!
//! **महत्वाचे.** कमीतकमी सध्या तुम्ही फंक्शनसाठी `Box<T>` प्रकार वापरणे टाळावे जे सी मध्ये परिभाषित केले गेले परंतु झेड रस्ट ० झेड पासून आवाहन केले.अशा परिस्थितीत आपण सी प्रकार शक्य तितक्या जवळून मिरर केले पाहिजेत.
//! X001 एक्ससारखे प्रकार वापरणे जेथे सी व्याख्या फक्त `T*` वापरत आहे हे [rust-lang/unsafe-code-guidelines#198][ucg#198] मध्ये वर्णन केल्यानुसार अपरिभाषित वर्तन होऊ शकते.
//!
//! [ucg#198]: https://github.com/rust-lang/unsafe-code-guidelines/issues/198
//! [dereferencing]: core::ops::Deref
//! [`Box::<T>::from_raw(value)`]: Box::from_raw
//! [`Global`]: crate::alloc::Global
//! [`Layout`]: crate::alloc::Layout
//! [`Layout::for_value(&*value)`]: crate::alloc::Layout::for_value
//! [valid]: ptr#safety
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::future::Future;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator, Iterator};
use core::marker::{Unpin, Unsize};
use core::mem;
use core::ops::{
    CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Generator, GeneratorState, Receiver,
};
use core::pin::Pin;
use core::ptr::{self, Unique};
use core::stream::Stream;
use core::task::{Context, Poll};

use crate::alloc::{handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw};
use crate::borrow::Cow;
use crate::raw_vec::RawVec;
use crate::str::from_boxed_utf8_unchecked;
use crate::vec::Vec;

/// ढीग वाटपासाठी पॉईंटर प्रकार.
///
/// अधिकसाठी [module-level documentation](../../std/boxed/index.html) पहा.
#[lang = "owned_box"]
#[fundamental]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Box<
    T: ?Sized,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
>(Unique<T>, A);

impl<T> Box<T> {
    /// ढीग वर मेमरी वाटप करते आणि नंतर त्यात `x` ठेवते.
    ///
    /// हे `T` शून्य-आकाराचे असल्यास प्रत्यक्षात त्याचे वाटप करत नाही.
    ///
    /// # Examples
    ///
    /// ```
    /// let five = Box::new(5);
    /// ```
    #[inline(always)]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(x: T) -> Self {
        box x
    }

    /// निर्विवाद सामग्रीसह एक नवीन बॉक्स तयार करतो.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // स्थगित आरंभ:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn new_uninit() -> Box<mem::MaybeUninit<T>> {
        Self::new_uninit_in(Global)
    }

    /// `0` बाइट्सने मेमरी भरल्यामुळे, बिनविभाजित सामग्रीसह नवीन `Box` तयार करते.
    ///
    ///
    /// या पद्धतीच्या अचूक आणि चुकीच्या वापराच्या उदाहरणांसाठी [`MaybeUninit::zeroed`][zeroed] पहा.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let zero = Box::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[inline]
    #[doc(alias = "calloc")]
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Box<mem::MaybeUninit<T>> {
        Self::new_zeroed_in(Global)
    }

    /// नवीन `Pin<Box<T>>` तयार करते.
    /// जर `T` ने `Unpin` लागू केले नाही तर `x` मेमरीमध्ये पिन होईल आणि हलविण्यात अक्षम आहे.
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn pin(x: T) -> Pin<Box<T>> {
        (box x).into()
    }

    /// ढीग वर मेमरी वाटप करतो मग त्यात `x` ठेवते, वाटप अयशस्वी झाल्यास त्रुटी परत करते
    ///
    ///
    /// हे `T` शून्य-आकाराचे असल्यास प्रत्यक्षात त्याचे वाटप करत नाही.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// let five = Box::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(x: T) -> Result<Self, AllocError> {
        Self::try_new_in(x, Global)
    }

    /// ढिगा .्यावरील अविभाजीत सामग्रीसह एक नवीन बॉक्स तयार करतो, वाटप अयशस्वी झाल्यास त्रुटी परत करतो
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let mut five = Box::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // स्थगित आरंभ:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_uninit() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_uninit_in(Global)
    }

    /// ढीगावर `0` बाइट्ससह मेमरी भरल्यामुळे, बिनविभाज्य सामग्रीसह एक नवीन एक्स00 एक्स बनवते
    ///
    ///
    /// या पद्धतीच्या अचूक आणि चुकीच्या वापराच्या उदाहरणांसाठी [`MaybeUninit::zeroed`][zeroed] पहा.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let zero = Box::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_zeroed() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_zeroed_in(Global)
    }
}

impl<T, A: Allocator> Box<T, A> {
    /// दिलेल्या allocलोटरमध्ये मेमरी वाटप करते मग त्यामध्ये `x` ठेवते.
    ///
    /// हे `T` शून्य-आकाराचे असल्यास प्रत्यक्षात त्याचे वाटप करत नाही.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::new_in(5, System);
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn new_in(x: T, alloc: A) -> Self {
        let mut boxed = Self::new_uninit_in(alloc);
        unsafe {
            boxed.as_mut_ptr().write(x);
            boxed.assume_init()
        }
    }

    /// दिलेल्या allocलोटरमध्ये मेमरी वाटप करतो मग त्यात `x` ठेवते, वाटप अयशस्वी झाल्यास त्रुटी परत करते
    ///
    ///
    /// हे `T` शून्य-आकाराचे असल्यास प्रत्यक्षात त्याचे वाटप करत नाही.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::try_new_in(5, System)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new_in(x: T, alloc: A) -> Result<Self, AllocError> {
        let mut boxed = Self::try_new_uninit_in(alloc)?;
        unsafe {
            boxed.as_mut_ptr().write(x);
            Ok(boxed.assume_init())
        }
    }

    /// प्रदान केलेल्या allocलोटरमध्ये निर्विवाद सामग्रीसह एक नवीन बॉक्स तयार करतो.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::new_uninit_in(System);
    ///
    /// let five = unsafe {
    ///     // स्थगित आरंभ:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: कधीकधी इनलाइन नसल्यामुळे unwrap_or_else वर सामना पसंत करा.
        // त्यामुळे कोडचा आकार मोठा होईल.
        match Box::try_new_uninit_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// वाटप अयशस्वी झाल्यास त्रुटी परत करून प्रदान केलेल्या allocलोटरमध्ये निर्विवाद सामग्रीसह नवीन बॉक्स तयार करते
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::try_new_uninit_in(System)?;
    ///
    /// let five = unsafe {
    ///     // स्थगित आरंभ:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// प्रदान केलेल्या allocलोटरमध्ये `0` बाइट्ससह मेमरी भरल्यामुळे, निर्विवाद सामग्रीसह एक नवीन `Box` तयार करते.
    ///
    ///
    /// या पद्धतीच्या अचूक आणि चुकीच्या वापराच्या उदाहरणांसाठी [`MaybeUninit::zeroed`][zeroed] पहा.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::new_zeroed_in(System);
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: कधीकधी इनलाइन नसल्यामुळे unwrap_or_else वर सामना पसंत करा.
        // त्यामुळे कोडचा आकार मोठा होईल.
        match Box::try_new_zeroed_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// प्रदान केलेल्या atorलोकटरमध्ये `0` बाइट्ससह मेमरी भरल्यामुळे, वाटप अयशस्वी झाल्यास त्रुटी परत करून, निर्विवाद सामग्रीसह एक नवीन `Box` तयार करते,
    ///
    ///
    /// या पद्धतीच्या अचूक आणि चुकीच्या वापराच्या उदाहरणांसाठी [`MaybeUninit::zeroed`][zeroed] पहा.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::try_new_zeroed_in(System)?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate_zeroed(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// नवीन `Pin<Box<T, A>>` तयार करते.
    /// जर `T` ने `Unpin` लागू केले नाही तर `x` मेमरीमध्ये पिन होईल आणि हलविण्यात अक्षम आहे.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline(always)]
    pub fn pin_in(x: T, alloc: A) -> Pin<Self>
    where
        A: 'static,
    {
        Self::new_in(x, alloc).into()
    }

    /// `Box<T>` ला `Box<[T]>` मध्ये रूपांतरित करते
    ///
    /// हे रूपांतर ढीग वाटप होत नाही आणि त्या ठिकाणी होते.
    #[unstable(feature = "box_into_boxed_slice", issue = "71582")]
    pub fn into_boxed_slice(boxed: Self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(boxed);
        unsafe { Box::from_raw_in(raw as *mut [T; 1], alloc) }
    }

    /// गुंडाळलेले मूल्य परत करून, `Box` घेते.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(box_into_inner)]
    ///
    /// let c = Box::new(5);
    ///
    /// assert_eq!(Box::into_inner(c), 5);
    /// ```
    #[unstable(feature = "box_into_inner", issue = "80437")]
    #[inline]
    pub fn into_inner(boxed: Self) -> T {
        *boxed
    }
}

impl<T> Box<[T]> {
    /// निर्विवाद सामग्रीसह नवीन बॉक्सिंग स्लाइस तयार करते.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // स्थगित आरंभ:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity(len).into_box(len) }
    }

    /// एक्सटीएसएक्स बाइटसह मेमरी भरल्यामुळे, बिनविभाजित सामग्रीसह नवीन बॉक्सिंग स्लाइस तयार करते.
    ///
    ///
    /// या पद्धतीच्या अचूक आणि चुकीच्या वापराच्या उदाहरणांसाठी [`MaybeUninit::zeroed`][zeroed] पहा.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let values = Box::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity_zeroed(len).into_box(len) }
    }
}

impl<T, A: Allocator> Box<[T], A> {
    /// प्रदान केलेल्या allocलोटरमध्ये निर्विवाद सामग्रीसह नवीन बॉक्सिंग स्लाइस तयार करते.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut values = Box::<[u32], _>::new_uninit_slice_in(3, System);
    ///
    /// let values = unsafe {
    ///     // स्थगित आरंभ:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_in(len, alloc).into_box(len) }
    }

    /// `0` बाइटसह मेमरी भरल्यामुळे प्रदान केलेल्या allocलोटरमध्ये निर्विवाद सामग्रीसह नवीन बॉक्सिंग स्लाइस तयार करते.
    ///
    ///
    /// या पद्धतीच्या अचूक आणि चुकीच्या वापराच्या उदाहरणांसाठी [`MaybeUninit::zeroed`][zeroed] पहा.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let values = Box::<[u32], _>::new_zeroed_slice_in(3, System);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_zeroed_in(len, alloc).into_box(len) }
    }
}

impl<T, A: Allocator> Box<mem::MaybeUninit<T>, A> {
    /// `Box<T, A>` मध्ये रूपांतरित करते.
    ///
    /// # Safety
    ///
    /// एक्स 100 एक्स प्रमाणेच, मूल्य खरोखर आरंभिक स्थितीत आहे याची हमी देणे कॉल करणार्‍यावर अवलंबून आहे.
    ///
    /// जेव्हा सामग्री अद्याप पूर्णपणे प्रारंभ केलेली नसते तेव्हा कॉल केल्यास तत्काळ अपरिभाषित वर्तन होते.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five: Box<u32> = unsafe {
    ///     // स्थगित आरंभ:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<T, A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut T, alloc) }
    }
}

impl<T, A: Allocator> Box<[mem::MaybeUninit<T>], A> {
    /// `Box<[T], A>` मध्ये रूपांतरित करते.
    ///
    /// # Safety
    ///
    /// एक्स 100 एक्स प्रमाणेच, मूल्ये खरोखर आरंभिक स्थितीत असल्याची हमी देणे हे कॉल करणार्‍यावर अवलंबून आहे.
    ///
    /// जेव्हा सामग्री अद्याप पूर्णपणे प्रारंभ केलेली नसते तेव्हा कॉल केल्यास तत्काळ अपरिभाषित वर्तन होते.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // स्थगित आरंभ:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut [T], alloc) }
    }
}

impl<T: ?Sized> Box<T> {
    /// कच्च्या पॉईंटरमधून बॉक्स तयार करतो.
    ///
    /// या फंक्शनला कॉल केल्यानंतर, कच्चा पॉईंटर परिणामी `Box` च्या मालकीचा आहे.
    /// विशेषतः, `Box` डिस्ट्रक्टर `T` च्या डिस्ट्रक्टरला कॉल करेल आणि वाटप केलेल्या मेमरीला मुक्त करेल.
    /// हे सुरक्षित होण्यासाठी, `Box` द्वारे वापरलेल्या [memory layout] नुसार मेमरीचे वाटप केले गेले पाहिजे.
    ///
    ///
    /// # Safety
    ///
    /// हे कार्य असुरक्षित आहे कारण अयोग्य वापरामुळे मेमरीची समस्या उद्भवू शकते.
    /// उदाहरणार्थ, त्याच कच्च्या पॉइंटरवर फंक्शनला दोनदा कॉल केल्यास दुहेरी मुक्त होऊ शकते.
    ///
    /// सुरक्षा शर्तींचे वर्णन [memory layout] विभागात केले गेले आहे.
    ///
    /// # Examples
    ///
    /// एक `Box` पुन्हा तयार करा जो यापूर्वी [`Box::into_raw`] वापरून कच्च्या पॉईंटरमध्ये रुपांतरित झाला होता:
    ///
    /// ```
    /// let x = Box::new(5);
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// ग्लोबल atorलोकरेटरचा वापर करुन स्क्रॅचमधून मॅन्युअली `Box` तयार करा:
    ///
    /// ```
    /// use std::alloc::{alloc, Layout};
    ///
    /// unsafe {
    ///     let ptr = alloc(Layout::new::<i32>()) as *mut i32;
    ///     // सर्वसाधारणपणे .write ला `ptr` ची मागील सामग्री (uninitialized) नष्ट करण्याचा प्रयत्न करणे टाळणे आवश्यक आहे, जरी या सोप्या उदाहरणासाठी `*ptr = 5` ने देखील कार्य केले असते.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw(ptr);
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub unsafe fn from_raw(raw: *mut T) -> Self {
        unsafe { Self::from_raw_in(raw, Global) }
    }
}

impl<T: ?Sized, A: Allocator> Box<T, A> {
    /// दिलेल्या allocलोटरमध्ये कच्च्या पॉईंटरमधून बॉक्स तयार करतो.
    ///
    /// या फंक्शनला कॉल केल्यानंतर, कच्चा पॉईंटर परिणामी `Box` च्या मालकीचा आहे.
    /// विशेषतः, `Box` डिस्ट्रक्टर `T` च्या डिस्ट्रक्टरला कॉल करेल आणि वाटप केलेल्या मेमरीला मुक्त करेल.
    /// हे सुरक्षित होण्यासाठी, `Box` द्वारे वापरलेल्या [memory layout] नुसार मेमरीचे वाटप केले गेले पाहिजे.
    ///
    ///
    /// # Safety
    ///
    /// हे कार्य असुरक्षित आहे कारण अयोग्य वापरामुळे मेमरीची समस्या उद्भवू शकते.
    /// उदाहरणार्थ, त्याच कच्च्या पॉइंटरवर फंक्शनला दोनदा कॉल केल्यास दुहेरी मुक्त होऊ शकते.
    ///
    /// # Examples
    ///
    /// एक `Box` पुन्हा तयार करा जो यापूर्वी [`Box::into_raw_with_allocator`] वापरून कच्च्या पॉईंटरमध्ये रुपांतरित झाला होता:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(5, System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// सिस्टीम atorलोकटरचा वापर करून स्क्रॅचमधून मॅन्युअली `Box` तयार करा:
    ///
    /// ```
    /// #![feature(allocator_api, slice_ptr_get)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// unsafe {
    ///     let ptr = System.allocate(Layout::new::<i32>())?.as_mut_ptr();
    ///     // सर्वसाधारणपणे .write ला `ptr` ची मागील सामग्री (uninitialized) नष्ट करण्याचा प्रयत्न करणे टाळणे आवश्यक आहे, जरी या सोप्या उदाहरणासाठी `*ptr = 5` ने देखील कार्य केले असते.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw_in(ptr, System);
    /// }
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub unsafe fn from_raw_in(raw: *mut T, alloc: A) -> Self {
        Box(unsafe { Unique::new_unchecked(raw) }, alloc)
    }

    /// गुंडाळलेला कच्चा पॉईन्टर परत करून, `Box` घेतो.
    ///
    /// पॉईंटर योग्य प्रकारे संरेखित केले जाईल आणि शून्य असेल.
    ///
    /// या फंक्शनला कॉल केल्यानंतर, कॉलर पूर्वी एक्स00 एक्स द्वारे व्यवस्थापित केलेल्या मेमरीसाठी जबाबदार आहे.
    /// विशेषतः, कॉलरने `T` योग्यरित्या नष्ट केला पाहिजे आणि `Box` द्वारे वापरलेले [memory layout] विचारात घेऊन मेमरी सोडली पाहिजे.
    /// हे करण्याचा सर्वात सोपा मार्ग म्हणजे [`Box::from_raw`] फंक्शनद्वारे कच्चा पॉइंटर परत एक्स 100 एक्स मध्ये रुपांतरित करणे, ज्यामुळे एक्स0 2 एक्स डिस्ट्रक्टरला क्लिनअप करण्यास परवानगी दिली जा.
    ///
    ///
    /// Note: हे एक संबंधित कार्य आहे, याचा अर्थ असा की आपण त्यास `b.into_raw()` ऐवजी `Box::into_raw(b)` म्हणून कॉल करावे.
    /// हे असे आहे जेणेकरून अंतर्गत प्रकारात कोणत्याही पद्धतीचा विरोध नाही.
    ///
    /// # Examples
    /// स्वयंचलित क्लीनअपसाठी कच्चा पॉइंटर परत एक्स 100 एक्स मध्ये रुपांतरित करणे:
    ///
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// स्पष्टपणे डिस्ट्रॅक्टर चालवून आणि मेमरीचे विकृत करून मॅन्युअल क्लीनअप:
    ///
    /// ```
    /// use std::alloc::{dealloc, Layout};
    /// use std::ptr;
    ///
    /// let x = Box::new(String::from("Hello"));
    /// let p = Box::into_raw(x);
    /// unsafe {
    ///     ptr::drop_in_place(p);
    ///     dealloc(p as *mut u8, Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub fn into_raw(b: Self) -> *mut T {
        Self::into_raw_with_allocator(b).0
    }

    /// गुंडाळलेले कच्चे पॉइंटर आणि allocलोकरेटर परत करत `Box` घेते.
    ///
    /// पॉईंटर योग्य प्रकारे संरेखित केले जाईल आणि शून्य असेल.
    ///
    /// या फंक्शनला कॉल केल्यानंतर, कॉलर पूर्वी एक्स00 एक्स द्वारे व्यवस्थापित केलेल्या मेमरीसाठी जबाबदार आहे.
    /// विशेषतः, कॉलरने `T` योग्यरित्या नष्ट केला पाहिजे आणि `Box` द्वारे वापरलेले [memory layout] विचारात घेऊन मेमरी सोडली पाहिजे.
    /// हे करण्याचा सर्वात सोपा मार्ग म्हणजे [`Box::from_raw_in`] फंक्शनद्वारे कच्चा पॉइंटर परत एक्स 100 एक्स मध्ये रुपांतरित करणे, ज्यामुळे एक्स0 2 एक्स डिस्ट्रक्टरला क्लिनअप करण्यास परवानगी दिली जा.
    ///
    ///
    /// Note: हे एक संबंधित कार्य आहे, याचा अर्थ असा की आपण त्यास `b.into_raw_with_allocator()` ऐवजी `Box::into_raw_with_allocator(b)` म्हणून कॉल करावे.
    /// हे असे आहे जेणेकरून अंतर्गत प्रकारात कोणत्याही पद्धतीचा विरोध नाही.
    ///
    /// # Examples
    /// स्वयंचलित साफसफाईसाठी कच्चे पॉइंटरला पुन्हा एक्स 100 एक्स मध्ये रुपांतरित करणे:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// स्पष्टपणे डिस्ट्रॅक्टर चालवून आणि मेमरीचे विकृत करून मॅन्युअल क्लीनअप:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    /// use std::ptr::{self, NonNull};
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// unsafe {
    ///     ptr::drop_in_place(ptr);
    ///     let non_null = NonNull::new_unchecked(ptr);
    ///     alloc.deallocate(non_null.cast(), Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn into_raw_with_allocator(b: Self) -> (*mut T, A) {
        let (leaked, alloc) = Box::into_unique(b);
        (leaked.as_ptr(), alloc)
    }

    #[unstable(
        feature = "ptr_internals",
        issue = "none",
        reason = "use `Box::leak(b).into()` or `Unique::from(Box::leak(b))` instead"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn into_unique(b: Self) -> (Unique<T>, A) {
        // बॉक्सला स्टॅक्ड बोर्न्सद्वारे एक्स 100 एक्स म्हणून मान्यता प्राप्त आहे, परंतु अंतर्गतरित्या ते टाइप सिस्टमसाठी एक कच्चा सूचक आहे.
        // त्यास थेट कच्च्या पॉइंटरमध्ये रुपांतरित केल्याने एलिएस्ड कच्च्या प्रवेशास अनुमती देण्यासाठी अद्वितीय पॉईंटर "releasing" म्हणून ओळखले जाऊ शकत नाही, म्हणून सर्व कच्च्या पॉइंटर पद्धती `Box::leak` मधून जाव्या लागतात.
        //
        // *ते* कच्च्या पॉईंटरकडे वळविणे योग्य प्रकारे वर्तन करते.
        //
        let alloc = unsafe { ptr::read(&b.1) };
        (Unique::from(Box::leak(b)), alloc)
    }

    /// अंतर्निहित वाटप करणार्‍याचा संदर्भ मिळवते.
    ///
    /// Note: हे एक संबंधित कार्य आहे, याचा अर्थ असा की आपण त्यास `b.allocator()` ऐवजी `Box::allocator(&b)` म्हणून कॉल करावे.
    /// हे असे आहे जेणेकरून अंतर्गत प्रकारात कोणत्याही पद्धतीचा विरोध नाही.
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(b: &Self) -> &A {
        &b.1
    }

    /// `Box` घेते आणि लीक करते, एक बदलता संदर्भ परत करतो, `&'a mut T`.
    /// लक्षात घ्या की `T` प्रकाराने निवडलेल्या आजीवन `'a` ला मागे टाकणे आवश्यक आहे.
    /// प्रकारात फक्त स्थिर संदर्भ असल्यास किंवा काहीच नाही, तर हे `'static` म्हणून निवडले जाऊ शकते.
    ///
    /// हे कार्य मुख्यतः प्रोग्रामच्या उर्वरित जीवनासाठी डेटासाठी उपयुक्त आहे.
    /// परत केलेला संदर्भ टाकणे मेमरी गळतीस कारणीभूत ठरेल.
    /// हे स्वीकार्य नसल्यास, संदर्भ प्रथम `Box` एक्स फंक्शनसह गुंडाळावा जे `Box` तयार करतात.
    ///
    /// हे `Box` नंतर सोडले जाऊ शकते जे `T` योग्यरित्या नष्ट करेल आणि वाटप केलेली मेमरी सोडेल.
    ///
    /// Note: हे एक संबंधित कार्य आहे, याचा अर्थ असा की आपण त्यास `b.leak()` ऐवजी `Box::leak(b)` म्हणून कॉल करावे.
    /// हे असे आहे जेणेकरून अंतर्गत प्रकारात कोणत्याही पद्धतीचा विरोध नाही.
    ///
    /// # Examples
    ///
    /// साधा वापर:
    ///
    /// ```
    /// let x = Box::new(41);
    /// let static_ref: &'static mut usize = Box::leak(x);
    /// *static_ref += 1;
    /// assert_eq!(*static_ref, 42);
    /// ```
    ///
    /// आकार नसलेला डेटा:
    ///
    /// ```
    /// let x = vec![1, 2, 3].into_boxed_slice();
    /// let static_ref = Box::leak(x);
    /// static_ref[0] = 4;
    /// assert_eq!(*static_ref, [4, 2, 3]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "box_leak", since = "1.26.0")]
    #[inline]
    pub fn leak<'a>(b: Self) -> &'a mut T
    where
        A: 'a,
    {
        unsafe { &mut *mem::ManuallyDrop::new(b).0.as_ptr() }
    }

    /// `Box<T>` ला `Pin<Box<T>>` मध्ये रूपांतरित करते
    ///
    /// हे रूपांतर ढीग वाटप होत नाही आणि त्या ठिकाणी होते.
    ///
    /// हे [`From`] मार्गे देखील उपलब्ध आहे.
    #[unstable(feature = "box_into_pin", issue = "62370")]
    pub fn into_pin(boxed: Self) -> Pin<Self>
    where
        A: 'static,
    {
        // `T: !Unpin` असताना `Pin<Box<T>>` चे आतील भाग हलविणे किंवा पुनर्स्थित करणे शक्य नाही, म्हणून कोणत्याही अतिरिक्त आवश्यकताशिवाय थेट पिन करणे सुरक्षित आहे.
        //
        //
        unsafe { Pin::new_unchecked(boxed) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized, A: Allocator> Drop for Box<T, A> {
    fn drop(&mut self) {
        // FIXME: काहीही करू नका, ड्रॉप सध्या कंपाईलरद्वारे केले जाते.
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Box<T> {
    /// टी साठी एक्स 0 एक्स एक्स मूल्यासह एक एक्स 100 एक्स तयार करते.
    fn default() -> Self {
        box T::default()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Box<[T]> {
    fn default() -> Self {
        Box::<[T; 0]>::new([])
    }
}

#[stable(feature = "default_box_extra", since = "1.17.0")]
impl Default for Box<str> {
    fn default() -> Self {
        unsafe { from_boxed_utf8_unchecked(Default::default()) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<T, A> {
    /// या बॉक्समधील सामग्रीच्या `clone()` सह एक नवीन बॉक्स मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let y = x.clone();
    ///
    /// // मूल्य समान आहे
    /// assert_eq!(x, y);
    ///
    /// // पण त्या अद्वितीय वस्तू आहेत
    /// assert_ne!(&*x as *const i32, &*y as *const i32);
    /// ```
    #[inline]
    fn clone(&self) -> Self {
        // क्लोन केलेले मूल्य थेट लिहिण्याची परवानगी देण्यासाठी पूर्व-वाटप मेमरी.
        let mut boxed = Self::new_uninit_in(self.1.clone());
        unsafe {
            (**self).write_clone_into_raw(boxed.as_mut_ptr());
            boxed.assume_init()
        }
    }

    /// नवीन creatingलोकेशन तयार न करता `स्त्रोत` च्या सामग्री `self` मध्ये कॉपी करा.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let mut y = Box::new(10);
    /// let yp: *const i32 = &*y;
    ///
    /// y.clone_from(&x);
    ///
    /// // मूल्य समान आहे
    /// assert_eq!(x, y);
    ///
    /// // आणि कोणतेही वाटप झाले नाही
    /// assert_eq!(yp, &*y);
    /// ```
    #[inline]
    fn clone_from(&mut self, source: &Self) {
        (**self).clone_from(&(**source));
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl Clone for Box<str> {
    fn clone(&self) -> Self {
        // हे डेटाची एक प्रत बनवते
        let buf: Box<[u8]> = self.as_bytes().into();
        unsafe { from_boxed_utf8_unchecked(buf) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq, A: Allocator> PartialEq for Box<T, A> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        PartialEq::eq(&**self, &**other)
    }
    #[inline]
    fn ne(&self, other: &Self) -> bool {
        PartialEq::ne(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd, A: Allocator> PartialOrd for Box<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
    #[inline]
    fn lt(&self, other: &Self) -> bool {
        PartialOrd::lt(&**self, &**other)
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        PartialOrd::le(&**self, &**other)
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        PartialOrd::ge(&**self, &**other)
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        PartialOrd::gt(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord, A: Allocator> Ord for Box<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq, A: Allocator> Eq for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash, A: Allocator> Hash for Box<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<T: ?Sized + Hasher, A: Allocator> Hasher for Box<T, A> {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Box<T> {
    /// जेनेरिक प्रकार `T` ला `Box<T>` मध्ये रुपांतरीत करते
    ///
    /// रूपांतरण ढीग वर वाटप करते आणि त्यामध्ये स्टॅकमधून एक्स00 एक्स हलवते.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let x = 5;
    /// let boxed = Box::new(5);
    ///
    /// assert_eq!(Box::from(x), boxed);
    /// ```
    fn from(t: T) -> Self {
        Box::new(t)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> From<Box<T, A>> for Pin<Box<T, A>>
where
    A: 'static,
{
    /// `Box<T>` ला `Pin<Box<T>>` मध्ये रूपांतरित करते
    ///
    /// हे रूपांतर ढीग वाटप होत नाही आणि त्या ठिकाणी होते.
    fn from(boxed: Box<T, A>) -> Self {
        Box::into_pin(boxed)
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl<T: Copy> From<&[T]> for Box<[T]> {
    /// `&[T]` ला `Box<[T]>` मध्ये रूपांतरित करते
    ///
    /// हे रूपांतर ढीगवर वाटप करते आणि `slice` ची प्रत करते.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // एक&[u8] तयार करा जो बॉक्स <[u8]> तयार करण्यासाठी वापरला जाईल
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice: Box<[u8]> = Box::from(slice);
    ///
    /// println!("{:?}", boxed_slice);
    /// ```
    fn from(slice: &[T]) -> Box<[T]> {
        let len = slice.len();
        let buf = RawVec::with_capacity(len);
        unsafe {
            ptr::copy_nonoverlapping(slice.as_ptr(), buf.ptr(), len);
            buf.into_box(slice.len()).assume_init()
        }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl<T: Copy> From<Cow<'_, [T]>> for Box<[T]> {
    #[inline]
    fn from(cow: Cow<'_, [T]>) -> Box<[T]> {
        match cow {
            Cow::Borrowed(slice) => Box::from(slice),
            Cow::Owned(slice) => Box::from(slice),
        }
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl From<&str> for Box<str> {
    /// `&str` ला `Box<str>` मध्ये रूपांतरित करते
    ///
    /// हे रूपांतर ढीगवर वाटप करते आणि `s` ची प्रत करते.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<str> = Box::from("hello");
    /// println!("{}", boxed);
    /// ```
    #[inline]
    fn from(s: &str) -> Box<str> {
        unsafe { from_boxed_utf8_unchecked(Box::from(s.as_bytes())) }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl From<Cow<'_, str>> for Box<str> {
    #[inline]
    fn from(cow: Cow<'_, str>) -> Box<str> {
        match cow {
            Cow::Borrowed(s) => Box::from(s),
            Cow::Owned(s) => Box::from(s),
        }
    }
}

#[stable(feature = "boxed_str_conv", since = "1.19.0")]
impl<A: Allocator> From<Box<str, A>> for Box<[u8], A> {
    /// `Box<str>` ला `Box<[u8]>` मध्ये रूपांतरित करते
    /// हे रूपांतर ढीग वाटप होत नाही आणि त्या ठिकाणी होते.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // एक बॉक्स तयार करा<str>जो एक बॉक्स <[u8]> तयार करण्यासाठी वापरला जाईल
    /// let boxed: Box<str> = Box::from("hello");
    /// let boxed_str: Box<[u8]> = Box::from(boxed);
    ///
    /// // एक&[u8] तयार करा जो बॉक्स <[u8]> तयार करण्यासाठी वापरला जाईल
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice = Box::from(slice);
    ///
    /// assert_eq!(boxed_slice, boxed_str);
    /// ```
    #[inline]
    fn from(s: Box<str, A>) -> Self {
        let (raw, alloc) = Box::into_raw_with_allocator(s);
        unsafe { Box::from_raw_in(raw as *mut [u8], alloc) }
    }
}

#[stable(feature = "box_from_array", since = "1.45.0")]
impl<T, const N: usize> From<[T; N]> for Box<[T]> {
    /// `[T; N]` ला `Box<[T]>` मध्ये रूपांतरित करते
    /// हे रूपांतरण अ‍रेला नवीन हिप-वाटप केलेल्या मेमरीवर हलवते.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<[u8]> = Box::from([4, 2]);
    /// println!("{:?}", boxed);
    /// ```
    fn from(array: [T; N]) -> Box<[T]> {
        box array
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Box<[T]>> for Box<[T; N]> {
    type Error = Box<[T]>;

    fn try_from(boxed_slice: Box<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Box::from_raw(Box::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

impl<A: Allocator> Box<dyn Any, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// कॉंक्रीट प्रकारात बॉक्स डाउनकास्ट करण्याचा प्रयत्न.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut dyn Any, _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// कॉंक्रीट प्रकारात बॉक्स डाउनकास्ट करण्याचा प्रयत्न.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send), _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send + Sync, A> {
    #[inline]
    #[stable(feature = "box_send_sync_any_downcast", since = "1.51.0")]
    /// कॉंक्रीट प्रकारात बॉक्स डाउनकास्ट करण्याचा प्रयत्न.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send + Sync), _) =
                    Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized, A: Allocator> fmt::Display for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug + ?Sized, A: Allocator> fmt::Debug for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> fmt::Pointer for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // आतील युनिक थेट बॉक्समधून काढणे शक्य नाही, त्याऐवजी आम्ही त्या अद्वितीय व्यक्तीचे नाव असलेल्या कॉन्स्टेटवर टाकले.
        //
        let ptr: *const T = &**self;
        fmt::Pointer::fmt(&ptr, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> Deref for Box<T, A> {
    type Target = T;

    fn deref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> DerefMut for Box<T, A> {
    fn deref_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized, A: Allocator> Receiver for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized, A: Allocator> Iterator for Box<I, A> {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth(n)
    }
    fn last(self) -> Option<I::Item> {
        BoxIter::last(self)
    }
}

trait BoxIter {
    type Item;
    fn last(self) -> Option<Self::Item>;
}

impl<I: Iterator + ?Sized, A: Allocator> BoxIter for Box<I, A> {
    type Item = I::Item;
    default fn last(self) -> Option<I::Item> {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }
}

/// डीफॉल्टऐवजी `last()` च्या s I`s च्या अंमलबजावणीचा वापर करणार्‍या आकाराच्या`I fors साठी विशेषीकरण.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator, A: Allocator> BoxIter for Box<I, A> {
    fn last(self) -> Option<I::Item> {
        (*self).last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: DoubleEndedIterator + ?Sized, A: Allocator> DoubleEndedIterator for Box<I, A> {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized, A: Allocator> ExactSizeIterator for Box<I, A> {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized, A: Allocator> FusedIterator for Box<I, A> {}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnOnce<Args> + ?Sized, A: Allocator> FnOnce<Args> for Box<F, A> {
    type Output = <F as FnOnce<Args>>::Output;

    extern "rust-call" fn call_once(self, args: Args) -> Self::Output {
        <F as FnOnce<Args>>::call_once(*self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnMut<Args> + ?Sized, A: Allocator> FnMut<Args> for Box<F, A> {
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output {
        <F as FnMut<Args>>::call_mut(self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: Fn<Args> + ?Sized, A: Allocator> Fn<Args> for Box<F, A> {
    extern "rust-call" fn call(&self, args: Args) -> Self::Output {
        <F as Fn<Args>>::call(self, args)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized, A: Allocator> CoerceUnsized<Box<U, A>> for Box<T, A> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Box<U>> for Box<T, Global> {}

#[stable(feature = "boxed_slice_from_iter", since = "1.32.0")]
impl<I> FromIterator<I> for Box<[I]> {
    fn from_iter<T: IntoIterator<Item = I>>(iter: T) -> Self {
        iter.into_iter().collect::<Vec<_>>().into_boxed_slice()
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<[T], A> {
    fn clone(&self) -> Self {
        let alloc = Box::allocator(self).clone();
        self.to_vec_in(alloc).into_boxed_slice()
    }

    fn clone_from(&mut self, other: &Self) {
        if self.len() == other.len() {
            self.clone_from_slice(&other);
        } else {
            *self = other.clone();
        }
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::Borrow<T> for Box<T, A> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::BorrowMut<T> for Box<T, A> {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsRef<T> for Box<T, A> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsMut<T> for Box<T, A> {
    fn as_mut(&mut self) -> &mut T {
        &mut **self
    }
}

/* Nota bene
 *
 *  We could have chosen not to add this impl, and instead have written a
 *  function of Pin<Box<T>> to Pin<T>. Such a function would not be sound,
 *  because Box<T> implements Unpin even when T does not, as a result of
 *  this impl.
 *
 *  We chose this API instead of the alternative for a few reasons:
 *      - Logically, it is helpful to understand pinning in regard to the
 *        memory region being pointed to. For this reason none of the
 *        standard library pointer types support projecting through a pin
 *        (Box<T> is the only pointer type in std for which this would be
 *        safe.)
 *      - It is in practice very useful to have Box<T> be unconditionally
 *        Unpin because of trait objects, for which the structural auto
 *        trait functionality does not apply (e.g., Box<dyn Foo> would
 *        otherwise not be Unpin).
 *
 *  Another type with the same semantics as Box but only a conditional
 *  implementation of `Unpin` (where `T: Unpin`) would be valid/safe, and
 *  could have a method to project a Pin<T> from it.
 */
#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> Unpin for Box<T, A> where A: 'static {}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R, A: Allocator> Generator<R> for Box<G, A>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R, A: Allocator> Generator<R> for Pin<Box<G, A>>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin, A: Allocator> Future for Box<F, A>
where
    A: 'static,
{
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut *self), cx)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for Box<S> {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        Pin::new(&mut **self).poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}