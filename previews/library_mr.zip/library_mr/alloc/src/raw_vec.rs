#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// नवीन मेमरीची सामग्री बिनविभाजित केली गेली आहे.
    Uninitialized,
    /// नवीन मेमरी शून्य होण्याची हमी आहे.
    Zeroed,
}

/// अधिक कार्यक्षमतेने एगोनॉमीली वाटप करणे, रीलोकॅकेट करणे आणि मेमरीचा बफर कमी करणे यासाठी गुंतलेली सर्व कोपरा प्रकरणांची चिंता न करता.
///
/// हा प्रकार आपल्या स्वत: च्या डेटा स्ट्रक्चर्स जसे की वेक आणि वेकडेक तयार करण्यासाठी उत्कृष्ट आहे.
/// विशेषतः:
///
/// * शून्य-आकाराच्या प्रकारांवर `Unique::dangling()` तयार करते.
/// * शून्य-लांबीच्या वाटपांवर `Unique::dangling()` तयार करते.
/// * `Unique::dangling()` मुक्त करणे टाळते.
/// * क्षमता संगणकात सर्व ओव्हरफ्लो कॅच करते (त्यांना एक्स 100 एक्स झेड 0 पॅनिक्स 0 झेडमध्ये प्रोत्साहित करते).
/// * isize::MAX बाइटपेक्षा जास्त वाटप 32-बिट सिस्टम विरूद्ध रक्षक.
/// * आपली लांबी ओव्हरफ्लो करण्यापासून संरक्षण करणारे.
/// * फॉलिबल ationsलोकेशनसाठी `handle_alloc_error` कॉल करा.
/// * एक `ptr::Unique` समाविष्टीत आहे आणि अशा प्रकारे वापरकर्त्यास सर्व संबंधित फायद्यांसह प्रदान करते.
/// * सर्वात मोठी उपलब्ध क्षमता वापरण्यासाठी वाटपकर्त्याकडून परत आलेल्या जास्तीचा वापर करते.
///
/// हा प्रकार व्यवस्थापित केलेल्या मेमरीची तरीही तपासणी करत नाही.सोडल्यास *त्याची मेमरी* मुक्त होईल, परंतु ती त्यातील सामग्री सोडण्याचा प्रयत्न करणार नाही *.
/// हे X01 एक्स च्या वापरकर्त्याचे आहे की आपण `RawVec` च्या आत *संग्रहित* वास्तविक गोष्टी हाताळू शकता.
///
/// लक्षात घ्या की शून्य-आकाराच्या प्रकारांपेक्षा जास्तीचे प्रमाण नेहमीच असीम असते, म्हणून एक्स 0 एक्स एक्स नेहमी एक्स एक्स एक्स परत करते.
/// याचा अर्थ असा आहे की X01 एक्स लांबी देणार नाही, म्हणून या प्रकारच्या एक्स 100 एक्स सह फेरी मारताना आपण सावधगिरी बाळगणे आवश्यक आहे.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): हे अस्तित्वात आहे कारण `#[unstable]` `const fn`s ला `min_const_fn` चे अनुरूप असणे आवश्यक नाही आणि म्हणून त्यांना either min_const_fn`s मध्ये देखील कॉल केले जाऊ शकत नाही.
    ///
    /// आपण `RawVec<T>::new` किंवा अवलंबन बदलल्यास, कृपया `min_const_fn` चे उल्लंघन करणार्‍या कोणत्याही गोष्टीची ओळख न लावण्याची काळजी घ्या.
    ///
    /// NOTE: आम्ही हे खाच टाळू शकलो आणि `min_const_fn` सह काही कॉन्फरन्समेंट आवश्यक असलेल्या काही `#[rustc_force_min_const_fn]` एट्रिब्यूटसह कॉन्फरमन्स तपासू शकलो परंतु `#[rustc_const_unstable(feature = "foo", issue = "01234")]` उपस्थित असताना `stable(...) const fn`/यूजर कोडमध्ये तो कॉल करण्यास अनुमती देत नाही.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// वाटप न करता सर्वात मोठे शक्य `RawVec` (सिस्टम ढीग वर) तयार करते.
    /// जर `T` चे सकारात्मक आकार असल्यास, हे क्षमतेसह X02 एक्स बनवते `0`.
    /// जर X01 एक्स शून्य-आकाराचा असेल तर ते क्षमतेसह `usize::MAX` बनवेल `usize::MAX`.
    /// उशीरा वाटप अंमलबजावणीसाठी उपयुक्त.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// `[T; capacity]` साठी नेमकी क्षमता आणि संरेखन आवश्यकतांसह एक `RawVec` (सिस्टम हीपवर) तयार करते.
    /// जेव्हा एक्स 0 एक्स एक्स एक्स 2 एक्स आहे किंवा एक्स 0 एक्स एक्स शून्य-आकाराचा असेल तेव्हा हे एक्स 100 एक्स कॉल करण्यासारखे आहे.
    /// लक्षात घ्या की `T` शून्य-आकाराचे असेल तर याचा अर्थ असा की आपल्याला विनंती केलेल्या क्षमतेसह `RawVec` मिळणार नाही.
    ///
    /// # Panics
    ///
    /// विनंती केलेली क्षमता `isize::MAX` बाइटपेक्षा जास्त असल्यास Panics.
    ///
    /// # Aborts
    ///
    /// ओओएम वर विमोचन.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// `with_capacity` प्रमाणे, परंतु बफर शून्य असल्याची हमी देते.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// पॉईंटर आणि क्षमतेपासून `RawVec` ची पुनर्स्थापना करते.
    ///
    /// # Safety
    ///
    /// `ptr` (सिस्टम ढीग वर) आणि दिलेल्या `capacity` सह वाटप करणे आवश्यक आहे.
    /// आकाराच्या प्रकारांसाठी `capacity` `isize::MAX` पेक्षा जास्त होऊ शकत नाही.(केवळ 32-बिट सिस्टमवरील चिंता).
    /// ZST vectors ची क्षमता `usize::MAX` पर्यंत असू शकते.
    /// जर `ptr` आणि `capacity` `RawVec` मधून आला असेल तर याची हमी दिलेली आहे.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // लहान वेक्स मुका आहेत.यावर जा:
    // - 8 जर घटकांचा आकार 1 असेल तर कोणत्याही ढीग वाटपकर्त्यांकडून 8 बाइटपेक्षा कमीतकमी 8 बाइटची विनंती केली जाईल.
    //
    // - 4 जर घटक मध्यम-आकाराचे (<=1 KiB) असतील.
    // - 1 अन्यथा, फारच कमी वेस्कसाठी जास्त जागा वाया घालवू नये.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// `new` प्रमाणे, परंतु परत केलेल्या `RawVec` साठी वाटप करणार्‍याच्या निवडीबद्दल पॅरामीराइज्ड
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` म्हणजे "unallocated".शून्य-आकाराचे प्रकार दुर्लक्षित केले जातात.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// `with_capacity` प्रमाणे, परंतु परत केलेल्या `RawVec` साठी वाटप करणार्‍याच्या निवडीबद्दल पॅरामीराइज्ड
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// `with_capacity_zeroed` प्रमाणे, परंतु परत केलेल्या `RawVec` साठी वाटप करणार्‍याच्या निवडीबद्दल पॅरामीराइज्ड
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// `Box<[T]>` ला `RawVec<T>` मध्ये रूपांतरित करते.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// निर्दिष्ट `len` सह संपूर्ण बफरला `Box<[MaybeUninit<T>]>` मध्ये रुपांतरीत करते.
    ///
    /// लक्षात घ्या की हे केलेले कोणतेही `cap` बदल योग्यरित्या पुनर्रचना करेल.(तपशीलासाठी प्रकाराचे वर्णन पहा.)
    ///
    /// # Safety
    ///
    /// * `len` सर्वात अलीकडील विनंती केलेल्या क्षमतेपेक्षा किंवा त्यापेक्षा जास्त असणे आवश्यक आहे
    /// * `len` `self.capacity()` पेक्षा कमी किंवा त्यासमान असणे आवश्यक आहे.
    ///
    /// लक्षात ठेवा, विनंती केलेली क्षमता आणि `self.capacity()` भिन्न असू शकतात, कारण एक वाटपकर्ता एकत्रीत होऊ शकतो आणि विनंतीपेक्षा मोठा मेमरी ब्लॉक परत करू शकतो.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // सेफ्टी आवश्यकतेच्या अर्ध्या भागाची तपासणी करा (आम्ही बाकीचा अर्धा भाग तपासू शकत नाही).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // आम्ही येथे एक्स00 एक्स टाळतो कारण ते व्युत्पन्न केलेल्या एलएलव्हीएम आयआरची मात्रा फुगवित आहे.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// पॉईंटर, क्षमता आणि allocलोकरेटरकडून `RawVec` ची पुनर्स्थापना करते.
    ///
    /// # Safety
    ///
    /// `ptr` वाटप करणे आवश्यक आहे (दिलेल्या अ‍ॅलॉकेटर `alloc` मार्गे) आणि दिलेल्या `capacity` सह.
    /// आकाराच्या प्रकारांसाठी `capacity` `isize::MAX` पेक्षा जास्त होऊ शकत नाही.
    /// (केवळ 32-बिट सिस्टमवरील चिंता).
    /// ZST vectors ची क्षमता `usize::MAX` पर्यंत असू शकते.
    /// जर `ptr` आणि `capacity` हे `alloc` द्वारे निर्मित केलेल्या `RawVec` वरून आले असेल तर याची हमी दिलेली आहे.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// वाटपाच्या सुरूवातीस कच्चा सूचक मिळतो.
    /// `capacity == 0` किंवा `T` शून्य-आकाराचे असल्यास हे `Unique::dangling()` आहे हे लक्षात घ्या.
    /// पूर्वीच्या बाबतीत, आपण सावधगिरी बाळगणे आवश्यक आहे.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// वाटपाची क्षमता मिळते.
    ///
    /// जर एक्स 0 एक्स एक्स शून्य-आकाराचा असेल तर हे नेहमीच एक्स 100 एक्स असेल.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// या `RawVec` चे समर्थन करत असलेल्या allocलोटरेटरला सामायिक केलेला संदर्भ परत करते.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // आमच्याकडे मेमरीचा एक हिस्सा आहे, ज्यामुळे आम्ही आमचा सद्य लेआउट मिळविण्यासाठी रनटाइम चेकला बायपास करू शकतो.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// हे सुनिश्चित करते की बफरमध्ये `len + additional` घटक ठेवण्यासाठी कमीत कमी पुरेशी जागा आहे.
    /// त्याच्याकडे आधीपासूनच पुरेशी क्षमता नसल्यास, परिपूर्ण *ओ*(१) वर्तन मिळविण्यासाठी पुरेशी जागा आणि आरामदायक स्लॅक स्पेस पुनर्विकृत करेल.
    ///
    /// जर हे अनावश्यकपणे स्वत: ला panic वर कारणीभूत असेल तर या वर्तनास मर्यादित करेल.
    ///
    /// `len` `self.capacity()` पेक्षा जास्त असल्यास, विनंती केलेली जागा वाटण्यात हे अयशस्वी होऊ शकते.
    /// हे खरोखर असुरक्षित नाही, परंतु या कार्याच्या वर्तनावर अवलंबून असलेला आपण * लिहित असलेला असुरक्षित कोड तुटू शकतो.
    ///
    /// हे `extend` सारख्या बल्क-पुश ऑपरेशनच्या अंमलबजावणीसाठी आदर्श आहे.
    ///
    /// # Panics
    ///
    /// नवीन क्षमता `isize::MAX` बाइटपेक्षा अधिक असल्यास Panics.
    ///
    /// # Aborts
    ///
    /// ओओएम वर विमोचन.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // जर लेनने `isize::MAX` ओलांडली असेल तर रिझर्व रद्द करणे किंवा घाबरू शकले असते जेणेकरून हे आता अनचेक करणे सुरक्षित आहे.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// `reserve` प्रमाणेच, परंतु घाबरून किंवा गर्भपात करण्याऐवजी त्रुटींवर परत येते.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// हे सुनिश्चित करते की बफरमध्ये `len + additional` घटक ठेवण्यासाठी कमीत कमी पुरेशी जागा आहे.
    /// हे आधीपासून नसल्यास, आवश्यक मेमरीची किमान संभाव्य प्रमाणात पुनर्स्थित करेल.
    /// साधारणत: हे आवश्यक तेवढे मेमरीचे प्रमाण असेल, परंतु तत्त्वानुसार वाटपकर्ता आम्हाला मागण्यापेक्षा परत देण्यास मोकळे आहे.
    ///
    ///
    /// `len` `self.capacity()` पेक्षा जास्त असल्यास, विनंती केलेली जागा वाटण्यात हे अयशस्वी होऊ शकते.
    /// हे खरोखर असुरक्षित नाही, परंतु या कार्याच्या वर्तनावर अवलंबून असलेला आपण * लिहित असलेला असुरक्षित कोड तुटू शकतो.
    ///
    /// # Panics
    ///
    /// नवीन क्षमता `isize::MAX` बाइटपेक्षा अधिक असल्यास Panics.
    ///
    /// # Aborts
    ///
    /// ओओएम वर विमोचन.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// `reserve_exact` प्रमाणेच, परंतु घाबरून किंवा गर्भपात करण्याऐवजी त्रुटींवर परत येते.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// निर्दिष्ट रकमेवर वाटप कमी करते.
    /// जर दिलेली रक्कम 0 असेल तर प्रत्यक्षात पूर्णपणे कमी होते.
    ///
    /// # Panics
    ///
    /// दिलेली रक्कम सध्याच्या क्षमतेपेक्षा *मोठी* असल्यास Panics.
    ///
    /// # Aborts
    ///
    /// ओओएम वर विमोचन.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// आवश्यक अतिरिक्त क्षमता पूर्ण करण्यासाठी बफरला वाढण्याची आवश्यकता असल्यास परत येते.
    /// `grow` इनलाइन न करता इनलाइनिंग रिझर्व कॉल करणे शक्यतेसाठी वापरले जाते.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // ही पद्धत सहसा बर्‍याच वेळा इन्स्टंट केली जाते.कंपाईल वेळा सुधारण्यासाठी ते शक्य तितके लहान असले पाहिजे.
    // परंतु व्युत्पन्न केलेला कोड अधिक वेगवान चालविण्यासाठी आम्ही त्यातील जास्तीत जास्त सामग्री स्टॅटिकली कंप्यूट करण्यायोग्य देखील इच्छित आहोत.
    // म्हणून ही पद्धत काळजीपूर्वक लिहिली गेली आहे जेणेकरुन `T` वर अवलंबून असलेला सर्व कोड त्यामध्ये असेल तर `T` वर अवलंबून नसलेला जास्तीत जास्त कोड `T` पेक्षा अधिक जेनेरिक नसलेल्या फंक्शन्समध्ये आहे.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // कॉलिंग संदर्भांद्वारे याची खात्री केली जाते.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // `elem_size` असते तेव्हा आम्ही `usize::MAX` ची क्षमता परत करतो
            // 0, येथे पोचणे म्हणजेच `RawVec` ओव्हरफुल आहे.
            return Err(CapacityOverflow);
        }

        // दुर्दैवाने या धनादेशांबद्दल आपण खरोखर काहीही करू शकत नाही.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // हे घातांकीय विकासाची हमी देते.
        // दुप्पट ओव्हरफ्लो होऊ शकत नाही कारण `cap <= isize::MAX` आणि `cap` चा प्रकार `usize` आहे.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` हे एक्स-एक्स एक्स पेक्षा जास्त सामान्य आहे.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // या पद्धतीवरील अडचणी `grow_amortized` वरील प्रमाणेच आहेत, परंतु ही पद्धत सहसा कमी वेळा इंस्टंट केली जाते म्हणून ती कमी गंभीर असते.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // जेव्हा प्रकारचा आकार असतो तेव्हा आम्ही `usize::MAX` ची क्षमता परत करतो
            // 0, येथे पोचणे म्हणजेच `RawVec` ओव्हरफुल आहे.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` हे एक्स-एक्स एक्स पेक्षा जास्त सामान्य आहे.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// कंपाईल वेळा कमी करण्यासाठी हे कार्य `RawVec` च्या बाहेर आहे.तपशीलांसाठी `RawVec::grow_amortized` वरील टिप्पणी पहा.
// (`A` मापदंड महत्त्वपूर्ण नाही, कारण सराव मध्ये दिसणार्‍या भिन्न `A` प्रकारांची संख्या `T` प्रकारच्या संख्येपेक्षा खूपच लहान आहे.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // `RawVec::grow_*` चा आकार कमी करण्यासाठी येथे त्रुटीसाठी तपासा.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // वाटपकर्ता संरेखन समानतेसाठी तपासणी करतो
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// `RawVec`*च्या मालकीच्या मेमरीला* त्यातील सामग्री सोडण्याचा प्रयत्न न करता मुक्त करते.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// राखीव त्रुटी हाताळणीसाठी मध्यवर्ती कार्य.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// आम्हाला पुढील हमी देणे आवश्यक आहे:
// * आम्ही कधीही एक्स 100 एक्स बाइट-साइज ऑब्जेक्टचे वाटप करीत नाही.
// * आम्ही `usize::MAX` ओव्हरफ्लो करत नाही आणि प्रत्यक्षात फारच कमी वाटप करतो.
//
// -64-बिट वर आम्हाला फक्त ओव्हरफ्लो तपासण्याची आवश्यकता आहे कारण एक्स १० एक्स बाइट्सचे वाटप करण्याचा प्रयत्न नक्कीच अपयशी ठरेल.
// - २-बिट आणि १--बिट वर आम्हाला याकरिता अतिरिक्त गार्ड जोडण्याची आवश्यकता आहे जर आम्ही एका व्यासपीठावर चालत असाल जे उपभोक्त्यामध्ये सर्व GB जीबी वापरू शकेल, उदा. पीएई किंवा एक्स १०००
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// क्षमतेच्या ओव्हरफ्लोस अहवाल देण्यासाठी जबाबदार असलेले एक केंद्रीय कार्य.
// हे सुनिश्चित करेल की या झेडस्पॅनिक्स 0 झेडशी संबंधित कोड जनरेशन कमीतकमी आहे कारण तेथे संपूर्ण मॉड्यूलमध्ये घड होण्याऐवजी झेडस्पॅनिक्स 0 झेडचे फक्त एक स्थान आहे.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}