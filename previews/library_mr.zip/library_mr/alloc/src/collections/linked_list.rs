//! मालकीच्या नोड्ससह दुप्पट-लिंक केलेली सूची.
//!
//! `LinkedList` सतत वेळेत एकतर शेवटी घटकांना धक्का आणि पॉपिंग करण्यास अनुमती देते.
//!
//! NOTE: [`Vec`] किंवा [`VecDeque`] वापरणे जवळजवळ नेहमीच चांगले असते कारण अ‍ॅरे-आधारित कंटेनर सामान्यत: वेगवान, अधिक मेमरी कार्यक्षम असतात आणि सीपीयू कॅशेचा अधिक चांगला वापर करतात.
//!
//!
//! [`Vec`]: crate::vec::Vec
//! [`VecDeque`]: super::vec_deque::VecDeque
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::Ordering;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem;
use core::ptr::NonNull;

use super::SpecExtend;
use crate::boxed::Box;

#[cfg(test)]
mod tests;

/// मालकीच्या नोड्ससह दुप्पट-लिंक केलेली सूची.
///
/// `LinkedList` सतत वेळेत एकतर शेवटी घटकांना धक्का आणि पॉपिंग करण्यास अनुमती देते.
///
/// NOTE: `Vec` किंवा `VecDeque` वापरणे जवळजवळ नेहमीच चांगले असते कारण अ‍ॅरे-आधारित कंटेनर सामान्यत: वेगवान, अधिक मेमरी कार्यक्षम असतात आणि सीपीयू कॅशेचा अधिक चांगला वापर करतात.
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "LinkedList")]
pub struct LinkedList<T> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<Box<Node<T>>>,
}

struct Node<T> {
    next: Option<NonNull<Node<T>>>,
    prev: Option<NonNull<Node<T>>>,
    element: T,
}

/// `LinkedList` च्या घटकांवरील एक पुनरावृत्तीकर्ता.
///
/// हे `struct` [`LinkedList::iter()`] द्वारे तयार केले गेले आहे.
/// अधिकसाठी त्याचे दस्तऐवजीकरण पहा.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<&'a Node<T>>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.len).finish()
    }
}

// FIXME(#26925) `#[derive(Clone)]` च्या बाजूने काढा
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { ..*self }
    }
}

/// `LinkedList` च्या घटकांवर बदलता येणारा पुनरावृत्ती करणारा.
///
/// हे `struct` [`LinkedList::iter_mut()`] द्वारे तयार केले गेले आहे.
/// अधिकसाठी त्याचे दस्तऐवजीकरण पहा.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    // आम्ही येथे संपूर्ण यादीचा पूर्णपणे मालकीचा *नाही* करीत आहोत, नोडच्या एक्स ०१ एक्सचे संदर्भ पुनरावृत्तीकर्त्याद्वारे दिले गेले आहेत!म्हणून हे वापरताना काळजी घ्या;म्हटल्या गेलेल्या पद्धतींमध्ये हे माहित असले पाहिजे की `element` वर अलियासिंग पॉईंटर्स असू शकतात.
    //
    //
    list: &'a mut LinkedList<T>,
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IterMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IterMut").field(&self.list).field(&self.len).finish()
    }
}

/// `LinkedList` च्या घटकांवर मालकीचे पुनरावृत्ती करणारा.
///
/// हे `struct` [`LinkedList`] (`IntoIterator` trait द्वारे प्रदान केलेले) [`into_iter`] पद्धतीने तयार केले आहे.
/// अधिकसाठी त्याचे दस्तऐवजीकरण पहा.
///
/// [`into_iter`]: LinkedList::into_iter
#[derive(Clone)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    list: LinkedList<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.list).finish()
    }
}

impl<T> Node<T> {
    fn new(element: T) -> Self {
        Node { next: None, prev: None, element }
    }

    fn into_element(self: Box<Self>) -> T {
        self.element
    }
}

// खाजगी पद्धती
impl<T> LinkedList<T> {
    /// सूचीच्या पुढील भागामध्ये दिलेला नोड जोडेल.
    #[inline]
    fn push_front_node(&mut self, mut node: Box<Node<T>>) {
        // `element` मध्ये अलियासिंग पॉईंटर्सची वैधता राखण्यासाठी संपूर्ण नोड्समध्ये बदल करण्यायोग्य संदर्भ तयार न करण्याची ही पद्धत काळजी घेते.
        //
        unsafe {
            node.next = self.head;
            node.prev = None;
            let node = Some(Box::leak(node).into());

            match self.head {
                None => self.tail = node,
                // नवीन म्युटेबल (unique!) संदर्भ आच्छादित करत नाही `element`.
                Some(head) => (*head.as_ptr()).prev = node,
            }

            self.head = node;
            self.len += 1;
        }
    }

    /// यादीच्या पुढच्या बाजूला नोड काढून टाकते आणि मिळवते.
    #[inline]
    fn pop_front_node(&mut self) -> Option<Box<Node<T>>> {
        // `element` मध्ये अलियासिंग पॉईंटर्सची वैधता राखण्यासाठी संपूर्ण नोड्समध्ये बदल करण्यायोग्य संदर्भ तयार न करण्याची ही पद्धत काळजी घेते.
        //
        self.head.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.head = node.next;

            match self.head {
                None => self.tail = None,
                // नवीन म्युटेबल (unique!) संदर्भ आच्छादित करत नाही `element`.
                Some(head) => (*head.as_ptr()).prev = None,
            }

            self.len -= 1;
            node
        })
    }

    /// सूचीच्या मागील भागामध्ये दिलेला नोड जोडेल.
    #[inline]
    fn push_back_node(&mut self, mut node: Box<Node<T>>) {
        // `element` मध्ये अलियासिंग पॉईंटर्सची वैधता राखण्यासाठी संपूर्ण नोड्समध्ये बदल करण्यायोग्य संदर्भ तयार न करण्याची ही पद्धत काळजी घेते.
        //
        unsafe {
            node.next = None;
            node.prev = self.tail;
            let node = Some(Box::leak(node).into());

            match self.tail {
                None => self.head = node,
                // नवीन म्युटेबल (unique!) संदर्भ आच्छादित करत नाही `element`.
                Some(tail) => (*tail.as_ptr()).next = node,
            }

            self.tail = node;
            self.len += 1;
        }
    }

    /// सूचीच्या मागील बाजूस नोड काढते आणि मिळवते.
    #[inline]
    fn pop_back_node(&mut self) -> Option<Box<Node<T>>> {
        // `element` मध्ये अलियासिंग पॉईंटर्सची वैधता राखण्यासाठी संपूर्ण नोड्समध्ये बदल करण्यायोग्य संदर्भ तयार न करण्याची ही पद्धत काळजी घेते.
        //
        self.tail.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.tail = node.prev;

            match self.tail {
                None => self.head = None,
                // नवीन म्युटेबल (unique!) संदर्भ आच्छादित करत नाही `element`.
                Some(tail) => (*tail.as_ptr()).next = None,
            }

            self.len -= 1;
            node
        })
    }

    /// सद्य सूचीमधून निर्दिष्ट नोडचा दुवा तोडतो.
    ///
    /// चेतावणी: प्रदान केलेला नोड सध्याच्या सूचीचा आहे हे तपासणार नाही.
    ///
    /// अलियासिंग पॉइंटर्सची वैधता राखण्यासाठी `element` वर बदलण्यायोग्य संदर्भ तयार न करण्याची ही पद्धत काळजी घेते.
    ///
    #[inline]
    unsafe fn unlink_node(&mut self, mut node: NonNull<Node<T>>) {
        let node = unsafe { node.as_mut() }; // हे आता आमचे आहे, आम्ही एक &mut तयार करू शकतो.

        // नवीन म्युटेबल (unique!) संदर्भ आच्छादित करत नाही `element`.
        match node.prev {
            Some(prev) => unsafe { (*prev.as_ptr()).next = node.next },
            // हे नोड हे डोके नोड आहे
            None => self.head = node.next,
        };

        match node.next {
            Some(next) => unsafe { (*next.as_ptr()).prev = node.prev },
            // हे नोड शेपटीचे नोड आहे
            None => self.tail = node.prev,
        };

        self.len -= 1;
    }

    /// दोन विद्यमान नोड्स दरम्यान नोड्सची मालिका विभाजित करते.
    ///
    /// चेतावणी: हे प्रदान केलेले नोड विद्यमान दोन सूचीच्या मालकीचे असल्याचे तपासणार नाही.
    #[inline]
    unsafe fn splice_nodes(
        &mut self,
        existing_prev: Option<NonNull<Node<T>>>,
        existing_next: Option<NonNull<Node<T>>>,
        mut splice_start: NonNull<Node<T>>,
        mut splice_end: NonNull<Node<T>>,
        splice_length: usize,
    ) {
        // ही पद्धत संपूर्ण नोड्सवर एकाच वेळी एकाधिक बदलण्यायोग्य संदर्भ न तयार करण्याची आणि `element` मध्ये पॉईंट्स अलियासिंगची वैधता राखण्यासाठी नाही याची काळजी घेते.
        //
        if let Some(mut existing_prev) = existing_prev {
            unsafe {
                existing_prev.as_mut().next = Some(splice_start);
            }
        } else {
            self.head = Some(splice_start);
        }
        if let Some(mut existing_next) = existing_next {
            unsafe {
                existing_next.as_mut().prev = Some(splice_end);
            }
        } else {
            self.tail = Some(splice_end);
        }
        unsafe {
            splice_start.as_mut().prev = existing_prev;
            splice_end.as_mut().next = existing_next;
        }

        self.len += splice_length;
    }

    /// नोड्सची मालिका म्हणून जोडलेल्या यादीतून सर्व नोड्स विलग करते.
    #[inline]
    fn detach_all_nodes(mut self) -> Option<(NonNull<Node<T>>, NonNull<Node<T>>, usize)> {
        let head = self.head.take();
        let tail = self.tail.take();
        let len = mem::replace(&mut self.len, 0);
        if let Some(head) = head {
            let tail = tail.unwrap_or_else(|| unsafe { core::hint::unreachable_unchecked() });
            Some((head, tail, len))
        } else {
            None
        }
    }

    #[inline]
    unsafe fn split_off_before_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // स्प्लिट नोड हा दुसर्या भागाचा नवीन मुख्य नोड आहे
        if let Some(mut split_node) = split_node {
            let first_part_head;
            let first_part_tail;
            unsafe {
                first_part_tail = split_node.as_mut().prev.take();
            }
            if let Some(mut tail) = first_part_tail {
                unsafe {
                    tail.as_mut().next = None;
                }
                first_part_head = self.head;
            } else {
                first_part_head = None;
            }

            let first_part = LinkedList {
                head: first_part_head,
                tail: first_part_tail,
                len: at,
                marker: PhantomData,
            };

            // दुसर्या भागाच्या मुख्य पीटीआरचे निराकरण करा
            self.head = Some(split_node);
            self.len = self.len - at;

            first_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }

    #[inline]
    unsafe fn split_off_after_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // स्प्लिट नोड हा पहिल्या भागाचा नवीन टेल नोड आहे आणि दुसर्या भागाच्या मस्तकाचा मालक आहे.
        //
        if let Some(mut split_node) = split_node {
            let second_part_head;
            let second_part_tail;
            unsafe {
                second_part_head = split_node.as_mut().next.take();
            }
            if let Some(mut head) = second_part_head {
                unsafe {
                    head.as_mut().prev = None;
                }
                second_part_tail = self.tail;
            } else {
                second_part_tail = None;
            }

            let second_part = LinkedList {
                head: second_part_head,
                tail: second_part_tail,
                len: self.len - at,
                marker: PhantomData,
            };

            // पहिल्या भागाची शेपटी पीटीआर निश्चित करा
            self.tail = Some(split_node);
            self.len = at;

            second_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for LinkedList<T> {
    /// रिक्त `LinkedList<T>` तयार करते.
    #[inline]
    fn default() -> Self {
        Self::new()
    }
}

impl<T> LinkedList<T> {
    /// रिक्त `LinkedList` तयार करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let list: LinkedList<u32> = LinkedList::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_linked_list_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        LinkedList { head: None, tail: None, len: 0, marker: PhantomData }
    }

    /// `other` वरून सर्व घटक सूचीच्या शेवटी हलविते.
    ///
    /// हे `other` मधील सर्व नोड्सचा पुन्हा वापर करते आणि त्यांना `self` मध्ये हलवते.
    /// या ऑपरेशननंतर, `other` रिक्त होईल.
    ///
    /// या ऑपरेशनने *ओ*(1) वेळ आणि *ओ*(1) मेमरीमध्ये गणना केली पाहिजे.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list1 = LinkedList::new();
    /// list1.push_back('a');
    ///
    /// let mut list2 = LinkedList::new();
    /// list2.push_back('b');
    /// list2.push_back('c');
    ///
    /// list1.append(&mut list2);
    ///
    /// let mut iter = list1.iter();
    /// assert_eq!(iter.next(), Some(&'a'));
    /// assert_eq!(iter.next(), Some(&'b'));
    /// assert_eq!(iter.next(), Some(&'c'));
    /// assert!(iter.next().is_none());
    ///
    /// assert!(list2.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn append(&mut self, other: &mut Self) {
        match self.tail {
            None => mem::swap(self, other),
            Some(mut tail) => {
                // `as_mut` येथे ठीक आहे कारण आमच्याकडे दोन्ही याद्यांमधील संपूर्ण प्रवेश आहे.
                //
                if let Some(mut other_head) = other.head.take() {
                    unsafe {
                        tail.as_mut().next = Some(other_head);
                        other_head.as_mut().prev = Some(tail);
                    }

                    self.tail = other.tail.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// `other` वरून सर्व घटक सूचीच्या सुरूवातीस हलवते.
    #[unstable(feature = "linked_list_prepend", issue = "none")]
    pub fn prepend(&mut self, other: &mut Self) {
        match self.head {
            None => mem::swap(self, other),
            Some(mut head) => {
                // `as_mut` येथे ठीक आहे कारण आमच्याकडे दोन्ही याद्यांमधील संपूर्ण प्रवेश आहे.
                //
                if let Some(mut other_tail) = other.tail.take() {
                    unsafe {
                        head.as_mut().prev = Some(other_tail);
                        other_tail.as_mut().next = Some(head);
                    }

                    self.head = other.head.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// एक अग्रेषित पुनरावृत्ती करणारा प्रदान करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { head: self.head, tail: self.tail, len: self.len, marker: PhantomData }
    }

    /// बदलण्यायोग्य संदर्भांसह अग्रेषित पुनरावृत्ती करणारा प्रदान करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// for element in list.iter_mut() {
    ///     *element += 10;
    /// }
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&10));
    /// assert_eq!(iter.next(), Some(&11));
    /// assert_eq!(iter.next(), Some(&12));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { head: self.head, tail: self.tail, len: self.len, list: self }
    }

    /// पुढच्या घटकावर कर्सर प्रदान करते.
    ///
    /// सूची रिक्त असल्यास कर्सर "ghost" नॉन-एलिमेंटला निर्देशित करीत आहे.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front(&self) -> Cursor<'_, T> {
        Cursor { index: 0, current: self.head, list: self }
    }

    /// पुढच्या घटकावर संपादन ऑपरेशनसह कर्सर प्रदान करते.
    ///
    /// सूची रिक्त असल्यास कर्सर "ghost" नॉन-एलिमेंटला निर्देशित करीत आहे.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: 0, current: self.head, list: self }
    }

    /// मागील घटकावर कर्सर प्रदान करते.
    ///
    /// सूची रिक्त असल्यास कर्सर "ghost" नॉन-एलिमेंटला निर्देशित करीत आहे.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back(&self) -> Cursor<'_, T> {
        Cursor { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// मागील घटकावर संपादन ऑपरेशनसह कर्सर प्रदान करते.
    ///
    /// सूची रिक्त असल्यास कर्सर "ghost" नॉन-एलिमेंटला निर्देशित करीत आहे.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// `LinkedList` रिक्त असल्यास `true` मिळवते.
    ///
    /// या ऑपरेशनने *ओ*(1) वेळेत गणना केली पाहिजे.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert!(dl.is_empty());
    ///
    /// dl.push_front("foo");
    /// assert!(!dl.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.head.is_none()
    }

    /// `LinkedList` ची लांबी मिळवते.
    ///
    /// या ऑपरेशनने *ओ*(1) वेळेत गणना केली पाहिजे.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.len(), 1);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    ///
    /// dl.push_back(3);
    /// assert_eq!(dl.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// `LinkedList` वरून सर्व घटक काढून टाकते.
    ///
    /// या ऑपरेशनने *ओ*(*एन*) वेळेत गणना केली पाहिजे.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// dl.clear();
    /// assert_eq!(dl.len(), 0);
    /// assert_eq!(dl.front(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = Self::new();
    }

    /// जर एक्स 0 एक्स मध्ये दिलेल्या मूल्याच्या बरोबरीचा एखादा घटक असेल तर तो एक्स 100 एक्स मिळवते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// assert_eq!(list.contains(&0), true);
    /// assert_eq!(list.contains(&10), false);
    /// ```
    #[stable(feature = "linked_list_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        self.iter().any(|e| e == x)
    }

    /// पुढील घटक, किंवा सूची रिक्त असल्यास `None` संदर्भ प्रदान करते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        unsafe { self.head.as_ref().map(|node| &node.as_ref().element) }
    }

    /// फ्रंट एलिमेंटला बदलू संदर्भ प्रदान करते, किंवा यादी रिक्त असल्यास `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// match dl.front_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.front(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        unsafe { self.head.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// मागच्या घटकाचा संदर्भ प्रदान करते, किंवा सूची रिक्त असल्यास `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        unsafe { self.tail.as_ref().map(|node| &node.as_ref().element) }
    }

    /// बॅक एलिमेंटचा एक बदल संदर्भ प्रदान करते, किंवा यादी रिक्त असल्यास `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    ///
    /// match dl.back_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.back(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        unsafe { self.tail.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// यादीमध्ये प्रथम घटक जोडा.
    ///
    /// या ऑपरेशनने *ओ*(1) वेळेत गणना केली पाहिजे.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.front().unwrap(), &2);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front().unwrap(), &1);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, elt: T) {
        self.push_front_node(box Node::new(elt));
    }

    /// प्रथम घटक काढून तो परत करते किंवा सूची रिक्त असल्यास `None`.
    ///
    ///
    /// या ऑपरेशनने *ओ*(1) वेळेत गणना केली पाहिजे.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_front(), None);
    ///
    /// d.push_front(1);
    /// d.push_front(3);
    /// assert_eq!(d.pop_front(), Some(3));
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        self.pop_front_node().map(Node::into_element)
    }

    /// सूचीच्या मागील बाजूस घटक समाविष्ट करते.
    ///
    /// या ऑपरेशनने *ओ*(1) वेळेत गणना केली पाहिजे.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(3, *d.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, elt: T) {
        self.push_back_node(box Node::new(elt));
    }

    /// सूचीमधून शेवटचा घटक काढून टाकते आणि ते रिक्त असल्यास `None` मिळवते.
    ///
    ///
    /// या ऑपरेशनने *ओ*(1) वेळेत गणना केली पाहिजे.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_back(), None);
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(d.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        self.pop_back_node().map(Node::into_element)
    }

    /// दिलेल्या निर्देशांकात यादी दोनमध्ये विभाजित करते.
    /// निर्देशांकसह दिलेल्या निर्देशांकानंतर सर्वकाही मिळवते.
    ///
    /// या ऑपरेशनने *ओ*(*एन*) वेळेत गणना केली पाहिजे.
    ///
    /// # Panics
    ///
    /// `at > len` असल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// let mut split = d.split_off(2);
    ///
    /// assert_eq!(split.pop_front(), Some(1));
    /// assert_eq!(split.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn split_off(&mut self, at: usize) -> LinkedList<T> {
        let len = self.len();
        assert!(at <= len, "Cannot split off at a nonexistent index");
        if at == 0 {
            return mem::take(self);
        } else if at == len {
            return Self::new();
        }

        // खाली, वेगवान होईल त्यानुसार आम्ही सुरुवातीपासून किंवा शेवटपर्यंत `i-1` व्या नोडकडे वळत आहोत.
        //
        let split_node = if at - 1 <= len - 1 - (at - 1) {
            let mut iter = self.iter_mut();
            // .skip() (जे एक नवीन रचना तयार करते) वापरुन वगळण्याऐवजी आपण व्यक्तिचलितरित्या वगळू जेणेकरून स्किपच्या अंमलबजावणीच्या तपशीलांवर अवलंबून न राहता आपण मुख्य क्षेत्रात प्रवेश करू शकू.
            //
            //
            for _ in 0..at - 1 {
                iter.next();
            }
            iter.head
        } else {
            // शेवट पासून सुरू चांगले
            let mut iter = self.iter_mut();
            for _ in 0..len - 1 - (at - 1) {
                iter.next_back();
            }
            iter.tail
        };
        unsafe { self.split_off_after_node(split_node, at) }
    }

    /// दिलेल्या निर्देशांकातील घटक काढून टाकते आणि परत मिळवितो.
    ///
    /// या ऑपरेशनने *ओ*(*एन*) वेळेत गणना केली पाहिजे.
    ///
    /// # Panics
    /// > 0 लेन असल्यास झेडपॅनिक्स 0 झेड
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(linked_list_remove)]
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// assert_eq!(d.remove(1), 2);
    /// assert_eq!(d.remove(0), 3);
    /// assert_eq!(d.remove(0), 1);
    /// ```
    #[unstable(feature = "linked_list_remove", issue = "69210")]
    pub fn remove(&mut self, at: usize) -> T {
        let len = self.len();
        assert!(at < len, "Cannot remove at an index outside of the list bounds");

        // खाली, आम्ही दिलेली अनुक्रमणिकेवरील नोडच्या दिशेने पुनरावृत्ती करतो, एकतर सुरूवातीस किंवा शेवटपर्यंत, त्यानुसार वेगवान होईल.
        //
        let offset_from_end = len - at - 1;
        if at <= offset_from_end {
            let mut cursor = self.cursor_front_mut();
            for _ in 0..at {
                cursor.move_next();
            }
            cursor.remove_current().unwrap()
        } else {
            let mut cursor = self.cursor_back_mut();
            for _ in 0..offset_from_end {
                cursor.move_prev();
            }
            cursor.remove_current().unwrap()
        }
    }

    /// एखादा आयटर काढला पाहिजे की नाही हे निर्धारित करण्यासाठी क्लोजर वापरणारा इटरेटर तयार करतो.
    ///
    /// जर बंद सत्य परत आले तर घटक काढून टाकला जाईल.
    /// जर क्लोजर चुकीचे परत आले तर घटक सूचीमध्ये राहील व पुनरावृत्ती करणार्‍याद्वारे त्याचा उत्पन्न होणार नाही.
    ///
    /// लक्षात ठेवा की `drain_filter` आपल्याला फिल्टर क्लोजरमधील प्रत्येक घटकाचे रुपांतर करू देते, आपण ते ठेवणे किंवा काढणे निवडले आहे याची पर्वा न करता.
    ///
    ///
    /// # Examples
    ///
    /// मूळ यादीचा पुन्हा वापर करून, संध्याकाळ आणि शक्यतांमध्ये सूची विभाजित करणे:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// use std::collections::LinkedList;
    ///
    /// let mut numbers: LinkedList<u32> = LinkedList::new();
    /// numbers.extend(&[1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15]);
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<LinkedList<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens.into_iter().collect::<Vec<_>>(), vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds.into_iter().collect::<Vec<_>>(), vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F>
    where
        F: FnMut(&mut T) -> bool,
    {
        // कर्ज प्रकरणे टाळा.
        let it = self.head;
        let old_len = self.len;

        DrainFilter { list: self, it, pred: filter, idx: 0, old_len }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for LinkedList<T> {
    fn drop(&mut self) {
        struct DropGuard<'a, T>(&'a mut LinkedList<T>);

        impl<'a, T> Drop for DropGuard<'a, T> {
            fn drop(&mut self) {
                // आम्ही खाली करतो त्याच पळवाट सुरू ठेवा.हे फक्त तेव्हा चालते जेव्हा विध्वंसक घाबरले असेल.
                // आणखी एक झेडस्पॅनिक्स 0 झेड असल्यास हे गर्भपात होईल.
                while self.0.pop_front_node().is_some() {}
            }
        }

        while let Some(node) = self.pop_front_node() {
            let guard = DropGuard(self);
            drop(node);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // 'अ मिळविण्यासाठी एक अबाधित आजीवन आवश्यक आहे
                let node = &*node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // 'अ मिळविण्यासाठी एक अबाधित आजीवन आवश्यक आहे
                let node = &*node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // 'अ मिळविण्यासाठी एक अबाधित आजीवन आवश्यक आहे
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &mut node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a mut T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // 'अ मिळविण्यासाठी एक अबाधित आजीवन आवश्यक आहे
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &mut node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

/// `LinkedList` वरील कर्सर.
///
/// एक्स एक्स एक्स एक्स आयटरसारखे आहे, त्याशिवाय ते मुक्तपणे मागे-पुढे शोधू शकते.
///
/// कर्सर नेहमी सूचीतील दोन घटकांमधील आणि तार्किकपणे गोलाकार मार्गाने निर्देशांक दरम्यान विश्रांती घेतात.
/// हे समायोजित करण्यासाठी, तेथे एक "ghost" नॉन-एलिमेंट आहे जो सूचीच्या डोके आणि शेपटीच्या दरम्यान `None` उत्पन्न करतो.
///
///
/// तयार केल्यावर, सूचीच्या अग्रभागापासून कर्सर किंवा सूची रिक्त असल्यास "ghost" नॉन-एलिमेंट प्रारंभ होते.
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct Cursor<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T> Clone for Cursor<'_, T> {
    fn clone(&self) -> Self {
        let Cursor { index, current, list } = *self;
        Cursor { index, current, list }
    }
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for Cursor<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Cursor").field(&self.list).field(&self.index()).finish()
    }
}

/// संपादन ऑपरेशन्ससह `LinkedList` वरील कर्सर.
///
/// एक्स एक्स एक्स हे आयटरसारखे आहे, त्याशिवाय ते मुक्तपणे मागे-पुढे शोधू शकते आणि पुनरावृत्तीच्या काळात सूचीला सुरक्षितपणे बदलू शकते.
/// हे त्याचे मूळ उत्पन्न केवळ मूळ सूचीऐवजी त्याच्या स्वतःच्या आयुष्याशी जोडलेले आहे.
/// याचा अर्थ असा की कर्सर एकाच वेळी एकाधिक घटक उत्पन्न करू शकत नाहीत.
///
/// कर्सर नेहमी सूचीतील दोन घटकांमधील आणि तार्किकपणे गोलाकार मार्गाने निर्देशांक दरम्यान विश्रांती घेतात.
/// हे समायोजित करण्यासाठी, तेथे एक "ghost" नॉन-एलिमेंट आहे जो सूचीच्या डोके आणि शेपटीच्या दरम्यान `None` उत्पन्न करतो.
///
///
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct CursorMut<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a mut LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for CursorMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("CursorMut").field(&self.list).field(&self.index()).finish()
    }
}

impl<'a, T> Cursor<'a, T> {
    /// `LinkedList` मध्ये कर्सर स्थिती निर्देशांक मिळवते.
    ///
    /// जर कर्सर सध्या एक्स 0 एक्स एक्स-घटकांकडे निर्देशित करत असेल तर हे एक्स 100 एक्स परत करेल.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// `LinkedList` च्या पुढील घटकाकडे कर्सर हलवते.
    ///
    /// जर कर्सर "ghost" नॉन-एलिमेंटवर निर्देशित करीत असेल तर तो त्यास `LinkedList` च्या पहिल्या घटकावर हलवेल.
    /// जर ते `LinkedList` च्या शेवटच्या घटकाकडे निर्देश करीत असेल तर हे ते "ghost" नॉन-एलिमेंटवर हलवेल.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // आमच्याकडे कोणतेही वर्तमान घटक नव्हते;कर्सर प्रारंभ स्थितीत बसला होता पुढील घटक सूचीचा प्रमुख असावा
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // आमच्याकडे मागील घटक होता, चला तर मग पुढच्या गोष्टींवर जाऊ
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// `LinkedList` च्या मागील घटकावर कर्सर हलवते.
    ///
    /// जर कर्सर "ghost" नॉन-एलिमेंटवर निर्देशित करीत असेल तर तो त्यास एक्स 100 एक्स च्या शेवटच्या घटकाकडे हलवेल.
    /// जर ते `LinkedList` च्या पहिल्या घटकाकडे निर्देश करीत असेल तर हे त्यास "ghost" नॉन-एलिमेंटवर हलवेल.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // चालू नाही.आम्ही यादीच्या सुरूवातीस आहोत.पीक नाही आणि शेवटी जा.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // एक prev आहेते उत्पन्न द्या आणि मागील घटकावर जा.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// कर्सर सध्या निर्देशित करीत असलेल्या घटकाचा संदर्भ मिळवते.
    ///
    /// जर कर्सर सध्या एक्स 0 एक्स एक्स-घटकांकडे निर्देशित करत असेल तर हे एक्स 100 एक्स परत करेल.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&self) -> Option<&'a T> {
        unsafe { self.current.map(|current| &(*current.as_ptr()).element) }
    }

    /// पुढील घटकाचा संदर्भ मिळवते.
    ///
    /// जर कर्सर "ghost" नॉन-एलिमेंटला सूचित करीत असेल तर हे एक्स 100 एक्स चा पहिला घटक परत करेल.
    /// जर ते `LinkedList` च्या शेवटच्या घटकाकडे निर्देश करीत असेल तर हे एक्स 100 एक्स परत करेल.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&self) -> Option<&'a T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &(*next.as_ptr()).element)
        }
    }

    /// मागील घटकाचा संदर्भ मिळवते.
    ///
    /// जर कर्सर "ghost" नॉन-एलिमेंटवर निर्देशित करीत असेल तर हे `LinkedList` चा शेवटचा घटक परत करेल.
    /// जर ते `LinkedList` च्या पहिल्या घटकाकडे निर्देश करीत असेल तर हे एक्स 100 एक्स परत करेल.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&self) -> Option<&'a T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &(*prev.as_ptr()).element)
        }
    }
}

impl<'a, T> CursorMut<'a, T> {
    /// `LinkedList` मध्ये कर्सर स्थिती निर्देशांक मिळवते.
    ///
    /// जर कर्सर सध्या एक्स 0 एक्स एक्स-घटकांकडे निर्देशित करत असेल तर हे एक्स 100 एक्स परत करेल.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// `LinkedList` च्या पुढील घटकाकडे कर्सर हलवते.
    ///
    /// जर कर्सर "ghost" नॉन-एलिमेंटवर निर्देशित करीत असेल तर तो त्यास `LinkedList` च्या पहिल्या घटकावर हलवेल.
    /// जर ते `LinkedList` च्या शेवटच्या घटकाकडे निर्देश करीत असेल तर हे ते "ghost" नॉन-एलिमेंटवर हलवेल.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // आमच्याकडे कोणतेही वर्तमान घटक नव्हते;कर्सर प्रारंभ स्थितीत बसला होता पुढील घटक सूचीचा प्रमुख असावा
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // आमच्याकडे मागील घटक होता, चला तर मग पुढच्या गोष्टींवर जाऊ
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// `LinkedList` च्या मागील घटकावर कर्सर हलवते.
    ///
    /// जर कर्सर "ghost" नॉन-एलिमेंटवर निर्देशित करीत असेल तर तो त्यास एक्स 100 एक्स च्या शेवटच्या घटकाकडे हलवेल.
    /// जर ते `LinkedList` च्या पहिल्या घटकाकडे निर्देश करीत असेल तर हे त्यास "ghost" नॉन-एलिमेंटवर हलवेल.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // चालू नाही.आम्ही यादीच्या सुरूवातीस आहोत.पीक नाही आणि शेवटी जा.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // एक prev आहेते उत्पन्न द्या आणि मागील घटकावर जा.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// कर्सर सध्या निर्देशित करीत असलेल्या घटकाचा संदर्भ मिळवते.
    ///
    /// जर कर्सर सध्या एक्स 0 एक्स एक्स-घटकांकडे निर्देशित करत असेल तर हे एक्स 100 एक्स परत करेल.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&mut self) -> Option<&mut T> {
        unsafe { self.current.map(|current| &mut (*current.as_ptr()).element) }
    }

    /// पुढील घटकाचा संदर्भ मिळवते.
    ///
    /// जर कर्सर "ghost" नॉन-एलिमेंटला सूचित करीत असेल तर हे एक्स 100 एक्स चा पहिला घटक परत करेल.
    /// जर ते `LinkedList` च्या शेवटच्या घटकाकडे निर्देश करीत असेल तर हे एक्स 100 एक्स परत करेल.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&mut self) -> Option<&mut T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &mut (*next.as_ptr()).element)
        }
    }

    /// मागील घटकाचा संदर्भ मिळवते.
    ///
    /// जर कर्सर "ghost" नॉन-एलिमेंटवर निर्देशित करीत असेल तर हे `LinkedList` चा शेवटचा घटक परत करेल.
    /// जर ते `LinkedList` च्या पहिल्या घटकाकडे निर्देश करीत असेल तर हे एक्स 100 एक्स परत करेल.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&mut self) -> Option<&mut T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &mut (*prev.as_ptr()).element)
        }
    }

    /// वर्तमान घटकाकडे निर्देशित करणारा केवळ वाचनीय कर्सर मिळवते.
    ///
    /// परत केलेल्या `Cursor` चे आजीवन हे `CursorMut` प्रमाणेच बंधनकारक आहे, याचा अर्थ असा की हे `CursorMut` ला मागे टाकू शकत नाही आणि `Cursor` एक्सच्या आयुष्यासाठी `CursorMut` गोठलेले आहे.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn as_cursor(&self) -> Cursor<'_, T> {
        Cursor { list: self.list, current: self.current, index: self.index }
    }
}

// आता यादी संपादन कार्य

impl<'a, T> CursorMut<'a, T> {
    /// सद्यानंतर `LinkedList` मध्ये एक नवीन घटक घाला.
    ///
    /// जर कर्सर "ghost" नॉन-एलिमेंटवर निर्देशित करीत असेल तर नवीन घटक एक्स 100 एक्स च्या पुढच्या बाजूला घातला जाईल.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_after(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, spliced_node, spliced_node, 1);
            if self.current.is_none() {
                // "ghost" नॉन-एलिमेंटची अनुक्रमणिका बदलली आहे.
                self.index = self.list.len;
            }
        }
    }

    /// वर्तमानापूर्वी `LinkedList` मध्ये एक नवीन घटक घाला.
    ///
    /// जर कर्सर "ghost" नॉन-एलिमेंटवर निर्देशित करीत असेल तर नवीन घटक `LinkedList` च्या शेवटी घातला जाईल.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_before(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, spliced_node, spliced_node, 1);
            self.index += 1;
        }
    }

    /// `LinkedList` वरून वर्तमान घटक काढून टाकते.
    ///
    /// काढलेला घटक परत केला आणि कर्सर `LinkedList` मधील पुढील घटकाकडे निर्देशित करण्यासाठी हलविला गेला.
    ///
    ///
    /// जर कर्सर सध्या एक्स 100 एक्स नॉन-एलिमेंटला सूचित करीत असेल तर कोणताही घटक काढला जाणार नाही आणि एक्स 0 एक्स एक्स परत येईल.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current(&mut self) -> Option<T> {
        let unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);
            let unlinked_node = Box::from_raw(unlinked_node.as_ptr());
            Some(unlinked_node.element)
        }
    }

    /// सूची नोडची विपुलता न करता `LinkedList` वरून वर्तमान घटक काढून टाकते.
    ///
    /// काढून टाकलेला नोड नवीन `LinkedList` म्हणून परत आला आहे ज्यामध्ये केवळ हा नोड आहे.
    /// वर्तमान `LinkedList` मधील पुढील घटकाकडे निर्देश करण्यासाठी कर्सर हलविला गेला आहे.
    ///
    /// जर कर्सर सध्या एक्स 100 एक्स नॉन-एलिमेंटला सूचित करीत असेल तर कोणताही घटक काढला जाणार नाही आणि एक्स 0 एक्स एक्स परत येईल.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current_as_list(&mut self) -> Option<LinkedList<T>> {
        let mut unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);

            unlinked_node.as_mut().prev = None;
            unlinked_node.as_mut().next = None;
            Some(LinkedList {
                head: Some(unlinked_node),
                tail: Some(unlinked_node),
                len: 1,
                marker: PhantomData,
            })
        }
    }

    /// सद्यानंतर दिलेल्या `LinkedList` मधील घटक समाविष्ट करते.
    ///
    /// जर कर्सर "ghost" नॉन-एलिमेंटवर निर्देशित करीत असेल तर नवीन घटक `LinkedList` च्या सुरूवातीस घातल्या जातात.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_after(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, splice_head, splice_tail, splice_len);
            if self.current.is_none() {
                // "ghost" नॉन-एलिमेंटची अनुक्रमणिका बदलली आहे.
                self.index = self.list.len;
            }
        }
    }

    /// वर्तमान X च्या आधी दिलेल्या `LinkedList` मधील घटक समाविष्ट करते.
    ///
    /// जर कर्सर "ghost" नॉन-एलिमेंटवर निर्देशित करीत असेल तर नवीन घटक `LinkedList` च्या शेवटी घातले जातील.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_before(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, splice_head, splice_tail, splice_len);
            self.index += splice_len;
        }
    }

    /// वर्तमान घटका नंतर यादी दोनमध्ये विभागली.
    /// हे कर्सर नंतर सर्वकाही असलेली एक नवीन यादी परत करेल, मूळ यादी आधी सर्व काही राखून ठेवेल.
    ///
    ///
    /// जर कर्सर "ghost" नॉन-एलिमेंटवर निर्देशित करीत असेल तर `LinkedList` ची संपूर्ण सामग्री हलविली जाईल.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_after(&mut self) -> LinkedList<T> {
        let split_off_idx = if self.index == self.list.len { 0 } else { self.index + 1 };
        if self.index == self.list.len {
            // "ghost" नॉन-एलिमेंट्सची अनुक्रमणिका 0 मध्ये बदलली आहे.
            self.index = 0;
        }
        unsafe { self.list.split_off_after_node(self.current, split_off_idx) }
    }

    /// वर्तमान घटकाच्या आधी यादी दोनमध्ये विभागली जाते.
    /// हे कर्सरच्या आधी असलेल्या प्रत्येक वस्तूसह एक नवीन यादी परत करेल, मूळ यादी नंतर सर्व काही राखून ठेवेल.
    ///
    ///
    /// जर कर्सर "ghost" नॉन-एलिमेंटवर निर्देशित करीत असेल तर `LinkedList` ची संपूर्ण सामग्री हलविली जाईल.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_before(&mut self) -> LinkedList<T> {
        let split_off_idx = self.index;
        self.index = 0;
        unsafe { self.list.split_off_before_node(self.current, split_off_idx) }
    }
}

/// लिंक्डलिस्टवर `drain_filter` वर कॉल करून एक इटरेटर तयार केला.
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub struct DrainFilter<'a, T: 'a, F: 'a>
where
    F: FnMut(&mut T) -> bool,
{
    list: &'a mut LinkedList<T>,
    it: Option<NonNull<Node<T>>>,
    pred: F,
    idx: usize,
    old_len: usize,
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Iterator for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        while let Some(mut node) = self.it {
            unsafe {
                self.it = node.as_ref().next;
                self.idx += 1;

                if (self.pred)(&mut node.as_mut().element) {
                    // `unlink_node` अलियासिंग `element` संदर्भांसह ठीक आहे.
                    self.list.unlink_node(node);
                    return Some(Box::from_raw(node.as_ptr()).element);
                }
            }
        }

        None
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Drop for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T, F>(&'r mut DrainFilter<'a, T, F>)
        where
            F: FnMut(&mut T) -> bool;

        impl<'r, 'a, T, F> Drop for DropGuard<'r, 'a, T, F>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                self.0.for_each(drop);
            }
        }

        while let Some(item) = self.next() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T: fmt::Debug, F> fmt::Debug for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.list).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.list.pop_front()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.list.len, Some(self.list.len))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.list.pop_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for LinkedList<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Self {
        let mut list = Self::new();
        list.extend(iter);
        list
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for LinkedList<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// मूल्याद्वारे पुनरावृत्ती करणार्‍या घटकांची सूची पुनरावृत्ती करते.
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { list: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a LinkedList<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut LinkedList<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Extend<T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, elem: T) {
        self.push_back(elem);
    }
}

impl<I: IntoIterator> SpecExtend<I> for LinkedList<I::Item> {
    default fn spec_extend(&mut self, iter: I) {
        iter.into_iter().for_each(move |elt| self.push_back(elt));
    }
}

impl<T> SpecExtend<LinkedList<T>> for LinkedList<T> {
    fn spec_extend(&mut self, ref mut other: LinkedList<T>) {
        self.append(other);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &'a T) {
        self.push_back(elem);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq> PartialEq for LinkedList<T> {
    fn eq(&self, other: &Self) -> bool {
        self.len() == other.len() && self.iter().eq(other)
    }

    fn ne(&self, other: &Self) -> bool {
        self.len() != other.len() || self.iter().ne(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for LinkedList<T> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.iter().partial_cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for LinkedList<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.iter().cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for LinkedList<T> {
    fn clone(&self) -> Self {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        let mut iter_other = other.iter();
        if self.len() > other.len() {
            self.split_off(other.len());
        }
        for (elem, elem_other) in self.iter_mut().zip(&mut iter_other) {
            elem.clone_from(elem_other);
        }
        if !iter_other.is_empty() {
            self.extend(iter_other.cloned());
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for LinkedList<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash> Hash for LinkedList<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        for elt in self {
            elt.hash(state);
        }
    }
}

// `LinkedList` आणि केवळ-वाचनीय पुनरावृत्ती करणारे त्यांच्या प्रकारातील मापदंडांमध्ये हे सुनिश्चित करा.
#[allow(dead_code)]
fn assert_covariance() {
    fn a<'a>(x: LinkedList<&'static str>) -> LinkedList<&'a str> {
        x
    }
    fn b<'i, 'a>(x: Iter<'i, &'static str>) -> Iter<'i, &'a str> {
        x
    }
    fn c<'a>(x: IntoIter<&'static str>) -> IntoIter<&'a str> {
        x
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Send for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for IterMut<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for IterMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Send for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Send> Send for CursorMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for CursorMut<'_, T> {}