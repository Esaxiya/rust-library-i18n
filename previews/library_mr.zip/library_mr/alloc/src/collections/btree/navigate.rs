use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// तात्पुरते त्याच श्रेणीचे दुसरे, अपरिवर्तनीय समतुल्य बाहेर आणते.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// झाडामध्ये निर्दिष्ट श्रेणी मर्यादा घालणारी विशिष्ट पाने कडा शोधतात.
    /// एकाच झाडावर भिन्न हँडलची जोडी किंवा रिक्त पर्यायांची जोडी मिळवते.
    ///
    /// # Safety
    ///
    /// जोपर्यंत X01 एक्स हे X00 एक्स आहे तोपर्यंत त्याच केव्हीला दोनदा भेट देण्यासाठी डुप्लिकेट हँडल वापरू नका.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// `(root1.first_leaf_edge(), root2.last_leaf_edge())` च्या समतुल्य परंतु अधिक कार्यक्षम.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// झाडामध्ये विशिष्ट श्रेणीची मर्यादा घालणारी पानांच्या कडांची जोडी शोधते.
    ///
    /// `BTreeMap` मधील झाडाप्रमाणेच झाडाला कळ द्वारे क्रम लावल्यासच अर्थपूर्ण आहे.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // सुरक्षितता: आमचा कर्जाचा प्रकार बदलण्यायोग्य आहे.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// संपूर्ण झाडाची मर्यादा घालणारी पानांच्या कडांची जोडी शोधते.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// निर्दिष्ट श्रेणीची मर्यादा घालणार्‍या पानांच्या कडांच्या जोडीमध्ये एक अद्वितीय संदर्भ विभाजित करतो.
    /// याचा परिणाम म्हणजे (some) उत्परिवर्तनला अनुमती देणारे अद्वितीय संदर्भ आहेत, जे काळजीपूर्वक वापरणे आवश्यक आहे.
    ///
    /// `BTreeMap` मधील झाडाप्रमाणेच झाडाला कळ द्वारे क्रम लावल्यासच अर्थपूर्ण आहे.
    ///
    ///
    /// # Safety
    /// समान केव्हीला दोनदा भेट देण्यासाठी डुप्लिकेट हँडल वापरू नका.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// झाडाची पूर्ण श्रेणी मर्यादित करणार्‍या पानांच्या कडांच्या जोडीमध्ये एक अनोखा संदर्भ विभाजित करतो.
    /// परिणाम अ-अद्वितीय संदर्भ आहेत ज्यास उत्परिवर्तन (केवळ मूल्यांचे) अनुमती आहे, म्हणून काळजीपूर्वक वापरणे आवश्यक आहे.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // आम्ही येथे मूळ नोडरेफची नक्कल करतो-आम्ही त्याच केव्हीला दोनदा भेट देत नाही आणि आम्ही कधीही ओव्हरलॅपिंग मूल्य संदर्भासह येऊ शकत नाही.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// झाडाची पूर्ण श्रेणी मर्यादित करणार्‍या पानांच्या कडांच्या जोडीमध्ये एक अनोखा संदर्भ विभाजित करतो.
    /// परिणाम अद्वितीय संदर्भ आहेत ज्यांना मोठ्या प्रमाणात विध्वंसक उत्परिवर्तन होऊ शकते, म्हणून अत्यंत काळजीपूर्वक वापरणे आवश्यक आहे.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // आम्ही येथे नोडरेफ रूटची डुप्लिकेट बनवितो-मूळातून प्राप्त झालेल्या संदर्भांना आच्छादित करण्याच्या मार्गाने आम्ही त्यात कधीही प्रवेश करणार नाही.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// edge हँडल दिलेली पाने, [`Result::Ok`] हँडलसह उजवीकडील शेजारच्या केव्हीला परत करते, जी एकतर समान लीफ नोडमध्ये किंवा पूर्वज नोडमध्ये असते.
    ///
    /// झाडाची पाने edge झाडामधील शेवटची असल्यास, रूट नोडसह [`Result::Err`] मिळवते.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// edge हँडल दिलेली पाने, [`Result::Ok`] परत हँडलसह शेजारच्या केव्हीला डाव्या बाजूला परत करते, जी एकतर समान लीफ नोडमध्ये किंवा पूर्वज नोडमध्ये असते.
    ///
    /// जर झाडाची पाने edge झाडामध्ये पहिली असल्यास, रूट नोडसह [`Result::Err`] मिळवते.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// अंतर्गत edge हँडल दिले, [`Result::Ok`] हँडलसह उजवीकडील शेजारच्या केव्हीला परत करते, जे एकतर समान अंतर्गत नोडमध्ये किंवा पूर्वज नोडमध्ये आहे.
    ///
    /// अंतर्गत edge झाडामधील शेवटचे असल्यास, रूट नोडसह [`Result::Err`] मिळवते.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// झेडगेडझेड हँडलला मरणा tree्या झाडामध्ये पान दिले, पुढची पाने edge उजवीकडील आणि पूर्व-नोडमध्ये किंवा एक-विद्यमान नसलेली, दरम्यानच्या मधील की-व्हॅल्यू जोडी परत मिळवते.
    ///
    ///
    /// ही पद्धत शेवटच्या टोकापर्यंत पोहोचणार्‍या कोणत्याही node(s) चे विमुद्रीकरण देखील करते.
    /// याचा अर्थ असा की आणखी की-मूल्य जोडी अस्तित्त्वात नसल्यास, झाडाचे उर्वरित भाग उरलेले असतील आणि परतण्यासाठी काहीही शिल्लक राहिले नाही.
    ///
    /// # Safety
    /// दिलेले edge पूर्वीचे काउंटर पार्ट `deallocating_next_back` ने परत केले नसावे.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// मरणासन्न झाडामध्ये झेडडजेडझेड हँडल दिलेली पाने पुढील डावीकडील edge आणि डावीकडील की-व्हॅल्यू जोडी, जी पूर्वज नोडमध्ये किंवा समान नसलेल्या, एकतर त्याच पानांच्या नोडमध्ये आहेत.
    ///
    ///
    /// ही पद्धत शेवटच्या टोकापर्यंत पोहोचणार्‍या कोणत्याही node(s) चे विमुद्रीकरण देखील करते.
    /// याचा अर्थ असा की आणखी की-मूल्य जोडी अस्तित्त्वात नसल्यास, झाडाचे उर्वरित भाग उरलेले असतील आणि परतण्यासाठी काहीही शिल्लक राहिले नाही.
    ///
    /// # Safety
    /// दिलेले edge पूर्वीचे काउंटर पार्ट `deallocating_next` ने परत केले नसावे.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// पानापर्यंत मुळापर्यंत नोड्सचा ढीग हटवितो.
    /// `deallocating_next` आणि `deallocating_next_back` झाडाच्या दोन्ही बाजूंनी झिरपणे गेले आहे आणि त्याच edge दाबा नंतर झाडाचे उर्वरित भाग नष्ट करण्याचा हा एकमेव मार्ग आहे.
    /// जेव्हा केवळ सर्व की आणि मूल्ये परत आल्या तेव्हाच कॉल करण्याचा हेतू आहे, कोणत्याही की किंवा मूल्यांवर कोणतीही साफसफाई केली जात नाही.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// edge हँडल लीफला पुढच्या लीफ edge वर हलवते आणि त्यामधील की व त्यातील मूल्यांचे संदर्भ मिळवते.
    ///
    ///
    /// # Safety
    /// प्रवास केलेल्या दिशेने आणखी एक केव्ही असणे आवश्यक आहे.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// edge हँडलची पाने मागील पानांच्या edge वर हलवते आणि त्या दरम्यानच्या की आणि मूल्याचे संदर्भ मिळवते.
    ///
    ///
    /// # Safety
    /// प्रवास केलेल्या दिशेने आणखी एक केव्ही असणे आवश्यक आहे.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// edge हँडल लीफला पुढच्या लीफ edge वर हलवते आणि त्यामधील की व त्यातील मूल्यांचे संदर्भ मिळवते.
    ///
    ///
    /// # Safety
    /// प्रवास केलेल्या दिशेने आणखी एक केव्ही असणे आवश्यक आहे.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // बेंचमार्कच्या मते, हे अंतिम करणे अधिक वेगवान आहे.
        kv.into_kv_valmut()
    }

    /// मागील पानाकडे edge हँडल पाने हलवते आणि त्या दरम्यान की आणि मूल्याचे संदर्भ मिळवते.
    ///
    ///
    /// # Safety
    /// प्रवास केलेल्या दिशेने आणखी एक केव्ही असणे आवश्यक आहे.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // बेंचमार्कच्या मते, हे अंतिम करणे अधिक वेगवान आहे.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// edge हँडलची पाने पुढील पान edge वर हलवते आणि त्या दरम्यानच्या edge ला त्याच्या मूळ नोडमध्ये डांगलिंग सोडताना मागे सोडलेले कोणतेही नोड मागे ठेवून की आणि मूल्य दरम्यान परत करते.
    ///
    /// # Safety
    /// - प्रवास केलेल्या दिशेने आणखी एक केव्ही असणे आवश्यक आहे.
    /// - तो केव्ही पूर्वी काउंटर पार्ट `next_back_unchecked` द्वारे झाडाला ओलांडण्यासाठी वापरल्या जाणार्‍या हँडलच्या कोणत्याही प्रतिवर परत केला नव्हता.
    ///
    /// अद्ययावत हँडलसह पुढे जाण्याचा एकमात्र सुरक्षित मार्ग म्हणजे त्याची तुलना करणे, त्यास सोडणे, या सुरक्षिततेच्या अधीन असलेल्या या पद्धतीस पुन्हा कॉल करणे, किंवा काउंटरपार्ट एक्स एक्सएक्सएक्सला त्याच्या सुरक्षा अटींच्या अधीन कॉल करणे.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// edge हँडलची पाने मागील पान edge वर हलवते आणि त्या दरम्यानच्या edge ला त्याच्या मूळ नोडमध्ये डांगलिंग सोडताना मागे सोडलेले कोणतेही नोड मागे ठेवून की आणि मूल्य दरम्यान मिळवते.
    ///
    /// # Safety
    /// - प्रवास केलेल्या दिशेने आणखी एक केव्ही असणे आवश्यक आहे.
    /// - झाडाच्या पलीकडे जाण्यासाठी वापरल्या जाणा the्या हँडलच्या कोणत्याही प्रतिवर आधी X0edge0Z हे पान काउंटरपार्ट `next_unchecked` ने परत केले नाही.
    ///
    /// अद्ययावत हँडलसह पुढे जाण्याचा एकमात्र सुरक्षित मार्ग म्हणजे त्याची तुलना करणे, त्यास सोडणे, या सुरक्षिततेच्या अधीन असलेल्या या पद्धतीस पुन्हा कॉल करणे, किंवा काउंटरपार्ट एक्स एक्सएक्सएक्सला त्याच्या सुरक्षा अटींच्या अधीन कॉल करणे.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// नोडमध्ये किंवा त्याखालील डावीकडील पाने edge मिळवते, दुसर्‍या शब्दांत, पुढे नॅव्हिगेट करताना आपल्याला प्रथम आवश्यक असलेले edge (किंवा मागे नेव्हिगेट करताना शेवटचे).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// नोडमध्ये किंवा त्याखालील सर्वात उजवी पाने edge मिळवते, दुसर्‍या शब्दांत, पुढे नॅव्हिगेट करताना (किंवा मागे नेव्हिगेट करताना प्रथम) आपल्यास आवश्यक असलेले edge.
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// चढत्या की च्या क्रमाने लीफ नोड्स आणि अंतर्गत केव्हीला भेट दिली जाते आणि संपूर्णपणे पहिल्या खोलीत संपूर्ण अंतर्गत नोड्सला भेट दिली जाते, म्हणजे अंतर्गत नोड्स त्यांच्या वैयक्तिक केव्ही आणि त्यांच्या मुलाच्या नोड्सच्या आधी असतात.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// (उप) झाडामधील घटकांच्या संख्येची गणना करते.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// फॉरवर्ड नेव्हिगेशनसाठी केव्हीच्या सर्वात जवळील edge लीफ मिळवते.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// बॅकवर्ड नेव्हिगेशनसाठी केव्हीच्या सर्वात जवळील edge लीफ मिळवते.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}