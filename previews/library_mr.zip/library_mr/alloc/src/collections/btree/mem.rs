use core::intrinsics;
use core::mem;
use core::ptr;

/// हे संबंधित फंक्शनवर कॉल करून `v` अनन्य संदर्भामागील मूल्य पुनर्स्थित करते.
///
///
/// जर झेडस्पॅनिक 0 झेड `change` बंदमध्ये उद्भवली तर संपूर्ण प्रक्रिया निरस्त केली जाईल.
#[allow(dead_code)] // उदाहरण म्हणून आणि झेडफ्यूचर0 झेड वापरासाठी ठेवा
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// हे संबंधित फंक्शनवर कॉल करून `v` अनन्य संदर्भामागील मूल्य पुनर्स्थित करते आणि मार्गाने प्राप्त केलेला निकाल परत करते.
///
///
/// जर झेडस्पॅनिक 0 झेड `change` बंदमध्ये उद्भवली तर संपूर्ण प्रक्रिया निरस्त केली जाईल.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}