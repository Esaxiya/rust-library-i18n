use super::node::{ForceResult::*, Root};
use super::search::SearchResult::*;
use core::borrow::Borrow;

impl<K, V> Root<K, V> {
    /// दोन्ही झाडाच्या लांबीची गणना करते जी दिलेली संख्या भिन्न की-मूल्य जोड्यांच्या विभाजित केल्यामुळे होते.
    ///
    pub fn calc_split_length(
        total_num: usize,
        root_a: &Root<K, V>,
        root_b: &Root<K, V>,
    ) -> (usize, usize) {
        let (length_a, length_b);
        if root_a.height() < root_b.height() {
            length_a = root_a.reborrow().calc_length();
            length_b = total_num - length_a;
            debug_assert_eq!(length_b, root_b.reborrow().calc_length());
        } else {
            length_b = root_b.reborrow().calc_length();
            length_a = total_num - length_b;
            debug_assert_eq!(length_a, root_a.reborrow().calc_length());
        }
        (length_a, length_b)
    }

    /// दिलेल्या की वर आणि नंतर की-व्हॅल्यू जोड्यांसह झाडाचे विभाजन करा.
    /// जर झाडाला कळ द्वारे क्रमवारी लावली गेली असेल तरच आणि `Q` चे क्रमवारी `K` प्रमाणे असेल तरच परिणाम अर्थपूर्ण आहे.
    /// जर `self` सर्व `BTreeMap` वृक्ष आक्रमणकर्त्यांचा आदर करत असेल तर `self` आणि परतलेले झाड दोघेही त्या आक्रमणकर्त्यांचा आदर करतील.
    ///
    ///
    pub fn split_off<Q: ?Sized + Ord>(&mut self, key: &Q) -> Self
    where
        K: Borrow<Q>,
    {
        let left_root = self;
        let mut right_root = Root::new_pillar(left_root.height());
        let mut left_node = left_root.borrow_mut();
        let mut right_node = right_root.borrow_mut();

        loop {
            let mut split_edge = match left_node.search_node(key) {
                // की उजव्या झाडाकडे जात आहे
                Found(kv) => kv.left_edge(),
                GoDown(edge) => edge,
            };

            split_edge.move_suffix(&mut right_node);

            match (split_edge.force(), right_node.force()) {
                (Internal(edge), Internal(node)) => {
                    left_node = edge.descend();
                    right_node = node.first_edge().descend();
                }
                (Leaf(_), Leaf(_)) => break,
                _ => unreachable!(),
            }
        }

        left_root.fix_right_border();
        right_root.fix_left_border();
        right_root
    }

    /// रिक्त नोड्स असलेले एक झाड तयार करते.
    fn new_pillar(height: usize) -> Self {
        let mut root = Root::new();
        for _ in 0..height {
            root.push_internal_level();
        }
        root
    }
}