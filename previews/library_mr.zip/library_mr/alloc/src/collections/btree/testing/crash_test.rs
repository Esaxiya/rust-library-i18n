use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// विशिष्ट घटनांचे परीक्षण करणार्‍या क्रॅश टेस्ट डमी प्रसंगांचे ब्ल्यू प्रिंट.
/// काही उदाहरणे काही क्षणी panic वर कॉन्फिगर केली जाऊ शकतात.
/// इव्हेंट्स `clone`, `drop` किंवा काही अनामिक `query` आहेत.
///
/// क्रॅश टेस्ट डमी ओळखल्या जातात आणि आयडीद्वारे ऑर्डर केल्या जातात, ज्यायोगे ते बीटीआरॅपमध्ये की म्हणून वापरल्या जाऊ शकतात.
/// हेतुपुरस्सर वापरलेली अंमलबजावणी `Debug` trait व्यतिरिक्त crate मध्ये परिभाषित केलेल्या कोणत्याही गोष्टीवर अवलंबून नाही.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// क्रॅश टेस्ट डमी डिझाइन तयार करते.`id` क्रमवारी व घटनांची समानता निर्धारित करते.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// क्रॅश टेस्ट डमीचे एक उदाहरण तयार करते जे त्यास कोणत्या घटनांचा अनुभव घेते आणि पर्यायाने panics नोंदवते.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// डमीच्या किती वेळा क्लोन केल्या गेल्याचे परत मिळवते.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// डमीची किती वेळा उदाहरणे सोडली आहेत याची परत मिळते.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// डमीच्या त्याच्या एक्स 100 एक्स सदस्याकडे किती वेळा विनंती केली आहे याची परत येते.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// काही अज्ञात क्वेरी, ज्याचा निकाल आधीच देण्यात आला आहे.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}