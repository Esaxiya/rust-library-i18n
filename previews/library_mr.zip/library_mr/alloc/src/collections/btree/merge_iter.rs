use core::cmp::Ordering;
use core::fmt::{self, Debug};
use core::iter::FusedIterator;

/// आयटरचा कोर जो दोन कठोरपणे चढत्या पुनरावृत्ती झालेल्यांचे आउटपुट विलीन करतो, उदाहरणार्थ एक संघ किंवा सममितीय फरक.
///
pub struct MergeIterInner<I: Iterator> {
    a: I,
    b: I,
    peeked: Option<Peeked<I>>,
}

/// दोन्ही इट्रेटर्सला पीक करण्यायोग्य गुंडाळण्यापेक्षा बेंचमार्क वेगवान आहे, कदाचित आम्ही फ्यूजस्टेटर बंधन लागू करण्यास परवडणार आहोत.
///
#[derive(Clone, Debug)]
enum Peeked<I: Iterator> {
    A(I::Item),
    B(I::Item),
}

impl<I: Iterator> Clone for MergeIterInner<I>
where
    I: Clone,
    I::Item: Clone,
{
    fn clone(&self) -> Self {
        Self { a: self.a.clone(), b: self.b.clone(), peeked: self.peeked.clone() }
    }
}

impl<I: Iterator> Debug for MergeIterInner<I>
where
    I: Debug,
    I::Item: Debug,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("MergeIterInner").field(&self.a).field(&self.b).field(&self.peeked).finish()
    }
}

impl<I: Iterator> MergeIterInner<I> {
    /// स्त्रोतांच्या जोडीने विलीन होणार्‍या पुनरावृत्तीसाठी नवीन कोर तयार करते.
    pub fn new(a: I, b: I) -> Self {
        MergeIterInner { a, b, peeked: None }
    }

    /// विलीन होणार्‍या स्त्रोतांच्या जोडीपासून उद्भवणारी आयटमची पुढील जोडी मिळवते.
    /// जर दोन्ही परत केलेल्या पर्यायांमध्ये मूल्य असेल तर ते मूल्य समान आहे आणि दोन्ही स्रोतांमध्ये उद्भवते.
    /// परत केलेल्या पर्यायांपैकी एकामध्ये मूल्य असल्यास, ते मूल्य इतर स्त्रोतामध्ये आढळत नाही (किंवा स्त्रोत काटेकोरपणे चढत्या प्रमाणात नाहीत).
    ///
    /// जराही परत केलेल्या पर्यायात मूल्य नसल्यास, पुनरावृत्ती समाप्त झाली आणि त्यानंतरचे कॉल समान रिक्त जोडी परत करतील.
    ///
    ///
    pub fn nexts<Cmp: Fn(&I::Item, &I::Item) -> Ordering>(
        &mut self,
        cmp: Cmp,
    ) -> (Option<I::Item>, Option<I::Item>)
    where
        I: FusedIterator,
    {
        let mut a_next;
        let mut b_next;
        match self.peeked.take() {
            Some(Peeked::A(next)) => {
                a_next = Some(next);
                b_next = self.b.next();
            }
            Some(Peeked::B(next)) => {
                b_next = Some(next);
                a_next = self.a.next();
            }
            None => {
                a_next = self.a.next();
                b_next = self.b.next();
            }
        }
        if let (Some(ref a1), Some(ref b1)) = (&a_next, &b_next) {
            match cmp(a1, b1) {
                Ordering::Less => self.peeked = b_next.take().map(Peeked::B),
                Ordering::Greater => self.peeked = a_next.take().map(Peeked::A),
                Ordering::Equal => (),
            }
        }
        (a_next, b_next)
    }

    /// अंतिम आयटरच्या `size_hint` साठी वरच्या सीमेची जोडी मिळवते.
    pub fn lens(&self) -> (usize, usize)
    where
        I: ExactSizeIterator,
    {
        match self.peeked {
            Some(Peeked::A(_)) => (1 + self.a.len(), self.b.len()),
            Some(Peeked::B(_)) => (self.a.len(), 1 + self.b.len()),
            _ => (self.a.len(), self.b.len()),
        }
    }
}