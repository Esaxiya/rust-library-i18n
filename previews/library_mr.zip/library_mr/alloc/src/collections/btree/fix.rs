use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef, Root};

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// भावंडात विलीन करून किंवा चोरी करून शक्यतो अंडरफुल नोड साठवते.
    /// यशस्वी असल्यास परंतु मूळ नोड संकुचित करण्याच्या किंमतीवर, संकुचित पॅरंट नोड मिळवते.
    /// नोड रिक्त रूट असल्यास एक `Err` मिळवते.
    ///
    fn fix_node_through_parent(
        self,
    ) -> Result<Option<NodeRef<marker::Mut<'a>, K, V, marker::Internal>>, Self> {
        let len = self.len();
        if len >= MIN_LEN {
            Ok(None)
        } else {
            match self.choose_parent_kv() {
                Ok(Left(mut left_parent_kv)) => {
                    if left_parent_kv.can_merge() {
                        let parent = left_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        left_parent_kv.bulk_steal_left(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Ok(Right(mut right_parent_kv)) => {
                    if right_parent_kv.can_merge() {
                        let parent = right_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        right_parent_kv.bulk_steal_right(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Err(root) => {
                    if len > 0 {
                        Ok(None)
                    } else {
                        Err(root)
                    }
                }
            }
        }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// संभाव्यत: अंडरफुल नोड साठा करतो आणि यामुळे जर त्याचे पालक नोड संकुचित होते, तर पालकांना वारंवार साठा करते.
    /// `true` ने वृक्ष निश्चित केल्यास तो परत करेल, `false` शक्य नसल्यास ते रूट नोड रिक्त झाले.
    ///
    /// रिक्त पूर्वज आढळल्यास या पद्धतीद्वारे पूर्वजांच्या आधीच प्रवेशानंतर आणि झेडस्पॅनिक्स 0 झेड आधीपासूनच अंडरफुल असेल अशी अपेक्षा करत नाही.
    ///
    ///
    ///
    pub fn fix_node_and_affected_ancestors(mut self) -> bool {
        loop {
            match self.fix_node_through_parent() {
                Ok(Some(parent)) => self = parent.forget_type(),
                Ok(None) => return true,
                Err(_) => return false,
            }
        }
    }
}

impl<K, V> Root<K, V> {
    /// शीर्षस्थानी रिक्त स्तर काढून टाकते, परंतु संपूर्ण झाड रिक्त असल्यास रिक्त पान ठेवते.
    pub fn fix_top(&mut self) {
        while self.height() > 0 && self.len() == 0 {
            self.pop_internal_level();
        }
    }

    /// झाडाच्या उजवीकडील सीमेवरील कोणत्याही अंडरफुल नोड्स साठवतात किंवा विलीन करतात.
    /// इतर नोड्स, जे मूळ नाहीत किंवा अगदी बरोबर edge नाहीत, त्यांच्याकडे आधीपासूनच किमान MIN_LEN घटक असणे आवश्यक आहे.
    ///
    pub fn fix_right_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().last_kv().fix_right_border_of_right_edge();
            self.fix_top();
        }
    }

    /// `fix_right_border` चे सममितीय क्लोन.
    pub fn fix_left_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().first_kv().fix_left_border_of_left_edge();
            self.fix_top();
        }
    }

    /// झाडाच्या उजव्या सीमेवर कोणत्याही अंडरफुल नोड्सचा साठा करा.
    /// इतर नोड्स, जे मूळ नाहीत किंवा अगदी बरोबर edge नाहीत, त्यांनी जवळजवळ MIN_LEN घटक चोरी करण्यासाठी तयार केले जाणे आवश्यक आहे.
    ///
    pub fn fix_right_border_of_plentiful(&mut self) {
        let mut cur_node = self.borrow_mut();
        while let Internal(internal) = cur_node.force() {
            // सर्वात उजवीकडील मूल मुलभूत नसलेली आहे का ते तपासा.
            let mut last_kv = internal.last_kv().consider_for_balancing();
            debug_assert!(last_kv.left_child_len() >= MIN_LEN * 2);
            let right_child_len = last_kv.right_child_len();
            if right_child_len < MIN_LEN {
                // आम्ही चोरी करणे आवश्यक आहे.
                last_kv.bulk_steal_left(MIN_LEN - right_child_len);
            }

            // आणखी खाली जा.
            cur_node = last_kv.into_right_child();
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    fn fix_left_border_of_left_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_left_child().first_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }

    fn fix_right_border_of_right_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_right_child().last_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// डाव्या मुलाला साठवून ठेवून, योग्य मुल गृहीत धरले नाही आणि असे समजते की त्याच्या मुलांना अधूनमधून न विलीन करता यावी म्हणून एक मूलभूत तरतूद करण्याची तरतूद आहे.
    ///
    /// डाव्या मुलाला परत करते.
    ///
    fn fix_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let left_len = internal_kv.left_child_len();
        debug_assert!(internal_kv.right_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` पुढच्या स्तरावर विलीन झाल्यास पुन्हा समायोजित करणे टाळण्यासाठी.
            let count = (MIN_LEN + 1).saturating_sub(left_len);
            if count > 0 {
                internal_kv.bulk_steal_right(count);
            }
            internal_kv.into_left_child()
        }
    }

    /// डाव्या मुलाला अंडरफुल नसल्याचे गृहीत धरुन उजव्या मुलाचा साठा करतो आणि त्याच्या मुलांना विनाकारण अडकविण्यामागे विलीन करण्याची परवानगी देण्यासाठी अतिरिक्त घटकांची तरतूद करते.
    ///
    /// योग्य मुल संपले तेथे जिथे परत येते.
    ///
    fn fix_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let right_len = internal_kv.right_child_len();
        debug_assert!(internal_kv.left_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` पुढच्या स्तरावर विलीन झाल्यास पुन्हा समायोजित करणे टाळण्यासाठी.
            let count = (MIN_LEN + 1).saturating_sub(right_len);
            if count > 0 {
                internal_kv.bulk_steal_left(count);
            }
            internal_kv.into_right_child()
        }
    }
}