use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef};

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    /// झाडापासून एक की-व्हॅल्यूची जोडी काढून टाकते आणि ती जोडी परत करते, तसेच पूर्वीच्या जोडीशी संबंधित edge लीफ मिळवते.
    /// हे शक्य आहे की हे अंतर्गत नोंदी रिकामे करेल जे कॉलरने झाड धारण केलेल्या नकाशावरून पॉप करावे.
    /// कॉलरने नकाशाची लांबी देखील कमी केली पाहिजे.
    ///
    pub fn remove_kv_tracking<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        match self.force() {
            Leaf(node) => node.remove_leaf_kv(handle_emptied_internal_root),
            Internal(node) => node.remove_internal_kv(handle_emptied_internal_root),
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    fn remove_leaf_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let (old_kv, mut pos) = self.remove();
        let len = pos.reborrow().into_node().len();
        if len < MIN_LEN {
            let idx = pos.idx();
            // आम्हाला लहान मुलांचा प्रकार तात्पुरता विसरला पाहिजे, कारण पानाच्या तात्काळ पालकांसाठी कोणताही नोड प्रकार नाही.
            //
            let new_pos = match pos.into_node().forget_type().choose_parent_kv() {
                Ok(Left(left_parent_kv)) => {
                    debug_assert!(left_parent_kv.right_child_len() == MIN_LEN - 1);
                    if left_parent_kv.can_merge() {
                        left_parent_kv.merge_tracking_child_edge(Right(idx))
                    } else {
                        debug_assert!(left_parent_kv.left_child_len() > MIN_LEN);
                        left_parent_kv.steal_left(idx)
                    }
                }
                Ok(Right(right_parent_kv)) => {
                    debug_assert!(right_parent_kv.left_child_len() == MIN_LEN - 1);
                    if right_parent_kv.can_merge() {
                        right_parent_kv.merge_tracking_child_edge(Left(idx))
                    } else {
                        debug_assert!(right_parent_kv.right_child_len() > MIN_LEN);
                        right_parent_kv.steal_right(idx)
                    }
                }
                Err(pos) => unsafe { Handle::new_edge(pos, idx) },
            };
            // सुरक्षितताः `new_pos` हे पान आहे ज्यापासून आपण सुरुवात केली किंवा एखादी बहीण.
            pos = unsafe { new_pos.cast_to_leaf_unchecked() };

            // केवळ जर आपण विलीन केले तरच पालक (असल्यास असल्यास) संकुचित झाला आहे, परंतु खालील चरण वगळल्यास अन्यथा बेंचमार्कमध्ये पैसे दिले जात नाहीत.
            //
            // सुरक्षितताः आम्ही ज्या ठिकाणी `pos` आहे तेथे लीफ नष्ट किंवा पुनर्रचना करणार नाही
            // त्याच्या पालकांना वारंवार हाताळणी करून;सर्वात वाईट म्हणजे आम्ही आजी-आजोबाद्वारे पालकांचा नाश किंवा पुनर्रचना करू, अशा प्रकारे पानाच्या आत पालकांचा दुवा बदलू.
            //
            //
            //
            if let Ok(parent) = unsafe { pos.reborrow_mut() }.into_node().ascend() {
                if !parent.into_node().forget_type().fix_node_and_affected_ancestors() {
                    handle_emptied_internal_root();
                }
            }
        }
        (old_kv, pos)
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    fn remove_internal_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        // त्याच्या पानातून एक संबद्ध केव्ही काढा आणि नंतर आम्हाला त्या घटकाच्या जागी परत काढायला सांगितले.
        //
        // `choose_parent_kv` मध्ये सूचीबद्ध केलेल्या कारणांमुळे डावीकडील केव्हीला प्राधान्य द्या.
        let left_leaf_kv = self.left_edge().descend().last_leaf_edge().left_kv();
        let left_leaf_kv = unsafe { left_leaf_kv.ok().unwrap_unchecked() };
        let (left_kv, left_hole) = left_leaf_kv.remove_leaf_kv(handle_emptied_internal_root);

        // अंतर्गत नोड कदाचित चोरी केले गेले असेल किंवा विलीन केले असेल.
        // मूळ केव्ही कोठे संपला हे शोधण्यासाठी उजवीकडे परत जा.
        let mut internal = unsafe { left_hole.next_kv().ok().unwrap_unchecked() };
        let old_kv = internal.replace_kv(left_kv.0, left_kv.1);
        let pos = internal.next_leaf_edge();
        (old_kv, pos)
    }
}