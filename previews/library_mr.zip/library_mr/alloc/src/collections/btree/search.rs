use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// `Bound::Included(T)` प्रमाणेच, सर्वसमावेशक बाध्यकारी.
    Included(T),
    /// `Bound::Excluded(T)` प्रमाणेच, अनन्य बाउंड पहाण्यासाठी.
    Excluded(T),
    /// `Bound::Unbounded` प्रमाणेच बिनशर्त सर्वसमावेशक मर्यादा.
    AllIncluded,
    /// एक बिनशर्त अनन्य सीम.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// नोडच्या अध्यक्षतेखाली असलेल्या (उप) झाडामध्ये दिलेली की पुन्हा पुन्हा दिसते.
    /// जुळणार्‍या केव्हीच्या हँडलसह एक `Found` मिळवते.
    /// अन्यथा, कीची मालकी असलेल्या edge च्या पानांच्या हँडलसह एक `GoDown` मिळवते.
    ///
    /// `BTreeMap` मधील झाडाप्रमाणेच झाडाला कळ द्वारे क्रम लावल्यासच अर्थपूर्ण आहे.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// श्रेणीच्या खालच्या सीमेशी जुळणारी edge वरच्या बाउंडशी जुळणार्‍या edge पेक्षा भिन्न आहे म्हणजे जवळच्या नोडला खाली जाते, म्हणजे जवळच्या नोडमध्ये ज्यामध्ये श्रेणीमध्ये कमीतकमी एक की असेल.
    ///
    ///
    /// आढळल्यास, त्या नोडसह `Ok` परत करते, त्यामध्ये edge निर्देशांकांची जोडी श्रेणी मर्यादित करते आणि नोड अंतर्गत असल्यास, मुलाच्या नोड्समध्ये शोध चालू ठेवण्यासाठी सीमांचे संबंधित जोड.
    ///
    /// आढळले नाही तर संपूर्ण श्रेणीशी जुळणारी पान edge सह `Err` परत करते.
    ///
    /// झाडाला किल्लीद्वारे ऑर्डर दिली गेली तरच परिणाम अर्थपूर्ण आहे.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // हे व्हेरिएबल्स इनलाइन करणे टाळले पाहिजे.
        // आम्ही असे गृहीत धरतो की एक्स ०१ एक्सने कळवलेली सीमाही तशीच आहे, परंतु एक्स-एक्सएक्सएक्सएक्सची अंमलबजावणी (#81138) कॉल दरम्यान बदलू शकते.
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// श्रेणीच्या खालच्या मर्यादेचे मर्यादा घालणार्‍या नोडमध्ये एक edge शोधते.
    /// `self` अंतर्गत नोड असल्यास जुळणार्‍या चाइल्ड नोडमध्ये शोध सुरू ठेवण्यासाठी वापरण्यासाठी वापरण्यात येणारी खालची सीमा देखील परत करते.
    ///
    ///
    /// झाडाला किल्लीद्वारे ऑर्डर दिली गेली तरच परिणाम अर्थपूर्ण आहे.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// वरच्या सीमेसाठी `find_lower_bound_edge` चा क्लोन
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// पुनरावृत्ती न करता नोडमध्ये दिलेली की दिसते.
    /// जुळणार्‍या केव्हीच्या हँडलसह एक `Found` मिळवते.
    /// अन्यथा, झेडजेडझेडझेडच्या हँडलसह एक एक्स00 एक्स मिळवते जिथे की आढळू शकते (नोड अंतर्गत असेल तर) किंवा जेथे की घातली जाऊ शकते.
    ///
    ///
    /// `BTreeMap` मधील झाडाप्रमाणेच झाडाला कळ द्वारे क्रम लावल्यासच अर्थपूर्ण आहे.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// की (किंवा समकक्ष) जिथे विद्यमान असलेल्या नोडमध्ये केव्ही अनुक्रमणिका किंवा की मालकीची आहे तेथे edge अनुक्रमणिका मिळवते.
    ///
    ///
    /// `BTreeMap` मधील झाडाप्रमाणेच झाडाला कळ द्वारे क्रम लावल्यासच अर्थपूर्ण आहे.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// श्रेणीची खालची सीमा मर्यादा घालणार्‍या नोडमध्ये एक edge अनुक्रमणिका शोधते.
    /// `self` अंतर्गत नोड असल्यास जुळणार्‍या चाइल्ड नोडमध्ये शोध सुरू ठेवण्यासाठी वापरण्यासाठी वापरण्यात येणारी खालची सीमा देखील परत करते.
    ///
    ///
    /// झाडाला किल्लीद्वारे ऑर्डर दिली गेली तरच परिणाम अर्थपूर्ण आहे.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// वरच्या सीमेसाठी `find_lower_bound_index` चा क्लोन
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}