// आदर्शानंतरच्या अंमलबजावणीचा हा प्रयत्न आहे
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Rust प्रत्यक्षात अवलंबून नसलेले प्रकार आणि बहुभुज रिकर्जन नसल्याने आम्ही बर्‍याच असुरक्षिततेसह करतो.
//

// या मॉड्यूलचे एक प्रमुख लक्ष्य म्हणजे झाडाला जेनेरिक (विचित्र आकाराने) कंटेनर म्हणून उपचार देऊन आणि बहुतेक बी-वृक्ष आक्रमणकर्त्यांसह व्यवहार करणे टाळणे.
//
// या नोंदी या क्रमवारीत आहेत की कोणत्या नोड्स अंडरफुल असू शकतात किंवा अंडरफुल म्हणजे काय, या मॉड्यूलकडे लक्ष नाही.तथापि, आम्ही काही आक्रमणकर्त्यांवर अवलंबून आहोतः
//
// - झाडांमध्ये एकसमान depth/height असणे आवश्यक आहे.याचा अर्थ असा आहे की दिलेल्या नोडपासून एका पानाकडे जाणार्‍या प्रत्येक मार्गाची लांबी अगदी तशीच असते.
// - `n` लांबीच्या नोडमध्ये `n` की, `n` मूल्ये आणि `n + 1` कडा आहेत.
//   याचा अर्थ असा होतो की रिक्त नोडमध्ये देखील कमीतकमी एक edge आहे.
//   लीफ नोडसाठी, एक्स00 एक्स चा अर्थ फक्त आम्ही नोडमधील स्थान ओळखू शकतो, कारण पानांची कडा रिक्त आहे आणि डेटा प्रतिनिधित्व आवश्यक नाही.
// अंतर्गत नोडमध्ये, एक edge दोन्ही स्थान ओळखते आणि त्यामध्ये मुलाच्या नोडला निर्देशक असतात.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// लीफ नोड्सचे अंतर्गत प्रतिनिधित्व आणि अंतर्गत नोड्सचे प्रतिनिधित्व करणारा भाग.
struct LeafNode<K, V> {
    /// आम्हाला `K` आणि `V` मध्ये सहजासहजी व्हायचे आहे.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// मूळ नोडच्या `edges` अ‍ॅरेमध्ये या नोडची अनुक्रमणिका.
    /// `*node.parent.edges[node.parent_idx]` `node` सारखीच गोष्ट असावी.
    /// जेव्हा केवळ `parent` नॉन-शून्य असेल तेव्हाच याची सुरूवात करण्याची हमी दिली जाते.
    parent_idx: MaybeUninit<u16>,

    /// या नोड स्टोअरमध्ये की आणि व्हॅल्यूची संख्या.
    len: u16,

    /// अ‍ॅरे नोडचा वास्तविक डेटा संचयित करतात.
    /// प्रत्येक अ‍ॅरेचे फक्त प्रथम `len` घटक आरंभ आणि वैध असतात.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// ठिकाणी नवीन `LeafNode` प्रारंभ करते.
    unsafe fn init(this: *mut Self) {
        // एक सामान्य धोरण म्हणून, फील्ड्स असू शकतात तर ते बिनविभाजित सोडतात, कारण वॅलग्राइंडमध्ये हे थोडी वेगवान आणि सुलभ असले पाहिजे.
        //
        unsafe {
            // पालक_idx, कळा आणि vals सर्व कदाचितUUininit आहेत
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// नवीन बॉक्सिंग `LeafNode` तयार करते.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// अंतर्गत नोड्सचे अंतर्गत प्रतिनिधित्व.`लीफनोड्स प्रमाणेच, न करता निरुपयोगी की आणि मूल्ये सोडणे टाळण्यासाठी हे` BoxedNode`s च्या मागे लपलेले असावेत.
/// `InternalNode` चे कोणतेही पॉईंटर थेट नोडच्या अंतर्निहित `LeafNode` भागाकडे पॉईंटरवर थेट पेस्ट केले जाऊ शकतात, ज्यामुळे पॉईंटर दोन पैकी कोणत्या बिंदूकडे निर्देशित करीत आहे हे तपासल्याशिवाय कोड लीफ आणि अंतर्गत नोड्सवर सामान्यपणे कार्य करू शकेल.
///
/// ही मालमत्ता `repr(C)` च्या वापराद्वारे सक्षम केली आहे.
///
#[repr(C)]
// gdb_providers.py आत्मपरीक्षण करण्यासाठी या प्रकारचे नाव वापरते.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// या नोडच्या मुलांना पॉईंटर्स
    /// `len + 1` यापैकी आरंभिक आणि वैध मानले जातात, शेवटच्या जवळ वगळता, झाडाचे कर्ज घेण्याच्या प्रकाराद्वारे `Dying` ठेवले जाते, तर त्यातील काही पॉईंटर्स झुंबडत आहेत.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// नवीन बॉक्सिंग `InternalNode` तयार करते.
    ///
    /// # Safety
    /// अंतर्गत नोड्सचा अविभाज्य असा आहे की त्यांच्याकडे कमीतकमी एक आरंभिक आणि वैध edge असेल.
    /// हे कार्य अशा edge सेट अप करत नाही.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // आम्हाला केवळ डेटा आरंभ करण्याची आवश्यकता आहे;कडा कदाचित युनिट आहेत.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// नोडवर व्यवस्थापित, नल-पॉलींटरहे एकतर `LeafNode<K, V>` चे मालकीचे पॉईंटर किंवा `InternalNode<K, V>` चे मालकीचे पॉईंटर आहे.
///
/// तथापि, एक्स 200 एक्समध्ये त्यामध्ये कोणत्या दोन नोड्स आहेत ज्याविषयी प्रत्यक्षात माहिती नाही आणि अंशतः माहितीच्या अभावामुळे हा वेगळा प्रकार नाही आणि विध्वंसकही नाही.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// मालकीच्या झाडाचे मूळ नोड.
///
/// लक्षात घ्या की यात डिस्ट्रॅक्टर नाही आणि व्यक्तिचलितरित्या साफ केले जाणे आवश्यक आहे.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// प्रारंभी रिक्त असलेल्या त्याच्या स्वतःच्या मूळ नोडसह नवीन मालकीचे झाड मिळवते.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` शून्य नसावे.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// परस्पररित्या मालकीचे मूळ नोड घेते.
    /// एक्स 100 एक्स विपरीत, हे सुरक्षित आहे कारण रूट नष्ट करण्यासाठी परताव्याचे मूल्य वापरले जाऊ शकत नाही आणि झाडाचे इतर संदर्भ असू शकत नाहीत.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// किंचित परस्परपणे मालकीचे रूट नोड घेते.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ट्रान्सव्हर्सलला परवानगी देणारी आणि विध्वंसक पद्धती आणि इतर काही ऑफर करणार्‍या संदर्भावर न बदलता संक्रमणे.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// मागील रूट नोडकडे निर्देशित केलेल्या एकल झेडजेड0 झेडसह नवीन अंतर्गत नोड जोडते, ते नवीन नोड रूट नोड बनवा आणि ते परत करा.
    /// हे उंची 1 ने वाढवते आणि हे `pop_internal_level` च्या विरूद्ध आहे.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, याशिवाय आम्ही आता विसरलो आहोत की आम्ही आता अंतर्गत आहोत:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// अंतर्गत रूट नोड काढून टाकते, त्याचे प्रथम मूल नवीन रूट नोड म्हणून.
    /// ज्याचा उद्देश फक्त रूट नोडला फक्त एक मूल असतो तेव्हाच केला जाण्याचा हेतू असतो, की कळा, मूल्ये आणि इतर मुलांवर कोणतीही साफसफाई केली जात नाही.
    ///
    /// ही उंची 1 ने कमी करते आणि हे `push_internal_level` च्या विरूद्ध आहे.
    ///
    /// `Root` ऑब्जेक्टमध्ये विशेष प्रवेश आवश्यक आहे परंतु रूट नोडमध्ये नाही;
    /// हे अन्य हँडल किंवा मूळ नोडचा संदर्भ अवैध करणार नाही.
    ///
    /// अंतर्गत पातळी नसल्यास Panics, म्हणजेच जर रूट नोड एक पान असेल तर.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // सुरक्षा: आम्ही अंतर्गत असल्याचे प्रतिपादन केले.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // सुरक्षितता: आम्ही एक्सक्लेक्स पूर्णपणे घेतले आणि त्याचा कर्ज घेण्याचा प्रकार अनन्य आहे.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // सुरक्षाः प्रथम झेडजेड 0 झेड नेहमी आरंभ केला जातो.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` X X01 एक्स असूनही `NodeRef` `K` आणि `V` मध्ये नेहमीच सुसंस्कृत असते.
// हे तांत्रिकदृष्ट्या चुकीचे आहे, परंतु `NodeRef` च्या अंतर्गत वापरामुळे कोणत्याही असफलतेचा परिणाम होऊ शकत नाही कारण आम्ही `K` आणि `V` वर पूर्णपणे सामान्य राहतो.
//
// तथापि, जेव्हा जेव्हा एखादा सार्वजनिक प्रकार `NodeRef` गुंडाळतो, तेव्हा खात्री करुन घ्या की त्यात योग्य तफावत आहे.
//
/// नोडचा संदर्भ.
///
/// या प्रकारात असंख्य मापदंड आहेत जे हे कसे कार्य करते यावर नियंत्रण ठेवते:
/// - `BorrowType`: एक डमी प्रकार जे कर्ज घेण्याच्या प्रकाराचे वर्णन करते आणि जीवनभर चालते.
///    - जेव्हा हे X01 एक्स असते तेव्हा `NodeRef` हे अंदाजे `&'a Node` प्रमाणे कार्य करते.
///    - जेव्हा हे एक्स 100 एक्स असते, तेव्हा एक्स 0 एक्स एक्स आणि ट्री स्ट्रक्चरच्या संदर्भात अंदाजे `&'a Node` प्रमाणेच कार्य करते, परंतु संपूर्ण झाडाच्या मूल्यांमध्ये अनेक बदल बदलू शकत नाही.
///    - जेव्हा हे एक्स 100 एक्स असते तेव्हा एक्स0 2 एक्स अंदाजे `&'a mut Node` प्रमाणेच कार्य करते, जरी अंतर्भूत पध्दती बदलण्यायोग्य पॉईंटरला एकत्र राहण्यास परवानगी देतात.
///    - जेव्हा हे एक्स 100 एक्स असते, तेव्हा एक्स 0 एक्स एक्स एक्स 1 एक्ससारखे कार्य करते, परंतु त्यात डिस्ट्रक्टर नसतो आणि ते स्वहस्ते साफ केले पाहिजेत.
///    - जेव्हा हे एक्स 100 एक्स असते तेव्हा `NodeRef` अजूनही साधारणपणे एक्स01 एक्स प्रमाणेच कार्य करते, परंतु त्या झाडाला थोडीशी नष्ट करण्याची पद्धती आहेत आणि सामान्य पद्धती, ज्याला कॉल करणे असुरक्षित म्हणून चिन्हांकित केलेले नाही, चुकीच्या पद्धतीने कॉल केल्यास युबीची विनंती करू शकते.
///
///   कोणताही X01 एक्स झाडावरुन नेव्हिगेट करण्यास परवानगी देत असल्याने, एक्स00 एक्स केवळ नोडलाच नव्हे तर संपूर्ण झाडास प्रभावीपणे लागू करते.
/// - `K` आणि एक्स00 एक्स: हे नोड्समध्ये संग्रहित केलेल्या की आणि मूल्यांचे प्रकार आहेत.
/// - `Type`: हे `Leaf`, `Internal` किंवा `LeafOrInternal` असू शकते.
/// जेव्हा हे एक्स 100 एक्स असते तेव्हा एक्स01 एक्स लीफ नोडला निर्देशित करते, जेव्हा हे एक्स0 2 एक्स असते तेव्हा एक्स03 एक्स अंतर्गत नोडला सूचित करते आणि जेव्हा हे एक्स 0 एक्स एक्स असते तेव्हा एक्स05 एक्स एकतर प्रकारच्या नोडला सूचित करू शकते.
///   `Type` `NodeRef` बाहेरील वापरले जाते तेव्हा त्याला `NodeType` असे नाव दिले जाते.
///
/// `BorrowType` आणि `NodeType` दोन्ही स्थिर प्रकारच्या सुरक्षिततेचे शोषण करण्यासाठी आम्ही कोणत्या पद्धती लागू करतो यावर प्रतिबंधित करते.आम्ही अशा निर्बंध लागू करू शकतो अशा प्रकारे काही मर्यादा आहेतः
/// - प्रत्येक प्रकारच्या पॅरामीटरसाठी, आम्ही केवळ एक पद्धत सर्वसाधारणपणे किंवा एका विशिष्ट प्रकारासाठी परिभाषित करू शकतो.
/// उदाहरणार्थ, आम्ही `into_kv` सारखी पद्धत सर्व एक्स 100 एक्ससाठी किंवा संपूर्ण आयुष्यातल्या सर्व प्रकारच्या एकदा परिभाषित करू शकत नाही, कारण एक्स एक्स 2 एक्स संदर्भ परत मिळावा अशी आपली इच्छा आहे.
///   म्हणूनच आम्ही केवळ कमीतकमी शक्तिशाली प्रकारच्या `Immut<'a>` साठी परिभाषित करतो.
/// - आम्ही `Mut<'a>` ते `Immut<'a>` म्हटल्यापासून अंतर्ग्रहण करू शकत नाही.
///   म्हणूनच, एक्स00 एक्स सारख्या पध्दतीवर पोहोचण्यासाठी आम्हाला अधिक पॉवरफुल एक्स ०२ एक्सवर स्पष्टपणे एक्स ०१ एक्स म्हटले आहे.
///
/// `NodeRef` वरील सर्व पद्धती ज्या काही प्रकारचे संदर्भ परत करतात:
/// - मूल्यानुसार `self` घ्या आणि `BorrowType` ने चालविलेले आजीवन परत करा.
///   कधीकधी, अशी पद्धत वापरण्यासाठी, आम्हाला `reborrow_mut` वर कॉल करणे आवश्यक आहे.
/// - संदर्भानुसार `self` घ्या आणि X002 ने केलेल्या आजीवनाच्या ऐवजी (implicitly) त्या संदर्भाचे आजीवन परत आणा.
/// अशाप्रकारे, कर्ज तपासक हमी देतो की परत केलेला संदर्भ वापरल्याखेरीज `NodeRef` कर्ज घेतले जाते.
///   घाला घालण्यास समर्थन देणार्‍या पद्धती कच्चा पॉईन्टर परत केल्याने हा नियम वाकतात, म्हणजेच, आजीविकाशिवाय संदर्भ.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// नोड आणि पानांची पातळी खाली असलेल्या पातळीची संख्या, नोडचा स्थिर भाग ज्याचे संपूर्णपणे एक्स00 एक्स द्वारे वर्णन केले जाऊ शकत नाही आणि ते नोड स्वतःच साठवत नाहीत.
    /// आम्हाला फक्त रूट नोडची उंची साठवण्याची आणि त्यापासून प्रत्येक इतर नोडची उंची मिळविणे आवश्यक आहे.
    /// `Type` `Leaf` असल्यास शून्य आणि `Type` `Internal` असल्यास शून्य नसणे आवश्यक आहे.
    ///
    ///
    height: usize,
    /// पानांचे किंवा अंतर्गत नोडचे सूचक.
    /// `InternalNode` ची व्याख्या हे सुनिश्चित करते की पॉईंटर एकतर मार्गाने वैध आहे.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// `NodeRef::parent` म्हणून पॅक केलेला नोड संदर्भ अनपॅक करा.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// अंतर्गत नोडचा डेटा उघड करतो.
    ///
    /// या नोडवर अन्य संदर्भ अवैध करण्यास टाळण्यासाठी एक कच्चा पीटीआर परत करते.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // सुरक्षितता: स्टॅटिक नोड प्रकार एक्स 100 एक्स आहे.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// अंतर्गत नोडच्या डेटावर विशिष्ट प्रवेश घेते.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// नोडची लांबी शोधते.ही की किंवा मूल्यांची संख्या आहे.
    /// किनारांची संख्या `len() + 1` आहे.
    /// लक्षात ठेवा, सुरक्षित असूनही, या फंक्शनला कॉल केल्याने असुरक्षित कोडने तयार केलेल्या अवैध बदल करण्याच्या संदर्भांचा दुष्परिणाम होऊ शकतो.
    ///
    pub fn len(&self) -> usize {
        // निर्णायकपणे, आम्ही येथे केवळ `len` फील्डमध्ये प्रवेश करतो.
        // जर बोर्न टाईप marker::ValMut असेल तर त्या मूल्यांबाबत थकबाकीदार बदल बदलू शकतील जे आपण अवैध करू नयेत.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// नोड आणि पाने वेगळ्या असलेल्या पातळीची संख्या मिळवते.
    /// शून्य उंची म्हणजे नोड एक पानच असते.
    /// जर आपण मुळांच्या वरची झाडे चित्रित केली तर संख्या सांगते की कोणत्या उंचीवर नोड दिसते.
    /// जर आपण वर पाने असलेली झाडे चित्रित केली तर संख्या नोडच्या वरचे झाड किती उंच करते हे सांगते.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// त्याच नोडसाठी तात्पुरते दुसरा, अपरिवर्तनीय संदर्भ घेते.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// कोणत्याही पानांचा किंवा अंतर्गत नोडचा पानांचा भाग उघड करते.
    ///
    /// या नोडवर अन्य संदर्भ अवैध करण्यास टाळण्यासाठी एक कच्चा पीटीआर परत करते.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // नोड कमीतकमी लीफनोड भागासाठी वैध असणे आवश्यक आहे.
        // हा नोडरेफ प्रकारात संदर्भ नाही कारण तो अद्वितीय आहे की सामायिक केला पाहिजे हे आम्हाला माहित नाही.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// वर्तमान नोडचे पालक शोधते.
    /// सध्याच्या नोडवर प्रत्यक्षात पालक असल्यास `Ok(handle)` मिळवते, जिथे वर्तमान नोडकडे निर्देशित केलेल्या पालकांच्या edge वर `handle` निर्देशित करते.
    ///
    /// मूळ नोडला मूळ `NodeRef` परत देऊन वर्तमान नोडला कोणतेही पालक नसल्यास X01 एक्स मिळवते.
    ///
    /// पद्धतीचे नाव गृहीत धरून आहे की शीर्षस्थानी रूट नोडसह आपली चित्रे आहेत.
    ///
    /// `edge.descend().ascend().unwrap()` आणि `node.ascend().unwrap().descend()` दोघांनाही यश मिळाल्यावर काहीही करु नये.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // आम्हाला नोड्ससाठी कच्चे पॉईंटर्स वापरण्याची आवश्यकता आहे कारण, जर बोर्नटाइप marker::ValMut असेल तर त्या मूल्यांचा उल्लेखनीय बदल होऊ शकेल ज्यास आपण अवैध करू नये.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// लक्षात घ्या की `self` निरर्थक असणे आवश्यक आहे.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// लक्षात घ्या की `self` निरर्थक असणे आवश्यक आहे.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// कोणत्याही पानांचा किंवा अंतर्गत नोडचा पानांचा एखादा भाग बदलू शकत नाही.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // सुरक्षितताः या झाडामध्ये कोणतेही बदललेले संदर्भ नाहीत जे `Immut` म्हणून घेतले आहेत.
        unsafe { &*ptr }
    }

    /// नोडमध्ये संचयित केलेल्या की मध्ये दृश्य घेते.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// `ascend` प्रमाणेच, नोडच्या मूळ नोडचा संदर्भ मिळतो, परंतु प्रक्रियेतील वर्तमान नोडची deallocates देखील करतो.
    /// हे असुरक्षित आहे कारण विद्यमान नोड विस्कळीत असूनही अद्याप प्रवेशयोग्य असेल.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// हे नोड एक `Leaf` आहे की स्थिर माहिती कम्पाइलरला असुरक्षितपणे सांगते.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// हे नोड एक `Internal` आहे की स्थिर माहिती कम्पाइलरला असुरक्षितपणे सांगते.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// त्याच नोडसाठी तात्पुरते दुसरा, परस्पर बदल घडवून आणतो.सावधगिरी बाळगा, ही पद्धत अत्यंत धोकादायक आहे कारण ती त्वरित धोकादायक दिसत नाही.
    ///
    /// बदलण्यायोग्य पॉईंटर्स झाडाच्या आजूबाजूला कोठेही फिरू शकतात, रिटर्न पॉइंटर मूळ पॉइंटर डेंग्लिंग, हद्दबाहेरील किंवा स्टॅक केलेल्या कर्जाच्या नियमांनुसार अवैध करण्यासाठी सहज वापरला जाऊ शकतो.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) या असुरक्षिततेस प्रतिबंधित करून, पुनर्बांधित बिंदूंवर नेव्हिगेशन पद्धतींचा वापर प्रतिबंधित करणारे `NodeRef` मध्ये आणखी एक प्रकार पॅरामीटर जोडण्याचा विचार करा.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// कोणत्याही पानाच्या किंवा अंतर्गत नोडच्या पानांच्या भागावर विशेष प्रवेश घेते.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // सुरक्षितता: आमच्याकडे संपूर्ण नोडमध्ये विशेष प्रवेश आहे.
        unsafe { &mut *ptr }
    }

    /// कोणत्याही पानाच्या किंवा अंतर्गत नोडच्या पानांच्या भागावर विशेष प्रवेश देते.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // सुरक्षितता: आमच्याकडे संपूर्ण नोडमध्ये विशेष प्रवेश आहे.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// की स्टोरेज क्षेत्राच्या एका घटकासाठी खास प्रवेश घेते.
    ///
    /// # Safety
    /// `index` 0. .CAPACITY च्या हद्दीत आहे
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // सुरक्षितता: कॉलर स्वत: वर पुढील पद्धती कॉल करू शकणार नाही
        // की स्लाईस संदर्भ सोडल्याशिवाय आमच्याकडे कर्जाच्या आजीव काळासाठी अनन्य प्रवेश आहे.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// नोडच्या मूल्य संचय क्षेत्राच्या एका घटकाकडे किंवा स्लाइसवर अनन्य प्रवेश घेते.
    ///
    /// # Safety
    /// `index` 0. .CAPACITY च्या हद्दीत आहे
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // सुरक्षितता: कॉलर स्वत: वर पुढील पद्धती कॉल करू शकणार नाही
        // जोपर्यंत व्हॅल्यू स्लाइस संदर्भ सोडला जात नाही, तोपर्यंत आमच्याकडे कर्जाच्या आयुष्यासाठी अनन्य प्रवेश आहे.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// झेडजेडजेडझेड सामग्रीसाठी नोडच्या स्टोरेज एलिमेन्टसाठी घटक किंवा स्लाइसवर अनन्य प्रवेश घेते.
    ///
    /// # Safety
    /// `index` 0. .Capacity + 1 च्या हद्दीत आहे
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // सुरक्षितता: कॉलर स्वत: वर पुढील पद्धती कॉल करू शकणार नाही
        // edge स्लाइस संदर्भ सोडल्याशिवाय आमच्याकडे कर्जाच्या आजीव काळासाठी अनन्य प्रवेश आहे.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - नोडमध्ये `idx` पेक्षा जास्त आरंभिक घटक आहेत.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // आम्ही इतर घटकांच्या थकबाकीदार संदर्भांसह अलियासिंग टाळण्यासाठी, ज्याला आम्ही आवडतो त्या एका घटकाचा संदर्भ केवळ तयार करतो, विशेषतः पूर्वीच्या पुनरावृत्तीमध्ये कॉलरकडे परत गेलेल्या.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // आम्ही Rust जारी केलेल्या #74679 मुळे आकार नसलेल्या अ‍ॅरे पॉईंटर्सवर दबाव आणणे आवश्यक आहे.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// नोडच्या लांबीपर्यंत अनन्य प्रवेश घेते.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// नोडला अन्य संदर्भ अवैध न करता, त्याच्या मूळ edge वर नोडचा दुवा सेट करते.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// मूळचा त्याचा मूळ edge चा दुवा साफ करतो.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// नोडच्या शेवटी की-व्हॅल्यू जोडी जोडते.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// `range` द्वारे परत केलेली प्रत्येक वस्तू नोडसाठी वैध edge अनुक्रमणिका आहे.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// की-व्हॅल्यू जोडी आणि नोडच्या शेवटी, त्या जोडीच्या उजवीकडे जाण्यासाठी एक edge जोडते.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// नोड हे `Internal` नोड किंवा `Leaf` नोड आहे किंवा नाही हे तपासते.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// नोडमधील विशिष्ट की-मूल्य जोडीचा किंवा edge चा संदर्भ.
/// `Node` पॅरामीटर `NodeRef` असणे आवश्यक आहे, तर `Type` एकतर `KV` (की-व्हॅल्यू जोडीवरील हँडल दर्शविणारा) किंवा `Edge` (edge वर हँडल दर्शविणारा) असू शकतो.
///
/// लक्षात घ्या की `Leaf` नोड्समध्ये देखील `Edge` हँडल असू शकतात.
/// चाइल्ड नोडवर पॉईंटरचे प्रतिनिधित्व करण्याऐवजी हे त्या जागेचे प्रतिनिधित्व करते जेथे चाईल्ड पॉईंटर की-व्हॅल्यू जोड्या दरम्यान जातात.
/// उदाहरणार्थ, लांबी 2 असलेल्या नोडमध्ये, 3 शक्य झेडगेडझेडझेड 3 ठिकाणे असतील, एक नोडच्या डावीकडे, दोन जोड्यांमधील एक आणि नोडच्या उजवीकडे असेल.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// आम्हाला `#[derive(Clone)]` च्या पूर्ण सामान्यतेची आवश्यकता नाही, कारण एक्सट 2 एक्स ही एकमेव वेळ असेल `क्लोनेबल जेव्हा तो अचल संदर्भ असेल आणि म्हणून एक्स 100 एक्स असेल.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// हे हँडल पॉईंट करते edge किंवा की-व्हॅल्यू जोडी असलेले नोड पुनर्प्राप्त करते.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// नोडमध्ये या हँडलची स्थिती मिळवते.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// `node` मधील की-मूल्य जोडीसाठी नवीन हँडल तयार करते.
    /// असुरक्षित आहे कारण कॉलरने हे सुनिश्चित केले पाहिजे की `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// आंशिकएकची सार्वजनिक अंमलबजावणी होऊ शकते, परंतु केवळ या मॉड्यूलमध्ये वापरली जाते.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// त्याच ठिकाणी दुसरे, अचल हँडल तात्पुरते बाहेर काढते.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // आम्ही Handle::new_kv किंवा Handle::new_edge वापरू शकत नाही कारण आम्हाला आपला प्रकार माहित नाही
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// हँडलचा नोड एक `Leaf` आहे की स्थिर माहिती कम्पाइलरला असुरक्षितपणे सांगते.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// त्याच ठिकाणी दुसरे, बदलण्यायोग्य हँडल तात्पुरते बाहेर काढते.
    /// सावधगिरी बाळगा, ही पद्धत अत्यंत धोकादायक आहे कारण ती त्वरित धोकादायक दिसत नाही.
    ///
    ///
    /// तपशीलांसाठी, `NodeRef::reborrow_mut` पहा.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // आम्ही Handle::new_kv किंवा Handle::new_edge वापरू शकत नाही कारण आम्हाला आपला प्रकार माहित नाही
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// `node` मध्ये edge वर नवीन हँडल तयार करते.
    /// असुरक्षित आहे कारण कॉलरने हे सुनिश्चित केले पाहिजे की `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// झेडजेडझेडझेड अनुक्रमणिका दिली जेथे आम्हाला क्षमतेने भरलेल्या नोडमध्ये समाविष्ट करायचे आहे, स्प्लिट पॉईंटच्या एक समझदार केव्ही इंडेक्सची गणना करते आणि अंतर्ग्रहण कोठे करावे.
///
/// स्प्लिट पॉईंटचे उद्दीष्ट हे त्याच्या की आणि व्हॅल्यूचे मूळ पालक नोडमध्ये समाप्त होण्याकरिता आहे;
/// स्प्लिट पॉईंटच्या डावीकडील की, मूल्ये आणि कडा डावे मूल होतात;
/// विभाजित बिंदूच्या उजवीकडील की, मूल्ये आणि कडा योग्य मूल बनतात.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust जारी करणे #74834 हे सममितीय नियम समजावून सांगण्याचा प्रयत्न करतो.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// या edge च्या उजवी-डावीकडील की-मूल्याच्या जोड्यांमधील एक नवीन की-मूल्य जोडी घाला.
    /// ही पद्धत असे गृहित करते की नवीन जोड्या फिट होण्यासाठी नोडमध्ये पुरेशी जागा आहे.
    ///
    /// परत केलेला पॉईंटर घातलेल्या मूल्याकडे निर्देश करतो.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// या edge च्या उजवी-डावीकडील की-मूल्याच्या जोड्यांमधील एक नवीन की-मूल्य जोडी घाला.
    /// पुरेशी जागा नसल्यास ही पद्धत नोडला विभाजित करते.
    ///
    /// परत केलेला पॉईंटर घातलेल्या मूल्याकडे निर्देश करतो.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// या edge चा दुवा साधलेल्या मुलाच्या नोडमधील मूळ पॉईंटर आणि अनुक्रमणिका निश्चित करते.
    /// जेव्हा काठाचे क्रम बदलले जातात तेव्हा हे उपयुक्त ठरते,
    fn correct_parent_link(self) {
        // नोडला इतर संदर्भ अवैध केल्याशिवाय बॅकपॉइन्टर तयार करा.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// एक नवीन की-मूल्य जोडी आणि एक edge समाविष्ट करते जे या edge आणि त्या edge च्या उजवीकडे की-मूल्य जोडी दरम्यान त्या नवीन जोडीच्या उजवीकडे जाईल.
    /// ही पद्धत असे गृहित करते की नवीन जोड्या फिट होण्यासाठी नोडमध्ये पुरेशी जागा आहे.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// एक नवीन की-मूल्य जोडी आणि एक edge समाविष्ट करते जे या edge आणि त्या edge च्या उजवीकडे की-मूल्य जोडी दरम्यान त्या नवीन जोडीच्या उजवीकडे जाईल.
    /// पुरेशी जागा नसल्यास ही पद्धत नोडला विभाजित करते.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// या edge च्या उजवी-डावीकडील की-मूल्याच्या जोड्यांमधील एक नवीन की-मूल्य जोडी घाला.
    /// पुरेशी जागा नसल्यास ही पद्धत नोडला विभाजित करते आणि मूळ गाठल्याशिवाय, पॅरंट नोडमध्ये स्प्लिट ऑफ भाग घालायचा प्रयत्न करते.
    ///
    ///
    /// परत केलेला निकाल `Fit` असल्यास, त्याच्या हँडलचा नोड हा झेडजेडझेड झेडचा नोड किंवा पूर्वज असू शकतो.
    /// परत केलेला निकाल `Split` असल्यास, `left` फील्ड मूळ नोड असेल.
    /// परत केलेला पॉईंटर घातलेल्या मूल्याकडे निर्देश करतो.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// या edge द्वारे दर्शविलेले नोड शोधते.
    ///
    /// पद्धतीचे नाव गृहीत धरून आहे की शीर्षस्थानी रूट नोडसह आपली चित्रे आहेत.
    ///
    /// `edge.descend().ascend().unwrap()` आणि `node.ascend().unwrap().descend()` दोघांनाही यश मिळाल्यावर काहीही करु नये.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // आम्हाला नोड्ससाठी कच्चे पॉईंटर्स वापरण्याची आवश्यकता आहे कारण, जर बोर्नटाइप marker::ValMut असेल तर त्या मूल्यांचा उल्लेखनीय बदल होऊ शकेल ज्यास आपण अवैध करू नये.
        // उंचीच्या क्षेत्रात प्रवेश करण्याची कोणतीही चिंता नाही कारण ते मूल्य कॉपी केले गेले आहे.
        // सावधगिरी बाळगा, एकदा नोड पॉईंटरचा संदर्भ घेतल्यानंतर आम्ही एका संदर्भात (Rust समस्या #73987) कडा अ‍ॅरेमध्ये प्रवेश करतो आणि अ‍ॅरेच्या आत किंवा इतर कोणतेही संदर्भ अवैध बनवितो.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // आम्ही स्वतंत्र की आणि मूल्य पद्धती कॉल करू शकत नाही कारण दुसर्‍याला कॉल केल्याने प्रथम परत केलेला संदर्भ अवैध ठरतो.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// केव्ही हँडल संदर्भित की आणि मूल्य पुनर्स्थित करा.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// लीफ डेटाची काळजी घेऊन एका विशिष्ट `NodeType` साठी `split` च्या अंमलबजावणीस मदत करते.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// मूळ नोडला तीन भागांमध्ये विभाजित करते:
    ///
    /// - या हँडलच्या डावीकडे फक्त की-मूल्य जोड्या जोडण्यासाठी नोड कापला जातो.
    /// - या हँडलद्वारे दर्शविलेले की आणि मूल्य काढले आहे.
    /// - या हँडलच्या उजवीकडे असलेल्या सर्व की-मूल्याच्या जोड्या नव्याने वाटप केलेल्या नोडमध्ये ठेवल्या आहेत.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// या हँडलद्वारे दर्शविलेली की-मूल्य जोडी काढून टाकते आणि की-मूल्य जोडी कोसळलेल्या edge सोबत ते परत करते.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// मूळ नोडला तीन भागांमध्ये विभाजित करते:
    ///
    /// - या हँडलच्या डावीकडे फक्त कडा आणि की-व्हॅल्यू जोड्या जोडण्यासाठी नोड कापला जातो.
    /// - या हँडलद्वारे दर्शविलेले की आणि मूल्य काढले आहे.
    /// - या हँडलच्या उजवीकडे सर्व कडा आणि की-मूल्याच्या जोड्या नव्याने वाटप केलेल्या नोडमध्ये ठेवल्या आहेत.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// अंतर्गत की-मूल्य जोडीच्या आसपास संतुलन ऑपरेशनचे मूल्यांकन आणि प्रदर्शन करण्यासाठी सत्राचे प्रतिनिधित्व करते.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// मूल म्हणून नोडशी संबंधित संतुलन संदर्भ निवडते, अशा प्रकारे केव्ही दरम्यान ताबडतोब डावीकडील किंवा पॅरेंट नोडमध्ये उजवीकडे.
    /// कोणतेही पालक नसल्यास `Err` मिळवते.
    /// पालक रिक्त असल्यास Panics.
    ///
    /// दिलेला नोड काही प्रमाणात खाली बसल्यास इष्टतम होण्यास डावीकडील प्राधान्य देते, याचा अर्थ असा आहे की येथे त्याच्या डाव्या भावंडापेक्षा कमी घटक आहेत आणि जर ते अस्तित्त्वात असतील तर उजवा भावंड त्यापेक्षा कमी आहे.
    /// अशा परिस्थितीत, डाव्या भावंडांसह विलीन होणे वेगवान आहे, कारण आपल्याला फक्त नोडचे एन घटक हलविले जाण्याऐवजी, त्यांना उजवीकडे हलविण्याऐवजी आणि एन घटकांपेक्षा अधिक हलविणे आवश्यक आहे.
    /// डाव्या भावंडातून चोरी करणे देखील सहसा वेगवान असते, कारण आपल्याला बहिणीच्या घटकापैकी कमीतकमी एन डावीकडे हलविण्याऐवजी फक्त नोडचे एन घटक उजवीकडे हलविणे आवश्यक आहे.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// विलीन करणे शक्य आहे की नाही ते मिळवते, म्हणजेच, दोन्ही केन्द्रीय केव्ही एकत्रित करण्यासाठी नोडमध्ये पुरेशी जागा आहे की नाही.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// विलीनीकरण करते आणि काय परत करावे हे एक बंद करू देते.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // सुरक्षितता: विलीन होणार्‍या नोड्सची उंची उंचीपेक्षा एक आहे
                // या edge च्या नोडचे, अशा प्रकारे शून्यापेक्षा वरचे आहेत, जेणेकरून ते अंतर्गत आहेत.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// पालकांची की-व्हॅल्यू जोडी आणि दोन्ही संबद्ध चाइल्ड नोड डाव्या मुलाच्या नोडमध्ये विलीन करते आणि संकुचित पालक नोड मिळवते.
    ///
    ///
    /// आम्ही `.can_merge()` जोपर्यंत Panics नाही.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// पालकांची की-व्हॅल्यू जोडी आणि दोन्ही जवळच्या चाइल्ड नोड्स डाव्या मुलाच्या नोडमध्ये विलीन करते आणि ते मूल नोड मिळवते.
    ///
    ///
    /// आम्ही `.can_merge()` जोपर्यंत Panics नाही.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// पालकांची की-व्हॅल्यू जोडी आणि दोन्ही जवळच्या मुलाच्या नोड्स डाव्या मुलाच्या नोडमध्ये विलीन करते आणि त्या मुलाच्या नोडमध्ये edge हँडल मिळवते जिथे ट्रॅक केलेला मूल edge संपला,
    ///
    ///
    /// आम्ही `.can_merge()` जोपर्यंत Panics नाही.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// जुन्या पालक की-मूल्य जोडीला उजव्या मुलामध्ये ढकलताना डाव्या मुलाकडून एक की-मूल्य जोडी काढते आणि त्यास पालकांच्या की-मूल्यामध्ये संचयित करते.
    ///
    /// `track_right_edge_idx` ने निर्दिष्ट केलेले मूळ edge समाप्त झाले त्याठिकाणी योग्य मुलाच्या edge वर हँडल मिळवते.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// जुन्या पालक की-मूल्य जोडीला डावीकडील बाजुला ढकलताना उजवीकडील मुलापासून एक की-मूल्य जोडी काढते आणि ते पालकांच्या की-व्हॅल्यू स्टोरेजमध्ये ठेवते.
    ///
    /// एक्स00 एक्सने निर्दिष्ट केलेल्या डाव्या मुलाच्या झेडजेडझेडझेडला हँडल मिळवते, जे हलले नाही.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// हे एक्स 100 एक्ससारखेच चोरी करते परंतु एकाच वेळी एकाधिक घटकांची चोरी करते.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // आम्ही सुरक्षितपणे चोरी करू शकतो याची खात्री करा.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // लीफ डेटा हलवा.
            {
                // योग्य मुलामध्ये चोरी झालेल्या घटकांसाठी जागा तयार करा.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // डाव्या मुलाकडून घटक एका उजवीकडे हलवा.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // डावीकडील सर्वात चोरलेली जोडी पालकांकडे हलवा.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // पालकांची की-मूल्य जोडी योग्य मुलाकडे हलवा.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // चोरीच्या काठासाठी जागा तयार करा.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // कडा चोरी करा.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// `bulk_steal_left` चे सममितीय क्लोन.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // आम्ही सुरक्षितपणे चोरी करू शकतो याची खात्री करा.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // लीफ डेटा हलवा.
            {
                // सर्वात चोरलेली जोडी पालकांकडे हलवा.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // पालकांची की-मूल्य जोडी डाव्या मुलाकडे हलवा.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // घटक उजव्या मुलापासून डावीकडे हलवा.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // चोरलेले घटक असायचे तेथे अंतर भरा.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // कडा चोरी करा.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // चोरीच्या कडा असायची तिथे अंतर भरा.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// हा नोड एक `Leaf` नोड असल्याचे सांगून कोणतीही स्थिर माहिती काढून टाकते.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// हा नोड एक `Internal` नोड असल्याचे सांगून कोणतीही स्थिर माहिती काढून टाकते.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// अंतर्निहित नोड एक `Internal` नोड किंवा `Leaf` नोड आहे की नाही ते तपासेल.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// `self` नंतर प्रत्यय एका नोडमधून दुसर्‍याकडे हलवा.`right` रिक्त असणे आवश्यक आहे.
    /// `right` चा पहिला edge अद्याप बदललेला नाही.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// अंतर्भूततेचा परिणाम, जेव्हा नोडला त्याच्या क्षमतेपेक्षा विस्तारित करणे आवश्यक असते.
pub struct SplitResult<'a, K, V, NodeType> {
    // `kv` च्या डावीकडील घटक आणि कडा असलेल्या विद्यमान वृक्षात नोड बदलले.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // इतर की अंतर्भूत करण्यासाठी काही की आणि मूल्य विभाजित होते.
    pub kv: (K, V),
    // एक्स 100 एक्स च्या उजवीकडे संबंधित घटक आणि कडा असलेले मालक, न जोडलेले, नवीन नोड.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // या उधार प्रकारच्या प्रकाराचे नोड संदर्भ वृक्षातील इतर नोड्सवर जाण्यासाठी परवानगी देतात की नाही.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // ट्रॅव्हर्शलची आवश्यकता नाही, हे `borrow_mut` चा परिणाम वापरुन घडते.
        // ट्रॅव्हर्सल अक्षम करून, आणि केवळ मुळांसाठी नवीन संदर्भ तयार करून, आम्हाला माहित आहे की `Owned` प्रकाराचा प्रत्येक संदर्भ मूळ नोडचा आहे.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// प्रारंभ न केलेल्या घटकांच्या तुकड्यात मूल्य समाविष्ट करते त्यानंतर एक निर्विवाद घटक.
///
/// # Safety
/// स्लाइसमध्ये `idx` पेक्षा जास्त घटक आहेत.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// एका ट्रेलिंग अनइन्टीटायझेशन घटकास मागे ठेवून, सर्व आरंभिक घटकांच्या स्लाइसमधून मूल्य काढून टाकते आणि मिळवते.
///
///
/// # Safety
/// स्लाइसमध्ये `idx` पेक्षा जास्त घटक आहेत.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// स्लाइस `distance` स्थितीतील घटक डावीकडे हलवा.
///
/// # Safety
/// स्लाइसमध्ये कमीतकमी `distance` घटक आहेत.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// स्लाइस `distance` स्थितीतील घटकांना उजवीकडे हलवा.
///
/// # Safety
/// स्लाइसमध्ये कमीतकमी `distance` घटक आहेत.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// सर्व मूल्ये आरंभिक घटकांच्या तुकड्यातून निर्विष्कृत घटकांच्या तुकड्यात हलवते, सर्व एक्सनिटलाइज्ड म्हणून `src` मागे ठेवते.
///
/// `dst.copy_from_slice(src)` प्रमाणे कार्य करते परंतु `T` `Copy` असणे आवश्यक नाही.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;