//! वाढणार्‍या रिंग बफरसह एक डबल-एंड रांग लागू केली.
//!
//! या रांगेत कंटेनरच्या दोन्ही टोकांमधून *ओ*(1) अमोराइज्ड इन्सर्ट आणि काढणे आहेत.
//! यात vector प्रमाणे अनुक्रमणिका *O*(1) देखील आहे.
//! समाविष्ट केलेले घटक कॉपी करण्यायोग्य असणे आवश्यक नाही आणि जर समाविष्ट केलेला प्रकार पाठविण्यायोग्य असेल तर रांग पाठविण्यायोग्य असेल.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // दोन सर्वात मोठी संभाव्य शक्ती

/// वाढणार्‍या रिंग बफरसह एक डबल-एंड रांग लागू केली.
///
/// या प्रकाराचा "default" रांगेचा वापर म्हणजे रांगेत जोडण्यासाठी [`push_back`] आणि रांगेतून काढण्यासाठी [`pop_front`] चा वापर करणे.
///
/// [`extend`] आणि [`append`] या मार्गाने पाठीवर ढकलते आणि `VecDeque` वर पुनरावृत्ती करणे समोरासमोर होते.
///
/// `VecDeque` हा रिंग बफर असल्याने, त्याचे घटक मेमरीमध्ये सुसंगत नसतात.
/// कार्यक्षम क्रमवारी लावण्यासारख्या घटकांप्रमाणे तुम्हाला एकच स्लाइस म्हणून प्रवेश करू इच्छित असाल तर तुम्ही एक्स00 एक्स वापरू शकता.
/// हे `VecDeque` फिरवते जेणेकरून त्याचे घटक लपेटू शकणार नाहीत आणि आता-घटकाच्या घटक अनुक्रमात एक बदलण्यायोग्य स्लाइस परत करतील.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // शेपटी आणि डोके बफरमध्ये पॉईंटर्स असतात.
    // शेपटी नेहमी वाचल्या जाणार्‍या पहिल्या घटकाकडे निर्देश करते, डोके नेहमी डेटा कोठे लिहावा हे दर्शवितो.
    //
    // शेपूट==डोके असल्यास बफर रिक्त आहे.रिंगबफरची लांबी दोन दरम्यानचे अंतर म्हणून परिभाषित केली जाते.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// स्लाइसमधील सर्व आयटम नष्ट होण्यापूर्वी (सामान्यपणे किंवा अनइंडिंग दरम्यान) विनाशक चालविते.
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // [T] साठी ड्रॉप वापरा
            ptr::drop_in_place(front);
        }
        // रॉवेक विकृत रूप हाताळते
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// रिक्त `VecDeque<T>` तयार करते.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// किरकोळ अधिक सोयीस्कर
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// किरकोळ अधिक सोयीस्कर
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // शून्य आकाराच्या प्रकारांसाठी, आम्ही नेहमीच अधिकतम क्षमतेवर असतो
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// पीटीआर एका स्लाइसमध्ये बदला
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// पीटीआरला म्युट स्लाइसमध्ये बदला
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// बफरमधून घटक हलवितो
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// बफरमध्ये एक घटक लिहितो, हलवत आहे.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// बफर पूर्ण क्षमतेवर असल्यास `true` मिळवते.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// दिलेल्या लॉजिकल एलिमेंट इंडेक्ससाठी अंतर्निहित बफरमध्ये अनुक्रमणिका मिळवते.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// दिलेल्या लॉजिकल एलिमेंट इंडेक्स + अ‍ॅडेंडेसाठी अंतर्निहित बफरमध्ये अनुक्रमणिका मिळवते.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// दिलेल्या लॉजिकल एलिमेंट इंडेक्स, सबट्राहेंडसाठी अंतर्निहित बफरमध्ये अनुक्रमणिका मिळवते.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// src पासून dst पर्यंत लांब मेमरी लेनचा संबद्ध ब्लॉक कॉपी करतो
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// src पासून dst पर्यंत लांब मेमरी लेनचा संबद्ध ब्लॉक कॉपी करतो
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// src पासून नशिबपर्यंत लांब मेमरी लेनचा संभाव्यतः लपेटणारा ब्लॉक कॉपी करतो.
    /// (abs(dst - src) + लेन) cap() पेक्षा मोठे नसावे (src आणि गतीच्या दरम्यान जास्तीत जास्त एक सतत आच्छादित प्रदेश असणे आवश्यक आहे).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src गुंडाळत नाही, डीएसटी लपेटत नाही
                //
                //        एस...
                // 1 एक्स 100 एक्स
                // 2 एक्स 100 एक्स डी.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // src च्या आधी dst, src गुंडाळत नाही, dst लपेटते
                //
                //
                //    एस...
                // 1 एक्स 100 एक्स
                // 2 एक्स 100 एक्स
                // 3 एक्स 100 एक्स .. डी.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // डीएसटीपूर्वी src, src लपेटत नाही, डीएसटी रॅप्स
                //
                //
                //              एस...
                // 1 एक्स 100 एक्स
                // 2 एक्स 100 एक्स
                // 3 एक्स 100 एक्स .. डी.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // z0src0Z करण्यापूर्वी dst, src लपेटणे, dst लपेटणे नाही
                //
                //
                //    .. एस.
                // 1 एक्स 100 एक्स
                // 2 एक्स 100 एक्स
                // 3 एक्स 100 एक्स डी...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // डीएसटीपूर्वी src, src लपेटते, डीएसटी लपेटत नाही
                //
                //
                //    .. एस.
                // 1 एक्स 100 एक्स
                // 2 एक्स 100 एक्स
                // 3 एक्स 100 एक्स डी...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // z0src0Z च्या आधी dst, src लपेटणे, dst लपेटणे
                //
                //
                //    ... एस.
                // 1 एक्स 100 एक्स
                // 2 एक्स 100 एक्स
                // 3 एक्स 100 एक्स
                // 4 एक्स 100 एक्स .. डी..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // डीएसटीपूर्वी src, src लपेटणे, डीएसटी लपेटणे
                //
                //
                //    .. एस..
                // 1 एक्स 100 एक्स
                // 2 एक्स 100 एक्स
                // 3 एक्स 100 एक्स
                // 4 [H A B D _ E F F G]... डी.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// आम्ही नुकत्याच पूर्ववत केले या वस्तुस्थितीस हाताळण्यासाठी डोके व शेपटीच्या भागाभोवती फ्रॉब्स.
    /// असुरक्षित आहे कारण ते जुन्या_ क्षमतावर विश्वास ठेवते.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // रिंग बफर टीएचचा सर्वात लहान संमिश्र विभाग हलवा
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] एचटी
        //   [o o . o o o o o ]
        //          THB [...ooooooo......
        //          ] एचटी
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // एक नाही
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// रिक्त `VecDeque` तयार करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// कमीतकमी `capacity` घटकांसाठी रिक्त `VecDeque` तयार करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1 कारण रिंगबफर नेहमीच एक जागा रिक्त ठेवते
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// दिलेल्या निर्देशांकातील घटकास संदर्भ प्रदान करते.
    ///
    /// अनुक्रमणिका 0 मधील घटक रांगेचा पुढील भाग आहे.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// दिलेल्या निर्देशांकावरील घटकाला बदलता संदर्भ प्रदान करते.
    ///
    /// अनुक्रमणिका 0 मधील घटक रांगेचा पुढील भाग आहे.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// निर्देशांक `i` आणि `j` वर घटक स्वॅप करते.
    ///
    /// `i` आणि `j` समान असू शकतात.
    ///
    /// अनुक्रमणिका 0 मधील घटक रांगेचा पुढील भाग आहे.
    ///
    /// # Panics
    ///
    /// जर एकतर निर्देशांक मर्यादेत नसेल तर Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// रीलोकॉट केल्याशिवाय `VecDeque` धारण करू शकणार्‍या घटकांची संख्या मिळवते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// दिलेल्या `VecDeque` मध्ये अचूक `additional` अधिक घटक समाविष्ट करण्यासाठी किमान क्षमता राखून ठेवते.
    /// क्षमता आधीच पुरेशी असल्यास काहीही करत नाही.
    ///
    /// लक्षात ठेवा की वाटपकर्ता विनंत्यापेक्षा अधिक संग्रह देऊ शकेल.
    /// म्हणून क्षमतेवर अगदी कमीतकमी असावे यावर अवलंबून राहू शकत नाही.
    /// झेडफ्यूचर 0 झेडच्या आशेची अपेक्षा असल्यास [`reserve`] ला प्राधान्य द्या.
    ///
    /// # Panics
    ///
    /// नवीन क्षमता `usize` ओव्हरफ्लो झाल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// दिलेल्या `VecDeque` मध्ये कमीतकमी `additional` अधिक घटक समाविष्ट करण्यासाठी क्षमता राखीव आहे.
    /// वारंवार पुनर्विक्री टाळण्यासाठी संकलनात अधिक जागा राखीव असू शकते.
    ///
    /// # Panics
    ///
    /// नवीन क्षमता `usize` ओव्हरफ्लो झाल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// दिलेल्या `VecDeque<T>` मध्ये अचूक `additional` अधिक घटक समाविष्ट करण्यासाठी किमान क्षमता राखण्याचा प्रयत्न करतो.
    ///
    /// `try_reserve_exact` वर कॉल केल्यानंतर, क्षमता `self.len() + additional` पेक्षा मोठी किंवा समान असेल.
    /// क्षमता आधीच पुरेशी असल्यास काहीही करत नाही.
    ///
    /// लक्षात ठेवा की वाटपकर्ता विनंत्यापेक्षा अधिक संग्रह देऊ शकेल.
    /// म्हणूनच क्षमतेवर तंतोतंत किमान असणे अवलंबून नाही.
    /// झेडफ्यूचर 0 झेडच्या आशेची अपेक्षा असल्यास `reserve` ला प्राधान्य द्या.
    ///
    /// # Errors
    ///
    /// क्षमता ओव्हरफ्लो `usize`, किंवा वितरकाने अपयशाची नोंद केली तर त्रुटी परत केली जाते.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // मेमरी प्री-रिझर्व करा, शक्य नसल्यास बाहेर पडा
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // आता आम्हाला माहित आहे की आमच्या जटिल कार्याच्या मध्यभागी हे OOM(Out-Of-Memory) करू शकत नाही
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // खूप क्लिष्ट
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// दिलेल्या `VecDeque<T>` मध्ये कमीतकमी `additional` अधिक घटक समाविष्ट करण्यासाठी क्षमता राखून ठेवण्याचा प्रयत्न करतो.
    /// वारंवार पुनर्विक्री टाळण्यासाठी संकलनात अधिक जागा राखीव असू शकते.
    /// `try_reserve` वर कॉल केल्यानंतर, क्षमता `self.len() + additional` पेक्षा मोठी किंवा समान असेल.
    /// क्षमता आधीच पुरेशी असल्यास काहीही करत नाही.
    ///
    /// # Errors
    ///
    /// क्षमता ओव्हरफ्लो `usize`, किंवा वितरकाने अपयशाची नोंद केली तर त्रुटी परत केली जाते.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // मेमरी प्री-रिझर्व करा, शक्य नसल्यास बाहेर पडा
    ///     output.try_reserve(data.len())?;
    ///
    ///     // आता आम्हाला माहित आहे की आमच्या जटिल कार्याच्या मध्यभागी हे OOM करू शकत नाही
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // खूप क्लिष्ट
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// शक्य तितक्या `VecDeque` ची क्षमता कमी करते.
    ///
    /// हे शक्य तितक्या कमी लांबीच्या खाली खाली जाईल परंतु आणखी काही घटकांसाठी जागा असल्याचे वितरक अद्याप `VecDeque` ला सांगू शकेल.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// कमी बाउंडसह `VecDeque` ची क्षमता कमी करते.
    ///
    /// लांबी आणि पुरवठा केलेले मूल्य यापेक्षा कमीतकमी क्षमता राहील.
    ///
    ///
    /// जर सद्य क्षमता कमी मर्यादेपेक्षा कमी असेल तर ही एक निवड नाही.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // आम्हाला ओव्हरफ्लोबद्दल चिंता करण्याची आवश्यकता नाही कारण `self.len()` किंवा `self.capacity()` कधीही `usize::MAX` असू शकत नाही.
        // रिंग बफर म्हणून एक जागा नेहमी रिक्त ठेवते म्हणून +1.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // व्याज तीन प्रकरणे आहेत:
            //   सर्व घटक इच्छित मर्यादेबाहेर असतात घटक सुसंगत असतात आणि डोके इच्छित सीमांच्या बाहेर असतात घटक विसंगत असतात आणि शेपटी इच्छित सीमांच्या बाहेर असतात.
            //
            //
            // इतर सर्व वेळी, घटकांची स्थिती अप्रभावित असते.
            //
            // हे दर्शविते की डोक्यावर असलेले घटक हलले पाहिजेत.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // घटकांना इच्छित सीमेवरून हलवा (लक्ष्य_कॅप नंतरची स्थिती)
            if self.tail >= target_cap && head_outside {
                // त्या
                //   [. . . . . . . . o o o o o o o . ]
                //    त्या
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // त्या
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // एचटी
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// प्रथम `len` घटक ठेवून आणि बाकीचे सोडत, `VecDeque` लहान करते.
    ///
    ///
    /// जर `len` `VecDeque` च्या वर्तमान लांबीपेक्षा मोठे असेल तर याचा कोणताही परिणाम होणार नाही.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// स्लाइसमधील सर्व आयटम नष्ट होण्यापूर्वी (सामान्यपणे किंवा अनइंडिंग दरम्यान) विनाशक चालविते.
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // सुरक्षित कारण:
        //
        // * `drop_in_place` ला दिलेली कोणतीही स्लाइस वैध आहे;दुसर्‍या प्रकरणात `len <= front.len()` आहे आणि `len > self.len()` वर परत येणे पहिल्या प्रकरणात `begin <= back.len()` सुनिश्चित करते
        //
        // * `drop_in_place` वर कॉल करण्यापूर्वी वेकडिकचे डोके हलविले जाते, म्हणून `drop_in_place` panics असल्यास कोणतेही मूल्य दोनदा सोडले जात नाही
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // पहिल्या अर्ध्या झेडस्पॅनिक्स 0 झेडमध्ये डिस्ट्रक्टर असतानाही दुसरा अर्धा भाग सोडल्याची खात्री करा.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// एका समोरासमोर परत इटरेटर परत मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// एका फ्रंट-टू-बॅक इटरेटरला परत करते जे परिवर्तनीय संदर्भ परत करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // सुरक्षितता: अंतर्गत `IterMut` सुरक्षा इन्व्हिएरंट स्थापित केला आहे कारण
        // `ring` आम्ही आजीवन 'डीरेफरेन्सेबल स्लाईस' तयार करतो.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// `VecDeque` च्या सामग्रीनुसार क्रमाने जोडलेल्या जोड्यांचा परत मिळवते.
    ///
    /// यापूर्वी [`make_contiguous`] ला कॉल केले असल्यास, `VecDeque` चे सर्व घटक पहिल्या स्लाइसमध्ये असतील आणि दुसरी स्लाइस रिक्त असेल.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// `VecDeque` च्या सामग्रीनुसार क्रमाने जोडलेल्या जोड्यांचा परत मिळवते.
    ///
    /// यापूर्वी [`make_contiguous`] ला कॉल केले असल्यास, `VecDeque` चे सर्व घटक पहिल्या स्लाइसमध्ये असतील आणि दुसरी स्लाइस रिक्त असेल.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// `VecDeque` मधील घटकांची संख्या मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// `VecDeque` रिक्त असल्यास `true` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// एक्सट्रॅक्समध्ये निर्दिष्ट श्रेणी व्यापणार्‍या इटरेटर तयार करते.
    ///
    /// # Panics
    ///
    /// प्रारंभ बिंदू शेवटच्या बिंदूपेक्षा मोठा असल्यास किंवा शेवटचा बिंदू vector च्या लांबीपेक्षा मोठा असल्यास Panics.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // संपूर्ण श्रेणीमध्ये सर्व सामग्री समाविष्ट आहेत
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // आमच्याकडे &self मध्ये असलेला सामायिक संदर्भ '_च्या' _मध्ये ठेवला जातो.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// एक्सट्रॅक्समध्ये निर्दिष्ट परिवर्तनीय श्रेणी कव्हर करणारा इटरेटर तयार करते.
    ///
    /// # Panics
    ///
    /// प्रारंभ बिंदू शेवटच्या बिंदूपेक्षा मोठा असल्यास किंवा शेवटचा बिंदू vector च्या लांबीपेक्षा मोठा असल्यास Panics.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // संपूर्ण श्रेणीमध्ये सर्व सामग्री समाविष्ट आहेत
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // सुरक्षितता: अंतर्गत `IterMut` सुरक्षा इन्व्हिएरंट स्थापित केला आहे कारण
        // `ring` आम्ही आजीवन 'डीरेफरेन्सेबल स्लाईस' तयार करतो.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// एक्सएमएक्सएक्समधील निर्दिष्ट श्रेणी काढून टाकलेल्या आयटमचे उत्पादन करणारे एक ड्रॉइंग इटरटर तयार करते.
    ///
    /// टीप 1: इरेटर शेवटपर्यंत सेवन न केल्यास देखील घटक श्रेणी काढली जाते.
    ///
    /// टीप 2: एक्स 100 एक्स मूल्य सोडले नाही तर डुकमधून किती घटक काढले गेले हे अनिश्चित आहे, परंतु त्याद्वारे घेतलेले कर्ज कालबाह्य होते (उदा. एक्स ०१ एक्समुळे).
    ///
    ///
    /// # Panics
    ///
    /// प्रारंभ बिंदू शेवटच्या बिंदूपेक्षा मोठा असल्यास किंवा शेवटचा बिंदू vector च्या लांबीपेक्षा मोठा असल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // संपूर्ण श्रेणी सर्व सामग्री साफ करते
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // मेमरी सुरक्षा
        //
        // जेव्हा झेडड्रेन0 झेड प्रथम तयार केला जातो तेव्हा झेडड्रेन0 झेडचा विध्वंसक कधीही चालत नसाल तर निर्विवाद किंवा हलविलेले घटक कोणत्याही वेळी प्रवेशयोग्य नसतात हे सुनिश्चित करण्यासाठी स्त्रोत अर्धवट लहान केला जातो.
        //
        //
        // Drain काढण्यासाठी मूल्ये ptr::read काढेल.
        // पूर्ण झाल्यावर, उर्वरित डेटा भोक झाकण्यासाठी परत कॉपी केला जाईल आणि head/tail मूल्ये योग्यरित्या पुनर्संचयित केली जातील.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // डेकचे घटक तीन विभागांमध्ये विभागले गेले आहेत:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // टी=एक्स 100 एक्स;हरभजन=X01 एक्स;t=drain_tail;h=drain_head
        //
        // आम्ही drain_tail self.head म्हणून आणि drain_head आणि self.head अनुक्रमे Z_Drain0Z वर after_tail आणि after_head म्हणून संचयित करतो.
        // हे प्रभावी अ‍ॅरे देखील छाटते जे झेडड्रेन 0 झेड लीक झाल्यास आम्ही झेडड्रेन 0 झेड सुरू झाल्यानंतर संभाव्य स्थलांतरित मूल्यांबद्दल विसरलो आहोत.
        //
        //
        //        टी व्या एच
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" drain सुरू झाल्यानंतर आणि Drain विध्वंसक चालू होईपर्यंत मूल्ये बद्दल.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // निर्णायकपणे, आम्ही केवळ येथे `self` कडील सामायिक संदर्भ तयार करतो आणि त्यातून वाचतो.
                // आम्ही `self` ला लिहित नाही किंवा परिवर्तनीय संदर्भावर पुन्हा विचार करत नाही.
                // म्हणून आम्ही `deque` साठी वरील तयार केलेले कच्चे सूचक वैध राहिले.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// सर्व मूल्ये काढून `VecDeque` साफ करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// जर एक्स 0 एक्स मध्ये दिलेल्या मूल्याच्या बरोबरीचा एखादा घटक असेल तर तो एक्स 100 एक्स मिळवते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// समोरच्या घटकाचा संदर्भ प्रदान करते किंवा X01 एक्स रिक्त असल्यास `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// फ्रंट एलिमेंटला, किंवा `None` एक्स रिक्त असल्यास एक्स00 एक्सला बदलता संदर्भ प्रदान करते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// मागील घटकाचा संदर्भ प्रदान करा किंवा X01 एक्स रिक्त असल्यास `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// बॅक एलिमेंटला बदलू संदर्भ प्रदान करा किंवा X01 एक्स रिक्त असल्यास `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// प्रथम घटक काढून तो परत मिळवितो किंवा X01 एक्स रिक्त असल्यास `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// `VecDeque` वरुन शेवटचा घटक काढून टाकते आणि ते रिक्त असल्यास किंवा `None` परत करते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// `VecDeque` वर घटक तयार करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// `VecDeque` च्या मागील भागावर एक घटक जोडा.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: आम्ही `head == 0` चा अर्थ विचारला पाहिजे का?
        // की `self` सुसंगत आहे?
        self.tail <= self.head
    }

    /// `VecDeque` मधील कोठूनही एखादा घटक काढून टाकते आणि प्रथम घटकासह त्यास परत आणते.
    ///
    ///
    /// हे ऑर्डरिंगचे जतन करीत नाही, परंतु *ओ*(1) आहे.
    ///
    /// `index` ची मर्यादा न संपल्यास `None` मिळवते.
    ///
    /// अनुक्रमणिका 0 मधील घटक रांगेचा पुढील भाग आहे.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// `VecDeque` मधील कोठूनही एखादा घटक काढतो आणि शेवटच्या घटकासह त्यास परत मिळवितो.
    ///
    ///
    /// हे ऑर्डरिंगचे जतन करीत नाही, परंतु *ओ*(1) आहे.
    ///
    /// `index` ची मर्यादा न संपल्यास `None` मिळवते.
    ///
    /// अनुक्रमणिका 0 मधील घटक रांगेचा पुढील भाग आहे.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// `VecDeque` मध्ये `index` वर घटक समाविष्ट करते, `index` पेक्षा मोठे किंवा समान चे निर्देशांक असलेले सर्व घटक मागील बाजूस सरकवते.
    ///
    ///
    /// अनुक्रमणिका 0 मधील घटक रांगेचा पुढील भाग आहे.
    ///
    /// # Panics
    ///
    /// जर `index` `VecDeque` च्या लांबीपेक्षा मोठे असेल तर Panics
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // रिंग बफरमध्ये घटकांची किमान संख्या हलवा आणि दिलेला ऑब्जेक्ट घाला
        //
        // कमाल len/2 वर, 1 घटक हलविले जातील. O(min(n, n-i))
        //
        // तीन मुख्य प्रकरणे आहेतः
        //  घटक निरंतर असतात
        //      - विशेष केस जेव्हा शेपटी 0 असते तेव्हा घटक विस्कळीत असतात आणि घाला शेपटीच्या विभागात असतात घटक विसंगत असतात आणि घाला डोके विभागात असतो
        //
        //
        // त्या प्रत्येकासाठी आणखी दोन प्रकरणे आहेतः
        //  घाला शेपटीच्या जवळ आहे घाला घाला डोके जवळ आहे
        //
        // की: एच, एक्स00 एक्स
        //      टी, एक्स 100 एक्स ओ, वैध घटक मी, अंतर्भूत घटक ए, घटक जो निर्देशांक एम नंतर असावा, दर्शविणारा घटक हलविला गेला
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       टीआयएच
                //      [ए oooooo......
                //      .
                //      .]
                //
                //                       एचटी
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // संमिश्र, शेपटीच्या जवळ घाला:
                    //
                    //             टीआयएच
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           त्या
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // संमिश्र, शेपटी आणि शेपटीच्या जवळ घाला 0:
                    //
                    //
                    //       टीआयएच
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       एचटी
                    //      [o I A o o o o o . . . . . . . o]
                    //       एम.एम.

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // आधीपासूनच शेपटी हलविली आहे, म्हणून आम्ही केवळ `index - 1` घटक कॉपी करतो.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // सतत, डोके जवळ घाला:
                    //
                    //             टीआयएच
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             त्या
                    //      [. . . o o o o I A o o . . . . .]
                    //                       एमएमएम

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // असंगत, शेपटीच्या जवळ घाला, शेपटी विभाग:
                    //
                    //                   एचटीआय
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   एचटी
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // असंगत, डोके जवळ शेपटी घाला, शेपटी विभाग:
                    //
                    //           एचटीआय
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             एचटी
                    //      [o o o . . . . . . o o o o o I A]
                    //       एमएमएमएम

                    // नवीन डोके पर्यंत घटक कॉपी करा
                    self.copy(1, 0, self.head);

                    // बफरच्या तळाशी असलेल्या रिक्त जागेवर शेवटच्या घटकाची कॉपी करा
                    self.copy(0, self.cap() - 1, 1);

                    // आयडीएक्स वरुन घटकांना end घटक समाविष्ट न करता पुढे सरकवा
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // असंगत, घाला शेपटीच्या जवळ, डोके भागाच्या अगदी जवळ आहे आणि अंतर्गत बफरमध्ये निर्देशांक शून्यावर आहे:
                    //
                    //
                    //       आयएचटी
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           एचटी
                    //      [A o o o o o o o o o . . o o o I]
                    //                               एमएमएम

                    // नवीन शेपटी पर्यंत घटक कॉपी करा
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // बफरच्या तळाशी असलेल्या रिक्त जागेवर शेवटच्या घटकाची कॉपी करा
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // असंगत, शेपटीच्या जवळ घाला, डोके विभाग:
                    //
                    //             आयएचटी
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           एचटी
                    //      [o o I A o o o o o o . . o o o o]
                    //       एमएमएमएमएमएम

                    // नवीन शेपटी पर्यंत घटक कॉपी करा
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // बफरच्या तळाशी असलेल्या रिक्त जागेवर शेवटच्या घटकाची कॉपी करा
                    self.copy(self.cap() - 1, 0, 1);

                    // idx-1 मधील घटकांना including घटकासह समाविष्ट न करता पुढे सरकवा
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // असंगत, डोके जवळ डोके घाला, डोके विभाग:
                    //
                    //               आयएचटी
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     एचटी
                    //      [o o o o I A o o . . . . . o o o]
                    //                 एमएमएम

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // शेपटी बदलली असावी म्हणून आम्हाला पुन्हा गणना करणे आवश्यक आहे
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// `VecDeque` वरून `index` वरील घटक काढते आणि मिळवते.
    /// ज्याचा शेवट काढण्याच्या बिंदूच्या अगदी जवळ आहे तो खोली तयार करण्यासाठी हलविला जाईल आणि सर्व प्रभावित घटक नवीन स्थानांवर हलविले जातील.
    ///
    /// `index` ची मर्यादा न संपल्यास `None` मिळवते.
    ///
    /// अनुक्रमणिका 0 मधील घटक रांगेचा पुढील भाग आहे.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // तीन मुख्य प्रकरणे आहेतः
        //  घटक सुसंगत असतात घटक विसंगत असतात आणि काढणे शेपटी विभागात असतात घटक विसंगत असतात आणि ते काढणे डोके विभागात असतात.
        //
        //      - घटक जेव्हा तांत्रिकदृष्ट्या संमिश्र असतात परंतु एक्स 100 एक्स=0 असतात तेव्हा विशेष
        //
        // त्या प्रत्येकासाठी आणखी दोन प्रकरणे आहेतः
        //  घाला शेपटीच्या जवळ आहे घाला घाला डोके जवळ आहे
        //
        // की: एच, एक्स00 एक्स
        //      टी, एक्स 100 एक्स ओ, वैध घटक x, घटक काढण्यासाठी आर चिन्हांकित केले, काढले जात असलेले घटक दर्शवते एम, घटक हलविला गेला असल्याचे दर्शवते
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // संमिश्र, शेपटीच्या जवळ काढा:
                    //
                    //             टीआरएच
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               त्या
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // सतत, डोके जवळ काढा:
                    //
                    //             टीआरएच
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             त्या
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // असंगत, शेपटीच्या जवळ, शेपटी विभाग काढा:
                    //
                    //                   एचटीआर
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   एचटी
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // असंगत, डोके, डोके विभाग जवळ काढा:
                    //
                    //               आरएचटी
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   एचटी
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // असंगत, डोके जवळ, शेपटी विभाग काढा:
                    //
                    //             एचटीआर
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           एचटी
                    //      [o o . . . . . . . o o o o o o o]
                    //       एमएमएमएम
                    //
                    // किंवा अर्ध-असंगत, डोके पुढे, शेपटी विभाग काढा:
                    //
                    //       एचटीआर
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         त्या
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // शेपूट विभागात घटक काढा
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // अंडरफ्लो प्रतिबंधित करते.
                    if self.head != 0 {
                        // रिकाम्या जागेवर प्रथम घटकाची प्रत बनवा
                        self.copy(self.cap() - 1, 0, 1);

                        // डोके विभागातील घटक मागे हलवा
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // असंगत, शेपटीच्या जवळ, डोके विभाग काढा:
                    //
                    //           आरएचटी
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           एचटी
                    //      [o o o o o o o o o o . . . . o o]
                    //       एमएमएमएमएम

                    // आयडीएक्स पर्यंत घटक काढा
                    self.copy(1, 0, idx);

                    // रिकाम्या जागेवर शेवटच्या घटकाची कॉपी करा
                    self.copy(0, self.cap() - 1, 1);

                    // शेवटचे वगळता घटकांना शेपटीपासून पुढे सरकवा
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// दिलेल्या निर्देशांकात `VecDeque` दोन मध्ये विभाजित करते.
    ///
    /// नवीन वाटप केलेले `VecDeque` मिळवते.
    /// `self` `[0, at)` घटक आहेत आणि परत केलेल्या `VecDeque` मध्ये एक्स 100 एक्स आहेत.
    ///
    /// लक्षात घ्या की `self` ची क्षमता बदलत नाही.
    ///
    /// अनुक्रमणिका 0 मधील घटक रांगेचा पुढील भाग आहे.
    ///
    /// # Panics
    ///
    /// `at > len` असल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` पहिल्या सहामाहीत आहे.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // फक्त अर्ध्या भागातील सर्व घ्या.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` दुस half्या सहामाहीत आहे, आम्ही पहिल्या सहामाहीत वगळले घटक घटक आवश्यक आहे.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // जिथे बफरचे टोक आहेत तिथे स्वच्छता
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// `other` चे सर्व घटक `self` मध्ये हलविते, `other` रिक्त ठेवतात.
    ///
    /// # Panics
    ///
    /// जर स्वत: मधील घटकांची नवीन संख्या `usize` ओव्हरफ्लो करते तर Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // भोळसटपणा
        self.extend(other.drain(..));
    }

    /// केवळ पूर्वानुमानाने निर्दिष्ट केलेले घटक राखून ठेवतात.
    ///
    /// दुसर्‍या शब्दांत,`e` सर्व घटक खोटे परत आणा जे X0X खोटे परत करतात.
    /// ही पद्धत त्या ठिकाणी कार्य करते, प्रत्येक घटकास एकदाच मूळ क्रमाने भेट देते आणि कायम ठेवलेल्या घटकांचा क्रम जतन करते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// निर्देशांकप्रमाणे बाह्य स्थितीचा मागोवा घेण्यासाठी अचूक ऑर्डर उपयुक्त ठरू शकते.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // हे panic किंवा निरस्त होऊ शकते
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // बफरचा आकार दुप्पट करा.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// `VecDeque` चे जागेचे ठिकाण बदलते जेणेकरुन `len()` `new_len` च्या समतुल्य असेल, एकतर मागील भागांमधून जास्तीचे घटक काढून टाकून किंवा `generator` वर परत कॉल करून व्युत्पन्न घटकांना एकत्र करून.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// या डुकराच्या अंतर्गत संचयनाचे पुनर्रचना करते जेणेकरून तो एक छोटासा तुकडा आहे जो परत केला जातो.
    ///
    /// ही पद्धत वाटप करत नाही आणि घातलेल्या घटकांची क्रमवारी बदलत नाही.हे बदलण्यायोग्य स्लाइस परत केल्यामुळे, हे एखाद्या डुकला क्रमवारी लावण्यासाठी वापरले जाऊ शकते.
    ///
    /// एकदा अंतर्गत स्टोरेज सुसंगत झाल्यावर, एक्स 100 एक्स आणि एक्स 0 एक्स एक्स पद्धती `VecDeque` ची संपूर्ण सामग्री एकाच स्लाइसमध्ये परत करेल.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// एखाद्या देवळातील सामग्रीची क्रमवारी लावत आहे.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // डुकला क्रमवारी लावत आहे
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // त्यास उलट क्रमाने क्रमवारी लावत आहे
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// सततच्या तुकड्यात अविचल प्रवेश मिळवित आहे.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // आम्ही आता हे सुनिश्चित करू शकतो की X01 एक्समध्ये डुकचे सर्व घटक आहेत, तरीही एक्स00 एक्समध्ये अविचल प्रवेश आहे.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // एकाच वेळी शेपटीची कॉपी करण्यासाठी पुरेशी मोकळी जागा आहे, याचा अर्थ असा आहे की आपण प्रथम डोके मागे सरकवा आणि नंतर शेपटीला योग्य ठिकाणी कॉपी करू.
            //
            //
            // प्रेषक: DEFGH .... एबीसी
            // प्रति: एबीसीडीईएफजीएच ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: आम्ही सध्या विचारात घेत नाही .... एबीसीडीईएफजीएच
            // सुसंगत असणे कारण या प्रकरणात `head` हे X01 एक्स असेल.
            // आम्ही कदाचित हे बदलू इच्छित असताना हे क्षुल्लक नाही कारण काही ठिकाणी `is_contiguous` चा अर्थ असा आहे की आम्ही फक्त `buf[tail..head]` चा वापर करुन तुकडा बनवू शकतो.
            //
            //

            // एकाच वेळी डोके कॉपी करण्यासाठी पुरेशी मोकळी जागा आहे, याचा अर्थ असा आहे की आपण प्रथम शेपटी पुढे सरकवतो आणि नंतर डोके योग्य ठिकाणी कॉपी करतो.
            //
            //
            // प्रेषकः एफजीएच .... एबीसीडीई
            // प्रति: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // फ्री हे डोके आणि शेपूट या दोन्हीपेक्षा लहान आहे, याचा अर्थ आपल्यास हळू हळू शेपटी आणि डोके "swap" करावे लागेल.
            //
            //
            // कडून: EFGHI ... ABCD किंवा HIJK.ABCDEFG
            // प्रति: एबीसीडीएफएफजीआय ... किंवा एबीसीडीएफएफजीएचके
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // सामान्य समस्या या GHIJKLM सारखी दिसते आहे ... एबीसीडीएफ, कोणत्याही स्वॅप करण्यापूर्वी एबीसीडीएफएम ... जीएचजीकेएल, अॅप्सच्या 1 पास नंतर एबीसीडीएफजीजीएम ... केएल, डावीकडे झेडजेडजेड झेड टेम्प स्टोअरपर्यंत पोहोचेपर्यंत स्वॅप
                //                  - नंतर नवीन (smaller) स्टोअरसह अल्गोरिदम पुन्हा सुरु करा कधीकधी योग्य edge जेव्हा बफरच्या शेवटी असते तेव्हा तात्पुरते स्टोअर पोहोचते, याचा अर्थ असा आहे की आम्ही कमी स्वॅप्ससह योग्य क्रमाने दाबा!
                //
                // E.g
                // EF..ABCD ABCDEF .., केवळ चार स्वॅप्सनंतर आम्ही समाप्त केले
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// डावीकडे दुहेरी-समाप्त रांग `mid` ठिकाणे फिरवते.
    ///
    /// Equivalently,
    /// - आयटम `mid` प्रथम स्थानावर फिरवते.
    /// - प्रथम `mid` आयटम पॉप करते आणि त्यास शेवटपर्यंत खेचते.
    /// - `len() - mid` ठिकाणे उजवीकडे फिरवते.
    ///
    /// # Panics
    ///
    /// `mid` हे `len()` पेक्षा मोठे असल्यास.
    /// लक्षात घ्या की `mid == len()` _not_ panic करते आणि नाही-रोटेशन आहे.
    ///
    /// # Complexity
    ///
    /// `*O*(min(mid, len() - mid))` वेळ आणि अतिरिक्त जागा नाही.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// दुहेरी-समाप्त रांग `k` ठिकाणे उजवीकडे फिरवते.
    ///
    /// Equivalently,
    /// - प्रथम आयटम `k` स्थितीत फिरवते.
    /// - शेवटच्या `k` आयटम पॉप करतो आणि त्यास पुढच्या बाजूला धकेल.
    /// - डावीकडे `len() - k` ठिकाणे फिरविते.
    ///
    /// # Panics
    ///
    /// `k` हे `len()` पेक्षा मोठे असल्यास.
    /// लक्षात घ्या की `k == len()` _not_ panic करते आणि नाही-रोटेशन आहे.
    ///
    /// # Complexity
    ///
    /// `*O*(min(k, len() - k))` वेळ आणि अतिरिक्त जागा नाही.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // सुरक्षा: खालील दोन पद्धतींसाठी रोटेशनची रक्कम आवश्यक आहे
    // अर्ध्यापेक्षा अर्धा पेक्षा कमी लांबीचा असावा.
    //
    // `wrap_copy` त्यास `min(x, cap() - x) + copy_len <= cap()` आवश्यक आहे, परंतु एक्स 0 ए एक्सपेक्षा कमी क्षणापेक्षा अर्ध्या क्षमतेपेक्षा जास्त कधीही नाही, म्हणून येथे कॉल करणे योग्य आहे कारण आम्ही अर्ध्यापेक्षा कमी लांबीसह काहीतरी बोलत आहोत, जे कधीही अर्ध्या क्षमतेपेक्षा जास्त नसते.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// बायनरी दिलेल्या घटकासाठी हे क्रमवारी लावलेले `VecDeque` शोधते.
    ///
    /// मूल्य आढळल्यास जुळणार्‍या घटकाची अनुक्रमणिका असलेली [`Result::Ok`] परत केली जाईल.
    /// जर तेथे अनेक सामने असतील तर सामन्यांपैकी कोणताही एक परत केला जाऊ शकेल.
    /// जर व्हॅल्यू सापडला नाही तर क्रमवारी लावताना एक जुळणारा घटक घातला जाऊ शकेल अशी अनुक्रमणिका असलेली एक्स 100 एक्स परत केली जाईल.
    ///
    ///
    /// # Examples
    ///
    /// चार घटकांची मालिका दिसते.
    /// प्रथम आढळतो, एक अद्वितीयपणे निर्धारित स्थितीसह;दुसरा आणि तिसरा सापडला नाही;चौथा `[1, 4]` मधील कोणत्याही स्थानाशी जुळेल.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// क्रमवारी लावताना आपल्यास क्रमवारी लावलेल्या `VecDeque` वर आयटम घालायचा असल्यास:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// बायनरी तुलनात्मक कार्यासह हे क्रमवारी लावलेले `VecDeque` शोधते.
    ///
    /// कंपॅरटर फंक्शनने अंतर्निहित `VecDeque` च्या क्रमवारीनुसार सुसंगत ऑर्डरची अंमलबजावणी केली पाहिजे आणि ऑर्डर कोड परत केला जे सूचित करेल की त्याचा लक्ष्य इच्छित लक्ष्यापेक्षा `Less`, `Equal` किंवा `Greater` आहे का.
    ///
    ///
    /// मूल्य आढळल्यास जुळणार्‍या घटकाची अनुक्रमणिका असलेली [`Result::Ok`] परत केली जाईल.जर तेथे अनेक सामने असतील तर सामन्यांपैकी कोणताही एक परत केला जाऊ शकेल.
    /// जर व्हॅल्यू सापडला नाही तर क्रमवारी लावताना एक जुळणारा घटक घातला जाऊ शकेल अशी अनुक्रमणिका असलेली एक्स 100 एक्स परत केली जाईल.
    ///
    /// # Examples
    ///
    /// चार घटकांची मालिका दिसते.प्रथम आढळतो, एक अद्वितीयपणे निर्धारित स्थितीसह;दुसरा आणि तिसरा सापडला नाही;चौथा `[1, 4]` मधील कोणत्याही स्थानाशी जुळेल.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// बायनरी की एक्स्ट्रक्शन फंक्शनसह हे सॉर्ट केलेले `VecDeque` शोधते.
    ///
    /// असे मानले की `VecDeque` की द्वारे क्रमवारी लावलेले आहे, उदाहरणार्थ समान की एक्सट्रक्शन फंक्शनचा वापर करून एक्स ०१ एक्स सह.
    ///
    ///
    /// मूल्य आढळल्यास जुळणार्‍या घटकाची अनुक्रमणिका असलेली [`Result::Ok`] परत केली जाईल.
    /// जर तेथे अनेक सामने असतील तर सामन्यांपैकी कोणताही एक परत केला जाऊ शकेल.
    /// जर व्हॅल्यू सापडला नाही तर क्रमवारी लावताना एक जुळणारा घटक घातला जाऊ शकेल अशी अनुक्रमणिका असलेली एक्स 100 एक्स परत केली जाईल.
    ///
    /// # Examples
    ///
    /// त्यांच्या दुसर्‍या घटकांनुसार क्रमवारी लावलेल्या जोड्यांच्या तुकड्यात चार घटकांची मालिका दिसते.
    /// प्रथम आढळतो, एक अद्वितीयपणे निर्धारित स्थितीसह;दुसरा आणि तिसरा सापडला नाही;चौथा `[1, 4]` मधील कोणत्याही स्थानाशी जुळेल.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// एक्स-एक्स एक्स ला जागेत बदलते जेणेकरून मागील बाजूस जास्तीचे घटक काढून किंवा परत एक्स0 2 एक्सचे क्लोन जोडून, एक्स ०१ एक्स नवीन_लेनच्या समान असेल.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// दिलेल्या लॉजिकल एलिमेंट इंडेक्ससाठी अंतर्निहित बफरमध्ये अनुक्रमणिका मिळवते.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // आकार ही नेहमीच 2 ची शक्ती असते
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// बफरमध्ये वाचण्यासाठी सोडलेल्या घटकांची संख्या मोजा
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // आकार ही नेहमीच 2 ची शक्ती असते
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // नेहमी तीन विभागांमध्ये विभाजनीय, उदाहरणार्थ: स्व: एक्स ०3 एक्स इतर: एक्स ०१ एक्स फ्रंट=,, मध्य=१, एक्स ०२ एक्स==एक्स ० X एक्स&एक्स एक्स 5 एक्स==एक्स ०6 एक्स आणि&एक्स ०7 एक्स==एक्स00 एक्स
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // As_slices पद्धतीने परतलेल्या कापांवर Hash::hash_slice वापरणे शक्य नाही कारण त्यांची लांबी अन्यथा एकसारख्या लाकमध्ये भिन्न असू शकते.
        //
        //
        // हॅशर त्याच्या पद्धतींमधील कॉलच्या तंतोतंत समान संचासाठी समानतेची हमी देतो.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// व्हॅल्यूनुसार घटक देणार्‍या फ्रंट-टू-बॅक इटरेटरमध्ये एक्स 100 एक्सचे सेवन करते.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // हे कार्य नैतिक समतुल्य असावे:
        //
        //      iter.into_iter() मधील आयटमसाठी
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// [`Vec<T>`] ला [`VecDeque<T>`] मध्ये बदला.
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// हे शक्य असेल तेथे पुन्हा बदल करणे टाळते, परंतु त्याकरिता अटी कठोर आहेत आणि त्या बदलू शकतात, आणि म्हणूनच `Vec<T>` `From<VecDeque<T>>` वरून परत आला नाही तोपर्यंत यावर अवलंबून राहू नये.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // क्षमतेबद्दल काळजी करण्यासाठी झेडएसटींसाठी कोणतेही वास्तविक वाटप नाही, परंतु `Vec` `Vec` इतकी लांबी हाताळू शकत नाही.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // क्षमता दोनची उर्जा नसल्यास खूपच लहान किंवा कमीतकमी एक मुक्त जागा नसल्यास आम्हाला आकार बदलण्याची आवश्यकता आहे.
            // आम्ही हे `Vec` मध्ये असतानाही हे करतो जेणेकरून panic वर आयटम खाली येतील.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// [`VecDeque<T>`] ला [`Vec<T>`] मध्ये बदला.
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// यास पुन्हा वाटप करण्याची आवश्यकता नाही, परंतु परिपत्रक बफर वाटपाच्या सुरूवातीस असे झाले नाही तर *ओ*(*एन*) डेटा हालचाल करण्याची आवश्यकता नाही.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // हा एक *ओ*(1) आहे.
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // यास डेटा पुनर्रचना आवश्यक आहे.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}