//! बायनरी ढीगासह प्राधान्य रांग लागू केली.
//!
//! सर्वात मोठा घटक समाविष्ट करणे आणि पॉप करणे एक्स एक्स एक्स एक्स जटिलता आहे.
//! सर्वात मोठा घटक तपासत आहे *ओ*(1).झेडवेक्टोर0 झेडला बायनरी ढीगमध्ये रूपांतरित करणे त्या ठिकाणी केले जाऊ शकते आणि त्यात *ओ*(*एन*) गुंतागुंत आहे.
//! बायनरी हीपचे ठिकाण ठिकाणी वर्गीकरण केलेल्या vector मध्ये रूपांतरित देखील केले जाऊ शकते, ज्यायोगे हे ओ ओ (*एन*\* एक्स00 एक्स-इन-प्लेस हिप्सोर्टसाठी वापरता येऊ शकेल.)
//!
//! # Examples
//!
//! हे एक मोठे उदाहरण आहे जे X002 वर [shortest path problem][sssp] सोडविण्यासाठी [Dijkstra's algorithm][dijkstra] लागू करते.
//!
//! हे सानुकूल प्रकारांसह [`BinaryHeap`] कसे वापरावे हे दर्शविते.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // प्राधान्य रांग `Ord` वर अवलंबून असते.
//! // trait स्पष्टपणे अंमलात आणा जेणेकरून रांग जास्तीत जास्त-ढीगऐवजी मिनि-हीप होईल.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // लक्षात घ्या की आम्ही किंमतीवरील ऑर्डर फ्लिप करतो.
//!         // टायच्या बाबतीत आम्ही पदांची तुलना करतो, `PartialEq` आणि `Ord` ची अंमलबजावणी सातत्याने करणे आवश्यक आहे.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` तसेच अंमलबजावणी करणे आवश्यक आहे.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // लहान अंमलबजावणीसाठी प्रत्येक नोडला एक्स 100 एक्स म्हणून प्रतिनिधित्व केले जाते.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // डिजकस्ट्राचा सर्वात लहान पथ अल्गोरिदम
//!
//! // `start` वर प्रारंभ करा आणि प्रत्येक नोडसाठी सध्याचे सर्वात कमी अंतर ट्रॅक करण्यासाठी `dist` वापरा.हे अंमलबजावणी मेमरी-कार्यक्षम नाही कारण यामुळे रांगेत डुप्लिकेट नोड्स सोडू शकतात.
//! //
//! // हे सुलभ अंमलबजावणीसाठी `usize::MAX` चा पाठविला गेलेला मूल्य म्हणून देखील वापरते.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // डिस्ट [नोड]=सध्याचे सर्वात कमी अंतर एक्स 0 एक्स ते एक्स 100 एक्स
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // आम्ही शून्य किंमतीसह `start` वर आहोत
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // प्रथम एक्स 100 एक्स कमी किंमतीच्या नोड्ससह सीमांचे परीक्षण करा
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // वैकल्पिकरित्या आम्ही सर्व लहान मार्ग शोधत राहू शकलो असतो
//!         if position == goal { return Some(cost); }
//!
//!         // आम्हाला आधीपासूनच एक चांगला मार्ग सापडला आहे म्हणून महत्त्वपूर्ण
//!         if cost > dist[position] { continue; }
//!
//!         // आपण पोहोचू शकणार्‍या प्रत्येक नोडसाठी, या नोडमधून कमी खर्चासह एखादा मार्ग शोधू शकतो का ते पहा
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // तसे असल्यास, ते सरहद्दीवर जोडा आणि सुरू ठेवा
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // विश्रांती, आम्हाला आता एक चांगला मार्ग सापडला आहे
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // उद्दिष्ट गाठता येत नाही
//!     None
//! }
//!
//! fn main() {
//!     // आपण वापरणार आहोत हा दिग्दर्शित आलेख आहे.
//!     // नोड संख्या वेगवेगळ्या राज्यांशी संबंधित आहेत आणि झेडजेडझेडझेड वजनाने एका नोडमधून दुसर्‍या ठिकाणी जाण्याच्या किंमतीचे प्रतीक दिले.
//!     //
//!     // लक्षात घ्या की कडा एकेरी मार्ग आहेत.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // आलेख समीप सूची म्हणून दर्शविला जातो जेथे प्रत्येक निर्देशांक, नोड मूल्याशी संबंधित, आउटगोइंग कडांची यादी असते.
//!     // त्याच्या कार्यक्षमतेसाठी निवडले.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // नोड 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // नोड 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // नोड 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // नोड 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // नोड 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// बायनरी ढीगासह प्राधान्य रांग लागू केली.
///
/// हे जास्तीत जास्त ढीग असेल.
///
/// एखाद्या वस्तूला अशा प्रकारे सुधारित करणे ही लॉजिक त्रुटी आहे की एक्सटॅक्स झेडट्रायट0झेडद्वारे निर्धारणानुसार आयटमला इतर कोणत्याही वस्तूच्या ऑर्डरनुसार ऑर्डर करणे, ही ढीगमध्ये असताना बदलते.
///
/// हे सामान्यत: केवळ `Cell`, `RefCell`, ग्लोबल स्टेट, I/O किंवा असुरक्षित कोडद्वारे शक्य होते.
/// अशा तर्काच्या त्रुटींमुळे उद्भवणारे वर्तन निर्दिष्ट केलेले नाही, परंतु परिणामी अपरिभाषित वर्तन होणार नाही.
/// यात panics, चुकीचे परिणाम, विलोपन, मेमरी गळती आणि समाप्ती न करणे समाविष्ट असू शकते.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // प्रकार अनुमान आम्हाला एक स्पष्ट प्रकारची स्वाक्षरी वगळू देते (जे या उदाहरणात `BinaryHeap<i32>` असेल).
/////
/// let mut heap = BinaryHeap::new();
///
/// // ढीग मध्ये पुढील आयटम पहाण्यासाठी आम्ही डोकावून पाहू शकतो.
/// // या प्रकरणात अद्याप तेथे कोणतेही आयटम नाहीत त्यामुळे आम्हाला काहीही मिळणार नाही.
/// assert_eq!(heap.peek(), None);
///
/// // चला काही स्कोअर जोडू ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // आता डोकावून पाहणे ही सर्वात महत्वाची वस्तू दाखवते.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // आम्ही ढीग लांबी तपासू शकतो.
/// assert_eq!(heap.len(), 3);
///
/// // आम्ही ढिगा .्यात असलेल्या वस्तूंवर पुनरावृत्ती करू शकतो, जरी ते यादृच्छिक क्रमाने परत केले जातात.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // त्याऐवजी आम्ही हे स्कोअर पॉप केले तर ते क्रमाने परत यावेत.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // आम्ही उर्वरित कोणत्याही वस्तूंचे ढीग साफ करू शकतो.
/// heap.clear();
///
/// // ढीग आता रिक्त असले पाहिजे.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// एकतर `std::cmp::Reverse` किंवा सानुकूल `Ord` अंमलबजावणी `BinaryHeap` ला कमीतकमी कमी करण्यासाठी वापरली जाऊ शकते.
/// हे `heap.pop()` सर्वात मोठ्याऐवजी सर्वात लहान मूल्य परत आणते.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // `Reverse` मधील मूल्ये लपेटणे
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // जर आपण हे स्कोअर आता पॉप केले तर ते उलट क्रमाने परत यावेत.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # वेळ गुंतागुंत
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// `push` चे मूल्य अपेक्षित किंमत आहे;मेथड डॉक्युमेंटेशन अधिक तपशीलवार विश्लेषण देते.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// `BinaryHeap` वरील महान आयटमसाठी बदलता येणारा संदर्भ लपेटणारी रचना.
///
///
/// हे `struct` एक्स 100 एक्स वर एक्स0 2 एक्स पद्धतीने तयार केले गेले आहे.
/// अधिकसाठी त्याचे दस्तऐवजीकरण पहा.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // सुरक्षितताः पीकमट केवळ रिक्त नसलेल्या ढीगांसाठी स्थापित केले जाते.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // सुरक्षित: पीकमट केवळ रिक्त नसलेल्या ढीगांसाठीच स्थापित केले जाते
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // सुरक्षित: पीकमट केवळ रिक्त नसलेल्या ढीगांसाठीच स्थापित केले जाते
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// ढीगातून डोकावलेले मूल्य काढून टाकते आणि ते परत करते.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// रिक्त `BinaryHeap<T>` तयार करते.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// कमाल-हीप म्हणून रिक्त `BinaryHeap` तयार करते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// विशिष्ट क्षमतेसह रिक्त `BinaryHeap` तयार करते.
    /// हे `capacity` घटकांसाठी पुरेशी मेमरी प्रीलोकसेट करते, जेणेकरुन त्यात कमीतकमी अनेक मूल्ये येईपर्यंत `BinaryHeap` रीलोकेट करणे आवश्यक नसते.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// बायनरी ढीगमधील सर्वात मोठ्या आयटमसाठी बदलणारा संदर्भ किंवा रिक्त असल्यास `None` मिळवते.
    ///
    /// Note: `PeekMut` मूल्य लीक झाल्यास, ढीग विसंगत स्थितीत असू शकतात.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # वेळ गुंतागुंत
    ///
    /// जर आयटम सुधारित केला गेला असेल तर सर्वात वाईट वेळेची गुंतागुंत *O*(log(*n*)) आहे, अन्यथा ती *ओ*(1) आहे.
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// बायनरी ढीगमधून सर्वात मोठी वस्तू काढून ती परत करते किंवा ती रिक्त असल्यास `None`.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # वेळ गुंतागुंत
    ///
    /// *एन* एलिमेंट्स असलेल्या ढीगवरील एक्स ०१ एक्सची सर्वात वाईट किंमत म्हणजे एक्स २०० एक्स.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // सुरक्षा: !self.is_empty() म्हणजे self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// बायनरी ढीग वर आयटम ढकलतो.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # वेळ गुंतागुंत
    ///
    /// एक्स 100 एक्स ची अपेक्षित किंमत, ज्यामुळे घटक ढकलल्या जाणा every्या प्रत्येक क्रमवारीत क्रमशः मिळतात आणि पुरेसे मोठ्या संख्येने पुश होते *ओ*(1).
    ///
    /// आधीपासून कोणत्याही क्रमवारी लावलेल्या नमुन्यात * नसलेले घटक ढकलताना ही सर्वात अर्थपूर्ण किंमत मेट्रिक आहे.
    ///
    /// घटकांना प्रामुख्याने चढत्या क्रमाने लावले तर वेळची जटिलता कमी होते.
    /// सर्वात वाईट परिस्थितीत, घटकांना चढत्या क्रमवारीत ढकलले जाते आणि प्रति पुश प्रतिरूप किंमत ही एक्स एन एक्स असते ज्यात *एन* घटक असतात.
    ///
    /// `push` वर *एकल* कॉलची सर्वात वाईट किंमत *ओ*(*एन*) आहे.क्षमता समाप्त झाल्यावर आणि आकार बदलण्याची आवश्यकता असल्यास सर्वात वाईट परिस्थिती उद्भवते.
    /// मागील आकारात आकार बदलण्याची किंमत मोजली गेली आहे.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // सुरक्षा: आम्ही नवीन वस्तू ढकलल्यामुळे याचा अर्थ असा आहे
        //  जुने_लेन=X01 एक्स, 1 <एक्स 100 एक्स
        unsafe { self.sift_up(0, old_len) };
    }

    /// `BinaryHeap` घेते आणि क्रमवारी लावलेल्या (ascending) क्रमाने एक vector मिळवते.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // सुरक्षाः `end` `self.len() - 1` पासून 1 पर्यंत जाते (दोन्ही समाविष्ट केलेले),
            //  तर प्रवेश करण्यासाठी हे नेहमीच वैध अनुक्रमणिका असते.
            //  निर्देशांक 0 (म्हणजे `ptr`) वर प्रवेश करणे सुरक्षित आहे, कारण
            //  1 <=समाप्ती <self.len(), ज्याचा अर्थ self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // सुरक्षाः `end` `self.len() - 1` पासून 1 पर्यंत जाते (दोन्ही समाविष्ट केलेले) त्यामुळेः
            //  0 <1 <=शेवट <=X01 एक्स, 1 <एक्स0 2 एक्स ज्याचा अर्थ 0 <शेवट आणि शेवट <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // सिफ्ट_अप आणि सिफ्ट_डाऊन ची अंमलबजावणी असुरक्षित अवरोध वापरते ज्यामुळे झेडवेक्टोर0झेड (एखाद्या छिद्र मागे सोडून) बाहेर काढले जाते, इतरांसह सरकतात आणि काढलेल्या घटकास छिद्रच्या अंतिम स्थानावर परत झेडवेक्टोर0झेडमध्ये हलवले जाते.
    //
    // हे प्रतिनिधित्व करण्यासाठी एक्स 100 एक्स प्रकारचा वापर केला जातो आणि panic वर देखील, त्याच्या व्याप्तीच्या शेवटी भोक परत भरला असल्याचे सुनिश्चित करा.
    // भोक वापरणे स्वॅप्सच्या तुलनेत स्थिर घटक कमी करते, ज्यामध्ये दुप्पट हालचालींचा समावेश आहे.
    //
    //
    //
    //

    /// # Safety
    ///
    /// कॉलरने हमी दिली पाहिजे की `pos < self.len()`
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // `pos` वर मूल्य काढा आणि एक छिद्र तयार करा.
        // सुरक्षितता: कॉलर हमी देतो की << self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // सुरक्षितता: hole.pos()> प्रारंभ>=0, ज्याचा अर्थ hole.pos()> 0 आहे
            //  आणि म्हणून hole.pos(), 1 उतू शकत नाही.
            //  हे हमी देते की पालक <X01 एक्स म्हणून ते एक वैध अनुक्रमणिका आणि देखील!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // सुरक्षा: वरील प्रमाणेच
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// `pos` वर एक घटक घ्या आणि त्याची मुले मोठी असल्यास ती ढीग खाली हलवा.
    ///
    ///
    /// # Safety
    ///
    /// कॉलरने हमी दिली पाहिजे की `pos < end <= self.len()`
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // सुरक्षितता: कॉलर हमी देतो की <शेवट << एक्स 100 एक्स.
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // लूप इनव्हिएरंट: मूल==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // दोन मुलांपेक्षा अधिक सुरक्षिततेशी तुलना करा सुरक्षितता: मूल <अंत, 1 <self.len() आणि मूल + 1 <अंत <= self.len(), जेणेकरून ते वैध अनुक्रमणिका आहेत.
            //
            //  मूल==2 *hole.pos() + 1!= hole.pos() आणि मूल + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: टी *झेडएसटी असल्यास 2* एक्स 100 एक्स + 1 किंवा 2 * एक्स01 एक्स + 2 ओव्हरफ्लो होऊ शकतात
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // जर आम्ही आधीच क्रमाने असाल तर थांबा.
            // सुरक्षितता: मूल आता एकतर जुना मूल किंवा म्हातारा मूल +1
            //  आम्ही आधीपासूनच सिद्ध केले आहे की दोन्ही <self.len() आणि!= hole.pos() आहेत
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // सुरक्षा: वरील प्रमाणेच.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // सुरक्षितता: आणि&शॉर्ट सर्किट, ज्याचा अर्थ असा की
        //  दुसरी अट आधीपासूनच हे खरे आहे की मूल==शेवट, 1 <एक्स00 एक्स.
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // सुरक्षितता: मूल आधीच एक वैध अनुक्रमणिका असल्याचे सिद्ध झाले आहे आणि
            //  मूल==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// कॉलरने हमी दिली पाहिजे की `pos < self.len()`
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // सुरक्षितता: पोस् <लेनची हमी कॉलरद्वारे दिले जाते आणि
        //  स्पष्टपणे लेन= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// `pos` वर एक घटक घ्या आणि तो ढीगातून संपूर्ण मार्गाने हलवा, नंतर त्यास त्याच्या स्थानापर्यंत चाळा.
    ///
    ///
    /// Note: जेव्हा घटक मोठा असल्याचे ज्ञात आहे/तळाशी असणे आवश्यक आहे तेव्हा हे वेगवान होते.
    ///
    /// # Safety
    ///
    /// कॉलरने हमी दिली पाहिजे की `pos < self.len()`
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // सुरक्षितता: कॉलर हमी देतो की << self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // लूप इनव्हिएरंट: मूल==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // सुरक्षितता: मूल <अंत, 1 <self.len() आणि
            //  मूल +1 <शेवट <= self.len(), जेणेकरून ते वैध अनुक्रमणिका आहेत.
            //  मूल==2 *hole.pos() + 1!= hole.pos() आणि मूल + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: टी *झेडएसटी असल्यास 2* एक्स 100 एक्स + 1 किंवा 2 * एक्स01 एक्स + 2 ओव्हरफ्लो होऊ शकतात
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // सुरक्षा: वरील प्रमाणेच
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // सुरक्षितता: मूल==शेवट, 1 <एक्स00 एक्स, म्हणून ते एक वैध अनुक्रमणिका आहे
            //  आणि मूल==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // सुरक्षा: पॉस ही भोकातील स्थिती आहे आणि ते आधीच सिद्ध झाले आहे
        //  वैध अनुक्रमणिका असणे.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // सुरक्षितता: एन self.len()/2 पासून सुरू होते आणि 0 पर्यंत खाली जाते.
            //  फक्त तेव्हाच! (एन <एक्स 00 एक्स जर एक्स ०१ एक्स==० असेल तर, परंतु लूपच्या स्थितीनुसार ते नाकारले जात नाही.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// `other` चे सर्व घटक `self` मध्ये हलविते, `other` रिक्त ठेवतात.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` सर्वात वाईट परिस्थितीमध्ये O(len1 + len2) ऑपरेशन्स आणि सुमारे 2 *(len1 + len2) तुलना घेते तर `extend` O(len2* log(len1)) ऑपरेशन्स घेते आणि len1>= len2 असे गृहीत धरून सर्वात जवळच्या 1 *len2* log_2(len1) ची तुलना करते.
        // मोठ्या ढीगांसाठी, क्रॉसओव्हर पॉईंट यापुढे या युक्तिवादाचे अनुसरण करीत नाही आणि अनुभवीपणे निर्धारित केले गेले.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// एक आयरेटर परत आणते जो ढीग क्रमाने घटक पुनर्प्राप्त करतो.
    /// पुनर्प्राप्त केलेले घटक मूळ ढीगातून काढले जातात.
    /// उर्वरित घटक ड्रॉप इन हिप ऑर्डरवर काढले जातील.
    ///
    /// Note:
    /// * `.drain_sorted()` हे *ओ*(*एन*\* एक्स01 एक्स; एक्स 100 एक्स पेक्षा खूपच हळू आहे.
    ///   आपण बहुतेक प्रकरणांमध्ये नंतरचे वापरावे.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // ढीग क्रमाने सर्व घटक काढून टाकते
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// केवळ पूर्वानुमानाने निर्दिष्ट केलेले घटक राखून ठेवतात.
    ///
    /// दुसर्‍या शब्दांत, `e` ने `false` परत केल्यासारखे सर्व घटक `e` काढा.
    /// घटकांची अनुक्रमित (आणि अनिर्दिष्ट) क्रमाने भेट दिली जाते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // फक्त समान संख्या ठेवा
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// अंतर्निहित vector मधील सर्व मूल्यांना भेट देणारा एक इंटरटर अनियंत्रित क्रमाने परत करतो.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // अनियंत्रित क्रमाने 1, 2, 3, 4 मुद्रित करा
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// एक आयरेटर परत आणते जो ढीग क्रमाने घटक पुनर्प्राप्त करतो.
    /// ही पद्धत मूळ ढीग वापरते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// बायनरी ढीगमधील सर्वात मोठी आयटम किंवा ती रिक्त असल्यास `None` मिळवते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # वेळ गुंतागुंत
    ///
    /// सर्वात वाईट परिस्थितीत किंमत *ओ*(1) आहे.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// बायनरी ढीग पुन्हा ठेवल्याशिवाय ठेवू शकणार्‍या घटकांची संख्या मिळवते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// दिलेल्या `BinaryHeap` मध्ये अचूक `additional` अधिक घटक समाविष्ट करण्यासाठी किमान क्षमता राखून ठेवते.
    /// क्षमता आधीच पुरेशी असल्यास काहीही करत नाही.
    ///
    /// लक्षात ठेवा की वाटपकर्ता विनंत्यापेक्षा अधिक संग्रह देऊ शकेल.
    /// म्हणून क्षमतेवर अगदी कमीतकमी असावे यावर अवलंबून राहू शकत नाही.
    /// झेडफ्यूचर 0 झेडच्या आशेची अपेक्षा असल्यास [`reserve`] ला प्राधान्य द्या.
    ///
    /// # Panics
    ///
    /// नवीन क्षमता `usize` ओव्हरफ्लो झाल्यास Panics.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// `BinaryHeap` मध्ये कमीतकमी `additional` आणखी घटक समाविष्ट करण्यासाठी क्षमता राखीव आहे.
    /// वारंवार पुनर्विक्री टाळण्यासाठी संकलनात अधिक जागा राखीव असू शकते.
    ///
    /// # Panics
    ///
    /// नवीन क्षमता `usize` ओव्हरफ्लो झाल्यास Panics.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// शक्य तितकी अतिरिक्त क्षमता टाकून देते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// कमी बाउंडसह क्षमता टाकून देते.
    ///
    /// लांबी आणि पुरवठा केलेले मूल्य यापेक्षा कमीतकमी क्षमता राहील.
    ///
    ///
    /// जर सद्य क्षमता कमी मर्यादेपेक्षा कमी असेल तर ही एक निवड नाही.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// `BinaryHeap` घेते आणि अंतर्निहित vector अनियंत्रित क्रमाने मिळवते.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // काही क्रमाने मुद्रित करेल
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// बायनरी ढीगची लांबी मिळवते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// बायनरी ढीग रिकामे आहेत का ते तपासेल.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// बायनरी ढीग साफ करते, काढून टाकलेल्या घटकांमधून पुनरावृत्ती करणारा परत.
    ///
    /// घटक मनमानी पद्धतीने काढले जातात.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// बायनरी ढीग पासून सर्व आयटम थेंब.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// होल स्लाइसमधील छिद्रांचे प्रतिनिधित्व करते, म्हणजे वैध मूल्याशिवाय अनुक्रमणिका (कारण ते हलविले गेले किंवा डुप्लिकेट केले गेले).
///
/// ड्रॉप मध्ये, `Hole` मूळतः काढलेल्या मूल्यासह भोक स्थिती भरून स्लाइस पुनर्संचयित करेल.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// अनुक्रमणिका `pos` वर नवीन `Hole` तयार करा.
    ///
    /// असुरक्षित कारण पोस्ट डेटा स्लाइसमध्ये असणे आवश्यक आहे.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // सेफः पोझ स्लाइसच्या आत असावेत
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// काढलेल्या घटकाचा संदर्भ मिळवते.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// `index` वरील घटकाचा संदर्भ मिळवते.
    ///
    /// असुरक्षित आहे कारण निर्देशांक डेटा स्लाइसच्या आत असणे आवश्यक आहे आणि पोस्टाइतकीच नाही.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// नवीन ठिकाणी छिद्र हलवा
    ///
    /// असुरक्षित आहे कारण निर्देशांक डेटा स्लाइसच्या आत असणे आवश्यक आहे आणि पोस्टाइतकीच नाही.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // पुन्हा भोक भरा
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// `BinaryHeap` च्या घटकांवरील एक पुनरावृत्तीकर्ता.
///
/// हे `struct` [`BinaryHeap::iter()`] द्वारे तयार केले गेले आहे.
/// अधिकसाठी त्याचे दस्तऐवजीकरण पहा.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) `#[derive(Clone)]` च्या बाजूने काढा
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// `BinaryHeap` च्या घटकांवर मालकीचे पुनरावृत्ती करणारा.
///
/// हे `struct` हे [`BinaryHeap::into_iter()`] (`IntoIterator` trait द्वारे प्रदान केलेले) द्वारे तयार केले गेले आहे.
/// अधिकसाठी त्याचे दस्तऐवजीकरण पहा.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// `BinaryHeap` च्या घटकांवरील जल प्रवाहित करणारा.
///
/// हे `struct` [`BinaryHeap::drain()`] द्वारे तयार केले गेले आहे.
/// अधिकसाठी त्याचे दस्तऐवजीकरण पहा.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// `BinaryHeap` च्या घटकांवरील जल प्रवाहित करणारा.
///
/// हे `struct` [`BinaryHeap::drain_sorted()`] द्वारे तयार केले गेले आहे.
/// अधिकसाठी त्याचे दस्तऐवजीकरण पहा.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// ढीग क्रमाने ढीग घटक काढून टाकते.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// `Vec<T>` ला `BinaryHeap<T>` मध्ये रूपांतरित करते.
    ///
    /// हे रूपांतरण एकाच ठिकाणी होते आणि त्यामध्ये *ओ*(*एन*) वेळ गुंतागुंत आहे.
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// `BinaryHeap<T>` ला `Vec<T>` मध्ये रूपांतरित करते.
    ///
    /// या रूपांतरणासाठी डेटा हालचाल किंवा ationलोकेशनची आवश्यकता नाही आणि त्यात सतत वेळ गुंतागुंत आहे.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// एक उपभोग करणारा इटररेटर तयार करतो, म्हणजेच तो प्रत्येक मूल्य बायनरी ढीगमधून अनियंत्रित क्रमाने हलवितो.
    /// हे कॉल केल्यानंतर बायनरी ढीग वापरणे शक्य नाही.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // अनियंत्रित क्रमाने 1, 2, 3, 4 मुद्रित करा
    /// for x in heap.into_iter() {
    ///     // x चा प्रकार i32 आहे, एक्स 100 एक्स नाही
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}