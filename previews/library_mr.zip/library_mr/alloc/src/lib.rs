//! # Rust कोर वाटप आणि संग्रह लायब्ररी
//!
//! ही लायब्ररी हीप-वाटप केलेल्या मूल्यांच्या व्यवस्थापनासाठी स्मार्ट पॉईंटर्स आणि संग्रह प्रदान करते.
//!
//! हे लायब्ररी लिबकोर प्रमाणे सामान्यपणे थेट वापरण्याची आवश्यकता नसते कारण त्यातील सामग्री एक्स एक्स एक्स मध्ये पुन्हा निर्यात केली जाते.
//! Crates जे `#![no_std]` गुणधर्म वापरतात ते सामान्यत: `std` वर अवलंबून नसतात, म्हणून ते त्याऐवजी हे crate वापरू इच्छित.
//!
//! ## बॉक्सिंग मूल्ये
//!
//! एक्स ०१ एक्स प्रकार हा एक स्मार्ट पॉईंटर प्रकार आहे.एक [`Box`] चे फक्त एक मालक असू शकतात आणि मालक त्या ढिगा .्यावरील सामग्री बदलण्याचा निर्णय घेऊ शकतो.
//!
//! हा प्रकार थ्रेड्समध्ये कार्यक्षमतेने पाठविला जाऊ शकतो कारण `Box` मूल्याचे आकार पॉईंटर प्रमाणेच आहे.
//! झाडासारखी डेटा स्ट्रक्चर्स बहुतेक वेळा बॉक्ससह बनविली जातात कारण प्रत्येक नोडमध्ये बर्‍याचदा एकच पालक असतो, पालक.
//!
//! ## संदर्भ मोजलेले पॉईंटर्स
//!
//! [`Rc`] प्रकार हा थ्रेडमधील मेमरी सामायिक करण्यासाठी हेतू नसलेला थ्रेडसेफ संदर्भ-मोजलेला पॉईंटर प्रकार आहे.
//! एक [`Rc`] पॉईंटर एक प्रकार गुंडाळतो, `T`, आणि केवळ सामायिक केलेला संदर्भ `&T` वर प्रवेश करण्यास अनुमती देतो.
//!
//! वारसा मिळालेला बदल (जसे की X02 एक्स वापरणे) एखाद्या अनुप्रयोगासाठी खूपच मर्यादित असते तेव्हा हा प्रकार उपयुक्त ठरतो आणि बहुतेक वेळा परिवर्तनास अनुमती देण्यासाठी [`Cell`] किंवा [`RefCell`] प्रकारांसह जोडला जातो.
//!
//!
//! ## अणुदृष्ट्या संदर्भ मोजलेले पॉईंटर्स
//!
//! [`Arc`] प्रकार हा [`Rc`] प्रकाराचा थ्रेडसेफ समतुल्य आहे.हे [`Rc`] ची सर्व समान कार्यक्षमता प्रदान करते, याशिवाय समाविष्ट असलेली प्रकार `T` सामायिक करण्यायोग्य आहे.
//! याव्यतिरिक्त,[`Arc<T>`][`Arc`] एक्स नसल्यास एक्स 100 एक्स स्वतःच पाठविण्यायोग्य आहे.
//!
//! हा प्रकार समाविष्ट असलेल्या डेटामध्ये सामायिक प्रवेशास अनुमती देतो आणि बहुतेक वेळा सामायिक संसाधनांच्या उत्परिवर्तनास अनुमती देण्यासाठी मुटेक्सेससारख्या सिंक्रोनाइझेशन आदिमसह जोडला जातो.
//!
//! ## Collections
//!
//! सर्वात सामान्य सामान्य हेतू डेटा स्ट्रक्चर्सची अंमलबजावणी या लायब्ररीत परिभाषित केली आहे.ते एक्स-एक्स एक्सद्वारे पुन्हा निर्यात केले जातात.
//!
//! ## ढीग इंटरफेस
//!
//! एक्स00 एक्स मॉड्यूल डीफॉल्ट ग्लोबल allocलोकरेटरला निम्न-स्तरीय इंटरफेस परिभाषित करते.हे libc allocलोटर एपीआयशी सुसंगत नाही.
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// तांत्रिकदृष्ट्या, हे रस्टडोकमधील बग आहे: रस्टडॉक एक्स02 एक्स ब्लॉकवरील दस्तऐवजीकरण एक्स 100 एक्ससाठी पाहते, ज्यात हे वैशिष्ट्य X01 एक्समध्ये वापरलेले दस्तऐवजीकरण देखील आहे आणि वेडा झाले आहे की वैशिष्ट्य-गेट सक्षम नाही.
// तद्वतच, ते इतर झेडकेरेट्स 0 झेड मधील डॉक्ससाठी वैशिष्ट्यीय गेटसाठी तपासणार नाही, परंतु हे केवळ लँग आयटमसाठीच दिसू शकते म्हणून ते निश्चित करणे योग्य वाटत नाही.
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// या लायब्ररीच्या चाचणीस अनुमती द्या

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// इतर मॉड्यूलद्वारे वापरल्या जाणार्‍या अंतर्गत मॅक्रोसह मॉड्यूल (इतर मॉड्यूलपूर्वी समाविष्ट करणे आवश्यक आहे).
#[macro_use]
mod macros;

// निम्न-स्तरीय वाटप रणनीतींसाठी ढीग प्रदान केले

pub mod alloc;

// वरील ढीगांचा वापर करून आदिम प्रकार

// चाचणी सीएफजीमध्ये बिल्डिंग करताना लँग-आयटमची डुप्लिकेट टाळण्यासाठी `boxed.rs` कडील मोडची सशर्त व्याख्या करणे आवश्यक आहे;परंतु कोडमध्ये `use boxed::Box;` घोषणा देखील करण्याची आवश्यकता आहे.
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}