/// वितर्क असलेले [`Vec`] तयार करते.
///
/// `vec!` अ‍ॅरे एक्सप्रेशन्स प्रमाणे समान वाक्यरचनासह `Vec`s परिभाषित करण्याची अनुमती देते.
/// या मॅक्रोचे दोन प्रकार आहेत:
///
/// - दिलेल्या घटकांची सूची असलेली एक [`Vec`] तयार करा:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - दिलेल्या घटक आणि आकारातून एक [`Vec`] तयार करा:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// लक्षात घ्या की अ‍ॅरे एक्सप्रेशन्सच्या विपरीत हा वाक्यरचना [`Clone`] ची अंमलबजावणी करणार्या सर्व घटकांना समर्थन देते आणि घटकांची संख्या स्थिर असू शकत नाही.
///
/// हे एक्सप्रेशन डुप्लिकेट करण्यासाठी `clone` चा वापर करेल, म्हणून एखाद्याने नॉन-स्टँडर्ड `Clone` अंमलबजावणी असलेल्या प्रकारांसह याचा वापर केला पाहिजे.
/// उदाहरणार्थ, एक्स 100 एक्स;5] independent स्वतंत्र बॉक्सिंग पूर्णांकांकडे निर्देशित करणारे पाच संदर्भ नव्हे तर समान बॉक्सिंग पूर्णांक मूल्याचे पाच संदर्भांचे एक vector तयार करेल.
///
///
/// हे देखील लक्षात घ्या की `vec![expr; 0]` ला परवानगी आहे आणि ते रिक्त vector तयार करते.
/// हे अद्याप `expr` चे मूल्यांकन करेल आणि परिणामी मूल्य त्वरित ड्रॉप करेल, म्हणून दुष्परिणाम लक्षात घ्या.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): या मॅक्रो परिभाषासाठी आवश्यक असलेली मूळ एक्स एक्स 01 एक्स पद्धत एक्स 100 एक्स सह उपलब्ध नाही.
// त्याऐवजी `slice::into_vec` फंक्शन वापरा जे फक्त cfg(test) NB सह उपलब्ध आहे अधिक माहितीसाठी slice.rs मधील slice::hack मॉड्यूल पहा
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// रनटाइम एक्सप्रेशन्सचे इंटरपोलेशन वापरून एक `String` तयार करते.
///
/// `format!` ला प्राप्त होणारा पहिला वितर्क एक फॉर्मेट स्ट्रिंग आहे.हे तार अक्षरशः असले पाहिजे.स्वरूपण स्ट्रिंगची उर्जा the {}} `s मध्ये आहे.
///
/// `format!` ला दिले गेलेले अतिरिक्त मापदंड नामित किंवा स्थितीत्मक पॅरामीटर्स वापरल्याशिवाय दिलेली क्रमाने स्वरुपण स्ट्रिंगमध्ये replace {}; replace चे पुनर्स्थित करतात;अधिक माहितीसाठी [`std::fmt`] पहा.
///
///
/// एक्स 100 एक्सचा सामान्य वापर म्हणजे कंक्रीटेशन आणि स्ट्रिंग्सचा इंटरपोलेशन.
/// त्याच संमेलनाचा उपयोग स्ट्रिंगच्या हेतूनुसार, [`print!`] आणि [`write!`] मॅक्रोसह केला जातो.
///
/// एकल मूल्य स्ट्रिंगमध्ये रूपांतरित करण्यासाठी, [`to_string`] पद्धत वापरा.हे [`Display`] स्वरूपन trait वापरेल.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` traics स्वरूपन trait अंमलबजावणीत त्रुटी आढळल्यास.
/// हे चुकीच्या अंमलबजावणीस सूचित करते कारण `fmt::Write for String` कधीही त्रुटी परत करीत नाही.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// नमुना स्थितीत निदान सुधारण्यासाठी एएसटी नोडला अभिव्यक्तीवर भाग घ्या.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}