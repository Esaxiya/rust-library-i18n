//! संक्रमित अनुक्रमात गतिशील-आकाराचे दृश्य, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! स्लाइस हे पॉईंटर आणि लांबी म्हणून दर्शविलेल्या मेमरी ब्लॉकमधील एक दृश्य आहे.
//!
//! ```
//! // एक वैक कापून
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // स्लाइसवर अ‍ॅरे सक्ती करणे
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! काप एकतर बदलण्यायोग्य किंवा सामायिक आहेत.
//! सामायिक स्लाइस प्रकार `&[T]` आहे, तर परिवर्तनीय स्लाइस प्रकार एक्स ०१ एक्स आहे, जेथे एक्स ०२ एक्स घटक प्रकार दर्शवते.
//! उदाहरणार्थ, आपण मेमरी ब्लॉकला बदलू शकता ज्यामध्ये बदलण्यायोग्य स्लाइस सूचित करतातः
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! या मॉड्यूलमध्ये काही गोष्टी आहेतः
//!
//! ## Structs
//!
//! कापांकरिता उपयुक्त अशा अनेक स्ट्रक्च आहेत, जसे की एक्स 100 एक्स, जो स्लाइसवरून पुनरावृत्तीचे प्रतिनिधित्व करतो.
//!
//! ## Trait अंमलबजावणी
//!
//! कापांसाठी सामान्य झेडट्रायटस 0 झेडची अनेक अंमलबजावणी आहेत.काही उदाहरणांमध्ये हे समाविष्ट आहेः
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], ज्याच्या प्रकारांचा घटक प्रकार [`Eq`] किंवा [`Ord`] आहे.
//! * [`Hash`] - ज्या प्रकारच्या घटकांचा प्रकार [`Hash`] आहे.
//!
//! ## Iteration
//!
//! तुकडे `IntoIterator` अंमलात आणतात.इट्रेटर स्लाइस घटकांना संदर्भ देते.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! बदलण्यायोग्य स्लाइसमुळे घटकांना परस्पर बदल आढळतात:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! हा आयटर स्लाइसच्या घटकांना परस्पर बदल घडवून आणू शकतो, म्हणून स्लाइसचा घटक प्रकार एक्स ०१ एक्स आहे तर पुनरावृत्ती करणाराचा घटक प्रकार एक्स १००० एक्स आहे.
//!
//!
//! * [`.iter`] डीफॉल्ट पुनरावृत्ती करणार्‍यांना परत करण्यासाठी एक्स आणि एक्स स्पष्ट पद्धती आहेत.
//! * आयटरस परत करणार्‍या पुढील पद्धती म्हणजे [`.split`], [`.splitn`], [`.chunks`], [`.windows`] आणि अधिक.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// या मॉड्यूलमधील अनेक usies चाचणी कॉन्फिगरेशनमध्येच वापरली जातात.
// न वापरलेल्या_मार्गाच्या इशारेचे निराकरण करण्यापेक्षा केवळ चेतावणी बंद करणे हे क्लिनर आहे.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// मूलभूत स्लाइस विस्तार पद्धती
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) एनबी चाचणी करताना `vec!` मॅक्रोच्या अंमलबजावणीसाठी आवश्यक, अधिक तपशीलांसाठी या फायलीमधील एक्स 0 एक्स एक्स मॉड्यूल पहा.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) चाचणी NB दरम्यान `Vec::clone` च्या अंमलबजावणीसाठी आवश्यक, अधिक तपशीलांसाठी या फाईलमधील `hack` मॉड्यूल पहा.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): cfg(test) `impl [T]` उपलब्ध नसल्यामुळे, ही तीन कार्ये वास्तविकपणे अशा पद्धती आहेत जी एक्स 2 एक्स मध्ये आहेत परंतु एक्स0 3 एक्समध्ये नाहीत, आम्हाला ही कार्ये `test_permutations` चाचणीसाठी पुरविणे आवश्यक आहे
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // आम्ही यामध्ये इनलाइन गुणधर्म जोडू नये कारण हे बहुतेक `vec!` मॅक्रोमध्ये वापरले जाते आणि यामुळे परिपूर्ण प्रतिगमन होते.
    // चर्चा आणि परिपूर्ण निकालांसाठी #71204 पहा.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // आयटम खाली लूपमध्ये आरंभ चिन्हांकित केले
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) एलएलव्हीएमसाठी सीमांकन तपासणी काढणे आवश्यक आहे आणि झिपपेक्षा चांगले कोडेजेन आहे.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // कमीतकमी या लांबीपर्यंत व्हेक्टरचे वाटप केले आणि वर आरंभ केले.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // `s` च्या क्षमतेसह वर वाटप केले आणि खाली ptr::copy_to_non_overlapping मध्ये `s.len()` प्रारंभ करा.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// स्लाइसची क्रमवारी लावते.
    ///
    /// हा क्रमवारी स्थिर आहे (उदा. समान घटकांची पुन्हा क्रमवारी लावत नाही) आणि *O*(*n*\*log(* n*)) सर्वात वाईट-केस)
    ///
    /// लागू असल्यास, अस्थिर क्रमवारी लावणे पसंत केले जाते कारण ते सामान्यपणे स्थिर क्रमवारीपेक्षा वेगवान असते आणि यामुळे सहायक मेमरीचे वाटप होत नाही.
    /// [`sort_unstable`](slice::sort_unstable) पहा.
    ///
    /// # सध्याची अंमलबजावणी
    ///
    /// वर्तमान अल्गोरिदम हे [timsort](https://en.wikipedia.org/wiki/Timsort) द्वारे प्रेरित एक अनुकूली, पुनरावृत्ती विलय क्रम आहे.
    /// स्लाइस जवळजवळ क्रमवारीत असणार्‍या किंवा एकामागून दोन किंवा अधिक क्रमवारी लावलेल्या क्रमांकामध्ये अशी द्रुत रचना तयार केली गेली आहे.
    ///
    ///
    /// तसेच, हे `self` च्या अर्ध्या आकाराचे तात्पुरते स्टोरेजचे वाटप करते, परंतु लहान तुकड्यांसाठी त्याऐवजी विना-वाटप समाविष्ट करणे क्रमवारी वापरली जाते.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// तुलनेत कार्यासह स्लाइसची क्रमवारी लावते.
    ///
    /// हा क्रमवारी स्थिर आहे (उदा. समान घटकांची पुन्हा क्रमवारी लावत नाही) आणि *O*(*n*\*log(* n*)) सर्वात वाईट-केस)
    ///
    /// कंपेटर फंक्शनने स्लाइसमधील घटकांसाठी एकूण ऑर्डरिंग निश्चित करणे आवश्यक आहे.ऑर्डरिंग एकूण नसल्यास, घटकांची ऑर्डर अनिर्दिष्ट आहे.
    /// ऑर्डर ही एकूण ऑर्डर असेल तर (सर्व `a`, `b` आणि `c` साठी):
    ///
    /// * एकूण आणि एन्टिस्मिमेट्रिकः `a < b`, `a == b` किंवा `a > b` पैकी एक सत्य आहे, आणि
    /// * संक्रमित, `a < b` आणि `b < c` सूचित करते `a < c`.हे दोन्ही `==` आणि `>` साठी असणे आवश्यक आहे.
    ///
    /// उदाहरणार्थ, [`f64`] [`Ord`] ची अंमलबजावणी करीत नाही कारण `NaN != NaN`, जेव्हा स्लाइसमध्ये एक्स 100 एक्स नसते तेव्हा आम्ही आमच्या क्रमवारी कार्य म्हणून `partial_cmp` वापरू शकतो.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// लागू असल्यास, अस्थिर क्रमवारी लावणे पसंत केले जाते कारण ते सामान्यपणे स्थिर क्रमवारीपेक्षा वेगवान असते आणि यामुळे सहायक मेमरीचे वाटप होत नाही.
    /// [`sort_unstable_by`](slice::sort_unstable_by) पहा.
    ///
    /// # सध्याची अंमलबजावणी
    ///
    /// वर्तमान अल्गोरिदम हे [timsort](https://en.wikipedia.org/wiki/Timsort) द्वारे प्रेरित एक अनुकूली, पुनरावृत्ती विलय क्रम आहे.
    /// स्लाइस जवळजवळ क्रमवारीत असणार्‍या किंवा एकामागून दोन किंवा अधिक क्रमवारी लावलेल्या क्रमांकामध्ये अशी द्रुत रचना तयार केली गेली आहे.
    ///
    /// तसेच, हे `self` च्या अर्ध्या आकाराचे तात्पुरते स्टोरेजचे वाटप करते, परंतु लहान तुकड्यांसाठी त्याऐवजी विना-वाटप समाविष्ट करणे क्रमवारी वापरली जाते.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // उलट क्रमवारी लावणे
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// की एक्सट्रॅक्शन फंक्शनसह स्लाइसची क्रमवारी लावते.
    ///
    /// हा क्रमवारी स्थिर आहे (उदा. समान घटकांची पुन्हा क्रमवारी लावत नाही) आणि *ओ*(*एम*\* * एन *\* एक्स00 एक्स सर्वात वाईट घटना आहे जिथे की फंक्शन *ओ*(*एम*) आहे.
    ///
    /// महागड्या की फंक्शन्ससाठी (उदा
    /// सोपी मालमत्ता प्रवेश किंवा मूलभूत ऑपरेशन्स नसलेली कार्ये), एक्स 00 एक्स कदाचित वेगवान होण्याची शक्यता आहे, कारण ते घटक की पुन्हा वापरत नाहीत.
    ///
    ///
    /// लागू असल्यास, अस्थिर क्रमवारी लावणे पसंत केले जाते कारण ते सामान्यपणे स्थिर क्रमवारीपेक्षा वेगवान असते आणि यामुळे सहायक मेमरीचे वाटप होत नाही.
    /// [`sort_unstable_by_key`](slice::sort_unstable_by_key) पहा.
    ///
    /// # सध्याची अंमलबजावणी
    ///
    /// वर्तमान अल्गोरिदम हे [timsort](https://en.wikipedia.org/wiki/Timsort) द्वारे प्रेरित एक अनुकूली, पुनरावृत्ती विलय क्रम आहे.
    /// स्लाइस जवळजवळ क्रमवारीत असणार्‍या किंवा एकामागून दोन किंवा अधिक क्रमवारी लावलेल्या क्रमांकामध्ये अशी द्रुत रचना तयार केली गेली आहे.
    ///
    /// तसेच, हे `self` च्या अर्ध्या आकाराचे तात्पुरते स्टोरेजचे वाटप करते, परंतु लहान तुकड्यांसाठी त्याऐवजी विना-वाटप समाविष्ट करणे क्रमवारी वापरली जाते.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// की एक्सट्रॅक्शन फंक्शनसह स्लाइसची क्रमवारी लावते.
    ///
    /// क्रमवारी लावताना, की फंक्शन प्रति घटकास एकदाच म्हटले जाते.
    ///
    /// हा क्रमवारी स्थिर आहे (उदा. समान घटकांची पुन्हा क्रमवारी लावत नाही) आणि *ओ*(*मी*\* * एन *+ एन*\*एक्स00 एक्स सर्वात वाईट घटना आहे जिथे की फंक्शन* ओ *(* मी *) आहे .
    ///
    /// सोप्या की कार्यांसाठी (उदा. मालमत्ता प्रवेश किंवा मूलभूत ऑपरेशन्स अशी कार्ये), [`sort_by_key`](slice::sort_by_key) वेगवान होण्याची शक्यता आहे.
    ///
    /// # सध्याची अंमलबजावणी
    ///
    /// सध्याचे अल्गोरिदम ओरसन पीटर्सच्या एक्स 100 एक्स वर आधारित आहे, जे विशिष्ट नमुन्यांसह कापांवर रेषात्मक वेळ मिळविताना यादृच्छिक क्विटकोर्टच्या वेगवान सरासरी घटकास हेपसोर्टच्या सर्वात वाईट प्रकरणांसह एकत्र करते.
    /// हे अध: पतन होणारी प्रकरणे टाळण्यासाठी काही यादृच्छिकरण वापरते, परंतु नेहमी निरोधक वर्तन प्रदान करण्यासाठी निश्चित झेड सीड0झेड सह.
    ///
    /// सर्वात वाईट परिस्थितीत, अल्गोरिदम `Vec<(K, usize)>` मध्ये स्लाइसच्या लांबीमध्ये तात्पुरते स्टोरेज वाटप करते.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // आमचे vector सर्वात लहान संभाव्य प्रकारानुसार, वाटप कमी करण्यासाठी अनुक्रमित करण्यासाठी सहाय्यक मॅक्रो.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // अनुक्रमित केल्यानुसार एक्स00 एक्सचे घटक अद्वितीय आहेत, म्हणून मूळ स्लाइसच्या संदर्भात कोणताही क्रमवारी स्थिर असेल.
                // आम्ही येथे एक्स00 एक्स वापरतो कारण त्यासाठी कमी मेमरी वाटप आवश्यक आहे.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// नवीन `Vec` मध्ये `self` प्रती कॉपी करा.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // येथे `s` आणि `x` स्वतंत्रपणे सुधारित केले जाऊ शकतात.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Allocलोकरेटरसह नवीन `Vec` मध्ये `self` कॉपी करा.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // येथे `s` आणि `x` स्वतंत्रपणे सुधारित केले जाऊ शकतात.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // एनबी, अधिक तपशीलांसाठी या फाईलमधील एक्स 100 एक्स मॉड्यूल पहा.
        hack::to_vec(self, alloc)
    }

    /// क्लोन किंवा वाटप न करता `self` ला vector मध्ये रूपांतरित करते.
    ///
    /// परिणामी vector `Vec मार्गे परत बॉक्समध्ये रूपांतरित केले जाऊ शकते<T>ची `into_boxed_slice` पद्धत.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` यापुढे वापरले जाऊ शकत नाही कारण ते एक्स 100 एक्स मध्ये रूपांतरित झाले आहे.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // एनबी, अधिक तपशीलांसाठी या फाईलमधील एक्स 100 एक्स मॉड्यूल पहा.
        hack::into_vec(self)
    }

    /// एक स्लाईस `n` वेळा पुनरावृत्ती करुन एक vector तयार करते.
    ///
    /// # Panics
    ///
    /// क्षमता ओव्हरफ्लो झाल्यास हे कार्य panic करेल.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// ओव्हरफ्लो यावर एक panic:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // जर एक्स 0 एक्स एक्स शून्यापेक्षा मोठा असेल तर ते एक्स 100 एक्स म्हणून विभाजित केले जाऊ शकते.
        // `2^expn` `n` च्या डावीकडील '1' बिटद्वारे दर्शविलेले संख्या आहे आणि `rem` हे `n` चा उर्वरित भाग आहे.
        //
        //

        // `set_len()` वर प्रवेश करण्यासाठी `Vec` वापरणे.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` पुनरावृत्ती `buf`-एक्सपेंशन-वेळा दुप्पट करून केली जाते.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // `m > 0` असल्यास, डावीकडील '1' पर्यंत उर्वरित बिट आहेत.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` `self.len() * n` ची क्षमता आहे.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ विस्तारित) पुनरावृत्ती `buf` मधूनच प्रथम `rem` पुनरावृत्ती कॉपी करून केली जाते.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // हे `2^expn > rem` पासून नॉन-आच्छादित आहे.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` `buf.capacity()` (`= self.len() * n`)) इतके आहे.
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// `T` चा तुकडा सिंगल व्हॅल्यू `Self::Output` मध्ये चपटा करतो.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// `T` चा स्लाइस सिंगल व्हॅल्यू `Self::Output` मध्ये चपटा करतो, प्रत्येकामध्ये दिलेला विभाजक ठेवतो.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// `T` चा स्लाइस सिंगल व्हॅल्यू `Self::Output` मध्ये चपटा करतो, प्रत्येकामध्ये दिलेला विभाजक ठेवतो.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// या स्लाइसची प्रत असलेली एक vector मिळवते जिथे प्रत्येक बाइट त्याच्या एएससीआयआय अप्पर केस समकक्ष वर मॅप केले जाते.
    ///
    ///
    /// 'a' ते 'z' पर्यंत ASCII अक्षरे 'A' ते 'Z' पर्यंत मॅप केली गेली आहेत, परंतु ASCII नसलेली अक्षरे बदलली नाहीत.
    ///
    /// जागेचे मूल्य मोठ्या प्रमाणात घेण्यासाठी, [`make_ascii_uppercase`] वापरा.
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// या स्लाइसची प्रत असलेली झेडवेक्टोर0 झेड मिळवते जिथे प्रत्येक बाइट त्याच्या एएससीआयआय लोअर केस समकक्षांवर मॅप केले जाते.
    ///
    ///
    /// 'A' ते 'Z' पर्यंत ASCII अक्षरे 'a' ते 'z' पर्यंत मॅप केली गेली आहेत, परंतु ASCII नसलेली अक्षरे बदलली नाहीत.
    ///
    /// जागेचे मूल्य कमी करण्यासाठी, [`make_ascii_lowercase`] वापरा.
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// विशिष्ट प्रकारच्या डेटावर तुकड्यांसाठी झेडट्रेट्स 0 झेड विस्तारित करा
////////////////////////////////////////////////////////////////////////////////

/// [`[टी]: : कॉन्काट](स्लाइस::कॉंकट) साठी मदतनीस झेडट्रायट0 झेड.
///
/// Note: या trait मध्ये `Item` प्रकार मापदंड वापरला जात नाही, परंतु ते इम्पल्सला अधिक सामान्य बनविण्यास अनुमती देते.
/// त्याशिवाय ही त्रुटी आपल्याला मिळते.
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// याचे कारण असे की तेथे एकाधिक `Borrow<[_]>` आवरणासह `V` प्रकार अस्तित्वात असू शकतात, जसे की एकाधिक `T` प्रकार लागू होतीलः
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// काँटेन्टेशन नंतर परिणामी प्रकार
    type Output;

    /// [`[टी]: : कॉंकॅट`](स्लाइस::कॉंकॅट) ची अंमलबजावणी
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// [`[टी]: : जॉइन`](स्लाइस::जॉइन) साठी मदतनीस झेडट्रायट ० झेड
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// काँटेन्टेशन नंतर परिणामी प्रकार
    type Output;

    /// [`[टी]: : जॉइन`](स्लाइस::जॉइन) ची अंमलबजावणी
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// कापांसाठी मानक trait अंमलबजावणी
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // अधिलिखित केले जाऊ शकत नाही लक्ष्यात काहीही ड्रॉप
        target.truncate(self.len());

        // target.len <= self.len वरील काटकीमुळे
        //
        let (init, tail) = self.split_at(target.len());

        // समाविष्टीत मूल्ये allocations/resources पुन्हा वापरा.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// पूर्व-क्रमवारीबद्ध क्रम `v[1..]` मध्ये `v[0]` घालते जेणेकरुन संपूर्ण `v[..]` क्रमवारी लावा.
///
/// हे अंतर्भूत क्रमवारीची अविभाज्य सब्रूटिन आहे.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // येथे अंमलबजावणीचे तीन मार्ग आहेत:
            //
            // 1. प्रथम त्याच्या अंतिम गंतव्यस्थानी येईपर्यंत समीप घटक स्वॅप करा.
            //    तथापि, आम्ही आवश्यकतेपेक्षा जास्त डेटा कॉपी करतो.
            //    जर घटक मोठ्या रचना असतील (कॉपी करणे महाग असेल) तर ही पद्धत हळू होईल.
            //
            // 2. प्रथम घटकासाठी योग्य जागा सापडत नाही तोपर्यंत Iterate.
            // नंतर त्यास जागा बनविण्यासाठी त्यात यशस्वी होणारे घटक सरकवा आणि शेवटी उर्वरित छिद्रात ठेवा.
            // ही एक चांगली पद्धत आहे.
            //
            // 3. प्रथम घटकास तात्पुरत्या व्हेरिएबलमध्ये कॉपी करा.योग्य जागा सापडत नाही तोपर्यंत Iterate.
            // आम्ही पुढे जात असताना, प्रत्येक ट्रॅस्ड घटक त्यापूर्वीच्या स्लॉटमध्ये कॉपी करा.
            // शेवटी, तात्पुरत्या व्हेरिएबलमधून उर्वरित छिद्रात डेटा कॉपी करा.
            // ही पद्धत खूप चांगली आहे.
            // बेंचमार्कने 2 री पद्धतीपेक्षा काहीसे चांगले प्रदर्शन केले.
            //
            // सर्व पद्धती बेंचमार्क केल्या गेल्या आणि 3 रा उत्कृष्ट परिणाम दर्शविला.म्हणून आम्ही ते निवडले.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // अंतर्भूत प्रक्रियेची इंटरमिजिएट स्टेट नेहमीच एक्स00 एक्स द्वारे ट्रॅक केली जाते, जी दोन उद्देशांसाठी उपयुक्त आहे:
            // 1. `is_less` मधील panics पासून `v` च्या अखंडतेचे संरक्षण करते.
            // 2. शेवटी `v` मधील उर्वरित भोक भरा.
            //
            // Panic सुरक्षा:
            //
            // प्रक्रियेदरम्यान कोणत्याही क्षणी `is_less` panics असल्यास, `hole` सोडला जाईल आणि `v` मधील छिद्र `tmp` सह भरेल, अशाप्रकारे `v` ने सुरुवातीला एकदाच ठेवलेल्या प्रत्येक वस्तूची अजूनही खात्री आहे.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` सोडले जाते आणि अशा प्रकारे `v` मधील उर्वरित छिद्रात X01 एक्स कॉपी करते.
        }
    }

    // सोडल्यास `src` कडील `dest` मध्ये प्रती.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// `buf` तात्पुरते स्टोरेज म्हणून न वापरता कमी होत असलेल्या धावा `v[..mid]` आणि `v[mid..]` विलीन करते आणि परिणाम `v[..]` मध्ये संचयित करते.
///
/// # Safety
///
/// दोन स्लाइस रिक्त नसल्या पाहिजेत आणि `mid` मर्यादा असणे आवश्यक आहे.
/// छोट्या स्लाइसची प्रत ठेवण्यासाठी बफर `buf` लांब असणे आवश्यक आहे.
/// तसेच, `T` हा शून्य-आकाराचा प्रकार नसावा.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // विलीनीकरण प्रक्रियेची प्रथम `buf` मध्ये लहान धावण्याची प्रत बनते.
    // नंतर ते नवीन कॉपी केलेल्या धाव आणि अधिक धावपटू (किंवा मागे) पुढे शोधून काढतात, त्यांचे पुढील बिनशर्त घटकांची तुलना करून आणि त्यापेक्षा कमी (किंवा त्याहून अधिक) ची कॉपी X00 एक्स मध्ये करते.
    //
    // लहान धावण्याचा पूर्णपणे वापर झाल्यावर, प्रक्रिया पूर्ण केली जाते.जर लांब धावणे प्रथम खाल्ले तर आपण लहान धावातील जे काही शिल्लक आहे ते `v` मधील उर्वरित भोक मध्ये कॉपी करणे आवश्यक आहे.
    //
    // प्रक्रियेची इंटरमिजिएट स्टेट नेहमीच एक्स00 एक्स द्वारे ट्रॅक केली जाते, जी दोन उद्दीष्टे देते:
    // 1. `is_less` मधील panics पासून `v` च्या अखंडतेचे संरक्षण करते.
    // 2. जर मोठी धावपळ प्रथम वापरात राहिली तर उर्वरित छिद्र `v` मध्ये भरा.
    //
    // Panic सुरक्षा:
    //
    // प्रक्रियेदरम्यान कोणत्याही क्षणी `is_less` panics असल्यास, `hole` सोडला जाईल आणि `v` मधील छिद्र भरला जाईल `buf` मधील अनकॉन्स्ड रेंजसह, अशा प्रकारे `v` ने सुरुवातीला एकदाच ठेवलेल्या प्रत्येक वस्तूची अजूनही खात्री आहे.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // डावा धाव लहान आहे.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // सुरुवातीला हे पॉईंटर्स त्यांच्या अ‍ॅरेच्या सुरूवातीस सूचित करतात.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // कमी बाजूचे सेवन करा.
            // जर समान असेल तर स्थिरता राखण्यासाठी डाव्या धावला प्राधान्य द्या.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // योग्य धाव कमी आहे.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // सुरुवातीला हे पॉईंटर्स त्यांच्या अ‍ॅरेच्या शेवटच्या दिशेने जातात.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // मोठ्या बाजूचे सेवन करा.
            // जर समान असेल तर स्थिरता राखण्यासाठी योग्य धावण्यास प्राधान्य द्या.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // शेवटी, `hole` सोडले जाईल.
    // जर लहान धावा पूर्णपणे वापरली गेली नाहीत तर, त्यातील जे काही शिल्लक आहे ते आता एक्स00 एक्स मधील भोकमध्ये कॉपी केले जाईल.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // सोडल्यास, X01 एक्स श्रेणी `dest..` मध्ये कॉपी करते.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` हा शून्य-आकाराचा प्रकार नाही, म्हणून त्याच्या आकारानुसार विभाजित करणे ठीक आहे.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// या विलीनीकरण क्रमवारीत टीमसॉर्टकडून काही (परंतु सर्वच नाही) कल्पना घेतात, ज्याचे तपशीलवार वर्णन केले आहे एक्स00 एक्स.
///
///
/// अल्गोरिदम कठोरपणे खाली उतरत्या आणि उतरत्या नसलेल्या पुढील भागांना ओळखते, ज्यास नैसर्गिक धावा म्हणतात.विलीन होण्याच्या बाकी प्रलंबित धावांचा स्टॅक अद्याप आहे.
/// प्रत्येक नवीन सापडलेली धाव स्टॅकवर ढकलली जाते आणि नंतर या दोन आक्रमणकर्त्यांचे समाधान होईपर्यंत लगतच्या काही जोड्या जोडल्या जातात:
///
/// 1. `1..runs.len()` मधील प्रत्येक `i` साठी: `runs[i - 1].len > runs[i].len`
/// 2. `2..runs.len()` मधील प्रत्येक `i` साठी: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// आक्रमण करणार्‍यांनी हे सुनिश्चित केले की एकूण चालू वेळ *ओ*(*एन*\* एक्स00 एक्स) सर्वात वाईट घटना आहे.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // या लांबी पर्यंतचे स्लाइस समाविष्ट करणे क्रमवारी लावून क्रमवारी लावा.
    const MAX_INSERTION: usize = 20;
    // कमीतकमी या अनेक घटकांना विस्तृत करण्यासाठी इन्सर्ट सॉर्टचा वापर करून खूप लहान धावा वाढविल्या जातात.
    const MIN_RUN: usize = 10;

    // क्रमवारी लावणे शून्य-आकाराच्या प्रकारांवर अर्थपूर्ण वर्तन नाही.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // वाटप टाळण्यासाठी छोट्या अ‍ॅरे समाविष्ट क्रमवारीनुसार ठिकाणी लावल्या जातात.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // स्क्रॅच मेमरी म्हणून वापरण्यासाठी बफरचे वाटप करा.आम्ही लांबी 0 ठेवतो जेणेकरुन आम्ही त्यात `v` मधील सामग्रीच्या उथळ प्रती ठेवू शकतो ज्या `is_less` panics वर चालत असलेल्या डक्टरांना धोक्यात न घालता.
    //
    // दोन क्रमवारी लावलेले धावा विलीन करताना, या बफरकडे कमी धावांची प्रत असते, ज्याची लांबी नेहमीच `len / 2` असते.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // `v` मधील नैसर्गिक धावा ओळखण्यासाठी, आम्ही त्यास मागे वळत आहोत.
    // हा कदाचित एक विचित्र निर्णय असल्यासारखे वाटेल, परंतु विलीनीकरण जास्त वेळा उलट दिशेने जाणा X्या (forwards) वर विचार करा.
    // बेंचमार्कच्या मते, फॉरवर्ड विलीन करणे मागील दिशेने विलीन होण्यापेक्षा थोडा वेगवान आहे.
    // निष्कर्षापर्यंत, मागच्या बाजूस चाल करून धावा ओळखणे कार्यप्रदर्शन सुधारते.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // पुढील नैसर्गिक धाव शोधा आणि ती काटेकोरपणे खाली उतरत असल्यास उलट करा.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // खूपच लहान असल्यास धावमध्ये आणखी काही घटक घाला.
        // अंतर्भूत क्रमवारी लहान क्रमांकावर विलीन होण्यापेक्षा वेगवान आहे, यामुळे यामुळे कार्यक्षमतेत लक्षणीय सुधारणा होते.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // ही रन स्टॅकवर ढकल.
        runs.push(Run { start, len: end - start });
        end = start;

        // आक्रमणकर्त्यांचे समाधान करण्यासाठी लगतच्या काही जोड्या विलीन करा.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // शेवटी, नक्की एक धाव स्टॅकमध्येच राहिली पाहिजे.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // धावांच्या स्टॅकची तपासणी करते आणि विलीन होण्यासाठी पुढील जोड्यांची ओळख पटवते.
    // अधिक विशेषतः, जर `Some(r)` परत केले तर याचा अर्थ पुढील `runs[r]` आणि `runs[r + 1]` विलीन करणे आवश्यक आहे.
    // त्याऐवजी अल्गोरिदमने नवीन धाव तयार करणे सुरू ठेवल्यास, `None` परत येईल.
    //
    // येथे वर्णन केल्यानुसार टिमसोर्ट त्याच्या बग्गी अंमलबजावणीसाठी कुप्रसिद्ध आहे:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // कथेचा सारांश: आम्ही स्टॅकवर पहिल्या चार धावांवर आक्रमण करणार्‍यांची अंमलबजावणी करणे आवश्यक आहे.
    // त्यांना फक्त अव्वल तीनवर अंमलबजावणी करणे हे सुनिश्चित करण्यासाठी पुरेसे नाही की आक्रमणकर्ते अद्याप स्टॅकमध्ये *सर्व* धावा राखतील.
    //
    // हे कार्य शीर्ष चार धावांसाठी योग्य प्रकारे तपासणी करतात.
    // याव्यतिरिक्त, जर शीर्षांक निर्देशांक 0 वर प्रारंभ होत असेल तर, क्रमवारी पूर्ण करण्यासाठी, स्टॅक पूर्णपणे कोसळत नाही तोपर्यंत ते नेहमी विलीन ऑपरेशनची मागणी करेल.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}