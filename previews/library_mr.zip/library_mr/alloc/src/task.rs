#![stable(feature = "wake_trait", since = "1.51.0")]
//! असिंक्रोनस कार्यांसह कार्य करण्यासाठी प्रकार आणि झेडट्रेट 0 झेड.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// एक्झिक्युटरवर कार्य जागृत करण्याची अंमलबजावणी.
///
/// हे trait [`Waker`] तयार करण्यासाठी वापरले जाऊ शकते.
/// एखादा एक्झिक्युटर या झेडट्रायट ० झेडची अंमलबजावणी परिभाषित करू शकतो आणि त्या उपयोगकर्त्यावर कार्य केलेल्या कार्ये पार करण्यासाठी वॅकर तयार करण्यासाठी वापरु शकतो.
///
/// हे trait एक [`RawWaker`] तयार करण्यासाठी मेमरी-सेफ आणि एर्गोनोमिक पर्याय आहे.
/// हे सामान्य कार्यवाहक डिझाइनचे समर्थन करते ज्यात कार्य जागृत करण्यासाठी वापरलेला डेटा [`Arc`] मध्ये संग्रहित केला जातो.
/// काही एक्झिक्युटर्स (विशेषत: एम्बेड केलेल्या सिस्टमसाठी) हे एपीआय वापरू शकत नाहीत, म्हणूनच त्या सिस्टमसाठी पर्याय म्हणून एक्स00 एक्स अस्तित्त्वात आहे.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// एक मूलभूत एक्स00 एक्स फंक्शन जे झेडफ्यूचर 0 झेड घेते आणि सध्याच्या थ्रेडवर पूर्ण करण्यासाठी ते चालवते.
///
/// **Note:** हे उदाहरण साधेपणासाठी शुद्धतेचा व्यापार करते.
/// डेडलॉक टाळण्यासाठी, उत्पादन-ग्रेड अंमलबजावणीसाठी `thread::unpark` तसेच नेस्टेड विनंतीसाठी इंटरमीडिएट कॉल देखील हाताळणे आवश्यक आहे.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// कॉल केल्यावर वर्तमान धागा जागृत करणारा एक वॅकर
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// सद्य थ्रेडवर पूर्ण होण्यासाठी झेडफ्यूचर 0 झेड चालवा.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // झेडफ्यूचर 0 झेड पिन करा जेणेकरून ते मतदान केले जाऊ शकते.
///     let mut fut = Box::pin(fut);
///
///     // झेडफ्यूचर 0 झेडवर जाण्यासाठी एक नवीन संदर्भ तयार करा.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // पूर्ण करण्यासाठी future चालवा.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// हे कार्य जागृत करा.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// वेकरचे सेवन न करता हे कार्य करा.
    ///
    /// जर एखादा एक्झिक्युटरने वेकरचे सेवन न करता जाग येण्यासाठी स्वस्त मार्गाचा पाठिंबा दर्शविला असेल तर त्याने ही पद्धत अधिलिखित केली पाहिजे.
    /// डीफॉल्टनुसार, हे क्लोनवर [`Arc`] क्लोन करते आणि [`wake`] ला कॉल करते.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // सुरक्षितता: हे सुरक्षित आहे कारण कच्चे_वापर सुरक्षितपणे बांधकाम करतात
        // कच्चा पासून रॉ<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: याऐवजी रॉवॉकर बांधण्यासाठीचे हे खाजगी कार्य वापरले जाते
// `From<Arc<W>> for RawWaker` एक्सची सुरक्षा अचूक trait पाठवण्यावर अवलंबून नाही हे सुनिश्चित करण्यासाठी, यास `From<Arc<W>> for RawWaker` impl मध्ये अधोरेखित करणे याऐवजी दोन्ही आवाहन या कार्यास थेट आणि स्पष्टपणे कॉल करतात.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // क्लोन करण्यासाठी कमानाची संदर्भ संख्या वाढवा.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Wake::wake फंक्शनमध्ये आर्क हलवून मूल्यानुसार जागृत व्हा
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // संदर्भाने जागृत व्हा, वॅकर सोडण्यापासून टाळण्यासाठी मॅन्युअलीड्रॉपमध्ये लपेटून घ्या
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // ड्रॉप आर्कची संदर्भ संख्या कमी करा
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}