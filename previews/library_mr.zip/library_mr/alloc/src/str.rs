//! युनिकोड स्ट्रिंग स्लाइस.
//!
//! *[See also the `str` primitive type](str).*
//!
//! `&str` प्रकार हा दोन मुख्य स्ट्रिंग प्रकारांपैकी एक आहे, तर दुसरा एक्स 100 एक्स आहे.
//! त्याच्या `String` भागांच्या विपरीत, तिची सामग्री उधार घेतली गेली आहे.
//!
//! # मूलभूत वापर
//!
//! `&str` प्रकारची मूलभूत स्ट्रिंग घोषणा:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! येथे आम्ही स्ट्रिंगला अक्षरशः घोषित केले, ज्याला स्ट्रिंग स्लाइस असेही म्हणतात.
//! स्ट्रिंग लिटरल्सचा स्थिर जीवनकाळ असतो, ज्याचा अर्थ `hello_world` स्ट्रिंग संपूर्ण प्रोग्रामच्या कालावधीसाठी वैध असण्याची हमी असते.
//!
//! आम्ही `हॅलो_वर्ल्ड` चे आजीवन देखील स्पष्टपणे निर्दिष्ट करू शकतो:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// या मॉड्यूलमधील अनेक usies चाचणी कॉन्फिगरेशनमध्येच वापरली जातात.
// न वापरलेल्या_मार्गाच्या इशारेचे निराकरण करण्यापेक्षा केवळ चेतावणी बंद करणे हे क्लिनर आहे.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `Concat<str>` मधील `str` येथे अर्थपूर्ण नाही.
/// झेडट्रायट0 झेडचा हा प्रकार मापदंड केवळ दुसरा इम्प्ली सक्षम करण्यासाठी विद्यमान आहे.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // हार्डकोड आकारासह पळवाट लहान वेगळ्या लांबीच्या केसांना अधिक वेगवान चालवते
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // अनियंत्रित शून्य आकाराचा फॉलबॅक
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// ऑप्टिमाइझ जॉइन अंमलबजावणी जी दोन्ही व्ही.ई.सी.<T>(टी: कॉपी) आणि स्ट्रिंगची अंतर्गत तपासणी सध्या एक्स 100 एक्स मध्ये प्रकार आणि अनुमान (बॅक #36262 पहा) यासह एक बग आहे. या कारणास्तव स्लाईसकॉनकॅट<T>टीसाठी कॉपी केलेले नाहीः कॉपी आणि स्लाइसकॉनकॅट<str>या फंक्शनचा एकमेव वापरकर्ता आहे.
// ते निश्चित झाल्यावर ते त्या ठिकाणी ठेवले जाते.
//
// स्ट्रिंग-जॉइनची मर्यादा एस: बोन<str>आणि वैक-जॉइन बोनसाठी <[T]> [T] आणि str दोन्ही एएसआरफ <[टी]> काही टीसाठी
// => s.borrow().as_ref() आणि आमच्याकडे नेहमीच स्लाइस असतात
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // प्रथम स्लाइस फक्त त्यापूर्वी विभाजकविना आहे
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // सामील झालेल्या वेकच्या अचूक एकूण लांबीची गणना करा जर `len` गणना ओव्हरफ्लो झाली तर आम्ही झेडस्पॅनिक 0 झेड करू जेणेकरून आम्ही मेमरी संपली असती आणि उर्वरित कार्य सुरक्षेसाठी संपूर्ण व्हेक पूर्व-आवंटित करण्याची आवश्यकता आहे
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // एक निर्विवाद बफर तयार करा
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // छेद न करता विभाजक आणि तुकड्यांच्या प्रती कॉपी करा लहान विभाजकांसाठी हार्डकोड केलेल्या ऑफसेटसह लूप व्युत्पन्न करणे शक्य आहे (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // विचित्र कर्जाची अंमलबजावणी लांबी गणना आणि वास्तविक प्रत यासाठी वेगवेगळ्या काप परत करू शकते.
        //
        // आम्ही कॉलरकडे निर्विवाद बाइट उघडकीस आणत नसल्याचे सुनिश्चित करा.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// स्ट्रिंग स्लाइससाठी पद्धती.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// एक `Box<str>` कॉपी किंवा वाटप न करता `Box<[u8]>` मध्ये रूपांतरित करते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// नमुन्याचे सर्व सामने दुसर्‍या स्ट्रिंगसह पुनर्स्थित करते.
    ///
    /// `replace` एक नवीन [`String`] तयार करते आणि या स्ट्रिंगमधील डेटा त्यामध्ये कॉपी करतो.
    /// असे करत असताना, ते नमुन्याचे सामने शोधण्याचा प्रयत्न करतो.
    /// जर त्यास काही आढळले तर ते त्याऐवजी बदलीच्या स्ट्रिंगच्या स्लाइससह पुनर्स्थित करते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// जेव्हा नमुना जुळत नाही:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// दुसर्‍या स्ट्रिंगसह नमुन्याचे प्रथम एन सामने पुनर्स्थित करते.
    ///
    /// `replacen` एक नवीन [`String`] तयार करते आणि या स्ट्रिंगमधील डेटा त्यामध्ये कॉपी करतो.
    /// असे करत असताना, ते नमुन्याचे सामने शोधण्याचा प्रयत्न करतो.
    /// जर त्यास काही आढळले तर ते त्यांना बहुतेक `count` वेळा बदलण्याच्या स्ट्रिंग स्लाइससह पुनर्स्थित करते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// जेव्हा नमुना जुळत नाही:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // पुन्हा वाटपाचे वेळ कमी होईल अशी आशा आहे
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// नवीन स्ट्रिंग स्लाइसच्या लोअरकेस समांतर, नवीन [`String`] म्हणून मिळवते.
    ///
    /// 'Lowercase' युनिकोड व्युत्पन्न कोअर प्रॉपर्टी `Lowercase` च्या अटींनुसार परिभाषित केले आहे.
    ///
    /// केस बदलताना काही वर्ण एकाधिक वर्णांमध्ये विस्तारित होऊ शकतात, म्हणून हे कार्य स्थान बदलण्याऐवजी [`String`] मिळवते.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// सिग्मा असलेले एक अवघड उदाहरणः
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // परंतु शब्दाच्या शेवटी, हे ς आहे, नाही σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// केस नसलेल्या भाषा बदलल्या नाहीत:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Word वर नकाशे, शब्दाच्या शेवटी ज्या ठिकाणी ते maps नकाशे करते.
                // हे एकमेव सशर्त X01 एक्स आहे परंतु `SpecialCasing.txt` मधील भाषा-स्वतंत्र मॅपिंग आहे, जेनेरिक "condition" यंत्रणा नसण्याऐवजी त्यास कठोर कोड.
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // `Final_Sigma` च्या व्याख्येसाठी.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// या स्ट्रिंग स्लाइसच्या अपरकेसच्या समकक्ष, नवीन [`String`] म्हणून मिळवते.
    ///
    /// 'Uppercase' युनिकोड व्युत्पन्न कोअर प्रॉपर्टी `Uppercase` च्या अटींनुसार परिभाषित केले आहे.
    ///
    /// केस बदलताना काही वर्ण एकाधिक वर्णांमध्ये विस्तारित होऊ शकतात, म्हणून हे कार्य स्थान बदलण्याऐवजी [`String`] मिळवते.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// केस नसलेली स्क्रिप्ट बदलली नाहीत:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// एक वर्ण एकाधिक बनू शकते:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// एक [`Box<str>`] कॉपी किंवा वाटप न करता [`String`] मध्ये रूपांतरित करते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// `n` वेळा पुनरावृत्ती करुन नवीन [`String`] तयार करते.
    ///
    /// # Panics
    ///
    /// क्षमता ओव्हरफ्लो झाल्यास हे कार्य panic करेल.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// ओव्हरफ्लो यावर एक panic:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// या स्ट्रिंगची एक प्रत मिळवते जिथे प्रत्येक वर्ण त्याच्या ASCII अप्पर केस समतुल्यतेमध्ये मॅप केला जातो.
    ///
    ///
    /// 'a' ते 'z' पर्यंत ASCII अक्षरे 'A' ते 'Z' पर्यंत मॅप केली गेली आहेत, परंतु ASCII नसलेली अक्षरे बदलली नाहीत.
    ///
    /// जागेचे मूल्य मोठ्या प्रमाणात घेण्यासाठी, [`make_ascii_uppercase`] वापरा.
    ///
    /// एएससीआयआय नसलेल्या वर्ण व्यतिरिक्त एएससीआयआय वर्ण मोठ्या करण्यासाठी, एक्स00 एक्स वापरा.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() UTF-8 आक्रमणकर्ता संरक्षित करते.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// या स्ट्रिंगची प्रत मिळवते जिथे प्रत्येक वर्ण त्याच्या ASCII लोअर केस समतुल्यतेवर मॅप केला जातो.
    ///
    ///
    /// 'A' ते 'Z' पर्यंत ASCII अक्षरे 'a' ते 'z' पर्यंत मॅप केली गेली आहेत, परंतु ASCII नसलेली अक्षरे बदलली नाहीत.
    ///
    /// जागेचे मूल्य कमी करण्यासाठी, [`make_ascii_lowercase`] वापरा.
    ///
    /// एएससीआयआय नसलेल्या वर्ण व्यतिरिक्त एएससीआयआय वर्ण लहान करण्यासाठी, [`to_lowercase`] वापरा.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() UTF-8 आक्रमणकर्ता संरक्षित करते.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// बाइटच्या बॉक्सिंग स्लाइसला बॉक्सिंग स्ट्रिंगच्या स्लाइसमध्ये रुपांतरित करते ज्यामध्ये स्ट्रिंगमध्ये वैध UTF-8 आहे.
///
///
/// # Examples
///
/// मूलभूत वापर:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}