use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// स्त्रोत वाटप पुन्हा वापरताना वैक मध्ये इटररेटर पाइपलाइन गोळा करण्यासाठी स्पेशलायझेशन मार्कर
/// ठिकाणी पाईपलाईन चालवित आहे.
///
/// सोर्सआयटर पॅरंट झेडट्रायट0 झेड स्पेशलायझेशन फंक्शनसाठी accessलोकेशनमध्ये पुन्हा प्रवेश करण्यासाठी प्रवेश करणे आवश्यक आहे.
/// परंतु विशिष्टता वैध असणे पुरेसे नाही.
/// इम्प्ली वर अतिरिक्त मर्यादा पहा.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-अंतर्गत SourceIter/InPlaceIterable traits केवळ अ‍ॅडॉप्टरच्या साखळ्यांद्वारे लागू केले जाते <Adapter<Adapter<IntoIter>>> (सर्व core/std च्या मालकीचे आहेत)
// अ‍ॅडॉप्टर अंमलबजावणीवरील अतिरिक्त मर्यादा (`impl<I: Trait> Trait for Adapter<I>` च्या पलीकडे) केवळ इतर traits वर अवलंबून असते जे आधीपासूनच स्पेशलायझेशन traits (कॉपी, ट्रस्टर्डरँडॉम cessक्सेस, फ्यूजडिएटर) म्हणून चिन्हांकित केले गेले आहे.
//
// I.e. चिन्हक वापरकर्त्याने पुरविलेल्या प्रकारांच्या लाइफटाइमवर अवलंबून नाही.मॉड्यूल कॉपी कॉपी होल, ज्यावर इतर अनेक वैशिष्ट्ये यापूर्वीच अवलंबून आहेत.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // अतिरिक्त आवश्यकता जे trait bounds मार्गे व्यक्त करू शकत नाहीत.आम्ही त्याऐवजी कॉन्स्ट इवलवर अवलंबून असतोः
        // अ) झेडएसटी नाही कारण तेथे पुन्हा उपयोग करण्यासाठी कोणतेही वाटप होणार नाही आणि पॉईंटर अंकगणित झेडस्पॅनिक ० झेड बी) आकार जुळेल ए) करारानुसार आवश्यक संरेखन जुळवून घ्या) अलोक कराराद्वारे आवश्यकतेनुसार संरेखन
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // अधिक सामान्य अंमलबजावणीवर फॉलबॅक
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // तेव्हापासून प्रयत्न करा
        // - हे काही इट्रेटर अ‍ॅडॉप्टर्ससाठी चांगले वेक्टर करते
        // - बर्‍याच अंतर्गत पुनरावृत्ती पद्धतींच्या विपरीत, ते केवळ एक &mut स्व घेते
        // - हे आपल्या अंतर्भागात लेखन सूचक धागा टाकू देते आणि शेवटी ते परत मिळवू देते
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // पुनरावृत्ती यशस्वी झाली, डोके सोडू नका
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // सोर्सइटर कराराची खात्री आहे की नाही ते तपासा: ते नसते तर आम्ही या टप्प्यावरही येऊ शकत नाही
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // इनप्लेसइटेरेबल करार पहा.हे केवळ तेव्हाच शक्य आहे जर इटरेटरने स्त्रोत पॉईंटर मुळेच प्रगत केले.
        // जर हे ट्रस्टेड रँडम cessक्सेसद्वारे चेक न केलेला प्रवेश वापरत असेल तर स्त्रोत पॉईंटर त्याच्या प्रारंभिक स्थितीत राहील आणि आम्ही त्याचा संदर्भ म्हणून वापरू शकत नाही
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // उर्वरित मूल्ये स्त्रोताच्या शेपटीवर टाका पण एकदा ntoंटोस्टर क्षेत्राच्या बाहेर गेल्यास 0लोकेशन स्वतःच थांबविणे थांबवा, जर झेडस्पॅनिक्स ० झेड ड्रॉप केले तर आम्ही डीएसटी_ब्यूफमध्ये गोळा केलेले कोणतेही घटक गळती करतो.
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // येथे इनप्लेसइटेरेबल कराराची पडताळणी करता येणार नाही कारण ट्रायफोल्डचा स्त्रोत पॉईंटरचा एक विशिष्ट संदर्भ आहे आम्ही करू शकतो ते अद्याप श्रेणीत आहे का ते तपासा.
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}