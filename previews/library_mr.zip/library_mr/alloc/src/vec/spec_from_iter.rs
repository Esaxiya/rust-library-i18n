use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Vec::from_iter साठी वापरलेली विशेषीकरण trait
///
/// ## प्रतिनिधी आलेख:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // एक सामान्य प्रकरण म्हणजे vector ला एका फंक्शनमध्ये जात आहे जे झेडवेक्टर 0 झेडमध्ये त्वरित पुन्हा एकत्रित होते.
        // जर इंटोइटर अजिबात प्रगत केले नसल्यास आपण हा शॉर्ट सर्किट करू शकतो.
        // जेव्हा हे प्रगत होते तेव्हा आम्ही मेमरीचा पुन्हा वापर करू शकतो आणि डेटा समोर ठेवू शकतो.
        // परंतु आम्ही केवळ तेव्हाच करतो जेव्हा परिणामी व्हीसीकडे सर्वसाधारण फ्रिइटररेटर अंमलबजावणीद्वारे तयार करण्यापेक्षा अधिक न वापरलेली क्षमता नसते.
        //
        // ही मर्यादा काटेकोरपणे आवश्यक नाही कारण वेकचे वाटप वर्तन हेतूपूर्वक अनिर्दिष्ट केले गेले आहे.
        // पण ती एक पुराणमतवादी निवड आहे.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // spec_extend() ने स्वतः रिक्त Vecs साठी विशिष्ट_प्रति प्रतिनिधी म्हणून spec_extend() ला प्रतिनिधीत्व केले पाहिजे
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// हे एक्स00 एक्सचा उपयोग करते कारण स्पेक्ट एक्सटेन्डने अंतिम क्षमता + लांबीबद्दल तर्क करण्यासाठी अधिक पावले उचलणे आवश्यक आहे आणि अशा प्रकारे अधिक कार्य करणे आवश्यक आहे.
// `to_vec()` थेट योग्य रक्कम वाटप करते आणि ती अगदी भरते.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): cfg(test) सह अंतर्भूत `[T]::to_vec` पद्धत, जी या पद्धतीच्या परिभाषासाठी आवश्यक आहे, उपलब्ध नाही.
    // त्याऐवजी `slice::to_vec` फंक्शन वापरा जे फक्त cfg(test) NB सह उपलब्ध आहे अधिक माहितीसाठी slice.rs मधील slice::hack मॉड्यूल पहा
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}