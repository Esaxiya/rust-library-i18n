use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// आच्छादित वैशिष्ट्यांकरिता व्यक्तिचलितपणे व्यक्तिचलितपणे आवश्यक असलेल्या एक्स 100 एक्ससाठी आणखी एक विशेषज्ञता झेडट्रायट 0 झेड तपशीलांसाठी एक्स01 एक्स पहा.
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // पहिल्या पुनरावृत्तीची नोंदणी रद्द करा, कारण जेव्हा पुनरावृत्ती करण्यायोग्य रिक्त नसते तेव्हा प्रत्येक प्रकरणात झेडवेक्टोर0 झेड या पुनरावृत्तीवर विस्तारित केले जात आहे, परंतु एक्स00 एक्स मधील पळवाट त्यानंतरच्या काही लूप पुनरावृत्तींमध्ये झेडवेक्टोर0झेड पूर्ण भरलेला दिसत नाही.
        //
        // म्हणून आम्हाला झेडब्रेन्च 0 झेडचा अधिक चांगला अंदाज येतो.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // spec_extend() ने स्वतः रिक्त Vecs साठी विशिष्ट_प्रति प्रतिनिधी म्हणून spec_extend() ला प्रतिनिधीत्व केले पाहिजे
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // spec_extend() ने स्वतः रिक्त Vecs साठी विशिष्ट_प्रति प्रतिनिधी म्हणून spec_extend() ला प्रतिनिधीत्व केले पाहिजे
        //
        vector.spec_extend(iterator);
        vector
    }
}