// जेव्हा `SetLenOnDrop` मूल्य व्याप्तीच्या बाहेर जाईल तेव्हा व्हॅकची लांबी सेट करा.
//
// कल्पना अशीः सेटलएनऑनड्रॉप मधील लांबी फील्ड हे स्थानिक व्हेरिएबल आहे जे ऑप्टिमाइझरला दिसेल की वेकच्या डेटा पॉईंटरद्वारे कोणत्याही स्टोअरमध्ये उर्फ नाही.
// हे उर्फ अ‍ॅनालिसिस इश्यू #32155 साठीचे कार्य आहे
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}