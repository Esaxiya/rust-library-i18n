//! हेप-वाटप केलेल्या सामग्रीसह, लिखित `Vec<T>` असलेला एक सतत वाढणारा अ‍ॅरे प्रकार.
//!
//! झेडवेक्टर्स0 झेडमध्ये एक्स 100 एक्स इंडेक्सिंग, एमोराइज्ड एक्स 0 एक्स एक्स पुश (शेवटपर्यंत) आणि एक्स0 2 एक्स पॉप (अंत पासून) आहे.
//!
//!
//! झेडवेक्टर्स0 झेड हे सुनिश्चित करतात की ते कधीही एक्स 100 एक्स बाइटपेक्षा जास्त वाटप करत नाहीत.
//!
//! # Examples
//!
//! आपण स्पष्टपणे [`Vec::new`] सह एक [`Vec`] तयार करू शकता:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... किंवा [`vec!`] मॅक्रो वापरुन:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // दहा शून्य
//! ```
//!
//! आपण vector च्या शेवटी [`push`] ची मूल्ये काढू शकता (जे vector आवश्यकतेनुसार वाढेल):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! पॉपिंग व्हॅल्यूज त्याच प्रकारे कार्य करते:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors देखील अनुक्रमणिका समर्थित करते ([`Index`] आणि [`IndexMut`] traits मार्गे):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// `Vec<T>` आणि उच्चारित 'vector' म्हणून लिहिलेला एक सतत वाढणारा अ‍ॅरे प्रकार.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// [`vec!`] मॅक्रो आरंभिकरण अधिक सोयीस्कर करण्यासाठी प्रदान केले गेले आहे:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// हे दिलेल्या मूल्यासह `Vec<T>` चे प्रत्येक घटक प्रारंभ करू शकते.
/// स्वतंत्र चरणांमध्ये वाटप आणि आरंभ करण्यापेक्षा हे अधिक कार्यक्षम असू शकते, विशेषत: झिरोच्या झेडवेक्टर 0 झेड सुरू करताना:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // खाली समतुल्य आहे, परंतु संभाव्य हळू:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// अधिक माहितीसाठी, [Capacity and Reallocation](#capacity-and-reallocation) पहा.
///
/// कार्यक्षम स्टॅक म्हणून `Vec<T>` वापरा:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // प्रिंट्स 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// एक्स 100 एक्स प्रकार अनुक्रमणिकेनुसार मूल्यांमध्ये प्रवेश करण्यास अनुमती देते, कारण ते एक्स 0 एक्स एक्स झेडट्रायट 0 झेड लागू करते.एक उदाहरण अधिक स्पष्ट होईल:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // हे '2' प्रदर्शित करेल
/// ```
///
/// तथापि सावधगिरी बाळगा: जर आपण `Vec` मध्ये नसलेल्या निर्देशांकात प्रवेश करण्याचा प्रयत्न केला तर आपले सॉफ्टवेअर panic करेल!आपण हे करू शकत नाही:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// आपण निर्देशांक `Vec` मध्ये आहे की नाही हे तपासू इच्छित असल्यास [`get`] आणि [`get_mut`] वापरा.
///
/// # Slicing
///
/// एक `Vec` बदलू शकतो.दुसरीकडे, काप फक्त-वाचनीय वस्तू आहेत.
/// [slice][prim@slice] मिळविण्यासाठी, [`&`] वापरा.उदाहरणः
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... आणि हे सर्व आहे!
/// // आपण हे असे देखील करू शकता:
/// let u: &[usize] = &v;
/// // किंवा हे आवडले:
/// let u: &[_] = &v;
/// ```
///
/// Rust मध्ये, जेव्हा आपल्याला फक्त वाचन प्रवेश प्रदान करायचा असेल तेव्हा झेडवेक्टर्स0 झेडपेक्षा तर्क वितर्क म्हणून कापणे अधिक सामान्य आहे.हेच [`String`] आणि [`&str`] साठी आहे.
///
/// # क्षमता आणि रीलोकेशन
///
/// vector ची क्षमता vector वर जोडल्या जाणार्‍या कोणत्याही future घटकांसाठी वाटप केलेल्या जागेचे प्रमाण आहे.vector च्या *लांबी* सह गोंधळ होऊ नये, जे vector मधील वास्तविक घटकांची संख्या निर्दिष्ट करते.
/// जर झेडवेक्टोर0 झेडची लांबी त्याच्या क्षमतेपेक्षा जास्त झाली तर त्याची क्षमता आपोआप वाढेल, परंतु त्यातील घटक पुन्हा रिकॉल करावे लागतील.
///
/// उदाहरणार्थ, क्षमता 10 आणि लांबी 0 असलेले झेडवेक्टोर0 झेड 10 अधिक घटकांसाठी रिक्त झेडवेक्टर 0 झेड असेल.vector वर 10 किंवा त्याहून कमी घटक ढकलण्यामुळे त्याची क्षमता बदलणार नाही किंवा पुनर्वापर होण्यास कारणीभूत ठरणार नाही.
/// तथापि, झेडवेक्टर 0 झेडची लांबी 11 पर्यंत वाढविल्यास, ती पुन्हा मोजावी लागेल, जी धीमे होऊ शकते.या कारणास्तव, vector किती मोठे मिळण्याची अपेक्षा आहे हे निर्दिष्ट करण्यासाठी जेव्हा शक्य असेल तेव्हा [`Vec::with_capacity`] वापरण्याची शिफारस केली जाते.
///
/// # Guarantees
///
/// त्याच्या आश्चर्यकारक मूलभूत स्वरूपामुळे, एक्स 0 एक्स त्याच्या डिझाइनबद्दल बर्‍याच हमी देते.हे सुनिश्चित करते की सामान्य बाबतीत हे शक्य तितके कमी-ओव्हरहेड आहे आणि असुरक्षित कोडद्वारे आदिम मार्गांनी योग्यरित्या हाताळले जाऊ शकते.लक्षात घ्या की या हमी एक पात्र नसलेल्या `Vec<T>` चा संदर्भ घेतात.
/// अतिरिक्त प्रकारचे मापदंड जोडले असल्यास (उदा. सानुकूल वाटप करणार्‍याचे समर्थन करण्यासाठी), त्यांच्या डीफॉल्टच्या ओव्हरराइडिंगने वर्तन बदलू शकते.
///
/// मूलभूतपणे, `Vec` आहे आणि नेहमीच (पॉईंटर, क्षमता, लांबी) त्रिकूट असेल.ना कमी ना जास्त.या फील्ड्सची क्रम पूर्णपणे अनिर्दिष्ट आहे आणि आपण त्या सुधारित करण्यासाठी योग्य पद्धती वापरल्या पाहिजेत.
/// पॉईंटर कधीही अशक्त होणार नाही, म्हणून हा प्रकार शून्य-सूचक-अनुकूलित आहे.
///
/// तथापि, पॉईंटर प्रत्यक्षात वाटप केलेल्या मेमरीकडे निर्देश करू शकत नाही.
/// विशेषतः, आपण [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`] मार्गे 0 क्षमतेसह किंवा [`shrink_to_fit`] ला रिक्त Vec वर कॉल केल्यास, ते मेमरीचे वाटप करणार नाही.त्याचप्रमाणे, आपण `Vec` मध्ये शून्य-आकाराचे प्रकार संग्रहित केल्यास ते त्यांच्यासाठी जागा वाटप करणार नाही.
/// *लक्षात घ्या की या प्रकरणात `Vec` 0* च्या [`capacity`] नोंदवू शकत नाही.
/// `Vec` तर आणि फक्त [`मेम: : आकार_::<T>`]`() * capacity()> 0`.
/// सर्वसाधारणपणे, `वेकाचे वाटप तपशील खूप सूक्ष्म आहेत-जर आपण `Vec` वापरुन मेमरीचे वाटप करायचे आणि त्या दुसर्‍या कशासाठी वापरली असल्यास (एकतर असुरक्षित कोड पास करणे किंवा आपल्या स्वत: च्या मेमरी-बॅकड संग्रह तयार करणे) निश्चित करा `Vec` पुनर्प्राप्त करण्यासाठी `from_raw_parts` चा वापर करून आणि नंतर त्यास सोडुन ही मेमरी नष्ट करणे.
///
/// जर एखाद्या `Vec`*ने* वाटप केलेली मेमरी असेल तर ती जी मेमरी दाखवते ती ढीग वर असते (theलोकटर द्वारा परिभाषित केल्यानुसार Rust डीफॉल्टनुसार वापरण्यासाठी कॉन्फिगर केली जाते), आणि पॉईंटर [`len`] इनिशियलाइज्ड, संमिश्र घटकांना क्रमाने निर्देशित करतो (आपण काय कराल आपण त्यास एका स्लाइसवर भाग पाडले आहे का ते पहा), त्यानंतर [`क्षमता`]`,`[` लेनि] तार्किकरित्या निर्विवाद, संबद्ध घटक.
///
///
/// क्षेड 4 सह `'a'` आणि `'b'` घटक असलेले झेडवेक्टर 0 झेड खाली दर्शविले जाऊ शकते.सर्वात वरचा भाग `Vec` स्ट्रक्चर आहे, त्यात ढीग, लांबी आणि क्षमता मध्ये वाटप च्या डोक्यावर एक पॉईंटर आहे.
/// तळाचा भाग म्हणजे ढीगांवर वाटप, एक अविरत स्मृती ब्लॉक.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **अननिट** प्रारंभ केलेली नसलेली मेमरी दर्शवते, [`MaybeUninit`] पहा.
/// - Note: एबीआय स्थिर नाही आणि `Vec` त्याच्या मेमरी लेआउटबद्दल (फील्डच्या क्रमासह) कोणतीही हमी देत नाही.
///
/// `Vec` जिथे घटक दोन कारणास्तव स्टॅकवर प्रत्यक्षात साठवले जातात तेथे "small optimization" कधीही करणार नाही:
///
/// * असुरक्षित कोडसाठी `Vec` योग्यरित्या हाताळणे अधिक कठिण होईल.केवळ हलविल्यास `Vec` मधील सामग्रीचा स्थिर पत्ता नसतो आणि `Vec` ने मेमरीचे वाटप केले आहे की नाही हे निश्चित करणे अधिक अवघड आहे.
///
/// * हे प्रत्येक प्रवेशासाठी अतिरिक्त झेडब्राँक 0 झेडच्या सामान्य प्रकरणात दंड आकारेल.
///
/// `Vec` पूर्णपणे रिक्त असले तरीही कधीही स्वयंचलितरित्या संकुचित होणार नाही.हे सुनिश्चित करते की अनावश्यक वाटप किंवा विपुलता होणार नाही.एक X01 एक्स रिकामी करणे आणि नंतर त्याच [`len`] पर्यंत परत भरणे theलोटरला कॉल करु नये.आपण न वापरलेली मेमरी मोकळी करू इच्छित असल्यास, [`shrink_to_fit`] किंवा [`shrink_to`] वापरा.
///
/// [`push`] आणि अहवाल दिलेली क्षमता पुरेसे असल्यास [`insert`] कधीही (पुन्हा) वाटप करणार नाही.[`push`] आणि [`insert`]*[re लेन] `==` [`क्षमता`] असल्यास*(पुन्हा) वाटप करेल.म्हणजेच, नोंदविलेली क्षमता पूर्णपणे अचूक आहे आणि त्यावर अवलंबून राहू शकते.हे इच्छित असल्यास `Vec` ने दिलेली मेमरी मॅन्युअली मोकळी करण्यासाठी देखील वापरली जाऊ शकते.
/// बल्क समाविष्ट करण्याच्या पद्धती *आवश्यक नसतानाही* पुन्हा सांगू शकतात.
///
/// `Vec` पूर्ण झाल्यावर रीलोकेशन करताना किंवा एक्स ०१ एक्स कॉल केल्यावर कोणत्याही विशिष्ट वाढीच्या धोरणाची हमी देत नाही.सध्याची रणनीती मूलभूत आहे आणि अ-स्थिर वाढीचा घटक वापरणे इष्ट आहे.कोणतीही रणनीती वापरली जाईल याची हमी नक्कीच *ओ*(1) एमोराइज्ड एक्स 100 एक्सची असेल.
///
/// `vec![x; n]`, `vec![a, b, c, d]` आणि [`Vec::with_capacity(n)`][`Vec::with_capacity`] सर्वजण विनंती केलेल्या क्षमतेसह एक `Vec` तयार करतात.
/// [`Len`]`==`[`क्षमता`], ([`vec!`] मॅक्रोसाठी जसे आहे तसे) असल्यास, घटकांना पुन्हा न सांगता किंवा हलविल्याशिवाय, एक `Vec<T>` मध्ये आणि [`Box<[T]>`][owned slice] मधून रूपांतरित केले जाऊ शकते.
///
/// `Vec` त्यातून काढलेला कोणताही डेटा विशेषतः अधिलिखित करणार नाही, परंतु त्यास तो विशेषतः जतन देखील करणार नाही.त्याची इनिटिटलाइझ्ड मेमरी ही स्क्रॅच स्पेस आहे जी कदाचित ती वापरू शकते.हे सामान्यत: जे कार्यक्षम किंवा अंमलात आणण्यास सुलभ असेल ते करेल.सुरक्षिततेच्या उद्देशाने नष्ट केल्या जाणार्‍या डेटावर अवलंबून राहू नका.
/// आपण `Vec` सोडला तरीही, त्याचा बफर सहजपणे दुसर्‍या `Vec` द्वारे पुन्हा वापरला जाऊ शकतो.
/// जरी आपण प्रथम व्हॅकची मेमरी शून्य केली तरीही ते प्रत्यक्षात घडू शकत नाही कारण ऑप्टिमाइझरने जतन करणे आवश्यक असलेला हा दुष्परिणाम मानला नाही.
/// असे एक प्रकरण आहे जे आम्ही खंडित करणार नाही, तथापिः अत्यधिक क्षमतेवर लिहिण्यासाठी `unsafe` कोड वापरणे आणि नंतर जुळण्यासाठी लांबी वाढविणे नेहमीच वैध असते.
///
/// सध्या, एक्स 100 एक्स ज्यामध्ये घटक सोडले गेले आहेत याची हमी देत नाही.
/// यापूर्वी ऑर्डर बदलली आहे आणि पुन्हा बदलू शकतात.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// जन्मजात पद्धती
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// नवीन, रिक्त `Vec<T>` तयार करते.
    ///
    /// घटकांवर दबाव आणल्याशिवाय vector वाटप करणार नाही.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// निर्दिष्ट क्षमतेसह नवीन, रिक्त `Vec<T>` तयार करते.
    ///
    /// vector रीलोकेशिवाय अचूक `capacity` घटक ठेवण्यात सक्षम होईल.
    /// जर `capacity` 0 असेल तर vector वाटप करणार नाही.
    ///
    /// हे लक्षात घेणे महत्वाचे आहे की परत आलेल्या vector मध्ये *क्षमता* निर्दिष्ट केली गेली असली तरी, vector ची शून्य *लांबी* असेल.
    ///
    /// लांबी आणि क्षमता यांच्यातील फरक स्पष्ट करण्यासाठी,*[क्षमता आणि रीलोकेशन]* पहा.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector मध्ये अधिक आयटम नसले तरीही त्यात कोणतेही आयटम नाहीत
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // हे सर्व पुन्हा न सांगता करता आले ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... परंतु यामुळे vector रीलोकेट होऊ शकते
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// दुसर्‍या vector च्या कच्च्या घटकांपासून थेट एक `Vec<T>` तयार करते.
    ///
    /// # Safety
    ///
    /// हे अत्यंत असुरक्षित आहे, तपासणी न केलेल्या हल्ल्यांच्या संख्येमुळे:
    ///
    /// * `ptr` यापूर्वी [`स्ट्रिंग`]/`व्हेईसी मार्फत वाटप करणे आवश्यक आहे<T>`(कमीतकमी ते नसल्यास हे चुकीचे असू शकते.)
    /// * `T` `ptr` चे वाटप केले त्याप्रमाणे आकार आणि संरेखन असणे आवश्यक आहे.
    ///   (`T` कमी कठोर संरेखन असणे पुरेसे नाही, [`dealloc`] ची आवश्यकता पूर्ण करण्यासाठी संरेखन खरोखर समान असणे आवश्यक आहे की मेमरीचे वाटप केले पाहिजे आणि त्याच लेआउटसह विकृत केले जाणे आवश्यक आहे.)
    ///
    /// * `length` `capacity` पेक्षा कमी किंवा समान असणे आवश्यक आहे.
    /// * `capacity` पॉईंटर ने वाटप केलेली क्षमता असणे आवश्यक आहे.
    ///
    /// या उल्लंघन केल्याने वाटप करणार्‍याच्या अंतर्गत डेटा स्ट्रक्चर्समध्ये भ्रष्ट होणे यासारख्या समस्या उद्भवू शकतात.उदाहरणार्थ **नाही** लांबी `size_t` सह पॉइंटरपासून सी एक्स02 एक्स अ‍ॅरे पर्यंत एक्स 01 एक्स तयार करणे सुरक्षित नाही.
    /// हे `Vec<u16>` व त्याची लांबी तयार करणे देखील सुरक्षित नाही, कारण वाटप करणार्‍याला संरेखनाची काळजी असते आणि या दोन प्रकारांमध्ये भिन्न संरेखन असते.
    /// बफर संरेखन 2 सह (`u16` साठी) वाटप केले गेले, परंतु ते `Vec<u8>` मध्ये बदलल्यानंतर ते संरेखन 1 ने कमी केले जाईल.
    ///
    /// `ptr` ची मालकी प्रभावीपणे `Vec<T>` वर हस्तांतरित केली गेली आहे जी नंतर पॉईंटरद्वारे दर्शविलेल्या मेमरीची सामग्री विखुरली, पुन्हा गमावू किंवा बदलू शकते.
    /// हे कार्य कॉल केल्यावर दुसरे काहीही पॉईंटर वापरत नाही याची खात्री करा.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FCXME vec_into_raw_parts स्थीर झाल्यावर हे अद्यतनित करा.
    ///     // Running v` च्या डिस्ट्रक्टरला चालविणे प्रतिबंधित करा जेणेकरून आमच्याकडे वाटप पूर्ण नियंत्रणात असेल.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // `v` बद्दल माहितीचे विविध महत्त्वाचे भाग बाहेर काढा
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // 4, 5, 6 सह मेमरी ओव्हरराइट करा
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // सर्वकाही परत एक व्हेईसी मध्ये एकत्र करा
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// नवीन, रिक्त `Vec<T, A>` तयार करते.
    ///
    /// घटकांवर दबाव आणल्याशिवाय vector वाटप करणार नाही.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// प्रदान केलेल्या allocलोकटरसह निर्दिष्ट क्षमतेसह नवीन, रिक्त `Vec<T, A>` तयार करते.
    ///
    /// vector रीलोकेशिवाय अचूक `capacity` घटक ठेवण्यात सक्षम होईल.
    /// जर `capacity` 0 असेल तर vector वाटप करणार नाही.
    ///
    /// हे लक्षात घेणे महत्वाचे आहे की परत आलेल्या vector मध्ये *क्षमता* निर्दिष्ट केली गेली असली तरी, vector ची शून्य *लांबी* असेल.
    ///
    /// लांबी आणि क्षमता यांच्यातील फरक स्पष्ट करण्यासाठी,*[क्षमता आणि रीलोकेशन]* पहा.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector मध्ये अधिक आयटम नसले तरीही त्यात कोणतेही आयटम नाहीत
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // हे सर्व पुन्हा न सांगता करता आले ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... परंतु यामुळे vector रीलोकेट होऊ शकते
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// दुसर्‍या vector च्या कच्च्या घटकांपासून थेट एक `Vec<T, A>` तयार करते.
    ///
    /// # Safety
    ///
    /// हे अत्यंत असुरक्षित आहे, तपासणी न केलेल्या हल्ल्यांच्या संख्येमुळे:
    ///
    /// * `ptr` यापूर्वी [`स्ट्रिंग`]/`व्हेईसी मार्फत वाटप करणे आवश्यक आहे<T>`(कमीतकमी ते नसल्यास हे चुकीचे असू शकते.)
    /// * `T` `ptr` चे वाटप केले त्याप्रमाणे आकार आणि संरेखन असणे आवश्यक आहे.
    ///   (`T` कमी कठोर संरेखन असणे पुरेसे नाही, [`dealloc`] ची आवश्यकता पूर्ण करण्यासाठी संरेखन खरोखर समान असणे आवश्यक आहे की मेमरीचे वाटप केले पाहिजे आणि त्याच लेआउटसह विकृत केले जाणे आवश्यक आहे.)
    ///
    /// * `length` `capacity` पेक्षा कमी किंवा समान असणे आवश्यक आहे.
    /// * `capacity` पॉईंटर ने वाटप केलेली क्षमता असणे आवश्यक आहे.
    ///
    /// या उल्लंघन केल्याने वाटप करणार्‍याच्या अंतर्गत डेटा स्ट्रक्चर्समध्ये भ्रष्ट होणे यासारख्या समस्या उद्भवू शकतात.उदाहरणार्थ **नाही** लांबी `size_t` सह पॉइंटरपासून सी एक्स02 एक्स अ‍ॅरे पर्यंत एक्स 01 एक्स तयार करणे सुरक्षित नाही.
    /// हे `Vec<u16>` व त्याची लांबी तयार करणे देखील सुरक्षित नाही, कारण वाटप करणार्‍याला संरेखनाची काळजी असते आणि या दोन प्रकारांमध्ये भिन्न संरेखन असते.
    /// बफर संरेखन 2 सह (`u16` साठी) वाटप केले गेले, परंतु ते `Vec<u8>` मध्ये बदलल्यानंतर ते संरेखन 1 ने कमी केले जाईल.
    ///
    /// `ptr` ची मालकी प्रभावीपणे `Vec<T>` वर हस्तांतरित केली गेली आहे जी नंतर पॉईंटरद्वारे दर्शविलेल्या मेमरीची सामग्री विखुरली, पुन्हा गमावू किंवा बदलू शकते.
    /// हे कार्य कॉल केल्यावर दुसरे काहीही पॉईंटर वापरत नाही याची खात्री करा.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FCXME vec_into_raw_parts स्थीर झाल्यावर हे अद्यतनित करा.
    ///     // Running v` च्या डिस्ट्रक्टरला चालविणे प्रतिबंधित करा जेणेकरून आमच्याकडे वाटप पूर्ण नियंत्रणात असेल.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // `v` बद्दल माहितीचे विविध महत्त्वाचे भाग बाहेर काढा
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // 4, 5, 6 सह मेमरी ओव्हरराइट करा
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // सर्वकाही परत एक व्हेईसी मध्ये एकत्र करा
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// एक `Vec<T>` त्याच्या कच्च्या घटकांमध्ये विघटित करते.
    ///
    /// मूळ डेटाकडे कच्चा पॉईंटर, vector लांबी (घटकांमध्ये) आणि डेटाची वाटप क्षमता (घटकांमध्ये) मिळवते.
    /// हे त्याच क्रमाने [`from_raw_parts`] ला वितर्क म्हणून समान वितर्क आहेत.
    ///
    /// या फंक्शनला कॉल केल्यानंतर, कॉलर पूर्वी एक्स00 एक्स द्वारे व्यवस्थापित केलेल्या मेमरीसाठी जबाबदार आहे.
    /// हे करण्याचा एकमेव मार्ग म्हणजे कच्चा पॉइंटर, लांबी आणि क्षमता परत एक्स 100 एक्स मध्ये एक्स01 एक्स फंक्शनसह रुपांतरित करणे, ज्यामुळे डिस्ट्रक्टरला क्लिनअप करण्यास परवानगी दिली जाते.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // आम्ही आता घटकांमध्ये बदल करू शकतो, जसे की कच्चा पॉइंटर एक सुसंगत प्रकारात हस्तांतरित करतो.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// एक `Vec<T>` त्याच्या कच्च्या घटकांमध्ये विघटित करते.
    ///
    /// मूळ डेटा, कच्चा पॉइंटर, झेडवेक्टर 0 झेडची लांबी (घटकांमध्ये), डेटाची वाटप केलेली क्षमता (घटकांमध्ये) आणि theलोटरला मिळवते.
    /// हे त्याच क्रमाने [`from_raw_parts_in`] ला वितर्क म्हणून समान वितर्क आहेत.
    ///
    /// या फंक्शनला कॉल केल्यानंतर, कॉलर पूर्वी एक्स00 एक्स द्वारे व्यवस्थापित केलेल्या मेमरीसाठी जबाबदार आहे.
    /// हे करण्याचा एकमेव मार्ग म्हणजे कच्चा पॉइंटर, लांबी आणि क्षमता परत एक्स 100 एक्स मध्ये एक्स01 एक्स फंक्शनसह रुपांतरित करणे, ज्यामुळे डिस्ट्रक्टरला क्लिनअप करण्यास परवानगी दिली जाते.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // आम्ही आता घटकांमध्ये बदल करू शकतो, जसे की कच्चा पॉइंटर एक सुसंगत प्रकारात हस्तांतरित करतो.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// vector परत न बोलता ठेवू शकणार्‍या घटकांची संख्या मिळवते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// दिलेल्या `Vec<T>` मध्ये कमीतकमी `additional` अधिक घटक समाविष्ट करण्यासाठी क्षमता राखीव आहे.
    /// वारंवार पुनर्विक्री टाळण्यासाठी संकलनात अधिक जागा राखीव असू शकते.
    /// `reserve` वर कॉल केल्यानंतर, क्षमता `self.len() + additional` पेक्षा मोठी किंवा समान असेल.
    /// क्षमता आधीच पुरेशी असल्यास काहीही करत नाही.
    ///
    /// # Panics
    ///
    /// नवीन क्षमता `isize::MAX` बाइटपेक्षा अधिक असल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// दिलेल्या `Vec<T>` मध्ये अचूक `additional` अधिक घटक समाविष्ट करण्यासाठी किमान क्षमता राखून ठेवते.
    ///
    /// `reserve_exact` वर कॉल केल्यानंतर, क्षमता `self.len() + additional` पेक्षा मोठी किंवा समान असेल.
    /// क्षमता आधीच पुरेशी असल्यास काहीही करत नाही.
    ///
    /// लक्षात ठेवा की वाटपकर्ता विनंत्यापेक्षा अधिक संग्रह देऊ शकेल.
    /// म्हणूनच क्षमतेवर तंतोतंत किमान असणे अवलंबून नाही.
    /// झेडफ्यूचर 0 झेडच्या आशेची अपेक्षा असल्यास `reserve` ला प्राधान्य द्या.
    ///
    /// # Panics
    ///
    /// नवीन क्षमता `usize` ओव्हरफ्लो झाल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// दिलेल्या `Vec<T>` मध्ये कमीतकमी `additional` अधिक घटक समाविष्ट करण्यासाठी क्षमता राखून ठेवण्याचा प्रयत्न करतो.
    /// वारंवार पुनर्विक्री टाळण्यासाठी संकलनात अधिक जागा राखीव असू शकते.
    /// `try_reserve` वर कॉल केल्यानंतर, क्षमता `self.len() + additional` पेक्षा मोठी किंवा समान असेल.
    /// क्षमता आधीच पुरेशी असल्यास काहीही करत नाही.
    ///
    /// # Errors
    ///
    /// जर क्षमता ओव्हरफ्लो झाली असेल किंवा वितरकाने अपयशाची नोंद केली असेल तर त्रुटी परत केली जाईल.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // मेमरी प्री-रिझर्व करा, शक्य नसल्यास बाहेर पडा
    ///     output.try_reserve(data.len())?;
    ///
    ///     // आता आम्हाला माहित आहे की आमच्या जटिल कार्याच्या मध्यभागी हे OOM करू शकत नाही
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // खूप क्लिष्ट
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// दिलेल्या `Vec<T>` मध्ये अचूक `additional` घटक समाविष्ट करण्यासाठी किमान क्षमता राखण्याचा प्रयत्न करतो.
    /// `try_reserve_exact` वर कॉल केल्यानंतर, क्षमतेची किंमत `Ok(())` परत आल्यास `self.len() + additional` च्या तुलनेत किंवा त्यापेक्षा जास्त असेल.
    ///
    /// क्षमता आधीच पुरेशी असल्यास काहीही करत नाही.
    ///
    /// लक्षात ठेवा की वाटपकर्ता विनंत्यापेक्षा अधिक संग्रह देऊ शकेल.
    /// म्हणूनच क्षमतेवर तंतोतंत किमान असणे अवलंबून नाही.
    /// झेडफ्यूचर 0 झेडच्या आशेची अपेक्षा असल्यास `reserve` ला प्राधान्य द्या.
    ///
    /// # Errors
    ///
    /// जर क्षमता ओव्हरफ्लो झाली असेल किंवा वितरकाने अपयशाची नोंद केली असेल तर त्रुटी परत केली जाईल.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // मेमरी प्री-रिझर्व करा, शक्य नसल्यास बाहेर पडा
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // आता आम्हाला माहित आहे की आमच्या जटिल कार्याच्या मध्यभागी हे OOM करू शकत नाही
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // खूप क्लिष्ट
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// शक्य तितक्या vector ची क्षमता कमी करते.
    ///
    /// हे शक्य तितक्या जवळच्या लांबीच्या खाली खाली जाईल परंतु आणखी काही घटकांसाठी जागा असल्याचे वितरक अद्याप vector ला कळवू शकेल.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // क्षमता कधीही लांबीपेक्षा कमी नसते आणि जेव्हा ते समान असतात तेव्हा काहीही करण्याचे नसते, म्हणून आम्ही केवळ मोठ्या क्षमतेसह कॉल करून `RawVec::shrink_to_fit` मधील panic केस टाळू शकतो.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// खालच्या बाउंडसह vector ची क्षमता कमी करते.
    ///
    /// लांबी आणि पुरवठा केलेले मूल्य यापेक्षा कमीतकमी क्षमता राहील.
    ///
    ///
    /// जर सद्य क्षमता कमी मर्यादेपेक्षा कमी असेल तर ही एक निवड नाही.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// vector ला [`Box<[T]>`][owned slice] मध्ये रूपांतरित करते.
    ///
    /// लक्षात घ्या की यामुळे कोणतीही अतिरिक्त क्षमता कमी होईल.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// कोणतीही अतिरिक्त क्षमता काढून टाकली जाते:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// प्रथम `len` घटक ठेवून आणि उर्वरित सोडत, vector लहान करते.
    ///
    /// जर `len` vector च्या सद्य लांबीपेक्षा जास्त असेल तर याचा काही परिणाम होणार नाही.
    ///
    /// [`drain`] पद्धत `truncate` चे अनुकरण करू शकते, परंतु अतिरिक्त घटक सोडल्याऐवजी परत आणण्यास कारणीभूत ठरते.
    ///
    ///
    /// लक्षात घ्या की vector च्या वाटप केलेल्या क्षमतेवर या पद्धतीचा कोणताही परिणाम होणार नाही.
    ///
    /// # Examples
    ///
    /// दोन घटकांकरिता पाच घटक vector कमी करणे:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// जेव्हा vector च्या वर्तमान लांबीपेक्षा `len` मोठे असेल तेव्हा कोणतेही काटछाट होत नाही:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// जेव्हा `len == 0` हे [`clear`] पद्धतीला कॉल करण्यासारखे आहे तेव्हा ट्रंक करणे.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // हे सुरक्षित आहे कारणः
        //
        // * `drop_in_place` ला दिलेला स्लाइस वैध आहे;`len > self.len` केस अवैध स्लाइस तयार करणे टाळतो आणि
        // * झेडवेक्टोर0 झेडचा एक्स ०१ एक्स एक्स १००० वर कॉल करण्यापूर्वी संकुचित झाला आहे, जेणेकरुन `drop_in_place` एकदा झेडस्पॅनिक0 झेडवर असल्यास (मूल्य दोनदा झेडस्पॅनिक्स ० झेड असल्यास, प्रोग्राम संपुष्टात येतो) दोनदा मूल्य सोडले जाणार नाही.
        //
        //
        //
        unsafe {
            // Note: हे हेतुपुरस्सर आहे की हे X01 एक्स आहे आणि `>=` नाही.
            //       हे `>=` मध्ये बदलण्यामुळे काही प्रकरणांमध्ये कार्यक्षमतेचे नकारात्मक प्रभाव पडतात.
            //       अधिकसाठी #78884 पहा.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// संपूर्ण vector असलेली एक स्लाइस काढते.
    ///
    /// `&s[..]` च्या समतुल्य.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// संपूर्ण vector ची एक परिवर्तनीय स्लाइस काढतो.
    ///
    /// `&mut s[..]` च्या समतुल्य.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// vector च्या बफरवर एक कच्चा पॉईंटर मिळवते.
    ///
    /// कॉलरने हे सुनिश्चित केले पाहिजे की vector हे कार्य परत आलेल्या पॉईंटरला आउटलेट करते, अन्यथा ते कचर्‍याकडे निर्देश करुन समाप्त होईल.
    /// vector मध्ये बदल केल्याने त्याचा बफर पुन्हा रिक्त होऊ शकतो, ज्यामुळे त्याचे कोणतेही पॉइंटर्स अवैधही बनू शकतात.
    ///
    /// कॉलरने हे देखील सुनिश्चित केले पाहिजे की पॉईंटर (non-transitively) ने दर्शविलेली मेमरी या पॉईंटरद्वारे किंवा त्याद्वारे घेतलेल्या कोणत्याही पॉईंटरचा वापर करुन (`UnsafeCell` च्या आत वगळता) कधीही लिहिलेले नाही.
    /// आपल्याला स्लाइसमधील सामग्री बदलण्याची आवश्यकता असल्यास, एक्स00 एक्स वापरा.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // आम्ही `deref` मध्ये जाण्यापासून टाळण्यासाठी त्याच नावाच्या स्लाईस पद्धतीची छाया घेतो, ज्यामुळे एक दरम्यानचे संदर्भ तयार होईल.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// vector च्या बफरवर असुरक्षित म्युटेबल पॉईंटर मिळवते.
    ///
    /// कॉलरने हे सुनिश्चित केले पाहिजे की vector हे कार्य परत आलेल्या पॉईंटरला आउटलेट करते, अन्यथा ते कचर्‍याकडे निर्देश करुन समाप्त होईल.
    ///
    /// vector मध्ये बदल केल्याने त्याचा बफर पुन्हा रिक्त होऊ शकतो, ज्यामुळे त्याचे कोणतेही पॉइंटर्स अवैधही बनू शकतात.
    ///
    /// # Examples
    ///
    /// ```
    /// // 4 घटकांसाठी पुरेसे मोठे vector वाटप करा.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // कच्च्या पॉइंटर लेखकाद्वारे घटक प्रारंभ करा, नंतर लांबी सेट करा.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // आम्ही `deref_mut` मध्ये जाण्यापासून टाळण्यासाठी त्याच नावाच्या स्लाईस पद्धतीची छाया घेतो, ज्यामुळे एक दरम्यानचे संदर्भ तयार होईल.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// अंतर्निहित वाटप करणार्‍याचा संदर्भ मिळवते.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// vector लांबीची `new_len` ला सक्ती करते.
    ///
    /// हे एक निम्न-स्तरीय ऑपरेशन आहे जे प्रकारच्या सामान्य हल्ल्यांपैकी कोणत्याहीची देखभाल करत नाही.
    /// साधारणपणे vector ची लांबी बदलणे त्याऐवजी [`truncate`], [`resize`], [`extend`] किंवा [`clear`] यासारख्या सुरक्षित ऑपरेशन्सपैकी एक वापरुन केले जाते.
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` [`capacity()`] पेक्षा कमी किंवा त्यासमान असणे आवश्यक आहे.
    /// - `old_len..new_len` मधील घटक प्रारंभ करणे आवश्यक आहे.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// ही पद्धत अशा परिस्थितीत उपयुक्त ठरू शकते ज्यामध्ये vector इतर कोडसाठी बफर म्हणून काम करीत आहे, विशेषत: एफएफआय:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // हे डॉक्टरांच्या उदाहरणासाठी फक्त एक सांगाडा आहे;
    /// # // वास्तविक लायब्ररीसाठी हा प्रारंभ बिंदू म्हणून वापरू नका.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // एफएफआय पद्धतीच्या दस्तऐवजानुसार, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // सुरक्षितताः जेव्हा `deflateGetDictionary` `Z_OK` परत करते तेव्हा ते असे ठेवते:
    ///     // 1. `dict_length` घटक आरंभ केले.
    ///     // 2.
    ///     // `dict_length` <=क्षमता (32_768) जी `set_len` ला कॉल करणे सुरक्षित करते.
    ///     unsafe {
    ///         // एफएफआय कॉल करा ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... आणि आरंभ झालेली लांबी अद्यतनित करा.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// खालील उदाहरण दणदणीत असतानाही, मेमरी गळती झाली आहे कारण आतील vectors `set_len` कॉलपूर्वी मोकळे झाले नव्हते:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` रिक्त आहे म्हणून कोणत्याही घटकांना आरंभ करण्याची आवश्यकता नाही.
    /// // 2. `0 <= capacity` `capacity` जे आहे ते नेहमी धारण करते.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// सामान्यत: , येथे एखादी सामग्री योग्यरित्या टाकण्यासाठी [`clear`] चा वापर करेल आणि त्यामुळे मेमरी लीक होणार नाही.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// vector वरून घटक काढतो आणि परत मिळवितो.
    ///
    /// काढलेला घटक vector च्या शेवटच्या घटकाद्वारे बदलला आहे.
    ///
    /// हे ऑर्डर करणे जतन करत नाही, परंतु हे O(1) आहे.
    ///
    /// # Panics
    ///
    /// जर `index` मर्यादेबाहेर असेल तर Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // आम्ही स्वयंपूर्ण [अनुक्रमणिका] शेवटच्या घटकासह पुनर्स्थित करतो.
            // लक्षात ठेवा की वरील सीमांची तपासणी यशस्वी झाल्यास तेथे शेवटचा घटक असणे आवश्यक आहे (जे स्वतःच [अनुक्रमणिका] स्वतः असू शकते).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// vector मध्ये `index` स्थितीत घटक समाविष्ट करते, नंतर सर्व घटक उजवीकडे सरकवितो.
    ///
    ///
    /// # Panics
    ///
    /// `index > len` असल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // नवीन घटकासाठी जागा
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // नवीन मूल्य ठेवण्यासाठी स्पॉट
            //
            {
                let p = self.as_mut_ptr().add(index);
                // जागा तयार करण्यासाठी सर्व काही शिफ्ट करा.
                // (अनुक्रमांक element घटकांची सलग दोन ठिकाणी प्रत बनवित आहे.)
                ptr::copy(p, p.offset(1), len - index);
                // `अनुक्रमणिका घटकाची पहिली प्रत अधिलिखित करून त्यात लिहा.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// सर्व घटक डाव्या बाजूला सरकवून, झेडवेक्टर 0 झेडमध्ये एक्स 100 एक्स स्थानावर घटक काढते आणि मिळवते.
    ///
    ///
    /// # Panics
    ///
    /// जर `index` मर्यादेबाहेर असेल तर Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // आम्ही ज्या स्थानावरून घेत आहोत.
                let ptr = self.as_mut_ptr().add(index);
                // असुरक्षितपणे स्टॅकवर आणि त्याच वेळी झेडवेक्टर 0 झेडमध्ये मूल्याची एक प्रत असल्यास ती कॉपी करा.
                //
                ret = ptr::read(ptr);

                // त्या जागेत भरण्यासाठी सर्व काही शिफ्ट करा.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// केवळ पूर्वानुमानाने निर्दिष्ट केलेले घटक राखून ठेवतात.
    ///
    /// दुसर्‍या शब्दांत, `e` ने `false` परत केल्यासारखे सर्व घटक `e` काढा.
    /// ही पद्धत त्या ठिकाणी कार्य करते, प्रत्येक घटकास एकदाच मूळ क्रमाने भेट देते आणि कायम ठेवलेल्या घटकांचा क्रम जतन करते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// घटकांना मूळ क्रमाने एकदाच भेट दिली असल्याने बाह्य स्थितीत कोणता घटक ठेवावा हे ठरवण्यासाठी वापरले जाऊ शकते.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // ड्रॉप गार्ड कार्यान्वित न झाल्यास डबल ड्रॉप टाळा, कारण आम्ही प्रक्रियेदरम्यान काही भोक करू शकतो.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-प्रक्रिया केलेले लेन-> | |^-तपासणीपुढील
        //                  | <-हटविलेले सीएनटी-> | |
        //      | <-original_len-> | |ठेवलेले: जे घटक पूर्वानुमान करतात ते खरे असतात.
        //
        // होल: घटक स्लॉट हलविला किंवा सोडला.
        // चेक न केलेले: चेक न केलेले वैध घटक
        //
        // जेव्हा पूर्वानुमानित किंवा `drop` एलिमेंटचे घटक घाबरून जातात तेव्हा हा ड्रॉप गार्ड मागविला जाईल.
        // हे अचूक लांबीचे छिद्र आणि `set_len` झाकण्यासाठी अनचेक केलेले घटक बदलते.
        // जेव्हा प्रिकेट आणि एक्स 100 एक्स कधीही घाबरू शकणार नाहीत तेव्हा त्यास ऑप्टिमाइझ केले जाईल.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // सुरक्षितता: अनचेक केलेले आयटम मागे ठेवणे वैध असणे आवश्यक आहे कारण आम्ही त्यांना कधीही स्पर्श करत नाही.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // सुरक्षितता: भोक भरल्यानंतर सर्व आयटम संमिश्र स्मृतीत असतात.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // सुरक्षितता: चेक न केलेला घटक वैध असणे आवश्यक आहे.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // `drop_in_place` घाबरून गेला तर डबल ड्रॉप टाळण्यासाठी लवकर अ‍ॅडव्हान्स.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // सुरक्षा: सोडल्या नंतर आम्ही या घटकाला पुन्हा कधीही स्पर्श करत नाही.
                unsafe { ptr::drop_in_place(cur) };
                // आम्ही काउंटर आधीच प्रगत केले आहे.
                continue;
            }
            if g.deleted_cnt > 0 {
                // सुरक्षितता: `deleted_cnt`> 0, म्हणून भोक स्लॉट वर्तमान घटकासह आच्छादित होऊ नये.
                // आम्ही हलविण्यासाठी कॉपी वापरतो आणि या घटकाला पुन्हा कधीही स्पर्श करत नाही.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // सर्व आयटमवर प्रक्रिया केली जाते.हे एलएलव्हीएमद्वारे एक्स 100 एक्समध्ये अनुकूलित केले जाऊ शकते.
        drop(g);
    }

    /// त्याच किल्लीचे निराकरण करणारे vector मधील सलग घटकांच्या पहिल्याखेरीज सर्व काढते.
    ///
    ///
    /// जर vector चे क्रमवारी लावली गेली तर हे सर्व डुप्लिकेट काढेल.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// दिलेल्या समानतेच्या नातेसंबंधास समाधान देणारी vector मधील सलग घटकांपैकी सर्व प्रथम वगळता सर्व काढते.
    ///
    /// `same_bucket` फंक्शनने vector मधील दोन घटकांचा संदर्भ पाठविला आहे आणि घटक समान तुलना करत आहेत हे निर्धारित केले पाहिजे.
    /// स्लाइसमध्ये घटक त्यांच्या ऑर्डरच्या विरुद्ध क्रमाने पास केले जातात, म्हणून जर एक्स ० एक्स एक्स एक्स १० एक्स परत करेल तर एक्स ०१ एक्स काढला जाईल.
    ///
    ///
    /// जर vector चे क्रमवारी लावली गेली तर हे सर्व डुप्लिकेट काढेल.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// संग्रहाच्या मागील बाजूस घटक जोडते.
    ///
    /// # Panics
    ///
    /// नवीन क्षमता `isize::MAX` बाइटपेक्षा अधिक असल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // आम्ही> isize::MAX बाइटचे वाटप केल्यास किंवा लांबीची वाढ शून्य-आकाराच्या प्रकारांसाठी ओव्हरफ्लो होईल तर हे panic किंवा गर्भपात करेल.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// vector वरुन शेवटचा घटक काढून टाकते आणि ते रिक्त असल्यास किंवा [`None`] परत करते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// `other` चे सर्व घटक `Self` मध्ये हलविते, `other` रिक्त ठेवतात.
    ///
    /// # Panics
    ///
    /// vector मधील घटकांची संख्या `usize` ओव्हरफ्लो केल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// इतर बफरमधून एक्स 100 एक्समध्ये घटक समाविष्ट करते.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// झरझन इटरेटर तयार करते जे vector मधील निर्दिष्ट श्रेणी काढून टाकते आणि काढलेल्या वस्तूंचे उत्पन्न देते.
    ///
    /// जेव्हा इरेटर ** ** सोडला जातो तेव्हा श्रेणीतील सर्व घटक झेडवेक्टोर0 झेडमधून काढून टाकले जातात, जरी इरेटरटर पूर्णपणे सेवन केले नव्हते.
    /// जर इटरेटर ** ** सोडला नसेल (उदाहरणार्थ एक्स 100 एक्स सह), किती घटक काढले गेले आहेत हे अनिश्चित आहे.
    ///
    /// # Panics
    ///
    /// प्रारंभ बिंदू शेवटच्या बिंदूपेक्षा मोठा असल्यास किंवा शेवटचा बिंदू vector च्या लांबीपेक्षा मोठा असल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // एक संपूर्ण श्रेणी vector साफ करते
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // मेमरी सुरक्षा
        //
        // जेव्हा झेडड्रेन0 झेड प्रथम तयार केला जातो तेव्हा झेडड्रेन0 झेडचा नाशकर्ता कधीही चालत नाही तर कोणत्याही निर्विवाद किंवा हलविलेल्या घटकांवर अजिबात प्रवेश करता येत नाही हे सुनिश्चित करण्यासाठी स्त्रोत झेडवेक्टोर0 झेड कमी करते.
        //
        //
        // Drain काढण्यासाठी मूल्ये ptr::read काढेल.
        // पूर्ण झाल्यावर, छिद्र झाकण्यासाठी व्हेक्टरच्या उर्वरित शेपटीची पुन्हा कॉपी केली जाते आणि झेडवेक्टोर0 झेडची लांबी नवीन लांबीवर पुनर्संचयित केली जाते.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // Drain लीक झाल्यास सुरक्षित होण्यासाठी self.vec लांबी सेट करा
            self.set_len(start);
            // संपूर्ण झेडड्रेन 0 झेड इटरेटर (एक्स 100 एक्स टी प्रमाणे) च्या कर्ज घेण्याचे वर्तन दर्शविण्यासाठी आयटरमटमध्ये कर्ज वापरा.
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// सर्व मूल्ये काढून झेडवेक्टर 0 झेड साफ करते.
    ///
    /// लक्षात घ्या की vector च्या वाटप केलेल्या क्षमतेवर या पद्धतीचा कोणताही परिणाम होणार नाही.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// vector मधील घटकांची संख्या मिळवते, ज्यास त्याचा 'length' देखील म्हटले जाते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// vector मध्ये कोणतेही घटक नसल्यास `true` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// दिलेल्या निर्देशांकात संग्रह दोन मध्ये विभाजित करतो.
    ///
    /// `[at, len)` श्रेणीमधील घटक असलेले नवीन वाटप केलेले vector मिळवते.
    /// कॉलनंतर, मूळ vector मध्ये त्याच्या आधीच्या क्षमतेत कोणतीही बदल न करता `[0, at)` घटक असलेले सोडले जाईल.
    ///
    ///
    /// # Panics
    ///
    /// `at > len` असल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // नवीन vector मूळ बफर ताब्यात घेऊ शकते आणि कॉपी टाळेल
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // असुरक्षितपणे X01 एक्स आणि आयटम `other` वर कॉपी करा.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// `Vec` चे जागेचे आकार बदलते जेणेकरुन `len` `new_len` बरोबर असेल.
    ///
    /// `new_len` हे `len` पेक्षा मोठे असल्यास, क्लोजर एक्स 100 एक्स कॉलच्या परिणामी प्रत्येक अतिरिक्त स्लॉटसह `Vec` फरक वाढविला आहे.
    ///
    /// `f` मधील परतावा मूल्ये ते व्युत्पन्न केलेल्या क्रमाने `Vec` मध्ये समाप्त होतील.
    ///
    /// जर `new_len` हे `len` पेक्षा कमी असेल तर, `Vec` फक्त लहान आहे.
    ///
    /// ही पद्धत प्रत्येक पुशवर नवीन मूल्ये तयार करण्यासाठी क्लोजरचा वापर करते.आपण त्याऐवजी दिले मूल्य [`Clone`] इच्छित असल्यास, [`Vec::resize`] वापरा.
    /// मूल्ये व्युत्पन्न करण्यासाठी आपल्याला [`Default`] trait वापरायचे असल्यास आपण [`Default::default`] दुसर्‍या वितर्क म्हणून पास करू शकता.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// `Vec` घेते आणि लीक करते, त्यातील सामग्रीचा बदल बदलणारा संदर्भ परत करतो, `&'a mut [T]`.
    /// लक्षात घ्या की `T` प्रकाराने निवडलेल्या आजीवन `'a` ला मागे टाकणे आवश्यक आहे.
    /// प्रकारात फक्त स्थिर संदर्भ असल्यास किंवा काहीच नाही, तर हे `'static` म्हणून निवडले जाऊ शकते.
    ///
    /// लीक मेमरी पुनर्प्राप्त करण्याचा कोणताही मार्ग वगळता हे फंक्शन एक्स 0 एक्स एक्स एक्स एक्स एक्स एक्स फंक्शनसारखेच आहे.
    ///
    ///
    /// हे कार्य मुख्यतः प्रोग्रामच्या उर्वरित जीवनासाठी डेटासाठी उपयुक्त आहे.
    /// परत केलेला संदर्भ टाकणे मेमरी गळतीस कारणीभूत ठरेल.
    ///
    /// # Examples
    ///
    /// साधा वापर:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// vector ची उर्वरित अतिरिक्त क्षमता `MaybeUninit<T>` चा तुकडा म्हणून मिळवते.
    ///
    /// परत केलेली स्लाइस vector डेटासह भरण्यासाठी वापरली जाऊ शकते (उदा
    /// [`set_len`] पद्धत वापरुन आरंभ केलेला म्हणून डेटा चिन्हांकित करण्यापूर्वी फाइलमधून वाचून).
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // 10 घटकांसाठी पुरेसे मोठे vector वाटप करा.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // प्रथम 3 घटक भरा.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // आरंभिक म्हणून vector चे प्रथम 3 घटक चिन्हांकित करा.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // बफरकडे पॉईंटर्स अवैध करणे टाळण्यासाठी ही पद्धत `split_at_spare_mut` च्या दृष्टीने लागू केलेली नाही.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// vector सामग्रीला `T` चा स्लाइस म्हणून, vector च्या उर्वरित अतिरिक्त क्षमतेसह `MaybeUninit<T>` चा स्लाइस म्हणून मिळवते.
    ///
    /// [`set_len`] पद्धतीचा वापर करुन डेटा आरंभ करण्यापूर्वी परत केलेल्या अतिरिक्त स्पेसी क्षमता स्लाइसचा वापर झेडवेवेक्टर0 झेडला डेटासह भरण्यासाठी केला जाऊ शकतो (उदा. फाइलमधून वाचून).
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// लक्षात ठेवा की हे एक निम्न-स्तरीय API आहे, जे ऑप्टिमायझेशनच्या उद्देशाने काळजीपूर्वक वापरले पाहिजे.
    /// आपल्याला `Vec` वर डेटा जोडण्याची आवश्यकता असल्यास आपल्या अचूक गरजा लक्षात घेऊन आपण [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] किंवा [`resize_with`] वापरू शकता.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // 10 घटकांसाठी पुरेशी जागा अतिरिक्त राखून ठेवा.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // पुढील 4 घटक भरा.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // आरंभिक म्हणून vector चे 4 घटक चिन्हांकित करा.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - लेनकडे दुर्लक्ष केले जाते आणि म्हणून कधीही बदलले नाही
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// सुरक्षितताः .2 (&mut usize) बदलणे हे `.set_len(_)` कॉल करण्यासारखेच मानले जाते.
    ///
    /// ही पद्धत `extend_from_within` मध्ये एकाच वेळी सर्व पशु भागांमध्ये अनन्य प्रवेश मिळविण्यासाठी वापरली जाते.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` `len` घटकांसाठी वैध असल्याची हमी दिलेली आहे
        // - `spare_ptr` बफरच्या मागील भागाकडे एक घटक दर्शवित आहे, जेणेकरून ते `initialized` सह आच्छादित होणार नाही
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// `Vec` चे जागेचे आकार बदलते जेणेकरुन `len` `new_len` बरोबर असेल.
    ///
    /// `new_len` हे `len` पेक्षा मोठे असल्यास, प्रत्येक अतिरिक्त स्लॉटमध्ये `value` भरलेल्या, `Vec` फरकाने वाढविले आहे.
    ///
    /// जर `new_len` हे `len` पेक्षा कमी असेल तर, `Vec` फक्त लहान आहे.
    ///
    /// उत्तीर्ण मूल्य क्लोन करण्यात सक्षम होण्यासाठी या पद्धतीमध्ये [`Clone`] लागू करण्यासाठी `T` आवश्यक आहे.
    /// आपल्याला अधिक लवचिकता आवश्यक असल्यास (किंवा [`Clone`] ऐवजी [`Default`] वर अवलंबून रहायचे असेल तर), [`Vec::resize_with`] वापरा.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// क्लोन्स आणि एक्स 100 एक्स मध्ये स्लाइसमधील सर्व घटक जोडा.
    ///
    /// स्लाइस X01 एक्स वर शोधणे, प्रत्येक घटक क्लोन करणे आणि नंतर या एक्स 100 एक्समध्ये जोडणे.
    /// `other` vector क्रमाने ट्रान्सव्हर्ड केलेले आहे.
    ///
    /// लक्षात ठेवा की हे कार्य त्याऐवजी कापांसह कार्य करण्यासाठी विशेष आहे याशिवाय हे कार्य [`extend`] सारखे आहे.
    ///
    /// जर आणि जेव्हा झेडआरस्ट0 झेडला स्पेशलायझेशन प्राप्त होते तेव्हा हे कार्य संभवत: नाकारले जाईल (परंतु अद्याप उपलब्ध आहे).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// `src` श्रेणीपासून vector च्या शेवटच्या भागापर्यंत कॉपी करते.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` दिलेली श्रेणी स्वयं अनुक्रमित करण्यासाठी वैध आहे याची हमी देते
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// हा कोड एक्स 100 एक्सला सामान्यीकृत करतो.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// दिलेल्या जनरेटरचा वापर करून, `n` मूल्यांद्वारे vector वाढवा.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // बगचे कार्य करण्यासाठी सेटलेनऑनड्रॉप वापरा जिथे कंपाईलर `ptr` मार्गे एक्स01 एक्सद्वारे उर्फ नाही तर स्टोअरची जाणीव होऊ शकत नाही.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // शेवटच्या व्यतिरिक्त सर्व घटक लिहा
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // next() panics बाबतीत प्रत्येक चरणात लांबी वाढवा
                local_len.increment_len(1);
            }

            if n > 0 {
                // अनावश्यकपणे क्लोनिंग न करता आम्ही शेवटचा घटक थेट लिहू शकतो
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // स्कोप गार्ड द्वारे सेट लेन
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// [`PartialEq`] trait अंमलबजावणीनुसार vector मधील सलग पुनरावृत्ती केलेले घटक काढते.
    ///
    ///
    /// जर vector चे क्रमवारी लावली गेली तर हे सर्व डुप्लिकेट काढेल.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// अंतर्गत पद्धती आणि कार्ये
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` वैध अनुक्रमणिका असणे आवश्यक आहे
    /// - `self.capacity() - self.len()` `>= src.len()` असणे आवश्यक आहे
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - घटक प्रारंभ केल्यावरच लेन वाढविली जाते
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - कॉलर गॅरंटीज जे झेडएसआरसी 0 झेड एक वैध अनुक्रमणिका आहे
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - एलिमेंट नुकतीच `MaybeUninit::write` ने आरंभ केला होता, म्हणून लेन वाढविणे ठीक आहे
            // - गळतीपासून बचाव करण्यासाठी प्रत्येक घटकानंतर लेन वाढविला जातो (#82533 जारी करा)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - कॉलर हमी देतो की एक्स 100 एक्स एक वैध अनुक्रमणिका आहे
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - दोन्ही पॉइंटर्स अद्वितीय स्लाइस संदर्भ (`&mut [_]`) वरून तयार केले गेले आहेत जेणेकरून ते वैध आहेत आणि आच्छादित होणार नाहीत.
            //
            // - घटक आहेतः कॉपी करा त्यामुळे मूळ मूल्यांसह काहीही केल्याशिवाय त्यांची कॉपी करणे ठीक आहे
            // - `count` `source` च्या लेनच्या बरोबरीचे आहे, म्हणून `count` वाचनासाठी स्त्रोत वैध आहे
            // - `.reserve(count)` हमी देते की एक्स 100 एक्स इतका अतिरिक्त एक्स एक्स 01 एक्स लेखनासाठी वैध आहे
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - घटक नुकतेच `copy_nonoverlapping` ने आरंभ केले
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// वेकसाठी सामान्य झेडट्रायट 0 झेड कार्यान्वयन
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): cfg(test) सह अंतर्भूत `[T]::to_vec` पद्धत, जी या पद्धतीच्या परिभाषासाठी आवश्यक आहे, उपलब्ध नाही.
    // त्याऐवजी `slice::to_vec` फंक्शन वापरा जे फक्त cfg(test) NB सह उपलब्ध आहे अधिक माहितीसाठी slice.rs मधील slice::hack मॉड्यूल पहा
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // अधिलिखित होणार नाही असे काहीही सोडा
        self.truncate(other.len());

        // self.len <= other.len वरील काटकीमुळे
        //
        let (init, tail) = other.split_at(self.len());

        // समाविष्टीत मूल्ये allocations/resources पुन्हा वापरा.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// एक उपभोग करणारा आयटर तयार करतो, म्हणजेच तो एक मूल्य जे झेड वेक्टर0 झेडच्या बाहेर (प्रारंभ पासून शेवटपर्यंत) हलवितो.
    /// हे कॉल केल्यानंतर vector वापरणे शक्य नाही.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // चे एक्स स्ट्रिंग आहे, एक्स 100 एक्स नाही
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // लीफ पद्धत ज्यावर एक्सएक्सएक्सच्या कार्यान्वयनासाठी कोणतेही अधिक ऑप्टिमायझेशन नसल्यास ते नियुक्त करतात
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // सामान्य पुनरावृत्ती करणार्‍याची ही स्थिती आहे.
        //
        // हे कार्य नैतिक समतुल्य असावे:
        //
        //      आयटरमध्ये आयटमसाठी {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // आम्हाला अ‍ॅड्रेस स्पेस द्यावी लागणार असल्याने एनबी ओव्हरफ्लो होऊ शकत नाही
                self.set_len(len + 1);
            }
        }
    }

    /// एक स्प्लिकिंग इटरेटर तयार करते जे vector मध्ये निर्दिष्ट श्रेणी पुनर्निर्देशित `replace_with` इटरेटर सह पुनर्स्थित करते आणि काढलेल्या वस्तूंचे उत्पन्न देते.
    ///
    /// `replace_with` `range` समान लांबीची आवश्यकता नाही.
    ///
    /// `range` शेवटपर्यंत पुनरावृत्ती करणारा वापर केला जात नसला तरीही काढला जातो.
    ///
    /// `Splice` मूल्य लीक झाल्यास vector वरून किती घटक काढले गेले हे अनिश्चित आहे.
    ///
    /// `Splice` मूल्य सोडल्यास केवळ इनपुट इटररेटर `replace_with` वापरला जातो.
    ///
    /// हे इष्टतम असेल तरः
    ///
    /// * शेपटी (`range` नंतर vector मधील घटक) रिक्त आहे,
    /// * किंवा `replace_with` ला `श्रेणी`च्या लांबीपेक्षा कमी किंवा समान घटक मिळतात
    /// * किंवा त्याच्या `size_hint()` ची खालची सीमा अचूक आहे.
    ///
    /// अन्यथा, तात्पुरते vector वाटप केले जाते आणि शेपटी दोनदा हलविली जाते.
    ///
    /// # Panics
    ///
    /// प्रारंभ बिंदू शेवटच्या बिंदूपेक्षा मोठा असल्यास किंवा शेवटचा बिंदू vector च्या लांबीपेक्षा मोठा असल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// एखादा आयटर काढला पाहिजे की नाही हे निर्धारित करण्यासाठी क्लोजर वापरणारा इटरेटर तयार करतो.
    ///
    /// जर बंद सत्य परत आले तर घटक काढून टाकला जाईल.
    /// जर क्लोजर चुकीचे परत आले तर घटक vector मध्ये राहील आणि पुनरावृत्ती करणार्‍याद्वारे उत्पन्न मिळणार नाही.
    ///
    /// ही पद्धत वापरणे खालील कोड समतुल्य आहे:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // आपला कोड येथे
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// परंतु `drain_filter` वापरणे सोपे आहे.
    /// `drain_filter` हे अधिक कार्यक्षम आहे, कारण हे मोठ्या संख्येने अ‍ॅरेच्या घटकांचे समर्थन करेल.
    ///
    /// लक्षात घ्या की `drain_filter` आपल्याला फिल्टर क्लोजरमधील प्रत्येक घटकास बदलू देतो, आपण ते ठेवणे किंवा काढणे निवडले आहे याची पर्वा न करता.
    ///
    ///
    /// # Examples
    ///
    /// मूळ वाटपाचा पुन्हा वापर करून, संध्याकाळ आणि शक्यतांमध्ये अ‍ॅरेचे विभाजन करणे:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // आमच्याकडून लीक होण्यापासून सावध रहा (लीक एम्पलीफिकेशन)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// अंमलबजावणीचे विस्तार करा जे घटकांकडे संदर्भाबाहेर वेक वर ढकलण्याआधी कॉपी करतात.
///
/// ही अंमलबजावणी स्लाइस पुनरावृत्ती करणार्‍यांसाठी विशेष आहे, जिथे ती संपूर्ण स्लाइस एकाच वेळी जोडण्यासाठी [`copy_from_slice`] वापरते.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// vectors ची तुलना प्रभावी करते, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// vectors च्या ऑर्डरिंगची अंमलबजावणी करते, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // [T] साठी वापर ड्रॉप झेडवेक्टोर0झेडच्या घटकांचा संदर्भ देण्यासाठी एक कच्चा स्लाइस वापरणे आवश्यक तितका आवश्यक प्रकार;
            //
            // विशिष्ट प्रकरणांमध्ये वैधतेचे प्रश्न टाळता येऊ शकतात
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // रॉवेक विकृत रूप हाताळते
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// रिक्त `Vec<T>` तयार करते.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: चाचणी लिबस्टडी मध्ये खेचते, ज्यामुळे येथे चुका होतात
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: चाचणी लिबस्टडी मध्ये खेचते, ज्यामुळे येथे चुका होतात
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// `Vec<T>` ची संपूर्ण सामग्री अ‍ॅरेच्या रूपात मिळविते, जर त्याचा आकार विनंती केलेल्या अ‍ॅरेपेक्षा अचूक जुळत असेल तर.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// जर लांबी जुळत नसेल तर इनपुट परत `Err` मध्ये येईल:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// आपण `Vec<T>` चे फक्त एक उपसर्ग मिळविण्यासह ठीक असल्यास, आपण प्रथम [`.truncate(N)`](Vec::truncate) वर कॉल करू शकता.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // सुरक्षितता: `.set_len(0)` नेहमीच ध्वनी असते.
        unsafe { vec.set_len(0) };

        // सुरक्षितता: ए `वेका चे पॉईंटर नेहमी योग्यरितीने संरेखित केले जाते आणि
        // अ‍ॅरेची आवश्यक असलेली संरेखन आयटमसारखेच आहे.
        // आमच्याकडे पुरेशी वस्तू आहेत हे आम्ही पूर्वी तपासले होते.
        // आयटम डबल-ड्रॉप होणार नाहीत कारण `set_len` `Vec` ला देखील टाकू नका असे सांगते.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}