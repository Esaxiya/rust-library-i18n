use core::ptr::{self};
use core::slice::{self};

// जागेच्या पुनरावृत्तीसाठी एक सहाय्यक रचना जी पुनरावृत्तीच्या गंतव्य स्लाइस, म्हणजे डोके सोडते.
// स्त्रोत स्लाइस (शेपटी) इन्टॉइटरने सोडली आहे.
pub(super) struct InPlaceDrop<T> {
    pub(super) inner: *mut T,
    pub(super) dst: *mut T,
}

impl<T> InPlaceDrop<T> {
    fn len(&self) -> usize {
        unsafe { self.dst.offset_from(self.inner) as usize }
    }
}

impl<T> Drop for InPlaceDrop<T> {
    #[inline]
    fn drop(&mut self) {
        unsafe {
            ptr::drop_in_place(slice::from_raw_parts_mut(self.inner, self.len()));
        }
    }
}