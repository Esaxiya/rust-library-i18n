#![stable(feature = "rust1", since = "1.0.0")]

//! थ्रेड-सेफ संदर्भ-मोजणी पॉईंटर्स
//!
//! अधिक तपशीलांसाठी [`Arc<T>`][Arc] दस्तऐवजीकरण पहा.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// `Arc` वर केले जाऊ शकणार्‍या संदर्भांच्या प्रमाणात मर्यादा.
///
/// या मर्यादेच्या वर जाणे आपला प्रोग्राम (जरी आवश्यक नसला तरी) _exactly_ `MAX_REFCOUNT + 1` संदर्भांवर रद्द करेल.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// थ्रेडसॅनिटायझर मेमरी कुंपणाला समर्थन देत नाही.
// कंस/कमकुवत अंमलबजावणीमधील चुकीचे सकारात्मक अहवाल टाळण्यासाठी त्याऐवजी सिंक्रोनाइझेशनसाठी अणु भार वापरा.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// एक धागा-सुरक्षित संदर्भ-मोजणी पॉईंटरएक्स00 एक्स म्हणजे 'अ‍ॅटॉमिकली रेफरन्स काउंटेड'.
///
/// `Arc<T>` हा प्रकार ढीगमध्ये वाटप केलेल्या `T` प्रकारच्या मूल्याची सामायिक मालकी प्रदान करतो.एक्स ०4 एक्सवर एक्स ०3 एक्सची सुरूवात केल्याने एक नवीन एक्स ०5 एक्स एक्स घटना तयार होते, जे संदर्भ संख्या वाढवित असताना, स्रोत एक्स ०१ एक्सच्या ढीगावर समान वाटपाकडे निर्देश करते.
/// जेव्हा दिलेल्या वाटपाचे शेवटचे `Arc` पॉईंटर नष्ट होते तेव्हा त्या allocलोकेशनमध्ये संचयित केलेले मूल्य (बहुधा "inner value" म्हणून संदर्भित) देखील सोडले जाते.
///
/// Rust मधील सामायिक संदर्भ डीफॉल्टनुसार उत्परिवर्तन करण्यास अनुमती देत नाहीत आणि `Arc` देखील याला अपवाद नाहीः आपण सामान्यत: `Arc` च्या आत कशासही बदल बदलू शकत नाही.आपल्याला `Arc` द्वारे बदलण्याची आवश्यकता असल्यास, [`Mutex`][mutex], [`RwLock`][rwlock] किंवा [`Atomic`][atomic] प्रकारांपैकी एक वापरा.
///
/// ## थ्रेड सेफ्टी
///
/// [`Rc<T>`] च्या विपरीत, `Arc<T>` त्याच्या संदर्भ मोजणीसाठी अणूचा वापर करते.याचा अर्थ असा की तो धागा-सेफ आहे.गैरसोय म्हणजे सामान्य मेमरी एक्सेसपेक्षा अणु ऑपरेशन अधिक महाग असतात.जर आपण थ्रेड्स दरम्यान संदर्भ-मोजले गेलेले वाटप सामायिक करत नसाल तर निम्न ओव्हरहेडसाठी [`Rc<T>`] वापरण्याचा विचार करा.
/// [`Rc<T>`] एक सुरक्षित डीफॉल्ट आहे, कारण कंपाईलर थ्रेड्स दरम्यान एक्स 100 एक्स पाठविण्याचा कोणताही प्रयत्न पकडेल.
/// तथापि, लायब्ररी ग्राहकांना अधिक लवचिकता देण्यासाठी `Arc<T>` निवडू शकते.
///
/// `Arc<T>` जोपर्यंत `T` [`Send`] आणि [`Sync`] लागू करतो तोपर्यंत [`Send`] आणि [`Sync`] कार्यान्वित करेल.
/// थ्रेड-सेफ करण्यासाठी आपण एक्स-0 एक्स मध्ये एक्स-थ्रेड-सेफ प्रकार एक्स-1 एक्स का ठेवू शकत नाही?प्रथम हे थोडा प्रति-अंतर्ज्ञानी असू शकते: सर्व केल्यानंतर, `Arc<T>` थ्रेड सेफ्टीचा मुद्दा नाही काय?की हे असे आहे: एक्स00 एक्स समान डेटाची एकाधिक मालकी मिळविण्यासाठी थ्रेडला सुरक्षित बनवितो, परंतु तो त्याच्या डेटामध्ये धागा सुरक्षितता जोडत नाही.
///
/// `आर्क <` [`रेफसेल<T>`]`>`.
/// [`RefCell<T>`] [`Sync`] नाही आणि जर X02 एक्स नेहमीच X01 एक्स असते तर `आर्क <` [`रेफसेल<T>`]`>`तसेच होईल.
/// परंतु नंतर आम्हाला एक समस्या असेल:
/// [`RefCell<T>`] धागा सुरक्षित नाही;हे अणुविरहीत ऑपरेशन्सद्वारे उधार घेण्याच्या मोजणीचा मागोवा ठेवते.
///
/// शेवटी, याचा अर्थ असा की आपल्याला `Arc<T>` प्रकारची [`std::sync`] प्रकारची सहसा जोडणे आवश्यक आहे, सहसा [`Mutex<T>`][mutex].
///
/// ## `Weak` सह चक्र ब्रेकिंग
///
/// [`downgrade`][downgrade] पद्धत नॉन-मालकीचे [`Weak`] पॉईंटर तयार करण्यासाठी वापरली जाऊ शकते.एक [`Weak`] पॉईंटर [`अपग्रेड`][अपग्रेड] डी एक्सएक्सएक्सएक्सवर असू शकतो, परंतु जर ationलोकेशनमध्ये संग्रहित मूल्य आधीपासून सोडली गेली असेल तर हे एक्स 0 एक्स एक्स परत करेल.
/// दुस words्या शब्दांत, `Weak` पॉईंटर्स वाटप अंतर्गत मूल्य जिवंत ठेवत नाही;तथापि, ते वाटप (मूल्यासाठीचे आधारभूत स्टोअर) * चालू ठेवतात.
///
/// `Arc` पॉइंटर्स दरम्यानचे चक्र कधीही कमी होणार नाही.
/// या कारणास्तव, चक्र खंडित करण्यासाठी [`Weak`] चा वापर केला जातो.उदाहरणार्थ, झाडामध्ये पालकांकडे असलेल्या नोडस् कडून `Arc` पॉईंटर्स आणि मुलांपासून त्यांच्या पालकांकडे [`Weak`] पॉईंटर्स असू शकतात.
///
/// # क्लोनिंग संदर्भ
///
/// अस्तित्वातील संदर्भ-मोजले जाणारे सूचकांकडून नवीन संदर्भ तयार करणे [`Arc<T>`][Arc] आणि [`Weak<T>`][Weak] साठी लागू केलेल्या `Clone` trait वापरुन केले जाते.
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // खाली दोन वाक्यरचना समतुल्य आहेत.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b आणि foo हे सर्व आर्क्स समान मेमरी स्थानाकडे निर्देश करतात
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` आपोआप `T` ला संदर्भित करा ([`Deref`][deref] trait मार्गे), जेणेकरुन आपण `Arc<T>` प्रकारच्या मूल्यावर `T` च्या पद्धती कॉल करू शकता.`T` च्या पद्धतींसह नावाचा संघर्ष टाळण्यासाठी, स्वतः `Arc<T>` च्या पद्धती संबंधित कार्ये आहेत, ज्यास [fully qualified syntax] वापरून म्हटले जाते:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `कमान<T>`Clone` सारख्या traits च्या अंमलबजावणीस पूर्णपणे पात्र वाक्यरचना वापरून देखील म्हटले जाऊ शकते.
/// काही लोक पूर्णपणे पात्र वाक्यरचना वापरण्यास प्राधान्य देतात तर काही मेथड-कॉल सिंटॅक्स वापरण्यास प्राधान्य देतात.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // मेथड-कॉल सिंटॅक्स
/// let arc2 = arc.clone();
/// // पूर्णपणे पात्र वाक्यरचना
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] `T` चे स्वयं-डीरेफरन्स देत नाही, कारण आतील मूल्य आधीपासून सोडले गेले आहे.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// थ्रेड्स दरम्यान काही अपरिवर्तनीय डेटा सामायिक करत आहे:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// लक्षात ठेवा आम्ही येथे **या चाचण्या** करीत नाही.
// जर एखादा धागा मुख्य धागापेक्षा जास्त बाहेर पडला तर त्याच वेळी (काहीतरी डेडलॉक्स) बाहेर पडल्यास windows बिल्डर्स फारच नाखूष आहेत म्हणून आम्ही या चाचण्या न चालवून हे पूर्णपणे टाळतो.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// एक बदलण्यायोग्य [`AtomicUsize`] सामायिकरण:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// सर्वसाधारणपणे संदर्भ मोजणीच्या अधिक उदाहरणांसाठी [`rc` documentation][rc_examples] पहा.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` [`Arc`] ची एक आवृत्ती आहे ज्यात व्यवस्थापित वाटपाचा मालकीचा नसलेला संदर्भ आहे.
/// `Weak` पॉईंटरवर [`upgrade`] ला कॉल करून वाटप प्रवेश केला जातो, जो [`पर्याय`] returns <`[`आर्का] returns परत करतो<T>> `.
///
/// `Weak` संदर्भ मालकीकडे मोजत नसल्यामुळे, तो वाटप मध्ये संग्रहित मूल्य सोडण्यापासून प्रतिबंधित करणार नाही आणि स्वतः एक्स 0 एक्स एक्स अजूनही मूल्य असलेल्या अस्तित्वाची हमी देत नाही.
///
/// जेव्हा [`अपग्रेड`] डी. तेव्हा ते [`None`] परत येऊ शकते.
/// तथापि हे लक्षात घ्या की एक `Weak` संदर्भ *करतो* स्वत: चे वाटप (बॅकिंग स्टोअर) विपुल होण्यापासून प्रतिबंधित करतो.
///
/// एक `Weak` पॉईंटर [`Arc`] द्वारे व्यवस्थापित केलेल्या वाटपाचा तात्पुरता संदर्भ ठेवण्यासाठी उपयुक्त आहे कारण त्याचे अंतर्गत मूल्य खाली न येण्यापासून प्रतिबंधित करते.
/// हे [`Arc`] पॉइंटर्स दरम्यान परिपत्रक संदर्भ रोखण्यासाठी देखील वापरले जाते कारण परस्पर मालकीचे संदर्भ [`Arc`] कधीही सोडत नाहीत.
/// उदाहरणार्थ, एका झाडामध्ये पालकांकरिता नोडस् कडून [`Arc`] पॉईंटर्स आणि मुलांपासून त्यांच्या पालकांकडे `Weak` पॉईंटर्स असू शकतात.
///
/// `Weak` पॉईंटर मिळविण्यासाठीचा सामान्य मार्ग म्हणजे [`Arc::downgrade`] वर कॉल करणे.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Enums मध्ये या प्रकारच्या आकारास अनुकूलित करण्यासाठी हे एक `NonNull` आहे, परंतु हे वैध पॉईंटर असणे आवश्यक नाही.
    //
    // `Weak::new` हे `usize::MAX` वर सेट करते जेणेकरून ढीगवर जागा वाटपाची आवश्यकता नाही.
    // वास्तविक पॉईंटरला असलेले हे मूल्य नाही कारण आरसीबॉक्सचे संरेखन किमान 2 आहे.
    // हे तेव्हाच शक्य आहे जेव्हा एक्स 100 एक्स;आकार नसलेली `T` कधीही डँगल नका.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// संभाव्य फील्ड-रर्डरिंग विरूद्ध हे एक्स 100 एक्स ते झेडफ्यूचर 0 झेड-प्रूफ आहे, जे ट्रान्समिटेबल आतील प्रकारांच्या सुरक्षित [into|from]_raw() मध्ये व्यत्यय आणेल.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // usize::MAX मूल्य कमकुवत पॉइंटर्स अपग्रेड करण्याची किंवा बळकट व्यक्तींना श्रेणीसुधारित करण्याची क्षमता तात्पुरते "locking" साठी प्रेषक म्हणून कार्य करते;हे `make_mut` आणि `get_mut` मधील रेस टाळण्यासाठी वापरले जाते.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// नवीन `Arc<T>` तयार करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // कमकुवत पॉईंटर गणना 1 म्हणून प्रारंभ करा जी सर्व सशक्त पॉईंटर्स (kinda) ने ठेवलेली कमकुवत सूचक आहे, अधिक माहितीसाठी std/rc.rs पहा
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// स्वतःचा कमकुवत संदर्भ वापरुन नवीन `Arc<T>` तयार करते.
    /// हे कार्य परत येण्यापूर्वी कमकुवत संदर्भ श्रेणीसुधारित करण्याचा प्रयत्न केल्यास `None` मूल्य मिळेल.
    /// तथापि, कमकुवत संदर्भ नंतर मुक्तपणे क्लोन केला जाऊ शकतो आणि नंतर वापरासाठी संग्रहित केला जाऊ शकतो.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // एकल कमकुवत संदर्भासह "uninitialized" स्थितीत अंतर्गत बनवा.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // हे महत्त्वाचे आहे की आम्ही कमकुवत पॉइंटरची मालकी सोडत नाही, अन्यथा `data_fn` परत येईपर्यंत मेमरी मोकळी होऊ शकते.
        // आम्हाला खरोखर मालकी उत्तीर्ण व्हायची असेल तर आम्ही स्वतःसाठी एक अतिरिक्त कमकुवत पॉईंटर तयार करु शकू, परंतु यामुळे कमकुवत संदर्भ मोजणीत अतिरिक्त अद्यतने आढळू शकतात जी कदाचित अन्यथा आवश्यक नसतील.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // आता आम्ही अंतर्गत मूल्य योग्यरित्या आरंभ करू आणि आपला कमकुवत संदर्भ मजबूत संदर्भात बदलू शकतो.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // उपरोक्त फील्डमध्ये उपरोक्त लेखन अशा कोणत्याही धाग्यांना दृश्यमान असणे आवश्यक आहे जे शून्य नसलेल्या मजबूत गणनाचे निरीक्षण करतात.
            // म्हणूनच `Weak::upgrade` मधील `compare_exchange_weak` सह समक्रमित करण्यासाठी आम्हाला कमीतकमी "Release" क्रमवारीची आवश्यकता आहे.
            //
            // "Acquire" ऑर्डर करणे आवश्यक नाही.
            // `data_fn` च्या संभाव्य वर्तनांचा विचार करताना आम्हाला केवळ अपग्रेड करण्यायोग्य `Weak` च्या संदर्भासह काय करता येईल हे पाहण्याची आवश्यकता आहे:
            //
            // - हे कमकुवत संदर्भ संख्या वाढवून `Weak`*क्लोन* करू शकते.
            // - हे त्या क्लोन ड्रॉप करू शकते, कमकुवत संदर्भ संख्या कमी करते (परंतु कधीही शून्यावर नाही).
            //
            // हे दुष्परिणाम आमच्यावर कोणत्याही प्रकारे परिणाम करीत नाहीत आणि केवळ सुरक्षित कोडसह कोणतेही इतर दुष्परिणाम संभव नाहीत.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // मजबूत संदर्भ एकत्रितपणे सामायिक कमकुवत संदर्भाचे मालक असले पाहिजेत, म्हणून आमच्या जुन्या कमकुवत संदर्भासाठी डिस्ट्रक्टर चालवू नका.
        //
        mem::forget(weak);
        strong
    }

    /// निर्विवाद सामग्रीसह एक नवीन `Arc` तयार करते.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // स्थगित आरंभ:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// `0` बाइट्ससह मेमरी भरल्यामुळे, बिनविभाजित सामग्रीसह नवीन एक्स00 एक्स बनवते.
    ///
    ///
    /// या पद्धतीच्या अचूक आणि चुकीच्या वापराच्या उदाहरणांसाठी [`MaybeUninit::zeroed`][zeroed] पहा.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// नवीन `Pin<Arc<T>>` तयार करते.
    /// जर `T` ने `Unpin` लागू केले नाही तर `data` मेमरीमध्ये पिन होईल आणि हलविण्यात अक्षम आहे.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// नवीन `Arc<T>` तयार करते, वाटप अयशस्वी झाल्यास त्रुटी परत करत.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // कमकुवत पॉईंटर गणना 1 म्हणून प्रारंभ करा जी सर्व सशक्त पॉईंटर्स (kinda) ने ठेवलेली कमकुवत सूचक आहे, अधिक माहितीसाठी std/rc.rs पहा
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// वाटप अयशस्वी झाल्यास त्रुटी परत करून, बिनविभाज्य सामग्रीसह नवीन `Arc` तयार करते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // स्थगित आरंभ:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// `0` बाइट्सने मेमरी भरल्यामुळे, निर्विवाद सामग्रीसह नवीन `Arc` तयार करते, वाटप अयशस्वी झाल्यास त्रुटी परत करते.
    ///
    ///
    /// या पद्धतीच्या अचूक आणि चुकीच्या वापराच्या उदाहरणांसाठी [`MaybeUninit::zeroed`][zeroed] पहा.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// जर एक्स 100 एक्स मध्ये एक मजबूत संदर्भ असेल तर अंतर्गत मूल्य मिळवते.
    ///
    /// अन्यथा, आत गेलेल्या `Arc` सह [`Err`] परत केला जाईल.
    ///
    ///
    /// थकबाकीदार दुर्बल संदर्भ असूनही हे यशस्वी होईल.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // निहित मजबूत-कमकुवत संदर्भ साफ करण्यासाठी कमकुवत सूचक बनवा
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// निर्विवाद सामग्रीसह एक नवीन आण्विक संदर्भ-मोजलेली स्लाईस तयार करते.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // स्थगित आरंभ:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// `0` बाइट्सने मेमरी भरल्यामुळे, निर्विवाद सामग्रीसह एक नवीन अणुदृष्ट्या संदर्भ-मोजलेली स्लाईस तयार करते.
    ///
    ///
    /// या पद्धतीच्या अचूक आणि चुकीच्या वापराच्या उदाहरणांसाठी [`MaybeUninit::zeroed`][zeroed] पहा.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// `Arc<T>` मध्ये रूपांतरित करते.
    ///
    /// # Safety
    ///
    /// एक्स 100 एक्स प्रमाणेच, आतील मूल्य खरोखर आरंभिक स्थितीत आहे याची हमी देणे कॉल करणार्‍यावर अवलंबून आहे.
    ///
    /// जेव्हा सामग्री अद्याप पूर्णपणे प्रारंभ केलेली नसते तेव्हा कॉल केल्यास तत्काळ अपरिभाषित वर्तन होते.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // स्थगित आरंभ:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// `Arc<[T]>` मध्ये रूपांतरित करते.
    ///
    /// # Safety
    ///
    /// एक्स 100 एक्स प्रमाणेच, आतील मूल्य खरोखर आरंभिक स्थितीत आहे याची हमी देणे कॉल करणार्‍यावर अवलंबून आहे.
    ///
    /// जेव्हा सामग्री अद्याप पूर्णपणे प्रारंभ केलेली नसते तेव्हा कॉल केल्यास तत्काळ अपरिभाषित वर्तन होते.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // स्थगित आरंभ:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// गुंडाळलेला पॉईंटर परत करून, `Arc` घेतो.
    ///
    /// मेमरी गळती टाळण्यासाठी पॉईंटरला [`Arc::from_raw`] वापरून परत एक्स 0 एक्स मध्ये रुपांतरित करणे आवश्यक आहे.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// डेटाला एक कच्चा सूचक प्रदान करते.
    ///
    /// गणना कोणत्याही प्रकारे प्रभावित होत नाहीत आणि `Arc` वापरली जात नाही.
    /// `Arc` मध्ये मजबूत संख्या आहेत तोपर्यंत पॉईंटर वैध आहे.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // सुरक्षितता: हे Deref::deref किंवा RcBoxPtr::inner मध्ये जाऊ शकत नाही कारण
        // यासाठी एक्स. एक्स एक्स प्रोव्हान्सन्स ठेवणे आवश्यक आहे उदा
        // `get_mut` `from_raw` द्वारे आरसी पुनर्प्राप्त झाल्यानंतर पॉईंटरद्वारे लिहू शकता.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// कच्च्या पॉईंटरमधून एक `Arc<T>` तयार करते.
    ///
    /// कच्चा सूचक यापूर्वी [`Arc<U>::into_raw`][into_raw] वर कॉलद्वारे परत आला असावा जिथे `U` चा आकार आणि संरेखन `T` सारखे असणे आवश्यक आहे.
    /// `U` `T` असल्यास हे क्षुल्लकपणे सत्य आहे.
    /// लक्षात घ्या की जर `U` हे X01 एक्स नसले परंतु त्याचे आकार आणि संरेखन समान असेल तर हे मुळात वेगवेगळ्या प्रकारचे संदर्भ ट्रान्समिट करण्यासारखे आहे.
    /// या प्रकरणात कोणते प्रतिबंध लागू आहेत याविषयी अधिक माहितीसाठी [`mem::transmute`][transmute] पहा.
    ///
    /// `from_raw` च्या वापरकर्त्यास हे निश्चित केले पाहिजे की `T` चे विशिष्ट मूल्य फक्त एकदाच सोडले गेले आहे.
    ///
    /// हे कार्य असुरक्षित आहे कारण अयोग्य वापरामुळे मेमरी असुरक्षित होऊ शकते, जरी परत आलेल्या `Arc<T>` मध्ये कधीही प्रवेश केला नसला तरीही.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // गळती रोखण्यासाठी परत `Arc` मध्ये रुपांतरित करा.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Arc::from_raw(x_ptr)` चे पुढील कॉल मेमरी-असुरक्षित असतील.
    /// }
    ///
    /// // जेव्हा एक्स 100 एक्स वरील व्याप्तीच्या बाहेर गेला तेव्हा मेमरी मोकळी झाली, म्हणून आता एक्स 0 एक्स एक्स झुकत आहे!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // मूळ आर्कीइनर शोधण्यासाठी ऑफसेटला उलट करा.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// या वाटपासाठी नवीन [`Weak`] पॉईंटर तयार करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // हे रिलॅक्स्ड ठीक आहे कारण आम्ही खाली असलेल्या सीएएसमधील मूल्य तपासत आहोत.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // कमकुवत काउंटर सध्या "locked" आहे का ते तपासा;असल्यास, फिरकी.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: हा कोड ओव्हरफ्लोच्या शक्यतेकडे दुर्लक्ष करतो
            // usize::MAX मध्ये;ओव्हरफ्लोचा सामना करण्यासाठी सर्वसाधारणपणे आरसी आणि आर्क दोन्ही समायोजित करणे आवश्यक आहे.
            //

            // Clone() च्या विपरीत, आम्हाला हे `is_unique` पासून आलेल्या लेखनासह समक्रमित करण्यासाठी एक्वायर वाचन असणे आवश्यक आहे, जेणेकरून त्या लिखाणापूर्वी घडलेल्या घटना या वाचनाच्या आधी घडतील.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // आम्ही एक डेंगलिंग कमकुवत तयार करत नाही हे सुनिश्चित करा
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// या वाटपासाठी [`Weak`] पॉइंटर्सची संख्या मिळते.
    ///
    /// # Safety
    ///
    /// ही पद्धत स्वतःच सुरक्षित आहे, परंतु ती योग्यरित्या वापरण्यासाठी अतिरिक्त काळजी घेणे आवश्यक आहे.
    /// या पद्धतीवर कॉल करणे आणि परिणामावर कार्य करणे यासह संभाव्यतः यासह दुसरा धागा कधीही कमकुवत गणना बदलू शकतो.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // हे ठाम मत निरोधक आहे कारण आम्ही थ्रेड दरम्यान `Arc` किंवा `Weak` सामायिक केले नाही.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // कमकुवत गणना सध्या लॉक केली असल्यास लॉक घेण्यापूर्वी मोजणीचे मूल्य 0 होते.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// या toलोकेशनला मजबूत (`Arc`) पॉईंटर्सची संख्या मिळते.
    ///
    /// # Safety
    ///
    /// ही पद्धत स्वतःच सुरक्षित आहे, परंतु ती योग्यरित्या वापरण्यासाठी अतिरिक्त काळजी घेणे आवश्यक आहे.
    /// या पद्धतीवर कॉल करणे आणि परिणामावर कार्य करणे यासह संभाव्यतः यासह दुसरा धागा कधीही मजबूत गणना बदलू शकतो.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // हे ठाम मत निरोधक आहे कारण आम्ही थ्रेडच्या दरम्यान `Arc` सामायिक केले नाही.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// एकाद्वारे प्रदान केलेल्या पॉईंटरशी संबंधित `Arc<T>` वर मजबूत संदर्भ संख्या वाढवते.
    ///
    /// # Safety
    ///
    /// पॉईंटर `Arc::into_raw` द्वारे प्राप्त केले असावे आणि संबंधित `Arc` घटना वैध असणे आवश्यक आहे (उदा
    /// या पद्धतीच्या कालावधीसाठी सशक्त गणना किमान 1) असणे आवश्यक आहे.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // हे ठाम मत निरोधक आहे कारण आम्ही थ्रेडच्या दरम्यान `Arc` सामायिक केले नाही.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // चाप कायम ठेवा, परंतु मॅन्युअलीड्रॉपमध्ये लपेटून रीकाउंटला स्पर्श करू नका
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // आता रीफकउंट वाढवा, परंतु नवीन रीकाउंट देखील टाकू नका
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// एकाद्वारे प्रदान केलेल्या पॉईंटरशी संबंधित `Arc<T>` वरील मजबूत संदर्भ संख्या कमी करते.
    ///
    /// # Safety
    ///
    /// पॉईंटर `Arc::into_raw` द्वारे प्राप्त केले असावे आणि संबंधित `Arc` घटना वैध असणे आवश्यक आहे (उदा
    /// ही पद्धत वापरत असताना मजबूत संख्या कमीतकमी 1) असणे आवश्यक आहे.
    /// ही पद्धत अंतिम एक्स 100 एक्स आणि बॅकिंग स्टोरेज सोडण्यासाठी वापरली जाऊ शकते, परंतु अंतिम एक्स01 एक्स रिलीझ झाल्यानंतर ** कॉल केला जाऊ नये.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // ते ठामपणे निवेदक आहेत कारण आम्ही थ्रेड्समध्ये `Arc` सामायिक केले नाही.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // हे असुरक्षितपणा ठीक आहे कारण हा कंस जिवंत असतानाच आपल्यास खात्री आहे की अंतर्गत पॉईंटर वैध आहे.
        // याउप्पर, आम्हाला हे माहित आहे की `ArcInner` ची रचना स्वतःच `Sync` आहे कारण आतील डेटा देखील `Sync` आहे, म्हणून आम्ही या सामग्रीसाठी निर्विकार पॉईंटरसाठी कर्ज घेत आहोत.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // `drop` चा अविभाज्य भाग.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // आम्ही बॉक्स वाटप स्वतःच मुक्त करू शकत नसलो तरीही या वेळी डेटा नष्ट करा (अजूनही तेथे कमकुवत पॉईंटर्स असू शकतात).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // सर्व सशक्त संदर्भांद्वारे एकत्रितपणे कमकुवत रेफ ड्रॉप करा
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// जर दोन `आर्केस समान वाटपाकडे निर्देशित केले तर `true` मिळवते ([`ptr::eq`] प्रमाणेच शिरामध्ये).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// संभाव्य-आकार नसलेल्या अंतर्गत मूल्यासाठी जेथे लेआउट प्रदान केले आहे तेथे पुरेशी जागा असलेल्या `ArcInner<T>` चे वाटप करते.
    ///
    /// `mem_to_arcinner` फंक्शनला डेटा पॉईंटरसह म्हटले जाते आणि `ArcInner<T>` साठी (संभाव्य चरबी)-पॉईंटर परत करणे आवश्यक आहे.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // दिलेल्या मूल्याच्या लेआउटचा वापर करुन लेआउटची गणना करा.
        // पूर्वी एक्सआॅक्सएक्सएक्सएक्सएक्सन वर लेआउटची गणना केली जात होती, परंतु यामुळे चुकीचा सही संदर्भ तयार केला गेला (#54908 पहा).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// संभाव्यत-आकार नसलेल्या आतील मूल्यासाठी पुरेशा जागेसह एक X00 एक्सचे वाटप करते जेथे मूल्य दिले आहे लेआउट प्रदान केले आहे, वाटप अयशस्वी झाल्यास त्रुटी परत करेल.
    ///
    ///
    /// `mem_to_arcinner` फंक्शनला डेटा पॉईंटरसह म्हटले जाते आणि `ArcInner<T>` साठी (संभाव्य चरबी)-पॉईंटर परत करणे आवश्यक आहे.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // दिलेल्या मूल्याच्या लेआउटचा वापर करुन लेआउटची गणना करा.
        // पूर्वी एक्सआॅक्सएक्सएक्सएक्सएक्सन वर लेआउटची गणना केली जात होती, परंतु यामुळे चुकीचा सही संदर्भ तयार केला गेला (#54908 पहा).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // आर्कीइन्सर प्रारंभ करा
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// आकार नसलेल्या अंतर्गत मूल्यासाठी पुरेशी जागा असलेले `ArcInner<T>` चे वाटप करते.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // दिलेली व्हॅल्यू वापरुन एक्स00 एक्ससाठी वाटप करा.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // बाइट्स म्हणून मूल्य कॉपी करा
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Contentsलोकेशनची सामग्री न सोडता मोकळी करा
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// दिलेल्या लांबीसह एक `ArcInner<[T]>` वाटप करते.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// नव्याने वाटप केलेल्या आर्क <\[टी\]> मध्ये स्लाइसमधून घटक कॉपी करा
    ///
    /// असुरक्षित आहे कारण कॉलरने एकतर मालकी घेणे आवश्यक आहे किंवा `T: Copy` प्रतिबद्ध करणे आवश्यक आहे.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// एका विशिष्ट आकाराचे ज्ञात असलेल्या इटरेटरकडून एक `Arc<[T]>` तयार करते.
    ///
    /// आकार चुकीचा असेल तर वर्तणूक अपरिभाषित आहे.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // टी घटकांची क्लोनिंग करत असताना झेडपॅनिक ० झेड गार्ड.
        // झेडस्पॅनिक0 झेडच्या घटनेत, नवीन आर्कइन्नरमध्ये लिहिलेले घटक सोडले जातील, त्यानंतर मेमरी मुक्त होईल.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // प्रथम घटकाकडे निर्देशक
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // सर्व स्पष्ट.गार्डला विसरा जेणेकरून हे नवीन आर्कीइनर मुक्त करणार नाही.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` साठी वापरलेली विशेषीकरण trait.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// `Arc` पॉईंटरचा क्लोन बनवते.
    ///
    /// हे त्याच संदर्भात आणखी एक पॉईंटर तयार करते, मजबूत संदर्भ संख्या वाढवते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // येथे रिलॅक्स ऑर्डरिंग वापरणे ठीक आहे, कारण मूळ संदर्भाचे ज्ञान अन्य थ्रेड्स चुकून ऑब्जेक्ट हटविण्यापासून प्रतिबंधित करते.
        //
        // [Boost documentation][1] मध्ये वर्णन केल्याप्रमाणे, संदर्भ काउंटर वाढविणे नेहमीच मेमरी_ऑर्डररेक्स्डसह केले जाऊ शकते: ऑब्जेक्टचे नवीन संदर्भ केवळ अस्तित्वातील संदर्भातूनच तयार केले जाऊ शकतात आणि अस्तित्वातील संदर्भ एका थ्रेडमधून दुसर्‍याकडे पाठविणे आधीपासूनच आवश्यक सिंक्रोनाइझेशन प्रदान करणे आवश्यक आहे.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // तथापि एखादी व्यक्ती `मेम: : विसरणे चाप आहे अशा स्थितीत आम्हाला मोठ्या प्रमाणात पैसे मोजण्यापासून संरक्षण देणे आवश्यक आहे.
        // आम्ही हे न केल्यास गणना ओव्हरफ्लो होऊ शकते आणि वापरकर्ते विनामूल्य-वापरु शकतात.
        // आम्ही एकाच वेळी संदर्भ संख्या वाढविणारे ~2 अब्ज थ्रेड नसल्या आहेत असे समजून आम्ही `isize::MAX` ला धैर्याने भरले.
        //
        // हा झेड00051 बी 0 झेड कोणत्याही वास्तविक कार्यक्रमात घेतला जाणार नाही.
        //
        // आम्ही गर्भपात करतो कारण असा प्रोग्राम आश्चर्यकारकपणे पतित आहे आणि आम्हाला त्याचे समर्थन करण्याची काळजी नाही.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// दिलेल्या `Arc` मध्ये एक परिवर्तनीय संदर्भ बनविते.
    ///
    /// समान वाटपासाठी इतर `Arc` किंवा [`Weak`] पॉईंटर्स असल्यास, एक्स एक्स 2 एक्स एक नवीन वाटप तयार करेल आणि अनन्य मालकीची खात्री करण्यासाठी आतील मूल्यावर एक्स03 एक्सची विनंती करेल.
    /// याला क्लोन-ऑन-राइट असेही म्हणतात.
    ///
    /// लक्षात ठेवा की हे [`Rc::make_mut`] च्या वर्तनपेक्षा भिन्न आहे जे उर्वरित `Weak` पॉईंटर्स वेगळे करते.
    ///
    /// [`get_mut`][get_mut] देखील पहा, जे क्लोनिंग करण्याऐवजी अपयशी ठरेल.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // काहीही क्लोन करणार नाही
    /// let mut other_data = Arc::clone(&data); // अंतर्गत डेटा क्लोन करणार नाही
    /// *Arc::make_mut(&mut data) += 1;         // क्लोन्स अंतर्गत डेटा
    /// *Arc::make_mut(&mut data) += 1;         // काहीही क्लोन करणार नाही
    /// *Arc::make_mut(&mut other_data) *= 2;   // काहीही क्लोन करणार नाही
    ///
    /// // आता `data` आणि `other_data` वेगवेगळ्या वाटपाकडे निर्देश करतात.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // लक्षात ठेवा की आम्ही एक मजबूत संदर्भ आणि कमकुवत संदर्भ दोन्ही ठेवतो.
        // म्हणूनच, आमचा मजबूत संदर्भ सोडल्यास, स्वतःच स्मरणशक्ती कमी होणार नाही.
        //
        // एक्सेस (एक्सक्वायर) वापरा हे सुनिश्चित करण्यासाठी की एक्स-एक्सएक्सएक्सला कोणतेही लेखन दिसतात जे `strong` वर रिलीझ होण्यापूर्वी होते (म्हणजे कमी होते).
        // आमच्याकडे कमकुवत संख्या असल्याने, आर्कइन्टर स्वतःच कमी पडण्याची शक्यता नाही.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // दुसरा मजबूत पॉईन्टर अस्तित्वात आहे, म्हणून आपण क्लोन करणे आवश्यक आहे.
            // क्लोन केलेले मूल्य थेट लिहिण्याची परवानगी देण्यासाठी पूर्व-वाटप मेमरी.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // वरील गोष्टींमध्ये आरामशीर दु: ख आहे कारण हे मूलभूतपणे एक ऑप्टिमायझेशन आहे: आम्ही नेहमीच कमकुवत पॉईंटर्स टाकून रेस करीत असतो.
            // सर्वात वाईट बाब म्हणजे आम्ही अनावश्यकपणे नवीन आर्कचे वाटप केले.
            //

            // आम्ही शेवटचा मजबूत रेफ काढला, परंतु तेथे अतिरिक्त कमकुवत रेफ बाकी आहेत.
            // आम्ही सामग्री एका नवीन आर्कवर हलवू आणि अन्य कमकुवत रेफ्रेस अवैध करू.
            //

            // लक्षात घ्या की `weak` चे वाचन usize::MAX (म्हणजेच लॉक केलेले) मिळविणे शक्य नाही, कारण कमकुवत गणना केवळ एका मजबूत संदर्भात धाग्याने लॉक केली जाऊ शकते.
            //
            //

            // आमच्या स्वत: च्या अंतर्भूत कमकुवत पॉईंटरला सामील करा, जेणेकरून ते आवश्यकतेनुसार आर्केइनर साफ करू शकेल.
            //
            let _weak = Weak { ptr: this.ptr };

            // फक्त डेटा चोरू शकतो, उरलेलं सगळं
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // आम्ही एकतर प्रकारचा एकमेव संदर्भ होतो;मजबूत रेफ मोजणीचा बॅक अप घ्या.
            //
            this.inner().strong.store(1, Release);
        }

        // `get_mut()` प्रमाणे, असुरक्षितपणा ठीक आहे कारण आमचा संदर्भ एकतर सुरू करण्यासाठी अनोखा होता किंवा सामग्री क्लोनिंग केल्यावर झाला.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// समान वाटप करण्यासाठी कोणतेही इतर `Arc` किंवा [`Weak`] पॉईंटर्स नसल्यास दिलेल्या `Arc` मध्ये एक बदलण्यायोग्य संदर्भ मिळवते.
    ///
    ///
    /// अन्यथा [`None`] मिळवते, कारण सामायिक केलेल्या मूल्याचे रुपांतरण करणे सुरक्षित नाही.
    ///
    /// [`make_mut`][make_mut] देखील पहा, जे इतर पॉईंटर्स असतात तेव्हा अंतर्गत मूल्य [`clone`][clone] करेल.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // हे असुरक्षित आहे कारण आम्हाला खात्री आहे की पॉईंटर परत आला *फक्त* पॉईंटर जो कधीही टी वर परत जाईल.
            // आमची संदर्भ संख्या या टप्प्यावर 1 ची हमी आहे आणि आम्हाला आर्क स्वतःच `mut` असणे आवश्यक आहे, म्हणून आम्ही केवळ अंतर्गत संदर्भातील संभाव्य संदर्भ परत करत आहोत.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// कोणत्याही चेकशिवाय, दिलेल्या `Arc` मध्ये बदलणारा संदर्भ मिळवते.
    ///
    /// [`get_mut`] देखील पहा, जे सुरक्षित आहे आणि योग्य तपासणी करते.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// परत दिलेल्या कर्जाच्या कालावधीसाठी समान वाटपासाठी अन्य कोणतेही `Arc` किंवा [`Weak`] पॉईंटर्सचा आदर करणे आवश्यक नाही.
    ///
    /// असे कोणतेही पॉइंटर्स अस्तित्वात नसल्यास, क्षुल्लकदृष्ट्या असे आहे उदाहरणार्थ, एक्स00 एक्स नंतर लगेच.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // आम्ही "count" फील्ड्स कव्हर करणारा संदर्भ * तयार करू नये याची खबरदारी घेत आहोत, कारण हे संदर्भ मोजमापांच्या अनुरुप प्रवेशासह उर्फ असेल (उदा.
        // `Weak` द्वारा).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// मूलभूत डेटाचा हा अद्वितीय संदर्भ (कमकुवत रेफ्रेससह) आहे की नाही हे ठरवा.
    ///
    ///
    /// लक्षात घ्या की यासाठी कमकुवत संदर्भ संख्या लॉक करणे आवश्यक आहे.
    fn is_unique(&mut self) -> bool {
        // आम्ही एकमात्र कमकुवत पॉईंटर धारक असल्याचे दिसत असल्यास कमकुवत पॉइंटर गणना लॉक करा.
        //
        // येथे अधिग्रहण लेबल `weak` गणना कमी होण्यापूर्वी `strong` (विशेषकरुन `Weak::upgrade` मध्ये) लिहिण्याशी संबंधित होण्यापूर्वीचे संबंध सुनिश्चित करते (`Weak::drop` मार्गे, जे रिलीझ वापरते).
        // अपग्रेड केलेले कमकुवत रेफ कधीही सोडले नाही तर इथले सीएएस अपयशी ठरतील म्हणून आम्हाला समक्रमित करण्याची काळजी नाही.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // हे `drop` मधील `strong` काउंटरच्या घटतेसह समक्रमित करण्यासाठी एक `Acquire` असणे आवश्यक आहे-शेवटचा संदर्भ सोडला जात असताना केवळ तेव्हाच होतो जेव्हा प्रवेश केला जातो.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // येथे रिलीझ राइट `downgrade` मधील वाचनासह संकालित करते, `strong` च्या वरील वाचनास प्रभावीपणे लेखनानंतर होण्यापासून प्रतिबंध करते.
            //
            //
            self.inner().weak.store(1, Release); // लॉक सोडा
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// एक्स 100 एक्स ड्रॉप.
    ///
    /// यामुळे दृढ संदर्भ संख्या कमी होईल.
    /// जर सशक्त संदर्भ संख्या शून्यापर्यंत पोहोचली तर केवळ इतर संदर्भ (काही असल्यास) [`Weak`] आहेत, म्हणून आम्ही अंतर्गत मूल्य `drop` करतो.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // काहीही छापत नाही
    /// drop(foo2);   // "dropped!" मुद्रित करते
    /// ```
    #[inline]
    fn drop(&mut self) {
        // कारण `fetch_sub` आधीपासूनच अणू आहे, जोपर्यंत आपण ऑब्जेक्ट हटवणार नाही तोपर्यंत आम्हाला इतर थ्रेडसह समक्रमित करण्याची आवश्यकता नाही.
        // हे समान लॉजिक `weak` गणना खाली `fetch_sub` ला लागू आहे.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // डेटाचा पुनर्क्रमित करणे आणि डेटा हटविणे टाळण्यासाठी हे कुंपण आवश्यक आहे.
        // हे `Release` म्हणून चिन्हांकित केलेले असल्याने, संदर्भ संख्या कमी होत या `Acquire` कुंपणासह समक्रमित होते.
        // याचा अर्थ असा आहे की डेटाचा वापर संदर्भ संख्या कमी होण्यापूर्वी होतो, जो या कुंपणापूर्वी होतो, जो डेटा हटविण्यापूर्वी होतो.
        //
        // [Boost documentation][1] मध्ये स्पष्ट केल्याप्रमाणे,
        //
        // > त्यामध्ये ऑब्जेक्टमध्ये कोणत्याही संभाव्य प्रवेशाची अंमलबजावणी करणे महत्वाचे आहे
        // > *हटविण्यापूर्वी* व्हायचा धागा (विद्यमान संदर्भाद्वारे)
        // > भिन्न थ्रेडमधील ऑब्जेक्ट.हे "release" द्वारे प्राप्त झाले आहे
        // > संदर्भ सोडल्यानंतर ऑपरेशन (ऑब्जेक्टमध्ये कोणताही प्रवेश
        // > या संदर्भात स्पष्टपणे आधी घडलेच पाहिजे) आणि अ
        // > "acquire" ऑब्जेक्ट हटविण्यापूर्वी ऑपरेशन.
        //
        // विशेषतः, एखाद्या आर्कमधील सामग्री सहसा बदलण्यायोग्य नसली तरी, म्युटेक्स सारख्या एखाद्या गोष्टीसाठी इंटिरियर लिहिणे शक्य आहे<T>.
        // हे डिलीट केल्यावर म्यूटेक्स प्राप्त झाले नसल्यामुळे आम्ही थ्रेड बी मध्ये धागा अ लिहिण्याकरिता त्याच्या सिंक्रोनाइझेशन लॉजिकवर अवलंबून राहू शकत नाही.
        //
        //
        // हे देखील लक्षात घ्या की येथे quक्वायर कुंपण कदाचित अक्वायर लोडसह बदलले जाऊ शकते, जे अत्यंत विवादित परिस्थितीत कामगिरी सुधारू शकते.[2] पहा.
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// कॉंक्रिट प्रकारात एक्स 100 एक्स डाउनकास्ट करण्याचा प्रयत्न.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// कोणतीही मेमरी वाटप न करता नवीन `Weak<T>` तयार करते.
    /// परतीच्या मूल्यावर [`upgrade`] वर कॉल करणे नेहमी [`None`] देते.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// डेटा फील्डबद्दल कोणतेही ठाम मत न घेता संदर्भ गणनांमध्ये प्रवेश करण्यास अनुमती देणारा मदतनीस प्रकार.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// या `Weak<T>` द्वारे दर्शविलेल्या ऑब्जेक्ट `T` वर एक कच्चा सूचक मिळवते.
    ///
    /// काही मजबूत संदर्भ असल्यासच पॉईंटर वैध असते.
    /// पॉईंटर अन्यत्र अन्यथा, डेंगलिंग, अस्वाक्षरीकृत किंवा अगदी [`null`] देखील असू शकतो.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // दोन्ही एकाच वस्तूकडे निर्देश करतात
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // येथे मजबूत तो जिवंत ठेवतो, म्हणून आम्ही अद्याप त्या ऑब्जेक्टमध्ये प्रवेश करू शकतो.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // पण आता नाही.
    /// // आम्ही weak.as_ptr() करू शकतो, परंतु पॉईंटरमध्ये प्रवेश केल्याने अपरिभाषित वर्तन होते.
    /// // assert_eq! ("हॅलो", असुरक्षित {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // पॉईंटर डेंगिंग होत असल्यास आम्ही सेन्टिनल थेट परत करतो.
            // हा वैध पेलोड पत्ता असू शकत नाही, कारण पेलोड कमीतकमी आर्कीइन्सर एक्स 100 एक्स म्हणून संरेखित असेल.
            ptr as *const T
        } else {
            // सुरक्षाः जर is_dangling चुकीचे परत आले तर पॉइंटर डीरेफरेन्सेबल आहे.
            // पेलोड या टप्प्यावर सोडले जाऊ शकते आणि आम्हाला प्रोव्हन्सन्स राखणे आवश्यक आहे, म्हणून कच्चे पॉइंटर हाताळणे वापरा.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// `Weak<T>` घेते आणि त्यास कच्च्या पॉइंटरमध्ये बदलते.
    ///
    /// हे एक कमकुवत संदर्भ मालकीचे जतन करीत असताना दुर्बल पॉईंटरला कच्च्या पॉइंटरमध्ये रुपांतरित करते (कमकुवत गणना या ऑपरेशनद्वारे सुधारित केली जात नाही).
    /// हे परत [`from_raw`] सह `Weak<T>` मध्ये बदलले जाऊ शकते.
    ///
    /// [`as_ptr`] प्रमाणे पॉईंटरच्या लक्ष्यावर प्रवेश करण्याच्या समान निर्बंध लागू आहेत.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// पूर्वी [`into_raw`] द्वारे निर्मित कच्चा पॉइंटर परत `Weak<T>` मध्ये रूपांतरित करते.
    ///
    /// याचा सुरक्षितपणे एक मजबूत संदर्भ मिळविण्यासाठी (नंतर X01 एक्स वर कॉल करून) किंवा `Weak<T>` टाकून कमकुवत मोजणी कमी करण्यासाठी वापरले जाऊ शकते.
    ///
    /// हे एका कमकुवत संदर्भाची मालकी घेते ([`new`] ने निर्मित पॉईंटर्सचा अपवाद वगळता, या कशाचेही मालक नसतात; तरीही पद्धत त्यांच्यावर कार्य करते).
    ///
    /// # Safety
    ///
    /// पॉईंटर [`into_raw`] मधील मूळ असावा आणि अद्याप त्याच्या संभाव्य कमकुवत संदर्भाचे मालक असले पाहिजेत.
    ///
    /// हे कॉल करण्याच्या वेळी सशक्त मोजणी 0 असणे अनुमत आहे.
    /// तथापि, हे सध्या कच्चे पॉइंटर म्हणून दर्शविलेल्या एका कमकुवत संदर्भाची मालकी घेते (कमकुवत गणना या ऑपरेशनद्वारे सुधारित केलेली नाही) आणि म्हणूनच ती एक्स 100 एक्स वर मागील कॉलसह जोडली जाणे आवश्यक आहे.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // शेवटची कमकुवत गणना कमी करा.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // इनपुट पॉईंटर कसे प्राप्त होते या संदर्भात Weak::as_ptr पहा.

        let ptr = if is_dangling(ptr as *mut T) {
            // ही एक लहरी कमकुवत आहे.
            ptr as *mut ArcInner<T>
        } else {
            // अन्यथा, आम्ही हमी देतो की पॉईंटर एका अशक्त कमकुवतपणाकडून आला आहे.
            // सुरक्षा: डेटा_ऑफसेट कॉल करणे सुरक्षित आहे, कारण पीटीआरचा संदर्भ वास्तविक (संभाव्यत: सोडलेला) टी.
            let offset = unsafe { data_offset(ptr) };
            // अशाप्रकारे, संपूर्ण आरसीबॉक्स मिळविण्यासाठी आम्ही ऑफसेटला उलट करतो.
            // सुरक्षितता: पॉईंटर दुर्बल पासून उत्पन्न झाले आहे, म्हणूनच हे ऑफसेट सुरक्षित आहे.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // सुरक्षितता: आम्ही आता मूळ कमकुवत पॉइंटर पुनर्प्राप्त केला आहे, त्यामुळे दुर्बल तयार करू शकतो.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// `Weak` पॉईंटरला [`Arc`] वर श्रेणीसुधारित करण्याचा प्रयत्न, यशस्वी झाल्यास अंतर्गत मूल्य सोडण्यास विलंब.
    ///
    ///
    /// आतील मूल्य नंतरपासून सोडल्यास [`None`] मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // सर्व मजबूत पॉईंटर्स नष्ट करा.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // आम्ही fetch_add ऐवजी मजबूत गणना वाढविण्यासाठी CAS पळवाट वापरतो कारण हे कार्य कधीही संदर्भ संख्या शून्यातून घेऊ नये.
        //
        //
        let inner = self.inner()?;

        // रिलॅक्स्ड लोड कारण 0 चे कोणतेही लेखन जे आपण निरीक्षण करू शकतो ते फील्ड कायमस्वरुपी शून्य स्थितीत सोडते (म्हणून 0 चे "stale" वाचन ठीक आहे), आणि इतर कोणत्याही मूल्याची पुष्टी खाली सीएएसद्वारे केली गेली.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // आम्ही हे का करतो यासाठी (X01 एक्ससाठी) एक्स 100 एक्स मधील टिप्पण्या पहा.
            if n > MAX_REFCOUNT {
                abort();
            }

            // विफलतेच्या प्रकरणात विश्रांती ठीक आहे कारण आम्हाला नवीन राज्याबद्दल कोणतीही अपेक्षा नाही.
            // `Arc::new_cyclic` सह सिंक्रोनाइझ करण्यासाठी सक्सेस केससाठी एक्क्वायर आवश्यक आहे, जेव्हा एक्स 01 एक्स संदर्भ तयार केले गेल्यानंतर अंतर्गत मूल्य आरंभ केले जाऊ शकते.
            // अशा परिस्थितीत आम्ही पूर्णपणे आरंभ केलेल्या मूल्याचे निरीक्षण करण्याची अपेक्षा करतो.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // खाली शून्य
                Err(old) => n = old,
            }
        }
    }

    /// या ationलोकेशनकडे निर्देश करणार्‍या सशक्त (`Arc`) पॉइंटर्सची संख्या मिळते.
    ///
    /// जर `self` हे [`Weak::new`] वापरून तयार केले गेले असेल तर ते 0 येईल.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// या ationलोकेशनकडे निर्देशित केलेल्या `Weak` पॉईंटर्सच्या संख्येचे अंदाजे मूल्य मिळते.
    ///
    /// जर `self` हे [`Weak::new`] वापरून तयार केले गेले असेल किंवा उर्वरित कोणतेही मजबूत पॉइंटर्स नसल्यास, हे 0 येईल.
    ///
    /// # Accuracy
    ///
    /// अंमलबजावणीच्या तपशीलांमुळे, जेव्हा इतर थ्रेड्स कोणत्याही `आर्केस किंवा` दुर्बल व्यक्तींना समान वाटपाकडे निर्देशित करतात तेव्हा हाताळत असताना परत केलेले मूल्य दोन्ही दिशेने 1 ने बंद केले जाऊ शकते.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // आम्ही पाहिले की कमकुवत गणना वाचल्यानंतर कमीतकमी एक मजबूत पॉईन्टर होता, आम्ही जाणतो की जेव्हा आम्ही कमकुवत गणना पाहिली तेव्हा अंतर्निहित कमकुवत संदर्भ (जेव्हा कोणतेही मजबूत संदर्भ जिवंत असतात तेव्हा उपस्थित) अजूनही असतो आणि म्हणूनच तो सुरक्षितपणे वजाबाकी करू शकतो.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// पॉईंटर डेंग होत असताना X01 एक्स मिळवते आणि तेथे कोणतेही `ArcInner` वाटप केलेले नाही, (म्हणजे जेव्हा हे `Weak` `Weak::new` द्वारे तयार केले गेले होते).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // आम्ही एक्सएक्सएक्स एक्स फील्डला कव्हर करणारा *संदर्भ* तयार करू नये याची खबरदारी घेत आहोत, कारण हे फील्ड एकाचवेळी बदलले जाऊ शकते (उदाहरणार्थ, शेवटचा एक्स ०१ एक्स सोडल्यास डेटा फील्ड जागी सोडली जाईल).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// जर दोन `दुर्बलांचे समान वाटप ([`ptr::eq`] प्रमाणेच) वर निर्देशित केले तर किंवा दोन्ही कोणत्याही वितरणास सूचित करीत नसल्यास `true` मिळविते (कारण ते `Weak::new()`) सह तयार केले गेले होते).
    ///
    ///
    /// # Notes
    ///
    /// हे पॉईंटर्सची तुलना करत असल्याने याचा अर्थ असा की `Weak::new()` एकमेकांच्या बरोबरी करेल, जरी त्यांनी कोणत्याही वाटपाकडे लक्ष दिले नाही.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// तुलना करीत आहे `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// त्याच वाटपाकडे निर्देशित करणारा `Weak` पॉईंटरचा क्लोन बनवितो.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // हे शिथिल का केले गेले यासाठी Arc::clone() मधील टिप्पण्या पहा.
        // हे एक फेच_एडडी वापरू शकते (लॉककडे दुर्लक्ष करून) कारण कमकुवत गणना केवळ तेथेच लॉक केलेली आहे जिथे अस्तित्वातील इतर कोणतेही कमकुवत पॉइंटर्स नाहीत.
        //
        // (म्हणून आम्ही त्या बाबतीत हा कोड चालवू शकत नाही).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // आम्ही हे का करतो यासाठी (X01 एक्ससाठी) एक्स 100 एक्स मधील टिप्पण्या पहा.
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// मेमरीचे वाटप न करता नवीन `Weak<T>` तयार करते.
    /// परतीच्या मूल्यावर [`upgrade`] वर कॉल करणे नेहमी [`None`] देते.
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` पॉईंटर ड्रॉप करा.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // काहीही छापत नाही
    /// drop(foo);        // "dropped!" मुद्रित करते
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // आम्ही शेवटचे कमकुवत पॉइंटर असल्याचे आम्हाला आढळल्यास डेटा पूर्णपणे विस्कळीत करण्याची वेळ आली आहे.मेमरी ऑर्डरिंगबद्दल Arc::drop() मध्ये चर्चा पहा
        //
        // येथे लॉक केलेल्या अवस्थेची तपासणी करणे आवश्यक नाही, कारण एक कमकुवत रेफ असेल तरच कमकुवत गणना लॉक केली जाऊ शकते, म्हणजेच ड्रॉप त्यानंतरच्या उर्वरित कमकुवत रेफवरच चालू शकते, जे लॉक सोडल्यानंतरच होऊ शकते.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// आम्ही हे स्पेशलायझेशन येथे करत आहोत, आणि एक्स 100 एक्स वर अधिक सामान्य ऑप्टिमायझेशन म्हणून नाही, कारण रेफवरील सर्व समानता तपासणीसाठी हे अन्यथा खर्च करेल.
/// आम्ही असे गृहित धरतो की `आर्केस मोठ्या मूल्यांची संचयित करण्यासाठी वापरली जातात, जी क्लोन करणे धीमे असतात, परंतु समानता तपासण्यासाठी देखील जड असतात, ज्यामुळे ही किंमत अधिक सहजतेने चुकते.
///
/// दोन एक्स 100 एक्स क्लोन असण्याचीही शक्यता आहे, ती समान मूल्याकडे दोन two&टीपेक्षा जास्त आहे.
///
/// आम्ही हे तेव्हाच करू शकतो जेव्हा `T: Eq` एक X01 एक्स म्हणून मुद्दाम इराफॅक्सिव्ह असू शकेल.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// दोन `आर्केस साठी समानता.
    ///
    /// दोन `आर्के समान आहेत जर त्यांची अंतर्गत मूल्ये समान असतील, जरी ती वेगवेगळ्या ationलोकेशनमध्ये संग्रहित आहेत.
    ///
    /// जर `T` देखील `Eq` (समानतेची प्रतिक्षिप्तता) अंमलात आणत असेल तर, समान वाटपाकडे निर्देशित करणारे दोन `आर्केस नेहमीच समान असतात.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// दोन `आर्केस साठी असमानता.
    ///
    /// जर त्यांची अंतर्गत मूल्ये असमान असतील तर दोन `आर्क असमान असतात.
    ///
    /// जर `T` देखील `Eq` (समानतेची प्रतिक्षिप्तता) अंमलात आणत असेल तर, समान मूल्याकडे निर्देशित करणारे दोन `आर्के कधीही असमान नसतात.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// दोन `आर्केसची आंशिक तुलना.
    ///
    /// त्यांच्या अंतर्गत मूल्यांवर `partial_cmp()` कॉल करून या दोघांची तुलना केली जाते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// दोन `आर्केसाठी तुलना पेक्षा कमी.
    ///
    /// त्यांच्या अंतर्गत मूल्यांवर `<` कॉल करून या दोघांची तुलना केली जाते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// दोन `आर्केसची तुलना 'पेक्षा कमी किंवा समान'.
    ///
    /// त्यांच्या अंतर्गत मूल्यांवर `<=` कॉल करून या दोघांची तुलना केली जाते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// दोन-आर्केसपेक्षा मोठी तुलना.
    ///
    /// त्यांच्या अंतर्गत मूल्यांवर `>` कॉल करून या दोघांची तुलना केली जाते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// दोन `आर्केसची तुलना 'पेक्षा मोठी किंवा समान'.
    ///
    /// त्यांच्या अंतर्गत मूल्यांवर `>=` कॉल करून या दोघांची तुलना केली जाते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// दोन `आर्केससाठी तुलना.
    ///
    /// त्यांच्या अंतर्गत मूल्यांवर `cmp()` कॉल करून या दोघांची तुलना केली जाते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// `T` साठी `Default` मूल्यासह एक नवीन `Arc<T>` तयार करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// संदर्भ-मोजलेल्या स्लाइसचे वाटप करा आणि cl v` च्या आयटम क्लोनिंग करुन भरा.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// संदर्भ-मोजलेली `str` वाटप करा आणि त्यामध्ये `v` कॉपी करा.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// संदर्भ-मोजलेली `str` वाटप करा आणि त्यामध्ये `v` कॉपी करा.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// बॉक्स केलेल्या ऑब्जेक्टला नवीन, संदर्भ-मोजलेल्या ationलोकेशनवर हलवा.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// संदर्भ-मोजलेली स्लाइस वाटप करा आणि त्यामध्ये आयटम हलवा.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // वेकला त्याची मेमरी मोकळी करण्यास परवानगी द्या परंतु त्यातील सामग्री नष्ट करू नका
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// प्रत्येक घटक `Iterator` मध्ये घेते आणि ते `Arc<[T]>` मध्ये संकलित करते.
    ///
    /// # कामगिरी वैशिष्ट्ये
    ///
    /// ## सामान्य प्रकरण
    ///
    /// सामान्य प्रकरणात, `Arc<[T]>` मध्ये संग्रह प्रथम `Vec<T>` मध्ये गोळा करून केले जाते.ते आहे की, पुढील गोष्टी लिहितानाः
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// आम्ही लिहिल्याप्रमाणे असे वागते:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // वाटपांचा पहिला सेट येथे होतो.
    ///     .into(); // `Arc<[T]>` चे दुसरे वाटप येथे होते.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// हे `Vec<T>` तयार करण्यासाठी आवश्यक तेवढे वेळा वाटप करेल आणि नंतर ते X02 एक्सला `Arc<[T]>` मध्ये बदलण्यासाठी एकदा वाटप करेल.
    ///
    ///
    /// ## ज्ञात लांबीचे आयटेटर
    ///
    /// जेव्हा आपल्या `Iterator` ने `TrustedLen` लागू केली आणि अचूक आकाराचे असेल तेव्हा, `Arc<[T]>` साठी एकल वाटप केले जाईल.उदाहरणार्थ:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // येथे फक्त एक वाटप होते.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// एक्स 100 एक्स मध्ये गोळा करण्यासाठी वापरले स्पेशलायझेशन झेडट्रायट 0 झेड.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // हे एक एक्स 100 एक्स इटरेटरसाठी आहे.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // सुरक्षितता: आम्हाला हे सुनिश्चित करण्याची आवश्यकता आहे की पुनरावृत्ती करणार्‍याची लांबी अचूक आहे आणि आपल्याकडे आहे.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // सामान्य अंमलबजावणीकडे परत जा.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// पॉईंटरच्या मागे असलेल्या पेलोडसाठी `ArcInner` मध्ये ऑफसेट मिळवा.
///
/// # Safety
///
/// पॉईंटरने टीचे पूर्वीचे वैध उदाहरण दर्शविले पाहिजे (आणि यासाठी वैध मेटाडेटा असणे आवश्यक आहे), परंतु टी सोडण्याची परवानगी नाही.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // आर्केइनेरच्या शेवटी असुरक्षित मूल्य संरेखित करा.
    // कारण आरसीबॉक्स हे एक्स 100 एक्स आहे, ते नेहमीच मेमरीमधील शेवटचे फील्ड असेल.
    // सुरक्षितता: केवळ आकार नसलेले प्रकार म्हणजे काप, झेडट्रायट0 झेड ऑब्जेक्ट्स,
    // आणि बाह्य प्रकारांनुसार, align_of_val_raw च्या आवश्यकता पूर्ण करण्यासाठी इनपुट सुरक्षा आवश्यकता सध्या पुरेसे आहे;हे भाषेचे अंमलबजावणी तपशील आहे जे std च्या बाहेर अवलंबून राहू शकत नाही.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}