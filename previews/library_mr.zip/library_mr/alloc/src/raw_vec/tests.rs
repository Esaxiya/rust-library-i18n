use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // तृतीय-पक्षाच्या वाटप करणार्‍या आणि `RawVec` यांच्यात एकीकरणाची चाचणी लिहिणे थोडे अवघड आहे कारण `RawVec` एपीआय फॉलिबल ationलोकेशन पद्धती उघडकीस आणत नाही, म्हणून जेव्हा atorलोकटर संपत असेल तेव्हा काय होते ते आम्ही तपासू शकत नाही (झेडस्पॅनिक 0 झेड शोधण्यापलीकडे).
    //
    //
    // त्याऐवजी, हे तपासते की `RawVec` पद्धती कमीतकमी ocलोकेटर एपीआयमध्ये जातात जेव्हा हे स्टोरेज आरक्षित करते.
    //
    //
    //
    //
    //

    // वाटप करण्याच्या प्रयत्नांना अपयशी होण्यापूर्वी एक मुर्गा वाटप करणारा जो निश्चित प्रमाणात इंधन वापरतो.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (अशा रीतीने +० + १=०=२०० युनिट इंधन वापरुन रीलोक होतो)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // प्रथम, `reserve` `reserve_exact` प्रमाणे वाटप करते.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 हे 7 च्या दुप्पटपेक्षा अधिक आहे, म्हणून `reserve` `reserve_exact` प्रमाणे कार्य केले पाहिजे.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 हे 12 च्या अर्ध्यापेक्षा कमी आहे, म्हणून `reserve` वेगाने वाढणे आवश्यक आहे.
        // ही चाचणी लिहिण्याच्या वेळी वाढीचा घटक 2 असतो, म्हणून नवीन क्षमता 24 असते, तथापि, 1.5 चा वाढीचा घटकही ठीक आहे.
        //
        // म्हणून ठामपणे `>= 18`.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}