//! झेडपॅनिक्स 0 झेडची अंमलबजावणी स्टॅक अनावश्यक द्वारे
//!
//! हे crate हे Rust मध्ये panics ची अंमलबजावणी आहे ज्याचे प्लॅटफॉर्म ज्यासाठी संकलित केले जात आहे त्याच्या "most native" स्टॅक अनावश्यक यंत्रणेचा वापर करून केले आहे.
//! हे सध्या तीन बादल्यांमध्ये मूलत: वर्गीकृत केले आहे:
//!
//! 1. एमएसव्हीसी लक्ष्य एक्स-एक्स एक्स फाइलमध्ये एसईएच वापरतात.
//! 2. एम्स्क्रिप्टेन `emcc.rs` फाईलमध्ये C++ अपवाद वापरते.
//! 3. इतर सर्व लक्ष्ये X01 एक्स फाईलमध्ये libunwind/libgcc वापरतात.
//!
//! प्रत्येक अंमलबजावणीविषयी अधिक कागदपत्रे संबंधित मॉड्यूलमध्ये आढळू शकतात.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` मीरी बरोबरच न वापरलेले, म्हणून सावधानतेचा इशारा.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Rust रनटाइमच्या स्टार्टअप ऑब्जेक्ट्स या प्रतीकांवर अवलंबून असतात, म्हणून त्यांना सार्वजनिक करा.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // लक्ष्यीकरण जे अनावश्यक समर्थन देत नाहीत.
        // - arch=wasm32
        // - os=काहीही नाही ("bare metal" लक्ष्य)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // मिरी रनटाइम वापरा.
        // आम्हाला अद्याप वरील सामान्य रनटाइम देखील लोड करणे आवश्यक आहे, कारण झ0rustc0Z तेथून काही लँग आयटम परिभाषित केले जाण्याची अपेक्षा करतो.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // वास्तविक रनटाइम वापरा.
        use real_imp as imp;
    }
}

extern "C" {
    /// जेव्हा panic ऑब्जेक्ट `catch_unwind` च्या बाहेर सोडले जाते तेव्हा libstd मधील हँडलर म्हणतात.
    ///
    fn __rust_drop_panic() -> !;

    /// जेव्हा एखादा विदेशी अपवाद पकडला जातो तेव्हा लिबस्टीड इन हँडलरला कॉल केले जाते.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// अपवाद वाढविण्यासाठी प्रवेश बिंदू, फक्त प्लॅटफॉर्म-विशिष्ट अंमलबजावणीसाठी प्रतिनिधी.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}