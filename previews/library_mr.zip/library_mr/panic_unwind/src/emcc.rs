//! *ईम्स्क्रिप्टेन* लक्ष्यासाठी अनावश्यक.
//!
//! जेव्हा Rust चे नेहमीचे अनावश्यक अंमलबजावणी Unix प्लॅटफॉर्मवर लिबुनविंड एपीआयमध्ये थेट कॉल होते, तर एम्स्क्रिप्टेनवर आम्ही त्याऐवजी सी ++ अनवाइंडिंग एपीआय वर कॉल करतो.
//! एम्स्क्रिप्टेनचा रनटाइम नेहमीच त्या एपीआयची अंमलबजावणी करतो आणि लिबुनविंडची अंमलबजावणी करीत नसल्यामुळे हे केवळ एक विस्तार आहे.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// हे C++ मधील std::type_info च्या लेआउटशी जुळते
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // येथे अग्रगण्य `\x01` बाइट हे एलएलव्हीएमला एक्स ०1 एक्स वर्णानुसार प्रीफिक्सिंग सारखे इतर कोणतेही मॅंगलिंग *लागू न करण्यासाठी* जादुई सिग्नल आहे.
    //
    //
    // हे चिन्ह सी ++ च्या एक्स 100 एक्स द्वारे वापरलेले व्हीटेबल आहे.
    // प्रकार `std::type_info` च्या प्रकारांचे वर्णन करणारे टाइप करा या सारणीसाठी पॉईंटर आहे.
    // प्रकार वर्णन करणारे वर वर्णन केलेल्या सी ++ ईएच स्ट्रक्चर्सद्वारे संदर्भित आहेत आणि आम्ही खाली बांधकाम करतो.
    //
    // लक्षात घ्या की वास्तविक आकार 3 वापरण्यापेक्षा मोठा आहे, परंतु तिसर्‍या घटकाकडे निर्देश करण्यासाठी आम्हाला आमच्या व्हीटेबलची आवश्यकता आहे.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info रस्ट_पॅनिक वर्गासाठी
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // सामान्यत: आम्ही .as_ptr().add(2) वापरू पण हे कोणत्याही संदर्भात कार्य करत नाही.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // हे हेतुपुरस्सर सामान्य नाव मॅंगलिंग स्कीम वापरत नाही कारण आम्हाला Z +Rust0Z panics उत्पादन करण्यास किंवा पकडण्यात C++ पाहिजे नाही.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // हे आवश्यक आहे कारण सी ++ कोड आमच्या कार्यवाहीला std::exception_ptr सह कॅप्चर करू शकतो आणि शक्यतो दुसर्या थ्रेडमध्ये अनेक वेळा पुनर्विचार करू शकतो.
    //
    //
    caught: AtomicBool,

    // याला एक ऑप्शन्स असणे आवश्यक आहे कारण ऑब्जेक्टचे आजीवन सी ++ शब्दरचनांचे अनुसरण करते: जेव्हा कॅच_अनविंड बॉक्सला अपवादाच्या बाहेर हलविते तेव्हा तो अपवाद ऑब्जेक्टला वैध अवस्थेत सोडला पाहिजे कारण त्याचा डिस्ट्रक्टर अद्याप __cxa_end_catch द्वारे कॉल केला जाऊ शकत नाही.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try प्रत्यक्षात या रचनेस आपल्याला पॉईंटर देते.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // cleanup() ला panic ला परवानगी नाही, त्याऐवजी आम्ही त्याऐवजी सोडून देणे.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}