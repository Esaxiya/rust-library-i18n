//! DWARF-एन्कोडेड डेटा प्रवाह विश्लेषित करण्यासाठी उपयुक्तता.
//! <http://www.dwarfstd.org>, DWARF-4 मानक, विभाग 7, "Data Representation" पहा
//!

// हे मॉड्यूल आत्तासाठी फक्त x86_64-pc-Windows-gnu द्वारे वापरले जात आहे परंतु आम्ही तणाव टाळण्यासाठी सर्वत्र संकलित करीत आहोत.
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // DWARF प्रवाह पॅक केलेले आहेत, म्हणून उदा. u32 अपरिहार्यपणे 4-बाइट सीमेवर संरेखित होऊ नये.
    // हे कठोर संरेखन आवश्यकतासह प्लॅटफॉर्मवर समस्या उद्भवू शकते.
    // "packed" संरचनेत डेटा लपेटून, आम्ही बॅकएंडला "misalignment-safe" कोड व्युत्पन्न करण्यास सांगत आहोत.
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // ULEB128 आणि SLEB128 एन्कोडिंग्ज विभाग 7.6, "Variable Length Data" मध्ये परिभाषित केले आहेत.
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}