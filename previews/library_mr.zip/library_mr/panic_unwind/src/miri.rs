//! मिरीसाठी झेडपॅनिक्स 0 झेड अनावश्यक.
use alloc::boxed::Box;
use core::any::Any;

// मिरी इंजिन आमच्यासाठी अनावश्यक गोष्टीद्वारे पेलोडचा प्रचार करतो.
// पॉईंटर-आकाराचे असणे आवश्यक आहे.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// मिनी-पुरवलेले बाह्य कार्य अवांछनीय सुरू करण्यासाठी.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // आम्ही `miri_start_panic` वर दिलेला पेलोड आम्ही खाली `cleanup` मध्ये मिळवतो तंतोतंत वितर्क असेल.
    // पॉईंटर-आकाराचे काहीतरी मिळविण्यासाठी आम्ही फक्त एकदा ते बॉक्स करतो.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // अंतर्निहित `Box` पुनर्प्राप्त करा.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}