//! *संहार* लक्ष्यासाठी अनावश्यक.
//!
//! आत्ता आम्ही याला समर्थन देत नाही, म्हणून हे फक्त स्टब्स आहे.

use alloc::boxed::Box;
use core::any::Any;

pub unsafe fn cleanup(_ptr: *mut u8) -> Box<dyn Any + Send> {
    extern "C" {
        pub fn __rust_abort() -> !;
    }
    __rust_abort();
}

pub unsafe fn panic(_data: Box<dyn Any + Send>) -> u32 {
    extern "C" {
        pub fn __rust_abort() -> !;
    }
    __rust_abort();
}