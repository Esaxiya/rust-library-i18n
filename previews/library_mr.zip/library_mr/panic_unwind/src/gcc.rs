//! libgcc/libunwind (काही स्वरूपात) द्वारा समर्थित panics ची अंमलबजावणी.
//!
//! अपवाद हाताळणी आणि अनावश्यक स्टॅकच्या पार्श्वभूमीसाठी कृपया "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) आणि त्यातून दुवा साधलेली कागदपत्रे पहा.
//! हे देखील चांगले वाचले आहेत:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## एक संक्षिप्त सारांश
//!
//! अपवाद हाताळणी दोन टप्प्यांत घडते: शोध फेज आणि क्लीनअप टप्पा.
//!
//! दोन्ही चरणांमध्ये अनन्विंदर चालू प्रक्रियेच्या मॉड्यूल्सच्या स्टॅक फ्रेम अनावंड विभागातील माहितीचा वापर करून वरपासून खालपर्यंत स्टॅक फ्रेम्स चालविते (येथे एक्स 100 एक्स एक ओएस मॉड्यूल संदर्भित करते, म्हणजे, एक्झिक्युटेबल किंवा डायनामिक लायब्ररी).
//!
//!
//! प्रत्येक स्टॅक फ्रेमसाठी, ते संबंधित "personality routine" ची विनंती करते, ज्याचा पत्ता देखील अनावश्यक माहिती विभागात संग्रहित केला जातो.
//!
//! शोध टप्प्यात, व्यक्तिमत्त्वाच्या नियमाचे काम म्हणजे टाकलेल्या अपवाद वस्तूची तपासणी करणे आणि त्या स्टॅक फ्रेममध्ये ते पकडले जावे की नाही हे ठरविणे.एकदा हँडलर फ्रेम ओळखल्यानंतर, क्लीनअप चरण सुरू होते.
//!
//! साफसफाईच्या टप्प्यात, अनन्विंडर प्रत्येक व्यक्तिमत्त्वास पुन्हा पुन्हा विनंती करतात.
//! सध्याच्या स्टॅक फ्रेमसाठी कोणता (असल्यास असल्यास) क्लीनअप कोड चालविणे आवश्यक आहे हे निर्णय घेते.तसे असल्यास, नियंत्रण फंक्शन बॉडीमधील विशेष झेडब्रेन्च ० झेडकडे हस्तांतरित केले जाते, एक्स00 एक्स, जे डिस्ट्रक्टर्सची विनंती करते, मेमरी मुक्त करते इ.
//! लँडिंग पॅडच्या शेवटी, नियंत्रण अनविंदर आणि अवांछित सारांश परत हस्तांतरित केले जाते.
//!
//! एकदा स्टॅक हँडलर फ्रेम पातळीवर अवांछित झाल्यावर, अवांछित थांबे आणि शेवटच्या व्यक्तिमत्त्वाच्या नित्यकर्माने कॅच ब्लॉकवर नियंत्रण हस्तांतरित केले.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Rust चे अपवाद वर्ग अभिज्ञापक.
// हा अपवाद त्यांच्या स्वतःच्या रनटाइमद्वारे टाकला गेला आहे की नाही हे निर्धारित करण्यासाठी व्यक्तिमत्त्वाच्या दिनचर्याद्वारे याचा वापर केला जातो.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 रस्ट-विक्रेता, भाषा
    0x4d4f5a_00_52555354
}

// प्रत्येक आर्किटेक्चरसाठी रजिस्टर आयडी एलएलव्हीएमच्या एक्स 100 एक्स व एक्स ०१ एक्सकडून काढले गेले होते, नंतर रजिस्टर डिफेन्स टेबलच्या माध्यमातून डीव्हीआरएफ रजिस्टर नंबरवर मॅप केले होते (सामान्यत: <arch>RegisterInfo.td, "DwarfRegNum" चा शोध घ्या).
//
// http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register देखील पहा.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // ईएएक्स, ईडीएक्स

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // आरएक्स, आरडीएक्स

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// खालील कोड झेडजीसीसी 0 झेड च्या सी आणि सी ++ व्यक्तिमत्त्वाच्या दिनचर्यावर आधारित आहे.संदर्भासाठी पहा:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM EHABI व्यक्तिमत्व दिनचर्या.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS त्याऐवजी डीफॉल्ट रूटीन वापरते कारण ते एसजेएलजे अनवाइंडिंग वापरते.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // एआरएमवरील बॅकट्रॅसेस राज्य==_US_VIRTUAL_UNWIND_FRAME | सह व्यक्तिमत्त्वाच्या रूटीनवर कॉल करतील |_US_FORCE_UNWIND.
                // अशा परिस्थितीत आम्ही स्टॅक अनइंडिंग करणे सुरू ठेऊ इच्छितो, अन्यथा आमचे सर्व मागोवा __rust_try वर समाप्त होतील
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // DWARF अनविंदर असे गृहित धरते की _Uwind_Context मध्ये फंक्शन आणि एलएसडीए पॉईंटर्स यासारख्या गोष्टी आहेत, तथापि एआरएम EHABI त्यांना अपवाद ऑब्जेक्टमध्ये ठेवते.
            // _Unwind_GetLanguageSpecificData() सारख्या फंक्शन्सच्या स्वाक्षर्‍या जतन करण्यासाठी, जे फक्त संदर्भ पॉईंटर घेतात, झेडजीसीसी 0 झेड व्यक्तिमत्व दिनदर्शिकेने एआरएमच्या एक्स 0 2 एक्स एक्स 100 एक्ससाठी आरक्षित स्थान वापरुन संदर्भात अपवाद_शिक्षणाकडे पॉईंटर स्टॅश करते.
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... एक अधिक तत्त्व पध्दत म्हणजे आमच्या लिबुनविंड बाइंडिंगमध्ये एआरएमच्या _उन्नविंद_संकल्पांची संपूर्ण व्याख्या प्रदान करणे आणि तेथून आवश्यक डेटा थेट डीवायआरएफ संगतता कार्ये बाजूला ठेवणे होय.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // अपवाद ऑब्जेक्टच्या अडथळा कॅशेमध्ये एसपी मूल्य अद्यतनित करण्यासाठी एएचएबीआयला व्यक्तिमत्व दिनचर्या आवश्यक आहे.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // एआरएम एएचबीआय वर परत येण्यापूर्वी व्यक्तिमत्त्व दिनचर्या एक स्टॅक फ्रेम प्रत्यक्षात उतरविण्यास जबाबदार असते (एआरएम एएचबीआय से.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // libgcc मध्ये परिभाषित
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // डीफॉल्ट व्यक्तिमत्व दिनचर्या, जी बहुतेक लक्ष्यांवर आणि अप्रत्यक्षपणे एसईएच मार्गे एक्स 100 एक्स एक्स 01 एक्स वर वापरली जाते.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // एक्स 100 एक्स मिनजीडब्ल्यू लक्ष्यांवर, अनावश्यक यंत्रणा एसईएच आहे तथापि अवाइंड हँडलर डेटा (उर्फ एलएसडीए) झेडजीसीसी 0 झेड-सुसंगत एन्कोडिंग वापरतो.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // आपल्या बहुतेक लक्ष्यांसाठी व्यक्तिमत्त्व नियमित.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // कॉल इंस्ट्रक्शनच्या आधीचा पत्ता पॉईंट 1 बाइट, जो एलएसडीए श्रेणी सारणीच्या पुढील आयपी रेंजमध्ये असू शकतो.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// फ्रेम अनावश्यक माहिती नोंदणी
//
// प्रत्येक मॉड्यूलच्या प्रतिमेत एक फ्रेम अनावंड माहिती विभाग असतो (सामान्यत: ".eh_frame").जेव्हा मॉड्यूल प्रक्रियेत loaded/unloaded असेल तेव्हा अनविंदरला स्मृतीतील या विभागाच्या स्थानाबद्दल माहिती दिली जाणे आवश्यक आहे.प्लॅटफॉर्मनुसार बदलणार्‍या साध्य करण्याच्या पद्धती.
// काही (उदा., एक्स ०२ एक्स) वर, अनविंदरला स्वतःच अनावंड माहिती विभाग शोधता येऊ शकतात (एक्स लोड एक्स-एक्स एक्स द्वारे सध्या लोड केलेल्या मॉड्यूल्सची गतिकरित्या गणना करून; एक्स ०१ एक्स सारख्या, मॉड्यूल्सना अनविंदर एपीआयद्वारे त्यांचे अनावश्यक माहिती विभाग सक्रियपणे नोंदणी करणे आवश्यक आहे.
//
//
// हे मॉड्यूल GCC रनटाइमसह आमची माहिती नोंदविण्यासाठी rsbegin.rs वरून संदर्भित आणि कॉल केलेल्या दोन चिन्हे परिभाषित करते.
// स्टॅक अनावंडिंगची अंमलबजावणी (आत्तासाठी) libgcc_eh कडे स्थगित केली गेली आहे, तथापि Rust crates कोणत्याही GCC रनटाइमसह संभाव्य संघर्ष टाळण्यासाठी हे Rust-विशिष्ट प्रविष्टी बिंदू वापरा.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}