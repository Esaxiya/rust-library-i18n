//! `compiler-rt` लायब्ररीचा प्रोफाइलर भाग संकलित करते.
//!
//! तपशीलांसाठी libcompiler_builtins crate साठी build.rs पहा.

use std::env;
use std::path::Path;

fn main() {
    let target = env::var("TARGET").expect("TARGET was not set");
    let cfg = &mut cc::Build::new();

    // FIXME: `rerun-if-changed` निर्देश सध्या उत्सर्जित नाहीत आणि बिल्ड स्क्रिप्ट
    // या स्त्रोत फायली किंवा त्यात समाविष्ट असलेल्या शीर्षलेखांमधील बदलांवर पुन्हा चालणार नाही.
    let mut profile_sources = vec![
        "GCDAProfiling.c",
        "InstrProfiling.c",
        "InstrProfilingBuffer.c",
        "InstrProfilingFile.c",
        "InstrProfilingMerge.c",
        "InstrProfilingMergeFile.c",
        "InstrProfilingNameVar.c",
        "InstrProfilingPlatformDarwin.c",
        "InstrProfilingPlatformFuchsia.c",
        "InstrProfilingPlatformLinux.c",
        "InstrProfilingPlatformOther.c",
        "InstrProfilingPlatformWindows.c",
        "InstrProfilingUtil.c",
        "InstrProfilingValue.c",
        "InstrProfilingVersionVar.c",
        "InstrProfilingWriter.c",
        // या फाईलचे नाव एलएलव्हीएम 10 मध्ये ठेवले गेले.
        "InstrProfilingRuntime.cc",
        "InstrProfilingRuntime.cpp",
        // या फायली एलएलव्हीएम 11 मध्ये जोडल्या गेल्या.
        "InstrProfilingInternal.c",
        "InstrProfilingBiasVar.c",
    ];

    if target.contains("msvc") {
        // एमएसव्हीसीवरील अतिरिक्त लायब्ररी काढू नका
        cfg.flag("/Zl");
        profile_sources.push("WindowsMMap.c");
        cfg.define("strdup", Some("_strdup"));
        cfg.define("open", Some("_open"));
        cfg.define("fdopen", Some("_fdopen"));
        cfg.define("getpid", Some("_getpid"));
        cfg.define("fileno", Some("_fileno"));
    } else {
        // gcc ची विविध वैशिष्ट्ये आणि त्या बंद करा, मुख्यत: कंपाईलर आरटीची बिल्ड सिस्टम आधीपासून कॉपी करत आहे
        //
        cfg.flag("-fno-builtin");
        cfg.flag("-fomit-frame-pointer");
        cfg.define("VISIBILITY_HIDDEN", None);
        if !target.contains("windows") {
            cfg.flag("-fvisibility=hidden");
            cfg.define("COMPILER_RT_HAS_UNAME", Some("1"));
        } else {
            profile_sources.push("WindowsMMap.c");
        }
    }

    // समजू की आपण ज्या युनिक्ससाठी हे बनवत आहोत त्यांच्याकडे fnctl() उपलब्ध आहे
    if env::var_os("CARGO_CFG_UNIX").is_some() {
        cfg.define("COMPILER_RT_HAS_FCNTL_LCK", Some("1"));
    }

    // COMPILER_RT_HAS_ATOMICS कधी सेट करावे हे एक खूप चांगले आस्त्रीय असावे
    //
    if env::var_os("CARGO_CFG_TARGET_HAS_ATOMIC")
        .map(|features| features.to_string_lossy().to_lowercase().contains("ptr"))
        .unwrap_or(false)
    {
        cfg.define("COMPILER_RT_HAS_ATOMICS", Some("1"));
    }

    // लक्षात ठेवा आम्ही चालू असलो तर हे अस्तित्त्वात असले पाहिजे (अन्यथा आम्ही प्रोफाईल बिल्टिन अजिबात तयार करत नाही).
    //
    let root = Path::new("../../src/llvm-project/compiler-rt");

    let src_root = root.join("lib").join("profile");
    for src in profile_sources {
        let path = src_root.join(src);
        if path.exists() {
            cfg.file(path);
        }
    }

    cfg.include(root.join("include"));
    cfg.warnings(false);
    cfg.compile("profiler-rt");
}