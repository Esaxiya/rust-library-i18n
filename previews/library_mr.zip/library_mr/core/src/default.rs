//! अशा प्रकारच्या `Default` trait ज्यात अर्थपूर्ण डीफॉल्ट मूल्य असू शकतात.

#![stable(feature = "rust1", since = "1.0.0")]

/// प्रकारास उपयुक्त डीफॉल्ट मूल्य देण्यासाठी trait.
///
/// कधीकधी, आपण काही प्रकारच्या डीफॉल्ट मूल्याकडे परत जाऊ इच्छित आहात आणि विशेषतः ते काय आहे याची काळजी घेऊ नका.
/// हे बर्‍याचदा `रचनांसह येते जे पर्यायांचा संच परिभाषित करतात:
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// आम्ही काही डीफॉल्ट मूल्ये कशी परिभाषित करू शकतो?आपण `Default` वापरू शकता:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// आता तुम्हाला सर्व डीफॉल्ट व्हॅल्यूज मिळतील.Rust विविध आदिम प्रकारांसाठी `Default` लागू करते.
///
/// आपण एखादा विशिष्ट पर्याय अधिलिखित करू इच्छित असल्यास, परंतु तरीही अन्य डीफॉल्ट कायम ठेवा:
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// जर प्रकारची सर्व फील्ड `Default` लागू केली तर हे trait `#[derive]` सह वापरले जाऊ शकते.
/// जेव्हा शोधले जाते, ते प्रत्येक फील्डच्या प्रकारासाठी डीफॉल्ट मूल्य वापरेल.
///
/// ## मी `Default` ची अंमलबजावणी कशी करू शकेन?
///
/// `default()` पद्धतीची अंमलबजावणी प्रदान करा जी आपल्या प्रकारची मूल्य डीफॉल्ट असावी:
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// एका प्रकारासाठी "default value" मिळवते.
    ///
    /// डीफॉल्ट मूल्ये सहसा एक प्रकारचे प्रारंभिक मूल्य, ओळख मूल्य किंवा डीफॉल्ट म्हणून अर्थपूर्ण वाटणारी कोणतीही गोष्ट असू शकतात.
    ///
    ///
    /// # Examples
    ///
    /// अंगभूत डीफॉल्ट मूल्ये वापरणे:
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// आपले स्वतःचे बनवणे:
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// `Default` trait नुसार प्रकारच्या डीफॉल्ट मूल्य परत करा.
///
/// परत करण्याचा प्रकार संदर्भातून अनुमान काढला जातो;हे `Default::default()` च्या बरोबरीचे आहे परंतु टाइप करण्यासाठी लहान आहे.
///
/// उदाहरणार्थ:
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// झेडट्रायट0झेड एक्स 100 एक्सची इम्प्लिअल व्युत्पन्न करणार्‍या डेरिव मॅक्रो.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }