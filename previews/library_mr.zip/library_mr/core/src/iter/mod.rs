//! संमिश्र बाह्य पुनरावृत्ती.
//!
//! आपण स्वत: ला एखाद्या प्रकारचा संग्रह सापडला असेल आणि म्हणाला की संग्रहातील घटकांवर ऑपरेशन करणे आवश्यक असेल तर आपण त्वरीत 'iterators' मध्ये जाल.
//! आयडिओमॅटिक Rust कोडमध्ये इटेटरचा मोठ्या प्रमाणात वापर केला जातो, म्हणून त्यांच्याशी परिचित होण्यासारखे आहे.
//!
//! अधिक स्पष्टीकरण देण्यापूर्वी, हे मॉड्यूल कसे रचले गेले याबद्दल चर्चा करूया:
//!
//! # Organization
//!
//! हे विभाग मुख्यत्वे प्रकारानुसार आयोजित केले जाते:
//!
//! * [Traits] मूळ भाग आहेतः हे झेडट्रायट्स ० झेड परिभाषित करतात की कोणत्या प्रकारचे इटरेटर्स अस्तित्वात आहेत आणि आपण त्यांच्यासह काय करू शकता.या झेडट्रिट्स0 झेडच्या पद्धतींमध्ये काही अतिरिक्त अभ्यासाचा वेळ घालविणे योग्य आहे.
//! * [Functions] काही मूलभूत पुनरावृत्त्या तयार करण्यासाठी काही उपयुक्त मार्ग प्रदान करा.
//! * [Structs] या मॉड्यूलच्या traits वर बर्‍याच पद्धतींचा परतावा प्रकार असतो.आपण सहसा `struct` ऐवजी `struct` तयार करणारी पद्धत पाहू इच्छित असाल.
//! का याबद्दल अधिक तपशीलांसाठी, '[लागू करणारे Iterator](#अंमलबजावणी-पुनरावृत्तीकर्ता)' पहा.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! बस एवढेच!चला पुनरावलोकने करू.
//!
//! # Iterator
//!
//! या मॉड्यूलचे हृदय आणि आत्मा हे [`Iterator`] trait आहे.[`Iterator`] चे मूळ असे दिसते:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! इटरेटरला [`next`] ची एक पद्धत असते, ज्यास जेव्हा कॉल केले जाते तेव्हा [`पर्याय`] returns मिळवते<Item>`.
//! [`next`] जोपर्यंत घटक आहेत तोपर्यंत [`Some(Item)`] परत करेल आणि एकदा ते सर्व संपून गेल्यानंतर पुनरावृत्ती संपल्याचे सूचित करण्यासाठी X01 एक्स परत येईल.
//! वैयक्तिक पुनरावृत्ती (पुनरावृत्ती) पुन्हा सुरू करणे निवडू शकते आणि म्हणूनच एक्स 100 एक्सला पुन्हा कॉल करणे शेवटी कधीकधी पुन्हा X01 एक्स परत करणे सुरू करू शकते किंवा नाही (उदाहरणार्थ, एक्स ०२ एक्स पहा).
//!
//!
//! [Te Iterator`] च्या पूर्ण व्याख्येत इतर बर्‍याच पद्धतींचा समावेश आहे, परंतु त्या डीफॉल्ट पद्धती आहेत, ज्या [`next`] च्या वर तयार केल्या आहेत आणि म्हणूनच आपण त्या विनामूल्य प्राप्त करा.
//!
//! आयटरर्स देखील कंपोझ करण्यायोग्य आहेत आणि अधिक जटिल प्रकारची प्रक्रिया करण्यासाठी त्यांना एकत्र साखळी बनविणे सामान्य आहे.अधिक तपशीलांसाठी खालील [Adapters](#adapters) विभाग पहा.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # पुनरावृत्तीचे तीन प्रकार
//!
//! संग्रहातून पुनरावृत्ती करणार्‍या तीन सामान्य पद्धती आहेत:
//!
//! * `iter()`, जे एक्स 100 एक्स वर पुनरावृत्ती होते.
//! * `iter_mut()`, जे एक्स 100 एक्स वर पुनरावृत्ती होते.
//! * `into_iter()`, जे एक्स 100 एक्स वर पुनरावृत्ती होते.
//!
//! प्रमाणित लायब्ररीत विविध गोष्टी योग्य असल्यास तिन्हीपैकी एक किंवा अधिक लागू करू शकतात.
//!
//! # आयटरची अंमलबजावणी करीत आहे
//!
//! आपल्या स्वत: च्या इटरेटर तयार करण्यामध्ये दोन चरणांचा समावेश आहे: इट्रेटरची स्थिती ठेवण्यासाठी `struct` तयार करणे आणि नंतर त्या `struct` साठी [`Iterator`] लागू करणे.
//! म्हणूनच या मॉड्यूलमध्ये बरीच रचना आहेत: प्रत्येक पुनरावृत्ती करणार्‍यासाठी आणि पुनरावृत्ती करणार्‍या अ‍ॅडॉप्टरसाठी एक असे आहे.
//!
//! `1` ते `5` पर्यंत मोजले जाणारे `Counter` नावाचे एक आयटर बनवू:
//!
//! ```
//! // प्रथम, रचना:
//!
//! /// एक पुनरावृत्ती करणारा जो एक ते पाच पर्यंत मोजला जातो
//! struct Counter {
//!     count: usize,
//! }
//!
//! // आम्हाला आमची गणना एक प्रारंभ करायची आहे, म्हणून मदतीसाठी एक new() पद्धत जोडा.
//! // हे काटेकोरपणे आवश्यक नाही, परंतु सोयीस्कर आहे.
//! // लक्षात ठेवा आम्ही `count` शून्यावर प्रारंभ करतो, आम्ही खाली `next()`'s अंमलबजावणी का करतो ते पाहू.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // मग आम्ही आमच्या `Counter` साठी `Iterator` लागू करतोः
//!
//! impl Iterator for Counter {
//!     // आम्ही usize सह मोजत आहोत
//!     type Item = usize;
//!
//!     // next() फक्त आवश्यक पद्धत आहे
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // आमची संख्या वाढवा.म्हणूनच आम्ही शून्यावर सुरुवात केली.
//!         self.count += 1;
//!
//!         // आम्ही मोजणी पूर्ण केली आहे की नाही ते पहा.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // आणि आता आम्ही ते वापरू शकतो!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! अशाप्रकारे [`next`] वर कॉल करणे पुनरावृत्ती होते.झेडआरस्ट0 झेड मध्ये एक कन्स्ट्रक्शन आहे जो आपल्या इटरेटरवर [`next`] वर कॉल करू शकतो जोपर्यंत तो `None` पर्यंत पोहोचत नाही.चला त्या पुढे जाऊया.
//!
//! हे देखील लक्षात घ्या की `Iterator` अंतर्गत `nth` कॉल करणार्या `nth` आणि `fold` सारख्या पद्धतींची डीफॉल्ट अंमलबजावणी प्रदान करते.
//! तथापि, एक्सट्रॅक्टर `next` वर कॉल न करता अधिक कार्यक्षमतेने गणना करू शकत असल्यास `nth` आणि `fold` सारख्या पद्धतींची सानुकूल अंमलबजावणी लिहिणे देखील शक्य आहे.
//!
//! # `for` पळवाट आणि `IntoIterator`
//!
//! झेडआरस्ट0झेडचा एक्स ०१ एक्स लूप सिंटॅक्स प्रत्यक्षात पुनरावृत्ती करणार्‍यांसाठी साखर आहे.येथे `for` चे मूलभूत उदाहरणः
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! हे प्रत्येकाला त्यांच्या स्वत: च्या ओळीवर पाच ते एक अंक प्रिंट करेल.परंतु आपणास येथे काहीतरी दिसेल: इटररेटर तयार करण्यासाठी आम्ही आमच्या झेडवेक्टोर0झेडवर कधीही काहीही बोललो नाही.काय देते?
//!
//! काहीतरी ला इटरेटरमध्ये रूपांतरित करण्यासाठी मानक लायब्ररीत एक trait आहे: [`IntoIterator`].
//! या trait मध्ये एक पद्धत आहे, [`into_iter`], जी [`IntoIterator`] ची अंमलबजावणी करणार्‍या वस्तूला इटरेटरमध्ये रूपांतरित करते.
//! त्या `for` लूपवर पुन्हा एक नजर टाकू आणि कंपाईलर त्यास कशामध्ये रुपांतरित करते:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! झेड रस्ट ० झेड यास डी-शुगर्सः
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! प्रथम, आम्ही मूल्यावर `into_iter()` कॉल करतो.नंतर, आम्ही परत येणार्‍या पुनरावलोककावर जुळतो, जोपर्यंत आम्ही `None` दिसत नाही तोपर्यंत [`next`] वर कॉल करतो.
//! त्या क्षणी आम्ही लूपच्या बाहेर `break` केले आणि आम्ही पुनरावृत्ती केली.
//!
//! येथे आणखी एक सूक्ष्म बिट आहे: मानक लायब्ररीत [`IntoIterator`] ची एक मनोरंजक अंमलबजावणी आहे:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! दुसर्‍या शब्दांत सांगायचे तर, सर्व [`Iterator just] यांनी फक्त परत येऊन [`IntoIterator`] ची अंमलबजावणी केली.याचा अर्थ दोन गोष्टी:
//!
//! 1. आपण [`Iterator`] लिहित असल्यास, आपण हे `for` लूपसह वापरू शकता.
//! 2. आपण संग्रह तयार करत असल्यास, त्यासाठी [`IntoIterator`] ची अंमलबजावणी केल्यास आपला संग्रह `for` लूपसह वापरला जाईल.
//!
//! # संदर्भाने Iterating
//!
//! [`into_iter()`] मूल्यानुसार `self` घेत असल्याने संग्रहावर पुनरावृत्ती करण्यासाठी `for` लूप वापरुन तो संग्रह वापरतो.बर्‍याचदा, आपल्याला कदाचित संकलनाचे सेवन न करता पुनरावृत्ती करण्याची इच्छा असू शकते.
//! बरेच संग्रह संदर्भांद्वारे पुनरावलोकने प्रदान करणार्‍या पद्धती ऑफर करतात, त्यांना परंपरेने `iter()` आणि `iter_mut()` म्हणतात:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` अद्याप या फंक्शनच्या मालकीचे आहे.
//! ```
//!
//! जर संग्रह प्रकार `C` `iter()` प्रदान करत असेल तर तो सहसा `&C` साठी `IntoIterator` देखील लागू करतो, ज्याची अंमलबजावणी नुकतीच एक्स 100 एक्स ला करते.
//! त्याचप्रमाणे, `iter_mut()` प्रदान करणारा `C` संग्रह X0 `iter_mut()` सहसा `&mut C` साठी `IntoIterator` लागू करतो.हे सोयीस्कर शॉर्टहँड सक्षम करते:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // `values.iter_mut()` प्रमाणेच
//!     *x += 1;
//! }
//! for x in &values { // `values.iter()` प्रमाणेच
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! बरेच संग्रह `iter()` ऑफर करतात, सर्व ऑफर `iter_mut()` देत नाहीत.
//! उदाहरणार्थ, की हॅश बदलल्यास [`HashSet<T>`] किंवा [`HashMap<K, V>`] की की बदलल्यास संकलन विसंगत स्थितीत टाकता येऊ शकते, म्हणूनच हे संग्रह केवळ `iter()` देतात.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! जे कार्ये [`Iterator`] घेतात आणि दुसर्‍या X01 एक्सला परत करतात त्यांना बर्‍याचदा 'इट्रेटर अ‍ॅडॉप्टर' असे म्हणतात, कारण ते 'अ‍ॅडॉप्टर' चे प्रकार आहेत
//! pattern'.
//!
//! सामान्य पुनरावृत्ती करणार्‍या अ‍ॅडॉप्टर्समध्ये [`map`], [`take`] आणि [`filter`] समाविष्ट आहे.
//! अधिक माहितीसाठी त्यांचे दस्तऐवजीकरण पहा.
//!
//! जर इट्रेटर अ‍ॅडॉप्टर झेडस्पॅनिक्स 0 झेड असेल तर, इटररेटर अनिर्दिष्ट (परंतु मेमरी सेफ) स्थितीत असेल.
//! या क्षेत्राची देखील Rust च्या आवृत्त्यांमध्ये समान राहण्याची हमी नाही, जेणेकरून आपण घाबरलेल्या पुनरावृत्ती करणार्‍याद्वारे परत आलेल्या अचूक मूल्यांवर अवलंबून राहणे टाळले पाहिजे.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! आयटर (आणि इटरेटर एक्स ०१ एक्स *आळशी* आहेत. याचा अर्थ असा आहे की केवळ इटररेटर तयार करणे संपूर्णपणे _do_ करत नाही. आपण [`next`] ला कॉल करेपर्यंत काहीही घडत नाही.
//! केवळ त्याच्या दुष्परिणामांसाठी इटरटर तयार करताना हे काहीवेळा गोंधळाचे कारण असते.
//! उदाहरणार्थ, [`map`] पद्धत ज्या पुनरावृत्ती होते त्या प्रत्येक घटकावर बंद कॉल करते:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! हे कोणतीही व्हॅल्यूज प्रिंट करणार नाही, कारण आम्ही वापरण्याऐवजी केवळ इटरेटर तयार केला आहे.संकलक आपल्याला या प्रकारच्या वर्तनाबद्दल चेतावणी देईल:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! त्याच्या दुष्परिणामांकरिता [`map`] लिहिण्याचा मुर्ख मार्ग म्हणजे `for` लूप वापरणे किंवा [`for_each`] पद्धतीवर कॉल करणे:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! इटरेटरचे मूल्यांकन करण्याचा दुसरा सामान्य मार्ग म्हणजे नवीन संग्रह तयार करण्यासाठी एक्स 100 एक्स पद्धत वापरणे.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! आयटेटर मर्यादित नसतात.उदाहरणार्थ, मुक्त-अंत श्रेणी एक असीम पुनरावर्तक आहे:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! अनंत इटररेटरला परिष्कृत करण्यासाठी [`take`] इटररेटर अ‍ॅडॉप्टर वापरणे सामान्य आहेः
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! हे प्रत्येक त्यांच्या स्वत: च्या ओळीवर `4` मार्गे `0` अंक मुद्रित करेल.
//!
//! हे लक्षात ठेवा की अनंत पुनरावृत्ती करणार्‍यावरील पद्धती, जरी परिपूर्ण काळामध्ये परिणाम गणितावर निश्चित केला जाऊ शकतो, त्या समाप्त होणार नाहीत.
//! विशेषत: एक्स00 एक्स सारख्या पद्धती ज्यास सामान्यतः इटरेटरमध्ये प्रत्येक घटकाचा मागोवा घेण्याची आवश्यकता असते, बहुधा कोणत्याही अनंत पुनरावृत्ती करणार्‍यांसाठी यशस्वीरित्या परत येऊ शकत नाही.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // अरे नाही!अनंत पळवाट!
//! // `ones.min()` असीम पळवाट कारणीभूत आहे, म्हणून आम्ही या टप्प्यावर पोहोचणार नाही!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;