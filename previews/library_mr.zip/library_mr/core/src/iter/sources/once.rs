use crate::iter::{FusedIterator, TrustedLen};

/// आयटरर तयार करते ज्याला एकदाच घटक मिळतो.
///
/// हे सामान्यत: एकल मूल्य अन्य प्रकारच्या पुनरावृत्तीच्या एक्स 100 एक्समध्ये बदलण्यासाठी वापरले जाते.
/// कदाचित आपल्याकडे इटरेटर असेल ज्यात जवळजवळ प्रत्येक गोष्ट व्यापली असेल, परंतु आपल्यास अतिरिक्त विशेष केसांची आवश्यकता असेल.
/// कदाचित आपल्याकडे फंक्शन आहे जे इटरेटरवर कार्य करते, परंतु आपल्याला केवळ एका मूल्यावर प्रक्रिया करण्याची आवश्यकता आहे.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// मूलभूत वापर:
///
/// ```
/// use std::iter;
///
/// // एक एकमेव संख्या आहे
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // फक्त एक, आपल्याकडे इतकेच आहे
/// assert_eq!(None, one.next());
/// ```
///
/// दुसर्‍या इटरेटरसह एकत्र चेन करणे.
/// समजा, आम्ही `.foo` निर्देशिकेच्या प्रत्येक फाईलवर पुनरावृत्ती करू इच्छितो, परंतु कॉन्फिगरेशन फाइल देखील,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // आम्हाला डिरेन्ट्री-एस च्या इटरेटरवरून पाथबफ्सच्या इटरेटरमध्ये रूपांतरित करणे आवश्यक आहे, म्हणून आम्ही नकाशा वापरतो
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // आता केवळ आमच्या कॉन्फिगरेशन फाईलसाठी आमचा इटरेटर
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // दोन आयटरला एका मोठ्या इटरेटरमध्ये एकत्र साखळी घाला
/// let files = dirs.chain(config);
///
/// // हे आम्हाला .foo मधील तसेच .foorc मधील सर्व फायली देईल
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// एक आयरेटर जो एका वेळी एका घटकास उत्पन्न देतो.
///
/// हे `struct` हे [`once()`] फंक्शनद्वारे तयार केले गेले आहे.अधिकसाठी त्याचे दस्तऐवजीकरण पहा.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}