use crate::iter::{FusedIterator, TrustedLen};

/// एक नवीन आयटर तयार करतो जो अविरतपणे एकाच घटकाची पुनरावृत्ती करतो.
///
/// `repeat()` फंक्शन एकाच मूल्याचे पुन्हा पुन्हा पुनरावृत्ती करते.
///
/// `repeat()` सारख्या अनंत पुनरावृत्त्यांचा वापर बहुतेक वेळा मर्यादित करण्यासाठी [`Iterator::take()`] सारख्या अ‍ॅडॉप्टर्ससह केला जातो.
///
/// आपल्याला आवश्यक असलेल्या इटरेटरचा घटक प्रकार `Clone` लागू करत नाही किंवा पुनरावृत्ती केलेला घटक मेमरीमध्ये ठेवू इच्छित नसल्यास आपण त्याऐवजी [`repeat_with()`] फंक्शन वापरू शकता.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// मूलभूत वापर:
///
/// ```
/// use std::iter;
///
/// // क्रमांक चार 4ver:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // होय, अद्याप चार
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// [`Iterator::take()`] सह मर्यादित जात:
///
/// ```
/// use std::iter;
///
/// // हे शेवटचे उदाहरण बरेच चौकार होते.चला फक्त चार चौकार करू या.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... आणि आता आम्ही पूर्ण केले
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// एक पुनरावृत्ती करणारा जो घटकाची निरंतर पुनरावृत्ती करतो.
///
/// हे `struct` हे [`repeat()`] फंक्शनद्वारे तयार केले गेले आहे.अधिकसाठी त्याचे दस्तऐवजीकरण पहा.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}