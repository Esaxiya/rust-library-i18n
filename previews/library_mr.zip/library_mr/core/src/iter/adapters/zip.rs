use crate::cmp;
use crate::fmt::{self, Debug};
use crate::iter::{DoubleEndedIterator, ExactSizeIterator, FusedIterator, Iterator};
use crate::iter::{InPlaceIterable, SourceIter, TrustedLen};

/// एक पुनरावृत्ती करणारा जो एकाच वेळी दोन अन्य पुनरावृत्तीची पुनरावृत्ती करतो.
///
/// हे `struct` [`Iterator::zip`] द्वारे तयार केले गेले आहे.
/// अधिकसाठी त्याचे दस्तऐवजीकरण पहा.
#[derive(Clone)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Zip<A, B> {
    a: A,
    b: B,
    // अनुक्रमणिका, लेन आणि ए_लेन केवळ झिपच्या विशेष आवृत्तीद्वारे वापरले जातात
    index: usize,
    len: usize,
    a_len: usize,
}
impl<A: Iterator, B: Iterator> Zip<A, B> {
    pub(in crate::iter) fn new(a: A, b: B) -> Zip<A, B> {
        ZipImpl::new(a, b)
    }
    fn super_nth(&mut self, mut n: usize) -> Option<(A::Item, B::Item)> {
        while let Some(x) = Iterator::next(self) {
            if n == 0 {
                return Some(x);
            }
            n -= 1;
        }
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> Iterator for Zip<A, B>
where
    A: Iterator,
    B: Iterator,
{
    type Item = (A::Item, B::Item);

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        ZipImpl::next(self)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        ZipImpl::size_hint(self)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        ZipImpl::nth(self, n)
    }

    #[inline]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        // सुरक्षाः `ZipImpl::__iterator_get_unchecked` मध्ये समान सुरक्षा आहे
        // `Iterator::__iterator_get_unchecked` म्हणून आवश्यकता.
        unsafe { ZipImpl::get_unchecked(self, idx) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> DoubleEndedIterator for Zip<A, B>
where
    A: DoubleEndedIterator + ExactSizeIterator,
    B: DoubleEndedIterator + ExactSizeIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<(A::Item, B::Item)> {
        ZipImpl::next_back(self)
    }
}

// झिप विशेषज्ञता trait
#[doc(hidden)]
trait ZipImpl<A, B> {
    type Item;
    fn new(a: A, b: B) -> Self;
    fn next(&mut self) -> Option<Self::Item>;
    fn size_hint(&self) -> (usize, Option<usize>);
    fn nth(&mut self, n: usize) -> Option<Self::Item>;
    fn next_back(&mut self) -> Option<Self::Item>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator;
    // यास `Iterator::__iterator_get_unchecked` प्रमाणेच सुरक्षा आवश्यकता आहेत
    unsafe fn get_unchecked(&mut self, idx: usize) -> <Self as Iterator>::Item
    where
        Self: Iterator + TrustedRandomAccess;
}

// जनरल जि.प.
#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: Iterator,
    B: Iterator,
{
    type Item = (A::Item, B::Item);
    default fn new(a: A, b: B) -> Self {
        Zip {
            a,
            b,
            index: 0, // unused
            len: 0,   // unused
            a_len: 0, // unused
        }
    }

    #[inline]
    default fn next(&mut self) -> Option<(A::Item, B::Item)> {
        let x = self.a.next()?;
        let y = self.b.next()?;
        Some((x, y))
    }

    #[inline]
    default fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.super_nth(n)
    }

    #[inline]
    default fn next_back(&mut self) -> Option<(A::Item, B::Item)>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator,
    {
        let a_sz = self.a.len();
        let b_sz = self.b.len();
        if a_sz != b_sz {
            // A, b समान लांबी समायोजित करा
            if a_sz > b_sz {
                for _ in 0..a_sz - b_sz {
                    self.a.next_back();
                }
            } else {
                for _ in 0..b_sz - a_sz {
                    self.b.next_back();
                }
            }
        }
        match (self.a.next_back(), self.b.next_back()) {
            (Some(x), Some(y)) => Some((x, y)),
            (None, None) => None,
            _ => unreachable!(),
        }
    }

    #[inline]
    default fn size_hint(&self) -> (usize, Option<usize>) {
        let (a_lower, a_upper) = self.a.size_hint();
        let (b_lower, b_upper) = self.b.size_hint();

        let lower = cmp::min(a_lower, b_lower);

        let upper = match (a_upper, b_upper) {
            (Some(x), Some(y)) => Some(cmp::min(x, y)),
            (Some(x), None) => Some(x),
            (None, Some(y)) => Some(y),
            (None, None) => None,
        };

        (lower, upper)
    }

    default unsafe fn get_unchecked(&mut self, _idx: usize) -> <Self as Iterator>::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: TrustedRandomAccess + Iterator,
    B: TrustedRandomAccess + Iterator,
{
    fn new(a: A, b: B) -> Self {
        let a_len = a.size();
        let len = cmp::min(a_len, b.size());
        Zip { a, b, index: 0, len, a_len }
    }

    #[inline]
    fn next(&mut self) -> Option<(A::Item, B::Item)> {
        if self.index < self.len {
            let i = self.index;
            self.index += 1;
            // सुरक्षाः `i` हे `self.len` पेक्षा लहान आहे, जेणेकरुन हे `self.a.len()` आणि `self.b.len()` पेक्षा लहान आहे
            unsafe {
                Some((self.a.__iterator_get_unchecked(i), self.b.__iterator_get_unchecked(i)))
            }
        } else if A::MAY_HAVE_SIDE_EFFECT && self.index < self.a_len {
            let i = self.index;
            self.index += 1;
            self.len += 1;
            // बेस अंमलबजावणीच्या संभाव्य दुष्परिणाम सुरक्षिततेशी जुळवा: आम्ही नुकतेच हे तपासले की `i` <`self.a.len()`
            //
            unsafe {
                self.a.__iterator_get_unchecked(i);
            }
            None
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len - self.index;
        (len, Some(len))
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        let delta = cmp::min(n, self.len - self.index);
        let end = self.index + delta;
        while self.index < end {
            let i = self.index;
            self.index += 1;
            if A::MAY_HAVE_SIDE_EFFECT {
                // सुरक्षितता: `delta` मोजण्यासाठी `cmp::min` चा वापर
                // हे सुनिश्चित करते की `end` हे `self.len` पेक्षा लहान किंवा त्या समान आहे, म्हणून `i` देखील `self.len` पेक्षा लहान आहे.
                //
                unsafe {
                    self.a.__iterator_get_unchecked(i);
                }
            }
            if B::MAY_HAVE_SIDE_EFFECT {
                // सुरक्षा: वरील प्रमाणेच.
                unsafe {
                    self.b.__iterator_get_unchecked(i);
                }
            }
        }

        self.super_nth(n - delta)
    }

    #[inline]
    fn next_back(&mut self) -> Option<(A::Item, B::Item)>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator,
    {
        if A::MAY_HAVE_SIDE_EFFECT || B::MAY_HAVE_SIDE_EFFECT {
            let sz_a = self.a.size();
            let sz_b = self.b.size();
            // A, b ला समान लांबी समायोजित करा, `next_back` चा केवळ प्रथम कॉलच हे करत असल्याचे सुनिश्चित करा, अन्यथा आम्ही `get_unchecked()` वर कॉल केल्यानंतर `self.next_back()` वर कॉलवरील निर्बंध तोडू.
            //
            //
            if sz_a != sz_b {
                let sz_a = self.a.size();
                if A::MAY_HAVE_SIDE_EFFECT && sz_a > self.len {
                    for _ in 0..sz_a - self.len {
                        self.a.next_back();
                    }
                    self.a_len = self.len;
                }
                let sz_b = self.b.size();
                if B::MAY_HAVE_SIDE_EFFECT && sz_b > self.len {
                    for _ in 0..sz_b - self.len {
                        self.b.next_back();
                    }
                }
            }
        }
        if self.index < self.len {
            self.len -= 1;
            self.a_len -= 1;
            let i = self.len;
            // सुरक्षितता: एक्स ० एक्स एक्स एक्स एक्सच्या पूर्वीच्या मूल्यापेक्षा लहान आहे,
            // जे `self.a.len()` आणि `self.b.len()` च्या तुलनेत लहान किंवा समान आहे
            unsafe {
                Some((self.a.__iterator_get_unchecked(i), self.b.__iterator_get_unchecked(i)))
            }
        } else {
            None
        }
    }

    #[inline]
    unsafe fn get_unchecked(&mut self, idx: usize) -> <Self as Iterator>::Item {
        let idx = self.index + idx;
        // सुरक्षितता: कॉलरने `Iterator::__iterator_get_unchecked` कराराचे समर्थन केले पाहिजे.
        //
        unsafe { (self.a.__iterator_get_unchecked(idx), self.b.__iterator_get_unchecked(idx)) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> ExactSizeIterator for Zip<A, B>
where
    A: ExactSizeIterator,
    B: ExactSizeIterator,
{
}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<A, B> TrustedRandomAccess for Zip<A, B>
where
    A: TrustedRandomAccess,
    B: TrustedRandomAccess,
{
    const MAY_HAVE_SIDE_EFFECT: bool = A::MAY_HAVE_SIDE_EFFECT || B::MAY_HAVE_SIDE_EFFECT;
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A, B> FusedIterator for Zip<A, B>
where
    A: FusedIterator,
    B: FusedIterator,
{
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, B> TrustedLen for Zip<A, B>
where
    A: TrustedLen,
    B: TrustedLen,
{
}

// एक्सट्रॅक्सेबल "source" म्हणून झिप पुनरावृत्तीची डावी बाजू अनियंत्रितपणे निवडते यासाठी दोन्हीचा प्रयत्न करण्यासाठी नकारात्मक trait bounds आवश्यक असेल
//
#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S, A, B> SourceIter for Zip<A, B>
where
    A: SourceIter<Source = S>,
    B: Iterator,
    S: Iterator,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // सुरक्षितता: समान आवश्यकतांसह असुरक्षित कार्यासाठी असुरक्षित कार्य अग्रेषण
        unsafe { SourceIter::as_inner(&mut self.a) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
// आयटमवर मर्यादित: झिप च्या ट्रस्टर्ड रँडमएक्सेसचा वापर आणि स्त्रोताच्या ड्रॉप अंमलबजावणी दरम्यानचा संवाद अस्पष्ट आहे.
//
// स्त्रोताची तार्किकदृष्ट्या किती वेळा उन्नती केली गेली आहे याची परत परत येण्याची एक अतिरिक्त पद्धत (next()) ला कॉल न करता स्त्रोत उर्वरित योग्यरित्या ड्रॉप करणे आवश्यक आहे.
//
//
unsafe impl<A: InPlaceIterable, B: Iterator> InPlaceIterable for Zip<A, B> where A::Item: Copy {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Debug, B: Debug> Debug for Zip<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        ZipFmt::fmt(self, f)
    }
}

trait ZipFmt<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result;
}

impl<A: Debug, B: Debug> ZipFmt<A, B> for Zip<A, B> {
    default fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Zip").field("a", &self.a).field("b", &self.b).finish()
    }
}

impl<A: Debug + TrustedRandomAccess, B: Debug + TrustedRandomAccess> ZipFmt<A, B> for Zip<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // समाविष्ट केलेल्या पुनरावृत्ती झालेल्यांवर एफएमटीवर कॉल करणे *सुरक्षित नाही* कारण एकदा आपण पुनरावृत्ती करणे सुरू केल्यास ते विचित्र, संभाव्य असुरक्षित, असे म्हणतात.
        //
        f.debug_struct("Zip").finish()
    }
}

/// एक आयटर ज्याचे आयटम कार्यक्षमतेने यादृच्छिक-प्रवेश करण्यायोग्य आहेत
///
/// # Safety
///
/// आयटरचा एक्स00 एक्स कॉल करण्यासाठी अचूक आणि स्वस्त असणे आवश्यक आहे.
///
/// `size` अधिलिखित केले जाऊ शकत नाही.
///
/// `<Self as Iterator>::__iterator_get_unchecked` खालील अटी पूर्ण झाल्यास कॉल करण्यासाठी सुरक्षित असणे आवश्यक आहे.
///
/// 1. `0 <= idx` आणि `idx < self.size()`.
/// 2. `self: !Clone` असल्यास, नंतर एक्स01 एक्सला एकापेक्षा जास्त वेळा `self` वर समान निर्देशांकासह कधीही कॉल केले जात नाही.
/// 3. `self.get_unchecked(idx)` कॉल केल्यावर नंतर `next_back` फक्त जास्तीत जास्त `self.size() - idx - 1` वेळा कॉल केले जाईल.
/// 4. `get_unchecked` कॉल केल्यानंतर, नंतर फक्त खालील पद्धती `self` वर कॉल केल्या जातीलः
///     * `std::clone::Clone::clone()`
///     * `std::iter::Iterator::size_hint()`
///     * `std::iter::Iterator::next_back()`
///     * `std::iter::Iterator::__iterator_get_unchecked()`
///     * `std::iter::TrustedRandomAccess::size()`
///
/// पुढे या अटी पूर्ण केल्या की याची हमी दिली पाहिजे:
///
/// * हे `size_hint` मधून मिळविलेले मूल्य बदलत नाही
/// * आवश्यक असलेल्या traits कार्यान्वित केल्या आहेत असे गृहित धरुन `get_unchecked` वर कॉल केल्यानंतर `self` वर सूचीबद्ध केलेल्या पद्धतींना कॉल करणे सुरक्षित असणे आवश्यक आहे.
///
/// * `get_unchecked` वर कॉल केल्यानंतर `self` सोडणे देखील सुरक्षित असले पाहिजे.
///
///
///
///
#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
#[rustc_specialization_trait]
pub unsafe trait TrustedRandomAccess: Sized {
    // सोयीची पद्धत.
    fn size(&self) -> usize
    where
        Self: Iterator,
    {
        self.size_hint().0
    }
    /// `true` जर इरेटर एलिमेंट मिळाल्यास साइड इफेक्ट्स होऊ शकतात.
    /// अंतर्गत पुनरावलोकने खात्यात घेणे लक्षात ठेवा.
    const MAY_HAVE_SIDE_EFFECT: bool;
}

/// `Iterator::__iterator_get_unchecked` प्रमाणेच परंतु `U: TrustedRandomAccess` हे जाणून घेण्यासाठी कंपाईलरची आवश्यकता नाही.
///
///
/// ## Safety
///
/// त्याच आवश्यकता ज्या थेट एक्स 100 एक्स वर कॉल करतात.
#[doc(hidden)]
pub(in crate::iter::adapters) unsafe fn try_get_unchecked<I>(it: &mut I, idx: usize) -> I::Item
where
    I: Iterator,
{
    // सुरक्षितता: कॉलरने `Iterator::__iterator_get_unchecked` कराराचे समर्थन केले पाहिजे.
    //
    unsafe { it.try_get_unchecked(idx) }
}

unsafe trait SpecTrustedRandomAccess: Iterator {
    /// `Self: TrustedRandomAccess` असल्यास, ते `Iterator::__iterator_get_unchecked(self, index)` वर कॉल करणे सुरक्षित असले पाहिजे.
    ///
    unsafe fn try_get_unchecked(&mut self, index: usize) -> Self::Item;
}

unsafe impl<I: Iterator> SpecTrustedRandomAccess for I {
    default unsafe fn try_get_unchecked(&mut self, _: usize) -> Self::Item {
        panic!("Should only be called on TrustedRandomAccess iterators");
    }
}

unsafe impl<I: Iterator + TrustedRandomAccess> SpecTrustedRandomAccess for I {
    unsafe fn try_get_unchecked(&mut self, index: usize) -> Self::Item {
        // सुरक्षितता: कॉलरने `Iterator::__iterator_get_unchecked` कराराचे समर्थन केले पाहिजे.
        //
        unsafe { self.__iterator_get_unchecked(index) }
    }
}