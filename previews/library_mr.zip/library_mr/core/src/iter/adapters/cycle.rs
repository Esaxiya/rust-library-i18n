use crate::{iter::FusedIterator, ops::Try};

/// एक पुनरावृत्ती करणारा जो सतत पुनरावृत्ती करत नाही.
///
/// हे `struct` एक्स 100 एक्स वर एक्स0 2 एक्स पद्धतीने तयार केले गेले आहे.
/// अधिकसाठी त्याचे दस्तऐवजीकरण पहा.
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // सायकल पुनरावृत्तीकर्ता रिक्त किंवा असीम आहे
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // वर्तमान पुनरावृत्तीकर्ता पूर्णपणे पुनरावृत्ती करा.
        // हे आवश्यक आहे कारण `self.orig` नसतानाही `self.iter` रिक्त असू शकते
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // सायकल चालवणारे यंत्र रिक्त आहे की नाही याचा मागोवा ठेवत एक संपूर्ण चक्र पूर्ण करा.
        // आम्हाला असीम लूप टाळण्यासाठी रिक्त पुनरावृत्ती करणार्‍याच्या बाबतीत लवकर परत जाणे आवश्यक आहे
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // `fold` अधिलिखित नाही, कारण `fold` `Cycle` साठी जास्त अर्थ प्राप्त करीत नाही आणि आम्ही डीफॉल्टपेक्षा काही चांगले करू शकत नाही.
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}