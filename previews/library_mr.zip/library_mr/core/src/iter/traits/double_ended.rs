use crate::ops::{ControlFlow, Try};

/// दोन्ही टोकापासून घटक मिळविण्यास सक्षम इटरेटर
///
/// `DoubleEndedIterator` लागू करणार्‍या काहीतरीची [`Iterator`] लागू करणार्‍या एखाद्या वस्तूवर एक अतिरिक्त क्षमता आहे: मागच्या बाजूने तसेच पुढच्या भागाकडून देखील `आयटम` घेण्याची क्षमता.
///
///
/// हे लक्षात घेणे आवश्यक आहे की मागे आणि पुढे दोन्ही समान श्रेणीवर काम करतात आणि क्रॉस करत नाहीत: जेव्हा ते मध्यभागी भेटतात तेव्हा पुनरावृत्ती संपते.
///
/// [`Iterator`] प्रोटोकॉल प्रमाणेच फॅशनमध्ये, एकदा `DoubleEndedIterator` एक [`next_back()`] वरून [`None`] परत करतो, तर त्याला परत कॉल करून पुन्हा कधीही [`Some`] परत येऊ शकत नाही किंवा नाही.
/// [`next()`] आणि [`next_back()`] या हेतूसाठी अदलाबदल करण्यायोग्य आहेत.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// मूलभूत वापर:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// आयटरच्या शेवटी एक घटक काढते आणि मिळवते.
    ///
    /// जेव्हा कोणतेही घटक नसतात तेव्हा `None` मिळवते.
    ///
    /// [trait-level] डॉक्समध्ये अधिक तपशील आहेत.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// `DoubleEenderIterator` च्या पद्धतींनी उत्पन्न केलेले घटक [`Iterator`] च्या पद्धतींनी उत्पन्न केलेल्यांपेक्षा भिन्न असू शकतात:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// `n` घटकांद्वारे मागील पासून इटरेटरला पुढे करते.
    ///
    /// `advance_back_by` [`advance_by`] ची उलट आवृत्ती आहे.ही पद्धत [`None`] चे समोर येईपर्यंत [`next_back`] पर्यंत [`next_back`] वर कॉल करून `n` घटकांना उत्सुकतेने मागे सोडते.
    ///
    /// `advance_back_by(n)` एक्सट्रॅक्टर `n` घटकांद्वारे यशस्वीरित्या प्रगती करत असल्यास [`Ok(())`] किंवा [`None`] आढळल्यास [`Err(k)`] परत करेल, जेथे एक्स-04 एक्स घटकांची संख्या संपविण्यापूर्वी पुनरावृत्ती होणार्‍या पुनरावृत्ती झालेल्या घटकांची संख्या आहे (उदा.
    /// आयटरची लांबी).
    /// लक्षात घ्या की `k` नेहमी `n` पेक्षा कमी असतो.
    ///
    /// `advance_back_by(0)` वर कॉल करणे कोणतेही घटक वापरत नाही आणि नेहमीच [`Ok(())`] परत करते.
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // केवळ `&3` वगळले गेले
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// आयटरच्या शेवटी पासून `n` वा घटक परत करते.
    ///
    /// हे मूलत: एक्स00 एक्स ची उलट आवृत्ती आहे.
    /// जरी बहुतेक अनुक्रमणिका ऑपरेशन्स प्रमाणे, गणना शून्यापासून सुरू होते, म्हणून `nth_back(0)` शेवटपासून प्रथम मूल्य मिळवते, दुसरे `nth_back(1)` आणि इतके.
    ///
    ///
    /// लक्षात ठेवा की परतलेल्या घटकासह शेवट आणि परतलेले घटक यांच्यामधील सर्व घटक खाऊन टाकतील.
    /// याचा अर्थ असा आहे की समान पुनरावृत्तीकर्त्यावर `nth_back(0)` वर एकाधिक वेळा कॉल करणे भिन्न घटक परत करेल.
    ///
    /// `nth_back()` जर एक्स 0 एक्स एक्स आयटरच्या लांबीपेक्षा मोठे किंवा समान असेल तर [`None`] परत करेल.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// अनेकदा `nth_back()` कॉल केल्याने पुनरावृत्ती करणारा पुन्हा चालू होणार नाही:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// `n + 1` पेक्षा कमी घटक असल्यास `None` परत करणे:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// ही एक्स00 एक्स ची उलट आवृत्ती आहे: हे पुनरावृत्ती करणार्‍याच्या मागील भागापासून सुरू होणारे घटक घेते.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // कारण हे अल्प-प्रसारित आहे, उर्वरित घटक अद्याप इटरेटरद्वारे उपलब्ध आहेत.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// पुनरावृत्ती करण्याची पद्धत जी पुनरावृत्ती करणाrator्याचे घटक मागील पासून प्रारंभ करते, एका अंतिम, अंतिम मूल्यापर्यंत कमी करते.
    ///
    /// ही एक्स00 एक्स ची रिव्हर्स आवृत्ती आहे: हे आयटरच्या मागील भागापासून सुरू होणारे घटक घेते.
    ///
    /// `rfold()` दोन वितर्क घेतात: प्रारंभिक मूल्य आणि दोन वितर्कांसह क्लोजरः एक एक्स 100 एक्स आणि एक घटक.
    /// क्लोजर संचयकाला पुढील पुनरावृत्तीसाठी असलेले मूल्य मिळवते.
    ///
    /// प्रारंभिक मूल्य संचयकाचे प्रथम कॉलवर असलेले मूल्य आहे.
    ///
    /// हे क्लोजर इटरेटरच्या प्रत्येक घटकावर लागू केल्यानंतर, एक्स00 एक्स जमा करणारा परत करतो.
    ///
    /// या ऑपरेशनला कधीकधी 'reduce' किंवा 'inject' म्हणतात.
    ///
    /// जेव्हा आपल्याकडे एखाद्या वस्तूचा संग्रह असतो तेव्हा फोल्डिंग उपयुक्त ठरते आणि त्यामधून एक मूल्य तयार करू इच्छितो.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // अ च्या सर्व घटकांची बेरीज
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// हे उदाहरण एक स्ट्रिंग तयार करते, प्रारंभिक मूल्यासह प्रारंभ करुन आणि प्रत्येक घटकासह मागील बाजूस पुढील बाजूपर्यंत सुरू ठेवते:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// मागीलमधून इटरेटरच्या घटकासाठी शोध करतो जे एखाद्या भक्षकांना समाधानी करते.
    ///
    /// `rfind()` `true` किंवा `false` परत करणारी बंदी घेते.
    /// हे इट्यूटरच्या प्रत्येक घटकास हे समाप्तीपासून प्रारंभ होण्यास लागू होते आणि जर त्यापैकी कोणी एक्स ०१ एक्स परत केले तर एक्स ०२ एक्स एक्स १० एक्स परत करेल.
    /// जर ते सर्वजण X01 एक्स परत करतात, तर ते [`None`] परत करते.
    ///
    /// `rfind()` शॉर्ट सर्किटिंग आहे;दुसर्‍या शब्दांत, क्लोजर `true` परत होताच प्रक्रिया थांबेल.
    ///
    /// कारण `rfind()` संदर्भ घेते आणि बर्‍याच पुनरावृत्ती पुनरावलोकनांद्वारे पुनरावृत्ती होतात, यामुळे संभाव्यत: गोंधळात टाकणारी परिस्थिती उद्भवते जिथे युक्तिवाद दुहेरी संदर्भ आहे.
    ///
    /// आपण हा प्रभाव `&&x` सह खालील उदाहरणांमध्ये पाहू शकता.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// पहिल्या `true` वर थांबणे:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // आम्ही अद्याप `iter` वापरू शकतो, कारण तेथे अधिक घटक आहेत.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}