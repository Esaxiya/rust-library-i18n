use crate::iter;
use crate::num::Wrapping;

/// इट्रेटरचा सारांश तयार करुन तयार करता येऊ शकणार्‍या प्रकारांचे प्रतिनिधित्व करण्यासाठी Trait.
///
/// हे झेडट्रायट0झेड आयटरवर [`sum()`] पद्धत लागू करण्यासाठी वापरली जाते.
/// trait लागू करणारे प्रकार [`sum()`] पद्धतीने व्युत्पन्न केले जाऊ शकतात.
/// [`FromIterator`] प्रमाणे या trait क्वचितच थेट कॉल केले पाहिजे आणि त्याऐवजी [`Iterator::sum()`] सह संवाद साधला पाहिजे.
///
///
/// [`sum()`]: Sum::sum
/// [`FromIterator`]: iter::FromIterator
#[stable(feature = "iter_arith_traits", since = "1.12.0")]
pub trait Sum<A = Self>: Sized {
    /// आयटरर घेणारी आणि "summing up" द्वारे घटकांकडून `Self` व्युत्पन्न करणारी पद्धत.
    ///
    #[stable(feature = "iter_arith_traits", since = "1.12.0")]
    fn sum<I: Iterator<Item = A>>(iter: I) -> Self;
}

/// प्रकार दर्शविण्यास Trait जे इटरेटरच्या गुणाकार घटकांद्वारे तयार केले जाऊ शकतात.
///
/// हे झेडट्रायट0झेड आयटरवर [`product()`] पद्धत लागू करण्यासाठी वापरली जाते.
/// trait लागू करणारे प्रकार [`product()`] पद्धतीने व्युत्पन्न केले जाऊ शकतात.
/// [`FromIterator`] प्रमाणे या trait क्वचितच थेट कॉल केले पाहिजे आणि त्याऐवजी [`Iterator::product()`] सह संवाद साधला पाहिजे.
///
///
/// [`product()`]: Product::product
/// [`FromIterator`]: iter::FromIterator
///
#[stable(feature = "iter_arith_traits", since = "1.12.0")]
pub trait Product<A = Self>: Sized {
    /// आयटर घेणारी आणि घटकांची गुणाकार करून घटकांकडून एक्स 100 एक्स व्युत्पन्न करणारी पद्धत.
    ///
    #[stable(feature = "iter_arith_traits", since = "1.12.0")]
    fn product<I: Iterator<Item = A>>(iter: I) -> Self;
}

macro_rules! integer_sum_product {
    (@impls $zero:expr, $one:expr, #[$attr:meta], $($a:ty)*) => ($(
        #[$attr]
        impl Sum for $a {
            fn sum<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    $zero,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[$attr]
        impl Product for $a {
            fn product<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    $one,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }

        #[$attr]
        impl<'a> Sum<&'a $a> for $a {
            fn sum<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    $zero,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[$attr]
        impl<'a> Product<&'a $a> for $a {
            fn product<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    $one,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }
    )*);
    ($($a:ty)*) => (
        integer_sum_product!(@impls 0, 1,
                #[stable(feature = "iter_arith_traits", since = "1.12.0")],
                $($a)*);
        integer_sum_product!(@impls Wrapping(0), Wrapping(1),
                #[stable(feature = "wrapping_iter_arith", since = "1.14.0")],
                $(Wrapping<$a>)*);
    );
}

macro_rules! float_sum_product {
    ($($a:ident)*) => ($(
        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl Sum for $a {
            fn sum<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    0.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl Product for $a {
            fn product<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    1.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl<'a> Sum<&'a $a> for $a {
            fn sum<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    0.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl<'a> Product<&'a $a> for $a {
            fn product<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    1.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }
    )*)
}

integer_sum_product! { i8 i16 i32 i64 i128 isize u8 u16 u32 u64 u128 usize }
float_sum_product! { f32 f64 }

#[stable(feature = "iter_arith_traits_result", since = "1.16.0")]
impl<T, U, E> Sum<Result<U, E>> for Result<T, E>
where
    T: Sum<U>,
{
    /// [`Iterator`] मध्ये प्रत्येक घटक घेते: जर ते X01 एक्स असेल तर पुढील घटक घेतले जात नाहीत आणि [`Err`] परत मिळविला जाईल.
    /// कोणताही [`Err`] नसावा, सर्व घटकांची बेरीज परत केली जाईल.
    ///
    /// # Examples
    ///
    /// हे झेडवेक्टोर0 झेडमधील प्रत्येक पूर्ण संख्येची बेरीज करते, जर एखाद्या नकारात्मक घटकास सामोरे जाते तर बेरीज नाकारते:
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let res: Result<i32, &'static str> = v.iter().map(|&x: &i32|
    ///     if x < 0 { Err("Negative element found") }
    ///     else { Ok(x) }
    /// ).sum();
    /// assert_eq!(res, Ok(3));
    /// ```
    ///
    ///
    fn sum<I>(iter: I) -> Result<T, E>
    where
        I: Iterator<Item = Result<U, E>>,
    {
        iter::process_results(iter, |i| i.sum())
    }
}

#[stable(feature = "iter_arith_traits_result", since = "1.16.0")]
impl<T, U, E> Product<Result<U, E>> for Result<T, E>
where
    T: Product<U>,
{
    /// [`Iterator`] मध्ये प्रत्येक घटक घेते: जर ते X01 एक्स असेल तर पुढील घटक घेतले जात नाहीत आणि [`Err`] परत मिळविला जाईल.
    /// [`Err`] येऊ नये, सर्व घटकांचे उत्पादन परत केले.
    ///
    fn product<I>(iter: I) -> Result<T, E>
    where
        I: Iterator<Item = Result<U, E>>,
    {
        iter::process_results(iter, |i| i.product())
    }
}

#[stable(feature = "iter_arith_traits_option", since = "1.37.0")]
impl<T, U> Sum<Option<U>> for Option<T>
where
    T: Sum<U>,
{
    /// [`Iterator`] मध्ये प्रत्येक घटक घेते: जर ते X01 एक्स असेल तर पुढील घटक घेतले जात नाहीत आणि [`None`] परत मिळविला जाईल.
    /// कोणताही [`None`] नसावा, सर्व घटकांची बेरीज परत केली जाईल.
    ///
    /// # Examples
    ///
    /// हे एका शब्दात 'a' अक्षराच्या vector मधील तारखेच्या स्थितीचे सारांश देते, जर शब्दात 'a' वर्ण नसल्यास ऑपरेशन `None` परत करते:
    ///
    ///
    /// ```
    /// let words = vec!["have", "a", "great", "day"];
    /// let total: Option<usize> = words.iter().map(|w| w.find('a')).sum();
    /// assert_eq!(total, Some(5));
    /// ```
    ///
    fn sum<I>(iter: I) -> Option<T>
    where
        I: Iterator<Item = Option<U>>,
    {
        iter.map(|x| x.ok_or(())).sum::<Result<_, _>>().ok()
    }
}

#[stable(feature = "iter_arith_traits_option", since = "1.37.0")]
impl<T, U> Product<Option<U>> for Option<T>
where
    T: Product<U>,
{
    /// [`Iterator`] मध्ये प्रत्येक घटक घेते: जर ते X01 एक्स असेल तर पुढील घटक घेतले जात नाहीत आणि [`None`] परत मिळविला जाईल.
    /// [`None`] येऊ नये, सर्व घटकांचे उत्पादन परत केले.
    ///
    fn product<I>(iter: I) -> Option<T>
    where
        I: Iterator<Item = Option<U>>,
    {
        iter.map(|x| x.ok_or(())).product::<Result<_, _>>().ok()
    }
}