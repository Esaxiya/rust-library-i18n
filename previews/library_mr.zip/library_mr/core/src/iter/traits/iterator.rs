// दुर्लक्ष-नीट-फाईललेन्थ या फाईलमध्ये जवळजवळ केवळ एक्स 100 एक्स ची व्याख्या असते.
// आम्ही हे एकाधिक फायलींमध्ये विभाजित करू शकत नाही.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// पुनरावृत्ती करणार्‍यांशी वागण्याचा एक इंटरफेस.
///
/// हे मुख्य पुनरावृत्ती करणारा trait आहे.
/// सामान्यत: पुनरावृत्ती करणार्‍यांच्या संकल्पनेबद्दल, कृपया [module-level documentation] पहा.
/// विशेषतः, आपण [implement `Iterator`][impl] कसे करावे हे जाणून घेऊ शकता.
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// पुनरावृत्ती होणार्‍या घटकांचा प्रकार.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// आयटरची प्रगती करते आणि पुढील मूल्य मिळवते.
    ///
    /// पुनरावृत्ती पूर्ण झाल्यावर [`None`] मिळवते.
    /// वैयक्तिक इटरेटर अंमलबजावणी पुनरावृत्ती पुन्हा सुरू करणे निवडू शकते आणि म्हणून एक्स 100 एक्सला पुन्हा कॉल करणे अखेरीस काही क्षणी पुन्हा X01 एक्स परत करणे सुरू करू शकते किंवा करू शकत नाही.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // next() ला कॉल नंतरचे मूल्य परत करते ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... आणि मग ती संपल्यावर काहीही नाही.
    /// assert_eq!(None, iter.next());
    ///
    /// // अधिक कॉल `None` परत येऊ शकतात किंवा परत येऊ शकत नाहीत.येथे, ते नेहमीच करतील.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// आयटरच्या उर्वरित लांबीवरील सीमा मिळवते.
    ///
    /// विशेषत: `size_hint()` एक टपल मिळवते जिथे प्रथम घटक कमी बाउंड असतो आणि दुसरा घटक वरच्या बाउंड असतो.
    ///
    /// परत आलेल्या टपलच्या दुसर्‍या अर्ध्या भागामध्ये एक [`पर्याय`]`<`[`usize`] `>` आहे.
    /// येथे एक्स ०१ एक्सचा अर्थ असा आहे की एकतर अप्पर बाऊंड ज्ञात नाही, किंवा वरची बाउंड [`usize`] पेक्षा मोठी आहे.
    ///
    /// # अंमलबजावणीच्या नोट्स
    ///
    /// हे लागू केले जात नाही की इटरेटर अंमलबजावणीमुळे घटकांची घोषित संख्या मिळते.बग्गी इट्रेटर खालच्या सीमापेक्षा कमी किंवा घटकांच्या वरच्या सीमांपेक्षा कमी उत्पन्न मिळवू शकते.
    ///
    /// `size_hint()` प्रामुख्याने पुनरावृत्ती करणार्‍याच्या घटकांसाठी जागा आरक्षित करण्यासारख्या ऑप्टिमायझेशनसाठी वापरली जावी असा हेतू आहे, परंतु उदा. वर विश्वास ठेवू नये, असुरक्षित कोडमधील सीमा धनादेश वगळणे.
    /// `size_hint()` च्या चुकीच्या अंमलबजावणीमुळे मेमरी सुरक्षा उल्लंघन होऊ नये.
    ///
    /// ते म्हणाले, अंमलबजावणीने अचूक अंदाज प्रदान केला पाहिजे, अन्यथा ते झेडट्रायट0 झेडच्या प्रोटोकॉलचे उल्लंघन होईल.
    ///
    /// डीफॉल्ट अंमलबजावणी ite (0, `[` काहीही नाही]] `) returns मिळवते जे कोणत्याही पुनरावृत्ती करणार्‍यासाठी योग्य आहे.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// अधिक जटिल उदाहरणः
    ///
    /// ```
    /// // अगदी शून्य ते दहा पर्यंतची संख्या.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // आम्ही शून्य ते दहा वेळा पुनरावृत्ती होऊ शकतो.
    /// // हे माहित आहे की हे पाच अचूक आहे filter() कार्यान्वित केल्याशिवाय शक्य होणार नाही.
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // आता chain() सह आणखी पाच संख्या जोडू
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // आता दोन्ही मर्यादा पाचने वाढविल्या आहेत
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// अप्पर बाऊंडसाठी `None` परत करणे:
    ///
    /// ```
    /// // अनंत पुनरावृत्ती करणार्‍यास कोणतेही वरचे बंधन नसते आणि कमाल संभाव्य लोअर बाउंड नसते
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// पुनरावृत्तीची संख्या मोजून ते परत करत, पुनरावृत्ती करणारा वापरते.
    ///
    /// [`None`] येईपर्यंत ही पद्धत [`next`] ला वारंवार कॉल करेल, [`Some`] किती वेळा पाहिले याची संख्या परत करेल.
    /// लक्षात घ्या की इटरटरमध्ये कोणतेही घटक नसले तरीही [`next`] ला एकदा तरी कॉल करावे लागेल.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # ओव्हरफ्लो वर्तन
    ///
    /// पध्दती ओव्हरफ्लोपासून संरक्षण देत नाही, म्हणून एक्सटरएक्सपेक्षा जास्त घटक असलेल्या पुनरावृत्तीच्या घटकांची मोजणी करणे एकतर चुकीचे परिणाम किंवा panics उत्पन्न करते.
    ///
    /// डीबग असेरेन्स सक्षम केले असल्यास, झेडस्पॅनिक 0 झेडची हमी दिली जाते.
    ///
    /// # Panics
    ///
    /// जर इटरटरमध्ये [`usize::MAX`] पेक्षा जास्त घटक असतील तर हे फंक्शन panic असू शकते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// शेवटचा घटक परत करून, पुनरावृत्ती करणारा वापरते.
    ///
    /// ही पद्धत पुनरावृत्ती होणार्‍याचे [`None`] परत करेपर्यंत त्याचे मूल्यांकन करेल.
    /// असे करत असताना, ते विद्यमान घटकाचा मागोवा ठेवते.
    /// [`None`] परत आल्यानंतर, `last()` नंतर पाहिलेला शेवटचा घटक परत करेल.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// `n` घटकांद्वारे पुनरावृत्ती करणार्‍याची प्रगती करते.
    ///
    /// ही पद्धत [`None`] चे होईपर्यंत [`next`] पर्यंत [`next`] वर कॉल करून `n` घटकांना उत्सुकतेने वगळेल.
    ///
    /// `advance_by(n)` एक्सट्रॅक्टर `n` घटकांद्वारे यशस्वीरित्या प्रगती करत असल्यास [`Ok(())`][Ok] किंवा [`None`] आढळल्यास [`Err(k)`][Err] परत करेल, जेथे एक्स-04 एक्स घटकांची संख्या संपविण्यापूर्वी पुनरावृत्ती होणार्‍या पुनरावृत्ती झालेल्या घटकांची संख्या आहे (उदा.
    /// आयटरची लांबी).
    /// लक्षात घ्या की `k` नेहमी `n` पेक्षा कमी असतो.
    ///
    /// `advance_by(0)` वर कॉल करणे कोणतेही घटक वापरत नाही आणि नेहमीच [`Ok(())`][Ok] परत करते.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // केवळ `&4` वगळले गेले
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// आयटरचा `n` वा घटक परत करतो.
    ///
    /// इतर अनुक्रमणिक ऑपरेशन्स प्रमाणे, गणना शून्यापासून सुरू होते, म्हणून `nth(0)` प्रथम मूल्य, दुसरे `nth(1)` आणि इतर मिळवते.
    ///
    /// लक्षात ठेवा की मागील सर्व घटक, तसेच परतलेले घटक, पुनरावृत्ती करणार्‍याकडून सेवन केले जातील.
    /// याचा अर्थ असा की आधीचे घटक टाकून दिले जातील आणि त्याच आयटरवर अनेक वेळा `nth(0)` कॉल करणे भिन्न घटक परत करेल.
    ///
    ///
    /// `nth()` जर एक्स 0 एक्स एक्स आयटरच्या लांबीपेक्षा मोठे किंवा समान असेल तर [`None`] परत करेल.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// अनेकदा `nth()` कॉल केल्याने पुनरावृत्ती करणारा पुन्हा चालू होणार नाही:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// `n + 1` पेक्षा कमी घटक असल्यास `None` परत करणे:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// त्याच बिंदूपासून प्रारंभ होणारा आयटर तयार करतो, परंतु प्रत्येक पुनरावृत्तीच्या वेळी दिलेल्या रकमेवरुन पाऊल ठेवतो.
    ///
    /// टीप 1: दिलेल्या पायर्‍याची पर्वा न करता, पुनरावृत्ती करणाराचा पहिला घटक नेहमी परत येईल.
    ///
    /// टीप 2: ज्या वेळी दुर्लक्षित घटकांना खेचले जाईल ते वेळ निश्चित केलेले नाही.
    /// `StepBy` अनुक्रम `next(), nth(step-1), nth(step-1),…` प्रमाणे वर्तन करते, परंतु अनुक्रमांसारखे वर्तन करण्यास देखील स्वतंत्र आहे
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// कामकाजाच्या कारणास्तव कोणत्या पुनरावृत्तीसाठी काही मार्ग बदलला जाऊ शकतो.
    /// दुसरा मार्ग पुनरावृत्ती करणार्‍यास पूर्वी वाढवेल आणि अधिक वस्तू वापरू शकेल.
    ///
    /// `advance_n_and_return_first` च्या समतुल्य आहे:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// दिलेली पायरी `0` असल्यास पद्धत panic करेल.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// दोन पुनरावृत्ती घेते आणि अनुक्रमे दोन्हीवर एक नवीन इटरटर तयार करते.
    ///
    /// `chain()` एक नवीन इटरेटर परत करेल जे प्रथम पुनरावृत्ती होणार्‍याच्या मूल्यांवर पुन्हा पुनरावृत्ती करेल आणि नंतर दुसर्‍या पुनरावृत्ती करणार्‍याच्या मूल्यांवर जाईल.
    ///
    /// दुस words्या शब्दांत, ते एका साखळीमध्ये दोन पुनरावृत्त्यांना जोडते.🔗
    ///
    /// [`once`] सामान्यत: एकल मूल्य अन्य प्रकारच्या पुनरावृत्तीच्या शृंखलामध्ये रुपांतर करण्यासाठी वापरली जाते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `chain()` चा युक्तिवाद [`IntoIterator`] चा वापर करत असल्याने, आम्ही केवळ [`Iterator`] च नव्हे तर [`Iterator`] मध्ये रूपांतरित केले जाऊ शकते अशा कोणत्याही गोष्टीस पास करू शकतो.
    /// उदाहरणार्थ, (`&[T]`) च्या काप [`IntoIterator`] ची अंमलबजावणी करतात आणि म्हणून थेट `chain()` वर जाऊ शकतात:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// आपण Windows एपीआय सह कार्य करीत असल्यास, आपण [`OsStr`] ला एक्स 100 एक्स मध्ये रूपांतरित करू शकता:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// जोडप्यांच्या एकाच पुनरावृत्तीकर्त्यामध्ये दोन पुनरावलोकने 'झिप अप' करा.
    ///
    /// `zip()` एक नवीन इटरेटर परत करेल जो दोन अन्य पुनरावृत्ती होणा-यांवर पुनरावृत्ती करेल आणि प्रथम आयटरद्वारे पहिला घटक येतो आणि दुसरे घटक दुसर्‍या पुनरावृत्तीकातून येते असे टपल परत करेल.
    ///
    ///
    /// दुसर्‍या शब्दांत, हे एकामध्ये दोन पुनरावृत्ती करणार्‍यांना एकत्र झिप करते.
    ///
    /// जर एकतर आयटरने एक्स ०१ एक्स परत केले तर झिप केलेल्या पुनरावृत्ती करणार्‍याकडून एक्स ०२ एक्स एक्स १० एक्स परत करेल.
    /// प्रथम इटररेटरने एक्स 100 एक्स परत केल्यास, एक्स 0 एक्स एक्स शॉर्ट-सर्किट होईल आणि दुसर्‍या इट्रेटरवर एक्स0 2 एक्स कॉल केला जाणार नाही.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` चा युक्तिवाद [`IntoIterator`] चा वापर करत असल्याने, आम्ही केवळ [`Iterator`] च नव्हे तर [`Iterator`] मध्ये रूपांतरित केले जाऊ शकते अशा कोणत्याही गोष्टीस पास करू शकतो.
    /// उदाहरणार्थ, (`&[T]`) च्या काप [`IntoIterator`] ची अंमलबजावणी करतात आणि म्हणून थेट `zip()` वर जाऊ शकतात:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` बर्‍याच वेळा मर्यादित व्यक्तीवर अनंत पुनरावृत्ती करणार्‍याला झिप करण्यासाठी वापरले जाते.
    /// हे कार्य करते कारण परिष्कृत पुनरावृत्ती करणारा शेवटी, जिपर संपवून, एक्स 0१ एक्स परत करेल.`(0..)` सह झिप करणे हे बरेच [`enumerate`] सारखे दिसू शकते:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// नवीन इटरेटर तयार करते जे मूळ आयटरच्या समीप आयटम दरम्यान एक्स00 एक्सची एक प्रत ठेवते.
    ///
    /// `separator` [`Clone`] कार्यान्वित करत नाही किंवा प्रत्येक वेळी गणना करणे आवश्यक असल्यास, [`intersperse_with`] वापरा.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // `a` मधील प्रथम घटक.
    /// assert_eq!(a.next(), Some(&100)); // विभाजक.
    /// assert_eq!(a.next(), Some(&1));   // `a` मधील पुढील घटक
    /// assert_eq!(a.next(), Some(&100)); // विभाजक.
    /// assert_eq!(a.next(), Some(&2));   // `a` मधील शेवटचा घटक.
    /// assert_eq!(a.next(), None);       // पुनरावृत्ती करणारा पूर्ण झाला.
    /// ```
    ///
    /// `intersperse` सामान्य घटकांचा वापर करून इटरटरच्या आयटममध्ये सामील होण्यासाठी खूप उपयुक्त ठरू शकते:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// नवीन इटरेटर तयार करते जे एक्सट्रॅक्सद्वारे व्युत्पन्न केलेला आयटम मूळ पुनरावृत्तीच्या समीप आयटम दरम्यान ठेवते.
    ///
    /// प्रत्येक वेळी अंतर्निहित पुनरावृत्ती करणा from्याकडून दोन जवळच्या वस्तूंच्या दरम्यान एखादी वस्तू ठेवल्यास ती बंद करणे योग्य वेळी म्हटले जाईल;
    /// विशेषतः, अंतर्निहित पुनरावृत्ती करणारा दोन वस्तूंपेक्षा कमी उत्पन्न मिळाल्यास आणि शेवटची वस्तू मिळाल्यानंतर क्लोजर म्हटले जात नाही.
    ///
    ///
    /// जर पुनरावृत्ती करणार्‍याची वस्तू [`Clone`] लागू करते तर [`intersperse`] वापरणे सोपे होईल.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // `v` मधील प्रथम घटक.
    /// assert_eq!(it.next(), Some(NotClone(99))); // विभाजक.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // `v` मधील पुढील घटक
    /// assert_eq!(it.next(), Some(NotClone(99))); // विभाजक.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // `v` मधील शेवटचा घटक.
    /// assert_eq!(it.next(), None);               // पुनरावृत्ती करणारा पूर्ण झाला.
    /// ```
    ///
    /// `intersperse_with` विभाजक मोजणे आवश्यक अशा परिस्थितीत वापरले जाऊ शकते:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // एखादी वस्तू व्युत्पन्न करण्यासाठी बंदर त्या परस्पर संदर्भात कर्ज घेते.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// एक बंद घेते आणि एक इटररेटर तयार करते ज्याला त्या प्रत्येक घटकावर बंद म्हणतात.
    ///
    /// `map()` त्याच्या युक्तिवादाच्या सहाय्याने एका इटरेटरला दुसर्‍यामध्ये रूपांतरित करते:
    /// [`FnMut`] लागू करणारे काहीतरी.हे नवीन इटरेटर तयार करते जे मूळ इटरेटरच्या प्रत्येक घटकावर या क्लोजरला कॉल करते.
    ///
    /// आपण प्रकारांमध्ये विचार करण्यास चांगले असल्यास, आपण असे `map()` बद्दल विचार करू शकता:
    /// जर आपल्याकडे इटरेटर असेल जे आपल्याला काही प्रकारच्या एक्स ०१ एक्सचे घटक देईल आणि आपल्याला काही प्रकारचे एक्स ०२ एक्स चे इटरेटर हवा असेल तर आपण एक्स ०0 एक्स वापरु शकता आणि एक्स ० एक्स एक्स घेणारी बंदी देऊन एक्स एक्स एक्स एक्स वापरू शकता.
    ///
    ///
    /// `map()` हे एक्स-एक्स एक्स लूपसारखे वैचारिक आहे.तथापि, `map()` आळशी असल्याने आपण आधीपासून अन्य पुनरावृत्ती करणार्‍यांसह आधीपासून कार्य करत असताना याचा वापर केला जातो.
    /// आपण साइड इफेक्टसाठी काही प्रकारचे पळवाट करत असल्यास, `map()` पेक्षा [`for`] वापरणे अधिक मुर्खपणाचे मानले जाते.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// आपण काही प्रकारचे साइड इफेक्ट करत असल्यास, [`for`] ते `map()` ला प्राधान्य द्या:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // हे करू नका:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // हे आळशी आहे कारण अंमलात आणणार नाही.Rust आपल्याला याबद्दल चेतावणी देईल.
    ///
    /// // त्याऐवजी, यासाठी वापरा:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// आयटरच्या प्रत्येक घटकावर बंद कॉल करते.
    ///
    /// हे आयटरवर [`for`] लूप वापरण्यासारखे आहे, जरी `break` आणि `continue` बंद केल्यापासून शक्य नाही.
    /// हे सामान्यत: `for` लूप वापरण्यासाठी अधिक मुर्ख आहे परंतु लांब पुनरावृत्ती साखळ्यांच्या शेवटी आयटमवर प्रक्रिया करताना `for_each` अधिक सुवाच्य असू शकते.
    ///
    /// काही प्रकरणांमध्ये एक्स 0 एक्स एक्स लूपपेक्षा वेगवान देखील असू शकतो, कारण ते एक्स 100 एक्स सारख्या अ‍ॅडॉप्टर्सवर अंतर्गत पुनरावृत्ती वापरेल.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// अशा छोट्या छोट्या उदाहरणासाठी, एक्स 100 एक्स लूप क्लिनर असू शकेल, परंतु दीर्घ पुनरावृत्ती करणार्‍यांसह कार्यशील शैली ठेवणे `for_each` अधिक श्रेयस्कर असेल:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// एखादा आयटर तयार करतो जो घटक मिळतो की नाही हे निर्धारित करण्यासाठी क्लोजर वापरतो.
    ///
    /// घटक दिले तर बंद केल्याने `true` किंवा `false` परत येणे आवश्यक आहे.परत केलेल्या पुनरावृत्तीकर्त्यास केवळ तेच घटक मिळतात ज्यासाठी क्लोजर ट्रू मिळते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// कारण `filter()` ला बंद केलेला संदर्भ घेते आणि बर्‍याच पुनरावृत्ती पुनरावलोकनांद्वारे पुनरावृत्ती होतात, यामुळे संभाव्यत: गोंधळ घालणारी परिस्थिती उद्भवते, जिथे बंद होण्याचा प्रकार दुहेरी संदर्भ आहे:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // दोन * चे गरज!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// त्याऐवजी एखादी गोष्ट काढून टाकण्यासाठी युक्तिवादावर डिस्ट्रक्चरिंग वापरणे सामान्य आहे:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // दोघे आणि *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// किंवा दोन्ही:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // दोन एक्स00 एक्स
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// या थरांचा.
    ///
    /// लक्षात घ्या की `iter.filter(f).next()` हे `iter.find(f)` च्या समतुल्य आहे.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// एक इटररेटर तयार करतो जो फिल्टर आणि नकाशे दोन्ही करतो.
    ///
    /// मिळविलेले पुनरावृत्तीकर्ता केवळ the मूल्यांचे उत्पन्न देते ज्यासाठी पुरवठा बंद केल्याने एक्स 100 एक्स दिले.
    ///
    /// `filter_map` [`filter`] आणि [`map`] चे अधिक संक्षिप्त बनवण्यासाठी वापरला जाऊ शकतो.
    /// खाली दिलेली उदाहरणे दर्शविते की X001 मधील एका कॉलवर `map().filter().map()` कसे लहान केले जाऊ शकते.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// येथे हेच उदाहरण आहे, परंतु [`filter`] आणि [`map`] सह:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// एक इटरेटर तयार करते जे वर्तमान पुनरावृत्ती संख्या तसेच पुढील मूल्य देते.
    ///
    /// आयटरने जोड्या `(i, val)` मिळवल्या, जिथे `i` हे पुनरावृत्तीचे वर्तमान अनुक्रमणिका आहे आणि एक्स 0 2 एक्स ही पुनरावृत्ती करणार्‍याद्वारे परत केलेले मूल्य आहे.
    ///
    ///
    /// `enumerate()` त्याची गणना [`usize`] म्हणून ठेवते.
    /// आपण भिन्न आकाराचे पूर्णांक मोजू इच्छित असल्यास, [`zip`] कार्य समान कार्यक्षमता प्रदान करते.
    ///
    /// # ओव्हरफ्लो वर्तन
    ///
    /// पध्दती ओव्हरफ्लोपासून संरक्षण देत नाही, म्हणून [`usize::MAX`] पेक्षा जास्त घटकांची गणना केल्यास एकतर चुकीचा परिणाम किंवा panics मिळतो.
    /// डीबग असेरेन्स सक्षम केले असल्यास, झेडस्पॅनिक 0 झेडची हमी दिली जाते.
    ///
    /// # Panics
    ///
    /// टू-बी-रिटर्न इंडेक्स [`usize`] ओव्हरफ्लो झाल्यास रिटर्न इटररेटर झेडस्पॅनिक 0 झेड कदाचित
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// एक इटररेटर तयार करते जो एक्सटरएक्सचा वापर न करता पुनरावृत्तीचा पुढील घटक पाहण्यासाठी वापरू शकतो.
    ///
    /// आयटरमध्ये एक [`peek`] पद्धत जोडते.अधिक माहितीसाठी त्याचे दस्तऐवजीकरण पहा.
    ///
    /// लक्षात घ्या की [`peek`] प्रथमच कॉल केल्यावर अंतर्निहित आयटरटर अद्याप प्रगत आहे: पुढील घटक पुनर्प्राप्त करण्यासाठी, एक्स 300 एक्स अंतर्निहित पुनरावृत्तीकर्त्यावर कॉल केले जाते, म्हणून कोणतेही दुष्परिणाम (उदा.
    ///
    /// [`next`] पद्धतीचे पुढील मूल्य प्राप्त करण्याशिवाय अन्य काहीही आढळेल.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() आम्हाला झेडफ्यूचर0 झेड पाहू
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // आम्ही अनेक वेळा peek() करू शकतो, पुनरावृत्ती करणारा पुढे होणार नाही
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // इटररेटर पूर्ण झाल्यानंतर, एक्स 100 एक्स देखील आहे
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// एखाद्या भविष्यवाणीवर आधारित [`स्किप] चे घटक बनविणारे इटरेटर तयार करते.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` वितर्क म्हणून क्लोजर घेते.हे इटरेटरच्या प्रत्येक घटकावर या बंदला कॉल करेल आणि `false` परत करेपर्यंत घटकांकडे दुर्लक्ष करेल.
    ///
    /// `false` परत आल्यानंतर, `skip_while()`'s कार्य समाप्त झाले आणि बाकीचे घटक प्राप्त झाले.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// कारण `skip_while()` ला दिलेली बंदी एक संदर्भ घेते आणि बर्‍याच पुनरावृत्ती पुनरावलोकनांद्वारे पुनरावृत्ती होते, यामुळे संभाव्यत: गोंधळात टाकणारी परिस्थिती उद्भवते, जिथे क्लोजर युक्तिवादाचा प्रकार दुहेरी संदर्भ आहे.
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // दोन * चे गरज!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// प्रारंभिक `false` नंतर थांबणे:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // हे चुकीचे झाले असते, कारण आपल्याकडे आधीपासूनच खोटेपणा आहे, skip_while() यापुढे वापरलेले नाही
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// एक इटरेटर तयार करतो जो एखाद्या भांड्यावर आधारीत घटकांचे उत्पादन देतो.
    ///
    /// `take_while()` वितर्क म्हणून क्लोजर घेते.हे इटरेटरच्या प्रत्येक घटकावर या क्लोजरला कॉल करेल आणि एक्स00 एक्स परत येताना घटक देईल.
    ///
    /// `false` परत आल्यानंतर, `take_while()`'s कार्य समाप्त झाले आणि बाकीच्या घटकांकडे दुर्लक्ष केले जाईल.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// कारण `take_while()` ला बंद केलेला संदर्भ घेते आणि बर्‍याच पुनरावृत्ती पुनरावलोकनांद्वारे पुनरावृत्ती होतात, यामुळे संभाव्यत: गोंधळ घालणारी परिस्थिती उद्भवते, जिथे बंद होण्याचा प्रकार दुहेरी संदर्भ आहे:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // दोन * चे गरज!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// प्रारंभिक `false` नंतर थांबणे:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // आमच्याकडे शून्यापेक्षा कमी घटक आहेत, परंतु आमच्याकडे आधीपासून खोटा असल्याने, take_while() यापुढे वापरला जात नाही
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// कारण `take_while()` मध्ये हे समाविष्ट केले जावे की नाही हे पहाण्यासाठी मूल्य पहाण्याची आवश्यकता आहे, उपभोक्ता पुनरावृत्ती करणारे ते काढले असल्याचे दिसेल:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` यापुढे नाही, कारण पुनरावृत्ती थांबेल की नाही हे पाहण्यासाठी ते सेवन केले गेले होते, परंतु ते पुनरावृत्ती करणारा मध्ये परत ठेवलेले नाही.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// एक इटरेटर तयार करतो जो पूर्वानुमान आणि नकाशेवर आधारित दोन्ही मिळवितो.
    ///
    /// `map_while()` वितर्क म्हणून क्लोजर घेते.
    /// हे इटरेटरच्या प्रत्येक घटकावर या क्लोजरला कॉल करेल आणि एक्स00 एक्स परत येताना घटक देईल.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// येथे हेच उदाहरण आहे, परंतु [`take_while`] आणि [`map`] सह:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// प्रारंभिक [`None`] नंतर थांबणे:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // आमच्याकडे अधिक घटक आहेत जे u32 (4, 5) मध्ये बसू शकतात, परंतु `map_while` ने `-3` साठी `None` परत केला (`predicate` परत `None` परत आला म्हणून) आणि `collect` पहिल्यांदा आलेला `None` थांबला.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// कारण `map_while()` मध्ये हे समाविष्ट केले जावे की नाही हे पहाण्यासाठी मूल्य पहाण्याची आवश्यकता आहे, उपभोक्ता पुनरावृत्ती करणारे ते काढले असल्याचे दिसेल:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` यापुढे नाही, कारण पुनरावृत्ती थांबेल की नाही हे पाहण्यासाठी ते सेवन केले गेले होते, परंतु ते पुनरावृत्ती करणारा मध्ये परत ठेवलेले नाही.
    ///
    /// लक्षात घ्या की [`take_while`] विपरीत हा आयरेटर **नाही** फ्यूज केलेला आहे.
    /// प्रथम एक्स 100 एक्स परत आल्यानंतर हे पुनरावृत्ती करणारा काय परत करेल हे देखील निर्दिष्ट केलेले नाही.
    /// आपल्याला फ्युज इटरेटर आवश्यक असल्यास, एक्स00 एक्स वापरा.
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// इटररेटर तयार करते जे प्रथम `n` घटकांना वगळते.
    ///
    /// त्यांचे सेवन केल्यावर उर्वरित घटक मिळतात.
    /// या पद्धतीने थेट अधिलिखित करण्याऐवजी `nth` पद्धत अधिलिखित करा.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// एक आयटर तयार करतो जो त्याचे प्रथम `n` घटक उत्पन्न करतो.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` हे मर्यादित करण्यासाठी, बर्‍याचदा अनंत पुनरावृत्ती करणार्‍यासह वापरले जाते:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// जर `n` पेक्षा कमी घटक उपलब्ध असतील तर, `take` स्वतःस अंतर्निहित पुनरावृत्ती करणार्‍याच्या आकारापर्यंत मर्यादित करेल:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// एक्सट्रॅक्ससारखेच एक आयटर अ‍ॅडॉप्टर जे अंतर्गत स्थिती ठेवते आणि नवीन इटरटर तयार करते.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` दोन युक्तिवाद घेतातः प्रारंभिक मूल्य जे अंतर्गत स्थितीचे बी बनवते, आणि दोन युक्तिवादासह बंद होते, प्रथम अंतर्गत स्थितीचा परिवर्तनीय संदर्भ आणि दुसरे आयटर घटक.
    ///
    /// बंद केल्याने पुनरावृत्ती दरम्यान राज्य सामायिक करण्यासाठी अंतर्गत स्थितीस सुपूर्त केले जाऊ शकते.
    ///
    /// पुनरावृत्ती केल्यावर, क्लोजर आयटरच्या प्रत्येक घटकास लागू केले जाईल आणि क्लोजरमधील रिटर्न व्हॅल्यू, एक्स एक्स एक्स, इटरेटरद्वारे मिळते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // प्रत्येक पुनरावृत्ती, आम्ही घटकाद्वारे राज्य गुणाकार करू
    ///     *state = *state * x;
    ///
    ///     // तर, आम्ही राज्याकडे दुर्लक्ष करू
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// नकाशाप्रमाणे कार्य करणारे इटरेटर तयार करते परंतु नेस्टेड स्ट्रक्चर सपाट करते.
    ///
    /// एक्स00 एक्स अ‍ॅडॉप्टर खूप उपयुक्त आहे, परंतु जेव्हा क्लोजर युक्तिवाद मूल्ये निर्माण करतो तेव्हाच.
    /// त्याऐवजी जर ते आयटररेटर तयार करत असेल तर त्यासंदर्भात अतिरिक्त थर असेल.
    /// `flat_map()` हा अतिरिक्त थर स्वतःच काढेल.
    ///
    /// आपण `flat_map(f)` बद्दल [`map`] पिंग, आणि नंतर [` सपाट] `map(f).flatten()` प्रमाणे अर्थ असा समजू शकता.
    ///
    /// एक्स00 एक्सबद्दल विचार करण्याचा आणखी एक मार्गः [`map`] चे बंद होण्यामुळे प्रत्येक घटकासाठी एक आयटम मिळतो आणि `flat_map()`'s क्लोजर प्रत्येक घटकासाठी इटरेटर परत करतो.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() आयटर पाठवते
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// नेटर स्ट्रक्चर सपाट करणारा इटरेटर तयार करते.
    ///
    /// जेव्हा आपल्याकडे इटरेटरची पुनरावृत्ती करणारी वस्तू किंवा पुनरावृत्त्यांमध्ये बदलल्या जाऊ शकणार्‍या गोष्टींचे इटररेटर असेल तेव्हा आपल्याला हे आवश्यक आहे जेव्हा आपण एक स्तर दर्शक दूर करू इच्छित असाल.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// मॅपिंग आणि नंतर सपाट:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() आयटर पाठवते
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// आपण हे [`flat_map()`] च्या संदर्भात देखील पुन्हा लिहू शकता, जे या प्रकरणात हेतू अधिक स्पष्टपणे सांगते त्यापेक्षा श्रेयस्कर आहेः
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() आयटर पाठवते
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// सपाट होणे एकाच वेळी घरटीचे एक स्तर काढून टाकते:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// येथे आपण पाहतो की `flatten()` एक "deep" सपाट करत नाही.
    /// त्याऐवजी फक्त एक स्तर घरटे काढले आहेत.म्हणजेच आपण त्रिमितीय अ‍ॅरे `flatten()` केल्यास त्याचा परिणाम द्विमितीय होईल आणि एक-आयामी होणार नाही.
    /// एक-आयामी रचना मिळविण्यासाठी, आपल्याला पुन्हा `flatten()` करावे लागेल.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// आयटररेटर तयार करते जो पहिल्या [`None`] नंतर समाप्त होतो.
    ///
    /// इटररेटरने एक्स 100 एक्स परत केल्यानंतर, झेडफ्यूचर 0 झेड कॉल पुन्हा एक्स01 एक्स येऊ शकतात किंवा नाही.
    /// `fuse()` आयटरला रुपांतरित करते, हे सुनिश्चित करून की [`None`] दिल्यानंतर तो नेहमीच X01 एक्स परत करेल.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// // एक पुनरावृत्ती करणारा जो काही आणि कोणा मध्येही बदलत नाही
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // जर तो समतुल्य असेल तर, एक्स00 एक्स, अन्यथा काहीही नाही
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // आपण आपला पुनरावृत्ती करणारा मागे-मागे जाताना पाहतो
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // तथापि, एकदा आम्ही ते फ्यूज केले ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // हे प्रथमच नंतर नेहमीच `None` परत करेल.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// व्हॅल्यू पुढे देऊन, इटरेटरच्या प्रत्येक घटकासह काहीतरी करते.
    ///
    /// इटरेटर वापरताना आपण बर्‍याचदा एकत्रित साखळी बनवाल.
    /// अशा कोडवर काम करत असताना आपल्याला कदाचित पाईपलाईनमध्ये विविध भागांमध्ये काय चालले आहे ते पहावे लागेल.ते करण्यासाठी, `inspect()` वर कॉल घाला.
    ///
    /// आपल्या अंतिम कोडमध्ये अस्तित्वापेक्षा डिबगिंग साधन म्हणून `inspect()` वापरणे अधिक सामान्य आहे, परंतु त्रुटी टाकून देण्यापूर्वी लॉग लॉग करणे आवश्यक असताना अनुप्रयोगांना विशिष्ट परिस्थितीत हे उपयुक्त वाटेल.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // हा पुनरावृत्ती करणारा क्रम जटिल आहे.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // काय होत आहे ते तपासण्यासाठी काही एक्स 100 एक्स कॉल जोडा
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// हे मुद्रित करेल:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// त्रुटी काढून टाकण्यापूर्वी लॉगिंग त्रुटी:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// हे मुद्रित करेल:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// आयटर घेण्याऐवजी ते घेते.
    ///
    /// मूळ पुनरावृत्ती करणार्‍याची अद्याप मालकी कायम ठेवताना इटररेटर अ‍ॅडॉप्टर्स लागू करण्यास हे उपयुक्त आहे.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // जर आम्ही पुन्हा iter वापरण्याचा प्रयत्न केला तर ते कार्य करणार नाही.
    /// // खालील ओळ "त्रुटी देते: हलविलेल्या मूल्याचा वापर: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // पुन्हा प्रयत्न करूया
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // त्याऐवजी आम्ही .by_ref() मध्ये समाविष्ट करतो
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // आता हे ठीक आहे:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// आयटरला संकलनामध्ये रुपांतरित करते.
    ///
    /// `collect()` पुनरावृत्ती करण्यायोग्य काहीही घेऊ शकते आणि त्यास संबद्ध संग्रहात रुपांतर करू शकते.
    /// विविध संदर्भांमध्ये वापरल्या जाणार्‍या प्रमाणित लायब्ररीत ही सर्वात शक्तिशाली पद्धत आहे.
    ///
    /// `collect()` चा सर्वात मूलभूत नमुना म्हणजे एका संग्रहात दुसर्यामध्ये रुपांतर करणे.
    /// आपण संग्रह घेता, त्यावर [`iter`] वर कॉल करा, अनेक बदल करा आणि शेवटी `collect()`.
    ///
    /// `collect()` ठराविक संग्रह नसलेल्या प्रकारची उदाहरणे देखील तयार करु शकतात.
    /// उदाहरणार्थ, एक एक्स ०1 एक्स [`चार्ट`] चे पासून बनविला जाऊ शकतो आणि एक्स ० एक्स एक्स आयटमचे इटररेटर एक्स १००० मध्ये संग्रहित केले जाऊ शकते.
    ///
    /// अधिकसाठी खालील उदाहरणे पहा.
    ///
    /// कारण `collect()` सामान्य आहे, यामुळे प्रकारासंदर्भात समस्या उद्भवू शकतात.
    /// अशाच प्रकारे, `collect()` ही काही वेळा एक वाक्य आहे जी आपणास प्रेमपूर्वक 'turbofish' म्हणून ओळखले जाते: `::<>`.
    /// आपण कोणत्या संकलनात संकलित करण्याचा प्रयत्न करीत आहात हे अनुमान अल्गोरिदमला हे विशिष्टपणे समजण्यास मदत करते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// लक्षात घ्या की आम्हाला डाव्या बाजूला `: Vec<i32>` आवश्यक आहे.कारण आपण त्याऐवजी [`VecDeque<T>`] मध्ये संग्रहित करू शकतो:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// `doubled` भाष्य करण्याऐवजी 'turbofish' वापरणे:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// `collect()` केवळ आपण ज्यामध्ये संकलित करीत आहात त्याबद्दल काळजी घेत आहे, परंतु तरीही आपण टर्बोफिशसह अर्धवट प्रकारचा इशारा, `_` वापरू शकता:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// [`String`] करण्यासाठी `collect()` वापरणे:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// आपल्याकडे [`निकालाची यादी असल्यास<T, E>`][`परिणाम`] चे, आपण त्यापैकी कोणतेही अयशस्वी झाले की नाही हे पाहण्यासाठी आपण `collect()` वापरू शकता:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // प्रथम एरर देतो
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // आम्हाला उत्तरांची यादी देते
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// आयटर घेते, त्यातून दोन संग्रह तयार करते.
    ///
    /// `partition()` ला दिलेली प्रीडिकेट `true` किंवा `false` परत मिळवू शकते.
    /// `partition()` एक जोडी मिळवते, ज्या सर्व घटकांसाठी त्याने X01 एक्स परत केले आणि ते सर्व घटक ज्यासाठी त्याने एक्स 100 एक्स परत केले.
    ///
    ///
    /// [`is_partitioned()`] आणि [`partition_in_place()`] देखील पहा.
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// दिलेल्या पूर्वानुमानुसार या इटरेटरच्या *जागेच्या* घटकांना पुनर्क्रमित करते, जसे की `true` परत येणारे सर्व `false` परत येणा all्या सर्व अगोदर.
    ///
    /// आढळलेल्या `true` घटकांची संख्या मिळवते.
    ///
    /// विभाजित आयटमची संबंधित ऑर्डर राखली जात नाही.
    ///
    /// [`is_partitioned()`] आणि [`partition()`] देखील पहा.
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // संध्याकाळ आणि शक्यता यांच्यात जागी विभाजन
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: आम्ही संख्या ओसंडून वाहण्याची चिंता करावी?पेक्षा अधिक असणे हा एकमेव मार्ग आहे
        // `usize::MAX` परिवर्तनीय संदर्भ ZSTs सह आहेत, जे विभाजनास उपयुक्त नाहीत ...

        // हे बंद करणे "factory" कार्ये एक्स 100 एक्समधील औदार्य टाळण्यासाठी अस्तित्वात आहेत.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // वारंवार प्रथम `false` शोधा आणि शेवटच्या `true` सह स्वॅप करा.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// या पुनरावृत्ती करणार्‍याचे घटक दिलेल्या पूर्वानुमानानुसार विभाजित केले गेले आहेत का ते तपासते, जसे की `true` परत येणारे सर्व `false` परत येणा all्या सर्व अगोदर आहेत.
    ///
    ///
    /// [`partition()`] आणि [`partition_in_place()`] देखील पहा.
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // एकतर सर्व आयटम `true` चाचणी घेतात, किंवा पहिला खंड `false` वर थांबतो आणि आम्ही तपासतो की यापुढे आणखी `true` आयटम नाहीत.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// एक पुनरावृत्ती करण्याची पद्धत जी एक फंक्शन यशस्वीरित्या परत येते तोपर्यंत लागू करते, एकल, अंतिम मूल्य तयार करते.
    ///
    /// `try_fold()` दोन वितर्क घेतात: प्रारंभिक मूल्य आणि दोन वितर्कांसह क्लोजरः एक एक्स 100 एक्स आणि एक घटक.
    /// क्लोजर एकतर यशस्वीरित्या परत येतो, पुढच्या पुनरावृत्तीसाठी संचयकाचे मूल्य असले पाहिजे किंवा ते अयशस्वी होते, एरर व्हॅल्यूसह जे परत कॉलरवर त्वरित परत प्रचारित केले जाते (short-circuiting).
    ///
    ///
    /// प्रारंभिक मूल्य संचयकाचे प्रथम कॉलवर असलेले मूल्य आहे.क्लोजर लागू केल्यास इटरेटरच्या प्रत्येक घटकाविरूद्ध यश आले, तर एक्स00 एक्स अंतिम संचयनकर्ताला यश म्हणून परत करते.
    ///
    /// जेव्हा आपल्याकडे एखाद्या वस्तूचा संग्रह असतो तेव्हा फोल्डिंग उपयुक्त ठरते आणि त्यामधून एक मूल्य तयार करू इच्छितो.
    ///
    /// # अंमलबजावणी करणार्‍यांना नोट
    ///
    /// इतर अनेक (forward) पद्धतींमध्ये या बाबतीत डीफॉल्ट अंमलबजावणी आहेत, म्हणूनच हे डीफॉल्ट `for` लूप अंमलबजावणीपेक्षा काही चांगले करू शकत असल्यास हे स्पष्टपणे अंमलात आणण्याचा प्रयत्न करा.
    ///
    /// विशेषतः, ज्या कॉलनी हा इटरेटर तयार केला आहे त्या अंतर्गत भागांवर हा कॉल एक्स 100 एक्स करण्याचा प्रयत्न करा.
    /// जर एकाधिक कॉल आवश्यक असतील तर `?` ऑपरेटर संचयक मूल्यासह साखळीसाठी सोयीस्कर असेल, परंतु लवकर परत येण्यापूर्वी आवश्यक असणा any्या कोणत्याही हल्लेखोरांविषयी सावधगिरी बाळगा.
    /// ही एक `&mut self` पद्धत आहे, म्हणून येथे त्रुटी मारल्यानंतर पुनरावृत्ती पुन्हा सुरू करणे आवश्यक आहे.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // अ‍ॅरेच्या सर्व घटकांची चेकची बेरीज
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // 100 घटक जोडताना ही बेरीज ओव्हरफ्लो होते
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // कारण हे अल्प-प्रसारित आहे, उर्वरित घटक अद्याप इटरेटरद्वारे उपलब्ध आहेत.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// पुनरावृत्ती करणार्‍याची पद्धत जी पुनरावृत्ती करणा in्या प्रत्येक वस्तूवर फॉलिबल फंक्शन लागू करते, पहिल्या त्रुटीवर थांबते आणि ती त्रुटी परत करते.
    ///
    ///
    /// याचा अर्थ [`for_each()`] चे मोडकळीचा फॉर्म किंवा [`try_fold()`] ची स्टेटलेस आवृत्ती म्हणून विचार केला जाऊ शकतो.
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // हे अल्प-प्रसारित केले गेले आहे, जेणेकरून उर्वरित आयटम अद्याप इटरेटरमध्ये आहेत:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// अंतिम परिणाम परत करून ऑपरेशन लागू करून प्रत्येक घटकास संचयीकामध्ये फोल्ड करतो.
    ///
    /// `fold()` दोन वितर्क घेतात: प्रारंभिक मूल्य आणि दोन वितर्कांसह क्लोजरः एक एक्स 100 एक्स आणि एक घटक.
    /// क्लोजर संचयकाला पुढील पुनरावृत्तीसाठी असलेले मूल्य मिळवते.
    ///
    /// प्रारंभिक मूल्य संचयकाचे प्रथम कॉलवर असलेले मूल्य आहे.
    ///
    /// हे क्लोजर इटरेटरच्या प्रत्येक घटकावर लागू केल्यानंतर, एक्स00 एक्स जमा करणारा परत करतो.
    ///
    /// या ऑपरेशनला कधीकधी 'reduce' किंवा 'inject' म्हणतात.
    ///
    /// जेव्हा आपल्याकडे एखाद्या वस्तूचा संग्रह असतो तेव्हा फोल्डिंग उपयुक्त ठरते आणि त्यामधून एक मूल्य तयार करू इच्छितो.
    ///
    /// Note: `fold()` आणि अशाच पद्धती ज्या संपूर्ण इटरेटरला ओलांडतात, अनंत पुनरावृत्ती करणार्‍यांसाठी जरी traits वर समाप्त होऊ शकत नाहीत ज्यासाठी परिपूर्ण कालावधीमध्ये निकाल निश्चित केला जाऊ शकतो.
    ///
    /// Note: एक्झिक्युलेटर प्रकार आणि आयटम प्रकार समान असल्यास [`reduce()`] प्रारंभिक मूल्य म्हणून प्रथम घटकाचा वापर करण्यासाठी वापरला जाऊ शकतो.
    ///
    /// # अंमलबजावणी करणार्‍यांना नोट
    ///
    /// इतर अनेक (forward) पद्धतींमध्ये या बाबतीत डीफॉल्ट अंमलबजावणी आहेत, म्हणूनच हे डीफॉल्ट `for` लूप अंमलबजावणीपेक्षा काही चांगले करू शकत असल्यास हे स्पष्टपणे अंमलात आणण्याचा प्रयत्न करा.
    ///
    ///
    /// विशेषतः, ज्या कॉलनी हा इटरेटर तयार केला आहे त्या अंतर्गत भागांवर हा कॉल एक्स 100 एक्स करण्याचा प्रयत्न करा.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // अ‍ॅरेच्या सर्व घटकांची बेरीज
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// चला पुनरावृत्तीच्या प्रत्येक चरणातून येथे जाऊया:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// आणि म्हणूनच आमचा अंतिम निकाल, `6`.
    ///
    /// परीणाम तयार करण्यासाठी गोष्टींच्या सूचीसह एक्स ०१ एक्स लूप वापरण्यासाठी इट्यूटरचा जास्त वापर न केलेले लोक सामान्य आहेत.त्या `fold()`s मध्ये बदलू शकतात:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // लूपसाठी:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // ते सारखेच आहेत
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// वारंवार ऑपरेशन लागू करून घटकांना एकास कमी करते.
    ///
    /// जर इटररेटर रिकामी असेल तर, एक्स00 एक्स परत करेल;अन्यथा, घट घट परत करते.
    ///
    /// कमीतकमी एका घटकासह पुनरावृत्ती करणार्‍यांसाठी, हे पुनरावृत्तीच्या पहिल्या घटकासह एक्स 100 एक्ससारखे आहे प्रारंभिक मूल्यासारखे, त्यानंतरच्या प्रत्येक घटकास त्यामध्ये दुमडणे.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// जास्तीत जास्त मूल्य शोधा:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// आयटरचा प्रत्येक घटक पूर्वानुमानाशी जुळत असल्यास चाचणी करतो.
    ///
    /// `all()` `true` किंवा `false` परत करणारा एक बंद घेते.हे क्लोजर इटरेटरच्या प्रत्येक घटकाला लागू होते आणि जर ते सर्वजण X02 एक्स परत करतात, तर ते `all()` देखील करते.
    /// जर त्यांच्यापैकी कोणी `false` परत करत असेल तर ते `false` परत करेल.
    ///
    /// `all()` शॉर्ट सर्किटिंग आहे;दुसर्‍या शब्दांत, हे `false` सापडताच त्यावर प्रक्रिया करणे थांबवेल, हे लक्षात घेतल्या की दुसरे काय झाले तरी याचा परिणाम देखील `false` होईल.
    ///
    ///
    /// रिक्त पुनरावृत्ती करणारा `true` परत करतो.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// पहिल्या `false` वर थांबणे:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // आम्ही अद्याप `iter` वापरू शकतो, कारण तेथे अधिक घटक आहेत.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// आयटरचा कोणताही घटक एखाद्या पूर्वानुमानाशी जुळत असल्यास तपासणी करतो.
    ///
    /// `any()` `true` किंवा `false` परत करणारा एक बंद घेते.हे क्लोजर इटरेटरच्या प्रत्येक घटकास लागू करते आणि जर त्यापैकी कोणी एक्स0 2 एक्स परत केले तर ते एक्स 100 एक्स देखील करते.
    /// जर ते सर्वजण X01 एक्स परत करतात, तर ते `false` परत करते.
    ///
    /// `any()` शॉर्ट सर्किटिंग आहे;दुसर्‍या शब्दांत, हे `true` सापडताच त्यावर प्रक्रिया करणे थांबवेल, हे लक्षात घेतल्या की दुसरे काय झाले तरी याचा परिणाम देखील `true` होईल.
    ///
    ///
    /// रिक्त पुनरावृत्ती करणारा `false` परत करतो.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// पहिल्या `true` वर थांबणे:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // आम्ही अद्याप `iter` वापरू शकतो, कारण तेथे अधिक घटक आहेत.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// एखाद्या प्रीडेटवर समाधानी असणार्‍या इटरेटरच्या घटकासाठी शोध.
    ///
    /// `find()` `true` किंवा `false` परत करणारी बंदी घेते.
    /// हे क्लोजर इटरेटरच्या प्रत्येक घटकास लागू करते आणि जर त्यापैकी कोणी एक्स01 एक्स परत केले तर `find()` एक्स 100 एक्स परत करते.
    /// जर ते सर्वजण X01 एक्स परत करतात, तर ते [`None`] परत करते.
    ///
    /// `find()` शॉर्ट सर्किटिंग आहे;दुसर्‍या शब्दांत, क्लोजर `true` परत होताच प्रक्रिया थांबेल.
    ///
    /// कारण `find()` संदर्भ घेते आणि बर्‍याच पुनरावृत्ती पुनरावलोकनांद्वारे पुनरावृत्ती होतात, यामुळे संभाव्यत: गोंधळात टाकणारी परिस्थिती उद्भवते जिथे युक्तिवाद दुहेरी संदर्भ आहे.
    ///
    /// आपण हा प्रभाव `&&x` सह खालील उदाहरणांमध्ये पाहू शकता.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// पहिल्या `true` वर थांबणे:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // आम्ही अद्याप `iter` वापरू शकतो, कारण तेथे अधिक घटक आहेत.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// लक्षात घ्या की `iter.find(f)` हे `iter.filter(f).next()` च्या समतुल्य आहे.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// आयटरच्या घटकांना फंक्शन लागू करते आणि प्रथम नॉन-नॉन रिझल्ट मिळवते.
    ///
    ///
    /// `iter.find_map(f)` हे `iter.filter_map(f).next()` च्या समतुल्य आहे.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// आयटरच्या घटकांना फंक्शन लागू करते आणि पहिला खरा परिणाम किंवा पहिली त्रुटी परत करते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// आयटरमध्ये घटक शोधतो, त्याची अनुक्रमणिका परत करतो.
    ///
    /// `position()` `true` किंवा `false` परत करणारी बंदी घेते.
    /// हे क्लोजर इटरेटरच्या प्रत्येक घटकाला लागू करते आणि जर त्यातील एखादा एक्स ०१ एक्स परत करतो तर एक्स ०२ एक्स एक्स १० एक्स परत करतो.
    /// जर त्या सर्वांनी `false` परत केले तर ते [`None`] परत करते.
    ///
    /// `position()` शॉर्ट सर्किटिंग आहे;दुसर्‍या शब्दांत, हे `true` सापडताच ते प्रक्रिया करणे थांबवेल.
    ///
    /// # ओव्हरफ्लो वर्तन
    ///
    /// पध्दती ओव्हरफ्लोपासून संरक्षण देत नाही, म्हणून जर तेथे एक्स-एक्सएक्सएक्सपेक्षा जास्त न जुळणारे घटक असतील तर ते एकतर चुकीचे परिणाम किंवा झेडस्पॅनिक्स ० झेड उत्पन्न करते.
    ///
    /// डीबग असेरेन्स सक्षम केले असल्यास, झेडस्पॅनिक 0 झेडची हमी दिली जाते.
    ///
    /// # Panics
    ///
    /// जर इटरटरमध्ये `usize::MAX` पेक्षा अधिक न जुळणारे घटक असतील तर हे कार्य panic असू शकते.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// पहिल्या `true` वर थांबणे:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // आम्ही अद्याप `iter` वापरू शकतो, कारण तेथे अधिक घटक आहेत.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // परतावा निर्देशांक पुनरावृत्ती होणार्‍या अवस्थेवर अवलंबून असतो
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// उजवीकडून इटरेटरमध्ये घटकाचा शोध घेतो, त्याची अनुक्रमणिका परत करतो.
    ///
    /// `rposition()` `true` किंवा `false` परत करणारी बंदी घेते.
    /// हे क्लोजर शेवटपासून सुरू होणार्‍या इटरेटरच्या प्रत्येक घटकाला हे क्लोजर लागू करते आणि जर त्यातील एखादा एक्स ०१ एक्स परत करतो तर एक्स ०२ एक्स एक्स १० एक्स परत करतो.
    ///
    /// जर त्या सर्वांनी `false` परत केले तर ते [`None`] परत करते.
    ///
    /// `rposition()` शॉर्ट सर्किटिंग आहे;दुसर्‍या शब्दांत, हे `true` सापडताच ते प्रक्रिया करणे थांबवेल.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// पहिल्या `true` वर थांबणे:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // आम्ही अद्याप `iter` वापरू शकतो, कारण तेथे अधिक घटक आहेत.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // येथे ओव्हरफ्लो तपासणीची आवश्यकता नाही, कारण एक्स01 एक्स असे सूचित करते की घटकांची संख्या `usize` मध्ये बसते.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// आयटरचा कमाल घटक मिळवते.
    ///
    /// जर अनेक घटक तितकेच जास्तीत जास्त असतील तर शेवटचा घटक परत केला जाईल.
    /// जर इटररेटर रिकामी असेल तर, [`None`] परत येईल.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// आयटरचा किमान घटक मिळवते.
    ///
    /// जर अनेक घटक तितकेच कमीतकमी असतील तर प्रथम घटक परत केला जाईल.
    /// जर इटररेटर रिकामी असेल तर, [`None`] परत येईल.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// निर्दिष्ट फंक्शनमधून जास्तीत जास्त मूल्य देणारा घटक परत करतो.
    ///
    ///
    /// जर अनेक घटक तितकेच जास्तीत जास्त असतील तर शेवटचा घटक परत केला जाईल.
    /// जर इटररेटर रिकामी असेल तर, [`None`] परत येईल.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// निर्दिष्ट तुलनेच्या कार्यासाठी अधिकतम मूल्य देणारा घटक परत करतो.
    ///
    ///
    /// जर अनेक घटक तितकेच जास्तीत जास्त असतील तर शेवटचा घटक परत केला जाईल.
    /// जर इटररेटर रिकामी असेल तर, [`None`] परत येईल.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// निर्दिष्ट फंक्शनमधून किमान मूल्य देणारा घटक परत करतो.
    ///
    ///
    /// जर अनेक घटक तितकेच कमीतकमी असतील तर प्रथम घटक परत केला जाईल.
    /// जर इटररेटर रिकामी असेल तर, [`None`] परत येईल.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// निर्दिष्ट तुलनेच्या कार्यासाठी कमीतकमी मूल्य देणारा घटक परत करतो.
    ///
    ///
    /// जर अनेक घटक तितकेच कमीतकमी असतील तर प्रथम घटक परत केला जाईल.
    /// जर इटररेटर रिकामी असेल तर, [`None`] परत येईल.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// आयटरची दिशा उलट करते.
    ///
    /// सहसा, पुनरावृत्ती करणारे डावीकडून उजवीकडे पुनरावृत्ती करतात.
    /// `rev()` वापरल्यानंतर, एक आयरेटर त्याऐवजी उजवीकडून डावीकडे पुनरावृत्ती करेल.
    ///
    /// हे केवळ तेव्हाच शक्य आहे जर आयटरचा शेवट असेल तर, `rev()` केवळ [`DoubleEidedIterator`] s वर कार्य करते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// जोड्यांच्या इटररेटरला कंटेनरच्या जोडीमध्ये रुपांतरीत करते.
    ///
    /// `unzip()` जोड्यांचे संपूर्ण इटरेटर वापरते, ज्यामुळे दोन संग्रह तयार होतात: एक जोडीच्या डाव्या घटकांमधून आणि एक उजवा घटकांचा.
    ///
    ///
    /// हे कार्य काही प्रमाणात [`zip`] च्या विरूद्ध आहे.
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// एक आयटर तयार करतो जो त्याच्या सर्व घटकांची कॉपी करतो.
    ///
    /// जेव्हा आपल्याकडे एक्स ०१ एक्सपेक्षा अधिक पुनरावृत्ती करणारे असेल तेव्हा हे उपयुक्त आहे, परंतु आपल्याला एक्स १००० एक्सपेक्षा अधिक पुनरावृत्ती करणार्‍याची आवश्यकता आहे.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // कॉपी केलेले .map(|&x| x) प्रमाणेच आहे
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// एक आयटर तयार करतो ज्याने [`क्लोन] चे सर्व घटक तयार केले.
    ///
    /// जेव्हा आपल्याकडे एक्स ०१ एक्सपेक्षा अधिक पुनरावृत्ती करणारे असेल तेव्हा हे उपयुक्त आहे, परंतु आपल्याला एक्स १००० एक्सपेक्षा अधिक पुनरावृत्ती करणार्‍याची आवश्यकता आहे.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // पूर्णांक पूर्णांक म्हणून, .map(|&x| x) प्रमाणेच आहे
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// पुनरावृत्ती करणार्‍याची निरंतर पुनरावृत्ती होते.
    ///
    /// [`None`] वर थांबण्याऐवजी, पुनरावृत्ती सुरूवातीऐवजी पुन्हा सुरू होईल.पुन्हा पुनरावृत्ती केल्यानंतर, तो पुन्हा सुरूवातीस सुरू होईल.आणि पुन्हा.
    /// आणि पुन्हा.
    /// Forever.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// आयटरच्या घटकांची बेरीज करतो.
    ///
    /// प्रत्येक घटक घेते, त्यांना एकत्र जोडते आणि निकाल देतो.
    ///
    /// रिक्त पुनरावृत्ती करणार्‍याने प्रकाराचे शून्य मूल्य मिळवले.
    ///
    /// # Panics
    ///
    /// जेव्हा एक्स 100 एक्स वर कॉल करणे आणि आदिम पूर्णांक प्रकार परत केला जात असेल, तर गणना ओव्हरफ्लो आणि डीबग एसेरेन्स सक्षम केल्यास ही पद्धत panic करेल.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// सर्व घटकांना गुणाकार करून संपूर्ण पुनरावृत्ती (आयटर) वर Iterates
    ///
    /// रिक्त पुनरावृत्ती करणार्‍याने प्रकाराचे एक मूल्य दिले.
    ///
    /// # Panics
    ///
    /// जेव्हा एक्स 100 एक्स वर कॉल करणे आणि आदिम पूर्णांक प्रकार परत केला जात असेल, तर गणना ओव्हरफ्लो आणि डीबग एसेरेन्स सक्षम केल्यास पद्धत झेडस्पॅनिक 0 झेड करेल.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) या [`Iterator`] चे घटक दुसर्‍याच्या घटकांशी तुलना करते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) या [`Iterator`] च्या घटकांची तुलना आणि तुलना केलेल्या कार्याशी संबंधित इतरांशी तुलना करते.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) या [`Iterator`] चे घटक दुसर्‍याच्या घटकांशी तुलना करते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) या [`Iterator`] च्या घटकांची तुलना आणि तुलना केलेल्या कार्याशी संबंधित इतरांशी तुलना करते.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// या [`Iterator`] चे घटक दुसर्‍याच्या समान असल्यास ते निर्धारित करते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// निर्दिष्ट केलेल्या समानता फंक्शनच्या संदर्भात या [`Iterator`] चे घटक दुसर्‍याच्या समतुल्य असल्यास ते निर्धारित करते.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// या [`Iterator`] चे घटक इतरांपेक्षा असमान असल्यास हे निर्धारित करते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// या [`Iterator`] चे घटक दुसर्‍याच्या तुलनेत [lexicographically](Ord#lexicographical-comparison) कमी असल्यास निर्धारित करतात.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// या [`Iterator`] चे घटक [lexicographically](Ord#lexicographical-comparison) कमी किंवा दुसर्‍याच्या समान असल्यास ते निर्धारित करते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// या [`Iterator`] चे घटक इतरांपेक्षा [lexicographically](Ord#lexicographical-comparison) मोठे असल्यास निर्धारित करतात.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// या [`Iterator`] चे घटक इतरांपेक्षा [lexicographically](Ord#lexicographical-comparison) मोठे किंवा समान असल्यास निर्धारित करते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// या पुनरावृत्ती करणार्‍याच्या घटकांची क्रमवारी लावली आहे का ते तपासते.
    ///
    /// म्हणजेच, प्रत्येक घटक `a` आणि त्यातील खालील घटक `b` साठी, `a <= b` असणे आवश्यक आहे.जर इटरटर शून्य किंवा एक घटक मिळवितो, तर एक्स 0 एक्स परत येईल.
    ///
    /// लक्षात घ्या की `Self::Item` केवळ `PartialOrd` असल्यास, परंतु X01 एक्स नसल्यास, वरील परिभाषा असे सूचित करते की कोणतेही दोन सलग आयटम तुलना न केल्यास हे कार्य `false` परत करते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// या इटरेटरचे घटक दिलेल्या कंपॅरेटर फंक्शनचा वापर करून क्रमवारी लावलेले आहेत का ते तपासेल.
    ///
    /// `PartialOrd::partial_cmp` वापरण्याऐवजी हे कार्य दोन घटकांची क्रमवारी निश्चित करण्यासाठी दिलेल्या `compare` फंक्शनचा वापर करते.
    /// त्या व्यतिरिक्त, हे [`is_sorted`] च्या समतुल्य आहे;अधिक माहितीसाठी त्याचे दस्तऐवजीकरण पहा.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// या पुनरावृत्ती करणार्‍याचे घटक दिलेल्या की एक्सट्रक्शन फंक्शनचा वापर करून क्रमवारी लावलेले आहेत का ते तपासेल.
    ///
    /// आयटरच्या घटकांची थेट तुलना करण्याऐवजी हे फंक्शन एक्स 00 एक्स द्वारे निश्चित केल्याप्रमाणे घटकांच्या किल्लीची तुलना करते.
    /// त्या व्यतिरिक्त, हे [`is_sorted`] च्या समतुल्य आहे;अधिक माहितीसाठी त्याचे दस्तऐवजीकरण पहा.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// [TrustedRandomAccess] पहा
    // मेथड रिझोल्यूशनमध्ये नाव टक्कर टाळणे हे असामान्य नाव आहे #76479 पहा.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}