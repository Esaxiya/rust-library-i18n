/// एक पुनरावृत्ती करणारा ज्यास त्याची अचूक लांबी माहित असते.
///
/// बर्‍याच [te Iterator`] ला माहित नाही की ते किती वेळा पुनरावृत्ती करतील, परंतु काही जण करतात.
/// एखाद्या पुनरावृत्ती करणार्‍यास किती वेळा हे पुनरावृत्ती होऊ शकते हे माहित असल्यास त्या माहितीमध्ये प्रवेश प्रदान करणे उपयुक्त ठरू शकते.
/// उदाहरणार्थ, जर तुम्हाला मागे वळायचे असेल तर शेवट म्हणजे कोठे आहे हे जाणून घेणे चांगले आहे.
///
/// `ExactSizeIterator` लागू करताना, आपण देखील [`Iterator`] अंमलात आणणे आवश्यक आहे.
/// असे करताना, एक्स 100 एक्स *ची अंमलबजावणी* पुनरावृत्ती करणाराचा अचूक आकार परत करणे आवश्यक आहे.
///
/// [`len`] पद्धतीत डीफॉल्ट अंमलबजावणी असते, म्हणून आपण सहसा ते अंमलात आणू नये.
/// तथापि, आपण डीफॉल्टपेक्षा अधिक कार्यक्षम अंमलबजावणी प्रदान करण्यात सक्षम होऊ शकता, म्हणून या प्रकरणात त्यास अधिलिखित केल्याने अर्थ प्राप्त होतो.
///
///
/// लक्षात घ्या की हे झेडट्रायट0 झेड एक सुरक्षित झेडट्रायट0 झेड आहे आणि जसे की *नाही* आणि * परत केलेली लांबी योग्य आहे याची हमी देत नाही.
/// याचा अर्थ असा की `unsafe` कोड ** **[`Iterator::size_hint`] च्या शुद्धतेवर अवलंबून राहू नये.
/// अस्थिर आणि असुरक्षित [`TrustedLen`](super::marker::TrustedLen) trait ही अतिरिक्त हमी देते.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// मूलभूत वापर:
///
/// ```
/// // मर्यादित श्रेणीत किती वेळा पुनरावृत्ती होईल हे माहित असते
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// [module-level docs] मध्ये आम्ही एक [`Iterator`] लागू केला, `Counter`.
/// त्यासाठी `ExactSizeIterator` ची अंमलबजावणी करू:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // उर्वरित पुनरावृत्तीची संख्या आपण सहज गणना करू शकतो.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // आणि आता आम्ही ते वापरू शकतो!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// आयटरची अचूक लांबी मिळवते.
    ///
    /// कार्यान्वयन हे सुनिश्चित करते की आयटररेटर [`None`] परत येण्यापूर्वी [`Some(T)`] मूल्यापेक्षा अधिक वेळा `len()` परत करेल.
    ///
    /// या पद्धतीत डीफॉल्ट अंमलबजावणी आहे, म्हणून आपण सामान्यत: ते थेट अंमलात आणू नये.
    /// तथापि, आपण अधिक कार्यक्षम अंमलबजावणी प्रदान करू शकत असल्यास, आपण हे करू शकता.
    /// उदाहरणार्थ [trait-level] दस्तऐवज पहा.
    ///
    /// या फंक्शनची [`Iterator::size_hint`] फंक्शन प्रमाणेच सुरक्षा हमी आहे.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// // मर्यादित श्रेणीत किती वेळा पुनरावृत्ती होईल हे माहित असते
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: हे प्रतिपादन अत्यधिक बचावात्मक आहे, परंतु ते आक्रमणकर्त्याची तपासणी करते
        // trait द्वारे हमी दिलेली आहे.
        // जर हे trait rust-अंतर्गत असते तर आम्ही डीबग_असर्ट वापरू शकतो ;;assert_eq!सर्व Rust वापरकर्त्याची अंमलबजावणी देखील तपासेल.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// आयटर रिक्त असल्यास `true` मिळवते.
    ///
    /// या पद्धतीची एक्स 100 एक्स वापरुन डीफॉल्ट अंमलबजावणी आहे, म्हणून आपल्याला ते स्वतः अंमलात आणण्याची आवश्यकता नाही.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}