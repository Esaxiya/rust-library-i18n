/// [`Iterator`] चे रूपांतरण.
///
/// एका प्रकारासाठी `FromIterator` ची अंमलबजावणी करून, आपण ते परिभाषित करा की ते इटररेटरकडून कसे तयार केले जाईल.
/// हे अशा प्रकारच्या प्रकारांमध्ये सामान्य आहे जे कोणत्या प्रकारचे संग्रह वर्णन करतात.
///
/// [`FromIterator::from_iter()`] हे क्वचितच स्पष्टपणे म्हटले जाते आणि त्याऐवजी ते [`Iterator::collect()`] पद्धतीने वापरले जाते.
///
/// अधिक उदाहरणांसाठी [`Iterator::collect()`]'s दस्तऐवजीकरण पहा.
///
/// हे देखील पहा: [`IntoIterator`].
///
/// # Examples
///
/// मूलभूत वापर:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// `FromIterator` सुस्पष्टपणे वापरण्यासाठी [`Iterator::collect()`] वापरणे:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// आपल्या प्रकारासाठी `FromIterator` ची अंमलबजावणी करीत आहे:
///
/// ```
/// use std::iter::FromIterator;
///
/// // एक नमुना संग्रह, तो व्हेक वर फक्त एक आवरण आहे<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // चला त्यास काही पद्धती देऊ या म्हणजे आम्ही त्यात एक तयार करू आणि त्यात गोष्टी जोडू.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // आणि आम्ही fromIterator लागू करू
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // आता आपण नवीन इरेटर बनवू शकतो ...
/// let iter = (0..5).into_iter();
///
/// // ... आणि त्यातून मायकलेक्शन बनवा
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // कामे देखील गोळा!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// इटरेटरकडून मूल्य तयार करते.
    ///
    /// अधिकसाठी [module-level documentation] पहा.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// [`Iterator`] मध्ये रूपांतरण.
///
/// एका प्रकारासाठी `IntoIterator` ची अंमलबजावणी करून, ते परिभाषित करा की ते इटरेटरमध्ये कसे रूपांतरित केले जाईल.
/// हे अशा प्रकारच्या प्रकारांमध्ये सामान्य आहे जे कोणत्या प्रकारचे संग्रह वर्णन करतात.
///
/// `IntoIterator` लागू करण्याचा एक फायदा म्हणजे आपला प्रकार [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator) होईल.
///
///
/// हे देखील पहा: [`FromIterator`].
///
/// # Examples
///
/// मूलभूत वापर:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// आपल्या प्रकारासाठी `IntoIterator` ची अंमलबजावणी करीत आहे:
///
/// ```
/// // एक नमुना संग्रह, तो व्हेक वर फक्त एक आवरण आहे<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // चला त्यास काही पद्धती देऊ या म्हणजे आम्ही त्यात एक तयार करू आणि त्यात गोष्टी जोडू.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // आणि आम्ही इंटेंटिटर कार्यान्वित करू
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // आता आम्ही एक नवीन संग्रह करू शकतो ...
/// let mut c = MyCollection::new();
///
/// // ... त्यात काही सामान घाला ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... आणि नंतर त्यास आयटरमध्ये रुपांतरित करा:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// `IntoIterator` ला trait bound म्हणून वापरणे सामान्य आहे.हे इनपुट संकलन प्रकार बदलण्यास अनुमती देते, जोपर्यंत तो अजून एक पुनरावृत्ती करणारा आहे.
/// यावर मर्यादा घालून अतिरिक्त मर्यादा निर्दिष्ट केल्या जाऊ शकतात
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// पुनरावृत्ती होणार्‍या घटकांचा प्रकार.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// कोणत्या प्रकारचे इटरेटर आपण हे मध्ये बदलत आहोत?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// मूल्यातून इटरेटर तयार करते.
    ///
    /// अधिकसाठी [module-level documentation] पहा.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// आयटरच्या सामुग्रीसह संग्रह वाढवा.
///
/// शोधक मूल्ये मालिका तयार करतात आणि संग्रह देखील मूल्ये मालिका म्हणून विचार केला जाऊ शकतो.
/// `Extend` trait ही अंतर कमी करते, आपल्याला त्या पुनरावृत्ती करणार्‍याची सामग्री समाविष्ट करुन संग्रह वाढवू देते.
/// आधीपासून अस्तित्त्वात असलेल्या कीसह संकलन वाढवित असताना, ती नोंद अद्यतनित केली जाते किंवा समान कीसह एकाधिक प्रविष्ट्यांना परवानगी देणार्‍या संग्रहाच्या बाबतीत, ती प्रविष्ट केली जाते.
///
///
/// # Examples
///
/// मूलभूत वापर:
///
/// ```
/// // आपण काही अक्षरांसह एक स्ट्रिंग वाढवू शकता:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// `Extend` लागू करीत आहे:
///
/// ```
/// // एक नमुना संग्रह, तो व्हेक वर फक्त एक आवरण आहे<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // चला त्यास काही पद्धती देऊ या म्हणजे आम्ही त्यात एक तयार करू आणि त्यात गोष्टी जोडू.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // माय कलेक्शनकडे आय 32 ची यादी असल्याने आम्ही एक्सटेंडे फॉर एक्स एक्सएक्स लागू करतो
/// impl Extend<i32> for MyCollection {
///
///     // हे कॉंक्रिट प्रकाराच्या स्वाक्षरीसह थोडे सोपे आहे: आम्ही आयटरमध्ये बदलले जाऊ शकते अशा कोणत्याही गोष्टीवर एक्सटेंड कॉल करू शकतो जे आपल्याला आय 32 देते.
///     // कारण माय कलेक्शन मध्ये टाकण्यासाठी आम्हाला आय 32 ची गरज आहे.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // अंमलबजावणी अगदी सरळ आहे: इटरेटरद्वारे पळवाट, आणि प्रत्येक घटक स्वतःला एक्स एक्स एक्स करा.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // चला आणखी तीन क्रमांकासह आपला संग्रह वाढवूया
/// c.extend(vec![1, 2, 3]);
///
/// // आम्ही शेवटी हे घटक जोडले आहेत
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// आयटरच्या सामुग्रीसह संग्रह वाढवितो.
    ///
    /// या झेडट्रायट0 झेडसाठी ही एकमेव आवश्यक पद्धत असल्याने, एक्स00 एक्स डॉक्समध्ये अधिक तपशील आहेत.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// // आपण काही अक्षरांसह एक स्ट्रिंग वाढवू शकता:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// अगदी एका घटकासह संग्रह वाढवितो.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// अतिरिक्त घटकांच्या दिलेल्या संख्येसाठी संग्रहात क्षमता राखून ठेवते.
    ///
    /// डीफॉल्ट अंमलबजावणी काहीही करत नाही.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}