use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// *उत्तराधिकारी* आणि *पूर्ववर्ती* ऑपरेशन्सची कल्पना असलेल्या ऑब्जेक्ट.
///
/// *उत्तराधिकारी* ऑपरेशन अधिक मूल्यांशी तुलना करणार्‍या मूल्यांकडे वळते.
/// *पूर्ववर्ती* ऑपरेशन कमी मूल्यांची तुलना करणार्‍या मूल्यांकडे वळते.
///
/// # Safety
///
/// हे trait `unsafe` आहे कारण `unsafe trait TrustedLen` अंमलबजावणीच्या सुरक्षिततेसाठी त्याची अंमलबजावणी योग्य असणे आवश्यक आहे आणि या trait वापरण्याचे परिणाम अन्यथा `unsafe` कोडवर विश्वास ठेवू शकतात आणि सूचीबद्ध जबाबदा .्या पूर्ण करतात.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// `start` ते `end` पर्यंत जाण्यासाठी आवश्यक असलेल्या *उत्तराधिकारी* चरणांची संख्या मिळवते.
    ///
    /// चरणांची संख्या `usize` ओव्हरफ्लो झाल्यास (किंवा असीम आहे किंवा `end` कधीही पोहोचली नसल्यास) `None` मिळवते.
    ///
    ///
    /// # Invariants
    ///
    /// कोणत्याही `a`, `b` आणि `n` साठी:
    ///
    /// * `steps_between(&a, &b) == Some(n)` जर आणि केवळ `Step::forward_checked(&a, n) == Some(b)` असेल
    /// * `steps_between(&a, &b) == Some(n)` जर आणि केवळ `Step::backward_checked(&a, n) == Some(a)` असेल
    /// * `steps_between(&a, &b) == Some(n)` फक्त जर `a <= b`
    ///   * उपसिद्धांत: X01 एक्स जर आणि फक्त `a == b` असेल
    ///   * लक्षात घ्या की `a <= b` _not_ सुचवते `steps_between(&a, &b) != None`;
    ///     हे असे होते जेव्हा जेव्हा `b` वर जाण्यासाठी `usize::MAX` पेक्षा जास्त चरणांची आवश्यकता असेल
    /// * `steps_between(&a, &b) == None` `a > b` असल्यास
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// `self` `count` वेळा *उत्तराधिकारी* मिळवून मिळविलेले मूल्य मिळवते.
    ///
    /// हे `Self` द्वारा समर्थित मूल्यांच्या श्रेणीवर ओसंडून गेल्यास, `None` परत करेल.
    ///
    /// # Invariants
    ///
    /// कोणत्याही `a`, `n` आणि `m` साठी:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// कोणत्याही `a`, `n` आणि `m` साठी जेथे `n + m` ओव्हरफ्लो होत नाही:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// कोणत्याही `a` आणि `n` साठी:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// `self` `count` वेळा *उत्तराधिकारी* मिळवून मिळविलेले मूल्य मिळवते.
    ///
    /// हे `Self` द्वारा समर्थित मूल्यांच्या श्रेणीवर ओसंडत असेल तर या कार्यास panic, लपेटणे किंवा संतृप्त करण्याची परवानगी आहे.
    ///
    /// डीबग assertions सक्षम केले जातात तेव्हा, आणि लपेटणे किंवा अन्यथा संतृप्त करण्यासाठी सुचविलेले वर्तन panic चे आहे.
    ///
    /// असुरक्षित कोड ओव्हरफ्लो नंतर वर्तनच्या शुद्धतेवर अवलंबून राहू नये.
    ///
    /// # Invariants
    ///
    /// कोणत्याही `a`, `n` आणि `m` साठी, जिथे ओव्हरफ्लो होत नाही:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// कोणत्याही `a` आणि `n` साठी, जिथे ओव्हरफ्लो होत नाही:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// `self` `count` वेळा *उत्तराधिकारी* मिळवून मिळविलेले मूल्य मिळवते.
    ///
    /// # Safety
    ///
    /// या ऑपरेशनसाठी `Self` द्वारे समर्थित मूल्यांच्या श्रेणी ओलांडणे हे अपरिभाषित वर्तन आहे.
    /// हे ओव्हरफ्लो होणार नाही याची हमी आपण देऊ शकत नसल्यास त्याऐवजी `forward` किंवा `forward_checked` वापरा.
    ///
    /// # Invariants
    ///
    /// कोणत्याही `a` साठी:
    ///
    /// * जर तेथे `b` असे `b > a` अस्तित्वात असेल तर ते `Step::forward_unchecked(a, 1)` वर कॉल करणे सुरक्षित आहे
    /// * जर तेथे `b`, `n` असे `steps_between(&a, &b) == Some(n)` अस्तित्वात असतील तर कोणत्याही `m <= n` साठी `Step::forward_unchecked(a, m)` वर कॉल करणे सुरक्षित आहे.
    ///
    ///
    /// कोणत्याही `a` आणि `n` साठी, जिथे ओव्हरफ्लो होत नाही:
    ///
    /// * `Step::forward_unchecked(a, n)` हे `Step::forward(a, n)` च्या समतुल्य आहे
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// `self` `count` वेळा *पूर्ववर्ती* घेवून प्राप्त केले जाणारे मूल्य मिळवते.
    ///
    /// हे `Self` द्वारा समर्थित मूल्यांच्या श्रेणीवर ओसंडून गेल्यास, `None` परत करेल.
    ///
    /// # Invariants
    ///
    /// कोणत्याही `a`, `n` आणि `m` साठी:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// कोणत्याही `a` आणि `n` साठी:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// `self` `count` वेळा *पूर्ववर्ती* घेवून प्राप्त केले जाणारे मूल्य मिळवते.
    ///
    /// हे `Self` द्वारा समर्थित मूल्यांच्या श्रेणीवर ओसंडत असेल तर या कार्यास panic, लपेटणे किंवा संतृप्त करण्याची परवानगी आहे.
    ///
    /// डीबग assertions सक्षम केले जातात तेव्हा, आणि लपेटणे किंवा अन्यथा संतृप्त करण्यासाठी सुचविलेले वर्तन panic चे आहे.
    ///
    /// असुरक्षित कोड ओव्हरफ्लो नंतर वर्तनच्या शुद्धतेवर अवलंबून राहू नये.
    ///
    /// # Invariants
    ///
    /// कोणत्याही `a`, `n` आणि `m` साठी, जिथे ओव्हरफ्लो होत नाही:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// कोणत्याही `a` आणि `n` साठी, जिथे ओव्हरफ्लो होत नाही:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// `self` `count` वेळा *पूर्ववर्ती* घेवून प्राप्त केले जाणारे मूल्य मिळवते.
    ///
    /// # Safety
    ///
    /// या ऑपरेशनसाठी `Self` द्वारे समर्थित मूल्यांच्या श्रेणी ओलांडणे हे अपरिभाषित वर्तन आहे.
    /// हे ओव्हरफ्लो होणार नाही याची हमी आपण देऊ शकत नसल्यास त्याऐवजी `backward` किंवा `backward_checked` वापरा.
    ///
    /// # Invariants
    ///
    /// कोणत्याही `a` साठी:
    ///
    /// * जर तेथे `b` असे `b < a` अस्तित्वात असेल तर ते `Step::backward_unchecked(a, 1)` वर कॉल करणे सुरक्षित आहे
    /// * जर तेथे `b`, `n` असे `steps_between(&b, &a) == Some(n)` अस्तित्वात असतील तर कोणत्याही `m <= n` साठी `Step::backward_unchecked(a, m)` वर कॉल करणे सुरक्षित आहे.
    ///
    ///
    /// कोणत्याही `a` आणि `n` साठी, जिथे ओव्हरफ्लो होत नाही:
    ///
    /// * `Step::backward_unchecked(a, n)` हे `Step::backward(a, n)` च्या समतुल्य आहे
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// हे अद्याप मॅक्रो-व्युत्पन्न आहेत कारण पूर्णांक अक्षरशः भिन्न प्रकारचे निराकरण करते.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // सुरक्षितताः कॉलरला याची हमी दिली पाहिजे की `start + n` ओव्हरफ्लो होत नाही.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // सुरक्षितताः कॉलरला याची हमी दिली पाहिजे की `start - n` ओव्हरफ्लो होत नाही.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // डीबग बिल्ड्समध्ये, ओव्हरफ्लोवर एक panic ट्रिगर करा.
            // हे रिलीज बिल्डमध्ये पूर्णपणे अनुकूलित केले जावे.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // उदा. अनुमती देण्यासाठी गणितावर गुंडाळण्याचे काम करा `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // डीबग बिल्ड्समध्ये, ओव्हरफ्लोवर एक panic ट्रिगर करा.
            // हे रिलीज बिल्डमध्ये पूर्णपणे अनुकूलित केले जावे.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // उदा. अनुमती देण्यासाठी गणितावर गुंडाळण्याचे काम करा `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // हे $u_narrower <=usize वर अवलंबून आहे
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // एन श्रेणीबाहेर असल्यास, एक्स 100 एक्स देखील आहे
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // एन श्रेणीबाहेर असल्यास, एक्स 100 एक्स देखील आहे
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // हे $i_narrower <=usize वर अवलंबून आहे
                        //
                        // आयसाइझ करण्यासाठी कास्ट करणे रुंदी वाढवते परंतु चिन्ह जपते.
                        // आयसाइझच्या जागेमध्ये रॅपिंग_सब वापरा आणि आयसाइझच्या श्रेणीत न बसू शकणार्‍या फरक मोजण्यासाठी यूईझ करण्यासाठी कास्ट करा.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // `Step::forward(-120_i8, 200) == Some(80_i8)` सारखी 200 प्रकरणे मर्यादित नसतानाही लपेटणे `Step::forward(-120_i8, 200) == Some(80_i8)` सारखी प्रकरणे हाताळते.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // भर पडली
                            }
                        }
                        // जर एन उदा. श्रेणीबाहेर असेल तर
                        // u8, तर ती i8 साठी संपूर्ण श्रेणीपेक्षा मोठी आहे म्हणून `any_i8 + n` अपरिहार्यपणे i8 ओव्हरफ्लो करेल.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // `Step::forward(-120_i8, 200) == Some(80_i8)` सारखी 200 प्रकरणे मर्यादित नसतानाही लपेटणे `Step::forward(-120_i8, 200) == Some(80_i8)` सारखी प्रकरणे हाताळते.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // वजाबाकी ओव्हरफ्लो झाली
                            }
                        }
                        // जर एन उदा. श्रेणीबाहेर असेल तर
                        // u8, तर ती i8 साठी संपूर्ण श्रेणीपेक्षा मोठी आहे म्हणून `any_i8 - n` अपरिहार्यपणे i8 ओव्हरफ्लो करेल.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // जर फरक खूप मोठा असेल उदा
                            // i128, कमी बिट्स वापरुन ते देखील खूप मोठे होईल.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // सुरक्षा: रेस एक वैध युनिकोड स्केलर आहे
            // (0x110000 च्या खाली आणि 0xD800..0xE000 मध्ये नाही)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // सुरक्षा: रेस एक वैध युनिकोड स्केलर आहे
        // (0x110000 च्या खाली आणि 0xD800..0xE000 मध्ये नाही)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // सुरक्षितता: कॉलरने हमी देणे आवश्यक आहे की हे ओव्हरफ्लो होत नाही
        // एका चार्टसाठी मूल्यांची श्रेणी.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // सुरक्षितता: कॉलरने हमी देणे आवश्यक आहे की हे ओव्हरफ्लो होत नाही
            // एका चार्टसाठी मूल्यांची श्रेणी.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // सुरक्षा: मागील करारामुळे, याची हमी दिलेली आहे
        // कॉलरद्वारे वैध चार्ट बनू शकेल.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // सुरक्षितता: कॉलरने हमी देणे आवश्यक आहे की हे ओव्हरफ्लो होत नाही
        // एका चार्टसाठी मूल्यांची श्रेणी.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // सुरक्षितता: कॉलरने हमी देणे आवश्यक आहे की हे ओव्हरफ्लो होत नाही
            // एका चार्टसाठी मूल्यांची श्रेणी.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // सुरक्षा: मागील करारामुळे, याची हमी दिलेली आहे
        // कॉलरद्वारे वैध चार्ट बनू शकेल.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // सुरक्षितता: नुकतीच पूर्वस्थिती तपासली
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // सुरक्षितता: नुकतीच पूर्वस्थिती तपासली
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// हे मॅक्रो विविध श्रेणी प्रकारांकरिता एक्स 100 एक्स निपुणते व्युत्पन्न करतात.
//
// * `ExactSizeIterator::len` नेहमी अचूक X01 एक्स परत करणे आवश्यक असते, म्हणून कोणतीही श्रेणी `usize::MAX` पेक्षा मोठी असू शकत नाही.
//
// * `Range<_>` मधील पूर्णांक प्रकारांसाठी हे `usize` पेक्षा लहान किंवा विस्तृत रूंद प्रकारांसाठी आहे.
//   `RangeInclusive<_>` मधील पूर्णांक प्रकारांकरिता हे `usize` च्या तुलनेत *काटेकोरपणे संकुचित* प्रकारांसाठी आहे
//   `(0..=u64::MAX).len()` `u64::MAX + 1` असेल.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // हे वरील तर्कानुसार निर्विकार आहेत, परंतु त्यांना काढून टाकणे ब्रेकिंग बदल होईल कारण ते Rust 1.0.0 मध्ये स्थिर झाले होते.
    // तर उदा
    // `(0..66_000_u32).len()` उदाहरणार्थ 16-बिट प्लॅटफॉर्मवर त्रुटी किंवा चेतावणीशिवाय संकलित करेल, परंतु चुकीचा निकाल देणे सुरू ठेवेल.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // हे वरील तर्कानुसार निर्विकार आहेत, परंतु त्यांना काढून टाकणे ब्रेकिंग बदल होईल कारण ते Rust 1.26.0 मध्ये स्थिर झाले होते.
    // तर उदा
    // `(0..=u16::MAX).len()` उदाहरणार्थ 16-बिट प्लॅटफॉर्मवर त्रुटी किंवा चेतावणीशिवाय संकलित करेल, परंतु चुकीचा निकाल देणे सुरू ठेवेल.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // सुरक्षितता: नुकतीच पूर्वस्थिती तपासली
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // सुरक्षितता: नुकतीच पूर्वस्थिती तपासली
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // सुरक्षितता: नुकतीच पूर्वस्थिती तपासली
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // सुरक्षितता: नुकतीच पूर्वस्थिती तपासली
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // सुरक्षितता: नुकतीच पूर्वस्थिती तपासली
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // सुरक्षितता: नुकतीच पूर्वस्थिती तपासली
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}