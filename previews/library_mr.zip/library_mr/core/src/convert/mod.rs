//! प्रकारांमधील रूपांतरणांसाठी Traits.
//!
//! या मॉड्यूलमधील traits एका प्रकारातून दुसर्‍या प्रकारात रूपांतरित करण्याचा मार्ग प्रदान करते.
//! प्रत्येक trait भिन्न हेतूसाठी कार्य करते:
//!
//! - स्वस्त संदर्भ-संदर्भ-रूपांतरणांसाठी [`AsRef`] trait लागू करा
//! - स्वस्त बदलण्यायोग्य-ते-बदलण्यायोग्य रूपांतरणांसाठी [`AsMut`] trait लागू करा
//! - मूल्य-ते-मूल्य रूपांतरणे वापरण्यासाठी [`From`] trait लागू करा
//! - सद्य crate बाहेरील प्रकारांमध्ये मूल्य-ते-मूल्य रूपांतरणे वापरण्यासाठी [`Into`] trait लागू करा
//! - [`TryFrom`] आणि [`TryInto`] traits [`From`] आणि [`Into`] सारखे वर्तन करते, परंतु जेव्हा रूपांतरण अयशस्वी होऊ शकते तेव्हा अंमलात आणले जावे.
//!
//! या मॉड्यूलमधील traits बहुतेकदा trait bounds म्हणून वापरले जाते जे एकाधिक प्रकारच्या वितर्कांचे समर्थन करतात.उदाहरणांसाठी प्रत्येक trait चे दस्तऐवजीकरण पहा.
//!
//! ग्रंथालय लेखक म्हणून, आपण नेहमी [`Into<U>`][`Into`] किंवा [`TryInto<U>`][`TryInto`] ऐवजी [`From<T>`][`From`] किंवा [`TryFrom<T>`][`TryFrom`] लागू करणे पसंत केले पाहिजे, कारण [`From`] आणि [`TryFrom`] अधिक लवचिकता प्रदान करतात आणि मानक लायब्ररीत ब्लँकेट अंमलबजावणीबद्दल धन्यवाद, विनामूल्य [`Into`] किंवा [`TryInto`] अंमलबजावणी ऑफर करतात.
//! Rust 1.41 पूर्वीच्या आवृत्तीचे लक्ष्यीकरण करताना, सध्याच्या crate बाहेरील प्रकारात रूपांतरित करताना थेट [`Into`] किंवा [`TryInto`] लागू करणे आवश्यक असू शकते.
//!
//! # सामान्य अंमलबजावणी
//!
//! - [`AsRef`] आतील प्रकार संदर्भ असल्यास एक्स-एक्स एक्स स्वयं-डीरेफरन्स
//! - [`From`]`<U>साठी T` सुचवते [`Into`]`</u><T><U>U for साठी</u>
//! - [`TryFrom`]`<U>साठी T` सुचवते [`TryInto`]`</u><T><U>U for साठी</u>
//! - [`From`] आणि एक्स 100 एक्स रिफ्लेक्सिव्ह आहेत, ज्याचा अर्थ असा आहे की सर्व प्रकार स्वतः `into` करू शकतात आणि स्वतः `from`
//!
//! वापराच्या उदाहरणांसाठी प्रत्येक trait पहा.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// ओळख कार्य.
///
/// या कार्याबद्दल दोन गोष्टी लक्षात घेणे आवश्यक आहेः
///
/// - हे नेहमीच `|x| x` सारख्या बंद होण्यासारखे नसते कारण हे बंद केल्यामुळे `x` वेगळ्या प्रकारात भाग पाडले जाऊ शकते.
///
/// - हे फंक्शनला गेलेले इनपुट `x` हलवते.
///
/// एखादे फंक्शन फक्त इनपुट परत करतात हे विचित्र वाटले तरी तेथे काही मनोरंजक उपयोग आहेत.
///
///
/// # Examples
///
/// इतर, स्वारस्यपूर्ण, फंक्शन्सच्या अनुक्रमात काहीही न करण्यासाठी `identity` वापरणे:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // एखादी जोड म्हणजे एक रंजक फंक्शन असल्याचे भासवू या.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// सशर्त मध्ये `identity` ला "do nothing" बेस केस म्हणून वापरणे:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // अधिक मनोरंजक गोष्टी करा ...
///
/// let _results = do_stuff(42);
/// ```
///
/// `Option<T>` च्या आयटरचे `Some` रूपे ठेवण्यासाठी `identity` वापरणे:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// स्वस्त संदर्भ-संदर्भ रूपांतरण करण्यासाठी वापरले जाते.
///
/// हे trait [`AsMut`] प्रमाणेच आहे जे बदलण्यायोग्य संदर्भांमध्ये रूपांतरित करण्यासाठी वापरले जाते.
/// जर आपल्याला महागडे रूपांतरण करण्याची आवश्यकता असेल तर X01 एक्स प्रकारासह एक्स 100 एक्स लागू करणे किंवा सानुकूल कार्य लिहणे चांगले.
///
/// `AsRef` [`Borrow`] प्रमाणेच स्वाक्षरी आहे, परंतु [`Borrow`] काही पैलूंमध्ये भिन्न आहे:
///
/// - `AsRef` च्या विपरीत, [`Borrow`] मध्ये कोणत्याही `T` साठी ब्लँकेट इम्प्ली आहे आणि संदर्भ किंवा मूल्य एकतर स्वीकारण्यासाठी वापरले जाऊ शकते.
/// - [`Borrow`] हे देखील आवश्यक आहे की कर्ज घेणार्‍या मूल्यासाठी [`Hash`], [`Eq`] आणि [`Ord`] मालकीच्या मूल्याच्या समतुल्य असतील.
/// या कारणास्तव, आपल्याला एखाद्या स्ट्रक्चरचे केवळ एक फील्ड घ्यायचे असल्यास आपण `AsRef` लागू करू शकता, परंतु एक्स 100 एक्स नाही.
///
/// **Note: हे trait ** अयशस्वी होऊ नये.जर रूपांतरण अयशस्वी होऊ शकत असेल तर एक समर्पित पद्धत वापरा जी [`Option<T>`] किंवा [`Result<T, E>`] परत करेल.
///
/// # सामान्य अंमलबजावणी
///
/// - `AsRef` अंतर्गत प्रकार संदर्भ असल्यास किंवा बदलण्यायोग्य संदर्भ असल्यास स्वयं-संदर्भ `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// trait bounds वापरुन आम्ही निर्दिष्ट प्रकार `T` मध्ये रूपांतरित केल्या जाऊ शकतात तोपर्यंत आम्ही विविध प्रकारच्या वितर्क स्वीकारू शकतो.
///
/// उदाहरणार्थ: एक `AsRef<str>` घेणारे जेनेरिक फंक्शन तयार करून आम्ही व्यक्त करतो की [`&str`] मध्ये वितर्क म्हणून रूपांतरित केलेले सर्व संदर्भ आम्हाला स्वीकारायचे आहेत.
/// [`String`] आणि [`&str`] दोन्ही `AsRef<str>` लागू केल्यामुळे आम्ही दोघांनाही इनपुट वितर्क म्हणून स्वीकारू शकतो.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// रूपांतरण करते.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// स्वस्त-रूपांतर-ते-परिवर्तनीय संदर्भ रूपांतरण करण्यासाठी वापरले जाते.
///
/// हे trait [`AsRef`] प्रमाणेच आहे परंतु परिवर्तनीय संदर्भांमध्ये रूपांतरित करण्यासाठी वापरले जाते.
/// जर आपल्याला महागडे रूपांतरण करण्याची आवश्यकता असेल तर X01 एक्स प्रकारासह एक्स 100 एक्स लागू करणे किंवा सानुकूल कार्य लिहणे चांगले.
///
/// **Note: हे trait ** अयशस्वी होऊ नये.जर रूपांतरण अयशस्वी होऊ शकत असेल तर एक समर्पित पद्धत वापरा जी [`Option<T>`] किंवा [`Result<T, E>`] परत करेल.
///
/// # सामान्य अंमलबजावणी
///
/// - `AsMut` अंतर्गत प्रकार परिवर्तनीय संदर्भ असल्यास स्वयं-संदर्भ `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// जेनेरिक कार्यासाठी `AsMut` चा trait bound म्हणून वापरुन आम्ही सर्व बदलण्यायोग्य संदर्भ स्वीकारू जे `&mut T` प्रकारात रूपांतरित होऊ शकतात.
/// कारण [`Box<T>`] `AsMut<T>` ची अंमलबजावणी करते आम्ही `add_one` हे फंक्शन लिहू शकतो जे `&mut u64` मध्ये रूपांतरित केले जाऊ शकते अशा सर्व वितर्क घेते.
/// कारण [`Box<T>`] `AsMut<T>` ची अंमलबजावणी करते, `add_one` तसेच `&mut Box<u64>` प्रकाराचे वितर्क स्वीकारते:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// रूपांतरण करते.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// इनपुट मूल्य वापरणारे मूल्य-ते-मूल्य रूपांतरण.[`From`] च्या विरुद्ध
///
/// एखाद्याने [`Into`] लागू करणे टाळले पाहिजे आणि त्याऐवजी [`From`] अंमलात आणावे.
/// एक्स 100 एक्स ची अंमलबजावणी स्वयंचलितपणे एक्स लायब्ररीमधील ब्लँकेट अंमलबजावणीबद्दल [`Into`] अंमलबजावणीसह प्रदान करते.
///
/// केवळ [`Into`] लागू करणारे प्रकार देखील वापरले जाऊ शकतात हे सुनिश्चित करण्यासाठी जेनेरिक फंक्शनवर trait bounds निर्दिष्ट करतेवेळी [`Into`] X वर X0X वापरण्यास प्राधान्य द्या.
///
/// **Note: हे trait ** अयशस्वी होऊ नये.जर रूपांतरण अयशस्वी होऊ शकत असेल तर [`TryInto`] वापरा.
///
/// # सामान्य अंमलबजावणी
///
/// - [`प्रेषक]`<T>U` साठी `Into<U> for T` सुचवते
/// - [`Into`] रिफ्लेक्सिव्ह आहे, ज्याचा अर्थ `Into<T> for T` कार्यान्वित झाला आहे
///
/// # Rust च्या जुन्या आवृत्त्यांमध्ये बाह्य प्रकारांमध्ये रूपांतरणांसाठी [`Into`] ची अंमलबजावणी करणे
///
/// Rust 1.41 पूर्वी, जर गंतव्यस्थानाचा प्रकार सध्याच्या crate चा भाग नसला तर आपण थेट [`From`] लागू करू शकत नाही.
/// उदाहरणार्थ, हा कोड घ्या:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// हे भाषेच्या जुन्या आवृत्त्यांचे संकलन करण्यात अयशस्वी होईल कारण झेडआरस्ट ० झेडचे अनाथ नियम थोडे अधिक कठोर असायचे.
/// हे सोडण्यासाठी आपण थेट [`Into`] लागू करू शकता:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// हे समजून घेणे महत्वाचे आहे की [`Into`] [`From`] अंमलबजावणी प्रदान करत नाही ([`From`] [`Into`] प्रमाणेच).
/// म्हणूनच, आपण नेहमीच [`From`] अंमलात आणण्याचा प्रयत्न केला पाहिजे आणि [`From`] कार्यान्वित होऊ शकत नसेल तर मग परत [`Into`] वर जा.
///
/// # Examples
///
/// [`String`] अवजारे [`Into`]`<`[`Vec`] `<` [`u8`]`>> >>`:
///
/// आम्हाला असे निर्दिष्ट करण्यासाठी की जेनेरिक फंक्शन एका विशिष्ट प्रकारा `T` मध्ये रूपांतरित केले जाऊ शकते अशा सर्व युक्तिवादांसाठी आपण घेऊ इच्छित आहोत, आम्ही [`In``] of च्या trait bound वापरू शकतो.<T>`.
///
/// उदाहरणार्थ: कार्य `is_hello` सर्व आर्ग्युमेंट्स घेते जे [`वेक]` <`[` u8`]`>` मध्ये रूपांतरित केले जाऊ शकतात.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// रूपांतरण करते.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// इनपुट मूल्य घेताना व्हॅल्यू-टू-व्हॅल्यू रूपांतरण करण्यासाठी वापरले जाते.हे एक्स 100 एक्सचे परस्पर व्यवहार आहे.
///
/// [`Into`] च्या तुलनेत `From` ची अंमलबजावणी करण्यास नेहमीच प्राधान्य दिले पाहिजे कारण `From` ची अंमलबजावणी स्वयंचलितपणे [`Into`] च्या अंमलबजावणीसह प्रदान करते जी मानक लायब्ररीत ब्लँकेट अंमलबजावणीबद्दल धन्यवाद.
///
///
/// Rust 1.41 पूर्वीच्या आवृत्तीस लक्ष्यित करून आणि सध्याच्या crate बाहेरील प्रकारात रूपांतरित करताना केवळ [`Into`] लागू करा.
/// `From` Rust च्या अनाथ नियमांमुळे पूर्वीच्या आवृत्त्यांमध्ये या प्रकारचे रूपांतरण करण्यास सक्षम नाही.
/// अधिक तपशीलांसाठी [`Into`] पहा.
///
/// जेनेरिक फंक्शनवर trait bounds निर्दिष्ट करतेवेळी [`Into`] वापरण्यापेक्षा [`Into`] वापरण्यास प्राधान्य द्या.
/// अशाप्रकारे [`Into`] थेट लागू करणारे प्रकार तसेच वितर्क म्हणून वापरले जाऊ शकतात.
///
/// `From` त्रुटी हाताळणी करताना देखील उपयुक्त आहे.अपयशी ठरण्यास सक्षम असे कार्य तयार करताना, रिटर्न प्रकार सामान्यत: `Result<T, E>` फॉर्मचा असेल.
/// `From` trait एकाधिक त्रुटी प्रकारांना समाविष्‍ट करणारे एकल त्रुटी प्रकार परत करणार्‍या कार्यास अनुमती देऊन त्रुटी हाताळणीस सुलभ करते.अधिक तपशीलांसाठी "Examples" विभाग आणि [the book][book] पहा.
///
/// **Note: हे trait ** अयशस्वी होऊ नये.जर रूपांतरण अयशस्वी होऊ शकत असेल तर [`TryFrom`] वापरा.
///
/// # सामान्य अंमलबजावणी
///
/// - `From<T> for U` Tlies <U>साठी</u> [`Into`] lies सुचवते
/// - `From` रिफ्लेक्सिव्ह आहे, ज्याचा अर्थ `From<T> for T` कार्यान्वित झाला आहे
///
/// # Examples
///
/// [`String`] एक्स 100 एक्स लागू करते:
///
/// `&str` वरून एका स्ट्रिंगमध्ये स्पष्ट रूपांतरण खालीलप्रमाणे आहे:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// त्रुटी हाताळताना हे आपल्या स्वतःच्या त्रुटी प्रकारासाठी `From` अंमलात आणणे नेहमीच उपयुक्त ठरते.
/// अंतर्निहित त्रुटी प्रकारास अंतर्भूत असलेल्या स्वतःच्या सानुकूल त्रुटी प्रकारात अंतर्निहित त्रुटी प्रकार रूपांतरित करून, आम्ही मूळ कारणांची माहिती गमावल्याशिवाय एकच त्रुटी प्रकार परत करू शकतो.
/// '?' ऑपरेटर `Into<CliError>::into` वर कॉल करून आमच्या सानुकूल एरर प्रकारात अंतर्निहित त्रुटी प्रकार स्वयंचलितपणे रूपांतरित करतो जो `From` लागू करताना स्वयंचलितपणे प्रदान केला जातो.
/// कंपाइलर नंतर एक्स 100 एक्स ची अंमलबजावणी वापरली जावी याचा अनुमान लावते.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// रूपांतरण करते.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// `self` वापरणारे एक रूपांतरण, जे कदाचित महाग किंवा असू शकत नाही.
///
/// लायब्ररीच्या लेखकांनी सामान्यत: हे थेट trait कार्यान्वित करू नये, परंतु [`TryFrom`] trait ची अंमलबजावणी करण्यास प्राधान्य दिले पाहिजे, जे जास्त लवचिकता देते आणि प्रमाणित लायब्ररीत ब्लँकेट अंमलबजावणीबद्दल धन्यवाद, विनामूल्य विनामूल्य समकक्ष X01 एक्स अंमलबजावणी प्रदान करते.
/// यावरील अधिक माहितीसाठी, [`Into`] चे दस्तऐवजीकरण पहा.
///
/// # एक्स 100 एक्स ची अंमलबजावणी करीत आहे
///
/// हे [`Into`] लागू करण्यासारखेच निर्बंध आणि युक्तिवादाने ग्रस्त आहे, तपशीलांसाठी येथे पहा.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// रूपांतरण त्रुटी असल्यास प्रकार परत आला.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// रूपांतरण करते.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// काही परिस्थितीत नियंत्रित मार्गाने अयशस्वी होणारी साधे आणि सुरक्षित प्रकारची रूपांतरणे.हे एक्स 100 एक्सचे परस्पर व्यवहार आहे.
///
/// जेव्हा आपण एखादे प्रकार रूपांतर करीत असाल तेव्हा हे उपयुक्त ठरेल जे क्षुल्लक यशस्वी होऊ शकेल परंतु त्यांना विशेष हाताळणीची देखील आवश्यकता असू शकेल.
/// उदाहरणार्थ, [`From`] trait वापरुन [`i64`] ला [`i32`] मध्ये रूपांतरित करण्याचा कोणताही मार्ग नाही, कारण [`i64`] मध्ये असे मूल्य असू शकते जे [`i32`] दर्शवू शकत नाही आणि म्हणून रूपांतरण डेटा गमावेल.
///
/// हे [`i64`] ला [`i32`] (मूलत: [`i64`] चे मूल्य मॉड्यूलो एक्स03 एक्स देणे) किंवा [`i32::MAX`] परत करून किंवा अन्य कोणत्याही पद्धतीद्वारे हाताळले जाऊ शकते.
/// [`From`] trait परिपूर्ण रूपांतरणांसाठी आहे, म्हणून जेव्हा प्रकार रूपांतरण खराब होऊ शकते तेव्हा `TryFrom` trait प्रोग्रामरला माहिती देते आणि ते कसे हाताळायचे हे ठरवू देते.
///
/// # सामान्य अंमलबजावणी
///
/// - `TryFrom<T> for U` T`<U>साठी</u> [`TryInto`] imp सूचित <U>करते</u>
/// - [`try_from`] रिफ्लेक्सिव्ह आहे, याचा अर्थ असा की `TryFrom<T> for T` कार्यान्वित झाला आहे आणि अयशस्वी होऊ शकत नाही-`T` प्रकारावरील `T::try_from()` वर कॉल करण्यासाठी संबंधित `Error` प्रकार म्हणजे [`Infallible`] आहे.
/// जेव्हा एक्स 100 एक्स प्रकार स्थिर होईल तेव्हा X01 एक्स आणि एक्स0 2 एक्स समतुल्य असेल.
///
/// `TryFrom<T>` खालीलप्रमाणे अंमलबजावणी केली जाऊ शकते:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// वर्णन केल्यानुसार, [`i32`] अवजारे `ट्रायफ्रॉम <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // शांतपणे `big_number` छाटते, वस्तुस्थितीनंतर कटिंग शोधणे आणि हाताळणे आवश्यक आहे.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // एक त्रुटी परत करते कारण `big_number` `i32` मध्ये फिट होण्यास खूप मोठा आहे.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // `Ok(3)` मिळवते.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// रूपांतरण त्रुटी असल्यास प्रकार परत आला.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// रूपांतरण करते.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// सामान्य आयएमपीएल
////////////////////////////////////////////////////////////////////////////////

// वर उचल म्हणून&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// म्हणून &mut वर लिफ्ट
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): वरील अधिक प्रॉब्लेम्स&/&म्यूटसाठी खालील अधिक सामान्य सह पुनर्स्थित करा:
// // लिफ्ट म्हणून डेरेफ
// उत्तेजन देणे <D: ?Sized + Deref<Target: AsRef<U>>, यू:? आकार=> <U>डी {फ्न एक्स00 एक्स-> एक्स ०१ एक्स As</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut &mut वर उचलते
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): &mut साठी वरील impl ला खालील सर्वसाधारण जागी बदला:
// // AsMut डेरेफूट वर उचलते
// उत्तेजन देणे <D: ?Sized + Deref<Target: AsMut<U>>, यू:? आकार> एएसएमट <U>फॉर डी nफ्न एक्स00 एक्स-> एक्स ०१ एक्स यू {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// पासून सुचवते
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// कडून (आणि अशा प्रकारे मध्ये) प्रतिक्षिप्त आहे
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **स्थिरता टीप:** ही आव्हान अद्याप अस्तित्त्वात नाही, परंतु आम्ही ती झेडफ्यूचर0 झेडमध्ये जोडण्यासाठी "reserving space" आहोत.
/// तपशीलांसाठी [rust-lang/rust#64715][#64715] पहा.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): त्याऐवजी एक सिद्धांत करा.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// ट्रायफ्रॉम म्हणजे ट्रायंटो
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// अचूक रूपांतरणे निर्जन त्रुटी प्रकारासह चुकीच्या रूपांतरणांसारखे शब्दमूलक असतात.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// आयएमपीएल संकुचित करा
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// कोणतीही चूक त्रुटी प्रकार
////////////////////////////////////////////////////////////////////////////////

/// त्रुटींसाठी त्रुटी प्रकार जो कधीही होऊ शकत नाही.
///
/// या एनममध्ये प्रकार नसल्याने या प्रकाराचे मूल्य प्रत्यक्षात अस्तित्त्वात नाही.
/// [`Result`] वापरणार्‍या आणि त्रुटी प्रकाराला पॅरामीटराइझ करणार्‍या जेनेरिक एपीआयसाठी हे उपयुक्त ठरू शकते जेणेकरून परिणाम नेहमीच एक्स 100 एक्स असतो.
///
/// उदाहरणार्थ, [`TryFrom`] trait (एक [`Result`] परत करणारा रूपांतरण) मध्ये सर्व प्रकारच्या ब्लँकेटची अंमलबजावणी आहे जेथे उलट [`Into`] अंमलबजावणी विद्यमान आहे.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # झेडफ्यूचर 0 झेड सुसंगतता
///
/// या एनमची [the `!`“never”type][never] सारखीच भूमिका आहे जी Rust च्या या आवृत्तीत अस्थिर आहे.
/// जेव्हा `!` स्थीर होते, तेव्हा आम्ही `Infallible` ला त्यास एक उपनाव बनवण्याची योजना आखत आहोतः
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …आणि अखेरीस `Infallible` नाकारले.
///
/// तथापि, असे एक प्रकरण आहे जेथे X01 एक्स पूर्ण वाढीव प्रकार म्हणून स्थिर होण्यापूर्वी `!` वाक्यरचना वापरली जाऊ शकते: फंक्शनच्या रिटर्न प्रकाराच्या स्थितीत.
/// विशेषत: दोन भिन्न फंक्शन पॉईंटर प्रकारांसाठी ही अंमलबजावणी शक्य आहे:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// `Infallible` एनम असल्याने, हा कोड वैध आहे.
/// तथापि जेव्हा `Infallible` never type चे उपनाव बनते, तेव्हा दोन प्रवृत्ती आच्छादित होऊ लागतात आणि म्हणूनच भाषेच्या trait सुसंगत नियमांद्वारे त्यास अनुमती दिली जाईल.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}