use crate::iter::FromIterator;

/// आयटरमधून सर्व युनिट आयटम एकामध्ये संकुचित करते.
///
/// जेव्हा आपल्याला केवळ त्रुटींबद्दल काळजी असते अशा `Result<(), E>` वर संकलित करणे यासारख्या उच्च-स्तरावरील अमूर्ततेसह एकत्रितपणे हे अधिक उपयुक्त आहे:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}