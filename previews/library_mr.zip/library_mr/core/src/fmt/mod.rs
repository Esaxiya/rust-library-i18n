//! तारांचे स्वरूपन व मुद्रणासाठी उपयुक्तता.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// `Formatter::align` द्वारे परत केलेले संभाव्य संरेखन
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// सामग्री डावी संरेखित केली जावी असा संकेत.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// सामग्री उजवीकडे संरेखित केली जावी असा संकेत.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// सामग्री मध्य-संरेखित केली जावी असा संकेत.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// प्रकार स्वरूपन पद्धतींद्वारे परत आला.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// एक प्रवाह प्रकारात संदेश स्वरूपित करण्यापासून परत केलेला त्रुटी प्रकार.
///
/// हा प्रकार त्रुटीच्या व्यतिरिक्त कोणत्याही त्रुटीच्या संप्रेषणास समर्थन देत नाही.
/// कोणतीही अतिरिक्त माहिती इतर काही मार्गांनी प्रसारित करण्याची व्यवस्था केली पाहिजे.
///
/// लक्षात ठेवण्याची एक महत्त्वाची गोष्ट म्हणजे `fmt::Error` हा प्रकार [`std::io::Error`] किंवा [`std::error::Error`] सह गोंधळात टाकू नये, ज्याचा आपला व्याप्ती देखील असू शकेल.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// युनिकोड-स्वीकार करणारे बफर्स किंवा प्रवाहांमध्ये लिहिण्यासाठी किंवा स्वरूपित करण्यासाठी एक झेडट्रेट0 झेड.
///
/// हे trait केवळ UTF-8 - एन्कोड केलेला डेटा स्वीकारतो आणि [flushable] नाही.
/// आपण फक्त युनिकोड स्वीकारू इच्छित असल्यास आणि आपल्याला फ्लशिंगची आवश्यकता नसल्यास आपण हे झेडट्रेट 0 झेड कार्यान्वित केले पाहिजे;
/// अन्यथा आपण [`std::io::Write`] लागू केले पाहिजे.
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// या लेखकामध्ये एक स्ट्रिंग स्लाइस लिहितात, लेखन यशस्वी झाले की नाही यावर परत.
    ///
    /// संपूर्ण स्ट्रिंग स्लाइस यशस्वीरित्या लिहिली गेली असेल तरच ही पद्धत यशस्वी होईल आणि सर्व डेटा लिहिल्याशिवाय किंवा त्रुटी उद्भवल्याशिवाय ही पद्धत परत येणार नाही.
    ///
    ///
    /// # Errors
    ///
    /// हे कार्य त्रुटीमुळे [`Error`] चे उदाहरण परत करेल.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// या लेखकामध्ये [`char`] लिहितात, लेखन यशस्वी झाले की नाही ते परत.
    ///
    /// एकच [`char`] एकापेक्षा जास्त बाइट म्हणून एन्कोड केले जाऊ शकते.
    /// संपूर्ण बाइट क्रम यशस्वीरित्या लिहिला गेला असेल तरच ही पद्धत यशस्वी होईल आणि सर्व डेटा लिहिल्याशिवाय किंवा त्रुटी उद्भवल्याशिवाय ही पद्धत परत येणार नाही.
    ///
    ///
    /// # Errors
    ///
    /// हे कार्य त्रुटीमुळे [`Error`] चे उदाहरण परत करेल.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// या trait च्या अंमलबजावणी करणार्‍यांसह [`write!`] मॅक्रोच्या वापरासाठी गोंद.
    ///
    /// ही पद्धत सामान्यत: व्यक्तिचलितपणे चालू केली जाऊ नये, तर त्याऐवजी [`write!`] मॅक्रोद्वारेच केली पाहिजे.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// स्वरूपनासाठी कॉन्फिगरेशन.
///
/// एक `Formatter` स्वरूपनाशी संबंधित विविध पर्यायांचे प्रतिनिधित्व करते.
/// वापरकर्ते `स्वरूपन थेट तयार करीत नाहीत;एखाद्याचा बदलता संदर्भ [`Debug`] आणि [`Display`] सारख्या traits स्वरूपनाच्या `fmt` पद्धतीत पाठविला जातो.
///
///
/// `Formatter` शी संवाद साधण्यासाठी आपण स्वरूपनाशी संबंधित विविध पर्याय बदलण्यासाठी विविध पद्धतींना कॉल कराल.
/// उदाहरणार्थ, कृपया खालील `Formatter` वर परिभाषित केलेल्या पद्धतींचे दस्तऐवजीकरण पहा.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// युक्तिवाद हे मूलत: ऑप्टिमाइझ्ड अर्धवट लागू केलेले स्वरूपण कार्य आहे, जे `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result` च्या समतुल्य आहे.

extern "C" {
    type Opaque;
}

/// ही रचना सामान्य "argument" चे प्रतिनिधित्व करते जी एक्सप्रिंटफ फंक्शनच्या कार्येद्वारे घेतली जाते.त्यात दिलेली व्हॅल्यू फॉरमॅट करण्यासाठी फंक्शन असते.
/// कंपाईल वेळी हे सुनिश्चित केले जाते की फंक्शन आणि व्हॅल्यू मध्ये योग्य प्रकार आहेत आणि नंतर या स्ट्रक्टीकचा वापर युक्तिवाद एका प्रकारात अधिकृत करण्यासाठी केला जातो.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// हे फॉरमॅटिंग इन्फ्रास्ट्रक्चरमध्ये indices/counts शी संबंधित फंक्शन पॉईंटरसाठी एकाच स्थिर मूल्याची हमी देते.
//
// लक्षात ठेवा की असे कार्य केलेले कार्य योग्य होणार नाही कारण कार्ये नेहमीच अज्ञात_एडडीआरला सध्याच्या खालच्या एलएलव्हीएम आयआर सह टॅग केले जातात, म्हणून त्यांचा पत्ता एलएलव्हीएमसाठी महत्त्वपूर्ण मानला जात नाही आणि जसे की_साइज कास्ट चुकीची कंपाईल केले जाऊ शकते.
//
// प्रत्यक्ष व्यवहारात आम्ही डेटा नसलेल्या (फॉरमॅटिंग युक्तिवादाच्या स्थिर पिढीची गोष्ट म्हणून) कधीही as_usize म्हणत नाही, म्हणूनच ही फक्त अतिरिक्त तपासणी आहे.
//
// आम्ही प्रामुख्याने हे सुनिश्चित करू इच्छित आहोत की `USIZE_MARKER` मधील फंक्शन पॉईंटरला फंक्शनला * * फक्त * संबंधी पत्ता आहे जो `&usize` ला त्यांचा पहिला युक्तिवाद म्हणून घेईल.
// येथे वाचन_अंतरशील हे सुनिश्चित करते की आम्ही उत्तीर्ण संदर्भामधून एक वापर सुरक्षितपणे तयार करू शकतो आणि हा पत्ता एखाद्या उपयोगात न घेणार्‍या कार्याकडे सूचित करीत नाही.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // सुरक्षा: ptr हा एक संदर्भ आहे
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // सुरक्षा: `mem::transmute(x)` सुरक्षित आहे कारण
        //     1. `&'b T` हे `'b` सह उद्भवलेले आजीवन ठेवते (जेणेकरून अबाधित आजीवन नसावे)
        //     2.
        //     `&'b T` आणि `&'b Opaque` मध्ये समान मेमरी लेआउट आहे (जेव्हा `T` हे `Sized` आहे, जसे की ते येथे आहे) `mem::transmute(f)` सुरक्षित आहे कारण `fn(&T, &mut Formatter<'_>) -> Result` आणि `fn(&Opaque, &mut Formatter<'_>) -> Result` मध्ये समान एबीआय आहे (जोपर्यंत `T` `Sized` आहे तोपर्यंत)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // सुरक्षितता: `formatter` फील्ड फक्त USIZE_MARKER वर सेट केले असल्यास
            // मूल्य एक उपयोगाचे आहे, म्हणून हे सुरक्षित आहे
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// format_args च्या v1 स्वरूपनात ध्वज उपलब्ध आहेत
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// Format_args! () मॅक्रो वापरताना, हे फंक्शन आर्गमेंट्सची रचना तयार करण्यासाठी वापरली जाते.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// हे कार्य नॉन-स्टँडर्ड स्वरूपन मापदंड निर्दिष्ट करण्यासाठी वापरले जाते.
    /// वैध अर्ग्युमेंट्स रचना तयार करण्यासाठी `pieces` अ‍ॅरे किमान `fmt` इतका लांब असणे आवश्यक आहे.
    /// तसेच, `fmt` मधील कोणत्याही `Count` जो एक्स ०3 एक्स किंवा एक्स ०4 एक्स आहे तो `argumentusize` सह तयार केलेल्या वितर्ककडे निर्देशित करा.
    ///
    /// तथापि, असे करण्यात अयशस्वी झाल्यास असुरक्षिततेचे कारण नाही, परंतु त्याकडे दुर्लक्ष केले जाईल.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// स्वरूपित मजकूराची लांबी अंदाजे करते.
    ///
    /// `format!` वापरताना प्रारंभिक `String` क्षमता सेट करण्यासाठी याचा वापर करण्याचा हेतू आहे.
    /// Note: ही खालची किंवा वरची सीमा नाही.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // जर स्वरुपाची स्ट्रिंग एखाद्या युक्तिवादासह प्रारंभ होत असेल तर तुकड्यांची लांबी महत्त्वपूर्ण नसल्यास कोणतीही गोष्ट पूर्वग्रहण करू नका.
            //
            //
            0
        } else {
            // तेथे काही युक्तिवाद आहेत, म्हणून कोणताही अतिरिक्त पुश स्ट्रिंग पुन्हा फिरवेल.
            //
            // ते टाळण्यासाठी, आम्ही येथे क्षमता "pre-doubling" आहोत.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// ही रचना स्वरूप स्ट्रिंग आणि त्याच्या वितर्कांची सुरक्षितपणे प्रीकंपिल्ड केलेली आवृत्ती प्रस्तुत करते.
/// हे रनटाइमवर व्युत्पन्न केले जाऊ शकत नाही कारण ते सुरक्षितपणे केले जाऊ शकत नाही, म्हणून कोणतेही बांधकाम दिले जात नाही आणि बदल रोखण्यासाठी फील्ड खाजगी आहेत.
///
///
/// [`format_args!`] मॅक्रो सुरक्षितपणे या संरचनेचे उदाहरण तयार करेल.
/// मॅक्रो कॉम्पाईल-वेळी फॉर्मेट स्ट्रिंगचे प्रमाणीकरण करते म्हणून [`write()`] आणि [`format()`] फंक्शन्सचा वापर सुरक्षितपणे केला जाऊ शकतो.
///
/// आपण `Arguments<'a>` वापरू शकता जे [`format_args!`] परत `Debug` आणि `Display` संदर्भात परत करते.
/// उदाहरण देखील हे दर्शविते की त्याच गोष्टीचे `Debug` आणि `Display` स्वरूप: `format_args!` मधील इंटरपोलटेड स्वरूपन स्ट्रिंग.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // मुद्रित करण्यासाठी स्ट्रिंगचे तुकडे स्वरूपित करा.
    pieces: &'a [&'static str],

    // प्लेसहोल्डर चष्मा किंवा सर्व चष्मे डीफॉल्ट असल्यास `None` ("{}{}" प्रमाणे).
    fmt: Option<&'a [rt::v1::Argument]>,

    // इंटरपोलेशनसाठी गतीशील वितर्क, स्ट्रिंगच्या तुकड्यांसह इंटरलीवेव्ह करणे.
    // (प्रत्येक युक्तिवादाच्या आधी स्ट्रिंग पीस असतो.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// त्यामध्ये स्वरूपण करण्यासाठी कोणतेही वितर्क नसल्यास स्वरूपित स्ट्रिंग मिळवा.
    ///
    /// सर्वात क्षुल्लक प्रकरणात वाटप टाळण्यासाठी याचा वापर केला जाऊ शकतो.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` प्रोग्रामर-डिबगिंग संदर्भात आउटपुट स्वरूपित केले पाहिजे.
///
/// सामान्यत: , आपण फक्त `derive` एक `Debug` अंमलबजावणी करावी.
///
/// जेव्हा वैकल्पिक स्वरूप निर्दिष्टीकरणकर्ता `#?` सह वापरले जाते तेव्हा आउटपुट सुंदर-मुद्रित केले जाते.
///
/// स्वरूपनकर्त्यांवरील अधिक माहितीसाठी, [the module-level documentation][module] पहा.
///
/// [module]: ../../std/fmt/index.html
///
/// सर्व फील्डने `Debug` कार्यान्वित केल्यास हे trait `#[derive]` सह वापरले जाऊ शकते.
/// जेव्हा स्ट्रक्ट्ससाठी `साधित केले जातात, तेव्हा ते एक्स ०१ एक्स, नंतर एक्स ०२ एक्स, नंतर प्रत्येक फील्डच्या नावाची स्वल्पविरामाने-विभक्त केलेली यादी आणि एक्स ०3 एक्स मूल्य वापरेल, तर एक्स २०० एक्स वापरेल.
/// `एन्युमसाठी, ते व्हेरिएंटचे नाव आणि लागू असल्यास, एक्स ०१ एक्स, नंतर फील्डचे एक्स ०२ एक्स मूल्य वापरेल, तर एक्स X०० एक्स.
///
/// # Stability
///
/// व्युत्पन्न `Debug` स्वरूपने स्थिर नाहीत आणि म्हणूनच future Rust आवृत्त्या बदलू शकतात.
/// याव्यतिरिक्त, मानक लायब्ररीद्वारे प्रदान केलेल्या प्रकारच्या `Debug` अंमलबजावणी (b libstd`, `libcore`, `liballoc`, इ.) स्थिर नाहीत आणि future Rust आवृत्त्यांसह देखील बदलू शकतात.
///
///
/// # Examples
///
/// अंमलबजावणीचे विश्लेषण करीत आहे:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// व्यक्तिचलितपणे अंमलबजावणी:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// एक्स 100 एक्स सारख्या मॅन्युअल अंमलबजावणीसाठी आपल्याला मदत करण्यासाठी एक्स01 एक्स स्ट्रक्चरवर बर्‍याच मदतनीस पद्धती आहेत.
///
/// `Debug` `derive` वर एकतर `derive` किंवा डीबग बिल्डर API वापरणारी अंमलबजावणी वैकल्पिक ध्वजांकडून प्री-प्रिंटिंगला समर्थन देते: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// `#?` सह सुंदर-मुद्रण:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// दिलेल्या स्वरूपकाचा वापर करुन मूल्य स्वरूपित करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// trait `Debug` शिवाय झेडप्रील्यु00 झेड वरून मॅक्रो एक्स ०१ एक्स एक्सपोर्ट करण्यासाठी मॉड्यूल विभक्त करा.
pub(crate) mod macros {
    /// झेडट्रायट0झेड एक्स 100 एक्स ची एक इम्प्लिअल व्युत्पन्न करणार्‍या डेरिव मॅक्रो.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// रिक्त स्वरूपनासाठी trait स्वरूपित करा, `{}`.
///
/// `Display` [`Debug`] प्रमाणेच आहे, परंतु X01 एक्स वापरकर्त्यास सामोरे जाणा output्या आउटपुटसाठी आहे आणि म्हणून काढले जाऊ शकत नाही.
///
///
/// स्वरूपनकर्त्यांवरील अधिक माहितीसाठी, [the module-level documentation][module] पहा.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// एका प्रकारावर `Display` लागू करत आहे:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// दिलेल्या स्वरूपकाचा वापर करुन मूल्य स्वरूपित करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// `Octal` trait ने त्याचे आउटपुट base-8 मधील रूपात स्वरूपित केले पाहिजे.
///
/// आदिम चिन्हांकित पूर्णांकांसाठी (`i8` ते `i128` आणि `isize`), नकारात्मक मूल्ये दोनची पूरक प्रतिनिधित्व म्हणून स्वरूपित केली जातात.
///
///
/// पर्यायी ध्वज, `#`, आउटपुटच्या समोर `0o` जोडेल.
///
/// स्वरूपनकर्त्यांवरील अधिक माहितीसाठी, [the module-level documentation][module] पहा.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` सह मूलभूत वापरः
///
/// ```
/// let x = 42; // ऑक्टलमध्ये 42 हे एक्स 100 एक्स आहे
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// एका प्रकारावर `Octal` लागू करत आहे:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // आय 32 च्या अंमलबजावणीसाठी प्रतिनिधी
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// दिलेल्या स्वरूपकाचा वापर करुन मूल्य स्वरूपित करते.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// `Binary` trait ने त्याचे आउटपुट बायनरीमधील संख्येचे स्वरूपित केले पाहिजे.
///
/// आदिम चिन्हांकित पूर्णांकांसाठी ([`i8`] ते [`i128`] आणि [`isize`]), नकारात्मक मूल्ये दोनची पूरक प्रतिनिधित्व म्हणून स्वरूपित केली जातात.
///
///
/// पर्यायी ध्वज, `#`, आउटपुटच्या समोर `0b` जोडेल.
///
/// स्वरूपनकर्त्यांवरील अधिक माहितीसाठी, [the module-level documentation][module] पहा.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// [`i32`] सह मूलभूत वापरः
///
/// ```
/// let x = 42; // बायनरीमध्ये 42 हे एक्स 100 एक्स आहे
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// एका प्रकारावर `Binary` लागू करत आहे:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // आय 32 च्या अंमलबजावणीसाठी प्रतिनिधी
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// दिलेल्या स्वरूपकाचा वापर करुन मूल्य स्वरूपित करते.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// `LowerHex` trait ने त्याचे उत्पादन हेक्साडेसिमलमध्ये संख्येचे स्वरूपात केले पाहिजे, `a` ते `f` लोअर केसमध्ये.
///
/// आदिम चिन्हांकित पूर्णांकांसाठी (`i8` ते `i128` आणि `isize`), नकारात्मक मूल्ये दोनची पूरक प्रतिनिधित्व म्हणून स्वरूपित केली जातात.
///
///
/// पर्यायी ध्वज, `#`, आउटपुटच्या समोर `0x` जोडेल.
///
/// स्वरूपनकर्त्यांवरील अधिक माहितीसाठी, [the module-level documentation][module] पहा.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` सह मूलभूत वापरः
///
/// ```
/// let x = 42; // हेक्समध्ये 42 हे एक्स 100 एक्स आहे
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// एका प्रकारावर `LowerHex` लागू करत आहे:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // आय 32 च्या अंमलबजावणीसाठी प्रतिनिधी
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// दिलेल्या स्वरूपकाचा वापर करुन मूल्य स्वरूपित करते.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// `UpperHex` trait ने त्याचे आउटपुट हेक्साडेसिमलमध्ये संख्येचे स्वरूपात केले पाहिजे, अप्पर केसमध्ये `A` ते `F` सह.
///
/// आदिम चिन्हांकित पूर्णांकांसाठी (`i8` ते `i128` आणि `isize`), नकारात्मक मूल्ये दोनची पूरक प्रतिनिधित्व म्हणून स्वरूपित केली जातात.
///
///
/// पर्यायी ध्वज, `#`, आउटपुटच्या समोर `0x` जोडेल.
///
/// स्वरूपनकर्त्यांवरील अधिक माहितीसाठी, [the module-level documentation][module] पहा.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` सह मूलभूत वापरः
///
/// ```
/// let x = 42; // हेक्समध्ये 42 हे एक्स 100 एक्स आहे
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// एका प्रकारावर `UpperHex` लागू करत आहे:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // आय 32 च्या अंमलबजावणीसाठी प्रतिनिधी
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// दिलेल्या स्वरूपकाचा वापर करुन मूल्य स्वरूपित करते.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// `Pointer` trait ने त्याचे आउटपुट मेमरी स्थान म्हणून स्वरूपित केले पाहिजे.
/// हे सहसा हेक्साडेसिमल म्हणून सादर केले जाते.
///
/// स्वरूपनकर्त्यांवरील अधिक माहितीसाठी, [the module-level documentation][module] पहा.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `&i32` सह मूलभूत वापरः
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // हे '0x7f06092ac6d0' सारखे काहीतरी तयार करते
/// ```
///
/// एका प्रकारावर `Pointer` लागू करत आहे:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // `*const T` मध्ये रूपांतरित करण्यासाठी `as` वापरा, जे पॉईंटरची अंमलबजावणी करते, जे आम्ही वापरू शकतो
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// दिलेल्या स्वरूपकाचा वापर करुन मूल्य स्वरूपित करते.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// `LowerExp` trait ने त्याचे उत्पादन शास्त्रीय संकेत मध्ये लोअर-केस `e` सह स्वरूपित केले पाहिजे.
///
/// स्वरूपनकर्त्यांवरील अधिक माहितीसाठी, [the module-level documentation][module] पहा.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64` सह मूलभूत वापरः
///
/// ```
/// let x = 42.0; // 42.0 वैज्ञानिक संकेत मध्ये '4.2e1' आहे
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// एका प्रकारावर `LowerExp` लागू करत आहे:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // f64 च्या अंमलबजावणीसाठी प्रतिनिधी
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// दिलेल्या स्वरूपकाचा वापर करुन मूल्य स्वरूपित करते.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// `UpperExp` trait ने त्याचे आउटपुट वैज्ञानिक अपार्टमेंटमध्ये अप्पर-केस `E` सह स्वरूपित केले पाहिजे.
///
/// स्वरूपनकर्त्यांवरील अधिक माहितीसाठी, [the module-level documentation][module] पहा.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64` सह मूलभूत वापरः
///
/// ```
/// let x = 42.0; // 42.0 वैज्ञानिक संकेत मध्ये '4.2E1' आहे
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// एका प्रकारावर `UpperExp` लागू करत आहे:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // f64 च्या अंमलबजावणीसाठी प्रतिनिधी
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// दिलेल्या स्वरूपकाचा वापर करुन मूल्य स्वरूपित करते.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `write` फंक्शन आउटपुट प्रवाह घेते, आणि एक `Arguments` स्ट्रक्चर जे `format_args!` मॅक्रोसह पूर्वनिर्मित केले जाऊ शकते.
///
///
/// प्रदान केलेल्या आउटपुट प्रवाहात निर्दिष्ट स्वरूप स्ट्रिंगनुसार वितर्कांचे स्वरूपन केले जाईल.
///
/// # Examples
///
/// मूलभूत वापर:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// कृपया लक्षात घ्या की [`write!`] वापरणे अधिक श्रेयस्कर आहे.उदाहरणः
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // आम्ही सर्व वितर्कांसाठी डीफॉल्ट स्वरूपन पॅरामीटर्स वापरू शकतो.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // प्रत्येक स्पेकमध्ये संबंधित युक्तिवाद असतो जो स्ट्रिंग पीसच्या आधीचा असतो.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // सुरक्षितता: आर्ग आणि एक्स 100 एक्स समान वितर्कांमधून आले आहेत,
                // जे अनुक्रमणिकेची हमी देते नेहमीच मर्यादेत असतात.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // तेथे फक्त एक ट्रेलिंग स्ट्रिंग पीस बाकी असू शकतो.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // सुरक्षितता: युक्तिवाद आणि युक्तिवाद समान युक्तिवादान्यांमधून प्राप्त होते,
    // जे अनुक्रमणिकेची हमी देते नेहमीच मर्यादेत असतात.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // योग्य वितर्क काढा
    debug_assert!(arg.position < args.len());
    // सुरक्षितता: युक्तिवाद आणि युक्तिवाद समान युक्तिवादान्यांमधून प्राप्त होते,
    // जे त्याच्या निर्देशांकाची हमी देते ते नेहमीच मर्यादेत असते.
    let value = unsafe { args.get_unchecked(arg.position) };

    // मग प्रत्यक्षात काही मुद्रण करा
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // सुरक्षितता: सीएनटी आणि आर्गस समान युक्तिवादान्यांद्वारे येतात,
            // जी या निर्देशांकाची हमी देते ती नेहमीच हद्दीत असते.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// काहीतरी संपल्यानंतर पॅडिंग.`Formatter::padding` ने परत केले.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// हे पोस्ट पॅडिंग लिहा.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // आम्हाला हे बदलायचे आहे
            buf: wrap(self.buf),

            // आणि हे जतन करा
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // पॅडिंग आणि स्वरूपण वितर्क प्रक्रिया करण्यासाठी वापरल्या जाणार्‍या मदतनीस पद्धती जे सर्व traits वापरू शकतात.
    //

    /// पूर्णांकसाठी योग्य पॅडिंग कार्य करते जे आधीपासूनच एक स्ट्रिंग मध्ये उत्सर्जित केले गेले आहे.
    /// स्ट्रिंगमध्ये * पूर्णांक साठी चिन्ह असू नये, ही या पद्धतीने जोडली जाईल.
    ///
    /// # Arguments
    ///
    /// * is_nonnegative, मूळ पूर्णांक एकतर सकारात्मक किंवा शून्य होता.
    /// * उपसर्ग, जर '#' वर्ण (Alternate) प्रदान केला असेल तर, हे संख्या समोर ठेवण्याकरिता उपसर्ग आहे.
    ///
    /// * बफ, बाईट अ‍ॅरे की नंबरमध्ये फॉरमॅट केले गेले आहे
    ///
    /// हे फंक्शन प्रदान केलेल्या ध्वज तसेच किमान रूंदीसाठी योग्यरित्या कार्य करेल.
    /// हे सुस्पष्टता खात्यात घेत नाही.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // आम्हाला नंबर आउटपुटमधून "-" काढण्याची आवश्यकता आहे.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // अस्तित्त्वात असल्यास चिन्ह लिहितात, आणि मग विनंती केली असल्यास उपसर्ग
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // `width` फील्ड याक्षणी `min-width` पॅरामीटरपेक्षा अधिक आहे.
        match self.width {
            // किमान लांबीची आवश्यकता नसल्यास आपण फक्त बाइट लिहू शकतो.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // आम्ही किमान रूंदीपेक्षा जास्त आहोत का ते तपासा, तसे असल्यास आम्ही फक्त बाइट देखील लिहू शकतो.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // भरण वर्ण शून्य असल्यास चिन्ह आणि उपसर्ग पॅडिंगच्या आधी जाईल
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // अन्यथा, चिन्ह आणि उपसर्ग पॅडिंग नंतर जाईल
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// हे कार्य स्ट्रिंग स्लाइस घेते आणि निर्दिष्ट स्वरूपन ध्वजांकन निर्दिष्ट केल्यावर अंतर्गत बफरवर ते उत्साही करते.
    /// जेनेरिक स्ट्रिंगसाठी ओळखले जाणारे ध्वज हे आहेतः
    ///
    /// * रुंदी, काय उत्सर्जन करावे याची किमान रुंदी
    /// * fill/align - जर स्ट्रिंग पॅड करणे आवश्यक असेल तर काय उत्सर्जित करावे आणि कुठे उत्सर्जित करावे
    /// * तंतोतंत, उत्सर्जन करण्यासाठी जास्तीत जास्त लांबी, या लांबीपेक्षा जास्त लांब असल्यास स्ट्रिंग कमी केली जाते
    ///
    /// विशेष म्हणजे हे कार्य `flag` मापदंडांकडे दुर्लक्ष करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // समोर एक वेगवान मार्ग असल्याचे सुनिश्चित करा
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // `precision` फील्डचे रूपण केल्या जाणार्‍या स्ट्रिंगसाठी `max-width` म्हणून भाष्य केले जाऊ शकते.
        //
        let s = if let Some(max) = self.precision {
            // जर आमची स्ट्रिंग सुस्पष्टता यापेक्षा लांब असेल तर आपल्याकडे लहान करणे आवश्यक आहे.
            // तथापि, अन्य ध्वज जसे की `fill`, `width` आणि `align` नेहमीप्रमाणेच कार्य करणे आवश्यक आहे.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // येथे LLVM हे सिद्ध करू शकत नाही की `..i` panic `&s[..i]` करणार नाही, परंतु आम्हाला हे माहित आहे की ते panic करू शकत नाही.
                // `unsafe` टाळण्यासाठी `get` + `unwrap_or` वापरा आणि अन्यथा येथे कोणताही झेडस्पॅनिक 0 झेड संबंधित कोड सोडत नाही.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // `width` फील्ड याक्षणी `min-width` पॅरामीटरपेक्षा अधिक आहे.
        match self.width {
            // जर आपण जास्तीत जास्त लांबीच्या खाली असाल आणि किमान लांबीची आवश्यकता नसेल तर आम्ही फक्त स्ट्रिंग उत्सर्जित करू शकतो
            //
            None => self.buf.write_str(s),
            // जर आपण जास्तीत जास्त रुंदीखाली असाल तर आम्ही किमान रुंदीपेक्षा जास्त आहोत की नाही ते तपासा, ते तजेला फक्त स्ट्रिंग सोडणे इतकेच सोपे आहे.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // जर आम्ही जास्तीत जास्त आणि किमान रुंदीच्या दोन्ही खाली असाल तर निर्दिष्ट स्ट्रिंग + काही संरेखन सह किमान रूंदी भरा.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// प्री-पॅडिंग लिहा आणि अलिखित पोस्ट-पॅडिंग परत करा.
    /// पॅड पॅडिंगनंतर जे काही पॅड केले जात आहे त्या नंतर लिहिलेले आहे याची खात्री करण्यासाठी कॉलर जबाबदार आहेत.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// स्वरूपित भाग घेते आणि पॅडिंग लागू करते.
    /// असे गृहीत धरते की कॉलरने आधीपासूनच आवश्यक परिशुद्धतेसह भाग प्रस्तुत केले आहेत जेणेकरुन एक्स00 एक्सकडे दुर्लक्ष करता येईल.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // चिन्हे-जागरूक शून्य पॅडिंगसाठी, आम्ही प्रथम चिन्ह प्रस्तुत करतो आणि असे दिसते की आमच्याकडे सुरुवातीस काही चिन्ह नाही.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // एक चिन्ह नेहमीच प्रथम राहते
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // स्वरूपित भागातून चिन्ह काढा
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // उर्वरित भाग सामान्य पॅडिंग प्रक्रियेमधून जातात.
            let len = formatted.len();
            let ret = if width <= len {
                // पॅडिंग नाही
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // ही सामान्य बाब आहे आणि आम्ही एक शॉर्टकट घेतो
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // सुरक्षितता: हे `flt2dec::Part::Num` आणि `flt2dec::Part::Copy` साठी वापरले जाते.
            // हे `flt2dec::Part::Num` साठी वापरणे सुरक्षित आहे कारण प्रत्येक चार्ट `c` `b'0'` आणि `b'9'` दरम्यान आहे, म्हणजे `s` वैध UTF-8 आहे.
            // `buf` साधा ASCII असणे आवश्यक असल्याने `flt2dec::Part::Copy(buf)` साठी वापरणे सराव मध्ये कदाचित सुरक्षित देखील आहे, परंतु एखाद्याचे सार्वजनिक कार्य असल्यामुळे `buf` चे खराब मूल्य देऊन एखाद्याला ते शक्य आहे.
            //
            // FIXME: यामुळे यूबी होऊ शकतो की नाही हे ठरवा.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 शून्य
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// या स्वरूपनात अंतर्निहित बफरवर काही डेटा लिहितो.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // हे समतुल्य आहेः
    ///         // लिहा! (स्वरूपन, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// या प्रसंगी काही स्वरूपित माहिती लिहिते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// स्वरूपनासाठी ध्वज
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// संरेखन असते तेव्हा 'fill' म्हणून वापरले जाणारे वर्ण.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // आम्ही ">" सह उजवीकडे संरेखन सेट केले.
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// कोणत्या प्रकारच्या संरेखेची विनंती केली गेली होती ते दर्शविणारे ध्वज.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// आउटपुट असावे वैकल्पिकरित्या निर्दिष्ट पूर्णांक रुंदी.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // जर आम्हाला रूंदी मिळाली तर आम्ही ती वापरतो
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // अन्यथा आम्ही विशेष काही करत नाही
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// संख्यात्मक प्रकारांसाठी वैकल्पिकरित्या निर्दिष्ट अचूकता
    /// वैकल्पिकरित्या, स्ट्रिंग प्रकारांसाठी जास्तीत जास्त रुंदी.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // जर आम्हाला अचूकता मिळाली तर आम्ही ती वापरतो.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // अन्यथा आम्ही डीफॉल्ट 2.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// `+` ध्वज निर्दिष्ट केले असल्यास निश्चित करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// `-` ध्वज निर्दिष्ट केले असल्यास निश्चित करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // आपल्याला वजा चिन्ह पाहिजे आहे?एक आहे!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// `#` ध्वज निर्दिष्ट केले असल्यास निश्चित करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// `0` ध्वज निर्दिष्ट केला असल्यास निश्चित करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // आम्ही स्वरूपकाच्या पर्यायांकडे दुर्लक्ष करतो.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: या दोन ध्वजांसाठी आम्हाला कोणते सार्वजनिक API हवे आहेत ते ठरवा.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// स्ट्रक्ट्ससाठी [`fmt::Debug`] अंमलबजावणीच्या निर्मितीस मदत करण्यासाठी डिझाइन केलेला एक [`DebugStruct`] बिल्डर तयार करतो.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// ट्युपल स्ट्रक्ट्सच्या एक्स01 एक्स कार्यान्वयन निर्मितीस मदत करण्यासाठी डिझाइन केलेला एक एक्स 100 एक्स बिल्डर तयार करतो.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// यादी सारख्या रचनांसाठी `fmt::Debug` अंमलबजावणीच्या निर्मितीस मदत करण्यासाठी डिझाइन केलेला एक `DebugList` बिल्डर तयार करतो.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// सेट-सारख्या रचनांसाठी `fmt::Debug` अंमलबजावणीच्या निर्मितीस मदत करण्यासाठी डिझाइन केलेला एक `DebugSet` बिल्डर तयार करतो.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// या अधिक जटिल उदाहरणामध्ये, आम्ही सामन्याच्या शस्त्रांची सूची तयार करण्यासाठी [`format_args!`] आणि `.debug_set()` वापरतो:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// नकाशासारख्या रचनांसाठी `fmt::Debug` अंमलबजावणीच्या निर्मितीस मदत करण्यासाठी डिझाइन केलेला एक `DebugMap` बिल्डर तयार करतो.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// कोर स्वरूपण traits ची अंमलबजावणी

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // चारला सुटण्याची आवश्यकता असल्यास, आतापर्यंत बॅकलॉग फ्लश करा आणि लिहा, अन्यथा वगळा
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // वैकल्पिक ध्वज हे आधीपासूनच लोअरहेक्सद्वारे विशेष मानले जाते-ते 0x सह उपसर्ग निश्चित करायचे की नाही ते दर्शविते.
        // आम्ही शून्य वाढवायचे की नाही यावर कार्य करण्यासाठी हे वापरतो आणि नंतर उपसर्ग मिळविण्यासाठी ते बिनशर्त सेट करतो.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// विविध कोर प्रकारांसाठी एक्स 100 एक्स ची अंमलबजावणी

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // रेफसेलने परस्पर कर्ज घेतले आहे म्हणून आम्ही त्याचे मूल्य येथे पाहू शकत नाही.
                // त्याऐवजी प्लेसहोल्डर दर्शवा.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// जर आपल्याला येथे चाचण्यांची अपेक्षा असेल तर त्याऐवजी core/tests/fmt.rs फाईलकडे पहा, येथे सर्व rt::Piece रचना तयार करण्यापेक्षा बरेच सोपे आहे.
//
// 0लोकेशन आवश्यक असलेल्यांसाठी, crate testsलोकमध्ये चाचण्या देखील आहेत.