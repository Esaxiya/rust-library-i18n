//! हे ifmt द्वारे वापरले जाणारे अंतर्गत मॉड्यूल आहे!रनटाइमया स्ट्रक्चर्स वेळेच्या अगोदर स्टॅम्पिक अ‍ॅरेला प्रीकंपाइल फॉरमॅट स्ट्रिंग करण्यासाठी उत्सर्जित करतात.
//!
//! या व्याख्या त्यांच्या `ct` समकक्ष सारख्याच आहेत परंतु त्यापेक्षा भिन्न आहेत की या स्थिरपणे वाटप केल्या जाऊ शकतात आणि रनटाइमसाठी थोडीशी अनुकूलित केली जातात
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// स्वरूपण निर्देशाचा भाग म्हणून विनंती केली जाऊ शकणारी संभाव्य संरेखन.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// सामग्री डावी संरेखित केली जावी असा संकेत.
    Left,
    /// सामग्री उजवीकडे संरेखित केली जावी असा संकेत.
    Right,
    /// सामग्री मध्य-संरेखित केली जावी असा संकेत.
    Center,
    /// कोणत्याही संरेखन विनंती केली गेली नाही.
    Unknown,
}

/// [width](https://doc.rust-lang.org/std/fmt/#width) आणि [precision](https://doc.rust-lang.org/std/fmt/#precision) निर्देशकांद्वारे वापरले.
#[derive(Copy, Clone)]
pub enum Count {
    /// शाब्दिक संख्येसह निर्दिष्ट केलेले, मूल्य संचयित करते
    Is(usize),
    /// `$` आणि `*` वाक्यरचना वापरुन निर्दिष्ट केलेले, अनुक्रमणिका `args` मध्ये संचयित करते
    Param(usize),
    /// निर्दिष्ट नाही
    Implied,
}