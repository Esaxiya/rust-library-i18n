//! पूर्णांक आणि फ्लोटिंग पॉईंट क्रमांक स्वरूपन

use crate::fmt;
use crate::mem::MaybeUninit;
use crate::num::flt2dec;
use crate::ops::{Div, Rem, Sub};
use crate::ptr;
use crate::slice;
use crate::str;

#[doc(hidden)]
trait DisplayInt:
    PartialEq + PartialOrd + Div<Output = Self> + Rem<Output = Self> + Sub<Output = Self> + Copy
{
    fn zero() -> Self;
    fn from_u8(u: u8) -> Self;
    fn to_u8(&self) -> u8;
    fn to_u16(&self) -> u16;
    fn to_u32(&self) -> u32;
    fn to_u64(&self) -> u64;
    fn to_u128(&self) -> u128;
}

macro_rules! impl_int {
    ($($t:ident)*) => (
      $(impl DisplayInt for $t {
          fn zero() -> Self { 0 }
          fn from_u8(u: u8) -> Self { u as Self }
          fn to_u8(&self) -> u8 { *self as u8 }
          fn to_u16(&self) -> u16 { *self as u16 }
          fn to_u32(&self) -> u32 { *self as u32 }
          fn to_u64(&self) -> u64 { *self as u64 }
          fn to_u128(&self) -> u128 { *self as u128 }
      })*
    )
}
macro_rules! impl_uint {
    ($($t:ident)*) => (
      $(impl DisplayInt for $t {
          fn zero() -> Self { 0 }
          fn from_u8(u: u8) -> Self { u as Self }
          fn to_u8(&self) -> u8 { *self as u8 }
          fn to_u16(&self) -> u16 { *self as u16 }
          fn to_u32(&self) -> u32 { *self as u32 }
          fn to_u64(&self) -> u64 { *self as u64 }
          fn to_u128(&self) -> u128 { *self as u128 }
      })*
    )
}

impl_int! { i8 i16 i32 i64 i128 isize }
impl_uint! { u8 u16 u32 u64 u128 usize }

/// एक विशिष्ट मूलांक दर्शविणारा प्रकार
#[doc(hidden)]
trait GenericRadix: Sized {
    /// अंकांची संख्या.
    const BASE: u8;

    /// मूलांक-विशिष्ट उपसर्ग स्ट्रिंग.
    const PREFIX: &'static str;

    /// पूर्णांकला संबंधित मूलांक अंकात रूपांतरित करते.
    fn digit(x: u8) -> u8;

    /// फॉरमॅटरचा वापर करून मूलांक वापरुन पूर्णांक स्वरूपित करा.
    fn fmt_int<T: DisplayInt>(&self, mut x: T, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // मूलांक 2 इतके कमी असू शकतो, म्हणून बेस 2 संख्येसाठी आम्हाला किमान 128 वर्णांचा बफर आवश्यक आहे.
        //
        let zero = T::zero();
        let is_nonnegative = x >= zero;
        let mut buf = [MaybeUninit::<u8>::uninit(); 128];
        let mut curr = buf.len();
        let base = T::from_u8(Self::BASE);
        if is_nonnegative {
            // संख्येचे प्रत्येक अंक कमीतकमी महत्त्वपूर्णपासून सर्वात महत्त्वपूर्ण आकृतीपर्यंत एकत्रित करा.
            //
            for byte in buf.iter_mut().rev() {
                let n = x % base; // सद्य स्थान मूल्य मिळवा.
                x = x / base; // संख्या मोजा.
                byte.write(Self::digit(n.to_u8())); // बफरमध्ये अंक साठवा.
                curr -= 1;
                if x == zero {
                    // जमा होण्यासाठी आणखी अंक नाहीत.
                    break;
                };
            }
        } else {
            // वरील प्रमाणेच करा, परंतु दोन च्या पूरक गोष्टींचा हिशेब द्या.
            for byte in buf.iter_mut().rev() {
                let n = zero - (x % base); // सद्य स्थान मूल्य मिळवा.
                x = x / base; // संख्या मोजा.
                byte.write(Self::digit(n.to_u8())); // बफरमध्ये अंक साठवा.
                curr -= 1;
                if x == zero {
                    // जमा होण्यासाठी आणखी अंक नाहीत.
                    break;
                };
            }
        }
        let buf = &buf[curr..];
        // सुरक्षितताः `buf` मधील एकमात्र वर्ण `Self::digit` द्वारे तयार केले गेले आहेत जे गृहित धरले गेले आहेत
        // वैध UTF-8
        let buf = unsafe {
            str::from_utf8_unchecked(slice::from_raw_parts(
                MaybeUninit::slice_as_ptr(buf),
                buf.len(),
            ))
        };
        f.pad_integral(is_nonnegative, Self::PREFIX, buf)
    }
}

/// बायनरी (बेस 2) मूलांक
#[derive(Clone, PartialEq)]
struct Binary;

/// अष्टदल (आधार 8) मूलांक
#[derive(Clone, PartialEq)]
struct Octal;

/// लोटा-केस वर्णांसह स्वरूपित हेक्साडेसिमल (बेस 16) मूलांक
#[derive(Clone, PartialEq)]
struct LowerHex;

/// एक हेक्साडेसिमल (बेस 16) मूलांक, अप्पर-केस वर्णांसह स्वरूपित
#[derive(Clone, PartialEq)]
struct UpperHex;

macro_rules! radix {
    ($T:ident, $base:expr, $prefix:expr, $($x:pat => $conv:expr),+) => {
        impl GenericRadix for $T {
            const BASE: u8 = $base;
            const PREFIX: &'static str = $prefix;
            fn digit(x: u8) -> u8 {
                match x {
                    $($x => $conv,)+
                    x => panic!("number not in the range 0..={}: {}", Self::BASE - 1, x),
                }
            }
        }
    }
}

radix! { Binary,    2, "0b", x @  0 ..=  1 => b'0' + x }
radix! { Octal,     8, "0o", x @  0 ..=  7 => b'0' + x }
radix! { LowerHex, 16, "0x", x @  0 ..=  9 => b'0' + x, x @ 10 ..= 15 => b'a' + (x - 10) }
radix! { UpperHex, 16, "0x", x @  0 ..=  9 => b'0' + x, x @ 10 ..= 15 => b'A' + (x - 10) }

macro_rules! int_base {
    (fmt::$Trait:ident for $T:ident as $U:ident -> $Radix:ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl fmt::$Trait for $T {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                $Radix.fmt_int(*self as $U, f)
            }
        }
    };
}

macro_rules! integer {
    ($Int:ident, $Uint:ident) => {
        int_base! { fmt::Binary   for $Int as $Uint  -> Binary }
        int_base! { fmt::Octal    for $Int as $Uint  -> Octal }
        int_base! { fmt::LowerHex for $Int as $Uint  -> LowerHex }
        int_base! { fmt::UpperHex for $Int as $Uint  -> UpperHex }

        int_base! { fmt::Binary   for $Uint as $Uint -> Binary }
        int_base! { fmt::Octal    for $Uint as $Uint -> Octal }
        int_base! { fmt::LowerHex for $Uint as $Uint -> LowerHex }
        int_base! { fmt::UpperHex for $Uint as $Uint -> UpperHex }
    };
}
integer! { isize, usize }
integer! { i8, u8 }
integer! { i16, u16 }
integer! { i32, u32 }
integer! { i64, u64 }
integer! { i128, u128 }
macro_rules! debug {
    ($($T:ident)*) => {$(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl fmt::Debug for $T {
            #[inline]
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if f.debug_lower_hex() {
                    fmt::LowerHex::fmt(self, f)
                } else if f.debug_upper_hex() {
                    fmt::UpperHex::fmt(self, f)
                } else {
                    fmt::Display::fmt(self, f)
                }
            }
        }
    )*};
}
debug! {
  i8 i16 i32 i64 i128 isize
  u8 u16 u32 u64 u128 usize
}

// 2 अंकी दशांश लुक अप टेबल
static DEC_DIGITS_LUT: &[u8; 200] = b"0001020304050607080910111213141516171819\
      2021222324252627282930313233343536373839\
      4041424344454647484950515253545556575859\
      6061626364656667686970717273747576777879\
      8081828384858687888990919293949596979899";

macro_rules! impl_Display {
    ($($t:ident),* as $u:ident via $conv_fn:ident named $name:ident) => {
        fn $name(mut n: $u, is_nonnegative: bool, f: &mut fmt::Formatter<'_>) -> fmt::Result {
            // 2 ^ 128 सुमारे 3 * 10 ^ 38 आहे, म्हणून 39 जागेचे अतिरिक्त बाइट देते
            let mut buf = [MaybeUninit::<u8>::uninit(); 39];
            let mut curr = buf.len() as isize;
            let buf_ptr = MaybeUninit::slice_as_mut_ptr(&mut buf);
            let lut_ptr = DEC_DIGITS_LUT.as_ptr();

            // सुरक्षितताः `d1` आणि `d2` नेहमीच `198` च्या तुलनेत कमी किंवा त्यासारखे असतात
            // `lut_ptr[d1..d1 + 1]` आणि `lut_ptr[d2..d2 + 1]` वरून कॉपी करू शकता.
            // `buf_ptr` मध्ये कॉपी करणे ठीक आहे हे दर्शविण्यासाठी, `n < 2^128 < 10^39` पासून `curr == buf.len() == 39 > log(n)` सुरूवातीस लक्षात घ्या आणि प्रत्येक चरणात हे `n` प्रमाणेच ठेवले आहे.
            //
            // `n` नेहमी नकारात्मक असतो, याचा अर्थ असा की `curr > 0` म्हणून `buf_ptr[curr..curr + 1]` प्रवेश करणे सुरक्षित आहे.
            //
            //
            unsafe {
                // कार्य करण्यासाठी-अ‍ॅथ-ए-4-वर्णांसाठी कमीतकमी 16 बिट्सची आवश्यकता आहे.
                assert!(crate::mem::size_of::<$u>() >= 2);

                // उत्सुकतेने एका वेळी 4 वर्ण डीकोड करा
                while n >= 10000 {
                    let rem = (n % 10000) as isize;
                    n /= 10000;

                    let d1 = (rem / 100) << 1;
                    let d2 = (rem % 100) << 1;
                    curr -= 4;

                    // अन्यथा `curr < 0` पासून आम्हाला येथे `buf_ptr[curr..curr + 3]` वर कॉपी करण्याची परवानगी आहे.
                    // परंतु नंतर एक्स 0 एक्स एक्स मूलतः कमीत कमी एक्स0 2 एक्स होता जो एक्स 100 एक्स आहे.
                    //
                    ptr::copy_nonoverlapping(lut_ptr.offset(d1), buf_ptr.offset(curr), 2);
                    ptr::copy_nonoverlapping(lut_ptr.offset(d2), buf_ptr.offset(curr + 2), 2);
                }

                // जर आपण येथे पोहोचत असाल तर संख्या <=9999 आहेत, म्हणून जास्तीत जास्त 4 वर्ण लांब
                let mut n = n as isize; // शक्यतो 64 बिट गणित कमी करा

                // आणखी 2 वर्ण डीकोड करा, जर> 2 वर्ण
                if n >= 100 {
                    let d1 = (n % 100) << 1;
                    n /= 100;
                    curr -= 2;
                    ptr::copy_nonoverlapping(lut_ptr.offset(d1), buf_ptr.offset(curr), 2);
                }

                // शेवटचे 1 किंवा 2 वर्ण डीकोड करा
                if n < 10 {
                    curr -= 1;
                    *buf_ptr.offset(curr) = (n as u8) + b'0';
                } else {
                    let d1 = n << 1;
                    curr -= 2;
                    ptr::copy_nonoverlapping(lut_ptr.offset(d1), buf_ptr.offset(curr), 2);
                }
            }

            // सुरक्षितता: `curr`> 0 (आम्ही `buf` पुरेसे मोठे केल्यापासून) आणि सर्व वर्ण वैध आहेत
            // UTF-8 `DEC_DIGITS_LUT` असल्याने
            let buf_slice = unsafe {
                str::from_utf8_unchecked(
                    slice::from_raw_parts(buf_ptr.offset(curr), buf.len() - curr as usize))
            };
            f.pad_integral(is_nonnegative, "", buf_slice)
        }

        $(#[stable(feature = "rust1", since = "1.0.0")]
        impl fmt::Display for $t {
            #[allow(unused_comparisons)]
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                let is_nonnegative = *self >= 0;
                let n = if is_nonnegative {
                    self.$conv_fn()
                } else {
                    // 1 ची बेरीज करून 2 ची पूरक बनवून नकारात्मक संख्याला सकारात्मक मध्ये रुपांतरित करा
                    (!self.$conv_fn()).wrapping_add(1)
                };
                $name(n, is_nonnegative, f)
            }
        })*
    };
}

macro_rules! impl_Exp {
    ($($t:ident),* as $u:ident via $conv_fn:ident named $name:ident) => {
        fn $name(
            mut n: $u,
            is_nonnegative: bool,
            upper: bool,
            f: &mut fmt::Formatter<'_>
        ) -> fmt::Result {
            let (mut n, mut exponent, trailing_zeros, added_precision) = {
                let mut exponent = 0;
                // ट्रेलिंग दशांश शून्य मोजा आणि काढा
                while n % 10 == 0 && n >= 10 {
                    n /= 10;
                    exponent += 1;
                }
                let trailing_zeros = exponent;

                let (added_precision, subtracted_precision) = match f.precision() {
                    Some(fmt_prec) => {
                        // दशांश अंकांची संख्या वजा 1
                        let mut tmp = n;
                        let mut prec = 0;
                        while tmp >= 10 {
                            tmp /= 10;
                            prec += 1;
                        }
                        (fmt_prec.saturating_sub(prec), prec.saturating_sub(fmt_prec))
                    }
                    None => (0,0)
                };
                for _ in 1..subtracted_precision {
                    n/=10;
                    exponent += 1;
                }
                if subtracted_precision != 0 {
                    let rem = n % 10;
                    n /= 10;
                    exponent += 1;
                    // शेवटचा अंक पूर्ण करा
                    if rem >= 5 {
                        n += 1;
                    }
                }
                (n, exponent, trailing_zeros, added_precision)
            };

            // 39 अंक (सर्वात वाईट प्रकरण u128) +.
            // =40 `curr` नेहमी कॉपी केलेल्या अंकांच्या संख्येने कमी होत असल्याने याचा अर्थ असा की `curr >= 0`.
            //
            let mut buf = [MaybeUninit::<u8>::uninit(); 40];
            let mut curr = buf.len() as isize; // बुफसाठी अनुक्रमणिका
            let buf_ptr = MaybeUninit::slice_as_mut_ptr(&mut buf);
            let lut_ptr = DEC_DIGITS_LUT.as_ptr();

            // एका वेळी 2 वर्ण डीकोड करा
            while n >= 100 {
                let d1 = ((n % 100) as isize) << 1;
                curr -= 2;
                // सुरक्षितता: `d1 <= 198`, म्हणून आम्ही `lut_ptr[d1..d1 + 2]` वरून कॉपी करू शकतो
                // `DEC_DIGITS_LUT` त्याची लांबी 200 आहे.
                unsafe {
                    ptr::copy_nonoverlapping(lut_ptr.offset(d1), buf_ptr.offset(curr), 2);
                }
                n /= 100;
                exponent += 2;
            }
            // n म्हणजे <=99, म्हणून जास्तीत जास्त 2 वर्ण लांब
            let mut n = n as isize; // शक्यतो 64 बिट गणित कमी करा
            // दुसर्‍या ते शेवटचे वर्ण डीकोड करा
            if n >= 10 {
                curr -= 1;
                // सुरक्षाः `40 > curr >= 0` पासून सुरक्षित (टिप्पणी पहा)
                unsafe {
                    *buf_ptr.offset(curr) = (n as u8 % 10_u8) + b'0';
                }
                n /= 10;
                exponent += 1;
            }
            // दशांश बिंदू जोडा iff> 1 मॅन्टीसा अंक छापला जाईल
            if exponent != trailing_zeros || added_precision != 0 {
                curr -= 1;
                // सुरक्षा: `40 > curr >= 0` पासून सुरक्षित
                unsafe {
                    *buf_ptr.offset(curr) = b'.';
                }
            }

            // सुरक्षा: `40 > curr >= 0` पासून सुरक्षित
            let buf_slice = unsafe {
                // अंतिम वर्ण डीकोड करा
                curr -= 1;
                *buf_ptr.offset(curr) = (n as u8) + b'0';

                let len = buf.len() - curr as usize;
                slice::from_raw_parts(buf_ptr.offset(curr), len)
            };

            // 'e' (किंवा 'E') आणि सुमारे 2-अंकी घातांक संचयित करते
            let mut exp_buf = [MaybeUninit::<u8>::uninit(); 3];
            let exp_ptr = MaybeUninit::slice_as_mut_ptr(&mut exp_buf);
            // सुरक्षितता: एकतर प्रकरणात, एक्स ०१ एक्स सीमेत आणि एक्स १००० एक्स मध्ये लिहिलेले आहे
            // `len <= 3` पासून `exp_buf` मध्ये समाविष्ट आहे.
            let exp_slice = unsafe {
                *exp_ptr.offset(0) = if upper {b'E'} else {b'e'};
                let len = if exponent < 10 {
                    *exp_ptr.offset(1) = (exponent as u8) + b'0';
                    2
                } else {
                    let off = exponent << 1;
                    ptr::copy_nonoverlapping(lut_ptr.offset(off), exp_ptr.offset(1), 2);
                    3
                };
                slice::from_raw_parts(exp_ptr, len)
            };

            let parts = &[
                flt2dec::Part::Copy(buf_slice),
                flt2dec::Part::Zero(added_precision),
                flt2dec::Part::Copy(exp_slice)
            ];
            let sign = if !is_nonnegative {
                "-"
            } else if f.sign_plus() {
                "+"
            } else {
                ""
            };
            let formatted = flt2dec::Formatted{sign, parts};
            f.pad_formatted_parts(&formatted)
        }

        $(
            #[stable(feature = "integer_exp_format", since = "1.42.0")]
            impl fmt::LowerExp for $t {
                #[allow(unused_comparisons)]
                fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                    let is_nonnegative = *self >= 0;
                    let n = if is_nonnegative {
                        self.$conv_fn()
                    } else {
                        // 1 ची बेरीज करून 2 ची पूरक बनवून नकारात्मक संख्याला सकारात्मक मध्ये रुपांतरित करा
                        (!self.$conv_fn()).wrapping_add(1)
                    };
                    $name(n, is_nonnegative, false, f)
                }
            })*
        $(
            #[stable(feature = "integer_exp_format", since = "1.42.0")]
            impl fmt::UpperExp for $t {
                #[allow(unused_comparisons)]
                fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                    let is_nonnegative = *self >= 0;
                    let n = if is_nonnegative {
                        self.$conv_fn()
                    } else {
                        // 1 ची बेरीज करून 2 ची पूरक बनवून नकारात्मक संख्याला सकारात्मक मध्ये रुपांतरित करा
                        (!self.$conv_fn()).wrapping_add(1)
                    };
                    $name(n, is_nonnegative, true, f)
                }
            })*
    };
}

// येथे एक्स00 एक्स समाविष्ट करा कारण ते मूळ पॉईंटर आकार प्रतिबिंबित करत नाही आणि बर्‍याचदा लहान कोड आकार घेण्याची जोरदार काळजी घेतो.
//
#[cfg(any(target_pointer_width = "64", target_arch = "wasm32"))]
mod imp {
    use super::*;
    impl_Display!(
        i8, u8, i16, u16, i32, u32, i64, u64, usize, isize
            as u64 via to_u64 named fmt_u64
    );
    impl_Exp!(
        i8, u8, i16, u16, i32, u32, i64, u64, usize, isize
            as u64 via to_u64 named exp_u64
    );
}

#[cfg(not(any(target_pointer_width = "64", target_arch = "wasm32")))]
mod imp {
    use super::*;
    impl_Display!(i8, u8, i16, u16, i32, u32, isize, usize as u32 via to_u32 named fmt_u32);
    impl_Display!(i64, u64 as u64 via to_u64 named fmt_u64);
    impl_Exp!(i8, u8, i16, u16, i32, u32, isize, usize as u32 via to_u32 named exp_u32);
    impl_Exp!(i64, u64 as u64 via to_u64 named exp_u64);
}
impl_Exp!(i128, u128 as u128 via to_u128 named exp_u128);

/// `buf` मध्ये u64 लिहिण्यासाठी सहाय्यक कार्य, `curr` सह, शेवटच्या पासून प्रथम पर्यंत.
fn parse_u64_into<const N: usize>(mut n: u64, buf: &mut [MaybeUninit<u8>; N], curr: &mut isize) {
    let buf_ptr = MaybeUninit::slice_as_mut_ptr(buf);
    let lut_ptr = DEC_DIGITS_LUT.as_ptr();
    assert!(*curr > 19);

    // SAFETY:
    // बफरमध्ये जास्तीत जास्त 19 वर्ण लिहितात.हमी दिलेली कोणतीही पीटीआर सर्वात जास्त आहे
    // 198, म्हणून कधीच ओओबी होणार नाही.
    // वर एक धनादेश आहे की तेथे किमान 19 वर्ण शिल्लक आहेत.
    unsafe {
        if n >= 1e16 as u64 {
            let to_parse = n % 1e16 as u64;
            n /= 1e16 as u64;

            // यातील काही नाप्स आहेत परंतु हे या प्रकारे अधिक मोहक दिसत आहेत.
            let d1 = ((to_parse / 1e14 as u64) % 100) << 1;
            let d2 = ((to_parse / 1e12 as u64) % 100) << 1;
            let d3 = ((to_parse / 1e10 as u64) % 100) << 1;
            let d4 = ((to_parse / 1e8 as u64) % 100) << 1;
            let d5 = ((to_parse / 1e6 as u64) % 100) << 1;
            let d6 = ((to_parse / 1e4 as u64) % 100) << 1;
            let d7 = ((to_parse / 1e2 as u64) % 100) << 1;
            let d8 = ((to_parse / 1e0 as u64) % 100) << 1;

            *curr -= 16;

            ptr::copy_nonoverlapping(lut_ptr.offset(d1 as isize), buf_ptr.offset(*curr + 0), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d2 as isize), buf_ptr.offset(*curr + 2), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d3 as isize), buf_ptr.offset(*curr + 4), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d4 as isize), buf_ptr.offset(*curr + 6), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d5 as isize), buf_ptr.offset(*curr + 8), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d6 as isize), buf_ptr.offset(*curr + 10), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d7 as isize), buf_ptr.offset(*curr + 12), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d8 as isize), buf_ptr.offset(*curr + 14), 2);
        }
        if n >= 1e8 as u64 {
            let to_parse = n % 1e8 as u64;
            n /= 1e8 as u64;

            // यातील काही नाप्स आहेत परंतु हे या प्रकारे अधिक मोहक दिसत आहेत.
            let d1 = ((to_parse / 1e6 as u64) % 100) << 1;
            let d2 = ((to_parse / 1e4 as u64) % 100) << 1;
            let d3 = ((to_parse / 1e2 as u64) % 100) << 1;
            let d4 = ((to_parse / 1e0 as u64) % 100) << 1;
            *curr -= 8;

            ptr::copy_nonoverlapping(lut_ptr.offset(d1 as isize), buf_ptr.offset(*curr + 0), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d2 as isize), buf_ptr.offset(*curr + 2), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d3 as isize), buf_ptr.offset(*curr + 4), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d4 as isize), buf_ptr.offset(*curr + 6), 2);
        }
        // `n` <1e8 <(1 << 32)
        let mut n = n as u32;
        if n >= 1e4 as u32 {
            let to_parse = n % 1e4 as u32;
            n /= 1e4 as u32;

            let d1 = (to_parse / 100) << 1;
            let d2 = (to_parse % 100) << 1;
            *curr -= 4;

            ptr::copy_nonoverlapping(lut_ptr.offset(d1 as isize), buf_ptr.offset(*curr + 0), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d2 as isize), buf_ptr.offset(*curr + 2), 2);
        }

        // `n` <1e4 <(1 << 16)
        let mut n = n as u16;
        if n >= 100 {
            let d1 = (n % 100) << 1;
            n /= 100;
            *curr -= 2;
            ptr::copy_nonoverlapping(lut_ptr.offset(d1 as isize), buf_ptr.offset(*curr), 2);
        }

        // शेवटचे 1 किंवा 2 वर्ण डीकोड करा
        if n < 10 {
            *curr -= 1;
            *buf_ptr.offset(*curr) = (n as u8) + b'0';
        } else {
            let d1 = n << 1;
            *curr -= 2;
            ptr::copy_nonoverlapping(lut_ptr.offset(d1 as isize), buf_ptr.offset(*curr), 2);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for u128 {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt_u128(*self, true, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for i128 {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let is_nonnegative = *self >= 0;
        let n = if is_nonnegative {
            self.to_u128()
        } else {
            // 1 ची बेरीज करून 2 ची पूरक बनवून नकारात्मक संख्याला सकारात्मक मध्ये रुपांतरित करा
            (!self.to_u128()).wrapping_add(1)
        };
        fmt_u128(n, is_nonnegative, f)
    }
}

/// U128 साठी खास ऑप्टिमायझेशन.
/// एकावेळी दोन वस्तू घेण्याऐवजी, ते जास्तीत जास्त 2 u64 मध्ये विभाजित होते आणि नंतर 10e16, 10e8, 10e4, 10e2 आणि नंतर 10e1 ने विभाजित होते.
/// हे 10 ^ 40> 2 ^ 128> 10 ^ 39 म्हणून 1 शेवटचे आयटम देखील हाताळेल
/// 10 ^ 20> 2 ^ 64> 10 ^ 19.
fn fmt_u128(n: u128, is_nonnegative: bool, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    // 2 ^ 128 सुमारे 3 * 10 ^ 38 आहे, म्हणून 39 जागेचे अतिरिक्त बाइट देते
    let mut buf = [MaybeUninit::<u8>::uninit(); 39];
    let mut curr = buf.len() as isize;

    let (n, rem) = udiv_1e19(n);
    parse_u64_into(rem, &mut buf, &mut curr);

    if n != 0 {
        // 0 पॅड पर्यंत बिंदू
        let target = (buf.len() - 19) as isize;
        // सुरक्षाः आम्ही हमी दिले की आम्ही बर्‍याच १ tes बाइट लिहिल्या आहेत, आणि तेथे जागा असणे आवश्यक आहे
        // 39 ची लांबी असल्याने उर्वरित
        unsafe {
            ptr::write_bytes(
                MaybeUninit::slice_as_mut_ptr(&mut buf).offset(target),
                b'0',
                (curr - target) as usize,
            );
        }
        curr = target;

        let (n, rem) = udiv_1e19(n);
        parse_u64_into(rem, &mut buf, &mut curr);
        // हे खालीलप्रमाणे branch संभाव्यतेसह भाष्य केले पाहिजे?
        if n != 0 {
            let target = (buf.len() - 38) as isize;
            // पुढील वेळी `buf` चा वापर होईपर्यंत कच्चा `buf_ptr` पॉईंटर वैध असतो, buf `buf` या व्याप्तीत वापरला जात नाही म्हणून आम्ही चांगले आहोत.
            //
            let buf_ptr = MaybeUninit::slice_as_mut_ptr(&mut buf);
            // सुरक्षाः या टप्प्यावर आम्ही कमाल 38 बाइट लिहिल्या, त्या टप्प्यापर्यंत पॅड करा,
            // तेथे जास्तीत जास्त 1 अंक शिल्लक असू शकतात.
            unsafe {
                ptr::write_bytes(buf_ptr.offset(target), b'0', (curr - target) as usize);
                curr = target - 1;
                *buf_ptr.offset(curr) = (n as u8) + b'0';
            }
        }
    }

    // सुरक्षितता: `curr`> 0 (आम्ही `buf` पुरेसे मोठे केल्यापासून) आणि सर्व वर्ण वैध आहेत
    // UTF-8 `DEC_DIGITS_LUT` असल्याने
    let buf_slice = unsafe {
        str::from_utf8_unchecked(slice::from_raw_parts(
            MaybeUninit::slice_as_mut_ptr(&mut buf).offset(curr),
            buf.len() - curr as usize,
        ))
    };
    f.pad_integral(is_nonnegative, "", buf_slice)
}

/// एन> 1 ई 19 आणि री <=1e19 मध्ये `n` चे विभाजन
///
/// पूर्णांक विभाग अल्गोरिदम खालील कागदावर आधारित आहेत:
///
///   टी. ग्रॅनलुंड आणि पी.
///   मॉन्टगोमेरी, प्रॉक्समधील `इनव्हिएरंट इंटिगर्स वापरत गुणाकार वापरुन विभाग`.
///   प्रोग्रामिंग भाषा डिझाईन आणि अंमलबजावणीवरील एक्स-00 एक्स कॉन्फरन्सेशन, 1994 चे पीपी.
///   61–72
fn udiv_1e19(n: u128) -> (u128, u64) {
    const DIV: u64 = 1e19 as u64;
    const FACTOR: u128 = 156927543384667019095894735580191660403;

    let quot = if n < 1 << 83 {
        ((n >> 19) as u64 / (DIV >> 19)) as u128
    } else {
        u128_mulhi(n, FACTOR) >> 62
    };

    let rem = (n - quot * DIV as u128) as u64;
    (quot, rem)
}

/// स्वाक्षरी न केलेले १२ bit बिट पूर्णांक गुणाकार करा, निकालाचे वरचे १२8 बिट्स परत करा
#[inline]
fn u128_mulhi(x: u128, y: u128) -> u128 {
    let x_lo = x as u64;
    let x_hi = (x >> 64) as u64;
    let y_lo = y as u64;
    let y_hi = (y >> 64) as u64;

    // ओव्हरफ्लो होण्याची शक्यता हाताळा
    let carry = (x_lo as u128 * y_lo as u128) >> 64;
    let m = x_lo as u128 * y_hi as u128 + carry;
    let high1 = m >> 64;

    let m_lo = m as u64;
    let high2 = (x_hi as u128 * y_lo as u128 + m_lo as u128) >> 64;

    x_hi as u128 * y_hi as u128 + high1 + high2
}