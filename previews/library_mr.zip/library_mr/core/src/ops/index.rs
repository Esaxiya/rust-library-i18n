/// निर्विकार संदर्भात क्रियांच्या (`container[index]`) अनुक्रमित करण्यासाठी वापरले जाते.
///
/// `container[index]` खरं तर `*container.index(index)` साठी सिंटॅक्टिक साखर आहे, परंतु केवळ अमर मूल्य म्हणून वापरली जाते.
/// जर परिवर्तनीय मूल्याची विनंती केली गेली असेल तर त्याऐवजी [`IndexMut`] वापरले जाईल.
/// हे `value` चा प्रकार [`Copy`] लागू केल्यास `let value = v[index]` सारख्या चांगल्या गोष्टींना अनुमती देते.
///
/// # Examples
///
/// खालील उदाहरणांमध्ये केवळ-वाचनाच्या `NucleotideCount` कंटेनरवर `Index` लागू होते, इंडेक्स वाक्यरचनासह वैयक्तिक गणना पुनर्प्राप्त करण्यास सक्षम करते.
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// अनुक्रमणिका नंतर परत आलेला प्रकार.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// अनुक्रमणिका (`container[index]`) ऑपरेशन करते.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// परिवर्तनीय संदर्भात क्रियांच्या (`container[index]`) अनुक्रमित करण्यासाठी वापरले जाते.
///
/// `container[index]` प्रत्यक्षात `*container.index_mut(index)` साठी कृत्रिम साखर आहे, परंतु केवळ जेव्हा परिवर्तनीय मूल्य म्हणून वापरली जाते.
/// जर एखाद्या परिवर्तनीय मूल्याची विनंती केली गेली तर त्याऐवजी [`Index`] trait वापरली जाईल.
/// हे `v[index] = value` सारख्या छान गोष्टींना अनुमती देते.
///
/// # Examples
///
/// दोन बाजू असलेल्या `Balance` स्ट्रक्चरची अगदी सोपी अंमलबजावणी, जिथे प्रत्येकाला परस्पर आणि निर्विकार अनुक्रमित केले जाऊ शकते.
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // या प्रकरणात, `balance[Side::Right]` हे `*balance.index(Side::Right)` साठी साखर आहे, कारण आम्ही केवळ*`balance[Side::Right]` वाचत आहोत, ते लिहित नाही.
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // तथापि, या प्रकरणात `balance[Side::Left]` हे `*balance.index_mut(Side::Left)` साठी साखर आहे, कारण आम्ही `balance[Side::Left]` लिहित आहोत.
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// बदलण्यायोग्य अनुक्रमणिका (`container[index]`) ऑपरेशन करते.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}