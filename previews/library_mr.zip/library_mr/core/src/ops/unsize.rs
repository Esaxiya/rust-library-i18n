use crate::marker::Unsize;

/// Trait जे दर्शविते की हे पॉईंटर आहे किंवा एखाद्यासाठी रॅपर आहे, जेथे पॉईंटवर अनसाइजिंग केले जाऊ शकते.
///
/// अधिक तपशीलांसाठी [DST coercion RFC][dst-coerce] आणि [the nomicon entry on coercion][nomicon-coerce] पहा.
///
/// बिल्टिन पॉईंटर प्रकारांसाठी, `T` चे पॉईंटर्स `T: Unsize<U>` वर पॉइंटर्सला भाग पाडेल जर `T: Unsize<U>` पातळ पॉइंटरमधून फॅट पॉइंटरमध्ये रुपांतरित करते.
///
/// सानुकूल प्रकारांसाठी, X102 ते `Foo<U>` ला जबरदस्तीने बळजबरी करुन येथे बळजबरी करते.
/// `Foo<T>` मध्ये फक्त एक एकमेव नॉन-फॅन्टोमडाटा फील्ड असल्यास अशा प्रकारच्या ईएमएल लिहिणे शक्य आहे `T`.
/// त्या क्षेत्राचा प्रकार `Bar<T>` असल्यास, `CoerceUnsized<Bar<U>> for Bar<T>` ची अंमलबजावणी विद्यमान असणे आवश्यक आहे.
/// `Bar<T>` फील्डला `Bar<U>` मध्ये जबरदस्तीने बनवून आणि `Foo<U>` तयार करण्यासाठी `Foo<T>` मधील उर्वरित फील्ड भरून जबरदस्ती कार्य करेल.
/// हे पॉईंटर फील्डमध्ये प्रभावीपणे ड्रिल करेल आणि सक्ती करेल.
///
/// सामान्यत: स्मार्ट पॉईंटर्ससाठी आपण एक्स 100 एक्स लागू कराल, `T` वरच वैकल्पिक `?Sized` लागू करा.
/// `T` जसे की `T` आणि `RefCell<T>` थेट एम्बेड केलेल्या रॅपर प्रकारांसाठी आपण थेट `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` लागू करू शकता.
///
/// हे `Cell<Box<T>>` सारख्या प्रकारच्या सक्तीने कार्य करू देते.
///
/// [`Unsize`][unsize] प्रकार चिन्हांकित करण्यासाठी वापरले जाते जे पॉईंटर्सच्या मागे असल्यास डीएसटी वर सक्ती केले जाऊ शकतात.हे कंपाईलरद्वारे स्वयंचलितपणे अंमलात आणले जाते.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut टी-> एक्स00 एक्स यू
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut टी-> एक्स 100 एक्स
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut टी-> * मट यू
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut टी-> * कॉन्स्ट यू
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * कॉन्स्ट यू
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *मट टी->* मट यू
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *मट टी->* कॉन्स्ट यू
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *कॉन्स्ट टी->* कॉन्स्ट यू
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// याचा उपयोग ऑब्जेक्टच्या सुरक्षिततेसाठी केला जातो, यासाठी की मेथडचा रिसीव्हर प्रकार पाठविला जाऊ शकतो.
///
/// trait ची अंमलबजावणी:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut टी-> एक्स00 एक्स यू
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *कॉन्स्ट टी->* कॉन्स्ट यू
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *मट टी->* मट यू
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}