/// `*v` सारख्या, निर्विकार डीरेफरेन्सिंग ऑपरेशनसाठी वापरले जाते.
///
/// अपरिवर्तनीय संदर्भात एक्स ०१ एक्स एक्स ०२ एक्स ऑपरेटरसह स्पष्टपणे डेरेफरेन्सिंग ऑपरेशन्ससाठी वापरण्याव्यतिरिक्त, कम्पाइलरद्वारे बर्‍याच परिस्थितींमध्ये एक्स 00 एक्स देखील सुस्पष्टपणे वापरला जातो.
/// या यंत्रणेला ['`Deref` coercion'][more] म्हणतात.
/// परिवर्तनीय संदर्भात, [`DerefMut`] वापरला जातो.
///
/// स्मार्ट पॉईंटर्ससाठी एक्स01 एक्सची अंमलबजावणी करणे त्यांच्यामागील डेटामध्ये प्रवेश करणे सोयीस्कर करते, म्हणूनच ते एक्स 100 एक्स लागू करतात.
/// दुसरीकडे, `Deref` आणि [`DerefMut`] संबंधी नियम स्मार्ट पॉईंटर्ससाठी विशेषतः तयार केले गेले होते.
/// यामुळे, गोंधळ टाळण्यासाठी **डेरेफ केवळ स्मार्ट पॉईंटर्स** साठी लागू केले जावे.
///
/// तत्सम कारणास्तव,**हे झेडट्रेट 0 झेड कधीही* अयशस्वी होऊ नये.डिरेफरन्सींग दरम्यान अयशस्वी होणे अत्यंत गोंधळात टाकणारे असू शकते जेव्हा एक्स 100 एक्स अंतर्भूतपणे विनंती केली जाते.
///
/// # `Deref` जबरदस्तीवर अधिक
///
/// जर `T` `Deref<Target = U>` ची अंमलबजावणी करीत असेल आणि `x` हे `T` प्रकाराचे मूल्य असेल तर:
///
/// * अपरिवर्तनीय संदर्भात, `*x` (जिथे `T` हा संदर्भ नाही किंवा कच्चा सूचक देखील नाही) हे `* Deref::deref(&x)` च्या समतुल्य आहे.
/// * `&T` प्रकारची मूल्ये `&U` प्रकारच्या मूल्यांवर भाग पाडली जातात
/// * `T` `U` प्रकारच्या सर्व (immutable) पद्धती सुस्पष्टपणे लागू करतात.
///
/// अधिक तपशीलांसाठी [the chapter in *The Rust Programming Language*][book] तसेच [the dereference operator][ref-deref-op], [method resolution] आणि [type coercions] वरील संदर्भ विभागांना भेट द्या.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// स्ट्रक्चा डिरेफरन्स करून एकल फिल्डसह एक स्ट्रक्चर.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// डीरेफरेन्सिंग नंतर परिणामी प्रकार.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// मूल्य संदर्भात.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// `*v = 1;` प्रमाणेच बदल करण्यायोग्य डीरेफरेन्सिंग ऑपरेशनसाठी वापरले जाते.
///
/// बदलण्यायोग्य संदर्भांमध्ये एक्स ०१ एक्स एक्स ०२ एक्स ऑपरेटरसह स्पष्टपणे डेरेफरेन्सिंग ऑपरेशन्ससाठी वापरण्याव्यतिरिक्त, कम्पाइलरने बर्‍याच परिस्थितींमध्ये सुस्पष्टपणे `DerefMut` देखील वापरले आहे.
/// या यंत्रणेला ['`Deref` coercion'][more] म्हणतात.
/// अपरिवर्तनीय संदर्भात, [`Deref`] वापरला जातो.
///
/// स्मार्ट पॉइंटर्ससाठी एक्स01 एक्सची अंमलबजावणी करणे त्यांच्यामागील डेटा बदलणे सोयीस्कर करते, म्हणूनच ते एक्स 100 एक्स लागू करतात.
/// दुसरीकडे, [`Deref`] आणि `DerefMut` संबंधित नियम स्मार्ट पॉईंटर्ससाठी विशेषतः तयार केले गेले होते.
/// यामुळे, गोंधळ होऊ नये म्हणून **re डेरेफ्यूट केवळ स्मार्ट पॉईंटर्स** साठी लागू केले जावे.
///
/// तत्सम कारणास्तव,**हे झेडट्रेट 0 झेड कधीही* अयशस्वी होऊ नये.डिरेफरन्सींग दरम्यान अयशस्वी होणे अत्यंत गोंधळात टाकणारे असू शकते जेव्हा एक्स 100 एक्स अंतर्भूतपणे विनंती केली जाते.
///
/// # `Deref` जबरदस्तीवर अधिक
///
/// जर `T` `DerefMut<Target = U>` ची अंमलबजावणी करीत असेल आणि `x` हे `T` प्रकाराचे मूल्य असेल तर:
///
/// * बदलण्यायोग्य संदर्भांमध्ये, एक्स ०१ एक्स (जिथे एक्स0२ एक्स संदर्भ किंवा कच्चा सूचक नाही) एक्स १००० एक्स समतुल्य आहे.
/// * `&mut T` प्रकारची मूल्ये `&mut U` प्रकारच्या मूल्यांवर भाग पाडली जातात
/// * `T` `U` प्रकारच्या सर्व (mutable) पद्धती सुस्पष्टपणे लागू करतात.
///
/// अधिक तपशीलांसाठी [the chapter in *The Rust Programming Language*][book] तसेच [the dereference operator][ref-deref-op], [method resolution] आणि [type coercions] वरील संदर्भ विभागांना भेट द्या.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// स्ट्रक्चा डिरेफरन्स करून बदल करता येण्याजोग्या एकाच फील्डसह स्ट्रक्चर.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// मूल्य रूपांतरण.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// `arbitrary_self_types` वैशिष्ट्याशिवाय स्ट्रक्चर मेथड रिसीव्हर म्हणून वापरली जाऊ शकते हे दर्शविते.
///
/// हे एक्सटीएक्स एक्स एक्स एक्स एक्स एक्स एक्स एक्स एक्स एक्स एक्स एक्स एक्स एक्स एक्स एक्स एक्स एक्स एक्स एक्स स्टडीब पॉईंटर प्रकारांद्वारे लागू केले गेले आहे.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}