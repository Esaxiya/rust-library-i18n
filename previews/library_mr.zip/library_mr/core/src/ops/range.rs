use crate::fmt;
use crate::hash::Hash;

/// अनबाउंड श्रेणी (`..`).
///
/// `RangeFull` प्रामुख्याने [slicing index] म्हणून वापरला जातो, त्याचा शॉर्टहँड `..` आहे.
/// हे [`Iterator`] म्हणून कार्य करू शकत नाही कारण त्यात प्रारंभिक बिंदू नाही.
///
/// # Examples
///
/// `..` वाक्यरचना एक `RangeFull` आहे:
///
/// ```
/// assert_eq!((..), std::ops::RangeFull);
/// ```
///
/// यात [`IntoIterator`] अंमलबजावणी नाही, म्हणून आपण ते थेट `for` लूपमध्ये वापरू शकत नाही.
/// हे संकलित करणार नाही:
///
/// ```compile_fail,E0277
/// for i in .. {
///     // ...
/// }
/// ```
///
/// [slicing index] म्हणून वापरलेले, `RangeFull` स्लाइस म्हणून पूर्ण अ‍ॅरे तयार करते.
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]); // हे एक्स 100 एक्स आहे
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeFull"]
#[doc(alias = "..")]
#[derive(Copy, Clone, Default, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFull;

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for RangeFull {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")
    }
}

/// एक (half-open) श्रेणी खाली आणि केवळ (`start..end`) च्या वर मर्यादित आहे.
///
///
/// `start..end` श्रेणीमध्ये `start <= x < end` सह सर्व मूल्ये आहेत.
/// हे `start >= end` असल्यास रिक्त आहे.
///
/// # Examples
///
/// `start..end` वाक्यरचना एक `Range` आहे:
///
/// ```
/// assert_eq!((3..5), std::ops::Range { start: 3, end: 5 });
/// assert_eq!(3 + 4 + 5, (3..6).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]); // हे एक `Range` आहे
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
#[lang = "Range"]
#[doc(alias = "..")]
#[derive(Clone, Default, PartialEq, Eq, Hash)] // कॉपी नाही-#27186 पहा
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Range<Idx> {
    /// श्रेणी (inclusive) ची खालची सीमा.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
    /// श्रेणी (exclusive) ची वरची सीमा.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for Range<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> Range<Idx> {
    /// `item` श्रेणीमध्ये असल्यास `true` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).contains(&2));
    /// assert!( (3..5).contains(&3));
    /// assert!( (3..5).contains(&4));
    /// assert!(!(3..5).contains(&5));
    ///
    /// assert!(!(3..3).contains(&3));
    /// assert!(!(3..2).contains(&3));
    ///
    /// assert!( (0.0..1.0).contains(&0.5));
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// श्रेणीमध्ये कोणतेही आयटम नसल्यास `true` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).is_empty());
    /// assert!( (3..3).is_empty());
    /// assert!( (3..2).is_empty());
    /// ```
    ///
    /// दोन्ही बाजू अतुलनीय असल्यास श्रेणी रिक्त आहे:
    ///
    /// ```
    /// assert!(!(3.0..5.0).is_empty());
    /// assert!( (3.0..f32::NAN).is_empty());
    /// assert!( (f32::NAN..5.0).is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    pub fn is_empty(&self) -> bool {
        !(self.start < self.end)
    }
}

/// श्रेणी केवळ (`start..`) च्या खाली समाविष्ठ आहे.
///
/// `RangeFrom` `start..` मध्ये `x >= start` सह सर्व मूल्ये आहेत.
///
/// *टीप*: [`Iterator`] अंमलबजावणीमध्ये ओव्हरफ्लो (जेव्हा समाविष्टीत डेटा प्रकार त्याच्या अंकीय मर्यादेपर्यंत पोहोचेल) panic, लपेटणे किंवा संतृप्त करण्यास अनुमती आहे.
/// हे वर्तन [`Step`] trait च्या अंमलबजावणीद्वारे परिभाषित केले गेले आहे.
/// आदिम पूर्णांकरिता, हे सामान्य नियमांचे पालन करते आणि ओव्हरफ्लो चेक प्रोफाइलचा आदर करते (डीबगमध्ये झेडस्पॅनिक ० झेड, रिलिझमध्ये लपेटणे).
/// हे देखील लक्षात घ्या की ओव्हरफ्लो आपण असे गृहीत धरण्याआधीच होतेः ओव्हरफ्लो `next` ला कॉलमध्ये होते जे जास्तीत जास्त मूल्य देते, कारण पुढील मूल्य मिळविण्यासाठी श्रेणी सेट करणे आवश्यक आहे.
///
///
/// [`Step`]: crate::iter::Step
///
/// # Examples
///
/// `start..` वाक्यरचना एक `RangeFrom` आहे:
///
/// ```
/// assert_eq!((2..), std::ops::RangeFrom { start: 2 });
/// assert_eq!(2 + 3 + 4, (2..).take(3).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]); // हे एक `RangeFrom` आहे
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
///
///
#[lang = "RangeFrom"]
#[doc(alias = "..")]
#[derive(Clone, PartialEq, Eq, Hash)] // कॉपी नाही-#27186 पहा
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFrom<Idx> {
    /// श्रेणी (inclusive) ची खालची सीमा.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeFrom<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeFrom<Idx> {
    /// `item` श्रेणीमध्ये असल्यास `true` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..).contains(&2));
    /// assert!( (3..).contains(&3));
    /// assert!( (3..).contains(&1_000_000_000));
    ///
    /// assert!( (0.0..).contains(&0.5));
    /// assert!(!(0.0..).contains(&f32::NAN));
    /// assert!(!(f32::NAN..).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// श्रेणी केवळ (`..end`) च्या वरच मर्यादित आहे.
///
/// `RangeTo` `..end` मध्ये `x < end` सह सर्व मूल्ये आहेत.
/// हे [`Iterator`] म्हणून कार्य करू शकत नाही कारण त्यात प्रारंभिक बिंदू नाही.
///
/// # Examples
///
/// `..end` वाक्यरचना एक `RangeTo` आहे:
///
/// ```
/// assert_eq!((..5), std::ops::RangeTo { end: 5 });
/// ```
///
/// यात [`IntoIterator`] अंमलबजावणी नाही, म्हणून आपण ते थेट `for` लूपमध्ये वापरू शकत नाही.
/// हे संकलित करणार नाही:
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeTo<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..5 {
///     // ...
/// }
/// ```
///
/// [slicing index] म्हणून वापरताना, `RangeTo` निर्देशांक निर्देशांक आधी `end` द्वारे सर्व अ‍ॅरे घटकांचा तुकडा तयार करते.
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]); // हे एक `RangeTo` आहे
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeTo"]
#[doc(alias = "..")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeTo<Idx> {
    /// श्रेणी (exclusive) ची वरची सीमा.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeTo<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeTo<Idx> {
    /// `item` श्रेणीमध्ये असल्यास `true` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..5).contains(&-1_000_000_000));
    /// assert!( (..5).contains(&4));
    /// assert!(!(..5).contains(&5));
    ///
    /// assert!( (..1.0).contains(&0.5));
    /// assert!(!(..1.0).contains(&f32::NAN));
    /// assert!(!(..f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// (`start..=end`) च्या खाली आणि त्याखालील श्रेणीची श्रेणी.
///
/// `RangeInclusive` `start..=end` मध्ये `x >= start` आणि `x <= end` सह सर्व मूल्ये आहेत.हे `start <= end` पर्यंत रिक्त आहे.
///
/// हे पुनरावृत्ती करणारा एक्स 100 एक्स आहे, परंतु पुनरावृत्ती संपल्यानंतर एक्स ०१ एक्स आणि एक्स ०२ एक्सची विशिष्ट मूल्ये **अनिर्दिष्ट** याशिवाय एक्स ०3 एक्सशिवाय अन्य मूल्ये तयार न झाल्याने एक्स ०0 एक्स परत येईल.
///
///
/// [fused]: crate::iter::FusedIterator
/// [`.is_empty()`]: RangeInclusive::is_empty
///
/// # Examples
///
/// `start..=end` वाक्यरचना एक `RangeInclusive` आहे:
///
/// ```
/// assert_eq!((3..=5), std::ops::RangeInclusive::new(3, 5));
/// assert_eq!(3 + 4 + 5, (3..=5).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]); // हे एक `RangeInclusive` आहे
/// ```
///
///
#[lang = "RangeInclusive"]
#[doc(alias = "..=")]
#[derive(Clone, PartialEq, Eq, Hash)] // कॉपी नाही-#27186 पहा
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeInclusive<Idx> {
    // लक्षात घ्या की झेडफ्यूचर 0 झेड मधील प्रतिनिधित्त्व बदलण्याची परवानगी देण्यासाठी येथील फील्ड सार्वजनिक नाहीत;विशेषतः, आम्ही start/end उघडपणे उघडकीस आणू शकत असताना, (future/current) खासगी फील्ड न बदलता त्या सुधारित केल्यास चुकीचे वर्तन होऊ शकते, म्हणून आम्हाला त्या मोडचे समर्थन करायचे नाही.
    //
    //
    //
    //
    pub(crate) start: Idx,
    pub(crate) end: Idx,

    // हे फील्ड आहे:
    //  - `false` बांधकाम यावर
    //  - `false` जेव्हा पुनरावृत्तीला मूलभूत घटक प्राप्त झाले आणि पुनरावृत्ती करणारा संपत नाही
    //  - `true` जेव्हा इटरटरचा वापर एटरटरला संपवण्यासाठी वापरला जातो
    //
    // आंशिक ऑर्डर किंवा स्पेशलायझेशनशिवाय आंशिकएक आणि हॅशचे समर्थन करण्यासाठी हे आवश्यक आहे.
    pub(crate) exhausted: bool,
}

impl<Idx> RangeInclusive<Idx> {
    /// एक नवीन समावेशी श्रेणी तयार करते.`start..=end` लिहिण्यासाठी समतुल्य.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ops::RangeInclusive;
    ///
    /// assert_eq!(3..=5, RangeInclusive::new(3, 5));
    /// ```
    #[lang = "range_inclusive_new"]
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    #[rustc_promotable]
    #[rustc_const_stable(feature = "const_range_new", since = "1.32.0")]
    pub const fn new(start: Idx, end: Idx) -> Self {
        Self { start, end, exhausted: false }
    }

    /// (inclusive) श्रेणीची खालची सीमा मिळवते.
    ///
    /// पुनरावृत्तीसाठी समावेशी श्रेणी वापरताना, पुनरावृत्ती संपल्यानंतर `start()` आणि [`end()`] ची मूल्ये अनिर्दिष्ट केली जातात.
    /// सर्वसमावेशक श्रेणी रिक्त आहे की नाही हे निर्धारित करण्यासाठी, `start() > end()` ची तुलना करण्याऐवजी [`is_empty()`] पद्धत वापरा.
    ///
    /// Note: या पद्धतीद्वारे मिळविलेले मूल्य अनिर्बंधित आहे जी श्रेणी थकव्यापर्यंत पुनरावृत्ती केली गेल्यानंतर.
    ///
    /// [`end()`]: RangeInclusive::end
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).start(), &3);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn start(&self) -> &Idx {
        &self.start
    }

    /// (inclusive) श्रेणीची वरची सीमा मिळवते.
    ///
    /// पुनरावृत्तीसाठी समावेशी श्रेणी वापरताना, पुनरावृत्ती संपल्यानंतर [`start()`] आणि `end()` ची मूल्ये अनिर्दिष्ट केली जातात.
    /// सर्वसमावेशक श्रेणी रिक्त आहे की नाही हे निर्धारित करण्यासाठी, `start() > end()` ची तुलना करण्याऐवजी [`is_empty()`] पद्धत वापरा.
    ///
    /// Note: या पद्धतीद्वारे मिळविलेले मूल्य अनिर्बंधित आहे जी श्रेणी थकव्यापर्यंत पुनरावृत्ती केली गेल्यानंतर.
    ///
    /// [`start()`]: RangeInclusive::start
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).end(), &5);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn end(&self) -> &Idx {
        &self.end
    }

    /// मध्ये `RangeInclusive` तयार करते (खालच्या बाउंड, अप्पर (inclusive) बाऊंड).
    ///
    /// Note: या पद्धतीद्वारे मिळविलेले मूल्य अनिर्बंधित आहे जी श्रेणी थकव्यापर्यंत पुनरावृत्ती केली गेल्यानंतर.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).into_inner(), (3, 5));
    /// ```
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    pub fn into_inner(self) -> (Idx, Idx) {
        (self.start, self.end)
    }
}

impl RangeInclusive<usize> {
    /// `SliceIndex` अंमलबजावणीसाठी एक्सक्लुझिव्ह `Range` मध्ये रूपांतरित करते.
    /// कॉलर `end == usize::MAX` वर व्यवहार करण्यासाठी जबाबदार आहे.
    #[inline]
    pub(crate) fn into_slice_range(self) -> Range<usize> {
        // जर आपण थकलो नाही तर आपल्याला फक्त `start..end + 1` चा तुकडा काढायचा आहे.
        // जर आपण थकलो आहोत, तर `end + 1..end + 1` चा तुकडा केल्याने आम्हाला रिकामी रेंज मिळते जी अद्याप त्या शेवटच्या बिंदूसाठी सीमांच्या तपासणीच्या अधीन आहे.
        //
        let exclusive_end = self.end + 1;
        let start = if self.exhausted { exclusive_end } else { self.start };
        start..exclusive_end
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        if self.exhausted {
            write!(fmt, " (exhausted)")?;
        }
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeInclusive<Idx> {
    /// `item` श्रेणीमध्ये असल्यास `true` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).contains(&2));
    /// assert!( (3..=5).contains(&3));
    /// assert!( (3..=5).contains(&4));
    /// assert!( (3..=5).contains(&5));
    /// assert!(!(3..=5).contains(&6));
    ///
    /// assert!( (3..=3).contains(&3));
    /// assert!(!(3..=2).contains(&3));
    ///
    /// assert!( (0.0..=1.0).contains(&1.0));
    /// assert!(!(0.0..=1.0).contains(&f32::NAN));
    /// assert!(!(0.0..=f32::NAN).contains(&0.0));
    /// assert!(!(f32::NAN..=1.0).contains(&1.0));
    /// ```
    ///
    /// पुनरावृत्ती समाप्त झाल्यानंतर ही पद्धत नेहमीच `false` परत करते:
    ///
    /// ```
    /// let mut r = 3..=5;
    /// assert!(r.contains(&3) && r.contains(&5));
    /// for _ in r.by_ref() {}
    /// // नेमकी फील्ड व्हॅल्यूज येथे अनिर्दिष्ट आहेत
    /// assert!(!r.contains(&3) && !r.contains(&5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// श्रेणीमध्ये कोणतेही आयटम नसल्यास `true` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).is_empty());
    /// assert!(!(3..=3).is_empty());
    /// assert!( (3..=2).is_empty());
    /// ```
    ///
    /// दोन्ही बाजू अतुलनीय असल्यास श्रेणी रिक्त आहे:
    ///
    /// ```
    /// assert!(!(3.0..=5.0).is_empty());
    /// assert!( (3.0..=f32::NAN).is_empty());
    /// assert!( (f32::NAN..=5.0).is_empty());
    /// ```
    ///
    /// पुनरावृत्ती संपल्यानंतर ही पद्धत `true` परत करते:
    ///
    /// ```
    /// let mut r = 3..=5;
    /// for _ in r.by_ref() {}
    /// // नेमकी फील्ड व्हॅल्यूज येथे अनिर्दिष्ट आहेत
    /// assert!(r.is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    #[inline]
    pub fn is_empty(&self) -> bool {
        self.exhausted || !(self.start <= self.end)
    }
}

/// श्रेणी केवळ सर्वसमावेशकपणे (`..=end`) वर मर्यादित आहे.
///
/// `RangeToInclusive` `..=end` मध्ये `x <= end` सह सर्व मूल्ये आहेत.
/// हे [`Iterator`] म्हणून कार्य करू शकत नाही कारण त्यात प्रारंभिक बिंदू नाही.
///
/// # Examples
///
/// `..=end` वाक्यरचना एक `RangeToInclusive` आहे:
///
/// ```
/// assert_eq!((..=5), std::ops::RangeToInclusive{ end: 5 });
/// ```
///
/// यात [`IntoIterator`] अंमलबजावणी नाही, म्हणून आपण ते थेट `for` लूपमध्ये वापरू शकत नाही.हे संकलित करणार नाही:
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeToInclusive<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..=5 {
///     // ...
/// }
/// ```
///
/// [slicing index] म्हणून वापरल्यास, `RangeToInclusive` पर्यंत सर्व अ‍ॅरे घटकांचा तुकडा तयार करतो आणि एक्स 100 एक्सने निर्देशित निर्देशांकासह.
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]); // हे एक `RangeToInclusive` आहे
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
///
#[lang = "RangeToInclusive"]
#[doc(alias = "..=")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeToInclusive<Idx> {
    /// श्रेणी (inclusive) ची वरची सीमा
    #[stable(feature = "inclusive_range", since = "1.26.0")]
    pub end: Idx,
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeToInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeToInclusive<Idx> {
    /// `item` श्रेणीमध्ये असल्यास `true` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..=5).contains(&-1_000_000_000));
    /// assert!( (..=5).contains(&5));
    /// assert!(!(..=5).contains(&6));
    ///
    /// assert!( (..=1.0).contains(&1.0));
    /// assert!(!(..=1.0).contains(&f32::NAN));
    /// assert!(!(..=f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

// रेंजटॉइन्क्लुझिव्ह<Idx>पासून उत्तेजन देऊ शकत नाही <RangeTo<Idx>> कारण (..0).into() सह भूमिगत करणे शक्य होईल
//

/// की च्या श्रेणीचा शेवटचा बिंदू.
///
/// # Examples
///
/// `सीमा श्रेणी बिंदू आहेत:
///
/// ```
/// use std::ops::Bound::*;
/// use std::ops::RangeBounds;
///
/// assert_eq!((..100).start_bound(), Unbounded);
/// assert_eq!((1..12).start_bound(), Included(&1));
/// assert_eq!((1..12).end_bound(), Excluded(&12));
/// ```
///
/// [`BTreeMap::range`] चे वितर्क म्हणून `बाउंडसचे ट्यूपल वापरणे.
/// लक्षात घ्या की बर्‍याच प्रकरणांमध्ये, त्याऐवजी श्रेणी वाक्यरचना (`1..5`) वापरणे चांगले.
///
/// ```
/// use std::collections::BTreeMap;
/// use std::ops::Bound::{Excluded, Included, Unbounded};
///
/// let mut map = BTreeMap::new();
/// map.insert(3, "a");
/// map.insert(5, "b");
/// map.insert(8, "c");
///
/// for (key, value) in map.range((Excluded(3), Included(8))) {
///     println!("{}: {}", key, value);
/// }
///
/// assert_eq!(Some((&3, &"a")), map.range((Unbounded, Included(5))).next());
/// ```
///
/// [`BTreeMap::range`]: ../../std/collections/btree_map/struct.BTreeMap.html#method.range
#[stable(feature = "collections_bound", since = "1.17.0")]
#[derive(Clone, Copy, Debug, Hash, PartialEq, Eq)]
pub enum Bound<T> {
    /// सर्वसमावेशक मर्यादा.
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Included(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// अनन्य मर्यादा.
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Excluded(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// एक अनंत शेवटचा मुद्दा.या दिशेने कोणतेही बंधन नसल्याचे दर्शवते.
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Unbounded,
}

#[unstable(feature = "bound_as_ref", issue = "80996")]
impl<T> Bound<T> {
    /// `&Bound<T>` ते `Bound<&T>` मध्ये रूपांतरित करते.
    #[inline]
    pub fn as_ref(&self) -> Bound<&T> {
        match *self {
            Included(ref x) => Included(x),
            Excluded(ref x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }

    /// `&mut Bound<T>` ते `Bound<&T>` मध्ये रूपांतरित करते.
    #[inline]
    pub fn as_mut(&mut self) -> Bound<&mut T> {
        match *self {
            Included(ref mut x) => Included(x),
            Excluded(ref mut x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }
}

impl<T: Clone> Bound<&T> {
    /// सीमेची सामग्री क्लोनिंग करून एक `Bound<&T>` वर X0X नकाशा बनवा.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(bound_cloned)]
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((1..12).start_bound(), Included(&1));
    /// assert_eq!((1..12).start_bound().cloned(), Included(1));
    /// ```
    #[unstable(feature = "bound_cloned", issue = "61356")]
    pub fn cloned(self) -> Bound<T> {
        match self {
            Bound::Unbounded => Bound::Unbounded,
            Bound::Included(x) => Bound::Included(x.clone()),
            Bound::Excluded(x) => Bound::Excluded(x.clone()),
        }
    }
}

/// `RangeBounds` X0Rust0Z च्या अंगभूत श्रेणी प्रकारांद्वारे अंमलात आणली गेली आहे, `..`, `a..`, `..b`, `..=c`, `d..e` किंवा `f..=g` सारख्या श्रेणी वाक्यरचनाद्वारे उत्पादित.
///
#[stable(feature = "collections_range", since = "1.28.0")]
pub trait RangeBounds<T: ?Sized> {
    /// प्रारंभ अनुक्रमणिका.
    ///
    /// प्रारंभ मूल्य `Bound` म्हणून मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((..10).start_bound(), Unbounded);
    /// assert_eq!((3..10).start_bound(), Included(&3));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn start_bound(&self) -> Bound<&T>;

    /// समाप्ती अनुक्रमणिका
    ///
    /// `Bound` म्हणून अंतिम मूल्य मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((3..).end_bound(), Unbounded);
    /// assert_eq!((3..10).end_bound(), Excluded(&10));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn end_bound(&self) -> Bound<&T>;

    /// `item` श्रेणीमध्ये असल्यास `true` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// ठामपणे सांगा! ((3..5).contains(&4));
    /// assert!(!(3..5).contains(&2));
    ///
    /// ठामपणे सांगा! ((0.0..1.0).contains(&0.5));
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    #[stable(feature = "range_contains", since = "1.35.0")]
    fn contains<U>(&self, item: &U) -> bool
    where
        T: PartialOrd<U>,
        U: ?Sized + PartialOrd<T>,
    {
        (match self.start_bound() {
            Included(ref start) => *start <= item,
            Excluded(ref start) => *start < item,
            Unbounded => true,
        }) && (match self.end_bound() {
            Included(ref end) => item <= *end,
            Excluded(ref end) => item < *end,
            Unbounded => true,
        })
    }
}

use self::Bound::{Excluded, Included, Unbounded};

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T: ?Sized> RangeBounds<T> for RangeFull {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        if self.exhausted {
            // जेव्हा पुनरावृत्ती करणारा थकला असेल, तेव्हा आमच्याकडे सहसा प्रारंभ==अंत असतो, परंतु आम्हाला काही रिकामे नसलेली श्रेणी रिकामी असावी असे वाटते.
            //
            Excluded(&self.end)
        } else {
            Included(&self.end)
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for (Bound<T>, Bound<T>) {
    fn start_bound(&self) -> Bound<&T> {
        match *self {
            (Included(ref start), _) => Included(start),
            (Excluded(ref start), _) => Excluded(start),
            (Unbounded, _) => Unbounded,
        }
    }

    fn end_bound(&self) -> Bound<&T> {
        match *self {
            (_, Included(ref end)) => Included(end),
            (_, Excluded(ref end)) => Excluded(end),
            (_, Unbounded) => Unbounded,
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<'a, T: ?Sized + 'a> RangeBounds<T> for (Bound<&'a T>, Bound<&'a T>) {
    fn start_bound(&self) -> Bound<&T> {
        self.0
    }

    fn end_bound(&self) -> Bound<&T> {
        self.1
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}