/// `?` ऑपरेटरच्या वर्तन सानुकूलित करण्यासाठी एक trait.
///
/// एक्स एम्प्लीएक्सिंग एक प्रकार म्हणजे एक्स एक्स 01 एक्स डाइकोटॉमीच्या बाबतीत तो पहाण्याचा सामान्य मार्ग आहे.
/// हे trait विद्यमान घटनामधून ती यश किंवा अपयशी मूल्ये काढण्याची आणि यशस्वी किंवा अयशस्वी मूल्यापासून एक नवीन घटना तयार करणे या दोघांना अनुमती देते.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// जेव्हा यशस्वी पाहिले तेव्हा या मूल्याचा प्रकार.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// अयशस्वी म्हणून पाहिले तेव्हा या मूल्याचा प्रकार.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// "?" ऑपरेटर लागू करते.एक्स0 2 एक्सचा परतावा म्हणजे अंमलबजावणी सामान्यपणे सुरू ठेवावी आणि X03 एक्स चा परिणाम म्हणजे एक्स 100 एक्स.
    /// `Err(e)` चा परतावा म्हणजे अंमलबजावणी branch सर्वात आतून बंद केलेले `catch` पर्यंत जावी किंवा कार्यामधून परत यावी.
    ///
    /// जर `Err(e)` निकाल परत केला तर, संलग्न व्याप्तीच्या रिटर्न प्रकारात `e` मूल्य "wrapped" असेल (ज्याने स्वतः `Try` अंमलात आणणे आवश्यक आहे).
    ///
    /// विशेषत: `X::from_error(From::from(e))` मूल्य परत केले जाते, जेथे `X` हे एन्क्लोझिंग फंक्शनचा परतीचा प्रकार आहे.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// संमिश्र निकाल तयार करण्यासाठी त्रुटी मूल्य गुंडाळा.
    /// उदाहरणार्थ, `Result::Err(x)` आणि `Result::from_error(x)` समतुल्य आहेत.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// संमिश्र निकाल तयार करण्यासाठी ओके मूल्य लपेटणे.
    /// उदाहरणार्थ, `Result::Ok(x)` आणि `Result::from_ok(x)` समतुल्य आहेत.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}