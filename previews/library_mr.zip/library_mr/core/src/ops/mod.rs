//! ओव्हरलोड करण्यायोग्य ऑपरेटर
//!
//! या झेडट्रिट्स0 झेडची अंमलबजावणी आपल्याला काही ऑपरेटर ओव्हरलोड करण्याची परवानगी देते.
//!
//! यापैकी काही झेडट्रायट0 झेड झेडप्रिल्ड 0 झेडद्वारे आयात केली आहेत, म्हणून ती प्रत्येक झेडस्ट्रास्ट 0 झेड प्रोग्राममध्ये उपलब्ध आहेत.केवळ traits द्वारा समर्थित ऑपरेटर ओव्हरलोड केले जाऊ शकतात.
//! उदाहरणार्थ, अतिरिक्त ऑपरेटर (`+`) [`Add`] trait द्वारे ओव्हरलोड केले जाऊ शकते, परंतु असाईनमेंट ऑपरेटर (`=`) ला trait चा पाठिंबा नसल्याने त्याचे शब्दरचना ओव्हरलोड करण्याचा कोणताही मार्ग नाही.
//! याव्यतिरिक्त, हे मॉड्यूल नवीन ऑपरेटर तयार करण्यासाठी कोणतीही यंत्रणा प्रदान करत नाही.
//! जर ट्रिटलेस ओव्हरलोडिंग किंवा सानुकूल ऑपरेटर आवश्यक असतील तर आपण झेडआरस्ट ० झेड चा सिंटॅक्स वाढविण्यासाठी मॅक्रो किंवा कंपाईलर प्लगइनकडे पहावे.
//!
//! ऑपरेटर traits ची अंमलबजावणी त्यांचे नेहमीचे अर्थ आणि [operator precedence] लक्षात ठेवून संबंधित संदर्भात आश्चर्यकारक नसावे.
//! उदाहरणार्थ, एक्स 100 एक्सची अंमलबजावणी करताना, ऑपरेशनमध्ये गुणाकारांशी काही साम्य असले पाहिजे (आणि असोसिएटिव्हिटीसारख्या अपेक्षित मालमत्ता सामायिक करा).
//!
//! लक्षात घ्या की `&&` आणि `||` ऑपरेटर शॉर्ट-सर्किट, म्हणजेच, ते निकालास हातभार लावल्यास केवळ त्यांच्या दुसर्‍या ऑपरेंडचे मूल्यांकन करतात.हे वर्तन traits द्वारे अंमलबजावणीयोग्य नसल्यामुळे, `&&` आणि `||` ओव्हरलोड करण्यायोग्य ऑपरेटर म्हणून समर्थित नाहीत.
//!
//! बरेच ऑपरेटर त्यांचे ऑपरेंड मूल्य देऊन घेतात.अंगभूत प्रकारांचा समावेश नसलेल्या-सामान्य संदर्भांमध्ये, ही सहसा समस्या नसते.
//! जेनेरिक कोडमध्ये या ऑपरेटरचा वापर करण्यासाठी, ऑपरेटरचा वापर करण्यास विरोध करण्याऐवजी मूल्ये पुन्हा वापरावी लागतील तर त्याकडे थोडे लक्ष देणे आवश्यक आहे.कधीकधी [`clone`] वापरणे हा एक पर्याय आहे.
//! संदर्भासाठी अतिरिक्त ऑपरेटर अंमलबजावणी प्रदान करण्याच्या प्रकारांवर अवलंबून राहणे हा दुसरा पर्याय आहे.
//! उदाहरणार्थ, वापरकर्त्याने परिभाषित केलेल्या `T` प्रकारासाठी जो व्यतिरिक्त समर्थन देऊ शकतो, त्यासाठी `T` आणि `&T` ने traits [`Add<T>`][`Add`] आणि [`Add<&T>`][`Add`] दोन्ही अंमलात आणणे चांगले आहे जेणेकरुन जेनेरिक कोड अनावश्यक क्लोनिंगशिवाय लिहिता येऊ शकेल.
//!
//!
//! # Examples
//!
//! हे उदाहरण [`Add`] आणि [`Sub`] लागू करणारी एक `Point` रचना तयार करते आणि नंतर दोन-बिंदू जोडणे आणि वजा करणे दर्शविते.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! उदाहरणार्थ अंमलबजावणीसाठी प्रत्येक trait साठी दस्तऐवजीकरण पहा.
//!
//! [`Fn`], [`FnMut`], आणि [`FnOnce`] traits अशा प्रकारांद्वारे अंमलबजावणी केली जाते जी कार्ये प्रमाणेच लागू केली जाऊ शकतात.[`Fn`] `&self` घेते, [`FnMut`] `&mut self` घेते आणि [`FnOnce`] `self` घेते हे लक्षात घ्या.
//! हे अशा तीन प्रकारच्या पद्धतींशी संबंधित आहे जे एका उदाहरणावरून कॉल केले जाऊ शकतात: कॉल-बाय-रेफरेंस, कॉल-बाय-म्युटेबल-रेफरेंस, आणि कॉल-बाय-व्हॅल्यू.
//! या traits चा सर्वात सामान्य वापर म्हणजे उच्च स्तरीय फंक्शन्सच्या सीमा म्हणून कार्य करणे जे कार्य म्हणून किंवा क्लोजरमध्ये वितर्क म्हणून कार्य करतात.
//!
//! पॅरामीटर म्हणून [`Fn`] घेत आहे:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! पॅरामीटर म्हणून [`FnMut`] घेत आहे:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! पॅरामीटर म्हणून [`FnOnce`] घेत आहे:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` त्याचे कॅप्चर केलेले व्हेरिएबल्स वापरते, म्हणून हे एकापेक्षा जास्त वेळा चालविले जाऊ शकत नाही
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // पुन्हा एक्स ०१ एक्सची विनंती करण्याचा प्रयत्न केल्यास, एक्स ००० एक्ससाठी एक्स ०२ एक्स त्रुटी टाकली जाईल
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` यापुढे यापुढे विनंती केली जाऊ शकत नाही
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;