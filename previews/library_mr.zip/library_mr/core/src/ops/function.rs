/// कॉल ऑपरेटरची आवृत्ती जी एक अपरिवर्तनीय रिसीव्हर घेते.
///
/// उत्परिवर्तन स्थितीशिवाय `Fn` च्या घटना वारंवार कॉल केल्या जाऊ शकतात.
///
/// *हे trait (`Fn`) [function pointers] (`fn`) सह गोंधळात टाकू नये.*
///
/// `Fn` क्लोजरद्वारे स्वयंचलितपणे अंमलबजावणी केली जाते जे केवळ कॅप्चर केलेल्या चलनांशीच बदलण्यायोग्य संदर्भ घेतात किंवा अजिबात काही हस्तगत करत नाहीत, तसेच (safe) [function pointers] (काही सावधगिरीसह, अधिक माहितीसाठी त्यांचे दस्तऐवजीकरण पहा).
///
/// याव्यतिरिक्त, `Fn` लागू करणार्‍या कोणत्याही प्रकारच्या `F` साठी, `&F` देखील `Fn` लागू करते.
///
/// [`FnMut`] आणि [`FnOnce`] हे दोघेही `Fn` चे सुपरट्रेट आहेत, `Fn` चे कोणतेही उदाहरण पॅरामीटर म्हणून वापरले जाऊ शकते जेथे [`FnMut`] किंवा [`FnOnce`] अपेक्षित आहे.
///
/// जेव्हा आपल्याला फंक्शन-सारख्या प्रकारचे पॅरामीटर स्वीकारण्याची इच्छा असते तेव्हा `Fn` वापरा आणि वारंवार आणि उत्परिवर्तन स्थितीशिवाय कॉल करणे आवश्यक आहे (उदा. त्याचवेळी कॉल करताना).
/// आपल्याला अशा कठोर आवश्यकतांची आवश्यकता नसल्यास, [`FnMut`] किंवा [`FnOnce`] सीमा म्हणून वापरा.
///
/// या विषयावरील काही अधिक माहितीसाठी [chapter on closures in *The Rust Programming Language*][book] पहा.
///
/// `Fn` traits (उदा. साठी विशेष सिंटॅक्स देखील लक्षात ठेवा
/// `Fn(usize, bool) -> usize`).ज्यांच्या तांत्रिक तपशीलांमध्ये स्वारस्य आहे ते [the relevant section in the *Rustonomicon*][nomicon] चा संदर्भ घेऊ शकतात.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## बंद पुकारत आहे
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## `Fn` पॅरामीटर वापरणे
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // जेणेकरुन regex त्या `&str: !FnMut` वर अवलंबून राहू शकेल
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// कॉल ऑपरेशन करते.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// एक बदलण्यायोग्य रिसीव्हर घेणार्‍या कॉल ऑपरेटरची आवृत्ती.
///
/// `FnMut` च्या घटना वारंवार कॉल केल्या जाऊ शकतात आणि स्थिती बदलू शकतात.
///
/// `FnMut` क्लोजरद्वारे स्वयंचलितपणे अंमलबजावणी केली जाते जी कॅप्चर केलेल्या व्हेरिएबल्समध्ये बदल करण्यायोग्य संदर्भ घेतात, तसेच [`Fn`] कार्यान्वित करणारे सर्व प्रकार, उदा. (safe) [function pointers] (`FnMut` हे [`Fn`] चा सुपरट्रॅट असल्याने).
/// याव्यतिरिक्त, `FnMut` लागू करणार्‍या कोणत्याही प्रकारच्या `F` साठी, `&mut F` देखील `FnMut` लागू करते.
///
/// [`FnOnce`] हे `FnMut` चे सुपरट्रॅक्ट असल्याने, एक्स ०4 एक्सची कोणतीही उदाहरणे जेथे एक्स ०4 एक्सची अपेक्षा असेल तिथे वापरली जाऊ शकते आणि एक्स ०5 एक्स एक्स ०१ एक्सचा सबट्रेट असल्याने, एक्स ०6 एक्सचे कोणतेही उदाहरण वापरले जाऊ शकते जेथे एक्स ०7 एक्स अपेक्षित आहे.
///
/// जेव्हा आपल्याला फंक्शन-सारख्या प्रकारचे पॅरामीटर स्वीकारण्याची इच्छा असते तेव्हा `FnMut` चा वापर करा आणि त्यास फेरबदल स्थितीत असताना त्यास वारंवार कॉल करण्याची आवश्यकता असेल.
/// जर आपणास पॅरामीटर बदलण्याची स्थिती नको असेल तर [`Fn`] चा बाउंड म्हणून वापरा;आपल्याला वारंवार कॉल करण्याची आवश्यकता नसल्यास, [`FnOnce`] वापरा.
///
/// या विषयावरील काही अधिक माहितीसाठी [chapter on closures in *The Rust Programming Language*][book] पहा.
///
/// `Fn` traits (उदा. साठी विशेष सिंटॅक्स देखील लक्षात ठेवा
/// `Fn(usize, bool) -> usize`).ज्यांच्या तांत्रिक तपशीलांमध्ये स्वारस्य आहे ते [the relevant section in the *Rustonomicon*][nomicon] चा संदर्भ घेऊ शकतात.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## परस्पर कॅप्चरिंग बंद करणे कॉल करीत आहे
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## `FnMut` पॅरामीटर वापरणे
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // जेणेकरुन regex त्या `&str: !FnMut` वर अवलंबून राहू शकेल
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// कॉल ऑपरेशन करते.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// कॉल ऑपरेटरची आवृत्ती जी उप-मूल्य प्राप्तकर्ता घेते.
///
/// `FnOnce` च्या उदाहरणे कॉल केल्या जाऊ शकतात, परंतु बर्‍याच वेळा कॉल करण्यायोग्य नसतील.या कारणास्तव, जर प्रकाराबद्दल एकमेव गोष्ट ज्ञात असेल तर ती `FnOnce` लागू करते, तर फक्त एकदाच म्हटले जाऊ शकते.
///
/// `FnOnce` क्लोजरद्वारे स्वयंचलितपणे अंमलात आणले जाईल जे कदाचित कॅप्चर केलेले व्हेरिएबल्सचा वापर करु शकतील, तसेच सर्व प्रकारच्या [`FnMut`] ची अंमलबजावणी करतात, उदा. (safe) [function pointers] (`FnOnce` हा [`FnMut`] चा सुपरट्रॅट असल्याने).
///
///
/// [`Fn`] आणि [`FnMut`] हे दोन्ही `FnOnce` चे सबट्रेट असल्याने, [`Fn`] किंवा [`FnMut`] चे कोणतेही उदाहरण वापरले जाऊ शकते जेथे `FnOnce` अपेक्षित आहे.
///
/// जेव्हा आपल्याला फंक्शन-सारख्या प्रकाराचे पॅरामीटर स्वीकार करायचे असते तेव्हा `FnOnce` चा बाउंड म्हणून वापरा आणि फक्त एकदाच कॉल करणे आवश्यक आहे.
/// आपल्याला पॅरामीटरला वारंवार कॉल करण्याची आवश्यकता असल्यास, [`FnMut`] चा बांध म्हणून वापरा;जर आपल्याला त्याची स्थिती बदलण्याची आवश्यकता नसेल तर [`Fn`] वापरा.
///
/// या विषयावरील काही अधिक माहितीसाठी [chapter on closures in *The Rust Programming Language*][book] पहा.
///
/// `Fn` traits (उदा. साठी विशेष सिंटॅक्स देखील लक्षात ठेवा
/// `Fn(usize, bool) -> usize`).ज्यांच्या तांत्रिक तपशीलांमध्ये स्वारस्य आहे ते [the relevant section in the *Rustonomicon*][nomicon] चा संदर्भ घेऊ शकतात.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## `FnOnce` पॅरामीटर वापरणे
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` त्याचे कॅप्चर केलेले व्हेरिएबल्स वापरते, म्हणून हे एकापेक्षा जास्त वेळा चालविले जाऊ शकत नाही.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // पुन्हा एक्स ०१ एक्सची विनंती करण्याचा प्रयत्न केल्यास, एक्स ००० एक्ससाठी एक्स ०२ एक्स त्रुटी टाकली जाईल.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` यापुढे यापुढे विनंती केली जाऊ शकत नाही
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // जेणेकरुन regex त्या `&str: !FnMut` वर अवलंबून राहू शकेल
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// कॉल ऑपरेटर वापरल्यानंतर परतलेला प्रकार.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// कॉल ऑपरेशन करते.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}