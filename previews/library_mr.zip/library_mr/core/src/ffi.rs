#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! परदेशी फंक्शन इंटरफेस (FFI) बाइंडिंगशी संबंधित उपयुक्तता.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// जेव्हा एक्स 100 एक्स म्हणून वापरला जातो तेव्हा सीच्या एक्स01 एक्स प्रकारच्या समतुल्य.
///
/// थोडक्यात, एक्स 0 एक्स एक्स सी च्या एक्स0 2 एक्स समतुल्य आहे आणि एक्स 0 एक्स एक्स सी च्या एक्स 100 एक्स समतुल्य आहे.
/// ते म्हणाले की, हा सी च्या एक्स00 एक्स रिटर्न प्रकाराप्रमाणेच नाही * जो झेडआरस्ट ० झेडचा एक्स ०१ एक्स प्रकार आहे.
///
/// एफएफआयमध्ये अपारदर्शक प्रकारांकडे निर्देशकांचे नमुना तयार करण्यासाठी, `extern type` स्थिर होईपर्यंत, रिक्त बाइट अ‍ॅरेच्या सभोवतालच्या झेडनेटव्हेप0 झेड रॅपर वापरण्याची शिफारस केली जाते.
///
/// तपशीलांसाठी [Nomicon] पहा.
///
/// ते 1.1.0 पर्यंत जुन्या Rust कंपाईलरला समर्थन देऊ इच्छित असल्यास कोणी `std::os::raw::c_void` वापरू शकेल.
/// Rust 1.30.0 नंतर, या परिभाषाद्वारे ती पुन्हा निर्यात केली गेली.
/// अधिक माहितीसाठी, कृपया [RFC 2521] वाचा.
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// एनबी, एलएलव्हीएमला शून्य पॉईंटर प्रकार ओळखण्यासाठी आणि एक्स 100 एक्स सारख्या विस्तारित कार्याद्वारे, आम्हाला एलएलव्हीएम बिटकॉडमध्ये आय 8 * असे दर्शविणे आवश्यक आहे.
// येथे वापरलेला एनम याची खात्री देतो आणि केवळ खाजगी रूपे घेऊन एक्स 100 एक्स प्रकारचा गैरवापर रोखतो.
// आम्हाला दोन रूपे आवश्यक आहेत, कारण कंपाईलर अन्यथा रेप्र विशेषताबद्दल तक्रार करतो आणि आपल्याला कमीतकमी एक रूप आवश्यक आहे कारण अन्यथा एनम निर्जन असेल आणि कमीतकमी अशा पॉइंटर्सचा डिरेफरिंग यूबी असेल.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// `va_list` चे मूलभूत अंमलबजावणी.
// आत्तासाठी `VaListImpl` वापरुन हे नाव डब्ल्यूआयपी आहे.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // `'f` पेक्षा अधिक अविभाज्य, म्हणून प्रत्येक `VaListImpl<'f>` ऑब्जेक्ट त्याच्या परिभाषित केलेल्या फंक्शनच्या क्षेत्राशी जोडलेले आहे
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 एबीआय एक `va_list` ची अंमलबजावणी.
/// अधिक तपशीलांसाठी [AArch64 Procedure Call Standard] पहा.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC एबीआय एक `va_list` ची अंमलबजावणी.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 एबीआय एक `va_list` ची अंमलबजावणी.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// `va_list` साठी एक आवरण
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// सी च्या एक्स 100 एक्स सह बायनरी-सुसंगत असलेल्या एका X01 एक्सला एका एक्स 2 एक्स मध्ये रुपांतरित करा.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// सी च्या एक्स 100 एक्स सह बायनरी-सुसंगत असलेल्या एका X01 एक्सला एका एक्स 2 एक्स मध्ये रुपांतरित करा.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// VaArgSafe trait सार्वजनिक इंटरफेसमध्ये वापरण्याची आवश्यकता आहे, तथापि, trait स्वतःच या मॉड्यूलच्या बाहेर वापरण्याची परवानगी देऊ नये.
// वापरकर्त्यांना trait एका नवीन प्रकारासाठी अंमलबजावणी करण्यास परवानगी देणे (त्याद्वारे va_arg आंतरिक नवीन प्रकारच्या वापरास अनुमती देते) अपरिभाषित वर्तन होण्याची शक्यता आहे.
//
// FIXME(dlrobertson): सार्वजनिक इंटरफेसमध्ये VaArgSafe trait वापरण्यासाठी परंतु ते अन्यत्र वापरता येणार नाही याची खात्री करण्यासाठी, झेडट्रायट0 झेडला खाजगी विभागातील सार्वजनिक करणे आवश्यक आहे.
// एकदा आरएफसी 2145 ची अंमलबजावणी झाली की त्यात सुधारणा होईल.
//
//
//
//
mod sealed_trait {
    /// Trait जे [super::VaListImpl::arg] सह वापरल्या जाणार्‍या प्रकारांना परवानगी देते.
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// पुढील वादाकडे जा.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // सुरक्षितता: कॉलरने `va_arg` साठी सुरक्षितता करार पाळला पाहिजे.
        unsafe { va_arg(self) }
    }

    /// वर्तमान स्थानावरील `va_list` कॉपी करते.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // सुरक्षितता: कॉलरने `va_end` साठी सुरक्षितता करार पाळला पाहिजे.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // सुरक्षाः आम्ही `MaybeUninit` ला लिहितो, अशाप्रकारे ते आरंभ झाले आणि `assume_init` कायदेशीर आहे
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: यास `va_end` कॉल करावा, परंतु यासाठी कोणताही स्वच्छ मार्ग नाही
        // हमी द्या की `drop` नेहमीच त्याच्या कॉलरमध्ये समाविष्ट असतो, म्हणूनच एक्स0 एक्स एक्स संबंधित एक्स 100 एक्स सारख्याच फंक्शनमधून थेट कॉल करेल.
        // `man va_end` असे म्हटले आहे की सीला हे आवश्यक आहे, आणि एलएलव्हीएम मुळात सी अर्थशास्त्रांचे अनुसरण करते, म्हणून आम्हाला हे सुनिश्चित करणे आवश्यक आहे की `va_end` नेहमीच `va_copy` सारख्याच कार्यातून कॉल केले जाते.
        //
        // अधिक माहितीसाठी, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // हे आतासाठी कार्य करते, कारण सर्व वर्तमान एलएलव्हीएम लक्ष्यांवर एक्स 100 एक्स ही एक निवड नाही.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// `va_start` किंवा `va_copy` सह आरंभानंतर अर्गलिस्ट `ap` नष्ट करा.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// आर्गलिस्ट X01 एक्सचे वर्तमान स्थान आर्गलिस्ट एक्स00 एक्स वर कॉपी करते.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// `va_list` `ap` वरून `T` प्रकाराचे वितर्क लोड करते आणि `ap` बिंदूकडे वितर्क वाढवते.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}