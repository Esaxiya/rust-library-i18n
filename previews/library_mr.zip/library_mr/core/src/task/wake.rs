#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// एक `RawWaker` कार्य कार्यवाहीच्या अंमलबजावणीस [`Waker`] तयार करण्यास अनुमती देते जे सानुकूलित वेकअप वर्तन प्रदान करते.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// यात डेटा पॉईंटर आणि एक X01 एक्स आहे जो एक्स 100 एक्स च्या वर्तनला सानुकूलित करतो.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// डेटा पॉईंटर, ज्याचा उपयोग कार्यालयाद्वारे आवश्यकतेनुसार अनियंत्रित डेटा संग्रहित करण्यासाठी केला जाऊ शकतो.
    /// हे उदा असू शकते
    /// टास्कशी संबद्ध `Arc` चे टाइप-मिटविलेले पॉईंटर
    /// या फील्डचे मूल्य सर्व पॅरामिटर म्हणून vtable चा भाग असलेल्या सर्व फंक्शन्सपर्यंत जाते.
    ///
    data: *const (),
    /// व्हर्च्युअल फंक्शन पॉईंटर टेबल जो या वाइकरच्या वर्तनास सानुकूलित करते.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// प्रदान केलेल्या `data` पॉइंटर आणि `vtable` वरून नवीन `RawWaker` तयार करते.
    ///
    /// एक्झिक्युटरद्वारे आवश्यक डेटा अनियंत्रित डेटा संचयित करण्यासाठी `data` पॉईंटरचा वापर केला जाऊ शकतो.हे उदा असू शकते
    /// टास्कशी संबद्ध `Arc` चे टाइप-मिटविलेले पॉईंटर
    /// या पॉईंटरचे मूल्य सर्व पॅरामीटर म्हणून `vtable` चे भाग असलेल्या सर्व फंक्शन्सवर जाईल.
    ///
    /// `vtable` `Waker` चे वर्तन सानुकूलित करते जे `RawWaker` वरून तयार होते.
    /// `Waker` वरील प्रत्येक ऑपरेशनसाठी, अंतर्निहित `RawWaker` च्या `vtable` मधील संबंधित फंक्शनला कॉल केले जाईल.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// व्हर्च्युअल फंक्शन पॉईंटर टेबल (vtable) जे [`RawWaker`] चे वर्तन निर्दिष्ट करते.
///
/// व्हीटेबलच्या आत असलेल्या सर्व फंक्शन्सला दिलेला पॉईंटर एन्क्लोझिंग एक्स01 एक्स ऑब्जेक्टमधील एक्स 100 एक्स पॉईंटर आहे.
///
/// या संरचनेच्या अंतर्गत कार्ये केवळ [`RawWaker`] अंमलबजावणीच्या आतून योग्यरित्या तयार केलेल्या [`RawWaker`] ऑब्जेक्टच्या `data` पॉईंटरवर कॉल करण्याचा हेतू आहे.
/// इतर कोणत्याही `data` पॉईंटरचा वापर करून समाविष्ट असलेल्या फंक्शन्सपैकी एकास कॉल केल्यास अपरिभाषित वर्तन होईल.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// जेव्हा [`RawWaker`] क्लोन झाल्यावर हे फंक्शन कॉल केले जाईल, उदा. जेव्हा [`Waker`] ज्यामध्ये [`RawWaker`] संचयित आहे तो क्लोन झाला.
    ///
    /// या कार्याच्या अंमलबजावणीमध्ये [`RawWaker`] आणि संबंधित कार्य या अतिरिक्त घटकासाठी आवश्यक असलेली सर्व संसाधने राखून ठेवणे आवश्यक आहे.
    /// [`RawWaker`] वर परिणामी `wake` वर कॉल करण्यामुळे मूळ [`RawWaker`] ने जागृत केलेल्या समान कार्याचा वेगाने परिणाम झाला पाहिजे.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// हे कार्य `wake`[`Waker`] वर कॉल केले जाईल तेव्हा.
    /// या [`RawWaker`] सह संबंधित कार्य जागृत करणे आवश्यक आहे.
    ///
    /// या कार्याच्या अंमलबजावणीमध्ये [`RawWaker`] आणि संबंधित कार्याच्या या घटकाशी संबंधित कोणतीही संसाधने सोडण्याची खात्री करणे आवश्यक आहे.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// हे कार्य `wake_by_ref`[`Waker`] वर कॉल केले जाईल तेव्हा.
    /// या [`RawWaker`] सह संबंधित कार्य जागृत करणे आवश्यक आहे.
    ///
    /// हे कार्य एक्स 100 एक्ससारखे आहे, परंतु प्रदान केलेला डेटा पॉईंटर वापरु नये.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// जेव्हा [`RawWaker`] सोडले जाते तेव्हा हे कार्य म्हटले जाते.
    ///
    /// या कार्याच्या अंमलबजावणीमध्ये [`RawWaker`] आणि संबंधित कार्याच्या या घटकाशी संबंधित कोणतीही संसाधने सोडण्याची खात्री करणे आवश्यक आहे.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// प्रदान केलेल्या `clone`, `wake`, `wake_by_ref` आणि `drop` कार्ये वरून नवीन `RawWakerVTable` तयार करते.
    ///
    /// # `clone`
    ///
    /// जेव्हा [`RawWaker`] क्लोन झाल्यावर हे फंक्शन कॉल केले जाईल, उदा. जेव्हा [`Waker`] ज्यामध्ये [`RawWaker`] संचयित आहे तो क्लोन झाला.
    ///
    /// या कार्याच्या अंमलबजावणीमध्ये [`RawWaker`] आणि संबंधित कार्य या अतिरिक्त घटकासाठी आवश्यक असलेली सर्व संसाधने राखून ठेवणे आवश्यक आहे.
    /// [`RawWaker`] वर परिणामी `wake` वर कॉल करण्यामुळे मूळ [`RawWaker`] ने जागृत केलेल्या समान कार्याचा वेगाने परिणाम झाला पाहिजे.
    ///
    /// # `wake`
    ///
    /// हे कार्य `wake`[`Waker`] वर कॉल केले जाईल तेव्हा.
    /// या [`RawWaker`] सह संबंधित कार्य जागृत करणे आवश्यक आहे.
    ///
    /// या कार्याच्या अंमलबजावणीमध्ये [`RawWaker`] आणि संबंधित कार्याच्या या घटकाशी संबंधित कोणतीही संसाधने सोडण्याची खात्री करणे आवश्यक आहे.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// हे कार्य `wake_by_ref`[`Waker`] वर कॉल केले जाईल तेव्हा.
    /// या [`RawWaker`] सह संबंधित कार्य जागृत करणे आवश्यक आहे.
    ///
    /// हे कार्य एक्स 100 एक्ससारखे आहे, परंतु प्रदान केलेला डेटा पॉईंटर वापरु नये.
    ///
    /// # `drop`
    ///
    /// जेव्हा [`RawWaker`] सोडले जाते तेव्हा हे कार्य म्हटले जाते.
    ///
    /// या कार्याच्या अंमलबजावणीमध्ये [`RawWaker`] आणि संबंधित कार्याच्या या घटकाशी संबंधित कोणतीही संसाधने सोडण्याची खात्री करणे आवश्यक आहे.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// एसिन्क्रोनस टास्कचे एक्स 100 एक्स.
///
/// सध्या, `Context` केवळ `&Waker` मध्ये प्रवेश प्रदान करते जे सध्याचे कार्य जागृत करण्यासाठी वापरले जाऊ शकते.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // आजीवन चंचल होण्यास भाग पाडून भिन्नता बदलांविरूद्ध आम्ही झेडफ्यूचर ० झेड-प्रूफ सुनिश्चित करा (युक्तिवादाची स्थिती जीवनरक्षक तुलनात्मक असते तर रिटर्न-पोजीशन लाइफटाइम कॉवेरियंट असते).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// `&Waker` वरून नवीन `Context` तयार करा.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// सद्य कार्यासाठी `Waker` चा संदर्भ मिळवते.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// एक्स एक्स एक्स हे कार्य करण्यासाठी जागृत करण्यासाठीचे एक हँडल आहे ज्याच्या कार्यालयाला सूचित करण्यासाठी ते चालवण्यास तयार आहे.
///
/// हे हँडल एक एक्स00 एक्स घटना encapsulates, जे कार्यकारी-विशिष्ट वेकअप वर्तन परिभाषित करते.
///
///
/// [`Clone`], [`Send`] आणि [`Sync`] लागू करते.
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// या `Waker` सह संबंधित कार्य जागृत करा.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // वास्तविक वेकअप कॉल अंमलबजावणीसाठी व्हर्च्युअल फंक्शन कॉलद्वारे नियुक्त केला जातो जो एक्झिक्यूटरद्वारे परिभाषित केला जातो.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // `drop` वर कॉल करु नका-विकर `wake` द्वारे खाल्ला जाईल.
        crate::mem::forget(self);

        // सुरक्षितता: हे सुरक्षित आहे कारण `Waker::from_raw` हा एकमेव मार्ग आहे
        // `wake` आणि `data` प्रारंभ करण्यासाठी वापरकर्त्याने हे कबूल केले की `RawWaker` चा करार कायम आहे.
        //
        unsafe { (wake)(data) };
    }

    /// `Waker` न वापरता या `Waker` शी संबंधित कार्य जागृत करा.
    ///
    /// हे `wake` प्रमाणेच आहे परंतु मालकीचे `Waker` उपलब्ध असल्यास त्या बाबतीत थोडेसे कार्यक्षम असू शकतात.
    /// ही पद्धत `waker.clone().wake()` वर कॉल करण्यास प्राधान्य दिले पाहिजे.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // वास्तविक वेकअप कॉल अंमलबजावणीसाठी व्हर्च्युअल फंक्शन कॉलद्वारे नियुक्त केला जातो जो एक्झिक्यूटरद्वारे परिभाषित केला जातो.
        //

        // सुरक्षितता: `wake` पहा
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// हे `Waker` आणि दुसर्‍या `Waker` ने समान कार्य केले असेल तर `true` मिळवते.
    ///
    /// हे कार्य उत्कृष्ट-प्रयत्नांच्या आधारावर कार्य करते आणि जेव्हा वाकारचे कार्य समान जागृत करतील तेव्हा देखील ते चुकीचे परत येऊ शकतात.
    /// तथापि, जर हे कार्य `true` परत करते, तर हमी आहे की वाकर हे समान कार्य जागृत करतील.
    ///
    /// हे फंक्शन प्रामुख्याने ऑप्टिमायझेशनच्या उद्देशाने वापरले जाते.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// [`RawWaker`] वरून नवीन `Waker` तयार करते.
    ///
    /// [`RawWaker`] च्या आणि [`RawWakerVTable`] च्या दस्तऐवजीकरणामध्ये करार केलेला करार मान्य नसल्यास परत केलेल्या `Waker` चे वर्तन अपरिभाषित आहे.
    ///
    /// म्हणून ही पद्धत असुरक्षित आहे.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // सुरक्षितता: हे सुरक्षित आहे कारण `Waker::from_raw` हा एकमेव मार्ग आहे
            // `clone` आणि `data` प्रारंभ करण्यासाठी वापरकर्त्याने हे कबूल केले की [`RawWaker`] चा करार कायम आहे.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // सुरक्षितता: हे सुरक्षित आहे कारण `Waker::from_raw` हा एकमेव मार्ग आहे
        // `drop` आणि `data` प्रारंभ करण्यासाठी वापरकर्त्याने हे कबूल केले की `RawWaker` चा करार कायम आहे.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}