macro_rules! int_impl {
    ($SelfT:ty, $ActualT:ident, $UnsignedT:ty, $BITS:expr, $Min:expr, $Max:expr,
     $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
     $reversed:expr, $le_bytes:expr, $be_bytes:expr,
     $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// सर्वात लहान मूल्य जे या पूर्णांक प्रकाराद्वारे प्रतिनिधित्व केले जाऊ शकते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, ", stringify!($Min), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = !0 ^ ((!0 as $UnsignedT) >> 1) as Self;

        /// या पूर्णांक प्रकाराद्वारे प्रतिनिधित्व केले जाऊ शकणारे सर्वात मोठे मूल्य.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($Max), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !Self::MIN;

        /// बिटांमध्ये या पूर्णांक प्रकाराचे आकार.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// दिलेल्या बेसमधील स्ट्रिंग स्लाइस पूर्णांकीमध्ये रूपांतरित करते.
        ///
        /// स्ट्रिंग अंकांनंतर पर्यायी `+` किंवा `-` चिन्ह असेल.
        /// अग्रगण्य आणि अनुगामी व्हाइटस्पेस त्रुटी दर्शवते.
        /// अंक हे वर्णांचे उपसमूह आहेत, `radix` वर अवलंबून:
        ///
        ///  * `0-9`
        ///  * `a-z`
        ///  * `A-Z`
        ///
        /// # Panics
        ///
        /// `radix` 2 ते 36 पर्यंतच्या श्रेणीमध्ये नसल्यास हे कार्य panics.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// `self` च्या बायनरी प्रतिनिधित्वात असलेल्यांची संख्या मिळवते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("let n = 0b100_0000", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 1);
        ///
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 { (self as $UnsignedT).count_ones() }

        /// `self` च्या बायनरी प्रतिनिधित्वातील शून्यांची संख्या मिळवते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// `self` च्या बायनरी प्रतिनिधित्त्वात अग्रणी असलेल्या शून्यांची संख्या मिळवते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]
        /// assert_eq!(n.leading_zeros(), 0);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            (self as $UnsignedT).leading_zeros()
        }

        /// `self` च्या बायनरी प्रतिनिधित्त्वात अनुगामी शून्यांची संख्या मिळवते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("let n = -4", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            (self as $UnsignedT).trailing_zeros()
        }

        /// `self` च्या बायनरी प्रतिनिधित्वात अग्रगण्य असलेल्यांची संख्या मिळवते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]

        #[doc = concat!("assert_eq!(n.leading_ones(), ", stringify!($BITS), ");")]
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (self as $UnsignedT).leading_ones()
        }

        /// `self` च्या बायनरी प्रतिनिधित्वामध्ये पिछाडीवर असलेल्यांची संख्या मिळवते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("let n = 3", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (self as $UnsignedT).trailing_ones()
        }

        /// बिट्स डाव्या बाजूस निर्दिष्ट रक्कम, `n` ने बदलून, परिणामी पूर्णांकाच्या शेवटी काटलेल्या बिट्स लपेटून.
        ///
        ///
        /// कृपया लक्षात घ्या की हे `<<` शिफ्टिंग ऑपरेटरसारखेच ऑपरेशन नाही!
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_left(n) as Self
        }

        /// विणलेल्या बिट्सला परिणामी पूर्णांकाच्या सुरूवातीस लपेटून, निर्दिष्ट रकमे `n` ने बिट्स उजवीकडे हलवा.
        ///
        ///
        /// कृपया लक्षात घ्या की हे `>>` शिफ्टिंग ऑपरेटरसारखेच ऑपरेशन नाही!
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_right(n) as Self
        }

        /// पूर्णांकीची बाइट क्रम उलट करते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// द्या मी=एक्स 100 एक्स;
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            (self as $UnsignedT).swap_bytes() as Self
        }

        /// पूर्णांकातील बिट्सचा क्रम उलट करते.
        /// कमीतकमी महत्त्वपूर्ण बिट सर्वात महत्त्वपूर्ण बिट बनतो, दुसरे सर्वात कमी-महत्त्वपूर्ण बिट दुसर्‍या क्रमांकाचे महत्त्वाचे बीट बनते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// द्या मी=एक्स 100 एक्स;
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            (self as $UnsignedT).reverse_bits() as Self
        }

        /// मोठ्या अंतःकरणातून पूर्णतेचे लक्ष्य च्या अंत्यलयास रुपांतर करते.
        ///
        /// मोठ्या एंडियनवर ही एक निवड नाही.छोट्या एरियनवर बाइट स्वॅप केले जातात.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// जर सीएफजी! (लक्ष्य_सेडियन=एक्स 100 एक्स){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } अन्य {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// लघुत्तम अंतरापासून पूर्णतेचे लक्ष्य च्या अंत्यलयास रुपांतर करते.
        ///
        /// थोड्या एंडियनवर ही एक निवड नाही.मोठ्या एरियनवर बाइट स्वॅप केले जातात.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// जर सीएफजी! (लक्ष्य_सेडियन=एक्स 100 एक्स){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } अन्य {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// `self` ला लक्ष्याच्या अंत्यांपासून मोठ्या एंडियनमध्ये रुपांतरित करते.
        ///
        /// मोठ्या एंडियनवर ही एक निवड नाही.छोट्या एरियनवर बाइट स्वॅप केले जातात.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// जर सीएफजी! (लक्ष्य_सेडियन=एक्स 100 एक्स){
        ///     assert_eq!(n.to_be(), n)
        /// X अन्य { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // की नाही?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// `self` ला लक्ष्यच्या अंत्यांपासून थोडे अंत्येक रुपांतरीत करते.
        ///
        /// थोड्या एंडियनवर ही एक निवड नाही.मोठ्या एरियनवर बाइट स्वॅप केले जातात.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// जर सीएफजी! (लक्ष्य_सेडियन=एक्स 100 एक्स){
        ///     assert_eq!(n.to_le(), n)
        /// X अन्य { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// पूर्णांक संख्‍या तपासली.
        /// ओव्हरफ्लो झाल्यास `self + rhs` चे परिक्षण, X01 एक्स परत करणे.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), Some(", stringify!($SelfT), "::MAX - 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// पूर्ण न केलेले पूर्णांक जोडओव्हरफ्लो येऊ शकत नाही असे गृहीत धरून `self + rhs` ची गणना करा.
        /// याचा परिणाम तेव्हा होतो
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // सुरक्षितता: कॉलरने `unchecked_add` साठी सुरक्षितता करार पाळला पाहिजे.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// पूर्णांक वजाबाकी तपासली.
        /// ओव्हरफ्लो झाल्यास `self - rhs` चे परिक्षण, X01 एक्स परत करणे.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(1), Some(", stringify!($SelfT), "::MIN + 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// पूर्ण न केलेले पूर्णांक वजाबाकी.ओव्हरफ्लो येऊ शकत नाही असे गृहीत धरून `self - rhs` ची गणना करा.
        /// याचा परिणाम तेव्हा होतो
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // सुरक्षितता: कॉलरने `unchecked_sub` साठी सुरक्षितता करार पाळला पाहिजे.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// पूर्णांक पूर्णांक गुणाकार केला.
        /// ओव्हरफ्लो झाल्यास `self * rhs` चे परिक्षण, X01 एक्स परत करणे.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(1), Some(", stringify!($SelfT), "::MAX));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// पूर्ण न केलेले पूर्णांक गुणाकार.ओव्हरफ्लो येऊ शकत नाही असे गृहीत धरून `self * rhs` ची गणना करा.
        /// याचा परिणाम तेव्हा होतो
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // सुरक्षितता: कॉलरने `unchecked_mul` साठी सुरक्षितता करार पाळला पाहिजे.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// पूर्णांक विभाग तपासला.
        /// एक्स 100 एक्सची गणना करते, एक्स0 2 एक्स किंवा डिव्हिजनच्या परिणामी ओव्हरफ्लो झाल्यास एक्स 0 एक्स एक्स परत.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // सुरक्षितता: शून्य बाय आयएनआयएमएमआयएन द्वारा वर तपासले गेले आहे
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// युक्लिडियन विभाग तपासला.
        /// एक्स 100 एक्सची गणना करते, एक्स0 2 एक्स किंवा डिव्हिजनच्या परिणामी ओव्हरफ्लो झाल्यास एक्स 0 एक्स एक्स परत.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div_euclid(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div_euclid(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }

        /// पूर्णांक पूर्ण केले.
        /// एक्स 100 एक्सची गणना करते, एक्स0 2 एक्स किंवा डिव्हिजनच्या परिणामी ओव्हरफ्लो झाल्यास एक्स 0 एक्स एक्स परत.
        ///
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem(-1), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // सुरक्षितता: शून्य बाय आयएनआयएमएमआयएन द्वारा वर तपासले गेले आहे
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// युक्लिडियन उर्वरित तपासणी केली.
        /// एक्स 100 एक्सची गणना करते, एक्स0 2 एक्स किंवा डिव्हिजनच्या परिणामी ओव्हरफ्लो झाल्यास एक्स 0 एक्स एक्स परत.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem_euclid(-1), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// नकार तपासला.
        /// `-self` ची गणना करते, `self == MIN` असल्यास `None` परत करते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_neg(), Some(-5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// शिफ्ट डावीकडे तपासले.
        /// `self << rhs` ची गणना करत आहे, `rhs` हे `self` मधील बिटच्या संख्येपेक्षा मोठे किंवा त्यासारखे असल्यास `None` परत करेल.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// शिफ्टची उजवी तपासणी केली.
        /// `self >> rhs` ची गणना करीत आहे, `rhs` हे `self` मधील बिटच्या संख्येपेक्षा मोठे किंवा त्यासारखे असल्यास `None` परत करेल.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(128), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// परिपूर्ण मूल्य तपासले.
        /// `self.abs()` ची गणना करते, `self == MIN` असल्यास `None` परत करते.
        ///
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-5", stringify!($SelfT), ").checked_abs(), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_abs(), None);")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_abs(self) -> Option<Self> {
            if self.is_negative() {
                self.checked_neg()
            } else {
                Some(self)
            }
        }

        /// तपासणी केली.
        /// ओव्हरफ्लो झाल्यास `self.pow(exp)` चे परिक्षण, X01 एक्स परत करणे.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(8", stringify!($SelfT), ".checked_pow(2), Some(64));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```

        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }
            // एक्सपा!=0 पासून, शेवटी समाप्ती 1 असणे आवश्यक आहे.
            // घातांकच्या अंतिम बिटसह स्वतंत्रपणे काम करा, कारण नंतर बेस स्क्वेअर करणे आवश्यक नाही आणि अनावश्यक ओव्हरफ्लो होऊ शकते.
            //
            //
            Some(try_opt!(acc.checked_mul(base)))
        }

        /// पूर्णांक पूर्णांक
        /// कॉम्प्यूट्स एक्स00 एक्स, ओव्हरफ्लो करण्याऐवजी अंकांच्या सीमेवर भरल्यावर.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(100), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_add(-1), ", stringify!($SelfT), "::MIN);")]
        /// ```

        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// पूर्णांक पूर्णांक पूर्णांक.
        /// कॉम्प्यूट्स एक्स00 एक्स, ओव्हरफ्लो करण्याऐवजी अंकांच्या सीमेवर भरल्यावर.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(127), -27);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_sub(100), ", stringify!($SelfT), "::MIN);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_sub(-1), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// पूर्णांक पूर्णांक नकारात्मक.
        /// `-self` ची गणना करते, ओव्हरफ्लो करण्याऐवजी `self == MIN` असल्यास X01 एक्स परत करते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_neg(), -100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_neg(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_neg(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_neg(), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_neg(self) -> Self {
            intrinsics::saturating_sub(0, self)
        }

        /// परिपूर्ण मूल्य संतुष्ट करणे.
        /// `self.abs()` ची गणना करते, ओव्हरफ्लो करण्याऐवजी `self == MIN` असल्यास X01 एक्स परत करते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_abs(self) -> Self {
            if self.is_negative() {
                self.saturating_neg()
            } else {
                self
            }
        }

        /// पूर्णांक पूर्णांक पूर्णांक.
        /// कॉम्प्यूट्स एक्स00 एक्स, ओव्हरफ्लो करण्याऐवजी अंकांच्या सीमेवर भरल्यावर.
        ///
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".saturating_mul(12), 120);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_mul(10), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_mul(10), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => if (self < 0) == (rhs < 0) {
                    Self::MAX
                } else {
                    Self::MIN
                }
            }
        }

        /// पूर्णांक पूर्णता वाढवणे.
        /// कॉम्प्यूट्स एक्स00 एक्स, ओव्हरफ्लो करण्याऐवजी अंकांच्या सीमेवर भरल्यावर.
        ///
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-4", stringify!($SelfT), ").saturating_pow(3), -64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(3), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None if self < 0 && exp % 2 == 1 => Self::MIN,
                None => Self::MAX,
            }
        }

        /// लपेटणे (modular) जोड
        /// प्रकाराच्या सीमेवर गुंडाळत `self + rhs` ची गणना करते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_add(27), 127);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_add(2), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// लपेटणे (modular) वजाबाकी.
        /// प्रकाराच्या सीमेवर गुंडाळत `self - rhs` ची गणना करते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".wrapping_sub(127), -127);")]
        #[doc = concat!("assert_eq!((-2", stringify!($SelfT), ").wrapping_sub(", stringify!($SelfT), "::MAX), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// गुंडाळणे (modular) गुणाकार.
        /// प्रकाराच्या सीमेवर गुंडाळत `self * rhs` ची गणना करते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".wrapping_mul(12), 120);")]
        /// assert_eq!(11i8.wrapping_mul(12), -124);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// लपेटणे (modular) विभाग.प्रकाराच्या सीमेवर गुंडाळत `self / rhs` ची गणना करते.
        ///
        /// जेव्हा अशा प्रकारचे लपेटणे शक्य होते तेव्हाच जेव्हा एखाद्याने हस्ताक्षरित प्रकारावर `MIN / -1` विभाजित केले (जेथे एक्स 0 2 एक्स प्रकारासाठी नकारात्मक किमान मूल्य आहे);हे एक्स 100 एक्स च्या समतुल्य आहे, एक सकारात्मक मूल्य जे प्रकारात प्रतिनिधित्व करण्यासाठी खूप मोठे आहे.
        /// अशा परिस्थितीत हे कार्य स्वतः `MIN` परत करते.
        ///
        /// # Panics
        ///
        /// `rhs` 0 असल्यास हे कार्य panic करेल.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div(-1), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self.overflowing_div(rhs).0
        }

        /// युकलिडियन विभाग लपेटणे.
        /// प्रकाराच्या सीमेवर गुंडाळत `self.div_euclid(rhs)` ची गणना करते.
        ///
        /// लपेटणे केवळ एक्स-एक्सएक्सएक्समध्ये एका स्वाक्षरीकृत प्रकारावर उद्भवेल (जिथे प्रकारासाठी एक्स ०१ एक्स नकारात्मक किमान मूल्य आहे).
        /// हे एक्स 100 एक्स च्या समतुल्य आहे, एक सकारात्मक मूल्य जे प्रकारात प्रतिनिधित्व करण्यासाठी खूप मोठे आहे.
        /// या प्रकरणात, ही पद्धत स्वतः `MIN` परत करते.
        ///
        /// # Panics
        ///
        /// `rhs` 0 असल्यास हे कार्य panic करेल.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div_euclid(-1), -128);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self.overflowing_div_euclid(rhs).0
        }

        /// (modular) उर्वरित लपेटणे.प्रकाराच्या सीमेवर गुंडाळत `self % rhs` ची गणना करते.
        ///
        /// अशी लपेटणे प्रत्यक्षात गणिताने कधीच उद्भवत नाही;अंमलबजावणी कृत्रिमता एका चिन्हांकित प्रकारावर `MIN / -1` साठी `x % y` अवैध बनवते (जिथे `MIN` नकारात्मक किमान मूल्य आहे).
        ///
        /// अशा परिस्थितीत, हे कार्य एक्स 100 एक्स परत करते.
        ///
        /// # Panics
        ///
        /// `rhs` 0 असल्यास हे कार्य panic करेल.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem(-1), 0);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self.overflowing_rem(rhs).0
        }

        /// युक्लिडियन उर्वरित लपेटणे.प्रकाराच्या सीमेवर गुंडाळत `self.rem_euclid(rhs)` ची गणना करते.
        ///
        /// लपेटणे केवळ एक्स-एक्सएक्सएक्समध्ये एका स्वाक्षरीकृत प्रकारावर उद्भवेल (जिथे प्रकारासाठी एक्स ०१ एक्स नकारात्मक किमान मूल्य आहे).
        /// या प्रकरणात, ही पद्धत 0 देते.
        ///
        /// # Panics
        ///
        /// `rhs` 0 असल्यास हे कार्य panic करेल.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem_euclid(-1), 0);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self.overflowing_rem_euclid(rhs).0
        }

        /// लपेटणे (modular) नकार.प्रकाराच्या सीमेवर गुंडाळत `-self` ची गणना करते.
        ///
        /// जेव्हा अशा प्रकारच्या लपेटणे उद्भवते तेव्हाच जेव्हा एखाद्याने हस्ताक्षरित प्रकारावर `MIN` ला नकार दिला (जेथे एक्स 0 एक्स एक्स प्रकाराचे नकारात्मक किमान मूल्य आहे);हे एक सकारात्मक मूल्य आहे जे प्रकारात प्रतिनिधित्व करण्यासाठी खूप मोठे आहे.
        /// अशा परिस्थितीत हे कार्य स्वतः `MIN` परत करते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_neg(), -100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_neg(), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// झेडपॅनिक ० झेड फ्री बिटवाइज शिफ्ट-डावे;`self << mask(rhs)` देते, जेथे `mask` `rhs` चे कोणतेही उच्च-ऑर्डर बिट्स काढून टाकते ज्यामुळे शिफ्ट प्रकाराच्या बिटविड्थपेक्षा जास्त असेल.
        ///
        /// लक्षात घ्या की हे *फिरवलेल्या डावीसारखे नाही* आहे;LHS मधून हलविलेले बिट्स दुसर्‍या टोकाला परत आणण्याऐवजी, लपेटण्याच्या शिफ्ट-डाव्या आरएचएस प्रकाराच्या मर्यादेपर्यंत मर्यादित आहेत.
        ///
        /// आदिम पूर्णांक सर्व एक [`rotate_left`](Self::rotate_left) फंक्शनची अंमलबजावणी करतात, जे त्याऐवजी आपल्याला हवे असलेले असू शकते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(7), -128);")]
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(128), -1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // सुरक्षितता: प्रकारच्या बिटसाइजद्वारे मुखवटा लावल्याने हे सुनिश्चित होते की आपण शिफ्ट होणार नाही
            // मर्यादा बाहेर
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// झेडपॅनिक ० झेड फ्री बिटवाइज शिफ्ट-राइट;`self >> mask(rhs)` देते, जेथे `mask` `rhs` चे कोणतेही उच्च-ऑर्डर बिट्स काढून टाकते ज्यामुळे शिफ्ट प्रकाराच्या बिटविड्थपेक्षा जास्त असेल.
        ///
        /// लक्षात घ्या की हे * फिरवा-उजवीकडे समान नाही;LHS मधून हलविलेले बिट्स दुसर्‍या टोकाला परत आणण्याऐवजी, लपेटण्याच्या शिफ्ट-राईटच्या आरएचएस प्रकाराच्या मर्यादेपर्यंत मर्यादित आहेत.
        ///
        /// आदिम पूर्णांक सर्व एक [`rotate_right`](Self::rotate_right) फंक्शनची अंमलबजावणी करतात, जे त्याऐवजी आपल्याला हवे असलेले असू शकते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-128", stringify!($SelfT), ").wrapping_shr(7), -1);")]
        /// assert_eq!((-128i16).wrapping_shr(64), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // सुरक्षितता: प्रकारच्या बिटसाइजद्वारे मुखवटा लावल्याने हे सुनिश्चित होते की आपण शिफ्ट होणार नाही
            // मर्यादा बाहेर
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// (modular) परिपूर्ण मूल्य लपेटणे.प्रकाराच्या सीमेवर गुंडाळत `self.abs()` ची गणना करते.
        ///
        /// अशा प्रकारचे लपेटणे शक्य होते तेव्हाच जेव्हा प्रकारासाठी नकारात्मक किमान मूल्याचे परिपूर्ण मूल्य घेतले जाते;हे एक सकारात्मक मूल्य आहे जे प्रकारात प्रतिनिधित्व करण्यासाठी खूप मोठे आहे.
        /// अशा परिस्थितीत हे कार्य स्वतः `MIN` परत करते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_abs(), ", stringify!($SelfT), "::MIN);")]
        /// assert_eq!((-128i8).wrapping_abs() as u8, 128);
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        pub const fn wrapping_abs(self) -> Self {
             if self.is_negative() {
                 self.wrapping_neg()
             } else {
                 self
             }
        }

        /// कोणतीही लपेटणे किंवा घाबरून न जाता `self` च्या परिपूर्ण मूल्याची गणना करते.
        ///
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        /// assert_eq!((-128i8).unsigned_abs(), 128u8);
        /// ```
        #[stable(feature = "unsigned_abs", since = "1.51.0")]
        #[rustc_const_stable(feature = "unsigned_abs", since = "1.51.0")]
        #[inline]
        pub const fn unsigned_abs(self) -> $UnsignedT {
             self.wrapping_abs() as $UnsignedT
        }

        /// एक्स 100 एक्सचा विस्तार लपेटणे.
        /// प्रकाराच्या सीमेवर गुंडाळत `self.pow(exp)` ची गणना करते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(4), 81);")]
        /// assert_eq!(3i8.wrapping_pow(5), -13);
        /// assert_eq!(3i8.wrapping_pow(6), -39);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // एक्सपा!=0 पासून, शेवटी समाप्ती 1 असणे आवश्यक आहे.
            // घातांकच्या अंतिम बिटसह स्वतंत्रपणे काम करा, कारण नंतर बेस स्क्वेअर करणे आवश्यक नाही आणि अनावश्यक ओव्हरफ्लो होऊ शकते.
            //
            //
            acc.wrapping_mul(base)
        }

        /// `self` + `rhs` ची गणना करते
        ///
        /// अंकित अंकगणित ओव्हरफ्लो होईल की नाही हे दर्शविणार्‍या बुलियनसह बेरीजची बेरीज मिळवते.
        /// जर ओव्हरफ्लो झाला असेल तर गुंडाळलेले मूल्य परत केले जाईल.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self`, `rhs` ची गणना करते
        ///
        /// अंकित अंकगणित ओव्हरफ्लो होईल की नाही हे दर्शविणार्‍या बुलियनसह वजाबाकीचे एक गुंतागुंत मिळवते.
        /// जर ओव्हरफ्लो झाला असेल तर गुंडाळलेले मूल्य परत केले जाईल.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` आणि `rhs` च्या गुणाची गणना करते.
        ///
        /// अंकातील अंकगणित ओव्हरफ्लो होईल की नाही हे दर्शविणार्‍या बुलियनसह गुणाकाराचा एक भाग मिळवते.
        /// जर ओव्हरफ्लो झाला असेल तर गुंडाळलेले मूल्य परत केले जाईल.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_mul(2), (10, false));")]
        /// assert_eq!(1_000_000_000i32.overflowing_mul(10), (1410065408, खरे));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` `rhs` ने विभाजित केल्यावर विभाजकांची गणना करते.
        ///
        /// अंकगणित ओव्हरफ्लो होईल की नाही हे दर्शविणार्‍या बुलियनसह भागाचे टुप्ल मिळवते.
        /// जर ओव्हरफ्लो होईल तर स्वत: ला परत केले जाईल.
        ///
        /// # Panics
        ///
        /// `rhs` 0 असल्यास हे कार्य panic करेल.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self / rhs, false)
            }
        }

        /// युक्लिडियन विभाग `self.div_euclid(rhs)` च्या भागांची गणना करते.
        ///
        /// अंकगणित ओव्हरफ्लो होईल की नाही हे दर्शविणार्‍या बुलियनसह भागाचे टुप्ल मिळवते.
        /// जर ओव्हरफ्लो होईल तर `self` परत येईल.
        ///
        /// # Panics
        ///
        /// `rhs` 0 असल्यास हे कार्य panic करेल.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div_euclid(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self.div_euclid(rhs), false)
            }
        }

        /// `self` `rhs` ने विभाजित केल्यावर उर्वरितची गणना करते.
        ///
        /// अंकित अंकगणित ओव्हरफ्लो होईल की नाही हे दर्शविणार्‍या बुलियनसह भागाकार केल्यानंतर उर्वरित भागांची परत मिळवते.
        /// जर ओव्हरफ्लो होईल तर 0 परत येईल.
        ///
        /// # Panics
        ///
        /// `rhs` 0 असल्यास हे कार्य panic करेल.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem(-1), (0, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self % rhs, false)
            }
        }


        /// ओव्हरफ्लोिंग युक्लिडियन उर्वरित.`self.rem_euclid(rhs)` ची गणना करते.
        ///
        /// अंकित अंकगणित ओव्हरफ्लो होईल की नाही हे दर्शविणार्‍या बुलियनसह भागाकार केल्यानंतर उर्वरित भागांची परत मिळवते.
        /// जर ओव्हरफ्लो होईल तर 0 परत येईल.
        ///
        /// # Panics
        ///
        /// `rhs` 0 असल्यास हे कार्य panic करेल.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem_euclid(-1), (0, true));")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self.rem_euclid(rhs), false)
            }
        }


        /// जर ते किमान मूल्याच्या बरोबरीचे असेल तर स्वयंचलितपणे नकारात्मक निगेट करतो.
        ///
        /// ओव्हरफ्लो झाला की नाही हे दर्शविणार्‍या बुलियनसह स्वार्थाच्या दुर्लक्षित आवृत्तीचा एक भाग मिळवते.
        /// जर एक्स ०१ एक्स हे किमान मूल्य असेल (उदा. एक्स ० एक्स एक्सच्या मूल्यांसाठी एक्स १० एक्स), तर कमीतकमी मूल्य परत येईल आणि ओव्हरफ्लो होण्याकरिता एक्स ०२ एक्स परत येईल.
        ///
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_neg(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            if unlikely!(self == Self::MIN) {
                (Self::MIN, true)
            } else {
                (-self, false)
            }
        }

        /// `rhs` बिट्सद्वारे स्वत: डावीकडे शिफ्ट करा.
        ///
        /// शिफ्टचे मूल्य बिट्सच्या संख्येपेक्षा मोठे किंवा समान होते की नाही हे दर्शविणार्‍या बुलियनसह स्वतःच्या रूपांतरित आवृत्तीचे एक टिपल मिळवते.
        /// जर शिफ्ट मूल्य खूप मोठे असेल तर मूल्य बिछान्यांची संख्या आहे तिथे (N-1) चे मुखवटा घातलेले असेल आणि नंतर हे मूल्य शिफ्ट करण्यासाठी वापरले जाईल.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT),".overflowing_shl(4), (0x10, false));")]
        /// assert_eq!(0x1i32.overflowing_shl(36), (0x10, खरे));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// एक्स00 एक्स बिट्सद्वारे स्वत: ची उजवीकडे शिफ्ट करा.
        ///
        /// शिफ्टचे मूल्य बिट्सच्या संख्येपेक्षा मोठे किंवा समान होते की नाही हे दर्शविणार्‍या बुलियनसह स्वतःच्या रूपांतरित आवृत्तीचे एक टिपल मिळवते.
        /// जर शिफ्ट मूल्य खूप मोठे असेल तर मूल्य बिछान्यांची संख्या आहे तिथे (N-1) चे मुखवटा घातलेले असेल आणि नंतर हे मूल्य शिफ्ट करण्यासाठी वापरले जाईल.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        /// assert_eq!(0x10i32.overflowing_shr(36), (0x1, सत्य));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// `self` च्या परिपूर्ण मूल्याची गणना करते.
        ///
        /// ओव्हरफ्लो झाला की नाही हे दर्शविणार्‍या बुलियनसह स्वत: च्या निरपेक्ष आवृत्तीचे टिपल मिळवते.
        /// जर स्वत: चे किमान मूल्य असेल तर
        #[doc = concat!("(e.g., ", stringify!($SelfT), "::MIN for values of type ", stringify!($SelfT), "),")]
        /// तर कमीतकमी मूल्य परत मिळवले जाईल आणि ओव्हरफ्लो होत असल्यास सत्य परत येईल.
        ///
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN).overflowing_abs(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn overflowing_abs(self) -> (Self, bool) {
            (self.wrapping_abs(), self == Self::MIN)
        }

        /// स्क्वेअरिंगद्वारे एक्सपेंशनेशन वापरुन एक्स00 एक्सच्या सामर्थ्यावर स्वत: ला वाढवते.
        ///
        /// ओव्हरफ्लो झाली की नाही हे दर्शविणार्‍या झेडबूल0 झेडसह घरोघरी एक टप्पल मिळवते.
        ///
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(4), (81, false));")]
        /// assert_eq!(3i8.overflowing_pow(5), (-13, सत्य));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0 {
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // ओव्हरफ्लोिंग_मूलच्या परिणाम संग्रहित करण्यासाठी स्क्रॅच स्पेस.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // एक्सपा!=0 पासून, शेवटी समाप्ती 1 असणे आवश्यक आहे.
            // घातांकच्या अंतिम बिटसह स्वतंत्रपणे काम करा, कारण नंतर बेस स्क्वेअर करणे आवश्यक नाही आणि अनावश्यक ओव्हरफ्लो होऊ शकते.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;
            r
        }

        /// स्क्वेअरिंगद्वारे एक्सपेंशनेशन वापरुन एक्स00 एक्सच्या सामर्थ्यावर स्वत: ला वाढवते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("let x: ", stringify!($SelfT), " = 2; // or any other integer type")]
        /// assert_eq!(x.pow(5), 32);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // एक्सपा!=0 पासून, शेवटी समाप्ती 1 असणे आवश्यक आहे.
            // घातांकच्या अंतिम बिटसह स्वतंत्रपणे काम करा, कारण नंतर बेस स्क्वेअर करणे आवश्यक नाही आणि अनावश्यक ओव्हरफ्लो होऊ शकते.
            //
            //
            acc * base
        }

        /// `self` च्या `self` च्या युक्लिडियन भागाच्या भागांची गणना करते.
        ///
        /// हे पूर्णांक `n` ची गणना करते जसे की `self = n * rhs + self.rem_euclid(rhs)`, `0 <= self.rem_euclid(rhs) < rhs` सह.
        ///
        ///
        /// दुसर्‍या शब्दांत, याचा परिणाम म्हणजे `self / rhs` पूर्णांक पूर्णांक `n` अशा `self >= n * rhs`.
        /// जर एक्स 100 एक्स, हे शून्याच्या दिशेने गोल (Rust मधील डीफॉल्ट) च्या बरोबरीचे असेल;
        /// `self < 0` असल्यास, हे +/-अनंत दिशेने गोल करण्यासाठी समान आहे.
        ///
        /// # Panics
        ///
        /// हे कार्य panic करेल जर `rhs` 0 असेल किंवा विभाजनाचा परिणाम ओव्हरफ्लो होईल.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// द्या बी=4;
        ///
        /// assert_eq!(a.div_euclid(b), 1); //7>=4 *1 एक्स 100 एक्स, एक्स0 9 एक्स);//7>= -4*-1 assert_eq!((-a).div_euclid(b), -2);//-7>=4 *-2 assert_eq!((-a).div_euclid(-b), 2);//-7>= -4* 2
        ///
        /// ```
        ///
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            let q = self / rhs;
            if self % rhs < 0 {
                return if rhs > 0 { q - 1 } else { q + 1 }
            }
            q
        }


        /// `self (mod rhs)` च्या सर्वात कमी नॉनगेटिव्ह उर्वरिताची गणना करते.
        ///
        /// हे असे केले जाते की युक्लिडियन विभाग अल्गोरिदमद्वारे-दिले गेले आहे `r = self.rem_euclid(rhs)`, `self = rhs * self.div_euclid(rhs) + r` आणि `0 <= r < abs(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// हे कार्य panic करेल जर `rhs` 0 असेल किंवा विभाजनाचा परिणाम ओव्हरफ्लो होईल.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// द्या बी=4;
        ///
        /// assert_eq!(a.rem_euclid(b), 3);
        /// assert_eq!((-a).rem_euclid(b), 1);
        /// assert_eq!(a.rem_euclid(-b), 3);
        /// assert_eq!((-a).rem_euclid(-b), 1);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            let r = self % rhs;
            if r < 0 {
                if rhs < 0 {
                    r - rhs
                } else {
                    r + rhs
                }
            } else {
                r
            }
        }

        /// `self` च्या परिपूर्ण मूल्याची गणना करते.
        ///
        /// # ओव्हरफ्लो वर्तन
        ///
        /// चे परिपूर्ण मूल्य
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// म्हणून प्रस्तुत केले जाऊ शकत नाही
        #[doc = concat!("`", stringify!($SelfT), "`,")]
        /// आणि त्याची गणना करण्याचा प्रयत्न केल्यास ओव्हरफ्लो होईल.
        /// याचा अर्थ असा की डीबग मोडमधील कोड या प्रकरणात झेडस्पॅनिक 0 झेड ट्रिगर करेल आणि ऑप्टिमाइझ कोड परत येईल
        ///
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// panic शिवाय.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".abs(), 10);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").abs(), 10);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn abs(self) -> Self {
            // लक्षात ठेवा की वरील#[इनलाइन] म्हणजे वजाबाकीचे ओव्हरफ्लो अर्थशास्त्र ज्यामध्ये आपण निहित आहोत त्या crate वर अवलंबून आहे.
            //
            //
            if self.is_negative() {
                -self
            } else {
                self
            }
        }

        /// `self` चे चिन्ह दर्शविणारी संख्या मिळवते.
        ///
        ///  - `0` जर संख्या शून्य असेल तर
        ///  - `1` संख्या सकारात्मक असल्यास
        ///  - `-1` संख्या नकारात्मक असल्यास
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".signum(), 1);")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".signum(), 0);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").signum(), -1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_sign", since = "1.47.0")]
        #[inline]
        pub const fn signum(self) -> Self {
            match self {
                n if n > 0 =>  1,
                0          =>  0,
                _          => -1,
            }
        }

        /// `self` सकारात्मक असल्यास `true` आणि संख्या शून्य किंवा नकारात्मक असल्यास X02 एक्स मिळवते.
        ///
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert!(10", stringify!($SelfT), ".is_positive());")]
        #[doc = concat!("assert!(!(-10", stringify!($SelfT), ").is_positive());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_positive(self) -> bool { self > 0 }

        /// `self` नकारात्मक असल्यास `true` आणि संख्या शून्य किंवा सकारात्मक असल्यास `true` परत करते.
        ///
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert!((-10", stringify!($SelfT), ").is_negative());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_negative());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_negative(self) -> bool { self < 0 }

        /// बिग-एंडियन (network) बाइट ऑर्डरमध्ये या पूर्णांकाचे मेमरी प्रतिनिधित्व बाइट अ‍ॅरे म्हणून परत करा.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// या पूर्णांकाचे स्मरणशक्ती लघु-अंतिय बाइट क्रमाने बाइट अ‍ॅरे म्हणून परत करा.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// या पूर्णांकाचे मेमरी प्रतिनिधित्व मूळ बाइट ऑर्डरमध्ये बाइट अ‍ॅरे म्हणून द्या.
        ///
        /// टार्गेट प्लॅटफॉर्मचा मूळ अंतःकरण वापरला जात आहे म्हणून पोर्टेबल कोडने त्याऐवजी [`to_be_bytes`] किंवा [`to_le_bytes`] वापरावे.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     बाइट्स, जर सीएफजी! (लक्ष्य_सेडियन=एक्स 100 एक्स){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } अन्य {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // सुरक्षितता: तटबंदीचा आवाज कारण पूर्णांक जुना डेटाटाइप असतो म्हणून आम्ही नेहमीच असतो
        // त्यांना बाइटच्या अ‍ॅरेमध्ये संक्रमित करा
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // सुरक्षितता: पूर्णांक जुने डेटाटेटाइप असतात जेणेकरून आम्ही त्यांना नेहमी संक्रमित करू शकतो
            // बाइटचे अ‍ॅरे
            unsafe { mem::transmute(self) }
        }

        /// या पूर्णांकाचे मेमरी प्रतिनिधित्व मूळ बाइट ऑर्डरमध्ये बाइट अ‍ॅरे म्हणून द्या.
        ///
        ///
        /// [`to_ne_bytes`] जेव्हा शक्य असेल तेव्हा यापेक्षा त्यास प्राधान्य दिले पाहिजे.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// ले बाइट्स=एक्स00 एक्स;
        /// assert_eq!(
        ///     बाइट्स, जर सीएफजी! (लक्ष्य_सेडियन=एक्स 100 एक्स){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } अन्य {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // सुरक्षितता: पूर्णांक जुने डेटाटेटाइप असतात जेणेकरून आम्ही त्यांना नेहमी संक्रमित करू शकतो
            // बाइटचे अ‍ॅरे
            unsafe { &*(self as *const Self as *const _) }
        }

        /// मोठ्या एरियनमध्ये बाइट अ‍ॅरे म्हणून त्याच्या प्रतिनिधीत्वातून पूर्णांक मूल्य तयार करा.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto वापरा;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * इनपुट=विश्रांती;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// थोड्या अंत्य अंतरामध्ये बाइट अ‍ॅरे म्हणून त्याच्या प्रतिनिधीत्वातून पूर्णांक मूल्य तयार करा.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto वापरा;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * इनपुट=विश्रांती;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// नेटिव्ह एंडॅनिनेसमध्ये बाइट अ‍ॅरे म्हणून त्याच्या मेमरी प्रतिनिधित्वामधून पूर्णांक मूल्य तयार करा.
        ///
        /// टार्गेट प्लॅटफॉर्मचा मूळ अंतःकरण वापरला जात आहे म्हणून पोर्टेबल कोड त्याऐवजी [`from_be_bytes`] किंवा [`from_le_bytes`] वापरू इच्छित आहे.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes)]
        /// } अन्य {
        #[doc = concat!("    ", $le_bytes)]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto वापरा;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * इनपुट=विश्रांती;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // सुरक्षितता: तटबंदीचा आवाज कारण पूर्णांक जुना डेटाटाइप असतो म्हणून आम्ही नेहमीच असतो
        // त्यांना हस्तांतरित
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // सुरक्षितता: पूर्णांक जुने डेटाटाइप असतात जेणेकरुन आम्ही त्यांच्याकडे नेहमी संक्रमण करू शकू
            unsafe { mem::transmute(bytes) }
        }

        /// नवीन कोड वापरण्यास प्राधान्य दिले पाहिजे
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// या पूर्णांक प्रकाराद्वारे प्रतिनिधित्व केले जाऊ शकते सर्वात लहान मूल्य मिळवते.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_min_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self {
            Self::MIN
        }

        /// नवीन कोड वापरण्यास प्राधान्य दिले पाहिजे
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// या पूर्णांक प्रकाराद्वारे प्रतिनिधित्व केले जाऊ शकते असे सर्वात मोठे मूल्य मिळवते.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self {
            Self::MAX
        }
    }
}