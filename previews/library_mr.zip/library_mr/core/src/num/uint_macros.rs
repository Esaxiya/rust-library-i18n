macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// सर्वात लहान मूल्य जे या पूर्णांक प्रकाराद्वारे प्रतिनिधित्व केले जाऊ शकते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// या पूर्णांक प्रकाराद्वारे प्रतिनिधित्व केले जाऊ शकणारे सर्वात मोठे मूल्य.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// बिटांमध्ये या पूर्णांक प्रकाराचे आकार.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// दिलेल्या बेसमधील स्ट्रिंग स्लाइस पूर्णांकीमध्ये रूपांतरित करते.
        ///
        /// स्ट्रिंग हे पर्यायी `+` चिन्ह असेल आणि त्यानंतर अंक असतील.
        ///
        /// अग्रगण्य आणि अनुगामी व्हाइटस्पेस त्रुटी दर्शवते.
        /// अंक हे वर्णांचे उपसमूह आहेत, `radix` वर अवलंबून:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// `radix` 2 ते 36 पर्यंतच्या श्रेणीमध्ये नसल्यास हे कार्य panics.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// `self` च्या बायनरी प्रतिनिधित्वात असलेल्यांची संख्या मिळवते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// `self` च्या बायनरी प्रतिनिधित्वातील शून्यांची संख्या मिळवते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// `self` च्या बायनरी प्रतिनिधित्त्वात अग्रणी असलेल्या शून्यांची संख्या मिळवते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// `self` च्या बायनरी प्रतिनिधित्त्वात अनुगामी शून्यांची संख्या मिळवते.
        ///
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// `self` च्या बायनरी प्रतिनिधित्वात अग्रगण्य असलेल्यांची संख्या मिळवते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// `self` च्या बायनरी प्रतिनिधित्वामध्ये पिछाडीवर असलेल्यांची संख्या मिळवते.
        ///
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// बिट्स डाव्या बाजूस निर्दिष्ट रक्कम, `n` ने बदलून, परिणामी पूर्णांकाच्या शेवटी काटलेल्या बिट्स लपेटून.
        ///
        ///
        /// कृपया लक्षात घ्या की हे `<<` शिफ्टिंग ऑपरेटरसारखेच ऑपरेशन नाही!
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// विणलेल्या बिट्सला परिणामी पूर्णांकाच्या सुरूवातीस लपेटून, निर्दिष्ट रकमे `n` ने बिट्स उजवीकडे हलवा.
        ///
        ///
        /// कृपया लक्षात घ्या की हे `>>` शिफ्टिंग ऑपरेटरसारखेच ऑपरेशन नाही!
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// पूर्णांकीची बाइट क्रम उलट करते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// द्या मी=एक्स 100 एक्स;
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// पूर्णांकातील बिट्सचा क्रम उलट करते.
        /// कमीतकमी महत्त्वपूर्ण बिट सर्वात महत्त्वपूर्ण बिट बनतो, दुसरे सर्वात कमी-महत्त्वपूर्ण बिट दुसर्‍या क्रमांकाचे महत्त्वाचे बीट बनते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// द्या मी=एक्स 100 एक्स;
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// मोठ्या अंतःकरणातून पूर्णतेचे लक्ष्य च्या अंत्यलयास रुपांतर करते.
        ///
        /// मोठ्या एंडियनवर ही एक निवड नाही.
        /// छोट्या एरियनवर बाइट स्वॅप केले जातात.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// जर सीएफजी! (लक्ष्य_सेडियन=एक्स 100 एक्स){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } अन्य {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// लघुत्तम अंतरापासून पूर्णतेचे लक्ष्य च्या अंत्यलयास रुपांतर करते.
        ///
        /// थोड्या एंडियनवर ही एक निवड नाही.
        /// मोठ्या एरियनवर बाइट स्वॅप केले जातात.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// जर सीएफजी! (लक्ष्य_सेडियन=एक्स 100 एक्स){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } अन्य {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// `self` ला लक्ष्याच्या अंत्यांपासून मोठ्या एंडियनमध्ये रुपांतरित करते.
        ///
        /// मोठ्या एंडियनवर ही एक निवड नाही.
        /// छोट्या एरियनवर बाइट स्वॅप केले जातात.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// जर सीएफजी! (लक्ष्य_सेडियन=एक्स 100 एक्स){
        ///     assert_eq!(n.to_be(), n)
        /// X अन्य { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // की नाही?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// `self` ला लक्ष्यच्या अंत्यांपासून थोडे अंत्येक रुपांतरीत करते.
        ///
        /// थोड्या एंडियनवर ही एक निवड नाही.
        /// मोठ्या एरियनवर बाइट स्वॅप केले जातात.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// जर सीएफजी! (लक्ष्य_सेडियन=एक्स 100 एक्स){
        ///     assert_eq!(n.to_le(), n)
        /// X अन्य { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// पूर्णांक संख्‍या तपासली.
        /// ओव्हरफ्लो झाल्यास `self + rhs` चे परिक्षण, X01 एक्स परत करणे.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// पूर्ण न केलेले पूर्णांक जोडओव्हरफ्लो येऊ शकत नाही असे गृहीत धरून `self + rhs` ची गणना करा.
        /// याचा परिणाम तेव्हा होतो
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // सुरक्षितता: कॉलरने `unchecked_add` साठी सुरक्षितता करार पाळला पाहिजे.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// पूर्णांक वजाबाकी तपासली.
        /// ओव्हरफ्लो झाल्यास `self - rhs` चे परिक्षण, X01 एक्स परत करणे.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// पूर्ण न केलेले पूर्णांक वजाबाकी.ओव्हरफ्लो येऊ शकत नाही असे गृहीत धरून `self - rhs` ची गणना करा.
        /// याचा परिणाम तेव्हा होतो
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // सुरक्षितता: कॉलरने `unchecked_sub` साठी सुरक्षितता करार पाळला पाहिजे.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// पूर्णांक पूर्णांक गुणाकार केला.
        /// ओव्हरफ्लो झाल्यास `self * rhs` चे परिक्षण, X01 एक्स परत करणे.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// पूर्ण न केलेले पूर्णांक गुणाकार.ओव्हरफ्लो येऊ शकत नाही असे गृहीत धरून `self * rhs` ची गणना करा.
        /// याचा परिणाम तेव्हा होतो
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // सुरक्षितता: कॉलरने `unchecked_mul` साठी सुरक्षितता करार पाळला पाहिजे.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// पूर्णांक विभाग तपासला.
        /// `self / rhs` ची गणना करते, `rhs == 0` असल्यास `None` परत करते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // सुरक्षितता: डिव्ह बाय शून्य वर तपासले गेले आहे आणि स्वाक्षरीकृत प्रकारांमध्ये इतर कोणतेही नाही
                // भागासाठी अपयशी पध्दती
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// युक्लिडियन विभाग तपासला.
        /// `self.div_euclid(rhs)` ची गणना करते, `rhs == 0` असल्यास `None` परत करते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// पूर्णांक पूर्ण केले.
        /// `self % rhs` ची गणना करते, `rhs == 0` असल्यास `None` परत करते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // सुरक्षितता: डिव्ह बाय शून्य वर तपासले गेले आहे आणि स्वाक्षरीकृत प्रकारांमध्ये इतर कोणतेही नाही
                // भागासाठी अपयशी पध्दती
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// युक्लिडियन मॉड्यूल चेक केले.
        /// `self.rem_euclid(rhs)` ची गणना करते, `rhs == 0` असल्यास `None` परत करते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// नकार तपासला.`-self` ची मोजणी करीत आहे, जोपर्यंत=स्वयं==जोपर्यंत X01 एक्स परत येत नाही
        /// 0`.
        ///
        /// लक्षात घ्या की कोणत्याही सकारात्मक पूर्णांकडे दुर्लक्ष केल्यास ती ओसंडून जाईल.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// शिफ्ट डावीकडे तपासले.
        /// `self << rhs` ची गणना करत आहे, `rhs` हे `self` मधील बिटच्या संख्येपेक्षा मोठे किंवा त्यासारखे असल्यास `None` परत करेल.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// शिफ्टची उजवी तपासणी केली.
        /// `self >> rhs` ची गणना करीत आहे, `rhs` हे `self` मधील बिटच्या संख्येपेक्षा मोठे किंवा त्यासारखे असल्यास `None` परत करेल.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// तपासणी केली.
        /// ओव्हरफ्लो झाल्यास `self.pow(exp)` चे परिक्षण, X01 एक्स परत करणे.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // एक्सपा!=0 पासून, शेवटी समाप्ती 1 असणे आवश्यक आहे.
            // घातांकच्या अंतिम बिटसह स्वतंत्रपणे काम करा, कारण नंतर बेस स्क्वेअर करणे आवश्यक नाही आणि अनावश्यक ओव्हरफ्लो होऊ शकते.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// पूर्णांक पूर्णांक
        /// कॉम्प्यूट्स एक्स00 एक्स, ओव्हरफ्लो करण्याऐवजी अंकांच्या सीमेवर भरल्यावर.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// पूर्णांक पूर्णांक पूर्णांक.
        /// कॉम्प्यूट्स एक्स00 एक्स, ओव्हरफ्लो करण्याऐवजी अंकांच्या सीमेवर भरल्यावर.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// पूर्णांक पूर्णांक पूर्णांक.
        /// कॉम्प्यूट्स एक्स00 एक्स, ओव्हरफ्लो करण्याऐवजी अंकांच्या सीमेवर भरल्यावर.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// पूर्णांक पूर्णता वाढवणे.
        /// कॉम्प्यूट्स एक्स00 एक्स, ओव्हरफ्लो करण्याऐवजी अंकांच्या सीमेवर भरल्यावर.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// लपेटणे (modular) जोड
        /// प्रकाराच्या सीमेवर गुंडाळत `self + rhs` ची गणना करते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// लपेटणे (modular) वजाबाकी.
        /// प्रकाराच्या सीमेवर गुंडाळत `self - rhs` ची गणना करते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// गुंडाळणे (modular) गुणाकार.
        /// प्रकाराच्या सीमेवर गुंडाळत `self * rhs` ची गणना करते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// कृपया लक्षात घ्या की हे उदाहरण पूर्णांक प्रकारांमध्ये सामायिक केलेले आहे.
        /// जे येथे `u8` का वापरले जाते हे स्पष्ट करते.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// लपेटणे (modular) विभाग.मोजणे `self / rhs`.
        /// स्वाक्षरीकृत प्रकारांवर गुंडाळलेला विभागणी म्हणजे सामान्य विभागणी.
        /// रॅपिंग कधीही होऊ शकत नाही.
        /// हे कार्य अस्तित्त्वात आहे, जेणेकरून सर्व ऑपरेशन्स रॅपिंग ऑपरेशनमध्ये जबाबदार आहेत.
        ///
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// युकलिडियन विभाग लपेटणे.मोजणे `self.div_euclid(rhs)`.
        /// स्वाक्षरीकृत प्रकारांवर गुंडाळलेला विभागणी म्हणजे सामान्य विभागणी.
        /// रॅपिंग कधीही होऊ शकत नाही.
        /// हे कार्य अस्तित्त्वात आहे, जेणेकरून सर्व ऑपरेशन्स रॅपिंग ऑपरेशनमध्ये जबाबदार आहेत.
        /// कारण, सकारात्मक पूर्णांकांकरिता, भागाच्या सर्व सामान्य व्याख्या समान आहेत, हे अगदी `self.wrapping_div(rhs)` च्या बरोबरीचे आहे.
        ///
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// (modular) उर्वरित लपेटणे.मोजणे `self % rhs`.
        /// स्वाक्षरीकृत प्रकारांवर लपेटलेली उर्वरित गणना फक्त नियमित उर्वरित गणना आहे.
        ///
        /// रॅपिंग कधीही होऊ शकत नाही.
        /// हे कार्य अस्तित्त्वात आहे, जेणेकरून सर्व ऑपरेशन्स रॅपिंग ऑपरेशनमध्ये जबाबदार आहेत.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// युक्लिडियन मोड्युलो लपेटणे.मोजणे `self.rem_euclid(rhs)`.
        /// स्वाक्षरीकृत प्रकारांवर लपेटलेले मोड्युलो गणना ही फक्त नियमित उर्वरित गणना आहे.
        /// रॅपिंग कधीही होऊ शकत नाही.
        /// हे कार्य अस्तित्त्वात आहे, जेणेकरून सर्व ऑपरेशन्स रॅपिंग ऑपरेशनमध्ये जबाबदार आहेत.
        /// कारण, सकारात्मक पूर्णांकांकरिता, भागाच्या सर्व सामान्य व्याख्या समान आहेत, हे अगदी `self.wrapping_rem(rhs)` बरोबर आहे.
        ///
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// लपेटणे (modular) नकार.
        /// प्रकाराच्या सीमेवर गुंडाळत `-self` ची गणना करते.
        ///
        /// स्वाक्षरीकृत प्रकारांमध्ये नकारात्मक समतुल्य नसल्यामुळे या कार्याचे सर्व अनुप्रयोग लपेटतील (`-0` वगळता).
        /// संबंधित साइन इन प्रकाराच्या कमालपेक्षा लहान मूल्यांसाठी परिणाम समान चिन्हे मूल्य निर्णायक सारखाच असतो.
        ///
        /// कोणतीही मोठी मूल्ये `MAX + 1 - (val - MAX - 1)` च्या समतुल्य आहेत जिथे `MAX` संबंधित चिन्हांकित प्रकारची कमाल आहे.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// कृपया लक्षात घ्या की हे उदाहरण पूर्णांक प्रकारांमध्ये सामायिक केलेले आहे.
        /// जे येथे `i8` का वापरले जाते हे स्पष्ट करते.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// झेडपॅनिक ० झेड फ्री बिटवाइज शिफ्ट-डावे;
        /// `self << mask(rhs)` देते, जेथे `mask` `rhs` चे कोणतेही उच्च-ऑर्डर बिट्स काढून टाकते ज्यामुळे शिफ्ट प्रकाराच्या बिटविड्थपेक्षा जास्त असेल.
        ///
        /// लक्षात घ्या की हे *फिरवलेल्या डावीसारखे नाही* आहे;LHS मधून हलविलेले बिट्स दुसर्‍या टोकाला परत आणण्याऐवजी, लपेटण्याच्या शिफ्ट-डाव्या आरएचएस प्रकाराच्या मर्यादेपर्यंत मर्यादित आहेत.
        /// आदिम पूर्णांक सर्व एक [`rotate_left`](Self::rotate_left) फंक्शनची अंमलबजावणी करतात, जे त्याऐवजी आपल्याला हवे असलेले असू शकते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // सुरक्षितता: प्रकारच्या बिटसाइजद्वारे मुखवटा लावल्याने हे सुनिश्चित होते की आपण शिफ्ट होणार नाही
            // मर्यादा बाहेर
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// झेडपॅनिक ० झेड फ्री बिटवाइज शिफ्ट-राइट;
        /// `self >> mask(rhs)` देते, जेथे `mask` `rhs` चे कोणतेही उच्च-ऑर्डर बिट्स काढून टाकते ज्यामुळे शिफ्ट प्रकाराच्या बिटविड्थपेक्षा जास्त असेल.
        ///
        /// लक्षात घ्या की हे * फिरवा-उजवीकडे समान नाही;LHS मधून हलविलेले बिट्स दुसर्‍या टोकाला परत आणण्याऐवजी, लपेटण्याच्या शिफ्ट-राईटच्या आरएचएस प्रकाराच्या मर्यादेपर्यंत मर्यादित आहेत.
        /// आदिम पूर्णांक सर्व एक [`rotate_right`](Self::rotate_right) फंक्शनची अंमलबजावणी करतात, जे त्याऐवजी आपल्याला हवे असलेले असू शकते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // सुरक्षितता: प्रकारच्या बिटसाइजद्वारे मुखवटा लावल्याने हे सुनिश्चित होते की आपण शिफ्ट होणार नाही
            // मर्यादा बाहेर
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// एक्स 100 एक्सचा विस्तार लपेटणे.
        /// प्रकाराच्या सीमेवर गुंडाळत `self.pow(exp)` ची गणना करते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // एक्सपा!=0 पासून, शेवटी समाप्ती 1 असणे आवश्यक आहे.
            // घातांकच्या अंतिम बिटसह स्वतंत्रपणे काम करा, कारण नंतर बेस स्क्वेअर करणे आवश्यक नाही आणि अनावश्यक ओव्हरफ्लो होऊ शकते.
            //
            //
            acc.wrapping_mul(base)
        }

        /// `self` + `rhs` ची गणना करते
        ///
        /// अंकित अंकगणित ओव्हरफ्लो होईल की नाही हे दर्शविणार्‍या बुलियनसह बेरीजची बेरीज मिळवते.
        /// जर ओव्हरफ्लो झाला असेल तर गुंडाळलेले मूल्य परत केले जाईल.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self`, `rhs` ची गणना करते
        ///
        /// अंकित अंकगणित ओव्हरफ्लो होईल की नाही हे दर्शविणार्‍या बुलियनसह वजाबाकीचे एक गुंतागुंत मिळवते.
        /// जर ओव्हरफ्लो झाला असेल तर गुंडाळलेले मूल्य परत केले जाईल.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` आणि `rhs` च्या गुणाची गणना करते.
        ///
        /// अंकातील अंकगणित ओव्हरफ्लो होईल की नाही हे दर्शविणार्‍या बुलियनसह गुणाकाराचा एक भाग मिळवते.
        /// जर ओव्हरफ्लो झाला असेल तर गुंडाळलेले मूल्य परत केले जाईल.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// कृपया लक्षात घ्या की हे उदाहरण पूर्णांक प्रकारांमध्ये सामायिक केलेले आहे.
        /// जे येथे `u32` का वापरले जाते हे स्पष्ट करते.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` `rhs` ने विभाजित केल्यावर विभाजकांची गणना करते.
        ///
        /// अंकगणित ओव्हरफ्लो होईल की नाही हे दर्शविणार्‍या बुलियनसह भागाचे टुप्ल मिळवते.
        /// लक्षात ठेवा की स्वाक्षरी केलेल्या पूर्णांकरिता ओव्हरफ्लो कधीच होत नाही, म्हणून दुसरे मूल्य नेहमीच `false` असते.
        ///
        /// # Panics
        ///
        /// `rhs` 0 असल्यास हे कार्य panic करेल.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// युक्लिडियन विभाग `self.div_euclid(rhs)` च्या भागांची गणना करते.
        ///
        /// अंकगणित ओव्हरफ्लो होईल की नाही हे दर्शविणार्‍या बुलियनसह भागाचे टुप्ल मिळवते.
        /// लक्षात ठेवा की स्वाक्षरी केलेल्या पूर्णांकरिता ओव्हरफ्लो कधीच होत नाही, म्हणून दुसरे मूल्य नेहमीच `false` असते.
        /// कारण, सकारात्मक पूर्णांकांकरिता, भागाच्या सर्व सामान्य व्याख्या समान आहेत, हे अगदी `self.overflowing_div(rhs)` बरोबर आहे.
        ///
        ///
        /// # Panics
        ///
        /// `rhs` 0 असल्यास हे कार्य panic करेल.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// `self` `rhs` ने विभाजित केल्यावर उर्वरितची गणना करते.
        ///
        /// अंकित अंकगणित ओव्हरफ्लो होईल की नाही हे दर्शविणार्‍या बुलियनसह भागाकार केल्यानंतर उर्वरित भागांची परत मिळवते.
        /// लक्षात ठेवा की स्वाक्षरी केलेल्या पूर्णांकरिता ओव्हरफ्लो कधीच होत नाही, म्हणून दुसरे मूल्य नेहमीच `false` असते.
        ///
        /// # Panics
        ///
        /// `rhs` 0 असल्यास हे कार्य panic करेल.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// युक्लिडियन विभागानुसार उर्वरित `self.rem_euclid(rhs)` ची गणना करते.
        ///
        /// अंकगणित ओव्हरफ्लो होईल की नाही हे दर्शविणार्‍या बुलियनसह भागाकार केल्यानंतर मोड्यूलोचा एक टपल मिळवते.
        /// लक्षात ठेवा की स्वाक्षरी केलेल्या पूर्णांकरिता ओव्हरफ्लो कधीच होत नाही, म्हणून दुसरे मूल्य नेहमीच `false` असते.
        /// कारण, सकारात्मक पूर्णांकांकरिता, भागाच्या सर्व सामान्य व्याख्या समान आहेत, हे ऑपरेशन अगदी `self.overflowing_rem(rhs)` च्या समान आहे.
        ///
        ///
        /// # Panics
        ///
        /// `rhs` 0 असल्यास हे कार्य panic करेल.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// ओसंडून वाहणा self्या फॅशनमध्ये स्वत: चे नकारात्मक
        ///
        /// या स्वाक्षरी केलेल्या मूल्याचे नकार दर्शविणारे मूल्य परत करण्यासाठी रॅपिंग ऑपरेशन्सचा वापर करून एक्स 100 एक्स परत करते.
        /// लक्षात ठेवा सकारात्मक अस्वाक्षरी मूल्यांसाठी ओव्हरफ्लो नेहमीच होतो परंतु 0 चे नकार देणे ओव्हरफ्लो होत नाही.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// `rhs` बिट्सद्वारे स्वत: डावीकडे शिफ्ट करा.
        ///
        /// शिफ्टचे मूल्य बिट्सच्या संख्येपेक्षा मोठे किंवा समान होते की नाही हे दर्शविणार्‍या बुलियनसह स्वतःच्या रूपांतरित आवृत्तीचे एक टिपल मिळवते.
        /// जर शिफ्ट मूल्य खूप मोठे असेल तर मूल्य बिछान्यांची संख्या आहे तिथे (N-1) चे मुखवटा घातलेले असेल आणि नंतर हे मूल्य शिफ्ट करण्यासाठी वापरले जाईल.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// एक्स00 एक्स बिट्सद्वारे स्वत: ची उजवीकडे शिफ्ट करा.
        ///
        /// शिफ्टचे मूल्य बिट्सच्या संख्येपेक्षा मोठे किंवा समान होते की नाही हे दर्शविणार्‍या बुलियनसह स्वतःच्या रूपांतरित आवृत्तीचे एक टिपल मिळवते.
        /// जर शिफ्ट मूल्य खूप मोठे असेल तर मूल्य बिछान्यांची संख्या आहे तिथे (N-1) चे मुखवटा घातलेले असेल आणि नंतर हे मूल्य शिफ्ट करण्यासाठी वापरले जाईल.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// स्क्वेअरिंगद्वारे एक्सपेंशनेशन वापरुन एक्स00 एक्सच्या सामर्थ्यावर स्वत: ला वाढवते.
        ///
        /// ओव्हरफ्लो झाली की नाही हे दर्शविणार्‍या झेडबूल0 झेडसह घरोघरी एक टप्पल मिळवते.
        ///
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, खरे));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // ओव्हरफ्लोिंग_मूलच्या परिणाम संग्रहित करण्यासाठी स्क्रॅच स्पेस.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // एक्सपा!=0 पासून, शेवटी समाप्ती 1 असणे आवश्यक आहे.
            // घातांकच्या अंतिम बिटसह स्वतंत्रपणे काम करा, कारण नंतर बेस स्क्वेअर करणे आवश्यक नाही आणि अनावश्यक ओव्हरफ्लो होऊ शकते.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// स्क्वेअरिंगद्वारे एक्सपेंशनेशन वापरुन एक्स00 एक्सच्या सामर्थ्यावर स्वत: ला वाढवते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // एक्सपा!=0 पासून, शेवटी समाप्ती 1 असणे आवश्यक आहे.
            // घातांकच्या अंतिम बिटसह स्वतंत्रपणे काम करा, कारण नंतर बेस स्क्वेअर करणे आवश्यक नाही आणि अनावश्यक ओव्हरफ्लो होऊ शकते.
            //
            //
            acc * base
        }

        /// युक्लिडियन विभाग करते.
        ///
        /// कारण, सकारात्मक पूर्णांकांकरिता, भागाच्या सर्व सामान्य व्याख्या समान आहेत, हे अगदी `self / rhs` बरोबर आहे.
        ///
        ///
        /// # Panics
        ///
        /// `rhs` 0 असल्यास हे कार्य panic करेल.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// `self (mod rhs)` च्या किमान उर्वरितची गणना करते.
        ///
        /// कारण, सकारात्मक पूर्णांकांकरिता, भागाच्या सर्व सामान्य व्याख्या समान आहेत, हे अगदी `self % rhs` बरोबर आहे.
        ///
        ///
        /// # Panics
        ///
        /// `rhs` 0 असल्यास हे कार्य panic करेल.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// काही `k` साठी `self == 2^k` असल्यास आणि `true` मिळवते.
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // पुढील दोन पैकी एकापेक्षा कमी मिळवते.
        // (8u8 साठी पुढील दोनची शक्ती 8u8 आहे आणि 6u8 साठी ती 8u8 आहे)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // ही पद्धत ओव्हरफ्लो करू शकत नाही, कारण `next_power_of_two` ओव्हरफ्लो प्रकरणांमध्ये त्याऐवजी प्रकाराचे जास्तीत जास्त मूल्य परत येते आणि 0 साठी 0 परत येऊ शकते.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // सुरक्षाः कारण `p > 0`, यात संपूर्णपणे अग्रगण्य शून्य असू शकत नाहीत.
            // याचा अर्थ शिफ्ट नेहमीच मर्यादीत असते आणि जेव्हा वितर्क शून्य नसते तेव्हा काही प्रोसेसरमध्ये (जसे की इंटेल प्री-हॅसवेल) अधिक कार्यक्षम सीटीएलझ इंटर्निक्स असतात.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// `self` पेक्षा मोठे किंवा समान दोनची सर्वात लहान शक्ती मिळवते.
        ///
        /// जेव्हा रिटर्न व्हॅल्यू ओव्हरफ्लो होते (म्हणजे एक्स टाइप 1 एक्स प्रकारासाठी एक्स 100 एक्स), ते डीबग मोडमध्ये झेडस्पॅनिक्स 0 झेड आणि रिटर्न व्हॅल्यू रिलीझ मोडमध्ये 0 पर्यंत गुंडाळले जाते (ही परिस्थिती ज्यामध्ये 0 परत येऊ शकते).
        ///
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// `n` पेक्षा मोठे किंवा समान दोनची सर्वात लहान शक्ती मिळवते.
        /// दोनची पुढील शक्ती प्रकाराच्या कमाल मूल्यापेक्षा अधिक असल्यास, एक्स 0 एक्स एक्स परत येईल, अन्यथा दोनची शक्ती `Some` मध्ये लपेटली जाते.
        ///
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// `n` पेक्षा मोठे किंवा समान दोनची सर्वात लहान शक्ती मिळवते.
        /// दोनची पुढील शक्ती प्रकाराच्या कमाल मूल्यापेक्षा अधिक असल्यास, परतावा मूल्य `0` वर गुंडाळले जाईल.
        ///
        ///
        /// # Examples
        ///
        /// मूलभूत वापर:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// बिग-एंडियन (network) बाइट ऑर्डरमध्ये या पूर्णांकाचे मेमरी प्रतिनिधित्व बाइट अ‍ॅरे म्हणून परत करा.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// या पूर्णांकाचे स्मरणशक्ती लघु-अंतिय बाइट क्रमाने बाइट अ‍ॅरे म्हणून परत करा.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// या पूर्णांकाचे मेमरी प्रतिनिधित्व मूळ बाइट ऑर्डरमध्ये बाइट अ‍ॅरे म्हणून द्या.
        ///
        /// टार्गेट प्लॅटफॉर्मचा मूळ अंतःकरण वापरला जात आहे म्हणून पोर्टेबल कोडने त्याऐवजी [`to_be_bytes`] किंवा [`to_le_bytes`] वापरावे.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     बाइट्स, जर सीएफजी! (लक्ष्य_सेडियन=एक्स 100 एक्स){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } अन्य {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // सुरक्षितता: तटबंदीचा आवाज कारण पूर्णांक जुना डेटाटाइप असतो म्हणून आम्ही नेहमीच असतो
        // त्यांना बाइटच्या अ‍ॅरेमध्ये संक्रमित करा
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // सुरक्षितता: पूर्णांक जुने डेटाटेटाइप असतात जेणेकरून आम्ही त्यांना नेहमी संक्रमित करू शकतो
            // बाइटचे अ‍ॅरे
            unsafe { mem::transmute(self) }
        }

        /// या पूर्णांकाचे मेमरी प्रतिनिधित्व मूळ बाइट ऑर्डरमध्ये बाइट अ‍ॅरे म्हणून द्या.
        ///
        ///
        /// [`to_ne_bytes`] जेव्हा शक्य असेल तेव्हा यापेक्षा त्यास प्राधान्य दिले पाहिजे.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// ले बाइट्स=एक्स00 एक्स;
        /// assert_eq!(
        ///     बाइट्स, जर सीएफजी! (लक्ष्य_सेडियन=एक्स 100 एक्स){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } अन्य {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // सुरक्षितता: पूर्णांक जुने डेटाटेटाइप असतात जेणेकरून आम्ही त्यांना नेहमी संक्रमित करू शकतो
            // बाइटचे अ‍ॅरे
            unsafe { &*(self as *const Self as *const _) }
        }

        /// बिग एंडियानमध्ये बाइट अ‍ॅरे म्हणून त्याच्या प्रतिनिधीत्वातून नेटिव्ह एन्डियन पूर्णांक मूल्य तयार करा.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto वापरा;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * इनपुट=विश्रांती;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// थोड्या अंत्य अंतरामध्ये बाइट अ‍ॅरे म्हणून त्याच्या प्रतिनिधीत्वातून नेटिव्ह एन्डियन पूर्णांक मूल्य तयार करा.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto वापरा;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * इनपुट=विश्रांती;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// नेटिव्ह एंडियानॅनेसमध्ये बाइट अ‍ॅरे म्हणून त्याच्या मेमरी प्रतिनिधित्वामधून नेटिव्ह एंडियन इंटिजर व्हॅल्यू तयार करा.
        ///
        /// टार्गेट प्लॅटफॉर्मचा मूळ अंतःकरण वापरला जात आहे म्हणून पोर्टेबल कोड त्याऐवजी [`from_be_bytes`] किंवा [`from_le_bytes`] वापरू इच्छित आहे.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } अन्य {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto वापरा;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * इनपुट=विश्रांती;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // सुरक्षितता: तटबंदीचा आवाज कारण पूर्णांक जुना डेटाटाइप असतो म्हणून आम्ही नेहमीच असतो
        // त्यांना हस्तांतरित
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // सुरक्षितता: पूर्णांक जुने डेटाटाइप असतात जेणेकरुन आम्ही त्यांच्याकडे नेहमी संक्रमण करू शकू
            unsafe { mem::transmute(bytes) }
        }

        /// नवीन कोड वापरण्यास प्राधान्य दिले पाहिजे
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// या पूर्णांक प्रकाराद्वारे प्रतिनिधित्व केले जाऊ शकते सर्वात लहान मूल्य मिळवते.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// नवीन कोड वापरण्यास प्राधान्य दिले पाहिजे
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// या पूर्णांक प्रकाराद्वारे प्रतिनिधित्व केले जाऊ शकते असे सर्वात मोठे मूल्य मिळवते.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}