//! वैयक्तिक भाग आणि त्रुटी श्रेणींमध्ये फ्लोटिंग-पॉइंट मूल्य डीकोड करते.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// डिकोड न केलेले स्वाक्षरीकृत मर्यादा मूल्य, जसे की:
///
/// - मूळ मूल्य `mant * 2^exp` च्या बरोबरीचे आहे.
///
/// - `(mant - minus)*2^exp` ते `(mant + plus)* 2^exp` पर्यंत कोणतीही संख्या मूळ मूल्यापर्यंत जाईल.
/// `inclusive` `true` आहे तेव्हाच श्रेणी समाविष्ट आहे.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// स्केल केलेले मॅन्टिसा.
    pub mant: u64,
    /// कमी त्रुटी श्रेणी.
    pub minus: u64,
    /// वरील त्रुटी श्रेणी.
    pub plus: u64,
    /// बेस 2 मधील सामायिक घातांक.
    pub exp: i16,
    /// त्रुटी श्रेणी समाविष्‍ट असते तेव्हा सत्य.
    ///
    /// आयईईई 754 मध्ये, मूळ मॅन्टीसा समात असताना हे सत्य आहे.
    pub inclusive: bool,
}

/// डिकोड केलेली अस्वाक्षरी मूल्य.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// एकतर सकारात्मक किंवा नकारात्मक असीमते.
    Infinite,
    /// शून्य, एकतर सकारात्मक किंवा नकारात्मक.
    Zero,
    /// पुढील डिकोड केलेल्या फील्डसह परिपूर्ण संख्या.
    Finite(Decoded),
}

/// फ्लोटिंग पॉईंट प्रकार जो `डीकोड करणे शक्य आहे.
pub trait DecodableFloat: RawFloat + Copy {
    /// किमान सकारात्मक सामान्यीकृत मूल्य.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// दिलेल्या फ्लोटिंग पॉईंट क्रमांकाचे चिन्ह (नकारात्मक असल्यास खरे) आणि `FullDecoded` मूल्य मिळवते.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // शेजारी: (मांट, २, कालबाह्य)-(मांट, एक्स्प्रेस)-(मांट + २, कालबाह्य)
            // Float::integer_decode घातांक नेहमी जपतो, म्हणूनच मॅन्टीसा subnormals साठी स्केल केले जाते.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // शेजारीः (मॅक्समॅन्ट, एक्स्प्रेस, १)-(मिनिमॉर्मंट, एक्स्प्रेस)-(मिन्नोर्मॅन्ट + १, एक्सप
                // जिथे मॅक्समॅन्ट=मिनिनरमंट * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // शेजारी: (मांट, १, समाप्ती)-(मांट, एक्स्प्रेस)-(मांट + १, समाप्ती)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}