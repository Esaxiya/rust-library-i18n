//! घातांक अनुमानक.

/// असे `10^(k_0-1) < mant * 2^exp <= 10^(k_0+1)` शोधते.
///
/// हे अंदाजे `k = ceil(log_10 (mant * 2^exp))` करण्यासाठी वापरले जाते;
/// खरे `k` एकतर `k_0` किंवा `k_0+1` आहे.
#[doc(hidden)]
pub fn estimate_scaling_factor(mant: u64, exp: i16) -> i16 {
    // 2 ^ (nbit-1) <मां <<2 2 bits nbit ifant> 0
    let nbits = 64 - (mant - 1).leading_zeros() as i64;
    // 1292913986= floor(2^32 * log_10 2) म्हणून हे नेहमीच कमी लेखते (किंवा अचूक आहे), परंतु जास्त नाही.
    //
    (((nbits + exp as i64) * 1292913986) >> 32) as i16
}