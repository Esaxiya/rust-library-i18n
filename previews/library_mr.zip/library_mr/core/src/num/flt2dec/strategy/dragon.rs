//! "प्रिंटिंग फ्लोटिंग-पॉइंट क्रमांक जलद आणि अचूकपणे" [^ 1] च्या आकृती 3 चे जवळजवळ थेट (परंतु थोडेसे ऑप्टिमाइझ केलेले) झेडस्ट्रास्ट 0 झेड अनुवाद.
//!
//!
//! [^1]: Burger, आरजी आणि डायबविग, आरके 1996. फ्लोटिंग-पॉइंट क्रमांक मुद्रित करणे
//!   द्रुत आणि अचूक.सिग्नल नाही.31, 5 (मे. 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// 10 ^ (2 ^ n) साठी `अंक`चे पूर्णाकलित अ‍ॅरे
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// `x < 16 * scale` तेव्हाच वापरण्यायोग्य;`scaleN` हे `scale.mul_small(N)` असावे
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// ड्रॅगनसाठी सर्वात लहान मोडची अंमलबजावणी.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // स्वरूपनासाठी `v` क्रमांक असल्याचे ज्ञात आहे:
    // - `mant * 2^exp` च्या समान;
    // - मूळ प्रकारात `(mant - 2 *minus)* 2^exp` च्या आधी;आणि
    // - त्यानंतर मूळ प्रकारात एक्स 100 एक्स
    //
    // अर्थात, `minus` आणि `plus` शून्य असू शकत नाही.(विकृतींसाठी, आम्ही श्रेणीबाह्य मूल्ये वापरतो.) तसेच आम्ही असेही गृहित धरू की कमीतकमी एक अंक व्युत्पन्न झाला आहे, म्हणजेच X01 देखील शून्य असू शकत नाही.
    //
    // याचा अर्थ असा की `low = (mant - minus)*2^exp` आणि `high = (mant + plus)* 2^exp` मधील कोणतीही संख्या या अचूक फ्लोटिंग पॉईंट क्रमांकावर नकाशा करेल, मूळ मँन्टीसा सम (म्हणजेच एक्स ० 2 एक्स) असताना देखील समाविष्ट असलेल्या सीमांसह.
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` `if d.inclusive {a <= b} else {a < b}` आहे
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // `10^(k_0-1) < high <= 10^(k_0+1)` समाधानकारक मूळ इनपुटवरून `k_0` चा अंदाज लावा.
    // घट्ट बांधलेली `k` समाधानकारक `10^(k-1) < high <= 10^k` नंतर गणना केली जाते.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // `{mant, plus, minus} * 2^exp` चे आंशिक स्वरूपात रूपांतर करा जेणेकरूनः
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // `mant` `10^k` ने विभाजित करा.आता `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // `mant + plus > scale` (किंवा `>=`) तेव्हा निश्चित करा.
    // आम्ही त्याऐवजी प्रारंभिक गुणाकार वगळू शकतो म्हणून आम्ही प्रत्यक्षात `scale` सुधारित करत नाही.
    // आता `scale < mant + plus <= scale * 10` आणि आम्ही अंक व्युत्पन्न करण्यास तयार आहोत.
    //
    // लक्षात घ्या की `d[0]` * शून्य असू शकतो, जेव्हा `scale - plus < mant < scale`.
    // या प्रकरणात राउंडिंग-अप स्थिती (खाली `up`) त्वरित ट्रिगर होईल.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // 10 ने `scale` स्केल करण्यासाठी समतुल्य
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // अंक निर्मितीसाठी कॅशे `(2, 4, 8) * scale`.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // आक्रमणकर्ते, जिथे आतापर्यंत `d[0..n-1]` अंक व्युत्पन्न केले आहेत:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (अशा प्रकारे X01 एक्स) जिथे `d[i..j]` `d [i] * 10 ^ (जी) + साठी शॉर्टहँड आहे
        // + डी [j-1] * 10 + d[j]`.

        // एक अंक व्युत्पन्न करा: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // हे सुधारित ड्रॅगन अल्गोरिदमचे एक सरलीकृत वर्णन आहे.
        // सोयीसाठी बर्‍याच दरम्यानचे व्युत्पन्न आणि परिपूर्णतेचे युक्तिवाद वगळले आहेत.
        //
        // आम्ही `n` अद्यतनित केल्यानुसार सुधारित हल्लेखोरांसह प्रारंभ करा:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // `d[0..n-1]` हे `low` आणि `high` मधील सर्वात कमी प्रतिनिधित्त्व आहे असे समजा, म्हणजे, `d[0..n-1]` खालीलपैकी दोघांचे समाधान करते परंतु `d[0..n-2]` तसे करत नाही:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (द्विपक्षीयता: `v` पर्यंतचे अंक);आणि
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (शेवटचा अंक बरोबर आहे)
        //
        // दुसरी अट `2 * mant <= scale` वर सुलभ करते.
        // `mant`, `low` आणि `high` च्या संदर्भात आक्रमणकर्ते सोडविण्यामुळे पहिल्या अटची एक सोपी आवृत्ती मिळते: `-plus < mant < minus`.
        // `-plus < 0 <= mant` पासून, जेव्हा `mant < minus` आणि `2 * mant <= scale` असेल तेव्हा आमच्याकडे सर्वात लहान प्रतिनिधित्व आहे.
        // (मूळ मॅन्टिसा समात असताना पूर्वी `mant <= minus` होते.)
        //
        // जेव्हा सेकंदात (`2 * मांट> स्केल) नसते तेव्हा आम्हाला शेवटचा अंक वाढविणे आवश्यक असते.
        // ही अट पुनर्संचयित करण्यासाठी हे पुरेसे आहे: आम्हाला आधीपासूनच माहित आहे की अंक निर्मिती ही `0 <= v / 10^(k-n) - d[0..n-1] < 1` ची हमी देते.
        // या प्रकरणात, पहिली अट `-plus < mant - scale < minus` बनते.
        // पिढीनंतर `mant < scale` पासून, आमच्याकडे `scale < mant + plus` आहे.
        // (पुन्हा, जेव्हा मूळ मॅन्टीसा सम असेल तेव्हा हे `scale <= mant + plus` होते.)
        //
        // थोडक्यात:
        // - `mant < minus` (किंवा `<=`) असताना `down` थांबा आणि गोलाकार करा.
        // - `scale < mant + plus` (किंवा `<=`) तेव्हा थांबा आणि गोल `up` (शेवटचा अंक वाढवा)
        // - अन्यथा निर्मिती सुरू ठेवा.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // आमच्याकडे सर्वात कमी प्रतिनिधित्व आहे, फेरीसाठी पुढे जा

        // हल्लेखोर पुनर्संचयित करा.
        // हे अल्गोरिदम नेहमीच संपुष्टात आणते: `minus` आणि `plus` नेहमीच वाढते, परंतु `mant` मोड्युलो एक्स03 एक्स क्लिप केलेला आहे आणि एक्स 0 4 एक्स निश्चित केले आहे.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // राउंडिंग अप होते जेव्हा i) केवळ राउंडिंग-अप अट ट्रिगर होते किंवा ii) दोन्ही अटी ट्रिगर केल्या गेल्या आणि ब्रेकिंग ब्रेकिंग प्राधान्य दिले.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // जर गोल करणे लांबी बदलते तर घातांक देखील बदलला पाहिजे.
        // असे वाटते की ही परिस्थिती पूर्ण करणे कठीण आहे (शक्यतो अशक्य आहे) परंतु आम्ही येथे केवळ सुरक्षित आणि सातत्य ठेवत आहोत.
        //
        // सुरक्षा: आम्ही वरील स्मृती आरंभ केल्या.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // सुरक्षा: आम्ही वरील स्मृती आरंभ केल्या.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// ड्रॅगनसाठी अचूक आणि निश्चित मोड अंमलबजावणी.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // `10^(k_0-1) < v <= 10^(k_0+1)` समाधानकारक मूळ निविष्ठांकडून `k_0` चा अंदाज लावा.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // `mant` `10^k` ने विभाजित करा.आता `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // `mant + plus >= scale`, जेथे `plus / scale = 10^-buf.len() / 2`.
    // निश्चित-आकार बिग्नाम ठेवण्यासाठी, आम्ही प्रत्यक्षात `mant + floor(plus) >= scale` वापरतो.
    // आम्ही त्याऐवजी प्रारंभिक गुणाकार वगळू शकतो म्हणून आम्ही प्रत्यक्षात `scale` सुधारित करत नाही.
    // पुन्हा सर्वात छोट्या अल्गोरिदमसह, एक्स 100 एक्स शून्य असू शकेल परंतु अखेरीस गोल केले जाईल.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // 10 ने `scale` स्केल करण्यासाठी समतुल्य
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // आम्ही शेवटच्या-अंकी मर्यादेसह कार्य करीत असल्यास, दुहेरी फेरी टाळण्यासाठी आम्हाला वास्तविक प्रस्तुत करण्यापूर्वी बफर लहान करणे आवश्यक आहे.
    //
    // लक्षात घ्या की फेरी मारल्यावर पुन्हा बफर वाढवावा लागेल!
    let mut len = if k < limit {
        // अरेरे, आम्ही *एक* अंक देखील काढू शकत नाही.
        // जेव्हा हे सांगावे की आपल्याकडे एक्स 100 एक्ससारखे काहीतरी मिळाले आहे आणि ते 10 पर्यंत पूर्ण केले जाईल तेव्हा हे शक्य आहे.
        // आम्ही एक्स रिक्त बफर परत मिळवितो, नंतरच्या राउंडिंग-अप प्रकरणात अपवाद वगळता जेव्हा `k == limit` होतो आणि अगदी एक अंक तयार करावा लागतो.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // अंक निर्मितीसाठी कॅशे `(2, 4, 8) * scale`.
        // (हे महाग असू शकते, म्हणून जेव्हा बफर रिक्त असेल तेव्हा त्यांची गणना करू नका.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // खालील अंक सर्व शून्य आहेत, आम्ही येथे थांबलो *गोल* करण्याचा प्रयत्न करू नका!त्याऐवजी उर्वरित अंक भरा.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // सुरक्षा: आम्ही वरील स्मृती आरंभ केल्या.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // पुढील अंक अगदी s००० असल्यास आम्ही अंकांच्या मध्यभागी थांबलो तर आधीचे अंक तपासा आणि सम (म्हणजे, आधीचा अंक समात असताना गोल करणे टाळणे) पहा.
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // सुरक्षा: `buf[len-1]` प्रारंभ झाले आहे.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // जर गोल करणे लांबी बदलते तर घातांक देखील बदलला पाहिजे.
        // परंतु आमच्याकडे एका निश्चित संख्येची विनंती केली गेली आहे, म्हणून बफरमध्ये बदल करु नका ...
        // सुरक्षा: आम्ही वरील स्मृती आरंभ केल्या.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... जोपर्यंत आम्हाला त्याऐवजी निश्चित सुस्पष्टतेची विनंती केली जात नाही.
            // आम्हाला हे देखील तपासण्याची आवश्यकता आहे, मूळ बफर रिक्त असल्यास, अतिरिक्त अंक केवळ `k == limit` (edge प्रकरण) मध्ये जोडला जाऊ शकतो.
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // सुरक्षा: आम्ही वरील स्मृती आरंभ केल्या.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}