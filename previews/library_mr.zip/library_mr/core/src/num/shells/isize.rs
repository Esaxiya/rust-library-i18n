//! पॉईंटर-आकाराच्या स्वाक्षरी केलेल्या पूर्णांक प्रकारासाठी स्थिर.
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! नवीन कोडने संबंधित प्रकारांचा थेट आदिम प्रकारावर वापर करावा.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }