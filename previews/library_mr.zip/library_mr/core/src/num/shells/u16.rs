//! 16-बिट स्वाक्षरीकृत पूर्णांक प्रकारांसाठी स्थिर.
//!
//! *[See also the `u16` primitive type][u16].*
//!
//! नवीन कोडने संबंधित प्रकारांचा थेट आदिम प्रकारावर वापर करावा.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u16`"
)]

int_module! { u16 }