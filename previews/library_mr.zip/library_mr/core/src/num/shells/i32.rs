//! 32-बीट साइन इन केलेले पूर्णांक प्रकार करीता स्थिर.
//!
//! *[See also the `i32` primitive type][i32].*
//!
//! नवीन कोडने संबंधित प्रकारांचा थेट आदिम प्रकारावर वापर करावा.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i32`"
)]

int_module! { i32 }