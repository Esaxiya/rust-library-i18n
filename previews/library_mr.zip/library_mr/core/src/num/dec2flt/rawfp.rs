//! सकारात्मक आयईईई 754 फ्लोट्सवर बिट फिडलिंग.नकारात्मक संख्या नाहीत आणि हाताळण्याची आवश्यकता नाही.
//! सामान्य फ्लोटिंग पॉईंट संख्येचे (फ्रॅक, एक्सप) असे प्रमाणिक प्रतिनिधित्व असते जसे की मूल्य 2 <sup>एक्सप</sup> * (1 + एक्स00 एक्स) असते जेथे एन बिट्सची संख्या असते.
//!
//! अलौकिक पदार्थ किंचित भिन्न आणि विचित्र आहेत, परंतु समान तत्व लागू होते.
//!
//! येथे मात्र आम्ही f (पॉवर पॉझिटिव्ह) चे (सिग, के) असे प्रतिनिधित्व करतो, जसे की मूल्य f *
//! 2 <sup>ई</sup> .एक्स 100 एक्स स्पष्ट करण्याव्यतिरिक्त, हे तथाकथित मॅन्टिसा शिफ्टद्वारे घातांक बदलते.
//!
//! आणखी एक मार्ग सांगा, साधारणपणे फ्लोट्स (1) म्हणून लिहिलेले असतात परंतु येथे ते (2) असे लिहिले जातात:
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! आम्ही (1) ला **अपूर्णांकिक प्रतिनिधित्व** आणि (2)**अविभाज्य प्रतिनिधित्व** म्हणतो.
//!
//! या विभागातील अनेक कार्ये केवळ सामान्य संख्या हाताळतात.डेक्लफ्ल्ट दिनचर्या अत्यंत लहान आणि खूप मोठ्या संख्येसाठी परंपरागतपणे सार्वभौम-योग्य स्लो पथ (अल्गोरिदम एम) घेतात.
//! त्या अल्गोरिदमला फक्त एक्स00 एक्स आवश्यक आहे जे उपनियम आणि शून्य हाताळेल.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// `f32` आणि `f64` साठी मुळात सर्व रूपांतर कोडची नक्कल टाळण्यासाठी एक सहाय्यक झेडट्रायट 0 झेड.
///
/// हे आवश्यक का आहे यासाठी पॅरेंट मॉड्यूलची डॉक टिप्पणी पहा.
///
/// **कधीही कधीही** अन्य प्रकारांसाठी लागू केला जाऊ नये किंवा डिक्फ्ल्ट मॉड्यूलच्या बाहेर वापरला जाऊ नये.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// `to_bits` आणि `from_bits` द्वारे वापरलेला प्रकार.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// पूर्णांकाचे कच्चे रूपांतर करते.
    fn to_bits(self) -> Self::Bits;

    /// पूर्णांक पासून एक कच्चे रूपांतरण करते.
    fn from_bits(v: Self::Bits) -> Self;

    /// ही संख्या ज्या श्रेणीमध्ये येते त्या श्रेणीस मिळवते.
    fn classify(self) -> FpCategory;

    /// मँटिसा, घातांक आणि पूर्णाकार म्हणून साइन मिळवते.
    fn integer_decode(self) -> (u64, i16, i8);

    /// फ्लोट डीकोड करा.
    fn unpack(self) -> Unpacked;

    /// एका छोट्या पूर्णांकावरील जाती ज्या अचूकपणे दर्शविल्या जाऊ शकतात.
    /// Panic पूर्णांक दर्शविला जाऊ शकत नसल्यास, या मॉड्यूलमधील इतर कोड कधीही होऊ नये याची खात्री करतो.
    fn from_int(x: u64) -> Self;

    /// प्री-कंप्यूट केलेले टेबलमधून 10 <sup>ई</sup> मूल्य मिळवते.
    /// `e >= CEIL_LOG5_OF_MAX_SIG` साठी Panics.
    fn short_fast_pow10(e: usize) -> Self;

    /// नाव काय म्हणतो.
    /// आंतरजातीय वस्तू मिळवून देणे आणि एलएलव्हीएम सतत दुमडणे यापेक्षा हार्ड कोड करणे सोपे आहे.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // ओव्हरफ्लो किंवा शून्य किंवा उत्पन्न करू शकत नाही अशा इनपुटच्या दशांश अंकांवर बांधलेले एक पुराणमतवादी बंध
    /// subnormals.बहुधा जास्तीत जास्त सामान्य मूल्याचा दशांश घातांक, म्हणूनच नाव.
    const MAX_NORMAL_DIGITS: usize;

    /// जेव्हा सर्वात महत्त्वपूर्ण दशांश अंकाचे स्थान मूल्य यापेक्षा मोठे असते तेव्हा ही संख्या निश्चितच अनंततेसाठी पूर्णांक असते.
    ///
    const INF_CUTOFF: i64;

    /// जेव्हा सर्वात महत्त्वाच्या दशांश अंकाचे स्थान मूल्य यापेक्षा कमी असते, तेव्हा संख्या निश्चितच शून्यावर येते.
    ///
    const ZERO_CUTOFF: i64;

    /// घातांकातील बिट्सची संख्या.
    const EXP_BITS: u8;

    /// लपविलेल्या बिटसह * महत्त्वाच्या असलेल्या बिट्सची संख्या.
    const SIG_BITS: u8;

    /// लपविलेल्या बीटला वगळता अर्थात असलेल्या बिटची संख्या.
    const EXPLICIT_SIG_BITS: u8;

    /// अपूर्णांक प्रतिनिधित्वात जास्तीत जास्त कायदेशीर घातांक.
    const MAX_EXP: i16;

    /// उपसंचय वगळता अपूर्णांक प्रतिनिधित्त्वात किमान कायदेशीर घातांक.
    const MIN_EXP: i16;

    /// `MAX_EXP` अविभाज्य प्रतिनिधित्वासाठी, म्हणजेच शिफ्ट लागू केली जाईल.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` एन्कोड केलेले (म्हणजे ऑफसेट बायससह)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` अविभाज्य प्रतिनिधित्वासाठी, म्हणजेच शिफ्ट लागू केली जाईल.
    const MIN_EXP_INT: i16;

    /// अभिन्न प्रतिनिधित्वात अधिकतम सामान्यीकृत महत्त्व.
    const MAX_SIG: u64;

    /// अभिन्न प्रतिनिधित्वात किमान सामान्यीकृत महत्त्व.
    const MIN_SIG: u64;
}

// बहुतेक #34344 साठी एक व्यायाम.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// मँटिसा, घातांक आणि पूर्णाकार म्हणून साइन मिळवते.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // घातांक पूर्वाग्रह + मॅन्टीसा शिफ्ट
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe सर्व प्लॅटफॉर्मवर `as` योग्यरित्या फेरीत आहे की नाही याबद्दल अनिश्चित आहे.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// मँटिसा, घातांक आणि पूर्णाकार म्हणून साइन मिळवते.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // घातांक पूर्वाग्रह + मॅन्टीसा शिफ्ट
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe सर्व प्लॅटफॉर्मवर `as` योग्यरित्या फेरीत आहे की नाही याबद्दल अनिश्चित आहे.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// `Fp` ला सर्वात जवळच्या मशीन फ्लोट प्रकारात रूपांतरित करते.
/// अलौकिक परिणाम हाताळत नाहीत.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f 64 बिट आहे, म्हणून एक्स मध्ये 63 चे मॅन्टिसा शिफ्ट आहे
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// अर्ध्या-ते-सह सह 00 64-बिट महत्तवाची T::SIG_BITS बिटपर्यंत फेरी.
/// घातांक ओव्हरफ्लो हाताळत नाही.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // मॅन्टिसा शिफ्ट समायोजित करा
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// सामान्यीकृत संख्येसाठी `RawFloat::unpack()` चे व्यस्त.
/// जर महत्त्व किंवा घातांक सामान्यीकृत संख्येसाठी वैध नसतील तर Panics.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // लपविलेले बिट काढा
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // घातांक बायस आणि मॅन्टीसा शिफ्टसाठी घातांक समायोजित करा
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // 0 ("+") वर चिन्ह बीट सोडा, आमची संख्या सर्व सकारात्मक आहेत
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// एक सबनेर्मल तयार करा.0 चे मॅन्टिसा अनुमत आहे आणि शून्य बनवते.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // एन्कोडेड घातांक 0 आहे, साइन बीट 0 आहे, म्हणून आपल्याला फक्त बिट्सचा अर्थ काढणे आवश्यक आहे.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// एक एफपी सह अंदाजे एक bignum.अर्ध्या-ते-सह सह 0.5 ULP मध्ये गोल.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // आम्ही अनुक्रमणिका `start` च्या आधीचे सर्व बिट कापले, म्हणजेच आम्ही प्रभावीपणे `start` च्या प्रमाणात राइट-शिफ्ट केले, म्हणून आपल्यास पाहिजे असलेले हे देखील आहे.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // खंडित बिटांवर अवलंबून गोल (half-to-even).
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// वितर्कापेक्षा काटेकोरपणे सर्वात लहान फ्लोटिंग पॉईंट क्रमांक शोधतो.
/// सबमॉर्मल्स, शून्य किंवा घातांक भूमिगत नसतात.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// वितर्कापेक्षा काटेकोरपणे सर्वात मोठा फ्लोटिंग पॉईंट क्रमांक शोधा.
// हे ऑपरेशन संतृप्त आहे, म्हणजेच next_float(inf) ==inf.
// या मॉड्यूलमधील बर्‍याच कोडच्या विपरीत, हे कार्य शून्य, अधोश्विक आणि अनफिनिटी हाताळते.
// तथापि, येथे इतर सर्व कोड प्रमाणे, ते एनएएन आणि नकारात्मक संख्यांबरोबर व्यवहार करत नाही.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // हे खरे असल्याचे खूप चांगले वाटले, परंतु ते कार्य करते.
        // 0.0 सर्व शून्य शब्द म्हणून एन्कोड केलेले आहे.सूक्ष्म जंतू 0x000 मीटर आहेत ... मी जेथे मीटर आहे.
        // विशेषतः, सर्वात लहान असामान्य 0x0 ... 01 आणि सर्वात मोठा 0x000F ... एफ आहे.
        // सर्वात छोटी सामान्य संख्या 0x0010 ... 0 आहे, म्हणून हा कोपरा केस देखील कार्य करते.
        // जर वाढ मँन्टिसाने ओव्हरफ्लो केली तर कॅरी बिट आपल्या इच्छेनुसार घातांक वाढवते आणि मॅन्टिसा बिट्स शून्य होतात.
        // लपलेल्या बिट अधिवेशनामुळे हेसुद्धा आपल्यास हवे आहे!
        // शेवटी, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}