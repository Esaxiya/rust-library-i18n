//! पद्धतींमध्ये रूपांतरित होण्यास फार अर्थ नाही अशा बिग्नामसाठी उपयुक्तता कार्ये.

// FIXME या मॉड्यूलचे नाव थोडी दुर्दैवी आहे, कारण इतर मॉड्यूल्स देखील `core::num` आयात करतात.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// `ones_place` पेक्षा कमी सर्व लक्षणीय बिट्स कमी करणे हे 0.5 ULP पेक्षा कमी, समान किंवा जास्त संबंधित सापेक्ष त्रुटीचा परिचय देते की नाही याची चाचणी घ्या.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // उर्वरित सर्व बिट्स शून्य असल्यास, ते= 0.5 यूएलपी आहे, अन्यथा> 0.5 अधिक बिट्स नसल्यास (अर्ध_बिट==0), खाली देखील योग्यरित्या समान दिले.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// दशांश संख्येसह असलेल्या एएससीआयआय स्ट्रिंगला `u64` मध्ये रूपांतरित करते.
///
/// ओव्हरफ्लो किंवा अवैध वर्णांची तपासणी करत नाही, म्हणून जर कॉलर सावध नसेल तर त्याचा परिणाम बोगस आहे आणि झेडस्पॅनिक 0 झेड करू शकतो (जरी तो एक्स 100 एक्स होणार नाही).
/// याव्यतिरिक्त, रिक्त तार शून्य मानले जातात.
/// हे कार्य अस्तित्वात आहे कारण
///
/// 1. `&[u8]` वर `FromStr` वापरण्यासाठी `from_utf8_unchecked` आवश्यक आहे, जे वाईट आहे, आणि
/// 2. या संपूर्ण फंक्शनपेक्षा `integral.parse()` आणि `fractional.parse()` चे परिणाम एकत्रितपणे शोधणे अधिक क्लिष्ट आहे.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// एएससीआयआय अंकांची स्ट्रिंग एका बिग्नुममध्ये रूपांतरित करते.
///
/// `from_str_unchecked` प्रमाणेच हे कार्य नॉन-अंकांचे तण काढण्यासाठी विश्लेषकांवर अवलंबून आहे.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// 64 बिट पूर्णांक मध्ये एक बिग्नुम लपेटतो.संख्या खूप मोठी असल्यास Panics.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// बिट्सची श्रेणी काढते.

/// निर्देशांक 0 सर्वात कमी महत्त्वाचा आहे आणि श्रेणी नेहमीपेक्षा अर्धा-खुली आहे.
/// रिटर्न प्रकारात फिटपेक्षा जास्त बिट काढायला सांगितले तर झेडपॅनिक्स ० झेड.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}