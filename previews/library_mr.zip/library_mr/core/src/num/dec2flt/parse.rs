//! फॉर्मच्या दशांश स्ट्रिंगचे प्रमाणीकरण आणि विघटन करणे:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! दुसर्‍या शब्दांत, दोन अपवादांसह मानक फ्लोटिंग-पॉइंट वाक्यरचनाः कोणतेही चिन्ह नाही आणि "inf" आणि "NaN" चे कोणतेही हँडलिंग नाही.हे (super::dec2flt) ड्राइव्हर फंक्शनद्वारे हाताळले जातात.
//!
//! वैध इनपुट ओळखणे तुलनेने सोपे असले तरी या मॉड्यूलला असंख्य अवैध बदल नाकारले पाहिजेत, कधीही झेडस्पॅनिक0 झेड आणि इतर मॉड्यूल्स त्या बदल्यात झेडस्पॅनिक0झेड (किंवा ओव्हरफ्लो) वर अवलंबून नसलेल्या असंख्य तपासणी करा.
//!
//! गोष्टी आणखी वाईट करण्यासाठी, सर्व काही इनपुटच्या एकाच पासमध्ये होते.
//! तर, काहीही सुधारित करताना सावधगिरी बाळगा आणि इतर विभागांसह डबल-चेक करा.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// दशांश स्ट्रिंगचे मनोरंजक भाग.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// दशांश घातांक, 18 पेक्षा कमी दशांश अंकांची हमी.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// इनपुट स्ट्रिंग एक वैध फ्लोटिंग पॉईंट क्रमांक आहे किंवा नाही आणि नाही तर ते अविभाज्य भाग, अपूर्णांक आणि त्यातील घातांक शोधा.
/// चिन्हे हाताळत नाहीत.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // 'e' पूर्वी अंक नाहीत
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // आम्हाला त्या बिंदूच्या आधी किंवा नंतर किमान एक अंक आवश्यक आहे.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // अपूर्णांकानंतर ट्रेलिंग जंक
            }
        }
        _ => Invalid, // पहिल्या अंकांच्या स्ट्रिंगनंतर पिछाडीवरचा जंक
    }
}

/// प्रथम-अंकीय वर्णांपर्यंत दशांश अंक काढते.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// घातांक काढणे आणि त्रुटी तपासणे.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // घुसखोरीनंतर पिछाडीवरचा जंक
    }
    if number.is_empty() {
        return Invalid; // रिक्त घातांक
    }
    // याक्षणी आपल्याकडे निश्चितपणे अंकांची वैध स्ट्रिंग आहे.`i64` मध्ये ठेवणे खूप लांब असू शकते, परंतु ते खूप मोठे असल्यास, इनपुट निश्चितच शून्य किंवा अनंत आहे.
    // दशांश अंकांमधील प्रत्येक शून्य केवळ +/-1 ने घातांशी जुळवून घेत असतो, एक्सपोर्ट=10 ^ 18 वर मर्यादा अगदी जवळ येण्यासाठी इनपुटमध्ये 17 एक्सबाईट एक्स 100 एक्स शूनो असणे आवश्यक आहे.
    //
    // आम्हाला अगदी काळजीपूर्वक वापरण्याची गरज नाही.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}