//! सानुकूल अनियंत्रित-सुस्पष्टता क्रमांक (bignum) अंमलबजावणी.
//!
//! स्टॅक मेमरीच्या किंमतीवर ढीग वाटप टाळण्यासाठी हे डिझाइन केले आहे.
//! सर्वात जास्त वापरलेला बिग्नम प्रकार, एक्स 100 एक्स 32 × 40=1,280 बिट द्वारे मर्यादित आहे आणि स्टॅक मेमरीच्या जास्तीत जास्त 160 बाइट घेईल.
//! हे शक्य सर्व मर्यादित `f64` मूल्यांना राउंड-ट्रिपिंगसाठी पुरेसे आहे.
//!
//! तत्वानुसार विविध इनपुटसाठी एकाधिक बिग्नुम प्रकार असणे शक्य आहे, परंतु कोड ब्लोट टाळण्यासाठी आम्ही तसे करत नाही.
//!
//! प्रत्येक बिग्नुम अजूनही प्रत्यक्ष उपयोगांसाठी शोधला जातो, त्यामुळे सामान्यत: काही फरक पडत नाही.
//!

// हे मॉड्यूल केवळ डिक्फ्ल्ट आणि फ्लॅट टू डीईसीसाठी आहे आणि कोर्सेटसमुळेच सार्वजनिक.
// हे कधीही स्थिर करण्याचे उद्दीष्ट नाही.
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// बिग्नुम्सद्वारे अंकगणित ऑपरेशन्स आवश्यक आहेत.
pub trait FullOps: Sized {
    /// `(carry', v')` असे `carry' * 2^W + v' = self + other + carry` मिळवते, जिथे `W` हे `Self` मधील बिटची संख्या आहे.
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// `(carry', v')` असे `carry'*2^W + v' = self* other + carry` मिळवते, जिथे `W` हे `Self` मधील बिटची संख्या आहे.
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// `(carry', v')` असे `carry'*2^W + v' = self* other + other2 + carry` मिळवते, जिथे `W` हे `Self` मधील बिटची संख्या आहे.
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// `(quo, rem)` जसे की `borrow *2^W + self = quo* other + rem` आणि `0 <= rem < other` मिळविते, जिथे `W` हे `Self` मधील बिटची संख्या आहे.
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // हे ओव्हरफ्लो होऊ शकत नाही;आउटपुट `0` आणि `2 * 2^nbits - 1` दरम्यान आहे.
                    // FIXME: एलएलव्हीएम यास एडीसी किंवा तत्सम रुपात अनुकूलित करेल?
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // हे ओव्हरफ्लो होऊ शकत नाही;
                    // आउटपुट `0` आणि `2^nbits * (2^nbits - 1)` दरम्यान आहे.
                    // FIXME: एलएलव्हीएम यास एडीसी किंवा तत्सम रुपात अनुकूलित करेल?
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // हे ओव्हरफ्लो होऊ शकत नाही;
                    // आउटपुट `0` आणि `2^nbits * (2^nbits - 1)` दरम्यान आहे.
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // हे ओव्हरफ्लो होऊ शकत नाही;आउटपुट `0` आणि `other * (2^nbits - 1)` दरम्यान आहे.
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // हे सक्षम करण्यासाठी आरएफसी #521 पहा.
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// अंकांमधील प्रतिनिधित्व करणार्‍या 5 च्या शक्तींची सारणी.विशेषतः, सर्वात मोठी {u8, u16, u32} मूल्य जी पाचची उर्जा असते तसेच संबंधित घातांक.
/// `mul_pow5` मध्ये वापरले.
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// स्टॅक-वाटप अनियंत्रित-अचूकता (विशिष्ट मर्यादेपर्यंत) पूर्णांक.
        ///
        /// हे दिलेल्या प्रकारच्या ("digit") च्या निश्चित-आकाराच्या अ‍ॅरेद्वारे समर्थित आहे.
        /// अ‍ॅरे फार मोठा नसला तरी (साधारणत: काहीशे बाइट्स), याची बेपर्वाईने कॉपी केल्यास परफॉर्मन्सवर परिणाम होऊ शकतो.
        ///
        /// हे हेतुपुरस्सर `Copy` नाही.
        ///
        /// ओव्हरफ्लोच्या बाबतीत Bignums panic वर सर्व ऑपरेशन्स उपलब्ध आहेत.
        /// कॉलर मोठ्या प्रमाणात बिग्नाम प्रकार वापरण्यास जबाबदार आहे.
        pub struct $name {
            /// एक अधिक वापरात जास्तीत जास्त "digit" ची ऑफसेट.
            /// हे कमी होत नाही, म्हणून गणना ऑर्डरबद्दल जागरूक रहा.
            /// `base[size..]` शून्य असावे.
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` `a + b *2^W + c* 2^(2W) + ...` चे प्रतिनिधित्व करते जेथे `W` अंकांच्या प्रकारातील बिटची संख्या आहे.
            base: [$ty; $n],
        }

        impl $name {
            /// एका अंकापासून एक बिग्नाम बनवते.
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// `u64` मूल्यातून एक बिगुनम बनवते.
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// आंतरिक अंक एक स्लाइस `[a, b, c, ...]` म्हणून दर्शविते की अंकीय मूल्य `a + b *2^W + c* 2^(2W) + ...` आहे जेथे `W` अंकांच्या प्रकारातील बिटची संख्या आहे.
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// जेथे बिट 0 सर्वात कमी महत्त्वाचे आहे तेथे `i`-th बिट मिळवते.
            /// दुसर्‍या शब्दांत, वजन `2^i` सह बिट.
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// Bignum शून्य असल्यास `true` मिळवते.
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// हे मूल्य दर्शविण्यासाठी आवश्यक बिटची संख्या मिळवते.
            /// लक्षात घ्या की शून्याला 0 बिट आवश्यक आहेत.
            pub fn bit_length(&self) -> usize {
                // शून्य असलेल्या सर्वात महत्त्वपूर्ण अंकांवर जा.
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // कोणतेही शून्य अंक नाहीत, म्हणजे संख्या शून्य आहे.
                    return 0;
                }
                // हे एक्स 100 एक्स आणि बिट शिफ्टसह ऑप्टिमाइझ केले जाऊ शकते, परंतु कदाचित ही त्रास कमी होणार नाही.
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// स्वतःमध्ये `other` जोडते आणि त्याचा स्वतःचा बदलण्यायोग्य संदर्भ परत करते.
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// स्वतःहून एक्स00 एक्स वजा करतो आणि स्वतःचा बदलता येणारा संदर्भ परत करतो.
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// अंक-आकाराच्या `other` ने स्वतःस गुणाकार करते आणि त्याचा स्वतःचा बदलता येणारा संदर्भ परत मिळवितो.
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// स्वतः `2^bits` ने गुणाकार करते आणि स्वतःचा बदलता येणारा संदर्भ परत करते.
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // `digits * digitbits` बिट द्वारे शिफ्ट
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // `bits` बिट द्वारे शिफ्ट
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // सेल्फ.बेस [.. अंक] शून्य आहे, शिफ्ट करण्याची आवश्यकता नाही
                }

                self.size = sz;
                self
            }

            /// स्वतः `5^e` ने गुणाकार करते आणि स्वतःचा बदलता येणारा संदर्भ परत करते.
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // २ on n वर अचूक एन ट्रेलिंग शून्य आहेत आणि फक्त संबंधित अंकांचे आकार सलग दोनची शक्ती आहेत, जेणेकरून हे टेबलसाठी योग्य अनुक्रमणिका आहे.
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // जोपर्यंत शक्य असेल तोपर्यंत सर्वात मोठ्या एकल-अंकी उर्जासह गुणाकार करा ...
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... तर उर्वरित संपवा.
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` (जेथे `W` अंकांच्या प्रकारातील बिटांची संख्या आहे) द्वारे वर्णन केलेल्या संख्येने स्वतःस गुणाकार करते आणि त्याचा स्वतःचा बदलता येणारा संदर्भ मिळवते.
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // अंतर्गत दिनचर्या.aa.len() <= bb.len() तेव्हा उत्कृष्ट कार्य करते.
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// स्वतःस एका अंकी आकाराच्या `other` ने विभाजित करते आणि त्याचा स्वतःचा बदलता संदर्भ *आणि* उर्वरित मिळवते.
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// दुसर्‍या बिग्नामद्वारे स्वत: ला विभाजित करा, भागफलकासह `q` अधिलिखित करा आणि उर्वरितसह `r`.
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // मूर्ख स्लो base-2 लांबीचा विभाग घेतला
                // https://en.wikipedia.org/wiki/Division_algorithm
                // लांबीच्या भागासाठी FIXME अधिक मोठा बेस ($ty) वापरते.
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // 1 ते बिट `i` सेट करा.
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// `Big32x40` साठीचा अंक प्रकार.
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// हा केवळ चाचणीसाठी वापरला जातो.
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}