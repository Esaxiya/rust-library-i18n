//! अविभाज्य प्रकारात रूपांतरित करण्यासाठी त्रुटी प्रकार.

use crate::convert::Infallible;
use crate::fmt;

/// चेक केलेला अविभाज्य प्रकार रूपांतरण अयशस्वी झाल्यावर त्रुटी प्रकार परत आला.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // `Infallible` `!` चे उपनाव बनल्यास वरील `From<Infallible> for TryFromIntError` सारखे कोड कार्यरत राहतील याची खात्री करण्यासाठी सक्ती करण्याऐवजी सामना.
        //
        //
        match never {}
    }
}

/// पूर्णांक विश्लेषित करताना परत येऊ शकणारी त्रुटी.
///
/// ही त्रुटी एक्स 100 एक्स सारख्या आदिम पूर्णांक प्रकारांवरील एक्स01 एक्स फंक्शन्ससाठी त्रुटी प्रकार म्हणून वापरली जाते.
///
/// # संभाव्य कारणे
///
/// इतर कारणांपैकी, एक्स 100 एक्स स्ट्रिंगमध्ये अग्रगण्य किंवा पिछाडीवर असलेल्या व्हाइटस्पेसमुळे फेकले जाऊ शकते उदा. जेव्हा मानक इनपुटमधून ते प्राप्त होते.
///
/// [`str::trim()`] पद्धत वापरणे हे सुनिश्चित करते की विश्लेषित करण्यापूर्वी कोणतेही स्पेस स्पेस राहत नाही.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// पूर्णांक अयशस्वी होण्यास कारणीभूत ठरू शकते अशा विविध प्रकारच्या त्रुटी संचयित करा.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// विश्लेषित केले जाणारे मूल्य रिक्त आहे.
    ///
    /// इतर कारणांपैकी रिक्त स्ट्रिंगचे विश्लेषण करताना हा प्रकार तयार केला जाईल.
    Empty,
    /// त्याच्या संदर्भात अवैध अंक आहे.
    ///
    /// इतर कारणांपैकी, एएससीआयआय नसलेल्या ताराचे विश्लेषण करतेवेळी हा प्रकार तयार केला जाईल.
    ///
    /// जेव्हा `+` किंवा `-` एक स्ट्रिंगमध्ये स्वतःच किंवा संख्येच्या मध्यभागी चुकीच्या ठिकाणी बदलला जातो तेव्हा देखील हा प्रकार तयार केला जातो.
    ///
    ///
    InvalidDigit,
    /// लक्ष्य पूर्णांक प्रकारात संग्रहित करण्यासाठी पूर्णांक खूप मोठा आहे.
    PosOverflow,
    /// लक्ष्य पूर्णांक प्रकारात संग्रहित करण्यासाठी पूर्णांक खूप लहान आहे.
    NegOverflow,
    /// मूल्य शून्य होते
    ///
    /// पार्सिंग स्ट्रिंगचे मूल्य शून्य असते तेव्हा हा प्रकार उत्सर्जित होईल जो शून्य नसलेल्या प्रकारांसाठी बेकायदेशीर असेल.
    ///
    Zero,
}

impl ParseIntError {
    /// पूर्णांक अयशस्वी होण्याच्या विस्तृत कारणास निष्पन्न करते.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}