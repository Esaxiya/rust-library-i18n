//! केवळ अंतर्गत वापरासाठी विस्तारित सुस्पष्टता "soft float".

// हे मॉड्यूल केवळ डिक्फ्ल्ट आणि फ्लॅट टू डीईसीसाठी आहे आणि कोर्सेटसमुळेच सार्वजनिक.
// हे कधीही स्थिर करण्याचे उद्दीष्ट नाही.
#![doc(hidden)]
#![unstable(
    feature = "core_private_diy_float",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

/// `f * 2^e` चे प्रतिनिधित्व करणारा सानुकूल 64-बिट फ्लोटिंग पॉईंट प्रकार.
#[derive(Copy, Clone, Debug)]
#[doc(hidden)]
pub struct Fp {
    /// पूर्णांक मँटीसा.
    pub f: u64,
    /// बेस 2 मधील घातांक.
    pub e: i16,
}

impl Fp {
    /// स्वतःचे आणि `other` चे योग्यरित्या गोल केलेले उत्पादन मिळवते.
    pub fn mul(&self, other: &Fp) -> Fp {
        const MASK: u64 = 0xffffffff;
        let a = self.f >> 32;
        let b = self.f & MASK;
        let c = other.f >> 32;
        let d = other.f & MASK;
        let ac = a * c;
        let bc = b * c;
        let ad = a * d;
        let bd = b * d;
        let tmp = (bd >> 32) + (ad & MASK) + (bc & MASK) + (1 << 31) /* round */;
        let f = ac + (ad >> 32) + (bc >> 32) + (tmp >> 32);
        let e = self.e + other.e + 64;
        Fp { f, e }
    }

    /// स्वतःस सामान्य करते जेणेकरून परिणामी मॅन्टीसा किमान `2^63` असेल.
    pub fn normalize(&self) -> Fp {
        let mut f = self.f;
        let mut e = self.e;
        if f >> (64 - 32) == 0 {
            f <<= 32;
            e -= 32;
        }
        if f >> (64 - 16) == 0 {
            f <<= 16;
            e -= 16;
        }
        if f >> (64 - 8) == 0 {
            f <<= 8;
            e -= 8;
        }
        if f >> (64 - 4) == 0 {
            f <<= 4;
            e -= 4;
        }
        if f >> (64 - 2) == 0 {
            f <<= 2;
            e -= 2;
        }
        if f >> (64 - 1) == 0 {
            f <<= 1;
            e -= 1;
        }
        debug_assert!(f >= (1 >> 63));
        Fp { f, e }
    }

    /// सामायिक घातांक मिळविण्यासाठी स्वतःस सामान्य करते.
    /// हे केवळ घातांक कमी करू शकते (आणि अशा प्रकारे मॅन्टिसा वाढवते).
    pub fn normalize_to(&self, e: i16) -> Fp {
        let edelta = self.e - e;
        assert!(edelta >= 0);
        let edelta = edelta as usize;
        assert_eq!(self.f << edelta >> edelta, self.f);
        Fp { f: self.f << edelta, e }
    }
}