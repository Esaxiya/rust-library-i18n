//! वैकल्पिक मूल्ये.
//!
//! प्रकार एक्स ०१ एक्स वैकल्पिक मूल्य दर्शवितो: प्रत्येक एक्स ०२ एक्स एकतर एक्स ०0 एक्स आहे आणि त्यात मूल्य, किंवा एक्स २०० एक्स आहे, आणि नाही.
//! [`Option`] Rust कोडमध्ये प्रकार बरेच सामान्य आहेत, कारण त्यांचे अनेक उपयोग आहेत:
//!
//! * आरंभिक मूल्ये
//! * त्यांच्या संपूर्ण इनपुट श्रेणी (आंशिक कार्ये) वर परिभाषित नसलेल्या फंक्शनसाठी रिटर्न मूल्ये
//! * अन्यथा साध्या त्रुटी नोंदविण्याकरिता रिटर्न मूल्य, जेथे [`None`] त्रुटीवर परत केले जाते
//! * पर्यायी रचना फील्ड
//! * कर्ज दिले जाऊ शकते किंवा "taken" असलेले फील्ड तयार करा
//! * पर्यायी फंक्शन वितर्क
//! * शून्य पॉइंटर्स
//! * कठीण परिस्थितीतून गोष्टी अदलाबदल करणे
//!
//! [`ऑप्शन`] चे सामान्यत: मूल्याच्या उपस्थितीची चौकशी करण्यासाठी आणि कारवाई करण्यासाठी नेहमीच नमुन्याशी जुळणी केली जाते, जे नेहमीच एक्स 100 एक्स प्रकरणात असते.
//!
//!
//! ```
//! fn divide(numerator: f64, denominator: f64) -> Option<f64> {
//!     if denominator == 0.0 {
//!         None
//!     } else {
//!         Some(numerator / denominator)
//!     }
//! }
//!
//! // फंक्शनचे रिटर्न व्हॅल्यू हा एक पर्याय आहे
//! let result = divide(2.0, 3.0);
//!
//! // मूल्य पुनर्प्राप्त करण्यासाठी नमुना सामना
//! match result {
//!     // विभाग वैध होता
//!     Some(x) => println!("Result: {}", x),
//!     // विभाग अवैध होता
//!     None    => println!("Cannot divide by 0"),
//! }
//! ```
//!
//!
//!
//!
//!
// FIXME: व्यवहारात बर्‍याच पद्धतींनी `Option` कसे वापरावे ते दर्शवा
//
//! # पर्याय आणि पॉईंटर्स ("nullable" पॉइंटर्स)
//!
//! Rust चे पॉईंटर प्रकार नेहमी वैध स्थानाकडे निर्देशित केले पाहिजेत;कोणतेही "null" संदर्भ नाहीत.त्याऐवजी, Rust मध्ये *पर्यायी* पॉईंटर्स आहेत, पर्यायी मालकीच्या बॉक्स प्रमाणे, [`पर्याय`]`<`[`बॉक्स<T>`]`>`.
//!
//! खालील उदाहरणे [`i32`] चा पर्यायी बॉक्स तयार करण्यासाठी [`Option`] वापरतात.
//! लक्षात घ्या की प्रथम आतील [`i32`] मूल्य वापरण्यासाठी, बॉक्समध्ये मूल्य आहे की नाही हे निर्धारित करण्यासाठी `check_optional` फंक्शनला नमुना जुळणी वापरण्याची आवश्यकता आहे (उदा. ते एक्स ० एस एक्स आहे की नाही X00 एक्स.
//!
//!
//! ```
//! let optional = None;
//! check_optional(optional);
//!
//! let optional = Some(Box::new(9000));
//! check_optional(optional);
//!
//! fn check_optional(optional: Option<Box<i32>>) {
//!     match optional {
//!         Some(p) => println!("has value {}", p),
//!         None => println!("has no value"),
//!     }
//! }
//! ```
//!
//! # Representation
//!
//! [`Option<T>`] चा आकार `T` प्रमाणेच खालील प्रकार `T` अनुकूलित करण्याची Rust हमी देते:
//!
//! * [`Box<U>`]
//! * `&U`
//! * `&mut U`
//! * `fn`, `extern "C" fn`
//! * [`num::NonZero*`]
//! * [`ptr::NonNull<U>`]
//! * `#[repr(transparent)]` या यादीतील प्रकारांपैकी एकाभोवती रचना करा.
//!
//! पुढील हमी दिली गेली आहे की वरील प्रकरणांमध्ये, `T` च्या सर्व वैध मूल्यांपासून ते X02 एक्स पर्यंत आणि एक्स ०3 एक्स ते एक्स ०4 एक्स पर्यंत एक्स00 एक्स (परंतु एक्स ०X एक्स एक्स एक्स 66 एक्समध्ये रूपांतरित करणे ही एक अपरिभाषित वर्तन आहे).
//!
//! # Examples
//!
//! [`Option`] वर मूळ नमुना जुळत आहे:
//!
//! ```
//! let msg = Some("howdy");
//!
//! // असलेल्या स्ट्रिंगचा संदर्भ घ्या
//! if let Some(m) = &msg {
//!     println!("{}", *m);
//! }
//!
//! // पर्याय नष्ट करून, समाविष्ट केलेली स्ट्रिंग काढा
//! let unwrapped_msg = msg.unwrap_or("default message");
//! ```
//!
//! लूपच्या आधी [`None`] वर निकाल प्रारंभ करा:
//!
//! ```
//! enum Kingdom { Plant(u32, &'static str), Animal(u32, &'static str) }
//!
//! // शोधण्यासाठी डेटाची एक सूची.
//! let all_the_big_things = [
//!     Kingdom::Plant(250, "redwood"),
//!     Kingdom::Plant(230, "noble fir"),
//!     Kingdom::Plant(229, "sugar pine"),
//!     Kingdom::Animal(25, "blue whale"),
//!     Kingdom::Animal(19, "fin whale"),
//!     Kingdom::Animal(15, "north pacific right whale"),
//! ];
//!
//! // आम्ही सर्वात मोठ्या प्राण्याचे नाव शोधत आहोत, परंतु नुकतीच आपल्याकडे एक्स 100 एक्स आला आहे.
//! //
//! let mut name_of_biggest_animal = None;
//! let mut size_of_biggest_animal = 0;
//! for big_thing in &all_the_big_things {
//!     match *big_thing {
//!         Kingdom::Animal(size, name) if size > size_of_biggest_animal => {
//!             // आता आम्हाला एका मोठ्या प्राण्याचे नाव सापडले आहे
//!             size_of_biggest_animal = size;
//!             name_of_biggest_animal = Some(name);
//!         }
//!         Kingdom::Animal(..) | Kingdom::Plant(..) => ()
//!     }
//! }
//!
//! match name_of_biggest_animal {
//!     Some(name) => println!("the biggest animal is {}", name),
//!     None => println!("there are no animals :("),
//! }
//! ```
//!
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Box<U>`]: ../../std/boxed/struct.Box.html
//! [`num::NonZero*`]: crate::num
//! [`ptr::NonNull<U>`]: crate::ptr::NonNull
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{FromIterator, FusedIterator, TrustedLen};
use crate::pin::Pin;
use crate::{
    fmt, hint, mem,
    ops::{self, Deref, DerefMut},
};

/// `Option` प्रकार.अधिकसाठी [the module level documentation](self) पहा.
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[rustc_diagnostic_item = "option_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Option<T> {
    /// कींमत नाही
    #[lang = "None"]
    #[stable(feature = "rust1", since = "1.0.0")]
    None,
    /// काही मूल्य `T`
    #[lang = "Some"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Some(#[stable(feature = "rust1", since = "1.0.0")] T),
}

/////////////////////////////////////////////////////////////////////////////
// प्रकारची अंमलबजावणी
/////////////////////////////////////////////////////////////////////////////

impl<T> Option<T> {
    /////////////////////////////////////////////////////////////////////////
    // अंतर्भूत मूल्ये विचारत आहेत
    /////////////////////////////////////////////////////////////////////////

    /// पर्याय [`Some`] मूल्य असल्यास `true` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_some(), true);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_some(), false);
    /// ```
    #[must_use = "if you intended to assert that this has a value, consider `.unwrap()` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_some(&self) -> bool {
        matches!(*self, Some(_))
    }

    /// पर्याय [`None`] मूल्य असल्यास `true` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_none(), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_none(), true);
    /// ```
    #[must_use = "if you intended to assert that this doesn't have a value, consider \
                  `.and_then(|| panic!(\"`Option` had a value when expected `None`\"))` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_none(&self) -> bool {
        !self.is_some()
    }

    /// पर्याय दिलेली मूल्य असलेली [`Some`] मूल्य असल्यास `true` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Option<u32> = Some(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Some(y) => x == y,
            None => false,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // संदर्भांसह कार्य करण्यासाठी अ‍ॅडॉप्टर
    /////////////////////////////////////////////////////////////////////////

    /// `&Option<T>` ते `Option<&T>` मध्ये रूपांतरित करते.
    ///
    /// # Examples
    ///
    /// मूळ जतन करुन `पर्याय <` [`स्ट्रिंग`]`>`ला`पर्याय <`[`usize`] `>` मध्ये रूपांतरित करते.
    /// [`map`] पद्धत मूळ वापरुन `self` आर्ग्युमेंट घेते, म्हणून हे तंत्र प्रथम मूळमधील मूल्याच्या संदर्भासाठी `Option` घेण्यास `as_ref` वापरते.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let text: Option<String> = Some("Hello, world!".to_string());
    /// // प्रथम, `Option<String>` ला `as_ref` सह `Option<&String>` वर कास्ट करा, नंतर स्टॅकवर `text` सोडून `map` सह *ते* वापरा.
    /////
    /// let text_length: Option<usize> = text.as_ref().map(|s| s.len());
    /// println!("still can print text: {:?}", text);
    /// ```
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Option<&T> {
        match *self {
            Some(ref x) => Some(x),
            None => None,
        }
    }

    /// `&mut Option<T>` ते `Option<&mut T>` मध्ये रूपांतरित करते.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// match x.as_mut() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Option<&mut T> {
        match *self {
            Some(ref mut x) => Some(x),
            None => None,
        }
    }

    /// [`Pin`]`<आणि पर्यायातून रूपांतरित करते<T>>`ते`पर्याय <`[`पिन]]`<आणि टी>>`.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_ref(self: Pin<&Self>) -> Option<Pin<&T>> {
        // सुरक्षितता: `x` पिन केल्याची हमी दिलेली आहे कारण ती `self` मधून आली आहे
        // जे पिन केलेले आहे.
        unsafe { Pin::get_ref(self).as_ref().map(|x| Pin::new_unchecked(x)) }
    }

    /// [`Pin`] from <व रुपांतरित पर्यायातून रुपांतरित करते<T>> `ते` पर्याय <`[` पिन]]&<आणि मट टी>>.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_mut(self: Pin<&mut Self>) -> Option<Pin<&mut T>> {
        // सुरक्षितता: X01 एक्सचा वापर `self` मध्ये कधीही `self` हलविण्यासाठी केला जात नाही.
        // `x` पिन केल्याची हमी आहे कारण ते पिन केलेल्या `self` कडून आले आहे.
        unsafe { Pin::get_unchecked_mut(self).as_mut().map(|x| Pin::new_unchecked(x)) }
    }

    /////////////////////////////////////////////////////////////////////////
    // समाविष्ट मूल्ये मिळवत आहे
    /////////////////////////////////////////////////////////////////////////

    /// `self` मूल्य वापरत असलेले असलेले [`Some`] मूल्य मिळवते.
    ///
    /// # Panics
    ///
    /// जर मूल्य `msg` द्वारे प्रदान केलेल्या सानुकूल झेडस्पॅनिक 0 झेड संदेशासह [`None`] असेल तर झेडपॅनिक्स 0 झेड.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("value");
    /// assert_eq!(x.expect("fruits are healthy"), "value");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// x.expect("fruits are healthy"); // panics with `fruits are healthy`
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Some(val) => val,
            None => expect_failed(msg),
        }
    }

    /// `self` मूल्य वापरत असलेले असलेले [`Some`] मूल्य मिळवते.
    ///
    /// हे कार्य कदाचित panic असू शकते, कारण त्याचा वापर सामान्यपणे परावृत्त केला जातो.
    /// त्याऐवजी, नमुना जुळणी वापरण्यास आणि [`None`] प्रकरण स्पष्टपणे हाताळण्यास प्राधान्य द्या किंवा [`unwrap_or`], [`unwrap_or_else`] किंवा [`unwrap_or_default`] वर कॉल करा.
    ///
    ///
    /// [`unwrap_or`]: Option::unwrap_or
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    /// [`unwrap_or_default`]: Option::unwrap_or_default
    ///
    /// # Panics
    ///
    /// जर स्वत: चे मूल्य [`None`] चे असेल तर Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("air");
    /// assert_eq!(x.unwrap(), "air");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// assert_eq!(x.unwrap(), "air"); // fails
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn unwrap(self) -> T {
        match self {
            Some(val) => val,
            None => panic!("called `Option::unwrap()` on a `None` value"),
        }
    }

    /// असलेले [`Some`] मूल्य किंवा प्रदान केलेला डीफॉल्ट मिळवते.
    ///
    /// एक्स ० ए एक्सकडे पाठविलेल्या वितर्कांचे उत्सुकतेने मूल्यांकन केले जाते;आपण एखाद्या फंक्शन कॉलचा निकाल देत असल्यास, एक्स 100 एक्स वापरण्याची शिफारस केली जाते, ज्याचे आळशी मूल्यांकन केले जाते.
    ///
    ///
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(Some("car").unwrap_or("bike"), "car");
    /// assert_eq!(None.unwrap_or("bike"), "bike");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Some(x) => x,
            None => default,
        }
    }

    /// असलेले [`Some`] मूल्य मिळवते किंवा बंद केल्यापासून त्याचे गणन करते.
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 10;
    /// assert_eq!(Some(4).unwrap_or_else(|| 2 * k), 4);
    /// assert_eq!(None.unwrap_or_else(|| 2 * k), 20);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce() -> T>(self, f: F) -> T {
        match self {
            Some(x) => x,
            None => f(),
        }
    }

    /// मूल्य [`None`] नाही याची तपासणी न करता, `self` मूल्य वापरत असलेले असलेले [`Some`] मूल्य मिळवते.
    ///
    ///
    /// # Safety
    ///
    /// [`None`] वर या पद्धतीला कॉल करणे म्हणजे *[अपरिभाषित वर्तन]*.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x = Some("air");
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air");
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Option<&str> = None;
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air"); // अपरिभाषित वर्तन!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_some());
        match self {
            Some(val) => val,
            // सुरक्षितता: सुरक्षितता करार कॉलरद्वारे कायम ठेवला जाणे आवश्यक आहे.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // बदललेली मूल्ये बदलली
    /////////////////////////////////////////////////////////////////////////

    /// समाविष्ट केलेल्या मूल्यावर कार्य करून एक `Option<T>` ते `Option<U>` नकाशे.
    ///
    /// # Examples
    ///
    /// मूळ वापरत असलेल्या `पर्याय <` [`स्ट्रिंग`]`>`ला`पर्याय <`[`usize`] `>` मध्ये रूपांतरित करते:
    ///
    /// [`String`]: ../../std/string/struct.String.html
    /// ```
    /// let maybe_some_string = Some(String::from("Hello, World!"));
    /// // `Option::map` `maybe_some_string` वापरत *मूल्यानुसार* स्वत: चा वापर करते
    /// let maybe_some_len = maybe_some_string.map(|s| s.len());
    ///
    /// assert_eq!(maybe_some_len, Some(13));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, f: F) -> Option<U> {
        match self {
            Some(x) => Some(f(x)),
            None => None,
        }
    }

    /// समाविष्ट केलेल्या मूल्यावर (कोणत्याही असल्यास) एक कार्य लागू करते, किंवा प्रदान केलेला डीफॉल्ट (नसल्यास) परत करते.
    ///
    /// एक्स ० ए एक्सकडे पाठविलेल्या वितर्कांचे उत्सुकतेने मूल्यांकन केले जाते;आपण एखाद्या फंक्शन कॉलचा निकाल देत असल्यास, एक्स 100 एक्स वापरण्याची शिफारस केली जाते, ज्याचे आळशी मूल्यांकन केले जाते.
    ///
    ///
    /// [`map_or_else`]: Option::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default,
        }
    }

    /// समाविष्ट केलेल्या व्हॅल्यू (एखादे असल्यास) वर फंक्शन लागू करते, किंवा डीफॉल्टची गणना करते (नसल्यास).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x = Some("foo");
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 42);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or_else<U, D: FnOnce() -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default(),
        }
    }

    /// `Option<T>` ला [`Result<T, E>`] मध्ये [`Some(v)`] आणि [`None`] ला [`Err(err)`] मध्ये मॅपिंग बनविते.
    ///
    /// एक्स ० ए एक्सकडे पाठविलेल्या वितर्कांचे उत्सुकतेने मूल्यांकन केले जाते;आपण एखाद्या फंक्शन कॉलचा निकाल देत असल्यास, एक्स 100 एक्स वापरण्याची शिफारस केली जाते, ज्याचे आळशी मूल्यांकन केले जाते.
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err)`]: Err
    /// [`Some(v)`]: Some
    /// [`ok_or_else`]: Option::ok_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or(0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or(0), Err(0));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or<E>(self, err: E) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err),
        }
    }

    /// `Option<T>` ला [`Result<T, E>`] मध्ये [`Some(v)`] आणि [`None`] ला [`Err(err())`] मध्ये मॅपिंग बनविते.
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err())`]: Err
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or_else(|| 0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or_else(|| 0), Err(0));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or_else<E, F: FnOnce() -> E>(self, err: F) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err()),
        }
    }

    /// पर्यायामध्ये एक्स00 एक्स समाविष्ट करते नंतर त्यास बदलण्याचा संदर्भ द्या.
    ///
    /// पर्यायात आधीपासूनच मूल्य असल्यास, जुने मूल्य सोडले जाईल.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(option_insert)]
    ///
    /// let mut opt = None;
    /// let val = opt.insert(1);
    /// assert_eq!(*val, 1);
    /// assert_eq!(opt.unwrap(), 1);
    /// let val = opt.insert(2);
    /// assert_eq!(*val, 2);
    /// *val = 3;
    /// assert_eq!(opt.unwrap(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "option_insert", reason = "newly added", issue = "78271")]
    pub fn insert(&mut self, value: T) -> &mut T {
        *self = Some(value);

        match self {
            Some(v) => v,
            // सुरक्षितता: वरील कोडमध्ये फक्त पर्याय भरला
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Iterator कन्स्ट्रक्टर
    /////////////////////////////////////////////////////////////////////////

    /// संभाव्यत: समाविलेल्या मूल्यापेक्षा इटररेटर मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(4);
    /// assert_eq!(x.iter().next(), Some(&4));
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn iter(&self) -> Iter<'_, T> {
        Iter { inner: Item { opt: self.as_ref() } }
    }

    /// संभाव्यत: समाविष्‍ट मूल्‍यांऐवजी म्युटेबल इटरेटर परत करतो.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(4);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    ///
    /// let mut x: Option<u32> = None;
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: Item { opt: self.as_mut() } }
    }

    /////////////////////////////////////////////////////////////////////////
    // उत्सुक आणि आळशी मूल्यांवर बुलियन ऑपरेशन्स
    /////////////////////////////////////////////////////////////////////////

    /// पर्याय [`None`] असल्यास [`None`] मिळवते, अन्यथा `optb` परत करते.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), None);
    ///
    /// let x = Some(2);
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), Some("foo"));
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, optb: Option<U>) -> Option<U> {
        match self {
            Some(_) => optb,
            None => None,
        }
    }

    /// पर्याय [`None`] असल्यास [`None`] मिळवते, अन्यथा लपेटलेल्या मूल्यासह `f` कॉल करते आणि निकाल परत करतो.
    ///
    ///
    /// काही भाषा या ऑपरेशनला फ्लॅटमॅप म्हणतात.
    ///
    /// # Examples
    ///
    /// ```
    /// fn sq(x: u32) -> Option<u32> { Some(x * x) }
    /// fn nope(_: u32) -> Option<u32> { None }
    ///
    /// assert_eq!(Some(2).and_then(sq).and_then(sq), Some(16));
    /// assert_eq!(Some(2).and_then(sq).and_then(nope), None);
    /// assert_eq!(Some(2).and_then(nope).and_then(sq), None);
    /// assert_eq!(None.and_then(sq).and_then(sq), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Option<U>>(self, f: F) -> Option<U> {
        match self {
            Some(x) => f(x),
            None => None,
        }
    }

    /// पर्याय [`None`] असल्यास [`None`] मिळवते, अन्यथा लपेटलेल्या मूल्यासह `predicate` कॉल करते आणि परत मिळवते:
    ///
    ///
    /// - [`Some(t)`] जर `predicate` `true` परत करेल (जेथे `t` गुंडाळलेले मूल्य आहे) आणि
    /// - [`None`] `predicate` `false` परत केल्यास.
    ///
    /// हे कार्य [`Iterator::filter()`] प्रमाणेच कार्य करते.
    /// आपण `Option<T>` एक किंवा शून्य घटकांपेक्षा पुनरावृत्ती करणारा असल्याची कल्पना करू शकता.
    /// `filter()` कोणते घटक ठेवायचे ते ठरवू देते.
    ///
    /// # Examples
    ///
    /// ```rust
    /// fn is_even(n: &i32) -> bool {
    ///     n % 2 == 0
    /// }
    ///
    /// assert_eq!(None.filter(is_even), None);
    /// assert_eq!(Some(3).filter(is_even), None);
    /// assert_eq!(Some(4).filter(is_even), Some(4));
    /// ```
    ///
    /// [`Some(t)`]: Some
    ///
    #[inline]
    #[stable(feature = "option_filter", since = "1.27.0")]
    pub fn filter<P: FnOnce(&T) -> bool>(self, predicate: P) -> Self {
        if let Some(x) = self {
            if predicate(&x) {
                return Some(x);
            }
        }
        None
    }

    /// जर त्यात मूल्य असेल तर तो पर्याय मिळवते, अन्यथा `optb` परत करते.
    ///
    /// एक्स ० ए एक्सकडे पाठविलेल्या वितर्कांचे उत्सुकतेने मूल्यांकन केले जाते;आपण एखाद्या फंक्शन कॉलचा निकाल देत असल्यास, एक्स 100 एक्स वापरण्याची शिफारस केली जाते, ज्याचे आळशी मूल्यांकन केले जाते.
    ///
    ///
    /// [`or_else`]: Option::or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y = None;
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x = None;
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(100));
    ///
    /// let x = Some(2);
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = None;
    /// assert_eq!(x.or(y), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or(self, optb: Option<T>) -> Option<T> {
        match self {
            Some(_) => self,
            None => optb,
        }
    }

    /// पर्यायात तो मूल्य असल्यास परतावा, अन्यथा `f` ला कॉल करतो आणि निकाल परत करतो.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn nobody() -> Option<&'static str> { None }
    /// fn vikings() -> Option<&'static str> { Some("vikings") }
    ///
    /// assert_eq!(Some("barbarians").or_else(vikings), Some("barbarians"));
    /// assert_eq!(None.or_else(vikings), Some("vikings"));
    /// assert_eq!(None.or_else(nobody), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F: FnOnce() -> Option<T>>(self, f: F) -> Option<T> {
        match self {
            Some(_) => self,
            None => f(),
        }
    }

    /// हे `self` पैकी एक असल्यास [`Some`] मिळवते, `optb` हे [`Some`] आहे अन्यथा [`None`] परत करते.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x = Some(2);
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), None);
    /// ```
    #[inline]
    #[stable(feature = "option_xor", since = "1.37.0")]
    pub fn xor(self, optb: Option<T>) -> Option<T> {
        match (self, optb) {
            (Some(a), None) => Some(a),
            (None, Some(b)) => Some(b),
            _ => None,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // काहीही नसल्यास घालण्यासाठी एंट्री-सारखी ऑपरेशन्स आणि संदर्भ परत
    /////////////////////////////////////////////////////////////////////////

    /// तो [`None`] असल्यास पर्यायात `value` समाविष्ट करते, नंतर समाविष्ट केलेल्या मूल्याचा बदल बदलते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert(5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert(&mut self, value: T) -> &mut T {
        self.get_or_insert_with(|| value)
    }

    /// हे डीफॉल्ट मूल्य जर तो [`None`] असेल तर त्यामध्ये समाविष्ट करते, नंतर समाविष्ट केलेल्या मूल्याचे बदल बदलते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_get_or_insert_default)]
    ///
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_default();
    ///     assert_eq!(y, &0);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[unstable(feature = "option_get_or_insert_default", issue = "82901")]
    pub fn get_or_insert_default(&mut self) -> &mut T
    where
        T: Default,
    {
        self.get_or_insert_with(Default::default)
    }

    /// `f` वरून गणना केलेले मूल्य जर ते X00 एक्स असेल तर ते समाविष्ट करते, नंतर समाविष्ट केलेल्या मूल्याचे बदल बदलते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_with(|| 5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert_with<F: FnOnce() -> T>(&mut self, f: F) -> &mut T {
        if let None = *self {
            *self = Some(f());
        }

        match self {
            Some(v) => v,
            // सुरक्षितताः `self` करिता `None` प्रकार `Some` ने बदलला असता
            // वरील कोडमध्ये भिन्न
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Misc
    /////////////////////////////////////////////////////////////////////////

    /// त्याच्या जागेवर एक [`None`] सोडून पर्यायातून मूल्य मिळविते.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, Some(2));
    ///
    /// let mut x: Option<u32> = None;
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self)
    }

    /// पॅरामीटरमध्ये दिलेल्या मूल्याद्वारे पर्यायामधील वास्तविक मूल्य पुनर्स्थित करते, जर विद्यमान असेल तर जुने मूल्य परत आणून, [`Some`] त्याच्या जागी ठेवून एकही डीिनटाइझ न करता.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let old = x.replace(5);
    /// assert_eq!(x, Some(5));
    /// assert_eq!(old, Some(2));
    ///
    /// let mut x = None;
    /// let old = x.replace(3);
    /// assert_eq!(x, Some(3));
    /// assert_eq!(old, None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "option_replace", since = "1.31.0")]
    pub fn replace(&mut self, value: T) -> Option<T> {
        mem::replace(self, Some(value))
    }

    /// दुसर्‍या `Option` सह झिप `self`.
    ///
    /// जर `self` हे `Some(s)` आहे आणि `other` हे X01 एक्स आहे, तर ही पद्धत एक्स 100 एक्स परत करते.
    /// अन्यथा, `None` परत केले.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(1);
    /// let y = Some("hi");
    /// let z = None::<u8>;
    ///
    /// assert_eq!(x.zip(y), Some((1, "hi")));
    /// assert_eq!(x.zip(z), None);
    /// ```
    #[stable(feature = "option_zip_option", since = "1.46.0")]
    pub fn zip<U>(self, other: Option<U>) -> Option<(T, U)> {
        match (self, other) {
            (Some(a), Some(b)) => Some((a, b)),
            _ => None,
        }
    }

    /// X001 फंक्शनसह झिप्स X01 एक्स आणि दुसरे `Option`.
    ///
    /// जर `self` हे `Some(s)` आहे आणि `other` हे X01 एक्स आहे, तर ही पद्धत एक्स 100 एक्स परत करते.
    /// अन्यथा, `None` परत केले.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_zip)]
    ///
    /// #[derive(Debug, PartialEq)]
    /// struct Point {
    ///     x: f64,
    ///     y: f64,
    /// }
    ///
    /// impl Point {
    ///     fn new(x: f64, y: f64) -> Self {
    ///         Self { x, y }
    ///     }
    /// }
    ///
    /// let x = Some(17.5);
    /// let y = Some(42.7);
    ///
    /// assert_eq!(x.zip_with(y, Point::new), Some(Point { x: 17.5, y: 42.7 }));
    /// assert_eq!(x.zip_with(None, Point::new), None);
    /// ```
    #[unstable(feature = "option_zip", issue = "70086")]
    pub fn zip_with<U, F, R>(self, other: Option<U>, f: F) -> Option<R>
    where
        F: FnOnce(T, U) -> R,
    {
        Some(f(self?, other?))
    }
}

impl<T: Copy> Option<&T> {
    /// पर्यायाची सामग्री कॉपी करुन एक एक्स 100 एक्सवर एक्स0 एक्स एक्स नकाशे करा.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&t| t)
    }
}

impl<T: Copy> Option<&mut T> {
    /// पर्यायाची सामग्री कॉपी करुन एक एक्स 100 एक्सवर एक्स0 एक्स एक्स नकाशे करा.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone> Option<&T> {
    /// पर्यायाची सामग्री क्लोनिंग करुन एक एक्स 100 एक्स वर एक्स 100 एक्स नकाशे.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone> Option<&mut T> {
    /// पर्यायाची सामग्री क्लोनिंग करुन एक एक्स 100 एक्स वर एक्स 100 एक्स नकाशे.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(since = "1.26.0", feature = "option_ref_mut_cloned")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: fmt::Debug> Option<T> {
    /// [`None`] ची अपेक्षा असताना आणि काहीही परत न करता `self` घेते.
    ///
    /// # Panics
    ///
    /// Panics मूल्य [`Some`] असल्यास पास केलेल्या संदेशासह panic संदेश आणि [`Some`] ची सामग्री.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // सर्व झीज अद्वितीय असल्याने हे झेडस्पॅनिक 0 झेड करणार नाही.
    ///     squares.insert(i, i * i).expect_none("duplicate key");
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).expect_none("duplicate key");
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_expect_none", reason = "newly added", issue = "62633")]
    pub fn expect_none(self, msg: &str) {
        if let Some(val) = self {
            expect_none_failed(msg, &val);
        }
    }

    /// [`None`] ची अपेक्षा असताना आणि काहीही परत न करता `self` घेते.
    ///
    /// # Panics
    ///
    /// Panics मूल्य [`Some`] असल्यास सानुकूल panic संदेशासह [`Some`] च्या मूल्याद्वारे प्रदान केलेले.
    ///
    ///
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // सर्व झीज अद्वितीय असल्याने हे झेडस्पॅनिक 0 झेड करणार नाही.
    ///     squares.insert(i, i * i).unwrap_none();
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).unwrap_none();
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_unwrap_none", reason = "newly added", issue = "62633")]
    pub fn unwrap_none(self) {
        if let Some(val) = self {
            expect_none_failed("called `Option::unwrap_none()` on a `Some` value", &val);
        }
    }
}

impl<T: Default> Option<T> {
    /// असलेले [`Some`] मूल्य किंवा डीफॉल्ट मिळवते
    ///
    /// नंतर `self` वितर्क घेते, [`Some`] असल्यास, समाविष्ट केलेले मूल्य परत करते, अन्यथा [`None`] असल्यास त्या प्रकारच्या [default value] परत करते.
    ///
    ///
    /// # Examples
    ///
    /// स्ट्रिंगला पूर्णांक मध्ये रूपांतरित करते, खराब-रचलेल्या तारांना 0 मध्ये बदलते (पूर्णांकाचे डीफॉल्ट मूल्य).
    /// [`parse`] चुकात [`None`] परत करून, [`FromStr`] लागू करणार्‍या इतर कोणत्याही प्रकारात स्ट्रिंग रूपांतरित करते.
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().ok().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().ok().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [default value]: Default::default
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Some(x) => x,
            None => Default::default(),
        }
    }
}

impl<T: Deref> Option<T> {
    /// `Option<T>` (किंवा `&Option<T>`) वरून `Option<&T::Target>` मध्ये रूपांतरित करते.
    ///
    /// मूळ पर्याय त्या जागी ठेवतो, मूळच्या संदर्भासह एक नवीन तयार करतो आणि त्याव्यतिरिक्त [`Deref`] द्वारे सामग्रीचा अभ्यास करतो.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref(), Some("hey"));
    ///
    /// let x: Option<String> = None;
    /// assert_eq!(x.as_deref(), None);
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref(&self) -> Option<&T::Target> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut> Option<T> {
    /// `Option<T>` (किंवा `&mut Option<T>`) वरून `Option<&mut T::Target>` मध्ये रूपांतरित करते.
    ///
    /// मूळ `Option` ला त्या जागी ठेवते, आतील प्रकाराच्या `Deref::Target` प्रकाराचा बदल बदलणारा एक नवीन तयार करते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref_mut().map(|x| {
    ///     x.make_ascii_uppercase();
    ///     x
    /// }), Some("HEY".to_owned().as_mut_str()));
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref_mut(&mut self) -> Option<&mut T::Target> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Option<Result<T, E>> {
    /// [`Result`] च्या `Option` ला एक `Option` च्या [`Result`] मध्ये बदलते.
    ///
    /// [`None`] [`Ok`]`(`[`काहीही नाही]]`) pped वर मॅप केले जाईल.
    /// [`काही`]`(`[`Ok`] `(_))` आणि [`काही`]`(`[`एर्रे]`(_))[`Ok`] to (`[` काही`]`(_))`आणि [`एर्रे]`(_)`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x, y.transpose());
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn transpose(self) -> Result<Option<T>, E> {
        match self {
            Some(Ok(x)) => Ok(Some(x)),
            Some(Err(e)) => Err(e),
            None => Ok(None),
        }
    }
}

// हे स्वत: .expect() चे कोड आकार कमी करण्यासाठी स्वतंत्र कार्य आहे.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_failed(msg: &str) -> ! {
    panic!("{}", msg)
}

// हे स्वत: .expect_none() चे कोड आकार कमी करण्यासाठी स्वतंत्र कार्य आहे.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_none_failed(msg: &str, value: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, value)
}

/////////////////////////////////////////////////////////////////////////////
// Trait कार्यान्वयन
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for Option<T> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Some(x) => Some(x.clone()),
            None => None,
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Some(to), Some(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Option<T> {
    /// [`None`][Option::None] मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// let opt: Option<u32> = Option::default();
    /// assert!(opt.is_none());
    /// ```
    #[inline]
    fn default() -> Option<T> {
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for Option<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// संभाव्यत: समाविष्‍ट मूल्यापेक्षा उपभोगणारा इटरेटर परत करतो
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("string");
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert_eq!(v, ["string"]);
    ///
    /// let x = None;
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: Item { opt: self } }
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a Option<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a mut Option<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(since = "1.12.0", feature = "option_from")]
impl<T> From<T> for Option<T> {
    /// नवीन `Some` मध्ये `val` प्रती कॉपी करा.
    ///
    /// # Examples
    ///
    /// ```
    /// let o: Option<u8> = Option::from(67);
    ///
    /// assert_eq!(Some(67), o);
    /// ```
    fn from(val: T) -> Option<T> {
        Some(val)
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a Option<T>> for Option<&'a T> {
    /// `&Option<T>` ते `Option<&T>` मध्ये रूपांतरित करते.
    ///
    /// # Examples
    ///
    /// मूळ जतन करुन `पर्याय <` [`स्ट्रिंग`]`>`ला`पर्याय <`[`usize`] `>` मध्ये रूपांतरित करते.
    /// [`map`] पद्धत मूळ वापरुन `self` आर्ग्युमेंट घेते, म्हणून हे तंत्र प्रथम मूळमधील मूल्याच्या संदर्भासाठी `Option` घेण्यास `as_ref` वापरते.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let s: Option<String> = Some(String::from("Hello, Rustaceans!"));
    /// let o: Option<usize> = Option::from(&s).map(|ss: &String| ss.len());
    ///
    /// println!("Can still print s: {:?}", s);
    ///
    /// assert_eq!(o, Some(18));
    /// ```
    ///
    fn from(o: &'a Option<T>) -> Option<&'a T> {
        o.as_ref()
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a mut Option<T>> for Option<&'a mut T> {
    /// `&mut Option<T>` ते `Option<&mut T>` मध्ये रूपांतरित करते
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = Some(String::from("Hello"));
    /// let o: Option<&mut String> = Option::from(&mut s);
    ///
    /// match o {
    ///     Some(t) => *t = String::from("Hello, Rustaceans!"),
    ///     None => (),
    /// }
    ///
    /// assert_eq!(s, Some(String::from("Hello, Rustaceans!")));
    /// ```
    fn from(o: &'a mut Option<T>) -> Option<&'a mut T> {
        o.as_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// पर्याय आयटर
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
struct Item<A> {
    opt: Option<A>,
}

impl<A> Iterator for Item<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.opt.take()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        match self.opt {
            Some(_) => (1, Some(1)),
            None => (0, Some(0)),
        }
    }
}

impl<A> DoubleEndedIterator for Item<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.opt.take()
    }
}

impl<A> ExactSizeIterator for Item<A> {}
impl<A> FusedIterator for Item<A> {}
unsafe impl<A> TrustedLen for Item<A> {}

/// [`Option`] च्या [`Some`] व्हेरिएंटच्या संदर्भात पुनरावृत्ती करणारा.
///
/// जर एक्स 0 एक्स एक्स एक्स 100 एक्स असेल तर इटरेटरला एक मूल्य मिळेल, अन्यथा काहीही नाही.
///
/// हे `struct` हे [`Option::iter`] फंक्शनद्वारे तयार केले गेले आहे.
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct Iter<'a, A: 'a> {
    inner: Item<&'a A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for Iter<'a, A> {
    type Item = &'a A;

    #[inline]
    fn next(&mut self) -> Option<&'a A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for Iter<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for Iter<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for Iter<'_, A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Clone for Iter<'_, A> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner.clone() }
    }
}

/// [`Option`] च्या [`Some`] व्हेरिएंटच्या बदलण्यायोग्य संदर्भावरील पुनरावृत्ती करणारा.
///
/// जर एक्स 0 एक्स एक्स एक्स 100 एक्स असेल तर इटरेटरला एक मूल्य मिळेल, अन्यथा काहीही नाही.
///
/// हे `struct` हे [`Option::iter_mut`] फंक्शनद्वारे तयार केले गेले आहे.
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, A: 'a> {
    inner: Item<&'a mut A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for IterMut<'a, A> {
    type Item = &'a mut A;

    #[inline]
    fn next(&mut self) -> Option<&'a mut A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for IterMut<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IterMut<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IterMut<'_, A> {}
#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// [`Option`] च्या [`Some`] व्हेरिएंटमधील मूल्यांपेक्षा एक पुनरावृत्तीकर्ता.
///
/// जर एक्स 0 एक्स एक्स एक्स 100 एक्स असेल तर इटरेटरला एक मूल्य मिळेल, अन्यथा काहीही नाही.
///
/// हे `struct` हे [`Option::into_iter`] फंक्शनद्वारे तयार केले गेले आहे.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<A> {
    inner: Item<A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Iterator for IntoIter<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> DoubleEndedIterator for IntoIter<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IntoIter<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IntoIter<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, V: FromIterator<A>> FromIterator<Option<A>> for Option<V> {
    /// [`Iterator`] मध्ये प्रत्येक घटक घेते: जर ते X01 एक्स असेल तर पुढील घटक घेतले जात नाहीत आणि [`None`][Option::None] परत केला जाईल.
    /// [`None`][Option::None] येऊ नये, प्रत्येक [`Option`] च्या मूल्यांचा कंटेनर परत केला जाईल.
    ///
    /// # Examples
    ///
    /// येथे एक उदाहरण आहे जे vector मध्ये प्रत्येक पूर्णांक वाढवते.
    /// आम्ही `add` चे चेक केलेले रूप वापरतो जे गणना केल्यामुळे ओव्हरफ्लो होईल तेव्हा X01 एक्स परत करेल.
    ///
    /// ```
    /// let items = vec![0_u16, 1, 2];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_add(1))
    ///     .collect();
    ///
    /// assert_eq!(res, Some(vec![1, 2, 3]));
    /// ```
    ///
    /// आपण पाहू शकता की हे अपेक्षित, वैध वस्तू परत करेल.
    ///
    /// येथे आणखी एक उदाहरण आहे जे पूर्णाकृतीच्या दुसर्‍या सूचीमधून एक वजा करण्याचा प्रयत्न करते, यावेळी अंडरफ्लोसाठी तपासणी करीत आहे:
    ///
    /// ```
    /// let items = vec![2_u16, 1, 0];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_sub(1))
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// ```
    ///
    /// शेवटचा घटक शून्य असल्याने ते खाली वाहून जाईल.अशाप्रकारे, परिणामी मूल्य `None` आहे.
    ///
    /// मागील उदाहरणात हा फरक आहे, हे दर्शवित आहे की प्रथम `None` नंतर `iter` पासून कोणतेही घटक घेतले नाहीत.
    ///
    /// ```
    /// let items = vec![3_u16, 2, 1, 10];
    ///
    /// let mut shared = 0;
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| { shared += x; x.checked_sub(2) })
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// तिसर्‍या घटकामुळे अंडरफ्लो झाल्यामुळे पुढील कोणतेही घटक घेतले नाहीत, म्हणून `shared` चे अंतिम मूल्य 16 नाही तर 6 (= `3 + 2 + 1`) आहे.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Option<A>>>(iter: I) -> Option<V> {
        // FIXME(#11084): जेव्हा हे कार्यप्रदर्शन बग बंद असेल तेव्हा हे Iterator::scan सह पुनर्स्थित केले जाऊ शकते.
        //

        iter.into_iter().map(|x| x.ok_or(())).collect::<Result<_, _>>().ok()
    }
}

/// X ऑपरेटर (`?`) ला `None` मूल्यावर लागू केल्यापासून त्रुटी प्रकार.
/// आपण आपल्या एरर प्रकारात रूपांतरित करण्यासाठी `x?` (जिथे `x` एक `Option<T>` आहे) परवानगी देऊ इच्छित असाल तर आपण `YourErrorType` साठी `impl From<NoneError>` लागू करू शकता.
///
/// त्या प्रकरणात, `Result<_, YourErrorType>` परत करणार्‍या कार्यामध्ये `x?` एक `None` मूल्याचे `Err` परिणामामध्ये अनुवाद करेल.
#[rustc_diagnostic_item = "none_error"]
#[unstable(feature = "try_trait", issue = "42327")]
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
pub struct NoneError;

#[unstable(feature = "try_trait", issue = "42327")]
impl<T> ops::Try for Option<T> {
    type Ok = T;
    type Error = NoneError;

    #[inline]
    fn into_result(self) -> Result<T, NoneError> {
        self.ok_or(NoneError)
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Some(v)
    }

    #[inline]
    fn from_error(_: NoneError) -> Self {
        None
    }
}

impl<T> Option<Option<T>> {
    /// `Option<Option<T>>` ते `Option<T>` मध्ये रूपांतरित करते
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let x: Option<Option<u32>> = Some(Some(6));
    /// assert_eq!(Some(6), x.flatten());
    ///
    /// let x: Option<Option<u32>> = Some(None);
    /// assert_eq!(None, x.flatten());
    ///
    /// let x: Option<Option<u32>> = None;
    /// assert_eq!(None, x.flatten());
    /// ```
    ///
    /// सपाट होणे एकाच वेळी घरटीचे एक स्तर काढून टाकते:
    ///
    /// ```
    /// let x: Option<Option<Option<u32>>> = Some(Some(Some(6)));
    /// assert_eq!(Some(Some(6)), x.flatten());
    /// assert_eq!(Some(6), x.flatten().flatten());
    /// ```
    #[inline]
    #[stable(feature = "option_flattening", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn flatten(self) -> Option<T> {
        match self {
            Some(inner) => inner,
            None => None,
        }
    }
}