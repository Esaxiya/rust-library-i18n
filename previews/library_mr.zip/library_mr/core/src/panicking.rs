//! लिबकोरसाठी Panic समर्थन
//!
//! कोर लायब्ररी पॅनीकिंगला परिभाषित करू शकत नाही, परंतु हे पॅनिकिंग *घोषित* करते.
//! याचा अर्थ असा होतो की लिबकोरमधील अंतर्गत कार्ये झेडपॅनिक ० झेडला परवानगी आहेत परंतु उपयुक्त होण्यासाठी अपस्ट्रीम झेडक्राईट ० झेडला लिबकोर वापरण्यासाठी पॅनीकिंगची व्याख्या करणे आवश्यक आहे.
//! घाबरून जाण्यासाठी सध्याचा इंटरफेस आहेः
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! ही व्याख्या कोणत्याही सामान्य संदेशासह घाबरून जाण्यास अनुमती देते, परंतु हे `Box<Any>` मूल्यासह अयशस्वी होण्यास अनुमती देत नाही.
//! (`PanicInfo` मध्ये नुकतेच एक `&(dyn Any + Send)` आहे, ज्यासाठी आम्ही `PanicInfo: : अंतर्गत_कंस्ट्रक्टर` मधील डमी मूल्य भरतो.) याचे कारण असे की लिबकोरला वाटप करण्याची परवानगी नाही.
//!
//!
//! या मॉड्यूलमध्ये काही इतर पॅनीकिंग फंक्शन्स आहेत, परंतु कंपाइलरसाठी या आवश्यक लँग आयटम आहेत.सर्व झेडस्पॅनिक्स 0 झेड या एकाच कार्याद्वारे एकत्रित केले गेले आहेत.
//! वास्तविक प्रतीक `#[panic_handler]` विशेषताद्वारे घोषित केले जाते.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// जेव्हा कोणतेही स्वरूपन वापरले जात नाही तेव्हा लिबकोरच्या एक्स 100 एक्स मॅक्रोची अंतर्निहित अंमलबजावणी.
#[cold]
// शक्य तितक्या कॉल साइटवर कोड ब्लोट टाळण्यासाठी पॅनिक_मिडिएट_अबोर्टशिवाय कधीही इनलाइन नका
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // ओव्हरफ्लो आणि इतर एक्स 100 एक्स एमआयआर टर्मिनेटरवर झेडस्पॅनिक 0 झेडसाठी कोडेजेनद्वारे आवश्यक
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // संभाव्यत: आकार ओव्हरहेड कमी करण्यासाठी format_args ऐवजी Arguments::new_v1 वापरा ("{}", expr).
    // स्वरूप_मार्ग!मॅक्रो एक्सप्रेस लिहिण्यासाठी str च्या डिस्प्ले trait चा वापर करते, ज्याला एक्स00 एक्स म्हणतात, ज्याला स्ट्रिंग ट्रंकेशन आणि पॅडिंग (तरीही येथे काहीही वापरलेले नाही) समाविष्ट करणे आवश्यक आहे.
    //
    // Arguments::new_v1 वापरणे कंपाईलरला Formatter::pad आउटपुट बायनरीमधून वगळण्याची परवानगी देऊ शकते, काही किलोबाइट्सची बचत होईल.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // कॉन्स्ट-मूल्यांकन केलेल्या panics साठी आवश्यक
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // OOB array/slice प्रवेशावरील panic साठी कोडेजेनद्वारे आवश्यक
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// स्वरूपन वापरले जाते तेव्हा लिबकोरच्या एक्स 100 एक्स मॅक्रोची अंतर्निहित अंमलबजावणी.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // टीप हे कार्य कधीही एफएफआय सीमा ओलांडत नाही;हा एक Rust-to-Rust कॉल आहे जो `#[panic_handler]` कार्यावर निराकरण करतो.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // सुरक्षितताः `panic_impl` सुरक्षित Rust कोडमध्ये परिभाषित केले आहे आणि अशा प्रकारे कॉल करणे सुरक्षित आहे.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// `assert_eq!` आणि `assert_ne!` मॅक्रोसाठी अंतर्गत कार्य
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}