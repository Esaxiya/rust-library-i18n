//! आळशी मूल्ये आणि स्थिर डेटाची एक-वेळ प्रारंभ.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// एक सेल ज्यावर फक्त एकदाच लिहिता येईल.
///
/// `RefCell` विपरीत, एक `OnceCell` केवळ त्याच्या मूल्याचे सामायिक `&T` संदर्भ प्रदान करते.
/// `Cell` विपरीत, `OnceCell` ला त्यात प्रवेश करण्यासाठी मूल्य कॉपी करणे किंवा त्यास पुनर्स्थित करणे आवश्यक नाही.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // इन्व्हिएंट: एकदाच लिहिलेले
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// एक नवीन रिक्त सेल तयार करते.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// अंतर्निहित मूल्याचा संदर्भ मिळतो.
    ///
    /// सेल रिक्त असल्यास `None` मिळवते.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // सुरक्षितता: `आतील व्यक्तीच्या आक्रमणकर्त्यामुळे सुरक्षित
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// अंतर्निहित मूल्याचा परिवर्तनीय संदर्भ मिळतो.
    ///
    /// सेल रिक्त असल्यास `None` मिळवते.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // सुरक्षितता: सुरक्षित कारण आमच्याकडे अनन्य प्रवेश आहे
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// सेलची सामग्री `value` वर सेट करते.
    ///
    /// # Errors
    ///
    /// सेल रिक्त असल्यास ही पद्धत `Ok(())` आणि भरलेली असल्यास X01 एक्स परत करते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // सुरक्षितता: सुरक्षित कारण आमच्याकडे परस्पर बदल करणार्‍या परस्पर कर्ज असू शकत नाहीत
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // सुरक्षाः ही एकमेव जागा आहे जिथे आम्ही स्लॉट सेट करतो, रेस नाही
        // reentrancy/concurrency मुळे शक्य आहे, आणि आम्ही हे तपासले आहे की स्लॉट सध्या एक्स 100 एक्स आहे, म्हणून हे लिखाण `आतील`चे अनिवार्य राखते.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// सेल रिक्त असल्यास `f` सह प्रारंभ करुन सेलची सामग्री प्राप्त करते.
    ///
    /// # Panics
    ///
    /// `f` panics असल्यास, panic कॉलरवर प्रसारित केला गेला आहे आणि सेल निर्विवाद राहतो.
    ///
    ///
    /// `f` वरून सेलची पुन्हा सुरूवात करण्यात एक त्रुटी आहे.असे केल्याने झेडस्पॅनिक 0 झेड होईल.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// सेल रिक्त असल्यास `f` सह प्रारंभ करुन सेलची सामग्री प्राप्त करते.
    /// सेल रिक्त असल्यास आणि `f` अयशस्वी झाल्यास, एक त्रुटी परत केली जाईल.
    ///
    /// # Panics
    ///
    /// `f` panics असल्यास, panic कॉलरवर प्रसारित केला गेला आहे आणि सेल निर्विवाद राहतो.
    ///
    ///
    /// `f` वरून सेलची पुन्हा सुरूवात करण्यात एक त्रुटी आहे.असे केल्याने झेडस्पॅनिक 0 झेड होईल.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // लक्षात घ्या की *काही* रेंट्रंट इनिशिएलायझेशनच्या प्रकारांमुळे यूबी होऊ शकेल (एक्स 100 एक्स चाचणी पहा).
        // माझा विश्वास आहे की हे `assert` काढून टाकणे, `set/get` ठेवताना आवाज होईल, परंतु जुने मूल्य शांतपणे वापरण्याऐवजी झेडपेनिक0 झेडला ते अधिक चांगले वाटेल.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// लपेटलेले मूल्य परत करून सेल वापरते.
    ///
    /// सेल रिक्त असल्यास `None` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // कारण `into_inner` मूल्यानुसार X01 एक्स घेतो, कंपाईलर सध्या हे कर्ज घेतलेले नाही हे स्थिरपणे सत्यापित करते.
        // म्हणून `Option<T>` बाहेर जाणे सुरक्षित आहे.
        self.inner.into_inner()
    }

    /// या `OnceCell` मधील मूल्य मिळविते, ते परत निर्विवाद अवस्थेमध्ये हलवित आहे.
    ///
    /// कोणताही प्रभाव नाही आणि X01 एक्स आरंभ न केल्यास `None` परत करेल.
    ///
    /// परिवर्तनीय संदर्भ आवश्यक असल्यास सुरक्षिततेची हमी दिली जाते.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// प्रथम प्रवेशास आरंभ केलेले मूल्य.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   तयार सुरू
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// दिलेल्या आरंभिक कार्यासह नवीन आळशी मूल्य तयार करते.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// या आळशी मूल्याचे मूल्यांकन करण्यास भाग पाडते आणि परिणामाचा संदर्भ परत करते.
    ///
    ///
    /// हे `Deref` impl च्या समतुल्य आहे, परंतु ते सुस्पष्ट आहे.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// आरंभिक कार्य म्हणून `Default` वापरून नवीन आळशी मूल्य तयार करते.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}