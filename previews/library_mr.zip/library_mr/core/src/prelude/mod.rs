//! लिबकोर झेडप्रिपेइड 0 झेड
//!
//! हे मॉड्यूल लिबकोरच्या वापरकर्त्यांसाठी आहे जे लिबस्टडीला देखील जोडत नाहीत.
//! हे मॉड्यूल डीफॉल्टनुसार आयात केले जाते जेव्हा मानक लायब्ररीच्या झेडप्रीलोड 0 झेडच्या समान प्रकारे `#![no_std]` वापरले जाते.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// कोर झेडप्रिपेइड 0 झेडची 2015 आवृत्ती.
///
/// अधिकसाठी [module-level documentation](self) पहा.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// कोर झेडप्रिपेइड 0 झेडची 2018 आवृत्ती.
///
/// अधिकसाठी [module-level documentation](self) पहा.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// कोर झेडप्रेस 00 झेडची 2021 आवृत्ती.
///
/// अधिकसाठी [module-level documentation](self) पहा.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: अधिक गोष्टी जोडा.
}