//! मानक लायब्ररीत Panic समर्थन.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// झेडस्पॅनिक0 झेड बद्दल माहिती प्रदान करणारी एक रचना.
///
/// `PanicInfo` संरचना [`set_hook`] फंक्शनद्वारे सेट केलेल्या panic hook वर पुरविली जाते.
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// panic शी संबंधित पेलोड मिळवते.
    ///
    /// हे सहसा, परंतु नेहमीच नाही, `&'static str` किंवा [`String`] असेल.
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// `core` crate मधील `panic!` मॅक्रो (`std` कडून नाही) स्वरूपण स्ट्रिंग आणि काही अतिरिक्त वितर्कांसह वापरल्यास, तो संदेश उदाहरणार्थ [`fmt::write`] सह वापरण्यासाठी तयार आहे
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// जर उपलब्ध असेल तर panic ज्या स्थानापासून उद्भवली त्या स्थानाबद्दल माहिती मिळवते.
    ///
    /// ही पद्धत सध्या [`Some`] परत करेल, परंतु हे झेडफ्यूचर0 झेड आवृत्तीमध्ये बदलू शकते.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: हे कधीकधी परत न केल्यास हे बदलल्यास,
        // std::panicking::default_hook आणि std::panicking::begin_panic_fmt मध्ये त्या प्रकरणाचा सामना करा.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: आम्ही डाउनकास्ट_रेफ: : वापरू शकत नाही<String>() येथे
        // स्ट्रिंग लिबकोरमध्ये उपलब्ध नसल्याने!
        // `std::panic!` ला एकाधिक वितर्कांसह कॉल केले जाते तेव्हा पेलोड एक स्ट्रिंग असते, परंतु त्या प्रकरणात संदेश देखील उपलब्ध असतो.
        //

        self.location.fmt(formatter)
    }
}

/// panic च्या स्थानाबद्दल माहिती असलेली एक रचना.
///
/// ही रचना [`PanicInfo::location()`] द्वारे तयार केली गेली आहे.
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// समानता आणि ऑर्डरची तुलना फाइल, लाइन आणि नंतर स्तंभ प्राधान्याने केली जाते.
/// फायलींची तुलना `Path` नव्हे तर तारांप्रमाणे केली जाते, ती अनपेक्षित असू शकते.
/// अधिक चर्चेसाठी [`स्थान: : फाइल`] चे दस्तऐवजीकरण पहा.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// या फंक्शनच्या कॉलरचे स्त्रोत स्थान मिळवते.
    /// जर त्या फंक्शनचा कॉलर भाष्य केला असेल तर त्याचे कॉल स्थान परत येईल, आणि अशाच प्रकारे ट्रॅक न केलेल्या फंक्शन बॉडीमध्ये पहिल्या कॉलवर स्टॅक अप आहे.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// ज्याला म्हणतात त्या [`Location`] मिळवते.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// या कार्याच्या परिभाषेतून एक [`Location`] मिळवते.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // भिन्न अनक्रॅक केलेले कार्य वेगळ्या ठिकाणी चालविणे आपल्याला समान परिणाम देते
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // ट्रॅक केलेला फंक्शन वेगळ्या ठिकाणी चालविणे भिन्न मूल्य तयार करते
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// स्त्रोत फाईलचे नाव परत करते जिथून panic उगम झाले.
    ///
    /// # `&str`, `&Path` नाही
    ///
    /// परत केलेले नाव कंपाईल सिस्टमवरील स्त्रोताच्या मार्गाचा संदर्भ देते, परंतु हे थेट `&Path` म्हणून प्रतिनिधित्व करणे वैध नाही.
    /// संकलित कोड भिन्न सिस्टमवर सामग्री पाठविणार्‍या सिस्टमपेक्षा भिन्न `Path` कार्यान्वयनसह चालू शकते आणि या लायब्ररीमध्ये सध्या भिन्न "host path" प्रकार नाही.
    ///
    /// सर्वात आश्चर्यकारक वर्तन उद्भवते जेव्हा मॉड्यूल सिस्टममध्ये बहुतेक पथांद्वारे "the same" फाईल पोहोचता येते (सामान्यत: `#[path = "..."]` गुणधर्म किंवा तत्सम वापरुन), ज्यामुळे या कार्यामधून भिन्न मूल्ये परत एकसारखे कोड असल्याचे दिसून येते.
    ///
    ///
    /// # Cross-compilation
    ///
    /// जेव्हा होस्ट प्लॅटफॉर्म आणि लक्ष्य प्लॅटफॉर्म भिन्न असतात तेव्हा हे मूल्य `Path::new` किंवा तत्सम कन्स्ट्रक्टरकडे जाण्यासाठी योग्य नाही.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// panic मूळ असलेला रेखा क्रमांक मिळवते.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// panic मूळ असलेला स्तंभ मिळवते.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// लिबस्टडी कडून एक्स00 एक्स व इतर झेडस्पॅनिक0झेड रनटाइमवर डेटा पास करण्यासाठी लिबस्टडीद्वारे वापरलेला अंतर्गत झेडट्रेट0 झेड.
/// लवकरच कधीही स्थिर होण्याचा हेतू नाही, वापरू नका.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// सामग्रीची पूर्ण मालकी घ्या.
    /// परतीचा प्रकार प्रत्यक्षात `Box<dyn Any + Send>` आहे, परंतु आम्ही लिबकोरमध्ये `Box` वापरू शकत नाही.
    ///
    /// ही पद्धत कॉल केल्यावर, `self` मध्ये फक्त काही डमी डीफॉल्ट मूल्य शिल्लक आहे.
    /// या पद्धतीला दोनदा कॉल करणे किंवा या पद्धतीवर कॉल केल्यावर एक्स00 एक्स वर कॉल करणे ही एक त्रुटी आहे.
    ///
    /// वितर्क कर्ज घेतले आहे कारण झेडस्पॅनिक0 झेड रनटाइम एक्स01 एक्स केवळ कर्ज घेतलेले एक्स 100 एक्स प्राप्त करते.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// फक्त सामग्री उधार घ्या.
    fn get(&mut self) -> &(dyn Any + Send);
}