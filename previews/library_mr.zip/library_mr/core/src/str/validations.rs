//! UTF-8 प्रमाणीकरणाशी संबंधित ऑपरेशन्स.

use crate::mem;

use super::Utf8Error;

/// प्रथम बाइटसाठी प्रारंभिक कोडिपॉईंट संचयीक मिळवते.
/// पहिला बाइट खास आहे, फक्त रुंदी 2 साठी तळाशी 5 बिट पाहिजे, रुंदी 3 साठी 4 बिट आणि रुंदी 4 साठी 3 बिट पाहिजे.
///
#[inline]
fn utf8_first_byte(byte: u8, width: u32) -> u32 {
    (byte & (0x7F >> width)) as u32
}

/// एक्सटेंशन बाइट `byte` सह अद्यतनित केलेले एक्स 0 एक्स एक्सचे मूल्य मिळवते.
#[inline]
fn utf8_acc_cont_byte(ch: u32, byte: u8) -> u32 {
    (ch << 6) | (byte & CONT_MASK) as u32
}

/// बाइट हे UTF-8 कॉन्टिनेशन बाइट आहे की नाही हे तपासते (म्हणजेच, बिट्स X01 एक्स ने प्रारंभ होते).
///
#[inline]
pub(super) fn utf8_is_cont_byte(byte: u8) -> bool {
    (byte & !CONT_MASK) == TAG_CONT_U8
}

#[inline]
fn unwrap_or_0(opt: Option<&u8>) -> u8 {
    match opt {
        Some(&byte) => byte,
        None => 0,
    }
}

/// बाइट आयटरचा पुढील कोड पॉईंट वाचतो (एक यूटीएफ-8 सारखी एन्कोडिंग गृहित धरून).
///
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn next_code_point<'a, I: Iterator<Item = &'a u8>>(bytes: &mut I) -> Option<u32> {
    // डिकोड UTF-8
    let x = *bytes.next()?;
    if x < 128 {
        return Some(x as u32);
    }

    // मल्टिबाइट केस खालील बाइट संयोगामधून डीकोडला अनुसरून: [[[x y] z] w]
    //
    // NOTE: कामगिरी येथे अचूक तयार करण्यासाठी संवेदनशील आहे
    let init = utf8_first_byte(x, 2);
    let y = unwrap_or_0(bytes.next());
    let mut ch = utf8_acc_cont_byte(init, y);
    if x >= 0xE0 {
        // [[x y z] डब्ल्यू] केस
        // 0xE0 मधील 5 वा बिट .. 0xEF नेहमीच स्पष्ट असतो, म्हणून `init` अद्याप वैध आहे
        let z = unwrap_or_0(bytes.next());
        let y_z = utf8_acc_cont_byte((y & CONT_MASK) as u32, z);
        ch = init << 12 | y_z;
        if x >= 0xF0 {
            // [x y z w] केस `init` चे फक्त खालचे 3 बिट्स वापरा
            //
            let w = unwrap_or_0(bytes.next());
            ch = (init & 7) << 18 | utf8_acc_cont_byte(y_z, w);
        }
    }

    Some(ch)
}

/// बाइट इटरेटर (शेवटचा कोड यूटीएफ-8 सारखा एन्कोडिंग गृहित धरून) शेवटचा कोड पॉईंट वाचतो.
///
#[inline]
pub(super) fn next_code_point_reverse<'a, I>(bytes: &mut I) -> Option<u32>
where
    I: DoubleEndedIterator<Item = &'a u8>,
{
    // डिकोड UTF-8
    let w = match *bytes.next_back()? {
        next_byte if next_byte < 128 => return Some(next_byte as u32),
        back_byte => back_byte,
    };

    // मल्टिबाईट प्रकरण खालील बाइट संयोगामधून डीकोडला अनुसरून आहे: [x [y [z w]]]
    //
    let mut ch;
    let z = unwrap_or_0(bytes.next_back());
    ch = utf8_first_byte(z, 2);
    if utf8_is_cont_byte(z) {
        let y = unwrap_or_0(bytes.next_back());
        ch = utf8_first_byte(y, 3);
        if utf8_is_cont_byte(y) {
            let x = unwrap_or_0(bytes.next_back());
            ch = utf8_first_byte(x, 4);
            ch = utf8_acc_cont_byte(ch, y);
        }
        ch = utf8_acc_cont_byte(ch, z);
    }
    ch = utf8_acc_cont_byte(ch, w);

    Some(ch)
}

// वापरात u64 फिट करण्यासाठी ट्रंकेशन वापरा
const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;

/// `x` शब्दामधील कोणतीही बाइट नॉनॅस्सी (>=128) असल्यास `true` मिळवते.
#[inline]
fn contains_nonascii(x: usize) -> bool {
    (x & NONASCII_MASK) != 0
}

/// `v` तपासून हे वैध UTF-8 क्रम आहे, त्या प्रकरणात `Ok(())` परत करते किंवा ते अवैध असल्यास, `Err(err)`.
///
#[inline(always)]
pub(super) fn run_utf8_validation(v: &[u8]) -> Result<(), Utf8Error> {
    let mut index = 0;
    let len = v.len();

    let usize_bytes = mem::size_of::<usize>();
    let ascii_block_size = 2 * usize_bytes;
    let blocks_end = if len >= ascii_block_size { len - ascii_block_size + 1 } else { 0 };
    let align = v.as_ptr().align_offset(usize_bytes);

    while index < len {
        let old_offset = index;
        macro_rules! err {
            ($error_len: expr) => {
                return Err(Utf8Error { valid_up_to: old_offset, error_len: $error_len })
            };
        }

        macro_rules! next {
            () => {{
                index += 1;
                // आम्हाला डेटा आवश्यक होता, परंतु तेथे काहीही नव्हते: त्रुटी!
                if index >= len {
                    err!(None)
                }
                v[index]
            }};
        }

        let first = v[index];
        if first >= 128 {
            let w = UTF8_CHAR_WIDTH[first as usize];
            // 2-बाइट एन्कोडिंग कोडेपॉइंट्स\u {0080} ते\u {07ff} प्रथम C2 80 अंतिम डीएफ बीएफसाठी आहे
            // 3-बाइट एन्कोडिंग कोडेपॉइंट्स\u {0800} ते\u {ffff for प्रथम E0 A0 80 शेवटचे EF BF BF वगळता सरोगेट्स कोडेपॉइंट्स\u {d800} ते\u {dfff} ED A0 80 ते ED BF BF आहे
            // 4-बाइट एन्कोडिंग कोडेपॉइंट्स\u {1000} 0 ते\u {10ff} ff प्रथम F0 90 80 80 अंतिम F4 8F बीएफ बीएफसाठी आहे
            //
            // आरएफसी कडील एक्स 100 एक्स सिंटॅक्स वापरा
            //
            // https://tools.ietf.org/html/rfc3629
            // UTF8-1=% x00-7F UTF8-2=% xC2-DF UTF8-शेपूट UTF8-3= %xE0% xA0-BF UTF8-शेपटी/% xE1-EC 2( UTF8-tail )/%xED% x80-9F UTF8-शेपटी/% xEE-EF 2( UTF8-tail ) UTF8-4= %xF0% x90-BF 2( UTF8-tail )/% xF1-F3 3( UTF8-tail )/%xF4% x80-8F 2( UTF8-tail )
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            match w {
                2 => {
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(1))
                    }
                }
                3 => {
                    match (first, next!()) {
                        (0xE0, 0xA0..=0xBF)
                        | (0xE1..=0xEC, 0x80..=0xBF)
                        | (0xED, 0x80..=0x9F)
                        | (0xEE..=0xEF, 0x80..=0xBF) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                }
                4 => {
                    match (first, next!()) {
                        (0xF0, 0x90..=0xBF) | (0xF1..=0xF3, 0x80..=0xBF) | (0xF4, 0x80..=0x8F) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(3))
                    }
                }
                _ => err!(Some(1)),
            }
            index += 1;
        } else {
            // Ascii केस, द्रुतपणे पुढे जाण्याचा प्रयत्न करा.
            // जेव्हा पॉइंटर संरेखित केले जाते, तेव्हापर्यंत आम्हाला पुनरावृत्ती होईपर्यंत डेटाचे दोन शब्द वाचा, जोपर्यंत आम्हाला नॉन-एस्की बाइट नसलेला शब्द सापडतो.
            //
            if align != usize::MAX && align.wrapping_sub(index) % usize_bytes == 0 {
                let ptr = v.as_ptr();
                while index < blocks_end {
                    // सुरक्षा: `align - index` आणि `ascii_block_size` असल्याने
                    // `usize_bytes`, `block = ptr.add(index)` चे गुणाकार नेहमी `usize` सह संरेखित असतो जेणेकरुन `block` आणि `block.offset(1)` या दोहोंचा अवलोकन करणे सुरक्षित आहे.
                    //
                    //
                    unsafe {
                        let block = ptr.add(index) as *const usize;
                        // नॉनस्की बाईट असल्यास ब्रेक करा
                        let zu = contains_nonascii(*block);
                        let zv = contains_nonascii(*block.offset(1));
                        if zu | zv {
                            break;
                        }
                    }
                    index += ascii_block_size;
                }
                // ज्या ठिकाणी वर्डवाईस लूप थांबला त्या ठिकाणाहून जा
                while index < len && v[index] < 128 {
                    index += 1;
                }
            } else {
                index += 1;
            }
        }
    }

    Ok(())
}

// https://tools.ietf.org/html/rfc3629
static UTF8_CHAR_WIDTH: [u8; 256] = [
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x1F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x3F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x5F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x7F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0x9F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0xBF
    0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, // 0xDF
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, // 0xEF
    4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 0xFF
];

/// प्रथम बाइट दिल्यास या UTF-8 वर्णात किती बाइट आहेत हे निर्धारित करते.
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn utf8_char_width(b: u8) -> usize {
    UTF8_CHAR_WIDTH[b as usize] as usize
}

/// सातत्य बाइटच्या मूल्य बिटचा मुखवटा.
const CONT_MASK: u8 = 0b0011_1111;
/// एक कॉन्टिनेशन बाइटचे टॅग बिट्सचे मूल्य (टॅग मास्क एक्स 100 एक्स आहे).
const TAG_CONT_U8: u8 = 0b1000_0000;

// तो कापला असल्यास `&str` ची लांबी `max` पर्यंत परत करा आणि नवीन तार.
//
pub(super) fn truncate_to_char_boundary(s: &str, mut max: usize) -> (bool, &str) {
    if max >= s.len() {
        (false, s)
    } else {
        while !s.is_char_boundary(max) {
            max -= 1;
        }
        (true, &s[..max])
    }
}