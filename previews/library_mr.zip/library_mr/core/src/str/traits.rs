//! `str` साठी Trait कार्यान्वयन.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// तारांची क्रमवारी लागू करते.
///
/// स्ट्रिंगस त्यांच्या बाइट व्हॅल्यूजद्वारे एक्स00 एक्सची मागणी केली जाते.
/// हे कोड चार्टमध्ये त्यांच्या स्थानाच्या आधारे युनिकोड कोड पॉइंटची ऑर्डर देतात.
/// हे अपरिहार्यपणे "alphabetical" ऑर्डरसारखेच नाही, जे भाषा आणि लोकॅलनुसार बदलते.
/// सांस्कृतिकदृष्ट्या-स्वीकारलेल्या मानकांनुसार तारांची क्रमवारी लावण्यासाठी लोकॅल-विशिष्ट डेटा आवश्यक आहे जो `str` प्रकारच्या क्षेत्राच्या बाहेरील आहे.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// तारांवर तुलना ऑपरेशनची अंमलबजावणी करते.
///
/// स्ट्रिंगची तुलना [lexicographically](Ord#lexicographical-comparison) ने त्यांच्या बाइट मूल्यांद्वारे केली आहे.
/// हे कोड चार्टमध्ये त्यांच्या स्थानांच्या आधारे युनिकोड कोड पॉइंट्सची तुलना करते.
/// हे अपरिहार्यपणे "alphabetical" ऑर्डरसारखेच नाही, जे भाषा आणि लोकॅलनुसार बदलते.
/// सांस्कृतिकदृष्ट्या-स्वीकारलेल्या मानकांनुसार तारांची तुलना करण्यासाठी लोकॅल-विशिष्ट डेटा आवश्यक आहे जो `str` प्रकाराच्या बाहेरील आहे.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// सिंटॅक्स एक्स ०१ एक्स किंवा एक्स X०० एक्स सह स्ट्रिंग स्ट्रिंग स्ट्रिंगची सामग्री.
///
/// संपूर्ण स्ट्रिंगचा एक तुकडा मिळवते, म्हणजे, एक्स 0 एक्स किंवा एक्स 100 एक्स.`आणि सेल्फ [० ..
/// लेन] `किंवा`&स्वत: ची बदल करा [0 ..
/// len]`.
/// इतर अनुक्रमित ऑपरेशन्सप्रमाणेच हे कधीही झेडस्पॅनिक 0 झेड करू शकत नाही.
///
/// हे ऑपरेशन *ओ*(1) आहे.
///
/// 1.20.0 पूर्वी, या अनुक्रमणिका क्रियांना अद्याप `Index` आणि `IndexMut` थेट अंमलबजावणीद्वारे समर्थित केले गेले.
///
/// `&self[0 .. len]` किंवा `&mut self[0 .. len]` च्या समतुल्य.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// सिंटॅक्स एक्स ०१ एक्स किंवा एक्स X०० एक्स सह स्ट्रिंग स्ट्रिंग स्ट्रिंगची सामग्री.
///
/// बाइट श्रेणी [`बिनीग, एक्स00 एक्स) वरून दिलेल्या स्ट्रिंगचा स्लाइस मिळवते.
///
/// हे ऑपरेशन *ओ*(1) आहे.
///
/// 1.20.0 पूर्वी, या अनुक्रमणिका क्रियांना अद्याप `Index` आणि `IndexMut` थेट अंमलबजावणीद्वारे समर्थित केले गेले.
///
/// # Panics
///
/// `begin` किंवा `end` जर `begin > end` किंवा `end > len` असल्यास, एखाद्या अक्षराच्या (प्रारंभिक `is_char_boundary` द्वारे परिभाषित) ऑफसेटकडे निर्देश करीत नसेल तर Panics.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // हे panic करेल:
/// // बाइट 2 एक्स 100 एक्स मध्ये आहे:
/// // &एस [2 ..3];
///
/// // बाइट 8 एक्स 100 एक्स मध्ये&एस [1 ..
/// // 8];
///
/// // बाइट 100 स्ट्रिंगच्या बाहेर आहे [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // सुरक्षितताः नुकतेच तपासले की `start` आणि `end` चार सीमेवर आहेत,
            // आणि आम्ही एका सुरक्षित संदर्भात जात आहोत, तर रिटर्न व्हॅल्यू देखील एक होईल.
            // आम्ही चार सीमाही तपासल्या, म्हणून ही वैध UTF-8 आहे.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // सुरक्षितताः नुकतेच तपासले की `start` आणि `end` चार सीमेवर आहेत.
            // आम्हाला माहित आहे की पॉईंटर अद्वितीय आहे कारण आम्हाला ते `slice` वरून प्राप्त झाले आहे.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // सुरक्षितताः कॉलर हमी देतो की `self` `slice` च्या हद्दीत आहे
        // जे `add` च्या सर्व अटींचे समाधान करते.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // सुरक्षितता: `get_unchecked` साठी टिप्पण्या पहा.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary हे तपासते की अनुक्रमणिका [0, .len()] वर `get` पुन्हा वापरु शकत नाही, कारण एनएलएलच्या अडचणीमुळे
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // सुरक्षितताः नुकतेच तपासले की `start` आणि `end` चार सीमेवर आहेत,
            // आणि आम्ही एका सुरक्षित संदर्भात जात आहोत, तर रिटर्न व्हॅल्यू देखील एक होईल.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// सिंटॅक्स एक्स ०१ एक्स किंवा एक्स X०० एक्स सह स्ट्रिंग स्ट्रिंग स्ट्रिंगची सामग्री.
///
/// बाइट श्रेणी [`0`, `end`) वरून दिलेल्या स्ट्रिंगचा स्लाइस मिळवते.
/// `&self[0 .. end]` किंवा `&mut self[0 .. end]` च्या समतुल्य.
///
/// हे ऑपरेशन *ओ*(1) आहे.
///
/// 1.20.0 पूर्वी, या अनुक्रमणिका क्रियांना अद्याप `Index` आणि `IndexMut` थेट अंमलबजावणीद्वारे समर्थित केले गेले.
///
/// # Panics
///
/// जर `end` वर्णाच्या आरंभिक बाइट ऑफसेटकडे दर्शवित नाही (`is_char_boundary` द्वारे परिभाषित केल्यानुसार), किंवा `end > len` असल्यास.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // सुरक्षितताः नुकतेच तपासले की `end` चार सीमेवर आहे,
            // आणि आम्ही एका सुरक्षित संदर्भात जात आहोत, तर रिटर्न व्हॅल्यू देखील एक होईल.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // सुरक्षितताः नुकतेच तपासले की `end` चार सीमेवर आहे,
            // आणि आम्ही एका सुरक्षित संदर्भात जात आहोत, तर रिटर्न व्हॅल्यू देखील एक होईल.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // सुरक्षितताः नुकतेच तपासले की `end` चार सीमेवर आहे,
            // आणि आम्ही एका सुरक्षित संदर्भात जात आहोत, तर रिटर्न व्हॅल्यू देखील एक होईल.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// सिंटॅक्स एक्स ०१ एक्स किंवा एक्स X०० एक्स सह स्ट्रिंग स्ट्रिंग स्ट्रिंगची सामग्री.
///
/// बाइट श्रेणी [`बिनीग, एक्स00 एक्स) वरून दिलेल्या स्ट्रिंगचा स्लाइस मिळवते.Iv आणि सेल्फ [समारंभात समान]
/// लेन] `किंवा`&स्वत: ची बदल [सुरू करा ..
/// len]`.
///
/// हे ऑपरेशन *ओ*(1) आहे.
///
/// 1.20.0 पूर्वी, या अनुक्रमणिका क्रियांना अद्याप `Index` आणि `IndexMut` थेट अंमलबजावणीद्वारे समर्थित केले गेले.
///
/// # Panics
///
/// जर `begin` वर्णाच्या आरंभिक बाइट ऑफसेटकडे दर्शवित नाही (`is_char_boundary` द्वारे परिभाषित केल्यानुसार), किंवा `begin > len` असल्यास.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // सुरक्षितताः नुकतेच तपासले की `start` चार सीमेवर आहे,
            // आणि आम्ही एका सुरक्षित संदर्भात जात आहोत, तर रिटर्न व्हॅल्यू देखील एक होईल.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // सुरक्षितताः नुकतेच तपासले की `start` चार सीमेवर आहे,
            // आणि आम्ही एका सुरक्षित संदर्भात जात आहोत, तर रिटर्न व्हॅल्यू देखील एक होईल.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // सुरक्षितताः कॉलर हमी देतो की `self` `slice` च्या हद्दीत आहे
        // जे `add` च्या सर्व अटींचे समाधान करते.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // सुरक्षितता: `get_unchecked` प्रमाणेच.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // सुरक्षितताः नुकतेच तपासले की `start` चार सीमेवर आहे,
            // आणि आम्ही एका सुरक्षित संदर्भात जात आहोत, तर रिटर्न व्हॅल्यू देखील एक होईल.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// सिंटॅक्स एक्स ०१ एक्स किंवा एक्स X०० एक्स सह स्ट्रिंग स्ट्रिंग स्ट्रिंगची सामग्री.
///
/// [`begin`, `end`] बाइट श्रेणीतून दिलेल्या स्ट्रिंगचा एक स्लाईस मिळवते.`end` चे `usize` चे जास्तीत जास्त मूल्य असल्यास, `&self [begin .. end + 1]` किंवा `&mut self[begin .. end + 1]` च्या समतुल्य आहे.
///
/// हे ऑपरेशन *ओ*(1) आहे.
///
/// # Panics
///
/// `begin` एखाद्या वर्णातील प्रारंभिक बाइट ऑफसेट (`is_char_boundary` द्वारे परिभाषित केल्यानुसार) दर्शवित नसल्यास झेडपॅनिक्स 0 झेड, जर एक्स 0 एक्स एक्स एक्स 1 एक्स एक्स 1 एक्स बाईज ऑफसेट किंवा एक्स 06 एक्सच्या समान असेल तर किंवा `end >= len` असल्यास.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // सुरक्षितता: कॉलरने `get_unchecked` साठी सुरक्षितता करार पाळला पाहिजे.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // सुरक्षितता: कॉलरने `get_unchecked_mut` साठी सुरक्षितता करार पाळला पाहिजे.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// सिंटॅक्स एक्स ०१ एक्स किंवा एक्स X०० एक्स सह स्ट्रिंग स्ट्रिंग स्ट्रिंगची सामग्री.
///
/// एक्स बाईस श्रेणी [0, `end`] वरून दिलेल्या स्ट्रिंगचा स्लाइस मिळवते.
/// `&self [0 .. end + 1]` च्या समतुल्य, `end` चे `usize` चे अधिकतम मूल्य असल्यास.
///
/// हे ऑपरेशन *ओ*(1) आहे.
///
/// # Panics
///
/// जर `end` एखाद्या अक्षराच्या शेवटच्या बाइट ऑफसेटकडे निर्देश करीत नसेल तर (`end + 1` एकतर `is_char_boundary` नुसार परिभाषित केलेल्या प्रारंभिक बाइट ऑफसेट आहे किंवा `len` बरोबर आहे) किंवा `end >= len` असल्यास.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // सुरक्षितता: कॉलरने `get_unchecked` साठी सुरक्षितता करार पाळला पाहिजे.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // सुरक्षितता: कॉलरने `get_unchecked_mut` साठी सुरक्षितता करार पाळला पाहिजे.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// स्ट्रिंगमधून मूल्याचे विश्लेषण करा
///
/// `थ्रीस्ट्राची [`from_str`] पद्धत बर्‍याचदा [` str`] च्या [`parse`] पद्धतीने, अप्रत्यक्षपणे वापरली जाते.
/// उदाहरणांसाठी [ars पार्सी] चे दस्तऐवजीकरण पहा.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` आजीवन पॅरामीटर नसते आणि म्हणूनच आपण केवळ असे प्रकार विश्लेषित करू शकता ज्यात आजीवन पॅरामीटर स्वतःच नसतो.
///
/// दुसर्‍या शब्दांत, आपण `FromStr` सह `i32` विश्लेषित करू शकता, परंतु एक्स 100 एक्स नाही.
/// आपण `i32` असणार्‍या एका संरचनेचे विश्लेषण करू शकता, परंतु यात एक `&i32` नसलेले एक नाही.
///
/// # Examples
///
/// `Point` प्रकारावर `FromStr` चे मूलभूत अंमलबजावणीः
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// संबंधित त्रुटी जी पार्सिंगमधून परत येऊ शकते.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// या प्रकाराचे मूल्य मिळविण्यासाठी स्ट्रिंग `s` विश्लेषित करते.
    ///
    /// विश्लेषित करणे यशस्वी झाल्यास, [`Ok`] मधील मूल्य परत करा, अन्यथा जेव्हा स्ट्रिंग चुकीचे स्वरूपित केली जाते तेव्हा आतल्या [`Err`] ला विशिष्ट त्रुटी परत करते.
    /// एरर प्रकार trait च्या अंमलबजावणीसाठी विशिष्ट आहे.
    ///
    /// # Examples
    ///
    /// [`i32`] सह मूळ वापर, `FromStr` लागू करणारा प्रकारः
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// स्ट्रिंगमधून `bool` विश्लेषित करा.
    ///
    /// `Result<bool, ParseBoolError>` चे उत्पन्न देते, कारण X01 एक्स प्रत्यक्षात विश्लेषण करणे योग्य किंवा नसू शकते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// लक्षात ठेवा, बर्‍याच प्रकरणांमध्ये, `str` वरील `.parse()` पद्धत अधिक योग्य आहे.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}