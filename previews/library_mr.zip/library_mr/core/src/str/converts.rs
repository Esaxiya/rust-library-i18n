//! बाइट स्लाइसमधून एक्स 100 एक्स तयार करण्याचे मार्ग.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// बाइट्सचा तुकडा स्ट्रिंग स्लाइसमध्ये रूपांतरित करते.
///
/// एक स्ट्रिंग स्लाइस X01 एक्स बाइट एक्स 100 एक्सपासून बनविलेले आहे, आणि बाइट स्लाइस एक्स 0 2 एक्स बाइट्सपासून बनलेले आहे, म्हणून हे फंक्शन दोघांमध्ये रूपांतरित होते.
/// सर्व बाइट स्लाइस वैध स्ट्रिंग स्लाइस नसतात, तथापिः [`&str`] ला वैध UTF-8 असणे आवश्यक असते.
/// `from_utf8()` बाइट्स वैध UTF-8 आहेत हे सुनिश्चित करण्यासाठी तपासणी करते आणि नंतर ते रूपांतरण करतात.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// जर आपल्याला खात्री असेल की बाइट स्लाईस वैध UTF-8 आहे आणि आपल्याला वैधता तपासणीचे ओव्हरहेड खर्च करायचे नाहीत तर या फंक्शनची एक असुरक्षित आवृत्ती आहे [`from_utf8_unchecked`], ज्याचे समान वर्तन आहे परंतु चेक वगळले आहे.
///
///
/// आपल्याला `&str` ऐवजी `String` आवश्यक असल्यास, [`String::from_utf8`][string] चा विचार करा.
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// आपण एक `[u8; N]` स्टॅक-वाटप करू शकता आणि आपण त्यापैकी [`&[u8]`][byteslice] घेऊ शकता, हे कार्य स्टॅक-वाटप केलेली स्ट्रिंग आहे.खाली उदाहरणे विभागात त्याचं उदाहरण आहे.
///
/// [byteslice]: slice
///
/// # Errors
///
/// प्रदान केलेली स्लाइस UTF-8 का नाही यासह वर्णन असलेले स्लाइस UTF-8 नसल्यास `Err` मिळवते.
///
/// # Examples
///
/// मूलभूत वापर:
///
/// ```
/// use std::str;
///
/// // vector मध्ये काही बाइट
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // आम्हाला माहित आहे की हे बाइट वैध आहेत, म्हणून केवळ `unwrap()` वापरा.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// चुकीचे बाइट:
///
/// ```
/// use std::str;
///
/// // vector मध्ये काही अवैध बाइट
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// परत येऊ शकणार्‍या त्रुटींच्या अधिक तपशीलांसाठी [`Utf8Error`] चे दस्तऐवज पहा.
///
/// एक "stack allocated string":
///
/// ```
/// use std::str;
///
/// // काही बाइट्स, स्टॅक-वाटप केलेल्या अ‍ॅरेमध्ये
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // आम्हाला माहित आहे की हे बाइट वैध आहेत, म्हणून केवळ `unwrap()` वापरा.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // सुरक्षा: नुकतीच चाललेली वैधता.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// बाइट्सच्या म्युटेबल स्लाइसला रूपांतरित स्ट्रिंग स्लाइसमध्ये रूपांतरित करते.
///
/// # Examples
///
/// मूलभूत वापर:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" एक परिवर्तनीय vector म्हणून
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // आम्हाला माहित आहे की हे बाइट वैध आहेत, आम्ही `unwrap()` वापरू शकतो
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// चुकीचे बाइट:
///
/// ```
/// use std::str;
///
/// // बदलण्यायोग्य vector मध्ये काही अवैध बाइट
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// परत येऊ शकणार्‍या त्रुटींच्या अधिक तपशीलांसाठी [`Utf8Error`] चे दस्तऐवज पहा.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // सुरक्षा: नुकतीच चाललेली वैधता.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// बाइटच्या तुकड्यात स्ट्रिंगमध्ये वैध UTF-8 आहे याची तपासणी न करता स्ट्रिंगच्या स्लाइसमध्ये रूपांतरित करते.
///
/// अधिक माहितीसाठी, सुरक्षित आवृत्ती, [`from_utf8`] पहा.
///
/// # Safety
///
/// हे कार्य असुरक्षित आहे कारण ते त्यात पार केलेले बाइट वैध UTF-8 आहेत हे तपासत नाही.
/// जर या मर्यादेचे उल्लंघन केले तर अपरिभाषित वर्तनाचा परिणाम होईल, कारण उर्वरित झेड रस्ट0झेड असे मानते की [`&str`] s वैध UTF-8 आहेत.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// मूलभूत वापर:
///
/// ```
/// use std::str;
///
/// // vector मध्ये काही बाइट
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // सुरक्षितता: कॉलरने हमी देणे आवश्यक आहे की बाइट्स X01 एक्स वैध UTF-8 आहेत.
    // तसेच समान लेआउट असणार्‍या `&str` आणि `&[u8]` वर देखील अवलंबून आहे.
    unsafe { mem::transmute(v) }
}

/// बाइटच्या तुकड्याला स्ट्रिंगमध्ये स्लोइसमध्ये रुपांतरित करते स्ट्रिंगमध्ये वैध UTF-8 आहे;परिवर्तनीय आवृत्ती.
///
///
/// अधिक माहितीसाठी अपरिवर्तनीय आवृत्ती, [`from_utf8_unchecked()`] पहा.
///
/// # Examples
///
/// मूलभूत वापर:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // सुरक्षितता: कॉलरने हमी देणे आवश्यक आहे की बाइट्स `v`
    // वैध UTF-8 आहेत, अशा प्रकारे `*mut str` वर कास्ट सुरक्षित आहे.
    // तसेच, पॉइंटर डीरेफरेन्स सुरक्षित आहे कारण तो पॉइंटर एखाद्या संदर्भात आला आहे जो लेखनास वैध असल्याची हमी दिलेला आहे.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}