//! स्ट्रिंग पैटर्न API.
//!
//! स्ट्रिंगद्वारे शोधताना पॅटर्न एपीआय भिन्न नमुना प्रकारांचा वापर करण्यासाठी एक सामान्य प्रणाली प्रदान करते.
//!
//! अधिक तपशीलांसाठी, traits [`Pattern`], [`Searcher`], [`ReverseSearcher`] आणि [`DoubleEndedSearcher`] पहा.
//!
//! जरी हे एपीआय अस्थिर आहे, तरी हे एक्सपीएक्स एक्स प्रकारच्या स्थिर एपीआयद्वारे उघड केले गेले आहे.
//!
//! # Examples
//!
//! [`Pattern`] [`&str`][`str`], [`char`], [`char`] चे तुकडे आणि एक्स 100 एक्स लागू करणार्‍या कार्ये आणि क्लोजरसाठी स्थिर एपीआय मध्ये एक्स 04 एक्स आहे.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // चार नमुना
//! assert_eq!(s.find('n'), Some(2));
//! // चारस नमुना चा तुकडा
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // बंद नमुना
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// एक स्ट्रिंग नमुना.
///
/// एक `Pattern<'a>` व्यक्त करतो की अंमलबजावणीचा प्रकार [`&'a str`][str] मध्ये शोधण्यासाठी स्ट्रिंग नमुना म्हणून वापरला जाऊ शकतो.
///
/// उदाहरणार्थ, `'a'` आणि `"aa"` हे दोन्ही नमुने आहेत जे एक्स 100 एक्स मधील अनुक्रमणिका `1` वर जुळतील.
///
/// trait स्वतःच संबंधित [`Searcher`] प्रकारासाठी बिल्डर म्हणून कार्य करते, जे स्ट्रिंगमधील पॅटर्नच्या घटना शोधण्याचे वास्तविक कार्य करते.
///
///
/// पॅटर्नच्या प्रकारानुसार, [`str::find`] आणि [`str::contains`] सारख्या पद्धतींचे वर्तन बदलू शकते.
/// खाली दिलेल्या तक्त्यात अशा काही वर्तनांचे वर्णन केले आहे.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// या धर्तीसाठी संबद्ध शोधकर्ता
    type Searcher: Searcher<'a>;

    /// शोधण्यासाठी `self` आणि `haystack` वरून संबंधित शोधकर्ता तयार करते.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// गवंडीच्या चौकटीत कोठेही नमुना जुळतो की नाही हे तपासते
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// गवतच्या पुढील भागाशी नमुना जुळतो की नाही ते तपासते
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// गवतच्या मागील बाजूस नमुना जुळत आहे की नाही ते तपासते
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// जर तो जुळत असेल तर गवतकाच्या पुढील भागातून नमुना काढून टाकते.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // सुरक्षितता: `Searcher` वैध सूचकांक परत करण्यासाठी ज्ञात आहे.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// हे जुळत असल्यास गवतच्या मागील भागापासून नमुना काढून टाकते.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // सुरक्षितता: `Searcher` वैध सूचकांक परत करण्यासाठी ज्ञात आहे.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// [`Searcher::next()`] किंवा [`ReverseSearcher::next_back()`] वर कॉल करण्याचा निकाल.
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// एक्सप्रेसएक्सची जुळणी `haystack[a..b]` वर आढळली की व्यक्त करते.
    ///
    Match(usize, usize),
    /// व्यक्त करते की नमुनाचा संभाव्य सामना म्हणून `haystack[a..b]` नाकारले गेले आहे.
    ///
    /// लक्षात घ्या की दोन `सामना दरम्यान एकापेक्षा जास्त `Reject` असू शकतात, त्यांना एकामध्ये एकत्र करण्याची आवश्यकता नाही.
    ///
    ///
    Reject(usize, usize),
    /// व्यक्त करतो की गवतच्या प्रत्येक बाईटला भेट दिली गेली आहे आणि पुनरावृत्ती संपेल.
    ///
    Done,
}

/// स्ट्रिंग पॅटर्नचा शोधकर्ता.
///
/// हे झेडट्रायट0झेड स्ट्रिंगच्या पुढील (left) पासून सुरू होणार्‍या नमुनाच्या नॉन-आच्छादित सामने शोधण्यासाठी पद्धती प्रदान करते.
///
/// हे [`Pattern`] trait संबंधित `Searcher` प्रकारांद्वारे अंमलात आणले जाईल.
///
/// झेडट्रायट0 झेड असुरक्षित म्हणून चिन्हांकित केले आहे कारण एक्स 100 एक्स पद्धतीद्वारे परत आलेल्या निर्देशांकास गवत गळतीतील वैध utf8 सीमांवर खोटे बोलणे आवश्यक आहे.
/// हे या झेडट्रायट0 झेडच्या ग्राहकांना अतिरिक्त रनटाइम तपासणीशिवाय गवत कापण्यासाठी सक्षम करते.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// मध्ये शोधल्या जाणार्‍या मूळ स्ट्रिंगसाठी Getter
    ///
    /// नेहमी समान [`&str`][str] परत करेल.
    fn haystack(&self) -> &'a str;

    /// समोरपासून प्रारंभ होणारी पुढील शोध चरण पार पाडते.
    ///
    /// - `haystack[a..b]` नमुन्याशी जुळल्यास [`Match(a, b)`][SearchStep::Match] मिळवते.
    /// - `haystack[a..b]` आंशिकपणे, नमुनाशी जुळत नसल्यास [`Reject(a, b)`][SearchStep::Reject] परत करते.
    /// - गवतच्या प्रत्येक बाईटला भेट दिली असल्यास [`Done`][SearchStep::Done] मिळवते.
    ///
    /// [`Match`][SearchStep::Match] X पर्यंतच्या [`Match`][SearchStep::Match] आणि [`Reject`][SearchStep::Reject] मूल्यांच्या प्रवाहामध्ये निर्देशांक श्रेणी आहेत ज्या जवळच्या, नॉन-आच्छादित, संपूर्ण गवत लपेटून आणि utf8 सीमांवर घालतात.
    ///
    ///
    /// [`Match`][SearchStep::Match] निकालामध्ये संपूर्ण जुळलेला नमुना असणे आवश्यक आहे, तथापि [`Reject`][SearchStep::Reject] परिणाम अनियंत्रित ब many्याच जवळच्या तुकड्यांमध्ये विभाजित केले जाऊ शकतात.दोन्ही श्रेणींची लांबी शून्य असू शकते.
    ///
    /// उदाहरणार्थ, एक्स 800 एक्स आणि गवत हे `"cbaaaaab"` नमुना प्रवाह निर्माण करू शकेल
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// पुढील [`Match`][SearchStep::Match] निकाल शोधतो.[`next()`][Searcher::next] पहा.
    ///
    /// [`next()`][Searcher::next] विपरीत, याची आणि [`next_reject`][Searcher::next_reject] ची परत केलेली श्रेणी ओव्हरलॅप होईल याची शाश्वती नाही.
    /// हे एक्स00 एक्स परत करेल, जिथे प्रारंभ_मॅच सामना सुरु होईल तेथील अनुक्रमणिका आहे, आणि एंड_मॅच सामना संपल्यानंतर अनुक्रमणिका आहे.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// पुढील [`Reject`][SearchStep::Reject] निकाल शोधतो.[`next()`][Searcher::next] आणि [`next_match()`][Searcher::next_match] पहा.
    ///
    /// [`next()`][Searcher::next] विपरीत, याची आणि [`next_match`][Searcher::next_match] ची परत केलेली श्रेणी ओव्हरलॅप होईल याची शाश्वती नाही.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// स्ट्रिंग पॅटर्नसाठी एक उलट शोधकर्ता.
///
/// हे झेडट्रायट0झेड स्ट्रिंगच्या मागील (right) पासून सुरू होणार्‍या नमुनाच्या नॉन-आच्छादित सामने शोधण्यासाठी पद्धती प्रदान करते.
///
/// नमुना मागून शोध घेतल्यास त्यास एक्स0 एक्स एक्स झेडट्रायट0झेडच्या संबंधित [`Searcher`] प्रकारांद्वारे लागू केले जाईल.
///
///
/// या झेडट्रायट 0 झेडद्वारे परत आलेल्या निर्देशांक श्रेणीस उलट्या पुढील शोधाशी जुळत नाही.
///
/// या trait असुरक्षित म्हणून चिन्हांकित का कारणास्तव, त्यांचे पालक trait [`Searcher`] पहा.
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// मागील पासून प्रारंभ होणारी पुढील शोध चरण पार पाडते.
    ///
    /// - `haystack[a..b]` नमुन्याशी जुळल्यास [`Match(a, b)`][SearchStep::Match] मिळवते.
    /// - `haystack[a..b]` आंशिकपणे, नमुनाशी जुळत नसल्यास [`Reject(a, b)`][SearchStep::Reject] परत करते.
    /// - गवतच्या प्रत्येक बाईटला भेट दिली असल्यास [`Done`][SearchStep::Done] मिळवते
    ///
    /// [`Match`][SearchStep::Match] X पर्यंतच्या [`Match`][SearchStep::Match] आणि [`Reject`][SearchStep::Reject] मूल्यांच्या प्रवाहामध्ये निर्देशांक श्रेणी आहेत ज्या जवळच्या, नॉन-आच्छादित, संपूर्ण गवत लपेटून आणि utf8 सीमांवर घालतात.
    ///
    ///
    /// [`Match`][SearchStep::Match] निकालामध्ये संपूर्ण जुळलेला नमुना असणे आवश्यक आहे, तथापि [`Reject`][SearchStep::Reject] परिणाम अनियंत्रित ब many्याच जवळच्या तुकड्यांमध्ये विभाजित केले जाऊ शकतात.दोन्ही श्रेणींची लांबी शून्य असू शकते.
    ///
    /// उदाहरण म्हणून, `"aaa"` आणि गवतच्या `"cbaaaaab"` नमुना `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// पुढील [`Match`][SearchStep::Match] निकाल शोधतो.
    /// [`next_back()`][ReverseSearcher::next_back] पहा.
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// पुढील [`Reject`][SearchStep::Reject] निकाल शोधतो.
    /// [`next_back()`][ReverseSearcher::next_back] पहा.
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// [`DoubleEndedIterator`] अंमलबजावणीसाठी [`ReverseSearcher`] चा वापर केला जाऊ शकतो हे व्यक्त करण्यासाठी मार्कर trait
///
/// यासाठी, [`Searcher`] आणि [`ReverseSearcher`] च्या आव्हानाने या अटींचे अनुसरण करणे आवश्यक आहे:
///
/// - `next()` चे सर्व परिणाम उलट क्रमाने `next_back()` च्या निकालांसारखे असले पाहिजेत.
/// - `next()` आणि `next_back()` ला मूल्यांच्या श्रेणीच्या दोन टोकांप्रमाणे वागण्याची आवश्यकता आहे, ते म्हणजे ते X00 एक्स करू शकत नाहीत.
///
/// # Examples
///
/// `char::Searcher` हे X00 एक्स आहे कारण [`char`] शोधण्यासाठी फक्त एकाच वेळी एक शोधणे आवश्यक आहे, जे दोन्ही बाजूंनी समान वागते.
///
/// `(&str)::Searcher` हे `DoubleEndedSearcher` नाही कारण हेसस्टेक `"aaa"` मधील नमुना `"[aa]a"` एकतर `"[aa]a"` किंवा `"a[aa]"` म्हणून जुळत आहे, ज्याचा शोध घेत असलेल्या बाजूला आहे.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// चारसाठी उत्तेजन द्या
/////////////////////////////////////////////////////////////////////////////

/// `<char as Pattern<'a>>::Searcher` साठी संबंधित प्रकार
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // सुरक्षा इन्व्हिएंट: एक्स ० एक्स एक्स ०२ एक्सचा वैध utf8 बाइट इंडेक्स असणे आवश्यक आहे. हा चोरट्या * नेक्स्ट_मॅच आणि नेक्स्ट_मॅच_बॅकमध्ये मोडला जाऊ शकतो, तथापि त्यांनी वैध कोड बिंदूच्या सीमांवर बोटांनी बाहेर पडायला हवे.
    //
    //
    /// `finger` अग्रेषित शोधाची सध्याची बाईट अनुक्रमणिका आहे.
    /// कल्पना करा की ते आपल्या निर्देशांकातील बाइटच्या आधी अस्तित्त्वात आहे
    /// `haystack[finger]` पुढील शोध दरम्यान आम्ही तपासणी करणे आवश्यक असलेल्या स्लाईसची पहिली बाइट आहे
    ///
    finger: usize,
    /// `finger_back` उलट शोधाची वर्तमान बाईट अनुक्रमणिका आहे.
    /// कल्पना करा की ते आपल्या अनुक्रमणिकेवरील बाइट नंतर अस्तित्वात आहे, म्हणजे
    /// अगोदर निर्देश केलेल्या बाबीसंबंधी बोलताना गवत (फिंगरबॅक, १] फॉरवर्ड सर्चिंग दरम्यान आपण तपासणी करणे आवश्यक असलेल्या स्लाइसची शेवटची बाईट आहे (आणि अशा प्रकारे next_back()) वर कॉल करताना तपासणी केली जाणारी पहिली बाइट.
    ///
    finger_back: usize,
    /// पात्र शोधले जात आहे
    needle: char,

    // सुरक्षा इन्व्हिएंट: `utf8_size` 5 पेक्षा कमी असणे आवश्यक आहे
    /// utf8 मध्ये एन्कोड केलेले असताना बाइट्स `needle` घेते.
    utf8_size: usize,
    /// `needle` ची एक utf8 एन्कोड प्रत
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // सुरक्षितता: एक्स-एक्स एक्स ची सुरक्षा हमी 1-4
        // 1. `self.finger` आणि एक्स00 एक्स हे युनिकोडच्या सीमांवर ठेवले आहे (हे चंचल आहे)
        // 2. `self.finger >= 0` कारण 0 पासून सुरू होते आणि केवळ वाढते
        // 3. `self.finger < self.finger_back` कारण अन्यथा चार्ट `iter` `SearchStep::Done` परत करेल
        // 4.
        // `self.finger` हे गवत उगवण्यापूर्वी येते कारण `self.finger_back` शेवटी सुरू होते आणि फक्त कमी होते
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // utf-8 म्हणून री-एन्कोडिंगशिवाय वर्तमान वर्णांचे ऑफसेट जोडा
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // शेवटचे पात्र सापडल्यानंतर गवत बनवा
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // utf8 एन्कोडेड सुई सेफ्टीची शेवटची बाईट: आमच्याकडे एक अनिएन्टर आहे जो एक्स 100 एक्स
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // नवीन बोट आम्हाला सापडलेल्या बाइटची अनुक्रमणिका आहे, तसेच एक, कारण आम्ही वर्णातील शेवटच्या बाइटसाठी मेमच्र केले होते.
                //
                // लक्षात घ्या की हे आम्हाला नेहमी UTF8 सीमेवर बोट देत नाही.
                // जर आम्हाला आमचे पात्र * सापडले नाही तर आम्ही कदाचित 3-बाइट किंवा 4-बाइट वर्णाच्या नॉन-लाइट बाइटची अनुक्रमित केली आहे.
                // आम्ही फक्त पुढील वैध प्रारंभिक बाइट वगळू शकत नाही कारण ꁁ (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` सारखे वर्ण तृतीय शोधताना आम्हाला नेहमीच दुसरा बाइट सापडेल.
                //
                //
                // तथापि, हे पूर्णपणे ठीक आहे.
                // आपल्याकडे self.finger UTF8 सीमेवरील आक्रमणकर्ता आहे, परंतु या आक्रमणकर्त्यावर या पद्धतीत अवलंबून राहणार नाही (यावर अवलंबून आहे CharSearcher::next()).
                //
                // जेव्हा आम्ही स्ट्रिंगच्या शेवटी पोहोचतो किंवा आपल्याला काही आढळल्यास आम्ही केवळ ही पद्धत सोडतो.जेव्हा आम्हाला काही सापडते तेव्हा `finger` UTF8 सीमेवर सेट केले जाईल.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // काहीही सापडले नाही, बाहेर पडा
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // Next_reject शोधकर्ता trait वरून डीफॉल्ट अंमलबजावणी वापरू द्या
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // सुरक्षितता: वरील next() ची टिप्पणी पहा
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // utf-8 म्हणून री-एन्कोडिंग न करता वर्तमान वर्णांचे ऑफसेट वजाबाकी करा
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // गवत उगवते पण शोधलेल्या शेवटच्या अक्षराचा समावेश नाही
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // utf8 एन्कोडेड सुई सेफ्टीची शेवटची बाईट: आमच्याकडे एक अनिएन्टर आहे जो एक्स 100 एक्स
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // आम्ही एक स्लाईस शोधली जी self.finger ने ऑफसेट केली होती, मूळ अनुक्रमणिका पुन्हा मिळविण्यासाठी self.finger जोडा
                //
                let index = self.finger + index;
                // मेमरचर आम्हाला शोधू इच्छित बाइटची अनुक्रमणिका परत करेल.
                // एएससीआयआय कॅरेक्टरच्या बाबतीत, आम्ही खरोखरच आपली नवीन बोट ("after" रिव्हर्स इटीरेशनच्या प्रतिमानात सापडलेला चार्ट) बनवू इच्छितो.
                //
                // मल्टीबाइट चरांसाठी आम्हाला एएससीआयआयपेक्षा अधिक बाइट्सची संख्या सोडली पाहिजे
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // वर्ण सापडण्यापूर्वी बोट वर हलवा (उदा. त्याच्या प्रारंभ निर्देशांकात)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // आम्ही येथे फिंगरबॅक=अनुक्रमणिका, आकार +1 वापरू शकत नाही.
                // आम्हाला भिन्न-आकाराचे वर्ण (किंवा भिन्न वर्णातील मध्यम बाइट) चे शेवटचे चार्ट आढळल्यास आम्हाला बोट_बॅकला `index` पर्यंत खाली धक्का देणे आवश्यक आहे.
                // यामुळे `finger_back` ला आता सीमेवर राहण्याची क्षमता नसते, परंतु हे फक्त ठीक आहे कारण आम्ही केवळ हे कार्य सीमेवरील बाहेर पडतो किंवा जेव्हा हे गवत पूर्णपणे शोधले गेले आहे.
                //
                //
                // पुढच्या_मॅचच्या विपरीत यामध्ये utf-8 मध्ये पुनरावृत्ती बाइटची समस्या उद्भवत नाही कारण आम्ही शेवटचा बाइट शोधत आहोत आणि उलट शोधताना आम्हाला फक्त शेवटचा बाइट सापडला आहे.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // काहीही सापडले नाही, बाहेर पडा
                return None;
            }
        }
    }

    // Next_reject_back शोधकर्ता trait वरून डीफॉल्ट अंमलबजावणी वापरू द्या
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// दिलेल्या [`char`] च्या बरोबरीच्या वर्णांसाठी शोध.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// एकाधिक-चारीक रॅपरसाठी इम्प्ली करा
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // सध्याच्या चार्टची लांबी शोधण्यासाठी अंतर्गत बाइट स्लाइस पुनरावृत्ती करणार्‍याच्या लांबीची तुलना करा
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // सध्याच्या चार्टची लांबी शोधण्यासाठी अंतर्गत बाइट स्लाइस पुनरावृत्ती करणार्‍याच्या लांबीची तुलना करा
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// &[चार] साठी अर्ज करा
/////////////////////////////////////////////////////////////////////////////

// Todo: अर्थात अस्पष्टतेमुळे बदला/काढा.

/// `<&[char] as Pattern<'a>>::Searcher` साठी संबंधित प्रकार
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// स्लाइसमधील कोणत्याही [`चार्ट] च्या बरोबरी असलेल्या चरांसाठी शोध.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// एफ साठी एक्सप्लोर करा: FnMut(char)-> झेडबूल0 झेड
/////////////////////////////////////////////////////////////////////////////

/// `<F as Pattern<'a>>::Searcher` साठी संबंधित प्रकार
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// दिलेल्या पूर्वानुमानाशी जुळणार्‍या [`char`] चे शोध.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// &&str साठी उत्तीर्ण
/////////////////////////////////////////////////////////////////////////////

/// `&str` impl साठी प्रतिनिधी.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// एक्स 100 एक्ससाठी इम्प्ली करा
/////////////////////////////////////////////////////////////////////////////

/// विना-वाटप सब्स्ट्रिंग शोध.
///
/// प्रत्येक वर्ण सीमेवर रिकामे सामने परत आणताना `""` नमुना हाताळेल.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// गवतच्या पुढील भागाशी नमुना जुळतो की नाही ते तपासते.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// जर तो जुळत असेल तर गवतकाच्या पुढील भागातून नमुना काढून टाकते.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // सुरक्षितता: उपसर्ग अस्तित्त्वात असल्याचे नुकतेच सत्यापित केले गेले होते.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// गवतच्या मागील बाजूस नमुना जुळत आहे की नाही ते तपासते.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// हे जुळत असल्यास गवतच्या मागील भागापासून नमुना काढून टाकते.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // सुरक्षितता: प्रत्यय नुकतेच अस्तित्त्वात असल्याचे सत्यापित केले गेले.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// टू वे सब्रिंग शोधकर्ता
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// `<&str as Pattern<'a>>::Searcher` साठी संबंधित प्रकार
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // रिक्त सुई प्रत्येक चार्ट नाकारते आणि त्या दरम्यानच्या प्रत्येक रिक्त स्ट्रिंगशी जुळते
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // टूवॉयसर्चर वैध *सामना* निर्देशांक तयार करतात जे चार सीमांवर विभाजित करतात जोपर्यंत तो योग्य जुळणी करत नाही आणि हे गवत आणि सुई वैध आहे UTF-8 *नकार* अल्गोरिदमपासून कोणत्याही निर्देशांकांवर येऊ शकतो, परंतु आम्ही त्या पुढच्या वर्ण सीमेवर व्यक्तिच पुढे जाऊ. , जेणेकरुन ते utf-8 सुरक्षित असतील.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // पुढील चार सीमेवर जा
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // कंपाइलरला दोन प्रकरणे स्वतंत्रपणे प्रोत्साहित करण्यासाठी प्रोत्साहित करण्यासाठी `true` आणि `false` प्रकरणे लिहा.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // पुढील चार सीमेवर जा
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // `true` आणि `false` लिहा, जसे `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// द्वि-मार्ग सब्स्ट्रिंग शोध अल्गोरिदमची अंतर्गत स्थिती.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// गंभीर घटकांकन निर्देशांक
    crit_pos: usize,
    /// उलट सुई साठी गंभीर घटकांकन निर्देशांक
    crit_pos_back: usize,
    period: usize,
    /// `byteset` एक विस्तार आहे (दोन मार्ग अल्गोरिदमचा भाग नाही);
    /// हे एक 64-बिट "fingerprint" आहे जेथे प्रत्येक सेट बिट `j` सुईमध्ये असलेल्या (बाइट आणि 63)==जेशी संबंधित आहे.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// सुई मध्ये निर्देशांक ज्याच्या आधी आपण जुळलो आहोत
    memory: usize,
    /// सुई मध्ये अनुक्रमणिका ज्या नंतर आम्ही आधीपासूनच जुळलो आहोत
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // येथे काय चालले आहे याचे विशेषतः वाचनीय स्पष्टीकरण क्रोशेमोर आणि रायटरच्या एक्स00 एक्स पुस्तक, सीएच 13 मध्ये आढळू शकते.
        // विशेषत: पी वरील "Algorithm CP" साठी कोड पहा.
        // 323.
        //
        // काय चालले आहे आपल्याकडे सुईचे काही गंभीर घटक (यू, व्ही) आहेत आणि आपण&व्ही [.. कालावधी] चे प्रत्यय आहे की नाही हे आम्ही ठरवू इच्छितो.
        // जर ते असेल तर आम्ही "Algorithm CP1" वापरतो.
        // अन्यथा आम्ही "Algorithm CP2" वापरतो, जेव्हा सुईचा कालावधी मोठा असतो तेव्हा अनुकूलित केला जातो.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // शॉर्ट पीरियड केस-कालावधी म्हणजे अचूक सुई x=u 'v' जेथे | v '| वेगळ्या गंभीर घटकाची गणना करणे.<period(x).
            //
            // हे आधीच माहित असलेल्या कालावधीमुळे वाढले आहे.
            // लक्षात घ्या की रिव्हर्समध्ये अंदाजे कालावधी (क्रिट_पॉस=2, पीरियड=2) असणार्‍या एक्स=एक्स 100 एक्स सारखे केस अचूक फॉरवर्ड (क्रिट_पॉस=1, कालावधी=3) केले जाऊ शकतात.
            // आम्ही दिलेला रिव्हर्स फॅक्टरिझेशन वापरतो परंतु अचूक कालावधी ठेवतो.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // दीर्घ कालावधीसाठी-आमच्याकडे वास्तविक कालावधीचे अंदाजे मूल्य आहे आणि आम्ही स्मरणशक्ती वापरू नका.
            //
            //
            // खालच्या बाउंड max(|u|, |v|) + 1 द्वारा कालावधी अंदाजे.
            // अग्रेषित आणि उलट शोध या दोहोंचा वापर करण्यासाठी गंभीर घटकांक कार्यक्षम आहे.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // कालावधी बराच आहे हे दर्शविण्यासाठी डमी मूल्य
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // टू-वेची मुख्य कल्पना म्हणजे आम्ही सुईला दोन भागांमध्ये (यू, व्ही) विभाजीत करतो आणि डावीकडून उजवीकडे स्कॅन करून गवतच्या खोड्यात v शोधण्याचा प्रयत्न सुरू करतो.
    // जर वी जुळत असेल तर, उजवीकडून डावीकडे स्कॅन करून आम्ही तुला जुळविण्याचा प्रयत्न करतो.
    // जेव्हा आपणास न जुळते तेव्हा आपण किती उडी मारू शकतो हे सर्व (यू, व्ही) सुईसाठी एक गंभीर घटक आहे यावर आधारित आहे.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` त्याचा कर्सर म्हणून `self.position` वापरते
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // आमच्याकडे स्थितीत + + सुई_लस्त्यात शोधायला जागा आहे हे तपासा जर आयसाइझच्या श्रेणीने स्लाईस बांधल्या आहेत असे आपण गृहित धरले तर ओव्हरफ्लो होऊ शकत नाही.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // आमच्या सबस्ट्रिंगशी संबंधित नसलेल्या मोठ्या भागांद्वारे द्रुतपणे वगळा
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // सुईचा उजवा भाग जुळत आहे का ते पहा
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // सुईचा डावा भाग जुळत आहे का ते पहा
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // आम्हाला एक सामना सापडला आहे!
            let match_pos = self.position;

            // Note: आच्छादित सामने होण्यासाठी needle.len() ऐवजी self.period जोडा
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // आच्छादित सामन्यांसाठी needle.len(), self.period वर सेट करा
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // एक्स 100 एक्स मधील कल्पनांचे अनुसरण करते.
    //
    // period(x) = period(reverse(x)) आणि local_period(u, v) = local_period(reverse(v), reverse(u)) सह परिभाषा सममितीय आहेत, म्हणून जर (u, v) एक गंभीर घटक आहे तर (reverse(v) देखील आहे, reverse(u)).
    //
    //
    // उलट केससाठी आम्ही एक गंभीर घटक x=u 'v' (फील्ड X02 एक्स) गणना केली आहे.आम्हाला | यू | आवश्यक आहे<एक्स00 एक्स फॉरवर्ड केससाठी आणि अशा प्रकारे | v '|उलट्यासाठी <period(x).
    //
    // गवतकाच्या सहाय्याने उलट शोधण्यासाठी, आम्ही उलटे सुईच्या सहाय्याने उलटलेल्या गवताच्या मागील भागाचा शोध घेत प्रथम 'यु' आणि नंतर 'वी' शी जुळत जाऊ.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` `self.end` चा त्याचा कर्सर म्हणून वापर करतो-जेणेकरुन `next()` आणि `next_back()` स्वतंत्र असतील.
        //
        let old_end = self.end;
        'search: loop {
            // शेवटी शोधायला आमच्याकडे जागा आहे हे तपासा, जागा नसताना needle.len() सभोवती गुंडाळेल, परंतु लांबीच्या लांबीच्या मर्यादेमुळे हे कधीही गवतच्या लांबीपर्यंत संपूर्ण लपेटू शकत नाही.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // आमच्या सबस्ट्रिंगशी संबंधित नसलेल्या मोठ्या भागांद्वारे द्रुतपणे वगळा
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // सुईचा डावा भाग जुळत आहे का ते पहा
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // सुईचा उजवा भाग जुळत आहे का ते पहा
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // आम्हाला एक सामना सापडला आहे!
            let match_pos = self.end - needle.len();
            // Note: आच्छादित सामने असणे needle.len() ऐवजी सब self.period
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // `arr` चे जास्तीत जास्त प्रत्यय मोजा.
    //
    // कमाल प्रत्यय हे `arr` चे संभाव्य गंभीर घटक (यू, व्ही) आहे.
    //
    // परतावा (`i`, `p`) जेथे `i` हा v ची प्रारंभिक अनुक्रमणिका आहे आणि `p` हा v चा कालावधी आहे.
    //
    // `order_greater` शब्दावली क्रम `<` किंवा `>` आहे की नाही हे निर्धारित करते.
    // दोन्ही ऑर्डरची गणना करणे आवश्यक आहे-सर्वात मोठ्या `i` सह ऑर्डर देणे एक गंभीर घटक बनवते.
    //
    //
    // दीर्घ कालावधीसाठी, परिणामी कालावधी अचूक नसतो (तो खूपच लहान असतो).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // पेपर मध्ये मी संबंधित
        let mut right = 1; // कागद मध्ये जे संबंधित
        let mut offset = 0; // पेपर मध्ये केशी संबंधित आहे, परंतु 0 पासून प्रारंभ होत आहे
        // 0-आधारित अनुक्रमणिका जुळविण्यासाठी.
        let mut period = 1; // पेपर मध्ये पी संबंधित

        while let Some(&a) = arr.get(right + offset) {
            // `left` `right` आहे तेव्हा अंतर्भूत होईल.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // प्रत्यय लहान आहे, कालावधी आतापर्यंतचा संपूर्ण उपसर्ग आहे.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // वर्तमान कालावधीच्या पुनरावृत्तीद्वारे आगाऊ.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // प्रत्यय मोठे आहे, वर्तमान स्थानापासून प्रारंभ करा.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // `arr` च्या उलट अधिकतम प्रत्यय मोजा.
    //
    // जास्तीत जास्त प्रत्यय हे `arr` चे संभाव्य गंभीर घटक (u ', v') आहे.
    //
    // `i` मिळवते जिथे `i` मागील वरुन v ची प्रारंभिक अनुक्रमणिका आहे;
    // `known_period` चा कालावधी पूर्ण झाल्यावर लगेच परत येते.
    //
    // `order_greater` शब्दावली क्रम `<` किंवा `>` आहे की नाही हे निर्धारित करते.
    // दोन्ही ऑर्डरची गणना करणे आवश्यक आहे-सर्वात मोठ्या `i` सह ऑर्डर देणे एक गंभीर घटक बनवते.
    //
    //
    // दीर्घ कालावधीसाठी, परिणामी कालावधी अचूक नसतो (तो खूपच लहान असतो).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // पेपर मध्ये मी संबंधित
        let mut right = 1; // कागद मध्ये जे संबंधित
        let mut offset = 0; // पेपर मध्ये केशी संबंधित आहे, परंतु 0 पासून प्रारंभ होत आहे
        // 0-आधारित अनुक्रमणिका जुळविण्यासाठी.
        let mut period = 1; // पेपर मध्ये पी संबंधित
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // प्रत्यय लहान आहे, कालावधी आतापर्यंतचा संपूर्ण उपसर्ग आहे.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // वर्तमान कालावधीच्या पुनरावृत्तीद्वारे आगाऊ.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // प्रत्यय मोठे आहे, वर्तमान स्थानापासून प्रारंभ करा.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// टू वेस्ट्रेटजी अल्गोरिदमला एकतर शक्य तितक्या लवकर नॉन-मॅच वगळण्याची परवानगी देते किंवा अशा मोडमध्ये कार्य करण्यास अनुमती देते जेथे तुलनेने द्रुतगतीने नाकारले जाते.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// कालांतराने शक्य तितक्या लवकर जुळण्यासाठी जा
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// एमिट नकार नियमितपणे
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}