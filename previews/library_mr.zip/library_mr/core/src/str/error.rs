//! utf8 त्रुटी प्रकार परिभाषित करते.

use crate::fmt;

/// [`u8`] च्या क्रमाचे स्ट्रिंग म्हणून अर्थ लावण्याचा प्रयत्न करताना उद्भवू शकणार्‍या त्रुटी.
///
/// जसे की, [`स्ट्रिंग`] आणि [`&str`] दोहोंसाठी कार्य आणि पद्धतींचे `from_utf8` कुटुंब या त्रुटीचा वापर करतात, उदाहरणार्थ.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// या एरर प्रकाराच्या पद्धती हेप मेमरीचे वाटप न करता `String::from_utf8_lossy` प्रमाणे कार्यक्षमता तयार करण्यासाठी वापरल्या जाऊ शकतात:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// दिलेल्या स्ट्रिंगमध्ये अनुक्रमणिका मिळवते ज्यात वैध UTF-8 सत्यापित होते.
    ///
    /// हे `from_utf8(&input[..index])` `Ok(_)` परत करेल अशी कमाल अनुक्रमणिका आहे.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// use std::str;
    ///
    /// // vector मध्ये काही अवैध बाइट
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 एक यूटीएफ 8 एरर मिळवते
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // दुसरा बाइट येथे अवैध आहे
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// अपयशाबद्दल अधिक माहिती प्रदान करते:
    ///
    /// * `None`: इनपुटचा शेवट अनपेक्षितपणे झाला.
    ///   `self.valid_up_to()` इनपुटच्या शेवटी 1 ते 3 बाइट आहे.
    ///   जर बाइट प्रवाह (जसे की फाइल किंवा नेटवर्क सॉकेट) वाढत्या प्रमाणात डीकोड केले जात असेल तर, हा एक वैध `char` असू शकेल ज्याचा एक्स ०१ एक्स बाइट क्रम एकाधिक भागांमध्ये विस्तारित असेल.
    ///
    ///
    /// * `Some(len)`: एक अनपेक्षित बाइट आला.
    ///   प्रदान केलेली लांबी ही एक्स बाईक्स अनुक्रमांची आहे जी एक्स 100 एक्स द्वारा निर्देशांकात प्रारंभ होते.
    ///   हानीकारक डिकोडिंगच्या प्रकरणात त्या अनुक्रमानंतर (एक्स 100 एक्स समाविष्ट केल्यानंतर) डिकोडिंग पुन्हा सुरू करावे.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// [`from_str`] वापरुन `bool` विश्लेषित करताना त्रुटी आली
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}