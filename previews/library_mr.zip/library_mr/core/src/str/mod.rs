//! स्ट्रिंग हेरफेर.
//!
//! अधिक माहितीसाठी, [`std::str`] मॉड्यूल पहा.
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. मर्यादा बाहेर
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. प्रारंभ <=शेवट
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. वर्ण सीमा
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // वर्ण शोधा
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` लेनपेक्षा कमी आणि चार सीमेवरील असावी
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// `self` ची लांबी मिळवते.
    ///
    /// ही लांबी बाइटमध्ये आहे, [`Char`] चे किंवा ग्राफिक नाहीत.
    /// दुस words्या शब्दांत, एखादी गोष्ट स्ट्रिंगची लांबी मानते.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // फॅन्सी फॅ!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// `self` ची शून्य बाइट लांबी असल्यास `true` मिळवते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// 00 अनुक्रमणिका-व्या बाइट हे UTF-8 कोड बिंदू क्रमातील किंवा स्ट्रिंगच्या शेवटी असलेला पहिला बाइट आहे याची तपासणी करते.
    ///
    ///
    /// स्ट्रिंगची सुरूवात आणि शेवट (जेव्हा `अनुक्रमणिका== self.len()`) सीमा समजली जाते.
    ///
    /// `index` हे `self.len()` पेक्षा मोठे असल्यास `false` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // `老` ची सुरूवात
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // `ö` चा दुसरा बाइट
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // `老` चा तिसरा बाइट
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 आणि लेन नेहमीच ठीक असतात.
        // 0 साठी स्पष्टपणे चाचणी घ्या जेणेकरून ते सहजतेने चेक ऑप्टिमाइझ होऊ शकेल आणि त्या प्रकरणातील वाचन स्ट्रिंग डेटा वगळू शकेल.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // हे थोडी जादू समतुल्य आहेः बी <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// स्ट्रिंग स्लाइसला बाइट स्लाइसमध्ये रुपांतरित करते.
    /// बाइट स्लाइस परत स्ट्रिंगच्या स्लाइसमध्ये रुपांतरित करण्यासाठी, [`from_utf8`] फंक्शन वापरा.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // सुरक्षितता: कॉन्स्ट आवाज कारण आम्ही समान लेआउटसह दोन प्रकारांचे संक्रमित करतो
        unsafe { mem::transmute(self) }
    }

    /// म्युटेबल स्ट्रिंग स्लाइसला म्युटेबल बाईट स्लाइसमध्ये रुपांतरित करते.
    ///
    /// # Safety
    ///
    /// कॉलरने हे सुनिश्चित केले पाहिजे की कर्ज संपण्यापूर्वी आणि अंतर्निहित `str` वापरण्यापूर्वी स्लाइसची सामग्री UTF-8 X वैध आहे.
    ///
    ///
    /// `str` चा वापर ज्यांची सामग्री वैध नाही UTF-8 ही अपरिभाषित वर्तन आहे.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // सुरक्षितता: `&str` ते `&[u8]` पर्यंत कास्ट `str` पासून सुरक्षित आहे
        // `&[u8]` प्रमाणेच लेआउट आहे (केवळ लिबस्टडी ही हमी देऊ शकते).
        // पॉईंटर डीरेफरेन्स सुरक्षित आहे कारण ते बदल करण्यायोग्य संदर्भातून येते जे लेखनास वैध असल्याची हमी दिलेली आहे.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// स्ट्रिंग स्लाइस कच्च्या पॉईंटरमध्ये रुपांतरित करते.
    ///
    /// स्ट्रिंग स्लाइस बाइट्सचा एक तुकडा असल्याने, कच्चा सूचक एक [`u8`] वर निर्देशित करतो.
    /// हे पॉईंटर स्ट्रिंग स्लाइसच्या पहिल्या बाईटकडे निर्देशित करेल.
    ///
    /// कॉलरने हे निश्चित केले पाहिजे की परत केलेला पॉईंटर कधीही लिहित नाही.
    /// आपल्याला स्ट्रिंग स्लाइसमधील सामग्री बदलण्याची आवश्यकता असल्यास, [`as_mut_ptr`] वापरा.
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// बदलण्यायोग्य स्ट्रिंग स्लाइसला कच्च्या पॉइंटरमध्ये रुपांतरित करते.
    ///
    /// स्ट्रिंग स्लाइस बाइट्सचा एक तुकडा असल्याने, कच्चा सूचक एक [`u8`] वर निर्देशित करतो.
    /// हे पॉईंटर स्ट्रिंग स्लाइसच्या पहिल्या बाईटकडे निर्देशित करेल.
    ///
    /// हे सुनिश्चित करणे आपली जबाबदारी आहे की केवळ स्ट्रिंग स्लाइस अशा प्रकारे सुधारित केली जाईल की ती वैध UTF-8 राहील.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// `str` ची सबलिसिस मिळवते.
    ///
    /// हे एक्स-00 एक्स अनुक्रमित करण्याचा नॉन-पॅनीकिंग पर्याय आहे.
    /// जेव्हाही समकक्ष अनुक्रमणिका ऑपरेशन panic होईल तेव्हा [`None`] मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // निर्देशांक UTF-8 क्रम सीमांवर नाहीत
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // मर्यादा बाहेर
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// `str` ची बदलता येणारी सबलिसिस मिळवते.
    ///
    /// हे एक्स-00 एक्स अनुक्रमित करण्याचा नॉन-पॅनीकिंग पर्याय आहे.
    /// जेव्हाही समकक्ष अनुक्रमणिका ऑपरेशन panic होईल तेव्हा [`None`] मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // योग्य लांबी
    /// assert!(v.get_mut(0..5).is_some());
    /// // मर्यादा बाहेर
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// `str` ची चेक न केलेली सबसिलिस परत करते.
    ///
    /// एक्स 100 एक्स अनुक्रमित करण्याचा हा एक अनचेक पर्याय आहे.
    ///
    /// # Safety
    ///
    /// या कार्याचे कॉलर जबाबदार आहेत की या पूर्व शर्ती समाधानी आहेत:
    ///
    /// * प्रारंभ सूचकांक शेवटच्या निर्देशांकापेक्षा जास्त नसावा;
    /// * निर्देशांक मूळ स्लाइसच्या सीमेत असावेत;
    /// * अनुक्रमणिका UTF-8 क्रम सीमांवर असणे आवश्यक आहे.
    ///
    /// अयशस्वी झाल्यास, परत आलेल्या स्ट्रिंग स्लाइस अवैध मेमरीचा संदर्भ घेऊ शकते किंवा `str` प्रकाराद्वारे सूचित केलेल्या आक्रमणांचे उल्लंघन करू शकते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // सुरक्षितता: कॉलरने `get_unchecked` साठी सुरक्षितता करार पाळलाच पाहिजे;
        // स्लाईस डीरेफरेन्सेबल आहे कारण एक्स00 एक्स हा एक सुरक्षित संदर्भ आहे.
        // परत केलेला पॉईंटर सुरक्षित आहे कारण एक्स 100 एक्सच्या इम्पल्सना ते असल्याची हमी दिली पाहिजे.
        unsafe { &*i.get_unchecked(self) }
    }

    /// `str` ची एक बदलण्यायोग्य, चेक न केलेली सबलिसिस मिळवते.
    ///
    /// एक्स 100 एक्स अनुक्रमित करण्याचा हा एक अनचेक पर्याय आहे.
    ///
    /// # Safety
    ///
    /// या कार्याचे कॉलर जबाबदार आहेत की या पूर्व शर्ती समाधानी आहेत:
    ///
    /// * प्रारंभ सूचकांक शेवटच्या निर्देशांकापेक्षा जास्त नसावा;
    /// * निर्देशांक मूळ स्लाइसच्या सीमेत असावेत;
    /// * अनुक्रमणिका UTF-8 क्रम सीमांवर असणे आवश्यक आहे.
    ///
    /// अयशस्वी झाल्यास, परत आलेल्या स्ट्रिंग स्लाइस अवैध मेमरीचा संदर्भ घेऊ शकते किंवा `str` प्रकाराद्वारे सूचित केलेल्या आक्रमणांचे उल्लंघन करू शकते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // सुरक्षितता: कॉलरने `get_unchecked_mut` साठी सुरक्षितता करार पाळलाच पाहिजे;
        // स्लाईस डीरेफरेन्सेबल आहे कारण एक्स00 एक्स हा एक सुरक्षित संदर्भ आहे.
        // परत केलेला पॉईंटर सुरक्षित आहे कारण एक्स 100 एक्सच्या इम्पल्सना ते असल्याची हमी दिली पाहिजे.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// सुरक्षा तपासणीला धरून दुसर्‍या स्ट्रिंग स्लाइसमधून एक स्ट्रिंग स्लाइस तयार करते.
    ///
    /// ही सहसा शिफारस केलेली नाही, सावधगिरीने वापरा!सुरक्षित पर्यायासाठी [`str`] आणि [`Index`] पहा.
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// ही नवीन स्लाईस `begin` वरून `end` पर्यंत जाते, यात `begin` चा समावेश आहे परंतु `end` वगळता.
    ///
    /// त्याऐवजी बदलण्यायोग्य स्ट्रिंग स्लाइस मिळविण्यासाठी, एक्स00 एक्स पद्धत पहा.
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// या कार्याचे कॉलर जबाबदार आहेत की तीन पूर्व शर्ती समाधानी आहेत:
    ///
    /// * `begin` `end` पेक्षा जास्त नसावा.
    /// * `begin` आणि एक्स00 एक्स स्ट्रिंग स्लाइसमध्ये बाइट पोझिशन्स असणे आवश्यक आहे.
    /// * `begin` आणि `end` UTF-8 क्रम सीमेवरील असू शकते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // सुरक्षितता: कॉलरने `get_unchecked` साठी सुरक्षितता करार पाळलाच पाहिजे;
        // स्लाईस डीरेफरेन्सेबल आहे कारण एक्स00 एक्स हा एक सुरक्षित संदर्भ आहे.
        // परत केलेला पॉईंटर सुरक्षित आहे कारण एक्स 100 एक्सच्या इम्पल्सना ते असल्याची हमी दिली पाहिजे.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// सुरक्षा तपासणीला धरून दुसर्‍या स्ट्रिंग स्लाइसमधून एक स्ट्रिंग स्लाइस तयार करते.
    /// ही सहसा शिफारस केलेली नाही, सावधगिरीने वापरा!सुरक्षित पर्यायासाठी [`str`] आणि [`IndexMut`] पहा.
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// ही नवीन स्लाईस `begin` वरून `end` पर्यंत जाते, यात `begin` चा समावेश आहे परंतु `end` वगळता.
    ///
    /// त्याऐवजी अचल स्ट्रिंग स्लाईस मिळविण्यासाठी, एक्स00 एक्स पद्धत पहा.
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// या कार्याचे कॉलर जबाबदार आहेत की तीन पूर्व शर्ती समाधानी आहेत:
    ///
    /// * `begin` `end` पेक्षा जास्त नसावा.
    /// * `begin` आणि एक्स00 एक्स स्ट्रिंग स्लाइसमध्ये बाइट पोझिशन्स असणे आवश्यक आहे.
    /// * `begin` आणि `end` UTF-8 क्रम सीमेवरील असू शकते.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // सुरक्षितता: कॉलरने `get_unchecked_mut` साठी सुरक्षितता करार पाळलाच पाहिजे;
        // स्लाईस डीरेफरेन्सेबल आहे कारण एक्स00 एक्स हा एक सुरक्षित संदर्भ आहे.
        // परत केलेला पॉईंटर सुरक्षित आहे कारण एक्स 100 एक्सच्या इम्पल्सना ते असल्याची हमी दिली पाहिजे.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// निर्देशांकात एक स्ट्रिंग स्लाइस दोन मध्ये विभागून घ्या.
    ///
    /// `mid` हा अर्ग्युमेंट स्ट्रिंगच्या सुरूवातीस बाईट ऑफसेट असावा.
    /// हे UTF-8 कोड पॉइंटच्या सीमेवर देखील असले पाहिजे.
    ///
    /// परत आलेल्या दोन स्लाइस्स स्ट्रिंगच्या सुरूवातीपासून `mid` पर्यंत आणि `mid` वरून स्ट्रिंग स्लाइसच्या शेवटी जा.
    ///
    /// त्याऐवजी म्यूटेबल स्ट्रिंग स्लाइस मिळविण्यासाठी, एक्स00 एक्स पद्धत पहा.
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// `mid` UTF-8 कोड पॉइंट सीमेवरील नसल्यास Panics किंवा स्ट्रिंग स्लाइसच्या शेवटच्या कोड बिंदूच्या शेवटी असल्यास.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_ सीमा तपासते की अनुक्रमणिका [0, .len()]
        if self.is_char_boundary(mid) {
            // सुरक्षितताः नुकतेच तपासले की `mid` चार सीमेवरील आहे.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// अनुक्रमणिका एक परिवर्तनीय स्ट्रिंग स्लाइस दोन मध्ये विभाजित करा.
    ///
    /// `mid` हा अर्ग्युमेंट स्ट्रिंगच्या सुरूवातीस बाईट ऑफसेट असावा.
    /// हे UTF-8 कोड पॉइंटच्या सीमेवर देखील असले पाहिजे.
    ///
    /// परत आलेल्या दोन स्लाइस्स स्ट्रिंगच्या सुरूवातीपासून `mid` पर्यंत आणि `mid` वरून स्ट्रिंग स्लाइसच्या शेवटी जा.
    ///
    /// त्याऐवजी अदम्य स्ट्रिंग स्लाइस मिळविण्यासाठी, [`split_at`] पद्धत पहा.
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// `mid` UTF-8 कोड पॉइंट सीमेवरील नसल्यास Panics किंवा स्ट्रिंग स्लाइसच्या शेवटच्या कोड बिंदूच्या शेवटी असल्यास.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_ सीमा तपासते की अनुक्रमणिका [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // सुरक्षितताः नुकतेच तपासले की `mid` चार सीमेवरील आहे.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// स्ट्रिंग स्लाइसच्या [`Char`] s वर पुनरावृत्ती करणारा मिळवते.
    ///
    /// स्ट्रिंग स्लाइसमध्ये वैध X01 एक्स असते म्हणून आम्ही एक्स 100 एक्स द्वारे स्ट्रिंग स्लाइसद्वारे पुनरावृत्ती करू शकतो.
    /// ही पद्धत अशी पुनरावृत्ती करणारा परत करते.
    ///
    /// हे लक्षात ठेवणे महत्वाचे आहे की [`char`] युनिकोड स्केलर मूल्याचे प्रतिनिधित्व करते आणि कदाचित 'character' काय आहे या आपल्या कल्पनेशी जुळत नाही.
    ///
    /// आपल्याला प्रत्यक्षात पाहिजे असलेले ग्राफिक क्लस्टर्सवरील आयटरेशन असू शकते.
    /// ही कार्यक्षमता Rust च्या मानक लायब्ररीत उपलब्ध नाही, त्याऐवजी crates.io तपासा.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// लक्षात ठेवा, [`char`] s वर्णांबद्दल आपल्या अंतर्ज्ञानाशी जुळत नाही:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // 'y̆' नाही
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// स्ट्रिंग स्लाइसच्या [`char`] च्या आणि त्यांच्या स्थानांवर एक इटररेटर मिळवते.
    ///
    /// स्ट्रिंग स्लाइसमध्ये वैध X01 एक्स असते म्हणून आम्ही एक्स 100 एक्स द्वारे स्ट्रिंग स्लाइसद्वारे पुनरावृत्ती करू शकतो.
    /// ही पद्धत या दोन्ही [`char`] चे पुनरावलोकने तसेच त्यांच्या बाइट स्थानांवर परत करते.
    ///
    /// इटररेटर ट्युपल्स देते.प्रथम क्रमांकावर, [`char`] दुसर्‍या क्रमांकावर आहे.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// लक्षात ठेवा, [`char`] s वर्णांबद्दल आपल्या अंतर्ज्ञानाशी जुळत नाही:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // नाही (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // येथे 3 लक्षात घ्या, शेवटच्या पात्राने दोन बाइट घेतले
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// स्ट्रिंग स्लाइसच्या बाइट्सवर एक इटरेटर.
    ///
    /// जसे स्ट्रिंग स्लाइसमध्ये बाइट्सचा क्रम असतो, आम्ही स्ट्रिंग स्लाइसद्वारे बाइटद्वारे पुनरावृत्ती करू शकतो.
    /// ही पद्धत अशी पुनरावृत्ती करणारा परत करते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// व्हाईटस्पेसद्वारे स्ट्रिंग स्लाइस विभाजित करते.
    ///
    /// परत केलेला इटरेटर मूळ स्ट्रिंगच्या स्लाइसच्या उप-स्लाइस असलेल्या पांढर्‍या स्पेसच्या कोणत्याही प्रमाणात विभक्त केलेल्या स्ट्रिंग स्लाइस परत करेल.
    ///
    ///
    /// 'Whitespace' युनिकोड व्युत्पन्न कोअर प्रॉपर्टी `White_Space` च्या अटींनुसार परिभाषित केले आहे.
    /// त्याऐवजी आपण फक्त एएससीआयआय व्हाईटस्पेसवर विभाजित करू इच्छित असल्यास, एक्स00 एक्स वापरा.
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// सर्व प्रकारच्या व्हाईटस्पेसचा विचार केला जातोः
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// एएससीआयआय व्हाईटस्पेसद्वारे स्ट्रिंग स्लाइस विभाजित करते.
    ///
    /// परत केलेला इटरेटर परत स्ट्रिंगच्या स्लाइस परत करेल जो मूळ स्ट्रिंगच्या स्लाइसच्या उप-स्लाइस आहेत, कोणत्याही प्रमाणात एएससीआयआय व्हाईटस्पेसद्वारे विभक्त.
    ///
    ///
    /// त्याऐवजी युनिकोड `Whitespace` ने विभाजित करण्यासाठी, [`split_whitespace`] वापरा.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// सर्व प्रकारच्या एएससीआयआय व्हाईटस्पेसचा विचार केला जातो:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// स्ट्रिंगच्या तुकड्यांप्रमाणे, स्ट्रिंगच्या ओळीवर एक इटरेटर.
    ///
    /// एकतर न्यूलाईन (`\n`) किंवा लाइन फीड (`\r\n`) सह कॅरेज रिटर्नसह लाईन्स समाप्त केल्या आहेत.
    ///
    /// अंतिम रेखा समाप्त करणे पर्यायी आहे.
    /// अंतिम रेषा समाप्त होणारी शेवटची ओळ शेवटची रेखा न संपता समान रेखा म्हणून परत येईल.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// अंतिम समाप्तीची आवश्यकता नाही:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// स्ट्रिंगच्या ओळीवर एक इटरेटर.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// UTF-16 म्हणून एन्कोड केलेल्या स्ट्रिंगवर `u16` चे एक आयटर मिळवते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// दिलेली नमुना या स्ट्रिंगच्या स्लाइसच्या उप-स्लाइसशी जुळल्यास `true` मिळवते.
    ///
    /// ते नसल्यास `false` मिळवते.
    ///
    /// [pattern] हे `&str`, [`char`], [`char`] चे एक तुकडा किंवा एखादे कार्य किंवा बंदर असू शकते जे वर्ण जुळते की नाही हे निर्धारित करते.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// दिलेल्या पॅटर्नने या स्ट्रिंग स्लाइसच्या प्रत्ययाशी जुळल्यास `true` मिळवते.
    ///
    /// ते नसल्यास `false` मिळवते.
    ///
    /// [pattern] हे `&str`, [`char`], [`char`] चे एक तुकडा किंवा एखादे कार्य किंवा बंदर असू शकते जे वर्ण जुळते की नाही हे निर्धारित करते.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// दिलेली नमुना या स्ट्रिंग स्लाइसच्या प्रत्ययशी जुळल्यास `true` मिळवते.
    ///
    /// ते नसल्यास `false` मिळवते.
    ///
    /// [pattern] हे `&str`, [`char`], [`char`] चे एक तुकडा किंवा एखादे कार्य किंवा बंदर असू शकते जे वर्ण जुळते की नाही हे निर्धारित करते.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// पॅटर्नशी जुळणार्‍या या स्ट्रिंग स्लाइसच्या पहिल्या वर्णातील बाइट अनुक्रमणिका मिळवते.
    ///
    /// नमुना जुळत नसल्यास [`None`] मिळवते.
    ///
    /// [pattern] हे `&str`, [`char`], [`char`] चे एक तुकडा किंवा एखादे कार्य किंवा बंदर असू शकते जे वर्ण जुळते की नाही हे निर्धारित करते.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// साधे नमुने:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// पॉईंट-फ्री शैली आणि बंदचा वापर करून अधिक जटिल नमुने:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// नमुना सापडत नाही:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// या स्ट्रिंग स्लाइसमधील नमुनाच्या सर्वात उजवीकडे जुळणार्‍या पहिल्या वर्णसाठी बाइट अनुक्रमणिका मिळवते.
    ///
    /// नमुना जुळत नसल्यास [`None`] मिळवते.
    ///
    /// [pattern] हे `&str`, [`char`], [`char`] चे एक तुकडा किंवा एखादे कार्य किंवा बंदर असू शकते जे वर्ण जुळते की नाही हे निर्धारित करते.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// साधे नमुने:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// क्लोजरसह अधिक जटिल नमुने:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// नमुना सापडत नाही:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// या स्ट्रिंग स्लाइसच्या सबस्ट्रिंग्जवरील एक पुनरावृत्ती करणारा, नमुन्यासह जुळणार्‍या वर्णांद्वारे विभक्त.
    ///
    /// [pattern] हे `&str`, [`char`], [`char`] चे एक तुकडा किंवा एखादे कार्य किंवा बंदर असू शकते जे वर्ण जुळते की नाही हे निर्धारित करते.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator वर्तन
    ///
    /// जर प्रतिमानाने उलट शोधास अनुमती दिली आणि forward/reverse शोधात समान घटक उत्पन्न केले तर परत केलेले आयटर एक [`DoubleEndedIterator`] असेल.
    /// हे [`char`] साठी खरे आहे, परंतु `&str` साठी नाही.
    ///
    /// जर नमुना उलट शोधास अनुमती देते परंतु त्याचे परिणाम पुढील शोधापेक्षा भिन्न असू शकतात तर [`rsplit`] पद्धत वापरली जाऊ शकते.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// साधे नमुने:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// नमुना चारसांचा तुकडा असल्यास कोणत्याही वर्णातील प्रत्येक घटनेवर विभाजन करा:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// क्लोजरचा वापर करून एक अधिक जटिल नमुना:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// जर एका स्ट्रिंगमध्ये अनेक कॉन्टिग्युलस सेप्युटर असतात, तर आपण आउटपुटमध्ये रिकाम्या तारांसह समाप्त व्हाल:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// कॉन्टिग्युज विभाजक रिकाम्या स्ट्रिंगद्वारे विभक्त केले जातात.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// स्ट्रिंगच्या सुरूवातीस किंवा शेवटी विभाजक रिक्त तारांनी शेजारी असतात.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// जेव्हा रिक्त स्ट्रिंग विभाजक म्हणून वापरली जाते, तेव्हा ती स्ट्रिंगच्या सुरूवातीस आणि शेवटी स्ट्रिंगमधील प्रत्येक वर्ण विभक्त करते.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// जेव्हा व्हाइटस्पेस विभाजक म्हणून वापरला जातो तेव्हा वेगळ्या विभाजकांद्वारे शक्यतो आश्चर्यकारक वर्तन होऊ शकते.हा कोड बरोबर आहेः
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// हे आपल्याला _not_ देते:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// या वर्तनसाठी [`split_whitespace`] वापरा.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// या स्ट्रिंग स्लाइसच्या सबस्ट्रिंग्जवरील एक पुनरावृत्ती करणारा, नमुन्यासह जुळणार्‍या वर्णांद्वारे विभक्त.
    /// त्या `split_inclusive` मधील `split` द्वारा निर्मित इट्रेटरपेक्षा भिन्न म्हणजे जुळलेला भाग सबस्ट्रिंगचा टर्मिनेटर म्हणून सोडतो.
    ///
    ///
    /// [pattern] हे `&str`, [`char`], [`char`] चे एक तुकडा किंवा एखादे कार्य किंवा बंदर असू शकते जे वर्ण जुळते की नाही हे निर्धारित करते.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// जर तारांचा शेवटचा घटक जुळला असेल तर तो घटक आधीच्या सबस्ट्रिंगचा टर्मिनेटर मानला जाईल.
    /// ते सब्टरिंग ही पुनरावृत्ती करणार्‍याद्वारे परत केलेली शेवटची आयटम असेल.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// दिलेल्या स्ट्रिंग स्लाइसच्या सबस्ट्रिंग्जवरील एक पुनरावृत्ती करणारा, नमुन्यासह जुळणार्‍या वर्णांद्वारे विभक्त आणि उलट क्रमवारीत उत्पन्न.
    ///
    /// [pattern] हे `&str`, [`char`], [`char`] चे एक तुकडा किंवा एखादे कार्य किंवा बंदर असू शकते जे वर्ण जुळते की नाही हे निर्धारित करते.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator वर्तन
    ///
    /// परत केलेल्या पुनरावृत्तीकाला आवश्यक आहे की नमुना उलट्या शोधास समर्थन देते आणि जर एक एक्स ० एक्स एक्स शोधात समान घटक उत्पन्न केले तर ते [`DoubleEndedIterator`] असेल.
    ///
    ///
    /// समोरून पुनरावृत्ती करण्यासाठी, [`split`] पद्धत वापरली जाऊ शकते.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// साधे नमुने:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// क्लोजरचा वापर करून एक अधिक जटिल नमुना:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// दिलेल्या स्ट्रिंग स्लाइसच्या सबस्ट्रिंग्जवरील एक पुनरावृत्ती करणारा, नमुन्यासह जुळणार्‍या वर्णांद्वारे विभक्त.
    ///
    /// [pattern] हे `&str`, [`char`], [`char`] चे एक तुकडा किंवा एखादे कार्य किंवा बंदर असू शकते जे वर्ण जुळते की नाही हे निर्धारित करते.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// [`split`] च्या समतुल्य, रिक्त असल्यास अनुगामी सबस्ट्रिंग वगळले जाते.
    ///
    /// [`split`]: str::split
    ///
    /// ही पद्धत _separated_ ऐवजी, नमुना नुसार _terminated_ असलेल्या स्ट्रिंग डेटासाठी वापरली जाऊ शकते.
    ///
    /// # Iterator वर्तन
    ///
    /// जर प्रतिमानाने उलट शोधास अनुमती दिली आणि forward/reverse शोधात समान घटक उत्पन्न केले तर परत केलेले आयटर एक [`DoubleEndedIterator`] असेल.
    /// हे [`char`] साठी खरे आहे, परंतु `&str` साठी नाही.
    ///
    /// जर नमुना उलट शोधास अनुमती देते परंतु त्याचे परिणाम पुढील शोधापेक्षा भिन्न असू शकतात तर [`rsplit_terminator`] पद्धत वापरली जाऊ शकते.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// `self` च्या सबस्ट्रिंगवरील पुनरावृत्ती करणारा, नमुना जुळणार्‍या वर्णांद्वारे विभक्त आणि उलट क्रमाने उत्पन्न दिले.
    ///
    /// [pattern] हे `&str`, [`char`], [`char`] चे एक तुकडा किंवा एखादे कार्य किंवा बंदर असू शकते जे वर्ण जुळते की नाही हे निर्धारित करते.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// [`split`] च्या समतुल्य, रिक्त असल्यास अनुगामी सबस्ट्रिंग वगळले जाते.
    ///
    /// [`split`]: str::split
    ///
    /// ही पद्धत _separated_ ऐवजी, नमुना नुसार _terminated_ असलेल्या स्ट्रिंग डेटासाठी वापरली जाऊ शकते.
    ///
    /// # Iterator वर्तन
    ///
    /// परत केलेल्या आयटरला आवश्यक आहे की नमुना उलट्या शोधास समर्थन देते आणि जर एक्स00 एक्स शोधात समान घटक मिळाले तर ते दुहेरी समाप्त होईल.
    ///
    ///
    /// समोरून पुनरावृत्ती करण्यासाठी, [`split_terminator`] पद्धत वापरली जाऊ शकते.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// दिलेल्या स्ट्रिंग स्लाइसच्या सबस्ट्रिंग्जवरील पुनरावृत्ती करणारा, नमुना विभक्त, बहुतेक `n` आयटमवर परत येण्यास प्रतिबंधित आहे.
    ///
    /// जर एक्स 100 एक्स सबस्ट्रिंग परत केले तर शेवटच्या सबस्ट्रिंग (`n`th सबस्ट्रिंग) मध्ये उर्वरित स्ट्रिंग असेल.
    ///
    /// [pattern] हे `&str`, [`char`], [`char`] चे एक तुकडा किंवा एखादे कार्य किंवा बंदर असू शकते जे वर्ण जुळते की नाही हे निर्धारित करते.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator वर्तन
    ///
    /// परत केलेला आयटर दुहेरी समाप्त होणार नाही, कारण तो समर्थन करण्यास कार्यक्षम नाही.
    ///
    /// जर नमुना उलट शोधास अनुमती देत असेल तर [`rsplitn`] पद्धत वापरली जाऊ शकते.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// साधे नमुने:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// क्लोजरचा वापर करून एक अधिक जटिल नमुना:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// या स्ट्रिंगच्या स्लाइसच्या सबस्ट्रिंग्जवरील पुनरावृत्ती, एका पॅटर्नद्वारे विभक्त केलेले, स्ट्रिंगच्या शेवटीपासून सुरू होते, बहुतेक `n` आयटमवर परत येण्यास प्रतिबंधित आहे.
    ///
    ///
    /// जर एक्स 100 एक्स सबस्ट्रिंग परत केले तर शेवटच्या सबस्ट्रिंग (`n`th सबस्ट्रिंग) मध्ये उर्वरित स्ट्रिंग असेल.
    ///
    /// [pattern] हे `&str`, [`char`], [`char`] चे एक तुकडा किंवा एखादे कार्य किंवा बंदर असू शकते जे वर्ण जुळते की नाही हे निर्धारित करते.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator वर्तन
    ///
    /// परत केलेला आयटर दुहेरी समाप्त होणार नाही, कारण तो समर्थन करण्यास कार्यक्षम नाही.
    ///
    /// समोरपासून विभक्त होण्यासाठी, [`splitn`] पद्धत वापरली जाऊ शकते.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// साधे नमुने:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// क्लोजरचा वापर करून एक अधिक जटिल नमुना:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// निर्दिष्ट केलेल्या डिलिमिटरच्या पहिल्या घटकावर स्ट्रिंग विभाजित करते आणि डिलिमीटरच्या आधी उपसर्ग आणि डिलिमीटर नंतर प्रत्यय मिळवते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// निर्दिष्ट डिलिमिटरच्या शेवटच्या घटकावर स्ट्रिंग विभाजित करते आणि डिलिमीटरच्या आधी उपसर्ग आणि डिलिमीटर नंतर प्रत्यय मिळवते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// दिलेल्या स्ट्रिंग स्लाइसमध्ये नमुन्यांची विच्छेदन जुळण्यांवर पुनरावृत्ती करणारा.
    ///
    /// [pattern] हे `&str`, [`char`], [`char`] चे एक तुकडा किंवा एखादे कार्य किंवा बंदर असू शकते जे वर्ण जुळते की नाही हे निर्धारित करते.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator वर्तन
    ///
    /// जर प्रतिमानाने उलट शोधास अनुमती दिली आणि forward/reverse शोधात समान घटक उत्पन्न केले तर परत केलेले आयटर एक [`DoubleEndedIterator`] असेल.
    /// हे [`char`] साठी खरे आहे, परंतु `&str` साठी नाही.
    ///
    /// जर नमुना उलट शोधास अनुमती देते परंतु त्याचे परिणाम पुढील शोधापेक्षा भिन्न असू शकतात तर [`rmatches`] पद्धत वापरली जाऊ शकते.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// या स्ट्रिंगच्या तुकड्यातून नमुन्यांची विघटित जुळण्या केल्यावर एक पुनरावलोकने उलट क्रमाने प्राप्त केला.
    ///
    /// [pattern] हे `&str`, [`char`], [`char`] चे एक तुकडा किंवा एखादे कार्य किंवा बंदर असू शकते जे वर्ण जुळते की नाही हे निर्धारित करते.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator वर्तन
    ///
    /// परत केलेल्या पुनरावृत्तीकाला आवश्यक आहे की नमुना उलट्या शोधास समर्थन देते आणि जर एक एक्स ० एक्स एक्स शोधात समान घटक उत्पन्न केले तर ते [`DoubleEndedIterator`] असेल.
    ///
    ///
    /// समोरून पुनरावृत्ती करण्यासाठी, [`matches`] पद्धत वापरली जाऊ शकते.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// या स्ट्रिंग स्लाइसमधील नमुन्याचे विच्छेदनपूर्ण सामने तसेच सामना प्रारंभ होणारी अनुक्रमणिका यावर एक पुनरावृत्ती करणारा.
    ///
    /// आच्छादित `self` मधील `pat` च्या सामन्यांसाठी, पहिल्या सामन्याशी संबंधित केवळ निर्देशांक परत केले जातात.
    ///
    /// [pattern] हे `&str`, [`char`], [`char`] चे एक तुकडा किंवा एखादे कार्य किंवा बंदर असू शकते जे वर्ण जुळते की नाही हे निर्धारित करते.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator वर्तन
    ///
    /// जर प्रतिमानाने उलट शोधास अनुमती दिली आणि forward/reverse शोधात समान घटक उत्पन्न केले तर परत केलेले आयटर एक [`DoubleEndedIterator`] असेल.
    /// हे [`char`] साठी खरे आहे, परंतु `&str` साठी नाही.
    ///
    /// जर नमुना उलट शोधास अनुमती देते परंतु त्याचे परिणाम पुढील शोधापेक्षा भिन्न असू शकतात तर [`rmatch_indices`] पद्धत वापरली जाऊ शकते.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // फक्त प्रथम `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// `self` मधील नमुन्याच्या विच्छेदनपूर्ण सामन्यांपैकी पुनरावृत्ती करणारा, सामन्याच्या अनुक्रमणिकेसह उलट क्रमाने प्राप्त झाला.
    ///
    /// आच्छादित `self` मधील `pat` च्या सामन्यांसाठी, शेवटच्या सामन्याशी संबंधित केवळ निर्देशांक परत केले जातात.
    ///
    /// [pattern] हे `&str`, [`char`], [`char`] चे एक तुकडा किंवा एखादे कार्य किंवा बंदर असू शकते जे वर्ण जुळते की नाही हे निर्धारित करते.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator वर्तन
    ///
    /// परत केलेल्या पुनरावृत्तीकाला आवश्यक आहे की नमुना उलट्या शोधास समर्थन देते आणि जर एक एक्स ० एक्स एक्स शोधात समान घटक उत्पन्न केले तर ते [`DoubleEndedIterator`] असेल.
    ///
    ///
    /// समोरून पुनरावृत्ती करण्यासाठी, [`match_indices`] पद्धत वापरली जाऊ शकते.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // फक्त शेवटचा `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// अग्रगण्य आणि अनुगामी व्हाइटस्पेस काढलेल्या स्ट्रिंग स्लाइस मिळवते.
    ///
    /// 'Whitespace' युनिकोड व्युत्पन्न कोअर प्रॉपर्टी `White_Space` च्या अटींनुसार परिभाषित केले आहे.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// अग्रगण्य व्हाइटस्पेस काढलेल्या स्ट्रिंगचा स्लाइस मिळवते.
    ///
    /// 'Whitespace' युनिकोड व्युत्पन्न कोअर प्रॉपर्टी `White_Space` च्या अटींनुसार परिभाषित केले आहे.
    ///
    /// # मजकूर दिशात्मकता
    ///
    /// स्ट्रिंग बाइट्सचा क्रम आहे.
    /// `start` या संदर्भात त्या बाइट स्ट्रिंगची पहिली स्थिती;इंग्रजी किंवा रशियन सारख्या डावीकडून उजवीकडे असलेल्या भाषेसाठी, ही डावीकडील असेल आणि अरबी किंवा हिब्रूसारख्या उजवीकडून डावीकडे भाषांसाठी ही उजवी बाजू असेल.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// ट्रेलिंग व्हाइटस्पेस काढल्यासह स्ट्रिंग स्लाइस मिळवते.
    ///
    /// 'Whitespace' युनिकोड व्युत्पन्न कोअर प्रॉपर्टी `White_Space` च्या अटींनुसार परिभाषित केले आहे.
    ///
    /// # मजकूर दिशात्मकता
    ///
    /// स्ट्रिंग बाइट्सचा क्रम आहे.
    /// `end` या संदर्भात त्या बाइट स्ट्रिंगची शेवटची स्थिती;डावीकडून उजवीकडे इंग्रजी किंवा रशियन भाषेसाठी ही उजवीकडील बाजू असेल आणि अरबी किंवा हिब्रूसारख्या उजवी-डावी-भाषेसाठी ही डावी बाजू असेल.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// अग्रगण्य व्हाइटस्पेस काढलेल्या स्ट्रिंगचा स्लाइस मिळवते.
    ///
    /// 'Whitespace' युनिकोड व्युत्पन्न कोअर प्रॉपर्टी `White_Space` च्या अटींनुसार परिभाषित केले आहे.
    ///
    /// # मजकूर दिशात्मकता
    ///
    /// स्ट्रिंग बाइट्सचा क्रम आहे.
    /// 'Left' या संदर्भात त्या बाइट स्ट्रिंगची पहिली स्थिती;'डावीकडून उजवीकडे' ऐवजी 'उजवीकडून डावीकडे' असलेल्या अरबी किंवा हिब्रू भाषेसाठी ही _right_ बाजू असेल, डावी नाही.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// ट्रेलिंग व्हाइटस्पेस काढल्यासह स्ट्रिंग स्लाइस मिळवते.
    ///
    /// 'Whitespace' युनिकोड व्युत्पन्न कोअर प्रॉपर्टी `White_Space` च्या अटींनुसार परिभाषित केले आहे.
    ///
    /// # मजकूर दिशात्मकता
    ///
    /// स्ट्रिंग बाइट्सचा क्रम आहे.
    /// 'Right' या संदर्भात त्या बाइट स्ट्रिंगची शेवटची स्थिती;'डावीकडून उजवीकडे' ऐवजी 'उजवीकडून डावीकडे' असलेल्या अरबी किंवा हिब्रूसारख्या भाषेसाठी, ही _left_ बाजू असेल, उजवीकडे नाही.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// वारंवार काढून टाकलेल्या पॅटर्नशी जुळणार्‍या सर्व प्रत्यय आणि प्रत्ययांसह एक स्ट्रिंग स्लाइस मिळवते.
    ///
    /// [pattern] एक [`char`], [`char`] चे एक तुकडा किंवा एखादा कार्य किंवा क्लोजर असू शकतो जो वर्ण जुळत असेल तर निर्धारित करतो.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// साधे नमुने:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// क्लोजरचा वापर करून एक अधिक जटिल नमुना:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // लवकरात लवकर ज्ञात सामना लक्षात ठेवा, तर ते खाली दुरुस्त करा
            // शेवटचा सामना वेगळा आहे
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // सुरक्षितता: `Searcher` वैध सूचकांक परत करण्यासाठी ज्ञात आहे.
        unsafe { self.get_unchecked(i..j) }
    }

    /// वारंवार काढलेल्या नमुन्याशी जुळणार्‍या सर्व उपसर्गांसह एक स्ट्रिंग स्लाइस मिळवते.
    ///
    /// [pattern] हे `&str`, [`char`], [`char`] चे एक तुकडा किंवा एखादे कार्य किंवा बंदर असू शकते जे वर्ण जुळते की नाही हे निर्धारित करते.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # मजकूर दिशात्मकता
    ///
    /// स्ट्रिंग बाइट्सचा क्रम आहे.
    /// `start` या संदर्भात त्या बाइट स्ट्रिंगची पहिली स्थिती;इंग्रजी किंवा रशियन सारख्या डावीकडून उजवीकडे असलेल्या भाषेसाठी, ही डावीकडील असेल आणि अरबी किंवा हिब्रूसारख्या उजवीकडून डावीकडे भाषांसाठी ही उजवी बाजू असेल.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // सुरक्षितता: `Searcher` वैध सूचकांक परत करण्यासाठी ज्ञात आहे.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// प्रत्यय काढल्यास स्ट्रिंग स्लाइस मिळवते.
    ///
    /// जर स्ट्रिंग `prefix` च्या नमुनासह प्रारंभ होत असेल तर, `Some` मध्ये गुंडाळलेल्या उपसर्गानंतर उपस्ट्रिंग मिळवते.
    /// `trim_start_matches` विपरीत, ही पद्धत एकदाच उपसर्ग काढून टाकते.
    ///
    /// जर स्ट्रिंग `prefix` ने प्रारंभ होत नसेल तर `None` मिळवते.
    ///
    /// [pattern] हे `&str`, [`char`], [`char`] चे एक तुकडा किंवा एखादे कार्य किंवा बंदर असू शकते जे वर्ण जुळते की नाही हे निर्धारित करते.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// प्रत्यय काढून स्ट्रिंग स्लाइस मिळवते.
    ///
    /// जर स्ट्रिंग `suffix` च्या नमुनासह समाप्त होते तर `Some` मध्ये गुंडाळलेले प्रत्ययच्या आधी सबस्ट्रिंग मिळवते.
    /// `trim_end_matches` विपरीत, ही पद्धत प्रत्यय एकदाच काढून टाकते.
    ///
    /// जर स्ट्रिंग `suffix` ने समाप्त होत नसेल तर `None` मिळवते.
    ///
    /// [pattern] हे `&str`, [`char`], [`char`] चे एक तुकडा किंवा एखादे कार्य किंवा बंदर असू शकते जे वर्ण जुळते की नाही हे निर्धारित करते.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// वारंवार काढल्या गेलेल्या नमुनाशी जुळणार्‍या सर्व प्रत्ययांसह स्ट्रिंग स्लाइस मिळवते.
    ///
    /// [pattern] हे `&str`, [`char`], [`char`] चे एक तुकडा किंवा एखादे कार्य किंवा बंदर असू शकते जे वर्ण जुळते की नाही हे निर्धारित करते.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # मजकूर दिशात्मकता
    ///
    /// स्ट्रिंग बाइट्सचा क्रम आहे.
    /// `end` या संदर्भात त्या बाइट स्ट्रिंगची शेवटची स्थिती;डावीकडून उजवीकडे इंग्रजी किंवा रशियन भाषेसाठी ही उजवीकडील बाजू असेल आणि अरबी किंवा हिब्रूसारख्या उजवी-डावी-भाषेसाठी ही डावी बाजू असेल.
    ///
    ///
    /// # Examples
    ///
    /// साधे नमुने:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// क्लोजरचा वापर करून एक अधिक जटिल नमुना:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // सुरक्षितता: `Searcher` वैध सूचकांक परत करण्यासाठी ज्ञात आहे.
        unsafe { self.get_unchecked(0..j) }
    }

    /// वारंवार काढलेल्या नमुन्याशी जुळणार्‍या सर्व उपसर्गांसह एक स्ट्रिंग स्लाइस मिळवते.
    ///
    /// [pattern] हे `&str`, [`char`], [`char`] चे एक तुकडा किंवा एखादे कार्य किंवा बंदर असू शकते जे वर्ण जुळते की नाही हे निर्धारित करते.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # मजकूर दिशात्मकता
    ///
    /// स्ट्रिंग बाइट्सचा क्रम आहे.
    /// 'Left' या संदर्भात त्या बाइट स्ट्रिंगची पहिली स्थिती;'डावीकडून उजवीकडे' ऐवजी 'उजवीकडून डावीकडे' असलेल्या अरबी किंवा हिब्रू भाषेसाठी ही _right_ बाजू असेल, डावी नाही.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// वारंवार काढल्या गेलेल्या नमुनाशी जुळणार्‍या सर्व प्रत्ययांसह स्ट्रिंग स्लाइस मिळवते.
    ///
    /// [pattern] हे `&str`, [`char`], [`char`] चे एक तुकडा किंवा एखादे कार्य किंवा बंदर असू शकते जे वर्ण जुळते की नाही हे निर्धारित करते.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # मजकूर दिशात्मकता
    ///
    /// स्ट्रिंग बाइट्सचा क्रम आहे.
    /// 'Right' या संदर्भात त्या बाइट स्ट्रिंगची शेवटची स्थिती;'डावीकडून उजवीकडे' ऐवजी 'उजवीकडून डावीकडे' असलेल्या अरबी किंवा हिब्रूसारख्या भाषेसाठी, ही _left_ बाजू असेल, उजवीकडे नाही.
    ///
    ///
    /// # Examples
    ///
    /// साधे नमुने:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// क्लोजरचा वापर करून एक अधिक जटिल नमुना:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// ही स्ट्रिंग स्लाइस दुसर्‍या प्रकारात विश्लेषित करते.
    ///
    /// कारण `parse` सामान्य आहे, यामुळे प्रकारासंदर्भात समस्या उद्भवू शकतात.
    /// अशाच प्रकारे, `parse` ही काही वेळा एक वाक्य आहे जी आपणास प्रेमपूर्वक 'turbofish' म्हणून ओळखले जाते: `::<>`.
    ///
    /// हे अनुमान अल्गोरिदमला आपण कोणत्या प्रकारात विश्लेषित करण्याचा प्रयत्न करीत आहात हे विशिष्टपणे समजण्यास मदत करते.
    ///
    /// `parse` [`FromStr`] trait लागू करणार्‍या कोणत्याही प्रकारात विश्लेषण करू शकते.
    ///

    /// # Errors
    ///
    /// ही स्ट्रिंग स्लाइस इच्छित प्रकारात विश्लेषित करणे शक्य नसल्यास [`Err`] परत करेल.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// मूलभूत वापर
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// `four` भाष्य करण्याऐवजी 'turbofish' वापरणे:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// विश्लेषित करण्यात अयशस्वी:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// या स्ट्रिंगमधील सर्व वर्ण एएससीआयआय श्रेणीतील आहेत का ते तपासेल.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // आम्ही येथे प्रत्येक बाईटला चारित्र्याप्रमाणे वागू शकतो: सर्व मल्टीबाइट वर्ण असी श्रेणीत नसलेल्या बाईटपासून सुरू होते, म्हणून आम्ही तिथेच थांबू.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// दोन तार्यांचा एएससीआयआय केस-असंवेदनशील सामना आहे हे तपासते.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` प्रमाणेच, परंतु तात्पुरते वाटप आणि कॉपी केल्याशिवाय.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// या स्ट्रिंगला त्याच्या एएससीआयआय अप्पर केस मध्ये समांतर ठिकाणी रुपांतरित करते.
    ///
    /// 'a' ते 'z' पर्यंत ASCII अक्षरे 'A' ते 'Z' पर्यंत मॅप केली गेली आहेत, परंतु ASCII नसलेली अक्षरे बदलली नाहीत.
    ///
    /// विद्यमान व्हॅल्यू न सुधारता नवीन अप्परकेस मूल्य परत करण्यासाठी, [`to_ascii_uppercase()`] वापरा.
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // सुरक्षाः सुरक्षित कारण आम्ही एकाच लेआउटसह दोन प्रकारांचे संक्रमित करतो.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// या स्ट्रिंगला त्याच्या एएससीआयआय लोअर केसच्या समांतर ठिकाणी रुपांतरित करते.
    ///
    /// 'A' ते 'Z' पर्यंत ASCII अक्षरे 'a' ते 'z' पर्यंत मॅप केली गेली आहेत, परंतु ASCII नसलेली अक्षरे बदलली नाहीत.
    ///
    /// विद्यमान व्हॅल्यू न सुधारता नवीन लोअरकेस मूल्य परत करण्यासाठी, एक्स 100 एक्स वापरा.
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // सुरक्षाः सुरक्षित कारण आम्ही एकाच लेआउटसह दोन प्रकारांचे संक्रमित करतो.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// एक इटरेटर परत द्या जो `self` मधील प्रत्येक चार्टला [`char::escape_debug`] सह पलायन करेल.
    ///
    ///
    /// Note: केवळ स्ट्रिंग सुरू होणारी विस्तारित ग्राफीम कोडेपॉइंट्स सुटतात.
    ///
    /// # Examples
    ///
    /// आयटर म्हणूनः
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// थेट `println!` वापरणे:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// दोन्ही समतुल्य आहेत:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// `to_string` वापरणे:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// एक इटरेटर परत द्या जो `self` मधील प्रत्येक चार्टला [`char::escape_default`] सह पलायन करेल.
    ///
    ///
    /// # Examples
    ///
    /// आयटर म्हणूनः
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// थेट `println!` वापरणे:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// दोन्ही समतुल्य आहेत:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// `to_string` वापरणे:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// एक इटरेटर परत द्या जो `self` मधील प्रत्येक चार्टला [`char::escape_unicode`] सह पलायन करेल.
    ///
    ///
    /// # Examples
    ///
    /// आयटर म्हणूनः
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// थेट `println!` वापरणे:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// दोन्ही समतुल्य आहेत:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// `to_string` वापरणे:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// रिक्त स्ट्रीट तयार करते
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// रिक्त म्युटेबल स्ट्रिंग तयार करते
    #[inline]
    fn default() -> Self {
        // सुरक्षा: रिक्त स्ट्रिंग वैध UTF-8 आहे.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// एक नाव, क्लोन करण्यायोग्य एफएन प्रकार
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // सुरक्षा: सुरक्षित नाही
        unsafe { from_utf8_unchecked(bytes) }
    };
}