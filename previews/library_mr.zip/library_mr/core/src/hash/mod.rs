//! जेनेरिक हॅशिंग समर्थन.
//!
//! हे मॉड्यूल मूल्याच्या [hash] ची गणना करण्याचा सामान्य मार्ग प्रदान करते.
//! हॅशचा वापर बहुधा [`HashMap`] आणि [`HashSet`] सह केला जातो.
//!
//! [hash]: https://en.wikipedia.org/wiki/Hash_function
//! [`HashMap`]: ../../std/collections/struct.HashMap.html
//! [`HashSet`]: ../../std/collections/struct.HashSet.html
//!
//! प्रकार हॅशेबल बनवण्याचा सर्वात सोपा मार्ग म्हणजे एक्स00 एक्स वापरणे:
//!
//! # Examples
//!
//! ```rust
//! use std::collections::hash_map::DefaultHasher;
//! use std::hash::{Hash, Hasher};
//!
//! #[derive(Hash)]
//! struct Person {
//!     id: u32,
//!     name: String,
//!     phone: u64,
//! }
//!
//! let person1 = Person {
//!     id: 5,
//!     name: "Janet".to_string(),
//!     phone: 555_666_7777,
//! };
//! let person2 = Person {
//!     id: 5,
//!     name: "Bob".to_string(),
//!     phone: 555_666_7777,
//! };
//!
//! assert!(calculate_hash(&person1) != calculate_hash(&person2));
//!
//! fn calculate_hash<T: Hash>(t: &T) -> u64 {
//!     let mut s = DefaultHasher::new();
//!     t.hash(&mut s);
//!     s.finish()
//! }
//! ```
//!
//! आपल्याला व्हॅल्यू कसे चालवावे यावर अधिक नियंत्रण हवे असल्यास आपल्याला [`Hash`] trait कार्यान्वित करण्याची आवश्यकता आहे:
//!
//!
//! ```rust
//! use std::collections::hash_map::DefaultHasher;
//! use std::hash::{Hash, Hasher};
//!
//! struct Person {
//!     id: u32,
//!     # #[allow(dead_code)]
//!     name: String,
//!     phone: u64,
//! }
//!
//! impl Hash for Person {
//!     fn hash<H: Hasher>(&self, state: &mut H) {
//!         self.id.hash(state);
//!         self.phone.hash(state);
//!     }
//! }
//!
//! let person1 = Person {
//!     id: 5,
//!     name: "Janet".to_string(),
//!     phone: 555_666_7777,
//! };
//! let person2 = Person {
//!     id: 5,
//!     name: "Bob".to_string(),
//!     phone: 555_666_7777,
//! };
//!
//! assert_eq!(calculate_hash(&person1), calculate_hash(&person2));
//!
//! fn calculate_hash<T: Hash>(t: &T) -> u64 {
//!     let mut s = DefaultHasher::new();
//!     t.hash(&mut s);
//!     s.finish()
//! }
//! ```

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::marker;

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use self::sip::SipHasher;

#[unstable(feature = "hashmap_internals", issue = "none")]
#[allow(deprecated)]
#[doc(hidden)]
pub use self::sip::SipHasher13;

mod sip;

/// हॅशेबल प्रकार
///
/// `Hash` लागू करणारे प्रकार [`Hasher`] च्या उदाहरणासह [`हॅश] एड करण्यात सक्षम आहेत.
///
/// ## एक्स 100 एक्स ची अंमलबजावणी करीत आहे
///
/// सर्व फील्डने `Hash` कार्यान्वित केल्यास आपण `Hash` सह `Hash` मिळवू शकता.
/// परिणामी हॅश प्रत्येक फील्डवर [`hash`] कॉल करण्यापासून मूल्यांचे संयोजन असेल.
///
/// ```
/// #[derive(Hash)]
/// struct Rustacean {
///     name: String,
///     country: String,
/// }
/// ```
///
/// आपणास मूल्य हॅश कसे करावे यावर अधिक नियंत्रण हवे असल्यास आपण स्वत: `Hash` trait स्वतः अंमलात आणू शकताः
///
/// ```
/// use std::hash::{Hash, Hasher};
///
/// struct Person {
///     id: u32,
///     name: String,
///     phone: u64,
/// }
///
/// impl Hash for Person {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         self.id.hash(state);
///         self.phone.hash(state);
///     }
/// }
/// ```
///
/// ## `Hash` आणि `Eq`
///
/// `Hash` आणि [`Eq`] दोन्हीची अंमलबजावणी करताना, खालील मालमत्ता असणे हे महत्वाचे आहे:
///
/// ```text
/// k1 == k2 -> hash(k1) == hash(k2)
/// ```
///
/// दुस words्या शब्दांत, दोन की समान असल्यास, त्यांच्या हॅश देखील समान असणे आवश्यक आहे.
/// [`HashMap`] आणि [`HashSet`] दोघेही या वर्तनवर अवलंबून असतात.
///
/// कृतज्ञतापूर्वक, X001 X आणि `Hash` दोन्ही एक्स 100 एक्स मिळवित असताना आपल्याला या मालमत्तेचे समर्थन करण्याची चिंता करण्याची आवश्यकता नाही.
///
///
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
/// [`HashSet`]: ../../std/collections/struct.HashSet.html
/// [`hash`]: Hash::hash
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Hash {
    /// हे मूल्य दिलेल्या [`Hasher`] मध्ये फीड करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::{Hash, Hasher};
    ///
    /// let mut hasher = DefaultHasher::new();
    /// 7920.hash(&mut hasher);
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn hash<H: Hasher>(&self, state: &mut H);

    /// दिलेल्या [`Hasher`] मध्ये या प्रकाराचा एक तुकडा फीड करतो.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::{Hash, Hasher};
    ///
    /// let mut hasher = DefaultHasher::new();
    /// let numbers = [6, 28, 496, 8128];
    /// Hash::hash_slice(&numbers, &mut hasher);
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    #[stable(feature = "hash_slice", since = "1.3.0")]
    fn hash_slice<H: Hasher>(data: &[Self], state: &mut H)
    where
        Self: Sized,
    {
        for piece in data {
            piece.hash(state);
        }
    }
}

// trait `Hash` शिवाय झेडप्रील्यु00 झेड वरून मॅक्रो एक्स ०१ एक्स एक्सपोर्ट करण्यासाठी मॉड्यूल विभक्त करा.
pub(crate) mod macros {
    /// झेडट्रायट0झेड एक्स 100 एक्सची इम्प्लिअल व्युत्पन्न करणार्‍या डेरिव मॅक्रो.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Hash($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Hash;

/// बाइटचा अनियंत्रित प्रवाह हॅशिंगसाठी झेडट्रेट0 झेड.
///
/// `Hasher` ची उदाहरणे सहसा डेटाचे हॅशिंग करताना बदललेल्या अवस्थेचे प्रतिनिधित्व करतात.
///
/// `Hasher` व्युत्पन्न हॅश पुनर्प्राप्त करण्यासाठी ([`finish`] सह), आणि पूर्णांक लिहिणे तसेच बाइटचे तुकडे (एक्स 100 एक्स आणि एक्स ०१ एक्स इत्यादीसह) करण्यासाठी एक मूलभूत इंटरफेस प्रदान करते.
/// बहुतेक वेळा, `Hasher` घटना [`Hash`] trait च्या संयोगाने वापरली जातात.
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::Hasher;
///
/// let mut hasher = DefaultHasher::new();
///
/// hasher.write_u32(1989);
/// hasher.write_u8(11);
/// hasher.write_u8(9);
/// hasher.write(b"Huh?");
///
/// println!("Hash is {:x}!", hasher.finish());
/// ```
///
/// [`finish`]: Hasher::finish
/// [`write`]: Hasher::write
/// [`write_u8`]: Hasher::write_u8
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Hasher {
    /// आतापर्यंत लिहिलेल्या मूल्यांसाठी हॅश मूल्य मिळवते.
    ///
    /// त्याचे नाव असूनही, ही पद्धत हॅशरची अंतर्गत स्थिती रीसेट करत नाही.
    /// वर्तमान मूल्यापासून अतिरिक्त [`Writ the] चे सुरू राहील.
    /// आपल्याला नवीन हॅश मूल्य सुरू करण्याची आवश्यकता असल्यास आपल्याला नवीन हॅशर तयार करावे लागेल.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::Hasher;
    ///
    /// let mut hasher = DefaultHasher::new();
    /// hasher.write(b"Cool!");
    ///
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    ///
    /// [`write`]: Hasher::write
    #[stable(feature = "rust1", since = "1.0.0")]
    fn finish(&self) -> u64;

    /// या `Hasher` मध्ये काही डेटा लिहितो.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::Hasher;
    ///
    /// let mut hasher = DefaultHasher::new();
    /// let data = [0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef];
    ///
    /// hasher.write(&data);
    ///
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write(&mut self, bytes: &[u8]);

    /// या हॅशरमध्ये एकच `u8` लिहिते.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u8(&mut self, i: u8) {
        self.write(&[i])
    }
    /// या हॅशरमध्ये एकच `u16` लिहिते.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u16(&mut self, i: u16) {
        self.write(&i.to_ne_bytes())
    }
    /// या हॅशरमध्ये एकच `u32` लिहिते.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u32(&mut self, i: u32) {
        self.write(&i.to_ne_bytes())
    }
    /// या हॅशरमध्ये एकच `u64` लिहिते.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u64(&mut self, i: u64) {
        self.write(&i.to_ne_bytes())
    }
    /// या हॅशरमध्ये एकच `u128` लिहिते.
    #[inline]
    #[stable(feature = "i128", since = "1.26.0")]
    fn write_u128(&mut self, i: u128) {
        self.write(&i.to_ne_bytes())
    }
    /// या हॅशरमध्ये एकच `usize` लिहिते.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_usize(&mut self, i: usize) {
        self.write(&i.to_ne_bytes())
    }

    /// या हॅशरमध्ये एकच `i8` लिहिते.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i8(&mut self, i: i8) {
        self.write_u8(i as u8)
    }
    /// या हॅशरमध्ये एकच `i16` लिहिते.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i16(&mut self, i: i16) {
        self.write_u16(i as u16)
    }
    /// या हॅशरमध्ये एकच `i32` लिहिते.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i32(&mut self, i: i32) {
        self.write_u32(i as u32)
    }
    /// या हॅशरमध्ये एकच `i64` लिहिते.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i64(&mut self, i: i64) {
        self.write_u64(i as u64)
    }
    /// या हॅशरमध्ये एकच `i128` लिहिते.
    #[inline]
    #[stable(feature = "i128", since = "1.26.0")]
    fn write_i128(&mut self, i: i128) {
        self.write_u128(i as u128)
    }
    /// या हॅशरमध्ये एकच `isize` लिहिते.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_isize(&mut self, i: isize) {
        self.write_usize(i as usize)
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<H: Hasher + ?Sized> Hasher for &mut H {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

/// [`Hasher`] ची उदाहरणे तयार करण्यासाठी झेडट्रेट0 झेड.
///
/// प्रत्येक कीसाठी [`हॅशेर] चे तयार करण्यासाठी [, हॅशरी] चे स्टेटस स्वतंत्रपणे हॅश केल्या जाणार्‍या `BuildHasher` चा वापर विशेषत: ([`HashMap`] द्वारे) केला जातो.
///
///
/// `BuildHasher` च्या प्रत्येक घटकासाठी, [`build_hasher`] द्वारा निर्मित [`हॅशेर] समान असणे आवश्यक आहे.
/// म्हणजेच, बाइट्सचा समान प्रवाह प्रत्येक हॅशरमध्ये दिल्यास, समान आउटपुट देखील व्युत्पन्न होईल.
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::RandomState;
/// use std::hash::{BuildHasher, Hasher};
///
/// let s = RandomState::new();
/// let mut hasher_1 = s.build_hasher();
/// let mut hasher_2 = s.build_hasher();
///
/// hasher_1.write_u32(8128);
/// hasher_2.write_u32(8128);
///
/// assert_eq!(hasher_1.finish(), hasher_2.finish());
/// ```
///
/// [`build_hasher`]: BuildHasher::build_hasher
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
///
#[stable(since = "1.7.0", feature = "build_hasher")]
pub trait BuildHasher {
    /// हॅशरचा प्रकार तयार केला जाईल.
    #[stable(since = "1.7.0", feature = "build_hasher")]
    type Hasher: Hasher;

    /// नवीन हॅशर तयार करते.
    ///
    /// त्याच उदाहरणावर `build_hasher` वर येणा call्या प्रत्येक कॉलमध्ये एकसारखे [`हॅशेर] चे उत्पन्न केले पाहिजे.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::RandomState;
    /// use std::hash::BuildHasher;
    ///
    /// let s = RandomState::new();
    /// let new_s = s.build_hasher();
    /// ```
    #[stable(since = "1.7.0", feature = "build_hasher")]
    fn build_hasher(&self) -> Self::Hasher;
}

/// [`Hasher`] आणि [`Default`] लागू करणार्‍या प्रकारांसाठी डीफॉल्ट [`BuildHasher`] घटना तयार करण्यासाठी वापरले जाते.
///
/// `BuildHasherDefault<H>` जेव्हा प्रकार `H` [`Hasher`] आणि [`Default`] लागू करतो तेव्हा आपणास अनुरूप [`BuildHasher`] घटना आवश्यक असतात, परंतु कोणतीही व्याख्या केली जात नाही.
///
///
/// कोणताही `BuildHasherDefault` [zero-sized] आहे.हे [`default`][method.default] सह तयार केले जाऊ शकते.
/// [`HashMap`] किंवा [`HashSet`] सह `BuildHasherDefault` वापरताना, हे करण्याची आवश्यकता नाही, कारण ते योग्य [`Default`] उदाहरणे स्वतः लागू करतात.
///
/// # Examples
///
/// यासाठी सानुकूल [`BuildHasher`] निर्दिष्ट करण्यासाठी `BuildHasherDefault` वापरणे
/// [`HashMap`]:
///
/// ```
/// use std::collections::HashMap;
/// use std::hash::{BuildHasherDefault, Hasher};
///
/// #[derive(Default)]
/// struct MyHasher;
///
/// impl Hasher for MyHasher {
///     fn write(&mut self, bytes: &[u8]) {
///         // आपले हॅशिंग अल्गोरिदम येथे जातात!
///        unimplemented!()
///     }
///
///     fn finish(&self) -> u64 {
///         // आपले हॅशिंग अल्गोरिदम येथे जातात!
///         unimplemented!()
///     }
/// }
///
/// type MyBuildHasher = BuildHasherDefault<MyHasher>;
///
/// let hash_map = HashMap::<u32, u32, MyBuildHasher>::default();
/// ```
///
/// [method.default]: BuildHasherDefault::default
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
/// [`HashSet`]: ../../std/collections/struct.HashSet.html
/// [zero-sized]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#zero-sized-types-zsts
///
///
///
///
#[stable(since = "1.7.0", feature = "build_hasher")]
pub struct BuildHasherDefault<H>(marker::PhantomData<H>);

#[stable(since = "1.9.0", feature = "core_impl_debug")]
impl<H> fmt::Debug for BuildHasherDefault<H> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("BuildHasherDefault")
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
impl<H: Default + Hasher> BuildHasher for BuildHasherDefault<H> {
    type Hasher = H;

    fn build_hasher(&self) -> H {
        H::default()
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
impl<H> Clone for BuildHasherDefault<H> {
    fn clone(&self) -> BuildHasherDefault<H> {
        BuildHasherDefault(marker::PhantomData)
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
impl<H> Default for BuildHasherDefault<H> {
    fn default() -> BuildHasherDefault<H> {
        BuildHasherDefault(marker::PhantomData)
    }
}

#[stable(since = "1.29.0", feature = "build_hasher_eq")]
impl<H> PartialEq for BuildHasherDefault<H> {
    fn eq(&self, _other: &BuildHasherDefault<H>) -> bool {
        true
    }
}

#[stable(since = "1.29.0", feature = "build_hasher_eq")]
impl<H> Eq for BuildHasherDefault<H> {}

mod impls {
    use crate::mem;
    use crate::slice;

    use super::*;

    macro_rules! impl_write {
        ($(($ty:ident, $meth:ident),)*) => {$(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Hash for $ty {
                #[inline]
                fn hash<H: Hasher>(&self, state: &mut H) {
                    state.$meth(*self)
                }

                #[inline]
                fn hash_slice<H: Hasher>(data: &[$ty], state: &mut H) {
                    let newlen = data.len() * mem::size_of::<$ty>();
                    let ptr = data.as_ptr() as *const u8;
                    // सुरक्षितता: `ptr` वैध आणि संरेखित आहे, कारण हा मॅक्रो केवळ वापरला गेला आहे
                    // पॅडिंग नसलेल्या संख्यात्मक आदिमांसाठी.
                    // नवीन स्लाइस केवळ X01 एक्स वर पसरली आहे आणि कधीही उत्परिवर्तित होत नाही आणि तिचा एकूण आकार मूळ `data` प्रमाणेच आहे जेणेकरून तो `isize::MAX` पेक्षा जास्त असू शकत नाही.
                    //
                    state.write(unsafe { slice::from_raw_parts(ptr, newlen) })
                }
            }
        )*}
    }

    impl_write! {
        (u8, write_u8),
        (u16, write_u16),
        (u32, write_u32),
        (u64, write_u64),
        (usize, write_usize),
        (i8, write_i8),
        (i16, write_i16),
        (i32, write_i32),
        (i64, write_i64),
        (isize, write_isize),
        (u128, write_u128),
        (i128, write_i128),
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for bool {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write_u8(*self as u8)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for char {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write_u32(*self as u32)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for str {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write(self.as_bytes());
            state.write_u8(0xff)
        }
    }

    #[stable(feature = "never_hash", since = "1.29.0")]
    impl Hash for ! {
        #[inline]
        fn hash<H: Hasher>(&self, _: &mut H) {
            *self
        }
    }

    macro_rules! impl_hash_tuple {
        () => (
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Hash for () {
                #[inline]
                fn hash<H: Hasher>(&self, _state: &mut H) {}
            }
        );

        ( $($name:ident)+) => (
            #[stable(feature = "rust1", since = "1.0.0")]
            impl<$($name: Hash),+> Hash for ($($name,)+) where last_type!($($name,)+): ?Sized {
                #[allow(non_snake_case)]
                #[inline]
                fn hash<S: Hasher>(&self, state: &mut S) {
                    let ($(ref $name,)+) = *self;
                    $($name.hash(state);)+
                }
            }
        );
    }

    macro_rules! last_type {
        ($a:ident,) => { $a };
        ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
    }

    impl_hash_tuple! {}
    impl_hash_tuple! { A }
    impl_hash_tuple! { A B }
    impl_hash_tuple! { A B C }
    impl_hash_tuple! { A B C D }
    impl_hash_tuple! { A B C D E }
    impl_hash_tuple! { A B C D E F }
    impl_hash_tuple! { A B C D E F G }
    impl_hash_tuple! { A B C D E F G H }
    impl_hash_tuple! { A B C D E F G H I }
    impl_hash_tuple! { A B C D E F G H I J }
    impl_hash_tuple! { A B C D E F G H I J K }
    impl_hash_tuple! { A B C D E F G H I J K L }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: Hash> Hash for [T] {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            self.len().hash(state);
            Hash::hash_slice(self, state)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized + Hash> Hash for &T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            (**self).hash(state);
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized + Hash> Hash for &mut T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            (**self).hash(state);
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Hash for *const T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            #[cfg(not(bootstrap))]
            {
                let (address, metadata) = self.to_raw_parts();
                state.write_usize(address as usize);
                metadata.hash(state);
            }
            #[cfg(bootstrap)]
            {
                if mem::size_of::<Self>() == mem::size_of::<usize>() {
                    // पातळ पॉईंटर
                    state.write_usize(*self as *const () as usize);
                } else {
                    // चरबी सूचक सुरक्षितता: आम्ही एक्स 100 एक्स व्यापलेल्या मेमरीमध्ये प्रवेश करीत आहोत जे वैध असल्याची हमी दिलेली आहे.
                    // हे गृहीत धरते की चरबीचे सूचक `(usize, usize)` चे प्रतिनिधित्व केले जाऊ शकते, जे `std` मध्ये करणे सुरक्षित आहे कारण ते शिप केले गेले आहे आणि `rustc` मध्ये चरबी पॉईंटर्सच्या अंमलबजावणीसह समक्रमित ठेवले आहे.
                    //
                    //
                    //
                    //
                    let (a, b) = unsafe { *(self as *const Self as *const (usize, usize)) };
                    state.write_usize(a);
                    state.write_usize(b);
                }
            }
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Hash for *mut T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            #[cfg(not(bootstrap))]
            {
                let (address, metadata) = self.to_raw_parts();
                state.write_usize(address as usize);
                metadata.hash(state);
            }
            #[cfg(bootstrap)]
            {
                if mem::size_of::<Self>() == mem::size_of::<usize>() {
                    // पातळ पॉईंटर
                    state.write_usize(*self as *const () as usize);
                } else {
                    // चरबी सूचक सुरक्षितता: आम्ही एक्स 100 एक्स व्यापलेल्या मेमरीमध्ये प्रवेश करीत आहोत जे वैध असल्याची हमी दिलेली आहे.
                    // हे गृहीत धरते की चरबीचे सूचक `(usize, usize)` चे प्रतिनिधित्व केले जाऊ शकते, जे `std` मध्ये करणे सुरक्षित आहे कारण ते शिप केले गेले आहे आणि `rustc` मध्ये चरबी पॉईंटर्सच्या अंमलबजावणीसह समक्रमित ठेवले आहे.
                    //
                    //
                    //
                    //
                    let (a, b) = unsafe { *(self as *const Self as *const (usize, usize)) };
                    state.write_usize(a);
                    state.write_usize(b);
                }
            }
        }
    }
}