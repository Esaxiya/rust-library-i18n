//! सिपहॅशची अंमलबजावणी.

#![allow(deprecated)] // या मॉड्यूलमधील प्रकारांचा नापसंत केला आहे

use crate::cmp;
use crate::marker::PhantomData;
use crate::mem;
use crate::ptr;

/// सिपहॅश १-1-3 ची अंमलबजावणी.
///
/// हे सध्या मानक लायब्ररीद्वारे वापरलेले डीफॉल्ट हॅशिंग फंक्शन आहे (उदा. `collections::HashMap` डीफॉल्टनुसार ते वापरते).
///
///
/// See: <https://131002.net/siphash>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
#[doc(hidden)]
pub struct SipHasher13 {
    hasher: Hasher<Sip13Rounds>,
}

/// सिपहॅश 2-4 ची अंमलबजावणी.
///
/// See: <https://131002.net/siphash/>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
struct SipHasher24 {
    hasher: Hasher<Sip24Rounds>,
}

/// सिपहॅश 2-4 ची अंमलबजावणी.
///
/// See: <https://131002.net/siphash/>
///
/// सिपहॅश हा एक सामान्य हेतू हॅशिंग फंक्शन आहे: ते चांगल्या वेगाने चालते (स्पूकी आणि सिटीसह स्पर्धात्मक) आणि मजबूत एक्स 100 एक्स हॅशिंगला परवानगी देते.
///
/// हे आपणास आपल्या हॅश सारण्यांना [`rand::os::OsRng`](https://doc.rust-lang.org/rand/rand/os/struct.OsRng.html) सारख्या मजबूत आरएनजी कडून कळवू देते.
///
/// जरी सिपहॅश अल्गोरिदम सामान्यतः मजबूत मानला जात आहे, परंतु तो क्रिप्टोग्राफिक हेतूसाठी नाही.
/// याप्रमाणे, या अंमलबजावणीचे सर्व क्रिप्टोग्राफिक वापर _strongly discouraged_ आहेत.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
pub struct SipHasher(SipHasher24);

#[derive(Debug)]
struct Hasher<S: Sip> {
    k0: u64,
    k1: u64,
    length: usize, // आम्ही किती बाईटवर प्रक्रिया केली
    state: State,  // हॅश राज्य
    tail: u64,     // प्रक्रिया न केलेले बाइट्स ले
    ntail: usize,  // शेपटीत किती बाइट्स वैध आहेत
    _marker: PhantomData<S>,
}

#[derive(Debug, Clone, Copy)]
#[repr(C)]
struct State {
    // v0, v2 आणि v1, v3 अल्गोरिदममध्ये जोड्या दर्शविल्या जातील आणि सिपहॅशची सिमड अंमलबजावणी v02 आणि v13 चे vectors वापरेल.
    //
    // त्यांना या क्रमाने रचनामध्ये ठेवून, कंपाईलर केवळ काही सिम ऑप्टिमायझेशन स्वतःच उचलू शकेल.
    //
    v0: u64,
    v2: u64,
    v1: u64,
    v3: u64,
}

macro_rules! compress {
    ($state:expr) => {{ compress!($state.v0, $state.v1, $state.v2, $state.v3) }};
    ($v0:expr, $v1:expr, $v2:expr, $v3:expr) => {{
        $v0 = $v0.wrapping_add($v1);
        $v1 = $v1.rotate_left(13);
        $v1 ^= $v0;
        $v0 = $v0.rotate_left(32);
        $v2 = $v2.wrapping_add($v3);
        $v3 = $v3.rotate_left(16);
        $v3 ^= $v2;
        $v0 = $v0.wrapping_add($v3);
        $v3 = $v3.rotate_left(21);
        $v3 ^= $v0;
        $v2 = $v2.wrapping_add($v1);
        $v1 = $v1.rotate_left(17);
        $v1 ^= $v2;
        $v2 = $v2.rotate_left(32);
    }};
}

/// बाइट स्ट्रीममधून इच्छित क्रमांकाचा पूर्णांक LE क्रमाने लोड करतो.
/// कंपाईलरला संभाव्यतंत्रांकित-पत्त्यावरून लोड करण्याचा सर्वात प्रभावी मार्ग व्युत्पन्न करण्यासाठी `copy_nonoverlapping` वापरते.
///
///
/// असुरक्षित कारण: i..i+size_of(int_ty) वर चेक न केलेले अनुक्रमणिका
macro_rules! load_int_le {
    ($buf:expr, $i:expr, $int_ty:ident) => {{
        debug_assert!($i + mem::size_of::<$int_ty>() <= $buf.len());
        let mut data = 0 as $int_ty;
        ptr::copy_nonoverlapping(
            $buf.as_ptr().add($i),
            &mut data as *mut _ as *mut u8,
            mem::size_of::<$int_ty>(),
        );
        data.to_le()
    }};
}

/// बाइट स्लाइसचे 7 बाइट पर्यंत u64 X लोड करते.
/// हे अनाड़ी दिसत आहे परंतु `copy_nonoverlapping` कॉल (`load_int_le!` मार्गे) सर्व काही निश्चित आकाराचे असतात आणि `memcpy` वर कॉल करणे टाळतात, जे वेगसाठी चांगले आहे.
///
///
/// असुरक्षित कारण: प्रारंभ न करता चेक केलेला अनुक्रमणिका..स्टार्ट + लेन
#[inline]
unsafe fn u8to64_le(buf: &[u8], start: usize, len: usize) -> u64 {
    debug_assert!(len < 8);
    let mut i = 0; // u64 आउटपुटमध्ये वर्तमान बाइट इंडेक्स (एलएसबी पासून)
    let mut out = 0;
    if i + 3 < len {
        // सुरक्षितता: `i` हे `len` पेक्षा मोठे असू शकत नाही आणि कॉलरने याची हमी दिली पाहिजे
        // की इंडेक्स स्टार्ट..स्टार्ट + लेन हद्दीत आहे.
        out = unsafe { load_int_le!(buf, start + i, u32) } as u64;
        i += 4;
    }
    if i + 1 < len {
        // सुरक्षा: वरील प्रमाणेच.
        out |= (unsafe { load_int_le!(buf, start + i, u16) } as u64) << (i * 8);
        i += 2
    }
    if i < len {
        // सुरक्षा: वरील प्रमाणेच.
        out |= (unsafe { *buf.get_unchecked(start + i) } as u64) << (i * 8);
        i += 1;
    }
    debug_assert_eq!(i, len);
    out
}

impl SipHasher {
    /// दोन प्रारंभिक की 0 वर सेट केल्याने एक नवीन `SipHasher` तयार करते.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher {
        SipHasher::new_with_keys(0, 0)
    }

    /// प्रदान केलेल्या कळा बंद की एक `SipHasher` तयार करते.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher {
        SipHasher(SipHasher24 { hasher: Hasher::new_with_keys(key0, key1) })
    }
}

impl SipHasher13 {
    /// दोन प्रारंभिक की 0 वर सेट केल्याने एक नवीन `SipHasher13` तयार करते.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher13 {
        SipHasher13::new_with_keys(0, 0)
    }

    /// प्रदान केलेल्या कळा बंद की एक `SipHasher13` तयार करते.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher13 {
        SipHasher13 { hasher: Hasher::new_with_keys(key0, key1) }
    }
}

impl<S: Sip> Hasher<S> {
    #[inline]
    fn new_with_keys(key0: u64, key1: u64) -> Hasher<S> {
        let mut state = Hasher {
            k0: key0,
            k1: key1,
            length: 0,
            state: State { v0: 0, v1: 0, v2: 0, v3: 0 },
            tail: 0,
            ntail: 0,
            _marker: PhantomData,
        };
        state.reset();
        state
    }

    #[inline]
    fn reset(&mut self) {
        self.length = 0;
        self.state.v0 = self.k0 ^ 0x736f6d6570736575;
        self.state.v1 = self.k1 ^ 0x646f72616e646f6d;
        self.state.v2 = self.k0 ^ 0x6c7967656e657261;
        self.state.v3 = self.k1 ^ 0x7465646279746573;
        self.ntail = 0;
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl super::Hasher for SipHasher {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.0.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.0.hasher.finish()
    }
}

#[unstable(feature = "hashmap_internals", issue = "none")]
impl super::Hasher for SipHasher13 {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.hasher.finish()
    }
}

impl<S: Sip> super::Hasher for Hasher<S> {
    // Note: कोणतीही पूर्णांक हॅशिंग पद्धती (`Writ_u *`, `write_i*`) परिभाषित केलेली नाहीत
    // या प्रकारासाठी.
    // आम्ही त्यांना जोडू शकलो, librustc_data_structures/sip128.rs मध्ये `short_write` अंमलबजावणीची कॉपी करू आणि `SipHasher`, `SipHasher13` आणि `DefaultHasher` मध्ये `write_u *`/`write_i*` पद्धती जोडा.
    //
    // हे त्या हॅशर्सनी पूर्णांक हॅशिंगला मोठ्या मानाने गती देईल, काही बेंचमार्कांवर कंपाईल वेग थोडासा कमी केल्याने.
    // तपशीलांसाठी #69152 पहा.
    //
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        let length = msg.len();
        self.length += length;

        let mut needed = 0;

        if self.ntail != 0 {
            needed = 8 - self.ntail;
            // सुरक्षितता: X01 एक्सची हमी `length` पेक्षा जास्त नसावी
            self.tail |= unsafe { u8to64_le(msg, 0, cmp::min(length, needed)) } << (8 * self.ntail);
            if length < needed {
                self.ntail += length;
                return;
            } else {
                self.state.v3 ^= self.tail;
                S::c_rounds(&mut self.state);
                self.state.v0 ^= self.tail;
                self.ntail = 0;
            }
        }

        // बफर शेपूट आता फ्लश आहे, नवीन इनपुटवर प्रक्रिया करा.
        let len = length - needed;
        let left = len & 0x7; // लेन% 8

        let mut i = needed;
        while i < len - left {
            // सुरक्षितताः कारण `len - left` हे अंडर 8 मधील सर्वात मोठे गुणक आहे
            // `len`, आणि कारण `i` `needed` पासून प्रारंभ होते जिथे `len` हे `length - needed` आहे, `i + 8` हे `length` पेक्षा कमी किंवा समान असल्याची हमी दिलेली आहे.
            //
            let mi = unsafe { load_int_le!(msg, i, u64) };

            self.state.v3 ^= mi;
            S::c_rounds(&mut self.state);
            self.state.v0 ^= mi;

            i += 8;
        }

        // सुरक्षाः `i` आता `needed + len.div_euclid(8) * 8` आहे,
        // तर `i + left` = `needed + len` = `length`, जे `msg.len()` च्या समान परिभाषानुसार आहे.
        //
        self.tail = unsafe { u8to64_le(msg, i, left) };
        self.ntail = left;
    }

    #[inline]
    fn finish(&self) -> u64 {
        let mut state = self.state;

        let b: u64 = ((self.length as u64 & 0xff) << 56) | self.tail;

        state.v3 ^= b;
        S::c_rounds(&mut state);
        state.v0 ^= b;

        state.v2 ^= 0xff;
        S::d_rounds(&mut state);

        state.v0 ^ state.v1 ^ state.v2 ^ state.v3
    }
}

impl<S: Sip> Clone for Hasher<S> {
    #[inline]
    fn clone(&self) -> Hasher<S> {
        Hasher {
            k0: self.k0,
            k1: self.k1,
            length: self.length,
            state: self.state,
            tail: self.tail,
            ntail: self.ntail,
            _marker: self._marker,
        }
    }
}

impl<S: Sip> Default for Hasher<S> {
    /// दोन प्रारंभिक की 0 वर सेट केल्याने `Hasher<S>` तयार करते.
    #[inline]
    fn default() -> Hasher<S> {
        Hasher::new_with_keys(0, 0)
    }
}

#[doc(hidden)]
trait Sip {
    fn c_rounds(_: &mut State);
    fn d_rounds(_: &mut State);
}

#[derive(Debug, Clone, Default)]
struct Sip13Rounds;

impl Sip for Sip13Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
    }
}

#[derive(Debug, Clone, Default)]
struct Sip24Rounds;

impl Sip for Sip24Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
        compress!(state);
    }
}