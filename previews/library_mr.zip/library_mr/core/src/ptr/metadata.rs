#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// कोणत्याही पॉईंट-टू प्रकाराचा पॉईंटर मेटाडेटा प्रकार प्रदान करते.
///
/// # पॉईंटर मेटाडेटा
///
/// Rust मधील रॉ पॉइंटर प्रकार आणि संदर्भ प्रकारांचा दोन भागांप्रमाणे विचार केला जाऊ शकतो:
/// व्हॅल्यूचा मेमरी पत्ता आणि काही मेटाडेटा असलेले डेटा पॉईंटर.
///
/// स्थिर-आकाराच्या प्रकारांसाठी (जे `Sized` traits लागू करतात) तसेच `extern` प्रकारांसाठी, पॉईंटर्स "पातळ" असे म्हणतात: मेटाडेटा शून्य-आकाराचा आहे आणि त्याचा प्रकार `()` आहे.
///
///
/// [dynamically-sized types][dst] चे पॉईंटर्स "वाइड" किंवा "फॅट" असे म्हणतात, त्यांच्याकडे शून्य-आकाराचे मेटाडेटा नाहीत:
///
/// * ज्या स्ट्रक्चर्सचे शेवटचे फील्ड डीएसटी आहे अशा स्ट्रक्चर्ससाठी मेटाडेटा हे शेवटच्या फील्डसाठी मेटाडेटा आहे
/// * `str` प्रकारासाठी, मेटाडेटा ही बाइट्स मध्ये `usize` लांबीची लांबी आहे
/// * `[T]` सारख्या स्लाईस प्रकारांसाठी, मेटाडेटा ही `usize` म्हणून आयटमची लांबी आहे
/// * `dyn SomeTrait` सारख्या trait वस्तूंसाठी, मेटाडेटा [`DynMetadata<Self>`][DynMetadata] आहे (उदा. `DynMetadata<dyn SomeTrait>`)
///
/// future मध्ये, Rust भाषा नवीन प्रकारचे प्रकार मिळवू शकते ज्यात भिन्न पॉइंटर मेटाडेटा आहे.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// या झेडट्रायट0 झेडचा बिंदू हा त्याचा एक्स 100 एक्स संबंधित प्रकार आहे जो `()` किंवा `usize` किंवा `DynMetadata<_>` वर वर्णन केल्याप्रमाणे आहे.
/// ते प्रत्येक प्रकारासाठी स्वयंचलितपणे अंमलात आणले जाते.
/// अनुरूप बंधनाशिवाय, सर्वसामान्य संदर्भात याची अंमलबजावणी करणे गृहित धरले जाऊ शकते.
///
/// # Usage
///
/// कच्चे पॉइंटर्स त्यांच्या [`to_raw_parts`] पद्धतीने डेटा अ‍ॅड्रेस आणि मेटाडेटा घटकांमध्ये विघटित केले जाऊ शकतात.
///
/// वैकल्पिकरित्या, एकट्या मेटाडेटाला [`metadata`] फंक्शनसह काढले जाऊ शकते.
/// [`metadata`] ला संदर्भ पाठविला जाऊ शकतो आणि त्यास सक्तीने जबरदस्तीने भाग पाडले जाऊ शकते.
///
/// एक (possibly-wide) पॉईंटर त्याच्या पत्त्यावरून आणि एक्स02 एक्स किंवा एक्स 100 एक्स सह मेटाडेटा एकत्र ठेवला जाऊ शकतो.
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// पॉइंटर्समध्ये मेटाडाटासाठी प्रकार आणि एक्स 100 एक्सचा संदर्भ.
    #[lang = "metadata_type"]
    // NOTE: `static_assert_expected_bounds_for_metadata` मध्ये trait bounds ठेवा
    //
    // येथे असलेल्यांसह समक्रमित `library/core/src/ptr/metadata.rs` मध्ये:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// हे झेडट्रायट0 झेड उर्फ लागू करणारे प्रकारांचे निर्देशक `पातळ` आहेत.
///
/// यात स्टॅटिकली-आकार आकाराचे प्रकार आणि एक्स00 एक्स प्रकार समाविष्ट आहेत.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: trait उपनावे भाषेमध्ये स्थिर होण्यापूर्वी हे स्थिर करू नका?
pub trait Thin = Pointee<Metadata = ()>;

/// पॉईंटरचा मेटाडेटा घटक काढा.
///
/// `*mut T`, `&T` किंवा `&mut T` प्रकारची मूल्ये थेट या कार्यात दिली जाऊ शकतात कारण ते स्पष्टपणे `* const T` वर सक्ती करतात.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // सुरक्षितताः * कॉन्स्ट टी पासून `PtrRepr` युनियनकडून मूल्य प्राप्त करणे सुरक्षित आहे
    // आणि PtrComp घटक<T>समान मेमरी लेआउट आहेत.
    // केवळ std ही हमी देऊ शकते.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// डेटा अ‍ॅड्रेस आणि मेटाडेटामधून एक (possibly-wide) कच्चा पॉईंटर तयार करतो.
///
/// हे कार्य सुरक्षित आहे परंतु मिळविलेले पॉईंटर डीरेन्फ्रेंस करण्यासाठी आवश्यक नाही.
/// कापांसाठी, सुरक्षा आवश्यकतांसाठी [`slice::from_raw_parts`] चे दस्तऐवजीकरण पहा.
/// trait ऑब्जेक्ट्ससाठी, मेटाडेटा पॉईंटरवरून समान अंतर्भूत ईरेज्ड प्रकारात आला पाहिजे.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // सुरक्षितताः * कॉन्स्ट टी पासून `PtrRepr` युनियनकडून मूल्य प्राप्त करणे सुरक्षित आहे
    // आणि PtrComp घटक<T>समान मेमरी लेआउट आहेत.
    // केवळ std ही हमी देऊ शकते.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// कच्चे X02 एक्स पॉईन्टरच्या विरूद्ध, एक कच्चा `*mut` पॉईन्टर परत केल्याशिवाय, [`from_raw_parts`] सारखीच कार्यक्षमता पार पाडते.
///
///
/// अधिक तपशीलांसाठी [`from_raw_parts`] चे दस्तऐवजीकरण पहा.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // सुरक्षितताः * कॉन्स्ट टी पासून `PtrRepr` युनियनकडून मूल्य प्राप्त करणे सुरक्षित आहे
    // आणि PtrComp घटक<T>समान मेमरी लेआउट आहेत.
    // केवळ std ही हमी देऊ शकते.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// `T: Copy` बाउंड टाळण्यासाठी मॅन्युअल प्रोम्पल आवश्यक आहे.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// `T: Clone` बाउंड टाळण्यासाठी मॅन्युअल प्रोम्पल आवश्यक आहे.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// `Dyn = dyn SomeTrait` trait ऑब्जेक्ट प्रकारासाठी मेटाडेटा.
///
/// हे व्हीटेबल (व्हर्च्युअल कॉल टेबल) चे एक पॉईंटर आहे जे झेडट्रायट0झेड ऑब्जेक्टमध्ये साठविलेले कॉंक्रीट प्रकार हाताळण्यासाठी सर्व आवश्यक माहितीचे प्रतिनिधित्व करते.
/// व्हीटेबलमध्ये हे समाविष्ट आहेः
///
/// * प्रकार आकार
/// * टाइप संरेखन
/// * प्रकाराच्या एक्स 100 एक्स इम्प्लीकडे निर्देशक (साधा-जुना-डेटासाठी ऑप्ट असू शकेल)
/// * प्रकाराच्या trait च्या अंमलबजावणीसाठी सर्व पद्धतींना सूचित करते
///
/// लक्षात ठेवा की पहिले तीन विशेष आहेत कारण त्यांना कोणत्याही trait ऑब्जेक्टचे वाटप करणे, सोडणे आणि विकृत करणे आवश्यक आहे.
///
/// या संरचनेचे नाव `dyn` trait ऑब्जेक्ट नसलेल्या प्रकारच्या पॅरामीटरसह (उदाहरणार्थ `DynMetadata<u64>`) असले तरी त्या संरचनेचे अर्थपूर्ण मूल्य प्राप्त करणे शक्य नाही.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// सर्व vtables चे सामान्य उपसर्ग.त्यानंतर trait पद्धतींसाठी फंक्शन पॉईंटर्स पाठोपाठ येतो.
///
/// खाजगी अंमलबजावणीचे तपशील `DynMetadata::size_of` इ.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// या वॅटेबलशी संबंधित प्रकाराचा आकार मिळवते.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// या वॅटेबलशी संबंधित प्रकारच्या संरेखन मिळवते.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// `Layout` म्हणून एकत्र आकार आणि संरेखन मिळवते
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // सुरक्षा: कंपाईलरने कॉंक्रीट Rust प्रकारासाठी हे व्हीटेबल उत्सर्जित केले
        // वैध लेआउट असल्याचे ज्ञात आहे.`Layout::for_value` प्रमाणेच तर्क
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// `Dyn: $Trait` मर्यादा टाळण्यासाठी व्यक्तिचलित आवाहन आवश्यक आहे.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}