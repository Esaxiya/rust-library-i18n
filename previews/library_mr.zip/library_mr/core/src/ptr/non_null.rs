use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` परंतु शून्य आणि कोवेरिएंट नाही.
///
/// कच्चे पॉईंटर्सचा वापर करून डेटा स्ट्रक्चर्स बनविताना वापरण्यासाठी ही सहसा योग्य गोष्ट असते, परंतु अतिरिक्त गुणधर्मांमुळे ती वापरणे अधिक धोकादायक असते.आपण `NonNull<T>` वापरावे याची आपल्याला खात्री नसल्यास, फक्त `*mut T` वापरा!
///
/// `*mut T` विपरीत, पॉईंटर नेहमी नॉन-अशक्त असणे आवश्यक आहे, जरी पॉइंटर कधीही डिरेफर केलेले नसते.हे असे आहे जेणेकरुन एनम्स हे निषिद्ध मूल्य भेदभावी म्हणून वापरू शकतील-`Option<NonNull<T>>` चा आकार `* mut T` समान आहे.
/// तथापि, पॉईंटर अजूनही डिंकर्ड नाही तर त्यास लटकवू शकते.
///
/// `*mut T` च्या विपरीत, `NonNull<T>` `T` पेक्षा अधिक कोव्हरियंट म्हणून निवडले गेले.हे कोव्हेरिएंट प्रकार बनवताना एक्स ० एक्सचा वापर करणे शक्य करते, परंतु प्रत्यक्षात कोवळ्या प्रकारचे नसावे अशा प्रकारात वापरल्या गेल्या तर ते निर्भयतेचा धोका दर्शवितात.
/// (उलट तांत्रिकदृष्ट्या असुरक्षितता केवळ असुरक्षित फंक्शन्सना कॉल केल्यामुळे होऊ शकते तरीही एक्स00 एक्स साठी निवड केली गेली.)
///
/// `Box`, `Rc`, `Arc`, `Vec` आणि `LinkedList` सारख्या बर्‍याच सुरक्षित अ‍ॅब्स्ट्रॅक्शनसाठी कोव्हेरियन्स योग्य आहे.हे असे आहे कारण ते एक सार्वजनिक एपीआय प्रदान करतात जे झेडआरस्ट0 झेडच्या सामान्य सामायिक केलेल्या एक्सओआर म्युटेबल नियमांचे अनुसरण करते.
///
/// जर आपला प्रकार सुरक्षितपणे कोवेरियंट होऊ शकत नसेल तर त्यास इन्व्हरियन्स देण्यासाठी काही अतिरिक्त फील्ड असल्याचे सुनिश्चित केले पाहिजे.बहुतेकदा हे फील्ड `PhantomData<Cell<T>>` किंवा `PhantomData<&'a mut T>` सारखे [`PhantomData`] प्रकारचे असेल.
///
/// लक्षात घ्या की `NonNull<T>` मध्ये `&T` साठी `From` घटना आहे.तथापि, हे [`UnsafeCell<T>`] च्या आत उत्परिवर्तन होत नाही तोपर्यंत सामायिक संदर्भातून (अ पासून निर्मित पॉइंटर) बदल करणे ही अपरिभाषित वर्तन आहे हे बदलत नाही.सामायिक केलेल्या संदर्भामधून बदलता येणारा संदर्भ तयार करण्यासाठीही हेच होते.
///
/// हे `From` उदाहरण `UnsafeCell<T>` शिवाय वापरताना, `as_mut` कधीही कॉल केला जात नाही याची खात्री करण्याची आपली जबाबदारी आहे आणि `as_ptr` कधीही उत्परिवर्तनासाठी वापरला जात नाही.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` पॉईंटर्स `Send` नाहीत कारण त्यांनी संदर्भित केलेला डेटा उपनाव असू शकतो.
// एनबी, ही गरज अनावश्यक आहे, परंतु अधिक चांगले त्रुटी संदेश प्रदान केले पाहिजेत.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` पॉईंटर्स `Sync` नाहीत कारण त्यांनी संदर्भित केलेला डेटा उपनाव असू शकतो.
// एनबी, ही गरज अनावश्यक आहे, परंतु अधिक चांगले त्रुटी संदेश प्रदान केले पाहिजेत.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// डँगलिंग केलेले, परंतु चांगले संरेखित केलेले एक नवीन `NonNull` तयार करते.
    ///
    /// हे `Vec::new` प्रमाणे आळशीपणे वाटप केलेल्या प्रकारांच्या आरंभिकतेसाठी उपयुक्त आहे.
    ///
    /// लक्षात ठेवा की पॉइंटर मूल्य संभाव्यत: `T` मध्ये वैध पॉईंटरचे प्रतिनिधित्व करू शकते, याचा अर्थ असा की "not yet initialized" सेन्टिनल मूल्य म्हणून वापरले जाऊ नये.
    /// आळशीपणे वाटप केलेल्या प्रकारांमध्ये इतर काही मार्गांनी आरंभ ट्रॅक करणे आवश्यक आहे.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // सुरक्षितता: एक्स 100 एक्स एक शून्य न वापरलेले परतावे देते जे नंतर कास्ट केले जाते
        // एक * म्युट टी.
        // म्हणून, `ptr` अशक्त नाही आणि new_unchecked() वर कॉल करण्यासाठीच्या अटींचा आदर केला जातो.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// मूल्याचे सामायिक केलेले संदर्भ मिळवते.[`as_ref`] च्या विरोधाभास, यासाठी मूल्य प्रारंभ करणे आवश्यक नाही.
    ///
    /// परिवर्तनीय भागांसाठी [`as_uninit_mut`] पहा.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// ही पद्धत कॉल करताना, आपल्याला हे सुनिश्चित करणे आवश्यक आहे की खालील सर्व सत्य आहेतः
    ///
    /// * पॉईंटर योग्य प्रकारे संरेखित केले जाणे आवश्यक आहे.
    ///
    /// * हे [the module documentation] मध्ये परिभाषित अर्थाने "dereferencable" असणे आवश्यक आहे.
    ///
    /// * आपण Rust चे अलियासिंग नियम अंमलात आणणे आवश्यक आहे, कारण परतलेली आजीवन `'a` अनियंत्रितपणे निवडले गेले आहे आणि डेटाचे वास्तविक जीवनकाळ प्रतिबिंबित करत नाही.
    ///
    ///   विशेषतः, या आजीवन कालावधीसाठी, पॉईंटर ने दर्शविलेली मेमरी बदलू नये (एक्स 100 एक्सच्या व्यतिरिक्त).
    ///
    /// या पद्धतीचा परिणाम न वापरल्यास देखील हे लागू होते!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // सुरक्षितता: कॉलरने हमी देणे आवश्यक आहे की `self` सर्व पूर्ण करेल
        // संदर्भ आवश्यक.
        unsafe { &*self.cast().as_ptr() }
    }

    /// मूल्यासाठी एक अद्वितीय संदर्भ मिळवते.[`as_mut`] च्या विरोधाभास, यासाठी मूल्य प्रारंभ करणे आवश्यक नाही.
    ///
    /// सामायिक केलेल्या भागांसाठी [`as_uninit_ref`] पहा.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// ही पद्धत कॉल करताना, आपल्याला हे सुनिश्चित करणे आवश्यक आहे की खालील सर्व सत्य आहेतः
    ///
    /// * पॉईंटर योग्य प्रकारे संरेखित केले जाणे आवश्यक आहे.
    ///
    /// * हे [the module documentation] मध्ये परिभाषित अर्थाने "dereferencable" असणे आवश्यक आहे.
    ///
    /// * आपण Rust चे अलियासिंग नियम अंमलात आणणे आवश्यक आहे, कारण परतलेली आजीवन `'a` अनियंत्रितपणे निवडले गेले आहे आणि डेटाचे वास्तविक जीवनकाळ प्रतिबिंबित करत नाही.
    ///
    ///   विशेषतः या जीवनकाळात, पॉईंटर ने दर्शविलेली मेमरी इतर पॉईंटरद्वारे प्रवेश करणे (वाचणे किंवा लिखित) करणे आवश्यक नाही.
    ///
    /// या पद्धतीचा परिणाम न वापरल्यास देखील हे लागू होते!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // सुरक्षितता: कॉलरने हमी देणे आवश्यक आहे की `self` सर्व पूर्ण करेल
        // संदर्भ आवश्यक.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// नवीन `NonNull` तयार करते.
    ///
    /// # Safety
    ///
    /// `ptr` शून्य असणे आवश्यक आहे
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // सुरक्षितता: कॉलरने हमी देणे आवश्यक आहे की `ptr` शून्य आहे.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// जर X01 एक्स नल नसल्यास नवीन `NonNull` तयार करते.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // सुरक्षितता: पॉईंटर आधीच तपासलेले आहे आणि रिक्त नाही
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// [`std::ptr::from_raw_parts`] एक्स पॉईन्टरच्या विरूद्ध, `NonNull` पॉईन्टर परत केल्याशिवाय [`std::ptr::from_raw_parts`] सारखीच कार्यक्षमता पार पाडते.
    ///
    ///
    /// अधिक तपशीलांसाठी [`std::ptr::from_raw_parts`] चे दस्तऐवजीकरण पहा.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // सुरक्षितता: `ptr::from::raw_parts_mut` चे निकाल शून्य आहेत कारण `data_address` आहे.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// अ‍ॅड्रेस आणि मेटाडेटा घटकांमधील एक (शक्यतो रुंद) पॉईंटरचे विघटन करा.
    ///
    /// नंतर पॉईंटरची [`NonNull::from_raw_parts`] सह पुनर्रचना केली जाऊ शकते.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// अंतर्निहित `*mut` पॉईंटर मिळवते.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// मूल्याचा सामायिक केलेला संदर्भ मिळवते.मूल्य निर्विवाद करणे शक्य असल्यास, त्याऐवजी [`as_uninit_ref`] वापरणे आवश्यक आहे.
    ///
    /// परिवर्तनीय भागांसाठी [`as_mut`] पहा.
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// ही पद्धत कॉल करताना, आपल्याला हे सुनिश्चित करणे आवश्यक आहे की खालील सर्व सत्य आहेतः
    ///
    /// * पॉईंटर योग्य प्रकारे संरेखित केले जाणे आवश्यक आहे.
    ///
    /// * हे [the module documentation] मध्ये परिभाषित अर्थाने "dereferencable" असणे आवश्यक आहे.
    ///
    /// * पॉईंटरने `T` च्या आरंभिक घटकाकडे निर्देश करणे आवश्यक आहे.
    ///
    /// * आपण Rust चे अलियासिंग नियम अंमलात आणणे आवश्यक आहे, कारण परतलेली आजीवन `'a` अनियंत्रितपणे निवडले गेले आहे आणि डेटाचे वास्तविक जीवनकाळ प्रतिबिंबित करत नाही.
    ///
    ///   विशेषतः, या आजीवन कालावधीसाठी, पॉईंटर ने दर्शविलेली मेमरी बदलू नये (एक्स 100 एक्सच्या व्यतिरिक्त).
    ///
    /// या पद्धतीचा परिणाम न वापरल्यास देखील हे लागू होते!
    /// (आरंभ करण्याबद्दलचा भाग अद्याप पूर्णपणे निश्चित झालेला नाही, परंतु जोपर्यंत तो खरोखर आरंभ झाला आहे याची खात्री करुन घेण्याचा एकमात्र सुरक्षित दृष्टीकोन आहे.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // सुरक्षितता: कॉलरने हमी देणे आवश्यक आहे की `self` सर्व पूर्ण करेल
        // संदर्भ आवश्यक.
        unsafe { &*self.as_ptr() }
    }

    /// मूल्यासाठी एक अद्वितीय संदर्भ मिळवते.मूल्य निर्विवाद करणे शक्य असल्यास, त्याऐवजी [`as_uninit_mut`] वापरणे आवश्यक आहे.
    ///
    /// सामायिक केलेल्या भागांसाठी [`as_ref`] पहा.
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// ही पद्धत कॉल करताना, आपल्याला हे सुनिश्चित करणे आवश्यक आहे की खालील सर्व सत्य आहेतः
    ///
    /// * पॉईंटर योग्य प्रकारे संरेखित केले जाणे आवश्यक आहे.
    ///
    /// * हे [the module documentation] मध्ये परिभाषित अर्थाने "dereferencable" असणे आवश्यक आहे.
    ///
    /// * पॉईंटरने `T` च्या आरंभिक घटकाकडे निर्देश करणे आवश्यक आहे.
    ///
    /// * आपण Rust चे अलियासिंग नियम अंमलात आणणे आवश्यक आहे, कारण परतलेली आजीवन `'a` अनियंत्रितपणे निवडले गेले आहे आणि डेटाचे वास्तविक जीवनकाळ प्रतिबिंबित करत नाही.
    ///
    ///   विशेषतः या जीवनकाळात, पॉईंटर ने दर्शविलेली मेमरी इतर पॉईंटरद्वारे प्रवेश करणे (वाचणे किंवा लिखित) करणे आवश्यक नाही.
    ///
    /// या पद्धतीचा परिणाम न वापरल्यास देखील हे लागू होते!
    /// (आरंभ करण्याबद्दलचा भाग अद्याप पूर्णपणे निश्चित झालेला नाही, परंतु जोपर्यंत तो खरोखर आरंभ झाला आहे याची खात्री करुन घेण्याचा एकमात्र सुरक्षित दृष्टीकोन आहे.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // सुरक्षितता: कॉलरने हमी देणे आवश्यक आहे की `self` सर्व पूर्ण करेल
        // बदलण्यायोग्य संदर्भ आवश्यक.
        unsafe { &mut *self.as_ptr() }
    }

    /// दुसर्‍या प्रकारच्या पॉईंटरवर कास्ट करा.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // सुरक्षितताः `self` एक `NonNull` पॉईंटर आहे जो अपरिहार्यपणे शून्य आहे
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// पातळ पॉइंटर व लांबीमधून नॉन-नल कच्चा स्लाईस तयार करते.
    ///
    /// `len` वितर्क **घटकांची संख्या** आहे, बाइटची संख्या नाही.
    ///
    /// हे कार्य सुरक्षित आहे, परंतु परताव्याचे मूल्य कमी करणे हे असुरक्षित आहे.
    /// स्लाइस सुरक्षा आवश्यकतांसाठी [`slice::from_raw_parts`] चे दस्तऐवजीकरण पहा.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // पहिल्या घटकाकडे निर्देशकासह प्रारंभ करताना स्लाइस पॉईंटर तयार करा
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (लक्षात घ्या की हे उदाहरण कृत्रिमरित्या या पद्धतीचा वापर दर्शविते, परंतु sl स्लाइस=एक्स 100 एक्स द्या
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // सुरक्षितताः `data` एक `NonNull` पॉईंटर आहे जो अपरिहार्यपणे शून्य आहे
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// नॉन-नल कच्च्या स्लाइसची लांबी मिळवते.
    ///
    /// मिळविलेले मूल्य **घटकांची** संख्या आहे, बाइटची संख्या नाही.
    ///
    /// हे कार्य सुरक्षित आहे, तरीही नॉन-नल कच्च्या स्लाइसचा तुकड्यांस महत्त्व नाही कारण पॉईंटरला वैध पत्ता नसतो.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// स्लाइसच्या बफरवर नल नल पॉईंटर मिळवते.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // सुरक्षितता: आम्हाला माहित आहे की `self` अ-शून्य आहे.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// स्लाइसच्या बफरला कच्चा पॉईंटर मिळवते.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// शक्यतो निर्विवाद व्हॅल्यूजच्या स्लाइसचा सामायिक केलेला संदर्भ मिळवते.[`as_ref`] च्या विरोधाभास, यासाठी मूल्य प्रारंभ करणे आवश्यक नाही.
    ///
    /// परिवर्तनीय भागांसाठी [`as_uninit_slice_mut`] पहा.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// ही पद्धत कॉल करताना, आपल्याला हे सुनिश्चित करणे आवश्यक आहे की खालील सर्व सत्य आहेतः
    ///
    /// * अनेक बाइट `ptr.len() * mem::size_of::<T>()` वाचण्यासाठी पॉईंटर [valid] असणे आवश्यक आहे आणि ते योग्यरित्या संरेखित केले जाणे आवश्यक आहे.याचा अर्थ विशेषतःः
    ///
    ///     * या स्लाइसची संपूर्ण मेमरी श्रेणी एकाच वाटप केलेल्या ऑब्जेक्टमध्ये असणे आवश्यक आहे!
    ///       काप एकाधिक वाटप केलेल्या वस्तूंवर कधीही वाढू शकत नाही.
    ///
    ///     * शून्य-लांबीच्या कापांसाठी देखील पॉईंटर संरेखित करणे आवश्यक आहे.
    ///     यामागील एक कारण म्हणजे एनम लेआउट ऑप्टिमायझेशन संरेखित केल्या जाणार्‍या संदर्भांवर (कोणत्याही लांबीच्या तुकड्यांसह) अवलंबून असू शकतात आणि इतर डेटापासून ते वेगळे करू शकत नाहीत.
    ///
    ///     आपण [`NonNull::dangling()`] वापरून शून्य-लांबीच्या कापांसाठी `data` म्हणून वापरण्यायोग्य पॉईंटर मिळवू शकता.
    ///
    /// * स्लाइसचा एकूण आकार `ptr.len() * mem::size_of::<T>()` `isize::MAX` पेक्षा मोठा नसावा.
    ///   [`pointer::offset`] चे सुरक्षितता दस्तऐवजीकरण पहा.
    ///
    /// * आपण Rust चे अलियासिंग नियम अंमलात आणणे आवश्यक आहे, कारण परतलेली आजीवन `'a` अनियंत्रितपणे निवडले गेले आहे आणि डेटाचे वास्तविक जीवनकाळ प्रतिबिंबित करत नाही.
    ///   विशेषतः, या आजीवन कालावधीसाठी, पॉईंटर ने दर्शविलेली मेमरी बदलू नये (एक्स 100 एक्सच्या व्यतिरिक्त).
    ///
    /// या पद्धतीचा परिणाम न वापरल्यास देखील हे लागू होते!
    ///
    /// [`slice::from_raw_parts`] देखील पहा.
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // सुरक्षितता: कॉलरने `as_uninit_slice` साठी सुरक्षितता करार पाळला पाहिजे.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// शक्यतो निर्विवाद व्हॅल्यूजच्या स्लाइसचा अनोखा संदर्भ मिळवते.[`as_mut`] च्या विरोधाभास, यासाठी मूल्य प्रारंभ करणे आवश्यक नाही.
    ///
    /// सामायिक केलेल्या भागांसाठी [`as_uninit_slice`] पहा.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// ही पद्धत कॉल करताना, आपल्याला हे सुनिश्चित करणे आवश्यक आहे की खालील सर्व सत्य आहेतः
    ///
    /// * `ptr.len() * mem::size_of::<T>()` अनेक बाइट्स वाचण्यासाठी आणि लिहिण्यासाठी पॉईंटर [valid] असणे आवश्यक आहे आणि ते योग्यरित्या संरेखित केले जाणे आवश्यक आहे.याचा अर्थ विशेषतःः
    ///
    ///     * या स्लाइसची संपूर्ण मेमरी श्रेणी एकाच वाटप केलेल्या ऑब्जेक्टमध्ये असणे आवश्यक आहे!
    ///       काप एकाधिक वाटप केलेल्या वस्तूंवर कधीही वाढू शकत नाही.
    ///
    ///     * शून्य-लांबीच्या कापांसाठी देखील पॉईंटर संरेखित करणे आवश्यक आहे.
    ///     यामागील एक कारण म्हणजे एनम लेआउट ऑप्टिमायझेशन संरेखित केल्या जाणार्‍या संदर्भांवर (कोणत्याही लांबीच्या तुकड्यांसह) अवलंबून असू शकतात आणि इतर डेटापासून ते वेगळे करू शकत नाहीत.
    ///
    ///     आपण [`NonNull::dangling()`] वापरून शून्य-लांबीच्या कापांसाठी `data` म्हणून वापरण्यायोग्य पॉईंटर मिळवू शकता.
    ///
    /// * स्लाइसचा एकूण आकार `ptr.len() * mem::size_of::<T>()` `isize::MAX` पेक्षा मोठा नसावा.
    ///   [`pointer::offset`] चे सुरक्षितता दस्तऐवजीकरण पहा.
    ///
    /// * आपण Rust चे अलियासिंग नियम अंमलात आणणे आवश्यक आहे, कारण परतलेली आजीवन `'a` अनियंत्रितपणे निवडले गेले आहे आणि डेटाचे वास्तविक जीवनकाळ प्रतिबिंबित करत नाही.
    ///   विशेषतः या जीवनकाळात, पॉईंटर ने दर्शविलेली मेमरी इतर पॉईंटरद्वारे प्रवेश करणे (वाचणे किंवा लिखित) करणे आवश्यक नाही.
    ///
    /// या पद्धतीचा परिणाम न वापरल्यास देखील हे लागू होते!
    ///
    /// [`slice::from_raw_parts_mut`] देखील पहा.
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // हे सुरक्षित आहे कारण एक्स 100 एक्स वाचणे योग्य आहे आणि `memory.len()` अनेक बाइटसाठी लिहिते.
    /// // लक्षात घ्या की येथे सामग्री निर्विवाद करणे शक्य असल्याने येथे `memory.as_mut()` वर कॉल करण्याची परवानगी नाही.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // सुरक्षितता: कॉलरने `as_uninit_slice_mut` साठी सुरक्षितता करार पाळला पाहिजे.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// सीमांची तपासणी न करता घटक किंवा उपपरवानासाठी कच्चा सूचक मिळवते.
    ///
    /// या पद्धतीस आउट-ऑफ-सीमेट इंडेक्ससह कॉल करणे किंवा जेव्हा `self` डीरेफरेन्सेबल नसते तेव्हा *[अपरिभाषित वर्तन]** परिणामी पॉईंटर वापरला नसला तरीही.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // सुरक्षितताः कॉलर हे सुनिश्चित करते की `self` डीरेफरेन्सेबल आहे आणि `index` इन-सीमा आहे.
        // परिणामी, परिणामी पॉईंटर शून्य असू शकत नाही.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // सुरक्षितता: एक अद्वितीय पॉईंटर निरर्थक असू शकत नाही, म्हणून अटी
        // new_unchecked() आदर केला जातो.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // सुरक्षा: एक परिवर्तनीय संदर्भ शून्य असू शकत नाही.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // सुरक्षितता: संदर्भ शून्य असू शकत नाही, म्हणून अटी
        // new_unchecked() आदर केला जातो.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}