use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// कच्चा नॉन-नल एक्स00 एक्स भोवती एक आवरण असे दर्शविते की या रॅपरचा मालक रिझर्व्हचा मालक आहे.
/// `Box<T>`, `Vec<T>`, `String` आणि `HashMap<K, V>` सारख्या अ‍ॅबस्ट्रॅक्शन्ससाठी उपयुक्त.
///
/// `*mut T` विपरीत, `Unique<T>` "as if" वर्तन करते हे `T` चे उदाहरण होते.
/// `T` हे `Send`/`Sync` असल्यास ते `Send`/`Sync` लागू करते.
/// हे असे देखील दर्शविते की `T` च्या उदाहरणाद्वारे कोणत्या प्रकारच्या मजबूत अलियासिंगची अपेक्षा केली जाऊ शकते:
/// पॉईंटरचा वेगळा भाग त्याच्या अद्वितीय मार्गाच्या मालकीशिवाय सुधारित केला जाऊ नये.
///
/// आपल्या हेतूंसाठी `Unique` वापरणे योग्य आहे की नाही याबद्दल आपल्याला अनिश्चित असल्यास, कमकुवत शब्दरचना असलेल्या एक्स एक्स एक्सचा वापर करण्याचा विचार करा.
///
///
/// `*mut T` विपरीत, पॉईंटर नेहमी नॉन-रिकामा असणे आवश्यक आहे, जरी पॉईंटर कधीही डिरेफर केलेले नसते.
/// हे असे आहे जेणेकरुन एनम्स हे निषिद्ध मूल्य भेदभावी म्हणून वापरू शकतील-`Option<Unique<T>>` चे आकार `Unique<T>` इतकेच आहे.
/// तथापि, पॉईंटर अजूनही डिंकर्ड नाही तर त्यास लटकवू शकते.
///
/// `*mut T` विरुध्द, `Unique<T>` हे `T` पेक्षा अधिक कोव्हेरियंट आहे.
/// हे नेहमीच अद्वितीय च्या अलियासिंग आवश्यकतांचे समर्थन करणार्‍या कोणत्याही प्रकारासाठी योग्य असले पाहिजे.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: या मार्करचे भिन्नतेसाठी कोणतेही परिणाम नाहीत, परंतु ते आवश्यक आहे
    // आमच्याकडे तार्किकपणे `T` चे मालक असल्याचे समजण्यासाठी ड्रॉपसाठी.
    //
    // तपशीलांसाठी, पहा:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` `T` `Send` असल्यास पॉईंटर्स `Send` आहेत कारण त्यांचा संदर्भित डेटा एकसमान नसलेला आहे.
/// लक्षात ठेवा की हा अलियासिंग इन्व्हिएरंट प्रकार प्रकाराद्वारे असुरक्षित आहे;एक्स 100 एक्स वापरुन अ‍ॅबस्ट्रॅक्शनने ती अंमलात आणणे आवश्यक आहे.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` `T` `Sync` असल्यास पॉईंटर्स `Sync` आहेत कारण त्यांचा संदर्भित डेटा एकसमान नसलेला आहे.
/// लक्षात ठेवा की हा अलियासिंग इन्व्हिएरंट प्रकार प्रकाराद्वारे असुरक्षित आहे;एक्स 100 एक्स वापरुन अ‍ॅबस्ट्रॅक्शनने ती अंमलात आणणे आवश्यक आहे.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// डँगलिंग केलेले, परंतु चांगले संरेखित केलेले एक नवीन `Unique` तयार करते.
    ///
    /// हे `Vec::new` प्रमाणे आळशीपणे वाटप केलेल्या प्रकारांच्या आरंभिकतेसाठी उपयुक्त आहे.
    ///
    /// लक्षात ठेवा की पॉइंटर मूल्य संभाव्यत: `T` मध्ये वैध पॉईंटरचे प्रतिनिधित्व करू शकते, याचा अर्थ असा की "not yet initialized" सेन्टिनल मूल्य म्हणून वापरले जाऊ नये.
    /// आळशीपणे वाटप केलेल्या प्रकारांमध्ये इतर काही मार्गांनी आरंभ ट्रॅक करणे आवश्यक आहे.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // सुरक्षितता: mem::align_of() एक वैध, शून्य नसलेला पॉईंटर परत करतो.द
        // new_unchecked() कॉल करण्यासाठीच्या अटींचा अशा प्रकारे आदर केला जातो.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// नवीन `Unique` तयार करते.
    ///
    /// # Safety
    ///
    /// `ptr` शून्य असणे आवश्यक आहे
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // सुरक्षितता: कॉलरने हमी देणे आवश्यक आहे की `ptr` शून्य आहे.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// जर X01 एक्स नल नसल्यास नवीन `Unique` तयार करते.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // सुरक्षितता: पॉईंटर आधीच तपासले गेले आहे आणि रिक्त नाही.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// अंतर्निहित `*mut` पॉईंटर मिळवते.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// सामग्रीचा संदर्भ घेतो.
    ///
    /// परिणामी आजीवन स्वत: चे बंधन आहे म्हणूनच हे "as if" चे वर्तन करते हे खरंच टीचे उदाहरण होते जे कर्ज घेतले जात आहे.
    /// जर दीर्घ (unbound) आजीवन आवश्यक असेल तर, `&*my_ptr.as_ptr()` वापरा.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // सुरक्षितता: कॉलरने हमी देणे आवश्यक आहे की `self` सर्व पूर्ण करेल
        // संदर्भ आवश्यक.
        unsafe { &*self.as_ptr() }
    }

    /// सामग्रीचा विपर्यासपणे संदर्भ दर्शवितो.
    ///
    /// परिणामी आजीवन स्वत: चे बंधन आहे म्हणूनच हे "as if" चे वर्तन करते हे खरंच टीचे उदाहरण होते जे कर्ज घेतले जात आहे.
    /// जर दीर्घ (unbound) आजीवन आवश्यक असेल तर, `&mut *my_ptr.as_ptr()` वापरा.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // सुरक्षितता: कॉलरने हमी देणे आवश्यक आहे की `self` सर्व पूर्ण करेल
        // बदलण्यायोग्य संदर्भ आवश्यक.
        unsafe { &mut *self.as_ptr() }
    }

    /// दुसर्‍या प्रकारच्या पॉईंटरवर कास्ट करा.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // सुरक्षितता: Unique::new_unchecked() एक नवीन अनन्य आणि गरजा तयार करते
        // रिकामे होऊ नये यासाठी दिलेला पॉईंटर
        // आपण पॉईंटर म्हणून स्वत: ला जात असल्याने, हे शून्य असू शकत नाही.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // सुरक्षा: एक परिवर्तनीय संदर्भ शून्य असू शकत नाही
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}