//! अ‍ॅरेसाठी एक्स 100 एक्सच्या मालकीचे इटरेटर परिभाषित करते.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// एक मूल्य-मूल्य [array] पुनरावृत्ती करणारा.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// हे अ‍ॅरे आहे ज्यावर आपण पुनरावृत्ती करत आहोत.
    ///
    /// अनुक्रमणिका `i` सह घटक जेथे `alive.start <= i < alive.end` अद्याप प्राप्त झाले नाहीत आणि वैध अ‍ॅरे प्रविष्टी आहेत.
    /// इंडेक्स `i < alive.start` किंवा `i >= alive.end` सह घटक आधीच उत्पन्न केले गेले आहेत आणि यापुढे प्रवेश करणे आवश्यक नाही!ते मृत घटक अगदी पूर्णपणे निर्विवाद अवस्थेत असू शकतात!
    ///
    ///
    /// तर हल्लेखोर हेः
    /// - `data[alive]` जिवंत आहे (म्हणजे वैध घटक आहेत)
    /// - `data[..alive.start]` आणि `data[alive.end..]` मेलेले आहेत (म्हणजे घटक आधीच वाचलेले होते आणि यापुढे स्पर्श केला जाऊ नये!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// `data` मधील घटक जे अद्याप उत्पन्न झाले नाहीत.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// दिलेल्या `array` वर नवीन इटरेटर तयार करते.
    ///
    /// *टीप*: ही पद्धत [`IntoIterator` is implemented for arrays][array-into-iter] नंतर future मध्ये नापसंत केली जाऊ शकते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // `value` चा प्रकार येथे `&i32` ऐवजी `i32` आहे
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // सुरक्षितता: येथे संक्रमण खरोखर सुरक्षित आहे.`MaybeUninit` चे दस्तऐवज
        // promise:
        //
        // > `MaybeUninit<T>` समान आकार आणि संरेखन असण्याची हमी आहे
        // > `T` म्हणून
        //
        // दस्तऐवज अगदी `MaybeUninit<T>` च्या अ‍ॅरेपासून `T` च्या अ‍ॅरेमध्ये संक्रमित दर्शवितो.
        //
        //
        // त्यासह, ही आरंभ आक्रमकांना समाधानी करते.

        // FIXME(LukasKalbertodt): वास्तविक येथे एक्स00 एक्स वापरा, एकदा कॉन्स जेनेरिकसह कार्य करते:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // तोपर्यंत आम्ही वेगळ्या प्रकारची थोडीशी प्रत तयार करण्यासाठी `mem::transmute_copy` वापरू शकतो, त्यानंतर एक्स01 एक्स विसरू जेणेकरून ती सोडली जाणार नाही.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// अद्याप उत्पन्न न झालेल्या सर्व घटकांचा अविचल स्लाइस मिळवते.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // सुरक्षा: आम्हाला माहित आहे की `alive` मधील सर्व घटक योग्यरित्या आरंभ झाले आहेत.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// अद्याप उत्पन्न न झालेल्या सर्व घटकांची म्युटेबल स्लाइस मिळवते.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // सुरक्षा: आम्हाला माहित आहे की `alive` मधील सर्व घटक योग्यरित्या आरंभ झाले आहेत.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // पुढील पुढची अनुक्रमणिका मिळवा.
        //
        // `alive.start` ला 1 ने वाढविणे `alive` संबंधित अनिवार्य राखते.
        // तथापि, या बदलामुळे, थोड्या काळासाठी, सजीव झोन आता एक्स01 एक्स नाही, तर एक्स 100 एक्स आहे.
        //
        self.alive.next().map(|idx| {
            // अ‍ॅरेमधून घटक वाचा.
            // सुरक्षितता: एक्स 100 एक्स हे पूर्वीच्या एक्स01 एक्स प्रदेशातील एक निर्देशांक आहे
            // रचना.हा घटक वाचणे म्हणजे `data[idx]` आता मृत मानले गेले आहे (म्हणजे स्पर्श करू नका).
            // `idx` जिवंत-झोनची सुरूवात म्हणून, सर्व हल्लेखोरांना पुनर्संचयित करून, जिवंत झोन आता पुन्हा X01 एक्स आहे.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // मागून पुढील अनुक्रमणिका मिळवा.
        //
        // `alive.end` 1 ने कमी केल्याने `alive` संबंधित अनिवार्य राखले.
        // तथापि, या बदलामुळे, थोड्या काळासाठी, सजीव झोन आता एक्स01 एक्स नाही, तर एक्स 100 एक्स आहे.
        //
        self.alive.next_back().map(|idx| {
            // अ‍ॅरेमधून घटक वाचा.
            // सुरक्षितता: एक्स 100 एक्स हे पूर्वीच्या एक्स01 एक्स प्रदेशातील एक निर्देशांक आहे
            // रचना.हा घटक वाचणे म्हणजे `data[idx]` आता मृत मानले गेले आहे (म्हणजे स्पर्श करू नका).
            // एक्स 100 एक्स हा जिवंत-झोनचा शेवट होता, सर्व आक्रमकांना पुनर्संचयित करून, जिवंत झोन आता पुन्हा एक्स 0 एक्स आहे.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // सुरक्षितता: हे सुरक्षित आहे: एक्स00 एक्स नक्की उप-स्लाइस परत करेल
        // अद्याप अशा घटकांपैकी जे बाहेर हलवले गेले नाहीत आणि ते सोडले जाणे बाकी आहे.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // आक्रमणकर्त्या-जिवंत.start <=मुळे कधीही भूमिगत होणार नाही
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// पुनरावृत्ती करणारा खरोखरच योग्य लांबीचा अहवाल देतो.
// "alive" घटकांची संख्या (अद्याप उत्पन्न होईल) `alive` श्रेणीची लांबी आहे.
// ही श्रेणी `next` किंवा `next_back` मध्ये लांबीमध्ये कमी केली आहे.
// त्या पद्धतींमध्ये हे नेहमीच 1 ने कमी होते, परंतु केवळ `Some(_)` परत केल्यास.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // टीप, आम्हाला खरोखर तंतोतंत समान जिवंत श्रेणी जुळवून घेण्याची आवश्यकता नाही, म्हणून आम्ही एक्ससेट एक्स कुठेही आहे याची पर्वा न करता ऑफसेट 0 मध्ये क्लोन करू शकतो.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // सर्व जिवंत घटकांचा क्लोन करा.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // नवीन अ‍ॅरेमध्ये क्लोन लिहा, त्यानंतर त्याची सजीव श्रेणी अद्यतनित करा.
            // panics क्लोनिंग करत असल्यास, आम्ही मागील आयटम योग्यरित्या टाकू.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // अद्याप त्या घटकांना मुद्रित करा जे अद्याप उत्पन्न झाले नाहीत: आम्ही यापुढे उत्पादन दिलेल्या घटकांमध्ये प्रवेश करू शकत नाही.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}