//! निश्चित लांबीच्या अ‍ॅरेसाठी `Eq` सारख्या गोष्टींची अंमलबजावणी.
//! अखेरीस, आम्ही सर्व लांबी सामान्य करण्यासाठी सक्षम असावे.
//!
//! *[See also the array primitive type](array).*
//!

#![stable(feature = "core_array", since = "1.36.0")]

use crate::borrow::{Borrow, BorrowMut};
use crate::cmp::Ordering;
use crate::convert::{Infallible, TryFrom};
use crate::fmt;
use crate::hash::{self, Hash};
use crate::iter::TrustedLen;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{Index, IndexMut};
use crate::slice::{Iter, IterMut};

mod iter;

#[stable(feature = "array_value_iter", since = "1.51.0")]
pub use iter::IntoIter;

/// `T` ला संदर्भ 1 लांबीच्या अ‍ॅरेच्या (कॉपी न करता) संदर्भात रुपांतरीत करते.
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_ref<T>(s: &T) -> &[T; 1] {
    // सुरक्षाः `&T` ला `&[T; 1]` मध्ये रुपांतरित करणे आवाज आहे.
    unsafe { &*(s as *const T).cast::<[T; 1]>() }
}

/// लांबी 1 (कॉपी न करता) च्या अ‍ॅरेच्या परिवर्तनीय संदर्भामध्ये `T` चे रूपांतर बदलते.
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_mut<T>(s: &mut T) -> &mut [T; 1] {
    // सुरक्षाः `&mut T` ला `&mut [T; 1]` मध्ये रुपांतरित करणे आवाज आहे.
    unsafe { &mut *(s as *mut T).cast::<[T; 1]>() }
}

/// उपयुक्तता trait केवळ निश्चित आकाराच्या अ‍ॅरेवर लागू केली
///
/// हे झेडट्रायट0 झेड जास्त मेटाडेटा ब्लोट न आणता फिक्स्ड-आकार अ‍ॅरेवर इतर traits अंमलबजावणीसाठी वापरले जाऊ शकते.
///
/// फिक्स-साइज अ‍ॅरेपर्यंत अंमलबजावणी करणार्‍यांना प्रतिबंधित करण्यासाठी trait हे असुरक्षित चिन्हांकित केले आहे.
/// या झेडट्रिट0 झेडचा वापरकर्ता असे मानू शकतो की अंमलबजावणी करणार्‍यांना निश्चित आकाराच्या अ‍ॅरेच्या स्मृतीत अचूक मांडणी असते (उदाहरणार्थ, असुरक्षित प्रारंभसाठी).
///
///
/// लक्षात घ्या की traits [`AsRef`] आणि [`AsMut`] अशा प्रकारच्या प्रकारच्या पद्धती प्रदान करतात ज्या निश्चित-आकारातील अ‍ॅरे असू शकत नाहीत.
/// त्याऐवजी अंमलबजावणी करणार्‍यांनी त्या traits ला प्राधान्य दिले पाहिजे.
///
///
///
#[unstable(feature = "fixed_size_array", issue = "27778")]
pub unsafe trait FixedSizeArray<T> {
    /// अ‍ॅरेला परिवर्तनीय स्लाइसमध्ये रूपांतरित करते
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_slice(&self) -> &[T];
    /// अ‍ॅरेला परिवर्तनीय स्लाइसमध्ये रूपांतरित करते
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_mut_slice(&mut self) -> &mut [T];
}

#[unstable(feature = "fixed_size_array", issue = "27778")]
unsafe impl<T, A: Unsize<[T]>> FixedSizeArray<T> for A {
    #[inline]
    fn as_slice(&self) -> &[T] {
        self
    }
    #[inline]
    fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }
}

/// जेव्हा स्लाइसमधून अ‍ॅरेमध्ये रूपांतरण अयशस्वी होते तेव्हा त्रुटी प्रकार परत आला.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone)]
pub struct TryFromSliceError(());

#[stable(feature = "core_array", since = "1.36.0")]
impl fmt::Display for TryFromSliceError {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self.__description(), f)
    }
}

impl TryFromSliceError {
    #[unstable(
        feature = "array_error_internals",
        reason = "available through Error trait and this method should not \
                     be exposed publicly",
        issue = "none"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "could not convert slice to array"
    }
}

#[stable(feature = "try_from_slice_error", since = "1.36.0")]
impl From<Infallible> for TryFromSliceError {
    fn from(x: Infallible) -> TryFromSliceError {
        match x {}
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsRef<[T]> for [T; N] {
    #[inline]
    fn as_ref(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsMut<[T]> for [T; N] {
    #[inline]
    fn as_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> Borrow<[T]> for [T; N] {
    fn borrow(&self) -> &[T] {
        self
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> BorrowMut<[T]> for [T; N] {
    fn borrow_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<T, const N: usize> TryFrom<&[T]> for [T; N]
where
    T: Copy,
{
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<[T; N], TryFromSliceError> {
        <&Self>::try_from(slice).map(|r| *r)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a [T]> for &'a [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<&[T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_ptr() as *const [T; N];
            // सुरक्षितता: ठीक आहे कारण आम्ही फक्त लांबी बसते हे तपासले आहे
            unsafe { Ok(&*ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a mut [T]> for &'a mut [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &mut [T]) -> Result<&mut [T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_mut_ptr() as *mut [T; N];
            // सुरक्षितता: ठीक आहे कारण आम्ही फक्त लांबी बसते हे तपासले आहे
            unsafe { Ok(&mut *ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, const N: usize> Hash for [T; N] {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        Hash::hash(&self[..], state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for [T; N] {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&&self[..], f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a [T; N] {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a mut [T; N] {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> Index<I> for [T; N]
where
    [T]: Index<I>,
{
    type Output = <[T] as Index<I>>::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(self as &[T], index)
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> IndexMut<I> for [T; N]
where
    [T]: IndexMut<I>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(self as &mut [T], index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B; N]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &[B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&mut [B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&mut [B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&mut [B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &mut [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

// NOTE: कोड फ्लोट कमी करण्यासाठी काही कमी महत्वाच्या इम्प्लीट्स वगळल्या जातात
// _इंपल_स्लाइस_इक 2!{ [A; $N], &'b [B; $N] } __इंपल_स्लाइस_इक 2! { [A; $N], &'b mut [B; $N] }
//

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, const N: usize> Eq for [T; N] {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, const N: usize> PartialOrd for [T; N] {
    #[inline]
    fn partial_cmp(&self, other: &[T; N]) -> Option<Ordering> {
        PartialOrd::partial_cmp(&&self[..], &&other[..])
    }
    #[inline]
    fn lt(&self, other: &[T; N]) -> bool {
        PartialOrd::lt(&&self[..], &&other[..])
    }
    #[inline]
    fn le(&self, other: &[T; N]) -> bool {
        PartialOrd::le(&&self[..], &&other[..])
    }
    #[inline]
    fn ge(&self, other: &[T; N]) -> bool {
        PartialOrd::ge(&&self[..], &&other[..])
    }
    #[inline]
    fn gt(&self, other: &[T; N]) -> bool {
        PartialOrd::gt(&&self[..], &&other[..])
    }
}

/// अ‍ॅरे [lexicographically](Ord#lexicographical-comparison) ची तुलना प्रभावी करते.
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, const N: usize> Ord for [T; N] {
    #[inline]
    fn cmp(&self, other: &[T; N]) -> Ordering {
        Ord::cmp(&&self[..], &&other[..])
    }
}

// डीफॉल्ट इन्सल्स कॉन्स जेनेरिक्ससह केले जाऊ शकत नाही कारण एक्स 100 एक्स ला डीफॉल्ट लागू करण्याची आवश्यकता नसते, आणि भिन्न क्रमांकासाठी भिन्न इम्प्लिक ब्लॉक असणे अद्याप समर्थित नाही.
//
//

macro_rules! array_impl_default {
    {$n:expr, $t:ident $($ts:ident)*} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] where T: Default {
            fn default() -> [T; $n] {
                [$t::default(), $($ts::default()),*]
            }
        }
        array_impl_default!{($n - 1), $($ts)*}
    };
    {$n:expr,} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] {
            fn default() -> [T; $n] { [] }
        }
    };
}

array_impl_default! {32, T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T}

#[lang = "array"]
impl<T, const N: usize> [T; N] {
    /// क्रमाने प्रत्येक घटकास `f` फंक्शनसह `self` सारख्या आकाराचे अ‍ॅरे मिळवते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_map)]
    /// let x = [1, 2, 3];
    /// let y = x.map(|v| v + 1);
    /// assert_eq!(y, [2, 3, 4]);
    ///
    /// let x = [1, 2, 3];
    /// let mut temp = 0;
    /// let y = x.map(|v| { temp += 1; v * temp });
    /// assert_eq!(y, [1, 4, 9]);
    ///
    /// let x = ["Ferris", "Bueller's", "Day", "Off"];
    /// let y = x.map(|v| v.len());
    /// assert_eq!(y, [6, 9, 3, 3]);
    /// ```
    #[unstable(feature = "array_map", issue = "75243")]
    pub fn map<F, U>(self, f: F) -> [U; N]
    where
        F: FnMut(T) -> U,
    {
        // सुरक्षितता: आम्हाला हे माहित आहे की हे पुनरावृत्ती करणारा अचूक `N` देईल
        // items.
        unsafe { collect_into_array_unchecked(&mut IntoIter::new(self).map(f)) }
    }

    /// 'झिप अप' दोन अ‍ॅरे जोड्यांच्या एकाच अ‍ॅरेमध्ये.
    ///
    /// `zip()` एक नवीन अ‍ॅरे मिळवते जिथे प्रत्येक घटक ट्युपल असतो जिथे प्रथम घटक पहिल्या अ‍ॅरेमधून येतो आणि दुसरा घटक दुसर्‍या अ‍ॅरेमधून येतो.
    ///
    /// दुसर्‍या शब्दांत, हे एकामध्ये दोन अ‍ॅरे एकत्र झिप करते.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_zip)]
    /// let x = [1, 2, 3];
    /// let y = [4, 5, 6];
    /// let z = x.zip(y);
    /// assert_eq!(z, [(1, 4), (2, 5), (3, 6)]);
    /// ```
    ///
    #[unstable(feature = "array_zip", issue = "80094")]
    pub fn zip<U>(self, rhs: [U; N]) -> [(T, U); N] {
        let mut iter = IntoIter::new(self).zip(IntoIter::new(rhs));

        // सुरक्षितता: आम्हाला हे माहित आहे की हे पुनरावृत्ती करणारा अचूक `N` देईल
        // items.
        unsafe { collect_into_array_unchecked(&mut iter) }
    }

    /// संपूर्ण अ‍ॅरे असलेली स्लाइस मिळवते.`&s[..]` च्या समतुल्य.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// संपूर्ण अ‍ॅरे असलेली म्युटेबल स्लाइस मिळवते.
    /// `&mut s[..]` च्या समतुल्य.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// प्रत्येक घटक कर्ज घेते आणि `self` सारख्या आकारासह संदर्भाचा अ‍ॅरे मिळवते.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&f64; 3] = floats.each_ref();
    /// assert_eq!(float_refs, [&3.1, &2.7, &-1.0]);
    /// ```
    ///
    /// ही पद्धत विशेषतः उपयुक्त आहे जर एक्स-एक्स एक्स सारख्या इतर पद्धतींसह एकत्र केली गेली असेल.
    /// अशा प्रकारे, मूळ अ‍ॅरेचे घटक `Copy` नसल्यास आपण ते हलविणे टाळू शकता.
    ///
    /// ```
    /// #![feature(array_methods, array_map)]
    ///
    /// let strings = ["Ferris".to_string(), "♥".to_string(), "Rust".to_string()];
    /// let is_ascii = strings.each_ref().map(|s| s.is_ascii());
    /// assert_eq!(is_ascii, [true, false, true]);
    ///
    /// // आम्ही अद्याप मूळ अ‍ॅरेमध्ये प्रवेश करू शकतोः तो हलविला गेला नाही.
    /// assert_eq!(strings.len(), 3);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_ref(&self) -> [&T; N] {
        // सुरक्षितता: आम्हाला हे माहित आहे की हे पुनरावृत्ती करणारा अचूक `N` देईल
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter()) }
    }

    /// प्रत्येक घटकाला परस्परपणे कर्ज घेते आणि `self` सारख्या आकारासह परस्पर बदलांचे returnsरे मिळवते.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let mut floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&mut f64; 3] = floats.each_mut();
    /// *float_refs[0] = 0.0;
    /// assert_eq!(float_refs, [&mut 0.0, &mut 2.7, &mut -1.0]);
    /// assert_eq!(floats, [0.0, 2.7, -1.0]);
    /// ```
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_mut(&mut self) -> [&mut T; N] {
        // सुरक्षितता: आम्हाला हे माहित आहे की हे पुनरावृत्ती करणारा अचूक `N` देईल
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter_mut()) }
    }
}

/// `iter` वरून `N` आयटम खेचते आणि अ‍ॅरे म्हणून त्यांना परत करते.
/// जर इटरेटरने `N` आयटमपेक्षा कमी उत्पन्न दिले तर हे कार्य अपरिभाषित वर्तन दर्शवते.
///
///
/// अधिक माहितीसाठी [`collect_into_array`] पहा.
///
/// # Safety
///
/// `iter` कमीतकमी `N` आयटमची हमी देतो याची हमी देणे या गोष्टीवर अवलंबून आहे.
/// या स्थितीचे उल्लंघन केल्यामुळे अपरिभाषित वर्तन होते.
unsafe fn collect_into_array_unchecked<I, const N: usize>(iter: &mut I) -> [I::Item; N]
where
    // Note: येथे एक्स 100 एक्स हा काही प्रयोग आहे.हे फक्त एक आहे
    // अंतर्गत कार्य, म्हणून हे बंधन एखाद्या वाईट कल्पनेने वळले तर काढण्यासाठी मोकळ्या मनाने.
    // अशा परिस्थितीत, खालच्या बाउंड `debug_assert!` देखील काढण्याचे लक्षात ठेवा!
    //
    I: Iterator + TrustedLen,
{
    debug_assert!(N <= iter.size_hint().1.unwrap_or(usize::MAX));
    debug_assert!(N <= iter.size_hint().0);

    match collect_into_array(iter) {
        Some(array) => array,
        // सुरक्षा: कार्य कराराद्वारे संरक्षित
        None => unsafe { crate::hint::unreachable_unchecked() },
    }
}

/// `iter` वरून `N` आयटम खेचतात आणि अ‍ॅरे म्हणून त्यांना परत करतात.जर इटरेटरने एक्स ०0 एक्स आयटमपेक्षा कमी उत्पन्न दिले तर एक्स00 एक्स परत केले जाईल आणि आधीपासून उत्पन्न झालेल्या सर्व वस्तू सोडल्या जातील.
///
/// इटरटर बदलण्यायोग्य संदर्भ म्हणून पास झाल्यामुळे आणि हे फंक्शन जास्तीत जास्त `N` वेळा एक्स00 एक्स कॉल करते, बाकीचे आयटम पुन्हा मिळविण्यासाठी पुनरावृत्तीकर्ता नंतर वापरला जाऊ शकतो.
///
///
/// जर एक्स 100 एक्स पॅनीक असेल तर इटरेटरद्वारे आधीच उत्पन्न केलेल्या सर्व वस्तू सोडल्या गेल्या आहेत.
///
///
///
///
fn collect_into_array<I, const N: usize>(iter: &mut I) -> Option<[I::Item; N]>
where
    I: Iterator,
{
    if N == 0 {
        // सुरक्षितता: रिक्त अ‍ॅरेमध्ये नेहमीच रहात असते आणि त्यात वैधता नसलेले इन्व्हेंटर्स असतात.
        return unsafe { Some(mem::zeroed()) };
    }

    struct Guard<T, const N: usize> {
        ptr: *mut T,
        initialized: usize,
    }

    impl<T, const N: usize> Drop for Guard<T, N> {
        fn drop(&mut self) {
            debug_assert!(self.initialized <= N);

            let initialized_part = crate::ptr::slice_from_raw_parts_mut(self.ptr, self.initialized);

            // सुरक्षितता: या कच्च्या स्लाइसमध्ये केवळ आरंभिक वस्तू असतील.
            unsafe {
                crate::ptr::drop_in_place(initialized_part);
            }
        }
    }

    let mut array = MaybeUninit::uninit_array::<N>();
    let mut guard: Guard<_, N> =
        Guard { ptr: MaybeUninit::slice_as_mut_ptr(&mut array), initialized: 0 };

    while let Some(item) = iter.next() {
        // सुरक्षितता: `guard.initialized` 0 ने सुरू होते, त्यातील एकाने वाढ केली आहे
        // एन पर्यंत पोहोचल्यावर लूप आणि लूप सोडला जातो (जे एक्स 100 एक्स आहे.
        //
        unsafe {
            array.get_unchecked_mut(guard.initialized).write(item);
        }
        guard.initialized += 1;

        // संपूर्ण अ‍ॅरे प्रारंभ केला आहे का ते तपासा.
        if guard.initialized == N {
            mem::forget(guard);

            // सुरक्षितता: वरील स्थितीत असे दिसून येते की सर्व घटक आहेत
            // initialized.
            let out = unsafe { MaybeUninit::array_assume_init(array) };
            return Some(out);
        }
    }

    // `guard.initialized` `N` पर्यंत पोहोचण्यापूर्वी जर पुनरावृत्ती करणारा संपला असेल तरच हे गाठले जाईल.
    //
    // आधीपासूनच आरंभ केलेले सर्व घटक सोडत `guard` येथे सोडले गेले आहे हे देखील लक्षात घ्या.
    None
}