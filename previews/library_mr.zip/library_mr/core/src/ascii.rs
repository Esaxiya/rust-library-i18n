//! एएससीआयआय तार आणि वर्णांवर ऑपरेशन्स.
//!
//! Rust मधील बहुतेक स्ट्रिंग ऑपरेशन्स UTF-8 तारांवर कार्य करतात.
//! तथापि, काही वेळा विशिष्ट ऑपरेशनसाठी केवळ एएससीआयआय कॅरेक्टर सेटचा विचार करणे अधिक अर्थपूर्ण होते.
//!
//! [`escape_default`] फंक्शन दिलेल्या अक्षराच्या एस्केड आवृत्तीच्या बाइट्सवर इटरेटर प्रदान करते.
//!
//!

#![stable(feature = "core_ascii", since = "1.26.0")]

use crate::fmt;
use crate::iter::FusedIterator;
use crate::ops::Range;
use crate::str::from_utf8_unchecked;

/// बाइटच्या सुटलेल्या आवृत्तीवर एक पुनरावृत्ती करणारा.
///
/// हे `struct` हे [`escape_default`] फंक्शनद्वारे तयार केले गेले आहे.
/// अधिकसाठी त्याचे दस्तऐवजीकरण पहा.
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct EscapeDefault {
    range: Range<usize>,
    data: [u8; 4],
}

/// आयटररेटरला परत करते जे `u8` ची सुटलेली आवृत्ती तयार करते.
///
/// डीफॉल्टची निवड केली गेली आहे जी अक्षरशः उत्पादन करण्यास मदत करते जे झेड सी ++ 0 झेड 11 आणि तत्सम सी-कौटुंबिक भाषांसह विविध भाषांमध्ये कायदेशीर आहेत.
/// अचूक नियमः
///
/// * टॅब `\t` म्हणून निसटला आहे.
/// * `\r` म्हणून कॅरेज रिटर्न सुटला आहे.
/// * लाइन फीड `\n` म्हणून निसटला आहे.
/// * एकल कोट `\'` म्हणून निसटला आहे.
/// * डबल कोट `\"` म्हणून निसटला आहे.
/// * बॅकस्लॅश `\\` म्हणून निसटला आहे.
/// * 'प्रिंट करण्यायोग्य एएससीआयआय' श्रेणीतील कोणतेही वर्ण एक्स ०१ एक्स .. एक्स ००० एक्स समावेशक.
/// * इतर कोणत्याही वर्णांना एक्स 100 एक्स फॉर्मचे हेक्स एस्केप दिले जातात.
/// * युनिकोड पलायन या कार्याद्वारे कधीही व्युत्पन्न होत नाही.
///
/// # Examples
///
/// ```
/// use std::ascii;
///
/// let escaped = ascii::escape_default(b'0').next().unwrap();
/// assert_eq!(b'0', escaped);
///
/// let mut escaped = ascii::escape_default(b'\t');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b't', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\r');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'r', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\n');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'n', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\'');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'\'', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'"');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'"', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\\');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'\\', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\x9d');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'x', escaped.next().unwrap());
/// assert_eq!(b'9', escaped.next().unwrap());
/// assert_eq!(b'd', escaped.next().unwrap());
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn escape_default(c: u8) -> EscapeDefault {
    let (data, len) = match c {
        b'\t' => ([b'\\', b't', 0, 0], 2),
        b'\r' => ([b'\\', b'r', 0, 0], 2),
        b'\n' => ([b'\\', b'n', 0, 0], 2),
        b'\\' => ([b'\\', b'\\', 0, 0], 2),
        b'\'' => ([b'\\', b'\'', 0, 0], 2),
        b'"' => ([b'\\', b'"', 0, 0], 2),
        b'\x20'..=b'\x7e' => ([c, 0, 0, 0], 1),
        _ => ([b'\\', b'x', hexify(c >> 4), hexify(c & 0xf)], 4),
    };

    return EscapeDefault { range: 0..len, data };

    fn hexify(b: u8) -> u8 {
        match b {
            0..=9 => b'0' + b,
            _ => b'a' + b - 10,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Iterator for EscapeDefault {
    type Item = u8;
    fn next(&mut self) -> Option<u8> {
        self.range.next().map(|i| self.data[i])
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.range.size_hint()
    }
    fn last(mut self) -> Option<u8> {
        self.next_back()
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl DoubleEndedIterator for EscapeDefault {
    fn next_back(&mut self) -> Option<u8> {
        self.range.next_back().map(|i| self.data[i])
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ExactSizeIterator for EscapeDefault {}
#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for EscapeDefault {}

#[stable(feature = "ascii_escape_display", since = "1.39.0")]
impl fmt::Display for EscapeDefault {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // सुरक्षितता: ठीक आहे कारण `escape_default` ने केवळ वैध utf-8 डेटा तयार केला आहे
        f.write_str(unsafe { from_utf8_unchecked(&self.data[self.range.clone()]) })
    }
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for EscapeDefault {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("EscapeDefault { .. }")
    }
}