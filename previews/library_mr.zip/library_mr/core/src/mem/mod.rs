//! स्मृती हाताळण्यासाठी मूलभूत कार्ये.
//!
//! या मॉड्यूलमध्ये प्रकारांचे आकार आणि संरेखन शोधणे, मेमरीला प्रारंभ करणे आणि हाताळणे यासाठी कार्य समाविष्ट आहे.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// **डिस्ट्रॅक्टर चालविल्याशिवाय** मूल्याबद्दल मालकी आणि "forgets" घेते.
///
/// मूल्य व्यवस्थापित केलेली कोणतीही संसाधने, जसे की हेप मेमरी किंवा फाईल हँडल, प्रवेश करण्यायोग्य स्थितीत कायमची रेंगाळत राहते.तथापि, याची हमी देत नाही की या मेमरीचे पॉईंटर्स वैध राहतील.
///
/// * आपण मेमरी गळती करू इच्छित असल्यास, [`Box::leak`] पहा.
/// * आपण मेमरीसाठी एक कच्चा पॉईंटर प्राप्त करू इच्छित असल्यास, [`Box::into_raw`] पहा.
/// * आपणास एखादे मूल्य योग्यरित्या निकास करायचे असल्यास, त्याचा डिस्ट्रक्टर चालू करणे, [`mem::drop`] पहा.
///
/// # Safety
///
/// `forget` `unsafe` म्हणून चिन्हांकित केलेले नाही, कारण Rust च्या सुरक्षा हमीमध्ये विध्वंसक नेहमीच चालतील याची हमी समाविष्ट करत नाही.
/// उदाहरणार्थ, प्रोग्राम [`Rc`][rc] चा वापर करून एक संदर्भ चक्र तयार करू शकतो किंवा डिस्ट्रक्टर चालविल्याशिवाय बाहेर पडायला [`process::exit`][exit] वर कॉल करू शकतो.
/// अशा प्रकारे, `mem::forget` ला सुरक्षित कोडमधून परवानगी दिल्यास Rust च्या सुरक्षिततेच्या हमीमध्ये मूलत: बदल होत नाही.
///
/// असे म्हटले आहे की मेमरी किंवा I/O ऑब्जेक्ट्ससारखी संसाधने गळती करणे सामान्यत: अनिष्ट आहे.
/// एफएफआय किंवा असुरक्षित कोडसाठी काही विशिष्ट वापर प्रकरणांमध्ये ही आवश्यकता उद्भवली आहे, परंतु तरीही, एक्स00 एक्स विशेषतः प्राधान्य दिले जाते.
///
/// मूल्य विसरून जाण्याची परवानगी असल्यामुळे आपण लिहिलेल्या कोणत्याही `unsafe` कोडला या संभाव्यतेस अनुमती देणे आवश्यक आहे.आपण मूल्य परत करू शकत नाही आणि कॉलर आवश्यकतेने मूल्य विक्रेता चालवेल अशी अपेक्षा करू शकत नाही.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// `mem::forget` चा अधिकृत सुरक्षित उपयोग `Drop` trait ने कार्यान्वित केलेल्या मूल्याच्या डिस्ट्रक्टरला रोखणे आहे.उदाहरणार्थ, हे एक `File` गळती करेल, म्हणजे
/// व्हेरिएबलने घेतलेल्या जागेची पुन्हा हक्क सांगा परंतु मूळ प्रणाली स्त्रोत कधीही बंद करू नका.
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// मूलभूत स्त्रोताची मालकी पूर्वी Rust च्या बाहेरील कोडमध्ये हस्तांतरित केली जाते तेव्हा हे उपयुक्त आहे, उदाहरणार्थ कच्च्या फाईल वर्णनकर्त्याला सी कोडमध्ये प्रसारित करून.
///
/// # `ManuallyDrop` सह संबंध
///
/// `mem::forget`*स्मृती* मालकी हस्तांतरित करण्यासाठी देखील वापरली जाऊ शकते, असे करणे त्रुटी-प्रवण आहे.
/// [`ManuallyDrop`] त्याऐवजी वापरले पाहिजे.उदाहरणार्थ, या कोडचा विचार करा:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // `v` ची सामग्री वापरून एक `String` तयार करा
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // `v` लीक करा कारण त्याची मेमरी आता `s` द्वारे व्यवस्थापित केली गेली आहे
/// mem::forget(v);  // ERROR, v अवैध आहे आणि फंक्शनला पाठवणे आवश्यक नाही
/// assert_eq!(s, "Az");
/// // `s` सुस्पष्टपणे सोडले गेले आहे आणि त्याची मेमरी कमी झाली आहे.
/// ```
///
/// वरील उदाहरणासह दोन समस्या आहेतः
///
/// * जर एक्स कोड 2 एक्सचे बांधकाम आणि एक्स 0 एक्स एक्स च्या आवाहनामध्ये अधिक कोड जोडला गेला असेल तर त्यामधील एक झेडस्पॅनिक 0 झेड दुहेरी मुक्त होऊ शकते कारण तीच मेमरी एक्स0 3 एक्स आणि एक्स 100 एक्स दोन्ही हाताळली आहे.
/// * `v.as_mut_ptr()` वर कॉल करून आणि डेटाची मालकी `s` वर हस्तांतरित केल्यानंतर, `v` मूल्य अवैध आहे.
/// जरी मूल्य नुकतेच `mem::forget` वर हलविले जाते (जे त्यास तपासणी करणार नाही), काही प्रकारच्या त्यांच्या मूल्यांवर कठोर आवश्यकता असतात ज्या त्यांना झुकताना किंवा त्यापुढे मालकीच्या नसताना अवैध बनवतात.
/// कोणत्याही प्रकारे अवैध मूल्ये वापरणे, त्यांना त्याकडे पाठवणे किंवा कार्येमधून परत करणे यासह अपरिभाषित वर्तन बनवते आणि कंपाईलरद्वारे केलेल्या समजांना खंडित करू शकते.
///
/// `ManuallyDrop` वर स्विच करणे दोन्ही समस्या टाळते:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // आम्ही `v` च्या कच्च्या भागांमध्ये विभक्त करण्यापूर्वी, ते सोडले जाणार नाही याची खात्री करा!
/////
/// let mut v = ManuallyDrop::new(v);
/// // आता एक्स00 एक्स निराकरण करा.ही ऑपरेशन्स panic करू शकत नाहीत, म्हणून तेथे गळती होऊ शकत नाही.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // शेवटी, एक `String` तयार करा.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` सुस्पष्टपणे सोडले गेले आहे आणि त्याची मेमरी कमी झाली आहे.
/// ```
///
/// `ManuallyDrop` जोरदारपणे दुहेरी-मुक्त प्रतिबंधित करते कारण आम्ही काहीही करण्यापूर्वी. v` चा विध्वंसक अक्षम करतो.
/// `mem::forget()` याला अनुमती देत नाही कारण तो आपला युक्तिवाद वापरतो, आम्हाला केवळ `v` मधून काहीही काढल्यानंतर कॉल करण्यास भाग पाडते.
/// जरी `ManuallyDrop` च्या बांधकाम आणि स्ट्रिंग (जे दर्शविल्यानुसार कोडमध्ये घडू शकत नाही) बनवण्या दरम्यान झेडस्पॅनिक 0 झेडचा परिचय झाला असला तरी त्याचा परिणाम गळती होईल आणि डबल फ्री नाही.
/// दुसर्‍या शब्दांत, एक्स (एस) सोडण्याच्या (डबल-) च्या बाजूला चुकण्याऐवजी लीकच्या बाजूला चुकले.
///
/// तसेच, एक्स 100 एक्स मालकी हद्द `s` वर हस्तांतरित केल्यानंतर "touch" `v` होण्यापासून प्रतिबंधित करते-विनाशक चालविल्याशिवाय त्याची विल्हेवाट लावण्यासाठी एक्स04 एक्सशी संवाद साधण्याचे अंतिम चरण पूर्णपणे टाळले जाते.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// [`forget`] प्रमाणेच, परंतु असुरक्षित मूल्ये देखील स्वीकारते.
///
/// जेव्हा हे एक्स 100 एक्स वैशिष्ट्य स्थिर होते तेव्हा काढले जाण्याचा हेतू हा फंक्शन फक्त एक शिम आहे.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// बाइटमधील प्रकाराचा आकार मिळवते.
///
/// अधिक विशेष म्हणजे, संरेखन पॅडिंगसह त्या आयटम प्रकारासह अ‍ॅरेमधील लागोपाठ घटकांमधील हे ऑफसेट आहे.
///
/// अशाप्रकारे, कोणत्याही प्रकारच्या एक्स ०3 एक्स आणि लांबीच्या एक्स ०१ एक्ससाठी, एक्स ०२ एक्समध्ये एक्स २०० एक्सचा आकार आहे.
///
/// सर्वसाधारणपणे, संकलनांच्या प्रकारात प्रकाराचे आकार स्थिर नसते, परंतु विशिष्ट प्रकारचे आदिम असतात.
///
/// खालील सारणी आदिमांसाठी आकार देते.
///
/// प्रकार |आकार_को: :\<Type>()
/// ---- | ---------------
/// () |0 झेडबूल0झेड |1 एक्स 100 एक्स |1 एक्स01 एक्स |2 एक्स02 एक्स |4 एक्स03 एक्स |8 u128 |16 एक्स04 एक्स |1 एक्स05 एक्स |2 एक्स06 एक्स |4 एक्स07 एक्स |8 आय 128 |16 एक्स08 एक्स |4 एक्स0 9 एक्स |8 चार |4
///
/// शिवाय, `usize` आणि `isize` चा आकार समान आहे.
///
/// `*const T`, `&T`, `Box<T>`, `Option<&T>` आणि `Option<Box<T>>` या सर्व प्रकारांचे आकार समान आहेत.
/// जर एक्स ०१ एक्स आकारमान असेल तर त्या सर्व प्रकारांचा एक्स एक्स एक्स आकार समान आहे.
///
/// पॉईंटरचे परिवर्तनशीलता त्याचा आकार बदलत नाही.अशाच प्रकारे, `&T` आणि `&mut T` समान आकाराचे आहेत.
/// त्याचप्रमाणे `*const T` आणि `* mut T` साठी.
///
/// # `#[repr(C)]` आयटमचा आकार
///
/// आयटमसाठी एक्स 100 एक्स प्रतिनिधित्वामध्ये परिभाषित लेआउट असते.
/// या लेआउटसह, सर्व फील्डमध्ये स्थिर आकार जोपर्यंत आयटमचा आकार देखील स्थिर असतो.
///
/// ## स्ट्रक्चर्सचा आकार
///
/// `structs` साठी, आकार खालील अल्गोरिदम द्वारे निर्धारित केला जातो.
///
/// स्ट्रक्चरच्या प्रत्येक फील्डसाठी डिक्लरेशन ऑर्डरद्वारे ऑर्डर केलेलेः
///
/// 1. शेताचा आकार जोडा.
/// 2. पुढच्या फील्डच्या [alignment] च्या सर्वात जवळच्या एकाधिकपर्यंत वर्तमान आकाराचा गोल करा.
///
/// शेवटी, स्ट्रक्चा आकार त्याच्या [alignment] च्या जवळच्या एकाधिकवर गोल करा.
/// स्ट्रक्चे संरेखन सहसा त्याच्या सर्व क्षेत्रांचे सर्वात मोठे संरेखन असते;हे `repr(align(N))` च्या वापराने बदलले जाऊ शकते.
///
/// `C` विपरीत, शून्य आकाराच्या स्ट्रिक्स आकारात एका बाईटपर्यंत गोल केले जात नाहीत.
///
/// ## एनमचा आकार
///
/// ज्या एनममध्ये भेदभावाशिवाय इतर कोणताही डेटा नसतो त्यांचे प्लॅटफॉर्मवर सी एम्म्स सारखे आकार असतात.
///
/// ## युनियनचा आकार
///
/// युनियनचा आकार त्याच्या सर्वात मोठ्या क्षेत्राचा आकार असतो.
///
/// `C` विपरीत, शून्य आकाराच्या युनियन आकारात एक बाइट पर्यंत गोलाकार नाहीत.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // काही आदिम
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // काही अ‍ॅरे
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // पॉइंटर आकार समानता
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// `#[repr(C)]` वापरत आहे.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // पहिल्या फील्डचा आकार 1 आहे, म्हणून 1 आकारात जोडा.आकार 1 आहे.
/// // दुसर्‍या फील्डचे संरेखन 2 आहे, म्हणून पॅडिंगसाठी 1 आकार जोडा.आकार 2 आहे.
/// // दुसर्‍या फील्डचा आकार 2 आहे, म्हणून 2 आकारात जोडा.आकार 4 आहे.
/// // तिसर्‍या फील्डचे संरेखन 1 आहे, म्हणून पॅडिंगसाठी आकारात 0 जोडा.आकार 4 आहे.
/// // तिसर्‍या फील्डचा आकार 1 आहे, म्हणून 1 आकारात जोडा.आकार 5 आहे.
/// // शेवटी, संरचनेचे संरेखन 2 आहे (कारण त्यातील क्षेत्रांमधील सर्वात मोठे संरेखन 2 आहे), म्हणून पॅडिंगसाठी 1 आकार जोडा.
/// // आकार 6 आहे.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // टपल स्ट्रक्ट्स त्याच नियमांचे पालन करतात.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // लक्षात ठेवा फील्ड्सचे ऑर्डर करण्यामुळे आकार कमी होऊ शकतो.
/// // आम्ही X001 च्या आधी `third` लावून दोन्ही पॅडिंग बाइट्स काढू शकतो.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // युनियन आकार सर्वात मोठ्या क्षेत्राचा आकार आहे.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// बाइटमधील पॉईंट-टू मूल्याचे आकार मिळवते.
///
/// हे सहसा `size_of::<T>()` सारखेच असते.
/// तथापि, जेव्हा `T` * चा कोणताही स्थिर-ज्ञात आकार नसतो, उदा. स्लाइस [`[T]`][slice] किंवा [trait object], तेव्हा डायनॅमिकली-ज्ञात आकार मिळविण्यासाठी एक्स 0 एक्सचा वापर केला जाऊ शकतो.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // सुरक्षितता: `val` हा एक संदर्भ आहे, म्हणून हा वैध कच्चा सूचक आहे
    unsafe { intrinsics::size_of_val(val) }
}

/// बाइटमधील पॉईंट-टू मूल्याचे आकार मिळवते.
///
/// हे सहसा `size_of::<T>()` सारखेच असते.तथापि, जेव्हा `T` * चा कोणताही स्थिर-ज्ञात आकार नसतो, उदा. स्लाइस [`[T]`][slice] किंवा X01 एक्स, तेव्हा डायनॅमिकली-ज्ञात आकार मिळविण्यासाठी एक्स 0 4 एक्सचा वापर केला जाऊ शकतो.
///
/// # Safety
///
/// खाली दिलेल्या अटी धरून असल्यास हे फंक्शन फक्त कॉल करण्यासाठीच सुरक्षित आहेः
///
/// - जर `T` हे `Sized` असेल तर हे फंक्शन कॉल करण्यासाठी नेहमीच सुरक्षित असते.
/// - जर `T` ची आकार नसलेली शेपटी असेल तर:
///     - एक X01 एक्स, नंतर स्लाइस शेपटीची लांबी एक आरंभिक पूर्णांक असणे आवश्यक आहे आणि *संपूर्ण मूल्य*(डायनॅमिक शेपूट लांबी + स्थिर आकाराचे उपसर्ग) चा आकार `isize` मध्ये फिट असणे आवश्यक आहे.
///     - एक X01 एक्स, नंतर पॉईंटरच्या व्हेटेबल भागाने अनसाइझिंग सक्तीने विकत घेतलेल्या वैध vtable कडे निर्देश करणे आवश्यक आहे आणि *संपूर्ण मूल्य*(डायनॅमिक शेपूट लांबी + स्थिर आकाराचे उपसर्ग) आकार `isize` मध्ये फिट असणे आवश्यक आहे.
///
///     - एक (unstable) [extern type], नंतर हे फंक्शन कॉल करण्यासाठी नेहमीच सुरक्षित असते, परंतु बाह्य प्रकारच्या लेआउट माहित नसल्यामुळे panic किंवा अन्यथा चुकीचे मूल्य परत येऊ शकते.
///     बाह्य प्रकारच्या शेपटीसह प्रकाराच्या संदर्भात हेच [`size_of_val`] सारखेच वर्तन आहे.
///     - अन्यथा, हे कार्य करण्यासाठी कॉल करण्यासाठी पुराणमतवादी अनुमती नाही.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // सुरक्षितता: कॉलरने वैध कच्चा सूचक प्रदान करणे आवश्यक आहे
    unsafe { intrinsics::size_of_val(val) }
}

/// प्रकाराचे [एबीआय] आवश्यक किमान संरेखन मिळवते.
///
/// `T` प्रकाराच्या मूल्याचे प्रत्येक संदर्भ या संख्येचे गुणक असणे आवश्यक आहे.
///
/// हे स्ट्रक्चर फील्डसाठी वापरले जाणारे संरेखन आहे.हे प्राधान्य संरेखित पेक्षा लहान असू शकते.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// `val` ने निर्देश केलेल्या मूल्याच्या प्रकाराचे [एबीआय] आवश्यक किमान संरेखन मिळवते.
///
/// `T` प्रकाराच्या मूल्याचे प्रत्येक संदर्भ या संख्येचे गुणक असणे आवश्यक आहे.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // सुरक्षा: व्हॅल एक संदर्भ आहे, म्हणून हा एक वैध कच्चा सूचक आहे
    unsafe { intrinsics::min_align_of_val(val) }
}

/// प्रकाराचे [एबीआय] आवश्यक किमान संरेखन मिळवते.
///
/// `T` प्रकाराच्या मूल्याचे प्रत्येक संदर्भ या संख्येचे गुणक असणे आवश्यक आहे.
///
/// हे स्ट्रक्चर फील्डसाठी वापरले जाणारे संरेखन आहे.हे प्राधान्य संरेखित पेक्षा लहान असू शकते.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// `val` ने निर्देश केलेल्या मूल्याच्या प्रकाराचे [एबीआय] आवश्यक किमान संरेखन मिळवते.
///
/// `T` प्रकाराच्या मूल्याचे प्रत्येक संदर्भ या संख्येचे गुणक असणे आवश्यक आहे.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // सुरक्षा: व्हॅल एक संदर्भ आहे, म्हणून हा एक वैध कच्चा सूचक आहे
    unsafe { intrinsics::min_align_of_val(val) }
}

/// `val` ने निर्देश केलेल्या मूल्याच्या प्रकाराचे [एबीआय] आवश्यक किमान संरेखन मिळवते.
///
/// `T` प्रकाराच्या मूल्याचे प्रत्येक संदर्भ या संख्येचे गुणक असणे आवश्यक आहे.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// खाली दिलेल्या अटी धरून असल्यास हे फंक्शन फक्त कॉल करण्यासाठीच सुरक्षित आहेः
///
/// - जर `T` हे `Sized` असेल तर हे फंक्शन कॉल करण्यासाठी नेहमीच सुरक्षित असते.
/// - जर `T` ची आकार नसलेली शेपटी असेल तर:
///     - एक X01 एक्स, नंतर स्लाइस शेपटीची लांबी एक आरंभिक पूर्णांक असणे आवश्यक आहे आणि *संपूर्ण मूल्य*(डायनॅमिक शेपूट लांबी + स्थिर आकाराचे उपसर्ग) चा आकार `isize` मध्ये फिट असणे आवश्यक आहे.
///     - एक X01 एक्स, नंतर पॉईंटरच्या व्हेटेबल भागाने अनसाइझिंग सक्तीने विकत घेतलेल्या वैध vtable कडे निर्देश करणे आवश्यक आहे आणि *संपूर्ण मूल्य*(डायनॅमिक शेपूट लांबी + स्थिर आकाराचे उपसर्ग) आकार `isize` मध्ये फिट असणे आवश्यक आहे.
///
///     - एक (unstable) [extern type], नंतर हे फंक्शन कॉल करण्यासाठी नेहमीच सुरक्षित असते, परंतु बाह्य प्रकारच्या लेआउट माहित नसल्यामुळे panic किंवा अन्यथा चुकीचे मूल्य परत येऊ शकते.
///     बाह्य प्रकारच्या शेपटीसह प्रकाराच्या संदर्भात हेच [`align_of_val`] सारखेच वर्तन आहे.
///     - अन्यथा, हे कार्य करण्यासाठी कॉल करण्यासाठी पुराणमतवादी अनुमती नाही.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // सुरक्षितता: कॉलरने वैध कच्चा सूचक प्रदान करणे आवश्यक आहे
    unsafe { intrinsics::min_align_of_val(val) }
}

/// `T` प्रकारची मूल्ये सोडल्यास `true` मिळवते.
///
/// हा पूर्णपणे ऑप्टिमायझेशन इशारा आहे आणि याला पुराणमतवादी अंमलबजावणी केली जाऊ शकते:
/// हे अशा प्रकारच्या `true` परत येऊ शकते ज्यास प्रत्यक्षात सोडण्याची आवश्यकता नाही.
/// जसे की नेहमी परत `true` परत करणे ही या कार्याची वैध अंमलबजावणी होईल.तथापि हे कार्य खरोखर `false` परत केल्यास आपल्यास असे निश्चितपणे सोडता येईल की `T` सोडण्याचे कोणतेही दुष्परिणाम नाहीत.
///
/// संकलनासारख्या गोष्टींची निम्न स्तरीय अंमलबजावणी, ज्यांना त्यांचा डेटा व्यक्तिचलितपणे खाली टाकण्याची आवश्यकता आहे, जेव्हा हे नष्ट होते तेव्हा अनावश्यकपणे त्यांची सर्व सामग्री टाकण्याचा प्रयत्न टाळण्यासाठी हे कार्य वापरावे.
///
/// कदाचित रिलीझ बिल्डमध्ये फरक पडणार नाही (जेथे साइड-इफेक्ट नसतील अशी पळवाट सहजपणे शोधली जाते आणि नष्ट केली जाते) परंतु डीबग बिल्डसाठी बहुधा मोठा विजय असतो.
///
/// लक्षात घ्या की [`drop_in_place`] आधीपासून ही तपासणी करीत आहे, म्हणून जर आपले वर्कलोड काही [`drop_in_place`] कॉलमध्ये कमी केले जाऊ शकते तर हे वापरणे अनावश्यक आहे.
/// विशेषतः लक्षात घ्या की आपण एक स्लाईस [`drop_in_place`] करू शकता आणि ते सर्व मूल्यांसाठी एकल गरजा_ड्रॉप करेल.
///
/// वेकसारखे प्रकार म्हणून एक्स ०१ एक्सचा स्पष्टपणे वापर न करता फक्त `drop_in_place(&mut self[..])`.
/// दुसरीकडे [`HashMap`] सारख्या वेळी एकाच वेळी मूल्ये सोडली पाहिजेत आणि हे एपीआय वापरावे.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// संग्रहाने `needs_drop` चा कसा वापर करायचा याचे एक उदाहरण येथे आहे:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // डेटा ड्रॉप करा
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// सर्व-शून्य बाइट-नमुनाद्वारे प्रतिनिधित्व केलेल्या `T` प्रकाराचे मूल्य मिळवते.
///
/// याचा अर्थ असा की, उदाहरणार्थ, `(u8, u16)` मधील पॅडिंग बाइट शून्य नसणे आवश्यक आहे.
///
/// अशी कोणतीही हमी नाही की एक सर्व-शून्य बाइट-नमुना काही प्रकारचे `T` चे वैध मूल्य दर्शवते.
/// उदाहरणार्थ, ऑल-शून्य बाइट-नमुना संदर्भ प्रकार (`&T`, `&mut T`) आणि कार्ये पॉईंटर्ससाठी वैध मूल्य नाही.
/// अशा प्रकारच्या `zeroed` चा वापर केल्यामुळे त्वरित [undefined behavior][ub] होते कारण [the Rust compiler assumes][inv] की ते नेहमीच आरंभिक मानणार्‍या चलात वैध मूल्य असतात.
///
///
/// याचा प्रभाव [`MaybeUninit::zeroed().assume_init()`][zeroed] प्रमाणेच आहे.
/// हे कधीकधी एफएफआयसाठी उपयुक्त असते, परंतु सामान्यत: टाळावे.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// या कार्याचा अचूक वापर: पूर्णांक शून्यासह प्रारंभ करणे.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *या कार्याचा चुकीचा* वापर: शून्यासह संदर्भ आरंभ करणे.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // अपरिभाषित वर्तन!
/// let _y: fn() = unsafe { mem::zeroed() }; // आणि पुन्हा!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // सुरक्षितता: कॉलरने हमी दिली पाहिजे की `T` साठी सर्व-शून्य मूल्य वैध आहे.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// अजिबात काहीही न करता `T` प्रकारची व्हॅल्यू तयार करण्याचे भासवून बायपास, झेड रस्ट ० झेडच्या सामान्य मेमरी-इनिशिएलायझेशन तपासणी करते.
///
/// **हे कार्य नापसंत केले आहे.** त्याऐवजी [`MaybeUninit<T>`] वापरा.
///
/// घसारा होण्याचे कारण असे आहे की मूलत: हे फंक्शन योग्यरित्या वापरले जाऊ शकत नाही: याचा प्रभाव [`MaybeUninit::uninit().assume_init()`][uninit] प्रमाणेच आहे.
///
/// [`assume_init` documentation][assume_init] स्पष्ट केल्यानुसार, मूल्ये योग्यरित्या आरंभ केल्या गेलेल्या [the Rust compiler assumes][inv].
/// याचा परिणाम म्हणून, कॉल करणे उदा
/// `mem::uninitialized::<bool>()` `bool` परत करण्यासाठी त्वरित अपरिभाषित वर्तन कारणीभूत ठरते जे निश्चितपणे `true` किंवा `false` नाही.
/// सर्वात वाईट म्हणजे, खरोखर परत न करता येणारी मेमरी जसे परत मिळते ती विशेष आहे कारण कंपाईलरला हे ठाऊक आहे की त्याचे निश्चित मूल्य नाही.
/// हे व्हेरिएबलमध्ये पूर्णांक प्रकार असला तरीही व्हेरिएबलमध्ये बिनविभाजित डेटा ठेवणे यास अपरिभाषित वर्तन करते.
/// (लक्षात घ्या की बिनविभाजित पूर्णांकांविषयीचे नियम अद्याप अंतिम झाले नाहीत, परंतु जोपर्यंत ते आहेत तोपर्यंत त्यांना टाळण्याचा सल्ला दिला जाईल.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // सुरक्षितता: कॉलरने हमी देणे आवश्यक आहे की युनिटियलाइज्ड मूल्य `T` साठी वैध आहे.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// एकाही डीनाइटीलायझेशनशिवाय, दोन बदलण्यायोग्य ठिकाणी मूल्ये अदलाबदल करतात.
///
/// * आपण डीफॉल्ट किंवा डमी मूल्यासह स्वॅप करू इच्छित असल्यास, [`take`] पहा.
/// * जर आपण उत्तीर्ण केलेल्या मूल्यासह स्वॅप करू इच्छित असाल तर, जुने मूल्य परत करत असल्यास, [`replace`] पहा.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // सुरक्षितता: कच्चे पॉईंटर्स सुरक्षित बदलण्यायोग्य संदर्भांपासून तयार केले गेले आहेत जे सर्व समाधानकारक आहेत
    // `ptr::swap_nonoverlapping_one` वर निर्बंध
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// `dest` ला आधीच्या `dest` मूल्य परत करून, `T` च्या डीफॉल्ट मूल्यासह पुनर्स्थित करते.
///
/// * आपण दोन चलांचे मूल्य बदलू इच्छित असल्यास, [`swap`] पहा.
/// * आपण डीफॉल्ट मूल्याऐवजी उत्तीर्ण केलेल्या मूल्यासह पुनर्स्थित करू इच्छित असल्यास, [`replace`] पहा.
///
/// # Examples
///
/// एक साधे उदाहरणः
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` स्ट्रक्चर फील्डची "empty" व्हॅल्यू बदलवून त्याची मालकी घेण्यास परवानगी देते.
/// `take` शिवाय आपण यासारख्या समस्यांकडे जाऊ शकता:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// लक्षात घ्या की `T` आवश्यकपणे [`Clone`] अंमलबजावणी करीत नाही, म्हणून ते क्लोन करुन देखील `self.buf` रीसेट करू शकत नाही.
/// परंतु `take` याचा उपयोग X002 वरून एक्स02 एक्सचे मूळ मूल्य काढून टाकण्यासाठी केला जाऊ शकतो, ज्यामुळे ते परत येऊ शकेल:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// मागील `dest` मूल्य परत करून, `src` संदर्भित `dest` मध्ये हलवते.
///
/// दोन्हीही मूल्य सोडले जात नाही.
///
/// * आपण दोन चलांचे मूल्य बदलू इच्छित असल्यास, [`swap`] पहा.
/// * आपण डीफॉल्ट मूल्यासह पुनर्स्थित करू इच्छित असल्यास, [`take`] पहा.
///
/// # Examples
///
/// एक साधे उदाहरणः
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` स्ट्रक्चर फील्डला त्यास दुसर्‍या व्हॅल्यूसह बदलून वापरण्यास परवानगी देते.
/// `replace` शिवाय आपण यासारख्या समस्यांकडे जाऊ शकता:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// लक्षात घ्या की `T` [`Clone`] ची अंमलबजावणी करत नाही, म्हणून आम्ही हलविणे टाळण्यासाठी `self.buf[i]` क्लोन देखील करू शकत नाही.
/// परंतु एक्स 0 एक्स एक्सचा वापर मूळ निर्देशास त्या एक्सएक्सएक्समधून परत करण्यास परवानगी देऊन विभक्त करण्यासाठी केला जाऊ शकतो:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // सुरक्षितताः आम्ही `dest` मधून वाचतो परंतु त्यानंतर त्यामध्ये थेट `src` लिहितो,
    // जसे की जुने मूल्य डुप्लिकेट केलेले नाही.
    // काहीही सोडले जात नाही आणि येथे काहीही panic करू शकत नाही.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// मूल्याची विल्हेवाट लावणे
///
/// [`Drop`][drop] च्या युक्तिवादाच्या अंमलबजावणीला कॉल करुन हे होते.
///
/// हे `Copy` कार्यान्वित करणार्या प्रकारांसाठी प्रभावीपणे काहीही करीत नाही, उदा
/// integers.
/// अशी मूल्ये कॉपी केली जातात आणि एक्स 100 एक्स फंक्शनमध्ये हलविल्या जातात, म्हणून या फंक्शन कॉलनंतर मूल्य टिकून राहते.
///
///
/// हे कार्य जादू नाही;हे अक्षरशः म्हणून परिभाषित केले आहे
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// कारण `_x` फंक्शनमध्ये हलविला गेला आहे, फंक्शन परत येण्यापूर्वी ते आपोआप सोडले जाईल.
///
/// [drop]: Drop
///
/// # Examples
///
/// मूलभूत वापर:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // स्पष्टपणे vector ड्रॉप करा
/// ```
///
/// [`RefCell`] रनटाइमवेळी कर्ज घेण्याची नियमांची अंमलबजावणी करत असल्याने, `drop` एक [`RefCell`] कर्ज रिलीझ करू शकते:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // या स्लॉटवर परस्पर बदल रद्द करा
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// [`Copy`] ची अंमलबजावणी करणारी पूर्णांक आणि इतर प्रकार `drop` द्वारे अप्रभावित आहेत.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // `x` ची प्रत हलविली आणि सोडली
/// drop(y); // `y` ची प्रत हलविली आणि सोडली
///
/// println!("x: {}, y: {}", x, y.0); // अजूनही उपलब्ध
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// `src` चे प्रकार म्हणजे `&U` असे असते आणि नंतर समाविष्ट केलेले मूल्य न हलवता `src` वाचते.
///
/// हे कार्य असुरक्षितपणे असे गृहीत घेईल की `&T` ला `&U` मध्ये रुपांतरित करून [`size_of::<U>`][size_of] बाइटसाठी `src` वैध आहे आणि नंतर `&U` वाचणे (हे सोडल्यास `&U` `&T` पेक्षा कठोर संरेखन आवश्यकता बनविते तरीही हे योग्य प्रकारे केले जाते).
/// हे असुरक्षितपणे `src` च्या बाहेर जाण्याऐवजी अंतर्भूत मूल्याची एक प्रत तयार करेल.
///
/// `T` आणि `U` चे आकार वेगवेगळे असल्यास ही कंपाईल-टाइम त्रुटी नाही, परंतु केवळ `T` आणि `U` समान आकाराचे हे कार्य करण्यास प्रोत्साहित केले जाते.`U` हे `T` पेक्षा मोठे असल्यास हे कार्य [undefined behavior][ub] ट्रिगर करते.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // 'foo_array' वरून डेटा कॉपी करा आणि त्यास 'Foo' समजून घ्या
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // कॉपी केलेला डेटा सुधारित करा
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // 'foo_array' ची सामग्री बदलू नये
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // जर यू ला उच्च संरेखन आवश्यक असेल तर, src योग्यरित्या संरेखित केले जाऊ शकत नाही.
    if align_of::<U>() > align_of::<T>() {
        // सुरक्षितता: `src` हा एक संदर्भ आहे जो वाचनांसाठी वैध असल्याची हमी दिलेली आहे.
        // कॉलरने हमी देणे आवश्यक आहे की वास्तविक रूपांतरण सुरक्षित आहे.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // सुरक्षितता: `src` हा एक संदर्भ आहे जो वाचनांसाठी वैध असल्याची हमी दिलेली आहे.
        // आम्ही नुकतेच तपासले की `src as *const U` योग्य प्रकारे संरेखित केले आहे.
        // कॉलरने हमी देणे आवश्यक आहे की वास्तविक रूपांतरण सुरक्षित आहे.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// एनमच्या भेदभावाचे प्रतिनिधित्व करणारे अस्पष्ट प्रकार.
///
/// अधिक माहितीसाठी या मॉड्यूलमधील एक्स 100 एक्स कार्य पहा.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. हे trait अंमलबजावणी व्युत्पन्न केली जाऊ शकत नाहीत कारण आम्हाला टी वर काही मर्यादा नको आहेत.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// `v` मधील एनम प्रकार निश्चितपणे ओळखण्यासाठी मूल्य मिळवते.
///
/// जर एक्स 100 एक्स एनम नसल्यास, या फंक्शनला कॉल केल्याने अपरिभाषित वर्तन होणार नाही परंतु परतावा मूल्य अनिर्दिष्ट आहे.
///
///
/// # Stability
///
/// एनम परिभाषा बदलल्यास एनम प्रकारातील भेदभाव बदलू शकतो.
/// समान कंपाईलरसह संकलनांमध्ये काही प्रकारांचा भेदभाव बदलणार नाही.
///
/// # Examples
///
/// वास्तविक डेटाकडे दुर्लक्ष करताना डेटा वापरणार्‍या एनमची तुलना करण्यासाठी याचा वापर केला जाऊ शकतो:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// एनम प्रकार `T` मधील रूपांची संख्या मिळवते.
///
/// जर एक्स 100 एक्स एनम नसल्यास, या फंक्शनला कॉल केल्याने अपरिभाषित वर्तन होणार नाही परंतु परतावा मूल्य अनिर्दिष्ट आहे.
/// तितकेच, जर `T` हे एक्स ०१ एक्सपेक्षा जास्त रूपे असलेले एनम असेल तर परतावा मूल्य अनिर्दिष्ट असेल.
/// निर्जन रूपे मोजली जातील.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}