use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// आपोआप `T` चा डिस्ट्रॅक्टर कॉल करण्यापासून कंपाइलरला प्रतिबंधित करण्यासाठी एक आवरण.
/// हे रॅपर 0-किंमतीचे आहे.
///
/// `ManuallyDrop<T>` हे `T` सारख्याच लेआउट ऑप्टिमायझेशनच्या अधीन आहे.
/// एक परिणाम म्हणून, कंपाईलरने त्यातील सामग्रीबद्दल केलेल्या समजुतींवर त्याचा काही परिणाम होत नाही.
/// उदाहरणार्थ, [`mem::zeroed`] सह `ManuallyDrop<&mut T>` प्रारंभ करणे अपरिभाषित वर्तन आहे.
/// जर आपल्याला बेबनाव डेटा हाताळण्याची आवश्यकता असेल तर त्याऐवजी [`MaybeUninit<T>`] वापरा.
///
/// लक्षात घ्या की `ManuallyDrop<T>` मधील मूल्यात प्रवेश करणे सुरक्षित आहे.
/// याचा अर्थ असा की `ManuallyDrop<T>` ज्यांची सामग्री टाकली गेली आहे ती सार्वजनिक सुरक्षित API द्वारे उघडकीस आणू नये.
/// त्यानुसार, `ManuallyDrop::drop` असुरक्षित आहे.
///
/// # `ManuallyDrop` आणि ड्रॉप ऑर्डर.
///
/// झेडआरस्ट0 झेडमध्ये मूल्येची एक परिभाषित [drop order] आहे.
/// एका विशिष्ट क्रमाने फील्ड किंवा स्थानिक लोक वगळले गेले आहेत हे सुनिश्चित करण्यासाठी, घोषित घोषणांची पुनर्क्रमित करा की अंतर्निहित ड्रॉप ऑर्डर योग्य असेल.
///
/// ड्रॉप ऑर्डरवर नियंत्रण ठेवण्यासाठी `ManuallyDrop` वापरणे शक्य आहे, परंतु यासाठी असुरक्षित कोड आवश्यक आहे आणि अनइंडिंगच्या उपस्थितीत योग्यरित्या करणे कठीण आहे.
///
///
/// उदाहरणार्थ, आपण इतरांनंतर विशिष्ट फील्ड टाकल्याचे सुनिश्चित करायचे असल्यास त्यास संरचनेचे शेवटचे फील्ड बनवा:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` `children` नंतर सोडले जाईल.
///     // Rust हमी देते की फील्ड्स घोषित करण्याच्या क्रमाने सोडली जातात.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// व्यक्तिचलितपणे सोडले जाणारे मूल्य लपेटून घ्या.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // आपण अद्याप मूल्यावर सुरक्षितपणे ऑपरेट करू शकता
    /// assert_eq!(*x, "Hello");
    /// // परंतु येथे `Drop` चालविला जाणार नाही
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// `ManuallyDrop` कंटेनरमधून मूल्य काढते.
    ///
    /// हे पुन्हा व्हॅल्यू सोडण्याची परवानगी देते.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // हे `Box` ड्रॉप करते.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// `ManuallyDrop<T>` कंटेनरमधून मूल्य मिळविते.
    ///
    /// ही पद्धत प्रामुख्याने ड्रॉपमध्ये मूल्ये हलविण्यासाठी आहे.
    /// मूल्य स्वहस्ते ड्रॉप करण्यासाठी [`ManuallyDrop::drop`] वापरण्याऐवजी आपण मूल्य घेण्यासाठी ही पद्धत वापरू शकता आणि इच्छित असल्यास ती वापरू शकता.
    ///
    /// जेव्हा शक्य असेल तेव्हा त्याऐवजी [`into_inner`][`ManuallyDrop::into_inner`] वापरणे अधिक श्रेयस्कर आहे, जे एक्स 100 एक्सची सामग्री डुप्लिकेट करण्यास प्रतिबंधित करते.
    ///
    ///
    /// # Safety
    ///
    /// हे कार्य पुढील वापर प्रतिबंधित न करता अंतर्भूत मूल्य बाहेर आणते, या कंटेनरची स्थिती न बदलता.
    /// हे `ManuallyDrop` पुन्हा वापरणार नाही याची खात्री करण्याची आपली जबाबदारी आहे.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // सुरक्षाः आम्ही एका संदर्भातून वाचत आहोत, याची हमी दिलेली आहे
        // वाचण्यासाठी वैध असणे.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// अंतर्भूत मूल्य मॅन्युअली ड्रॉप करते.हे समाविष्ट असलेल्या मूल्याच्या पॉईंटरसह [`ptr::drop_in_place`] वर कॉल करण्यासारखेच आहे.
    /// जसे की, जोपर्यंत असलेली व्हॅल्यू पॅक केलेली स्ट्रक्चर्स नाही तोपर्यंत डिस्ट्रॅक्टरला व्हॅल्यू न हलवता त्या जागेवर कॉल केले जाईल आणि म्हणूनच [pinned] डेटा सुरक्षितपणे ड्रॉप करण्यासाठी वापरला जाऊ शकतो.
    ///
    /// आपल्याकडे मूल्याची मालकी असल्यास आपण त्याऐवजी [`ManuallyDrop::into_inner`] वापरू शकता.
    ///
    /// # Safety
    ///
    /// हे फंक्शन अंतर्भूत मूल्याचे डिस्ट्रक्टर चालवते.
    /// डिस्ट्रक्टरने स्वतः केलेले बदल वगळता, मेमरी अपरिवर्तित सोडली जाते आणि म्हणूनच कंपाईलरमध्ये अजूनही थोडासा नमुना आहे जो एक्स 100 एक्स प्रकारास वैध आहे.
    ///
    ///
    /// तथापि, हे "zombie" मूल्य सुरक्षित कोडवर उघड केले जाऊ नये आणि हे कार्य एकापेक्षा जास्त वेळा कॉल केले जाऊ नये.
    /// ते सोडल्यानंतर मूल्य वापरण्यासाठी किंवा मूल्य बहुविध वेळा ड्रॉप केल्याने अपरिभाषित वर्तणूक होऊ शकते (`drop` काय करते यावर अवलंबून).
    /// हे सामान्यत: टाइप सिस्टमद्वारे प्रतिबंधित केले जाते, परंतु `ManuallyDrop` च्या वापरकर्त्यांनी कंपाइलरच्या मदतीशिवाय त्या हमीचे समर्थन केले पाहिजे.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // सुरक्षितता: आम्ही बदलण्यायोग्य संदर्भाद्वारे दर्शविलेले मूल्य सोडत आहोत
        // जे लेखनास वैध असण्याची हमी आहे.
        // हे सांगण्यावर अवलंबून आहे की `slot` पुन्हा सोडला नाही.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}