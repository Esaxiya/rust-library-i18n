use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// एक्स 100 एक्स चे निर्विवाद उदाहरण तयार करण्यासाठी एक रॅपर प्रकार.
///
/// # प्रारंभ आरंभिक
///
/// कंपाईलर, सर्वसाधारणपणे असे गृहित धरते की व्हेरिएबलच्या प्रकारच्या आवश्यकतेनुसार व्हेरिएबल योग्यरित्या आरंभ केला जातो.उदाहरणार्थ, संदर्भ प्रकाराचे एक व्हेरिएबल संरेखित आणि एनयूएलएल नसलेले असणे आवश्यक आहे.
/// हा एक अनियंत्रक आहे जो असुरक्षित कोडमध्ये देखील *नेहमी* समर्थित केला गेला पाहिजे.
/// याचा परिणाम म्हणून, संदर्भ प्रकारात व्हेरिएबलचे शून्य-आरंभ केल्याने त्वरित [undefined behavior][ub] कारणीभूत ठरते, जरी तो संदर्भ मेमरीमध्ये प्रवेश करण्यासाठी कधीही वापरला जात नाही तरीही:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // अपरिभाषित वर्तन!⚠️
/// // `MaybeUninit<&i32>` सह समकक्ष कोडः
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // अपरिभाषित वर्तन!⚠️
/// ```
///
/// हे विविध ऑप्टिमायझेशनसाठी कंपाईलरद्वारे शोषण केले जाते, जसे की रन-टाइम चेक एलिडींग आणि एक्स 100 एक्स लेआउट ऑप्टिमाइझ करणे.
///
/// त्याचप्रमाणे, संपूर्णपणे निर्विवाद स्मृतीत कोणतीही सामग्री असू शकते, तर `bool` नेहमीच `true` किंवा `false` असणे आवश्यक आहे.म्हणूनच, निर्विवाद `bool` तयार करणे हे अपरिभाषित वर्तन आहे:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // अपरिभाषित वर्तन!⚠️
/// // `MaybeUninit<bool>` सह समकक्ष कोडः
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // अपरिभाषित वर्तन!⚠️
/// ```
///
/// शिवाय, अननिटिटलाइझ्ड मेमरी विशेष आहे ज्यामध्ये त्याचे निश्चित मूल्य नसते (एक्स 100 एक्स अर्थ एक्स01 एक्स).एकाच वेळी एकाचवेळी न वापरलेले बाइट वाचणे भिन्न परिणाम देऊ शकते.
/// हे व्हेरिएबलमध्ये पूर्णांक प्रकार नसले तरीही व्हेरिएबलमध्ये बिनविभाषित डेटा ठेवणे हे वर्तनला अपरिभाषित वर्तन करते, जे अन्यथा कोणताही *निश्चित* बिट नमुना ठेवू शकते:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // अपरिभाषित वर्तन!⚠️
/// // `MaybeUninit<i32>` सह समकक्ष कोडः
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // अपरिभाषित वर्तन!⚠️
/// ```
/// (लक्षात घ्या की बिनविभाजित पूर्णांकांविषयीचे नियम अद्याप अंतिम झाले नाहीत, परंतु जोपर्यंत ते आहेत तोपर्यंत त्यांना टाळण्याचा सल्ला दिला जाईल.)
///
/// त्याउलट, लक्षात ठेवा की बहुतेक प्रकारांमध्ये अतिरिक्त पातळी आहेत केवळ प्रकार पातळीवर आरंभिक मानले जाऊ नये.
/// उदाहरणार्थ, `1`-आरंभिक [`Vec<T>`] आरंभिक मानले जाते (सध्याच्या अंमलबजावणी अंतर्गत; हे स्थिर हमी देत नाही) कारण कंपाईलरला त्याबद्दल माहिती असणे आवश्यक आहे ती म्हणजे डेटा पॉईंटर रिकामे असणे आवश्यक आहे.
/// असे `Vec<T>` तयार केल्याने *त्वरित* अपरिभाषित वर्तन होत नाही, परंतु बर्‍याच सुरक्षित ऑपरेशन्ससह (ते सोडण्यासह) अपरिभाषित वर्तन होऊ शकते.
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` निर्विवाद डेटासह डील करण्यासाठी असुरक्षित कोड सक्षम करण्यासाठी कार्य करते.
/// हे कंपाईलरला सिग्नल आहे जे सूचित करते की येथे डेटा * प्रारंभ होऊ शकत नाही:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // एक स्पष्टपणे निर्विवाद संदर्भ तयार करा.
/// // कंपाईलरला हे माहित आहे की `MaybeUninit<T>` मधील डेटा अवैध असू शकतो आणि म्हणून हा यूबी नाही:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // त्यास वैध मूल्यावर सेट करा.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // आरंभ केलेला डेटा काढा-हे केवळ *नंतर* योग्यरित्या `x` आरंभ करण्यास अनुमती आहे!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// कंपाइलरला नंतर या कोडवर कोणतीही चुकीची धारणा किंवा ऑप्टिमायझेशन न करणे माहित आहे.
///
/// आपण `MaybeUninit<T>` बद्दल थोडासा `Option<T>` असल्याचा विचार करू शकता परंतु कोणत्याही रन-टाइम ट्रॅकिंगशिवाय आणि कोणत्याही सुरक्षा तपासणीशिवाय.
///
/// ## out-pointers
///
/// आपण "out-pointers" अंमलबजावणीसाठी `MaybeUninit<T>` वापरू शकता: फंक्शनमधून डेटा परत आणण्याऐवजी निकाल लावण्यासाठी त्यास काही (uninitialized) मेमरीकडे पॉईंटर द्या.
/// जेव्हा कॉलरने परिणाम साठवलेल्या मेमरीचे वाटप कसे होते हे नियंत्रित करणे महत्वाचे आहे आणि आपल्याला अनावश्यक हालचाली टाळाव्या लागतात तेव्हा हे उपयुक्त ठरू शकते.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` जुनी सामग्री टाकत नाही, जे महत्वाचे आहे.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // आता आम्हाला माहित आहे की `v` इनिशियलाइज्ड आहे!हे देखील सुनिश्चित करते की vector योग्यरित्या सोडले गेले आहे.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## अ‍ॅरे एलिमेंट-बाय-एलिमेंट प्रारंभ करीत आहे
///
/// `MaybeUninit<T>` मोठ्या-अ‍ॅरे-एलिमेंट-बाय-एलिमेंट प्रारंभ करण्यासाठी वापरले जाऊ शकते:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // `MaybeUninit` चा एक निर्विवाद अरे तयार करा.
///     // `assume_init` सुरक्षित आहे कारण ज्या प्रकारचा आपण येथे आरंभ केला आहे असा दावा करीत आहोत तो म्हणजे `कदाचित युनिनिट्सचा एक समूह, ज्यास आरंभ आवश्यक नाही.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // `MaybeUninit` सोडणे काहीच करत नाही.
///     // अशाप्रकारे `ptr::write` ऐवजी रॉ पॉइंटर असाइनमेंट वापरल्याने जुने अनइंटीलाइज्ड मूल्य सोडले जाऊ शकत नाही.
/////
///     // या पळवाट दरम्यान झेडस्पॅनिक 0 झेड असल्यास आपल्याकडे मेमरी गळती आहे, परंतु मेमरी सेफ्टीची कोणतीही समस्या नाही.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // सर्व काही आरंभ आहे.
///     // प्रारंभिक प्रकारात अ‍ॅरेचे संक्रमण करा.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// आपण अर्धवट आरंभ केलेल्या अ‍ॅरेसह देखील कार्य करू शकता, जे निम्न-स्तरीय डेटास्ट्रक्चरमध्ये आढळू शकते.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // `MaybeUninit` चा एक निर्विवाद अरे तयार करा.
/// // `assume_init` सुरक्षित आहे कारण ज्या प्रकारचा आपण येथे आरंभ केला आहे असा दावा करीत आहोत तो म्हणजे `कदाचित युनिनिट्सचा एक समूह, ज्यास आरंभ आवश्यक नाही.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // आम्ही नियुक्त केलेल्या घटकांची संख्या मोजा.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // अ‍ॅरेमधील प्रत्येक वस्तूसाठी, आम्ही वाटप केल्यास ड्रॉप करा.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## स्ट्रक्चर फील्ड-बाय-फील्ड प्रारंभ करत आहे
///
/// आपण स्ट्रक्ट्स फील्डद्वारे आरंभ करण्यासाठी `MaybeUninit<T>` आणि [`std::ptr::addr_of_mut`] मॅक्रो वापरू शकता:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // `name` फील्ड प्रारंभ करीत आहे
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // एक्स 100 एक्स फील्डची सुरूवात जर येथे झेडस्पॅनिक 0 झेड असेल तर एक्स0 2 एक्स फील्डमधील एक्स 01 एक्स लीक होईल.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // सर्व फील्ड्स इनिशियलाइज्ड आहेत, म्हणून आम्ही इनिशिएटेड एफू मिळविण्यासाठी `assume_init` ला कॉल करू.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` `T` समान आकार, संरेखन आणि एबीआय असण्याची हमी आहेः
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// तथापि लक्षात ठेवा * * एक एक्स 100 एक्स असणारा प्रकार समान लेआउट असणे आवश्यक नाही;Rust सामान्य हमी देत नाही की `Foo<T>` च्या फील्डमध्ये `Foo<U>` प्रमाणेच ऑर्डर आहे जरी `T` आणि `U` समान आकार आणि संरेखन असेल.
///
/// याव्यतिरिक्त `MaybeUninit<T>` साठी कोणतेही बिट मूल्य वैध असल्यामुळे कंपाईलर non-zero/niche-filling ऑप्टिमायझेशन लागू करू शकत नाही, संभाव्यत: मोठ्या आकारात:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// जर एक्स 0 एक्स एक्स एफएफआय-सेफ असेल तर एक्स 100 एक्स देखील असेल.
///
/// `MaybeUninit` हे X01 एक्स आहे (ते दर्शविते की ते समान आकार, संरेखन आणि एबीआयला एक्स02 एक्स म्हणून हमी देते), यामुळे मागील कोणत्याही सावधपणा बदलत नाही *.
/// `Option<T>` आणि `Option<MaybeUninit<T>>` मध्ये अद्याप भिन्न आकार असू शकतात आणि `T` प्रकाराचे फील्ड असलेले प्रकार ते फील्ड X00 एक्स नसल्यास वेगळ्या पद्धतीने (आणि आकाराचे) घातले जाऊ शकतात.
/// `MaybeUninit` एक युनियन प्रकार आहे, आणि युनियनवरील एक्स 0 एक्स एक्स अस्थिर आहे (एक्स 100 एक्स पहा.
/// कालांतराने, संघांवरील `#[repr(transparent)]` ची अचूक हमी विकसित होऊ शकते आणि `MaybeUninit` `#[repr(transparent)]` राहू शकते किंवा राहू शकत नाही.
/// ते म्हणाले की, एक्स 0 एक्स एक्स नेहमीची हमी देते की यात आकार, संरेखन आणि एबीआय हे एक्स00 एक्ससारखे आहे;हमी असे आहे की `MaybeUninit` ची अंमलबजावणी केलेली हमी विकसित होऊ शकते.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// लँग आयटम जेणेकरून आम्ही त्यात इतर प्रकार लपेटू.हे जनरेटरसाठी उपयुक्त आहे.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // `T::clone()` वर कॉल करीत नाही, आम्ही त्यासाठी पुरेसे आरंभ केले आहे की नाही हे आम्हाला माहित नाही.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// दिलेल्या मूल्यासह प्रारंभ केले नवीन `MaybeUninit<T>` तयार करते.
    /// या फंक्शनच्या रिटर्न व्हॅल्यूवर [`assume_init`] वर कॉल करणे सुरक्षित आहे.
    ///
    /// लक्षात घ्या की `MaybeUninit<T>` सोडल्यास `T` च्या ड्रॉप कोडवर कधीही कॉल होणार नाही.
    /// `T` आरंभ झाला की नाही हे सुनिश्चित करण्याची आपली जबाबदारी आहे.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// निर्विवाद अवस्थेत नवीन `MaybeUninit<T>` तयार करते.
    ///
    /// लक्षात घ्या की `MaybeUninit<T>` सोडल्यास `T` च्या ड्रॉप कोडवर कधीही कॉल होणार नाही.
    /// `T` आरंभ झाला की नाही हे सुनिश्चित करण्याची आपली जबाबदारी आहे.
    ///
    /// काही उदाहरणांसाठी [type-level documentation][MaybeUninit] पहा.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// निर्विवाद अवस्थेत, `MaybeUninit<T>` आयटमचा नवीन अ‍ॅरे तयार करा.
    ///
    /// Note: झेड फ्यूचर 0 झेड 0 रस्ट0 झेड आवृत्तीमध्ये जेव्हा अ‍ॅरे लिटरल सिंटॅक्स एक्स 100 एक्सला परवानगी देते तेव्हा ही पद्धत अनावश्यक होऊ शकते.
    ///
    /// खालील उदाहरणे नंतर `let mut buf = [MaybeUninit::<u8>::uninit(); 32];` वापरू शकतील.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// प्रत्यक्षात वाचन केलेला डेटाचा एक (संभवतः छोटा) स्लाइस मिळवते
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // सुरक्षितता: एक निर्विवाद `[MaybeUninit<_>; LEN]` वैध आहे.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// `0` बाइट्ससह मेमरी भरल्यामुळे, निर्विवाद अवस्थेत नवीन `MaybeUninit<T>` तयार करते.ते आधीच योग्य इनिशियलायझेशनसाठी करते की नाही हे `T` वर अवलंबून आहे.
    ///
    /// उदाहरणार्थ, `MaybeUninit<usize>::zeroed()` प्रारंभ झाले आहे परंतु `MaybeUninit<&'static i32>::zeroed()` असे नाही कारण संदर्भ शून्य नसावेत.
    ///
    /// लक्षात घ्या की `MaybeUninit<T>` सोडल्यास `T` च्या ड्रॉप कोडवर कधीही कॉल होणार नाही.
    /// `T` आरंभ झाला की नाही हे सुनिश्चित करण्याची आपली जबाबदारी आहे.
    ///
    /// # Example
    ///
    /// या फंक्शनचा अचूक वापरः स्ट्रॉक्सची सुरुवात शून्यासह करा, जिथे स्ट्रक्चे सर्व फील्ड बिट-पॅटर्न 0 वैध मूल्य म्हणून धारण करू शकतात.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *या कार्याचा चुकीचा* वापर: `0` या प्रकारासाठी वैध बिट-नमुना नसल्यास `x.zeroed().assume_init()` वर कॉल करणे:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // जोडीच्या आत, आम्ही एक `NotZero` तयार करतो ज्यात वैध भेदभाव नाही.
    /// // ही अपरिभाषित वर्तन आहे.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // सुरक्षितता: वाटप केलेल्या मेमरीला `u.as_mut_ptr()` गुण.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// `MaybeUninit<T>` चे मूल्य सेट करते.
    /// हे मागील मूल्य सोडल्याशिवाय अधिलिखित करते, म्हणून जोपर्यंत आपण डिस्ट्रक्टर चालू करणे सोडून देऊ इच्छित नाही तोपर्यंत हे दोनदा न वापरण्याची काळजी घ्या.
    ///
    /// आपल्या सोयीसाठी, हे `self` च्या (आता सुरक्षितपणे आरंभित) सामग्रीस बदलू संदर्भ देखील परत करेल.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // सुरक्षाः आम्ही नुकतेच हे मूल्य आरंभ केले.
        unsafe { self.assume_init_mut() }
    }

    /// समाविष्ट केलेल्या मूल्याचे पॉईंटर मिळते.
    /// `MaybeUninit<T>` आरंभ केल्याशिवाय या पॉईंटरवरून वाचणे किंवा त्यास संदर्भात बदलणे अपरिभाषित वर्तन आहे.
    /// हे पॉईंटर (non-transitively) ने दर्शविलेल्या मेमरीवर लिहिणे हे अपरिभाषित वर्तन आहे (`UnsafeCell<T>` च्या आतील बाजूस).
    ///
    /// # Examples
    ///
    /// या पद्धतीचा योग्य वापर:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<T>` मध्ये संदर्भ तयार करा.हे ठीक आहे कारण आम्ही ते आरंभ केले.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// या पद्धतीचा *चुकीचा* वापर:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // आम्ही निर्विवादपणे vector चा संदर्भ तयार केला आहे!ही अपरिभाषित वर्तन आहे.⚠️
    /// ```
    ///
    /// (लक्षात घ्या की बिनबुडाच्या डेटाच्या संदर्भातील नियम अद्याप अंतिम केले गेलेले नाहीत, परंतु जोपर्यंत ते आहेत तोपर्यंत त्यांना टाळण्याचा सल्ला दिला जाईल.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` आणि `ManuallyDrop` हे दोन्ही `repr(transparent)` आहेत जेणेकरुन आपण पॉईंटर कास्ट करू शकू.
        self as *const _ as *const T
    }

    /// समाविष्ट केलेल्या मूल्यासाठी एक बदलण्यायोग्य पॉईंटर मिळविते.
    /// `MaybeUninit<T>` आरंभ केल्याशिवाय या पॉईंटरवरून वाचणे किंवा त्यास संदर्भात बदलणे अपरिभाषित वर्तन आहे.
    ///
    /// # Examples
    ///
    /// या पद्धतीचा योग्य वापर:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<Vec<u32>>` मध्ये संदर्भ तयार करा.
    /// // हे ठीक आहे कारण आम्ही ते आरंभ केले.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// या पद्धतीचा *चुकीचा* वापर:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // आम्ही निर्विवादपणे vector चा संदर्भ तयार केला आहे!ही अपरिभाषित वर्तन आहे.⚠️
    /// ```
    ///
    /// (लक्षात घ्या की बिनबुडाच्या डेटाच्या संदर्भातील नियम अद्याप अंतिम केले गेलेले नाहीत, परंतु जोपर्यंत ते आहेत तोपर्यंत त्यांना टाळण्याचा सल्ला दिला जाईल.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` आणि `ManuallyDrop` हे दोन्ही `repr(transparent)` आहेत जेणेकरुन आपण पॉईंटर कास्ट करू शकू.
        self as *mut _ as *mut T
    }

    /// `MaybeUninit<T>` कंटेनरमधून मूल्य काढते.डेटा सोडला जाईल हे सुनिश्चित करण्याचा हा एक चांगला मार्ग आहे, कारण परिणामी X01 एक्स नेहमीच्या ड्रॉप हाताळणीच्या अधीन आहे.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` खरोखर आरंभिक अवस्थेत आहे याची हमी देणे हे कॉल करणार्‍यावर अवलंबून आहे.जेव्हा सामग्री अद्याप पूर्णपणे प्रारंभ केलेली नसते तेव्हा कॉल केल्यास तत्काळ अपरिभाषित वर्तन होते.
    /// [type-level documentation][inv] मध्ये या आरंभिक आमंत्रणकर्त्याबद्दल अधिक माहिती आहे.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// त्याउलट, लक्षात ठेवा की बहुतेक प्रकारांमध्ये अतिरिक्त पातळी आहेत केवळ प्रकार पातळीवर आरंभिक मानले जाऊ नये.
    /// उदाहरणार्थ, `1`-आरंभिक [`Vec<T>`] आरंभिक मानले जाते (सध्याच्या अंमलबजावणी अंतर्गत; हे स्थिर हमी देत नाही) कारण कंपाईलरला त्याबद्दल माहिती असणे आवश्यक आहे ती म्हणजे डेटा पॉईंटर रिकामे असणे आवश्यक आहे.
    ///
    /// असे `Vec<T>` तयार केल्याने *त्वरित* अपरिभाषित वर्तन होत नाही, परंतु बर्‍याच सुरक्षित ऑपरेशन्ससह (ते सोडण्यासह) अपरिभाषित वर्तन होऊ शकते.
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// या पद्धतीचा योग्य वापर:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// या पद्धतीचा *चुकीचा* वापर:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` अद्याप आरंभ झाला नव्हता, म्हणून या शेवटच्या ओळीमुळे अपरिभाषित वर्तन झाले.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // सुरक्षितता: कॉलरने हमी देणे आवश्यक आहे की `self` प्रारंभ झाला आहे.
        // याचा अर्थ असा की `self` हा `value` प्रकार असणे आवश्यक आहे.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// `MaybeUninit<T>` कंटेनरचे मूल्य वाचते.परिणामी X01 एक्स नेहमीच्या ड्रॉप हाताळणीच्या अधीन आहे.
    ///
    /// जेव्हा शक्य असेल तेव्हा त्याऐवजी [`assume_init`] वापरणे अधिक श्रेयस्कर आहे, जे एक्स 100 एक्सची सामग्री डुप्लिकेट करण्यास प्रतिबंधित करते.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` खरोखर आरंभिक अवस्थेत आहे याची हमी देणे हे कॉल करणार्‍यावर अवलंबून आहे.जेव्हा सामग्री अद्याप पूर्णपणे प्रारंभ केलेली नसते तेव्हा कॉल केल्यामुळे अपरिभाषित वर्तन होते.
    /// [type-level documentation][inv] मध्ये या आरंभिक आमंत्रणकर्त्याबद्दल अधिक माहिती आहे.
    ///
    /// शिवाय, हे `MaybeUninit<T>` मध्ये समान डेटाची एक प्रत मागे ठेवते.
    /// डेटाच्या एकाधिक प्रती वापरताना (`assume_init_read` वर एकाधिक वेळा कॉल करून किंवा प्रथम `assume_init_read` आणि नंतर [`assume_init`] वर कॉल करून) डेटा खरोखर डुप्लिकेट होऊ शकतो याची खात्री करण्याची आपली जबाबदारी आहे.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// या पद्धतीचा योग्य वापर:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` `Copy` आहे, म्हणून आम्ही बर्‍याच वेळा वाचू शकतो.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `None` मूल्य डुप्लिकेट करणे ठीक आहे, म्हणून आम्ही बर्‍याच वेळा वाचू शकतो.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// या पद्धतीचा *चुकीचा* वापर:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // आम्ही आता समान vector च्या दोन प्रती तयार केल्या आहेत ज्यायोगे दुहेरी मुक्त होईल-जेव्हा ते दोन्ही सोडले जातील!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // सुरक्षितता: कॉलरने हमी देणे आवश्यक आहे की `self` प्रारंभ झाला आहे.
        // `self.as_ptr()` प्रारंभ करणे आवश्यक असल्याने `self.as_ptr()` चे वाचन सुरक्षित आहे.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// त्यातील असलेले मूल्य त्या ठिकाणी टाका.
    ///
    /// आपल्याकडे `MaybeUninit` ची मालकी असल्यास आपण त्याऐवजी [`assume_init`] वापरू शकता.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` खरोखर आरंभिक अवस्थेत आहे याची हमी देणे हे कॉल करणार्‍यावर अवलंबून आहे.जेव्हा सामग्री अद्याप पूर्णपणे प्रारंभ केलेली नसते तेव्हा कॉल केल्यामुळे अपरिभाषित वर्तन होते.
    ///
    /// त्यावरील, `T` प्रकाराचे सर्व अतिरिक्त आक्रमक समाधानी असले पाहिजेत कारण `T` (किंवा त्याचे सदस्य) चे `Drop` अंमलबजावणी यावर अवलंबून असू शकते.
    /// उदाहरणार्थ, `1`-आरंभिक [`Vec<T>`] आरंभिक मानले जाते (सध्याच्या अंमलबजावणी अंतर्गत; हे स्थिर हमी देत नाही) कारण कंपाईलरला त्याबद्दल माहिती असणे आवश्यक आहे ती म्हणजे डेटा पॉईंटर रिकामे असणे आवश्यक आहे.
    ///
    /// असे `Vec<T>` टाकण्यामुळे अपरिभाषित वर्तन होईल.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // सुरक्षितता: कॉलरने हमी देणे आवश्यक आहे की `self` आरंभ झाला आहे आणि
        // `T` च्या सर्व आक्रमणकर्त्यांचे समाधान करते.
        // तसे असल्यास त्या ठिकाणी मूल्य सोडणे सुरक्षित आहे.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// समाविष्ट केलेल्या मूल्याचा सामायिक संदर्भ मिळतो.
    ///
    /// जेव्हा आम्ही आरंभिक झालेल्या `MaybeUninit` वर प्रवेश करू इच्छित असतो परंतु `MaybeUninit` ची मालकी नाही (`.assume_init()`) चा वापर प्रतिबंधित करत नाही) तेव्हा हे उपयुक्त ठरेल.
    ///
    /// # Safety
    ///
    /// जेव्हा सामग्री अद्याप पूर्णतः आरंभ केलेली नसते तेव्हा कॉल केल्यामुळे अपरिभाषित वर्तन होते: `MaybeUninit<T>` खरोखर आरंभिक अवस्थेत आहे याची हमी देणे हे कॉल करणार्‍यावर अवलंबून आहे.
    ///
    ///
    /// # Examples
    ///
    /// ### या पद्धतीचा योग्य वापर:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // `x` प्रारंभ करा:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // आता आमचे `MaybeUninit<_>` आरंभिक म्हणून ओळखले गेले आहे, त्याबद्दल सामायिक केलेला संदर्भ तयार करणे ठीक आहे:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // सुरक्षा: `x` प्रारंभ केले गेले आहे.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### या पद्धतीचा *चुकीचा* उपयोगः
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // आम्ही निर्विवादपणे vector चा संदर्भ तयार केला आहे!ही अपरिभाषित वर्तन आहे.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // `Cell::set` वापरून `MaybeUninit` प्रारंभ करा:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // निर्विवाद `Cell<bool>` चा संदर्भ: यूबी!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // सुरक्षितता: कॉलरने हमी देणे आवश्यक आहे की `self` प्रारंभ झाला आहे.
        // याचा अर्थ असा की `self` हा `value` प्रकार असणे आवश्यक आहे.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// अंतर्भूत मूल्यासाठी एक परिवर्तनीय (unique) संदर्भ मिळविते.
    ///
    /// जेव्हा आम्ही आरंभिक झालेल्या `MaybeUninit` वर प्रवेश करू इच्छित असतो परंतु `MaybeUninit` ची मालकी नाही (`.assume_init()`) चा वापर प्रतिबंधित करत नाही) तेव्हा हे उपयुक्त ठरेल.
    ///
    /// # Safety
    ///
    /// जेव्हा सामग्री अद्याप पूर्णतः आरंभ केलेली नसते तेव्हा कॉल केल्यामुळे अपरिभाषित वर्तन होते: `MaybeUninit<T>` खरोखर आरंभिक अवस्थेत आहे याची हमी देणे हे कॉल करणार्‍यावर अवलंबून आहे.
    /// उदाहरणार्थ, एक्स 100 एक्स प्रारंभ करण्यासाठी एक्स01 एक्सचा वापर केला जाऊ शकत नाही.
    ///
    /// # Examples
    ///
    /// ### या पद्धतीचा योग्य वापर:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// इनपुट बफरचे *सर्व* बाइट प्रारंभ करते.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // `buf` प्रारंभ करा:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // आता आम्हाला माहित आहे की `buf` प्रारंभ झाला आहे, म्हणून आम्ही हे `.assume_init()` करू शकू.
    /// // तथापि, `.assume_init()` वापरणे 2048 बाइटच्या `memcpy` ला चालना देऊ शकते.
    /// // आमच्या बफरची प्रतिलिपी न करता आरंभ केला गेला आहे हे सिद्ध करण्यासाठी आम्ही `&mut MaybeUninit<[u8; 2048]>` ला `&mut [u8; 2048]` मध्ये श्रेणीसुधारित केले:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // सुरक्षा: `buf` प्रारंभ केले गेले आहे.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // आता आम्ही सामान्य स्लाइस म्हणून `buf` वापरू शकतो:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### या पद्धतीचा *चुकीचा* उपयोगः
    ///
    /// मूल्य आरंभ करण्यासाठी आपण `.assume_init_mut()` वापरू शकत नाही:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // आम्ही निर्विवाद `bool` चा एक (mutable) संदर्भ तयार केला आहे!
    ///     // ही अपरिभाषित वर्तन आहे.⚠️
    /// }
    /// ```
    ///
    /// उदाहरणार्थ, आपण निर्विवाद बफरमध्ये [`Read`] करू शकत नाही:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) निरुपयोगी मेमरीचा संदर्भ!
    ///                             // ही अपरिभाषित वर्तन आहे.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// किंवा आपण फील्ड-बाय-फील्ड हळूहळू आरंभ करण्यासाठी थेट फील्ड प्रवेश वापरू शकत नाही:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) निरुपयोगी मेमरीचा संदर्भ!
    ///                  // ही अपरिभाषित वर्तन आहे.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) निरुपयोगी मेमरीचा संदर्भ!
    ///                  // ही अपरिभाषित वर्तन आहे.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): आम्ही सध्या वरील चुकीच्या असल्यावर अवलंबून आहोत, म्हणजे आमच्याकडे निर्विवाद डेटाचा संदर्भ आहे (उदा. एक्स 100 एक्स मध्ये).
    // स्थिरीकरणापूर्वी आपण नियमांविषयी अंतिम निर्णय घेतला पाहिजे.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // सुरक्षितता: कॉलरने हमी देणे आवश्यक आहे की `self` प्रारंभ झाला आहे.
        // याचा अर्थ असा की `self` हा `value` प्रकार असणे आवश्यक आहे.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// `MaybeUninit` कंटेनरच्या अ‍ॅरेमधून मूल्ये काढते.
    ///
    /// # Safety
    ///
    /// अ‍ॅरेचे सर्व घटक आरंभिक अवस्थेत आहेत याची हमी देणे कॉल करणार्‍यावर अवलंबून आहे.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // सुरक्षा: आम्ही सर्व घटकांना आरंभ केल्यामुळे आता सुरक्षित आहे
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * कॉलर हमी देतो की अ‍ॅरेचे सर्व घटक प्रारंभ केले आहेत
        // * `MaybeUninit<T>` आणि टी समान लेआउट असल्याची हमी दिलेली आहे
        // * कदाचित युनिट सोडत नाही, म्हणून डबल-फ्री नाहीत आणि अशा प्रकारे रूपांतरण सुरक्षित आहे
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// सर्व घटक आरंभ झाले आहेत असे समजू, त्यांना एक तुकडा मिळवा.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` घटक खरोखर आरंभिक अवस्थेत आहेत याची हमी देणे हे कॉल करणार्‍यावर अवलंबून आहे.
    ///
    /// जेव्हा सामग्री अद्याप पूर्णपणे प्रारंभ केलेली नसते तेव्हा कॉल केल्यामुळे अपरिभाषित वर्तन होते.
    ///
    /// अधिक तपशील आणि उदाहरणांसाठी [`assume_init_ref`] पहा.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // सुरक्षितताः कॉलरने याची हमी दिल्याने `*const [T]` ला स्लाइस कास्ट करणे सुरक्षित आहे
        // `slice` आरंभ केला आहे आणि आणि मायबेयुनिटला `T` सारख्याच लेआउटची हमी दिलेली आहे.
        // प्राप्त केलेला पॉईंटर वैध आहे कारण तो एक्स00 एक्स च्या मालकीच्या मेमरीचा संदर्भित आहे जो संदर्भ आहे आणि अशा प्रकारे वाचनास वैध असल्याची हमी दिलेली आहे.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// सर्व घटक आरंभ झाले आहेत असे समजू, त्यांना एक बदलण्यायोग्य स्लाइस मिळवा.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` घटक खरोखर आरंभिक अवस्थेत आहेत याची हमी देणे हे कॉल करणार्‍यावर अवलंबून आहे.
    ///
    /// जेव्हा सामग्री अद्याप पूर्णपणे प्रारंभ केलेली नसते तेव्हा कॉल केल्यामुळे अपरिभाषित वर्तन होते.
    ///
    /// अधिक तपशील आणि उदाहरणांसाठी [`assume_init_mut`] पहा.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // सुरक्षितताः `slice_get_ref` च्या सुरक्षा नोट्स प्रमाणेच, परंतु आमच्याकडे ए
        // बदलण्यायोग्य संदर्भ जो लेखनास वैध असण्याची हमी देतो.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// अ‍ॅरेच्या पहिल्या घटकाला पॉईंटर मिळतो.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// अ‍ॅरेच्या पहिल्या घटकाला बदलता पॉईंटर मिळतो.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// `src` ते `this` वर घटकांची प्रतिलिपी करते, `this` च्या आताच्या इनलिटलाइज्ड सामग्रीचा एक परस्पर संदर्भ पाठविते.
    ///
    /// `T` `Copy` लागू करत नसल्यास, [`write_slice_cloned`] वापरा
    ///
    /// हे [`slice::copy_from_slice`] प्रमाणेच आहे.
    ///
    /// # Panics
    ///
    /// दोन तुकड्यांची लांबी भिन्न असल्यास हे कार्य panic करेल.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // सुरक्षितता: आम्ही लेनचे सर्व घटक केवळ अतिरिक्त क्षमतांमध्ये कॉपी केले आहेत
    /// // वेक्टरचे पहिले src.len() घटक आता वैध आहेत.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // सुरक्षा: &[टी] आणि&[कदाचित युनिट<T>] समान लेआउट आहे
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // सुरक्षितता: वैध घटकांची नुकतीच `this` मध्ये कॉपी केली गेली आहे जेणेकरुन ते initalized आहे
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// `src` ते `this` पर्यंत घटकांची क्लोन करते, आता `this` च्या इनलिटलाइज्ड सामग्रीचा एक बदल संदर्भ परत करते.
    /// आधीपासूनच कोणताही मूलभूत घटक सोडला जाणार नाही.
    ///
    /// `T` `Copy` लागू करत असल्यास, [`write_slice`] वापरा
    ///
    /// हे [`slice::clone_from_slice`] प्रमाणेच आहे परंतु विद्यमान घटक सोडत नाही.
    ///
    /// # Panics
    ///
    /// दोन तुकड्यांची लांबी भिन्न असल्यास किंवा `Clone` panics ची अंमलबजावणी केल्यास हे कार्य panic करेल.
    ///
    /// जर झेडस्पॅनिक 0 झेड असेल तर आधीच क्लोन केलेले घटक सोडले जातील.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // सुरक्षितता: आम्ही आगाऊ क्षमतांमध्ये लेनच्या सर्व घटकांचे क्लोन केले आहेत
    /// // वेक्टरचे पहिले src.len() घटक आता वैध आहेत.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // कॉपी_फ्रॅम_स्लाइसच्या विपरीत हे स्लाईसवर क्लोन_फ्रॅम_स्लाइस कॉल करत नाही कारण हे `MaybeUninit<T: Clone>` क्लोन कार्यान्वित करीत नाही.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // सुरक्षितता: या कच्च्या स्लाइसमध्ये केवळ आरंभिक वस्तू असतील
                // म्हणूनच, ते सोडण्याची परवानगी आहे.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: आम्ही त्यांना समान लांबीवर स्पष्टपणे कापून टाकणे आवश्यक आहे
        // सीमेवर तपासणी करण्याच्या मर्यादेसाठी आणि ऑप्टिमाइझर सोप्या प्रकरणांसाठी मेम्पी तयार करेल (उदाहरणार्थ टी=एक्स 100 एक्स).
        //
        let len = this.len();
        let src = &src[..len];

        // गार्डची आवश्यकता आहे क्लोन दरम्यान b/c panic घडू शकते
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // सुरक्षितता: वैध घटक नुकतेच `this` मध्ये लिहिले गेले आहेत जेणेकरुन ते initalized आहे
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}