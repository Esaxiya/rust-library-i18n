//! ASCII `[u8]` वर ऑपरेशन्स.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// या स्लाइसमधील सर्व बाइट एएससीआयआय श्रेणीतील आहेत का ते तपासेल.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// दोन काप एक एएससीआयआय केस-असंवेदनशील सामना आहे याची तपासणी करतो.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` प्रमाणेच, परंतु तात्पुरते वाटप आणि कॉपी केल्याशिवाय.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// या स्लाइसला त्याच्या एएससीआयआय अप्पर केसमध्ये समांतर ठिकाणी रुपांतरित करते.
    ///
    /// 'a' ते 'z' पर्यंत ASCII अक्षरे 'A' ते 'Z' पर्यंत मॅप केली गेली आहेत, परंतु ASCII नसलेली अक्षरे बदलली नाहीत.
    ///
    /// विद्यमान व्हॅल्यू न सुधारता नवीन अप्परकेस मूल्य परत करण्यासाठी, [`to_ascii_uppercase`] वापरा.
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// या स्लाइसला त्याच्या एएससीआयआय लोअर केसच्या जागी समांतर ठिकाणी रुपांतरित करते.
    ///
    /// 'A' ते 'Z' पर्यंत ASCII अक्षरे 'a' ते 'z' पर्यंत मॅप केली गेली आहेत, परंतु ASCII नसलेली अक्षरे बदलली नाहीत.
    ///
    /// विद्यमान व्हॅल्यू न सुधारता नवीन लोअरकेस मूल्य परत करण्यासाठी, एक्स 100 एक्स वापरा.
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// `v` शब्दामधील कोणतीही बाइट नॉनॅस्सी (>=128) असल्यास `true` मिळवते.
/// एक्स 100 एक्स कडून स्नॅरफेड, जे एक्स01 एक्स प्रमाणीकरणासाठी असेच काहीतरी करते.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// ऑप्टिमाइझ्ड एएससीआयआय चाचणी जे बाईट-ए-ए-टाइम ऑपरेशन्सऐवजी वापरात-वापरल्या जाणार्‍या ऑपरेशनचा वापर करेल (जेव्हा शक्य असेल तेव्हा)
///
/// आपण येथे वापरत असलेल्या अल्गोरिदम खूप सोपे आहे.जर एक्स 100 एक्स खूपच लहान असेल तर आम्ही फक्त प्रत्येक बाइट तपासतो आणि त्याद्वारे पूर्ण केले.अन्यथाः
///
/// - पहिला शब्द अ-हस्ताक्षरित भारांसह वाचा.
/// - पॉइंटर संरेखित करा, संरेखित भारांसह शेवटपर्यंत शब्द वाचा.
/// - अचिन्हांकित लोडसह `s` मधील शेवटचे `usize` वाचा.
///
/// जर यापैकी कोणतेही भार जर असे काहीतरी तयार केले ज्यासाठी `contains_nonascii` (above) सत्य परत आले तर आम्हाला उत्तर माहित नाही.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // जर शब्द-अ-ए-टाइम अंमलबजावणीमधून आम्हाला काही मिळणार नसेल तर परत एक स्केलर लूपवर जा.
    //
    // आम्ही हे आर्किटेक्चरसाठी देखील करतो जेथे एक्स 100 एक्स हे एक्स 100 एक्ससाठी पुरेसे संरेखन नाही, कारण हे एक विचित्र edge प्रकरण आहे.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // आम्ही नेहमीच शब्द अ-हस्ताक्षरित वाचतो, ज्याचा अर्थ `align_offset` आहे
    // 0, संरेखित वाचनासाठी आम्ही समान मूल्य पुन्हा वाचू.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // सुरक्षितता: आम्ही उपरोक्त `len < USIZE_SIZE` सत्यापित करतो.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // आम्ही हे वरील काही अंशी सुस्पष्टपणे तपासले.
    // लक्षात घ्या की `offset_to_aligned` एकतर `align_offset` किंवा `USIZE_SIZE` आहे, दोन्ही स्पष्टपणे वर तपासले गेले आहेत.
    //
    debug_assert!(offset_to_aligned <= len);

    // सुरक्षितता: word_ptr ही (योग्यरित्या संरेखित केलेली) वापरलेली पीटीआर आहे जी आम्ही वाचण्यासाठी वापरतो
    // तुकडा मध्यम भाग.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` लूप एंड चेकसाठी वापरलेले एक्स 100 एक्स चे बाइट इंडेक्स आहे.
    let mut byte_pos = offset_to_aligned;

    // पॅरानोइया संरेखन बद्दल तपासा, कारण आम्ही अवांछित भारांचा एक समूह करणार आहोत.
    // सराव मध्ये हे `align_offset` मध्ये बग वगळता अशक्य असले पाहिजे.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // नंतर शेपटीच्या शेपटीच्या शेपटीवर अंतिम संरेखित शब्द वगळता शेवटच्या संरेखित शब्दापर्यंत पुढील शेडचे शब्द वाचा, जेणेकरून शेपटी नेहमीच एक `usize` जास्तीत जास्त जास्तीत जास्त branch `byte_pos == len` असेल.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // शुद्धता वाचन मर्यादेत आहे हे तपासा
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // आणि आमच्या `byte_pos` बद्दलच्या धारणा धरून आहेत.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // सुरक्षा: आम्हाला माहित आहे की `word_ptr` योग्यरित्या संरेखित केले आहे (कारण
        // `align_offset`), आणि आम्हाला हे माहित आहे की आमच्याकडे `word_ptr` आणि शेवटच्या दरम्यान पुरेसा बाइट आहे
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // सुरक्षा: आम्हाला ते माहित आहे की `byte_pos <= len - USIZE_SIZE`, ज्याचा अर्थ असा आहे
        // या `add` नंतर, `word_ptr` सर्वात जास्तीत जास्त शेवटचा असेल.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // तेथे फक्त एक `usize` शिल्लक असल्याचे सुनिश्चित करण्यासाठी शुद्धता तपासणी.
    // याची खात्री आपल्या पळवाट स्थितीने दिली पाहिजे.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // सुरक्षितता: हे `len >= USIZE_SIZE` वर अवलंबून असते, जे आम्ही सुरुवातीस तपासतो.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}