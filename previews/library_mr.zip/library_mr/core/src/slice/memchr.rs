// मूळ अंमलबजावणी rust-mechr वरून घेतली.
// कॉपीराइट 2015 अँड्र्यू गॅलंट, ब्लस आणि निकोलस कोच

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// काटछाट वापरा.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// `x` मध्ये कोणतीही शून्य बाइट असल्यास `true` मिळवते.
///
/// *मॅटर कॉम्प्यूटेशनल*, जे. आर्न्डट कडून:
///
/// "प्रत्येक बाईटमधून एक वजा करणे आणि नंतर कर्जाने सर्व मार्गांपर्यंत पोहोचलेल्या बाइट्स शोधणे ही कल्पना आहे
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// `text` मधील बाइट `x` शी जुळणारा पहिला अनुक्रमणिका मिळवते.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // लहान तुकड्यांसाठी वेगवान मार्ग
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // एकाच वेळी दोन `usize` शब्द वाचून एकाच बाइट मूल्यासाठी स्कॅन करा.
    //
    // तीन भागांमध्ये एक्स 100 एक्स विभाजित करा
    // - मजकूरात पहिला शब्द संरेखित पत्त्याआधी, अचिन्हांकित प्रारंभिक भाग
    // - शरीर, एकावेळी 2 शब्दांनी स्कॅन करा
    // - शेवटचा भाग, <2 शब्द आकार

    // एका संरेखित सीमेपर्यंत शोध
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // मजकूराचा मुख्य भाग शोधा
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // सुरक्षितता: त्या दरम्यानचे पूर्वानुमान कमीतकमी 2 * usize_bytes च्या अंतराची हमी देते
        // ऑफसेट आणि स्लाइसच्या शेवटी.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // जुळणारे बाइट असल्यास ब्रेक करा
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // बॉडी लूप थांबल्यानंतर बिंदूनंतर बाइट शोधा.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// `text` मधील बाइट `x` शी जुळणारा अंतिम अनुक्रमणिका मिळवते.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // एकाच वेळी दोन `usize` शब्द वाचून एकाच बाइट मूल्यासाठी स्कॅन करा.
    //
    // तीन भागांमध्ये `text` विभाजित करा:
    // - मजकूरातील शेवटच्या शब्दाच्या संरेखित पत्त्यानंतर, अवाक्षर असलेली शेपूट
    // - शरीर, एकावेळी 2 शब्दांनी स्कॅन केलेले,
    // - पहिले उर्वरित बाइट, <2 शब्द आकार.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // प्रत्यय आणि प्रत्यय लांबी मिळवण्यासाठी आम्ही याला कॉल करतो.
        // मध्यभागी आम्ही नेहमी एकाच वेळी दोन भागांवर प्रक्रिया करतो.
        // सुरक्षितता: X001 द्वारे हाताळल्या जाणार्‍या आकार फरक वगळता `[u8]` ला `[usize]` मध्ये रुपांतरित करणे सुरक्षित आहे.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // मजकूराचा मुख्य भाग शोधा, आम्ही min_aligned_offset पार करत नाही हे सुनिश्चित करा.
    // ऑफसेट नेहमीच संरेखित केले जाते, म्हणूनच फक्त `>` चाचणी करणे पुरेसे आहे आणि शक्य ओव्हरफ्लो टाळते.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // सुरक्षितता: ऑफसेट लेन, suffix.len() पासून सुरू होते, जोपर्यंत तो त्यापेक्षा मोठा असेल
        // min_aligned_offset (prefix.len()) उर्वरित अंतर किमान 2 * भाग_बाइट आहे.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // जुळणारे बाइट असल्यास ब्रेक करा.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // बॉडी लूप थांबण्यापूर्वी बिंदू शोधा.
    text[..offset].iter().rposition(|elt| *elt == x)
}