// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// एक्स 100 एक्स श्रेणी फिरवते जे X01 एक्स मधील घटक प्रथम घटक बनते.समांतर, `left` घटकांना डावीकडून किंवा `right` घटकांना उजवीकडे फिरवते.
///
/// # Safety
///
/// वाचन आणि लेखनासाठी निर्दिष्ट श्रेणी वैध असणे आवश्यक आहे.
///
/// # Algorithm
///
/// अल्गोरिदम 1 `left + right` च्या लहान मूल्यांसाठी किंवा मोठ्या `T` साठी वापरला जातो.
/// `mid - left` पासून प्रारंभ होणा and्या एकावेळी घटकांना त्यांच्या अंतिम स्थितीत स्थानांतरित केले जाते आणि `right` पायर्यांद्वारे मॉड्युलो `left + right` पुढे केले जाते, जसे की केवळ एक तात्पुरती आवश्यक आहे.
/// अखेरीस, आम्ही परत परत `mid - left` वर पोहोचलो.
/// तथापि, जर एक्स 100 एक्स 1 नसेल तर उपरोक्त चरण खाली सोडले गेले.
/// उदाहरणार्थ:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// सुदैवाने, अंतिम घटकांमधील घटकांना वगळण्याची संख्या नेहमीच समान असते, म्हणून आम्ही फक्त आमची सुरूवात करू शकतो आणि अधिक फेs्या करू शकतो (एकूण फेs्यांची संख्या एक्स 100 एक्स आहे.)
///
/// अंतिम परिणाम असा आहे की सर्व घटक एकदा आणि फक्त एकदाच अंतिम केले जातात.
///
/// `left + right` मोठे असल्यास अल्गोरिदम 2 वापरला जातो परंतु स्टॅक बफरवर फिट होण्यासाठी `min(left, right)` इतके लहान आहे.
/// `min(left, right)` घटकांची बफरवर कॉपी केली जाते, इतरांवर `memmove` लागू केले जाते आणि बफरवरील घटक ज्यांचे मूळ उद्भवतात तेथील बाजूच्या छिद्रात परत हलवले जातात.
///
/// एकदा `left + right` पुरेसे मोठे झाल्यावर वरील गोष्टींना वेक्टरसारखे बनविता येणारे अल्गोरिदम.
/// अल्गोरिदम 1 एकाच वेळी अनेक फे ch्यांची निवड करून आणि त्याद्वारे वेक्टर केला जाऊ शकतो, परंतु `left + right` प्रचंड होईपर्यंत सरासरी फारच कमी फेs्या असतात आणि एकाच फेरीची सर्वात वाईट घटना नेहमीच असते.
/// त्याऐवजी, अल्गोरिदम 3 वारंवार फिरण्याची समस्या सोडल्याशिवाय `min(left, right)` घटकांच्या स्वॅपिंगचा पुन्हा वापर करते.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// जेव्हा एक्स00 एक्स त्याऐवजी डावीकडून स्वॅपिंग होते.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. जर ही प्रकरणे तपासली गेली नाहीत तर खालील अल्गोरिदम अयशस्वी होऊ शकतात
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // अल्गोरिदम 1 मायक्रोबेन्चमार्क असे दर्शविते की यादृच्छिक शिफ्टसाठीची सरासरी कामगिरी सुमारे `left + right == 32` पर्यंत सर्व प्रकारे चांगली आहे, परंतु सर्वात वाईट परिस्थितीची कामगिरी अगदी 16 च्या आसपास मोडते.
            // 24 मधल्या मैदान म्हणून निवडले गेले.
            // जर `T` चा आकार 4 `usize`s पेक्षा मोठा असेल तर, हे अल्गोरिदम इतर अल्गोरिदमांना देखील मागेपुढे करते.
            //
            //
            let x = unsafe { mid.sub(left) };
            // पहिल्या फेरीची सुरुवात
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` `gcd(left + right, right)` ची गणना करून हातापूर्वी शोधली जाऊ शकते, परंतु जीसीडीची साइड इफेक्ट म्हणून गणना करणारी एक लूप करणे वेगवान आहे, त्यानंतर उर्वरित भाग करणे.
            //
            //
            let mut gcd = right;
            // बेंचमार्कमध्ये असे दिसून आले आहे की एकदाच एक तात्पुरते एकदा वाचण्याऐवजी मागील बाजूस कॉपी करण्याऐवजी तात्पुरते स्वॅपिंग करणे वेगवान आहे आणि त्या शेवटी अगदी तात्पुरते लिहा.
            // हे शक्य आहे की अस्थायी स्वॅपिंग किंवा त्याऐवजी दोन व्यवस्थापित करण्याची आवश्यकता न ठेवता लूपमध्ये फक्त एक मेमरी पत्ता वापरला जातो.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // `i` वाढविण्याऐवजी आणि नंतर ते सीमेच्या बाहेर आहे की नाही हे तपासण्याऐवजी, आम्ही पुढील वेतन वाढीवरील सीमेच्या बाहेर X01 एक्स जाईल की नाही ते तपासतो.
                // हे पॉइंटर किंवा `usize` चे कोणतेही लपेटणे प्रतिबंधित करते.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // पहिल्या फेरीचा शेवट
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // `left + right >= 15` असल्यास ही सशर्त येथे असणे आवश्यक आहे
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // अधिक फे with्यांसह भाग समाप्त करा
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` हा शून्य-आकाराचा प्रकार नाही, म्हणून त्याच्या आकारानुसार विभाजित करणे ठीक आहे.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // अल्गोरिदम 2 एक्स योग्यरित्या टी साठी संरेखित केले आहे याची खात्री करण्यासाठी येथे आहे
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // अल्गोरिदम sw अदलाबदल करण्याचा एक पर्यायी मार्ग आहे ज्यामध्ये या अल्गोरिदमचा शेवटचा स्वॅप कुठे असेल याचा शोध घेण्यामध्ये आणि या अल्गोरिदम सारख्या जवळच्या भागांची अदलाबदल करण्याऐवजी शेवटचा भाग वापरुन स्वॅपिंग करणे समाविष्ट आहे, परंतु तरीही हा मार्ग वेगवान आहे.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // अल्गोरिदम 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}