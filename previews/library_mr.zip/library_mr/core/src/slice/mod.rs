// ignore-tidy-filelength

//! स्लाइस व्यवस्थापन आणि इच्छित हालचाल घडवून आणण्यासाठी हाताचा उपयोग करणे.
//!
//! अधिक तपशीलांसाठी [`std::slice`] पहा.
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// शुद्ध rust मेमर ची अंमलबजावणी, rust-memchr वरून घेतली
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// हे फंक्शन केवळ सार्वजनिक आहे कारण युनिट टेस्ट हेपसोर्टसाठी दुसरा कोणताही मार्ग नाही.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// स्लाइसमधील घटकांची संख्या मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // सुरक्षितता: कॉन्स्ट साउंड कारण आम्ही लांबीचे फील्ड एक युज म्हणून (जे ते असलेच पाहिजे) रूपांतरित करतो.
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // सुरक्षितता: हे सुरक्षित आहे कारण `&[T]` आणि `FatPtr<T>` चे समान लेआउट आहे.
            // केवळ `std` ही हमी देऊ शकते.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: ते स्थिर-स्थिर असताना `crate::ptr::metadata(self)` सह बदला.
            // या लिखाणामुळे यास "Const-stable functions can only call other const-stable functions" त्रुटी येते.
            //

            // सुरक्षितताः * कॉन्स्ट टी पासून `PtrRepr` युनियनकडून मूल्य प्राप्त करणे सुरक्षित आहे
            // आणि PtrComp घटक<T>समान मेमरी लेआउट आहेत.
            // केवळ std ही हमी देऊ शकते.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// जर स्लाइसची लांबी 0 असेल तर `true` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// स्लाइसचा पहिला घटक किंवा रिक्त असल्यास `None` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// स्लाइसच्या पहिल्या घटकाला बदलणारा पॉईंटर किंवा रिक्त असल्यास `None` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// स्लाइसमधील पहिला आणि उर्वरित सर्व घटक किंवा रिक्त असल्यास `None` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// स्लाइसमधील पहिला आणि उर्वरित सर्व घटक किंवा रिक्त असल्यास `None` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// स्लाइसमधील शेवटचे आणि उर्वरित सर्व घटक किंवा रिक्त असल्यास `None` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// स्लाइसमधील शेवटचे आणि उर्वरित सर्व घटक किंवा रिक्त असल्यास `None` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// स्लाइसचा शेवटचा घटक किंवा रिक्त असल्यास `None` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// स्लाइसमधील शेवटच्या आयटमसाठी बदलता पॉईंटर मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// अनुक्रमणिकेच्या प्रकारानुसार एखाद्या घटकाचा संदर्भ किंवा सब्सलिसिस मिळवते.
    ///
    /// - स्थान दिल्यास त्या स्थानावरील घटकाचा संदर्भ मिळतो किंवा सीमेबाहेर असल्यास `None`.
    ///
    /// - श्रेणी दिली असल्यास, त्या श्रेणीशी संबंधित सबलिस परत आणते किंवा मर्यादेबाहेर असल्यास `None` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// निर्देशांक सीमेवरील नसल्यास निर्देशकाच्या प्रकारानुसार ([`get`] पहा) किंवा `None` च्या आधारावर घटकाचा किंवा सबलिसिसचा बदल बदलू शकतो.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// सीमा तपासणी न करता एखाद्या घटकाचा किंवा सबलिसिसचा संदर्भ मिळवते.
    ///
    /// सुरक्षित पर्यायासाठी [`get`] पहा.
    ///
    /// # Safety
    ///
    /// परिणामी संदर्भ वापरला नसला तरीही, या पद्धतीस मर्यादाबाहेरच्या निर्देशांकासह कॉल करणे *[अपरिभाषित वर्तन]* आहे.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // सुरक्षितता: कॉलरने `get_unchecked` साठी बहुतेक सुरक्षा आवश्यकता पाळल्या पाहिजेत;
        // स्लाईस डीरेफरेन्सेबल आहे कारण एक्स00 एक्स हा एक सुरक्षित संदर्भ आहे.
        // परत केलेला पॉईंटर सुरक्षित आहे कारण एक्स 100 एक्सच्या इम्पल्सना ते असल्याची हमी दिली पाहिजे.
        unsafe { &*index.get_unchecked(self) }
    }

    /// सीमांची तपासणी न करता एखाद्या घटकाचा किंवा सबलिसिसचा बदलणारा संदर्भ मिळवते.
    ///
    /// सुरक्षित पर्यायासाठी [`get_mut`] पहा.
    ///
    /// # Safety
    ///
    /// परिणामी संदर्भ वापरला नसला तरीही, या पद्धतीस मर्यादाबाहेरच्या निर्देशांकासह कॉल करणे *[अपरिभाषित वर्तन]* आहे.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // सुरक्षितता: कॉलरने `get_unchecked_mut` ची सुरक्षा आवश्यकता पाळणे आवश्यक आहे;
        // स्लाईस डीरेफरेन्सेबल आहे कारण एक्स00 एक्स हा एक सुरक्षित संदर्भ आहे.
        // परत केलेला पॉईंटर सुरक्षित आहे कारण एक्स 100 एक्सच्या इम्पल्सना ते असल्याची हमी दिली पाहिजे.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// स्लाइसच्या बफरला कच्चा पॉईंटर मिळवते.
    ///
    /// कॉलरने हे सुनिश्चित केले पाहिजे की स्लाइस हे कार्य परत आलेल्या पॉईंटरच्या बाहेर जाईल किंवा अन्यथा कचर्‍याकडे निर्देश करेल.
    ///
    /// कॉलरने हे देखील सुनिश्चित केले पाहिजे की पॉईंटर (non-transitively) ने दर्शविलेली मेमरी या पॉईंटरद्वारे किंवा त्याद्वारे घेतलेल्या कोणत्याही पॉईंटरचा वापर करुन (`UnsafeCell` च्या आत वगळता) कधीही लिहिलेले नाही.
    /// आपल्याला स्लाइसमधील सामग्री बदलण्याची आवश्यकता असल्यास, एक्स00 एक्स वापरा.
    ///
    /// या स्लाइसद्वारे संदर्भित कंटेनर सुधारित केल्याने त्याचा बफर पुन्हा रिक्त होऊ शकतो, ज्यामुळे त्याचे कोणतेही पॉइंटर्स अवैधही बनू शकतात.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// स्लाइसच्या बफरवर असुरक्षित म्युटेबल पॉईंटर मिळवते.
    ///
    /// कॉलरने हे सुनिश्चित केले पाहिजे की स्लाइस हे कार्य परत आलेल्या पॉईंटरच्या बाहेर जाईल किंवा अन्यथा कचर्‍याकडे निर्देश करेल.
    ///
    /// या स्लाइसद्वारे संदर्भित कंटेनर सुधारित केल्याने त्याचा बफर पुन्हा रिक्त होऊ शकतो, ज्यामुळे त्याचे कोणतेही पॉइंटर्स अवैधही बनू शकतात.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// स्लाइसमध्ये पसरलेले दोन कच्चे पॉइंटर्स मिळवते.
    ///
    /// परत केलेली श्रेणी अर्ध-खुली आहे, याचा अर्थ असा आहे की शेवटचा पॉईंटर *एक भूतकाळ* स्लाइसचा शेवटचा घटक दर्शवितो.
    /// अशाप्रकारे, रिक्त स्लाइस दोन समान पॉईंटर्सद्वारे दर्शविली जाते आणि दोन पॉइंटर्समधील फरक स्लाइसचा आकार दर्शवितो.
    ///
    /// हे पॉईंटर्स वापरण्याविषयी चेतावणी देण्यासाठी [`as_ptr`] पहा.शेवटच्या पॉईंटरला अतिरिक्त सावधगिरीची आवश्यकता असते कारण ते स्लाइसमधील वैध घटकाकडे निर्देश करत नाही.
    ///
    /// हे कार्य परदेशी इंटरफेससह संवाद साधण्यासाठी उपयुक्त आहे जे सी ++ मध्ये सामान्य असलेल्या मेमरीमधील घटकांच्या श्रेणीचा संदर्भ घेण्यासाठी दोन पॉईंटर्स वापरतात.
    ///
    ///
    /// घटकांकडे निर्देशक या स्लाइसच्या घटकांचा संदर्भित करते की नाही हे तपासणे देखील उपयुक्त ठरेल:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // सुरक्षितता: येथील `add` सुरक्षित आहे, कारणः
        //
        //   - दोन्ही पॉइंटर्स एकाच ऑब्जेक्टचा भाग आहेत, कारण ऑब्जेक्टला थेट दाखविणे देखील मोजले जाते.
        //
        //   - स्लाइसचा आकार isize::MAX बाइटपेक्षा मोठा कधीच असू शकत नाही, जसे येथे नमूद केले आहे:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - यामध्ये काही लपेटणे शक्य नाही, कारण स्लाइस्स अ‍ॅड्रेस स्पेसच्या शेवटी लपेटत नाहीत.
        //
        // pointer::add चे दस्तऐवजीकरण पहा.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// स्लाइसमध्ये असलेले दोन असुरक्षित म्युटेबल पॉईंटर्स मिळवते.
    ///
    /// परत केलेली श्रेणी अर्ध-खुली आहे, याचा अर्थ असा आहे की शेवटचा पॉईंटर *एक भूतकाळ* स्लाइसचा शेवटचा घटक दर्शवितो.
    /// अशाप्रकारे, रिक्त स्लाइस दोन समान पॉईंटर्सद्वारे दर्शविली जाते आणि दोन पॉइंटर्समधील फरक स्लाइसचा आकार दर्शवितो.
    ///
    /// हे पॉईंटर्स वापरण्याविषयी चेतावणी देण्यासाठी [`as_mut_ptr`] पहा.
    /// शेवटच्या पॉईंटरला अतिरिक्त सावधगिरीची आवश्यकता असते कारण ते स्लाइसमधील वैध घटकाकडे निर्देश करत नाही.
    ///
    /// हे कार्य परदेशी इंटरफेससह संवाद साधण्यासाठी उपयुक्त आहे जे सी ++ मध्ये सामान्य असलेल्या मेमरीमधील घटकांच्या श्रेणीचा संदर्भ घेण्यासाठी दोन पॉईंटर्स वापरतात.
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // सुरक्षितताः येथे `add` सुरक्षित का आहे यासाठी वरील as_ptr_range() पहा.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// स्लाइसमध्ये दोन घटक अदलाबदल करतात.
    ///
    /// # Arguments
    ///
    /// * अ, पहिल्या घटकाची अनुक्रमणिका
    /// * बी, दुसर्‍या घटकाची अनुक्रमणिका
    ///
    /// # Panics
    ///
    /// `a` किंवा `b` मर्यादेबाहेर असल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // एका झेडवेक्टोर0 झेडकडून दोन बदलू कर्ज घेऊ शकत नाही, म्हणून त्याऐवजी कच्चे पॉईंटर्स वापरा.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // सुरक्षितताः `pa` आणि `pb` सुरक्षित बदलण्यायोग्य संदर्भ आणि संदर्भातून तयार केले गेले आहेत
        // स्लाइसमधील घटकांना आणि म्हणून वैध आणि संरेखित असल्याची हमी दिलेली आहे.
        // लक्षात घ्या की `a` आणि `b` च्या मागील घटकांवर प्रवेश करणे तपासले गेले आहे आणि जेव्हा सीमेत नसते तेव्हा panic करेल.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// स्लाइसमधील घटकांच्या क्रमाने, त्याऐवजी उलट करते.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // अगदी लहान प्रकारांसाठी, सामान्य मार्गावरील सर्व वाचक खराब कामगिरी करतात.
        // आम्ही मोठा कार्यक्षेत्र लोड करून आणि नोंदणी परत करून, कार्यक्षम अ-हस्ताक्षरित load/store दिल्यास आम्ही अधिक चांगले करू शकतो.
        //

        // तद्वतच एलएलव्हीएम आमच्यासाठी हे करेल, कारण अनइलेन्टेड वाचन कार्यक्षम आहे की नाही हे आम्हाला करण्यापेक्षा हे चांगले आहे (उदाहरणार्थ एआरएमच्या वेगवेगळ्या आवृत्तींमध्ये बदल झाले आहेत, उदाहरणार्थ) आणि उत्कृष्ट भाग आकार कोणता असेल.
        // दुर्दैवाने, LLVM 4.0 (2017-05) नुसार ते केवळ पळवाट रद्द करते, म्हणून आम्हाला हे स्वतः करणे आवश्यक आहे.
        // (हाइपोथेसिस: उलटा त्रासदायक आहे कारण बाजू वेगळ्या प्रकारे संरेखित केल्या जाऊ शकतात-जेव्हा लांबी विषम असेल तेव्हा होईल-म्हणजे उत्सर्जन करण्याचा कोणताही मार्ग नाही-आणि मध्यभागी पूर्ण-संरेखित सिमडी वापरण्यासाठी पोस्टलाईड्स नाहीत.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // यू एस मध्ये यू 8 रिव्हर्स करण्यासाठी एक्स 100 एक्स इंटर्सिक वापरा
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // सुरक्षितता: येथे तपासण्यासाठी बर्‍याच गोष्टी आहेत:
                //
                // - वरील cfg तपासणीमुळे `chunk` एकतर 4 किंवा 8 आहे याची नोंद घ्या.तर `chunk - 1` सकारात्मक आहे.
                // - लूप चेकची हमी म्हणून अनुक्रमणिका एक्स 100 एक्स बरोबर अनुक्रमणिका ठीक आहे
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - अनुक्रमणिका `ln - i - chunk = ln - (i + chunk)` सह अनुक्रमणिका ठीक आहे:
                //   - `i + chunk > 0` क्षुल्लक गोष्ट आहे.
                //   - पळवाट तपासणीची हमी:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, अशा प्रकारे वजाबाकी प्रवाहात होणार नाहीत.
                // - `read_unaligned` आणि `write_unaligned` कॉल ठीक आहेतः
                //   - `pa` निर्देशांक `i` वर निर्देशित करते जेथे `i < ln / 2 - (chunk - 1)` (वर पहा) आणि `pb` निर्देशांक `ln - i - chunk` वर निर्देशित करते, म्हणून दोन्ही `self` च्या शेवटी कमीत कमी `chunk` बरेच बाइट दूर आहेत.
                //
                //   - कोणतीही आरंभ केलेली मेमरी वैध `usize` आहे.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // एक्स 16 एक्स मध्ये u16 चे उलट करण्यासाठी फिरवा-बाय-16 वापरा
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // सुरक्षितताः एक अस्ताक्षरित X01 एक्स X002 असल्यास `i` वरून वाचले जाऊ शकते
                // (आणि स्पष्टपणे `i < ln`), कारण प्रत्येक घटक 2 बाइटचा आहे आणि आम्ही 4 वाचत आहोत.
                //
                // `i + chunk - 1 < ln / 2` # अट असताना
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // हे 2 ने विभाजित लांबीपेक्षा कमी असल्याने ते मर्यादा असणे आवश्यक आहे.
                //
                // याचा अर्थ असा आहे की एक्स 100 एक्स स्थितीचा नेहमीच आदर केला जातो, हे सुनिश्चित करून `pb` पॉईंटर सुरक्षितपणे वापरला जाऊ शकतो.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // सुरक्षा: एक्स स्लाइसच्या अर्ध्या लांबीपेक्षा एक्सएक्सएक्स हीन कनिष्ठ आहे
            // `i` आणि `ln - i - 1` मध्ये प्रवेश करणे सुरक्षित आहे (`i` 0 पासून सुरू होते आणि `ln / 2 - 1` पेक्षा पुढे जाणार नाही).
            // परिणामी `pa` आणि `pb` पॉईंटर्स वैध आणि संरेखित आहेत आणि येथून वाचले आणि लिहिले जाऊ शकतात.
            //
            //
            unsafe {
                // सेफ स्वॅपमध्ये सीमेची तपासणी टाळण्यासाठी असुरक्षित स्वॅप.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// स्लाइसवर इटरेटर परत करतो.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// प्रत्येक व्हॅल्यू सुधारित करणार्‍या इटरेटरला परत करते.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// `size` लांबीच्या सर्व संक्षिप्त windows वर पुनरावृत्ती करणारा मिळवते.
    /// windows आच्छादित
    /// जर तुकडा `size` पेक्षा लहान असेल तर, पुनरावृत्ती करणार्‍यांना कोणतेही मूल्य दिले जाणार नाही.
    ///
    /// # Panics
    ///
    /// `size` 0 असल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// जर तुकडा `size` पेक्षा लहान असेल:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// स्लाइसच्या सुरूवातीस प्रारंभ करून, स्लाइसच्या `chunk_size` घटकांपेक्षा जास्त वेळा एक इटरेटर परत करते.
    ///
    /// भाग काप आहेत आणि आच्छादित होत नाहीत.जर एक्स ०१ एक्सने स्लाइसची लांबी विभागली नाही तर शेवटच्या भागात लांबी `chunk_size` नाही.
    ///
    /// या पुनरावृत्ती करणा a्याच्या बदलांसाठी [`chunks_exact`] पहा जे नेहमीच `chunk_size` घटकांचा भाग परत करते आणि त्याच पुनरावृत्तीसाठी [`rchunks`] पण स्लाइसच्या शेवटी प्रारंभ करते.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 असल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// स्लाइसच्या सुरूवातीस प्रारंभ करून, स्लाइसच्या `chunk_size` घटकांपेक्षा जास्त वेळा एक इटरेटर परत करते.
    ///
    /// भाग बदलू काप आहेत आणि ओव्हरलॅप होत नाहीत.जर एक्स ०१ एक्सने स्लाइसची लांबी विभागली नाही तर शेवटच्या भागात लांबी `chunk_size` नाही.
    ///
    /// या पुनरावृत्ती करणा a्याच्या बदलांसाठी [`chunks_exact_mut`] पहा जे नेहमीच `chunk_size` घटकांचा भाग परत करते आणि त्याच पुनरावृत्तीसाठी [`rchunks_mut`] पण स्लाइसच्या शेवटी प्रारंभ करते.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 असल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// स्लाइसच्या सुरूवातीस प्रारंभ करून, स्लाइसच्या `chunk_size` घटकांपेक्षा जास्त वेळा एक इटरेटर परत करते.
    ///
    /// भाग काप आहेत आणि आच्छादित होत नाहीत.
    /// जर `chunk_size` स्लाइसची लांबी विभाजित करीत नसेल तर, शेवटचे `chunk_size-1` घटक वगळले जातील आणि आयटरच्या `remainder` फंक्शनमधून पुनर्प्राप्त केले जाऊ शकतात.
    ///
    ///
    /// प्रत्येक हिस्सामध्ये अचूक X01 एक्स घटक असल्यामुळे कंपाईलर बहुतेक वेळा [`chunks`] च्या तुलनेत परिणामी कोडला अधिक अनुकूलित करू शकतो.
    ///
    /// या आयटरच्या भिन्न प्रकारासाठी [`chunks`] पहा जे उर्वरित लहान भाग म्हणून देखील परत करते आणि त्याच पुनरावृत्तीसाठी [`rchunks_exact`] पण स्लाइसच्या शेवटी प्रारंभ करते.
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 असल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// स्लाइसच्या सुरूवातीस प्रारंभ करून, स्लाइसच्या `chunk_size` घटकांपेक्षा जास्त वेळा एक इटरेटर परत करते.
    ///
    /// भाग बदलू काप आहेत आणि ओव्हरलॅप होत नाहीत.
    /// जर `chunk_size` स्लाइसची लांबी विभाजित करीत नसेल तर, शेवटचे `chunk_size-1` घटक वगळले जातील आणि आयटरच्या `into_remainder` फंक्शनमधून पुनर्प्राप्त केले जाऊ शकतात.
    ///
    ///
    /// प्रत्येक हिस्सामध्ये अचूक X01 एक्स घटक असल्यामुळे कंपाईलर बहुतेक वेळा [`chunks_mut`] च्या तुलनेत परिणामी कोडला अधिक अनुकूलित करू शकतो.
    ///
    /// या आयटरच्या भिन्न प्रकारासाठी [`chunks_mut`] पहा जे उर्वरित लहान भाग म्हणून देखील परत करते आणि त्याच पुनरावृत्तीसाठी [`rchunks_exact_mut`] पण स्लाइसच्या शेवटी प्रारंभ करते.
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 असल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// उर्वरित काही शिल्लक नाही असे गृहित धरून ice N`-घटक अ‍ॅरेच्या तुकड्यात स्लाइस विभाजित करते.
    ///
    ///
    /// # Safety
    ///
    /// हे तेव्हाच म्हटले जाऊ शकते
    /// - स्लाईस अगदी `N`-घटक भागांमध्ये (उर्फ `self.len() % N == 0`)) मध्ये विभाजित होतो.
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // सुरक्षा: 1-घटक भागांमध्ये उर्वरित कधीही नसते
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // सुरक्षा: स्लाइस लांबी (6) 3 ची गुणाकार आहे
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // हे अप्रमाणित असेल:
    /// // द्या भाग द्या: &[[_ _;5]]=एक्स 100 एक्स//स्लाइस लांबी 5 भाड्याने मिळविण्यापासून मिळणारी संख्या असू शकत नाही:&[[_ _;0]]= slice.as_chunks_unchecked()//शून्य-लांबी भागांना कधीही परवानगी नाही
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // सुरक्षितता: आमची पूर्वस्थिती अशी आहे की याला कॉल करण्यासाठी काय आवश्यक आहे
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // सुरक्षा: आम्ही यात `new_len * N` घटकांचा तुकडा टाकला
        // `new_len` चा एक तुकडा अनेक `N` घटकांचा भाग.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// स्लाइसच्या सुरूवातीस प्रारंभ होणार्‍या `N`-तत्त्व अ‍ॅरेच्या तुकड्यात स्लाईस विभाजित करते आणि `N` पेक्षा कमी लांबीची उर्वरित स्लाइस.
    ///
    ///
    /// # Panics
    ///
    /// `N` असल्यास Panics 0 ही पद्धत स्थिर होण्यापूर्वी ही तपासणी बहुदा कंपाईल टाइम एररमध्ये बदलली जाईल.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // सुरक्षितता: आम्ही आधीच शून्यासाठी घाबरून गेलो आहोत आणि बांधकामाद्वारे सुनिश्चित
        // सबसलिसची लांबी ही एन ची गुणाकार आहे.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// स्लाइसच्या शेवटी सुरू होणार्‍या `N`-एलिमेंट अ‍ॅरेच्या तुकड्यात स्लाईस विभाजित करते आणि `N` पेक्षा कमी लांबीची उर्वरित स्लाइस.
    ///
    ///
    /// # Panics
    ///
    /// `N` असल्यास Panics 0 ही पद्धत स्थिर होण्यापूर्वी ही तपासणी बहुदा कंपाईल टाइम एररमध्ये बदलली जाईल.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // सुरक्षितता: आम्ही आधीच शून्यासाठी घाबरून गेलो आहोत आणि बांधकामाद्वारे सुनिश्चित
        // सबसलिसची लांबी ही एन ची गुणाकार आहे.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// स्लाइसच्या सुरूवातीस प्रारंभ करून, स्लाइसच्या `N` घटकांपेक्षा जास्त वेळा एक इटरेटर परत करते.
    ///
    /// भाग हे अ‍ॅरे संदर्भ आहेत आणि आच्छादित होत नाहीत.
    /// जर `N` स्लाइसची लांबी विभाजित करीत नसेल तर, शेवटचे `N-1` घटक वगळले जातील आणि आयटरच्या `remainder` फंक्शनमधून पुनर्प्राप्त केले जाऊ शकतात.
    ///
    ///
    /// ही पद्धत [`chunks_exact`] च्या कॉन्ट्रॅक्ट जेनेरिक समतुल्य आहे.
    ///
    /// # Panics
    ///
    /// `N` असल्यास Panics 0 ही पद्धत स्थिर होण्यापूर्वी ही तपासणी बहुदा कंपाईल टाइम एररमध्ये बदलली जाईल.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// उर्वरित काही शिल्लक नाही असे गृहित धरून ice N`-घटक अ‍ॅरेच्या तुकड्यात स्लाइस विभाजित करते.
    ///
    ///
    /// # Safety
    ///
    /// हे तेव्हाच म्हटले जाऊ शकते
    /// - स्लाईस अगदी `N`-घटक भागांमध्ये (उर्फ `self.len() % N == 0`)) मध्ये विभाजित होतो.
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // सुरक्षा: 1-घटक भागांमध्ये उर्वरित कधीही नसते
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // सुरक्षा: स्लाइस लांबी (6) 3 ची गुणाकार आहे
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // हे अप्रमाणित असेल:
    /// // द्या भाग द्या: &[[_ _;5]]= slice.as_chunks_unchecked_mut()//स्लाइस लांबी 5 भाड्याने मिळविण्यापासून मिळणारी एक ची गुणाकार नाही:&[[_ _;0]]= slice.as_chunks_unchecked_mut()//शून्य-लांबी भागांना कधीही परवानगी नाही
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // सुरक्षितता: आमची पूर्वस्थिती अशी आहे की याला कॉल करण्यासाठी काय आवश्यक आहे
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // सुरक्षा: आम्ही यात `new_len * N` घटकांचा तुकडा टाकला
        // `new_len` चा एक तुकडा अनेक `N` घटकांचा भाग.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// स्लाइसच्या सुरूवातीस प्रारंभ होणार्‍या `N`-तत्त्व अ‍ॅरेच्या तुकड्यात स्लाईस विभाजित करते आणि `N` पेक्षा कमी लांबीची उर्वरित स्लाइस.
    ///
    ///
    /// # Panics
    ///
    /// `N` असल्यास Panics 0 ही पद्धत स्थिर होण्यापूर्वी ही तपासणी बहुदा कंपाईल टाइम एररमध्ये बदलली जाईल.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // सुरक्षितता: आम्ही आधीच शून्यासाठी घाबरून गेलो आहोत आणि बांधकामाद्वारे सुनिश्चित
        // सबसलिसची लांबी ही एन ची गुणाकार आहे.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// स्लाइसच्या शेवटी सुरू होणार्‍या `N`-एलिमेंट अ‍ॅरेच्या तुकड्यात स्लाईस विभाजित करते आणि `N` पेक्षा कमी लांबीची उर्वरित स्लाइस.
    ///
    ///
    /// # Panics
    ///
    /// `N` असल्यास Panics 0 ही पद्धत स्थिर होण्यापूर्वी ही तपासणी बहुदा कंपाईल टाइम एररमध्ये बदलली जाईल.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // सुरक्षितता: आम्ही आधीच शून्यासाठी घाबरून गेलो आहोत आणि बांधकामाद्वारे सुनिश्चित
        // सबसलिसची लांबी ही एन ची गुणाकार आहे.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// स्लाइसच्या सुरूवातीस प्रारंभ करून, स्लाइसच्या `N` घटकांपेक्षा जास्त वेळा एक इटरेटर परत करते.
    ///
    /// भाग बदलू अ‍ॅरे संदर्भ आहेत आणि आच्छादित होत नाहीत.
    /// जर `N` स्लाइसची लांबी विभाजित करीत नसेल तर, शेवटचे `N-1` घटक वगळले जातील आणि आयटरच्या `into_remainder` फंक्शनमधून पुनर्प्राप्त केले जाऊ शकतात.
    ///
    ///
    /// ही पद्धत [`chunks_exact_mut`] च्या कॉन्ट्रॅक्ट जेनेरिक समतुल्य आहे.
    ///
    /// # Panics
    ///
    /// `N` असल्यास Panics 0 ही पद्धत स्थिर होण्यापूर्वी ही तपासणी बहुदा कंपाईल टाइम एररमध्ये बदलली जाईल.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// स्लाइसच्या सुरूवातीस, स्लाईसच्या `N` घटकांच्या windows आच्छादित ओव्हरलॅपवर एक पुनरावृत्ती करणारा मिळवते.
    ///
    ///
    /// हे [`windows`] चे कॉन्सट जनरल समतुल्य आहे.
    ///
    /// जर `N` स्लाइसच्या आकारापेक्षा मोठा असेल तर तो कोणताही एक्स 100 एक्स परत करणार नाही.
    ///
    /// # Panics
    ///
    /// `N` 0 असल्यास Panics.
    /// ही पद्धत स्थिर होण्यापूर्वी बहुधा ही तपासणी कंपाईल टाइम एररमध्ये बदलली जाईल.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// स्लाइसच्या शेवटी सुरू होणार्‍या एकावेळी स्लाइसच्या `chunk_size` घटकांपेक्षा जास्त असलेले इटररेटर परत करते.
    ///
    /// भाग काप आहेत आणि आच्छादित होत नाहीत.जर एक्स ०१ एक्सने स्लाइसची लांबी विभागली नाही तर शेवटच्या भागात लांबी `chunk_size` नाही.
    ///
    /// या पुनरावृत्ती करणा a्याच्या बदलांसाठी [`rchunks_exact`] पहा जे नेहमीच `chunk_size` घटकांचा भाग परत करते आणि त्याच पुनरावृत्तीसाठी [`chunks`] पण स्लाइसच्या सुरूवातीस प्रारंभ होते.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 असल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// स्लाइसच्या शेवटी सुरू होणार्‍या एकावेळी स्लाइसच्या `chunk_size` घटकांपेक्षा जास्त असलेले इटररेटर परत करते.
    ///
    /// भाग बदलू काप आहेत आणि ओव्हरलॅप होत नाहीत.जर एक्स ०१ एक्सने स्लाइसची लांबी विभागली नाही तर शेवटच्या भागात लांबी `chunk_size` नाही.
    ///
    /// या पुनरावृत्ती करणा a्याच्या बदलांसाठी [`rchunks_exact_mut`] पहा जे नेहमीच `chunk_size` घटकांचा भाग परत करते आणि त्याच पुनरावृत्तीसाठी [`chunks_mut`] पण स्लाइसच्या सुरूवातीस प्रारंभ होते.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 असल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// स्लाइसच्या शेवटी सुरू होणार्‍या एकावेळी स्लाइसच्या `chunk_size` घटकांपेक्षा जास्त असलेले इटररेटर परत करते.
    ///
    /// भाग काप आहेत आणि आच्छादित होत नाहीत.
    /// जर `chunk_size` स्लाइसची लांबी विभाजित करीत नसेल तर, शेवटचे `chunk_size-1` घटक वगळले जातील आणि आयटरच्या `remainder` फंक्शनमधून पुनर्प्राप्त केले जाऊ शकतात.
    ///
    /// प्रत्येक हिस्सामध्ये अचूक X01 एक्स घटक असल्यामुळे कंपाईलर बहुतेक वेळा [`chunks`] च्या तुलनेत परिणामी कोडला अधिक अनुकूलित करू शकतो.
    ///
    /// या आयटरच्या भिन्न प्रकारासाठी [`rchunks`] पहा जे उर्वरित लहान भाग म्हणून देखील परत करते आणि त्याच पुनरावृत्तीसाठी [`chunks_exact`] पण स्लाइसच्या सुरूवातीस प्रारंभ करते.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 असल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// स्लाइसच्या शेवटी सुरू होणार्‍या एकावेळी स्लाइसच्या `chunk_size` घटकांपेक्षा जास्त असलेले इटररेटर परत करते.
    ///
    /// भाग बदलू काप आहेत आणि ओव्हरलॅप होत नाहीत.
    /// जर `chunk_size` स्लाइसची लांबी विभाजित करीत नसेल तर, शेवटचे `chunk_size-1` घटक वगळले जातील आणि आयटरच्या `into_remainder` फंक्शनमधून पुनर्प्राप्त केले जाऊ शकतात.
    ///
    /// प्रत्येक हिस्सामध्ये अचूक X01 एक्स घटक असल्यामुळे कंपाईलर बहुतेक वेळा [`chunks_mut`] च्या तुलनेत परिणामी कोडला अधिक अनुकूलित करू शकतो.
    ///
    /// या आयटरच्या भिन्न प्रकारासाठी [`rchunks_mut`] पहा जे उर्वरित लहान भाग म्हणून देखील परत करते आणि त्याच पुनरावृत्तीसाठी [`chunks_exact_mut`] पण स्लाइसच्या सुरूवातीस प्रारंभ करते.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 असल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// घटकांना वेगळे करण्यासाठी प्रीसीटचा वापर करून घटकांच्या ओव्हरलॅपिंग नॉन-आच्छादित धावांच्या तुकड्यावर पुनरावृत्ती करणारा मिळवते.
    ///
    /// प्रिकेटला स्वत: चे अनुसरण करीत असलेल्या दोन घटकांवर कॉल केले जाते, याचा अर्थ प्रीटीकेटला एक्स00 एक्स आणि एक्स ०१ एक्स नंतर एक्स ०२ एक्स आणि एक्स ०3 एक्स वर म्हटले जाते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// या पद्धतीने क्रमवारीकृत सदस्यता काढण्यासाठी वापरली जाऊ शकते:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// स्लीटवर इट्रेटर मिळवते ज्यामध्ये घटकांना वेगळे करण्यासाठी प्रीकेट वापरुन ओव्हरलॅपिंग नॉन-आच्छादित उत्परिवर्तनीय धाव तयार होते.
    ///
    /// प्रिकेटला स्वत: चे अनुसरण करीत असलेल्या दोन घटकांवर कॉल केले जाते, याचा अर्थ प्रीटीकेटला एक्स00 एक्स आणि एक्स ०१ एक्स नंतर एक्स ०२ एक्स आणि एक्स ०3 एक्स वर म्हटले जाते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// या पद्धतीने क्रमवारीकृत सदस्यता काढण्यासाठी वापरली जाऊ शकते:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// निर्देशांकात एक तुकडा दोन मध्ये विभागून घ्या.
    ///
    /// पहिल्यामध्ये `[0, mid)` मधील सर्व निर्देशांक असतील (स्वतः अनुक्रमणिका `mid` वगळता) आणि दुसर्‍यामध्ये `[mid, len)` मधील सर्व निर्देशांक असतील (स्वतः अनुक्रमणिका `len` वगळता).
    ///
    ///
    /// # Panics
    ///
    /// `mid > len` असल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // सुरक्षितता: `[ptr; mid]` आणि `[mid; len]` हे `self` च्या आत आहेत, जे
        // `from_raw_parts_mut` ची आवश्यकता पूर्ण करते.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// एका परिवर्तनीय स्लाइसला निर्देशांकात दोनमध्ये विभाजित करते.
    ///
    /// पहिल्यामध्ये `[0, mid)` मधील सर्व निर्देशांक असतील (स्वतः अनुक्रमणिका `mid` वगळता) आणि दुसर्‍यामध्ये `[mid, len)` मधील सर्व निर्देशांक असतील (स्वतः अनुक्रमणिका `len` वगळता).
    ///
    ///
    /// # Panics
    ///
    /// `mid > len` असल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // सुरक्षितता: `[ptr; mid]` आणि `[mid; len]` हे `self` च्या आत आहेत, जे
        // `from_raw_parts_mut` ची आवश्यकता पूर्ण करते.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// सीमा तपासणी न करता इंडेक्समध्ये एक तुकडा दोन मध्ये विभागून घ्या.
    ///
    /// पहिल्यामध्ये `[0, mid)` मधील सर्व निर्देशांक असतील (स्वतः अनुक्रमणिका `mid` वगळता) आणि दुसर्‍यामध्ये `[mid, len)` मधील सर्व निर्देशांक असतील (स्वतः अनुक्रमणिका `len` वगळता).
    ///
    ///
    /// सुरक्षित पर्यायासाठी [`split_at`] पहा.
    ///
    /// # Safety
    ///
    /// परिणामी संदर्भ वापरला नसला तरीही, या पद्धतीस मर्यादाबाहेरच्या निर्देशांकासह कॉल करणे *[अपरिभाषित वर्तन]* आहे.कॉलरने हे सुनिश्चित केले पाहिजे की `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // सुरक्षितता: कॉलरला ते `0 <= mid <= self.len()` तपासावे लागेल
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// सीमा तपासणी न करता एका परिवर्तनीय स्लाइसला निर्देशांकात दोनमध्ये विभाजित करते.
    ///
    /// पहिल्यामध्ये `[0, mid)` मधील सर्व निर्देशांक असतील (स्वतः अनुक्रमणिका `mid` वगळता) आणि दुसर्‍यामध्ये `[mid, len)` मधील सर्व निर्देशांक असतील (स्वतः अनुक्रमणिका `len` वगळता).
    ///
    ///
    /// सुरक्षित पर्यायासाठी [`split_at_mut`] पहा.
    ///
    /// # Safety
    ///
    /// परिणामी संदर्भ वापरला नसला तरीही, या पद्धतीस मर्यादाबाहेरच्या निर्देशांकासह कॉल करणे *[अपरिभाषित वर्तन]* आहे.कॉलरने हे सुनिश्चित केले पाहिजे की `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // सुरक्षितता: कॉलरला ते `0 <= mid <= self.len()` तपासावे लागेल.
        //
        // `[ptr; mid]` आणि एक्स 100 एक्स आच्छादित होत नाहीत, म्हणून बदलू संदर्भ परत करणे योग्य आहे.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// `pred` शी जुळणार्‍या घटकांद्वारे विभक्त केलेल्या सदस्यतांवर पुनरावृत्ती करणारा मिळवते.
    /// जुळलेला घटक सदस्यतांमध्ये समाविष्ट नाही.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// जर प्रथम घटक जुळला असेल तर रिक्त स्लाइस ही पुनरावृत्ती करणार्‍याद्वारे परत केलेली प्रथम आयटम असेल.
    /// त्याचप्रमाणे, जर स्लाइसमधील शेवटचा घटक जुळला असेल तर रिक्त स्लाइस ही पुनरावृत्ती करून परत केलेली शेवटची आयटम असेल:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// दोन जुळणारे घटक थेट समीप असल्यास, त्यांच्या दरम्यान रिक्त स्लाइस असेल:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// `pred` शी जुळणार्‍या घटकांद्वारे विभक्त बदलण्यायोग्य सदस्यतांवर पुनरावृत्ती करणारा मिळवते.
    /// जुळलेला घटक सदस्यतांमध्ये समाविष्ट नाही.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// `pred` शी जुळणार्‍या घटकांद्वारे विभक्त केलेल्या सदस्यतांवर पुनरावृत्ती करणारा मिळवते.
    /// जुळणारे घटक टर्मिनेटर म्हणून मागील सबलिसच्या शेवटी आहेत.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// जर स्लाइसचा शेवटचा घटक जुळला असेल तर तो घटक मागील स्लाइसचा टर्मिनेटर मानला जाईल.
    ///
    /// ही स्लाइस पुनरावृत्ती करणार्‍याद्वारे परत केलेली शेवटची आयटम असेल.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// `pred` शी जुळणार्‍या घटकांद्वारे विभक्त बदलण्यायोग्य सदस्यतांवर पुनरावृत्ती करणारा मिळवते.
    /// जुळणारा घटक टर्मिनेटर म्हणून मागील सबलिसमध्ये असतो.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// स्लाईसच्या शेवटी सुरू होऊन आणि मागील बाजूने कार्य करीत `pred` शी जुळणार्‍या घटकांद्वारे विभक्त केलेल्या सदस्यतांवर पुनरावृत्ती करणारा मिळवते.
    /// जुळलेला घटक सदस्यतांमध्ये समाविष्ट नाही.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `split()` प्रमाणे, जर पहिला किंवा शेवटचा घटक जुळला असेल तर रिक्त स्लाइस पुनरावृत्ती करून परत केलेली पहिली (किंवा शेवटची) आयटम असेल.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// स्लाईसच्या शेवटी सुरू होवून आणि मागे कार्य करीत `pred` शी जुळणार्‍या घटकांद्वारे विभक्त केलेल्या बदलण्यायोग्य सदस्यतांवर पुनरावृत्ती करणारा मिळवते.
    /// जुळलेला घटक सदस्यतांमध्ये समाविष्ट नाही.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// बहुतेक `n` आयटमवर परत येण्यासाठी मर्यादित `pred` शी जुळणार्‍या घटकांद्वारे विभक्त केलेल्या सदस्यतांवर पुनरावृत्ती करणारा मिळवते.
    /// जुळलेला घटक सदस्यतांमध्ये समाविष्ट नाही.
    ///
    /// परत आलेल्या शेवटच्या घटकामध्ये स्लाइसचा उर्वरित भाग असेल.
    ///
    /// # Examples
    ///
    /// 3 (म्हणजेच `[10, 40]`, `[20, 60, 50]`) ने भागाकार असलेल्या क्रमांकावरून एकदा स्लाइस विभाजन मुद्रित करा:
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// बहुतेक `n` आयटमवर परत येण्यासाठी मर्यादित `pred` शी जुळणार्‍या घटकांद्वारे विभक्त केलेल्या सदस्यतांवर पुनरावृत्ती करणारा मिळवते.
    /// जुळलेला घटक सदस्यतांमध्ये समाविष्ट नाही.
    ///
    /// परत आलेल्या शेवटच्या घटकामध्ये स्लाइसचा उर्वरित भाग असेल.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// बहुतेक `n` आयटमवर परत येण्यासाठी मर्यादित `pred` शी जुळणार्‍या घटकांद्वारे विभक्त केलेल्या सदस्यतांवर एक पुनरावृत्ती करणारा मिळवते.
    /// हे स्लाईसच्या शेवटी सुरू होते आणि मागे कार्य करते.
    /// जुळलेला घटक सदस्यतांमध्ये समाविष्ट नाही.
    ///
    /// परत आलेल्या शेवटच्या घटकामध्ये स्लाइसचा उर्वरित भाग असेल.
    ///
    /// # Examples
    ///
    /// स्लाईस स्प्लिट एकदा, शेवटपासून, 3 (म्हणजेच एक्स 100 एक्स, एक्स01 एक्स) ने भागलेल्या संख्यांद्वारे मुद्रित करा:
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// बहुतेक `n` आयटमवर परत येण्यासाठी मर्यादित `pred` शी जुळणार्‍या घटकांद्वारे विभक्त केलेल्या सदस्यतांवर एक पुनरावृत्ती करणारा मिळवते.
    /// हे स्लाईसच्या शेवटी सुरू होते आणि मागे कार्य करते.
    /// जुळलेला घटक सदस्यतांमध्ये समाविष्ट नाही.
    ///
    /// परत आलेल्या शेवटच्या घटकामध्ये स्लाइसचा उर्वरित भाग असेल.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// जर स्लाइसमध्ये दिलेल्या मूल्यासह एखादा घटक असेल तर `true` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// आपल्याकडे `&T` नसल्यास, परंतु `T: Borrow<U>` (उदा
    /// Ring तार: कर्ज<str>`), आपण `iter().any` वापरू शकता:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // `String` चा तुकडा
    /// assert!(v.iter().any(|e| e == "hello")); // `&str` सह शोधा
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// `needle` स्लाईसचा उपसर्ग असल्यास `true` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// `needle` रिक्त स्लाईस असल्यास नेहमी `true` परत करते:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// `needle` स्लाइसचा प्रत्यय असल्यास `true` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// `needle` रिक्त स्लाईस असल्यास नेहमी `true` परत करते:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// प्रत्यय काढून टाकलेल्या उपपरवानासह परत मिळवते.
    ///
    /// जर स्लाइस `prefix` ने सुरू झाली तर, `Some` मध्ये गुंडाळलेल्या उपसर्गानंतर सबलिस परत करेल.
    /// जर एक्स 100 एक्स रिक्त असेल तर फक्त मूळ स्लाइस परत करेल.
    ///
    /// जर स्लाइस `prefix` ने प्रारंभ होत नसेल तर `None` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // जेव्हा स्लाईसपॅटर्न अधिक परिष्कृत होते आणि तेव्हा या कार्यासाठी पुनर्लेखन आवश्यक असेल.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// प्रत्यय काढून प्रत्यय मिळवते.
    ///
    /// जर स्लाइस X01 एक्स ने समाप्त झाली तर `Some` मध्ये गुंडाळलेले प्रत्यय आधी सबलिस परत करेल.
    /// जर एक्स 100 एक्स रिक्त असेल तर फक्त मूळ स्लाइस परत करेल.
    ///
    /// जर स्लाइस `suffix` ने समाप्त होत नसेल तर `None` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // जेव्हा स्लाईसपॅटर्न अधिक परिष्कृत होते आणि तेव्हा या कार्यासाठी पुनर्लेखन आवश्यक असेल.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// बायनरी दिलेल्या घटकासाठी या क्रमवारी लावलेल्या स्लाइस शोधतात.
    ///
    /// मूल्य आढळल्यास जुळणार्‍या घटकाची अनुक्रमणिका असलेली [`Result::Ok`] परत केली जाईल.
    /// जर तेथे अनेक सामने असतील तर सामन्यांपैकी कोणताही एक परत केला जाऊ शकेल.
    /// जर व्हॅल्यू सापडला नाही तर क्रमवारी लावताना एक जुळणारा घटक घातला जाऊ शकेल अशी अनुक्रमणिका असलेली एक्स 100 एक्स परत केली जाईल.
    ///
    ///
    /// [`binary_search_by`], [`binary_search_by_key`] आणि [`partition_point`] देखील पहा.
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// चार घटकांची मालिका दिसते.
    /// प्रथम आढळतो, एक अद्वितीयपणे निर्धारित स्थितीसह;दुसरा आणि तिसरा सापडला नाही;चौथा `[1, 4]` मधील कोणत्याही स्थानाशी जुळेल.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// आपण क्रमवारी लावून, क्रमवारी लावलेली vector वर आयटम घालायचा असल्यास:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// बायनरी तुलनात्मक कार्यासह या क्रमवारी लावलेल्या स्लाइस शोधतो.
    ///
    /// कंपॅरटर फंक्शनने अंतर्निहित स्लाइसच्या क्रमवारीनुसार सुसंगत ऑर्डरची अंमलबजावणी केली पाहिजे, ऑर्डर कोड परत केला जो आपला युक्तिवाद `Less`, `Equal` किंवा `Greater` इच्छित लक्ष्य आहे की नाही हे दर्शविते.
    ///
    ///
    /// मूल्य आढळल्यास जुळणार्‍या घटकाची अनुक्रमणिका असलेली [`Result::Ok`] परत केली जाईल.जर तेथे अनेक सामने असतील तर सामन्यांपैकी कोणताही एक परत केला जाऊ शकेल.
    /// जर व्हॅल्यू सापडला नाही तर क्रमवारी लावताना एक जुळणारा घटक घातला जाऊ शकेल अशी अनुक्रमणिका असलेली एक्स 100 एक्स परत केली जाईल.
    ///
    /// [`binary_search`], [`binary_search_by_key`] आणि [`partition_point`] देखील पहा.
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// चार घटकांची मालिका दिसते.प्रथम आढळतो, एक अद्वितीयपणे निर्धारित स्थितीसह;दुसरा आणि तिसरा सापडला नाही;चौथा `[1, 4]` मधील कोणत्याही स्थानाशी जुळेल.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // सुरक्षितता: कॉल खालील हल्लेखोरांनी सुरक्षित केला आहे:
            // - `mid >= 0`
            // - `mid < size`: `mid` हे `[left; right)` बंधनाने मर्यादित आहे.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // आम्ही मॅचऐवजी if/else कंट्रोल फ्लो का वापरतो याचे कारण मॅच रीऑर्डर कंपेनेशन ऑपरेशन्स आहेत, जे परफेक्ट संवेदनशील आहेत.
            //
            // हे u8 चे x86 asm आहे: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// बायनरी की एक्स्ट्रक्शन फंक्शनसह या क्रमवारी लावलेल्या स्लाइस शोधतो.
    ///
    /// असे गृहीत धरले की स्लाइस की द्वारे सॉर्ट केली गेली आहे, उदाहरणार्थ समान की एक्सट्रक्शन फंक्शनचा वापर करून [`sort_by_key`] सह.
    ///
    /// मूल्य आढळल्यास जुळणार्‍या घटकाची अनुक्रमणिका असलेली [`Result::Ok`] परत केली जाईल.
    /// जर तेथे अनेक सामने असतील तर सामन्यांपैकी कोणताही एक परत केला जाऊ शकेल.
    /// जर व्हॅल्यू सापडला नाही तर क्रमवारी लावताना एक जुळणारा घटक घातला जाऊ शकेल अशी अनुक्रमणिका असलेली एक्स 100 एक्स परत केली जाईल.
    ///
    ///
    /// [`binary_search`], [`binary_search_by`] आणि [`partition_point`] देखील पहा.
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// त्यांच्या दुसर्‍या घटकांनुसार क्रमवारी लावलेल्या जोड्यांच्या तुकड्यात चार घटकांची मालिका दिसते.
    /// प्रथम आढळतो, एक अद्वितीयपणे निर्धारित स्थितीसह;दुसरा आणि तिसरा सापडला नाही;चौथा `[1, 4]` मधील कोणत्याही स्थानाशी जुळेल.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // `slice::sort_by_key` crate `alloc` मध्ये आहे म्हणून Lint rustdoc::broken_intra_doc_links ला परवानगी आहे आणि `core` बांधताना अद्याप अस्तित्वात नाही.
    //
    // डाउनस्ट्रीम crate: #74481 वर दुवा.आदिम फक्त लिबस्टडी एक्स ०१ एक्स मध्ये दस्तऐवजीकरण केलेले असल्याने, यामुळे व्यवहारात दुवे कधीच होत नाहीत.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// स्लाइसची क्रमवारी लावते, परंतु समान घटकांची क्रमवारी जतन करू शकत नाही.
    ///
    /// हा क्रमवारी अस्थिर आहे (म्हणजेच समान घटकांची पुन्हा क्रमवारी लावू शकते), ठिकाणी (म्हणजेच वाटप करत नाही) आणि *ओ*(*एन*\* एक्स00 एक्स सर्वात वाईट-केस).
    ///
    /// # सध्याची अंमलबजावणी
    ///
    /// सध्याचे अल्गोरिदम ओरसन पीटर्सच्या एक्स 100 एक्स वर आधारित आहे, जे विशिष्ट नमुन्यांसह कापांवर रेषात्मक वेळ मिळविताना यादृच्छिक क्विटकोर्टच्या वेगवान सरासरी घटकास हेपसोर्टच्या सर्वात वाईट प्रकरणांसह एकत्र करते.
    /// हे अध: पतन होणारी प्रकरणे टाळण्यासाठी काही यादृच्छिकरण वापरते, परंतु नेहमी निरोधक वर्तन प्रदान करण्यासाठी निश्चित झेड सीड0झेड सह.
    ///
    /// काही विशिष्ट प्रकरणांमध्ये वगळता हे स्थिर क्रमवारी लावण्यापेक्षा विशेषतः वेगवान असते, उदा. जेव्हा स्लाइसमध्ये अनेक कंटेन्टेटेड क्रमवारी लावलेल्या क्रम असतात.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// तुलनेत कार्यासह स्लाइसची क्रमवारी लावते, परंतु समान घटकांची क्रमवारी जपली जाऊ शकत नाही.
    ///
    /// हा क्रमवारी अस्थिर आहे (म्हणजेच समान घटकांची पुन्हा क्रमवारी लावू शकते), ठिकाणी (म्हणजेच वाटप करत नाही) आणि *ओ*(*एन*\* एक्स00 एक्स सर्वात वाईट-केस).
    ///
    /// कंपेटर फंक्शनने स्लाइसमधील घटकांसाठी एकूण ऑर्डरिंग निश्चित करणे आवश्यक आहे.ऑर्डरिंग एकूण नसल्यास, घटकांची ऑर्डर अनिर्दिष्ट आहे.ऑर्डर ही एकूण ऑर्डर असेल तर (सर्व `a`, `b` आणि `c` साठी):
    ///
    /// * एकूण आणि एन्टिस्मिमेट्रिकः `a < b`, `a == b` किंवा `a > b` पैकी एक सत्य आहे, आणि
    /// * संक्रमित, `a < b` आणि `b < c` सूचित करते `a < c`.हे दोन्ही `==` आणि `>` साठी असणे आवश्यक आहे.
    ///
    /// उदाहरणार्थ, [`f64`] [`Ord`] ची अंमलबजावणी करीत नाही कारण `NaN != NaN`, जेव्हा स्लाइसमध्ये एक्स 100 एक्स नसते तेव्हा आम्ही आमच्या क्रमवारी कार्य म्हणून `partial_cmp` वापरू शकतो.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # सध्याची अंमलबजावणी
    ///
    /// सध्याचे अल्गोरिदम ओरसन पीटर्सच्या एक्स 100 एक्स वर आधारित आहे, जे विशिष्ट नमुन्यांसह कापांवर रेषात्मक वेळ मिळविताना यादृच्छिक क्विटकोर्टच्या वेगवान सरासरी घटकास हेपसोर्टच्या सर्वात वाईट प्रकरणांसह एकत्र करते.
    /// हे अध: पतन होणारी प्रकरणे टाळण्यासाठी काही यादृच्छिकरण वापरते, परंतु नेहमी निरोधक वर्तन प्रदान करण्यासाठी निश्चित झेड सीड0झेड सह.
    ///
    /// काही विशिष्ट प्रकरणांमध्ये वगळता हे स्थिर क्रमवारी लावण्यापेक्षा विशेषतः वेगवान असते, उदा. जेव्हा स्लाइसमध्ये अनेक कंटेन्टेटेड क्रमवारी लावलेल्या क्रम असतात.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // उलट क्रमवारी लावणे
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// की एक्सट्रॅक्शन फंक्शनसह स्लाइसची क्रमवारी लावते, परंतु समान घटकांची क्रमवारी जतन करू शकत नाही.
    ///
    /// हा क्रमवारी अस्थिर आहे (म्हणजेच समान घटकांची पुनर्क्रमित करू शकते), ठिकाणी (म्हणजेच वाटप करत नाही) आणि *ओ*(एम\* * एन *\* एक्स00 एक्स सर्वात वाईट घटना आहे जिथे की फंक्शन *ओ* आहे (*मी*).
    ///
    /// # सध्याची अंमलबजावणी
    ///
    /// सध्याचे अल्गोरिदम ओरसन पीटर्सच्या एक्स 100 एक्स वर आधारित आहे, जे विशिष्ट नमुन्यांसह कापांवर रेषात्मक वेळ मिळविताना यादृच्छिक क्विटकोर्टच्या वेगवान सरासरी घटकास हेपसोर्टच्या सर्वात वाईट प्रकरणांसह एकत्र करते.
    /// हे अध: पतन होणारी प्रकरणे टाळण्यासाठी काही यादृच्छिकरण वापरते, परंतु नेहमी निरोधक वर्तन प्रदान करण्यासाठी निश्चित झेड सीड0झेड सह.
    ///
    /// त्याच्या की कॉलिंग रणनीतीमुळे, की फंक्शन महाग आहे अशा प्रकरणांमध्ये [`sort_unstable_by_key`](#method.sort_unstable_by_key) [`sort_by_cached_key`](#method.sort_by_cached_key) पेक्षा हळू होण्याची शक्यता आहे.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// स्लाईसची अशी क्रमवारी लावा की `index` मधील घटक त्याच्या अंतिम क्रमवारीत स्थितीवर आहे.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// स्लाइसला कंपॅरटर फंक्शनसह पुन्हा क्रमित करा जे `index` मधील घटक त्याच्या अंतिम क्रमवारीत स्थितीवर आहे.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// की एक्सट्रॅक्शन फंक्शनसह स्लाइसची पुन्हा क्रमवारी लावा जसे की `index` मधील घटक अंतिम क्रमवारी लावलेल्या स्थितीत आहे.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// स्लाईसची अशी क्रमवारी लावा की `index` मधील घटक त्याच्या अंतिम क्रमवारीत स्थितीवर आहे.
    ///
    /// या पुनर्क्रमणास अतिरिक्त गुणधर्म आहे की स्थिती `i < index` मधील कोणतेही मूल्य स्थान `j > index` वरील कोणत्याही मूल्यापेक्षा कमी किंवा त्या समान असेल.
    /// याव्यतिरिक्त, हे पुनर्क्रमण अस्थिर आहे (उदा
    /// कोणत्याही समान घटकांची संख्या `index` स्थितीत समाप्त होऊ शकते), ठिकाणी (म्हणजे
    /// वाटप करत नाही) आणि *ओ*(*एन*) सर्वात वाईट घटना.
    /// हे कार्य अन्य लायब्ररीत एक्स/एक्स म्हणून ओळखले जाते.
    /// हे खालील मूल्यांचे तिप्पट रिटर्न देते: दिलेल्या निर्देशांकातील एकापेक्षा कमी सर्व घटक, दिलेल्या निर्देशांकातील मूल्य आणि दिलेल्या निर्देशांकातील एकापेक्षा मोठे सर्व घटक.
    ///
    ///
    /// # सध्याची अंमलबजावणी
    ///
    /// सध्याचे अल्गोरिदम [`sort_unstable`] साठी वापरल्या जाणार्‍या समान क्विकॉर्ट अल्गोरिदमच्या क्विक सिलेक्ट भागावर आधारित आहे.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` असताना Panics, याचा अर्थ रिक्त कापांवर नेहमीच panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // मध्यम शोधा
    /// v.select_nth_unstable(2);
    ///
    /// // आम्हाला फक्त याची हमी आहे की आम्ही निर्दिष्ट केलेल्या निर्देशांकाच्या क्रमवारीनुसार, स्लाइस खालीलपैकी एक असेल.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// स्लाइसला कंपॅरटर फंक्शनसह पुन्हा क्रमित करा जे `index` मधील घटक त्याच्या अंतिम क्रमवारीत स्थितीवर आहे.
    ///
    /// या रीऑर्डरिंगमध्ये अतिरिक्त मालमत्ता आहे जी एक्स 100 एक्स स्थितीतील कोणतेही मूल्य कंपॅरटर फंक्शन वापरुन एक्स01 एक्स स्थितीतील कोणत्याही मूल्यापेक्षा कमी किंवा त्या समान असेल.
    /// याव्यतिरिक्त, हे पुनर्क्रमण अस्थिर आहे (म्हणजेच समान घटकांची संख्या `index` स्थितीत येऊ शकते), जागेवर (म्हणजे वाटप करत नाही) आणि *ओ*(*एन*) सर्वात वाईट-केस.
    /// हे फंक्शन इतर लायब्ररीत एक्स00 एक्स म्हणून देखील ओळखले जाते.
    /// हे खाली दिलेल्या मूल्यांचे त्रिपक्षीय मिळवते: दिलेल्या निर्देशांकातील मूल्यांपेक्षा कमी घटक, दिलेल्या निर्देशांकातील मूल्य आणि प्रदान केलेल्या तुलनात्मक कार्याचा वापर करून दिलेल्या निर्देशांकातील एकापेक्षा मोठे सर्व घटक.
    ///
    ///
    /// # सध्याची अंमलबजावणी
    ///
    /// सध्याचे अल्गोरिदम [`sort_unstable`] साठी वापरल्या जाणार्‍या समान क्विकॉर्ट अल्गोरिदमच्या क्विक सिलेक्ट भागावर आधारित आहे.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` असताना Panics, याचा अर्थ रिक्त कापांवर नेहमीच panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // जर स्लाईस उतरत्या क्रमाने क्रमबद्ध केला असेल तर मध्यमकाचा शोध घ्या.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // आम्हाला फक्त याची हमी आहे की आम्ही निर्दिष्ट केलेल्या निर्देशांकाच्या क्रमवारीनुसार, स्लाइस खालीलपैकी एक असेल.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// की एक्सट्रॅक्शन फंक्शनसह स्लाइसची पुन्हा क्रमवारी लावा जसे की `index` मधील घटक अंतिम क्रमवारी लावलेल्या स्थितीत आहे.
    ///
    /// या पुनर्क्रमणामध्ये अतिरिक्त गुणधर्म आहे की एक्स एक्स एक्स एक्स मधील कोणतेही मूल्य की एक्सट्रक्शन फंक्शनचा वापर करून एक्स एक्स 1 एक्स स्थितीतील कोणत्याही मूल्यापेक्षा कमी किंवा त्या समान असेल.
    /// याव्यतिरिक्त, हे पुनर्क्रमण अस्थिर आहे (म्हणजेच समान घटकांची संख्या `index` स्थितीत येऊ शकते), जागेवर (म्हणजे वाटप करत नाही) आणि *ओ*(*एन*) सर्वात वाईट-केस.
    /// हे फंक्शन इतर लायब्ररीत एक्स00 एक्स म्हणून देखील ओळखले जाते.
    /// हे खाली दिलेल्या मूल्यांचे त्रिपक्षीय मिळवते: दिलेल्या निर्देशांकातील मूल्यांपेक्षा कमी घटक, दिलेल्या निर्देशांकातील मूल्य आणि प्रदान केलेल्या की एक्सट्रक्शन फंक्शनचा वापर करून दिलेल्या निर्देशांकातील एकापेक्षा मोठे सर्व घटक.
    ///
    ///
    /// # सध्याची अंमलबजावणी
    ///
    /// सध्याचे अल्गोरिदम [`sort_unstable`] साठी वापरल्या जाणार्‍या समान क्विकॉर्ट अल्गोरिदमच्या क्विक सिलेक्ट भागावर आधारित आहे.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` असताना Panics, याचा अर्थ रिक्त कापांवर नेहमीच panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // अ‍ॅरे परिपूर्ण मूल्यानुसार क्रमवारी लावल्याप्रमाणे मध्यस्थ परत करा.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // आम्हाला फक्त याची हमी आहे की आम्ही निर्दिष्ट केलेल्या निर्देशांकाच्या क्रमवारीनुसार, स्लाइस खालीलपैकी एक असेल.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// [`PartialEq`] trait अंमलबजावणीनुसार स्लाइसच्या शेवटी सर्व सलग पुनरावृत्ती घटकांना हलवते.
    ///
    ///
    /// दोन काप परत करते.पहिल्यामध्ये सलग पुनरावृत्ती होणारे घटक नसतात.
    /// दुसर्‍यामध्ये निर्दिष्ट क्रमाने सर्व डुप्लीकेट असतात.
    ///
    /// जर स्लाइसची क्रमवारी लावली असेल तर प्रथम परत आलेल्या स्लाइसमध्ये डुप्लिकेट नसतात.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// दिलेल्या समानतेच्या नातेसंबंधास समाधान देणार्‍या स्लाइसच्या शेवटी सलग सर्व घटकांव्यतिरिक्त सर्व हलविते.
    ///
    /// दोन काप परत करते.पहिल्यामध्ये सलग पुनरावृत्ती होणारे घटक नसतात.
    /// दुसर्‍यामध्ये निर्दिष्ट क्रमाने सर्व डुप्लीकेट असतात.
    ///
    /// एक्स 100 एक्स फंक्शनला स्लाइसमधील दोन घटकांचा संदर्भ पुरविला जातो आणि घटक समान तुलना केल्यास ते निश्चित केले पाहिजे.
    /// स्लाइसमधील घटक त्यांच्या क्रमाने उलट क्रमाने पास केले जातात, म्हणून जर एक्स ० एक्स एक्स एक्स १० एक्स परत करेल तर एक्स ०१ एक्स स्लाईसच्या शेवटी हलविला जाईल.
    ///
    ///
    /// जर स्लाइसची क्रमवारी लावली असेल तर प्रथम परत आलेल्या स्लाइसमध्ये डुप्लिकेट नसतात.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // आमच्याकडे `self` चा परस्पर बदल असला तरी आम्ही *अनियंत्रित* बदल करू शकत नाही.एक्स 0 एक्स एक्स कॉल झेडस्पॅनिक 0 झेड करू शकले आहेत, म्हणून स्लाइस कायमच स्थितीत असल्याचे सुनिश्चित केले पाहिजे.
        //
        // आपण हे हाताळण्याचा मार्ग स्वॅप्सचा वापर करून आहे;आम्ही जाताना स्वॅपिंगच्या सर्व घटकांबद्दल पुनरावृत्ती करतो जेणेकरून शेवटी आपण ठेवू इच्छित घटक पुढच्या बाजूला असतात आणि ज्याला आपण नाकारू इच्छितो ते मागे आहेत.
        // त्यानंतर आपण स्लाइस विभाजित करू शकतो.
        // हे ऑपरेशन अद्याप `O(n)` आहे.
        //
        // उदाहरणः आम्ही या राज्यात प्रारंभ करतो, जिथे `r` "पुढील" चे प्रतिनिधित्व करते
        // वाचा "आणि `w` Next_writ` "चे प्रतिनिधित्व करते.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // स्व [एक्स-1] च्या विरूद्ध एक्स 100 एक्स ची तुलना करणे हे डुप्लिकेट नाही, म्हणून आम्ही एक्स 0 एक्स एक्स आणि एक्स0 2 एक्स (आर==ड म्हणून प्रभाव नाही) बदलू आणि नंतर आर आणि डब्ल्यू दोन्ही वाढवून आमच्यासहः
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // स्वत: च्या विरुद्ध एक्स 100 एक्स ची तुलना [डब्ल्यू-1] करणे, हे मूल्य एक डुप्लिकेट आहे, म्हणून आम्ही वाढवितो X01 एक्स परंतु सर्व काही बदलले नाहीः
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // स्व [एक्स-1] च्या विरूद्ध एक्स 100 एक्स ची तुलना करणे हे डुप्लिकेट नाही, म्हणून एक्स01 एक्स आणि एक्स0 2 एक्स आणि अ‍ॅडव्हान्स आर आणि डब्ल्यू स्वॅप करा:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // डुप्लिकेट नाही, पुन्हा करा:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // डुप्लिकेट, स्लाइसचे एक्स00 एक्स.डब्ल्यू येथे विभाजित.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // सुरक्षितता: `while` अट `next_read` आणि `next_write` ची हमी देते
        // हे `len` पेक्षा कमी आहेत, अशा प्रकारे ते `self` आत आहेत.
        // `prev_ptr_write` `ptr_write` पूर्वी एका घटकाकडे निर्देशित करते, परंतु `next_write` 1 ने सुरू होते, म्हणून `prev_ptr_write` कधीही 0 पेक्षा कमी नसते आणि स्लाइसच्या आत असतो.
        // हे एक्स-१० एक्स, एक्स ०4 एक्स आणि एक्स ०२ एक्स डीरेफरेन्स करण्यासाठी आणि एक्स ०3 एक्स, एक्स ०5 एक्स आणि एक्स 00०० एक्सच्या आवश्यकता पूर्ण करते.
        //
        //
        // `next_write` एकदा प्रति लूपमध्ये एकदाच वाढ केली जाते म्हणजे बहुतेक घटकांना वगळले जात नाही जेव्हा ते स्वॅप करणे आवश्यक असते.
        //
        // `ptr_read` आणि `prev_ptr_write` कधीही समान घटकाकडे निर्देश करत नाही.हे सुरक्षित होण्यासाठी `&mut *ptr_read`, `&mut* prev_ptr_write` आवश्यक आहे.
        // स्पष्टीकरण फक्त इतकेच आहे की `next_read >= next_write` नेहमीच सत्य असते, अशा प्रकारे X01 एक्स देखील आहे.
        //
        //
        //
        //
        //
        unsafe {
            // कच्चे पॉइंटर्स वापरुन सीमांकन तपासणी टाळा.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// एकाच की पर्यंत सोडविणार्‍या स्लाईसच्या शेवटी सलग सर्व घटकांव्यतिरिक्त सर्व हलवते.
    ///
    ///
    /// दोन काप परत करते.पहिल्यामध्ये सलग पुनरावृत्ती होणारे घटक नसतात.
    /// दुसर्‍यामध्ये निर्दिष्ट क्रमाने सर्व डुप्लीकेट असतात.
    ///
    /// जर स्लाइसची क्रमवारी लावली असेल तर प्रथम परत आलेल्या स्लाइसमध्ये डुप्लिकेट नसतात.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// स्लाइसला जागेत फिरवते जेणेकरून स्लाइसचे पहिले `mid` एलिमेंट्स शेवटच्या बाजूला सरकतात, तर शेवटच्या X01 एक्स घटक पुढच्या बाजूला सरकतात.
    /// `rotate_left` वर कॉल केल्यानंतर, पूर्वी निर्देशांक `mid` मधील घटक स्लाइसमधील पहिला घटक होईल.
    ///
    /// # Panics
    ///
    /// जर स्लाईसच्या लांबीपेक्षा `mid` मोठे असेल तर हे कार्य panic करेल.लक्षात घ्या की `mid == self.len()` हे _not_ panic करते आणि नाही-रोटेशन आहे.
    ///
    /// # Complexity
    ///
    /// रेषीय घेते (`self.len()`) वेळेत.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// एक उपपरवाना फिरवत आहे:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // सुरक्षितता: `[p.add(mid) - mid, p.add(mid) + k)` श्रेणी क्षुल्लक आहे
        // `ptr_rotate` नुसार आवश्यक वाचन आणि लेखनासाठी वैध.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// स्लाइसला जागेत फिरवते जेणेकरून स्लाइसचे पहिले `self.len() - k` एलिमेंट्स शेवटच्या बाजूला सरकतात, तर शेवटच्या X01 एक्स घटक पुढच्या बाजूला सरकतात.
    /// `rotate_right` वर कॉल केल्यानंतर, पूर्वी निर्देशांक `self.len() - k` मधील घटक स्लाइसमधील पहिला घटक होईल.
    ///
    /// # Panics
    ///
    /// जर स्लाईसच्या लांबीपेक्षा `k` मोठे असेल तर हे कार्य panic करेल.लक्षात घ्या की `k == self.len()` हे _not_ panic करते आणि नाही-रोटेशन आहे.
    ///
    /// # Complexity
    ///
    /// रेषीय घेते (`self.len()`) वेळेत.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// एक सबलीस फिरवा:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // सुरक्षितता: `[p.add(mid) - mid, p.add(mid) + k)` श्रेणी क्षुल्लक आहे
        // `ptr_rotate` नुसार आवश्यक वाचन आणि लेखनासाठी वैध.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// `value` क्लोनिंग करून घटकांसह `self` भरते.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// क्लोजरला वारंवार कॉल करून परत आलेल्या घटकांसह एक्स00 एक्स भरते.
    ///
    /// ही पद्धत नवीन मूल्ये तयार करण्यासाठी क्लोजरचा वापर करते.आपण त्याऐवजी दिले मूल्य [`Clone`] इच्छित असल्यास, [`fill`] वापरा.
    /// आपण मूल्ये व्युत्पन्न करण्यासाठी [`Default`] trait वापरू इच्छित असल्यास आपण [`Default::default`] वितर्क म्हणून पास करू शकता.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// `src` मधील घटकांना `self` मध्ये कॉपी करते.
    ///
    /// `src` ची लांबी `self` समान असणे आवश्यक आहे.
    ///
    /// जर `T` ने `Copy` लागू केले तर ते [`copy_from_slice`] वापरण्यासाठी अधिक परफॉरमेन्ट असू शकते.
    ///
    /// # Panics
    ///
    /// दोन तुकड्यांची लांबी भिन्न असल्यास हे कार्य panic करेल.
    ///
    /// # Examples
    ///
    /// एका स्लाइसमधून दुसर्‍या घटकात क्लोनिंग करणे:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // काप समान लांबीचे असणे आवश्यक आहे, आम्ही स्त्रोत स्लाइस चार घटकांमधून दोन पर्यंत करतो.
    /// // आम्ही असे न केल्यास ते panic करेल.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust ने अंमलबजावणी केली की विशिष्ट व्याप्तीमधील डेटाच्या विशिष्ट तुकड्याचा कोणताही बदल न करता संदर्भ असू शकतो.
    /// यामुळे, एकाच स्लाइसवर `clone_from_slice` वापरण्याचा प्रयत्न केल्यास कंपाईल अयशस्वी होईल:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// यावर कार्य करण्यासाठी, आम्ही स्लाइसमधून दोन भिन्न उप-स्लाइस तयार करण्यासाठी [`split_at_mut`] वापरू शकतो:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// मेम्पी वापरुन, एक्स ० ए एक्स वरुन सर्व घटकांची `self` मध्ये कॉपी करते.
    ///
    /// `src` ची लांबी `self` समान असणे आवश्यक आहे.
    ///
    /// `T` `Copy` लागू करत नसल्यास, [`clone_from_slice`] वापरा.
    ///
    /// # Panics
    ///
    /// दोन तुकड्यांची लांबी भिन्न असल्यास हे कार्य panic करेल.
    ///
    /// # Examples
    ///
    /// एका स्लाइसमधून दोन घटकांची दुसर्‍यामध्ये कॉपी करणे:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // काप समान लांबीचे असणे आवश्यक आहे, आम्ही स्त्रोत स्लाइस चार घटकांमधून दोन पर्यंत करतो.
    /// // आम्ही असे न केल्यास ते panic करेल.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust ने अंमलबजावणी केली की विशिष्ट व्याप्तीमधील डेटाच्या विशिष्ट तुकड्याचा कोणताही बदल न करता संदर्भ असू शकतो.
    /// यामुळे, एकाच स्लाइसवर `copy_from_slice` वापरण्याचा प्रयत्न केल्यास कंपाईल अयशस्वी होईल:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// यावर कार्य करण्यासाठी, आम्ही स्लाइसमधून दोन भिन्न उप-स्लाइस तयार करण्यासाठी [`split_at_mut`] वापरू शकतो:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // कॉल साइट फुलू नयेत म्हणून झेडस्पॅनिक ० झेड कोड पथ एका कोल्ड फंक्शनमध्ये ठेवला होता.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // सुरक्षितता: `self` परिभाषानुसार `self.len()` घटकांसाठी वैध आहे आणि `src` होते
        // समान लांबी असल्याचे तपासले.
        // काप ओव्हरलॅप होऊ शकत नाहीत कारण बदलण्यायोग्य संदर्भ विशेष आहेत.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// मेमॅव्ह वापरुन स्लाइसच्या एका भागापासून घटकांच्या स्वतःच्या दुसर्‍या भागावर कॉपी करतो.
    ///
    /// `src` येथून कॉपी करण्यासाठी `self` मधील श्रेणी आहे.
    /// `dest` कॉपी करण्यासाठी `self` मधील श्रेणीची प्रारंभिक अनुक्रमणिका आहे, ज्याची लांबी `src` समान असेल.
    /// दोन श्रेणी ओव्हरलॅप होऊ शकतात.
    /// दोन श्रेणींचे टोक `self.len()` पेक्षा कमी किंवा त्यासारखे असणे आवश्यक आहे.
    ///
    /// # Panics
    ///
    /// जर स्लाइसच्या शेवटी श्रेणीची मर्यादा ओलांडली असेल किंवा `src` चा शेवट सुरू होण्यापूर्वी असेल तर हे कार्य panic करेल.
    ///
    ///
    /// # Examples
    ///
    /// स्लाइसमध्ये चार बाइट कॉपी करत आहे:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // सुरक्षितताः `ptr::copy` च्या सर्व अटी वरील तपासल्या गेल्या आहेत,
        // जे `ptr::add` साठी आहेत.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// `other` मधील सर्व घटकांना एक्स 100 एक्समधील अदलाबदल करते.
    ///
    /// `other` ची लांबी `self` समान असणे आवश्यक आहे.
    ///
    /// # Panics
    ///
    /// दोन तुकड्यांची लांबी भिन्न असल्यास हे कार्य panic करेल.
    ///
    /// # Example
    ///
    /// कापांमधून दोन घटक अदलाबदल करणे:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust ने अंमलबजावणी केली की विशिष्ट व्याप्तीमधील डेटाच्या विशिष्ट तुकड्याचा केवळ एक बदलता संदर्भ असू शकतो.
    ///
    /// यामुळे, एकाच स्लाइसवर `swap_with_slice` वापरण्याचा प्रयत्न केल्यास कंपाईल अयशस्वी होईल:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// यावर कार्य करण्यासाठी, आम्ही स्लाइसमधून दोन भिन्न म्युटेबल उप-स्लाइस तयार करण्यासाठी [`split_at_mut`] वापरू शकतो:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // सुरक्षितता: `self` परिभाषानुसार `self.len()` घटकांसाठी वैध आहे आणि `src` होते
        // समान लांबी असल्याचे तपासले.
        // काप ओव्हरलॅप होऊ शकत नाहीत कारण बदलण्यायोग्य संदर्भ विशेष आहेत.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// `align_to{,_mut}` साठी मध्यम आणि पिछाडीच्या तुकड्यांच्या लांबीची गणना करण्यासाठी कार्य.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // आम्ही `rest` बद्दल काय करणार आहोत हे शोधून काढले की आपण सर्वात कमी संख्येने `T`s मध्ये किती`U`s ठेवू शकतो.
        //
        // आणि अशा प्रत्येक "multiple" साठी आम्हाला किती `T`s आवश्यक आहेत.
        //
        // उदाहरणार्थ टी=यू 8 यू=यू 16 याचा विचार करा.मग आपण 1 यू ला 2 एस मध्ये ठेवू.सोपे.
        // आता, उदाहरणार्थ आकार_या: :<T>=16, आकार_::::<U>24</u>
        // आम्ही एक्स 3 एक्स स्लाइसमध्ये प्रत्येक 3 एस च्या जागी 2 यू ठेवू शकतो.
        // जरा जटिल.
        //
        // याची गणना करण्याचे सूत्र असेः
        //
        // यूएस=एक्स 100 एक्स/आकार_: :::<U>टीएस=एक्स ० ए एक्स/आकार_::</u><T>
        //
        // विस्तारित आणि सरलीकृत:
        //
        // यूएस=आकार_: :<T>/gcd(size_of::<T>, size_of::<U>) टीएस=आकार_::::<U>gcd(size_of::<T>, size_of::<U>)</u>
        //
        // सुदैवाने हे सर्व स्थिर-मूल्यमापन केले जात असल्याने ... येथे कामगिरी महत्त्वाची नाही!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // पुनरावृत्ती झालेल्या स्टेनचे अल्गोरिदम आपण अद्याप हे `const fn` केले पाहिजे (आणि जर आम्ही केले तर रिकर्झिव्ह अल्गोरिदम परत यावे) कारण या सर्व गोष्टींवर नियंत्रण ठेवण्यासाठी एलएलव्हीएमवर अवलंबून राहणे म्हणजे आहे…तसेच, ते मला अस्वस्थ करते.
            //
            //

            // सुरक्षितता: `a` आणि `b` शून्य नसलेली मूल्ये असल्याचे तपासले गेले.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // बी पासून 2 चे सर्व घटक काढा
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // सुरक्षितता: `b` शून्य नसलेले असल्याचे तपासले गेले आहे.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // या ज्ञानाने सशस्त्र, आम्ही किती यूएस फिट होऊ शकतो हे शोधू शकतो!
        let us_len = self.len() / ts * us;
        // आणि पिछाडीच्या तुकड्यात किती `T`s असतील!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// स्लाइस दुसर्‍या प्रकारच्या स्लाइसमध्ये रुपांतरित करा, त्या प्रकारची संरेखन सुनिश्चित केली जाईल.
    ///
    /// ही पद्धत स्लाइस तीन वेगळ्या तुकड्यांमध्ये विभाजित करते: प्रत्यय, नवीन प्रकारची योग्यरित्या संरेखित केलेली मध्यम स्लाइस आणि प्रत्यय स्लाइस.
    /// दिलेल्या प्रकार आणि इनपुट स्लाइससाठी पद्धत मधल्या स्लाईसची सर्वात मोठी लांबी शक्य करते परंतु केवळ आपल्या अल्गोरिदमची कार्यक्षमता त्यावर अवलंबून असावी, तिची शुद्धता नाही.
    ///
    /// प्रत्येकाचा इनपुट डेटा उपसर्ग किंवा प्रत्यय स्लाइस म्हणून परत करणे परवानगी आहे.
    ///
    /// एकतर इनपुट घटक `T` किंवा आउटपुट घटक `U` शून्य-आकाराचे असतात आणि काहीही विभाजित न करता मूळ स्लाइस परत करेल तेव्हा या पद्धतीचा कोणताही हेतू नसतो.
    ///
    /// # Safety
    ///
    /// परत आलेल्या मध्यम स्लाइसमधील घटकांच्या संदर्भात ही पद्धत मूलत: एक `transmute` आहे, म्हणून एक्स ०१ एक्स संबंधित सर्व सामान्य सावधानता देखील येथे लागू होतात.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // लक्षात ठेवा की यापैकी बहुतेक कार्य स्थिर-मूल्यांकन केले जाईल,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // झेडएसटी विशेषपणे हाताळा, जे आहे-त्यांना अजिबात हाताळू नका.
            return (self, &[], &[]);
        }

        // प्रथम, पहिल्या आणि द्वितीय स्लाइसमध्ये आपण कोणत्या बिंदूत विभाजन करू या हे जाणून घ्या.
        // ptr.align_offset सह सोपे.
        let ptr = self.as_ptr();
        // सुरक्षितता: तपशीलवार सुरक्षा टिप्पणीसाठी `align_to_mut` पद्धत पहा.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // सुरक्षितताः आता `rest` निश्चितपणे संरेखित केले आहे, म्हणून `from_raw_parts` ठीक आहे,
            // कॉलर हमी देतो की आम्ही `T` ला `U` मध्ये सुरक्षितपणे संक्रमित करू शकतो.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// स्लाइस दुसर्‍या प्रकारच्या स्लाइसमध्ये रुपांतरित करा, त्या प्रकारची संरेखन सुनिश्चित केली जाईल.
    ///
    /// ही पद्धत स्लाइस तीन वेगळ्या तुकड्यांमध्ये विभाजित करते: प्रत्यय, नवीन प्रकारची योग्यरित्या संरेखित केलेली मध्यम स्लाइस आणि प्रत्यय स्लाइस.
    /// दिलेल्या प्रकार आणि इनपुट स्लाइससाठी पद्धत मधल्या स्लाईसची सर्वात मोठी लांबी शक्य करते परंतु केवळ आपल्या अल्गोरिदमची कार्यक्षमता त्यावर अवलंबून असावी, तिची शुद्धता नाही.
    ///
    /// प्रत्येकाचा इनपुट डेटा उपसर्ग किंवा प्रत्यय स्लाइस म्हणून परत करणे परवानगी आहे.
    ///
    /// एकतर इनपुट घटक `T` किंवा आउटपुट घटक `U` शून्य-आकाराचे असतात आणि काहीही विभाजित न करता मूळ स्लाइस परत करेल तेव्हा या पद्धतीचा कोणताही हेतू नसतो.
    ///
    /// # Safety
    ///
    /// परत आलेल्या मध्यम स्लाइसमधील घटकांच्या संदर्भात ही पद्धत मूलत: एक `transmute` आहे, म्हणून एक्स ०१ एक्स संबंधित सर्व सामान्य सावधानता देखील येथे लागू होतात.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // लक्षात ठेवा की यापैकी बहुतेक कार्य स्थिर-मूल्यांकन केले जाईल,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // झेडएसटी विशेषपणे हाताळा, जे आहे-त्यांना अजिबात हाताळू नका.
            return (self, &mut [], &mut []);
        }

        // प्रथम, पहिल्या आणि द्वितीय स्लाइसमध्ये आपण कोणत्या बिंदूत विभाजन करू या हे जाणून घ्या.
        // ptr.align_offset सह सोपे.
        let ptr = self.as_ptr();
        // सुरक्षितता: आम्ही आम्ही आमच्यासाठी यू साठी संरेखित पॉईंटर्स वापरू याची खात्री करीत आहोत
        // बाकीची पद्धत.यू साठी लक्ष्यित संरेखन सह&[टी] कडे पॉईंटर पाठवून हे केले जाते.
        // `crate::ptr::align_offset` योग्यरित्या संरेखित आणि वैध पॉइंटर `ptr` (हे `self` च्या संदर्भातून आले आहे) आणि दोनची शक्ती असलेल्या आकारासह म्हटले जाते (कारण ते यू साठी संरेखनातून आले आहे), त्याच्या सुरक्षिततेच्या मर्यादेचे समाधान करीत आहे.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // आम्ही या नंतर पुन्हा `rest` वापरू शकत नाही, ज्यामुळे त्याचे उपनाव `mut_ptr` अवैध होईल!सुरक्षितता: `align_to` साठी टिप्पण्या पहा.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// या स्लाइसमधील घटकांची क्रमवारी लावली आहे का ते तपासते.
    ///
    /// म्हणजेच, प्रत्येक घटक `a` आणि त्यातील खालील घटक `b` साठी, `a <= b` असणे आवश्यक आहे.जर स्लाइस अचूक शून्य किंवा एक घटक उत्पन्न देत असेल तर `true` परत येईल.
    ///
    /// लक्षात घ्या की `Self::Item` केवळ `PartialOrd` असल्यास, परंतु X01 एक्स नसल्यास, वरील परिभाषा असे सूचित करते की कोणतेही दोन सलग आयटम तुलना न केल्यास हे कार्य `false` परत करते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// या तुकडीतील घटक दिलेल्या कंपॅरेटर फंक्शनचा वापर करून क्रमवारी लावलेले आहेत का ते तपासेल.
    ///
    /// `PartialOrd::partial_cmp` वापरण्याऐवजी हे कार्य दोन घटकांची क्रमवारी निश्चित करण्यासाठी दिलेल्या `compare` फंक्शनचा वापर करते.
    /// त्या व्यतिरिक्त, हे [`is_sorted`] च्या समतुल्य आहे;अधिक माहितीसाठी त्याचे दस्तऐवजीकरण पहा.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// या स्लाइसमधील घटक दिलेल्या की एक्सट्रक्शन फंक्शनचा वापर करून क्रमवारी लावलेले आहेत की नाही हे तपासते.
    ///
    /// स्लाइसच्या घटकांची थेट तुलना करण्याऐवजी हे फंक्शन `f` द्वारे निश्चित केल्याप्रमाणे घटकांच्या किल्लीची तुलना करते.
    /// त्या व्यतिरिक्त, हे [`is_sorted`] च्या समतुल्य आहे;अधिक माहितीसाठी त्याचे दस्तऐवजीकरण पहा.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// दिलेल्या पूर्वानुसार (दुसर्‍या विभाजनाच्या पहिल्या घटकाची अनुक्रमणिका) नुसार विभाजन बिंदूची अनुक्रमणिका मिळवते.
    ///
    /// दिलेल्या पूर्वानुमानानुसार स्लाइसचे विभाजन केल्याचे गृहित धरले जाते.
    /// याचा अर्थ असा आहे की ज्या सर्व घटकांसाठी पूर्वानुमान खरे आहे ते स्लाईसच्या सुरूवातीस आहेत आणि ज्या सर्व घटकांसाठी पूर्वानुमान चुकीचे आहे ते शेवटी आहेत.
    ///
    /// उदाहरणार्थ, एक्स 100 एक्स हे प्रिडिकेट x% 2!=0 अंतर्गत विभाजित केलेले आहे (सर्व विचित्र संख्या सुरूवात आहेत, सर्व अगदी शेवटी).
    ///
    /// जर या स्लाइसचे विभाजन केले नाही तर परतलेला निकाल अनिर्दिष्ट आणि अर्थहीन आहे, कारण ही पद्धत एक प्रकारचा बायनरी शोध करते.
    ///
    /// [`binary_search`], [`binary_search_by`] आणि [`binary_search_by_key`] देखील पहा.
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // सुरक्षितता: जेव्हा `left < right`, `left <= mid < right`.
            // म्हणून `left` नेहमीच वाढत राहतो आणि `right` नेहमीच कमी होतो आणि त्यापैकी एक निवडला जातो.दोन्ही प्रकरणांमध्ये `left <= right` समाधानी आहे.म्हणूनच जर एका चरणात `left < right` असेल तर, `left <= right` पुढील चरणात समाधानी आहे.
            //
            // म्हणून जोपर्यंत `left != right` आहे तोपर्यंत `0 <= left < right <= len` समाधानी आहे आणि जर या प्रकरणात `0 <= mid < len` समाधानी असेल तर.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: आम्ही त्यांना समान लांबीवर स्पष्टपणे कापून टाकणे आवश्यक आहे
        // ऑप्टिमाइझरला एलिड सीम तपासणी करणे सुलभ करण्यासाठी.
        // परंतु यावर अवलंबून राहू शकत नाही म्हणून आमच्याकडे टी: कॉपीसाठी देखील एक स्पष्ट स्पेशलायझेशन आहे.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// रिक्त स्लाइस तयार करते.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// एक बदलण्याजोगी रिक्त स्लाइस तयार करते.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// कापांमध्ये नमुने, सध्या केवळ `strip_prefix` आणि `strip_suffix` द्वारे वापरले जातात.
/// झेडफ्यूचर0 झेड पॉईंटवर, आम्ही आशा करतो की एक्स 100 एक्स (जे लेखनाच्या वेळी `str` पर्यंत मर्यादित होते) कापांपर्यंत सामान्य केले जाईल आणि नंतर हे झेडट्रेट0 झेड बदलले जाईल किंवा रद्द केले जाईल.
///
pub trait SlicePattern {
    /// स्लाइसचा घटक प्रकार जुळला जात आहे.
    type Item;

    /// सध्या, `SlicePattern` च्या ग्राहकांना स्लाइसची आवश्यकता आहे.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}