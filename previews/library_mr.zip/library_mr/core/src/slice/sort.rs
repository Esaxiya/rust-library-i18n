//! स्लाइस सॉर्टिंग
//!
//! या मॉड्यूलमध्ये ओरसन पीटर्सच्या नमुना-पराभव करणार्‍या क्विकॉर्टवर आधारित सॉर्टिंग अल्गोरिदम आहे, ज्या येथे प्रकाशित केले: <https://github.com/orlp/pdqsort>
//!
//!
//! अस्थिर सॉर्टींग लिबकोरशी सुसंगत आहे कारण ते आमच्या स्थिर सॉर्टिंग अंमलबजावणीच्या विपरीत मेमरीचे वाटप करीत नाही.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// सोडल्यास `src` कडील `dest` मध्ये प्रती.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // सुरक्षा: हा एक मदतनीस वर्ग आहे.
        //          कृपया अचूकतेसाठी त्याचा वापर पहा.
        //          बहुदा, याची खात्री असणे आवश्यक आहे की `src` आणि `dst` हे `ptr::copy_nonoverlapping` नुसार आच्छादित होत नाही.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// प्रथम घटकास मोठ्या किंवा समान घटकाची पूर्तता होईपर्यंत उजवीकडे सरकवा.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // सुरक्षितताः खाली असुरक्षित ऑपरेशन्समध्ये बाउंड चेकशिवाय अनुक्रमित करणे समाविष्ट आहे (`get_unchecked` आणि `get_unchecked_mut`)
    // आणि मेमरी (`ptr::copy_nonoverlapping`) कॉपी करत आहे.
    //
    // अ.अनुक्रमणिका:
    //  1. आम्ही अ‍ॅरेचा आकार>=2 वर तपासला.
    //  2. आम्ही करू असे सर्व अनुक्रमणिका नेहमी कमाल {0 <= index < len} दरम्यान असते.
    //
    // बी.मेमरी कॉपी करत आहे
    //  1. आम्ही संदर्भांसाठी पॉईंटर्स प्राप्त करीत आहोत जे वैध असल्याची हमी दिलेली आहे.
    //  2. ते आच्छादित होऊ शकत नाहीत कारण स्लाइसच्या निर्देशांकांमध्ये फरक करण्यासाठी आम्ही पॉईंटर्स प्राप्त करतो.
    //     बहुदा, `i` आणि `i-1`.
    //  3. जर स्लाइस योग्य प्रकारे संरेखित केली गेली असेल तर घटक योग्य प्रकारे संरेखित केले जातील.
    //     स्लाईस योग्य प्रकारे संरेखित केली आहे याची खात्री करणे ही कॉलरची जबाबदारी आहे.
    //
    // पुढील तपशीलासाठी खाली टिप्पण्या पहा.
    unsafe {
        // जर प्रथम दोन घटक ऑर्डर-आउट असतील तर ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // प्रथम घटक स्टॅक-वाटप चल मध्ये वाचा.
            // जर खालील तुलना ऑपरेशन panics असेल तर, `hole` सोडले जाईल आणि स्वयंचलितपणे घटक परत स्लाइसमध्ये लिहा.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Element i`-th घटकाला डावीकडे एक स्थान हलवा, अशा प्रकारे भोक उजवीकडे हलवा.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` सोडले जाते आणि अशा प्रकारे `v` मधील उर्वरित छिद्रात X01 एक्स कॉपी करते.
        }
    }
}

/// शेवटचा घटक लहान किंवा समान घटकापर्यंत डावीकडे हलवा.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // सुरक्षितताः खाली असुरक्षित ऑपरेशन्समध्ये बाउंड चेकशिवाय अनुक्रमित करणे समाविष्ट आहे (`get_unchecked` आणि `get_unchecked_mut`)
    // आणि मेमरी (`ptr::copy_nonoverlapping`) कॉपी करत आहे.
    //
    // अ.अनुक्रमणिका:
    //  1. आम्ही अ‍ॅरेचा आकार>=2 वर तपासला.
    //  2. आम्ही करू असे सर्व अनुक्रमणिका नेहमी कमाल `0 <= index < len-1` दरम्यान असते.
    //
    // बी.मेमरी कॉपी करत आहे
    //  1. आम्ही संदर्भांसाठी पॉईंटर्स प्राप्त करीत आहोत जे वैध असल्याची हमी दिलेली आहे.
    //  2. ते आच्छादित होऊ शकत नाहीत कारण स्लाइसच्या निर्देशांकांमध्ये फरक करण्यासाठी आम्ही पॉईंटर्स प्राप्त करतो.
    //     बहुदा, `i` आणि `i+1`.
    //  3. जर स्लाइस योग्य प्रकारे संरेखित केली गेली असेल तर घटक योग्य प्रकारे संरेखित केले जातील.
    //     स्लाईस योग्य प्रकारे संरेखित केली आहे याची खात्री करणे ही कॉलरची जबाबदारी आहे.
    //
    // पुढील तपशीलासाठी खाली टिप्पण्या पहा.
    unsafe {
        // शेवटचे दोन घटक ऑर्डर-आउट असल्यास ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // स्टॅक-वाटप केलेल्या चल मध्ये शेवटचा घटक वाचा.
            // जर खालील तुलना ऑपरेशन panics असेल तर, `hole` सोडले जाईल आणि स्वयंचलितपणे घटक परत स्लाइसमध्ये लिहा.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Element i`-th घटक एका जागेला उजवीकडे हलवा, अशा प्रकारे भोक डावीकडे हलवा.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` सोडले जाते आणि अशा प्रकारे `v` मधील उर्वरित छिद्रात X01 एक्स कॉपी करते.
        }
    }
}

/// सुमारे अनेक ऑर्डर ऑर्डरच्या घटकांना हलवून अर्धवट एक स्लाईस सॉर्ट करते.
///
/// स्लाइस शेवटी क्रमवारी लावल्यास `true` मिळवते.हे कार्य *ओ*(*एन*) सर्वात वाईट प्रकरण आहे.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // ऑर्डर-आउट-ऑर्डर जोड्यांची अधिकतम संख्या जी शिफ्ट होतील.
    const MAX_STEPS: usize = 5;
    // जर तुकडा यापेक्षा छोटा असेल तर कोणत्याही घटकांना बदलू नका.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // सुरक्षितता: आम्ही आधीच स्पष्टपणे `i < len` सह बंधन तपासणी केली.
        // आमची त्यानंतरची सर्व अनुक्रमणिका केवळ `0 <= index < len` श्रेणीत आहे
        unsafe {
            // ऑर्डर ऑफ ऑर्डर घटकांची पुढील जोड शोधा.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // आपण केले?
        if i == len {
            return true;
        }

        // कार्यक्षमतेची किंमत असलेल्या लहान अ‍ॅरेवर घटक बदलू नका.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // घटकांची आढळलेली जोडी स्वॅप करा.हे त्यांना योग्य क्रमाने ठेवते.
        v.swap(i - 1, i);

        // लहान घटक डावीकडे बदला.
        shift_tail(&mut v[..i], is_less);
        // मोठा घटक उजवीकडे बदला.
        shift_head(&mut v[i..], is_less);
    }

    // मर्यादित संख्येच्या चरणांमध्ये स्लाइस क्रमवारीत ठेवणे व्यवस्थापित केले नाही.
    false
}

/// समाविष्ट क्रमवारी वापरुन स्लाइसची क्रमवारी लावा, जे *ओ*(*एन*^ 2) सर्वात वाईट-केस आहे.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// हेपसोर्ट वापरुन एक्स 100 एक्सची क्रमवारी लावते, जे *ओ*(*एन*\* एक्स01 एक्स सर्वात वाईट-केसची हमी देते)
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // हा बायनरी ढीग आक्रमक `parent >= child` चा आदर करतो.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // `node` ची मुले:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // मोठ्या मुलाची निवड करा.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // आक्रमणकर्त्याने `node` वर ठेवल्यास थांबा.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // मोठ्या मुलासह `node` अदलाबदल करा, एक पाऊल खाली हलवा आणि चालायला सुरू ठेवा.
            v.swap(node, greater);
            node = greater;
        }
    };

    // रेखीय वेळेत ढीग तयार करा.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // ढीग पासून जास्तीत जास्त घटक पॉप.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// `v` पेक्षा लहान घटकांमध्ये `v` चे विभाजन, त्यानंतर एक्स 100 एक्स पेक्षा मोठे किंवा समान घटक.
///
///
/// `pivot` पेक्षा लहान घटकांची संख्या मिळवते.
///
/// शाखा कार्यालयाची किंमत कमी करण्यासाठी विभाजन करणे ब्लॉक-बाय-ब्लॉक केले जाते.
/// ही कल्पना एक्स 100 एक्स पेपरमध्ये सादर केली गेली आहे.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // ठराविक ब्लॉकमधील घटकांची संख्या.
    const BLOCK: usize = 128;

    // विभाजन अल्गोरिदम पूर्ण होईपर्यंत खालील चरणांची पुनरावृत्ती करते:
    //
    // 1. मुख्य पेक्षा मोठे किंवा समान घटक ओळखण्यासाठी डावीकडून ब्लॉक ट्रेस करा.
    // 2. मुख्य पेक्षा लहान घटक ओळखण्यासाठी उजवीकडून ब्लॉक ट्रेस करा.
    // 3. डाव्या व उजव्या बाजूस ओळखलेल्या घटकांची देवाणघेवाण करा.
    //
    // घटकांच्या ब्लॉकसाठी आम्ही खालील चल ठेवतो:
    //
    // 1. `block` - ब्लॉकमधील घटकांची संख्या.
    // 2. `start` - `offsets` अ‍ॅरेमध्ये पॉईंटर प्रारंभ करा.
    // 3. `end` - `offsets` अ‍ॅरे मधील अंतिम पॉईंटर
    // 4. se ऑफसेट, ब्लॉकमधील ऑर्डर-ऑर्डर घटकांची सूचक.

    // डावीकडील सध्याचा ब्लॉक (`l` ते `l.add(block_l)`) पर्यंत.
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // उजवीकडील सध्याचा ब्लॉक (`r.sub(block_r)` to `r`) पासून.
    // सुरक्षितता: .add() च्या दस्तऐवजीकरणात असे नमूद केले आहे की X01 एक्स नेहमीच सुरक्षित असतो`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: जेव्हा आम्हाला व्हीएलए मिळतात, त्याऐवजी `min(v.len(), 2 * ब्लॉक) लांबीचा एक अ‍ॅरे तयार करण्याचा प्रयत्न करा
    // `BLOCK` लांबीच्या दोन निश्चित-आकाराच्या अ‍ॅरेपेक्षा.व्हीएलए अधिक कॅशे-कार्यक्षम असू शकतात.

    // `l` (inclusive) आणि `r` (exclusive) दरम्यान पॉईंटर्समधील घटकांची संख्या मिळवते.
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // जेव्हा `l` आणि `r` खूप जवळ येतात तेव्हा विभाजन ब्लॉक-बाय-ब्लॉक करून पूर्ण केले.
        // नंतर उर्वरित घटकांचे विभाजन करण्यासाठी आम्ही काही पॅच-अप कार्य करतो.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // उर्वरित घटकांची संख्या (अद्याप पिव्होटशी तुलना केली जात नाही).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // ब्लॉक आकार समायोजित करा जेणेकरून डावा आणि उजवा ब्लॉक आच्छादित होऊ नये, परंतु संपूर्ण उर्वरित अंतर कव्हर करण्यासाठी उत्तम प्रकारे संरेखित करा.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // डावीकडून `block_l` घटकांचा शोध घ्या.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // सुरक्षितताः खालील असमाधानकारक ऑपरेशन्समध्ये एक्स 100 एक्सचा वापर समाविष्ट आहे.
                //         फंक्शनला आवश्यक असलेल्या अटींनुसार आम्ही त्यांचे समाधान करतो कारणः
                //         1. `offsets_l` स्टॅक-वाटप केले जाते आणि म्हणून स्वतंत्र वाटप ऑब्जेक्ट मानले जाते.
                //         2. कार्य `is_less` एक `bool` परत करते.
                //            `bool` टाकणे कधीही `isize` ओव्हरफ्लो होणार नाही.
                //         3. आम्ही हमी दिली आहे की एक्स 01 एक्स एक्स 100 एक्स असेल.
                //            शिवाय, एक्स 100 एक्स सुरुवातीस एक्स 0 एक्स एक्सच्या प्रारंभ बिंदूवर सेट केले होते जे स्टॅकवर घोषित केले गेले होते.
                //            अशाप्रकारे, आम्हाला माहित आहे की अगदी सर्वात वाईट परिस्थितीतही (`is_less` चे सर्व आमंत्रणे खोटे दर्शविते) आम्ही फक्त कमाल 1 बाइट शेवटपर्यंत पास होऊ.
                //        येथे आणखी एक असमाधानकारक ऑपरेशन म्हणजे `elem` चे डीरेफरन्सिंग आहे.
                //        तथापि, एक्स 100 एक्स सुरुवातीला स्लाईससाठी प्रारंभ बिंदू होता जो नेहमी वैध असतो.
                unsafe {
                    // शाखाविहीन तुलना.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // उजवीकडून `block_r` X घटकांचा शोध घ्या.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // सुरक्षितताः खालील असमाधानकारक ऑपरेशन्समध्ये एक्स 100 एक्सचा वापर समाविष्ट आहे.
                //         फंक्शनला आवश्यक असलेल्या अटींनुसार आम्ही त्यांचे समाधान करतो कारणः
                //         1. `offsets_r` स्टॅक-वाटप केले जाते आणि म्हणून स्वतंत्र वाटप ऑब्जेक्ट मानले जाते.
                //         2. कार्य `is_less` एक `bool` परत करते.
                //            `bool` टाकणे कधीही `isize` ओव्हरफ्लो होणार नाही.
                //         3. आम्ही हमी दिली आहे की एक्स 01 एक्स एक्स 100 एक्स असेल.
                //            शिवाय, एक्स 100 एक्स सुरुवातीस एक्स 0 एक्स एक्सच्या प्रारंभ बिंदूवर सेट केले होते जे स्टॅकवर घोषित केले गेले होते.
                //            अशाप्रकारे, आम्हाला माहित आहे की अगदी सर्वात वाईट परिस्थितीतही (`is_less` चे सर्व आमंत्रण खरे ठरते) आपण फक्त जास्तीत जास्त 1 बाइट शेवटपर्यंत पास होऊ.
                //        येथे आणखी एक असमाधानकारक ऑपरेशन म्हणजे `elem` चे डीरेफरन्सिंग आहे.
                //        तथापि, `elem` सुरुवातीच्या शेवटी `1 *sizeof(T)` होते आणि त्यात प्रवेश करण्यापूर्वी आम्ही हे `1* sizeof(T)` ने कमी केले.
                //        तसेच, `block_r` हे `BLOCK` पेक्षा कमी असल्याचे प्रतिपादन केले गेले होते आणि `elem` म्हणून स्लाइसच्या सुरूवातीच्या दिशेने जाईल.
                unsafe {
                    // शाखाविहीन तुलना.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // डावी आणि उजवीकडील अदलाबदल करण्यासाठी ऑर्डर-ऑर्डर घटकांची संख्या.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // त्यावेळी एक जोडी अदलाबदल करण्याऐवजी चक्रीय क्रम बदलणे अधिक कार्यक्षम आहे.
            // हे अदलाबदल करण्यासारखे काटेकोरपणे नाही, परंतु कमी मेमरी ऑपरेशन्स वापरून समान परिणाम देतात.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // डाव्या ब्लॉकमधील सर्व ऑर्डर ऑर्डर घटक हलविले गेले.पुढील ब्लॉक वर जा.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // उजव्या ब्लॉकमधील सर्व आउट-ऑर्डर घटक हलवले गेले.मागील ब्लॉक वर जा.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // आता जे काही शिल्लक आहे ते जास्तीत जास्त एक ब्लॉक आहे (एकतर डावा किंवा उजवा) ऑर्डर-ऑर्डर घटकांसह ज्याला हलविणे आवश्यक आहे.
    // असे उर्वरित घटक त्यांच्या ब्लॉकमध्ये फक्त शेवटी समाप्त केले जाऊ शकतात.
    //

    if start_l < end_l {
        // डावा ब्लॉक बाकी आहे.
        // उर्वरित ऑर्डर ऑर्डर घटक आतापर्यंत उजवीकडे हलवा.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // उजवा ब्लॉक शिल्लक आहे.
        // उर्वरित ऑर्डर केलेल्या घटकांना डाव्या बाजूला हलवा.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // दुसरे काही करायचे नाही, आम्ही पूर्ण केले.
        width(v.as_mut_ptr(), l)
    }
}

/// `v` पेक्षा लहान घटकांमध्ये `v` चे विभाजन, त्यानंतर एक्स 100 एक्स पेक्षा मोठे किंवा समान घटक.
///
///
/// चे एक टपल मिळवते:
///
/// 1. `v[pivot]` पेक्षा लहान घटकांची संख्या.
/// 2. `v` आधीच विभाजित केले असल्यास खरे.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // स्लाइसच्या सुरूवातीस पिव्होट ठेवा.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // कार्यक्षमतेसाठी पिव्हॉटला स्टॅक-वाटप केलेल्या चल मध्ये वाचा.
        // खालील तुलना ऑपरेशन panics असल्यास, पिव्होट स्वयंचलितपणे स्लाइसमध्ये पुन्हा लिहिले जाईल.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // ऑर्डर-ऑर्डर घटकांची पहिली जोडी शोधा.
        let mut l = 0;
        let mut r = v.len();

        // सुरक्षाः खाली असुरक्षिततेत अ‍ॅरेची सूची तयार करणे समाविष्ट आहे.
        // पहिल्या एकासाठी: आम्ही येथे `l < r` सह मर्यादा तपासत आहोत.
        // दुसर्‍यासाठीः आमच्याकडे सुरुवातीला `l == 0` आणि `r == v.len()` आहे आणि आम्ही प्रत्येक अनुक्रमणिकेत `l < r` तपासले आहेत.
        //                     येथून आम्हाला माहित आहे की `r` किमान `r == l` असणे आवश्यक आहे जे पहिल्यापासून वैध असल्याचे दर्शविले गेले.
        unsafe {
            // मुख्य सारख्यापेक्षा मोठा किंवा समान असलेला पहिला घटक शोधा.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // मुख्य घटक लहान असलेला शेवटचा घटक शोधा.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` स्कोपच्या बाहेर जाते आणि मूळ (जिथे स्टॅक-allocatedलोकटेड व्हेरिएबल आहे) स्लाइस मध्ये होता जेथे मूळ होता.
        // सुरक्षा सुनिश्चित करण्यासाठी हे पाऊल गंभीर आहे!
        //
    };

    // दोन विभाजनांच्या दरम्यान मुख्य ठेवा.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// `v` च्या समान घटकांमध्ये `v` चे विभाजन आणि त्यानंतर एक्स 100 एक्स पेक्षा मोठे घटक.
///
/// मुख्य सारख्या घटकांची संख्या मिळवते.
/// असे मानले जाते की `v` मध्ये पिव्होटपेक्षा लहान घटक नसतात.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // स्लाइसच्या सुरूवातीस पिव्होट ठेवा.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // कार्यक्षमतेसाठी पिव्हॉटला स्टॅक-वाटप केलेल्या चल मध्ये वाचा.
    // खालील तुलना ऑपरेशन panics असल्यास, पिव्होट स्वयंचलितपणे स्लाइसमध्ये पुन्हा लिहिले जाईल.
    // सुरक्षा: येथे पॉईंटर वैध आहे कारण तो स्लाइसच्या संदर्भातुन प्राप्त झाला आहे.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // आता स्लाइस विभाजित करा.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // सुरक्षाः खाली असुरक्षिततेत अ‍ॅरेची सूची तयार करणे समाविष्ट आहे.
        // पहिल्या एकासाठी: आम्ही येथे `l < r` सह मर्यादा तपासत आहोत.
        // दुसर्‍यासाठीः आमच्याकडे सुरुवातीला `l == 0` आणि `r == v.len()` आहे आणि आम्ही प्रत्येक अनुक्रमणिकेत `l < r` तपासले आहेत.
        //                     येथून आम्हाला माहित आहे की `r` किमान `r == l` असणे आवश्यक आहे जे पहिल्यापासून वैध असल्याचे दर्शविले गेले.
        unsafe {
            // मुख्य पेक्षा मोठा घटक शोधा.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // मुख्य सारखा शेवटचा घटक शोधा.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // आपण केले?
            if l >= r {
                break;
            }

            // ऑर्डर-ऑर्डर घटकांची आढळलेली जोडी स्वॅप करा.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // आम्हाला मुख्य सारखे `l` घटक आढळले.मुख्य या खात्यात केवळ 1 जोडा.
    l + 1

    // `_pivot_guard` स्कोपच्या बाहेर जाते आणि मूळ (जिथे स्टॅक-allocatedलोकटेड व्हेरिएबल आहे) स्लाइस मध्ये होता जेथे मूळ होता.
    // सुरक्षा सुनिश्चित करण्यासाठी हे पाऊल गंभीर आहे!
}

/// नमुन्यांची मोडतोड करण्याच्या प्रयत्नात काही घटक विखुरतात ज्यामुळे क्विकॉर्टमध्ये असंतुलित विभाजन होऊ शकतात.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // जॉर्ज मार्साग्लियाने "Xorshift RNGs" पेपरमधील स्यूडोरॅन्डम नंबर जनरेटर.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // या क्रमांकावर यादृच्छिक क्रमांक मिळवा.
        // संख्या `usize` मध्ये बसते कारण `len` हे `isize::MAX` पेक्षा मोठे नाही.
        let modulus = len.next_power_of_two();

        // या निर्देशिकेच्या जवळपास काही मुख्य उमेदवार असतील.चला त्यांना यादृच्छिक करूया.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // एक्स यादृच्छिक `len` क्रमांकाची संख्या व्युत्पन्न करा.
            // तथापि, महागड्या ऑपरेशन्स टाळण्यासाठी आम्ही प्रथम त्यास दोनची उर्जा देतो आणि नंतर तो `[0, len - 1]` श्रेणीत येईपर्यंत `len` ने कमी होतो.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` `2 * len` पेक्षा कमी असण्याची हमी आहे.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// `v` मध्ये एक मुख्य निवडतो आणि जर स्लाइस आधीच क्रमवारी लावला असेल तर अनुक्रमणिका आणि X01 एक्स मिळवते.
///
/// प्रक्रियेत `v` मधील घटकांची पुनर्क्रमित केली जाऊ शकते.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // मेडियन्स ऑफ मेडियन्स निवडण्यासाठी किमान लांबी.
    // छोट्या तुकड्यांमध्ये साधारण तीन-तीन पद्धती वापरतात.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // या फंक्शनमध्ये केल्या जाणार्‍या स्वॅप्सची कमाल संख्या.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // तीन मुख्य निर्देशांक ज्यांच्या जवळ आम्ही मुख्य (मुख्य) निवडणार आहोत.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // निर्देशांकांची क्रमवारी लावताना आम्ही ज्या स्वॅप्स करणार आहोत त्या एकूण संख्येची गणना करतो.
    let mut swaps = 0;

    if len >= 8 {
        // निर्देशांक अदलाबदल करतात जेणेकरुन `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // निर्देशांक अदलाबदल करतात जेणेकरुन `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // `v[a - 1], v[a], v[a + 1]` चा मध्यम मिळवितो आणि अनुक्रमणिका `a` मध्ये संचयित करते.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // `a`, `b` आणि `c` च्या अतिपरिचित क्षेत्रामध्ये मध्यस्थ शोधा.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // `a`, `b` आणि `c` मधील मध्यम शोधा.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // जास्तीत जास्त स्वॅप्स केले गेले.
        // स्लाइस खाली उतरत आहे किंवा मुख्यत: खाली उतरत आहेत, म्हणून उलट्या केल्याने कदाचित त्यास वेगवान वर्गीकरण करण्यात मदत होईल.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// `v` पुनरावृत्ती क्रमवारी लावतो.
///
/// जर स्लाईसच्या मूळ अ‍ॅरेमध्ये पूर्ववर्ती असेल तर ते एक्स 100 एक्स म्हणून निर्दिष्ट केले जाईल.
///
/// `limit` `heapsort` वर स्विच करण्यापूर्वी अनुमत असंतुलित विभाजनांची संख्या आहे.
/// जर शून्य असेल तर हे कार्य ताबडतोब हेप्सोर्टवर जाईल.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // या लांबी पर्यंतचे स्लाइस समाविष्ट करणे क्रमवारी लावून क्रमवारी लावा.
    const MAX_INSERTION: usize = 20;

    // शेवटचे विभाजन वाजवी प्रमाणात संतुलित असल्यास खरे आहे.
    let mut was_balanced = true;
    // शेवटचे विभाजन घटक शफल करत नसल्यास खरे (स्लाईस आधीपासून विभाजीत केली गेली होती).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // अंतर्भूत क्रमवारी वापरुन खूप लहान कापांची क्रमवारी लावली जाते.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // जर बर्‍याच वाईट मुख्य निवडी केल्या गेल्या तर `O(n * log(n))` सर्वात वाईट-परिस्थितीची हमी देण्यासाठी फक्त हेप्सोर्टवर परत जा.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // जर शेवटचा विभाजन असंतुलित असेल तर, सभोवतालच्या काही घटकांमध्ये बदल करून स्लाइसमधील नमुने मोडण्याचा प्रयत्न करा.
        // आशा आहे की या वेळी आम्ही एक चांगला मुख्य निवडेल.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // एक मुख्य निवडा आणि स्लाइस आधीपासून क्रमवारीबद्ध आहे की नाही याचा अंदाज लावण्याचा प्रयत्न करा.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // जर मागील विभाजन सभ्य प्रमाणात संतुलित असेल आणि घटक शफल नसावेत आणि जर मुख्य निवडीचा अंदाज असेल तर स्लाइस आधीपासून क्रमवारी लावलेले असेल तर ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // अनेक ऑर्डर ऑर्डर घटक ओळखून त्यांना योग्य ठिकाणी हलवण्याचा प्रयत्न करा.
            // जर तुकडा पूर्णपणे क्रमवारीत संपला तर आम्ही पूर्ण केले.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // जर निवडलेला पिव्होट पूर्ववर्ती समान असेल तर स्लाइसमधील तो सर्वात लहान घटक आहे.
        // तुकडा समान आणि तत्त्वापेक्षा जास्त घटकांमध्ये विभाजित करा.
        // जेव्हा स्लाइसमध्ये बरेच डुप्लिकेट घटक असतात तेव्हा सामान्यत: या प्रकरणात फटका बसतो.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // मुख्य पेक्षा मोठ्या घटकांची क्रमवारी लावा.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // तुकडा विभाजित करा.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // `left`, `pivot` आणि `right` मध्ये स्लाइस विभाजित करा.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // रिकर्सिव्ह कॉलची एकूण संख्या कमी करण्यासाठी आणि कमी स्टॅक स्पेसचा वापर करण्यासाठी फक्त छोट्या बाजूने पुनरावृत्ती करा.
        // तर फक्त लांब बाजूने पुढे जा (हे शेपटीच्या पुनरावृत्तीसारखेच आहे).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// नमुना-पराभव करणार्‍या क्विझकोर्टचा वापर करून एक्स 100 एक्स प्रकारची, जे *ओ*(*एन*\* एक्स01 एक्स सर्वात वाईट-केस आहे) आहे.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // क्रमवारी लावणे शून्य-आकाराच्या प्रकारांवर अर्थपूर्ण वर्तन नाही.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // असंतुलित विभाजनांची संख्या `floor(log2(len)) + 1` पर्यंत मर्यादित करा.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // या लांबीच्या तुकड्यांसाठी कदाचित त्या क्रमवारीत लावणे कदाचित जलद असेल.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // एक मुख्य निवडा
        let (pivot, _) = choose_pivot(v, is_less);

        // जर निवडलेला पिव्होट पूर्ववर्ती समान असेल तर स्लाइसमधील तो सर्वात लहान घटक आहे.
        // तुकडा समान आणि तत्त्वापेक्षा जास्त घटकांमध्ये विभाजित करा.
        // जेव्हा स्लाइसमध्ये बरेच डुप्लिकेट घटक असतात तेव्हा सामान्यत: या प्रकरणात फटका बसतो.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // जर आम्ही आमची अनुक्रमणिका पास केली असेल तर आम्ही चांगले आहोत.
                if mid > index {
                    return;
                }

                // अन्यथा, पिव्हटपेक्षा मोठ्या घटकांची क्रमवारी लावा.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // `left`, `pivot` आणि `right` मध्ये स्लाइस विभाजित करा.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // जर मध्य==अनुक्रमणिका असेल तर आम्ही पूर्ण केले कारण partition() ची हमी आहे की मध्यभागी नंतरचे सर्व घटक मध्यापेक्षा मोठे किंवा समान आहेत.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // क्रमवारी लावणे शून्य-आकाराच्या प्रकारांवर अर्थपूर्ण वर्तन नाही.काही करू नको.
    } else if index == v.len() - 1 {
        // जास्तीत जास्त घटक शोधा आणि अ‍ॅरेच्या शेवटच्या स्थानावर ठेवा.
        // आम्ही येथे एक्स00 एक्स वापरण्यास मोकळे आहोत कारण आम्हाला माहित आहे की v रिक्त नसावे.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // किमान घटक शोधा आणि अ‍ॅरेच्या प्रथम स्थानावर ठेवा.
        // आम्ही येथे एक्स00 एक्स वापरण्यास मोकळे आहोत कारण आम्हाला माहित आहे की v रिक्त नसावे.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}