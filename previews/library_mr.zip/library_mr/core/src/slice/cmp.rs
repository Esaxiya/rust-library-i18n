//! `[T]` साठी तुलना traits.

use crate::cmp;
use crate::cmp::Ordering::{self, Greater, Less};
use crate::mem;

use super::from_raw_parts;
use super::memchr;

extern "C" {
    /// कॉलची अंमलबजावणी मेकॅम्प दिली.
    ///
    /// डेटाचे अर्थ u8 म्हणून करते.
    ///
    /// सम 0 साठी 0, त्यापेक्षा कमी <0 आणि त्यापेक्षा मोठे 0 मिळवते.
    ///
    // FIXME(#32610): रिटर्न प्रकार c_int असावा
    fn memcmp(s1: *const u8, s2: *const u8, n: usize) -> i32;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> PartialEq<[B]> for [A]
where
    A: PartialEq<B>,
{
    fn eq(&self, other: &[B]) -> bool {
        SlicePartialEq::equal(self, other)
    }

    fn ne(&self, other: &[B]) -> bool {
        SlicePartialEq::not_equal(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for [T] {}

/// vectors [lexicographically](Ord#lexicographical-comparison) ची तुलना प्रभावी करते.
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for [T] {
    fn cmp(&self, other: &[T]) -> Ordering {
        SliceOrd::compare(self, other)
    }
}

/// vectors [lexicographically](Ord#lexicographical-comparison) ची तुलना प्रभावी करते.
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for [T] {
    fn partial_cmp(&self, other: &[T]) -> Option<Ordering> {
        SlicePartialOrd::partial_compare(self, other)
    }
}

#[doc(hidden)]
// स्लाइसच्या अर्धपुत्राच्या विशेषीकरणासाठी इंटरमीडिएट झेडट्रायट 0 झेड
trait SlicePartialEq<B> {
    fn equal(&self, other: &[B]) -> bool;

    fn not_equal(&self, other: &[B]) -> bool {
        !self.equal(other)
    }
}

// सामान्य स्लाइस समानता
impl<A, B> SlicePartialEq<B> for [A]
where
    A: PartialEq<B>,
{
    default fn equal(&self, other: &[B]) -> bool {
        if self.len() != other.len() {
            return false;
        }

        self.iter().zip(other.iter()).all(|(x, y)| x == y)
    }
}

// जेव्हा प्रकार अनुमती देतात तेव्हा बाईटवेइव्ह समानतेसाठी मेमकॅम्प वापरा
impl<A, B> SlicePartialEq<B> for [A]
where
    A: BytewiseEquality<B>,
{
    fn equal(&self, other: &[B]) -> bool {
        if self.len() != other.len() {
            return false;
        }

        // सुरक्षितता: `self` आणि `other` हे संदर्भ आहेत आणि अशा प्रकारे वैध असल्याची हमी दिलेली आहे.
        // वरील दोन्ही आकार समान आकाराचे असल्याचे तपासले गेले आहेत.
        unsafe {
            let size = mem::size_of_val(self);
            memcmp(self.as_ptr() as *const u8, other.as_ptr() as *const u8, size) == 0
        }
    }
}

#[doc(hidden)]
// स्लाइस च्या अर्धवट ऑर्डरच्या स्पेशलायझेशनसाठी इंटरमीडिएट trait
trait SlicePartialOrd: Sized {
    fn partial_compare(left: &[Self], right: &[Self]) -> Option<Ordering>;
}

impl<A: PartialOrd> SlicePartialOrd for A {
    default fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        let l = cmp::min(left.len(), right.len());

        // कंपाइलरमध्ये बाउंड चेक एलिमिनेशन सक्षम करण्यासाठी लूप इट्रेशन रेंजवर स्लाइस
        //
        let lhs = &left[..l];
        let rhs = &right[..l];

        for i in 0..l {
            match lhs[i].partial_cmp(&rhs[i]) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }

        left.len().partial_cmp(&right.len())
    }
}

// ही आमची इच्छा आहे.दुर्दैवाने ते योग्य नाही.
// `partial_ord_slice.rs` पहा.
/*
impl<A> SlicePartialOrd for A
where
    A: Ord,
{
    default fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        Some(SliceOrd::compare(left, right))
    }
}
*/

impl<A: AlwaysApplicableOrd> SlicePartialOrd for A {
    fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        Some(SliceOrd::compare(left, right))
    }
}

#[rustc_specialization_trait]
trait AlwaysApplicableOrd: SliceOrd + Ord {}

macro_rules! always_applicable_ord {
    ($([$($p:tt)*] $t:ty,)*) => {
        $(impl<$($p)*> AlwaysApplicableOrd for $t {})*
    }
}

always_applicable_ord! {
    [] u8, [] u16, [] u32, [] u64, [] u128, [] usize,
    [] i8, [] i16, [] i32, [] i64, [] i128, [] isize,
    [] bool, [] char,
    [T: ?Sized] *const T, [T: ?Sized] *mut T,
    [T: AlwaysApplicableOrd] &T,
    [T: AlwaysApplicableOrd] &mut T,
    [T: AlwaysApplicableOrd] Option<T>,
}

#[doc(hidden)]
// स्लाइसच्या ऑर्डरच्या स्पेशलायझेशनसाठी इंटरमीडिएट झेडट्रायट0झेड
trait SliceOrd: Sized {
    fn compare(left: &[Self], right: &[Self]) -> Ordering;
}

impl<A: Ord> SliceOrd for A {
    default fn compare(left: &[Self], right: &[Self]) -> Ordering {
        let l = cmp::min(left.len(), right.len());

        // कंपाइलरमध्ये बाउंड चेक एलिमिनेशन सक्षम करण्यासाठी लूप इट्रेशन रेंजवर स्लाइस
        //
        let lhs = &left[..l];
        let rhs = &right[..l];

        for i in 0..l {
            match lhs[i].cmp(&rhs[i]) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }

        left.len().cmp(&right.len())
    }
}

// मेमॅम्पॅप लेक्सोग्राफिकदृष्ट्या स्वाक्षरी केलेल्या बाइट्सच्या अनुक्रमांची तुलना करते.
// हे आम्हाला [u8] साठी हव्या असलेल्या ऑर्डरशी जुळते परंतु इतर कोणीही नाही ([i8] देखील नाही).
impl SliceOrd for u8 {
    #[inline]
    fn compare(left: &[Self], right: &[Self]) -> Ordering {
        let order =
            // सुरक्षितता: `left` आणि `right` हे संदर्भ आहेत आणि अशा प्रकारे वैध असल्याची हमी दिलेली आहे.
            // आम्ही कमीतकमी दोन्ही लांबी वापरतो ज्याची हमी देते की त्या मधल्या दोन्ही भागांमध्ये वाचनासाठी वैधता आहे.
            //
            unsafe { memcmp(left.as_ptr(), right.as_ptr(), cmp::min(left.len(), right.len())) };
        if order == 0 {
            left.len().cmp(&right.len())
        } else if order < 0 {
            Less
        } else {
            Greater
        }
    }
}

// `Eq` मध्ये एक पद्धत असूनही `Eq` वर विशेषज्ञता आणण्यासाठी खाच.
#[rustc_unsafe_specialization_marker]
trait MarkerEq<T>: PartialEq<T> {}

impl<T: Eq> MarkerEq<T> for T {}

#[doc(hidden)]
/// Trait ने त्यांच्या बाईटवे प्रतिनिधित्वाचा वापर करुन समानतेसाठी तुलना करता येणार्‍या प्रकारांसाठी अंमलबजावणी केली
///
#[rustc_specialization_trait]
trait BytewiseEquality<T>: MarkerEq<T> + Copy {}

macro_rules! impl_marker_for {
    ($traitname:ident, $($ty:ty)*) => {
        $(
            impl $traitname<$ty> for $ty { }
        )*
    }
}

impl_marker_for!(BytewiseEquality,
                 u8 i8 u16 i16 u32 i32 u64 i64 u128 i128 usize isize char bool);

pub(super) trait SliceContains: Sized {
    fn slice_contains(&self, x: &[Self]) -> bool;
}

impl<T> SliceContains for T
where
    T: PartialEq,
{
    default fn slice_contains(&self, x: &[Self]) -> bool {
        x.iter().any(|y| *y == *self)
    }
}

impl SliceContains for u8 {
    #[inline]
    fn slice_contains(&self, x: &[Self]) -> bool {
        memchr::memchr(*self, x).is_some()
    }
}

impl SliceContains for i8 {
    #[inline]
    fn slice_contains(&self, x: &[Self]) -> bool {
        let byte = *self as u8;
        // सुरक्षितताः `i8` आणि `u8` मध्ये समान मेमरी लेआउट आहे, अशा प्रकारे `x.as_ptr()` कास्ट करणे
        // कारण `*const u8` सुरक्षित आहे.
        // `x.as_ptr()` संदर्भातून आला आहे आणि अशा प्रकारे `x.len()` स्लाइसच्या लांबीसाठी वाचकांसाठी वैध असल्याची हमी दिलेली आहे, जी `isize::MAX` पेक्षा मोठी असू शकत नाही.
        // परत केलेला स्लाइस कधीही बदलला जात नाही.
        let bytes: &[u8] = unsafe { from_raw_parts(x.as_ptr() as *const u8, x.len()) };
        memchr::memchr(byte, bytes).is_some()
    }
}