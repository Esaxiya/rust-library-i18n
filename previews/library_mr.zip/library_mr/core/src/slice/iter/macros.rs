//! स्लाईसच्या पुनरावृत्ती करणार्‍याद्वारे वापरलेले मॅक्रो.

// इनलाइनिंग_इम्प्टी आणि लेन कामगिरीमध्ये खूप फरक करते
macro_rules! is_empty {
    // आम्ही ज्या पद्धतीने झेडएसटी इटरेटरची लांबी एन्कोड करतो, हे झेडएसटी आणि नॉन-झेडएसटी दोन्हीसाठी कार्य करते.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// काही सीमांच्या धनादेशांपासून मुक्त होण्यासाठी (`position` पहा) आम्ही काही अनपेक्षित मार्गाने लांबी मोजतो.
// (`कोडेजेन/स्लाइस-पोझिशनिंग-सीमांकन-तपासणी द्वारे चाचणी केली.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // आम्ही कधीकधी असुरक्षित ब्लॉकमध्ये वापरला जातो

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // हे _cannot_ `unchecked_sub` वापरते कारण आम्ही लांब झेडएसटी स्लाइस पुनरावृत्ती करणार्‍यांच्या लांबीचे प्रतिनिधित्व करण्यासाठी रॅपिंगवर अवलंबून असतो.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // आम्हाला माहित आहे की `start <= end`, म्हणून एक्स01 एक्सपेक्षा चांगले करू शकते, ज्यांना साइन इनमध्ये करार करण्याची आवश्यकता आहे.
            // येथे योग्य ध्वजांकने सेट करून आम्ही हे एलएलव्हीएमला सांगू शकतो, जे त्यास सीमा तपासणी दूर करण्यास मदत करते.
            // सुरक्षितता: इन्व्हिएरंट प्रकारानुसार, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // एलएलव्हीएमला हे सांगून देखील की पॉईंटर्स प्रकाराच्या अचूक एकाधिकतेसह भिन्न आहेत, हे X01 एक्स ऐवजी `start == end` वर `len() == 0` चे अनुकूलन करू शकते.
            //
            // सुरक्षा: इन्व्हिएंट प्रकाराद्वारे, पॉईंटर्स संरेखित केले जातात जेणेकरून
            //         त्यामधील अंतर पॉइंटि आकाराचे एक गुणक असणे आवश्यक आहे
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// `Iter` आणि `IterMut` पुनरावृत्ती करणार्‍यांची सामायिक परिभाषा
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // प्रथम घटक मिळवते आणि पुनरावृत्तीची सुरूवात 1 ने पुढे करते.
        // अंतर्भूत कार्याच्या तुलनेत कार्यक्षमतेत मोठ्या प्रमाणात सुधारणा होते.
        // पुनरावृत्ती करणारा रिक्त नसावा.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // शेवटचा घटक मिळवते आणि 1 च्या सहाय्याने पुनरावृत्तीचा शेवट सरकतो.
        // अंतर्भूत कार्याच्या तुलनेत कार्यक्षमतेत मोठ्या प्रमाणात सुधारणा होते.
        // पुनरावृत्ती करणारा रिक्त नसावा.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // जेव्हा टी एक झेडएसटी असेल तर पुनरावृत्ती करणार्‍याचा शेवट `n` ने मागे हलवून इटररेटरला लहान करते.
        // `n` `self.len()` पेक्षा जास्त नसावा.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // इटरेटरकडून स्लाइस तयार करण्यासाठी मदतनीस कार्य.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // सुरक्षितता: आयटर पॉईंटर असलेल्या स्लाइसमधून तयार केला गेला होता
                // `self.ptr` आणि लांबी `len!(self)`.
                // हे हमी देते की `from_raw_parts` साठी सर्व पूर्तता पूर्ण केल्या आहेत.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // जुनी प्रारंभ परत करून, एक्सट्रॅक्स घटकांद्वारे पुनरावृत्ती करणार्‍याची सुरूवाती पुढे नेण्यासाठी मदतनीस कार्य.
            //
            // असुरक्षित कारण ऑफसेटने `self.len()` पेक्षा जास्त नसावे.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // सुरक्षितताः कॉलर हमी देतो की `offset` `self.len()` पेक्षा जास्त नाही,
                    // तर हे नवीन पॉईंटर `self` च्या आत आहे आणि अशोभनीय असल्याची हमी दिलेली आहे.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // एक्सट्रॅक्स घटकांद्वारे पुनरावृत्तीचा शेवट सरकण्यासाठी नवीन सहाय्य परत आणण्यासाठी मदतनीस कार्य.
            //
            // असुरक्षित कारण ऑफसेटने `self.len()` पेक्षा जास्त नसावे.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // सुरक्षितताः कॉलर हमी देतो की `offset` `self.len()` पेक्षा जास्त नाही,
                    // ज्याची हमी `isize` ओव्हरफ्लो न करण्याची हमी दिलेली आहे.
                    // तसेच, परिणामी पॉईंटर `slice` च्या हद्दीत आहे, जो एक्स 100 एक्ससाठी इतर आवश्यकता पूर्ण करतो.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // तुकड्यांसह अंमलात आणता येऊ शकते परंतु हे धनादेश टाळते

                // सुरक्षितता: स्लाईसच्या प्रारंभ पॉइंटरपासून `assume` कॉल सुरक्षित आहेत
                // नॉन-नल असणे आवश्यक आहे आणि झेडएसटी नसलेल्या तुकड्यांमध्ये नॉन-नल एंड पॉईंटर देखील असणे आवश्यक आहे.
                // एक्सरेक्सला कॉल सुरक्षित आहे कारण आम्ही पुनरावृत्ती करणारा प्रथम रिक्त आहे की नाही हे तपासतो.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // हा इटरेटर आता रिक्त आहे.
                    if mem::size_of::<T>() == 0 {
                        // आम्हाला हे असे करावे लागेल कारण `ptr` कधीही 0 असू शकत नाही परंतु `end` (लपेटल्यामुळे) असू शकते.
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // सुरक्षितताः टी ZST नसल्यास शेवट 0 असू शकत नाही कारण ptr 0 आणि end>=ptr नसते
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // सुरक्षा: आम्ही मर्यादित आहोत.Z00s साठी देखील `post_inc_start` योग्य कार्य करते.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // आम्ही डीफॉल्ट अंमलबजावणी अधिलिखित करतो, जे एक्स 100 एक्स वापरते, कारण ही साधी अंमलबजावणी कमी एलएलव्हीएम आयआर व्युत्पन्न करते आणि संकलित करण्यासाठी वेगवान आहे.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // आम्ही डीफॉल्ट अंमलबजावणी अधिलिखित करतो, जे एक्स 100 एक्स वापरते, कारण ही साधी अंमलबजावणी कमी एलएलव्हीएम आयआर व्युत्पन्न करते आणि संकलित करण्यासाठी वेगवान आहे.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // आम्ही डीफॉल्ट अंमलबजावणी अधिलिखित करतो, जे एक्स 100 एक्स वापरते, कारण ही साधी अंमलबजावणी कमी एलएलव्हीएम आयआर व्युत्पन्न करते आणि संकलित करण्यासाठी वेगवान आहे.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // आम्ही डीफॉल्ट अंमलबजावणी अधिलिखित करतो, जे एक्स 100 एक्स वापरते, कारण ही साधी अंमलबजावणी कमी एलएलव्हीएम आयआर व्युत्पन्न करते आणि संकलित करण्यासाठी वेगवान आहे.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // आम्ही डीफॉल्ट अंमलबजावणी अधिलिखित करतो, जे एक्स 100 एक्स वापरते, कारण ही साधी अंमलबजावणी कमी एलएलव्हीएम आयआर व्युत्पन्न करते आणि संकलित करण्यासाठी वेगवान आहे.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // आम्ही डीफॉल्ट अंमलबजावणी अधिलिखित करतो, जे एक्स 100 एक्स वापरते, कारण ही साधी अंमलबजावणी कमी एलएलव्हीएम आयआर व्युत्पन्न करते आणि संकलित करण्यासाठी वेगवान आहे.
            // तसेच, `assume` सीमा तपासणी टाळते.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // सुरक्षा: लूप इनव्हिएंटंटद्वारे आमच्या हद्दीत असण्याची हमीः
                        // जेव्हा एक्स 100 एक्स, एक्स 0 एक्स एक्स एक्स 2 एक्स परत करते आणि लूप ब्रेक होतो.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // आम्ही डीफॉल्ट अंमलबजावणी अधिलिखित करतो, जे एक्स 100 एक्स वापरते, कारण ही साधी अंमलबजावणी कमी एलएलव्हीएम आयआर व्युत्पन्न करते आणि संकलित करण्यासाठी वेगवान आहे.
            // तसेच, `assume` सीमा तपासणी टाळते.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // सुरक्षितता: `i` `n` पासून प्रारंभ होण्यापासून `n` पेक्षा कमी असणे आवश्यक आहे
                        // आणि फक्त कमी होत आहे.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // सुरक्षितता: कॉलरने हमी देणे आवश्यक आहे की `i` हद्दीत आहे
                // अंतर्निहित स्लाइस, म्हणून `i` एक `isize` ओव्हरफ्लो करू शकत नाही आणि परत आलेल्या संदर्भात स्लाइसच्या घटकाचा संदर्भ घेण्याची हमी दिलेली आहे आणि अशा प्रकारे वैध असल्याची हमी दिलेली आहे.
                //
                // हे देखील लक्षात घ्या की कॉलर देखील याची हमी देतो की आम्हाला पुन्हा त्याच इंडेक्ससह पुन्हा कधीच कॉल केला जात नाही आणि या उपपरवानामध्ये प्रवेश करणार्‍या इतर कोणत्याही पद्धतींना कॉल केला जात नाही, म्हणून परत आलेल्या संदर्भाच्या बाबतीत परस्पर बदल करणे वैध आहे.
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // तुकड्यांसह अंमलात आणता येऊ शकते परंतु हे धनादेश टाळते

                // सुरक्षितता: स्लाइसचा प्रारंभ पॉईंटर रिकामा असणे आवश्यक असल्याने एक्स00 एक्स कॉल सुरक्षित आहेत,
                // आणि झेडएसटी नसलेल्या तुकड्यांमध्ये नॉन-नल एंड पॉईंटर देखील असणे आवश्यक आहे.
                // एक्सरेक्सला कॉल सुरक्षित आहे कारण आम्ही पुनरावृत्ती करणारा प्रथम रिक्त आहे की नाही हे तपासतो.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // हा इटरेटर आता रिक्त आहे.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // सुरक्षा: आम्ही मर्यादित आहोत.जरी ZSTs साठी `pre_dec_end` योग्य कार्य करते.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}