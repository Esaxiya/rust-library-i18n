//! ऑर्डर आणि तुलना करण्यासाठी कार्यक्षमता.
//!
//! या मॉड्यूलमध्ये मूल्यांची तुलना आणि तुलना करण्यासाठी विविध साधने आहेत.सारांश:
//!
//! * [`Eq`] आणि [`PartialEq`] हे traits आहेत जे आपल्याला अनुक्रमे मूल्यांमधील एकूण आणि आंशिक समानता परिभाषित करण्याची परवानगी देतात.
//! त्यांची अंमलबजावणी `==` आणि `!=` ऑपरेटरना ओव्हरलोड करते.
//! * [`Ord`] आणि [`PartialOrd`] हे traits आहेत जे आपल्याला अनुक्रमे मूल्यांमधील एकूण आणि आंशिक क्रम परिभाषित करण्याची परवानगी देतात.
//!
//! त्यांची अंमलबजावणी `<`, `<=`, `>` आणि `>=` ऑपरेटरना ओव्हरलोड करते.
//! * [`Ordering`] [`Ord`] आणि [`PartialOrd`] च्या मुख्य फंक्शन्सद्वारे परत केलेले एनम आहे आणि ऑर्डरचे वर्णन करते.
//! * [`Reverse`] एक अशी रचना आहे जी आपल्याला ऑर्डरिंग सहजतेने परत करण्याची परवानगी देते.
//! * [`max`] आणि एक्स 100 एक्स ही फंक्शन्स आहेत जी एक्स 01 एक्सच्या बाहेर तयार करतात आणि आपल्याला जास्तीत जास्त किंवा किमान दोन मूल्य शोधण्याची परवानगी देतात.
//!
//! अधिक माहितीसाठी सूचीतील प्रत्येक वस्तूचे संबंधित कागदपत्रे पहा.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// एक्स 100 एक्स असलेल्या समानतेच्या तुलनेसाठी झेड ट्रायट0 झेड.
///
/// हा trait पूर्ण समता संबंध नसलेल्या अशा प्रकारांसाठी, आंशिक समानतेसाठी परवानगी देतो.
/// उदाहरणार्थ, फ्लोटिंग पॉईंट क्रमांक एक्स ०१ एक्स मध्ये, तर फ्लोटिंग पॉईंट प्रकार एक्स ०२ एक्स लागू करतात परंतु एक्स X०० एक्स.
///
/// औपचारिकपणे, समानता (सर्व `a`, `b`, `A`, `B`, `C` प्रकारच्या `c` साठी) असणे आवश्यक आहे:
///
/// - **सममितीय**: जर `A: PartialEq<B>` आणि `B: PartialEq<A>` असेल तर **`a==b` सुचवते` बी==ए**;आणि
///
/// - **ट्रान्झिटिव्ह**: जर `A: PartialEq<B>` आणि `B: PartialEq<C>` आणि `A:
///   आंशिक<C>`, नंतर **=a==b` आणि `b == c` सूचित करते`a==c`**.
///
/// लक्षात घ्या की `B: PartialEq<A>` (symmetric) आणि `A: PartialEq<C>` (transitive) इम्पल्स अस्तित्वात येण्यास भाग पाडले जात नाहीत, परंतु या आवश्यकता जेव्हा अस्तित्वात असतील तेव्हा लागू होतात.
///
/// ## Derivable
///
/// हे trait `#[derive]` सह वापरले जाऊ शकते.जेव्हा स्ट्रक्ट्स वर शोधले जातात तेव्हा सर्व फील्ड्स समान असल्यास दोन घटना समान आहेत आणि कोणतीही फील्ड समान नसल्यास समान नाहीत.जेव्हा एन्म्सवर व्युत्पन्न केले जाते, तेव्हा प्रत्येक रूपे स्वतःच समान असतात आणि इतर रूप्यांइतके नसतात.
///
/// ## मी `PartialEq` ची अंमलबजावणी कशी करू शकेन?
///
/// `PartialEq` केवळ [`eq`] पद्धत लागू करणे आवश्यक आहे;[`ne`] डीफॉल्टनुसार त्यास परिभाषित केले आहे.[`ne`]*च्या कोणत्याही मॅन्युअल अंमलबजावणीमध्ये*[`eq`] [`ne`] चे एक कठोर व्यस्त असल्याचे नियमांचा आदर करणे आवश्यक आहे;म्हणजेच `!(a == b)` जर आणि फक्त `a != b` असेल.
///
/// `PartialEq`, [`PartialOrd`] आणि [`Ord`]*ची अंमलबजावणी* एकमेकांशी सहमत असणे आवश्यक आहे.काही traits घेण्याद्वारे आणि इतरांना व्यक्तिचलितपणे अंमलात आणून चुकून त्यांना असहमत करणे सोपे आहे.
///
/// एखाद्या डोमेनसाठी उदाहरण अंमलबजावणी ज्यामध्ये दोन पुस्तके त्यांची पुस्तके आयएसबीएन जुळल्यास समान पुस्तके मानली जातील तरीही स्वरूप भिन्न असले तरीही:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## मी दोन भिन्न प्रकारांची तुलना कशी करू शकतो?
///
/// आपण ज्या प्रकारची तुलना करू शकता ते `PartialEq` च्या प्रकार मापदंडानुसार नियंत्रित केले जाते.
/// उदाहरणार्थ, आपला मागील कोड थोडा चिमटा:
///
/// ```
/// // साधित अवजारे<BookFormat>==<BookFormat>तुलना
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // अंमलबजावणी<Book>==<BookFormat>तुलना
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // अंमलबजावणी<BookFormat>==<Book>तुलना
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// `impl PartialEq for Book` ला `impl PartialEq<BookFormat> for Book` मध्ये बदलून, आम्ही `Book`mat`s ची तुलना` Book`s सह करण्यास करण्यास परवानगी देतो.
///
/// वरीलप्रमाणे तुलना करणे, जे स्ट्रक्च्या काही क्षेत्रांकडे दुर्लक्ष करते, हे धोकादायक ठरू शकते.हे सहजपणे आंशिक समतेच्या नातेसंबंधासाठी आवश्यक असणाed्या उल्लंघनास कारणीभूत ठरू शकते.
/// उदाहरणार्थ, जर आम्ही `BookFormat` साठी `PartialEq<Book>` ची उपरोक्त अंमलबजावणी कायम ठेवली आणि `Book` साठी `PartialEq<Book>` ची अंमलबजावणी जोडली (एकतर `#[derive]` मार्गे किंवा पहिल्या उदाहरणातून मॅन्युअल अंमलबजावणीद्वारे) तर परिणाम संक्रमणाचे उल्लंघन करेल:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// ही पद्धत `self` आणि `other` मूल्यांसाठी समान असल्याचे परीक्षण करते आणि हे `==` द्वारे वापरले जाते.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// ही पद्धत `!=` साठी चाचणी करते.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// झेडट्रायट0झेड एक्स 100 एक्सची इम्प्लिअल व्युत्पन्न करणार्‍या डेरिव मॅक्रो.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// एक्स 100 एक्स असलेल्या समानतेच्या तुलनेसाठी झेड ट्रायट0 झेड.
///
/// याचा अर्थ असा की `a == b` आणि `a != b` व्यतिरिक्त व्यतिरिक्त, समानता (सर्व `a`, `b` आणि `c` साठी) असणे आवश्यक आहे:
///
/// - reflexive: `a == a`;
/// - सममितीय: `a == b` सूचित करते `b == a`;आणि
/// - सकर्मक: `a == b` आणि `b == c` म्हणजे `a == c`.
///
/// ही मालमत्ता कंपाईलरद्वारे तपासली जाऊ शकत नाही आणि म्हणूनच `Eq` ने [`PartialEq`] सूचित केले आहे आणि त्याकडे अतिरिक्त पद्धती नाहीत.
///
/// ## Derivable
///
/// हे trait `#[derive]` सह वापरले जाऊ शकते.
/// जेव्हा व्युत्पन्न केले जाते, कारण `Eq` ला अतिरिक्त पद्धती नसतात, तेव्हा ते केवळ कंपाईलरलाच माहिती देत असते की हे अर्धवट समतेचे नाते बनण्याऐवजी समतेचे नाते आहे.
///
/// लक्षात घ्या की `derive` रणनीतीमध्ये सर्व फील्ड आवश्यक आहेत `Eq`, जे नेहमी इच्छित नसतात.
///
/// ## मी `Eq` ची अंमलबजावणी कशी करू शकेन?
///
/// आपण `derive` धोरण वापरू शकत नसल्यास, निर्दिष्ट करा की आपला प्रकार `Eq` लागू करतो, ज्यामध्ये कोणत्याही पद्धती नाहीत:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // या पद्धतीचा वापर केवळ#[साधित] द्वारे केला जातो की प्रकाराचा प्रत्येक घटक स्वतःच [[साधित]] कार्यान्वित करतो, सध्याची व्युत्पन्न संरचना या trait वर पद्धत वापरल्याशिवाय हे प्रतिपादन करणे जवळजवळ अशक्य आहे.
    //
    //
    // हे कधीही हाताने कार्यान्वित करू नये.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// झेडट्रायट0झेड एक्स 100 एक्सची इम्प्लिअल व्युत्पन्न करणार्‍या डेरिव मॅक्रो.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: या संरचनेचा वापर केवळ#[साधित] द्वारे केला जातो
// अशा प्रकारचे प्रत्येक घटक Eq कार्यान्वित करते.
//
// ही रचना कधीही वापरकर्त्याच्या कोडमध्ये दिसू नये.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// एक्स व्हॅक्स एक्स दोन मूल्यांमधील तुलनाचा परिणाम आहे.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// अशी तुलना जेथे मूल्य तुलनापेक्षा कमी असते.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// अशी तुलना जिथे तुलनात्मक मूल्य समान असते.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// जेथे तुलनात्मक मूल्य दुसर्‍यापेक्षा जास्त असेल असा क्रम.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// क्रमवारी `Equal` प्रकार असल्यास `true` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// क्रमवारी `Equal` प्रकार नसल्यास `true` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// क्रमवारी `Less` प्रकार असल्यास `true` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// क्रमवारी `Greater` प्रकार असल्यास `true` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// ऑर्डरिंग एकतर `Less` किंवा `Equal` प्रकार असल्यास `true` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// ऑर्डरिंग एकतर `Greater` किंवा `Equal` प्रकार असल्यास `true` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// एक्स 100 एक्सला उलट करते.
    ///
    /// * `Less` `Greater` होते.
    /// * `Greater` `Less` होते.
    /// * `Equal` `Equal` होते.
    ///
    /// # Examples
    ///
    /// मूलभूत वागणूक:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// ही पद्धत तुलना विरूद्ध करण्यासाठी वापरली जाऊ शकते:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // अ‍ॅरे सर्वात मोठ्या ते छोट्या क्रमात क्रमवारी लावा.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// साखळी दोन क्रम.
    ///
    /// `self` नसताना `self` मिळवते.अन्यथा `other` मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// दिलेल्या फंक्शनसह ऑर्डरिंग चेन.
    ///
    /// `Equal` नसते तेव्हा X01 एक्स मिळवते.
    /// अन्यथा `f` ला कॉल करतो आणि निकाल परत करतो.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// उलट ऑर्डर करण्यासाठी एक मदतनीस रचना.
///
/// ही रचना [`Vec::sort_by_key`] सारख्या फंक्शन्ससह वापरली जाणारी एक मदतनीस आहे आणि की चा भाग परत ऑर्डर करण्यासाठी वापरली जाऊ शकते.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// [total order](https://en.wikipedia.org/wiki/Total_order) तयार करणार्‍या प्रकारांसाठी Trait.
///
/// ऑर्डर ही एकूण ऑर्डर असेल तर (सर्व `a`, `b` आणि `c` साठी):
///
/// - एकूण आणि असममित: `a < b`, `a == b` किंवा `a > b` पैकी एक खरे आहे;आणि
/// - संक्रमित, `a < b` आणि `b < c` सूचित करते `a < c`.हे दोन्ही `==` आणि `>` साठी असणे आवश्यक आहे.
///
/// ## Derivable
///
/// हे trait `#[derive]` सह वापरले जाऊ शकते.
/// जेव्हा स्ट्रिक्ट्सवर आधारित असतात, तेव्हा ते स्ट्रक्चरच्या सदस्यांच्या टॉप-टू-तळाशी डिक्लेरेशन ऑर्डरवर आधारित एक एक्स00 एक्स ऑर्डरिंग तयार करते.
///
/// जेव्हा एन्म्सवर व्युत्पन्न केले जाते, तेव्हा रूपे त्यांच्या शीर्ष-ते-तळाशी भेदभावपूर्ण ऑर्डरद्वारे क्रमित केली जातात.
///
/// ## शब्दकोष तुलना
///
/// शब्दकोष तुलना ही खालील गुणधर्मांसह एक ऑपरेशन आहे:
///  - घटकांद्वारे दोन अनुक्रमांची तुलना घटकाद्वारे केली जाते.
///  - प्रथम जुळणारे घटक परिभाषित करतात की कोणता क्रम दुसर्‍यापेक्षा शब्दकोषदृष्ट्या कमी किंवा जास्त आहे.
///  - जर एक अनुक्रम दुसर्‍याचा उपसर्ग असेल तर, लहान अनुक्रम दुसर्‍यापेक्षा शब्दावलीत कमी आहे.
///  - जर दोन अनुक्रमात समकक्ष घटक असतील आणि समान लांबीचे असतील तर अनुक्रम कोशिकदृष्ट्या समान आहेत.
///  - रिक्त अनुक्रम कोणत्याही रिक्त नसलेल्या अनुक्रमांपेक्षा शब्दकोषदृष्ट्या कमी आहे.
///  - दोन रिक्त अनुक्रम शब्दावलीत समान आहेत.
///
/// ## मी `Ord` ची अंमलबजावणी कशी करू शकेन?
///
/// `Ord` प्रकार देखील [`PartialOrd`] आणि [`Eq`] असणे आवश्यक आहे (ज्यास [`PartialEq`] आवश्यक आहे).
///
/// मग आपण एक्स 100 एक्सची अंमलबजावणी परिभाषित करणे आवश्यक आहे.आपल्या प्रकारच्या शेतात [`cmp`] वापरणे आपल्याला उपयुक्त वाटेल.
///
/// [`PartialEq`], [`PartialOrd`] आणि `Ord`*ची अंमलबजावणी* एकमेकांशी सहमत असणे आवश्यक आहे.
/// म्हणजेच, `a.cmp(b) == Ordering::Equal` सर्व आणि सर्व `a` आणि `b` साठी `a == b` आणि `Some(a.cmp(b)) == a.partial_cmp(b)` असल्यास.
/// काही traits घेण्याद्वारे आणि इतरांना व्यक्तिचलितपणे अंमलात आणून चुकून त्यांना असहमत करणे सोपे आहे.
///
/// येथे एक उदाहरण आहे जेथे आपण केवळ उंचीनुसार लोकांना क्रमवारी लावू इच्छित आहात, `id` आणि `name` चे दुर्लक्ष करून:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// ही पद्धत `self` आणि `other` दरम्यान [`Ordering`] परत करते.
    ///
    /// संमेलनाद्वारे, `self.cmp(&other)` खरे असल्यास `self <operator> other` अभिव्यक्तीशी जुळणारा क्रम परत करते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// जास्तीत जास्त दोन मूल्यांची तुलना आणि मिळवते.
    ///
    /// तुलना समान असल्यास त्यांना निर्धारण केल्यास दुसरे वितर्क मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// किमान दोन मूल्यांची तुलना आणि मिळवते.
    ///
    /// तुलना त्यांना समान असल्याचे निर्धारित केल्यास प्रथम वितर्क मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// विशिष्ट अंतरापर्यंत मूल्य मर्यादित करा.
    ///
    /// `self` `max` पेक्षा मोठे असल्यास `max` आणि `self` हे एक्स 100 एक्सपेक्षा कमी असल्यास `max` मिळवते.
    /// अन्यथा हे एक्स 100 एक्स परत करेल.
    ///
    /// # Panics
    ///
    /// `min > max` असल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// झेडट्रायट0झेड एक्स 100 एक्सची इम्प्लिअल व्युत्पन्न करणार्‍या डेरिव मॅक्रो.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// क्रमवारी-क्रमवारीत तुलना करता येणार्‍या मूल्यांसाठी Trait.
///
/// सर्व `a`, `b` आणि `c` साठी तुलना पूर्ण करणे आवश्यक आहे:
///
/// - असममितता: जर `a < b` असेल तर `!(a > b)`, तसेच `a > b` सूचित करणारे X01 एक्स;आणि
/// - संक्रमितता: `a < b` आणि `b < c` सूचित करते `a < c`.हे दोन्ही `==` आणि `>` साठी असणे आवश्यक आहे.
///
/// लक्षात घ्या की या आवश्यकतांचा अर्थ असा आहे की trait स्वतःच सममितीय आणि संक्रमितपणे अंमलात आणणे आवश्यक आहे: जर `T: PartialOrd<U>` आणि `U: PartialOrd<V>` नंतर `U: PartialOrd<T>` आणि `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// हे trait `#[derive]` सह वापरले जाऊ शकते.जेव्हा स्ट्रिक्ट्सवर आधारित असतात, तेव्हा ते स्ट्रक्चरच्या सदस्यांच्या वरच्या ते खालच्या घोषणेच्या क्रमावर आधारित कोशिकीय क्रम तयार करतात.
/// जेव्हा एन्म्सवर व्युत्पन्न केले जाते, तेव्हा रूपे त्यांच्या शीर्ष-ते-तळाशी भेदभावपूर्ण ऑर्डरद्वारे क्रमित केली जातात.
///
/// ## मी `PartialOrd` ची अंमलबजावणी कशी करू शकेन?
///
/// `PartialOrd` डीफॉल्ट अंमलबजावणीतून व्युत्पन्न केलेल्या इतरांसह केवळ [`partial_cmp`] पद्धतीची अंमलबजावणी आवश्यक आहे.
///
/// तथापि एकूण ऑर्डर नसलेल्या प्रकारांसाठी स्वतंत्रपणे इतरांची अंमलबजावणी करणे शक्य आहे.
/// उदाहरणार्थ, फ्लोटिंग पॉइंट नंबरसाठी, `NaN < 0 == false` आणि X01 एक्स (सीएफ.
/// आयईईई 754-2008 विभाग एक्स 100 एक्स).
///
/// `PartialOrd` आपला प्रकार [`PartialEq`] असणे आवश्यक आहे.
///
/// [`PartialEq`], `PartialOrd` आणि [`Ord`]*ची अंमलबजावणी* एकमेकांशी सहमत असणे आवश्यक आहे.
/// काही traits घेण्याद्वारे आणि इतरांना व्यक्तिचलितपणे अंमलात आणून चुकून त्यांना असहमत करणे सोपे आहे.
///
/// जर आपला प्रकार [`Ord`] असेल तर आपण [`cmp`] वापरून [`partial_cmp`] लागू करू शकता:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// आपल्या प्रकारच्या शेतात [`partial_cmp`] वापरणे आपल्याला उपयुक्त वाटेल.
/// येथे `Person` प्रकारांचे उदाहरण आहे ज्यांचे फ्लोटिंग पॉईंट `height` फील्ड आहे जे सॉर्टिंगसाठी वापरले जाणारे एकमेव फील्ड आहे:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// ही पद्धत अस्तित्वात असल्यास `self` आणि `other` मूल्यांमध्ये ऑर्डर देईल.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// जेव्हा तुलना करणे अशक्य आहे:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// ही पद्धत (`self` आणि `other` साठी) पेक्षा कमी चाचणी घेते आणि `<` ऑपरेटरद्वारे वापरली जाते.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// ही पद्धत (`self` आणि `other` साठी) पेक्षा कमी किंवा समान चाचणी घेते आणि `<=` ऑपरेटरद्वारे वापरली जाते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// ही पद्धत (`self` आणि `other` साठी) पेक्षा जास्त चाचणी घेते आणि `>` ऑपरेटरद्वारे वापरली जाते.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// ही पद्धत (`self` आणि `other` साठी) पेक्षा मोठे किंवा समान चाचणी घेते आणि `>=` ऑपरेटरद्वारे वापरली जाते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// झेडट्रायट0झेड एक्स 100 एक्सची इम्प्लिअल व्युत्पन्न करणार्‍या डेरिव मॅक्रो.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// किमान दोन मूल्यांची तुलना आणि मिळवते.
///
/// तुलना त्यांना समान असल्याचे निर्धारित केल्यास प्रथम वितर्क मिळवते.
///
/// अंतर्गतपणे एक्स00 एक्स करण्यासाठी उपनाव वापरतो.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// निर्दिष्ट तुलना कार्यासाठी कमीतकमी दोन मूल्ये मिळवते.
///
/// तुलना त्यांना समान असल्याचे निर्धारित केल्यास प्रथम वितर्क मिळवते.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// निर्दिष्ट फंक्शनमधून किमान मूल्य देणारा घटक परत करतो.
///
/// तुलना त्यांना समान असल्याचे निर्धारित केल्यास प्रथम वितर्क मिळवते.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// जास्तीत जास्त दोन मूल्यांची तुलना आणि मिळवते.
///
/// तुलना समान असल्यास त्यांना निर्धारण केल्यास दुसरे वितर्क मिळवते.
///
/// अंतर्गतपणे एक्स00 एक्स करण्यासाठी उपनाव वापरतो.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// निर्दिष्ट तुलना कार्ये संदर्भात जास्तीत जास्त दोन मूल्ये मिळवते.
///
/// तुलना समान असल्यास त्यांना निर्धारण केल्यास दुसरे वितर्क मिळवते.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// निर्दिष्ट फंक्शनमधून जास्तीत जास्त मूल्य देणारा घटक परत करतो.
///
/// तुलना समान असल्यास त्यांना निर्धारण केल्यास दुसरे वितर्क मिळवते.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// आदिम प्रकारांकरिता अर्धवट, भाग, अर्धवट आणि ऑर्डरची अंमलबजावणी
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // अधिक इष्टतम असेंब्ली निर्माण करण्यासाठी येथे ऑर्डर देणे महत्वाचे आहे.
                    // अधिक माहितीसाठी <https://github.com/rust-lang/rust/issues/63758> पहा.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // आय 8 चे कास्ट करणे आणि फरक ऑर्डरिंगमध्ये रुपांतरित करणे अधिक इष्टतम विधानसभा निर्माण करते.
            //
            // अधिक माहितीसाठी <https://github.com/rust-lang/rust/issues/66780> पहा.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // सुरक्षितताः i8 0 किंवा 1 म्हणून bool परत येते, म्हणून फरक इतर काहीही असू शकत नाही
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &पॉईंटर्स

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}