#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // कॉलरच्या आवृत्तीवर अवलंबून `$crate::panic::panic_2015` किंवा `$crate::panic::panic_2021` एकतर विस्तृत करते.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// दोन एक्सप्रेशन्स एकमेकांच्या बरोबरीचे असल्याचे सांगते (एक्स 100 एक्स वापरुन).
///
/// panic वर, हा मॅक्रो त्यांच्या डीबग सादरीकरणासह अभिव्यक्तीची मूल्ये मुद्रित करेल.
///
///
/// [`assert!`] प्रमाणेच, या मॅक्रोचा दुसरा फॉर्म आहे, जिथे सानुकूल झेडस्पॅनिक 0 झेड संदेश प्रदान केला जाऊ शकतो.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // खाली बबरो हेतुपुरस्सर आहेत.
                    // त्यांच्याशिवाय, मूल्यांची तुलना करण्यापूर्वीच कर्जासाठीच्या स्टॅक स्लॉटची सुरूवात केली जाते ज्यामुळे सहज लक्षात येण्यासारखे काम होते.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // खाली बबरो हेतुपुरस्सर आहेत.
                    // त्यांच्याशिवाय, मूल्यांची तुलना करण्यापूर्वीच कर्जासाठीच्या स्टॅक स्लॉटची सुरूवात केली जाते ज्यामुळे सहज लक्षात येण्यासारखे काम होते.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// दोन एक्सप्रेशन्स एकमेकांच्या बरोबरीचे नसल्याचे प्रतिपादन करते ([`PartialEq`] वापरुन).
///
/// panic वर, हा मॅक्रो त्यांच्या डीबग सादरीकरणासह अभिव्यक्तीची मूल्ये मुद्रित करेल.
///
///
/// [`assert!`] प्रमाणेच, या मॅक्रोचा दुसरा फॉर्म आहे, जिथे सानुकूल झेडस्पॅनिक 0 झेड संदेश प्रदान केला जाऊ शकतो.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // खाली बबरो हेतुपुरस्सर आहेत.
                    // त्यांच्याशिवाय, मूल्यांची तुलना करण्यापूर्वीच कर्जासाठीच्या स्टॅक स्लॉटची सुरूवात केली जाते ज्यामुळे सहज लक्षात येण्यासारखे काम होते.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // खाली बबरो हेतुपुरस्सर आहेत.
                    // त्यांच्याशिवाय, मूल्यांची तुलना करण्यापूर्वीच कर्जासाठीच्या स्टॅक स्लॉटची सुरूवात केली जाते ज्यामुळे सहज लक्षात येण्यासारखे काम होते.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// असे सांगते की रनटाइम वर बुलियन अभिव्यक्ती `true` आहे.
///
/// जर प्रदान केलेल्या अभिव्यक्तीचे रनटाइमवेळी `true` वर मूल्यांकन केले जाऊ शकत नाही तर हे [`panic!`] मॅक्रोची विनंती करेल.
///
/// [`assert!`] प्रमाणेच या मॅक्रोचीही दुसरी आवृत्ती आहे, जिथे सानुकूल झेडस्पॅनिक 0 झेड संदेश प्रदान केला जाऊ शकतो.
///
/// # Uses
///
/// [`assert!`] च्या विपरीत, `debug_assert!` विधान केवळ डीफॉल्टनुसार ऑप्टिमाइझ केलेल्या बिल्डमध्ये सक्षम केलेले आहे.
/// कम्पाइलरवर `-C debug-assertions` पाठविल्याशिवाय ऑप्टिमाइझ्ड बिल्ड `debug_assert!` स्टेटमेंट्स कार्यान्वित करणार नाही.
/// हे रीलिझ बिल्डमध्ये उपस्थित राहणे खूप महाग आहे परंतु विकासादरम्यान उपयुक्त ठरू शकेल अशा धनादेशांसाठी हे `debug_assert!` उपयुक्त करते.
/// एक्स 100 एक्स विस्तारीत करण्याचा परिणाम नेहमी टाइप केला जातो.
///
/// एक चेक न केलेले विधान विसंगत स्थितीत प्रोग्राम चालू ठेवण्यास अनुमती देते, ज्याचा अनपेक्षित परिणाम होऊ शकतो परंतु जोपर्यंत केवळ सुरक्षित कोडमध्ये असे होत नाही तोपर्यंत असुरक्षिततेचा परिचय देत नाही.
///
/// निवेदनाची कार्यक्षमता किंमत तथापि सर्वसाधारणपणे मोजता येत नाही.
/// [`assert!`] चे `debug_assert!` सह बदलणे केवळ अशा प्रकारे संपूर्ण प्रोफाईल नंतरच प्रोत्साहित केले जाते आणि मुख्य म्हणजे केवळ सुरक्षित कोडमध्ये!
///
/// # Examples
///
/// ```
/// // या अभिप्रायांसाठी झेडस्पॅनिक 0 झेड संदेश म्हणजे दिलेली अभिव्यक्तीची स्ट्रिंगिफाईड मूल्य.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // खूप सोपे फंक्शन
/// debug_assert!(some_expensive_computation());
///
/// // सानुकूल संदेशासह ठासून सांगा
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// दोन अभिव्यक्ती एकमेकांच्या बरोबरीचे असल्याचे प्रतिपादन करते.
///
/// panic वर, हा मॅक्रो त्यांच्या डीबग सादरीकरणासह अभिव्यक्तीची मूल्ये मुद्रित करेल.
///
/// [`assert_eq!`] च्या विपरीत, `debug_assert_eq!` विधान केवळ डीफॉल्टनुसार ऑप्टिमाइझ केलेल्या बिल्डमध्ये सक्षम केलेले आहे.
/// कम्पाइलरवर `-C debug-assertions` पाठविल्याशिवाय ऑप्टिमाइझ्ड बिल्ड `debug_assert_eq!` स्टेटमेंट्स कार्यान्वित करणार नाही.
/// हे रीलिझ बिल्डमध्ये उपस्थित राहणे खूप महाग आहे परंतु विकासादरम्यान उपयुक्त ठरू शकेल अशा धनादेशांसाठी हे `debug_assert_eq!` उपयुक्त करते.
///
/// एक्स 100 एक्स विस्तारीत करण्याचा परिणाम नेहमी टाइप केला जातो.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// दोन अभिव्यक्ती एकमेकांच्या बरोबरीचे नसल्याचे प्रतिपादन करतो.
///
/// panic वर, हा मॅक्रो त्यांच्या डीबग सादरीकरणासह अभिव्यक्तीची मूल्ये मुद्रित करेल.
///
/// [`assert_ne!`] च्या विपरीत, `debug_assert_ne!` विधान केवळ डीफॉल्टनुसार ऑप्टिमाइझ केलेल्या बिल्डमध्ये सक्षम केलेले आहे.
/// कम्पाइलरवर `-C debug-assertions` पाठविल्याशिवाय ऑप्टिमाइझ्ड बिल्ड `debug_assert_ne!` स्टेटमेंट्स कार्यान्वित करणार नाही.
/// हे रीलिझ बिल्डमध्ये उपस्थित राहणे खूप महाग आहे परंतु विकासादरम्यान उपयुक्त ठरू शकेल अशा धनादेशांसाठी हे `debug_assert_ne!` उपयुक्त करते.
///
/// एक्स 100 एक्स विस्तारीत करण्याचा परिणाम नेहमी टाइप केला जातो.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// दिलेली अभिव्यक्ती दिलेल्या नमुन्यांपैकी कोणत्याहीशी जुळते की मिळवते.
///
/// `match` अभिव्यक्ती प्रमाणे, नमुना देखील वैकल्पिकरित्या `if` आणि एक संरक्षक अभिव्यक्ती असू शकतो ज्यास नमुनाद्वारे बांधलेल्या नावांमध्ये प्रवेश आहे.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// एखाद्या परिणामास लपेटून टाकते किंवा तिची त्रुटी प्रचारित करते.
///
/// `?` एक्स पुनर्स्थित करण्यासाठी `?` ऑपरेटर जोडला गेला आणि त्याऐवजी वापरला जावा.
/// शिवाय, `try` हा Rust 2018 मधील आरक्षित शब्द आहे, म्हणून जर आपण तो वापरलाच असेल तर आपल्याला [raw-identifier syntax][ris] वापरण्याची आवश्यकता असेल: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` दिलेल्या [`Result`] शी जुळते.`Ok` व्हेरिएंटच्या बाबतीत, अभिव्यक्तीमध्ये गुंडाळलेल्या मूल्याचे मूल्य असते.
///
/// `Err` व्हेरिएंटच्या बाबतीत, ते अंतर्गत त्रुटी पुनर्प्राप्त करते.त्यानंतर एक्स ० ए एक्स एक्स १० एक्स वापरुन रूपांतरण करते.
/// हे विशिष्ट त्रुटी आणि अधिक सामान्य मधील स्वयंचलित रूपांतरण प्रदान करते.
/// त्यानंतर परिणामी त्रुटी त्वरित परत केली जाते.
///
/// लवकर परत आल्यामुळे, `try!` केवळ [`Result`] परत करणार्‍या फंक्शन्समध्ये वापरला जाऊ शकतो.
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // द्रुत परत करणार्‍या त्रुटींची प्राधान्य पद्धत
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // द्रुत परत करणार्‍या त्रुटींची मागील पद्धत
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // हे समतुल्य आहेः
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// बफरमध्ये स्वरूपित डेटा लिहितो.
///
/// हा मॅक्रो एक 'writer', स्वरूप स्ट्रिंग आणि वितर्कांची सूची स्वीकारतो.
/// वितर्क निर्दिष्ट केलेल्या स्वरुपाच्या स्ट्रिंगनुसार स्वरूपित केले जातील आणि त्याचा परिणाम लेखकाकडे जाईल.
/// `write_fmt` पद्धतीने लेखक मूल्य असू शकतात;सामान्यत: हे एकतर [`fmt::Write`] किंवा [`io::Write`] trait च्या अंमलबजावणीद्वारे येते.
/// `write_fmt` पद्धतीने जे काही परत मिळते ते मॅक्रो परत करते;सामान्यत: [`fmt::Result`] किंवा [`io::Result`].
///
/// फॉर्मेट स्ट्रिंग सिंटॅक्सवरील अधिक माहितीसाठी [`std::fmt`] पहा.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// मॉड्यूल एकतर लागू करणार्‍या ऑब्जेक्टवर `std::fmt::Write` आणि `std::io::Write` दोन्ही आयात करू शकतो आणि `write!` वर कॉल करू शकतो, कारण ऑब्जेक्ट सामान्यत: दोन्ही अंमलबजावणी करत नाहीत.
///
/// तथापि, मॉड्यूलने traits अर्हता प्राप्त केली पाहिजे जेणेकरुन त्यांची नावे विरोधाभास नसावीत:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt वापरते
///     write!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt वापरते
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: हा मॅक्रो `no_std` सेटअपमध्ये देखील वापरला जाऊ शकतो.
/// एक्स 100 एक्स सेटअपमध्ये घटकांच्या अंमलबजावणीच्या तपशीलांसाठी आपण जबाबदार आहात.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// नवीन लाइन जोडल्यासह स्वरूपित डेटा बफरमध्ये लिहा.
///
/// सर्व प्लॅटफॉर्मवर, नवीनलाईन एकटेच लाईन फीड कॅरेक्टर एक्स ०१ एक्स आहे (कोणतेही अतिरिक्त कॅरेज रीटर्निंग एक्स00 एक्स नाही.
///
/// अधिक माहितीसाठी, [`write!`] पहा.फॉर्मेट स्ट्रिंग सिंटॅक्सवरील माहितीसाठी, [`std::fmt`] पहा.
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// मॉड्यूल एकतर लागू करणार्‍या ऑब्जेक्टवर `std::fmt::Write` आणि `std::io::Write` दोन्ही आयात करू शकतो आणि `write!` वर कॉल करू शकतो, कारण ऑब्जेक्ट सामान्यत: दोन्ही अंमलबजावणी करत नाहीत.
/// तथापि, मॉड्यूलने traits अर्हता प्राप्त केली पाहिजे जेणेकरुन त्यांची नावे विरोधाभास नसावीत:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt वापरते
///     writeln!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt वापरते
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// न पोचण्यायोग्य कोड दर्शविते.
///
/// हे कधीही उपयुक्त आहे जेव्हा कंपाईलर काही कोड पोहोचण्यायोग्य नाही हे निर्धारित करू शकत नाही.उदाहरणार्थ:
///
/// * गार्डच्या अटींसह शस्त्रे जुळवा.
/// * गतिकरित्या समाप्त होणारे लूप.
/// * गतिकरित्या समाप्त होणारे आयटेटर
///
/// कोड पोहोचण्यायोग्य नाही असा निर्धार अयोग्य असल्यास, प्रोग्राम त्वरित एक्स 100 एक्स सह समाप्त होईल.
///
/// या मॅक्रोचा असुरक्षित भाग म्हणजे [`unreachable_unchecked`] फंक्शन, जो कोड पोहोचल्यास अपरिभाषित वर्तन कारणीभूत ठरेल.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// हे नेहमी [`panic!`] राहील.
///
/// # Examples
///
/// हात जुळवा:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // टिप्पणी दिली असल्यास कंपाईल त्रुटी
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // x/3 च्या सर्वात गरीब अंमलबजावणींपैकी एक
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// "not implemented" च्या संदेशासह पॅनीक करुन विनाअनुदानित कोड दर्शविते.
///
/// हे आपल्या कोडला टाइप-चेक करण्यास अनुमती देते, जे आपण trait चे नमुना लिहून किंवा अंमलात आणत असल्यास उपयुक्त आहे ज्यासाठी आपल्याला सर्व वापरण्याची योजना नाही अशा एकाधिक पद्धती आवश्यक आहेत.
///
/// `unimplemented!` आणि [`todo!`] मधील फरक असा आहे की `todo!` नंतर कार्यक्षमता अंमलात आणण्याचा हेतू व्यक्त करतो आणि संदेश "not yet implemented" आहे, `unimplemented!` असे कोणतेही दावे करत नाही.
/// त्याचा संदेश एक्स 100 एक्स आहे.
/// तसेच काही आयडीई `टूडो! Mark चे चिन्हांकित करतील.
///
/// # Panics
///
/// हे नेहमी [`panic!`] राहील कारण एक्स 0 1 एक्स निश्चित, विशिष्ट संदेशासह एक्स0 2 एक्ससाठी फक्त एक शॉर्टहँड आहे.
///
/// `panic!` प्रमाणेच या मॅक्रोकडे सानुकूल मूल्ये प्रदर्शित करण्यासाठी दुसरा फॉर्म आहे.
///
/// # Examples
///
/// म्हणा की आमच्याकडे trait `Foo` आहे:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// आम्हाला 'MyStruct' साठी `Foo` ची अंमलबजावणी करायची आहे, परंतु काही कारणास्तव केवळ `bar()` कार्य कार्यान्वित करण्यात अर्थ प्राप्त होतो.
/// `baz()` आणि `qux()` चे अद्याप आमच्या `Foo` च्या अंमलबजावणीमध्ये परिभाषित करणे आवश्यक आहे, परंतु आम्ही आमच्या कोड संकलित करण्यास अनुमती देण्यासाठी त्यांच्या परिभाषांमध्ये `unimplemented!` वापरू शकतो.
///
/// अंमलबजावणी नसलेल्या पद्धती पूर्ण झाल्यास आमचा प्रोग्राम चालू राहू इच्छित आहे.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // हे `baz` ला एक `MyStruct` समजण्यास काही अर्थ नाही, म्हणून आमच्याकडे येथे अजिबात तर्क नाही.
/////
///         // हे "thread 'main' panicked at 'not implemented'" प्रदर्शित करेल.
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // आमच्याकडे येथे काही तर्क आहेत, आम्ही विनाअनुदानित संदेश जोडू शकतो!आपली चुक दाखवण्यासाठी
///         // हे प्रदर्शित करेल: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// अपूर्ण कोड दर्शविते.
///
/// आपण प्रोटोटाइप करत असाल आणि आपला कोड टाइप टाइप शोधत असाल तर हे उपयुक्त ठरेल.
///
/// [`unimplemented!`] आणि `todo!` मधील फरक असा आहे की `todo!` नंतर कार्यक्षमता अंमलात आणण्याचा हेतू व्यक्त करतो आणि संदेश "not yet implemented" आहे, `unimplemented!` असे कोणतेही दावे करत नाही.
/// त्याचा संदेश एक्स 100 एक्स आहे.
/// तसेच काही आयडीई `टूडो! Mark चे चिन्हांकित करतील.
///
/// # Panics
///
/// हे नेहमी [`panic!`] राहील.
///
/// # Examples
///
/// येथे काही प्रगती कोडचे उदाहरण आहे.आमच्याकडे एक trait `Foo` आहे:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// आम्हाला आमच्या प्रकारांपैकी `Foo` ची अंमलबजावणी करायची आहे, परंतु प्रथम केवळ `bar()` वर देखील कार्य करायचे आहे.आमच्या कोडचे संकलन करण्यासाठी, आम्हाला `baz()` ची अंमलबजावणी करणे आवश्यक आहे, जेणेकरुन आपण `todo!` वापरू शकता:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // अंमलबजावणी येथे नाही
///     }
///
///     fn baz(&self) {
///         // आत्तासाठी baz() लागू करण्याबद्दल काळजी करू नका
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // आम्ही baz() देखील वापरत नाही, म्हणून हे ठीक आहे.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// अंगभूत मॅक्रोची व्याख्या.
///
/// मॅक्रो गुणधर्म (स्थिरता, दृश्यमानता इ.) बहुतेक येथे स्त्रोत कोडमधून घेतले गेले आहेत, विस्तार कार्ये अपवाद वगळता मॅक्रो इनपुटला आउटपुटमध्ये रूपांतरित करतात, ही कार्ये कंपाइलरद्वारे प्रदान केली जातात.
///
///
pub(crate) mod builtin {

    /// जेव्हा त्रुटी आली तेव्हा दिलेल्या त्रुटी संदेशासह संकलन अयशस्वी होण्यास कारणीभूत ठरते.
    ///
    /// जेव्हा झेडक्रेट0झेड चुकीच्या परिस्थितीसाठी अधिक चांगले त्रुटी संदेश प्रदान करण्यासाठी सशर्त संकलन धोरण वापरते तेव्हा हा मॅक्रो वापरला जावा.
    ///
    /// हे [`panic!`] चे कंपाईलर-स्तरीय रूप आहे, परंतु *रनटाइम* ऐवजी *संकलित* दरम्यान त्रुटी उत्पन्न करते.
    ///
    /// # Examples
    ///
    /// अशी दोन उदाहरणे मॅक्रो आणि एक्स 100 एक्स वातावरण आहेत.
    ///
    /// मॅक्रो अवैध मूल्ये पास झाल्यास अधिक चांगले कंपाईलर त्रुटी उत्सर्जित करा.
    /// अंतिम झेडब्राँक 0 झेडशिवाय, कंपाईलर तरीही एक त्रुटी सोडेल, परंतु त्रुटीच्या संदेशामध्ये दोन वैध मूल्यांचा उल्लेख होणार नाही.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// अनेक वैशिष्ट्यांपैकी एक उपलब्ध नसल्यास कंपाईलर एरिट उत्सर्जित करा.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// इतर स्ट्रिंग-फॉरमॅटिंग मॅक्रोसाठी पॅरामीटर्स बनविते.
    ///
    /// प्रत्येक अतिरिक्त वितर्क वितरीत करण्यासाठी `{}` असलेले स्वरूपण स्ट्रिंग अक्षरशः घेऊन हे मॅक्रो कार्य करते.
    /// `format_args!` स्ट्रिंगच्या रूपात आउटपुटचा अर्थ लावला जाऊ शकतो आणि वितर्कांना एका प्रकारात कॅनोनिकल केले जाते हे सुनिश्चित करण्यासाठी अतिरिक्त पॅरामीटर्स तयार करते.
    /// [`Display`] trait ची अंमलबजावणी करणारी कोणतीही मूल्ये `format_args!` पर्यंत दिली जाऊ शकतात, जसे की कोणतेही [`Debug`] अंमलबजावणी फॉरमॅटिंग स्ट्रिंगमध्ये `{:?}` वर दिली जाऊ शकते.
    ///
    ///
    /// हे मॅक्रो एक्स प्रकार एक्सचे मूल्य तयार करते.उपयुक्त पुनर्निर्देशन करण्यासाठी हे मूल्य [`std::fmt`] मध्ये मॅक्रोला दिले जाऊ शकते.
    /// इतर सर्व स्वरूपन मॅक्रो ([`स्वरूप!`], [`write!`], X01 एक्स, इत्यादी) याद्वारे प्रॉक्सी केले आहेत.
    /// `format_args!`, त्याच्या व्युत्पन्न मॅक्रोजच्या विपरीत, ढीग वाटप टाळते.
    ///
    /// आपण [`fmt::Arguments`] मूल्य वापरू शकता जे `format_args!` `Debug` आणि `Display` संदर्भात परत दिसते.
    /// उदाहरण देखील हे दर्शविते की त्याच गोष्टीचे `Debug` आणि `Display` स्वरूप: `format_args!` मधील इंटरपोलटेड स्वरूपन स्ट्रिंग.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// अधिक माहितीसाठी, [`std::fmt`] मधील दस्तऐवजीकरण पहा.
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// `format_args` प्रमाणेच, परंतु शेवटी एक नवीन ओळ जोडली.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// कंपाईल वेळेत पर्यावरणीय बदलांची तपासणी करते.
    ///
    /// हे मॅक्रो कंपाईल वेळी नामित वातावरणीय चलच्या मूल्यापर्यंत वाढेल, जे एक्स 100 एक्स प्रकारची अभिव्यक्ती देईल.
    ///
    ///
    /// जर वातावरण व्हेरिएबलची व्याख्या केली नसेल तर संकलन त्रुटी सोडली जाईल.
    /// कंपाईल त्रुटी सोडण्यासाठी, त्याऐवजी [`option_env!`] मॅक्रो वापरा.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// आपण दुसर्‍या पॅरामीटरच्या रूपात स्ट्रिंग देऊन त्रुटी संदेश सानुकूलित करू शकता:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// जर `documentation` पर्यावरण व्हेरिएबल परिभाषित केले नाही तर आपणास खालील त्रुटी प्राप्त होईल:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// कंपाईल वेळेत पर्यावरणीय व्हेरिएबलची वैकल्पिकरित्या तपासणी करते.
    ///
    /// कंपाईल वेळी नामित पर्यावरण परिवर्तनशील उपस्थित असल्यास, हे प्रकार `Option<&'static str>` च्या अभिव्यक्तीमध्ये विस्तारित होईल ज्याचे मूल्य पर्यावरण परिवर्तनाच्या मूल्याचे `Some` आहे.
    /// जर वातावरण व्हेरिएबल अस्तित्वात नसेल तर हे `None` पर्यंत वाढेल.
    /// या प्रकारच्या अधिक माहितीसाठी [`Option<T>`][Option] पहा.
    ///
    /// पर्यावरणीय चल उपस्थित आहे की नाही याची पर्वा न करता हे मॅक्रो वापरताना कधीही एक कंपाईल वेळ त्रुटी सोडली जात नाही.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// अभिज्ञापकांना एक अभिज्ञापक बनवते.
    ///
    /// हा मॅक्रो असंख्य स्वल्पविरामाने-विभक्त अभिज्ञापक घेते आणि त्या सर्वांना एकाच मध्ये एकत्र करते, जे एक नवीन अभिव्यक्तकर्ता असते.
    /// लक्षात घ्या की स्वच्छता हे असे करते की हे मॅक्रो स्थानिक चल घेऊ शकत नाही.
    /// तसेच, सामान्य नियम म्हणून, मॅक्रोस केवळ आयटम, विधान किंवा अभिव्यक्ती स्थितीतच परवानगी आहे.
    /// याचा अर्थ असा की आपण विद्यमान व्हेरिएबल्स, फंक्शन्स किंवा मॉड्यूल्स इत्यादींचा संदर्भ घेण्यासाठी हा मॅक्रो वापरु शकता, परंतु आपण त्यासह नवीन परिभाषित करू शकत नाही.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_ निवासी! (नवीन, मजेदार, नाव) { }//या प्रकारे वापरण्यायोग्य नाही!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// अक्षरशः स्थिर स्ट्रिंगच्या स्लाइसमध्ये प्रतिस्पर्धी असतात.
    ///
    /// हा मॅक्रो असंख्य स्वल्पविरामाने-विभक्त अक्षरे घेतो, जे प्रकार `&'static str` चे अभिव्यक्ती देते जे सर्व अक्षरशः एकत्रित डावीकडून उजवीकडे दर्शविते.
    ///
    ///
    /// कॉन्टेनेट करण्यासाठी पूर्णांक आणि फ्लोटिंग पॉइंट अक्षरांना स्ट्रिंग दिले जाते.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ज्या लाइनवर आवाहन केले होते त्या ओळीवर ते विस्तार करते.
    ///
    /// [`column!`] आणि [`file!`] सह, हे मॅक्रो स्त्रोत मधील स्थानाबद्दल विकसकांसाठी डीबगिंग माहिती प्रदान करतात.
    ///
    /// विस्तारित अभिव्यक्तीमध्ये प्रकार `u32` आहे आणि तो 1-आधारित आहे, म्हणून प्रत्येक फाईलमधील पहिली ओळ 1, द्वितीय ते 2 इत्यादींचे मूल्यांकन करते.
    /// हे सामान्य कंपाईलर किंवा लोकप्रिय संपादकांद्वारे त्रुटी संदेशांशी सुसंगत आहे.
    /// परत केलेली ओळ *अपरिहार्यपणे*`line!` विनंतीचीच ओळ नसून त्याऐवजी `line!` मॅक्रोची विनंती करण्यापूर्वी अग्रगण्य प्रथम मॅक्रो विनंती आहे.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// ज्या कॉलम नंबरवर तो कॉल केला होता त्या विस्तारासाठी.
    ///
    /// [`line!`] आणि [`file!`] सह, हे मॅक्रो स्त्रोत मधील स्थानाबद्दल विकसकांसाठी डीबगिंग माहिती प्रदान करतात.
    ///
    /// विस्तारित अभिव्यक्तीमध्ये एक्स एक्स एक्स प्रकार आहे आणि तो 1-आधारित आहे, म्हणून प्रत्येक ओळीतील पहिला स्तंभ 1, द्वितीय ते 2 इत्यादींचे मूल्यांकन करतो.
    /// हे सामान्य कंपाईलर किंवा लोकप्रिय संपादकांद्वारे त्रुटी संदेशांशी सुसंगत आहे.
    /// परत केलेला स्तंभ *अपरिहार्यपणे*`column!` विनंतीची ओळच नाही तर त्याऐवजी `column!` मॅक्रोची विनंती करण्यापूर्वी प्रथम मॅक्रो विनंती.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// ज्या फाईल नावाची विनंती केली होती त्या नावापर्यंत ती विस्तारते.
    ///
    /// [`line!`] आणि [`column!`] सह, हे मॅक्रो स्त्रोत मधील स्थानाबद्दल विकसकांसाठी डीबगिंग माहिती प्रदान करतात.
    ///
    /// विस्तारित अभिव्यक्तिमध्ये प्रकार `&'static str` आहे, आणि परत प्राप्त केलेली फाइल स्वतः एक्स 0 एक्स एक्स मॅक्रोची विनंती नाही, तर त्याऐवजी एक्स 0 2 एक्स मॅक्रोची विनंती करण्यापूर्वी प्रथम मॅक्रो विनंती आहे.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// त्याचे युक्तिवाद स्ट्रिंग करते.
    ///
    /// हे मॅक्रो `&'static str` प्रकारची अभिव्यक्ती उत्पन्न करेल जे मॅक्रोकडे गेलेल्या सर्व tokens चे स्ट्रिंगिफिकेशन आहे.
    /// स्वतः मॅक्रो विनंतीच्या वाक्यरचनावर कोणतेही प्रतिबंध घातले जात नाहीत.
    ///
    /// लक्षात घ्या की tokens इनपुटचे विस्तारित परिणाम future मध्ये बदलू शकतात.आपण आउटपुटवर अवलंबून असल्यास आपण सावधगिरी बाळगली पाहिजे.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// स्ट्रिंगच्या रूपात UTF-8 एन्कोड फाइल समाविष्ट करते.
    ///
    /// फाइल सध्याच्या फाइलशी संबंधित आहे (मॉड्यूल कसे आढळतात त्याप्रमाणे).
    /// संकलित वेळी प्रदान केलेल्या मार्गाचे व्यासपीठ-विशिष्ट प्रकारे वर्णन केले जाते.
    /// म्हणून, उदाहरणार्थ, बॅकस्लॅश `\` असलेल्या Windows मार्गासह विनंती Unix वर योग्यरित्या कंपाईल करू शकत नाही.
    ///
    ///
    /// या मॅक्रोमधून एक्स 100 एक्स प्रकारची अभिव्यक्ती प्राप्त होईल जी फाईलमधील सामग्री आहे.
    ///
    /// # Examples
    ///
    /// समजा या निर्देशिकेत खालील सामग्रीसह दोन फायली आहेतः
    ///
    /// फाइल 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// फाइल 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// 'main.rs' कंपाईल करणे आणि परिणामी बायनरी चालविणे "adiós" प्रिंट करेल.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// बाइट अ‍ॅरेच्या संदर्भात फाइल समाविष्ट करते.
    ///
    /// फाइल सध्याच्या फाइलशी संबंधित आहे (मॉड्यूल कसे आढळतात त्याप्रमाणे).
    /// संकलित वेळी प्रदान केलेल्या मार्गाचे व्यासपीठ-विशिष्ट प्रकारे वर्णन केले जाते.
    /// म्हणून, उदाहरणार्थ, बॅकस्लॅश `\` असलेल्या Windows मार्गासह विनंती Unix वर योग्यरित्या कंपाईल करू शकत नाही.
    ///
    ///
    /// या मॅक्रोमधून एक्स 100 एक्स प्रकारची अभिव्यक्ती प्राप्त होईल जी फाईलमधील सामग्री आहे.
    ///
    /// # Examples
    ///
    /// समजा या निर्देशिकेत खालील सामग्रीसह दोन फायली आहेतः
    ///
    /// फाइल 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// फाइल 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// 'main.rs' कंपाईल करणे आणि परिणामी बायनरी चालविणे "adiós" प्रिंट करेल.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// विद्यमान मॉड्यूल पथ दर्शविणार्‍या स्ट्रिंगवर विस्तारित करते.
    ///
    /// सद्य मॉड्यूल पथ crate root पर्यंत परत जाणारे मॉड्यूलचे श्रेणीक्रम म्हणून विचार केला जाऊ शकतो.
    /// परत आलेल्या मार्गाचे प्रथम घटक सध्या संकलित केले जात असलेल्या crate चे नाव आहे.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// कंपाईल वेळेत कॉन्फिगरेशन ध्वजांच्या बुलियन संयोगांचे मूल्यांकन करते.
    ///
    /// `#[cfg]` विशेषता व्यतिरिक्त, हे मॅक्रो कॉन्फिगरेशन ध्वजांचे बुलियन अभिव्यक्ती मूल्यमापन अनुमत करण्यासाठी प्रदान केले गेले आहे.
    /// हे वारंवार कमी डुप्लिकेट कोड ठरतो.
    ///
    /// या मॅक्रोला दिलेला वाक्यरचना हाच [`cfg`] गुणधर्म सारखा सिंटॅक्स आहे.
    ///
    /// `cfg!`, `#[cfg]` विपरीत, कोणताही कोड काढत नाही आणि केवळ खरे किंवा खोटे चे मूल्यांकन करते.
    /// उदाहरणार्थ, एक्स ० एक्स एक्स काय मूल्यमापन करीत आहे त्याकडे दुर्लक्ष करून, `cfg!` स्थितीसाठी वापरली जाते तेव्हा if/else अभिव्यक्तीतील सर्व ब्लॉक वैध असणे आवश्यक आहे.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// संदर्भानुसार फाइलचे अभिव्यक्ती किंवा आयटम म्हणून विश्लेषित करते.
    ///
    /// फाइल सध्याच्या फाइलशी संबंधित आहे (मॉड्यूल कसे आढळतात त्याप्रमाणे).संकलित वेळी प्रदान केलेल्या मार्गाचे व्यासपीठ-विशिष्ट प्रकारे वर्णन केले जाते.
    /// म्हणून, उदाहरणार्थ, बॅकस्लॅश `\` असलेल्या Windows मार्गासह विनंती Unix वर योग्यरित्या कंपाईल करू शकत नाही.
    ///
    /// हा मॅक्रो वापरणे ही बर्‍याचदा वाईट कल्पना असते, कारण जर फाईल एक्सप्रेशन म्हणून विश्लेषित केली असेल तर ती आजूबाजूच्या कोडमध्ये अस्वच्छतेने ठेवली जाईल.
    /// सध्याच्या फाईलमधे एकसारखेच व्हेरिएबल्स किंवा फंक्शन्स असल्यास फाईलच्या अपेक्षेपेक्षा वेगळी किंवा कार्ये बदलू शकतात.
    ///
    ///
    /// # Examples
    ///
    /// समजा या निर्देशिकेत खालील सामग्रीसह दोन फायली आहेतः
    ///
    /// फाइल 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// फाइल 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// 'main.rs' कंपाईल करणे आणि परिणामी बायनरी चालविणे "🙈🙊🙉🙈🙊🙉" प्रिंट करेल.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// असे सांगते की रनटाइम वर बुलियन अभिव्यक्ती `true` आहे.
    ///
    /// जर प्रदान केलेल्या अभिव्यक्तीचे रनटाइमवेळी `true` वर मूल्यांकन केले जाऊ शकत नाही तर हे [`panic!`] मॅक्रोची विनंती करेल.
    ///
    /// # Uses
    ///
    /// ठाम मत नेहमी डीबग आणि रीलीझ बिल्ड दोन्हीमध्ये तपासले जाते आणि ते अक्षम केले जाऊ शकत नाही.
    /// डीफॉल्टनुसार रिलीज बिल्डमध्ये सक्षम नसलेल्या हक्कांसाठी [`debug_assert!`] पहा.
    ///
    /// असुरक्षित कोड रन-टाइम इन्व्हिएंटर्सची अंमलबजावणी करण्यासाठी `assert!` वर विसंबून राहू शकतो, उल्लंघन केल्यास तो असुरक्षिततेस कारणीभूत ठरू शकतो.
    ///
    /// `assert!` च्या इतर वापर प्रकरणांमध्ये सेफ कोडमध्ये रन-टाईम इन्व्हिएंटर्सची चाचणी आणि अंमलबजावणी समाविष्ट आहे (ज्याच्या उल्लंघनाचा परिणाम अयशस्वी होऊ शकत नाही).
    ///
    ///
    /// # सानुकूल संदेश
    ///
    /// या मॅक्रोला दुसरा फॉर्म आहे, जिथे सानुकूल झेडस्पॅनिक ० झेड संदेश फॉर्मेटसाठी किंवा वितर्कशिवाय प्रदान केला जाऊ शकतो.
    /// या फॉर्मच्या सिंटॅक्ससाठी [`std::fmt`] पहा.
    /// स्वरुपण वितर्क म्हणून वापरले जाणारे अभिव्यक्तीचे प्रतिपादन मूल्यमापन अयशस्वी झाल्यासच केले जाईल.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // या अभिप्रायांसाठी झेडस्पॅनिक 0 झेड संदेश म्हणजे दिलेली अभिव्यक्तीची स्ट्रिंगिफाईड मूल्य.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // खूप सोपे फंक्शन
    ///
    /// assert!(some_computation());
    ///
    /// // सानुकूल संदेशासह ठासून सांगा
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// इनलाइन असेंब्ली.
    ///
    /// वापरासाठी [unstable book] वाचा.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// एलएलव्हीएम-शैलीतील इनलाइन असेंब्ली.
    ///
    /// वापरासाठी [unstable book] वाचा.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// मॉड्यूल-स्तरीय इनलाइन असेंब्ली.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// मुद्रणांनी झेड टोकन्स्0 झेड प्रमाणित आउटपुटमध्ये पास केले.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// इतर मॅक्रो डीबग करण्यासाठी वापरलेली ट्रेसिंग कार्यक्षमता सक्षम किंवा अक्षम करते.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// डेरिव्ह मॅक्रो लागू करण्यासाठी वापरलेली विशेषता मॅक्रो.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// युनिट टेस्टमध्ये रुपांतरित करण्यासाठी फंक्शनला विशेषता मॅक्रो लागू केली.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// बेंचमार्क चाचणीत रुपांतर करण्यासाठी फंक्शनला विशेषता मॅक्रो लागू केली.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// `#[test]` आणि `#[bench]` मॅक्रोची अंमलबजावणी तपशील.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// वैश्विक वाटपकर्ता म्हणून नोंदणी करण्यासाठी स्थिर स्थळावर विशेषता मॅक्रो लागू केली.
    ///
    /// [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html) देखील पहा.
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// पास केलेला मार्ग प्रवेश करण्यायोग्य असल्यास त्यास लागू केलेला आयटम ठेवतो आणि अन्यथा काढून टाकतो.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// त्यास लागू झालेल्या कोड तुकड्यातील सर्व `#[cfg]` आणि `#[cfg_attr]` विशेषता विस्तृत करते.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// `rustc` कंपाईलरची अस्थिर अंमलबजावणी तपशील, वापरू नका.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// `rustc` कंपाईलरची अस्थिर अंमलबजावणी तपशील, वापरू नका.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}