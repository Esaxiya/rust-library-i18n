//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// `char` मध्ये सर्वात जास्त वैध कोड बिंदू असू शकतात.
    ///
    /// एक `char` एक [Unicode Scalar Value] आहे, ज्याचा अर्थ असा की तो एक एक्स 0 एक्स आहे, परंतु केवळ एका विशिष्ट श्रेणीमध्ये आहे.
    /// `MAX` एक वैध [Unicode Scalar Value] हा सर्वोच्च वैध कोड पॉइंट आहे.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` डिकोडिंग त्रुटीचे प्रतिनिधित्व करण्यासाठी युनिकोडमध्ये () चा वापर केला जातो.
    ///
    /// हे उद्भवू शकते, उदाहरणार्थ, [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy) ला चुकीचे UTF-8 बाइट्स देताना.
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// [Unicode](http://www.unicode.org/) ची आवृत्ती जी `char` आणि `str` पद्धतींचा युनिकोड भाग आधारित आहे.
    ///
    /// युनिकोडच्या नवीन आवृत्त्या नियमितपणे प्रकाशीत केल्या जातात आणि त्यानंतर युनिकोडनुसार प्रमाणित लायब्ररीत सर्व पद्धती अद्ययावत केल्या जातात.
    /// म्हणूनच काही एक्स 100 एक्स आणि एक्स 0 एक्स एक्स पद्धतींचे वर्तन आणि काळानुसार या सततचे मूल्य बदलते.
    /// हा *ब्रेकिंग बदल मानला जात नाही*.
    ///
    /// आवृत्ती क्रमांकन योजनेची [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) मध्ये व्याख्या केली आहे.
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// `iter` मधील UTF-16 एन्कोडेड कोड पॉइंट्सवर एक इटरटर तयार करते, p एरर्स म्हणून अनावश्यक सरोगेटस परत करते.
    ///
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// `Err` चे परिणाम पुनर्स्थित करण्याच्या अक्षरासह बदलून एक हानीकारक डीकोडर प्राप्त केले जाऊ शकते:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// `u32` ला `char` मध्ये रूपांतरित करते.
    ///
    /// लक्षात ठेवा की सर्व चार्स वैध आहेत [`u32`] आणि त्यासह एकावर कास्ट केले जाऊ शकते
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// तथापि, उलट सत्य नाही: सर्व वैध [`u32`] वैध` चार्ट नाहीत.
    /// `from_u32()` जर इनपुट `char` चे वैध मूल्य नसेल तर ते X01 एक्स परत करेल.
    ///
    /// या कार्याच्या असुरक्षित आवृत्तीसाठी जे या धनादेशांकडे दुर्लक्ष करतात, [`from_u32_unchecked`] पहा.
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// इनपुट वैध `char` नसते तेव्हा `None` परत करणे:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// वैधतेकडे दुर्लक्ष करून `u32` ला `char` मध्ये रूपांतरित करते.
    ///
    /// लक्षात ठेवा की सर्व चार्स वैध आहेत [`u32`] आणि त्यासह एकावर कास्ट केले जाऊ शकते
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// तथापि, उलट सत्य नाही: सर्व वैध [`u32`] वैध` चार्ट नाहीत.
    /// `from_u32_unchecked()` याकडे दुर्लक्ष करेल आणि शक्यतो एखादे अवैध तयार करुन `char` वर डोळे झाकून टाकले जाईल.
    ///
    ///
    /// # Safety
    ///
    /// हे कार्य असुरक्षित आहे कारण यामुळे अवैध `char` मूल्ये तयार केली जाऊ शकतात.
    ///
    /// या कार्याच्या सुरक्षित आवृत्तीसाठी, [`from_u32`] कार्य पहा.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // सुरक्षितता: सुरक्षितता करार कॉलरद्वारे कायम ठेवला जाणे आवश्यक आहे.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// दिलेल्या मूलातील अंक एका `char` मध्ये रूपांतरित करते.
    ///
    /// येथे एक्स01 एक्सला कधीकधी एक्स 100 एक्स देखील म्हटले जाते.
    /// दोनची मूलांक काही सामान्य मूल्ये देण्यासाठी बायनरी संख्या, दहाचा दशांश, दशांश आणि सोळा, हेक्साडेसिमलचा मूलांक दर्शवते.
    ///
    /// अनियंत्रित मूलांक समर्थित आहेत.
    ///
    /// `from_digit()` दिलेल्या इन रेडिक्समध्ये इनपुट अंक नसल्यास `None` परत करेल.
    ///
    /// # Panics
    ///
    /// जर 36 पेक्षा मोठा मूलांक दिल्यास Panics.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // बेस 16 मध्ये दशांश 11 हा एक अंक आहे
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// इनपुट अंक नसताना `None` परत करणे:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// मोठा मूलांक पास करणे, झेडस्पॅनिक0 झेडला कारणीभूत आहे:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// दिलेल्या रेडिक्समध्ये `char` अंक आहे की नाही ते तपासेल.
    ///
    /// येथे एक्स01 एक्सला कधीकधी एक्स 100 एक्स देखील म्हटले जाते.
    /// दोनची मूलांक काही सामान्य मूल्ये देण्यासाठी बायनरी संख्या, दहाचा दशांश, दशांश आणि सोळा, हेक्साडेसिमलचा मूलांक दर्शवते.
    ///
    /// अनियंत्रित मूलांक समर्थित आहेत.
    ///
    /// [`is_numeric()`] च्या तुलनेत, हे कार्य केवळ `0-9`, `a-z` आणि `A-Z` वर्ण ओळखते.
    ///
    /// 'Digit' फक्त खालील वर्णांकरिता परिभाषित केले आहे:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// 'digit' अधिक विस्तृत समजून घेण्यासाठी, [`is_numeric()`] पहा.
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// जर 36 पेक्षा मोठा मूलांक दिल्यास Panics.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// मोठा मूलांक पास करणे, झेडस्पॅनिक0 झेडला कारणीभूत आहे:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// दिलेल्या रेडिक्समधील `char` ला एका अंकात रूपांतरित करते.
    ///
    /// येथे एक्स01 एक्सला कधीकधी एक्स 100 एक्स देखील म्हटले जाते.
    /// दोनची मूलांक काही सामान्य मूल्ये देण्यासाठी बायनरी संख्या, दहाचा दशांश, दशांश आणि सोळा, हेक्साडेसिमलचा मूलांक दर्शवते.
    ///
    /// अनियंत्रित मूलांक समर्थित आहेत.
    ///
    /// 'Digit' फक्त खालील वर्णांकरिता परिभाषित केले आहे:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// `char` दिलेल्या मूलांकातील अंकांचा संदर्भ न घेतल्यास `None` मिळवते.
    ///
    /// # Panics
    ///
    /// जर 36 पेक्षा मोठा मूलांक दिल्यास Panics.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// अपयशी ठरल्यास अंक-नसलेले निकाल पास करणे:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// मोठा मूलांक पास करणे, झेडस्पॅनिक0 झेडला कारणीभूत आहे:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // `radix` स्थिर आणि 10 किंवा त्यापेक्षा कमी वरून प्रकरणांसाठी अंमलबजावणीची गती सुधारण्यासाठी कोड येथे विभाजित केला आहे
        //
        let val = if likely(radix <= 10) {
            // अंक नसल्यास मूलापेक्षा मोठी संख्या तयार केली जाईल.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Ite चार्ट्स म्हणून एका वर्णातून हेक्साडेसिमल युनिकोड एस्केप मिळविणारा एक इटररेटर मिळवते.
    ///
    /// हे `\u{NNNNNN}` फॉर्मच्या Rust सिंटॅक्ससह वर्ण सुटेल जिथे `NNNNNN` हेक्साडेसिमल प्रतिनिधित्व आहे.
    ///
    ///
    /// # Examples
    ///
    /// आयटर म्हणूनः
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// थेट `println!` वापरणे:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// दोन्ही समतुल्य आहेत:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// `to_string` वापरणे:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // किंवा-आयएन 1 हे सुनिश्चित करते की c==0 कोडचे गणन करते की एक अंक छापला जावा आणि (जे समान आहे)(31, 32) भूमिगत प्रवाह टाळेल
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // सर्वात महत्त्वपूर्ण हेक्स अंकांची अनुक्रमणिका
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// एक्स00 एक्स ची विस्तारित आवृत्ती जी विस्तारित ग्राफिक कोडपॉइंट्समधून बाहेर पडा परवानगी देते.
    /// हे आपल्याला स्ट्रिंगच्या सुरूवातीस नसलेले स्पेसिंग चिन्हे चांगले बनविण्यास अनुमती देते.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// एक पुनरावृत्ती करणारा मिळवते जो एका वर्णाचा अक्षरशः सुटलेला कोड `चार्ट्स म्हणून मिळवितो.
    ///
    /// हे `str` किंवा `char` च्या `Debug` अंमलबजावणीसारखेच वर्ण सुटेल.
    ///
    ///
    /// # Examples
    ///
    /// आयटर म्हणूनः
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// थेट `println!` वापरणे:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// दोन्ही समतुल्य आहेत:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// `to_string` वापरणे:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// एक पुनरावृत्ती करणारा मिळवते जो एका वर्णाचा अक्षरशः सुटलेला कोड `चार्ट्स म्हणून मिळवितो.
    ///
    /// डीफॉल्टची निवड केली गेली आहे जी अक्षरशः उत्पादन करण्यास मदत करते जे झेड सी ++ 0 झेड 11 आणि तत्सम सी-कौटुंबिक भाषांसह विविध भाषांमध्ये कायदेशीर आहेत.
    /// अचूक नियमः
    ///
    /// * टॅब `\t` म्हणून निसटला आहे.
    /// * `\r` म्हणून कॅरेज रिटर्न सुटला आहे.
    /// * लाइन फीड `\n` म्हणून निसटला आहे.
    /// * एकल कोट `\'` म्हणून निसटला आहे.
    /// * डबल कोट `\"` म्हणून निसटला आहे.
    /// * बॅकस्लॅश `\\` म्हणून निसटला आहे.
    /// * 'प्रिंट करण्यायोग्य एएससीआयआय' श्रेणीतील कोणतेही वर्ण एक्स ०१ एक्स .. एक्स ००० एक्स समावेशक.
    /// * इतर सर्व वर्णांना हेक्साडेसिमल युनिकोड एस्केप दिले गेले आहेत;[`escape_unicode`] पहा.
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// आयटर म्हणूनः
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// थेट `println!` वापरणे:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// दोन्ही समतुल्य आहेत:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// `to_string` वापरणे:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// UTF-8 मध्ये एन्कोड केलेले असल्यास या `char` ला आवश्यक असलेल्या बाइटची संख्या मिळवते.
    ///
    /// सर्व बाइट्सची संख्या नेहमी 1 ते 4 दरम्यान असते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// `&str` प्रकार याची हमी देतो की त्यातील सामग्री UTF-8 आहे आणि म्हणून आम्ही प्रत्येक कोड पॉईंटला `char` वि मध्ये `char` म्हणून दर्शविले असल्यास आम्ही घेत असलेल्या लांबीची तुलना करू शकतोः
    ///
    ///
    /// ```
    /// // अक्षर म्हणून
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // दोन्ही तीन बाइट म्हणून प्रतिनिधित्व केले जाऊ शकते
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // &str म्हणून, हे दोघे UTF-8 मध्ये एन्कोड केलेले आहेत
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // आम्ही पाहू शकतो की ते एकूण सहा बाइट घेतात ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... अगदी &str प्रमाणे
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// UTF-16 मध्ये एन्कोड केलेले असल्यास या `char` ला आवश्यक असलेल्या 16-बिट कोड युनिट्सची संख्या मिळवते.
    ///
    ///
    /// या संकल्पनेच्या अधिक स्पष्टीकरणासाठी [`len_utf8()`] चे दस्तऐवजीकरण पहा.
    /// हे कार्य एक आरसा आहे, परंतु UTF-8 ऐवजी UTF-8 साठी.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// हे वर्ण प्रदान केलेल्या बाइट बफरमध्ये UTF-8 म्हणून एन्कोड करते आणि नंतर एन्कोड वर्ण असलेल्या बफरची सदस्यता परत करते.
    ///
    ///
    /// # Panics
    ///
    /// जर बफर पुरेसा मोठा नसेल तर Panics.
    /// कुठल्याही `char` एन्कोड करण्यासाठी लांबीचा चौदा आकार मोठा असतो.
    ///
    /// # Examples
    ///
    /// या दोन्ही उदाहरणांमध्ये, 'ß' एन्कोड करण्यासाठी दोन बाइट घेते.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// खूप लहान असलेला बफर:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // सुरक्षितता: `char` हा सरोगेट नाही, म्हणून ही वैध UTF-8 आहे.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// प्रदान केलेल्या `u16` बफरमध्ये हे वर्ण UTF-16 म्हणून एन्कोड करते आणि नंतर एन्कोड वर्ण असलेल्या बफरची सदस्यता परत करते.
    ///
    ///
    /// # Panics
    ///
    /// जर बफर पुरेसा मोठा नसेल तर Panics.
    /// कोणत्याही `char` एन्कोड करण्यासाठी लांबी 2 चे बफर पुरेसे मोठे आहे.
    ///
    /// # Examples
    ///
    /// या दोन्ही उदाहरणांमध्ये, '𝕊' एन्कोड करण्यासाठी दोन takes u16` घेते.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// खूप लहान असलेला बफर:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// या `char` मध्ये `Alphabetic` गुणधर्म असल्यास `true` मिळवते.
    ///
    /// `Alphabetic` [Unicode Standard] च्या धडा 4 (वर्ण गुणधर्म) मध्ये वर्णन केले आहे आणि [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] मध्ये निर्दिष्ट केले आहे.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // प्रेम म्हणजे बर्‍याच गोष्टी असतात, परंतु ती वर्णमाला नसते
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// या `char` मध्ये `Lowercase` गुणधर्म असल्यास `true` मिळवते.
    ///
    /// `Lowercase` [Unicode Standard] च्या धडा 4 (वर्ण गुणधर्म) मध्ये वर्णन केले आहे आणि [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] मध्ये निर्दिष्ट केले आहे.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // चिनी लिपी आणि विरामचिन्हे आढळत नाहीत आणि म्हणून:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// या `char` मध्ये `Uppercase` गुणधर्म असल्यास `true` मिळवते.
    ///
    /// `Uppercase` [Unicode Standard] च्या धडा 4 (वर्ण गुणधर्म) मध्ये वर्णन केले आहे आणि [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] मध्ये निर्दिष्ट केले आहे.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // चिनी लिपी आणि विरामचिन्हे आढळत नाहीत आणि म्हणून:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// या `char` मध्ये `White_Space` गुणधर्म असल्यास `true` मिळवते.
    ///
    /// `White_Space` [Unicode Character Database][ucd] [`PropList.txt`] मध्ये निर्दिष्ट केले आहे.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // विना खंडित जागा
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// हे `char` [`is_alphabetic()`] किंवा [`is_numeric()`] एकतर समाधानी करत असल्यास `true` मिळवते.
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// या `char` मध्ये नियंत्रण कोडसाठी सामान्य श्रेणी असल्यास `true` मिळवते.
    ///
    /// कंट्रोल कोड (एक्स ०3 एक्सच्या सामान्य श्रेणीसह कोड पॉइंट्स) एक्स ०१ एक्सच्या धडा ((वर्ण गुणधर्म) मध्ये वर्णन केले आहेत आणि एक्स ०२ एक्स एक्स 00०० एक्स मध्ये निर्दिष्ट केले आहेत.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// // U + 009C, STRING टर्मिनेटर
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// या `char` मध्ये `Grapheme_Extend` गुणधर्म असल्यास `true` मिळवते.
    ///
    /// `Grapheme_Extend` [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] मध्ये वर्णन केले आहे आणि [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] मध्ये निर्दिष्ट केले आहे.
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// या `char` मध्ये संख्येसाठी सामान्य श्रेणीपैकी एक असल्यास `true` मिळवते.
    ///
    /// [Unicode Character Database][ucd] [`UnicodeData.txt`] मध्ये संख्येसाठी सामान्य श्रेणी (दशांश अंकांसाठी `Nd`, अक्षरासारख्या अंकीय वर्णांसाठी `Nl` आणि इतर संख्यात्मक वर्णांसाठी `No`) निर्दिष्ट केल्या आहेत.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// एक किंवा अधिक म्हणून या `char` चे लोअरकेस मॅपिंग मिळवित करणारा आयटर परत मिळवितो
    /// `char`s.
    ///
    /// या `char` मध्ये लोअरकेस मॅपिंग नसल्यास, पुनरावृत्ती करणारा समान `char` उत्पन्न देतो.
    ///
    /// जर या `char` मध्ये एक-एक-लोअरकेस मॅपिंग [Unicode Character Database][ucd] [`UnicodeData.txt`] ने दिले असेल तर, पुनरावृत्ती करणार्‍याने ते `char` दिले.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// या `char` ला विशेष विचारांची आवश्यकता असल्यास (उदा. एकाधिक `चार्ट) इटररेटर [`SpecialCasing.txt`] ने दिलेला` चार्ट (s) मिळवते.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// हे ऑपरेशन टेलरिंगशिवाय बिनशर्त मॅपिंग करते.म्हणजेच, रूपांतरण संदर्भ आणि भाषेपासून स्वतंत्र आहे.
    ///
    /// [Unicode Standard] मध्ये, धडा 4 (वर्ण गुणधर्म) सर्वसाधारणपणे केस मॅपिंगची चर्चा करते आणि प्रकरण 3 एक्स01 एक्स केस रूपांतरणासाठी डीफॉल्ट अल्गोरिदमबद्दल चर्चा करते.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// आयटर म्हणूनः
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// थेट `println!` वापरणे:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// दोन्ही समतुल्य आहेत:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// `to_string` वापरणे:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // कधीकधी परिणाम एका वर्णांपेक्षा अधिक असतो:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // वर्ण ज्यामध्ये अपरकेस आणि लोअरकेस दोन्ही नसतात ते स्वत: मध्ये रूपांतरित करतात.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// एक किंवा त्याहून अधिक म्हणून या `char` चे अपरकेस मॅपिंग प्राप्त करणारा इटरेटर परत मिळवते
    /// `char`s.
    ///
    /// या `char` मध्ये अपरकेस मॅपिंग नसल्यास, पुनरावृत्ती करणारा समान `char` मिळवते.
    ///
    /// या `char` मध्ये [Unicode Character Database][ucd] [`UnicodeData.txt`] ने दिलेली एक-एक-मोठ्या अपरकेस मॅपिंग असल्यास, पुनरावृत्ती करणार्‍याने ते `char` दिले.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// या `char` ला विशेष विचारांची आवश्यकता असल्यास (उदा. एकाधिक `चार्ट) इटररेटर [`SpecialCasing.txt`] ने दिलेला` चार्ट (s) मिळवते.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// हे ऑपरेशन टेलरिंगशिवाय बिनशर्त मॅपिंग करते.म्हणजेच, रूपांतरण संदर्भ आणि भाषेपासून स्वतंत्र आहे.
    ///
    /// [Unicode Standard] मध्ये, धडा 4 (वर्ण गुणधर्म) सर्वसाधारणपणे केस मॅपिंगची चर्चा करते आणि प्रकरण 3 एक्स01 एक्स केस रूपांतरणासाठी डीफॉल्ट अल्गोरिदमबद्दल चर्चा करते.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// आयटर म्हणूनः
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// थेट `println!` वापरणे:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// दोन्ही समतुल्य आहेत:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// `to_string` वापरणे:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // कधीकधी परिणाम एका वर्णांपेक्षा अधिक असतो:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // वर्ण ज्यामध्ये अपरकेस आणि लोअरकेस दोन्ही नसतात ते स्वत: मध्ये रूपांतरित करतात.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # लोकॅल वर टीप
    ///
    /// तुर्कीमध्ये, लॅटिनमध्ये 'i' च्या समतुल्य दोनऐवजी पाच फॉर्म आहेत:
    ///
    /// * 'Dotless': मी/ı, कधीकधी लिहिलेले ï
    /// * 'Dotted': İ/i
    ///
    /// लक्षात घ्या की लोअरकेस डॉटेड 'i' हे लॅटिनसारखेच आहे.म्हणून:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// येथे `upper_i` चे मूल्य मजकूराच्या भाषेवर अवलंबून आहे: जर आपण `en-US` मध्ये असाल तर ते `"I"` असले पाहिजे, परंतु जर आपण `tr_TR` मध्ये असाल तर ते `"İ"` असावे.
    /// `to_uppercase()` हे ध्यानात घेत नाही आणि म्हणून:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// भाषा ओलांडून
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// मूल्य एएससीआयआय श्रेणीत आहे की नाही ते तपासते.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// त्याच्या एएससीआयआय अप्पर केस समकक्ष मूल्याची एक प्रत बनवते.
    ///
    /// 'a' ते 'z' पर्यंत ASCII अक्षरे 'A' ते 'Z' पर्यंत मॅप केली गेली आहेत, परंतु ASCII नसलेली अक्षरे बदलली नाहीत.
    ///
    /// जागेचे मूल्य मोठ्या प्रमाणात घेण्यासाठी, [`make_ascii_uppercase()`] वापरा.
    ///
    /// एएससीआयआय नसलेल्या वर्ण व्यतिरिक्त एएससीआयआय वर्ण मोठ्या करण्यासाठी, एक्स00 एक्स वापरा.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// त्याच्या एएससीआयआय लोअर केस समकक्ष मूल्याची प्रत बनविते.
    ///
    /// 'A' ते 'Z' पर्यंत ASCII अक्षरे 'a' ते 'z' पर्यंत मॅप केली गेली आहेत, परंतु ASCII नसलेली अक्षरे बदलली नाहीत.
    ///
    /// जागेचे मूल्य कमी करण्यासाठी, [`make_ascii_lowercase()`] वापरा.
    ///
    /// एएससीआयआय नसलेल्या वर्ण व्यतिरिक्त एएससीआयआय वर्ण लहान करण्यासाठी, [`to_lowercase()`] वापरा.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// दोन मूल्ये एक एएससीआयआय केस-असंवेदनशील सामना आहे याची तपासणी करते.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` च्या समतुल्य.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// या प्रकारास त्याच्या एएससीआयआय अप्पर केसमध्ये समांतर ठिकाणी रुपांतरित करते.
    ///
    /// 'a' ते 'z' पर्यंत ASCII अक्षरे 'A' ते 'Z' पर्यंत मॅप केली गेली आहेत, परंतु ASCII नसलेली अक्षरे बदलली नाहीत.
    ///
    /// विद्यमान व्हॅल्यू न सुधारता नवीन अप्परकेस मूल्य परत करण्यासाठी, [`to_ascii_uppercase()`] वापरा.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// या प्रकारास त्याच्या एएससीआयआय लोअर केसच्या जागी समांतर ठिकाणी रुपांतरित करते.
    ///
    /// 'A' ते 'Z' पर्यंत ASCII अक्षरे 'a' ते 'z' पर्यंत मॅप केली गेली आहेत, परंतु ASCII नसलेली अक्षरे बदलली नाहीत.
    ///
    /// विद्यमान व्हॅल्यू न सुधारता नवीन लोअरकेस मूल्य परत करण्यासाठी, एक्स 100 एक्स वापरा.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// मूल्य एक एएससीआयआय वर्णमाला वर्ण आहे की नाही हे तपासते:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', किंवा
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// मूल्य एक एएससीआयआय अपरकेस वर्ण आहे की नाही ते तपासते:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// मूल्य एक एएससीआयआय लोअरकेस वर्ण असल्यास तपासते:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// मूल्य एक एएससीआयआय अल्फान्यूमेरिक वर्ण असल्यास ते तपासते:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', किंवा
    /// - U + 0061 'a' ..=U + 007A 'z', किंवा
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// मूल्य ASCII दशांश अंक आहे किंवा नाही हे तपासते:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// मूल्य एक ASCII हेक्साडेसिमल अंक आहे किंवा नाही हे तपासते:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', किंवा
    /// - U + 0041 'A' ..=U + 0046 'F', किंवा
    /// - U + 0061 'a' ..=यू +0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// मूल्य एक एएससीआयआय विरामचिन्हे आहे की नाही ते तपासते:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, किंवा
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, किंवा
    /// - U + 005B ..=U + 0060 ``[\] ^ _``, किंवा
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// मूल्य एक एएससीआयआय ग्राफिक वर्ण आहे की नाही ते तपासते:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// मूल्य एक एएससीआयआय व्हाइटस्पेस वर्ण आहे की नाही ते तपासते:
    /// यू +०२० स्पेस, यू +२० H हॅरिजॉन्टल टॅब, यू + +०० ए लाइन फीड, यू +०० सी फॉर्म फीड किंवा यू +०० डी कॅरिएज परत.
    ///
    /// झेडआरस्ट0 झेड वॉटडब्ल्यूजी इन्फ्रा स्टँडर्डचा एक्स00 एक्स वापरते.विस्तृत वापरात इतरही अनेक परिभाषा आहेत.
    /// उदाहरणार्थ, एक्स 100 एक्समध्ये यू + 000 बी व्हर्टिकल टॅब तसेच वरील सर्व वर्णांचा समावेश आहे, परंतु very अगदी समान वैशिष्ट्य पासून-[बॉर्न झेडशेल 0 झेड मधील एक्स 0 एक्सएक्ससाठी डीफॉल्ट नियम][बीएफएस] फक्त * स्पेस, हॉरिजॉन्टल टॅब आणि पांढरी जागा म्हणून लाइन फीड.
    ///
    ///
    /// जर आपण एखादा प्रोग्राम लिहित असाल जो विद्यमान फाईल फॉरमॅटवर प्रक्रिया करेल तर हे फंक्शन वापरण्यापूर्वी व्हाइटस्पेसच्या त्या स्वरूपाची व्याख्या काय आहे ते तपासा.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// मूल्य एक एएससीआयआय नियंत्रण वर्ण आहे की नाही ते तपासते:
    /// यू +0000 एनयूएल ..=यू +001 एफ युनिट सेपरेटर, किंवा यू +007 एफ हटवा.
    /// लक्षात ठेवा की बहुतेक एएससीआयआय व्हाइटस्पेस वर्ण नियंत्रित वर्ण आहेत, परंतु स्पेस तसे नाही.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// प्रदान केलेल्या बाइट बफरमध्ये UTF-8 म्हणून एक कच्चे u32 मूल्य एन्कोड करते आणि नंतर एन्कोड वर्ण असलेल्या बफरची सदस्यता परत करते.
///
///
/// `char::encode_utf8` विपरीत, ही पद्धत सरोगेट रेंजमधील कोडपॉइंट्स देखील हाताळते.
/// (सरोगेट रेंजमध्ये एक X01 एक्स तयार करणे यूबी आहे.) परिणाम वैध [generalized UTF-8] आहे परंतु वैध UTF-8 नाही.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// जर बफर पुरेसा मोठा नसेल तर Panics.
/// कुठल्याही `char` एन्कोड करण्यासाठी लांबीचा चौदा आकार मोठा असतो.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// प्रदान केलेल्या `u16` बफरमध्ये UTF-16 म्हणून एक कच्चे u32 मूल्य एन्कोड करते आणि नंतर एन्कोड वर्ण असलेल्या बफरची सदस्यता परत करते.
///
///
/// `char::encode_utf16` विपरीत, ही पद्धत सरोगेट रेंजमधील कोडपॉइंट्स देखील हाताळते.
/// (सरोगेट रेंजमध्ये एक्स 100 एक्स तयार करणे यूबी आहे.)
///
/// # Panics
///
/// जर बफर पुरेसा मोठा नसेल तर Panics.
/// कोणत्याही `char` एन्कोड करण्यासाठी लांबी 2 चे बफर पुरेसे मोठे आहे.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // सुरक्षितता: प्रत्येक आर्म लिहायला पुरेसे बिट्स आहेत की नाही याची तपासणी करतो
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // बीएमपी येते
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // पूरक विमाने सरोगेट्समध्ये मोडतात.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}