//! वर्ण रूपांतरणे.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// `u32` ला `char` मध्ये रूपांतरित करते.
///
/// लक्षात ठेवा की सर्व [`चार्ट`] वैध आहेत [`u32`] चे आणि त्यासह एकावर कास्ट केले जाऊ शकते
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// तथापि, उलट सत्य नाही: सर्व वैध [`u32`] s वैध नाहीत [`char`] s.
/// `from_u32()` जर इनपुट [`char`] चे वैध मूल्य नसेल तर ते X01 एक्स परत करेल.
///
/// या कार्याच्या असुरक्षित आवृत्तीसाठी जे या धनादेशांकडे दुर्लक्ष करतात, [`from_u32_unchecked`] पहा.
///
///
/// # Examples
///
/// मूलभूत वापर:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// इनपुट वैध [`char`] नसते तेव्हा `None` परत करणे:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// वैधतेकडे दुर्लक्ष करून `u32` ला `char` मध्ये रूपांतरित करते.
///
/// लक्षात ठेवा की सर्व [`चार्ट`] वैध आहेत [`u32`] चे आणि त्यासह एकावर कास्ट केले जाऊ शकते
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// तथापि, उलट सत्य नाही: सर्व वैध [`u32`] s वैध नाहीत [`char`] s.
/// `from_u32_unchecked()` याकडे दुर्लक्ष करेल आणि शक्यतो एखादे अवैध तयार करुन [`char`] वर डोळे झाकून टाकले जाईल.
///
///
/// # Safety
///
/// हे कार्य असुरक्षित आहे कारण यामुळे अवैध `char` मूल्ये तयार केली जाऊ शकतात.
///
/// या कार्याच्या सुरक्षित आवृत्तीसाठी, [`from_u32`] कार्य पहा.
///
/// # Examples
///
/// मूलभूत वापर:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // सुरक्षितता: कॉलरने हमी देणे आवश्यक आहे की `i` ही वैध मूल्य आहे.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// [`char`] ला [`u32`] मध्ये रूपांतरित करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// [`char`] ला [`u64`] मध्ये रूपांतरित करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // चार्ट कोड बिंदूच्या मूल्यावर चार्ट लावला जाईल, नंतर शून्य-वाढून 64 बिटवर जाईल.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] पहा
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// [`char`] ला [`u128`] मध्ये रूपांतरित करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // चार्ट कोड बिंदूच्या मूल्यावर चार्ट लावला जाईल, नंतर शून्य-विस्तारित 128 बिटवर जाईल.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] पहा
        c as u128
    }
}

/// यू +0000 मध्ये 0x00 ..=0xFF मधील एक्स बाईज नकाशे ज्याचे कोड पॉइंट समान मूल्य आहे ..=यू + 00 एफएफ.
///
/// युनिकोड असे डिझाइन केले आहे की हे आयएएनएला आयएसओ-8859-1 कॉल केलेल्या वर्ण एन्कोडिंगसह बाइट्सचे प्रभावीपणे डीकोड करते.
/// हे एन्कोडिंग ASCII सह सुसंगत आहे.
///
/// लक्षात घ्या की हे ISO/IEC 8859-1 उर्फपेक्षा भिन्न आहे
/// आयएसओ 8859-1 (एकापेक्षा कमी हायफनसह), जे काही एक्स 100 एक्स, बाइट व्हॅल्यूज सोडते जे कोणत्याही वर्णांना नियुक्त केलेले नाही.
/// आयएसओ-8859-1 (आयएएनए एक) त्यांना C0 आणि C1 नियंत्रण कोडमध्ये नियुक्त करतो.
///
/// लक्षात घ्या की हे *विंडोज-२००२ उर्फपेक्षा* वेगळा आहे
/// कोड पृष्ठ 1252, जो सुपरसेट एक्स 100 एक्स 8859-1 आहे जो विरामचिन्हे आणि विविध लॅटिन वर्णांना काही (सर्व नाही!) रिक्त स्थान प्रदान करतो.
///
/// गोष्टी आणखी गोंधळात टाकण्यासाठी, एक्स-0 एक्स एक्स 100 एक्स, एक्स ०१ एक्स आणि एक्स ० X एक्स ही विंडोज-१२२ च्या सुपरसेटसाठी उपनावे आहेत जे संबंधित एक्स ०4 एक्स आणि एक्स ०5 एक्स नियंत्रण कोडसह उर्वरित रिक्त जागा भरतात.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// [`u8`] ला [`char`] मध्ये रूपांतरित करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// एखादी त्रुटी जी चार्टचे विश्लेषण करतेवेळी परत येऊ शकते.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // सुरक्षा: हे कायदेशीर युनिकोड मूल्य असल्याचे तपासले
            Ok(unsafe { transmute(i) })
        }
    }
}

/// u32 वरून रूपांतरण अयशस्वी झाल्यास त्रुटी प्रकार परत आला.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// दिलेल्या मूलातील अंक एका `char` मध्ये रूपांतरित करते.
///
/// येथे एक्स01 एक्सला कधीकधी एक्स 100 एक्स देखील म्हटले जाते.
/// दोनची मूलांक काही सामान्य मूल्ये देण्यासाठी बायनरी संख्या, दहाचा दशांश, दशांश आणि सोळा, हेक्साडेसिमलचा मूलांक दर्शवते.
///
/// अनियंत्रित मूलांक समर्थित आहेत.
///
/// `from_digit()` दिलेल्या इन रेडिक्समध्ये इनपुट अंक नसल्यास `None` परत करेल.
///
/// # Panics
///
/// जर 36 पेक्षा मोठा मूलांक दिल्यास Panics.
///
/// # Examples
///
/// मूलभूत वापर:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // बेस 16 मध्ये दशांश 11 हा एक अंक आहे
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// इनपुट अंक नसताना `None` परत करणे:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// मोठा मूलांक पास करणे, झेडस्पॅनिक0 झेडला कारणीभूत आहे:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}