use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// हे कार्य एकाच ठिकाणी वापरले जात असताना आणि त्याची अंमलबजावणी इनलाइन केली जाऊ शकते, तसे करण्याच्या मागील प्रयत्नांनी झेडस्ट्रोस्ट0झेड हळू केले:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// मेमरी ब्लॉकची मांडणी.
///
/// `Layout` चे उदाहरण मेमरीच्या विशिष्ट लेआउटचे वर्णन करते.
/// आपण एखाद्या वितरकास देण्यासाठी इनपुट म्हणून एक `Layout` तयार करा.
///
/// सर्व लेआउटमध्ये संबंधित आकार आणि दोन-एक संरेखन असते.
///
/// (लक्षात घ्या की लेआउट्स * शून्य नसलेले आकार असणे आवश्यक नसतात, जरी `GlobalAlloc` ला आवश्यक आहे की सर्व मेमरी विनंत्या आकारात शून्य नसल्या पाहिजेत.
/// कॉलरने एकतर याची खात्री करुन घ्यावी की यासारख्या परिस्थिती पूर्ण झाल्या आहेत, लूझर आवश्यकता असलेल्या विशिष्ट वाटपाचा वापर करा किंवा अधिक सुस्त `Allocator` इंटरफेस वापरा.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // बाइट्समध्ये मोजलेल्या मेमरीच्या विनंती केलेल्या ब्लॉकचा आकार.
    size_: usize,

    // बाइट्समध्ये मोजलेल्या मेमरीच्या विनंती केलेल्या ब्लॉकचे संरेखन.
    // आम्ही हे सुनिश्चित करतो की हे नेहमीच पॉवर ऑफ टू असते, कारण API च्या `posix_memalign` सारख्या आवश्यक असते आणि लेआउट बांधकाम करणार्‍यांवर थोपवणे ही वाजवी मर्यादा असते.
    //
    //
    // (तथापि, आम्हाला समानपणे `संरेखित>=X00 एक्स आवश्यक नाही
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// दिलेल्या `size` आणि `align` वरून `Layout` तयार करते किंवा पुढीलपैकी कोणत्याही अटी पूर्ण न केल्यास `LayoutError` परत करते:
    ///
    /// * `align` शून्य नसावे,
    ///
    /// * `align` दोनची शक्ती असणे आवश्यक आहे
    ///
    /// * `size`, जेव्हा सर्वात जवळील `align` पर्यंत गोल केले जाते तेव्हा ते ओव्हरफ्लो न होणे (उदा. गोलाकार मूल्य `usize::MAX` पेक्षा कमी किंवा त्यासमान असणे आवश्यक आहे).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (दोनपैकी पॉवर संरेखित सूचित करते!=0)

        // राऊंड अप आकारः
        //   आकार_ग्राउंड_अप=(आकार + संरेखित, 1)&! (संरेखित, 1);
        //
        // आम्हाला त्या संरेखित वरून माहित आहे!=0
        // जोडल्यास (संरेखित, 1) ओव्हरफ्लो होत नसेल तर गोल करणे चांगले होईल.
        //
        // याउलट,&-मास्किंग! (संरेखित, 1) केवळ निम्न-ऑर्डर-बिट्स वजा करेल.
        // अशा प्रकारे ओव्हरफ्लो बेरीजसह झाल्यास, आणि-मास्क ओव्हरफ्लो पूर्ववत करण्यासाठी पुरेसे वजाबाकी करू शकत नाही.
        //
        //
        // वर सूचित केले आहे की समोराच्या ओव्हरफ्लोसाठी तपासणी करणे आवश्यक आणि पुरेसे आहे.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // सुरक्षितताः `from_size_align_unchecked` साठी अटी आहेत
        // वर तपासले.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// सर्व चेकला धरून एक लेआउट तयार करते.
    ///
    /// # Safety
    ///
    /// हे कार्य असुरक्षित आहे कारण ते [`Layout::from_size_align`] मधील पूर्व शर्ती सत्यापित करीत नाही.
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // सुरक्षितता: कॉलरने हे सुनिश्चित केले पाहिजे की `align` शून्यापेक्षा मोठे आहे.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// या लेआउटच्या मेमरी ब्लॉकसाठी बाइट्स मधील किमान आकार.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// या लेआउटच्या मेमरी ब्लॉकसाठी किमान बाइट संरेखन.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// `T` प्रकाराचे मूल्य ठेवण्यासाठी योग्य `Layout` तयार करते.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // सुरक्षितता: संरेखित Rust द्वारे दोन आणि एक ची शक्ती असल्याचे हमी दिलेली आहे
        // आकार + संरेखित कॉम्बोची हमी आमच्या अ‍ॅड्रेस स्पेसमध्ये बसण्याची हमी आहे.
        // याचा परिणाम म्हणून panics तो पुरेसा ऑप्टिमाइझ केलेला नसल्यास कोड प्रविष्ट करणे टाळण्यासाठी येथे अनचेक केलेले कन्स्ट्रक्टर वापरा.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T` (जे trait किंवा स्लाइससारखे अन्य आकार नसलेले प्रकार असू शकते) साठी रेकॉर्डिंगचे रेकॉर्ड वर्णन करणारे लेआउट तयार करते.
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // सुरक्षितताः हे असुरक्षित प्रकार का वापरत आहे हे `new` मधील तर्क पहा
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T` (जे trait किंवा स्लाइससारखे अन्य आकार नसलेले प्रकार असू शकते) साठी रेकॉर्डिंगचे रेकॉर्ड वर्णन करणारे लेआउट तयार करते.
    ///
    /// # Safety
    ///
    /// खाली दिलेल्या अटी धरून असल्यास हे फंक्शन फक्त कॉल करण्यासाठीच सुरक्षित आहेः
    ///
    /// - जर `T` हे `Sized` असेल तर हे फंक्शन कॉल करण्यासाठी नेहमीच सुरक्षित असते.
    /// - जर `T` ची आकार नसलेली शेपटी असेल तर:
    ///     - एक X01 एक्स, नंतर स्लाइस शेपटीची लांबी एक अंतर्निहित पूर्णांक असणे आवश्यक आहे आणि *संपूर्ण मूल्य*(डायनॅमिक शेपूट लांबी + स्थिर आकाराचे उपसर्ग) चा आकार `isize` मध्ये फिट असणे आवश्यक आहे.
    ///     - एक X01 एक्स, नंतर पॉईंटरच्या व्हीटेबल भागाने अनसाइझिंग कोर्सियनद्वारे अधिग्रहित केलेल्या एक्स02 एक्स प्रकारासाठी वैध व्हीटेबलकडे निर्देश करणे आवश्यक आहे आणि *संपूर्ण मूल्य*(डायनॅमिक शेपूट लांबी + स्थिर आकाराचे उपसर्ग) आकार `isize` मध्ये फिट असणे आवश्यक आहे.
    ///
    ///     - एक (unstable) [extern type], नंतर हे फंक्शन कॉल करण्यासाठी नेहमीच सुरक्षित असते, परंतु बाह्य प्रकारच्या लेआउट माहित नसल्यामुळे panic किंवा अन्यथा चुकीचे मूल्य परत येऊ शकते.
    ///     बाह्य प्रकारच्या शेपटीच्या संदर्भात हे [`Layout::for_value`] सारखेच वर्तन आहे.
    ///     - अन्यथा, हे कार्य करण्यासाठी कॉल करण्यासाठी पुराणमतवादी अनुमती नाही.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // सुरक्षितता: आम्ही या फंक्शन्सच्या आवश्यक गोष्टी कॉलरला पाठवतो
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // सुरक्षितताः हे असुरक्षित प्रकार का वापरत आहे हे `new` मधील तर्क पहा
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// डँगलिंग करणारे एक X00 एक्स तयार करते परंतु या लेआउटसाठी चांगले संरेखित केले आहे.
    ///
    /// लक्षात ठेवा की पॉईंटर मूल्य संभाव्यत: वैध पॉईंटरचे प्रतिनिधित्व करू शकते, याचा अर्थ असा की हे "not yet initialized" सेन्टिनल मूल्य म्हणून वापरले जाऊ नये.
    /// आळशीपणे वाटप केलेल्या प्रकारांमध्ये इतर काही मार्गांनी आरंभ ट्रॅक करणे आवश्यक आहे.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // सुरक्षा: संरेखित शून्य नसल्याची हमी आहे
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// रेकॉर्डचे वर्णन करणारे एक लेआउट तयार करते जे `self` सारख्याच लेआउटचे मूल्य धारण करू शकते, परंतु ते संरेखित देखील केलेले आहे `align` (बाइट्समध्ये मोजलेले).
    ///
    ///
    /// जर `self` आधीपासूनच निर्धारित संरेखन पूर्ण करीत असेल तर `self` परत करेल.
    ///
    /// लक्षात घ्या की परत आलेल्या लेआउटमध्ये भिन्न संरेखन आहे की नाही याकडे दुर्लक्ष करून ही पद्धत एकूण आकारात कोणतेही पॅडिंग जोडत नाही.
    /// दुसर्‍या शब्दांत, जर एक्स 0 एक्सचा आकार 16 असेल तर एक्स00 एक्स *स्टील* आकार 16 असेल.
    ///
    /// `self.size()` आणि दिलेल्या `align` चे संयोजन [`Layout::from_size_align`] मध्ये सूचीबद्ध अटींचे उल्लंघन करत असल्यास त्रुटी परत करते.
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// खालील पत्ते `align` (बाइट्स मध्ये मोजले) पूर्ण करतील याची खात्री करण्यासाठी आम्ही `self` नंतर समाविष्ट करणे आवश्यक असलेल्या पॅडिंगची रक्कम मिळवते.
    ///
    /// उदा. जर `self.size()` 9 असेल तर `self.padding_needed_for(4)` 3 परत करेल, कारण 4 संरेखित पत्ता मिळविण्यासाठी आवश्यक पॅडिंगच्या किमान बाइटची संख्या आहे (असे गृहीत धरून संबंधित मेमरी ब्लॉक 4-संरेखित पत्त्यापासून सुरू होईल).
    ///
    ///
    /// `align` दोनपैकी पॉवर ऑफ नसल्यास या कार्याचे परताव्याचे कोणतेही अर्थ नाही.
    ///
    /// लक्षात ठेवा की परत केलेल्या मूल्याची युटिलिटीमध्ये मेमरीच्या संपूर्ण वाटप केलेल्या ब्लॉकसाठी सुरू केलेल्या पत्त्याच्या संरेखनपेक्षा `align` कमी किंवा समान असणे आवश्यक आहे.ही मर्यादा पूर्ण करण्याचा एक मार्ग म्हणजे `align <= self.align()` सुनिश्चित करणे.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // पूर्णांक मूल्यः
        //   लेन_ग्राउंड_अप=(लेन + संरेखित, 1)&! (संरेखित, 1);
        // आणि मग आम्ही पॅडिंगचा फरक परत करतो: `len_rounded_up - len`.
        //
        // आम्ही संपूर्ण मॉड्यूलर अंकगणित वापरतो:
        //
        // 1. संरेखित> 0 असण्याची हमी आहे, म्हणून संरेखित करा, 1 नेहमी वैध असेल.
        //
        // 2.
        // `len + align - 1` जास्तीत जास्त `align - 1` ने ओव्हरफ्लो होऊ शकते, म्हणून एक्स-0 एक्स सह&-मास्क हे सुनिश्चित करेल की ओव्हरफ्लोच्या बाबतीत, एक्स 0 एक्स एक्स स्वतःच 0 असेल.
        //
        //    अशाप्रकारे परत केलेले पॅडिंग, जेव्हा एक्स0 एक्स मध्ये जोडले जाते तेव्हा 0 उत्पन्न मिळते जे संक्षिप्त `align` चे क्षुल्लक समाधान करते.
        //
        // (अर्थात, वरील पद्धतीने ज्याचे आकार आणि पॅडिंग ओव्हरफ्लो आहेत त्या मेमरीचे ब्लॉक वाटप करण्याच्या प्रयत्नांमुळे वाटप करणार्‍याला तरीही त्रुटी निर्माण होऊ शकते.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// या लेआउटच्या आकारात एकापेक्षा जास्त लेआउट संरेखन करण्यासाठी एक लेआउट तयार करते.
    ///
    ///
    /// हे लेआउटच्या सद्य आकारात `padding_needed_for` चा निकाल जोडण्यासारखे आहे.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // हे ओसंडून वाहू शकत नाही.लेआउटच्या आक्रमणकर्त्याचे अवतरण:
        // > `size`, जेव्हा `align` च्या जवळच्या एकाधिकपर्यंत गोल केले जाते,
        // > ओव्हरफ्लो होऊ नये (उदा. गोलाकार मूल्य त्यापेक्षा कमी असणे आवश्यक आहे
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// प्रत्येक उदाहरणास विनंती केलेले आकार आणि संरेखन दिले गेले आहे हे सुनिश्चित करण्यासाठी प्रत्येक दरम्यान योग्य प्रमाणात पॅडिंगसह `self` च्या एक्स 0 एक्स एक्सच्या रेकॉर्डचे वर्णन करणारा एक लेआउट तयार करतो.
    /// यशस्वीरित्या, `(k, offs)` मिळवते जिथे `k` अ‍ॅरेचा लेआउट आहे आणि `offs` अ‍ॅरेमधील प्रत्येक घटकाच्या सुरूवातीस अंतर आहे.
    ///
    /// अंकगणित ओव्हरफ्लोवर, `LayoutError` मिळवते.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // हे ओसंडून वाहू शकत नाही.लेआउटच्या आक्रमणकर्त्याचे अवतरण:
        // > `size`, जेव्हा `align` च्या जवळच्या एकाधिकपर्यंत गोल केले जाते,
        // > ओव्हरफ्लो होऊ नये (उदा. गोलाकार मूल्य त्यापेक्षा कमी असणे आवश्यक आहे
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // सुरक्षितता: self.align आधीपासूनच वैध असल्याचे ज्ञात आहे आणि allocलोक_साइझ केले गेले आहे
        // आधीच पॅड
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// X02 एक्स योग्यरित्या संरेखित केले जाईल याची खात्री करण्यासाठी कोणत्याही आवश्यक पॅडिंगसह, एक्स 100 एक्स नंतर एक्स 100 एक्सच्या रेकॉर्डचे वर्णन करणारा एक लेआउट तयार करतो, परंतु *ट्रेलिंग पॅडिंग नाही*.
    ///
    /// सी प्रतिनिधित्व लेआउट `repr(C)` शी जुळण्यासाठी, आपण सर्व फील्डसह लेआउट विस्तृत केल्या नंतर आपण `pad_to_align` वर कॉल केला पाहिजे.
    /// (डीफॉल्ट Rust प्रतिनिधीत्व लेआउट `repr(Rust)`, as it is unspecified.) शी जुळण्यासाठी कोणताही मार्ग नाही
    ///
    /// लक्षात घ्या की दोन्ही भागांचे संरेखन सुनिश्चित करण्यासाठी परिणामी लेआउटचे संरेखन `self` आणि `next` मधील कमाल असेल.
    ///
    /// `Ok((k, offset))` मिळवते, जिथे `k` हे एकत्रित रेकॉर्डचे लेआउट आहे आणि `offset` हे संक्षिप्त रेकॉर्डमध्ये एम्बेड केलेले `next` च्या प्रारंभाचे संबंधित स्थान आहे (असे गृहीत धरून की रेकॉर्ड स्वतः ऑफसेट 0 पासून सुरू होईल).
    ///
    ///
    /// अंकगणित ओव्हरफ्लोवर, `LayoutError` मिळवते.
    ///
    /// # Examples
    ///
    /// त्याच्या फील्डच्या लेआउटमधून `#[repr(C)]` स्ट्रक्चरची लेआउट आणि फील्डच्या ऑफसेटची गणना करण्यासाठी:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // `pad_to_align` सह अंतिम करणे लक्षात ठेवा!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // ते कार्य करते याची चाचणी घ्या
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// प्रत्येक उदाहरणात पॅडिंग नसताना `self` च्या एक्स 0 एक्स एक्सच्या रेकॉर्डचे वर्णन करणारे एक लेआउट तयार करते.
    ///
    /// लक्षात घ्या की `repeat` च्या विपरीत, `repeat_packed` हमी देत नाही की `self` ची पुनरावृत्ती केलेली घटना योग्यरित्या संरेखित केली जातील, जरी `self` ची दिलेली घटना योग्य प्रकारे संरेखित केली गेली असेल.
    /// दुसर्‍या शब्दांत, जर एक्स00 एक्स ने परत केलेला लेआउट अ‍ॅरे वाटप करण्यासाठी वापरला असेल तर अ‍ॅरे मधील सर्व घटक योग्य प्रकारे संरेखित केले जातील याची हमी नाही.
    ///
    /// अंकगणित ओव्हरफ्लोवर, `LayoutError` मिळवते.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// त्या दोघांमधील अतिरिक्त पॅडिंग न घेता `self` त्यानंतर `self` च्या विक्रमाचे वर्णन करणारे एक लेआउट तयार करते.
    /// कोणतेही पॅडिंग घातलेले नसल्यामुळे, `next` चे संरेखन असंबद्ध आहे आणि परिणामी लेआउटमध्ये *अजिबात* समाविष्ट केलेले नाही.
    ///
    ///
    /// अंकगणित ओव्हरफ्लोवर, `LayoutError` मिळवते.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// `[T; n]` च्या रेकॉर्डचे वर्णन करणारे एक लेआउट तयार करते.
    ///
    /// अंकगणित ओव्हरफ्लोवर, `LayoutError` मिळवते.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// `Layout::from_size_align` किंवा इतर काही `Layout` कन्स्ट्रक्टरला दिलेली मापदंड त्याच्या दस्तऐवजीकरणातील मर्यादा पूर्ण करीत नाहीत.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (आम्हाला झेडट्रायट0 झेड एररच्या डाउनस्ट्रीम प्रॉम्पलसाठी हे आवश्यक आहे)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}