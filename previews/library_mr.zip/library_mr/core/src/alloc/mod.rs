//! मेमरी वाटप एपीआय

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// `AllocError` त्रुटी हे वाटप अपयश सूचित करते जे संसाधन संपुष्टात आल्यामुळे किंवा या वाटपकर्त्यासह दिलेल्या इनपुट वितर्कांना एकत्रित करताना काहीतरी चुकीचे होऊ शकते.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (आम्हाला झेडट्रायट0 झेड एररच्या डाउनस्ट्रीम प्रॉम्पलसाठी हे आवश्यक आहे)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// `Allocator` ची अंमलबजावणी [`Layout`][] द्वारे वर्णन केलेल्या डेटाचे अनियंत्रित, वाढू, संकुचित करणे आणि अनियंत्रित ब्लॉक नष्ट करू शकते.
///
/// `Allocator` ZSTs, संदर्भ, किंवा स्मार्ट पॉईंटर्सवर अंमलात आणण्यासाठी डिझाइन केलेले आहे कारण वाटप केलेल्या मेमरीमध्ये पॉईंटर्स अद्यतनित केल्याशिवाय `MyAlloc([u8; N])` सारख्या वाटपाचा वापर करणे हलविणे शक्य नाही.
///
/// [`GlobalAlloc`][] विपरीत, `Allocator` मध्ये शून्य-आकाराच्या वाटपांना परवानगी आहे.
/// जर अंतर्निहित allocलोकटर (जेमॅलोक सारखे) यास समर्थन देत नसेल किंवा शून्य पॉईंटर (जसे की X00 एक्स) परत करत नसेल तर अंमलबजावणीद्वारे हे पकडले पाहिजे.
///
/// ### सध्या वाटप केलेली मेमरी
///
/// काही पद्धतींमध्ये आवश्यक आहे की स्मृती ब्लॉकला सध्या allocatedलोकटरद्वारे * वाटप केले जावे.याचा अर्थ असाः
///
/// * त्या मेमरी ब्लॉकसाठी प्रारंभ पत्ता पूर्वी [`allocate`], [`grow`], किंवा [`shrink`], आणि द्वारा परत आला
///
/// * त्यानंतर मेमरी ब्लॉक डीओलोकेटेड केले गेले नाही, जेथे ब्लॉक्स एकतर एक्स01 एक्सकडे पाठवून थेट विकृत केले गेले आहेत किंवा एक्स0 एक्स किंवा एक्स ०0 एक्सवर परत बदलले गेले आहेत जे एक्स १० एक्स परत करतात.
///
/// जर `grow` किंवा `shrink` ने `Err` परत केला असेल तर उत्तीर्ण पॉईंटर वैध राहील.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### मेमरी फिटिंग
///
/// काही पद्धतींसाठी एक लेआउट *फिट* मेमरी ब्लॉक असणे आवश्यक आहे.
/// मेमरी ब्लॉकच्या "fit" करण्यासाठी लेआउटचा अर्थ काय आहे (किंवा समांतर, मेमरी ब्लॉकसाठी "fit" पर्यंत एक लेआउट) हे आहे की पुढील अटी असाव्यातः
///
/// * [`layout.align()`] आणि त्याच प्रमाणे संरेखितसह ब्लॉकचे वाटप करणे आवश्यक आहे
///
/// * प्रदान केलेले [`layout.size()`] श्रेणी `min ..= max` श्रेणीमध्ये होणे आवश्यक आहे, जेथेः
///   - `min` अलीकडील ब्लॉकचे वाटप करण्यासाठी वापरलेल्या लेआउटचा आकार आणि
///   - `max` [`allocate`], [`grow`] किंवा [`shrink`] वरून परत केलेला नवीनतम वास्तविक आकार आहे.
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Allocलोकरेटरकडून परत आलेल्या मेमरी ब्लॉक्सने वैध मेमरीकडे निर्देश करणे आवश्यक आहे आणि घटना आणि त्याचे सर्व क्लोन सोडल्याशिवाय त्यांची वैधता टिकवून ठेवली पाहिजे,
///
/// * क्लोनिंग किंवा theलोकटर हलविण्यामुळे या वाटपकर्त्याकडून परत आलेल्या मेमरी ब्लॉक्स अवैध केले जाऊ शकत नाहीत.क्लोन वाटप करणार्‍याने समान वाटप करणार्‍यासारखे वागले पाहिजे आणि
///
/// * [*currently allocated*] असलेल्या मेमरी ब्लॉकचे कोणतेही पॉईंटर वाटप करणार्‍याच्या इतर कोणत्याही पद्धतीकडे जाऊ शकतात.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// मेमरी ब्लॉकचे वाटप करण्याचा प्रयत्न.
    ///
    /// यशस्वीरित्या, `layout` चे आकार आणि संरेखन हमीची पूर्तता करणारा एक `layout` परत करतो.
    ///
    /// परत केलेल्या ब्लॉकमध्ये `layout.size()` नुसार निर्दिष्ट केलेल्यापेक्षा मोठा आकार असू शकतो आणि कदाचित त्याची सामग्री प्रारंभ होऊ किंवा नसू शकते.
    ///
    /// # Errors
    ///
    /// `Err` परत करणे हे दर्शविते की एकतर मेमरी संपली आहे किंवा `layout` वाटप करणार्‍याचा आकार किंवा संरेखन मर्यादा पूर्ण करीत नाही.
    ///
    /// अंमलबजावणीमध्ये घाबरून किंवा गर्भपात करण्याऐवजी मेमरी थकवा वर एक्स 100 एक्स परत करण्यास प्रोत्साहित केले जाते, परंतु ही कठोर आवश्यकता नाही.
    /// (विशेषतःः मेमरी थकवा संपल्यावर मूळ मुळ ationलोकेशन लायब्ररीच्या शेवटी हे झेडट्रेट ० झेड लागू करणे *कायदेशीर* आहे.)
    ///
    /// वाटप त्रुटीच्या उत्तरात कंप्यूटेशन रद्द करण्यास इच्छुक ग्राहकांना `panic!` किंवा तत्सम थेट आवाहन करण्याऐवजी [`handle_alloc_error`] फंक्शन कॉल करण्यास प्रोत्साहित केले जाते.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// एक्स 100 एक्ससारखे वर्तन करते, परंतु परत मिळविलेले मेमरी शून्य-आरंभिक असल्याचे देखील सुनिश्चित करते.
    ///
    /// # Errors
    ///
    /// `Err` परत करणे हे दर्शविते की एकतर मेमरी संपली आहे किंवा `layout` वाटप करणार्‍याचा आकार किंवा संरेखन मर्यादा पूर्ण करीत नाही.
    ///
    /// अंमलबजावणीमध्ये घाबरून किंवा गर्भपात करण्याऐवजी मेमरी थकवा वर एक्स 100 एक्स परत करण्यास प्रोत्साहित केले जाते, परंतु ही कठोर आवश्यकता नाही.
    /// (विशेषतःः मेमरी थकवा संपल्यावर मूळ मुळ ationलोकेशन लायब्ररीच्या शेवटी हे झेडट्रेट ० झेड लागू करणे *कायदेशीर* आहे.)
    ///
    /// वाटप त्रुटीच्या उत्तरात कंप्यूटेशन रद्द करण्यास इच्छुक ग्राहकांना `panic!` किंवा तत्सम थेट आवाहन करण्याऐवजी [`handle_alloc_error`] फंक्शन कॉल करण्यास प्रोत्साहित केले जाते.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // सुरक्षितता: `alloc` एक वैध मेमरी ब्लॉक परत करतो
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// `ptr` द्वारे संदर्भित मेमरीचे विलोपन करते.
    ///
    /// # Safety
    ///
    /// * `ptr` या वाटपकर्त्याद्वारे मेमरी [*currently allocated*] चे ब्लॉक दर्शविणे आवश्यक आहे, आणि
    /// * `layout` मेमरी ब्लॉक करणे आवश्यक आहे [*fit*].
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// मेमरी ब्लॉक वाढवण्याचा प्रयत्न.
    ///
    /// पॉईंटर आणि वाटप केलेल्या मेमरीचा वास्तविक आकार असलेले नवीन [`NonNull<[u8]>`][NonNull] मिळवते.`new_layout` द्वारे वर्णन केलेला डेटा ठेवण्यासाठी पॉईंटर योग्य आहे.
    /// हे पूर्ण करण्यासाठी, नवीन लेआउट फिट करण्यासाठी Xलोकरेटर `ptr` द्वारे संदर्भित वाटप वाढवू शकतो.
    ///
    /// हे `Ok` परत करत असल्यास, नंतर एक्स 0 एएक्सने संदर्भित मेमरी ब्लॉकची मालकी या वाटपाकडे हस्तांतरित केली आहे.
    /// मेमरी मुक्त केली गेली असेल किंवा नसली असेल आणि या पद्धतीच्या परताव्या मूल्याद्वारे परत कॉलरकडे परत स्थानांतरित केल्याशिवाय आणि ती निरुपयोगी मानली जावी.
    ///
    /// ही पद्धत `Err` परत केल्यास, मेमरी ब्लॉकची मालकी या वाटपकर्त्यास हस्तांतरित केली गेली नाही आणि मेमरी ब्लॉकमधील सामग्री अवांछित आहे.
    ///
    /// # Safety
    ///
    /// * `ptr` या वाटपकर्त्याद्वारे मेमरी [*currently allocated*] चे ब्लॉक दर्शविणे आवश्यक आहे.
    /// * `old_layout` [*fit*] हे स्मृती ब्लॉक केले पाहिजे (`new_layout` वितर्क त्यास बसत नाही.)
    /// * `new_layout.size()` `old_layout.size()` पेक्षा मोठे किंवा समान असणे आवश्यक आहे.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// नवीन लेआउट वितरकाच्या आकार आणि संरेखन मर्यादेची पूर्तता न केल्यास किंवा वाढत्या प्रमाणात अपयशी ठरल्यास `Err` मिळवते.
    ///
    /// अंमलबजावणीमध्ये घाबरून किंवा गर्भपात करण्याऐवजी मेमरी थकवा वर एक्स 100 एक्स परत करण्यास प्रोत्साहित केले जाते, परंतु ही कठोर आवश्यकता नाही.
    /// (विशेषतःः मेमरी थकवा संपल्यावर मूळ मुळ ationलोकेशन लायब्ररीच्या शेवटी हे झेडट्रेट ० झेड लागू करणे *कायदेशीर* आहे.)
    ///
    /// वाटप त्रुटीच्या उत्तरात कंप्यूटेशन रद्द करण्यास इच्छुक ग्राहकांना `panic!` किंवा तत्सम थेट आवाहन करण्याऐवजी [`handle_alloc_error`] फंक्शन कॉल करण्यास प्रोत्साहित केले जाते.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // सुरक्षितता: कारण `new_layout.size()` यापेक्षा मोठे किंवा समान असणे आवश्यक आहे
        // `old_layout.size()`, जुन्या आणि नवीन मेमरीचे दोन्ही वाटप `old_layout.size()` बाइटसाठी वाचन आणि लेखनासाठी वैध आहेत.
        // तसेच, जुने वाटप अद्याप रद्दबातल झाले नव्हते म्हणून ते एक्स 100 एक्सला आच्छादित करू शकत नाही.
        // अशा प्रकारे, `copy_nonoverlapping` वर कॉल सुरक्षित आहे.
        // कॉलरद्वारे `dealloc` चे सुरक्षा कराराचे समर्थन केले जाणे आवश्यक आहे.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// एक्स 100 एक्ससारखे वर्तन करते, परंतु हे सुनिश्चित करते की नवीन सामग्री परत येण्यापूर्वी शून्यावर सेट केली जाईल.
    ///
    /// यशस्वी कॉलनंतर मेमरी ब्लॉकमध्ये खालील सामग्री असेल
    /// `grow_zeroed`:
    ///   * बाइट्स `0..old_layout.size()` मूळ वाटपापासून संरक्षित केले आहेत.
    ///   * बाइट्स एक्स 100 एक्स एकतर संरक्षित किंवा शून्य केले जाईल, जो theलोटरच्या अंमलबजावणीवर अवलंबून आहे.
    ///   `old_size` `grow_zeroed` कॉलपूर्वी मेमरी ब्लॉकच्या आकारास संदर्भित करते, जे वाटप करण्यात आले तेव्हा मूळत: विनंती केलेले आकारापेक्षा मोठे असू शकते.
    ///   * बाइट्स एक्स ०१ एक्स शून्य आहेत.`new_size` `grow_zeroed` कॉलद्वारे परत आलेल्या मेमरी ब्लॉकच्या आकाराचा संदर्भ देते.
    ///
    /// # Safety
    ///
    /// * `ptr` या वाटपकर्त्याद्वारे मेमरी [*currently allocated*] चे ब्लॉक दर्शविणे आवश्यक आहे.
    /// * `old_layout` [*fit*] हे स्मृती ब्लॉक केले पाहिजे (`new_layout` वितर्क त्यास बसत नाही.)
    /// * `new_layout.size()` `old_layout.size()` पेक्षा मोठे किंवा समान असणे आवश्यक आहे.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// नवीन लेआउट वितरकाच्या आकार आणि संरेखन मर्यादेची पूर्तता न केल्यास किंवा वाढत्या प्रमाणात अपयशी ठरल्यास `Err` मिळवते.
    ///
    /// अंमलबजावणीमध्ये घाबरून किंवा गर्भपात करण्याऐवजी मेमरी थकवा वर एक्स 100 एक्स परत करण्यास प्रोत्साहित केले जाते, परंतु ही कठोर आवश्यकता नाही.
    /// (विशेषतःः मेमरी थकवा संपल्यावर मूळ मुळ ationलोकेशन लायब्ररीच्या शेवटी हे झेडट्रेट ० झेड लागू करणे *कायदेशीर* आहे.)
    ///
    /// वाटप त्रुटीच्या उत्तरात कंप्यूटेशन रद्द करण्यास इच्छुक ग्राहकांना `panic!` किंवा तत्सम थेट आवाहन करण्याऐवजी [`handle_alloc_error`] फंक्शन कॉल करण्यास प्रोत्साहित केले जाते.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // सुरक्षितता: कारण `new_layout.size()` यापेक्षा मोठे किंवा समान असणे आवश्यक आहे
        // `old_layout.size()`, जुन्या आणि नवीन मेमरीचे दोन्ही वाटप `old_layout.size()` बाइटसाठी वाचन आणि लेखनासाठी वैध आहेत.
        // तसेच, जुने वाटप अद्याप रद्दबातल झाले नव्हते म्हणून ते एक्स 100 एक्सला आच्छादित करू शकत नाही.
        // अशा प्रकारे, `copy_nonoverlapping` वर कॉल सुरक्षित आहे.
        // कॉलरद्वारे `dealloc` चे सुरक्षा कराराचे समर्थन केले जाणे आवश्यक आहे.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// मेमरी ब्लॉक संकुचित करण्याचा प्रयत्न.
    ///
    /// पॉईंटर आणि वाटप केलेल्या मेमरीचा वास्तविक आकार असलेले नवीन [`NonNull<[u8]>`][NonNull] मिळवते.`new_layout` द्वारे वर्णन केलेला डेटा ठेवण्यासाठी पॉईंटर योग्य आहे.
    /// हे पूर्ण करण्यासाठी, नवीन लेआउट बसविण्यासाठी एक्सटॉरटर `ptr` द्वारे संदर्भित वाटप संकुचित करू शकेल.
    ///
    /// हे `Ok` परत करत असल्यास, नंतर एक्स 0 एएक्सने संदर्भित मेमरी ब्लॉकची मालकी या वाटपाकडे हस्तांतरित केली आहे.
    /// मेमरी मुक्त केली गेली असेल किंवा नसली असेल आणि या पद्धतीच्या परताव्या मूल्याद्वारे परत कॉलरकडे परत स्थानांतरित केल्याशिवाय आणि ती निरुपयोगी मानली जावी.
    ///
    /// ही पद्धत `Err` परत केल्यास, मेमरी ब्लॉकची मालकी या वाटपकर्त्यास हस्तांतरित केली गेली नाही आणि मेमरी ब्लॉकमधील सामग्री अवांछित आहे.
    ///
    /// # Safety
    ///
    /// * `ptr` या वाटपकर्त्याद्वारे मेमरी [*currently allocated*] चे ब्लॉक दर्शविणे आवश्यक आहे.
    /// * `old_layout` [*fit*] हे स्मृती ब्लॉक केले पाहिजे (`new_layout` वितर्क त्यास बसत नाही.)
    /// * `new_layout.size()` `old_layout.size()` पेक्षा लहान किंवा त्यासमान असणे आवश्यक आहे.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// नवीन लेआउट वितरकाच्या आकार आणि संरेखन मर्यादेची पूर्तता न केल्यास किंवा आकुंचन करणे अयशस्वी झाल्यास `Err` मिळवते.
    ///
    /// अंमलबजावणीमध्ये घाबरून किंवा गर्भपात करण्याऐवजी मेमरी थकवा वर एक्स 100 एक्स परत करण्यास प्रोत्साहित केले जाते, परंतु ही कठोर आवश्यकता नाही.
    /// (विशेषतःः मेमरी थकवा संपल्यावर मूळ मुळ ationलोकेशन लायब्ररीच्या शेवटी हे झेडट्रेट ० झेड लागू करणे *कायदेशीर* आहे.)
    ///
    /// वाटप त्रुटीच्या उत्तरात कंप्यूटेशन रद्द करण्यास इच्छुक ग्राहकांना `panic!` किंवा तत्सम थेट आवाहन करण्याऐवजी [`handle_alloc_error`] फंक्शन कॉल करण्यास प्रोत्साहित केले जाते.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // सुरक्षितताः कारण `new_layout.size()` यापेक्षा कमी किंवा त्यासमान असणे आवश्यक आहे
        // `old_layout.size()`, जुन्या आणि नवीन मेमरीचे दोन्ही वाटप `new_layout.size()` बाइटसाठी वाचन आणि लेखनासाठी वैध आहेत.
        // तसेच, जुने वाटप अद्याप रद्दबातल झाले नव्हते म्हणून ते एक्स 100 एक्सला आच्छादित करू शकत नाही.
        // अशा प्रकारे, `copy_nonoverlapping` वर कॉल सुरक्षित आहे.
        // कॉलरद्वारे `dealloc` चे सुरक्षा कराराचे समर्थन केले जाणे आवश्यक आहे.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// `Allocator` च्या या उदाहरणासाठी "by reference" अ‍ॅडॉप्टर तयार करते.
    ///
    /// परत केलेला अ‍ॅडॉप्टर `Allocator` देखील लागू करतो आणि हे कर्ज घेईल.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // सुरक्षितता: सुरक्षितता करार कॉलरद्वारे कायम ठेवला जाणे आवश्यक आहे
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // सुरक्षितता: सुरक्षितता करार कॉलरद्वारे कायम ठेवला जाणे आवश्यक आहे
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // सुरक्षितता: सुरक्षितता करार कॉलरद्वारे कायम ठेवला जाणे आवश्यक आहे
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // सुरक्षितता: सुरक्षितता करार कॉलरद्वारे कायम ठेवला जाणे आवश्यक आहे
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}