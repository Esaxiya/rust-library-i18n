#![stable(feature = "duration_core", since = "1.25.0")]

//! ऐहिक परिमाण
//!
//! Example:
//!
//! ```
//! use std::time::Duration;
//!
//! let five_seconds = Duration::new(5, 0);
//! // दोन्ही घोषणा समकक्ष आहेत
//! assert_eq!(Duration::new(5, 0), Duration::from_secs(5));
//! ```

use crate::fmt;
use crate::iter::Sum;
use crate::ops::{Add, AddAssign, Div, DivAssign, Mul, MulAssign, Sub, SubAssign};

const NANOS_PER_SEC: u32 = 1_000_000_000;
const NANOS_PER_MILLI: u32 = 1_000_000;
const NANOS_PER_MICRO: u32 = 1_000;
const MILLIS_PER_SEC: u64 = 1_000;
const MICROS_PER_SEC: u64 = 1_000_000;

/// कालावधीच्या कालावधीचे प्रतिनिधित्व करण्यासाठी `Duration` प्रकार, सामान्यत: सिस्टम टाइमआउटसाठी वापरला जातो.
///
/// प्रत्येक एक्स 100 एक्स संपूर्ण सेकंद आणि नॅनोसेकंदमध्ये प्रतिनिधित्व करणारा एक अपूर्णांक बनलेला असतो.
/// जर अंतर्निहित प्रणाली नॅनोसेकंद-स्तरीय सुस्पष्टतेस समर्थन देत नसेल तर सिस्टम कालबाह्य बंधनकारक एपीआय सहसा नॅनोसेकंदची संख्या वाढवतील.
///
/// [`अवधि`] चे [`Add`], [`Sub`] आणि इतर [`ops`] traits सह अनेक सामान्य traits ची अंमलबजावणी करते.हे शून्य-लांबीच्या `Duration` परत करून [`Default`] लागू करते.
///
/// [`ops`]: crate::ops
///
/// # Examples
///
/// ```
/// use std::time::Duration;
///
/// let five_seconds = Duration::new(5, 0);
/// let five_seconds_and_five_nanos = five_seconds + Duration::new(0, 5);
///
/// assert_eq!(five_seconds_and_five_nanos.as_secs(), 5);
/// assert_eq!(five_seconds_and_five_nanos.subsec_nanos(), 5);
///
/// let ten_millis = Duration::from_millis(10);
/// ```
///
/// # `Duration` मूल्ये स्वरूपित करीत आहे
///
/// `Duration` जाणूनबुजून `Display` इम्प्लिमेंट नसते कारण मानवी वाचनीयतेसाठी कालावधीचे स्वरूपित करण्याचे विविध मार्ग आहेत.
/// `Duration` व्हॅल्यूची संपूर्ण सुस्पष्टता दर्शविणारी एक `Debug` प्रोप्लिकेशन प्रदान करते.
///
/// एक्स 100 एक्स आउटपुट मायक्रोसेकँड्ससाठी नॉन-एएससीआयआय एक्स01 एक्स प्रत्यय वापरते.
/// जर आपला प्रोग्राम आउटपुट अशा संदर्भात दिसू शकेल जो पूर्ण युनिकोड अनुकूलतेवर विसंबून राहू शकत नसेल तर आपण स्वत: `Duration` ऑब्जेक्ट फॉर्मेट करू शकता किंवा असे करण्यासाठी crate वापरू शकता.
///
///
///
///
///
///
///
#[stable(feature = "duration", since = "1.3.0")]
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Default)]
pub struct Duration {
    secs: u64,
    nanos: u32, // नेहमी 0 <=नॅनो << नॅनॉस_पुस्तक
}

impl Duration {
    /// एक सेकंदाचा कालावधी.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::SECOND, Duration::from_secs(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const SECOND: Duration = Duration::from_secs(1);

    /// एक मिलिसेकंद कालावधी.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MILLISECOND, Duration::from_millis(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MILLISECOND: Duration = Duration::from_millis(1);

    /// एका मायक्रोसेकंदचा कालावधी.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MICROSECOND, Duration::from_micros(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MICROSECOND: Duration = Duration::from_micros(1);

    /// एका नॅनोसेकंदचा कालावधी.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::NANOSECOND, Duration::from_nanos(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const NANOSECOND: Duration = Duration::from_nanos(1);

    /// शून्य वेळेचा कालावधी.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// let duration = Duration::ZERO;
    /// assert!(duration.is_zero());
    /// assert_eq!(duration.as_nanos(), 0);
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    pub const ZERO: Duration = Duration::from_nanos(0);

    /// जास्तीत जास्त कालावधी.
    ///
    /// हे अंदाजे 584,942,417,355 वर्षांच्या कालावधीइतके आहे.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MAX, Duration::new(u64::MAX, 1_000_000_000 - 1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MAX: Duration = Duration::new(u64::MAX, NANOS_PER_SEC - 1);

    /// संपूर्ण सेकंद आणि अतिरिक्त नॅनोसेकंदांच्या निर्दिष्ट संख्येमधून एक नवीन `Duration` तयार करते.
    ///
    /// जर नॅनोसेकंदची संख्या 1 अब्जपेक्षा जास्त असेल (एका सेकंदात नॅनोसेकंदांची संख्या), तर ती प्रदान केलेल्या सेकंदांमध्ये पुढे जाईल.
    ///
    ///
    /// # Panics
    ///
    /// नॅनोसेकंड्समधून वाहून नेलेले सेकंद काउंटर ओव्हरफ्लो झाल्यास हा कन्स्ट्रक्टर झेडस्पॅनिक 0 झेड करेल.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let five_seconds = Duration::new(5, 0);
    /// ```
    ///
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn new(secs: u64, nanos: u32) -> Duration {
        let secs = match secs.checked_add((nanos / NANOS_PER_SEC) as u64) {
            Some(secs) => secs,
            None => panic!("overflow in Duration::new"),
        };
        let nanos = nanos % NANOS_PER_SEC;
        Duration { secs, nanos }
    }

    /// निर्दिष्ट सेकंदात संपूर्ण सेकंदांमधून नवीन `Duration` तयार करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_secs(5);
    ///
    /// assert_eq!(5, duration.as_secs());
    /// assert_eq!(0, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_secs(secs: u64) -> Duration {
        Duration { secs, nanos: 0 }
    }

    /// मिलिसेकंदांच्या निर्दिष्ट संख्येमधून एक नवीन `Duration` तयार करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(2569);
    ///
    /// assert_eq!(2, duration.as_secs());
    /// assert_eq!(569_000_000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_millis(millis: u64) -> Duration {
        Duration {
            secs: millis / MILLIS_PER_SEC,
            nanos: ((millis % MILLIS_PER_SEC) as u32) * NANOS_PER_MILLI,
        }
    }

    /// निर्दिष्ट केलेल्या मायक्रोसेकँड्समधून एक नवीन एक्स00 एक्स तयार करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_000_002);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(2000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_from_micros", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_micros(micros: u64) -> Duration {
        Duration {
            secs: micros / MICROS_PER_SEC,
            nanos: ((micros % MICROS_PER_SEC) as u32) * NANOS_PER_MICRO,
        }
    }

    /// नॅनोसेकंदांच्या निर्दिष्ट संख्येमधून एक नवीन `Duration` तयार करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_nanos(1_000_000_123);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(123, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_nanos(nanos: u64) -> Duration {
        Duration {
            secs: nanos / (NANOS_PER_SEC as u64),
            nanos: (nanos % (NANOS_PER_SEC as u64)) as u32,
        }
    }

    /// हे `Duration` वेळ नसल्यास सत्य मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert!(Duration::ZERO.is_zero());
    /// assert!(Duration::new(0, 0).is_zero());
    /// assert!(Duration::from_nanos(0).is_zero());
    /// assert!(Duration::from_secs(0).is_zero());
    ///
    /// assert!(!Duration::new(1, 1).is_zero());
    /// assert!(!Duration::from_nanos(1).is_zero());
    /// assert!(!Duration::from_secs(1).is_zero());
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    #[inline]
    pub const fn is_zero(&self) -> bool {
        self.secs == 0 && self.nanos == 0
    }

    /// या `Duration` द्वारे समाविष्ट केलेल्या _whole_ सेकंदांची संख्या मिळवते.
    ///
    /// परत केलेल्या मूल्यामध्ये भागातील भागांश (nanosecond) भाग समाविष्ट नाही, जो एक्स 100 एक्स वापरून प्राप्त केला जाऊ शकतो.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_secs(), 5);
    /// ```
    ///
    /// `Duration` द्वारे दर्शविलेले एकूण सेकंदांची संख्या निश्चित करण्यासाठी, [`subsec_nanos`] सह संयोजितपणे `as_secs` वापरा:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    ///
    /// assert_eq!(5.730023852,
    ///            duration.as_secs() as f64
    ///            + duration.subsec_nanos() as f64 * 1e-9);
    /// ```
    ///
    /// [`subsec_nanos`]: Duration::subsec_nanos
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn as_secs(&self) -> u64 {
        self.secs
    }

    /// संपूर्ण X मिलिसेकंदांमध्ये या `Duration` चा भागांश मिळवते.
    ///
    /// ही पद्धत **नाही** मिलिसेकेन्डद्वारे प्रतिनिधित्व करते त्या कालावधीची लांबी परत करत नाही.
    /// परत केलेली संख्या नेहमीच सेकंदाचा अंशात्मक भाग दर्शवते (म्हणजेच ती एक हजाराहून कमी आहे).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5432);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_millis(), 432);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_millis(&self) -> u32 {
        self.nanos / NANOS_PER_MILLI
    }

    /// संपूर्ण मायक्रोसेकंदांमध्ये या `Duration` चा अंशात्मक भाग मिळवते.
    ///
    /// मायक्रोसेकँड्सद्वारे प्रतिनिधित्व करताना ही पद्धत **नाही** कालावधीची लांबी परत करत नाही.
    /// परत केलेली संख्या नेहमीच सेकंदाचा अपूर्णांक दर्शवते (म्हणजेच तो दहा लाखापेक्षा कमी आहे).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_234_567);
    /// assert_eq!(duration.as_secs(), 1);
    /// assert_eq!(duration.subsec_micros(), 234_567);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_micros(&self) -> u32 {
        self.nanos / NANOS_PER_MICRO
    }

    /// या `Duration` चा अंशात्मक भाग, नॅनोसेकंदमध्ये मिळवते.
    ///
    /// नॅनोसेकँड्सद्वारे प्रतिनिधित्व करताना ही पद्धत **नाही** कालावधीची लांबी परत करत नाही.
    /// परत केलेली संख्या नेहमीच सेकंदाचा अंशात्मक भाग दर्शवते (म्हणजेच ती एक अब्जापेक्षा कमी आहे).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5010);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_nanos(), 10_000_000);
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn subsec_nanos(&self) -> u32 {
        self.nanos
    }

    /// या `Duration` द्वारे अंतर्भूत एकूण मिलिसेकंदांची एकूण संख्या मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_millis(), 5730);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_millis(&self) -> u128 {
        self.secs as u128 * MILLIS_PER_SEC as u128 + (self.nanos / NANOS_PER_MILLI) as u128
    }

    /// या `Duration` द्वारे समाविष्ट असलेल्या संपूर्ण मायक्रोसेकंदांची एकूण संख्या मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_micros(), 5730023);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_micros(&self) -> u128 {
        self.secs as u128 * MICROS_PER_SEC as u128 + (self.nanos / NANOS_PER_MICRO) as u128
    }

    /// या `Duration` द्वारे अंतर्भूत एकूण नॅनो सेकंदांची संख्या मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_nanos(), 5730023852);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_nanos(&self) -> u128 {
        self.secs as u128 * NANOS_PER_SEC as u128 + self.nanos as u128
    }

    /// `Duration` जोड तपासले.
    /// ओव्हरफ्लो झाल्यास `self + other` चे परिक्षण, X01 एक्स परत करणे.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).checked_add(Duration::new(0, 1)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(1, 0).checked_add(Duration::new(u64::MAX, 0)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_add(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_add(rhs.secs) {
            let mut nanos = self.nanos + rhs.nanos;
            if nanos >= NANOS_PER_SEC {
                nanos -= NANOS_PER_SEC;
                if let Some(new_secs) = secs.checked_add(1) {
                    secs = new_secs;
                } else {
                    return None;
                }
            }
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// भरणा `Duration` व्यतिरिक्त.
    /// ओव्हरफ्लो झाल्यास `self + other` चे परिक्षण, X01 एक्स परत करणे.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).saturating_add(Duration::new(0, 1)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(1, 0).saturating_add(Duration::new(u64::MAX, 0)), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_add(self, rhs: Duration) -> Duration {
        match self.checked_add(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// `Duration` वजाबाकी तपासली.
    /// परिणाम नकारात्मक असल्यास किंवा ओव्हरफ्लो झाल्यास X01 एक्स परत करत `self - other` ची गणना करते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).checked_sub(Duration::new(0, 0)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(0, 0).checked_sub(Duration::new(0, 1)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_sub(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_sub(rhs.secs) {
            let nanos = if self.nanos >= rhs.nanos {
                self.nanos - rhs.nanos
            } else {
                if let Some(sub_secs) = secs.checked_sub(1) {
                    secs = sub_secs;
                    self.nanos + NANOS_PER_SEC - rhs.nanos
                } else {
                    return None;
                }
            };
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// भरणा `Duration` वजाबाकी.
    /// परिणाम नकारात्मक असल्यास किंवा ओव्हरफ्लो झाल्यास X01 एक्स परत करत `self - other` ची गणना करते.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).saturating_sub(Duration::new(0, 0)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(0, 0).saturating_sub(Duration::new(0, 1)), Duration::ZERO);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_sub(self, rhs: Duration) -> Duration {
        match self.checked_sub(rhs) {
            Some(res) => res,
            None => Duration::ZERO,
        }
    }

    /// `Duration` गुणाकार तपासला.
    /// ओव्हरफ्लो झाल्यास `self * other` चे परिक्षण, X01 एक्स परत करणे.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).checked_mul(2), Some(Duration::new(1, 2)));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).checked_mul(2), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_mul(self, rhs: u32) -> Option<Duration> {
        // नॅनोसेकंदला u64 म्हणून गुणाकार करा, कारण ते त्या मार्गाने ओव्हरफ्लो होऊ शकत नाही.
        let total_nanos = self.nanos as u64 * rhs as u64;
        let extra_secs = total_nanos / (NANOS_PER_SEC as u64);
        let nanos = (total_nanos % (NANOS_PER_SEC as u64)) as u32;
        if let Some(s) = self.secs.checked_mul(rhs as u64) {
            if let Some(secs) = s.checked_add(extra_secs) {
                debug_assert!(nanos < NANOS_PER_SEC);
                return Some(Duration { secs, nanos });
            }
        }
        None
    }

    /// सॅचरेटिंग एक्स 100 एक्स गुणाकार.
    /// ओव्हरफ्लो झाल्यास `self * other` चे परिक्षण, X01 एक्स परत करणे.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).saturating_mul(2), Duration::new(1, 2));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).saturating_mul(2), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_mul(self, rhs: u32) -> Duration {
        match self.checked_mul(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// `Duration` विभाग तपासला.
    /// `self / other` ची गणना करते, `other == 0` असल्यास [`None`] परत करते.
    ///
    /// # Examples
    ///
    /// मूलभूत वापर:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(2, 0).checked_div(2), Some(Duration::new(1, 0)));
    /// assert_eq!(Duration::new(1, 0).checked_div(2), Some(Duration::new(0, 500_000_000)));
    /// assert_eq!(Duration::new(2, 0).checked_div(0), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_div(self, rhs: u32) -> Option<Duration> {
        if rhs != 0 {
            let secs = self.secs / (rhs as u64);
            let carry = self.secs - secs * (rhs as u64);
            let extra_nanos = carry * (NANOS_PER_SEC as u64) / (rhs as u64);
            let nanos = self.nanos / rhs + (extra_nanos as u32);
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// या `Duration` द्वारे समाविष्ट केलेल्या सेकंदांची संख्या `f64` म्हणून मिळवते.
    /// परत केलेल्या मूल्यामध्ये कालावधीचा अपूर्णांक (nanosecond) भाग समाविष्ट असतो.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f64(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f64(&self) -> f64 {
        (self.secs as f64) + (self.nanos as f64) / (NANOS_PER_SEC as f64)
    }

    /// या `Duration` द्वारे समाविष्ट केलेल्या सेकंदांची संख्या `f32` म्हणून मिळवते.
    /// परत केलेल्या मूल्यामध्ये कालावधीचा अपूर्णांक (nanosecond) भाग समाविष्ट असतो.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f32(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f32(&self) -> f32 {
        (self.secs as f32) + (self.nanos as f32) / (NANOS_PER_SEC as f32)
    }

    /// `f64` म्हणून दर्शविलेल्या निर्दिष्ट सेकंदांमधून एक नवीन एक्स01 एक्स तयार करते.
    ///
    /// # Panics
    /// हे कन्स्ट्रक्टर `secs` मर्यादित, नकारात्मक किंवा ओव्हरफ्लो `Duration` नसल्यास झेडपेनिक 0 झेड करेल.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f64(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f64(secs: f64) -> Duration {
        const MAX_NANOS_F64: f64 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f64;
        let nanos = secs * (NANOS_PER_SEC as f64);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F64 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// `f32` म्हणून दर्शविलेल्या निर्दिष्ट सेकंदांमधून एक नवीन एक्स01 एक्स तयार करते.
    ///
    /// # Panics
    /// हे कन्स्ट्रक्टर `secs` मर्यादित, नकारात्मक किंवा ओव्हरफ्लो `Duration` नसल्यास झेडपेनिक 0 झेड करेल.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f32(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f32(secs: f32) -> Duration {
        const MAX_NANOS_F32: f32 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f32;
        let nanos = secs * (NANOS_PER_SEC as f32);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F32 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// `f64` ने गुणाकार X01 एक्स.
    /// # Panics
    /// परिणाम मर्यादित, नकारात्मक किंवा ओव्हरफ्लो `Duration` नसल्यास ही पद्धत panic करेल.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.mul_f64(3.14), Duration::new(8, 478_000_000));
    /// assert_eq!(dur.mul_f64(3.14e5), Duration::new(847_800, 0));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(rhs * self.as_secs_f64())
    }

    /// `f32` ने गुणाकार X01 एक्स.
    /// # Panics
    /// परिणाम मर्यादित, नकारात्मक किंवा ओव्हरफ्लो `Duration` नसल्यास ही पद्धत panic करेल.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // लक्षात घ्या की राउंडिंग त्रुटींमुळे निकाल 8.478 आणि 847800.0 पेक्षा थोडा वेगळा आहे
    /////
    /// assert_eq!(dur.mul_f32(3.14), Duration::new(8, 478_000_640));
    /// assert_eq!(dur.mul_f32(3.14e5), Duration::new(847799, 969_120_256));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(rhs * self.as_secs_f32())
    }

    /// `Duration` `f64` ने भाग घ्या.
    /// # Panics
    /// परिणाम मर्यादित, नकारात्मक किंवा ओव्हरफ्लो `Duration` नसल्यास ही पद्धत panic करेल.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.div_f64(3.14), Duration::new(0, 859_872_611));
    /// // लक्षात घ्या की काटछाट वापरली जाते, गोलाकार नाही
    /// assert_eq!(dur.div_f64(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(self.as_secs_f64() / rhs)
    }

    /// `Duration` `f32` ने भाग घ्या.
    /// # Panics
    /// परिणाम मर्यादित, नकारात्मक किंवा ओव्हरफ्लो `Duration` नसल्यास ही पद्धत panic करेल.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // लक्षात घ्या की राउंडिंग त्रुटींमुळे निकाल 0.859_872_611 पेक्षा थोडा वेगळा आहे
    /////
    /// assert_eq!(dur.div_f32(3.14), Duration::new(0, 859_872_576));
    /// // लक्षात घ्या की काटछाट वापरली जाते, गोलाकार नाही
    /// assert_eq!(dur.div_f32(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(self.as_secs_f32() / rhs)
    }

    /// `Duration` `Duration` ने भाग घ्या आणि `f64` परत करा.
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f64(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f64(self, rhs: Duration) -> f64 {
        self.as_secs_f64() / rhs.as_secs_f64()
    }

    /// `Duration` `Duration` ने भाग घ्या आणि `f32` परत करा.
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f32(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f32(self, rhs: Duration) -> f32 {
        self.as_secs_f32() / rhs.as_secs_f32()
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Add for Duration {
    type Output = Duration;

    fn add(self, rhs: Duration) -> Duration {
        self.checked_add(rhs).expect("overflow when adding durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl AddAssign for Duration {
    fn add_assign(&mut self, rhs: Duration) {
        *self = *self + rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Sub for Duration {
    type Output = Duration;

    fn sub(self, rhs: Duration) -> Duration {
        self.checked_sub(rhs).expect("overflow when subtracting durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl SubAssign for Duration {
    fn sub_assign(&mut self, rhs: Duration) {
        *self = *self - rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Mul<u32> for Duration {
    type Output = Duration;

    fn mul(self, rhs: u32) -> Duration {
        self.checked_mul(rhs).expect("overflow when multiplying duration by scalar")
    }
}

#[stable(feature = "symmetric_u32_duration_mul", since = "1.31.0")]
impl Mul<Duration> for u32 {
    type Output = Duration;

    fn mul(self, rhs: Duration) -> Duration {
        rhs * self
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl MulAssign<u32> for Duration {
    fn mul_assign(&mut self, rhs: u32) {
        *self = *self * rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Div<u32> for Duration {
    type Output = Duration;

    fn div(self, rhs: u32) -> Duration {
        self.checked_div(rhs).expect("divide by zero error when dividing duration by scalar")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl DivAssign<u32> for Duration {
    fn div_assign(&mut self, rhs: u32) {
        *self = *self / rhs;
    }
}

macro_rules! sum_durations {
    ($iter:expr) => {{
        let mut total_secs: u64 = 0;
        let mut total_nanos: u64 = 0;

        for entry in $iter {
            total_secs =
                total_secs.checked_add(entry.secs).expect("overflow in iter::sum over durations");
            total_nanos = match total_nanos.checked_add(entry.nanos as u64) {
                Some(n) => n,
                None => {
                    total_secs = total_secs
                        .checked_add(total_nanos / NANOS_PER_SEC as u64)
                        .expect("overflow in iter::sum over durations");
                    (total_nanos % NANOS_PER_SEC as u64) + entry.nanos as u64
                }
            };
        }
        total_secs = total_secs
            .checked_add(total_nanos / NANOS_PER_SEC as u64)
            .expect("overflow in iter::sum over durations");
        total_nanos = total_nanos % NANOS_PER_SEC as u64;
        Duration { secs: total_secs, nanos: total_nanos as u32 }
    }};
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl Sum for Duration {
    fn sum<I: Iterator<Item = Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl<'a> Sum<&'a Duration> for Duration {
    fn sum<I: Iterator<Item = &'a Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_debug_impl", since = "1.27.0")]
impl fmt::Debug for Duration {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        /// दशांश चिन्हात फ्लोटिंग पॉईंट नंबरचे स्वरूपित करते.
        ///
        /// संख्या `integer_part` आणि अपूर्णांक म्हणून दिली आहे.
        /// अपूर्णांक भागाचे मूल्य `fractional_part / divisor` आहे.
        /// तर `integer_part` =3, `fractional_part` =12 आणि `divisor` =100 हे `3.012` संख्या दर्शवते.
        /// ट्रेलिंग झिरो वगळले आहेत.
        ///
        /// `divisor` 100_000_000 पेक्षा जास्त नसावे.
        /// हे 10 ची शक्ती देखील असले पाहिजे, बाकी सर्व काही अर्थ प्राप्त होत नाही.
        /// `fractional_part` हे `10 * divisor` पेक्षा कमी असावे!
        fn fmt_decimal(
            f: &mut fmt::Formatter<'_>,
            mut integer_part: u64,
            mut fractional_part: u32,
            mut divisor: u32,
        ) -> fmt::Result {
            // अपूर्णांक भागामध्ये तात्पुरते बफरमध्ये एन्कोड करा.
            // बफरला केवळ 9 घटक ठेवण्याची आवश्यकता आहे, कारण `fractional_part` 10 ^ 9 पेक्षा लहान असणे आवश्यक आहे.
            //
            // खालील कोड सुलभ करण्यासाठी बफर '0' अंकांसह प्रीफिल आहे.
            let mut buf = [b'0'; 9];

            // पुढील स्थान या स्थानावर लिहिलेले आहे
            let mut pos = 0;

            // शून्य-नसलेले अंक बाकी असताना आम्ही बफरमध्ये अंक लिहितो आणि आम्ही अद्याप पुरेसे अंक लिहिले नाहीत.
            //
            while fractional_part > 0 && pos < f.precision().unwrap_or(9) {
                // बफरमध्ये नवीन अंक लिहा
                buf[pos] = b'0' + (fractional_part / divisor) as u8;

                fractional_part %= divisor;
                divisor /= 10;
                pos += 1;
            }

            // जर अचूक <9 निर्दिष्ट केले असेल तर, तेथे काही शून्य-अंक बाकी असू शकतात जे बफरमध्ये लिहिलेले नाहीत.
            // अशावेळी आम्हाला सामान्य फ्लोटिंग पॉईंट नंबर छापण्याच्या शब्दांकाशी जुळण्यासाठी गोल करणे आवश्यक आहे.
            // तथापि, आम्हाला केवळ गोलाकार काम करतानाच कार्य करणे आवश्यक आहे.
            // उर्वरितचा पहिला अंक>=5 असल्यास हे घडते.
            //
            //
            if fractional_part > 0 && fractional_part >= divisor * 5 {
                // बफरमध्ये असलेली संख्या पूर्ण करा.
                // आम्ही बफरच्या मागील बाजूस जातो आणि कॅरीचा मागोवा ठेवतो.
                let mut rev_pos = pos;
                let mut carry = true;
                while carry && rev_pos > 0 {
                    rev_pos -= 1;

                    // जर बफरमधील अंक '9' नसल्यास, आम्हाला त्यास वाढविणे आवश्यक आहे आणि तेव्हाच थांबू शकतो (कारण आपल्याकडे आणखी एक कॅरी नाही).
                    // अन्यथा आम्ही ते '0' (overflow) वर सेट केले आणि सुरू ठेवतो.
                    //
                    //
                    if buf[rev_pos] < b'9' {
                        buf[rev_pos] += 1;
                        carry = false;
                    } else {
                        buf[rev_pos] = b'0';
                    }
                }

                // आपल्याकडे अद्याप कॅरी बिट सेट असल्यास, याचा अर्थ असा की आम्ही संपूर्ण बफर '0' वर सेट केला आहे आणि पूर्णांक भाग वाढविणे आवश्यक आहे.
                //
                //
                if carry {
                    integer_part += 1;
                }
            }

            // बफरचा शेवट निश्चित करा: जर अचूकता सेट केली गेली असेल तर आम्ही फक्त बफरपासून बरेच अंक वापरतो (9 पर्यंत कॅप्ड केलेले)
            // हे सेट केलेले नसल्यास, आम्ही फक्त शेवटचे शून्य नसलेले सर्व अंक वापरतो.
            //
            let end = f.precision().map(|p| crate::cmp::min(p, 9)).unwrap_or(pos);

            // जर आपण एकल विभक्त अंक सोडला नाही आणि अचूकता शून्य नसलेल्या मूल्यावर सेट केली नसेल तर आम्ही दशांश बिंदू मुद्रित करीत नाही.
            //
            if end == 0 {
                write!(f, "{}", integer_part)
            } else {
                // सुरक्षा: आम्ही फक्त बफरमध्ये एएससीआयआय अंक लिहित आहोत आणि ते होते
                // '0's' ने आरंभ केला आहे, म्हणून त्यात वैध UTF8 आहे.
                let s = unsafe { crate::str::from_utf8_unchecked(&buf[..end]) };

                // जर वापरकर्त्याने अचूकता> 9 ची विनंती केली असेल तर आम्ही शेवटी 0 चे पॅड करतो.
                let w = f.precision().unwrap_or(pos);
                write!(f, "{}.{:0<width$}", integer_part, s, width = w)
            }
        }

        // विनंती केल्यास अग्रगण्य '+' चिन्ह मुद्रित करा
        if f.sign_plus() {
            write!(f, "+")?;
        }

        if self.secs > 0 {
            fmt_decimal(f, self.secs, self.nanos, NANOS_PER_SEC / 10)?;
            f.write_str("s")
        } else if self.nanos >= NANOS_PER_MILLI {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MILLI) as u64,
                self.nanos % NANOS_PER_MILLI,
                NANOS_PER_MILLI / 10,
            )?;
            f.write_str("ms")
        } else if self.nanos >= NANOS_PER_MICRO {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MICRO) as u64,
                self.nanos % NANOS_PER_MICRO,
                NANOS_PER_MICRO / 10,
            )?;
            f.write_str("µs")
        } else {
            fmt_decimal(f, self.nanos as u64, 0, 1)?;
            f.write_str("ns")
        }
    }
}