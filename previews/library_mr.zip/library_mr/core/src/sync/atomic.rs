//! अणू प्रकार
//!
//! अणू प्रकार थ्रेड्स दरम्यान आदिम सामायिक-मेमरी संप्रेषण प्रदान करतात आणि हे इतर समवर्ती प्रकारांचे बिल्डिंग ब्लॉक आहेत.
//!
//! हे मॉड्यूल [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`] इत्यादींसह आदिम प्रकारांच्या निवडक संख्यांच्या अणू आवृत्ती परिभाषित करते.
//! अणू प्रकार ऑपरेशन्स सादर करतात जे योग्यरित्या वापरले जातात तेव्हा थ्रेड्स दरम्यान अद्यतने समक्रमित करतात.
//!
//! प्रत्येक पद्धतीमध्ये एक [`Ordering`] घेते जी त्या ऑपरेशनसाठी मेमरी अडथळ्याची शक्ती दर्शवते.हे ऑर्डर [C++20 atomic orderings][1] सारखेच आहेत.अधिक माहितीसाठी [nomicon][2] पहा.
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! अणू चलने थ्रेड्स दरम्यान सामायिक करणे सुरक्षित आहे (ते एक्स0१ एक्स लागू करतात) परंतु ते स्वत: झेडआरस्ट0झेडच्या एक्स00 एक्स सामायिकरण आणि त्यांचे अनुसरण करण्याची यंत्रणा देत नाहीत.
//!
//! अणू चल सामायिक करण्याचा सर्वात सामान्य मार्ग म्हणजे तो एक्स 100 एक्स मध्ये ठेवणे (एक अणु-संदर्भ-गणना-सामायिक शेजार).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! अणू प्रकार स्थिर स्टेरिएबल्समध्ये संग्रहित केले जाऊ शकतात, एक्स00 एक्स सारख्या स्थिर आरंभिकांचा वापर करून आरंभ केले जाऊ शकतात.आण्विक जागतिक स्तितीकरणासाठी अणूची स्थिती नेहमी वापरली जाते.
//!
//! # Portability
//!
//! या मॉड्यूलमधील सर्व अणू प्रकार उपलब्ध असल्यास [lock-free] असण्याची हमी आहे.याचा अर्थ ते आंतरिकरित्या जागतिक म्युटेक्स घेत नाहीत.अणू प्रकार आणि ऑपरेशन्स प्रतीक्षा रहित असल्याची हमी दिलेली नाही.
//! याचा अर्थ असा की `fetch_or` सारखी ऑपरेशन्स तुलना-स्वॅप लूपसह लागू केली जाऊ शकतात.
//!
//! अणु ऑपरेशन्स मोठ्या-आकाराच्या अणूशास्त्रांसह निर्देश स्तरावर अंमलात आणल्या जाऊ शकतात.उदाहरणार्थ काही प्लॅटफॉर्म `AtomicI8` अंमलात आणण्यासाठी 4-बाइट अणु सूचना वापरतात.
//! लक्षात घ्या की या अनुकरणचा कोडच्या शुद्धतेवर प्रभाव नसावा, हे लक्षात घेण्यासारखे काहीतरी आहे.
//!
//! या मॉड्यूलमधील अणू प्रकार सर्व प्लॅटफॉर्मवर उपलब्ध नसू शकतात.येथे अणू प्रकार सर्व उपलब्ध आहेत, परंतु सामान्यत: विद्यमान यावर अवलंबून राहू शकतात.काही उल्लेखनीय अपवाद हे आहेत:
//!
//! * PowerPC आणि 32-बिट पॉइंटरसह MIPS प्लॅटफॉर्मवर `AtomicU64` किंवा `AtomicI64` प्रकार नाहीत.
//! * ARM `armv5te` सारखे प्लॅटफॉर्म जे Linux साठी नसतात केवळ `load` आणि `store` ऑपरेशन्स प्रदान करतात आणि `swap`, `fetch_add` इत्यादी तुलना आणि स्वॅप (CAS) ऑपरेशन्सचे समर्थन देत नाहीत.
//! याव्यतिरिक्त Linux वर, या सीएएस ऑपरेशन्स [operating system support] मार्गे लागू केल्या गेल्या आहेत ज्या कार्यक्षमतेच्या दंडसह येऊ शकतात.
//! * ARM `thumbv6m` सह लक्ष्य केवळ `load` आणि `store` ऑपरेशन्स प्रदान करतात आणि तुलना आणि स्वॅप (CAS) ऑपरेशन्सना समर्थन देत नाहीत जसे की `swap`, `fetch_add` इ.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! लक्षात घ्या की झेडफ्यूचर 0 झेड प्लॅटफॉर्मवर कदाचित जोडले जाऊ शकते ज्यात काही अणु ऑपरेशन्सना समर्थन नाही.जास्तीत जास्त पोर्टेबल कोड कोणता अणू प्रकार वापरला जातो याबद्दल सावधगिरी बाळगायला आवडेल.
//! `AtomicUsize` आणि एक्स00 एक्स सामान्यतः सर्वात पोर्टेबल असतात, परंतु तरीही ते सर्वत्र उपलब्ध नाहीत.
//! संदर्भासाठी, `std` लायब्ररीला पॉईंटर-आकाराचे अणुशास्त्र आवश्यक आहे, जरी X01 एक्स नाही.
//!
//! अणुशास्त्रातील कोडमध्ये सशर्तपणे संकलित करण्यासाठी सध्या आपल्याला `#[cfg(target_arch)]` प्रामुख्याने वापरण्याची आवश्यकता आहे.एक अस्थिर `#[cfg(target_has_atomic)]` देखील आहे जे future मध्ये स्थिर असू शकते.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! एक साधा स्पिनलॉक:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // लॉक सोडण्यासाठी अन्य थ्रेडची प्रतीक्षा करा
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! थेट थ्रेडची जागतिक गणना ठेवा:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// एक बुलियन प्रकार जो सुरक्षितपणे धाग्यांमध्ये सामायिक केला जाऊ शकतो.
///
/// या प्रकारचे एक्स-एक्स एक्ससारखेच मेमरी प्रतिनिधित्व आहे.
///
/// **टीप**: हा प्रकार केवळ अशा प्लॅटफॉर्मवर उपलब्ध आहे जो एक्सबॉक्सच्या अणू भार आणि स्टोअरना समर्थन देतात.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// `false` वर प्रारंभ केलेला एक `AtomicBool` तयार करते.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// अ‍ॅटॉमिकबूलसाठी पाठवा स्पष्टपणे लागू केला आहे.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// एक कच्चा सूचक प्रकार जो थ्रेड्स दरम्यान सुरक्षितपणे सामायिक केला जाऊ शकतो.
///
/// या प्रकारचे एक्स-एक्स एक्ससारखेच मेमरी प्रतिनिधित्व आहे.
///
/// **टीप**: हा प्रकार केवळ अशा प्लॅटफॉर्मवर उपलब्ध आहे जो अणु भार आणि पॉइंटर्सच्या स्टोअरना समर्थन देतो.
/// त्याचा आकार लक्ष्य पॉईंटरच्या आकारावर अवलंबून असतो.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// शून्य `AtomicPtr<T>` तयार करते.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// अणू स्मृती क्रम
///
/// मेमरी ऑर्डरिंग अणू ऑपरेशन्स मेमरी सिंक्रोनाइझ करण्याचा मार्ग निर्दिष्ट करते.
/// त्याच्या सर्वात दुर्बल [`Ordering::Relaxed`] मध्ये, ऑपरेशनद्वारे थेट स्पर्श केलेली मेमरी सिंक्रोनाइझ केली जाते.
/// दुसरीकडे, [`Ordering::SeqCst`] ऑपरेशन्सची स्टोअर-लोड जोड्या इतर थ्रेड्समध्ये अशा प्रकारच्या ऑपरेशन्सची एकूण ऑर्डर संरक्षित करतेवेळी इतर मेमरी सिंक्रोनाइझ करते.
///
///
/// झेडआरस्ट0 झेडच्या मेमरी ऑर्डरिंग एक्स 100 एक्स आहेत.
///
/// अधिक माहितीसाठी [nomicon] पहा.
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// ऑर्डरची कोणतीही मर्यादा नाही, केवळ अणु परिचालन.
    ///
    /// C ++ 20 मधील [`memory_order_relaxed`] शी संबंधित.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// जेव्हा स्टोअरसह एकत्र केले जाते, तेव्हा मागील सर्व ऑपरेशन्स [`Acquire`] (किंवा अधिक मजबूत) ऑर्डरसह या मूल्याच्या कोणत्याही लोडपूर्वी ऑर्डर केली जातात.
    ///
    /// विशेषतः, मागील सर्व लेख सर्व थ्रेड्ससाठी दृश्यमान बनतात जे या मूल्याचे [`Acquire`] (किंवा अधिक मजबूत) लोड करतात.
    ///
    /// लक्षात घ्या की लोडिंग आणि स्टोअर्स एकत्र करणार्‍या ऑपरेशनसाठी हे ऑर्डरिंग वापरल्याने [`Relaxed`] लोड ऑपरेशन होते!
    ///
    /// हे ऑर्डर केवळ स्टोअर सुरू करू शकणार्‍या ऑपरेशनसाठी लागू आहे.
    ///
    /// C ++ 20 मधील [`memory_order_release`] शी संबंधित.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// जेव्हा लोडसह जोडलेले, [`Release`] (किंवा अधिक मजबूत) ऑर्डरसह स्टोअर ऑपरेशनद्वारे भारित मूल्य लिहिले गेले असेल तर त्यानंतरच्या सर्व ऑपरेशन्स त्या स्टोअरनंतर ऑर्डर होतात.
    /// विशेषतः, त्यानंतरचे सर्व भार स्टोअरच्या आधी लिहिलेले डेटा पाहतील.
    ///
    /// लक्षात घ्या की लोडिंग आणि स्टोअर्स एकत्र करणार्‍या ऑपरेशनसाठी हे ऑर्डरिंग वापरल्याने एक्स 100 एक्स स्टोअर ऑपरेशन होते!
    ///
    /// हे ऑर्डरिंग केवळ कार्य करू शकते जे लोड करू शकतात.
    ///
    /// C ++ 20 मधील [`memory_order_acquire`] शी संबंधित.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// दोन्ही [`Acquire`] आणि [`Release`] चे प्रभाव एकत्र आहेतः
    /// भारांसाठी ते [`Acquire`] ऑर्डरिंग वापरते.स्टोअरमध्ये ते एक्स 0 एक्स एक्स ऑर्डरचा वापर करते.
    ///
    /// लक्षात घ्या की `compare_and_swap` च्या बाबतीत, ऑपरेशन कोणत्याही स्टोअरची अंमलबजावणी न करता संपेल आणि म्हणूनच त्यास फक्त X01 एक्स ऑर्डर देण्यात आले आहे.
    ///
    /// तथापि, `AcqRel` कधीही X01 एक्स प्रवेश करणार नाही.
    ///
    /// हे ऑर्डरिंग केवळ त्या ऑपरेशन्ससाठी लागू आहे जे लोड आणि स्टोअर दोन्ही एकत्र करतात.
    ///
    /// C ++ 20 मधील [`memory_order_acq_rel`] शी संबंधित.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// [`अक्वाययर]/[`रिलीझ]]/[` अ‍ॅकॅक्रेल](अतिरिक्त स्टोअर ऑर्डरनुसार अनुक्रमे लोड, स्टोअर आणि लोड-स्टोअर ऑपरेशन्ससाठी) की सर्व थ्रेड्स सर्व क्रमानुसार सातत्य ऑपरेशन्स एकाच क्रमाने पाहतात. .
    ///
    ///
    /// C ++ 20 मधील [`memory_order_seq_cst`] शी संबंधित.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// एक [`AtomicBool`] `false` वर प्रारंभ केला.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// नवीन `AtomicBool` तयार करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// अंतर्निहित [`bool`] चा एक बदलणारा संदर्भ मिळवते.
    ///
    /// हे सुरक्षित आहे कारण परिवर्तनीय संदर्भ हमी देतो की इतर कोणतेही धागे एकाच वेळी अणु डेटामध्ये प्रवेश करत नाहीत.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // सुरक्षा: बदलण्यायोग्य संदर्भ अद्वितीय मालकीची हमी देते.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// `&mut bool` वर अणु प्रवेश मिळवा.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // सुरक्षा: बदलण्यायोग्य संदर्भ अद्वितीय मालकीची हमी देते, आणि
        // `bool` आणि `Self` दोन्हीचे संरेखन 1 आहे.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// अणू घेते आणि समाविष्ट केलेले मूल्य परत करते.
    ///
    /// हे सुरक्षित आहे कारण मूल्याद्वारे एक्स 100 एक्स उत्तीर्ण होणे याची हमी देते की इतर कोणतेही थ्रेड एकाचवेळी अणु डेटामध्ये प्रवेश करत नाहीत.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// bool वरून मूल्य लोड करते.
    ///
    /// `load` एक [`Ordering`] वितर्क घेते जे या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करते.
    /// [`SeqCst`], [`Acquire`] आणि [`Relaxed`] संभाव्य मूल्ये आहेत.
    ///
    /// # Panics
    ///
    /// `order` [`Release`] किंवा [`AcqRel`] असल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // सुरक्षितता: कोणत्याही डेटा रेसेसला अणु अंतर्ज्ञान आणि कच्चा प्रतिबंधित केले जाते
        // मध्ये दिलेला पॉईंटर वैध आहे कारण आम्हाला तो एका संदर्भामधून आला आहे.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// bool मध्ये मूल्य संचयित करते.
    ///
    /// `store` एक [`Ordering`] वितर्क घेते जे या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करते.
    /// [`SeqCst`], [`Release`] आणि [`Relaxed`] संभाव्य मूल्ये आहेत.
    ///
    /// # Panics
    ///
    /// `order` [`Acquire`] किंवा [`AcqRel`] असल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // सुरक्षितता: कोणत्याही डेटा रेसेसला अणु अंतर्ज्ञान आणि कच्चा प्रतिबंधित केले जाते
        // मध्ये दिलेला पॉईंटर वैध आहे कारण आम्हाला तो एका संदर्भामधून आला आहे.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// मागील मूल्य परत करून bool मध्ये मूल्य संचयित करते.
    ///
    /// `swap` एक [`Ordering`] वितर्क घेते जे या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करते.सर्व ऑर्डर करण्याच्या पद्धती शक्य आहेत.
    /// लक्षात घ्या की [`Acquire`] वापरणे स्टोअरला या ऑपरेशनचा भाग बनवते X01 एक्स, आणि एक्स 0 एक्सचा वापर केल्यास लोड भाग एक्स 100 एक्स बनतो.
    ///
    ///
    /// **Note:** ही पद्धत केवळ अशा प्लॅटफॉर्मवर उपलब्ध आहे जी `u8` वर अणु परिचालन समर्थित करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // सुरक्षा: डेटा रेस अणू अंतर्भागाद्वारे प्रतिबंधित आहे.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// जर वर्तमान मूल्य `current` मूल्यासारखेच असेल तर ते [`bool`] मध्ये मूल्य संचयित करते.
    ///
    /// परतावा मूल्य नेहमीच आधीचे मूल्य असते.जर ते `current` च्या बरोबरीचे असेल तर मूल्य अद्यतनित केले गेले.
    ///
    /// `compare_and_swap` एक [`Ordering`] वितर्क देखील घेते जे या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करते.
    /// लक्षात घ्या की [`AcqRel`] वापरताना देखील ऑपरेशन अयशस्वी होऊ शकते आणि म्हणूनच ते फक्त एक्स 0 एक्स एक्स लोड करतात, परंतु एक्स0 2 एक्स शब्दार्थ नाही.
    /// [`Acquire`] वापरणे स्टोअरला या ऑपरेशनचा भाग बनविते तर असे झाल्यास [`Relaxed`], आणि [`Release`] वापरल्याने लोड भाग एक्स 100 एक्स बनते.
    ///
    /// **Note:** ही पद्धत केवळ अशा प्लॅटफॉर्मवर उपलब्ध आहे जी `u8` वर अणु परिचालन समर्थित करते.
    ///
    /// # `compare_exchange` आणि `compare_exchange_weak` वर स्थलांतर करीत आहे
    ///
    /// `compare_and_swap` मेमरी ऑर्डरिंगसाठी खालील मॅपिंगसह `compare_exchange` च्या समतुल्य आहे:
    ///
    /// मूळ |यश |अपयश
    /// -------- | ------- | -------
    /// निवांत |निवांत |रिलॅक्सड एक्क्वायर |अधिग्रहण |रीलिझ मिळवा |रीलिझ |रिलॅक्स्ड अ‍ॅकॅक्रेल |अ‍ॅकॅक्रेल |सिक्कास्ट मिळवा |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` तुलना यशस्वी झाल्यावरही उत्तेजित होणे अयशस्वी आहे, जे तुलना व स्वॅप लूपमध्ये वापरले जाते तेव्हा कंपाईलर अधिक चांगले असेंब्ली कोड निर्माण करू देते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// जर वर्तमान मूल्य `current` मूल्यासारखेच असेल तर ते [`bool`] मध्ये मूल्य संचयित करते.
    ///
    /// रिटर्न व्हॅल्यू हा एक परिणाम आहे जो दर्शवितो की नवीन मूल्य लिहिले गेले आहे आणि त्यामध्ये मागील मूल्य आहे.
    /// यशस्वीरित्या हे मूल्य `current` च्या समान असल्याची हमी दिलेली आहे.
    ///
    /// `compare_exchange` या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करण्यासाठी दोन [`Ordering`] वितर्क घेतो.
    /// `success` `current` सह तुलना यशस्वी झाल्यास घडणार्‍या वाचन-सुधारित-लेखन ऑपरेशनसाठी आवश्यक ऑर्डरचे वर्णन करते.
    /// `failure` तुलना अयशस्वी झाल्यास उद्भवणार्‍या लोड ऑपरेशनसाठी आवश्यक ऑर्डरिंगचे वर्णन करते.
    /// एक्स ऑर्डर ऑर्डर म्हणून [`Acquire`] वापरणे स्टोअरला या ऑपरेशनचा भाग बनवते X01 एक्स, आणि एक्स 0 एक्स एक्सचा वापर केल्याने यशस्वी लोड एक्स 100 एक्स बनते.
    ///
    /// ऑर्डर करण्यात अयशस्वी होणे केवळ [`SeqCst`], [`Acquire`] किंवा [`Relaxed`] असू शकते आणि यश ऑर्डरपेक्षा समतुल्य किंवा कमकुवत असणे आवश्यक आहे.
    ///
    /// **Note:** ही पद्धत केवळ अशा प्लॅटफॉर्मवर उपलब्ध आहे जी `u8` वर अणु परिचालन समर्थित करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // सुरक्षा: डेटा रेस अणू अंतर्भागाद्वारे प्रतिबंधित आहे.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// जर वर्तमान मूल्य `current` मूल्यासारखेच असेल तर ते [`bool`] मध्ये मूल्य संचयित करते.
    ///
    /// [`AtomicBool::compare_exchange`] च्या विपरीत, तुलना यशस्वी झाल्यावरही या कार्यास उत्तेजन देण्यास अनुमती आहे, ज्यामुळे काही प्लॅटफॉर्मवर अधिक कार्यक्षम कोड येऊ शकेल.
    ///
    /// रिटर्न व्हॅल्यू हा एक परिणाम आहे जो दर्शवितो की नवीन मूल्य लिहिले गेले आहे आणि त्यामध्ये मागील मूल्य आहे.
    ///
    /// `compare_exchange_weak` या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करण्यासाठी दोन [`Ordering`] वितर्क घेतो.
    /// `success` `current` सह तुलना यशस्वी झाल्यास घडणार्‍या वाचन-सुधारित-लेखन ऑपरेशनसाठी आवश्यक ऑर्डरचे वर्णन करते.
    /// `failure` तुलना अयशस्वी झाल्यास उद्भवणार्‍या लोड ऑपरेशनसाठी आवश्यक ऑर्डरिंगचे वर्णन करते.
    /// एक्स ऑर्डर ऑर्डर म्हणून [`Acquire`] वापरणे स्टोअरला या ऑपरेशनचा भाग बनवते X01 एक्स, आणि एक्स 0 एक्स एक्सचा वापर केल्याने यशस्वी लोड एक्स 100 एक्स बनते.
    /// ऑर्डर करण्यात अयशस्वी होणे केवळ [`SeqCst`], [`Acquire`] किंवा [`Relaxed`] असू शकते आणि यश ऑर्डरपेक्षा समतुल्य किंवा कमकुवत असणे आवश्यक आहे.
    ///
    /// **Note:** ही पद्धत केवळ अशा प्लॅटफॉर्मवर उपलब्ध आहे जी `u8` वर अणु परिचालन समर्थित करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // सुरक्षा: डेटा रेस अणू अंतर्भागाद्वारे प्रतिबंधित आहे.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// बुलियन मूल्यासह लॉजिकल एक्स 100 एक्स.
    ///
    /// वर्तमान मूल्य आणि वितर्क `val` वर तार्किक "and" ऑपरेशन करते आणि परिणामी नवीन मूल्य सेट करते.
    ///
    /// मागील मूल्य मिळवते.
    ///
    /// `fetch_and` एक [`Ordering`] वितर्क घेते जे या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करते.सर्व ऑर्डर करण्याच्या पद्धती शक्य आहेत.
    /// लक्षात घ्या की [`Acquire`] वापरणे स्टोअरला या ऑपरेशनचा भाग बनवते X01 एक्स, आणि एक्स 0 एक्सचा वापर केल्यास लोड भाग एक्स 100 एक्स बनतो.
    ///
    ///
    /// **Note:** ही पद्धत केवळ अशा प्लॅटफॉर्मवर उपलब्ध आहे जी `u8` वर अणु परिचालन समर्थित करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // सुरक्षा: डेटा रेस अणू अंतर्भागाद्वारे प्रतिबंधित आहे.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// बुलियन मूल्यासह लॉजिकल एक्स 100 एक्स.
    ///
    /// वर्तमान मूल्य आणि वितर्क `val` वर तार्किक "nand" ऑपरेशन करते आणि परिणामी नवीन मूल्य सेट करते.
    ///
    /// मागील मूल्य मिळवते.
    ///
    /// `fetch_nand` एक [`Ordering`] वितर्क घेते जे या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करते.सर्व ऑर्डर करण्याच्या पद्धती शक्य आहेत.
    /// लक्षात घ्या की [`Acquire`] वापरणे स्टोअरला या ऑपरेशनचा भाग बनवते X01 एक्स, आणि एक्स 0 एक्सचा वापर केल्यास लोड भाग एक्स 100 एक्स बनतो.
    ///
    ///
    /// **Note:** ही पद्धत केवळ अशा प्लॅटफॉर्मवर उपलब्ध आहे जी `u8` वर अणु परिचालन समर्थित करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // आम्ही येथे अणु_नांद वापरू शकत नाही कारण त्याचा परिणाम झेडबूल0 झेड अवैध मूल्यासह होऊ शकतो.
        // हे घडते कारण अणू ऑपरेशन आंतरिकरित्या 8-बीट पूर्णांकाद्वारे केले जाते, ज्यामुळे वरील 7 बिट्स सेट केले जातील.
        //
        // त्याऐवजी आम्ही फक्त fetch_xor किंवा स्वॅप वापरतो.
        if val {
            // ! (एक्स आणि ट्रू)== !x आम्ही bool उलटा करणे आवश्यक आहे.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (एक्स आणि खोटे)==खरे आम्ही झेडबूल0 झेड सत्य वर सेट केले पाहिजे.
            //
            self.swap(true, order)
        }
    }

    /// बुलियन मूल्यासह लॉजिकल एक्स 100 एक्स.
    ///
    /// वर्तमान मूल्य आणि वितर्क `val` वर तार्किक "or" ऑपरेशन करते आणि परिणामी नवीन मूल्य सेट करते.
    ///
    /// मागील मूल्य मिळवते.
    ///
    /// `fetch_or` एक [`Ordering`] वितर्क घेते जे या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करते.सर्व ऑर्डर करण्याच्या पद्धती शक्य आहेत.
    /// लक्षात घ्या की [`Acquire`] वापरणे स्टोअरला या ऑपरेशनचा भाग बनवते X01 एक्स, आणि एक्स 0 एक्सचा वापर केल्यास लोड भाग एक्स 100 एक्स बनतो.
    ///
    ///
    /// **Note:** ही पद्धत केवळ अशा प्लॅटफॉर्मवर उपलब्ध आहे जी `u8` वर अणु परिचालन समर्थित करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // सुरक्षा: डेटा रेस अणू अंतर्भागाद्वारे प्रतिबंधित आहे.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// बुलियन मूल्यासह लॉजिकल एक्स 100 एक्स.
    ///
    /// वर्तमान मूल्य आणि वितर्क `val` वर तार्किक "xor" ऑपरेशन करते आणि परिणामी नवीन मूल्य सेट करते.
    ///
    /// मागील मूल्य मिळवते.
    ///
    /// `fetch_xor` एक [`Ordering`] वितर्क घेते जे या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करते.सर्व ऑर्डर करण्याच्या पद्धती शक्य आहेत.
    /// लक्षात घ्या की [`Acquire`] वापरणे स्टोअरला या ऑपरेशनचा भाग बनवते X01 एक्स, आणि एक्स 0 एक्सचा वापर केल्यास लोड भाग एक्स 100 एक्स बनतो.
    ///
    ///
    /// **Note:** ही पद्धत केवळ अशा प्लॅटफॉर्मवर उपलब्ध आहे जी `u8` वर अणु परिचालन समर्थित करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // सुरक्षा: डेटा रेस अणू अंतर्भागाद्वारे प्रतिबंधित आहे.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// अंतर्निहित [`bool`] वर परिवर्तनीय पॉईंटर मिळवते.
    ///
    /// परिणामी पूर्णांक वर अणू-वाचन वाचणे आणि लिहिणे ही डेटा रेस असू शकते.
    /// ही पद्धत मुख्यत: एफएफआयसाठी उपयुक्त आहे, जेथे कार्य स्वाक्षरी `&AtomicBool` ऐवजी `*mut bool` वापरू शकतात.
    ///
    /// या अणूच्या सामायिक संदर्भातून `*mut` पॉईंटर परत करणे सुरक्षित आहे कारण अणू प्रकार आतील उत्परिवर्तनासह कार्य करतात.
    /// अणूच्या सर्व बदलांनी सामायिक केलेल्या संदर्भाद्वारे मूल्य बदलते आणि जोपर्यंत ते अणु परिचालन वापरतात तोपर्यंत सुरक्षितपणे करू शकतात.
    /// परत आलेल्या कच्च्या पॉइंटरच्या कोणत्याही वापरास `unsafe` ब्लॉक आवश्यक आहे आणि तरीही तसाच निर्बंध कायम ठेवावा लागेल: त्यावरील ऑपरेशन अणू असणे आवश्यक आहे.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// मूल्य आणते आणि त्यात असे कार्य लागू करते जे पर्यायी नवीन मूल्य मिळवते.कार्याने `Some(_)` परत केले तर `Ok(previous_value)` चे `Result` मिळवते, अन्यथा `Err(previous_value)`.
    ///
    /// Note: या दरम्यान फंक्शनने एकाधिक वेळा कॉल केल्यास इतर थ्रेडमधून व्हॅल्यू बदलली गेली आहे, जोपर्यंत फंक्शन X00 एक्स परत करेल, परंतु फंक्शन फक्त एकदाच स्टोरेज व्हॅल्यूवर लागू होईल.
    ///
    ///
    /// `fetch_update` या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करण्यासाठी दोन [`Ordering`] वितर्क घेतो.
    /// प्रथम ऑपरेशन शेवटी यशस्वी होते तेव्हा आवश्यक ऑर्डरिंगचे वर्णन करते तर दुसरा लोडसाठी आवश्यक ऑर्डरिंगचे वर्णन करते.
    /// हे अनुक्रमे [`AtomicBool::compare_exchange`] च्या यश आणि अपयशाच्या ऑर्डरशी संबंधित आहेत.
    ///
    /// एक्स ऑर्डर ऑर्डर म्हणून [`Acquire`] वापरणे स्टोअरला या ऑपरेशनचा भाग बनवते X01 एक्स, आणि एक्स 0 एक्सचा वापर केल्यास अंतिम यशस्वी लोड एक्स 100 एक्स बनते.
    /// (failed) लोड ऑर्डरिंग केवळ [`SeqCst`], [`Acquire`] किंवा [`Relaxed`] असू शकते आणि यश ऑर्डरपेक्षा समतुल्य किंवा कमकुवत असणे आवश्यक आहे.
    ///
    /// **Note:** ही पद्धत केवळ अशा प्लॅटफॉर्मवर उपलब्ध आहे जी `u8` वर अणु परिचालन समर्थित करते.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// नवीन `AtomicPtr` तयार करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// अंतर्निहित पॉईंटरला परिवर्तनीय संदर्भ मिळवते.
    ///
    /// हे सुरक्षित आहे कारण परिवर्तनीय संदर्भ हमी देतो की इतर कोणतेही धागे एकाच वेळी अणु डेटामध्ये प्रवेश करत नाहीत.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// पॉईंटरवर अणु प्रवेश मिळवा.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - परिवर्तनीय संदर्भ अद्वितीय मालकीची हमी देतो.
        //  - उपरोक्त सत्यापित केल्यानुसार, rust द्वारे समर्थित सर्व प्लॅटफॉर्मवर `*mut T` आणि `Self` चे संरेखन समान आहे.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// अणू घेते आणि समाविष्ट केलेले मूल्य परत करते.
    ///
    /// हे सुरक्षित आहे कारण मूल्याद्वारे एक्स 100 एक्स उत्तीर्ण होणे याची हमी देते की इतर कोणतेही थ्रेड एकाचवेळी अणु डेटामध्ये प्रवेश करत नाहीत.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// पॉईंटर वरून मूल्य लोड करते.
    ///
    /// `load` एक [`Ordering`] वितर्क घेते जे या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करते.
    /// [`SeqCst`], [`Acquire`] आणि [`Relaxed`] संभाव्य मूल्ये आहेत.
    ///
    /// # Panics
    ///
    /// `order` [`Release`] किंवा [`AcqRel`] असल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // सुरक्षा: डेटा रेस अणू अंतर्भागाद्वारे प्रतिबंधित आहे.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// पॉईंटर मध्ये मूल्य साठवते.
    ///
    /// `store` एक [`Ordering`] वितर्क घेते जे या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करते.
    /// [`SeqCst`], [`Release`] आणि [`Relaxed`] संभाव्य मूल्ये आहेत.
    ///
    /// # Panics
    ///
    /// `order` [`Acquire`] किंवा [`AcqRel`] असल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // सुरक्षा: डेटा रेस अणू अंतर्भागाद्वारे प्रतिबंधित आहे.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// मागील मूल्य परत करून पॉइंटरमध्ये मूल्य साठवते.
    ///
    /// `swap` एक [`Ordering`] वितर्क घेते जे या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करते.सर्व ऑर्डर करण्याच्या पद्धती शक्य आहेत.
    /// लक्षात घ्या की [`Acquire`] वापरणे स्टोअरला या ऑपरेशनचा भाग बनवते X01 एक्स, आणि एक्स 0 एक्सचा वापर केल्यास लोड भाग एक्स 100 एक्स बनतो.
    ///
    ///
    /// **Note:** ही पद्धत केवळ प्लॅटफॉर्मवर उपलब्ध आहे जी पॉइंटर्सवरील अणु ऑपरेशनचे समर्थन करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // सुरक्षा: डेटा रेस अणू अंतर्भागाद्वारे प्रतिबंधित आहे.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// जर विद्यमान मूल्य `current` मूल्यासारखेच असेल तर ते पॉइंटरमध्ये मूल्य साठवते.
    ///
    /// परतावा मूल्य नेहमीच आधीचे मूल्य असते.जर ते `current` च्या बरोबरीचे असेल तर मूल्य अद्यतनित केले गेले.
    ///
    /// `compare_and_swap` एक [`Ordering`] वितर्क देखील घेते जे या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करते.
    /// लक्षात घ्या की [`AcqRel`] वापरताना देखील ऑपरेशन अयशस्वी होऊ शकते आणि म्हणूनच ते फक्त एक्स 0 एक्स एक्स लोड करतात, परंतु एक्स0 2 एक्स शब्दार्थ नाही.
    /// [`Acquire`] वापरणे स्टोअरला या ऑपरेशनचा भाग बनविते तर असे झाल्यास [`Relaxed`], आणि [`Release`] वापरल्याने लोड भाग एक्स 100 एक्स बनते.
    ///
    /// **Note:** ही पद्धत केवळ प्लॅटफॉर्मवर उपलब्ध आहे जी पॉइंटर्सवरील अणु ऑपरेशनचे समर्थन करते.
    ///
    /// # `compare_exchange` आणि `compare_exchange_weak` वर स्थलांतर करीत आहे
    ///
    /// `compare_and_swap` मेमरी ऑर्डरिंगसाठी खालील मॅपिंगसह `compare_exchange` च्या समतुल्य आहे:
    ///
    /// मूळ |यश |अपयश
    /// -------- | ------- | -------
    /// निवांत |निवांत |रिलॅक्सड एक्क्वायर |अधिग्रहण |रीलिझ मिळवा |रीलिझ |रिलॅक्स्ड अ‍ॅकॅक्रेल |अ‍ॅकॅक्रेल |सिक्कास्ट मिळवा |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` तुलना यशस्वी झाल्यावरही उत्तेजित होणे अयशस्वी आहे, जे तुलना व स्वॅप लूपमध्ये वापरले जाते तेव्हा कंपाईलर अधिक चांगले असेंब्ली कोड निर्माण करू देते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// जर विद्यमान मूल्य `current` मूल्यासारखेच असेल तर ते पॉइंटरमध्ये मूल्य साठवते.
    ///
    /// रिटर्न व्हॅल्यू हा एक परिणाम आहे जो दर्शवितो की नवीन मूल्य लिहिले गेले आहे आणि त्यामध्ये मागील मूल्य आहे.
    /// यशस्वीरित्या हे मूल्य `current` च्या समान असल्याची हमी दिलेली आहे.
    ///
    /// `compare_exchange` या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करण्यासाठी दोन [`Ordering`] वितर्क घेतो.
    /// `success` `current` सह तुलना यशस्वी झाल्यास घडणार्‍या वाचन-सुधारित-लेखन ऑपरेशनसाठी आवश्यक ऑर्डरचे वर्णन करते.
    /// `failure` तुलना अयशस्वी झाल्यास उद्भवणार्‍या लोड ऑपरेशनसाठी आवश्यक ऑर्डरिंगचे वर्णन करते.
    /// एक्स ऑर्डर ऑर्डर म्हणून [`Acquire`] वापरणे स्टोअरला या ऑपरेशनचा भाग बनवते X01 एक्स, आणि एक्स 0 एक्स एक्सचा वापर केल्याने यशस्वी लोड एक्स 100 एक्स बनते.
    ///
    /// ऑर्डर करण्यात अयशस्वी होणे केवळ [`SeqCst`], [`Acquire`] किंवा [`Relaxed`] असू शकते आणि यश ऑर्डरपेक्षा समतुल्य किंवा कमकुवत असणे आवश्यक आहे.
    ///
    /// **Note:** ही पद्धत केवळ प्लॅटफॉर्मवर उपलब्ध आहे जी पॉइंटर्सवरील अणु ऑपरेशनचे समर्थन करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // सुरक्षा: डेटा रेस अणू अंतर्भागाद्वारे प्रतिबंधित आहे.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// जर विद्यमान मूल्य `current` मूल्यासारखेच असेल तर ते पॉइंटरमध्ये मूल्य साठवते.
    ///
    /// [`AtomicPtr::compare_exchange`] च्या विपरीत, तुलना यशस्वी झाल्यावरही या कार्यास उत्तेजन देण्यास अनुमती आहे, ज्यामुळे काही प्लॅटफॉर्मवर अधिक कार्यक्षम कोड येऊ शकेल.
    ///
    /// रिटर्न व्हॅल्यू हा एक परिणाम आहे जो दर्शवितो की नवीन मूल्य लिहिले गेले आहे आणि त्यामध्ये मागील मूल्य आहे.
    ///
    /// `compare_exchange_weak` या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करण्यासाठी दोन [`Ordering`] वितर्क घेतो.
    /// `success` `current` सह तुलना यशस्वी झाल्यास घडणार्‍या वाचन-सुधारित-लेखन ऑपरेशनसाठी आवश्यक ऑर्डरचे वर्णन करते.
    /// `failure` तुलना अयशस्वी झाल्यास उद्भवणार्‍या लोड ऑपरेशनसाठी आवश्यक ऑर्डरिंगचे वर्णन करते.
    /// एक्स ऑर्डर ऑर्डर म्हणून [`Acquire`] वापरणे स्टोअरला या ऑपरेशनचा भाग बनवते X01 एक्स, आणि एक्स 0 एक्स एक्सचा वापर केल्याने यशस्वी लोड एक्स 100 एक्स बनते.
    /// ऑर्डर करण्यात अयशस्वी होणे केवळ [`SeqCst`], [`Acquire`] किंवा [`Relaxed`] असू शकते आणि यश ऑर्डरपेक्षा समतुल्य किंवा कमकुवत असणे आवश्यक आहे.
    ///
    /// **Note:** ही पद्धत केवळ प्लॅटफॉर्मवर उपलब्ध आहे जी पॉइंटर्सवरील अणु ऑपरेशनचे समर्थन करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // सुरक्षा: ही आंतरिक असुरक्षित आहे कारण ते कच्च्या पॉइंटरवर कार्य करते
        // परंतु आम्हाला हे निश्चितपणे माहित आहे की पॉईंटर वैध आहे (आमच्याकडे तो संदर्भानुसार आमच्यास नुकताच प्राप्त झाला आहे) आणि अणु संचालनच आम्हाला `UnsafeCell` सामग्री सुरक्षितपणे बदलू देतो.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// मूल्य आणते आणि त्यात असे कार्य लागू करते जे पर्यायी नवीन मूल्य मिळवते.कार्याने `Some(_)` परत केले तर `Ok(previous_value)` चे `Result` मिळवते, अन्यथा `Err(previous_value)`.
    ///
    /// Note: या दरम्यान फंक्शनने एकाधिक वेळा कॉल केल्यास इतर थ्रेडमधून व्हॅल्यू बदलली गेली आहे, जोपर्यंत फंक्शन X00 एक्स परत करेल, परंतु फंक्शन फक्त एकदाच स्टोरेज व्हॅल्यूवर लागू होईल.
    ///
    ///
    /// `fetch_update` या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करण्यासाठी दोन [`Ordering`] वितर्क घेतो.
    /// प्रथम ऑपरेशन शेवटी यशस्वी होते तेव्हा आवश्यक ऑर्डरिंगचे वर्णन करते तर दुसरा लोडसाठी आवश्यक ऑर्डरिंगचे वर्णन करते.
    /// हे अनुक्रमे [`AtomicPtr::compare_exchange`] च्या यश आणि अपयशाच्या ऑर्डरशी संबंधित आहेत.
    ///
    /// एक्स ऑर्डर ऑर्डर म्हणून [`Acquire`] वापरणे स्टोअरला या ऑपरेशनचा भाग बनवते X01 एक्स, आणि एक्स 0 एक्सचा वापर केल्यास अंतिम यशस्वी लोड एक्स 100 एक्स बनते.
    /// (failed) लोड ऑर्डरिंग केवळ [`SeqCst`], [`Acquire`] किंवा [`Relaxed`] असू शकते आणि यश ऑर्डरपेक्षा समतुल्य किंवा कमकुवत असणे आवश्यक आहे.
    ///
    /// **Note:** ही पद्धत केवळ प्लॅटफॉर्मवर उपलब्ध आहे जी पॉइंटर्सवरील अणु ऑपरेशनचे समर्थन करते.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// `bool` ला `AtomicBool` मध्ये रूपांतरित करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // हा मॅक्रो काही आर्किटेक्चर्सवर न वापरलेला असतो.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// एक पूर्णांक प्रकार जो थ्रेड दरम्यान सुरक्षितपणे सामायिक केला जाऊ शकतो.
        ///
        /// या प्रकारात अंतर्निहित पूर्णांक प्रकारांप्रमाणेच मेमरी प्रतिनिधित्व आहे, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// अणू प्रकार आणि अणु प्रकारांमधील फरक तसेच या प्रकारच्या पोर्टेबिलिटीबद्दल माहितीबद्दल, कृपया [module-level documentation] पहा.
        ///
        ///
        /// **Note:** हा प्रकार केवळ अशा प्लॅटफॉर्मवर उपलब्ध आहे जे [omic च्या अणू भार आणि स्टोअरचे समर्थन करतात
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// अणू पूर्णांक `0` ला प्रारंभ केला.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // पाठवा स्पष्टपणे अंमलात आला आहे.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// नवीन अणु पूर्णांक तयार करते.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// अंतर्निहित पूर्णांकासाठी परिवर्तनीय संदर्भ मिळवते.
            ///
            /// हे सुरक्षित आहे कारण परिवर्तनीय संदर्भ हमी देतो की इतर कोणतेही धागे एकाच वेळी अणु डेटामध्ये प्रवेश करत नाहीत.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// चला म्युट थोड_इंट=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - परिवर्तनीय संदर्भ अद्वितीय मालकीची हमी देतो.
                //  - `$int_type` आणि `Self` चे संरेखन समान आहे, $cfg_align द्वारे वचन दिले आहे आणि वरील सत्यापित केले आहे.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// अणू घेते आणि समाविष्ट केलेले मूल्य परत करते.
            ///
            /// हे सुरक्षित आहे कारण मूल्याद्वारे एक्स 100 एक्स उत्तीर्ण होणे याची हमी देते की इतर कोणतेही थ्रेड एकाचवेळी अणु डेटामध्ये प्रवेश करत नाहीत.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// अणू पूर्णांकाचे मूल्य लोड करते.
            ///
            /// `load` एक [`Ordering`] वितर्क घेते जे या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करते.
            /// [`SeqCst`], [`Acquire`] आणि [`Relaxed`] संभाव्य मूल्ये आहेत.
            ///
            /// # Panics
            ///
            /// `order` [`Release`] किंवा [`AcqRel`] असल्यास Panics.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // सुरक्षा: डेटा रेस अणू अंतर्भागाद्वारे प्रतिबंधित आहे.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// अणू पूर्णांक मध्ये मूल्य साठवते.
            ///
            /// `store` एक [`Ordering`] वितर्क घेते जे या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करते.
            ///  [`SeqCst`], [`Release`] आणि [`Relaxed`] संभाव्य मूल्ये आहेत.
            ///
            /// # Panics
            ///
            /// `order` [`Acquire`] किंवा [`AcqRel`] असल्यास Panics.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // सुरक्षा: डेटा रेस अणू अंतर्भागाद्वारे प्रतिबंधित आहे.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// मागील मूल्य परत करून अणू पूर्णांकात मूल्य साठवते.
            ///
            /// `swap` एक [`Ordering`] वितर्क घेते जे या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करते.सर्व ऑर्डर करण्याच्या पद्धती शक्य आहेत.
            /// लक्षात घ्या की [`Acquire`] वापरणे स्टोअरला या ऑपरेशनचा भाग बनवते X01 एक्स, आणि एक्स 0 एक्सचा वापर केल्यास लोड भाग एक्स 100 एक्स बनतो.
            ///
            ///
            /// **टीप**: ही पद्धत केवळ अशा प्लॅटफॉर्मवर उपलब्ध आहे जी चालू असलेल्या अणु ऑपरेशन्सचे समर्थन करतात
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // सुरक्षा: डेटा रेस अणू अंतर्भागाद्वारे प्रतिबंधित आहे.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// जर विद्यमान मूल्य `current` मूल्यासारखेच असेल तर अणू पूर्णांकात मूल्य संचयित करते.
            ///
            /// परतावा मूल्य नेहमीच आधीचे मूल्य असते.जर ते `current` च्या बरोबरीचे असेल तर मूल्य अद्यतनित केले गेले.
            ///
            /// `compare_and_swap` एक [`Ordering`] वितर्क देखील घेते जे या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करते.
            /// लक्षात घ्या की [`AcqRel`] वापरताना देखील ऑपरेशन अयशस्वी होऊ शकते आणि म्हणूनच ते फक्त एक्स 0 एक्स एक्स लोड करतात, परंतु एक्स0 2 एक्स शब्दार्थ नाही.
            ///
            /// [`Acquire`] वापरणे स्टोअरला या ऑपरेशनचा भाग बनविते तर असे झाल्यास [`Relaxed`], आणि [`Release`] वापरल्याने लोड भाग एक्स 100 एक्स बनते.
            ///
            /// **टीप**: ही पद्धत केवळ अशा प्लॅटफॉर्मवर उपलब्ध आहे जी चालू असलेल्या अणु ऑपरेशन्सचे समर्थन करतात
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # `compare_exchange` आणि `compare_exchange_weak` वर स्थलांतर करीत आहे
            ///
            /// `compare_and_swap` मेमरी ऑर्डरिंगसाठी खालील मॅपिंगसह `compare_exchange` च्या समतुल्य आहे:
            ///
            /// मूळ |यश |अपयश
            /// -------- | ------- | -------
            /// निवांत |निवांत |रिलॅक्सड एक्क्वायर |अधिग्रहण |रीलिझ मिळवा |रीलिझ |रिलॅक्स्ड अ‍ॅकॅक्रेल |अ‍ॅकॅक्रेल |सिक्कास्ट मिळवा |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` तुलना यशस्वी झाल्यावरही उत्तेजित होणे अयशस्वी आहे, जे तुलना व स्वॅप लूपमध्ये वापरले जाते तेव्हा कंपाईलर अधिक चांगले असेंब्ली कोड निर्माण करू देते.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// जर विद्यमान मूल्य `current` मूल्यासारखेच असेल तर अणू पूर्णांकात मूल्य संचयित करते.
            ///
            /// रिटर्न व्हॅल्यू हा एक परिणाम आहे जो दर्शवितो की नवीन मूल्य लिहिले गेले आहे आणि त्यामध्ये मागील मूल्य आहे.
            /// यशस्वीरित्या हे मूल्य `current` च्या समान असल्याची हमी दिलेली आहे.
            ///
            /// `compare_exchange` या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करण्यासाठी दोन [`Ordering`] वितर्क घेतो.
            /// `success` `current` सह तुलना यशस्वी झाल्यास घडणार्‍या वाचन-सुधारित-लेखन ऑपरेशनसाठी आवश्यक ऑर्डरचे वर्णन करते.
            /// `failure` तुलना अयशस्वी झाल्यास उद्भवणार्‍या लोड ऑपरेशनसाठी आवश्यक ऑर्डरिंगचे वर्णन करते.
            /// एक्स ऑर्डर ऑर्डर म्हणून [`Acquire`] वापरणे स्टोअरला या ऑपरेशनचा भाग बनवते X01 एक्स, आणि एक्स 0 एक्स एक्सचा वापर केल्याने यशस्वी लोड एक्स 100 एक्स बनते.
            ///
            /// ऑर्डर करण्यात अयशस्वी होणे केवळ [`SeqCst`], [`Acquire`] किंवा [`Relaxed`] असू शकते आणि यश ऑर्डरपेक्षा समतुल्य किंवा कमकुवत असणे आवश्यक आहे.
            ///
            /// **टीप**: ही पद्धत केवळ अशा प्लॅटफॉर्मवर उपलब्ध आहे जी चालू असलेल्या अणु ऑपरेशन्सचे समर्थन करतात
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // सुरक्षा: डेटा रेस अणू अंतर्भागाद्वारे प्रतिबंधित आहे.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// जर विद्यमान मूल्य `current` मूल्यासारखेच असेल तर अणू पूर्णांकात मूल्य संचयित करते.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// तुलना यशस्वी झाल्यावरही या कार्यास उत्तेजन देण्यास अनुमती आहे, ज्यामुळे काही प्लॅटफॉर्मवर अधिक कार्यक्षम कोड लागू शकतो.
            /// रिटर्न व्हॅल्यू हा एक परिणाम आहे जो दर्शवितो की नवीन मूल्य लिहिले गेले आहे आणि त्यामध्ये मागील मूल्य आहे.
            ///
            /// `compare_exchange_weak` या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करण्यासाठी दोन [`Ordering`] वितर्क घेतो.
            /// `success` `current` सह तुलना यशस्वी झाल्यास घडणार्‍या वाचन-सुधारित-लेखन ऑपरेशनसाठी आवश्यक ऑर्डरचे वर्णन करते.
            /// `failure` तुलना अयशस्वी झाल्यास उद्भवणार्‍या लोड ऑपरेशनसाठी आवश्यक ऑर्डरिंगचे वर्णन करते.
            /// एक्स ऑर्डर ऑर्डर म्हणून [`Acquire`] वापरणे स्टोअरला या ऑपरेशनचा भाग बनवते X01 एक्स, आणि एक्स 0 एक्स एक्सचा वापर केल्याने यशस्वी लोड एक्स 100 एक्स बनते.
            ///
            /// ऑर्डर करण्यात अयशस्वी होणे केवळ [`SeqCst`], [`Acquire`] किंवा [`Relaxed`] असू शकते आणि यश ऑर्डरपेक्षा समतुल्य किंवा कमकुवत असणे आवश्यक आहे.
            ///
            /// **टीप**: ही पद्धत केवळ अशा प्लॅटफॉर्मवर उपलब्ध आहे जी चालू असलेल्या अणु ऑपरेशन्सचे समर्थन करतात
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// चला मट जुन्या= val.load(Ordering::Relaxed);
            /// पळवाट {नवीन द्या=जुने * 2;
            ///     val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, } सामना match
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // सुरक्षा: डेटा रेस अणू अंतर्भागाद्वारे प्रतिबंधित आहे.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// मागील मूल्य परत करून, वर्तमान मूल्यामध्ये भर घालते.
            ///
            /// हे ऑपरेशन ओव्हरफ्लो वर गुंडाळले जाते.
            ///
            /// `fetch_add` एक [`Ordering`] वितर्क घेते जे या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करते.सर्व ऑर्डर करण्याच्या पद्धती शक्य आहेत.
            /// लक्षात घ्या की [`Acquire`] वापरणे स्टोअरला या ऑपरेशनचा भाग बनवते X01 एक्स, आणि एक्स 0 एक्सचा वापर केल्यास लोड भाग एक्स 100 एक्स बनतो.
            ///
            ///
            /// **टीप**: ही पद्धत केवळ अशा प्लॅटफॉर्मवर उपलब्ध आहे जी चालू असलेल्या अणु ऑपरेशन्सचे समर्थन करतात
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // सुरक्षा: डेटा रेस अणू अंतर्भागाद्वारे प्रतिबंधित आहे.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// मागील मूल्य परत करून वर्तमान मूल्यापासून वजा करते.
            ///
            /// हे ऑपरेशन ओव्हरफ्लो वर गुंडाळले जाते.
            ///
            /// `fetch_sub` एक [`Ordering`] वितर्क घेते जे या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करते.सर्व ऑर्डर करण्याच्या पद्धती शक्य आहेत.
            /// लक्षात घ्या की [`Acquire`] वापरणे स्टोअरला या ऑपरेशनचा भाग बनवते X01 एक्स, आणि एक्स 0 एक्सचा वापर केल्यास लोड भाग एक्स 100 एक्स बनतो.
            ///
            ///
            /// **टीप**: ही पद्धत केवळ अशा प्लॅटफॉर्मवर उपलब्ध आहे जी चालू असलेल्या अणु ऑपरेशन्सचे समर्थन करतात
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // सुरक्षा: डेटा रेस अणू अंतर्भागाद्वारे प्रतिबंधित आहे.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// वर्तमान मूल्यासह बिटवाइझ X00 एक्स.
            ///
            /// वर्तमान मूल्य आणि वितर्क `val` वर थोडासा "and" ऑपरेशन करते आणि निकालावर नवीन मूल्य सेट करते.
            ///
            /// मागील मूल्य मिळवते.
            ///
            /// `fetch_and` एक [`Ordering`] वितर्क घेते जे या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करते.सर्व ऑर्डर करण्याच्या पद्धती शक्य आहेत.
            /// लक्षात घ्या की [`Acquire`] वापरणे स्टोअरला या ऑपरेशनचा भाग बनवते X01 एक्स, आणि एक्स 0 एक्सचा वापर केल्यास लोड भाग एक्स 100 एक्स बनतो.
            ///
            ///
            /// **टीप**: ही पद्धत केवळ अशा प्लॅटफॉर्मवर उपलब्ध आहे जी चालू असलेल्या अणु ऑपरेशन्सचे समर्थन करतात
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // सुरक्षा: डेटा रेस अणू अंतर्भागाद्वारे प्रतिबंधित आहे.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// वर्तमान मूल्यासह बिटवाइझ X00 एक्स.
            ///
            /// वर्तमान मूल्य आणि वितर्क `val` वर थोडासा "nand" ऑपरेशन करते आणि निकालावर नवीन मूल्य सेट करते.
            ///
            /// मागील मूल्य मिळवते.
            ///
            /// `fetch_nand` एक [`Ordering`] वितर्क घेते जे या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करते.सर्व ऑर्डर करण्याच्या पद्धती शक्य आहेत.
            /// लक्षात घ्या की [`Acquire`] वापरणे स्टोअरला या ऑपरेशनचा भाग बनवते X01 एक्स, आणि एक्स 0 एक्सचा वापर केल्यास लोड भाग एक्स 100 एक्स बनतो.
            ///
            ///
            /// **टीप**: ही पद्धत केवळ अशा प्लॅटफॉर्मवर उपलब्ध आहे जी चालू असलेल्या अणु ऑपरेशन्सचे समर्थन करतात
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // सुरक्षा: डेटा रेस अणू अंतर्भागाद्वारे प्रतिबंधित आहे.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// वर्तमान मूल्यासह बिटवाइझ X00 एक्स.
            ///
            /// वर्तमान मूल्य आणि वितर्क `val` वर थोडासा "or" ऑपरेशन करते आणि निकालावर नवीन मूल्य सेट करते.
            ///
            /// मागील मूल्य मिळवते.
            ///
            /// `fetch_or` एक [`Ordering`] वितर्क घेते जे या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करते.सर्व ऑर्डर करण्याच्या पद्धती शक्य आहेत.
            /// लक्षात घ्या की [`Acquire`] वापरणे स्टोअरला या ऑपरेशनचा भाग बनवते X01 एक्स, आणि एक्स 0 एक्सचा वापर केल्यास लोड भाग एक्स 100 एक्स बनतो.
            ///
            ///
            /// **टीप**: ही पद्धत केवळ अशा प्लॅटफॉर्मवर उपलब्ध आहे जी चालू असलेल्या अणु ऑपरेशन्सचे समर्थन करतात
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // सुरक्षा: डेटा रेस अणू अंतर्भागाद्वारे प्रतिबंधित आहे.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// वर्तमान मूल्यासह बिटवाइझ X00 एक्स.
            ///
            /// वर्तमान मूल्य आणि वितर्क `val` वर थोडासा "xor" ऑपरेशन करते आणि निकालावर नवीन मूल्य सेट करते.
            ///
            /// मागील मूल्य मिळवते.
            ///
            /// `fetch_xor` एक [`Ordering`] वितर्क घेते जे या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करते.सर्व ऑर्डर करण्याच्या पद्धती शक्य आहेत.
            /// लक्षात घ्या की [`Acquire`] वापरणे स्टोअरला या ऑपरेशनचा भाग बनवते X01 एक्स, आणि एक्स 0 एक्सचा वापर केल्यास लोड भाग एक्स 100 एक्स बनतो.
            ///
            ///
            /// **टीप**: ही पद्धत केवळ अशा प्लॅटफॉर्मवर उपलब्ध आहे जी चालू असलेल्या अणु ऑपरेशन्सचे समर्थन करतात
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // सुरक्षा: डेटा रेस अणू अंतर्भागाद्वारे प्रतिबंधित आहे.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// मूल्य आणते आणि त्यात असे कार्य लागू करते जे पर्यायी नवीन मूल्य मिळवते.कार्याने `Some(_)` परत केले तर `Ok(previous_value)` चे `Result` मिळवते, अन्यथा `Err(previous_value)`.
            ///
            /// Note: या दरम्यान फंक्शनने एकाधिक वेळा कॉल केल्यास इतर थ्रेडमधून व्हॅल्यू बदलली गेली आहे, जोपर्यंत फंक्शन X00 एक्स परत करेल, परंतु फंक्शन फक्त एकदाच स्टोरेज व्हॅल्यूवर लागू होईल.
            ///
            ///
            /// `fetch_update` या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करण्यासाठी दोन [`Ordering`] वितर्क घेतो.
            /// प्रथम ऑपरेशन शेवटी यशस्वी होते तेव्हा आवश्यक ऑर्डरिंगचे वर्णन करते तर दुसरा लोडसाठी आवश्यक ऑर्डरिंगचे वर्णन करते.च्या यश आणि अपयशाच्या ऑर्डरशी संबंधित
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// एक्स ऑर्डर ऑर्डर म्हणून [`Acquire`] वापरणे स्टोअरला या ऑपरेशनचा भाग बनवते X01 एक्स, आणि एक्स 0 एक्सचा वापर केल्यास अंतिम यशस्वी लोड एक्स 100 एक्स बनते.
            /// (failed) लोड ऑर्डरिंग केवळ [`SeqCst`], [`Acquire`] किंवा [`Relaxed`] असू शकते आणि यश ऑर्डरपेक्षा समतुल्य किंवा कमकुवत असणे आवश्यक आहे.
            ///
            /// **टीप**: ही पद्धत केवळ अशा प्लॅटफॉर्मवर उपलब्ध आहे जी चालू असलेल्या अणु ऑपरेशन्सचे समर्थन करतात
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (क्रमवारी लावणे: SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (क्रमवारी लावणे: SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// वर्तमान मूल्यासह जास्तीत जास्त.
            ///
            /// सध्याचे मूल्य आणि वितर्क `val` मिळविते आणि परिणामास नवीन मूल्य सेट करते.
            ///
            /// मागील मूल्य मिळवते.
            ///
            /// `fetch_max` एक [`Ordering`] वितर्क घेते जे या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करते.सर्व ऑर्डर करण्याच्या पद्धती शक्य आहेत.
            /// लक्षात घ्या की [`Acquire`] वापरणे स्टोअरला या ऑपरेशनचा भाग बनवते X01 एक्स, आणि एक्स 0 एक्सचा वापर केल्यास लोड भाग एक्स 100 एक्स बनतो.
            ///
            ///
            /// **टीप**: ही पद्धत केवळ अशा प्लॅटफॉर्मवर उपलब्ध आहे जी चालू असलेल्या अणु ऑपरेशन्सचे समर्थन करतात
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// द्या बार=42;
            /// कमाल_फू=foo.fetch_max (बार, Ordering::SeqCst).max(bar);
            /// ठामपणे सांगा! (कमाल_फू==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // सुरक्षा: डेटा रेस अणू अंतर्भागाद्वारे प्रतिबंधित आहे.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// वर्तमान मूल्यासह किमान.
            ///
            /// कमीतकमी वर्तमान मूल्य आणि वितर्क `val` शोधते आणि परिणामास नवीन मूल्य सेट करते.
            ///
            /// मागील मूल्य मिळवते.
            ///
            /// `fetch_min` एक [`Ordering`] वितर्क घेते जे या ऑपरेशनच्या मेमरी ऑर्डरिंगचे वर्णन करते.सर्व ऑर्डर करण्याच्या पद्धती शक्य आहेत.
            /// लक्षात घ्या की [`Acquire`] वापरणे स्टोअरला या ऑपरेशनचा भाग बनवते X01 एक्स, आणि एक्स 0 एक्सचा वापर केल्यास लोड भाग एक्स 100 एक्स बनतो.
            ///
            ///
            /// **टीप**: ही पद्धत केवळ अशा प्लॅटफॉर्मवर उपलब्ध आहे जी चालू असलेल्या अणु ऑपरेशन्सचे समर्थन करतात
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// द्या बार=12;
            /// min_foo=foo.fetch_min (बार, Ordering::SeqCst).min(bar);
            /// assert_eq! (मिनिट_फू, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // सुरक्षा: डेटा रेस अणू अंतर्भागाद्वारे प्रतिबंधित आहे.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// अंतर्निहित पूर्णांकासाठी परिवर्तनीय पॉईंटर मिळवते.
            ///
            /// परिणामी पूर्णांक वर अणू-वाचन वाचणे आणि लिहिणे ही डेटा रेस असू शकते.
            /// ही पद्धत मुख्यतः एफएफआयसाठी उपयुक्त आहे, जेथे कार्य स्वाक्षरी वापरू शकतात
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// या अणूच्या सामायिक संदर्भातून `*mut` पॉईंटर परत करणे सुरक्षित आहे कारण अणू प्रकार आतील उत्परिवर्तनासह कार्य करतात.
            /// अणूच्या सर्व बदलांनी सामायिक केलेल्या संदर्भाद्वारे मूल्य बदलते आणि जोपर्यंत ते अणु परिचालन वापरतात तोपर्यंत सुरक्षितपणे करू शकतात.
            /// परत आलेल्या कच्च्या पॉइंटरच्या कोणत्याही वापरास `unsafe` ब्लॉक आवश्यक आहे आणि तरीही तसाच निर्बंध कायम ठेवावा लागेल: त्यावरील ऑपरेशन अणू असणे आवश्यक आहे.
            ///
            ///
            /// # Examples
            ///
            /// 00 `X (extern-declaration) कडे दुर्लक्ष करा
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// बाह्य "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // सुरक्षितताः जोपर्यंत `my_atomic_op` अणू आहे तोपर्यंत सुरक्षित आहे.
            /// असुरक्षित {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // सुरक्षितता: कॉलरने `atomic_store` साठी सुरक्षितता करार पाळला पाहिजे.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // सुरक्षितता: कॉलरने `atomic_load` साठी सुरक्षितता करार पाळला पाहिजे.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षितता: कॉलरने `atomic_swap` साठी सुरक्षितता करार पाळला पाहिजे.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// मागील मूल्य मिळवते (जसे ____ sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षितता: कॉलरने `atomic_add` साठी सुरक्षितता करार पाळला पाहिजे.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// मागील मूल्य मिळवते (जसे ____nc_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षितता: कॉलरने `atomic_sub` साठी सुरक्षितता करार पाळला पाहिजे.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // सुरक्षितता: कॉलरने `atomic_compare_exchange` साठी सुरक्षितता करार पाळला पाहिजे.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // सुरक्षितता: कॉलरने `atomic_compare_exchange_weak` साठी सुरक्षितता करार पाळला पाहिजे.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षितता: कॉलरने `atomic_and` साठी सुरक्षितता करार पाळला पाहिजे
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षितता: कॉलरने `atomic_nand` साठी सुरक्षितता करार पाळला पाहिजे
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षितता: कॉलरने `atomic_or` साठी सुरक्षितता करार पाळला पाहिजे
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षितता: कॉलरने `atomic_xor` साठी सुरक्षितता करार पाळला पाहिजे
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// कमाल मूल्य मिळवते (स्वाक्षरी केलेली तुलना)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षितता: कॉलरने `atomic_max` साठी सुरक्षितता करार पाळला पाहिजे
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// किमान मूल्य मिळवते (स्वाक्षरी केलेली तुलना)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षितता: कॉलरने `atomic_min` साठी सुरक्षितता करार पाळला पाहिजे
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// कमाल मूल्य मिळवते (स्वाक्षरीकृत तुलना)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षितता: कॉलरने `atomic_umax` साठी सुरक्षितता करार पाळला पाहिजे
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// किमान मूल्य मिळवते (स्वाक्षरीकृत तुलना)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षितता: कॉलरने `atomic_umin` साठी सुरक्षितता करार पाळला पाहिजे
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// एक अणु कुंपण.
///
/// निर्दिष्ट ऑर्डरवर अवलंबून, कुंपण कंपाईलर आणि सीपीयूला त्याभोवती विशिष्ट प्रकारच्या मेमरी ऑपरेशन्स पुनर्क्रमित करण्यापासून प्रतिबंधित करते.
/// हे त्या दरम्यान आणि इतर थ्रेडमधील अणु परिचालन किंवा कुंपण यांच्यातील संबंधांचे समक्रमित करते.
///
/// एक कुंपण 'A' ज्यामध्ये (कमीतकमी) [`Release`] ऑर्डरिंग सिमेंटिक्स आहे, कुंपण 'B' सह सिंक्रोनाइझ करते (कमीतकमी) एक्स 0 एक्स एक्स सिमेंटिक्स, जर आणि फक्त तेथे ऑपरेशन्स असल्यास एक्स आणि वाय, दोन्ही काही अणु ऑब्जेक्ट एक्स ० 4 एक्स वर कार्य करतात जसे की ए आधी अनुक्रमित आहे बी, वाई आणि एम मध्ये बदल पाहण्यापूर्वी एक्स, वाईचे समक्रमित केले जाते.
/// हे ए आणि बी दरम्यान होण्यापूर्वीचे अवलंबन प्रदान करते.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// एक्स 100 एक्स किंवा एक्स 0 एक्स एक्स सिमेंटिक्ससह अणु क्रिया देखील कुंपणासह समक्रमित करू शकतात.
///
/// [`Acquire`] आणि [`Release`] दोन्ही शब्दसंग्रह असण्याव्यतिरिक्त [`SeqCst`] ऑर्डरिंग असलेली कुंपण, इतर [`SeqCst`] ऑपरेशन्स आणि/किंवा कुंपणांच्या जागतिक प्रोग्राम ऑर्डरमध्ये भाग घेते.
///
/// [`Acquire`], [`Release`], [`AcqRel`] आणि [`SeqCst`] क्रमवारी स्वीकारते.
///
/// # Panics
///
/// `order` [`Relaxed`] असल्यास Panics.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // स्पिनलॉकवर आधारित परस्पर बहिष्कार आदिम.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // जुने मूल्य `false` होईपर्यंत प्रतीक्षा करा.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // हे कुंपण `unlock` मध्ये स्टोअर-सह सिंक्रोनाइझ करते.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // सुरक्षितता: अणु कुंपण वापरणे सुरक्षित आहे.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// एक कंपाईलर मेमरी कुंपण
///
/// `compiler_fence` कोणताही मशीन कोड सोडत नाही, परंतु कंपाईलरला पुन्हा करण्याची मागणी असलेल्या मेमरीच्या प्रकारांवर प्रतिबंधित आहे.विशेषतः, दिलेल्या X01 एक्स शब्दांकाच्या आधारावर, कंपाइलरला कॉलच्या आधी किंवा नंतर `compiler_fence` वर कॉलच्या आधी किंवा वाचन वाचन किंवा लिहिण्यापासून मनाई केली जाऊ शकते.लक्षात घ्या की हे **नाही***हार्डवेअर* ला अशा री-ऑर्डर करण्यापासून प्रतिबंधित करते.
///
/// सिंगल-थ्रेडेड, एक्झिक्यूशन संदर्भात ही समस्या नाही, परंतु जेव्हा इतर थ्रेड एकाच वेळी मेमरी सुधारू शकतात, तेव्हा [`fence`] सारख्या मजबूत सिंक्रोनाइझेशन आदिम आवश्यक असतात.
///
/// वेगवेगळ्या ऑर्डरिंग शब्दांकाद्वारे प्रतिबंधित री-ऑर्डरिंगः
///
///  - [`SeqCst`] सह, या पॉईंटवर वाचन आणि लेखनाचे पुनर्क्रमित करण्याची परवानगी नाही.
///  - [`Release`] सह, आधीचे वाचन आणि लेखन नंतरच्या लेखनांना हलविले जाऊ शकत नाही.
///  - [`Acquire`] सह, त्यानंतरचे वाचन आणि लेखन आधीच्या वाचनांच्या पुढे जाऊ शकत नाही.
///  - [`AcqRel`] सह, वरील दोन्ही नियम लागू केले आहेत.
///
/// `compiler_fence` *धागा स्वतःस रेसिंग* करण्यापासून रोखण्यासाठी सामान्यतः उपयुक्त आहे.म्हणजेच जर दिलेला धागा कोडचा एक तुकडा कार्यान्वित करीत असेल आणि नंतर व्यत्यय आला असेल आणि इतरत्र कोड कार्यान्वित करण्यास सुरवात करेल (समान धाग्यात असूनही, आणि वैचारिकदृष्ट्या अद्याप त्याच कोरवर).पारंपारिक प्रोग्राममध्ये, हे केवळ तेव्हाच उद्भवू शकते जेव्हा सिग्नल हँडलर नोंदणीकृत असेल.
/// अधिक निम्न-स्तरीय कोडमध्ये, व्यत्यय हाताळताना, पूर्व-शिपिंगसह हिरवे धागे अंमलबजावणी करताना देखील अशा परिस्थिती उद्भवू शकतात.
/// उत्साही वाचकांना Linux कर्नलची चर्चा [memory barriers] वाचण्यास प्रोत्साहित केले जाते.
///
/// # Panics
///
/// `order` [`Relaxed`] असल्यास Panics.
///
/// # Examples
///
/// `compiler_fence` शिवाय, एका कोडमध्ये सर्व काही असूनही, पुढील कोडमधील X01 एक्स * यशस्वी होण्याची हमी नाही.
/// हे पाहण्यासाठी, हे लक्षात ठेवा की कंपाईलर `IMPORTANT_VARIABLE` आणि `IS_READ` वर स्टोअर अदलाबदल करण्यास मोकळे आहेत कारण ते दोन्ही `Ordering::Relaxed` आहेत.जर ते करत असेल आणि `IS_READY` अद्यतनित झाल्यानंतर सिग्नल हँडलर विनंती केली असेल तर सिग्नल हँडलर `IS_READY=1`, परंतु `IMPORTANT_VARIABLE=0` दिसेल.
/// या परिस्थितीत `compiler_fence` उपाय वापरणे.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // पूर्वीच्या लेखनांना या बिंदूच्या पलीकडे जाण्यापासून प्रतिबंधित करा
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // सुरक्षितता: अणु कुंपण वापरणे सुरक्षित आहे.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// व्यस्त-प्रतीक्षा स्पिन-लूप ("स्पिन लॉक") च्या आत असल्याचे प्रोसेसर दर्शवते.
///
/// हे कार्य [`hint::spin_loop`] च्या नावे नापसंत केले गेले आहे.
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}