#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// [Unicode](http://www.unicode.org/) ची आवृत्ती जी `char` आणि `str` पद्धतींचा युनिकोड भाग आधारित आहे.
///
/// युनिकोडच्या नवीन आवृत्त्या नियमितपणे प्रकाशीत केल्या जातात आणि त्यानंतर युनिकोडनुसार प्रमाणित लायब्ररीत सर्व पद्धती अद्ययावत केल्या जातात.
/// म्हणूनच काही एक्स 100 एक्स आणि एक्स 0 एक्स एक्स पद्धतींचे वर्तन आणि काळानुसार या सततचे मूल्य बदलते.
/// हा *ब्रेकिंग बदल मानला जात नाही*.
///
/// आवृत्ती क्रमांकन योजनेची [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) मध्ये व्याख्या केली आहे.
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// लिबॉलोकच्या वापरासाठी, लिबस्टडीमध्ये पुन्हा निर्यात नाही.
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;