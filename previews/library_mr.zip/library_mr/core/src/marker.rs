//! आदिम झेडट्रिट्स0 झेड आणि प्रकारांच्या मूळ गुणधर्मांचे प्रतिनिधित्व करणारे प्रकार.
//!
//! Rust प्रकारांचे त्यांच्या अंतर्गत गुणधर्मांनुसार विविध उपयुक्त प्रकारे वर्गीकरण केले जाऊ शकते.
//! ही वर्गीकरण traits म्हणून दर्शविली जाते.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// धागेच्या सीमांवर ओलांडले जाऊ शकतात असे प्रकार.
///
/// जेव्हा संकलक योग्य ते निर्धारित करते तेव्हा हे trait स्वयंचलितपणे अंमलात आणले जाते.
///
/// Non-Send` नसलेल्या प्रकाराचे उदाहरण म्हणजे संदर्भ-मोजणी सूचक [`rc::Rc`][`Rc`].
/// जर दोन थ्रेड्स [`Rc`] चे क्लोन करण्याचा प्रयत्न करीत आहेत जे समान संदर्भ-मोजलेल्या मूल्याकडे निर्देशित करतात, तर ते एकाच वेळी संदर्भ संख्या अद्ययावत करण्याचा प्रयत्न करू शकतात, जे एक्स00 एक्स आहे कारण एक्स ० ए एक्स अणु परिचालन वापरत नाही.
///
/// याचा चुलतभावा X01 एक्स अणु ऑपरेशन्स वापरतो (काही ओव्हरहेड) आणि त्यामुळे एक्स 100 एक्स आहे.
///
/// अधिक तपशीलांसाठी [the Nomicon](../../nomicon/send-and-sync.html) पहा.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// कंपाईल वेळेवर स्थिर आकार असलेले प्रकार.
///
/// सर्व प्रकारच्या मापदंडांमध्ये `Sized` ची अंतर्भूत मर्यादा असते.हा बाउंड योग्य नसल्यास काढण्यासाठी विशेष सिंटॅक्स एक्स ०१ एक्सचा वापर केला जाऊ शकतो.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // X FooUse(Foo<[i32]>);//त्रुटी: [i32] साठी आकार लागू केलेला नाही
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// एक अपवाद म्हणजे trait चा अंतर्भूत `Self` प्रकार.
/// झेडट्रायट0 झेडला एक्स एक्स एक्स एक्स बाध्यकारी नसते कारण हे [झेडट्रायट0 झेड ऑब्जेक्ट] चे विसंगत आहे जिथे परिभाषानुसार, झेडट्रायट0 झेडला सर्व संभाव्य अंमलबजावणीकर्त्यांसह कार्य करणे आवश्यक आहे आणि त्यामुळे त्याचे आकार देखील असू शकतात.
///
///
/// जरी Rust आपल्‍याला `Sized` ला trait वर बांधू देईल, परंतु आपण नंतर trait ऑब्जेक्ट तयार करण्यासाठी त्याचा वापर करण्यास सक्षम राहणार नाहीः
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // चला y: &dyn बार= &Impl;//त्रुटी: trait `Bar` ऑब्जेक्टमध्ये बनविणे शक्य नाही
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // डीफॉल्टसाठी, उदाहरणार्थ, यासाठी आवश्यक आहे की `[T]: !Default` मूल्यमापन करण्यायोग्य असेल
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// डायनॅमिकली-आकाराच्या प्रकारासाठी "unsized" असू शकतात असे प्रकार.
///
/// उदाहरणार्थ, आकाराचा अ‍ॅरे प्रकार `[i8; 2]` `Unsize<[i8]>` आणि `Unsize<dyn fmt::Debug>` लागू करतो.
///
/// `Unsize` ची सर्व अंमलबजावणी कंपाइलरद्वारे स्वयंचलितपणे प्रदान केली जातात.
///
/// `Unsize` यासाठी लागू केले आहेः
///
/// - `[T; N]` `Unsize<[T]>` आहे
/// - `T` `T: Trait` असताना `Unsize<dyn Trait>` आहे
/// - `Foo<..., T, ...>` `Unsize<Foo<..., U, ...>>` आहे तरः
///   - `T: Unsize<U>`
///   - फू एक रचना आहे
///   - `Foo` च्या फक्त शेवटच्या फील्डमध्ये `T` चा एक प्रकार आहे
///   - `T` इतर कोणत्याही फील्डचा भाग नाही
///   - `Bar<T>: Unsize<Bar<U>>`, `Foo` च्या शेवटच्या फील्डमध्ये `Bar<T>` प्रकार असल्यास
///
/// `Unsize` "user-defined" सारख्या [`Rc`] कंटेनरना डायनॅमिकली-आकाराचे प्रकार समाविष्ट करण्यास अनुमती देण्यासाठी [`ops::CoerceUnsized`] सह वापरली जाते.
/// अधिक तपशीलांसाठी [DST coercion RFC][RFC982] आणि [the nomicon entry on coercion][nomicon-coerce] पहा.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// नमुना सामनामध्ये वापरल्या जाणार्‍या स्थिरांकांसाठी आवश्यक trait.
///
/// एक्स प्रकार 1 पॅरामीटर्स `Eq` कार्यान्वित करते की नाही याची पर्वा न करता `PartialEq` घेणारा कोणताही प्रकार स्वयंचलितपणे या झेडट्रेट 0 झेडला स्वयंचलितपणे लागू करतो.
///
/// जर एखाद्या `const` आयटममध्ये असे प्रकार आहेत जे हे झेडट्रायट0झेड अंमलबजावणी करीत नाहीत, तर त्या प्रकारात एकतर एक्स0 एक्स एक्स एक्स 2 एक्स लागू करत नाही (याचा अर्थ स्थिरांक तुलनात्मक पद्धत प्रदान करणार नाही, जे कोड जनरेशन उपलब्ध आहे असे गृहीत करते), किंवा एक्स 0 एक्स एक्स स्वतःचे लागू करते * *`PartialEq` ची आवृत्ती (जी आम्ही गृहीत करतो की स्ट्रक्चरल-समानतेच्या तुलनेत अनुरूप नाही).
///
///
/// उपरोक्त दोनपैकी कोणत्याही परिस्थितीत आम्ही नमुना सामनामध्ये अशा स्थिरतेचा वापर नाकारतो.
///
/// हे [structural match RFC][RFC1445] आणि [issue 63438] देखील पहा जे विशेषता-आधारित डिझाइनमधून या trait वर स्थलांतर करण्यास प्रवृत्त करते.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// नमुना सामनामध्ये वापरल्या जाणार्‍या स्थिरांकांसाठी आवश्यक trait.
///
/// `Eq` घेणारा कोणताही प्रकार स्वयंचलितपणे या झेडट्रायट 0 झेडला स्वयंचलितपणे लागू करतो, त्याचे प्रकार पॅरामीटर्स `Eq` लागू करतात की नाही याची पर्वा न करता *
///
/// आमच्या प्रकारातील सिस्टममध्ये मर्यादा घालून काम करण्यासाठी हे एक खाच आहे.
///
/// # Background
///
/// आम्हाला हे आवश्यक आहे की नमुना सामन्यांमध्ये वापरल्या जाणार्‍या प्रकारच्या प्रकारांमध्ये एक्स00 एक्स गुणधर्म असणे आवश्यक आहे.
///
/// अधिक आदर्श जगात आम्ही दिलेली प्रकार `StructuralPartialEq` trait *आणि*`Eq` trait दोन्ही लागू करते हे तपासूनच आम्ही ती आवश्यकता तपासू शकतो.
/// तथापि, आपल्याकडे एडीटी असू शकतात ज्या *एक्स* 1 एक्स * करतात आणि असे एक प्रकरण असू शकते जे आम्हाला कंपाईलरने स्वीकारावे अशी आमची इच्छा आहे, आणि तरीही स्थिर प्रकार एक्स 100 एक्स लागू करण्यात अयशस्वी होतो.
///
/// बहुदा, यासारखे प्रकरणः
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (वरील कोडमधील समस्या अशी आहे की `Wrap<fn(&())>` `PartialEq` किंवा `Eq` लागू करत नाही, कारण because <'a> fn(&'a _)` does not implement those traits.) साठी
///
/// म्हणून, आम्ही `StructuralPartialEq` आणि फक्त `Eq` साठी भोळे धनादेशावर विसंबून राहू शकत नाही.
///
/// यावर कार्य करण्यासाठी एक खाच म्हणून, आम्ही दोन वेगळ्या (`#[derive(PartialEq)]` आणि `#[derive(Eq)]`) मध्ये इंजेक्शन केलेले दोन स्वतंत्र traits वापरतो आणि त्या दोघीही स्ट्रक्चरल-सामना तपासणीच्या भाग म्हणून उपस्थित असल्याचे तपासा.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// प्रकार ज्याची मूल्ये बिट्स कॉपी करून फक्त डुप्लिकेट केली जाऊ शकतात.
///
/// डीफॉल्टनुसार, व्हेरिएबल बाइंडिंग्जमध्ये 'मूव्ह सिमेंटिक्स' असतात.दुसऱ्या शब्दात:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` `y` मध्ये हलविला आहे, आणि म्हणून वापरला जाऊ शकत नाही
///
/// // println! ("{: ?}", x);//त्रुटी: हलवलेल्या मूल्याचा वापर
/// ```
///
/// तथापि, प्रकारात `Copy` लागू केल्यास त्याऐवजी 'कॉपी सीमेंटिक्स' असतेः
///
/// ```
/// // आम्ही एक `Copy` कार्यान्वयन मिळवू शकतो.
/// // `Clone` हे देखील आवश्यक आहे, कारण ते एक्स 100 एक्स चा सुपरट्राईट आहे.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` ही `x` ची एक प्रत आहे
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// हे लक्षात घेणे महत्वाचे आहे की या दोन उदाहरणांमध्ये असाइनमेंट नंतर आपल्याला `x` वर प्रवेश करण्याची परवानगी आहे की नाही हा फरक आहे.
/// प्रवाहाच्या खाली, प्रत आणि चाल या दोहोंचा परिणाम बिट मेमरीमध्ये कॉपी केला जाऊ शकतो, जरी हे कधीकधी दूर केले जाते.
///
/// ## मी `Copy` ची अंमलबजावणी कशी करू शकेन?
///
/// आपल्या प्रकारावर `Copy` लागू करण्याचे दोन मार्ग आहेत.`derive` वापरणे सर्वात सोपा आहे:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// आपण व्यक्तिचलितपणे `Copy` आणि `Clone` देखील अंमलात आणू शकता:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// या दोघांमध्ये एक छोटासा फरक आहे: एक्स 100 एक्स रणनीती देखील प्रकार पॅरामीटर्सवर बंधन असलेले X01 एक्स ठेवेल, जी नेहमीच इच्छित नसते.
///
/// ## `Copy` आणि `Clone` मध्ये काय फरक आहे?
///
/// प्रती स्पष्टपणे घडतात, उदाहरणार्थ असाइनमेंट `y = x` चा भाग म्हणून.`Copy` चे वर्तन ओव्हरलोड करण्यायोग्य नाही;ही नेहमी साधी बिट वार प्रत असते.
///
/// क्लोनिंग ही एक स्पष्ट क्रिया आहे, एक्स00 एक्स.[`Clone`] ची अंमलबजावणी मूल्ये सुरक्षितपणे डुप्लिकेट करण्यासाठी आवश्यक असलेल्या कोणत्याही प्रकारचे-विशिष्ट वर्तन प्रदान करू शकते.
/// उदाहरणार्थ, एक्स ०० एक्ससाठी एक्स ००० एक्स च्या अंमलबजावणीसाठी पॉइंट-टू स्ट्रिंग बफरला ढीगमध्ये कॉपी करणे आवश्यक आहे.
/// [`String`] मूल्यांची सोपी बिटवाईज कॉपी केवळ पॉइंटरचीच प्रत बनवेल, ज्यामुळे ओळी खाली डबल फ्री होईल.
/// या कारणास्तव, [`String`] हे [`Clone`] आहे परंतु एक्स 100 एक्स नाही.
///
/// [`Clone`] हे एक्स01 एक्सचा सुपरट्रॅइट आहे, म्हणून जे एक्स 2 2 एक्स आहे त्या प्रत्येक गोष्टीने एक्स 100 एक्स देखील लागू केले पाहिजे.
/// जर एखादा प्रकार एक्स 100 एक्स असेल तर त्याच्या एक्स 0 ए एक्स अंमलबजावणीसाठी केवळ एक्स0 2 एक्स परत करणे आवश्यक आहे (वरील उदाहरण पहा).
///
/// ## माझा प्रकार `Copy` कधी असू शकतो?
///
/// एक प्रकार `Copy` अंमलात आणू शकतो जर त्याचे सर्व घटक `Copy` लागू करतात.उदाहरणार्थ, ही रचना `Copy` असू शकते:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// रचना `Copy` असू शकते, आणि [`i32`] हे `Copy` आहे, म्हणून एक्स04 एक्स एक्स 100 एक्स होण्यास पात्र आहे.
/// याउलट विचार करा
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// रचना `PointList` `Copy` लागू करू शकत नाही, कारण [`Vec<T>`] हे `Copy` नाही.आम्ही `Copy` अंमलबजावणी करण्याचा प्रयत्न केल्यास आम्हाला एक त्रुटी मिळेल:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// (`&T`) सामायिक केलेले संदर्भ देखील `Copy` आहेत, त्यामुळे एक प्रकार `Copy` असू शकतो, जरी तो *नाही*`Copy` नसलेल्या `T` प्रकारांचे सामायिक संदर्भ ठेवेल.
/// `Copy` ची अंमलबजावणी करू शकणार्‍या पुढील संरचनेचा विचार करा, कारण त्यातून आमच्या व op कॉपी प्रकार नसलेल्या `PointList` वर फक्त एक *सामायिक संदर्भ* आहे:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## जेव्हा * माझा प्रकार `Copy` असू शकत नाही?
///
/// काही प्रकारचे सुरक्षितपणे कॉपी केले जाऊ शकत नाहीत.उदाहरणार्थ, `&mut T` ची कॉपी केल्याने एक अलियास्टेड परस्पर बदल होऊ शकेल.
/// [`String`] कॉपी करणे [`स्ट्रिंग`] चे बफर व्यवस्थापित करण्याची जबाबदारीची नक्कल करेल, ज्यामुळे दुहेरी मुक्त होईल.
///
/// नंतरचे प्रकरण सामान्यीकृत करणे, कोणत्याही प्रकारचे [`Drop`] लागू करणे `Copy` असू शकत नाही, कारण ते स्वत: च्या एक्स0 2 एक्स बाइट्स व्यतिरिक्त काही स्त्रोत व्यवस्थापित करीत आहे.
///
/// आपण एक्स-01 एक्सची रचना एखाद्या स्ट्रक्चर किंवा एन-कॉपी डेटा नसलेल्या एनमवर अंमलात आणण्याचा प्रयत्न केल्यास आपल्याला [E0204] त्रुटी मिळेल.
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## * * माझा प्रकार `Copy` कधी असावा?
///
/// सर्वसाधारणपणे सांगायचे तर, आपला प्रकार _can_ `Copy` कार्यान्वित करत असल्यास, तो असावा.
/// तथापि, हे लक्षात ठेवा की `Copy` ची अंमलबजावणी करणे आपल्या प्रकारातील सार्वजनिक API चा एक भाग आहे.
/// जर प्रकार future मध्ये नॉन-कॉपी बनला असेल तर, ब्रेकिंग एपीआय बदल टाळण्यासाठी, आता `Copy` अंमलबजावणी वगळणे शहाणे आहे.
///
/// ## अतिरिक्त अंमलबजावणी करणारे
///
/// [implementors listed below][impls] व्यतिरिक्त, खालील प्रकार देखील `Copy` लागू करतात:
///
/// * फंक्शन आयटमचे प्रकार (म्हणजे प्रत्येक कार्यासाठी परिभाषित केलेले वेगळे प्रकार)
/// * कार्य पॉइंटर प्रकार (उदा. `fn() -> i32`)
/// * अ‍ॅरे प्रकार, सर्व आकारांसाठी, आयटम प्रकाराने `Copy` (उदा. `[i32; 123456]`) लागू केल्यास
/// * ट्युपल प्रकार, जर प्रत्येक घटक देखील एक्स ०१ एक्स लागू करतो (उदा. एक्स. एक्स एक्स, एक्स ०२ एक्स)
/// * बंद होण्याचे प्रकार, जर त्यांनी वातावरणाकडून काही मूल्य प्राप्त केले नाही किंवा अशा सर्व पकडलेल्या मूल्यांनी स्वत: `Copy` लागू केली असेल तर.
///   लक्षात घ्या की सामायिक रेफरन्सद्वारे कॅप्चर केलेले व्हेरिएबल्स नेहमीच `Copy` लागू करतात (जरी भिन्न नसले तरीही), परंतु बदलण्यायोग्य संदर्भाद्वारे मिळविलेले व्हेरिएबल्स कधीही `Copy` लागू करत नाहीत.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) हे असमाधानी आजीवन मर्यादेमुळे `Copy` अंमलबजावणी करीत नाही अशा प्रकारची कॉपी करण्यास अनुमती देते (केवळ `A<'static>: Copy` आणि `A<'_>: Clone` असताना `A<'_>` कॉपी करीत आहे).
// आमच्याकडे आत्ताच हे वैशिष्ट्य आहे कारण मानक ग्रंथालयात एक्स एक्स एक्स वर आधीच अस्तित्त्वात असलेल्या काही वैशिष्ट्ये आहेत आणि आत्ताच हे वर्तन सुरक्षितपणे ठेवण्याचा कोणताही मार्ग नाही.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// झेडट्रायट0झेड एक्स 100 एक्सची इम्प्लिअल व्युत्पन्न करणार्‍या डेरिव मॅक्रो.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// थ्रेड्स दरम्यान संदर्भ सामायिक करणे सुरक्षित आहे.
///
/// जेव्हा संकलक योग्य ते निर्धारित करते तेव्हा हे trait स्वयंचलितपणे अंमलात आणले जाते.
///
/// तंतोतंत व्याख्या अशीः `T` प्रकार [`Sync`] आहे तर आणि `&T` [`Send`] असेल तरच.
/// दुस words्या शब्दांत, थ्रेड्स दरम्यान एक्स01 एक्स संदर्भ पास करताना एक्स 100 एक्स (डेटा रेससह) ची शक्यता नसल्यास.
///
/// एखाद्याला अपेक्षेप्रमाणे, एक्स ०१ एक्स आणि एक्स ०२ एक्ससारखे आदिम प्रकार हे सर्व एक्स १००० एक्स आहेत, आणि म्हणून साध्या एकत्रित प्रकार आहेत ज्यामध्ये टपल्स, स्ट्रक्ट्स आणि एम्स आहेत.
/// मूलभूत [`Sync`] प्रकारांच्या अधिक उदाहरणांमध्ये "immutable" प्रकार `&T` आणि साध्या वारसागत परिवर्तनासह, जसे की एक्स ० एक्स, एक्स ०२ एक्स आणि इतर संग्रह प्रकारांचा समावेश आहे.
///
/// (जेनेरिक पॅरामीटर्स त्यांचे कंटेनर [`Sync`] होण्यासाठी [`Sync`] असणे आवश्यक आहे.)
///
/// या व्याख्येचा थोडा आश्चर्यकारक परिणाम म्हणजे `&mut T` हे `Sync` आहे (जर `T` हे X03 एक्स असेल तर) असे दिसते की ते कदाचित अनइन्क्रॉनाइझेशन उत्परिवर्तन प्रदान करेल.
/// युक्ती ही आहे की सामायिक केलेल्या संदर्भामागील एक परिवर्तनीय संदर्भ (म्हणजेच X02 एक्स) केवळ वाचनीय होते, जणू जणू तो एक्स 100 एक्स आहे.
/// म्हणून डेटा रेसचा धोका नाही.
///
/// `Sync` नसलेले प्रकार हे "interior mutability" नस-थ्रेड-सेफ फॉर्ममध्ये आहेत, जसे की [`Cell`][cell] आणि [`RefCell`][refcell].
/// हे प्रकार एका बदलण्यायोग्य, सामायिक केलेल्या संदर्भाद्वारे त्यांच्या सामग्रीचे उत्परिवर्तन करण्यास अनुमती देतात.
/// उदाहरणार्थ [`Cell<T>`][cell] वरील `set` पद्धत `&self` घेते, म्हणून यासाठी केवळ सामायिक संदर्भ [`&Cell<T>`][cell] आवश्यक आहे.
/// पद्धत कोणतीही सिंक्रोनाइझेशन करत नाही, अशा प्रकारे X01 एक्स `Sync` असू शकत नाही.
///
/// `सिंक` नसलेल्या प्रकाराचे आणखी एक उदाहरण म्हणजे संदर्भ-मोजणी पॉईंटर [`Rc`][rc].
/// कोणताही संदर्भ [`&Rc<T>`][rc] दिल्यास, आपण परमाणु मार्गाने संदर्भ संख्या सुधारित करून नवीन [`Rc<T>`][rc] क्लोन करू शकता.
///
/// जेव्हा एखाद्यास थ्रेड-सेफ इंटिरियर म्युटॅबिलिटीची आवश्यकता असते तेव्हा झेड रस्ट ० झेड एक्स ०१ एक्स प्रदान करते, तसेच एक्स ०२ एक्स आणि एक्स २०० एक्स मार्फत स्पष्ट लॉक करते.
/// हे प्रकार याची खात्री करतात की कोणत्याही उत्परिवर्तनांमुळे डेटा रेस होऊ शकत नाहीत, म्हणूनच हे प्रकार एक्स 100 एक्स आहेत.
/// त्याचप्रमाणे, [`sync::Arc`][arc] एक्स 100 एक्सचे थ्रेड-सेफ एनालॉग प्रदान करते.
///
/// आंतरिक उत्परिवर्तन असणार्‍या कोणत्याही प्रकारात value(s) भोवती [`cell::UnsafeCell`][unsafecell] आवरण देखील वापरणे आवश्यक आहे जे सामायिक संदर्भाद्वारे बदलले जाऊ शकते.
/// असे करण्यात अयशस्वी होणे [undefined behavior][ub] आहे.
/// उदाहरणार्थ, [`transmute`][transmute]-ing `&T` ते `&mut T` पर्यंत अवैध आहे.
///
/// `Sync` बद्दल अधिक तपशीलांसाठी [the Nomicon][nomicon-send-and-sync] पहा.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): एकदा बीटामध्ये एक्स ०१ एक्स जमिनीत नोट्स जोडण्यासाठी पाठिंबा दर्शविला आणि आवश्यकतेच्या साखळीत कोठेही बंद आहे की नाही हे तपासण्यासाठी विस्तारित केले गेले आहे, अशा एक्स00 एक्स म्हणून वाढवा:
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// त्यांच्याकडे X001 मालकीचे असलेल्या वस्तूंना चिन्हांकित करण्यासाठी शून्य-आकाराचा प्रकार वापरला जातो.
///
/// आपल्या प्रकारात एक X01 एक्स फील्ड जोडणे कंपाईलरला सांगते की आपला प्रकार खरोखर प्रकारात नसला तरीही `T` प्रकाराचे मूल्य साठवतो तसे कार्य करतो.
/// काही सुरक्षा गुणधर्मांची गणना करताना ही माहिती वापरली जाते.
///
/// `PhantomData<T>` कसे वापरावे याच्या अधिक सखोल स्पष्टीकरणासाठी, कृपया [the Nomicon](../../nomicon/phantom-data.html) पहा.
///
/// # एक भयानक नोट 👻👻👻
///
/// त्या दोघांची भीतीदायक नावे असूनही, `PhantomData` आणि 'फॅंटम प्रकार' संबंधित आहेत, परंतु एकसारखे नाहीत.फॅंटम प्रकार मापदंड म्हणजे एक प्रकार पैरामीटर जो कधीही वापरला जात नाही.
/// Rust मध्ये, यामुळे वारंवार कंपाईलर तक्रार करण्यास कारणीभूत ठरते आणि `PhantomData` च्या मार्गाने "dummy" चा वापर करणे हा उपाय आहे.
///
/// # Examples
///
/// ## न वापरलेले आजीवन पॅरामीटर्स
///
/// बहुधा सामान्यतः काही असुरक्षित कोडचा भाग म्हणून `PhantomData` साठी सर्वात सामान्य वापर केस एक अशी रचना आहे ज्यात न वापरलेले आजीवन पॅरामीटर आहे.
/// उदाहरणार्थ, येथे एक रचना `Slice` आहे ज्यामध्ये `*const T` प्रकाराचे दोन पॉईंटर्स आहेत, संभवतः कुठेतरी अ‍ॅरे मध्ये निर्देशित करतात:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// हेतू असा आहे की अंतर्भूत डेटा केवळ आजीवन `'a` साठी वैध आहे, म्हणून `Slice` `'a` ला चढाऊ नये.
/// तथापि, हा हेतू कोडमध्ये व्यक्त केला जात नाही, कारण आजीवन `'a` चे कोणतेही उपयोग नाहीत आणि म्हणूनच ते कोणत्या डेटावर लागू होते हे स्पष्ट नाही.
/// कंपाईलरला असे कार्य करण्यास सांगून आम्ही हे सुधारू शकतो जसे की * `Slice` संरचनेत एक संदर्भ `&'a T` आहे:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// यासाठी देखील `T: 'a` मधील कोणतेही संदर्भ आजीवन `'a` पर्यंत वैध आहेत हे दर्शविते, भाष्य `T: 'a` देखील आवश्यक आहे.
///
/// `Slice` प्रारंभ करताना आपण `phantom` फील्डसाठी `PhantomData` मूल्य सहजपणे प्रदान करता:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## न वापरलेले प्रकार मापदंड
///
/// असे कधीकधी असे होते की आपल्याकडे न वापरलेले प्रकार मापदंड आहेत जे निर्देशित करतात की स्ट्रक्डमध्ये कोणत्या प्रकारचा डेटा "tied" आहे, जरी डेटा प्रत्यक्षातच स्ट्रक्चमध्ये आढळला नाही.
/// येथे हे उदाहरण आहे जेथे हे एक्स 100 एक्स सह उद्भवते.
/// परदेशी इंटरफेसमध्ये `*mut ()` प्रकारची हँडल्स विविध प्रकारांच्या Rust मूल्यांचा संदर्भ घेण्यासाठी वापरली जातात.
/// आम्ही Rust प्रकार ट्रॅक करतो `ExternalResource` च्या स्ट्रॅक्ट एक्स पॅरामीटरचा वापर करून जो हँडल लपेटतो.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## मालकी आणि ड्रॉप चेक
///
/// `PhantomData<T>` प्रकाराचा फील्ड जोडणे हे सूचित करते की आपल्या प्रकारात `T` प्रकाराचा डेटा आहे.याचा अर्थ असा होतो की जेव्हा आपला प्रकार टाकला जाईल तेव्हा तो प्रकार `T` प्रकारची एक किंवा अधिक घटना घडू शकेल.
/// याचा परिणाम Rust कंपाईलरच्या [drop check] विश्लेषणावर आहे.
///
/// जर आपल्या स्ट्रेक्टमध्ये वास्तविकपणे `T` प्रकाराचा डेटा आपल्या मालकीचा नसेल * तर एक्सप्रेस 1 एक्स एक्स 2 एक्स किंवा एक्स03 एक्स (आजीवन लागू नसेल तर) सारखे संदर्भ प्रकार वापरणे चांगले आहे, जेणेकरून मालकी दर्शविली जाऊ नये.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// कंपाइलर-अंतर्गत trait एनम भेदभाव प्रकार दर्शविण्यासाठी वापरले.
///
/// हे trait स्वयंचलितपणे प्रत्येक प्रकारासाठी अंमलात आणले जाते आणि [`mem::Discriminant`] मध्ये कोणतीही हमी जोडत नाही.
/// `DiscriminantKind::Discriminant` आणि `mem::Discriminant` दरम्यान संक्रमण करणे **अपरिभाषित वर्तन** आहे.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// भेदभावाचा प्रकार, ज्याने `mem::Discriminant` ला आवश्यक असलेल्या trait bounds चे समाधान केले पाहिजे.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// कंपाइलर-अंतर्गत trait प्रकारात आंतरिकरित्या कोणत्याही `UnsafeCell` समाविष्ट आहेत की नाही हे निर्धारित करण्यासाठी वापरले जाते, परंतु ते एखाद्या दिशानिर्देशातून नाही.
///
/// हे प्रभावित करते, उदाहरणार्थ, त्या प्रकारचा `static` केवळ-वाचनीय स्थिर मेमरीमध्ये किंवा लिखित करण्यायोग्य स्थिर मेमरीमध्ये ठेवला आहे की नाही.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// पिन केल्यावर सुरक्षितपणे हलविल्या जाणार्‍या प्रकार.
///
/// झेडआरस्ट0 झेडमध्ये स्वतःच अचल जंगलांची कल्पना नसते आणि नेहमीच सुरक्षित राहण्यासाठी हालचाली (उदा. असाईनमेंटद्वारे किंवा एक्स 100 एक्स) मानतात.
///
/// त्याऐवजी प्रकार प्रणालीमध्ये जाण्यापासून रोखण्यासाठी त्याऐवजी [`Pin`][Pin] प्रकार वापरला जातो.[`Pin<P<T>>`][Pin] रॅपरमध्ये गुंडाळलेले पॉईंटर्स `P<T>` बाहेर हलविले जाऊ शकत नाहीत.
/// पिन करण्याच्या अधिक माहितीसाठी [`pin` module] दस्तऐवजीकरण पहा.
///
/// `T` साठी `Unpin` trait अंमलबजावणीमुळे प्रकार बंद होण्यावरील निर्बंध दूर होतात, ज्यामुळे [`mem::replace`] X च्या बाहेर [`mem::replace`] सारख्या कार्येसह `T` हलविण्यास परवानगी मिळते.
///
///
/// `Unpin` पिन नसलेल्या डेटासाठी काहीही परिणाम नाही.
/// विशेषतः, [`mem::replace`] `!Unpin` डेटा आनंदाने हलवते (हे कोणत्याही `&mut T` साठी कार्य करते, फक्त जेव्हा X03 एक्स नाही).
/// तथापि, आपण [`Pin<P<T>>`][Pin] मध्ये लपेटलेल्या डेटावर [`mem::replace`] वापरू शकत नाही कारण आपल्याला त्याकरिता आवश्यक असलेले `&mut T` मिळवू शकत नाही आणि *ही* ही प्रणाली कार्य करते.
///
/// म्हणूनच, उदाहरणार्थ, केवळ `Unpin` लागू करणार्‍या प्रकारांवरच केले जाऊ शकते:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // आम्हाला `mem::replace` वर कॉल करण्यासाठी परस्पर बदल आवश्यक आहे.
/// // आम्ही असा संदर्भ (implicitly) ने एक्स 01 एक्सला आवाहन करून प्राप्त करू शकतो, परंतु ते केवळ शक्य आहे कारण `String` एक्स 100 एक्स लागू करते.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// हे trait जवळजवळ प्रत्येक प्रकारासाठी स्वयंचलितपणे अंमलात आणले जाते.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// एक मार्कर प्रकार जो `Unpin` लागू करत नाही.
///
/// जर प्रकारात `PhantomPinned` असेल तर ते डीफॉल्टनुसार `Unpin` लागू करणार नाही.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// आदिम प्रकारच्या `Copy` ची अंमलबजावणी.
///
/// Rust मध्ये वर्णन केले जाऊ शकत नाही अशा अंमलबजावणी `rustc_trait_selection` मध्ये X0X मध्ये लागू केली गेली आहे.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// सामायिक संदर्भ कॉपी केले जाऊ शकतात, परंतु बदलू संदर्भ *करू शकत नाही*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}