//! अशा प्रकारच्या प्रकारांसाठी `Clone` trait ज्या 'स्पष्टपणे कॉपी केल्या जाऊ शकत नाहीत'.
//!
//! झेडआरस्ट0 झेडमध्ये काही साधे प्रकार एक्स 100 एक्स आहेत आणि जेव्हा आपण त्यांना नियुक्त करता किंवा त्यांना वितर्क म्हणून पास करता तेव्हा प्राप्तकर्त्यास एक प्रत मिळेल, मूळ मूल्य त्या ठिकाणी ठेवून.
//! या प्रकारच्या कॉपी करण्यासाठी allocलोकेशनची आवश्यकता नसते आणि अंतिम फायरिझर नसतात (उदा. त्यांच्यात मालकीचे बॉक्स नसतात किंवा एक्स00 एक्स लागू करतात), म्हणून कंपाईलर त्यांना स्वस्त आणि कॉपी करणे सुरक्षित मानते.
//!
//! [`Clone`] trait कार्यान्वित करून [`clone`] पद्धतीवर कॉल करून इतर प्रकारच्या प्रती स्पष्टपणे तयार केल्या पाहिजेत.
//!
//! [`clone`]: Clone::clone
//!
//! मूलभूत वापराचे उदाहरणः
//!
//! ```
//! let s = String::new(); // स्ट्रिंग प्रकार क्लोन कार्यान्वित करते
//! let copy = s.clone(); // तर आम्ही त्याची क्लोन करू शकतो
//! ```
//!
//! क्लोन झेडट्रायट 0 झेड सहजपणे अंमलात आणण्यासाठी आपण `#[derive(Clone)]` देखील वापरू शकता.उदाहरणः
//!
//! ```
//! #[derive(Clone)] // आम्ही मॉर्फियस स्ट्रक्चरमध्ये क्लोन झेडट्रेट 0 झेड जोडू
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // आणि आता आम्ही त्याची क्लोन करू शकतो!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// एखादी वस्तू स्पष्टपणे डुप्लिकेट करण्याच्या क्षमतेसाठी एक सामान्य trait.
///
/// [`Copy`] मधील एक्स 100 एक्सपेक्षा भिन्न अंतर्भूत आणि अत्यंत स्वस्त आहे, तर एक्स0 2 एक्स नेहमीच स्पष्ट असतो आणि महाग असू शकतो किंवा नसू शकतो.
/// ही वैशिष्ट्ये अंमलात आणण्यासाठी, Rust आपल्याला [`Copy`] ची पुनर्बांधणी करण्याची परवानगी देत नाही, परंतु आपण `Clone` ची पूर्तता करुन अनियंत्रित कोड चालवू शकता.
///
/// `Clone` हे [`Copy`] पेक्षा सामान्य आहे, आपण आपोआप देखील [`Copy`] देखील `Clone` देखील बनवू शकता.
///
/// ## Derivable
///
/// सर्व फील्ड `Clone` असल्यास हे trait `#[derive]` सह वापरले जाऊ शकते.प्रत्येक फील्डवर [`Clone`] चे `साधित अंमलबजावणी [`clone`] कॉल करते.
///
/// [`clone`]: Clone::clone
///
/// जेनेरिक स्ट्रक्चसाठी, एक्स00 एक्स सर्वसाधारण पॅरामीटर्समध्ये बाउंड एक्स 0 2 एक्स जोडून `Clone` सशर्तपणे लागू करते.
///
/// ```
/// // `derive` वाचन करण्यासाठी क्लोन कार्यान्वित करते<T>जेव्हा टी क्लोन असतो
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## मी `Clone` ची अंमलबजावणी कशी करू शकेन?
///
/// [`Copy`] प्रकारचे प्रकारांमध्ये `Clone` ची क्षुल्लक अंमलबजावणी असावी.अधिक औपचारिकरित्याः
/// `T: Copy`, `x: T` आणि `y: &T` असल्यास `let x = y.clone();` `let x = *y;` च्या समतुल्य आहे.
/// स्वयंचलित अंमलबजावणीमध्ये या अनोळखी व्यक्तीचे समर्थन करण्याची खबरदारी घ्यावी;तथापि, मेमरी सुरक्षितता सुनिश्चित करण्यासाठी असुरक्षित कोड त्यावर अवलंबून राहू नये.
///
/// एक फंक्शन पॉईंटर असलेली सामान्य रचना आहे.या प्रकरणात, `Clone` ची अंमलबजावणी `साधित केलेली असू शकत नाही, परंतु म्हणून अंमलात आणली जाऊ शकते:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## अतिरिक्त अंमलबजावणी करणारे
///
/// [implementors listed below][impls] व्यतिरिक्त, खालील प्रकार देखील `Clone` लागू करतात:
///
/// * फंक्शन आयटमचे प्रकार (म्हणजे प्रत्येक कार्यासाठी परिभाषित केलेले वेगळे प्रकार)
/// * कार्य पॉइंटर प्रकार (उदा. `fn() -> i32`)
/// * अ‍ॅरे प्रकार, सर्व आकारांसाठी, आयटम प्रकाराने `Clone` (उदा. `[i32; 123456]`) लागू केल्यास
/// * ट्युपल प्रकार, जर प्रत्येक घटक देखील एक्स ०१ एक्स लागू करतो (उदा. एक्स. एक्स एक्स, एक्स ०२ एक्स)
/// * बंद होण्याचे प्रकार, जर त्यांनी वातावरणाकडून काही मूल्य प्राप्त केले नाही किंवा अशा सर्व पकडलेल्या मूल्यांनी स्वत: `Clone` लागू केली असेल तर.
///   लक्षात घ्या की सामायिक रेफरन्सद्वारे कॅप्चर केलेले व्हेरिएबल्स नेहमीच `Clone` लागू करतात (जरी भिन्न नसले तरीही), परंतु बदलण्यायोग्य संदर्भाद्वारे मिळविलेले व्हेरिएबल्स कधीही `Clone` लागू करत नाहीत.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// मूल्याची एक प्रत परत करते.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str क्लोन कार्यान्वित करते
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// `source` वरून कॉपी-असाइनमेंट करते.
    ///
    /// `a.clone_from(&b)` कार्यक्षमतेमध्ये `a = b.clone()` च्या समतुल्य आहे, परंतु अनावश्यक वाटप टाळण्यासाठी `a` चे स्रोत पुन्हा वापरण्यासाठी अधिलिखित केले जाऊ शकते.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// झेडट्रायट0झेड एक्स 100 एक्सची इम्प्लिअल व्युत्पन्न करणार्‍या डेरिव मॅक्रो.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): या स्ट्रक्ट्सचा वापर संपूर्णपणे [[साधित]] द्वारे केला जातो की प्रकारातील प्रत्येक घटक क्लोन किंवा कॉपी लागू करतो.
//
//
// या स्ट्रिक कधीही वापरकर्त्याच्या कोडमध्ये दिसू नयेत.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// आदिम प्रकारच्या `Clone` ची अंमलबजावणी.
///
/// Rust मध्ये वर्णन केले जाऊ शकत नाही अशा अंमलबजावणी `rustc_trait_selection` मध्ये X0X मध्ये लागू केली गेली आहे.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// सामायिक संदर्भ क्लोन केले जाऊ शकतात, परंतु परिवर्तनीय संदर्भ *करू शकत नाहीत*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// सामायिक संदर्भ क्लोन केले जाऊ शकतात, परंतु परिवर्तनीय संदर्भ *करू शकत नाहीत*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}