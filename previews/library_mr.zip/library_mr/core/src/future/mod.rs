#![stable(feature = "futures_api", since = "1.36.0")]

//! अतुल्य मूल्ये.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// हा प्रकार आवश्यक आहे कारण:
///
/// a) जनरेटर `for<'a, 'b> Generator<&'a mut Context<'b>>` ची अंमलबजावणी करू शकत नाही, म्हणून आम्हाला एक कच्चा पॉईंटर पास करणे आवश्यक आहे (<https://github.com/rust-lang/rust/issues/68923> पहा).
///
/// बी) रॉ पॉइंटर्स आणि एक्स ०१ एक्स हे एक्स ०२ एक्स किंवा एक्स १००० एक्स नाहीत, जेणेकरून प्रत्येक झेडफ्यूचर ० झेड एक्स ०3 एक्सदेखील बनू शकेल आणि आम्हाला ते नको आहे.
///
/// हे एक्स 100 एक्सचे एचआयआर कमी करणे देखील सुलभ करते.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// झेडफ्यूचर0 झेडमध्ये जनरेटर गुंडाळा.
///
/// हे फंक्शन खाली एक `GenFuture` परत करते, परंतु अधिक चांगले त्रुटी संदेश (`GenFuture<[closure.....]>` ऐवजी `impl Future`) देण्यासाठी हे `impl Trait` मध्ये लपवते.
///
// आम्ही `const async fn` मधून सावरल्यानंतर अतिरिक्त त्रुटी टाळण्यासाठी हे X01 एक्स आहे
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // अंतर्निहित जनरेटरमध्ये स्वयं-संदर्भित कर्ज तयार करण्यासाठी async/await futures अचल आहेत यावर आम्ही अवलंबून आहोत.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // सुरक्षितता: सुरक्षित कारण आम्ही !Unpin + !Drop आहोत आणि हे फक्त एक फील्ड प्रोजेक्शन आहे.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // जनरेटर पुन्हा सुरू करा, `&mut Context` ला `NonNull` कच्च्या पॉइंटरमध्ये बदलू द्या.
            // `.await` कमी केल्याने ते परत `&mut Context` वर सुरक्षितपणे कास्ट होईल.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // सुरक्षा: कॉलरने हमी देणे आवश्यक आहे की `cx.0` वैध पॉईंटर आहे
    // हे बदलण्यायोग्य संदर्भासाठी सर्व आवश्यकता पूर्ण करते.
    unsafe { &mut *cx.0.as_ptr().cast() }
}