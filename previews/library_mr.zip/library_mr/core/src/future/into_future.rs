use crate::future::Future;

/// `Future` मध्ये रूपांतरण.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// झेडफ्यूचर0 झेड पूर्ण झाल्यावर उत्पादन करेल.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// कोणत्या प्रकारचे झेडफ्यूचर0 झेड आपण यामध्ये बदलत आहोत?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// मूल्यातून एक future तयार करते.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}