//! हे मॉड्यूल `Any` trait ची अंमलबजावणी करते, जे रनटाइम प्रतिबिंबणाद्वारे कोणत्याही एक्स01 एक्स प्रकारच्या डायनामिक टायपिंगला सक्षम करते.
//!
//! `Any` स्वतःच एक्स 100 एक्स मिळविण्यासाठी वापरले जाऊ शकते आणि जेव्हा झेडट्रायट0 झेड ऑब्जेक्ट म्हणून वापरली जाते तेव्हा त्यात अधिक वैशिष्ट्ये आहेत.
//! `&dyn Any` (एक कर्ज घेतलेली trait ऑब्जेक्ट) म्हणून, त्यात असलेली मूल्य दिलेल्या प्रकाराचे आहे की नाही हे तपासण्यासाठी आणि प्रकार म्हणून अंतर्गत मूल्यांचा संदर्भ मिळविण्यासाठी `is` आणि `downcast_ref` पद्धती आहेत.
//! `&mut dyn Any` म्हणून, आतील मूल्याचा बदल बदलण्यासाठी `downcast_mut` पद्धत देखील आहे.
//! `Box<dyn Any>` `downcast` पद्धत जोडते, जे `Box<T>` मध्ये रूपांतरित करण्याचा प्रयत्न करते.
//! संपूर्ण तपशीलांसाठी [`Box`] दस्तऐवजीकरण पहा.
//!
//! लक्षात घ्या की `&dyn Any` मूल्य निर्दिष्ट कॉंक्रीट प्रकाराचे आहे की नाही हे तपासण्यासाठी मर्यादित आहे आणि एक प्रकार trait लागू करतो की नाही हे तपासण्यासाठी वापरला जाऊ शकत नाही.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # स्मार्ट पॉईंटर्स आणि एक्स 100 एक्स
//!
//! `Any` वापरताना trait ऑब्जेक्ट म्हणून विशेषत: `Box<dyn Any>` किंवा `Arc<dyn Any>` सारख्या प्रकारच्या वर्तनचा एक तुकडा लक्षात ठेवणे म्हणजे फक्त `.type_id()` ला व्हॅल्यूवर कॉल करणे म्हणजे अंतर्भूत trait ऑब्जेक्ट नव्हे तर *कंटेनर* चे `TypeId` तयार करेल.
//!
//! त्याऐवजी स्मार्ट पॉईंटरला एक्स ०१ एक्स मध्ये रुपांतरित करून हे टाळता येऊ शकते, जे ऑब्जेक्टचे एक्स १००० एक्स परत करेल.
//! उदाहरणार्थ:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // आपणास हे हवे असेल अशी अधिक शक्यता आहेः
//! let actual_id = (&*boxed).type_id();
//! // ... यापेक्षाः
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! एखाद्या फंक्शनला दिलेली व्हॅल्यू लॉग आउट करू इच्छित असलेल्या परिस्थितीचा विचार करा.
//! डीबगची अंमलबजावणी करण्यासाठी आम्ही कार्य करीत असलेले मूल्य आम्हाला माहित आहे, परंतु आम्हाला त्याचे कंक्रीट प्रकार माहित नाहीत.आम्हाला विशिष्ट प्रकारांवर विशेष उपचार द्यायचे आहेतः या प्रकरणात स्ट्रिंग व्हॅल्यूजच्या किंमतीपूर्वी त्यांची लांबी मुद्रित करते.
//! कंपाईल वेळी आम्हाला आमच्या मूल्याचा ठोस प्रकार माहित नाही, म्हणून त्याऐवजी आम्हाला रनटाइम प्रतिबिंब वापरण्याची आवश्यकता आहे.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // डीबग लागू करणार्‍या कोणत्याही प्रकारच्या लॉगर फंक्शन.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // आमचे मूल्य `String` मध्ये रूपांतरित करण्याचा प्रयत्न करा.
//!     // यशस्वी झाल्यास स्ट्रिंगची लांबी तसेच त्याचे मूल्य आउटपुट करायचे आहे.
//!     // नसल्यास, हा एक वेगळा प्रकार आहे: केवळ तो अबाधित मुद्रित करा.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // कार्य करण्यापूर्वी हे कार्य त्याचे पॅरामीटर लॉग आउट करायचे आहे.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... अजून काही काम करा
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// कोणताही झेडट्रेट0 झेड
///////////////////////////////////////////////////////////////////////////////

/// डायनॅमिक टायपिंगचे अनुकरण करण्यासाठी एक trait.
///
/// बहुतेक प्रकार एक्स 100 एक्स लागू करतात.तथापि, कोणत्याही प्रकारात ज्यात अविश्वसनीय संदर्भ आहे.
/// अधिक तपशीलांसाठी [module-level documentation][mod] पहा.
///
/// [mod]: crate::any
// हे झेडट्रायट0 झेड असुरक्षित नाही, जरी आम्ही असुरक्षित कोडमधील (एक्झल एक्सएल १ एक्स एक्स फंक्शनच्या विशिष्ट वैशिष्ट्यावर अवलंबून आहे. उदा. एक्स ०3 एक्स).सामान्यत: ही एक समस्या असेल, परंतु केवळ `Any` चे आवाहन ही ब्लँकेट अंमलबजावणी आहे, इतर कोणताही कोड `Any` लागू करू शकत नाही.
//
// आम्ही हे trait असुरक्षितपणे बनवू शकू-यामुळे सर्व प्रकारची अंमलबजावणी नियंत्रित होत असल्याने-यामुळे ब्रेकेज होणार नाही-परंतु आम्ही खरोखरच आवश्यक नाही असे दोन्ही निवडले नाही आणि वापरकर्त्यांना असुरक्षित traits आणि असुरक्षित पध्दती (म्हणजे, `type_id` कॉल करणे अद्याप सुरक्षित असेल, परंतु आम्हाला कदाचित कागदपत्रांसारखे संकेत द्यायचे आहेत).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// `self` चे `TypeId` मिळते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// कोणत्याही trait वस्तूंसाठी विस्तारित पद्धती.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// याची खात्री करुन घ्या की उदा. थ्रेडमध्ये सामील होणे चा परिणाम छापता येतो आणि म्हणूनच तो `unwrap` सह वापरला जाऊ शकतो.
// अखेरीस प्रेषण कार्य करत असल्यास यापुढे यापुढे आवश्यक नाही.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// बॉक्सिंग प्रकार `T` प्रमाणेच असल्यास X01 एक्स मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // हे कार्य ज्या प्रकाराने स्थापित केले गेले आहे त्या प्रकारचे `TypeId` मिळवा.
        let t = TypeId::of::<T>();

        // trait ऑब्जेक्ट (`self`) मधील प्रकाराचा `TypeId` मिळवा.
        let concrete = self.type_id();

        // समानतेवर दोन्ही `टाइपआयडीची तुलना करा.
        t == concrete
    }

    /// बॉक्सिंग मूल्याचा काही संदर्भ `T` प्रकारचा असल्यास किंवा `None` नसल्यास तो परत मिळवते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // सुरक्षितता: आम्ही योग्य प्रकाराकडे निर्देश करीत आहोत की नाही हे तपासले आणि आम्ही त्यावर अवलंबून राहू शकतो
            // आम्ही मेमरी सेफ्टीची तपासणी करतो कारण आम्ही सर्व प्रकारांसाठी काहीही लागू केले आहे;इतर इंप्लिम्स अस्तित्त्वात येऊ शकत नाहीत कारण ते आमच्या इम्प्लियांशी विवाद करतात.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// बॉक्सिंग मूल्याबद्दल काही बदलण्यायोग्य संदर्भ `T` प्रकाराचा असल्यास किंवा तो नसल्यास `None` मिळवते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // सुरक्षितता: आम्ही योग्य प्रकाराकडे निर्देश करीत आहोत की नाही हे तपासले आणि आम्ही त्यावर अवलंबून राहू शकतो
            // आम्ही मेमरी सेफ्टीची तपासणी करतो कारण आम्ही सर्व प्रकारांसाठी काहीही लागू केले आहे;इतर इंप्लिम्स अस्तित्त्वात येऊ शकत नाहीत कारण ते आमच्या इम्प्लियांशी विवाद करतात.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// `Any` प्रकारावर परिभाषित केलेल्या पद्धतीकडे पाठवा.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// `Any` प्रकारावर परिभाषित केलेल्या पद्धतीकडे पाठवा.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// `Any` प्रकारावर परिभाषित केलेल्या पद्धतीकडे पाठवा.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// `Any` प्रकारावर परिभाषित केलेल्या पद्धतीकडे पाठवा.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// `Any` प्रकारावर परिभाषित केलेल्या पद्धतीकडे पाठवा.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// `Any` प्रकारावर परिभाषित केलेल्या पद्धतीकडे पाठवा.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// टाइपआयडी आणि त्याच्या पद्धती
///////////////////////////////////////////////////////////////////////////////

/// एक `TypeId` प्रकारासाठी जागतिक स्तरावर अद्वितीय अभिज्ञापक दर्शविते.
///
/// प्रत्येक एक्स 100 एक्स एक अपारदर्शक ऑब्जेक्ट आहे जो आत असलेल्या गोष्टींच्या तपासणीस परवानगी देत नाही परंतु क्लोनिंग, तुलना, मुद्रण आणि दर्शविणे यासारख्या मूलभूत ऑपरेशन्सना परवानगी देत नाही.
///
///
/// एक `TypeId` सध्या केवळ अशा प्रकारांसाठी उपलब्ध आहे जे `'static` चे समर्थन करतात परंतु future मध्ये ही मर्यादा हटविली जाऊ शकते.
///
/// `TypeId` `Hash`, `PartialOrd` आणि `Ord` ची अंमलबजावणी करते, हे लक्षात घेण्यासारखे आहे की झेडआरस्ट0झेड रीलिझ दरम्यान हॅश आणि ऑर्डरिंग भिन्न असेल.
/// आपल्या कोडच्या आत त्यांच्यावर अवलंबून रहाण्यापासून सावध रहा!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// हे जेनेरिक फंक्शन इन्स्टंट केले गेले आहे त्या प्रकारचे `TypeId` मिळवते.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// स्ट्रिंग स्लाइस म्हणून प्रकाराचे नाव मिळवते.
///
/// # Note
///
/// हे निदानात्मक वापरासाठी आहे.
/// प्रकाराचे सर्वोत्कृष्ट प्रयत्नांचे वर्णन केल्याखेरीज परत आलेल्या स्ट्रिंगचे नेमके मजकूर आणि स्वरूप निर्दिष्ट केलेले नाही.
/// उदाहरणार्थ, `type_name::<Option<String>>()` परत येऊ शकणार्‍या तारांमध्ये `"Option<String>"` आणि `"std::option::Option<std::string::String>"` आहेत.
///
///
/// परत आलेल्या स्ट्रिंगला प्रकाराचा एक अद्वितीय अभिज्ञापक मानला जाऊ नये कारण एकाधिक प्रकारात त्याच प्रकारच्या नावावर नकाशा असू शकतात.
/// त्याचप्रमाणे, प्रकाराचे सर्व भाग परत आलेल्या स्ट्रिंगमध्ये दिसतील याची शाश्वती नाही: उदाहरणार्थ, आजीवन निर्दिष्टकर्ता सध्या समाविष्ट केलेले नाहीत.
/// याव्यतिरिक्त, कंपाईलरच्या आवृत्तींमध्ये आउटपुट बदलू शकते.
///
/// सध्याची अंमलबजावणी संकलक निदान आणि डीबगिनफो सारख्याच पायाभूत सुविधांचा वापर करते, परंतु याची हमी दिलेली नाही.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// स्ट्रिंग स्लाइस म्हणून पॉईंट-टू मूल्याच्या प्रकाराचे नाव मिळवते.
/// हे एक्स 100 एक्ससारखेच आहे परंतु जिथे व्हेरिएबलचा प्रकार सहज उपलब्ध नसेल तेथे वापरला जाऊ शकतो.
///
/// # Note
///
/// हे निदानात्मक वापरासाठी आहे.प्रकारच्या उत्तम प्रयत्नांचे वर्णन केल्याखेरीज स्ट्रिंगची नेमकी सामग्री आणि स्वरूप निर्दिष्ट केलेले नाही.
/// उदाहरणार्थ, `type_name_of_val::<Option<String>>(None)` `"Option<String>"` किंवा `"std::option::Option<std::string::String>"` परत करू शकते, परंतु एक्स 100 एक्स नाही.
///
/// याव्यतिरिक्त, कंपाईलरच्या आवृत्तींमध्ये आउटपुट बदलू शकते.
///
/// हे कार्य trait ऑब्जेक्ट्सचे निराकरण करीत नाही, म्हणजे `type_name_of_val(&7u32 as &dyn Debug)` `"dyn Debug"` परत करेल, परंतु `"u32"` नाही.
///
/// प्रकाराचे नाव एक प्रकारचा एक अद्वितीय अभिज्ञापक मानला जाऊ नये;
/// अनेक प्रकार समान प्रकारचे नाव सामायिक करू शकतात.
///
/// सध्याची अंमलबजावणी संकलक निदान आणि डीबगिनफो सारख्याच पायाभूत सुविधांचा वापर करते, परंतु याची हमी दिलेली नाही.
///
/// # Examples
///
/// डीफॉल्ट पूर्णांक आणि फ्लोट प्रकार मुद्रित करते.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}