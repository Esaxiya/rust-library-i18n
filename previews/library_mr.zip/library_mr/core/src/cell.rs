//! सामायिक करण्यायोग्य बदलण्यायोग्य कंटेनर
//!
//! Rust मेमरी सुरक्षा या नियमावर आधारित आहे: ऑब्जेक्ट `T` दिल्यास, फक्त पुढील पैकी एक असणे शक्य आहे:
//!
//! - ऑब्जेक्टला अनेक अपरिवर्तनीय संदर्भ (`&T`) (ज्यांना **अलियासिंग** देखील म्हणतात).
//! - ऑब्जेक्टला एक परिवर्तनीय संदर्भ (`&mut T`)(ज्याला **उत्परिवर्तन** देखील म्हणतात).
//!
//! हे Rust कंपाईलरद्वारे लागू केले गेले आहे.तथापि, अशी परिस्थिती आहे जेथे हा नियम पुरेसा लवचिक नाही.काहीवेळा ऑब्जेक्टवर अनेक संदर्भ असणे आवश्यक असते आणि तरीही त्यास फेरबदल करणे आवश्यक असते.
//!
//! शेअरेबल बदलण्यायोग्य कंटेनर अलियासिंगच्या उपस्थितीतदेखील नियंत्रित पद्धतीने परिवर्तनास परवानगी देण्यासाठी अस्तित्त्वात आहेत.[`Cell<T>`] आणि [`RefCell<T>`] दोघेही एका-थ्रेडेड मार्गाने हे करण्याची परवानगी देतात.
//! तथापि, `Cell<T>` किंवा `RefCell<T>` दोन्हीही धागा सुरक्षित नाहीत (ते [`Sync`] अंमलात आणत नाहीत).
//! आपल्याला एकाधिक थ्रेड्समध्ये अलियासिंग आणि उत्परिवर्तन करण्याची आवश्यकता असल्यास [`Mutex<T>`], [`RwLock<T>`] किंवा [`atomic`] प्रकार वापरणे शक्य आहे.
//!
//! `Cell<T>` आणि `RefCell<T>` प्रकारची मूल्ये सामायिक केलेल्या संदर्भांद्वारे बदलली जाऊ शकतात (उदा
//! सामान्य `&T` प्रकार), तर बहुतेक झेडआरस्ट ० झेड प्रकार केवळ अद्वितीय (`&म्युट टी`) संदर्भांद्वारे बदलले जाऊ शकतात.
//! आम्ही म्हणतो की `Cell<T>` आणि `RefCell<T>` 'आनुवंशिक उत्परिवर्तनशीलता' दर्शविणार्‍या ठराविक Rust प्रकारांच्या विपरित 'आतील अंतर्गत बदल' प्रदान करतात.
//!
//! सेल प्रकार दोन फ्लेवर्समध्ये आढळतातः एक्स0२ एक्स आणि एक्स ०१ एक्स.एक्स0 एक्स एक्स आणि एक्स-एक्समध्ये मूल्ये हलवून आतील परिवर्तनशीलता लागू करते.
//! मूल्यांच्या ऐवजी संदर्भ वापरण्यासाठी, फेर बदलण्यापूर्वी लेखन लॉक मिळवून `RefCell<T>` प्रकार वापरणे आवश्यक आहे.`Cell<T>` सद्य आतील मूल्य पुनर्प्राप्त आणि बदलण्यासाठी पद्धती प्रदान करते:
//!
//!  - [`Copy`] लागू करणार्‍या प्रकारांसाठी, [`get`](Cell::get) पद्धत सध्याचे अंतर्गत मूल्य प्राप्त करते.
//!  - [`Default`] लागू करणार्‍या प्रकारांसाठी, [`take`](Cell::take) पद्धत वर्तमान आतील मूल्यास [`Default::default()`] ने पुनर्स्थित करते आणि पुनर्स्थित केलेले मूल्य परत करते.
//!  - सर्व प्रकारांसाठी, एक्स 100 एक्स पद्धत वर्तमान आतील मूल्याची जागा घेते आणि पुनर्स्थित केलेले मूल्य परत करते आणि एक्स 0 एक्स एक्स पद्धत एक्स0 2 एक्स वापरते आणि आतील मूल्य परत करते.
//!  याव्यतिरिक्त, [`set`](Cell::set) पद्धत आंतरिक मूल्याऐवजी पुनर्स्थित केलेली मूल्य सोडते.
//!
//! `RefCell<T>` 'डायनामिक बोरिंग' लागू करण्यासाठी Rust चे जीवनकाळ वापरते, ही प्रक्रिया ज्याद्वारे एखादी व्यक्ती आंतरिक मूल्यात तात्पुरती, अनन्य, परस्पर बदल करू शकते.
//! `रेफसेल साठी कर्ज<T>Z चे 'टाइम रनटाइम' ट्रॅक केले जातात, झेडआरस्ट0 झेडच्या मूळ संदर्भ प्रकारांच्या विपरीत जे संकलित वेळी संपूर्णपणे स्थिरपणे ट्रॅक केले जातात.
//! कारण `RefCell<T>` कर्ज गतिमान आहे जे आधीच परस्पर कर्ज घेतलेले मूल्य घेण्याचा प्रयत्न करणे शक्य आहे;जेव्हा हे होते तेव्हा त्याचा परिणाम panic थ्रेडमध्ये होतो.
//!
//! # आतील परिवर्तनशीलता कधी निवडायची
//!
//! अधिक सामान्य वारसा मिळालेला बदल, ज्यामध्ये मूल्य बदलण्यासाठी अद्वितीय प्रवेश असणे आवश्यक आहे, ही एक मुख्य भाषा घटक आहे जी पॉइंटर्स अलियासिंगबद्दल जोरदारपणे तर्क करण्यास आणि क्रॅश बगला प्रतिबंधित करण्यासाठी झेडआरस्ट0 झेडला सक्षम करते.
//! त्यामूळे, वारसा मिळालेला परिवर्तनाला प्राधान्य दिले जाते आणि अंतर्गत बदल ही शेवटच्या रिसॉर्टची गोष्ट असते.
//! सेल प्रकार परिवर्तनास सक्षम करतात जिथे ते अन्यथा अनुमत केले जाऊ शकत नाही, असे प्रसंग आहेत जेव्हा आंतरिक उत्परिवर्तन योग्य असू शकते किंवा *अगदी* वापरणे आवश्यक आहे, उदा.
//!
//! * अदलाबदल करणार्‍या एखाद्या गोष्टीचे परिवर्तनशील 'inside' सादर करीत आहे
//! * तार्किक-अपरिवर्तनीय पद्धतींची अंमलबजावणी तपशील.
//! * [`Clone`] ची अंमलबजावणी बदलत आहे.
//!
//! ## अदलाबदल करणार्‍या एखाद्या गोष्टीचे परिवर्तनशील 'inside' सादर करीत आहे
//!
//! [`Rc<T>`] आणि [`Arc<T>`] सह बरेच सामायिक स्मार्ट पॉईंटर प्रकार, कंटेनर प्रदान करतात जे क्लोन केले जाऊ शकतात आणि एकाधिक पक्षांमध्ये सामायिक केले जाऊ शकतात.
//! अंतर्भूत मूल्ये गुणाकार-अलाइज्ड असू शकतात म्हणूनच, ते केवळ X01 एक्स सह घेतले जाऊ शकतात, `&mut` नव्हे.
//! सेलशिवाय या स्मार्ट पॉईंटर्समधील डेटा बदलणे अशक्य आहे.
//!
//! उत्परिवर्तनाचा पुनर्विचार करण्यासाठी सामायिक पॉईंटर प्रकारांमध्ये `RefCell<T>` लावणे फार सामान्य आहे:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // डायनॅमिक कर्जाची व्याप्ती मर्यादित करण्यासाठी नवीन ब्लॉक तयार करा
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // लक्षात ठेवा आम्ही कॅशेचे मागील कर्ज वाया घालवू दिले नसते तर त्यानंतरचे कर्ज एक गतिशील थ्रेड panic होऊ शकते.
//!     //
//!     // हे `RefCell` वापरण्याचा मोठा धोका आहे.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! लक्षात घ्या की हे उदाहरण `Rc<T>` वापरते, `Arc<T>` नाही.`रेफसेल<T>single s एकल-थ्रेडेड परिस्थितीसाठी आहेत.जर आपल्याला बहु-थ्रेडेड परिस्थितीत सामायिकरित परिवर्तनाची आवश्यकता असेल तर [`RwLock<T>`] किंवा [`Mutex<T>`] वापरण्याचा विचार करा.
//!
//! ## तार्किक-अपरिवर्तनीय पद्धतींची अंमलबजावणी तपशील
//!
//! कधीकधी "under the hood" मध्ये उत्परिवर्तन होत असल्याचे एपीआयमध्ये उघड न करणे इष्ट असू शकते.
//! हे असे होऊ शकते कारण तार्किकरित्या ऑपरेशन अचल आहे, परंतु उदा. कॅशिंग अंमलबजावणीस उत्परिवर्तन करण्यास भाग पाडते;किंवा कारण आपण trait पद्धत अंमलात आणण्यासाठी उत्परिवर्तन नियोजित केले पाहिजे जी `&self` घेण्यासाठी मूळतः परिभाषित केली गेली होती.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // महाग गणना येथे आहे
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## `Clone` ची अंमलबजावणी बदलत आहे
//!
//! हे फक्त मागीलचे एक विशेष, परंतु सामान्य प्रकरण आहे: अपरिवर्तनीय असल्याचे दिसून येणार्‍या ऑपरेशन्ससाठी परिवर्तनीयपणा लपवित आहे.
//! [`clone`](Clone::clone) पद्धतीने स्रोत मूल्य बदलू नये आणि `&mut self` न घेता `&self` घेण्याची घोषणा केली जाईल.
//! म्हणून, `clone` पद्धतीत उद्भवणार्‍या कोणत्याही उत्परिवर्तनासाठी सेल प्रकार वापरणे आवश्यक आहे.
//! उदाहरणार्थ, [`Rc<T>`] त्याच्या संदर्भ संख्या `Cell<T>` मध्ये देखरेख करते.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// एक बदलण्यायोग्य मेमरी स्थान.
///
/// # Examples
///
/// या उदाहरणात, आपण हे पाहू शकता की एक्स 100 एक्स एका अपरिवर्तनीय संरचनेत उत्परिवर्तन सक्षम करते.
/// दुसर्‍या शब्दांत, हे एक्स 100 एक्स सक्षम करते.
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // त्रुटी: `my_struct` अचल आहे
/// // my_struct.regular_field =नवीन_मूल्य;
///
/// // कार्येः जरी `my_struct` अचल आहे, `special_field` एक `Cell` आहे,
/// // जे नेहमी बदलू शकते
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// अधिकसाठी [module-level documentation](self) पहा.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// टी साठी एक्स 0 एक्स एक्स मूल्यासह एक एक्स 100 एक्स तयार करते.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// दिले मूल्य असलेले एक नवीन `Cell` तयार करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// समाविष्ट मूल्य सेट करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// दोन सेलची व्हॅल्यू अदलाबदल करते.
    /// `std::mem::swap` मधील फरक हा आहे की या कार्यासाठी `&mut` संदर्भ आवश्यक नाही.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // सुरक्षितता: वेगळ्या धाग्यांमधून कॉल केल्यास हे धोकादायक असू शकते, परंतु एक्स 100 एक्स
        // हे `!Sync` आहे जेणेकरून असे होणार नाही.
        // हे कोणतेही पॉइंटर देखील अवैध ठरणार नाही कारण `Cell` या `सेल`पैकी कोणत्याही एकात सूचित करणार नाही याची खात्री करते.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// `val` सह असलेले मूल्य पुनर्स्थित करते आणि जुने असलेले मूल्य परत करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // सुरक्षितताः वेगळ्या धाग्यातून कॉल केल्यास डेटा रेस होऊ शकतात,
        // परंतु `Cell` हे X01 एक्स आहे जेणेकरून असे होणार नाही.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// मूल्य अन्रॅप करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// समाविष्ट केलेल्या मूल्याची एक प्रत परत करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // सुरक्षितताः वेगळ्या धाग्यातून कॉल केल्यास डेटा रेस होऊ शकतात,
        // परंतु `Cell` हे X01 एक्स आहे जेणेकरून असे होणार नाही.
        unsafe { *self.value.get() }
    }

    /// फंक्शन वापरून असलेले मूल्य अद्यतनित करते आणि नवीन मूल्य परत करते.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// या सेलमधील मूळ डेटावर एक कच्चा पॉईंटर मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// अंतर्निहित डेटाचा बदलणारा संदर्भ मिळवते.
    ///
    /// हा कॉल `Cell` परस्पर कर्ज घेतो (कंपाईल वेळी) जो आपल्याकडे फक्त संदर्भ आहे याची हमी देतो.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// `&mut T` वरून `&Cell<T>` मिळवते
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // सुरक्षितता: `&mut` अनन्य प्रवेश सुनिश्चित करते.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// त्या जागेवर `Default::default()` सोडून सेलचे मूल्य घेते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// `&Cell<[T]>` वरून `&[Cell<T>]` मिळवते
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // सुरक्षितता: `Cell<T>` मध्ये `T` प्रमाणेच मेमरी लेआउट आहे.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// गतिकरित्या तपासलेल्या कर्जाच्या नियमांसह बदलण्यायोग्य मेमरी स्थान
///
/// अधिकसाठी [module-level documentation](self) पहा.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// [`RefCell::try_borrow`] द्वारे परत एक त्रुटी.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// [`RefCell::try_borrow_mut`] द्वारे परत एक त्रुटी.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// सकारात्मक मूल्ये सक्रिय `Ref` च्या संख्येचे प्रतिनिधित्व करतात.नकारात्मक मूल्ये सक्रिय `RefMut` च्या संख्येचे प्रतिनिधित्व करतात.
// एकाधिक `RefMut`s केवळ एका वेळी सक्रिय होऊ शकतात जर ते `RefCell` (उदा. स्लाइसच्या भिन्न श्रेणी) चे भिन्न, नॉनओव्हरेपिंग घटकांचा संदर्भ घेतात.
//
// `Ref` आणि `RefMut` हे दोन्ही आकारात दोन शब्द आहेत आणि म्हणूनच `usize` श्रेणीच्या अर्ध्या ओव्हरफ्लोसाठी कधीही पुरेसे `रेफरी किंवा` रेफमूट्स अस्तित्वात नसतील.
// अशा प्रकारे, एक `BorrowFlag` कदाचित कधीच ओव्हरफ्लो किंवा अंडरफ्लो होणार नाही.
// तथापि, ही हमी नाही, कारण पॅथॉलॉजिकल प्रोग्राम वारंवार बनवू शकतो आणि नंतर एक्स 100 एक्स `रेफ्रेस किंवा` रेफमूट्स.
// अशाप्रकारे, सर्व कोडने स्पष्टपणे न वाहण्यासाठी ओव्हरफ्लो आणि अंडरफ्लोची तपासणी करणे आवश्यक आहे किंवा ओव्हरफ्लो किंवा अंडरफ्लो झाल्यास कमीतकमी योग्य रीतीने वागले पाहिजे (उदा. एक्स 100 एक्स पहा).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// `value` असलेले एक नवीन `RefCell` तयार करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// गुंडाळलेले मूल्य परत करून, `RefCell` घेते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // हे कार्य `self` (`RefCell`) मूल्यानुसार घेते, कंपाईलर हे सध्या कर्ज घेतले नसल्याचे सत्यापित करते.
        //
        self.value.into_inner()
    }

    /// गुंडाळलेल्या किंमतीला नवीनसह बदलविते, जुन्या मूल्याची परतफेड करते, त्यापैकी एकाही डीनाइटीलायझेशनशिवाय.
    ///
    ///
    /// हे कार्य [`std::mem::replace`](../mem/fn.replace.html) शी संबंधित आहे.
    ///
    /// # Panics
    ///
    /// मूल्य सध्या कर्ज घेत असल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// `f` वरून नवीन लपवून गुंडाळलेल्या जागेचे मूल्य बदलविते, जुने मूल्य परत केल्यावर, एकाचेही मूल्य निर्दिष्ट न करता.
    ///
    ///
    /// # Panics
    ///
    /// मूल्य सध्या कर्ज घेत असल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// `self` चे गुंडाळलेल्या मूल्याचे `other` च्या लपेटलेल्या मूल्यासह अदलाबदल करते, एकापैकी एकही निर्दिष्ट न करता.
    ///
    ///
    /// हे कार्य [`std::mem::swap`](../mem/fn.swap.html) शी संबंधित आहे.
    ///
    /// # Panics
    ///
    /// सध्या `RefCell` मधील कोणत्याही किंमतीचे कर्ज घेतल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// त्वरित लपेटलेले मूल्य घेतो.
    ///
    /// परत केलेले `Ref` व्याप्ती सोडत नाही तोपर्यंत कर्ज टिकते.
    /// एकाच वेळी एकापेक्षा जास्त अपरिवर्तनीय कर्ज घेतले जाऊ शकते.
    ///
    /// # Panics
    ///
    /// मूल्य सध्या परस्पर कर्ज घेतले असल्यास झेडपॅनिक्स 0 झेड.
    /// नॉन-पॅनीकिंग व्हेरिएंटसाठी, [`try_borrow`](#method.try_borrow) वापरा.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// झेडस्पॅनिक0 झेडचे एक उदाहरणः
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// त्वरित गुंडाळलेल्या किंमतीचे कर्ज घेतो, मूल्य सध्या परस्पर कर्ज घेतल्यास त्रुटी परत करेल.
    ///
    ///
    /// परत केलेले `Ref` व्याप्ती सोडत नाही तोपर्यंत कर्ज टिकते.
    /// एकाच वेळी एकापेक्षा जास्त अपरिवर्तनीय कर्ज घेतले जाऊ शकते.
    ///
    /// हे [`borrow`](#method.borrow) चे नॉन-पॅनीकिंग व्हेरिएंट आहे.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // सुरक्षितता: `BorrowRef` हे सुनिश्चित करते की तेथे केवळ अचल प्रवेश आहे
            // कर्ज घेतलेल्या किंमतीवर.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// आपोआप गुंडाळलेले मूल्य घेतो.
    ///
    /// हे कर्ज परत आलेल्या `RefMut` पर्यंत किंवा त्यामधून व्युत्पन्न केलेल्या सर्व `RefMut`s पर्यंत सोडते.
    ///
    /// हे कर्ज सक्रिय असताना मूल्य घेतले जाऊ शकत नाही.
    ///
    /// # Panics
    ///
    /// मूल्य सध्या कर्ज घेत असल्यास Panics.
    /// नॉन-पॅनीकिंग व्हेरिएंटसाठी, [`try_borrow_mut`](#method.try_borrow_mut) वापरा.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// झेडस्पॅनिक0 झेडचे एक उदाहरणः
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// वॅपेटेड व्हॅल्यूचे कर्ज घेतल्यास मूल्य सध्या कर्ज घेतल्यास त्रुटी परत करते.
    ///
    ///
    /// हे कर्ज परत आलेल्या `RefMut` पर्यंत किंवा त्यामधून व्युत्पन्न केलेल्या सर्व `RefMut`s पर्यंत सोडते.
    /// हे कर्ज सक्रिय असताना मूल्य घेतले जाऊ शकत नाही.
    ///
    /// हे [`borrow_mut`](#method.borrow_mut) चे नॉन-पॅनीकिंग व्हेरिएंट आहे.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // सुरक्षितता: `BorrowRef` अनन्य प्रवेशाची हमी देते.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// या सेलमधील मूळ डेटावर एक कच्चा पॉईंटर मिळवते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// अंतर्निहित डेटाचा बदलणारा संदर्भ मिळवते.
    ///
    /// हा कॉल परस्पररित्या (कंपाईल-वेळी) `RefCell` कर्ज घेतो म्हणून डायनॅमिक चेकची आवश्यकता नाही.
    ///
    /// तथापि सावधगिरी बाळगा: ही पद्धत `self` परिवर्तनीय होण्याची अपेक्षा करते, जे सामान्यत: `RefCell` वापरताना नसते.
    ///
    /// `self` बदलण्यायोग्य नसल्यास त्याऐवजी [`borrow_mut`] पद्धत पहा.
    ///
    /// तसेच, कृपया लक्षात घ्या की ही पद्धत केवळ विशिष्ट परिस्थितीसाठीच आहे आणि सामान्यत: आपल्यास इच्छित नसते.
    /// शंका असल्यास त्याऐवजी [`borrow_mut`] वापरा.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// `RefCell` च्या कर्ज घेणार्‍या स्थितीवरील लीक रक्षकाचा प्रभाव पूर्ववत करा.
    ///
    /// हा कॉल [`get_mut`] सारखाच आहे परंतु अधिक विशिष्ट आहे.
    /// कोणतेही कर्ज अस्तित्त्वात नाही हे सुनिश्चित करण्यासाठी ते परस्पर `RefCell` कर्ज घेते आणि नंतर सामायिक केलेल्या कर्जाचे राज्य ट्रॅकिंग रीसेट करते.
    /// काही `Ref` किंवा `RefMut` कर्ज लीक झाल्यास हे संबंधित आहे.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// त्वरित गुंडाळलेल्या किंमतीचे कर्ज घेतो, मूल्य सध्या परस्पर कर्ज घेतल्यास त्रुटी परत करेल.
    ///
    /// # Safety
    ///
    /// `RefCell::borrow` विपरीत, ही पद्धत असुरक्षित आहे कारण ती एक X01 एक्स परत करत नाही, यामुळे कर्ज घेण्याचा ध्वज अस्पर्श ठेवते.
    /// या पद्धतीने परत केलेला संदर्भ जिवंत असताना `RefCell` कर्ज घेणे ही अपरिभाषित वर्तन आहे.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // सुरक्षितताः आम्ही आता तपासतो की कोणीही आता सक्रियपणे लिहित नाही, पण तसे आहे
            // परत केलेला संदर्भ यापुढे वापरल्याशिवाय कोणीही लिहित नाही याची खात्री करण्याची कॉलरची जबाबदारी आहे.
            // तसेच, एक्स 0 एक्स एक्स एक्स 2 एक्स च्या मालकीच्या मूल्यास संदर्भित करते आणि अशा प्रकारे `self` च्या आजीवन कालावधीसाठी वैध असल्याची हमी दिलेली आहे.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// त्याच्या जागी `Default::default()` सोडून, गुंडाळलेले मूल्य घेते.
    ///
    /// # Panics
    ///
    /// मूल्य सध्या कर्ज घेत असल्यास Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// मूल्य सध्या परस्पर कर्ज घेतले असल्यास झेडपॅनिक्स 0 झेड.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// टी साठी एक्स 0 एक्स एक्स मूल्यासह एक एक्स 100 एक्स तयार करते.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// सध्या `RefCell` मधील कोणत्याही किंमतीचे कर्ज घेतल्यास Panics.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// सध्या `RefCell` मधील कोणत्याही किंमतीचे कर्ज घेतल्यास Panics.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// सध्या `RefCell` मधील कोणत्याही किंमतीचे कर्ज घेतल्यास Panics.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// सध्या `RefCell` मधील कोणत्याही किंमतीचे कर्ज घेतल्यास Panics.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// सध्या `RefCell` मधील कोणत्याही किंमतीचे कर्ज घेतल्यास Panics.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// सध्या `RefCell` मधील कोणत्याही किंमतीचे कर्ज घेतल्यास Panics.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// सध्या `RefCell` मधील कोणत्याही किंमतीचे कर्ज घेतल्यास Panics.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // वाढती कर्ज या प्रकरणांमध्ये न वाचनीय मूल्य (<=0) मध्ये परिणाम होऊ शकतेः
            // 1. ते <0 होते, म्हणजेच येथे कर्ज लिहित आहे, म्हणून आम्ही Rust च्या संदर्भ अलियासिंग नियमांमुळे वाचन कर्जास परवानगी देऊ शकत नाही
            // 2.
            // हे एक्स 100 एक्स होते (वाचनात जास्तीत जास्त रक्कम) आणि ती एक्स01 एक्स मध्ये वाढली (लेखनाची जास्तीत जास्त रक्कम) त्यामुळे आम्ही अतिरिक्त वाचनासाठी परवानगी घेऊ शकत नाही कारण आयसाइझ इतक्या वाचलेल्या कर्जाचे प्रतिनिधित्व करू शकत नाही (हे फक्त तेव्हाच होऊ शकते आपण कमी प्रमाणात constant रेफरीपेक्षा अधिक mem::forget करता, जे चांगली प्रॅक्टिस नाही)
            //
            //
            //
            //
            None
        } else {
            // वाढत्या कर्ज घेण्यामुळे या प्रकरणांमध्ये वाचन मूल्य (> 0) होऊ शकते:
            // 1. ते=0 होते, म्हणजे ते कर्ज घेतले नव्हते, आणि आम्ही प्रथम वाचलेले कर्ज घेत आहोत
            // 2. ते> 0 आणि <isize::MAX होते, म्हणजे
            // तेथे वाचनाची कर्जे होती आणि आयझाइझ हे आणखी एक वाचन कर्ज असण्यासाठी प्रतिनिधित्व करण्यासाठी इतके मोठे आहे
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // हा रेफ अस्तित्वात असल्याने आम्हाला माहित आहे की कर्ज ध्वज एक वाचन कर्ज आहे.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // लेखन उधळपट्टीमध्ये ओव्हरफ्लो होण्यापासून कर्जाच्या काउंटरला प्रतिबंध करा.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// `RefCell` बॉक्समधील मूल्याच्या कर्जाच्या संदर्भात लपेटते.
/// `RefCell<T>` वरून कायमस्वरुपी कर्जाच्या मूल्यासाठी एक रॅपर प्रकार.
///
/// अधिकसाठी [module-level documentation](self) पहा.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// एक `Ref` कॉपी करते.
    ///
    /// `RefCell` आधीपासूनच कायमचे कर्ज घेतले आहे, म्हणून हे अपयशी ठरू शकत नाही.
    ///
    /// हे एक संबंधित कार्य आहे जे `Ref::clone(...)` म्हणून वापरण्याची आवश्यकता आहे.
    /// `Clone` ची अंमलबजावणी करण्यासाठी `Clone` अंमलबजावणी किंवा एक पद्धत `r.borrow().clone()` च्या व्यापक वापरामध्ये हस्तक्षेप करेल.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// कर्ज घेतलेल्या डेटाच्या घटकासाठी नवीन `Ref` बनवते.
    ///
    /// `RefCell` आधीपासूनच कायमचे कर्ज घेतले आहे, म्हणून हे अपयशी ठरू शकत नाही.
    ///
    /// हे एक संबंधित कार्य आहे जे `Ref::map(...)` म्हणून वापरण्याची आवश्यकता आहे.
    /// `Deref` द्वारे वापरल्या जाणार्‍या `RefCell` मधील सामग्रीवर त्याच नावाच्या पद्धतींमध्ये पद्धत हस्तक्षेप करेल.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// कर्ज घेतलेल्या डेटाच्या वैकल्पिक घटकासाठी नवीन `Ref` बनवते.
    /// क्लोजरने `None` परत केल्यास मूळ रक्षक `Err(..)` म्हणून परत केला जाईल.
    ///
    /// `RefCell` आधीपासूनच कायमचे कर्ज घेतले आहे, म्हणून हे अपयशी ठरू शकत नाही.
    ///
    /// हे एक संबंधित कार्य आहे जे `Ref::filter_map(...)` म्हणून वापरण्याची आवश्यकता आहे.
    /// `Deref` द्वारे वापरल्या जाणार्‍या `RefCell` मधील सामग्रीवर त्याच नावाच्या पद्धतींमध्ये पद्धत हस्तक्षेप करेल.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// कर्ज घेतलेल्या डेटाच्या भिन्न घटकांसाठी एकाधिक `रेफ मध्ये एक `Ref` विभाजित करते.
    ///
    /// `RefCell` आधीपासूनच कायमचे कर्ज घेतले आहे, म्हणून हे अपयशी ठरू शकत नाही.
    ///
    /// हे एक संबंधित कार्य आहे जे `Ref::map_split(...)` म्हणून वापरण्याची आवश्यकता आहे.
    /// `Deref` द्वारे वापरल्या जाणार्‍या `RefCell` मधील सामग्रीवर त्याच नावाच्या पद्धतींमध्ये पद्धत हस्तक्षेप करेल.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// मूलभूत डेटाच्या संदर्भात रूपांतरित करा.
    ///
    /// अंतर्निहित `RefCell` पुन्हा कधीही परस्पर कर्ज घेतले जाऊ शकत नाही आणि नेहमीच कायमचे कर्ज घेतलेले दिसेल.
    ///
    /// निरंतर संदर्भांपेक्षा जास्त गळती घेणे चांगले नाही.
    /// एकूणच थोड्या संख्येने गळती उद्भवल्यास एक्स00 एक्स पुन्हा अचलपणे परत घेतले जाऊ शकते.
    ///
    /// हे एक संबंधित कार्य आहे जे `Ref::leak(...)` म्हणून वापरण्याची आवश्यकता आहे.
    /// `Deref` द्वारे वापरल्या जाणार्‍या `RefCell` मधील सामग्रीवर त्याच नावाच्या पद्धतींमध्ये पद्धत हस्तक्षेप करेल.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // हा रेफ विसरून आम्ही हे सुनिश्चित करतो की रेफसेलमधील कर्ज घेणारा काउंटर आजीवन `'b` मध्ये पुन्हा वापरात येऊ शकत नाही.
        // संदर्भ ट्रॅकिंग स्थिती रीसेट करण्यासाठी कर्ज घेतलेल्या रेफसेलचा अनोखा संदर्भ आवश्यक असेल.
        // मूळ सेलमधून पुढे कोणतेही बदलनीय संदर्भ तयार केले जाऊ शकत नाहीत.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// कर्ज घेतलेल्या डेटाच्या घटकासाठी नवीन एक्स 100 एक्स बनवते, उदा. एनम प्रकार.
    ///
    /// `RefCell` आधीच परस्पर कर्ज घेतले आहे, त्यामुळे हे अपयशी ठरू शकत नाही.
    ///
    /// हे एक संबंधित कार्य आहे जे `RefMut::map(...)` म्हणून वापरण्याची आवश्यकता आहे.
    /// `Deref` द्वारे वापरल्या जाणार्‍या `RefCell` मधील सामग्रीवर त्याच नावाच्या पद्धतींमध्ये पद्धत हस्तक्षेप करेल.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): कर्ज-चेकचे निराकरण करा
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// कर्ज घेतलेल्या डेटाच्या वैकल्पिक घटकासाठी नवीन `RefMut` बनवते.
    /// क्लोजरने `None` परत केल्यास मूळ रक्षक `Err(..)` म्हणून परत केला जाईल.
    ///
    /// `RefCell` आधीच परस्पर कर्ज घेतले आहे, त्यामुळे हे अपयशी ठरू शकत नाही.
    ///
    /// हे एक संबंधित कार्य आहे जे `RefMut::filter_map(...)` म्हणून वापरण्याची आवश्यकता आहे.
    /// `Deref` द्वारे वापरल्या जाणार्‍या `RefCell` मधील सामग्रीवर त्याच नावाच्या पद्धतींमध्ये पद्धत हस्तक्षेप करेल.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): कर्ज-चेकचे निराकरण करा
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // सुरक्षा: कार्य कालावधीसाठी विशेष संदर्भ ठेवते
        // त्याच्या कॉलचे `orig` द्वारे, आणि पॉईंटर मध्ये केवळ डि-रेफरेन्स आहे फंक्शन कॉलमध्ये अनन्य संदर्भ कधीही सुटू देत नाही.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // सुरक्षा: वरील प्रमाणेच.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// कर्ज घेतलेल्या डेटाच्या भिन्न घटकांसाठी एकाधिक `रीफमूट्स मध्ये एक एक्स 100 एक्स विभाजित करते.
    ///
    /// दोन्ही परत न येईपर्यंत अंतर्निहित `RefCell` परस्पर कर्ज घेतले जाईल `रेफमुट्स चे कार्यक्षेत्र बाहेर जाणार नाही.
    ///
    /// `RefCell` आधीच परस्पर कर्ज घेतले आहे, त्यामुळे हे अपयशी ठरू शकत नाही.
    ///
    /// हे एक संबंधित कार्य आहे जे `RefMut::map_split(...)` म्हणून वापरण्याची आवश्यकता आहे.
    /// `Deref` द्वारे वापरल्या जाणार्‍या `RefCell` मधील सामग्रीवर त्याच नावाच्या पद्धतींमध्ये पद्धत हस्तक्षेप करेल.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// मूलभूत डेटाच्या परिवर्तनीय संदर्भात रूपांतरित करा.
    ///
    /// मूळ `RefCell` पुन्हा कर्ज घेऊ शकत नाही आणि परत परस्पर कर्ज घेतलेले दिसेल, ज्यामुळे परतलेला संदर्भ केवळ आतील बाजू बनतो.
    ///
    ///
    /// हे एक संबंधित कार्य आहे जे `RefMut::leak(...)` म्हणून वापरण्याची आवश्यकता आहे.
    /// `Deref` द्वारे वापरल्या जाणार्‍या `RefCell` मधील सामग्रीवर त्याच नावाच्या पद्धतींमध्ये पद्धत हस्तक्षेप करेल.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // हे बोनरॅफमूट विसरून आम्ही हे सुनिश्चित करतो की रेफसेल मधील कर्ज काउंटर एक्सएक्सएक्सएक्सच्या काळात परत वापरात येऊ शकत नाही.
        // संदर्भ ट्रॅकिंग स्थिती रीसेट करण्यासाठी कर्ज घेतलेल्या रेफसेलचा अनोखा संदर्भ आवश्यक असेल.
        // मूळ कर्तृत्वातून या संदर्भात यापुढे कोणतेही संदर्भ तयार केले जाऊ शकत नाहीत, ज्यामुळे सध्याचे कर्ज उरलेल्या उर्वरित आयुष्याचा एकमात्र संदर्भ बनतो.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: एक्स 100 एक्स विपरीत, नवीन प्रारंभिक तयार करण्यासाठी म्हणतात
        // परिवर्तनीय संदर्भ आणि म्हणून सध्या कोणतेही विद्यमान संदर्भ नसावेत.
        // अशा प्रकारे, क्लोन वेतनवाढ म्युटेबल रीकाउंटमध्ये असताना आम्ही येथे केवळ यूयूएसईडी वरून यूएसयूएसडी, 1 वर जाण्यास स्पष्टपणे परवानगी देतो.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // क्लोन्स एक एक्स 100 एक्स.
    //
    // हे फक्त तेव्हाच वैध असेल जेव्हा प्रत्येक एक्स 100 एक्स मूळ ऑब्जेक्टच्या वेगळ्या, नॉनओव्हरेपिंग श्रेणीच्या फेरफार संदर्भाचा मागोवा घेण्यासाठी वापरला गेला असेल.
    //
    // हे क्लोन इनप्लिमेंटमध्ये नाही जेणेकरुन कोड त्याला अंतर्भूतपणे कॉल करीत नाही.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // कर्ज काउंटरला वाहण्यापासून प्रतिबंधित करा.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// `RefCell<T>` वरून परस्पर कर्ज घेतलेल्या मूल्यांसाठी एक रॅपर प्रकार.
///
/// अधिकसाठी [module-level documentation](self) पहा.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// झेडआरस्ट0 झेडमध्ये अंतर्गत बदल करण्याकरिता मुख्य आदिम.
///
/// आपल्याकडे संदर्भ `&T` असल्यास, सामान्यत: Rust मध्ये कंपाईलर `&T` अचल डेटाकडे निर्देश केलेल्या ज्ञानावर आधारित ऑप्टिमायझेशन करते.डेटा परिवर्तीत करणे, उदाहरणार्थ उर्फद्वारे किंवा X03 एक्सला एक्स ०१ एक्स मध्ये रुपांतरित करणे, अपरिभाषित वर्तन मानले जाते.
/// `UnsafeCell<T>` `&T` साठी अपरिवर्तनीय हमीची निवड रद्द करणे: एक सामायिक संदर्भ `&UnsafeCell<T>` बदललेल्या डेटाकडे निर्देश करू शकेल.याला एक्स 100 एक्स म्हणतात.
///
/// इतर सर्व प्रकार जे `Cell<T>` आणि `RefCell<T>` यासारख्या अंतर्गत परिवर्तनास अनुमती देतात, त्यांचा डेटा लपेटण्यासाठी अंतर्गतपणे `UnsafeCell` वापरतात.
///
/// लक्षात घ्या की सामायिक केलेल्या संदर्भांची केवळ अमरत्व हमी `UnsafeCell` द्वारे प्रभावित आहे.बदलण्यायोग्य संदर्भांची विशिष्टता हमी अप्रभावित आहे.एक्सियस 2 एक्स मिळविण्याचा *कोणताही* कायदेशीर मार्ग नाही, अगदी `UnsafeCell<T>` सह देखील नाही.
///
/// `UnsafeCell` एपीआय स्वतः तांत्रिकदृष्ट्या अगदी सोपे आहे: एक्स 100 एक्स आपल्याला त्यातील सामग्रीस एक कच्चा पॉईंटर `*mut T` देतो.तो कच्चा पॉइंटर अचूकपणे वापरण्यासाठी अ‍ॅबस्ट्रॅक्शन डिझाइनर म्हणून _you_ पर्यंत आहे.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// तंतोतंत झेड ० रस्ट ० झेड अलियासिंग नियम काही प्रमाणात प्रवाहात आहेत, परंतु मुख्य मुद्दे विवादित नाहीत:
///
/// - जर आपण सुरक्षित कोडद्वारे प्रवेश करण्यायोग्य आजीवन `'a` (एकतर `&T` किंवा `&mut T` संदर्भ) सह सुरक्षित संदर्भ तयार केला असेल तर (उदाहरणार्थ, आपण तो परत केला म्हणून) आपण त्या डेटाशी कोणत्याही प्रकारे प्रवेश करू नये जे उर्वरित संदर्भातील विरोधाभास असेल. `'a` चे.
/// उदाहरणार्थ, याचा अर्थ असा आहे की आपण `*mut T` वरून `* mut T` घेतल्यास आणि तो `&T` वर कास्ट केल्यास, `T` मधील डेटा अपरिवर्तनीय राहणे आवश्यक आहे (`T` मध्ये सापडलेला कोणताही `UnsafeCell` डेटा नक्कीच) संदर्भ संपुष्टात येईपर्यंत.
/// त्याचप्रमाणे, आपण सेफ कोडवर सोडलेला `&mut T` संदर्भ तयार केल्यास, तो संदर्भ संपेपर्यंत आपण `UnsafeCell` मधील डेटामध्ये प्रवेश करू नये.
///
/// - नेहमीच, आपण डेटा रेस टाळणे आवश्यक आहे.जर एकाधिक थ्रेड्समध्ये समान `UnsafeCell` मध्ये प्रवेश असेल तर इतर सर्व प्रवेशांशी (किंवा अणुशास्त्र वापरा) संबंधित कोणत्याही लेखनास योग्य घटना घडणे आवश्यक आहे.
///
/// योग्य रचनेस सहाय्य करण्यासाठी, खालील परिदृश्यांना एकल-थ्रेडेड कोडसाठी स्पष्टपणे कायदेशीर घोषित केले आहे:
///
/// 1. एक `&T` संदर्भ सेफ कोडवर सोडला जाऊ शकतो आणि तिथे तो इतर `&T` संदर्भांसह सह-अस्तित्वात असू शकतो, परंतु `&mut T` सह नाही
///
/// 2. सेफ कोडवर `&mut T` संदर्भ जारी केला जाऊ शकतो परंतु अन्य `&mut T` किंवा `&T` सह अस्तित्वात नसल्यास.एक `&mut T` नेहमी अद्वितीय असणे आवश्यक आहे.
///
/// लक्षात घ्या की `&UnsafeCell<T>` मधील सामग्रीचे रूपांतरण (इतर `&UnsafeCell<T>` संदर्भ ऊर्फ सेल असतानाही) ठीक आहे (आपण वरील हल्लेखोरांना इतर मार्गाने अंमलात आणाल तर), बहुविध `&mut UnsafeCell<T>` उपनावे असणे अद्याप अपरिभाषित वर्तन आहे.
/// म्हणजेच `UnsafeCell` हे एक रॅपर आहे जे एक्स 100 एक्ससह एक्सएक्स 3 एक्स संदर्भात विशेष संवाद साधण्यासाठी डिझाइन केलेले आहे);_exclusive_ accesses (_e.g._ वर व्यवहार करताना, `&mut UnsafeCell<_>` मार्फत कोणतीही जादू केली जात नाही: त्या `&mut` कर्जाच्या कालावधीसाठी सेल किंवा गुंडाळलेला मूल्य एकतर ठेवला जाऊ शकत नाही.
///
/// हे [`.get_mut()`] अ‍ॅक्सेसरद्वारे शोकेस केले गेले आहे, जे एक _safe_ getter आहे जे `&mut T` देते.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// सेलचे अलियासिंग असणारे अनेक संदर्भ असूनही एक्स एक्स एक्स मधील मजकूर ध्वनी रूपांतरित कसे करावे याचे उदाहरण देणारे हे येथे एक उदाहरण आहे:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // समान `x` चे एकाधिक/समवर्ती/सामायिक संदर्भ मिळवा.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // सुरक्षितता: या कार्यक्षेत्रात `x` च्या सामग्रीसंदर्भात इतर कोणतेही संदर्भ नाहीत.
///     // आमचे प्रभावीपणे अद्वितीय आहे.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- कर्ज-+
///     *p1_exclusive += 27; // |
/// } // <---------- या बिंदूच्या पलीकडे जाऊ शकत नाही -------------------+
///
/// unsafe {
///     // सुरक्षा: या कार्यक्षेत्रात कोणासही `x` च्या सामग्रीवर अनन्य प्रवेश असण्याची अपेक्षा नाही,
///     // जेणेकरून आपल्याकडे एकाच वेळी अनेक सामायिक प्रवेश होऊ शकतात.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// खालील उदाहरणांद्वारे हे स्पष्ट केले गेले आहे की एक्स एक्स 1 एक्समध्ये एक्सक्लुझिव्ह प्रवेश त्याच्या एक्स 100 एक्समध्ये अनन्य प्रवेश दर्शवितो:
///
/// ```rust
/// #![forbid(unsafe_code)] // अनन्य प्रवेशांसह,
///                         // `UnsafeCell` एक पारदर्शक नो-ऑप रॅपर आहे, म्हणून येथे `unsafe` ची आवश्यकता नाही.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // `x` चा कंपाईल-टाइम-चेक केलेला अनोखा संदर्भ मिळवा.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // विशिष्ट संदर्भासह, आम्ही सामग्री विनामूल्य बदलू शकतो.
/// *p_unique.get_mut() = 0;
/// // किंवा, समकक्षः
/// x = UnsafeCell::new(0);
///
/// // जेव्हा आमच्याकडे मूल्य असते, तेव्हा आम्ही सामग्री विनामूल्य काढू शकतो.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// `UnsafeCell` चे नवीन उदाहरण तयार करते जे निर्दिष्ट मूल्य लपेटेल.
    ///
    ///
    /// पद्धतींद्वारे अंतर्गत मूल्यापर्यंत सर्व प्रवेश म्हणजे एक्स 100 एक्स.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// मूल्य अन्रॅप करते.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// गुंडाळलेल्या मूल्याला एक परिवर्तनीय पॉईंटर मिळतो.
    ///
    /// हे कोणत्याही प्रकारच्या पॉईंटरवर टाकले जाऊ शकते.
    /// `&mut T` वर कास्टिंग करताना प्रवेश अद्वितीय आहे (सक्रिय संदर्भ नाहीत, बदलण्यायोग्य आहेत की नाही याची खात्री करा) आणि `&T` वर कास्ट करताना कोणतेही बदल किंवा म्युटेबल उपनावे चालू नसल्याचे सुनिश्चित करा.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // आम्ही नुकतेच X001 X पासून `T` वर पॉईंटर कास्ट करू शकतो.
        // हे libstd च्या विशेष स्थितीचा गैरफायदा घेतो, वापरकर्त्याच्या कोडची कोणतीही हमी नाही की हे कंपाईलरच्या future आवृत्त्यांमध्ये कार्य करेल!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// अंतर्निहित डेटाचा बदलणारा संदर्भ मिळवते.
    ///
    /// हा कॉल `UnsafeCell` परस्पर कर्ज घेतो (कंपाईल वेळी) जो आपल्याकडे फक्त एकच संदर्भ आहे याची हमी देतो.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// गुंडाळलेल्या मूल्याला एक परिवर्तनीय पॉईंटर मिळतो.
    /// [`get`] मधील फरक हा आहे की हे कार्य कच्चा पॉईंटर स्वीकारते, जे तात्पुरते संदर्भ तयार करणे टाळण्यासाठी उपयुक्त आहे.
    ///
    /// परिणाम कोणत्याही प्रकारच्या पॉईंटरवर टाकला जाऊ शकतो.
    /// `&mut T` वर कास्टिंग करताना प्रवेश अद्वितीय आहे (सक्रिय संदर्भ नाहीत, बदलण्यायोग्य आहेत की नाही याची खात्री करा) आणि `&T` वर कास्ट करताना कोणतेही बदल किंवा म्युटेबल उपनावे चालू नसल्याचे सुनिश्चित करा.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// `UnsafeCell` च्या हळूहळू आरंभ करण्यासाठी `raw_get` आवश्यक आहे, कारण `get` ला कॉल करणे आवश्यक नसलेल्या डेटाचा संदर्भ तयार करणे आवश्यक आहे:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // आम्ही नुकतेच X001 X पासून `T` वर पॉईंटर कास्ट करू शकतो.
        // हे libstd च्या विशेष स्थितीचा गैरफायदा घेतो, वापरकर्त्याच्या कोडची कोणतीही हमी नाही की हे कंपाईलरच्या future आवृत्त्यांमध्ये कार्य करेल!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// टी साठी एक्स 0 एक्स एक्स मूल्यासह एक एक्स 100 एक्स तयार करते.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}