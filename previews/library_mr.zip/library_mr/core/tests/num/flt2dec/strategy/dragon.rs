use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // मिरी खूप हळू आहे
fn exact_sanity_test() {
    // ही चाचणी केवळ मी केवळ गृहित धरू शकत असलेल्या `exp2` लायब्ररी फंक्शनचे कोर्नर-ईश प्रकरण आहे जे आम्ही वापरत असलेल्या सी रनटाइम मध्ये परिभाषित केले आहे.
    // व्हीएस २०१ In मध्ये हे कार्य स्पष्टपणे एक बग होते कारण या चाचणीशी जोडलेले असताना अयशस्वी होते, परंतु व्हीएस २०१ with सह बग निश्चित दिसत आहे कारण चाचणी फक्त ठीक आहे.
    //
    // बग `exp2(-1057)` च्या रिटर्न व्हॅल्यूमध्ये फरक आहे असे दिसते, जिथे व्हीएस 2013 मध्ये ते बिट पॅटर्न 0x2 सह डबल मिळवते आणि व्हीएस 2015 मध्ये ते एक्स 100 एक्स परत करते.
    //
    //
    // आता फक्त इतरत्र कोठेही चाचणी घेतली गेली आहे आणि आता प्रत्येक व्यासपीठाच्या exp2 अंमलबजावणीची चाचणी घेण्यात आम्हाला रस नाही.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}