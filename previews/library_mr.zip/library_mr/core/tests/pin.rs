use core::pin::Pin;

#[test]
fn pin_const() {
    // `Pin` च्या पद्धती स्थिर संदर्भात वापरण्यायोग्य असल्याचे परीक्षण करा

    const POINTER: &'static usize = &2;

    const PINNED: Pin<&'static usize> = Pin::new(POINTER);
    const PINNED_UNCHECKED: Pin<&'static usize> = unsafe { Pin::new_unchecked(POINTER) };
    assert_eq!(PINNED_UNCHECKED, PINNED);

    const INNER: &'static usize = Pin::into_inner(PINNED);
    assert_eq!(INNER, POINTER);

    const INNER_UNCHECKED: &'static usize = unsafe { Pin::into_inner_unchecked(PINNED) };
    assert_eq!(INNER_UNCHECKED, POINTER);

    const REF: &'static usize = PINNED.get_ref();
    assert_eq!(REF, POINTER);

    // Note: `pin_mut_const` चाचणी की `Pin<&mut T>` च्या पद्धती कॉन्टस्ट संदर्भात वापरण्यायोग्य आहेत.
    // कॉन्स्ट एफएन वापरला जातो कारण एक्स 100 एक्स स्थिरतेमध्ये X01 एक्स वापरण्यायोग्य नाही.
    const fn pin_mut_const() {
        let _ = Pin::new(&mut 2).into_ref();
        let _ = Pin::new(&mut 2).get_mut();
        let _ = unsafe { Pin::new(&mut 2).get_unchecked_mut() };
    }

    pin_mut_const();
}