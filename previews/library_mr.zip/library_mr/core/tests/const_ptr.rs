// दोन बाइटवर संरेखित केले
const DATA: [u16; 2] = [u16::from_ne_bytes([0x01, 0x23]), u16::from_ne_bytes([0x45, 0x67])];

const fn unaligned_ptr() -> *const u16 {
    // DATA.as_ptr() दोन बाइट्सवर संरेखित असल्याने, त्यात 1 बाइट जोडून एक अयोगेन्ड * कॉन्ट एक्स 100 एक्स तयार करते
    unsafe { (DATA.as_ptr() as *const u8).add(1) as *const u16 }
}

#[test]
fn read() {
    use core::ptr;

    const FOO: i32 = unsafe { ptr::read(&42 as *const i32) };
    assert_eq!(FOO, 42);

    const ALIGNED: i32 = unsafe { ptr::read_unaligned(&42 as *const i32) };
    assert_eq!(ALIGNED, 42);

    const UNALIGNED_PTR: *const u16 = unaligned_ptr();

    const UNALIGNED: u16 = unsafe { ptr::read_unaligned(UNALIGNED_PTR) };
    assert_eq!(UNALIGNED, u16::from_ne_bytes([0x23, 0x45]));
}

#[test]
fn const_ptr_read() {
    const FOO: i32 = unsafe { (&42 as *const i32).read() };
    assert_eq!(FOO, 42);

    const ALIGNED: i32 = unsafe { (&42 as *const i32).read_unaligned() };
    assert_eq!(ALIGNED, 42);

    const UNALIGNED_PTR: *const u16 = unaligned_ptr();

    const UNALIGNED: u16 = unsafe { UNALIGNED_PTR.read_unaligned() };
    assert_eq!(UNALIGNED, u16::from_ne_bytes([0x23, 0x45]));
}

#[test]
fn mut_ptr_read() {
    const FOO: i32 = unsafe { (&42 as *const i32 as *mut i32).read() };
    assert_eq!(FOO, 42);

    const ALIGNED: i32 = unsafe { (&42 as *const i32 as *mut i32).read_unaligned() };
    assert_eq!(ALIGNED, 42);

    const UNALIGNED_PTR: *mut u16 = unaligned_ptr() as *mut u16;

    const UNALIGNED: u16 = unsafe { UNALIGNED_PTR.read_unaligned() };
    assert_eq!(UNALIGNED, u16::from_ne_bytes([0x23, 0x45]));
}

// #[test]
// fn write() X core::ptr वापरा;
//
//    कॉन्स्ट fn write_aligned()-> i32 mut म्युट रेस=0 द्या;
//        असुरक्षित {
//            ptr::write(&mut res as *mut _, 42);
//        }
//        रेस} कॉन्ट अलाइज्ड: i32 = write_aligned();
//    assert_eq! (ALIGNED, 42);
//
//    कॉन्स्ट fn write_unaligned()-> [u16; 2] mut म्युट टू_लिंग्ड=एक्स00 एक्स;
//        असुरक्षित {unaligned_ptr= (two_aligned.as_mut_ptr()* * u8).add(1) म्हणून * mut u16;
//            ptr: : Writ_unalised (अनइलिंन्डड_प्टर, एक्स ०१ एक्स;} two_align; UN UNALIGNED: [u16; 2] = write_unaligned();
//
//    assert_eq! (UNALIGNED, [u16::from_ne_bytes([0x00, 0x23]), u16::from_ne_bytes([0x45, 0x00])]);
//
//
//
//
//
//
//
//
//
//

// #[test]
// fn mut_ptr_write() {const fn aligned()-> i32 mut म्युट रेस=0 द्या;
//        असुरक्षित { (&mut res as *mut i32).write(42); } रेस} कॉन्ट ALIGNED: i32 = aligned();
//
//    assert_eq! (ALIGNED, 42);
//
//    कॉन्स्ट fn write_unaligned()-> [u16; 2] mut म्युट टू_लिंग्ड=एक्स00 एक्स;
//        असुरक्षित {unaligned_ptr= (two_aligned.as_mut_ptr()* * u8).add(1) म्हणून * mut u16;
//            unaligned_ptr.write_unaligned(u16::from_ne_bytes([0x23, 0x45]));
//        }
//        two_aligned} const UNALIGNED: [u16; 2] = write_unaligned();
//    assert_eq! (UNALIGNED, [u16::from_ne_bytes([0x00, 0x23]), u16::from_ne_bytes([0x45, 0x00])]);
//
//
//
//
//
//
//
//
//
//
//