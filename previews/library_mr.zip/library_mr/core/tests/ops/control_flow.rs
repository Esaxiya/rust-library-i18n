use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // हे स्थिर पृष्ठभागाचे क्षेत्र नाही, परंतु एलएलव्हीएम आत्ता आत्ताच त्याचा फायदा घेऊ शकत नसला तरीही, त्यांच्यामध्ये एक्स 100 एक्स स्वस्त ठेवण्यास मदत करते.
    //
    // (दुर्दैवाने निकाल आणि पर्याय विसंगत आहेत, म्हणून कंट्रोलफ्लो दोघांशी जुळत नाही.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}