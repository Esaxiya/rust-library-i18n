#![feature(no_core)]
#![no_core]

// हे झेड 0 क्रेट 0 झेड का आवश्यक आहे यासाठी rustc-std-कार्यक्षेत्र-कोर पहा.

// लिबॉलोकमधील allocलोक मॉड्यूलशी विवाद टाळण्यासाठी झेडकेरेट 0 झेडचे नाव बदला.
extern crate alloc as foo;

pub use foo::*;