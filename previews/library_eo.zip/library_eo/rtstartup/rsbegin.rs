// rsbegin.o kaj rsend.o estas la tiel nomata "compiler runtime startup objects".
// Ili enhavas kodon bezonatan por ĝuste pravalorizi la rultempan kompililon.
//
// Kiam efektivigebla aŭ dylib-bildo estas ligita, ĉiuj uzanto-kodo kaj bibliotekoj estas "sandwiched" inter ĉi tiuj du objektaj dosieroj, do kodo aŭ datumoj de rsbegin.o fariĝas unuaj en la respektivaj sekcioj de la bildo, dum kodo kaj datumoj de rsend.o fariĝas la lastaj.
// Ĉi tiu efiko povas esti uzata por meti simbolojn ĉe la komenco aŭ fino de sekcio, kaj ankaŭ por enmeti iujn ajn bezonatajn kapliniojn aŭ piedliniojn.
//
// Rimarku, ke la efektiva modula enirejo situas en la C-rultempa startobjekto (kutime nomata `crtX.o`), kiu tiam alvokas komencajn revokojn de aliaj rultempaj eroj (registritaj per ankoraŭ alia speciala bilda sekcio).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Markas komencon de la staka kadro malstreĉu informan sekcion
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Grata spaco por interna librotenado de malvolviĝilo.
    // Ĉi tio estas difinita kiel `struct object` en $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Malvolvi informajn rutinojn pri registration/deregistration.
    // Vidu la dokumentojn de libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // registri malstreĉajn informojn pri lanĉo de modulo
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // malregistriĝi ĉe ĉesigo
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-specifa init/uninit-rutina registriĝo
    pub mod mingw_init {
        // La startaj objektoj de MinGW (crt0.o/dllcrt0.o) alvokos tutmondajn konstruilojn en la .ctors kaj .dtors-sekcioj je ekfunkciigo kaj eliro.
        // Ĉe DLL-oj, ĉi tio fariĝas kiam la DLL estas ŝarĝita kaj malŝarĝita.
        //
        // La ligilo ordigos la sekciojn, kio certigas, ke niaj alvokoj troviĝas ĉe la fino de la listo.
        // Ĉar konstruiloj funkcias laŭ inversa ordo, ĉi tio certigas, ke niaj revokoj estas la unuaj kaj lastaj ekzekutitaj.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: C-komencaj revokoj
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .kuracistoj. *: C-finaj revokoj
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}