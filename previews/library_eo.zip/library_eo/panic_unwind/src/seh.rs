//! Windows SEH
//!
//! Ĉe Windows (nuntempe nur ĉe MSVC), la defaŭlta mekanismo pri escepto traktas Structured Exception Handling (SEH).
//! Ĉi tio tute diferencas ol Nana-bazita escepta pritraktado (ekz. Kion uzas aliaj unix-platformoj) rilate al kompilaj internoj, do LLVM devas havi multan ekstran subtenon por SEH.
//!
//! Unuvorte, kio okazas ĉi tie estas:
//!
//! 1. La funkcio `panic` nomas la norman funkcion Windows `_CxxThrowException` por ĵeti similan C++ -escepton, ekigante la malvolvan procezon.
//! 2.
//! Ĉiuj surteriĝaj kusenoj generitaj de la kompililo uzas la personecan funkcion `__CxxFrameHandler3`, funkcion en la CRT, kaj la malvolva kodo en Windows uzos ĉi tiun personecan funkcion por plenumi ĉiun purigan kodon sur la stako.
//!
//! 3. Ĉiuj vokoj generitaj de kompililo al `invoke` havas surteriĝan kuseneton kiel instrukcion `cleanuppad` LLVM, kiu indikas la komencon de la puriga rutino.
//! La personeco (en paŝo 2, difinita en la CRT) respondecas pri prizorgado de la purigaj rutinoj.
//! 4. Finfine la "catch"-kodo en la interna `try` (generita de la kompililo) estas plenumita kaj indikas, ke kontrolo devas reveni al Rust.
//! Ĉi tio estas farita per `catchswitch` plus `catchpad`-instrukcio en LLVM-IR-terminoj, fine redonante normalan kontrolon al la programo per `catchret`-instrukcio.
//!
//! Iuj specifaj diferencoj de la gcc-bazita escepta uzado estas:
//!
//! * Rust ne havas laŭmendan personecan funkcion, ĝi anstataŭe estas *ĉiam*`__CxxFrameHandler3`.Aldone, neniu ekstra filtrado estas realigita, do ni finas kapti iujn ajn C++ -esceptojn, kiuj similas al tiaj, kiujn ni ĵetas.
//! Notu, ke ĵeti escepton en Rust estas nedifinita konduto ĉiuokaze, do ĉi tio devas esti bona.
//! * Ni havas iujn datumojn por transdoni trans la malstreĉan limon, specife `Box<dyn Any + Send>`.Kiel ĉe Dwarf-esceptoj ĉi tiuj du montriloj estas konservitaj kiel utila ŝarĝo en la escepto mem.
//! Sur MSVC, tamen, ne necesas kroma amasa atribuo ĉar la alvoko-stako konserviĝas dum filtrilaj funkcioj estas plenumataj.
//! Ĉi tio signifas, ke la montriloj pasas rekte al `_CxxThrowException`, kiuj tiam estas rekuperitaj en la filtrila funkcio por esti skribitaj al la staka kadro de la propra `try`.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Ĉi tio devas esti Opcio ĉar ni kaptas la escepton per referenco kaj ĝia detruilo estas ekzekutita per la rultempa C++ .
    // Kiam ni elprenas la Keston el la escepto, ni devas lasi la escepton en valida stato por ke ĝia detruilo funkciu sen duoble faligi la Keston.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Unue, tuta aro da tipaj difinoj.Estas kelkaj platformo-specifaj strangaĵoj ĉi tie, kaj multaj, kiuj simple malkaŝe kopiis de LLVM.La celo de ĉio ĉi estas efektivigi la `panic`-funkcion sube per alvoko al `_CxxThrowException`.
//
// Ĉi tiu funkcio prenas du argumentojn.La unua estas montrilo al la datumoj, kiujn ni transdonas, kiu ĉi-kaze estas nia objekto trait.Sufiĉe facile trovebla!La sekva tamen estas pli komplika.
// Ĉi tio estas montrilo al `_ThrowInfo`-strukturo, kaj ĝi ĝenerale celas simple priskribi la ĵetitan escepton.
//
// Nuntempe la difino de ĉi tiu tipo [1] estas iom harplena, kaj la ĉefa kuriozaĵo (kaj diferenco de la interreta artikolo) estas, ke sur 32-bitaj la montriloj estas montriloj, sed sur 64-bitaj la montriloj estas esprimitaj kiel 32-bitaj kompensoj de la Simbolo `__ImageBase`.
//
// La makrooj `ptr_t` kaj `ptr!` en la subaj moduloj estas uzataj por esprimi ĉi tion.
//
// La labirinto de tipaj difinoj ankaŭ atente sekvas tion, kion LLVM elsendas por tia speco de operacio.Ekzemple, se vi kompilas ĉi tiun C++ -kodon en MSVC kaj elsendas la LLVM-IR:
//
//      #include <stdint.h>
//
//      strukt rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      malplena foo() { rust_panic a = {0, 1};
//          ĵeti a;}
//
// Esence tion ni provas imiti.Plej multaj konstantaj valoroj sube estis nur kopiitaj de LLVM,
//
// Ĉiukaze ĉi tiuj strukturoj estas ĉiuj konstruitaj en simila maniero, kaj ĝi estas nur iom vorteca por ni.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Rimarku, ke ni intence ignoras regulojn pri nommanĝado ĉi tie: ni ne volas, ke C++ povu kapti Rust panics simple deklarante `struct rust_panic`.
//
//
// Kiam vi modifas, certigu, ke la tipa nomĉeno ĝuste kongruas kun tiu uzata en `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // La ĉefa `\x01`-bajto ĉi tie efektive estas magia signalo al LLVM por *ne* apliki iun alian mistraktadon kiel prefiksado kun `_`-signo.
    //
    //
    // Ĉi tiu simbolo estas la tabelo uzata de `std::type_info` de C++ .
    // Objektoj de tipo `std::type_info`, tajpaj priskribiloj, havas montrilon al ĉi tiu tabelo.
    // Tippriskribiloj estas referencitaj per la C++ EH-strukturoj supre difinitaj kaj kiujn ni konstruas sube.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Ĉi tiu tipa priskribilo estas uzata nur kiam oni ĵetas escepton.
// La kaptaĵoparto estas pritraktita per la interna provo, kiu generas sian propran TypeDescriptor.
//
// Ĉi tio estas bona, ĉar la rultempo de MSVC uzas komparan ĉenon ĉe la tipa nomo por kongrui kun TypeDescriptors anstataŭ kun montrilo-egaleco.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destructor uzita se la kodo C++ decidas kapti la escepton kaj faligi ĝin sen disvastigi ĝin.
// La kapta parto de la provo interna starigos la unuan vorton de la escepta objekto al 0 tiel ke ĝi estos transsaltita de la detruanto.
//
// Notu, ke x86 Windows uzas la "thiscall"-vokan konvencion por C++ -membraj funkcioj anstataŭ la defaŭlta "C"-voka konvencio.
//
// La funkcio exception_copy estas iom speciala ĉi tie: ĝi estas alvokita de la rultempo de MSVC sub bloko try/catch kaj la panic, kiun ni generas ĉi tie, estos uzata kiel rezulto de la escepta kopio.
//
// Ĉi tio estas uzata de la C++ -rultempo por subteni kaptajn esceptojn kun std::exception_ptr, kiun ni ne povas subteni ĉar Box<dyn Any>ne kloneblas.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException funkcias tute sur ĉi tiu staka kadro, do ne necesas alimaniere transdoni `data` al la amaso.
    // Ni nur pasas stakmontrilon al ĉi tiu funkcio.
    //
    // La ManuallyDrop necesas ĉi tie, ĉar ni ne volas, ke Escepto estu forigita dum malvolviĝo.
    // Anstataŭe ĝi estos faligita de exception_cleanup, kiun alvokas la rultempa C++ .
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Ĉi tio ... eble ŝajnas surpriza, kaj pravige.Ĉe 32-bita MSVC la montriloj inter ĉi tiuj strukturoj estas nur tio, montriloj.
    // Tamen sur 64-bita MSVC, la montriloj inter strukturoj estas sufiĉe esprimitaj kiel 32-bitaj ofsetoj de `__ImageBase`.
    //
    // Sekve, ĉe 32-bita MSVC ni povas deklari ĉiujn ĉi montrilojn en la supre "statika".
    // Ĉe 64-bita MSVC, ni devus esprimi subtrahon de montriloj per statiko, kion Rust nuntempe ne permesas, do ni ne povas efektive fari tion.
    //
    // La sekva plej bona afero estas do plenigi ĉi tiujn strukturojn dum rultempo (paniko jam estas la "slow path").
    // Do ĉi tie ni reinterpretas ĉiujn ĉi montrilajn kampojn kiel 32-bitajn entjerojn kaj tiam konservas la koncernan valoron en ĝi (atomece, ĉar samtempa panics povas okazi).
    //
    // Teknike la rultempo probable faros neatomikan legadon de ĉi tiuj kampoj, sed teorie ili neniam legas la *malĝustan* valoron do ĝi ne devus esti tro malbona ...
    //
    // Ĉiukaze ni esence bezonas fari ion tian ĝis ni povos esprimi pli da operacioj per statiko (kaj eble ni neniam povos).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // NULA utila ŝarĝo ĉi tie signifas, ke ni alvenis ĉi tien de la kaptaĵo (...) de __rust_try.
    // Ĉi tio okazas kiam ne-Rust eksterlanda escepto estas kaptita.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Tion postulas la kompililo por ekzisti (ekz. Ĝi estas langobjekto), sed ĝi neniam estas vokita de la kompililo ĉar __C_specific_handler aŭ _except_handler3 estas la personeca funkcio, kiu estas ĉiam uzata.
//
// Tial ĉi tio estas nur abortanta ĝermo.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}