//! Malvolvi panics por Miri.
use alloc::boxed::Box;
use core::any::Any;

// La speco de la utila ŝarĝo, kiun la Miri-motoro disvastigas por ni.
// Devas esti montrilo.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Miri-provizita ekstera funkcio por komenci malvolvi.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // La utila ŝarĝo, kiun ni transdonas al `miri_start_panic`, estos ĝuste la argumento, kiun ni ricevas en `cleanup` sube.
    // Do ni nur skatolas ĝin unufoje, por akiri ion kiel montrilo.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Rekuperu la suban `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}