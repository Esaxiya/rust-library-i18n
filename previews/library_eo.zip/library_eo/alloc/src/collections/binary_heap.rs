//! Prioritata vico efektivigita kun duuma amaso.
//!
//! Enmeto kaj eksplodo de la plej granda elemento havas *O*(log(*n*))-tempan kompleksecon.
//! Kontroli la plej grandan elementon estas *O*(1).Konvertado de vector al duuma amaso povas esti farita surloke, kaj havas *O*(*n*) kompleksecon.
//! Binara amaso ankaŭ povas esti konvertita al ordigita vector surloke, permesante ĝin uzi por *O*(*n*\*log(* n*))-surloka amaso.
//!
//! # Examples
//!
//! Ĉi tio estas pli granda ekzemplo, kiu efektivigas [Dijkstra's algorithm][dijkstra] por solvi la [shortest path problem][sssp] sur [directed graph][dir_graph].
//!
//! Ĝi montras kiel uzi [`BinaryHeap`] kun kutimaj specoj.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // La prioritata vico dependas de `Ord`.
//! // Eksplicite efektivigu la trait tiel la vico fariĝas min-amaso anstataŭ maks-amaso.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Rimarku, ke ni ordonas kostojn.
//!         // En kazo de egaleco ni komparas poziciojn, ĉi tiu paŝo necesas por efektivigi efektivigojn de `PartialEq` kaj `Ord`.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` necesas efektivigi ankaŭ.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Ĉiu nodo estas reprezentita kiel `usize`, por pli mallonga efektivigo.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // La plej mallonga vojalgoritmo de Dijkstra.
//!
//! // Komencu ĉe `start` kaj uzu `dist` por spuri la nunan plej mallongan distancon al ĉiu nodo.Ĉi tiu efektivigo ne efikas memore, ĉar ĝi eble lasos duplikatajn nodojn en la vico.
//! //
//! // Ĝi ankaŭ uzas `usize::MAX` kiel gardostarantan valoron, por pli simpla efektivigo.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [nodo]=nuna plej mallonga distanco de `start` al `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Ni estas ĉe `start`, kun nula kosto
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Ekzamenu la limon kun malpli kostaj nodoj unue (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // Alternative ni povus daŭre trovi ĉiujn plej mallongajn vojojn
//!         if position == goal { return Some(cost); }
//!
//!         // Grava ĉar ni eble jam trovis pli bonan manieron
//!         if cost > dist[position] { continue; }
//!
//!         // Por ĉiu nodo, kiun ni povas atingi, vidu, ĉu ni povas trovi manieron kun pli malalta kosto tra ĉi tiu nodo
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Se jes, aldonu ĝin al la limo kaj daŭrigu
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Malstreĉiĝo, ni nun trovis pli bonan manieron
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Celo ne atingebla
//!     None
//! }
//!
//! fn main() {
//!     // Jen la direktita grafeo, kiun ni uzos.
//!     // La nodnombroj egalrilatas al la malsamaj ŝtatoj, kaj la edge-pezoj simbolas la koston de movado de unu nodo al alia.
//!     //
//!     // Notu, ke la randoj estas unudirektaj.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // La grafeo estas prezentita kiel apuda listo, kie ĉiu indekso, responda al noda valoro, havas liston de elirantaj lateroj.
//!     // Elektita pro ĝia efikeco.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Nodo 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Nodo 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Nodo 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Nodo 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Nodo 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Prioritata vico efektivigita kun duuma amaso.
///
/// Ĉi tio estos maksimuma amaso.
///
/// Estas logika eraro, ke ero estu modifita tiel, ke la mendado de la ero rilate al iu ajn alia ero, kiel determinita de la `Ord` trait, ŝanĝiĝas dum ĝi estas en la amaso.
///
/// Ĉi tio normale eblas nur per `Cell`, `RefCell`, tutmonda stato, I/O aŭ nesekura kodo.
/// La konduto rezultanta de tia logika eraro ne estas specifita, sed ne rezultigos nedifinitan konduton.
/// Ĉi tio povus inkluzivi panics, malĝustajn rezultojn, nuligojn, memorajn likojn kaj nefinadon.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Tipinterferenco permesas al ni preterlasi eksplicitan tipan subskribon (kiu estus `BinaryHeap<i32>` en ĉi tiu ekzemplo).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Ni povas uzi kaŝrigardon por rigardi la sekvan eron en la amaso.
/// // En ĉi tiu kazo, ankoraŭ ne estas eroj, do ni ricevas Neniun.
/// assert_eq!(heap.peek(), None);
///
/// // Ni aldonu iujn partiturojn ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Nun rigardeto montras la plej gravan eron en la amaso.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Ni povas kontroli la longon de amaso.
/// assert_eq!(heap.len(), 3);
///
/// // Ni povas ripeti la erojn en la amaso, kvankam ili estas redonitaj laŭ hazarda ordo.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Se ni anstataŭe aperigos ĉi tiujn partiturojn, ili devas reveni laŭ ordo.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Ni povas malplenigi la amason de iuj ceteraj eroj.
/// heap.clear();
///
/// // La amaso nun devas esti malplena.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// Aŭ `std::cmp::Reverse` aŭ laŭmenda `Ord`-efektivigo povas esti uzataj por fari `BinaryHeap`-min-amaso.
/// Ĉi tio igas `heap.pop()` redoni la plej malgrandan valoron anstataŭ la plej grandan.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Envolvu valorojn en `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Se ni aperigas ĉi tiujn interpunkciojn nun, ili devas reveni laŭ la inversa ordo.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Tempokomplekseco
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// La valoro por `push` estas atendata kosto;la metododokumentado donas pli detalan analizon.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Strukturo envolvante ŝanĝeblan referencon al la plej bonega ero sur `BinaryHeap`.
///
///
/// Ĉi tiu `struct` estas kreita per la metodo [`peek_mut`] sur [`BinaryHeap`].
/// Vidu ĝian dokumentadon por pli.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // SEKURECO: PeekMut estas nur kreita por ne-malplenaj amasoj.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // SAFE: PeekMut estas nur kreita por ne-malplenaj amasoj
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // SAFE: PeekMut estas nur kreita por ne-malplenaj amasoj
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Forigas la kaŝrigarditan valoron de la amaso kaj redonas ĝin.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Kreas malplenan `BinaryHeap<T>`.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Kreas malplenan `BinaryHeap` kiel maksimuma amaso.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Kreas malplenan `BinaryHeap` kun specifa kapablo.
    /// Ĉi tio preasignas sufiĉe da memoro por `capacity`-elementoj, tiel ke la `BinaryHeap` ne devas esti reasignita ĝis ĝi enhavas almenaŭ tiom da valoroj.
    ///
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Liveras ŝanĝeblan referencon al la plej granda ero en la duuma amaso, aŭ `None` se ĝi estas malplena.
    ///
    /// Note: Se la `PeekMut`-valoro estas likita, la amaso povas esti en malkonsekvenca stato.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Tempokomplekseco
    ///
    /// Se la ero estas modifita tiam la plej malbona kazo-tempokomplekso estas *O*(log(*n*)), alie ĝi estas *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Forigas la plej grandan eron de la duuma amaso kaj redonas ĝin, aŭ `None` se ĝi estas malplena.
    ///
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Tempokomplekseco
    ///
    /// La plej malbona kazo de `pop` sur amaso enhavanta *n*-elementojn estas *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // SEKURECO: !self.is_empty() signifas, ke self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Enŝovas eron sur la duuman amason.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Tempokomplekseco
    ///
    /// La atendata kosto de `push`, averaĝe super ĉiu ebla mendado de la elementoj puŝataj, kaj super sufiĉe granda nombro da puŝoj, estas *O*(1).
    ///
    /// Ĉi tiu estas la plej signifa kosto-metriko, kiam oni puŝas elementojn, kiuj *ne* estas jam en iu ordigita ŝablono.
    ///
    /// La tempokomplekseco malpliiĝas se elementoj estas puŝitaj laŭ ĉefe ascenda ordo.
    /// En la plej malbona kazo, elementoj estas puŝitaj laŭ kreskanta ordigita ordo kaj la amortizita kosto po puŝo estas *O*(log(*n*)) kontraŭ amaso enhavanta *n* elementojn.
    ///
    /// La plej malbona kazo de *sola* alvoko al `push` estas *O*(*n*).La plej malbona kazo okazas kiam la kapablo estas elĉerpita kaj bezonas regrandigon.
    /// La regrandiga kosto estis amortizita en la antaŭaj ciferoj.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // SEKURECO: Ĉar ni puŝis novan eron, tio signifas
        //  malnova_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Konsumas la `BinaryHeap` kaj redonas vector en ordo (ascending).
    ///
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // SEKURECO: `end` iras de `self.len() - 1` al 1 (ambaŭ inkluzivitaj),
            //  do ĝi ĉiam estas valida indekso alirebla.
            //  Estas sekure aliri indekson 0 (t.e. `ptr`), ĉar
            //  1 <=fino <self.len(), kio signifas self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // SEKURECO: `end` iras de `self.len() - 1` al 1 (ambaŭ inkluzivitaj) do:
            //  0 <1 <=fino <= self.len(), 1 <self.len() Kiu signifas 0 <fino kaj fino <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // La efektivigoj de sift_up kaj sift_down uzas nesekurajn blokojn por movi elementon el la vector (postlasante truon), movi laŭ la aliaj kaj movi la forigitan elementon reen en la vector ĉe la fina loko de la truo.
    //
    // La tipo `Hole` estas uzata por reprezenti ĉi tion, kaj certigu, ke la truo estas plenigita reen ĉe la fino de sia amplekso, eĉ sur panic.
    // Uzi truon reduktas la konstantan faktoron kompare kun uzado de interŝanĝoj, kio implikas duoble pli multajn movojn.
    //
    //
    //
    //

    /// # Safety
    ///
    /// La alvokanto devas garantii tiun `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Elprenu la valoron ĉe `pos` kaj kreu truon.
        // SEKURECO: La alvokanto garantias, ke pos <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // SEKURECO: hole.pos()> komenci>=0, kio signifas hole.pos()> 0
            //  kaj do hole.pos(), 1 ne povas subflui.
            //  Ĉi tio garantias tiun gepatron <hole.pos() do ĝi estas valida indekso kaj ankaŭ!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // SEKURECO: Same kiel supre
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Prenu elementon ĉe `pos` kaj movu ĝin laŭ la amaso, dum ĝiaj infanoj estas pli grandaj.
    ///
    ///
    /// # Safety
    ///
    /// La alvokanto devas garantii tiun `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // SEKURECO: La alvokanto garantias, ke pos <end <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Bukla invarianto: infano==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // komparu kun la plej granda el la du infanoj SEKURECO: infano <fino, 1 <self.len() kaj infano + 1 <fino <= self.len(), do ili estas validaj indeksoj.
            //
            //  infano==2 *hole.pos() + 1!= hole.pos() kaj infano + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 aŭ 2* hole.pos() + 2 povus superflui se T estas ZST
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // se ni jam estas en ordo, ĉesu.
            // SEKURECO: infano nun estas aŭ la maljuna infano aŭ la maljuna infano + 1
            //  Ni jam pruvis, ke ambaŭ estas <self.len() kaj!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // SEKURECO: same kiel supre.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // SEKURECO: &&kurta cirkvito, kio signifas tion en la
        //  dua kondiĉo estas jam vere, ke infano==fino, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // SEKURECO: infano estas jam pruvita kiel valida indekso kaj
            //  infano==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// La alvokanto devas garantii tiun `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // SEKURECO: pos <len estas garantiita de la alvokanto kaj
        //  evidente len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Prenu elementon ĉe `pos` kaj movu ĝin ĝis la amaso, tiam kribru ĝin ĝis ĝia pozicio.
    ///
    ///
    /// Note: Ĉi tio estas pli rapida, kiam oni scias, ke la elemento estas granda/devas esti pli proksima al la fundo.
    ///
    /// # Safety
    ///
    /// La alvokanto devas garantii tiun `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // SEKURECO: La alvokanto garantias, ke pos <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Bukla invarianto: infano==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // SEKURECO: infano <fino, 1 <self.len() kaj
            //  infano + 1 <end <= self.len(), do ili estas validaj indeksoj.
            //  infano==2 *hole.pos() + 1!= hole.pos() kaj infano + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 aŭ 2* hole.pos() + 2 povus superflui se T estas ZST
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // SEKURECO: Same kiel supre
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // SEKURECO: infano==fino, 1 <self.len(), do ĝi estas valida indekso
            //  kaj infano==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // SEKURECO: pos estas la pozicio en la truo kaj jam estis pruvita
        //  esti valida indekso.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // SEKURECO: n komenciĝas de self.len()/2 kaj malsupreniras al 0.
            //  La sola kazo kiam! (N <self.len()) estas se self.len() ==0, sed ĝi estas ekskludita de la bukla kondiĉo.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Movas ĉiujn elementojn de `other` en `self`, lasante `other` malplena.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` prenas O(len1 + len2)-operaciojn kaj ĉirkaŭ 2 *(len1 + len2) komparojn en la plej malbona kazo dum `extend` prenas O(len2* log(len1))-operaciojn kaj ĉirkaŭ 1 *len2* log_2(len1)-komparojn en la plej malbona kazo, supozante len1>= len2.
        // Por pli grandaj amasoj, la interkruciĝa punkto ne plu sekvas ĉi tiun rezonadon kaj estis determinita empirie.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Liveras ripetilon, kiu retrovas elementojn laŭ amasa ordo.
    /// La retrovitaj elementoj estas forigitaj de la originala amaso.
    /// La ceteraj elementoj estos forigitaj post falo laŭ amasa ordo.
    ///
    /// Note:
    /// * `.drain_sorted()` estas *O*(*n*\*log(* n*)); multe pli malrapida ol `.drain()`.
    ///   Vi devas uzi ĉi-lastan por plej multaj kazoj.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // forigas ĉiujn elementojn laŭ amasa ordo
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Konservas nur la elementojn specifitajn de la predikato.
    ///
    /// Alivorte, forigu ĉiujn elementojn `e` tiel ke `f(&e)` redonu `false`.
    /// La elementoj estas vizitataj en ordigita (kaj nespecifita) ordo.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // nur konservu parajn nombrojn
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Liveras ripetilon vizitantan ĉiujn valorojn en la suba vector, en arbitra ordo.
    ///
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Presi 1, 2, 3, 4 laŭ arbitra ordo
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Liveras ripetilon, kiu retrovas elementojn laŭ amasa ordo.
    /// Ĉi tiu metodo konsumas la originalan amason.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Liveras la plej grandan eron en la duuma amaso, aŭ `None` se ĝi estas malplena.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Tempokomplekseco
    ///
    /// Kosto estas *O*(1) en la plej malbona kazo.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Liveras la nombron da elementoj, kiujn la duuma amaso povas teni sen reasignado.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Rezervas la minimuman kapaciton por ekzakte `additional` pli da elementoj enmetotaj en la donita `BinaryHeap`.
    /// Faras nenion se la kapablo jam sufiĉas.
    ///
    /// Notu, ke la asignilo eble donas al la kolekto pli da spaco ol ĝi petas.
    /// Tial kapacito ne povas esti fidata ĝuste minimuma.
    /// Preferu [`reserve`] se future-enmetoj estas atendataj.
    ///
    /// # Panics
    ///
    /// Panics se la nova kapablo superfluas `usize`.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Rezervas kapaciton por almenaŭ `additional` pli da elementoj enmetotaj en la `BinaryHeap`.
    /// La kolekto eble rezervos pli da spaco por eviti oftajn reasignojn.
    ///
    /// # Panics
    ///
    /// Panics se la nova kapablo superfluas `usize`.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Forĵetas kiel eble plej multe da aldona kapablo.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Forĵetas kapaciton kun malsupra rando.
    ///
    /// La kapablo restos almenaŭ same granda kiel la longo kaj la provizita valoro.
    ///
    ///
    /// Se la nuna kapablo estas malpli ol la suba limo, ĉi tio estas senoperacio.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Konsumas la `BinaryHeap` kaj redonas la suban vector en arbitra ordo.
    ///
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Presos en iu ordo
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Liveras la longon de la duuma amaso.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Kontrolas ĉu la duuma amaso estas malplena.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Forigas la duuman amason, redonante ripetilon super la forigitaj elementoj.
    ///
    /// La elementoj estas forigitaj laŭ arbitra ordo.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Faligas ĉiujn erojn de la duuma amaso.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Truo reprezentas truon en tranĉaĵo t.e. indekso sen valida valoro (ĉar ĝi estis movita de aŭ duobligita).
///
/// En guto, `Hole` restarigos la tranĉaĵon plenigante la truan pozicion per la valoro, kiu estis origine forigita.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Kreu novan `Hole` ĉe indekso `pos`.
    ///
    /// Nesekura ĉar pos devas esti ene de la datuma tranĉaĵo.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // SEKURA: pos devas esti ene de la tranĉaĵo
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Liveras referencon al la forigita elemento.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Liveras referencon al la elemento ĉe `index`.
    ///
    /// Nesekura ĉar indekso devas esti ene de la datuma tranĉaĵo kaj ne egala al pos.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Movu truon al nova loko
    ///
    /// Nesekura ĉar indekso devas esti ene de la datuma tranĉaĵo kaj ne egala al pos.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // plenigu la truon denove
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// Ripetanto pri la elementoj de `BinaryHeap`.
///
/// Ĉi tiu `struct` estas kreita de [`BinaryHeap::iter()`].
/// Vidu ĝian dokumentadon por pli.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Forigu favore al `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// Posedanta ripetilo super la elementoj de `BinaryHeap`.
///
/// Ĉi tiu `struct` estas kreita de [`BinaryHeap::into_iter()`] (provizita de la `IntoIterator` trait).
/// Vidu ĝian dokumentadon por pli.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// Malpleniga ripetilo super la elementoj de `BinaryHeap`.
///
/// Ĉi tiu `struct` estas kreita de [`BinaryHeap::drain()`].
/// Vidu ĝian dokumentadon por pli.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// Malpleniga ripetilo super la elementoj de `BinaryHeap`.
///
/// Ĉi tiu `struct` estas kreita de [`BinaryHeap::drain_sorted()`].
/// Vidu ĝian dokumentadon por pli.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Forigas amasajn elementojn laŭ amasaj ordo.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Konvertas `Vec<T>` en `BinaryHeap<T>`.
    ///
    /// Ĉi tiu konvertiĝo okazas surloke, kaj havas *O*(*n*) tempokompleksecon.
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Konvertas `BinaryHeap<T>` en `Vec<T>`.
    ///
    /// Ĉi tiu konvertiĝo postulas neniun movadon aŭ atribuon de datumoj, kaj havas konstantan tempokompleksecon.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Kreas konsumantan ripetilon, tio estas unu, kiu movas ĉiun valoron el la duuma amaso en arbitra ordo.
    /// La duuma amaso ne povas esti uzata post voki ĉi tion.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Presi 1, 2, 3, 4 laŭ arbitra ordo
    /// for x in heap.into_iter() {
    ///     // x havas tipon i32, ne &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}