use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Aldonas ĉiujn ŝlosil-valorajn parojn de la kuniĝo de du suprenirantaj ripetiloj, pliigante `length`-variablon laŭ la vojo.Ĉi-lasta plifaciligas la alvokanton eviti likon kiam faligilo panikiĝas.
    ///
    /// Se ambaŭ ripetiloj produktas la saman ŝlosilon, ĉi tiu metodo faligas la paron de la maldekstra ripetilo kaj aldonas la paron de la dekstra ripetilo.
    ///
    /// Se vi volas, ke la arbo finiĝu laŭ strikte ascenda ordo, kiel por `BTreeMap`, ambaŭ ripetantoj devas produkti klavojn strikte ascendantaj, ĉiu pli granda ol ĉiuj klavoj en la arbo, inkluzive iujn ajn klavojn jam en la arbo post eniro.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Ni preparas kunfandi `left` kaj `right` en ordigita sinsekvo en linea tempo.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Dume ni konstruas arbon el la ordigita sinsekvo laŭ linea tempo.
        self.bulk_push(iter, length)
    }

    /// Puŝas ĉiujn ŝlosil-valorajn parojn ĝis la fino de la arbo, pliigante `length`-variablon laŭ la vojo.
    /// Ĉi-lasta faciligas al la alvokanto eviti likon kiam la ripetanto panikiĝas.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Ripetu ĉiujn ŝlosil-valorajn parojn, puŝante ilin en nodojn sur la ĝusta nivelo.
        for (key, value) in iter {
            // Provu puŝi ŝlosil-valoran paron en la nunan folian nodon.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Ne restas spaco, supreniru kaj puŝu tien.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Trovis nodon kun spaco maldekstre, puŝu ĉi tien.
                                open_node = parent;
                                break;
                            } else {
                                // Supreniru denove.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Ni estas supre, kreas novan radikan nodon kaj puŝas tien.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Puŝu ŝlosil-valoran paron kaj novan dekstran subarbon.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Iru malsupren al la plej dekstra folio denove.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Pliigu longan ĉiun ripeton, por certigi, ke la mapo faligas la aldonitajn elementojn eĉ se progresas la ripeto.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Ripeto por kunfandado de du ordigitaj vicoj en unu
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Se du klavoj egalas, redonas la ŝlosil-valoran paron de la ĝusta fonto.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}