use core::intrinsics;
use core::mem;
use core::ptr;

/// Ĉi tio anstataŭas la valoron malantaŭ la unika referenco `v` vokante la koncernan funkcion.
///
///
/// Se panic okazas en la fermo de `change`, la tuta procezo estos nuligita.
#[allow(dead_code)] // konservu kiel ilustraĵo kaj por future uzo
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Ĉi tio anstataŭas la valoron malantaŭ la unika referenco `v` vokante la koncernan funkcion, kaj redonas rezulton akiritan laŭvoje.
///
///
/// Se panic okazas en la fermo de `change`, la tuta procezo estos nuligita.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}