use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// Inkluzive serĉenda, same kiel `Bound::Included(T)`.
    Included(T),
    /// Ekskluziva serĉo, same kiel `Bound::Excluded(T)`.
    Excluded(T),
    /// Senkondiĉa inkluziva bendo, same kiel `Bound::Unbounded`.
    AllIncluded,
    /// Senkondiĉa ekskluziva bendo.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Serĉas donitan ŝlosilon en (sub) arbo estrata de la nodo, rekursie.
    /// Liveras `Found` kun la tenilo de la kongrua KV, se ekzistas.
    /// Alie, redonas `GoDown` kun la tenilo de la folio edge al kiu apartenas la ŝlosilo.
    ///
    /// La rezulto estas signifa nur se la arbo estas ordigita per ŝlosilo, kiel la arbo en `BTreeMap` estas.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// Descendas al la plej proksima nodo, kie la edge kongruanta kun la malsupra rando de la gamo diferencas de la edge kongruanta kun la supra rando, do la plej proksima nodo, kiu havas almenaŭ unu ŝlosilon en la gamo.
    ///
    ///
    /// Se trovite, redonas `Ok` kun tiu nodo, la paro de edge-indicoj en ĝi limigas la intervalon, kaj la respondan paron de limoj por daŭrigi la serĉadon en la infanaj nodoj, se la nodo estas interna.
    ///
    /// Se ne trovita, redonas `Err` kun la folio edge kongruanta kun la tuta gamo.
    ///
    /// La rezulto estas signifa nur se la arbo estas ordigita per ŝlosilo.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // Enlinii ĉi tiujn variablojn devas esti evitita.
        // Ni supozas, ke la limoj raportitaj de `range` restas samaj, sed kontraŭa efektivigo povus ŝanĝiĝi inter vokoj (#81138).
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// Trovas edge en la nodo limanta la malsupran limon de gamo.
    /// Ankaŭ redonas la malsupran limon uzotan por daŭrigi la serĉadon en la kongrua infana nodo, se `self` estas interna nodo.
    ///
    ///
    /// La rezulto estas signifa nur se la arbo estas ordigita per ŝlosilo.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// Klono de `find_lower_bound_edge` por la supra limo.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Serĉas donitan ŝlosilon en la nodo, sen rekursio.
    /// Liveras `Found` kun la tenilo de la kongrua KV, se ekzistas.
    /// Alie, redonas `GoDown` kun la tenilo de la edge kie la ŝlosilo povus esti trovita (se la nodo estas interna) aŭ kie la ŝlosilo povas esti enigita.
    ///
    ///
    /// La rezulto estas signifa nur se la arbo estas ordigita per ŝlosilo, kiel la arbo en `BTreeMap` estas.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// Liveras aŭ la KV-indekson en la nodo, ĉe kiu la ŝlosilo (aŭ ekvivalento) ekzistas, aŭ la edge-indekson, al kiu apartenas la ŝlosilo.
    ///
    ///
    /// La rezulto estas signifa nur se la arbo estas ordigita per ŝlosilo, kiel la arbo en `BTreeMap` estas.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// Trovas edge-indekson en la nodo limanta la malsupran limon de gamo.
    /// Ankaŭ redonas la malsupran limon uzotan por daŭrigi la serĉadon en la kongrua infana nodo, se `self` estas interna nodo.
    ///
    ///
    /// La rezulto estas signifa nur se la arbo estas ordigita per ŝlosilo.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// Klono de `find_lower_bound_index` por la supra limo.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}