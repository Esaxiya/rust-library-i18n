use core::marker::PhantomData;
use core::ptr::NonNull;

/// Modelas reborrow de iu unika referenco, kiam vi scias, ke la reborrow kaj ĉiuj ĝiaj posteuloj (te ĉiuj montriloj kaj referencoj derivitaj de ĝi) ne plu estos uzataj iam, post kio vi volas denove uzi la originalan unikan referencon .
///
///
/// La prunta kontrolilo kutime pritraktas ĉi tiun staplon de pruntoj por vi, sed iuj kontrolaj fluoj, kiuj plenumas ĉi tiun stapladon, estas tro komplikaj por ke la kompililo sekvu.
/// `DormantMutRef` permesas al vi kontroli prunton mem, tamen esprimante ĝian stakitan naturon, kaj enkapsuligante la krudan montrilan kodon necesan por fari ĉi tion sen nedifinita konduto.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Kaptu unikan prunton, kaj tuj pruntedonu ĝin.
    /// Por la kompililo, la vivo de la nova referenco estas la sama kiel la vivo de la originala referenco, sed vi promesis uzi ĝin por pli mallonga periodo.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // SEKURECO: ni tenas la prunteprenon tra `_marker`, kaj ni elmontras
        // nur ĉi tiu referenco, do ĝi estas unika.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Revenu al la unika prunto komence kaptita.
    ///
    /// # Safety
    ///
    /// La repago certe finiĝis, t.e. la referenco resendita de `new` kaj ĉiuj montriloj kaj referencoj derivitaj de ĝi ne plu devas esti uzataj.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // SEKURECO: niaj propraj sekurecaj kondiĉoj implicas, ke ĉi tiu referenco denove estas unika.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;