#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// La enhavo de la nova memoro ne estas komencita.
    Uninitialized,
    /// La nova memoro certas esti nuligita.
    Zeroed,
}

/// Malaltnivela ilo por pli ergonomie atribui, reasigni kaj repartigi bufron de memoro sur la amaso sen devi zorgi pri ĉiuj angulaj kazoj.
///
/// Ĉi tiu tipo estas bonega por konstrui viajn proprajn datumajn strukturojn kiel Vec kaj VecDeque.
/// Precipe:
///
/// * Produktas `Unique::dangling()` ĉe nulgrandaj specoj.
/// * Produktas `Unique::dangling()` per nul-longaj asignoj.
/// * Evitas liberigi `Unique::dangling()`.
/// * Kaptas ĉiujn superfluojn en kapacitaj komputadoj (antaŭenigas ilin al "capacity overflow" panics).
/// * Protektas kontraŭ 32-bitaj sistemoj asignantaj pli ol isize::MAX-bitokojn.
/// * Gardas vin kontraŭ superfluado de via longo.
/// * Vokas `handle_alloc_error` por eraraj atribuoj.
/// * Enhavas `ptr::Unique` kaj tiel dotas la uzanton kun ĉiuj rilataj avantaĝoj.
/// * Uzas la eksceson redonitan de la asignilo por uzi la plej grandan haveblan kapaciton.
///
/// Ĉi tiu tipo ĉiuokaze ne inspektas la memoron, kiun ĝi administras.Forlasita ĝi *liberigos* sian memoron, sed ĝi *ne* provos faligi ĝian enhavon.
/// Dependas de la uzanto de `RawVec` pritrakti la realajn aĵojn *stokitajn* ene de `RawVec`.
///
/// Rimarku, ke la troo de nulgrandaj specoj estas ĉiam senfina, do `capacity()` ĉiam redonas `usize::MAX`.
/// Ĉi tio signifas, ke vi devas zorgi, kiam vi ĉirkaŭiras ĉi tiun tipon per `Box<[T]>`, ĉar `capacity()` ne donos la longon.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Ĉi tio ekzistas ĉar `#[unstable]` `const fn`s ne bezonas konformi al `min_const_fn` kaj do ili ankaŭ ne povas esti nomataj en`min_const_fn`s.
    ///
    /// Se vi ŝanĝas `RawVec<T>::new` aŭ dependencojn, bonvolu zorgi ne enkonduki ion, kio vere malobservus `min_const_fn`.
    ///
    /// NOTE: Ni povus eviti ĉi tiun hakon kaj kontroli konformecon kun iu `#[rustc_force_min_const_fn]`-atributo, kiu postulas konformecon kun `min_const_fn` sed ne nepre permesas voki ĝin per `stable(...) const fn`/uzanta kodo ne ebliganta `foo` kiam `#[rustc_const_unstable(feature = "foo", issue = "01234")]` ĉeestas.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Kreas la plej grandan eblan `RawVec` (sur la sistema amaso) sen asigno.
    /// Se `T` havas pozitivan grandecon, tiam ĉi tio fariĝas `RawVec` kun kapablo `0`.
    /// Se `T` estas nul-granda, tiam ĝi produktas `RawVec` kun kapablo `usize::MAX`.
    /// Utila por efektivigi malfruan atribuon.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Kreas `RawVec` (sur la sistema amaso) kun ĝuste la kapacito kaj vicigaj postuloj por `[T; capacity]`.
    /// Ĉi tio ekvivalentas al vokado de `RawVec::new` kiam `capacity` estas `0` aŭ `T` estas nula.
    /// Notu, ke se `T` estas nula, tio signifas, ke vi *ne* ricevos `RawVec` kun la petita kapablo.
    ///
    /// # Panics
    ///
    /// Panics se la petita kapablo superas `isize::MAX`-bitokojn.
    ///
    /// # Aborts
    ///
    /// Ĉesigas OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Kiel `with_capacity`, sed garantias ke la bufro estas nuligita.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Rekonstruas `RawVec` de montrilo kaj kapablo.
    ///
    /// # Safety
    ///
    /// La `ptr` devas esti asignita (sur la sistema amaso), kaj kun la donita `capacity`.
    /// La `capacity` ne povas superi `isize::MAX` por grandaj specoj.(nur zorgo pri 32-bitaj sistemoj).
    /// ZST vectors eble havas kapaciton ĝis `usize::MAX`.
    /// Se la `ptr` kaj `capacity` venas de `RawVec`, tiam tio estas garantiita.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Malgrandaj Vecs estas mutaj.Saltu al:
    // - 8 se la elementograndeco estas 1, ĉar iuj amasaj asigniloj probable rondigos peton de malpli ol 8 bajtoj al almenaŭ 8 bajtoj.
    //
    // - 4 se elementoj estas mezgrandaj (<=1 KiB).
    // - 1 alie, por eviti malŝpari tro da spaco por tre mallongaj Vecs.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Kiel `new`, sed parametrigita super la elekto de asignilo por la redonita `RawVec`.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` signifas "unallocated".nulgrandaj specoj estas ignorataj.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Kiel `with_capacity`, sed parametrigita super la elekto de asignilo por la redonita `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Kiel `with_capacity_zeroed`, sed parametrigita super la elekto de asignilo por la redonita `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Konvertas `Box<[T]>` en `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Konvertas la tutan bufron en `Box<[MaybeUninit<T>]>` kun la specifita `len`.
    ///
    /// Notu, ke ĉi tio ĝuste rekonstruos iujn ajn `cap`-ŝanĝojn, kiuj eble estis faritaj.(Vidu priskribon de tipo por detaloj.)
    ///
    /// # Safety
    ///
    /// * `len` devas esti pli granda aŭ egala al la plej ĵus petita kapablo, kaj
    /// * `len` devas esti malpli ol aŭ egala al `self.capacity()`.
    ///
    /// Notu, ke la petita kapacito kaj `self.capacity()` povus diferenci, ĉar atribuanto povus entute loki kaj redoni pli grandan memorblokon ol petite.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Sanity-check unu duono de la sekureca postulo (ni ne povas kontroli la alian duonon).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Ni evitas `unwrap_or_else` ĉi tie ĉar ĝi ŝveligas la kvanton de LLVM-IR kreita.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Rekonstruas `RawVec` de montrilo, kapablo kaj asignilo.
    ///
    /// # Safety
    ///
    /// La `ptr` devas esti asignita (per la donita asignilo `alloc`), kaj kun la donita `capacity`.
    /// La `capacity` ne povas superi `isize::MAX` por grandaj specoj.
    /// (nur zorgo pri 32-bitaj sistemoj).
    /// ZST vectors eble havas kapaciton ĝis `usize::MAX`.
    /// Se la `ptr` kaj `capacity` venas de `RawVec` kreita per `alloc`, tiam tio estas garantiita.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Akiras krudan montrilon al la komenco de la asigno.
    /// Notu, ke ĉi tio estas `Unique::dangling()` se `capacity == 0` aŭ `T` estas nula.
    /// En la unua kazo, vi devas zorgi.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Akiras la kapaciton de la asigno.
    ///
    /// Ĉi tio ĉiam estos `usize::MAX` se `T` estas nula.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Liveras komunan referencon al la atribuilo subtenanta ĉi tiun `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Ni havas asignitan parton de memoro, do ni povas preteriri rultempajn kontrolojn por akiri nian nunan aranĝon.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Certigas, ke la bufro enhavas almenaŭ sufiĉan spacon por enteni `len + additional`-elementojn.
    /// Se ĝi ne jam havas sufiĉe da kapablo, reasignos sufiĉe da spaco plus komfortan malstreĉan spacon por amortizi *O*(1) konduton.
    ///
    /// Limigos ĉi tiun konduton, se ĝi nenecese kaŭzus sin al panic.
    ///
    /// Se `len` superas `self.capacity()`, ĉi tio eble ne efektive asignas la petitan spacon.
    /// Ĉi tio ne vere estas nesekura, sed la nesekura kodo, kiun vi * skribas, kiu dependas de la konduto de ĉi tiu funkcio, povas rompiĝi.
    ///
    /// Ĉi tio estas ideala por efektivigi grand-puŝan operacion kiel `extend`.
    ///
    /// # Panics
    ///
    /// Panics se la nova kapablo superas `isize::MAX`-bitokojn.
    ///
    /// # Aborts
    ///
    /// Ĉesigas OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // rezervo ĉesigus aŭ panikiĝus se la len superus `isize::MAX`, do ĉi tio estas sekura fari sen kontrolo nun.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// La sama kiel `reserve`, sed redonas erarojn anstataŭ paniki aŭ ĉesigi.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Certigas, ke la bufro enhavas almenaŭ sufiĉan spacon por enteni `len + additional`-elementojn.
    /// Se ĝi ne faras tion, reasignos la necesan minimuman eblan memoron.
    /// Ĝenerale ĉi tio estos ĝuste la kvanto da memoro necesa, sed principe la asignilo rajtas redoni pli ol ni petis.
    ///
    ///
    /// Se `len` superas `self.capacity()`, ĉi tio eble ne efektive asignas la petitan spacon.
    /// Ĉi tio ne vere estas nesekura, sed la nesekura kodo, kiun vi * skribas, kiu dependas de la konduto de ĉi tiu funkcio, povas rompiĝi.
    ///
    /// # Panics
    ///
    /// Panics se la nova kapablo superas `isize::MAX`-bitokojn.
    ///
    /// # Aborts
    ///
    /// Ĉesigas OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// La sama kiel `reserve_exact`, sed redonas erarojn anstataŭ paniki aŭ ĉesigi.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Malgrandigas la asignon ĝis la specifa kvanto.
    /// Se la donita kvanto estas 0, efektive tute repartigas.
    ///
    /// # Panics
    ///
    /// Panics se la donita kvanto estas *pli granda* ol la nuna kapablo.
    ///
    /// # Aborts
    ///
    /// Ĉesigas OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Revenas se la bufro bezonas kreski por plenumi la bezonatan ekstran kapablon.
    /// Ĉefe uzata por ebligi enliniajn rezervvokojn sen enlinia `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Ĉi tiu metodo estas ofte ekzempligita multajn fojojn.Do ni volas, ke ĝi estu kiel eble plej malgranda, por plibonigi kompilajn tempojn.
    // Sed ni ankaŭ volas, ke laŭ eble plej multe de ĝia enhavo estu statike komputebla, por ke la generita kodo funkciu pli rapide.
    // Tial ĉi tiu metodo estas zorge skribita tiel ke ĉio el la kodo, kiu dependas de `T`, estas ene de ĝi, dum kiel eble plej multe de la kodo, kiu ne dependas de `T`, estas en funkcioj ne-senmarkaj super `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Tion certigas la alvokaj kuntekstoj.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Ĉar ni redonas kapaciton de `usize::MAX` kiam `elem_size` estas
            // 0, atingi ĉi tien nepre signifas, ke la `RawVec` estas tro plenplena.
            return Err(CapacityOverflow);
        }

        // Nenion ni vere povas fari pri ĉi tiuj ĉekoj, bedaŭrinde.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Ĉi tio garantias eksponentan kreskon.
        // La duobligo ne povas superflui ĉar `cap <= isize::MAX` kaj la tipo de `cap` estas `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` estas sengenera super `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // La limoj de ĉi tiu metodo estas egale al tiuj de `grow_amortized`, sed ĉi tiu metodo kutime estas malpli ofte kreita, do ĝi estas malpli kritika.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Ĉar ni redonas kapaciton de `usize::MAX` kiam la tipa grandeco estas
            // 0, atingi ĉi tien nepre signifas, ke la `RawVec` estas tro plenplena.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` estas sengenera super `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Ĉi tiu funkcio estas ekster `RawVec` por minimumigi kompili-tempojn.Vidu la komenton supre `RawVec::grow_amortized` por detaloj.
// (La `A`-parametro ne gravas, ĉar la nombro de malsamaj `A`-specoj vidataj praktike estas multe pli malgranda ol la nombro de `T`-specoj.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Kontrolu la eraron ĉi tie por minimumigi la grandecon de `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // La atribuilo kontrolas pri egaleca egaleco
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Liberigas la memoron posedatan de `RawVec`*sen* provi faligi ĝian enhavon.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Centra funkcio por rezerva erarmanipulado.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Ni devas garantii la jenon:
// * Ni neniam asignas `> isize::MAX`-bajtajn grandajn objektojn.
// * Ni ne superfluas `usize::MAX` kaj efektive asignas tro malmulte.
//
// Ĉe 64-bita ni nur bezonas kontroli superfluaĵon ĉar provi atribui `> isize::MAX`-bitokojn certe malsukcesos.
// Ĉe 32-bita kaj 16-bita ni devas aldoni ekstran gardiston por tio, se ni kuros sur platformo, kiu povas uzi ĉiujn 4GB en uzanto-spaco, ekz. PAE aŭ x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Unu centra funkcio respondeca pri raportado de kapacito superfluas.
// Ĉi tio certigos, ke la koda generacio rilata al ĉi tiuj panics estas minimuma, ĉar ekzistas nur unu loko, kiun panics anstataŭ aro tra la tuta modulo.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}