//! Utilaĵoj por formati kaj presi `String`s.
//!
//! Ĉi tiu modulo enhavas la rultempan subtenon por la sintaksa etendaĵo [`format!`].
//! Ĉi tiu makroo estas efektivigita en la kompililo por elsendi vokojn al ĉi tiu modulo por formati argumentojn dum rultempo en ĉenojn.
//!
//! # Usage
//!
//! La makroo [`format!`] celas esti konata al tiuj, kiuj venas de la funkcioj `printf`/`fprintf` de C aŭ la funkcio `str.format` de Python.
//!
//! Iuj ekzemploj de la etendaĵo [`format!`] estas:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" kun ĉefaj nuloj
//! ```
//!
//! El ĉi tiuj, vi povas vidi, ke la unua argumento estas formato-ĉeno.La tradukilo postulas, ke ĉi tio estu ĉeno laŭvorta;ĝi ne povas esti variablo enirita (por plenumi validecon).
//! La kompililo tiam analizos la formatan ĉenon kaj determinos ĉu la listo de argumentoj donitaj taŭgas transdoni al ĉi tiu formato-ĉeno.
//!
//! Por konverti unu valoron al ĉeno, uzu la [`to_string`]-metodon.Ĉi tio uzos la [`Display`]-formatadon trait.
//!
//! ## Poziciaj parametroj
//!
//! Ĉiu formatada argumento rajtas specifi kiun valoran argumenton ĝi referencas, kaj se preterlasita ĝi supozas esti "the next argument".
//! Ekzemple, la formatoŝnuro `{} {} {}` prenus tri parametrojn, kaj ili estus formatitaj en la sama ordo kiel ili estas donitaj.
//! La formato-ĉeno `{2} {1} {0}` tamen formatus argumentojn en inversa ordo.
//!
//! Aferoj iomete malfacilas post kiam vi ekmiksas la du specojn de poziciaj specifiloj.La "next argument"-specifilo povas esti konsiderata kiel ripetilo super la argumento.
//! Ĉiufoje, kiam "next argument"-specifilo vidiĝas, la ripetilo progresas.Ĉi tio kondukas al tia konduto:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! La interna ripeto pri la argumento ne estis antaŭita antaŭ la momento, kiam la unua `{}` estas vidata, do ĝi presas la unuan argumenton.Tiam atinginte la duan `{}`, la ripetilo antaŭeniris al la dua argumento.
//! Esence parametroj, kiuj eksplicite nomas sian argumenton, ne influas parametrojn, kiuj ne nomas argumenton laŭ poziciaj specifiloj.
//!
//! Formata ĉeno necesas por uzi ĉiujn siajn argumentojn, alie ĝi estas kompila tempo-eraro.Vi eble rilatas al la sama argumento pli ol unufoje en la formato-ĉeno.
//!
//! ## Nomitaj parametroj
//!
//! Rust mem ne havas Python-similan ekvivalenton de nomitaj parametroj al funkcio, sed la [`format!`]-makroo estas sintaksa etendaĵo, kiu permesas al ĝi utiligi nomitajn parametrojn.
//! Nomitaj parametroj estas listigitaj ĉe la fino de la argumenta listo kaj havas la sintakson:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Ekzemple, la jenaj [`format!`]-esprimoj ĉiuj uzas nomitan argumenton:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Ne validas meti poziciajn parametrojn (tiuj sen nomoj) post argumentoj kun nomoj.Kiel ĉe poziciaj parametroj, ne validas provizi nomitajn parametrojn neuzatajn de la formato-ĉeno.
//!
//! # Formataj Parametroj
//!
//! Ĉiu argumento formatata povas esti transformita per kelkaj formataj parametroj (respondaj al `format_spec` en [the syntax](#syntax)). Ĉi tiuj parametroj influas la ĉenan reprezentadon de tio, kio estas formatita.
//!
//! ## Width
//!
//! ```
//! // Ĉiuj ĉi tiuj presas "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Ĉi tio estas parametro por la "minimum width", kiun la formato devas uzi.
//! Se la ĉeno de la valoro ne plenigas tiom multajn signojn, tiam la kompletigo specifita de fill/alignment estos uzata por okupi la bezonatan spacon (vidu sube).
//!
//! La valoro por la larĝo ankaŭ povas esti donita kiel [`usize`] en la listo de parametroj aldonante postfikson `$`, indikante ke la dua argumento estas [`usize`] specifanta la larĝon.
//!
//! Aludi al argumento kun la dolara sintakso ne influas la "next argument"-nombrilon, do kutime estas bona ideo raporti al argumentoj laŭ pozicio, aŭ uzi nomitajn argumentojn.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! La laŭvola pleniga signo kaj vicigo estas provizitaj kutime kune kun la parametro [`width`](#width).Ĝi devas esti difinita antaŭ `width`, tuj post la `:`.
//! Ĉi tio indikas, ke se la formatata valoro estas pli malgranda ol `width`, iuj kromaj signoj estos presitaj ĉirkaŭ ĝi.
//! Plenigado venas en la jenaj variantoj por diversaj vicigoj:
//!
//! * `[fill]<` - la argumento estas maldekstre vicigita en `width`-kolumnoj
//! * `[fill]^` - la argumento estas centrita en `width`-kolumnoj
//! * `[fill]>` - la argumento estas dekstre vicigita en `width`-kolumnoj
//!
//! La apriora [fill/alignment](#fillalignment) por nenombra estas spaco kaj maldekstre vicigita.La apriora por nombraj formatiloj ankaŭ estas spaca signo sed kun dekstra vicigo.
//! Se la `0`-flago (vidu sube) estas specifita por numeroj, tiam la implica pleniga signo estas `0`.
//!
//! Notu, ke vicigo eble ne estas efektivigita de iuj specoj.Precipe ĝi ne estas ĝenerale efektivigita por la `Debug` trait.
//! Bona maniero certigi, ke remburaĵo estas aplikata, estas formati vian enigaĵon, kaj tiam bloki ĉi tiun rezultan ĉenon por akiri vian rezulton:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Saluton Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Ĉi tiuj estas ĉiuj flagoj ŝanĝantaj la konduton de la formanto.
//!
//! * `+` - Ĉi tio celas nombrajn specojn kaj indikas, ke la signo ĉiam devas esti presita.Pozitivaj signoj neniam estas presitaj defaŭlte, kaj la negativa signo estas presitaj nur defaŭlte por la `Signed` trait.
//! Ĉi tiu flago indikas, ke la ĝusta signo (`+` aŭ `-`) devas ĉiam esti presita.
//! * `-` - Nuntempe ne uzata
//! * `#` - Ĉi tiu flago indikas, ke la pres-formo "alternate" devas esti uzata.La alternaj formoj estas:
//!     * `#?` - sufiĉe presu la formatadon [`Debug`]
//!     * `#x` - antaŭas la argumenton per `0x`
//!     * `#X` - antaŭas la argumenton per `0x`
//!     * `#b` - antaŭas la argumenton per `0b`
//!     * `#o` - antaŭas la argumenton per `0o`
//! * `0` - Ĉi tio estas uzata por indiki por entjeraj formatoj, ke la kompletigo al `width` devas esti farita per `0`-signo same kiel sign-konscia.
//! Formato kiel `{:08}` donus `00000001` por la entjero `1`, dum la sama formato donus `-0000001` por la entjero `-1`.
//! Rimarku, ke la negativa versio havas unu malpli da nulo ol la pozitiva versio.
//!         Notu, ke kompletigaj nuloj estas ĉiam metitaj post la signo (se ekzistas) kaj antaŭ la ciferoj.Se uzata kune kun la `#`-flago, validas simila regulo: kompletigaj nuloj estas enmetitaj post la prefikso sed antaŭ la ciferoj.
//!         La prefikso estas inkluzivita en la tuta larĝo.
//!
//! ## Precision
//!
//! Por nenombraj specoj, ĉi tio povas esti konsiderata kiel "maximum width".
//! Se la rezulta ĉeno estas pli longa ol ĉi tiu larĝo, tiam ĝi estas detranĉita ĝis tiom multaj signoj kaj tiu detranĉita valoro estas elsendita per taŭgaj `fill`, `alignment` kaj `width` se tiuj parametroj estas agorditaj.
//!
//! Por integraj tipoj, ĉi tio estas ignorata.
//!
//! Por glitkomaj tipoj, ĉi tio indikas kiom da ciferoj post la dekuma punkto devas esti presitaj.
//!
//! Estas tri eblaj manieroj por specifi la deziratan `precision`:
//!
//! 1. Entjero `.N`:
//!
//!    la entjero `N` mem estas la precizeco.
//!
//! 2. Entjero aŭ nomo sekvita de dolara signo `.N$`:
//!
//!    uzu formato *argumento*`N` (kiu devas esti `usize`) kiel precizeco.
//!
//! 3. Steleto `.*`:
//!
//!    `.*` signifas, ke ĉi tiu `{...}` estas asociita kun *du* formataj enigoj anstataŭ unu: la unua enigo enhavas la precizecon `usize`, kaj la dua enhavas la valoron por presi.
//!    Notu, ke ĉi-kaze, se oni uzas la formatan ĉenon `{<arg>:<spec>.*}`, tiam la parto `<arg>` rilatas al la* valoro * por presi, kaj la `precision` devas eniri la eniron antaŭ `<arg>`.
//!
//! Ekzemple, la sekvaj alvokoj ĉiuj presas la saman aferon `Hello x is 0.01000`:
//!
//! ```
//! // Saluton {arg 0 ("x")} estas {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Saluton {arg 1 ("x")} estas {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Saluton {arg 0 ("x")} estas {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Saluton {next arg ("x")} estas {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Saluton {next arg ("x")} estas {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Saluton {next arg ("x")} estas {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Dum ĉi tiuj:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! presi tri signife malsamajn aferojn:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! En iuj programlingvoj, la konduto de kordaj formataj funkcioj dependas de la loka agordo de la operaciumo.
//! La formataj funkcioj provizitaj de la norma biblioteko de Rust havas neniun koncepton pri lokaĵaro kaj produktos la samajn rezultojn en ĉiuj sistemoj sendepende de uzanto-agordo.
//!
//! Ekzemple, la sekva kodo ĉiam presos `1.5` eĉ se la loka sistemo uzos decimalan apartigilon krom punkto.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! La laŭvortaj signoj `{` kaj `}` povas esti inkluzivitaj en ĉeno antaŭante ilin per la sama signo.Ekzemple, la `{`-signo eskapas per `{{` kaj la `}`-signo eskapas per `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Resume, ĉi tie vi povas trovi la plenan gramatikon de formataj ĉenoj.
//! La sintakso por la uzata formatlingvo estas tirita de aliaj lingvoj, do ĝi ne estu tro fremda.Argumentoj estas formatitaj per Python-simila sintakso, signifante ke argumentoj estas ĉirkaŭitaj de `{}` anstataŭ la C-simila `%`.
//! La efektiva gramatiko por la sintakso de formato estas:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! En la supra gramatiko, `text` eble ne enhavas iujn ajn `'{'` aŭ `'}'`-signojn.
//!
//! # Formato de traits
//!
//! Kiam vi petas, ke argumento estu formatita kun aparta tipo, vi efektive petas, ke argumento atribuas al aparta trait.
//! Ĉi tio permesas formati plurajn realajn tipojn per `{:x}` (kiel [`i8`] kaj [`isize`]).La aktuala mapado de tipoj al traits estas:
//!
//! * *nenio* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] kun minusklaj deksesumaj entjeroj
//! * `X?` ⇒ [`Debug`] kun majusklaj deksesumaj entjeroj
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Tio ĉi signifas, ke ĉiu ajn argumento, kiu efektivigas la [`fmt::Binary`][`Binary`] trait, tiam povas esti formatita per `{:b}`.Efektivigoj estas provizitaj por ĉi tiuj traits por kelkaj primitivaj specoj ankaŭ de la norma biblioteko.
//!
//! Se neniu formato estas specifita (kiel en `{}` aŭ `{:6}`), tiam la formato trait uzata estas la [`Display`] trait.
//!
//! Kiam vi efektivigas formaton trait por via propra tipo, vi devos efektivigi metodon de la subskribo:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // nia kutima tipo
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Via tipo estos transdonita kiel kromreferenco `self`, kaj tiam la funkcio devas elsendi eliron en la fluon `f.buf`.Dependas de ĉiu formata trait-efektivigo ĝuste aliĝi al la petitaj formataj parametroj.
//! La valoroj de ĉi tiuj parametroj estos listigitaj en la kampoj de la [`Formatter`]-strukturo.Por helpi tion, la [`Formatter`]-strukturo ankaŭ provizas iujn helpajn metodojn.
//!
//! Aldone, la redona valoro de ĉi tiu funkcio estas [`fmt::Result`], kiu estas tipa kaŝnomo de [`Rezulto`]`<(),`[`std: : fmt::Eraro`] `>`.
//! Formataj efektivigoj devas certigi, ke ili disvastigas erarojn de la [`Formatter`] (ekz. Kiam oni vokas [`write!`]).
//! Tamen ili neniam devas redoni erarojn fuŝe.
//! Tio estas, ke formata efektivigo devas kaj povas resendi eraron nur se la enmetita [`Formatter`] redonas eraron.
//! Ĉi tio estas ĉar, kontraŭe al tio, kion la funkcio-subskribo povus sugesti, kordformado estas neeraripova operacio.
//! Ĉi tiu funkcio nur redonas rezulton, ĉar skribado al la suba rivereto povus malsukcesi kaj ĝi devas doni manieron disvastigi la fakton, ke eraro okazis sekurkopiante la stakon.
//!
//! Ekzemplo de efektivigo de la formato traits aspektus kiel:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // La `f`-valoro efektivigas la `Write` trait, kio estas la skribo!makroo atendas.
//!         // Rimarku, ke ĉi tiu formatado ignoras la diversajn flagojn provizitajn por formati ĉenojn.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Malsamaj traits permesas malsamajn formojn de eligo de tipo.
//! // La signifo de ĉi tiu formato estas presi la grandon de vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Respektu la formatajn flagojn per la helpa metodo `pad_integral` sur la objekto Formatter.
//!         // Vidu la metodan dokumentadon por detaloj, kaj la funkcio `pad` uzeblas por ŝovi ŝnurojn.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` kontraŭ `fmt::Debug`
//!
//! Ĉi tiuj du formataj traits havas apartajn celojn:
//!
//! - [`fmt::Display`][`Display`] efektivigoj asertas, ke la tipo povas esti fidele reprezentata kiel UTF-8-ĉeno ĉiam.Estas **ne** atendite, ke ĉiuj specoj efektivigas la [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] efektivigoj devas esti efektivigitaj por **ĉiuj** publikaj tipoj.
//!   Eligo tipe reprezentos la internan staton kiel eble plej fidele.
//!   La celo de la [`Debug`] trait estas faciligi elpurigan kodon Rust.Plejofte uzi `#[derive(Debug)]` sufiĉas kaj rekomendas.
//!
//! Iuj ekzemploj de la eligo de ambaŭ traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Rilataj makrooj
//!
//! Estas kelkaj rilataj makrooj en la familio [`format!`].Nuntempe efektivigitaj estas:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Ĉi tio kaj [`writeln!`] estas du makrooj uzataj por elsendi la formatan ĉenon al specifa rivereto.Ĉi tio estas uzata por malebligi interajn atribuojn de formataj ĉenoj kaj anstataŭe rekte skribi la eliron.
//! Sub la kapuĉo, ĉi tiu funkcio efektive alvokas la [`write_fmt`]-funkcion difinitan sur la [`std::io::Write`] trait.
//! Ekzempla uzado estas:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Ĉi tio kaj [`println!`] elsendas sian eliron al stdout.Simile al la makroo [`write!`], la celo de ĉi tiuj makrooj estas eviti mezajn atribuojn dum presado de eligo.Ekzempla uzado estas:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! La makrooj [`eprint!`] kaj [`eprintln!`] estas identaj al [`print!`] kaj [`println!`], respektive, krom ke ili elsendas sian produktaĵon al stderr.
//!
//! ### `format_args!`
//!
//! Ĉi tio estas kurioza makroo uzata por sekure pasi ĉirkaŭ maldiafana objekto priskribanta la formatan ĉenon.Ĉi tiu objekto ne bezonas krei iujn amasajn atribuojn, kaj ĝi nur referencas informojn sur la stako.
//! Sub la kapuĉo, ĉiuj rilataj makrooj estas efektivigitaj laŭ ĉi tio.
//! Unue, iu ekzempla uzado estas:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! La rezulto de la makroo [`format_args!`] estas valoro de tipo [`fmt::Arguments`].
//! Ĉi tiu strukturo tiam povas esti transdonita al la funkcioj [`write`] kaj [`format`] ene de ĉi tiu modulo por prilabori la formatan ĉenon.
//! La celo de ĉi tiu makroo estas eĉ pli malhelpi mezajn atribuojn dum traktado de formataj ĉenoj.
//!
//! Ekzemple, registrada biblioteko povus uzi la norman formatan sintakson, sed ĝi interne preterpasus ĉi tiun strukturon ĝis ĝi estos determinita, kien devas eliri la eliro.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// La funkcio `format` prenas [`Arguments`]-strukturon kaj redonas la rezultan formatitan ĉenon.
///
///
/// La [`Arguments`]-kazo povas esti kreita per la [`format_args!`]-makroo.
///
/// # Examples
///
/// Baza uzado:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Bonvolu noti, ke uzi [`format!`] povus esti preferinda.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}