#![stable(feature = "wake_trait", since = "1.51.0")]
//! Tipoj kaj Traits por labori kun nesinkronaj taskoj.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// La efektivigo de vekado de tasko ĉe ekzekutisto.
///
/// Ĉi tiu trait uzeblas por krei [`Waker`].
/// Ekzekutisto povas difini efektivigon de ĉi tiu trait, kaj uzi tion por konstrui Waker por transdoni al la taskoj plenumitaj sur tiu ekzekutisto.
///
/// Ĉi tiu trait estas memora sekura kaj ergonomia alternativo al konstruado de [`RawWaker`].
/// Ĝi subtenas la komunan ekzekutiston, en kiu la datumoj uzataj por veki taskon estas konservitaj en [`Arc`].
/// Iuj ekzekutistoj (precipe tiuj por enigitaj sistemoj) ne povas uzi ĉi tiun API, tial [`RawWaker`] ekzistas kiel alternativo por tiuj sistemoj.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Baza `block_on`-funkcio, kiu prenas future kaj plenumas ĝin ĝis la nuna fadeno.
///
/// **Note:** Ĉi tiu ekzemplo komercas ĝustecon por simpleco.
/// Por malebligi blokiĝojn, produktaĵaj efektivigoj ankaŭ devos trakti mezajn alvokojn al `thread::unpark` kaj ankaŭ nestitajn alvokojn.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Vekanto, kiu vekas la nunan fadenon kiam oni vokas lin.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Rulu future ĝis kompletigo en la nuna fadeno.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Alpinglu la future por ke ĝi estu enketita.
///     let mut fut = Box::pin(fut);
///
///     // Kreu novan kuntekston transdonotan al la future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Kuru la future ĝis la fino.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Veku ĉi tiun taskon.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Veku ĉi tiun taskon sen konsumado de la vekisto.
    ///
    /// Se ekzekutisto subtenas pli malmultekostan manieron veki sen konsumado de la vekanto, ĝi devas anstataŭigi ĉi tiun metodon.
    /// Defaŭlte ĝi klonas la [`Arc`] kaj vokas [`wake`] sur la klono.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // SEKURECO: Ĉi tio estas sekura ĉar raw_waker sekure konstruas
        // RawWaker de Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Ĉi tiu privata funkcio por konstrui RawWaker estas uzata prefere ol
// enmetante ĉi tion en la `From<Arc<W>> for RawWaker`-impl, por certigi, ke la sekureco de `From<Arc<W>> for Waker` ne dependas de la ĝusta forsendo de trait, anstataŭe ambaŭ implicoj nomas ĉi tiun funkcion rekte kaj eksplicite.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Pliigu la referencan kalkulon de la arko por kloni ĝin.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Vekiĝu laŭ valoro, movante la Arkon en la funkcion Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Veku per referenco, envolveru la vekanton en ManuallyDrop por eviti faligi ĝin
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Malpliigu la referencan kalkulon de la Arko dum falo
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}