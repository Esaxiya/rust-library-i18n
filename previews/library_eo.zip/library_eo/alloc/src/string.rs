//! UTF-8-kodigita, kreskigebla ĉeno.
//!
//! Ĉi tiu modulo enhavas la [`String`]-tipon, la [`ToString`] trait por konvertiĝo al ŝnuroj, kaj plurajn erarajn specojn, kiuj povas rezulti de laborado kun ["Ŝnuroj"].
//!
//!
//! # Examples
//!
//! Estas multaj manieroj krei novan [`String`] de ĉeno laŭvorta:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Vi povas krei novan [`String`] de ekzistanta kunligante kun
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Se vi havas vector de validaj UTF-8-bitokoj, vi povas krei [`String`] el ĝi.Vi povas fari la inverson ankaŭ.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Ni scias, ke ĉi tiuj bajtoj validas, do ni uzos `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// UTF-8-kodigita, kreskigebla ĉeno.
///
/// La `String`-tipo estas la plej ofta ĉena tipo, kiu posedas la enhavon de la ĉeno.Ĝi havas proksiman rilaton kun sia pruntita kolego, la primitiva [`str`].
///
/// # Examples
///
/// Vi povas krei `String` de [a literal string][`str`] kun [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Vi povas aldoni [`char`] al `String` per la metodo [`push`], kaj aldoni [`&str`] per la metodo [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Se vi havas vector de UTF-8-bitokoj, vi povas krei `String` de ĝi per la [`from_utf8`]-metodo:
///
/// ```
/// // iuj bajtoj, en vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Ni scias, ke ĉi tiuj bajtoj validas, do ni uzos `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// "Ŝnuro" ĉiam validas UTF-8.Ĉi tio havas kelkajn implicojn, la unua el ili estas, ke se vi bezonas ne-UTF-8-ĉenon, konsideru [`OsString`].Ĝi similas, sed sen la limo UTF-8.La dua implico estas, ke vi ne povas indeksi en `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Indeksado celas esti konstanta tempoperacio, sed kodigado UTF-8 ne permesas al ni fari ĉi tion.Krome ne klare kian aferon la indekso devas redoni: bajto, kodpunkto aŭ grafema areto.
/// La [`bytes`] kaj [`chars`]-metodoj redonas ripetojn super la unuaj du, respektive.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// 'String`s tool [`Deref`]`<Target=str>`, kaj tiel heredas ĉiujn metodojn de [` str`].Krome ĉi tio signifas, ke vi povas transdoni `String` al funkcio, kiu prenas [`&str`], uzante signon kaj (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Ĉi tio kreos [`&str`] de la `String` kaj transdonos ĝin. Ĉi tiu konvertiĝo estas tre malmultekosta, do ĝenerale funkcioj akceptos [`&str`] kiel argumentojn krom se ili bezonas `String` pro iu specifa kialo.
///
/// En iuj kazoj Rust ne havas sufiĉe da informoj por fari ĉi tiun konvertiĝon, nomatan [`Deref`]-devigo.En la sekva ekzemplo ĉena tranĉaĵo [`&'a str`][`&str`] efektivigas la trait `TraitExample`, kaj la funkcio `example_func` prenas ĉion, kio efektivigas la trait.
/// Ĉi-kaze Rust bezonus fari du implicajn konvertiĝojn, kiujn Rust ne havas la rimedojn por fari.
/// Tial la sekva ekzemplo ne kompiliĝos.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Estas du ebloj, kiuj funkcius anstataŭe.La unua estus ŝanĝi la linion `example_func(&example_string);` al `example_func(example_string.as_str());`, uzante la metodon [`as_str()`] por eksplicite ĉerpi la ĉenan tranĉaĵon enhavantan la ĉenon.
/// La dua maniero ŝanĝas `example_func(&example_string);` al `example_func(&*example_string);`.
/// Ĉi-kaze ni malreferencas `String` al [`str`][`&str`], tiam referencante la [`str`][`&str`] al [`&str`].
/// La dua maniero estas pli idioma, tamen ambaŭ funkcias por fari la konvertiĝon eksplicite anstataŭ fidi je la implica konvertiĝo.
///
/// # Representation
///
/// `String` konsistas el tri eroj: montrilo al iuj bajtoj, longo kaj kapablo.La montrilo montras al interna bufro, kiun `String` uzas por stoki siajn datumojn.La longo estas la nombro da bajtoj nuntempe stokitaj en la bufro, kaj la kapablo estas la grandeco de la bufro en bajtoj.
///
/// Kiel tia, la longo ĉiam estos malpli ol aŭ egala al la kapablo.
///
/// Ĉi tiu bufro ĉiam estas konservita sur la amaso.
///
/// Vi povas rigardi ĉi tiujn per la metodoj [`as_ptr`], [`len`] kaj [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Ĝisdatigu ĉi tion kiam vec_into_raw_parts estas stabiligita.
/// // Malhelpu aŭtomate faligi la datumojn de la Ŝnuro
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // rakonto havas dek naŭ bajtojn
/// assert_eq!(19, len);
///
/// // Ni povas rekonstrui Ŝnuron el ptr, len kaj kapablo.
/// // Ĉi tio estas tute nesekura, ĉar ni respondecas certigi, ke la komponantoj validas:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Se `String` havas sufiĉe da kapablo, aldoni elementojn al ĝi ne reasignos.Ekzemple, konsideru ĉi tiun programon:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Ĉi tio eligos la jenajn:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Unue ni tute ne havas memoron asignitan, sed dum ni aldonas la ĉenon, ĝi pliigas sian kapablon taŭge.Se ni anstataŭe uzas la [`with_capacity`]-metodon por unue atribui la ĝustan kapaciton:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Ni finas per malsama eligo:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Ĉi tie ne necesas asigni pli da memoro en la buklo.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Ebla erara valoro kiam oni konvertas `String` de UTF-8-bajto vector.
///
/// Ĉi tiu tipo estas la erara tipo por la metodo [`from_utf8`] ĉe [`String`].
/// Ĝi estas desegnita tiel por zorge eviti reasignojn: la [`into_bytes`]-metodo redonos la bajton vector uzatan en la konverta provo.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// La [`Utf8Error`]-speco provizita de [`std::str`] reprezentas eraron, kiu povas okazi dum konvertado de tranĉaĵo de [`u8`] s al [`&str`].
/// Tiusence ĝi estas analoga al `FromUtf8Error`, kaj vi povas akiri unu de `FromUtf8Error` per la [`utf8_error`]-metodo.
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Baza uzado:
///
/// ```
/// // iuj nevalidaj bajtoj, en vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Ebla erara valoro dum konvertado de `String` de UTF-16-bitokta tranĉaĵo.
///
/// Ĉi tiu tipo estas la erara tipo por la metodo [`from_utf16`] ĉe [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Baza uzado:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Kreas novan malplenan `String`.
    ///
    /// Konsiderante, ke la `String` estas malplena, ĉi tio ne asignos iun komencan bufron.Kvankam tio signifas, ke ĉi tiu komenca operacio estas tre malmultekosta, ĝi povas kaŭzi troan atribuadon poste kiam vi aldonas datumojn.
    ///
    /// Se vi havas ideon pri kiom da datumoj la `String` tenos, konsideru la metodon [`with_capacity`] por malebligi troan reasignadon.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Kreas novan malplenan `String` kun aparta kapablo.
    ///
    /// "Ŝnuroj" havas internan bufron por teni siajn datumojn.
    /// La kapablo estas la longo de tiu bufro, kaj povas esti pridemandata per la [`capacity`]-metodo.
    /// Ĉi tiu metodo kreas malplenan `String`, sed unu kun komenca bufro, kiu povas enteni `capacity`-bitokojn.
    /// Ĉi tio utilas, se vi eble aldonos multajn datumojn al la `String`, reduktante la nombron de reasignoj, kiujn ĝi devas fari.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Se la donita kapacito estas `0`, neniu asigno okazos, kaj ĉi tiu metodo estas identa al la [`new`]-metodo.
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // La Ŝnuro enhavas neniujn signojn, kvankam ĝi havas kapablon por pli
    /// assert_eq!(s.len(), 0);
    ///
    /// // Ĉi tiuj estas faritaj sen reasignado ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... sed ĉi tio eble igos la ĉenon reasigni
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): kun cfg(test) la eneca `[T]::to_vec`-metodo, necesa por ĉi tiu metododifino, ne haveblas.
    // Ĉar ni ne postulas ĉi tiun metodon por testado, mi simple malhelpos ĝin. NB vidu la slice::hack-modulon en slice.rs por pliaj informoj.
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Konvertas vector de bajtoj al `String`.
    ///
    /// Ĉeno ([`String`]) estas farita de bitokoj ([`u8`]), kaj vector de bitokoj ([`Vec<u8>`]) estas farita de bitokoj, do ĉi tiu funkcio konvertiĝas inter la du.
    /// Ne ĉiuj bitokaj tranĉaĵoj validas `String`s, tamen: `String` postulas, ke ĝi validas UTF-8.
    /// `from_utf8()` kontrolas por certigi, ke la bajtoj validas UTF-8, kaj poste faras la konvertiĝon.
    ///
    /// Se vi certas, ke la bajta tranĉaĵo estas valida UTF-8, kaj vi ne volas provoki la superkoston de la valideco-kontrolo, ekzistas nesekura versio de ĉi tiu funkcio, [`from_utf8_unchecked`], kiu havas la saman konduton sed preterlasas la kontrolon.
    ///
    ///
    /// Ĉi tiu metodo zorgos ne kopii la vector, por efiko.
    ///
    /// Se vi bezonas [`&str`] anstataŭ `String`, konsideru [`str::from_utf8`].
    ///
    /// La inverso de ĉi tiu metodo estas [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Liveras [`Err`] se la tranĉaĵo ne estas UTF-8 kun priskribo kial la donitaj bajtoj ne estas UTF-8.La vector, kiun vi enloĝis, ankaŭ estas inkluzivita.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// // iuj bajtoj, en vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Ni scias, ke ĉi tiuj bajtoj validas, do ni uzos `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Malĝustaj bajtoj:
    ///
    /// ```
    /// // iuj nevalidaj bajtoj, en vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Vidu la dokumentojn por [`FromUtf8Error`] por pliaj detaloj pri tio, kion vi povas fari kun ĉi tiu eraro.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Konvertas tranĉaĵon de bajtoj al ĉeno, inkluzive nevalidajn signojn.
    ///
    /// Kordoj estas faritaj de bajtoj ([`u8`]), kaj tranĉaĵo de bajtoj ([`&[u8]`][byteslice]) estas farita de bajtoj, do ĉi tiu funkcio konvertiĝas inter la du.Ne ĉiuj bitokaj tranĉaĵoj tamen estas validaj kordoj: ĉenoj devas esti validaj UTF-8.
    /// Dum ĉi tiu konvertiĝo, `from_utf8_lossy()` anstataŭigos iujn malvalidajn UTF-8-sekvencojn per [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], kiu aspektas tiel:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Se vi certas, ke la bajta tranĉaĵo validas UTF-8, kaj vi ne volas provoki la superkoston de la konvertiĝo, ekzistas nesekura versio de ĉi tiu funkcio, [`from_utf8_unchecked`], kiu havas la saman konduton sed preterlasas la kontrolojn.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Ĉi tiu funkcio redonas [`Cow<'a, str>`].Se nia bajta tranĉaĵo estas malvalida UTF-8, tiam ni devas enmeti la anstataŭajn signojn, kiuj ŝanĝos la grandecon de la ĉeno, kaj do postulos `String`.
    /// Sed se ĝi jam validas UTF-8, ni ne bezonas novan atribuon.
    /// Ĉi tiu revena tipo permesas al ni trakti ambaŭ kazojn.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// // iuj bajtoj, en vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Malĝustaj bajtoj:
    ///
    /// ```
    /// // iuj nevalidaj bajtoj
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Malkodu UTF-16-koditan vector `v` en `String`, redonante [`Err`] se `v` enhavas iujn malvalidajn datumojn.
    ///
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Ĉi tio ne fariĝas per kolekti: : <Result<_, _>> () pro agadkialoj.
        // FIXME: la funkcio povas esti simpligita denove kiam #48994 estas fermita.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Malkodu UTF-16-koditan tranĉaĵon `v` en `String`, anstataŭigante malvalidajn datumojn per [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// Male al [`from_utf8_lossy`], kiu redonas [`Cow<'a, str>`], `from_utf16_lossy` redonas `String`, ĉar la konvertiĝo de UTF-16 al UTF-8 bezonas memoran atribuon.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Malkonstruas `String` en ĝiajn krudajn erojn.
    ///
    /// Redonas la krudan montrilon al la subaj datumoj, la longo de la ĉeno (en bajtoj) kaj la asignita kapablo de la datumoj (en bajtoj).
    /// Ĉi tiuj estas la samaj argumentoj en la sama ordo kiel la argumentoj al [`from_raw_parts`].
    ///
    /// Nominte ĉi tiun funkcion, la alvokanto respondecas pri la memoro antaŭe administrita de la `String`.
    /// La sola maniero fari tion estas konverti la krudan montrilon, longon kaj kapaciton en `String` kun la funkcio [`from_raw_parts`], permesante al la detruanto plenumi la purigadon.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Kreas novan `String` de longo, kapablo kaj montrilo.
    ///
    /// # Safety
    ///
    /// Ĉi tio estas tre nesekura, pro la nombro de neŝanĝeblaj neŝanĝeblaj:
    ///
    /// * La memoro ĉe `buf` devas esti antaŭe asignita de la sama atribuilo, kiun uzas la norma biblioteko, kun bezonata vicigo de ekzakte 1.
    /// * `length` devas esti malpli ol aŭ egala al `capacity`.
    /// * `capacity` bezonas esti la ĝusta valoro.
    /// * La unuaj `length`-bitokoj ĉe `buf` devas esti validaj UTF-8.
    ///
    /// Malobservi ĉi tiujn povas kaŭzi problemojn kiel korupti la internajn datumajn strukturojn de la atribuilo.
    ///
    /// La posedo de `buf` efike transdoniĝas al la `String`, kiu tiam povas transdoni, reasigni aŭ ŝanĝi la enhavon de memoro montrita de la montrilo laŭplaĉe.
    /// Certigu, ke nenio alia uzas la montrilon post nomi ĉi tiun funkcion.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Ĝisdatigu ĉi tion kiam vec_into_raw_parts estas stabiligita.
    ///     // Malhelpu aŭtomate faligi la datumojn de la Ŝnuro
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Konvertas vector de bajtoj al `String` sen kontroli, ke la ĉeno enhavas validan UTF-8.
    ///
    /// Vidu la sekuran version, [`from_utf8`], por pli da detaloj.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Ĉi tiu funkcio estas nesekura ĉar ĝi ne kontrolas, ke la bajtoj transdonitaj al ĝi estas validaj UTF-8.
    /// Se ĉi tiu limo estas malobservita, ĝi povas kaŭzi problemojn pri memora sekureco kun uzantoj de future de la `String`, ĉar la resto de la norma biblioteko supozas, ke `String` validas UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// // iuj bajtoj, en vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Konvertas `String` en bajton vector.
    ///
    /// Ĉi tio konsumas la `String`, do ni ne bezonas kopii ĝian enhavon.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Eltiras ĉenan tranĉaĵon enhavantan la tutan `String`.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Konvertas `String` en ŝanĝeblan ĉenan tranĉaĵon.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Aldonas donitan kordotranĉon al la fino de ĉi tiu `String`.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Liveras la kapaciton de ĉi tiu "Ŝnuro", en bajtoj.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Certigas, ke la kapablo de ĉi tiu "Ŝnuro" estas almenaŭ `additional`-bitokoj pli granda ol ĝia longo.
    ///
    /// La kapablo povas esti pliigita per pli ol `additional`-bajtoj se ĝi elektas, por malebligi oftajn reasignojn.
    ///
    ///
    /// Se vi ne volas ĉi tiun "at least"-konduton, vidu la [`reserve_exact`]-metodon.
    ///
    /// # Panics
    ///
    /// Panics se la nova kapablo superfluas [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Ĉi tio eble ne efektive pliigas la kapablon:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s nun havas longon de 2 kaj kapaciton de 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Ĉar ni jam havas ekstran 8-kapaciton, nomante ĉi tion ...
    /// s.reserve(8);
    ///
    /// // ... ne efektive pliiĝas.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Certigas, ke la kapablo de ĉi tiu "Ŝnuro" estas `additional`-bitokoj pli granda ol ĝia longo.
    ///
    /// Pripensu uzi la [`reserve`]-metodon krom se vi absolute scias pli bone ol la asignilo.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics se la nova kapablo superfluas `usize`.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Ĉi tio eble ne efektive pliigas la kapablon:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s nun havas longon de 2 kaj kapaciton de 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Ĉar ni jam havas ekstran 8-kapaciton, nomante ĉi tion ...
    /// s.reserve_exact(8);
    ///
    /// // ... ne efektive pliiĝas.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Provas rezervi kapaciton por almenaŭ `additional` pli da elementoj enmetotaj en la donita `String`.
    /// La kolekto eble rezervos pli da spaco por eviti oftajn reasignojn.
    /// Post voki `reserve`, kapacito estos pli granda aŭ egala al `self.len() + additional`.
    /// Faras nenion se kapablo jam sufiĉas.
    ///
    /// # Errors
    ///
    /// Se la kapacito superfluas, aŭ la asignilo raportas fiaskon, tiam eraro revenas.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Antaŭ-rezervu la memoron, elirante se ni ne povas
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Nun ni scias, ke ĉi tio ne povas OOM meze de nia kompleksa laboro
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Provas rezervi la minimuman kapaciton por ekzakte `additional` pli da elementoj enmetotaj en la donita `String`.
    ///
    /// Post voki `reserve_exact`, kapacito estos pli granda aŭ egala al `self.len() + additional`.
    /// Faras nenion se la kapablo jam sufiĉas.
    ///
    /// Notu, ke la asignilo eble donas al la kolekto pli da spaco ol ĝi petas.
    /// Sekve, oni ne povas fidi, ke kapablo estas precize minimuma.
    /// Preferu `reserve` se future-enmetoj estas atendataj.
    ///
    /// # Errors
    ///
    /// Se la kapacito superfluas, aŭ la asignilo raportas fiaskon, tiam eraro revenas.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Antaŭ-rezervu la memoron, elirante se ni ne povas
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Nun ni scias, ke ĉi tio ne povas OOM meze de nia kompleksa laboro
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Malgrandigas la kapablon de ĉi tiu `String` egali ĝian longon.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Malpligrandigas la kapablon de ĉi tiu `String` kun suba limo.
    ///
    /// La kapablo restos almenaŭ same granda kiel la longo kaj la provizita valoro.
    ///
    ///
    /// Se la nuna kapablo estas malpli ol la suba limo, ĉi tio estas senoperacio.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Aldonas la donitan [`char`] al la fino de ĉi tiu `String`.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Liveras bajtan tranĉaĵon de la enhavo de ĉi tiu "Ŝnuro".
    ///
    /// La inverso de ĉi tiu metodo estas [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Mallongigas ĉi tiun `String` al la specifa longo.
    ///
    /// Se `new_len` estas pli granda ol la nuna longo de la ĉeno, ĉi tio ne efikas.
    ///
    ///
    /// Notu, ke ĉi tiu metodo ne efikas sur la asignita kapablo de la ĉeno
    ///
    /// # Panics
    ///
    /// Panics se `new_len` ne kuŝas sur [`char`]-limo.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Forigas la lastan signon de la ĉena bufro kaj redonas ĝin.
    ///
    /// Liveras [`None`] se ĉi tiu `String` estas malplena.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Forigas [`char`] de ĉi tiu `String` ĉe bajta pozicio kaj redonas ĝin.
    ///
    /// Ĉi tio estas operacio *O*(*n*), ĉar ĝi postulas kopii ĉiun elementon en la bufro.
    ///
    /// # Panics
    ///
    /// Panics se `idx` estas pli granda ol aŭ egala al la longo de la "Ŝnuro", aŭ se ĝi ne kuŝas sur [`char`]-limo.
    ///
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Forigu ĉiujn kongruaĵojn de ŝablono `pat` en la `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Matĉoj estos detektitaj kaj forigitaj ripete, do en kazoj, kiam ŝablonoj interkovras, nur la unua ŝablono estos forigita:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // SEKURECO: komenco kaj fino estos sur utf8-bitokaj limoj po
        // la dokumentoj de Searcher
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Konservas nur la signojn specifitajn de la predikato.
    ///
    /// Alivorte, forigu ĉiujn signojn `c` tiel ke `f(c)` redonu `false`.
    /// Ĉi tiu metodo funkcias modloko, vizitante ĉiun rolulon ekzakte unufoje en la originala ordo, kaj konservas la ordon de la retenitaj signoj.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// La ĝusta ordo povas esti utila por spuri eksteran staton, kiel indekso.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Indiku idx al la sekva signo
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Enmetas signon en ĉi tiun `String` ĉe bajta pozicio.
    ///
    /// Ĉi tio estas operacio *O*(*n*) ĉar ĝi postulas kopii ĉiun elementon en la bufro.
    ///
    /// # Panics
    ///
    /// Panics se `idx` estas pli granda ol la longo de la "Ŝnuro", aŭ se ĝi ne kuŝas sur [`char`]-limo.
    ///
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Enmetas kordan tranĉaĵon en ĉi tiun `String` ĉe bajta pozicio.
    ///
    /// Ĉi tio estas operacio *O*(*n*) ĉar ĝi postulas kopii ĉiun elementon en la bufro.
    ///
    /// # Panics
    ///
    /// Panics se `idx` estas pli granda ol la longo de la "Ŝnuro", aŭ se ĝi ne kuŝas sur [`char`]-limo.
    ///
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Liveras ŝanĝeblan referencon al la enhavo de ĉi tiu `String`.
    ///
    /// # Safety
    ///
    /// Ĉi tiu funkcio estas nesekura ĉar ĝi ne kontrolas, ke la bajtoj transdonitaj al ĝi estas validaj UTF-8.
    /// Se ĉi tiu limo estas malobservita, ĝi povas kaŭzi problemojn pri memora sekureco kun uzantoj de future de la `String`, ĉar la resto de la norma biblioteko supozas, ke `String` validas UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Liveras la longon de ĉi tiu `String`, en bajtoj, ne [`char`] aŭ grafemoj.
    /// Alivorte, eble ne estas tio, kion homo konsideras la longo de la ŝnuro.
    ///
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Liveras `true` se ĉi tiu `String` havas longon de nulo, kaj `false` alie.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Disigas la ĉenon en du ĉe la donita bajta indekso.
    ///
    /// Liveras nove asignitan `String`.
    /// `self` enhavas bitokojn `[0, at)`, kaj la redonita `String` enhavas bitokojn `[at, len)`.
    /// `at` devas esti ĉe la limo de kodpunkto UTF-8.
    ///
    /// Notu, ke la kapablo de `self` ne ŝanĝiĝas.
    ///
    /// # Panics
    ///
    /// Panics se `at` ne estas sur limo de kodpunkto `UTF-8`, aŭ se ĝi estas preter la lasta kodpunkto de la ĉeno.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Detranĉas ĉi tiun `String`, forigante ĉiujn enhavojn.
    ///
    /// Dum ĉi tio signifas, ke la `String` havos longon de nulo, ĝi ne tuŝas sian kapablon.
    ///
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Kreas malplenigan ripeton, kiu forigas la specifitan intervalon en la `String` kaj donas la forigitan `chars`.
    ///
    ///
    /// Note: La elementaro estas forigita eĉ se la ripetilo ne konsumiĝas ĝis la fino.
    ///
    /// # Panics
    ///
    /// Panics se la komenca punkto aŭ fina punkto ne kuŝas sur [`char`]-limo, aŭ se ili estas ekster limoj.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Forigu la gamon ĝis la β de la ĉeno
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Plena gamo malplenigas la ĉenon
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Memora sekureco
        //
        // La String-versio de Drain ne havas la memorajn sekurecajn problemojn de la vector-versio.
        // La datumoj estas nur simplaj bajtoj.
        // Ĉar la forigo de gamo okazas en Drop, se la ripeto Drain estas likita, la forigo ne okazos.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Elprenu du samtempajn pruntojn.
        // La &mut-Ŝnuro ne estos alirita ĝis ripeto finiĝos, en Drop.
        let self_ptr = self as *mut _;
        // SEKURECO: `slice::range` kaj `is_char_boundary` faras la taŭgajn limojn.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Forigas la specifitan gamon en la ĉeno kaj anstataŭigas ĝin per la donita ĉeno.
    /// La donita ĉeno ne bezonas esti la sama longo kiel la gamo.
    ///
    /// # Panics
    ///
    /// Panics se la komenca punkto aŭ fina punkto ne kuŝas sur [`char`]-limo, aŭ se ili estas ekster limoj.
    ///
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Anstataŭigu la gamon ĝis la β de la ĉeno
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Memora sekureco
        //
        // Replace_range ne havas la memorajn sekurecajn problemojn de vector Splice.
        // de la versio vector.La datumoj estas nur simplaj bajtoj.

        // AVERTO: Enmeti ĉi tiun variablon estus maltaŭga (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // AVERTO: Enmeti ĉi tiun variablon estus maltaŭga (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Uzi `range` denove estus maltaŭga (#81138) Ni supozas, ke la limoj raportitaj de `range` restas samaj, sed kontraŭa efektivigo povus ŝanĝiĝi inter vokoj.
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Konvertas ĉi tiun `String` en [`Skatolo`]`<`[`str`] `>`.
    ///
    /// Ĉi tio faligos ajnan troan kapablon.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Liveras tranĉaĵon de [`u8`] s-bajtoj provitaj konvertiĝi al `String`.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// // iuj nevalidaj bajtoj, en vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Liveras la bajtojn provitajn konverti al `String`.
    ///
    /// Ĉi tiu metodo estas zorge konstruita por eviti atribuon.
    /// Ĝi konsumos la eraron, movante la bitokojn, tiel ke ne necesas fari kopion de la bitokoj.
    ///
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// // iuj nevalidaj bajtoj, en vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Prenu `Utf8Error` por akiri pli da detaloj pri la konverta malsukceso.
    ///
    /// La [`Utf8Error`]-speco provizita de [`std::str`] reprezentas eraron, kiu povas okazi dum konvertado de tranĉaĵo de [`u8`] s al [`&str`].
    /// Tiusence ĝi estas analoga al `FromUtf8Error`.
    /// Vidu ĝian dokumentaron por pliaj detaloj pri ĝia uzado.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// // iuj nevalidaj bajtoj, en vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // la unua bajto ne validas ĉi tie
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Ĉar ni ripetas super `String`s, ni povas eviti almenaŭ unu atribuon ricevante la unuan ĉenon de la ripetilo kaj aldonante al ĝi ĉiujn postajn ĉenojn.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Ĉar ni ripetas super CoWs, ni povas (potentially) eviti almenaŭ unu atribuon ricevante la unuan eron kaj aldonante al ĝi ĉiujn postajn erojn.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Oportuna programo, kiu delegas al la programo por `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Kreas malplenan `String`.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Efektivigas la `+`-operatoron por interligi du ĉenojn.
///
/// Ĉi tio konsumas la `String` maldekstre kaj reuzas sian bufron (kreskigante ĝin se necese).
/// Ĉi tio estas farita por eviti atribui novan `String` kaj kopii la tutan enhavon pri ĉiu operacio, kio kondukus al *O*(*n*^ 2) rultempo dum konstruado de *n*-bajta ĉeno per ripeta interligo.
///
///
/// La ŝnuro ĉe la dekstra flanko estas nur pruntita;ĝia enhavo estas kopiita en la redonitan `String`.
///
/// # Examples
///
/// Kombinado de du 'Ŝnuroj' prenas la unuan laŭ valoro kaj pruntas la duan:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` estas movita kaj ne plu uzebla ĉi tie.
/// ```
///
/// Se vi volas daŭre uzi la unuan `String`, vi povas kloni ĝin kaj aldoni la klonon anstataŭe:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` ankoraŭ validas ĉi tie.
/// ```
///
/// Kunligi `&str`-tranĉaĵojn povas esti farita per konvertado de la unua al `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Efektivigas la `+=`-operatoron por aldono al `String`.
///
/// Ĉi tio havas la saman konduton kiel la [`push_str`][String::push_str]-metodo.
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Tipo kaŝnomo por [`Infallible`].
///
/// Ĉi tiu kaŝnomo ekzistas por malantaŭa kongruo, kaj eble estos malrekomendata.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// trait por konverti valoron al `String`.
///
/// Ĉi tiu trait estas aŭtomate efektivigita por iu ajn tipo, kiu efektivigas la [`Display`] trait.
/// Kiel tia, `ToString` ne devas esti efektivigita rekte:
/// [`Display`] devas esti efektivigita anstataŭe, kaj vi ricevas la `ToString`-efektivigon senpage.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Konvertas la donitan valoron al `String`.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// En ĉi tiu efektivigo, la `to_string`-metodo panics se la `Display`-efektivigo redonas eraron.
/// Ĉi tio indikas malĝustan efektivigon de `Display`, ĉar `fmt::Write for String` neniam donas eraron mem.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Ofta gvidlinio estas ne enmeti ĝeneralajn funkciojn.
    // Tamen forigi `#[inline]` de ĉi tiu metodo kaŭzas neglekteblajn regresojn.
    // Vidu <https://github.com/rust-lang/rust/pull/74852>, la lastan provon provi forigi ĝin.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Konvertas `&mut str` en `String`.
    ///
    /// La rezulto estas atribuita al la amaso.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: testo ekas libstd, kio kaŭzas erarojn ĉi tie
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Konvertas la donitan boksitan `str`-tranĉaĵon al `String`.
    /// Rimarkinde estas, ke la tranĉaĵo `str` estas posedata.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Konvertas la donitan `String` al boksita `str`-tranĉaĵo posedata.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Konvertas ĉenan tranĉaĵon en pruntitan varianton.
    /// Neniu amaso estas farita, kaj la ĉeno ne estas kopiita.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Konvertas Ĉenon en Posedatan varianton.
    /// Neniu amaso estas farita, kaj la ĉeno ne estas kopiita.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Konvertas Ĉenan referencon en Pruntitan varianton.
    /// Neniu amaso estas farita, kaj la ĉeno ne estas kopiita.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Konvertas la donitan `String` al vector `Vec`, kiu tenas valorojn de tipo `u8`.
    ///
    /// # Examples
    ///
    /// Baza uzado:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Malpleniga ripeto por `String`.
///
/// Ĉi tiu strukturo estas kreita per la metodo [`drain`] ĉe [`String`].
/// Vidu ĝian dokumentadon por pli.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Estos uzata kiel&'mut Ŝnuro en la detruilo
    string: *mut String,
    /// Komenco de forigenda parto
    start: usize,
    /// Fino de forigenda parto
    end: usize,
    /// Nuna restanta gamo forigebla
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Uzu Vec::drain.
            // "Reaffirm" la limoj kontrolas por eviti ke panic-kodo estu enmetita denove.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Liveras la restantan (sub) ĉenon de ĉi tiu ripetilo kiel tranĉaĵo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: malkomento AsRef sugestas sube dum stabiligo.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Malkomenti dum stabiligado de `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>por Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> por Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}