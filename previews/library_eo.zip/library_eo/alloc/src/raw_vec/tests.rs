use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Skribi teston pri integriĝo inter triaj asigniloj kaj `RawVec` estas iom malfacila ĉar la `RawVec`-API ne malkaŝas fuŝeblajn asignajn metodojn, do ni ne povas kontroli, kio okazas kiam elĉerpilo estas elĉerpita (preter detektado de panic).
    //
    //
    // Anstataŭe ĉi tio nur kontrolas, ke la `RawVec`-metodoj almenaŭ trapasas la Allocator API kiam ĝi rezervas stokadon.
    //
    //
    //
    //
    //

    // Muta asignilo, kiu konsumas fiksan kvanton da brulaĵo antaŭ ol atribui provojn komencas fiaski.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (kaŭzas reallokon, tiel uzante 50 + 150=200 unuojn da brulaĵo)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Unue, `reserve` asignas kiel `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 estas pli ol duoblo de 7, do `reserve` devas funkcii kiel `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 estas malpli ol duono de 12, do `reserve` devas kreski eksponente.
        // Al la horo de skribado de ĉi tiu testo kreskfaktoro estas 2, do nova kapablo estas 24, tamen kreskfaktoro de 1.5 ankaŭ estas en ordo.
        //
        // Tial `>= 18` asertas.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}